

# Generated at 2022-06-10 23:43:14.348271
# Unit test for constructor of class GalaxyError
def test_GalaxyError():

    # Case: code = 200, galaxy_error = None, galaxy_msg = None
    http_error = HTTPError('url', 200, 'An error occured', {}, None)
    message = 'test_message'
    error = GalaxyError(http_error, message)
    assert error.http_code == 200
    assert error.url == 'url'
    assert error.message == 'test_message (HTTP Code: 200, Message: An error occured)'

    # Case: code = 200, galaxy_error = '', galaxy_msg = None
    http_error = HTTPError('url', 200, 'An error occured', {}, None)
    message = 'test_message'
    error = GalaxyError(http_error, message)
    assert error.http_code == 200
    assert error.url == 'url'
    assert error.message

# Generated at 2022-06-10 23:43:27.774710
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Assert that if self.name is less than other.name then GalaxyAPI.__lt__ returns True
    assert GalaxyAPI('foo','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','').__lt__(GalaxyAPI('goo','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''))
    # Assert that if self.name is greater than other.name then GalaxyAPI.__lt__ returns False

# Generated at 2022-06-10 23:43:35.318980
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert not is_rate_limit_exception(GalaxyError('', '', 500))
    assert not is_rate_limit_exception(GalaxyError('', '', 400))
    assert is_rate_limit_exception(GalaxyError('', '', 429))
    assert is_rate_limit_exception(GalaxyError('', '', 520))


# TODO: document this

# Generated at 2022-06-10 23:43:42.384956
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise HTTPError('/path/to/galaxy', 404, 'Not Found', {}, None)
    except HTTPError as e:
        error = GalaxyError(e, 'Galaxy not available')
        assert error.http_code == 404
        assert error.url == '/path/to/galaxy'
        assert str(error) == 'Galaxy not available (HTTP Code: 404, Message: Not Found Code: Unknown)'



# Generated at 2022-06-10 23:43:50.107933
# Unit test for function g_connect
def test_g_connect():
    @g_connect(versions=[u'v2'])
    def test_method(self):
        return

    class TestClass(object):
        _available_api_versions = {}
        api_server = 'http://example.com'
        name = 'Galaxy'

        def _call_galaxy(self, url, **kwargs):
            return {u'available_versions': {u'v1': u"v1/"}}

    test_obj = TestClass()
    try:
        test_method(test_obj)
    except AnsibleError:
        pass
    else:
        raise Exception("g_connect didn't raise an AnsibleError when the API version wasn't available")

    test_obj._call_galaxy = lambda x, **kw: {}

# Generated at 2022-06-10 23:43:56.865743
# Unit test for function cache_lock
def test_cache_lock():
    lock = threading.Lock()
    lock.acquire()
    assert lock.acquire(False) is False
    try:
        @cache_lock
        def my_func(lock, *args):
            lock.release()
            lock.acquire()
            return args

        assert my_func(lock, my_func, lock) == (my_func, lock)
        assert lock.acquire(False) is True
    finally:
        lock.release()



# Generated at 2022-06-10 23:43:59.487042
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    GF = GalaxyAPI
    assert GF('galaxy.XXXX').__lt__(GF('galaxy.YYYY')) == True

# Generated at 2022-06-10 23:44:09.665163
# Unit test for function get_cache_id
def test_get_cache_id():
    raw_url = "http://localhost:8080/api/v2/collections/"
    cache_id = get_cache_id(raw_url)
    assert cache_id == "localhost:8080"
    raw_url = "http://user:human@localhost:8080/api/v2/collections/"
    cache_id = get_cache_id(raw_url)
    assert cache_id == "localhost:8080"
    raw_url = "http://user:human@api.galaxy.ansible.com/api/v2/collections/"
    cache_id = get_cache_id(raw_url)
    assert cache_id == "api.galaxy.ansible.com"

# Generated at 2022-06-10 23:44:15.450449
# Unit test for function cache_lock
def test_cache_lock():
    import time

    def time_sleep(sec):
        time.sleep(sec)
    time_start = time.time()
    time_sleep = cache_lock(time_sleep)
    time_sleep(1)
    time_sleep(2)
    time_sleep(3)
    time_sleep = cache_lock(time_sleep)
    time_sleep(4)
    time_sleep(5)
    time_sleep(6)
    time_end = time.time()
    assert time_end - time_start > 14, 'We cannot hold cache_lock'



# Generated at 2022-06-10 23:44:19.767914
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def foo(name, age):
        return "Hi, I am {0}, I am {1} years old".format(name, age)
    assert foo("Gao", 22) == "Hi, I am Gao, I am 22 years old"



# Generated at 2022-06-10 23:45:36.436188
# Unit test for function g_connect
def test_g_connect():
    # create a class to test:
    class obj(object):

        def __init__(self):
            self.api_server = None
            self._available_api_versions = {}
            self.name = None
        def _call_galaxy(self, url, method='GET', error_context_msg=None, cache=False):
            # This is an stub, passing all requests.
            data = {
                'available_versions': {
                    'v1': 'v1/'
                }
            }
            return data

    test_url = 'https://test.galaxy.com/api/'
    test_class = obj()
    test_class.name = 'test_galaxy'
    test_class.api_server = test_url


# Generated at 2022-06-10 23:45:38.876005
# Unit test for function g_connect
def test_g_connect():
    """Verify attrs_to_skip is populated with expected objects."""
    # assert keep == set(["namespace", "name", "content_type", "download_count"])


# Generated at 2022-06-10 23:45:49.258105
# Unit test for function g_connect
def test_g_connect():
    # Note: this test only checks that the method decorator works.
    @g_connect(versions=['v1', 'v2'])
    def f(self):
        return 42

    class MyClass(object):
        def __init__(self):
            self._available_api_versions = {'v1': 'v1/', 'v2': 'v2/'}
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'galaxy.ansible.com'
        def __call__(self, *args, **kwargs):
            return f(self, *args, **kwargs)

    assert MyClass()() == 42



# Generated at 2022-06-10 23:45:57.712509
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    from ansible.module_utils.six.moves import http_client as httplib
    http_error = httplib.HTTPException(None)
    http_error.code = 500
    http_error.read = lambda: b'{"default": "something bad happened"}'
    http_error.geturl = lambda: 'https://galaxy.ansible.com/api/v2/'

    message = 'Tried to find galaxy API root at galaxy.ansible.com but no "available_versions" are available on https://galaxy.ansible.com'
    err = GalaxyError(http_error, message)

    assert err.http_code == 500
    assert err.url == 'https://galaxy.ansible.com/api/v2/'

# Generated at 2022-06-10 23:46:00.662735
# Unit test for function g_connect
def test_g_connect():
    @g_connect([u'v2', u'v3'])
    def test_g_connect_func_1():
        return u'v3'
    assert test_g_connect_func_1() == u'v3'
test_g_connect()



# Generated at 2022-06-10 23:46:10.281838
# Unit test for function g_connect
def test_g_connect():
    class TestObject(object):
        def __init__(self):
            self._available_api_versions = {}
            self.name = "test"
            self.api_server = ""

        def _call_galaxy(self, endpoint, method, error_context_msg, cache=False):
            return {"available_versions": {"v2": "v2/"}}

    def test1():
        pass

    def test2(self):
        return "foo"
    t = TestObject()
    t.test1 = g_connect(["v1", "v2"])(test1)
    res = t.test1()
    assert res is None
    t.test2 = g_connect(["v2", "v3"])(test2)
    res = t.test2()
    assert res == "foo"



# Generated at 2022-06-10 23:46:23.388490
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import mock

    # invalid json
    http_error = mock.MagicMock()
    http_error.code = 500
    http_error.geturl.return_value = u'https://galaxy.ansible.com/api/v1/'
    http_error.read.return_value = u'{"error_message": "No such resource: test"}'
    http_error.reason = u'Internal Server Error'
    err = GalaxyError(http_error, u'Ansible Error Message')
    assert err.http_code == 500
    assert err.url == u'https://galaxy.ansible.com/api/v1/'
    assert err.message == u'Ansible Error Message (HTTP Code: 500, Message: Internal Server Error)'

    # valid json from v1 api url

# Generated at 2022-06-10 23:46:27.732844
# Unit test for function g_connect
def test_g_connect():
    client = GalaxyClient(api_server='https://galaxy.ansible.com', validate_certs=True)
    assert client.api_server is None
    client._available_api_versions = {u'v1': u'v1/'}
    assert client.api_server == 'https://galaxy.ansible.com/api/'

# Generated at 2022-06-10 23:46:35.423151
# Unit test for function g_connect
def test_g_connect():
    test_versions = ['v1', 'v2']
    def test_function(self, *args, **kwargs):
        print(self)
        return self
    test_class = collections.namedtuple('test_class', ['function'])
    function = test_function.__get__(test_class, test_class)
    decorated_function = g_connect(test_versions)(function)
    decorated_function()
test_g_connect()



# Generated at 2022-06-10 23:46:37.685943
# Unit test for function cache_lock
def test_cache_lock():
    i = 0
    @cache_lock
    def plus_one():
        nonlocal i
        i += 1
        return i
    assert plus_one() == 1
    assert plus_one() == 2
    assert plus_one() == 3


# Generated at 2022-06-10 23:47:07.209458
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('404')
    error = GalaxyError(http_error, '')
    assert error.http_code == 404
    assert error.url == '404'
    assert error.message == ''



# Generated at 2022-06-10 23:47:17.689471
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    test_data = (
        (HTTPError('msg', 401, 'reason', {}, None), False),
        (HTTPError('msg', 403, 'reason', {}, None), False),
        (HTTPError('msg', 429, 'reason', {}, None), True),
        (HTTPError('msg', 520, 'reason', {}, None), True),
        # The following are refined GalaxyErrors
        (GalaxyError('msg', 401, 'reason', {}, None), False),
        (GalaxyError('msg', 403, 'reason', {}, None), False),
        (GalaxyError('msg', 429, 'reason', {}, None), True),
        (GalaxyError('msg', 520, 'reason', {}, None), True),
    )

# Generated at 2022-06-10 23:47:25.173023
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI(GalaxyApiTokenCredential(''),
                           GalaxyApiServerCredential('https://galaxy.ansible.com'),
                           'galaxy.ansible.com',
                           GalaxyApiVersionCredential('v2'),
                           insecure=True)
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api.name == 'galaxy.ansible.com'
    assert galaxy_api.available_api_versions == {'v2': '/api/v2/'}
    assert galaxy_api.default_api_version == 'v2'
    assert galaxy_api.allow_redirects is False
    assert galaxy_api.timeout == 10



# Generated at 2022-06-10 23:47:27.790713
# Unit test for function g_connect
def test_g_connect():
    def func():
        pass

    f = g_connect(['v1'])(func)
    assert f.__name__ == func.__name__


# Generated at 2022-06-10 23:47:41.269728
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    test_url = 'https://galaxy.com/api/v1/content/namespaces'
    test_msg = 'Some error message'
    test_code = '404'
    test_reason = 'Test reason'
    test_json_resp = {"default": "Test message"}

    # Test when http_error.read() returns text
    http_error = HTTPError(test_url, test_code, test_reason, None, None, None, None)
    http_error.read = lambda: test_json_resp
    galaxierr = GalaxyError(http_error, test_msg)

    assert galaxierr.http_code == int(test_code)
    assert galaxierr.url == test_url
    assert galaxierr.message == "Some error message (HTTP Code: 404, Message: Test message)"

# Generated at 2022-06-10 23:47:55.624248
# Unit test for constructor of class GalaxyError
def test_GalaxyError():

    # Case 1: Code: 429, Message: Too Many Requests
    # Case 2: Code: 422, Message: Unprocessable Entity
    # Case 3: Code: 400, Message: Bad Request
    # Case 4: Code: 404, Message: Not Found
    # Case 5: Code: 403, Message: Forbidden
    # Case 6: Code: 401, Message: Unauthorized
    # Case 7: Code: 401, Message: Unauthorized, ErrorMessage: {"default": "Authentication credentials were not provided."}
    error_dict = {'default': 'Invalid data provided'}
    http_error = HTTPError('https://galaxy.ansible.com', 429, 'Too Many Requests', {}, None)
    exception = GalaxyError(http_error, "Error performing a task")

# Generated at 2022-06-10 23:48:03.989363
# Unit test for function g_connect
def test_g_connect():
    from ansible.galaxy import Galaxy
    from ansible.module_utils.api import g_connect
    from ansible.errors import AnsibleError

    class TestGalaxy(Galaxy):
        def __init__(self, name, server, force_api_version, galaxy_api_key, require_ansible_collections,
                     ignore_certs):
            self.name = name
            self.api_server = server
            self.api_key = galaxy_api_key
            self.require_ansible_collections = require_ansible_collections
            self.ignore_certs = ignore_certs
            self._available_api_versions = {}
            self.force_api_version = force_api_version

        def get_galaxy_server_api_endpoint(self, version):
            return self._available_api

# Generated at 2022-06-10 23:48:10.797478
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429, reason="rate limit exceeded"))
    assert is_rate_limit_exception(GalaxyError(http_code=520, reason="rate limit exceeded"))
    assert not is_rate_limit_exception(GalaxyError(http_code=403, reason="rate limit exceeded"))
    assert not is_rate_limit_exception(GalaxyError(http_code=429, reason="other error"))


# Generated at 2022-06-10 23:48:13.983015
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    galaxy_error = GalaxyError(MockHTTPError(404, 'NOT FOUND'), 'File not found')
    assert galaxy_error.message == 'File not found (HTTP Code: 404, Message: NOT FOUND)'



# Generated at 2022-06-10 23:48:21.986011
# Unit test for function g_connect
def test_g_connect():
    """ """
    try:
        # First time decorator is called, the method initializes the connection.
        connection = GalaxyAPI(galaxy='https://galaxy.ansible.com')
        # Second time should use the cached version of the api
        connection = GalaxyAPI(galaxy='https://galaxy.ansible.com')
        # This should not get called
        connection = GalaxyAPI(galaxy='http://bad.ansible.com')
        # This should not get called
        connection = GalaxyAPI(galaxy='http://bad.ansible.com/api/v1')
    except AnsibleError:
        pass


# Generated at 2022-06-10 23:49:24.558393
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError({'code': 401, 'headers': "header", 'read': "read"}, "message")
    except GalaxyError as ge:
        assert ge.http_code == 401
        assert ge.message == "message (HTTP Code: 401, Message: read Code: Unknown)"


# Generated at 2022-06-10 23:49:33.465069
# Unit test for function g_connect
def test_g_connect():
    from ansible.galaxy.api import GalaxyAPI
    test_galaxy_instance = GalaxyAPI(galaxy_server='https://galaxy.ansible.com')
    assert isinstance(test_galaxy_instance, GalaxyAPI)
    assert '_available_api_versions' not in test_galaxy_instance.__dict__
    test_galaxy_instance.get_auth_token()
    assert test_galaxy_instance._available_api_versions
    # test_galaxy_instance.api_server = 'https://no-such-server.example.com'
    # assert '_available_api_versions' not in test_galaxy_instance.__dict__



# Generated at 2022-06-10 23:49:39.613976
# Unit test for function g_connect
def test_g_connect():
    class Galaxy():
        def __init__(self,name,api_server):
            self.name = name
            self.api_server = api_server
            self._available_api_versions = {'available_versions':{'v2':'v2/'}}
        @g_connect(versions=['v2'])
        def test(self):
            return self._available_api_versions
        def _call_galaxy(self,url,cache,method,error_context_msg):
            return {'available_versions':{'v1':'v1/'}}

    galaxy = Galaxy('testgalaxy','testapi')
    assert galaxy.test() == {'available_versions':{'v1':'v1/'}},'Error when running test_g_connect'

##
# ANSI COLOR CODES


# Generated at 2022-06-10 23:49:45.377197
# Unit test for function g_connect
def test_g_connect():
    class DummyGalaxy():
        def __init__(self):
            self._available_api_versions = [u'v2']
            self.api_server = 'https://cloud.redhat.com/api/'
            self.name = 'test'
        def _call_galaxy(self, url, method='GET', data=None, error_context_msg=None, cache=False):
            return {'available_versions': {u'v1': u'v1/'}}

        @g_connect(versions=[u'v1', u'v2'])
        def test(self, name):
            return name

    test_galaxy=DummyGalaxy()
    assert test_galaxy.test("hello")=="hello"


# Generated at 2022-06-10 23:49:56.657875
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    from ansible.module_utils.urls import ConnectionError
    import json
    import re
    import requests
    import urllib.parse

    http_error = ConnectionError(
        code=404,
        url='https://galaxy.ansible.com/api/',
        method='GET',
        info={},
        errno=None,
        error=None,
        reason=None,
    )
    http_error.read = lambda: json.dumps({})
    galaxy_error = GalaxyError(http_error, 'message')
    assert re.match(r"^message \(HTTP Code: 404, Message: None\)$", galaxy_error.message)


# Generated at 2022-06-10 23:50:04.053510
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError(HTTPError('url', 'code', 'msg', 'hdrs', None), 'error')
    except GalaxyError as ex:
        assert ex.message == "error (HTTP Code: code, Message: msg)"
        assert ex.message == ex.__unicode__()
        assert ex.http_code == 'code'
        assert ex.url == 'url'



# Generated at 2022-06-10 23:50:11.307596
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    assert GalaxyError(HTTPError, "GalaxyError Message").http_code == HTTPError.code, "GalaxyError http_code is wrong"
    assert GalaxyError(HTTPError, "GalaxyError Message").message is not None, "GalaxyError message is None"
    assert GalaxyError(HTTPError, "GalaxyError Message").url == HTTPError.geturl(), "GalaxyError url is wrong"
    assert GalaxyError(HTTPError, "GalaxyError Message").args[0] is not None, "GalaxyError args is None"



# Generated at 2022-06-10 23:50:19.084109
# Unit test for function g_connect
def test_g_connect():
    class Test:
        def __init__(self, api_server="", name=""):
            self.api_server = api_server
            self.name = name
            self._available_api_versions = {}
        @g_connect(["v1", "v2"])
        def test_method(self, *args, **kwargs):
            return "test"
    tt = Test("https://galaxy.ansible.com", "test")
    assert tt.test_method() == "test"
test_g_connect()


# Generated at 2022-06-10 23:50:24.880269
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error_http_code = 500
    error_msg = u'Error'
    error = HTTPError('http://example.com', error_http_code, error_msg, {'Content-Type':'application/json'}, None)
    galaxy_error = GalaxyError(error, error_msg)
    assert galaxy_error.http_code == error_http_code
    assert galaxy_error.url == error.geturl()
    assert to_text(galaxy_error.message).find(error_msg) > 0



# Generated at 2022-06-10 23:50:35.198551
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com/api') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:8080/api') == 'galaxy.ansible.com:8080'
    assert get_cache_id('https://galaxy.ansible.com:80/api') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:443/api') == 'galaxy.ansible.com'
    assert get_cache_id('https://user:pass@galaxy.ansible.com:443/api') == 'galaxy.ansible.com'