

# Generated at 2022-06-10 23:42:19.015375
# Unit test for function cache_lock
def test_cache_lock():
    def myfunc(x):
        # pretend to do something on a thread-unsafe cache
        return x + 1

    wrapped = cache_lock(myfunc)
    assert myfunc(1) == wrapped(1)



# Generated at 2022-06-10 23:42:23.959753
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK.acquire()

    @cache_lock
    def foo():
        return 5

    assert foo() == 5

    _CACHE_LOCK.release()



# Generated at 2022-06-10 23:42:35.106973
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test invalid constructor options
    try:
        GalaxyAPI(name="test", api_server=None)
        assert False, "AnsibleError was not raised"
    except AnsibleError as e:
        assert msg == "GalaxyAPI requires an api_server"

    try:
        GalaxyAPI(name=None, api_server="http://localhost")
        assert False, "AnsibleError was not raised"
    except AnsibleError as e:
        assert msg == "GalaxyAPI requires a name"

    # Test valid GalaxyAPI
    api = GalaxyAPI(name="test", api_server="https://galaxy.server.com:9999")
    assert api.name == "test"
    assert api.api_server == "https://galaxy.server.com:9999"
    assert api.available_api_versions is None

# Generated at 2022-06-10 23:42:37.576554
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def _get_cache_dir(urlbase):
        return None
    _get_cache_dir('urlbase')


# Generated at 2022-06-10 23:42:45.269640
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    _, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write("""
        {
            "galaxy_servers": {
                "tstgalaxy": {
                    "api_server": "https://galaxy.ansible.com",
                    "token": "blah"
                },
                "tstgalaxy2": {
                    "api_server": "https://galaxy.ansible.com",
                    "token": "blah2"
                },
                "tstgalaxy3": {
                    "api_server": "https://galaxy.ansible.com",
                    "token": "blah3",
                    "ignore_certs": true
                }
            }
        }
        """)

# Generated at 2022-06-10 23:42:49.238288
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """ Test the constructor of GalaxyAPI. """
    galaxy_api = GalaxyAPI('https://galaxy.ansible.com', 'test_user', 'test_pass', True)
    assert galaxy_api.name == 'galaxy.ansible.com'
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api.ignore_certs is True
    assert 'v2' in galaxy_api.available_api_versions


# Generated at 2022-06-10 23:42:52.763898
# Unit test for function cache_lock
def test_cache_lock():
    def test_func(lock):
        if lock:
            lock.acquire()
        return 1

    assert cache_lock(test_func)(_CACHE_LOCK) == 1



# Generated at 2022-06-10 23:43:01.931984
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError("url", 404, "Galaxy message", {}, None)
    error = GalaxyError(http_error, "Ansible message")
    assert to_text(error) == u"Ansible message (HTTP Code: 404, Message: Galaxy message)"

    # Test v2 error message
    message = {"message": "Galaxy message", "code": "code"}
    http_error = HTTPError("url", 404, json.dumps(message), {}, None)
    error = GalaxyError(http_error, "Ansible message")
    assert to_text(error) == u"Ansible message (HTTP Code: 404, Message: Galaxy message Code: code)"

    # Test v3 error message
    error = {"detail": "Galaxy message", "code": "code"}
    message = {"errors": [error]}


# Generated at 2022-06-10 23:43:11.900957
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error9999 = GalaxyError(HTTPError('http://someurl.com', 9999, 'Some message', {}, None), 'Something bad happened')
    assert error9999.message == 'Something bad happened (HTTP Code: 9999, Message: Some message)'

    error403 = GalaxyError(HTTPError('http://someurl.com', 403, 'Some message', {}, None), 'Something bad happened')
    assert error403.message == 'Something bad happened (HTTP Code: 403, Message: Some message)'

    error500 = GalaxyError(HTTPError('http://someurl.com', 500, 'Some message', {}, None), 'Something bad happened')
    assert error500.message == 'Something bad happened (HTTP Code: 500, Message: Some message)'



# Generated at 2022-06-10 23:43:23.058164
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    ansible_galaxy_api = GalaxyAPI(name='dummy_name', api_server='dummy_api_server')
    ansible_galaxy_api.name = 'dummy_name_new'
    ansible_galaxy_api.api_server = 'dummy_api_server'
    assert not ansible_galaxy_api is None
    assert ansible_galaxy_api.name == 'dummy_name_new'
    assert ansible_galaxy_api.api_server == 'dummy_api_server'
    assert ansible_galaxy_api.available_api_versions == {}


# Generated at 2022-06-10 23:44:37.127932
# Unit test for function g_connect
def test_g_connect():
    class fake_self(object):
        def __init__(self, my_name, api_server):
            self.name = my_name
            self.api_server = api_server
            self._available_api_versions = None

        def _call_galaxy(self, url, method='GET', data=None, error_context_msg=None, cache=None):
            if url == 'https://api.galaxy.ansible.com/':
                return {
                    "available_versions": {
                        "v1": "v1/"
                    }
                }
            if url == 'https://api.galaxy.ansible.com/v1/':
                return {
                    "available_versions": {
                        "v1": "v1/"
                    }
                }

# Generated at 2022-06-10 23:44:38.935230
# Unit test for function g_connect
def test_g_connect():
    assert g_connect('a', 'b')('foo') == 'foo'



# Generated at 2022-06-10 23:44:44.797172
# Unit test for function g_connect
def test_g_connect():
    def mock_method(instance, *args, **kwargs):
        return True

    version = 'v1'
    obj = GalaxyConnection('')
    obj._available_api_versions = {version: version}
    decorated = g_connect([version])(mock_method)
    assert decorated(obj) is True



# Generated at 2022-06-10 23:44:51.871101
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error_http_code = 403
    error_message = "Not allowed"
    error_url = "https://galaxy.example.com/api/"
    galaxy_error = GalaxyError(HTTPError(url=error_url, code=error_http_code, msg=error_message, hdrs={}, fp=None,
                                         filename=None), "")
    assert galaxy_error.http_code == error_http_code
    assert galaxy_error.url == error_url



# Generated at 2022-06-10 23:45:01.510040
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Setup arguments for test
    api1 = GalaxyAPI("http://galaxy.server", "galaxy", "api_key", "username", "password", "token")
    api2 = GalaxyAPI("http://galaxy.server", "galaxy", "api_key", "username", "password", "token")

    # Test __lt__()
    assert api1 == api2
    assert not (api1 < api2)
    assert not (api1 > api2)
    api1.api_server = 'http://api2.galaxy.server'
    assert api1 != api2
    assert api1 > api2



# Generated at 2022-06-10 23:45:13.455801
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com/') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/') == 'galaxy.ansible.com'

    # Test handling of credentials in the URL
    assert get_cache_id('https://user:pass@galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_

# Generated at 2022-06-10 23:45:18.833213
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError('http_error', 'message')
    except GalaxyError as error:
        assert(error.http_code == None)
        assert(error.url == None)
        assert(error.message == 'message (HTTP Code: None, Message: http_error Code: Unknown)')


# Generated at 2022-06-10 23:45:31.097870
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    server_api_version = '3.0.0'
    server_name = 'galaxy.com'
    galaxy = GalaxyAPI(server_name, server_api_version)

    other_server_api_version = '3.0.0'
    other_server_name = 'galaxy.net'
    other_galaxy = GalaxyAPI(other_server_name, other_server_api_version)
    assert galaxy < other_galaxy

    other_server_api_version = '1.0.0'
    other_server_name = 'galaxy.net'
    other_galaxy = GalaxyAPI(other_server_name, other_server_api_version)
    assert galaxy < other_galaxy
    assert not (galaxy == other_galaxy)


# Generated at 2022-06-10 23:45:37.264632
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    message = 'App not found.'
    http_code = 404
    http_error = HTTPError(
        url='https://galaxy.server.com/api/v3/roles',
        code=http_code,
        msg=message,
        hdrs={},
        fp=None)
    err = GalaxyError(http_error, 'test')

    assert ", Message: App not found. Code: Unknown)" in err.message
    assert err.http_code == http_code



# Generated at 2022-06-10 23:45:48.467579
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    """Run unit test for constructor 'GalaxyError'"""
    msg = u"Test Message"
    class HTTPErrorFake(object):
        """HTTPError Fake Implement"""
        def __init__(self):
            """Init HTTP Error Fake"""
            self.code = 200
            self.geturl = lambda: 'https://galaxy.example.org/v1/data/test'
            self.read = lambda: b'{"default": "Test Message"}'
            self.reason = u'Test Message'

    http_error = HTTPErrorFake()
    err = GalaxyError(http_error, msg)
    code = err.http_code
    url = err.url
    full_msg = err.message
    assert code == 200
    assert url == u'https://galaxy.example.org/v1/data/test'
    assert full

# Generated at 2022-06-10 23:46:31.816762
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error_type = GalaxyError(HTTPError('url', 'http_code', 'msg', 'hdrs', None), 'message')
    assert isinstance(error_type, GalaxyError) is True


# Generated at 2022-06-10 23:46:34.289017
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error = GalaxyError(None, "Test Message")
    error.message == "Test Message"
    error.http_code == None



# Generated at 2022-06-10 23:46:40.671744
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    _galaxyAPI = GalaxyAPI.__new__(GalaxyAPI)
    _galaxyAPI.server = '127.0.0.1:80'
    _other = GalaxyAPI('127.0.0.1:80', 'test')
    _galaxyAPI.__lt__(_other)
    _galaxyAPI.server = '127.0.0.1:80'
    _other = GalaxyAPI('127.0.0.1:80', 'test')
    _galaxyAPI.__lt__(_other)



# Generated at 2022-06-10 23:46:42.711747
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    assert isinstance(GalaxyError(HTTPError("url", 400, "msg", {}, None), "msg"), GalaxyError)



# Generated at 2022-06-10 23:46:45.476984
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    host = 'galaxy.ansible.com'
    galaxy_api = GalaxyAPI(host)

    if galaxy_api < host:
        raise AssertionError()


# Generated at 2022-06-10 23:46:54.943030
# Unit test for function g_connect
def test_g_connect():
    def mock_method(self, *args, **kwargs):
        # TODO: Update test to pass in a mocked object to this function, and use it to verify that
        # the method was called with the specified arguments.
        json_output = dict(available_versions=dict(v1="v1", v2="v2"))
        self._call_galaxy = lambda x: json_output

    with pytest.raises(AnsibleError, message="Tried to find galaxy API root at None but no 'available_versions' are available on None"):
        g_connect(versions=['v1'])(mock_method)



# Generated at 2022-06-10 23:47:02.393492
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    testHttpUrl = 'http://testUrl.com'
    testMessage = 'test message'
    httpError = HTTPError(testHttpUrl, 500, testMessage, {}, None)
    galaxyError = GalaxyError(httpError, testMessage)

    assert galaxyError.http_code == 500
    assert galaxyError.url == testHttpUrl
    assert galaxyError.message == testMessage


# Generated at 2022-06-10 23:47:12.504760
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api_01 = GalaxyAPI(name='galaxy', api_server='api.galaxy.ansible.com', ignore_certs=True)
    galaxy_api_02 = GalaxyAPI(name='galaxy', api_server='api.galaxy.ansible.com', ignore_certs=True)
    assert galaxy_api_01.__lt__(galaxy_api_02) == False
    galaxy_api_01 = GalaxyAPI(name='galaxy', api_server='api.galaxy.ansible.com', ignore_certs=True)
    galaxy_api_02 = GalaxyAPI(name='galaxy', api_server='api.galaxy.ansible.com', ignore_certs=False)
    assert galaxy_api_01.__lt__(galaxy_api_02) == True


# Generated at 2022-06-10 23:47:14.477708
# Unit test for function cache_lock
def test_cache_lock():
    with cache_lock(lambda: 0):
        assert True
        with cache_lock(lambda: 1):
            assert True



# Generated at 2022-06-10 23:47:19.057958
# Unit test for function cache_lock
def test_cache_lock():
    class C(object):
        def foo(self, a, b, c=3):
            return "foo"

    wrapped = cache_lock(C().foo)
    assert wrapped(1, 2) == "foo"
    assert wrapped(1, 2, 3) == "foo"
    assert wrapped(1, 2, c=4) == "foo"



# Generated at 2022-06-10 23:48:29.755112
# Unit test for function g_connect
def test_g_connect():
    return



# Generated at 2022-06-10 23:48:36.639569
# Unit test for function g_connect
def test_g_connect():
    def mocked_method(self):
        return True

    class mocked_client():
        def __init__(self):
            self.name = 'test.repo'
            self.api_server = 'http://galaxy.server'
            self._available_api_versions = []

        mocked_method = g_connect(versions=['v2'])(mocked_method)

    client = mocked_client()
    client.mocked_method()
    # TODO: extend test with mocking of http calls



# Generated at 2022-06-10 23:48:40.216778
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    """Test for GalaxyError class"""
    test_obj = dict(HTTPError='HTTPDummy', message='This is a test message', code='Dummy')
    exception_obj = GalaxyError(test_obj['HTTPError'], test_obj['message'])
    assert exception_obj.http_code == test_obj['code']


# Generated at 2022-06-10 23:48:42.136907
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxyapi = GalaxyAPI()
    assert isinstance(galaxyapi, GalaxyAPI) == True



# Generated at 2022-06-10 23:48:43.668262
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def my_func():
        return 1

    assert my_func() == 1



# Generated at 2022-06-10 23:48:54.737071
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # pylint: disable=line-too-long
    GALAXY_URL = 'https://galaxy.example.org'
    API_KEY = 'abcdefghijklmnop'

    test_api = GalaxyAPI(GALAXY_URL, API_KEY)
    assert test_api.api_server == GALAXY_URL
    assert test_api.api_key == API_KEY
    assert test_api.url_token_key == 'Authorization'
    assert test_api.url_token == 'Bearer %s' % API_KEY

    test_api = GalaxyAPI(GALAXY_URL, API_KEY, 'pulp')
    assert test_api.api_server == GALAXY_URL
    assert test_api.api_key == API_KEY
    assert test_api.url

# Generated at 2022-06-10 23:49:02.061487
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api_server = 'http://localhost/'
    username = 'bob'
    password = 'hunter2'
    ignore_certs = True
    force = True
    timeout = 21
    validate_certs = True
    client_cert = '/path/to/client_cert.pem'
    name = 'galaxy_server'
    available_api_versions = {}
    no_cache = True
    force_basic_auth = True
    proxy = 'https://proxy.example.org:8080/'
    persistent_cache_path = '/path/to/persistent_cache_path'
    session_path = '/path/to/session_path'

# Generated at 2022-06-10 23:49:13.634202
# Unit test for function cache_lock
def test_cache_lock():
    results = []
    # First lock a critical region
    @cache_lock
    def critical(results, idx):
        results.append(idx)

    critical(results, 0)
    # Then try to enter a second lock, this should block
    lock = threading.Lock()
    lock.acquire()

    @cache_lock
    def noncritical(results, idx):
        results.append(idx)

    def read_results():
        return results

    t = threading.Thread(target=noncritical, args=(results, 1))
    t.start()
    # Wait until the lock has been entered
    while len(results) < 2:
        continue
    assert results == [0, 1]
    lock.release()
    t.join()



# Generated at 2022-06-10 23:49:24.264858
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    fixture_path = 'test/fixtures'

    galaxy_server = 'https://galaxy.example.com'
    name = 'foo'

    galaxy = GalaxyAPI(name, galaxy_server, force=True)

    assert galaxy.name == name
    assert galaxy.api_server == galaxy_server
    assert galaxy.force is True
    assert galaxy.api_token is None
    assert len(galaxy.available_api_versions) == 2
    assert len(galaxy.available_api_versions['v2']) == 0
    assert len(galaxy.available_api_versions['v3']) == 0

    # Test with a galaxy server that does not exist
    galaxy_server = 'http://404.example.com'
    galaxy = GalaxyAPI(name, galaxy_server)

    assert galaxy.name == name
    assert galaxy.api

# Generated at 2022-06-10 23:49:29.842197
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error_class = GalaxyError
    error_instance = GalaxyError(HTTPError(url='/test', code=400, msg='test', hdrs='test', fp=None), 'test')
    assert error_instance.http_code == 400
    assert error_instance.url == '/test'

