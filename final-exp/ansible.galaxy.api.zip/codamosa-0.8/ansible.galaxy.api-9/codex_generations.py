

# Generated at 2022-06-10 23:42:12.881454
# Unit test for function g_connect
def test_g_connect():
    pass



# Generated at 2022-06-10 23:42:19.304800
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI(name='mygalaxyserver', galaxy_server='https://galaxy.ansible.com/api/v2/', api_key='ABC123')

    assert api.name == 'mygalaxyserver'
    assert api.galaxy_server == 'https://galaxy.ansible.com/api/v2/'
    assert api.api_key == 'ABC123'
#



# Generated at 2022-06-10 23:42:20.901717
# Unit test for function g_connect
def test_g_connect():
    assert isinstance(g_connect, collections.Callable)


# Generated at 2022-06-10 23:42:26.633187
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise HTTPError("url1", 555, "msg", "hdrs", "fd")
    except HTTPError as e:
        error = GalaxyError(e, "test_GalaxyError")
        assert error.url == "url1"
        assert error.http_code == 555
        assert error.message == "test_GalaxyError (HTTP Code: 555, Message: msg)"



# Generated at 2022-06-10 23:42:31.757072
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=400))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))



# Generated at 2022-06-10 23:42:38.397823
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # TODO(ssbarnea): Generate parametrized test cases
    # parameters:
    other = GalaxyAPI(api_server='https://galaxy.ansible.com', token='token', name='galaxy', last_update=0)
    instance = GalaxyAPI(api_server='https://galaxy.ansible.com', token='token', name='galaxy', last_update=1)
    expected_return = False
    # tests:
    assert instance < other == expected_return

# Generated at 2022-06-10 23:42:43.347221
# Unit test for function g_connect
def test_g_connect():
    def version_test(self, version):
        print('version: {}'.format(version))
        return version

    g_connect(['v3'])(version_test)(None, 'v3')

    try:
        g_connect(['v10'])(version_test)(None, 'v10')
    except AnsibleError as err:
        print('err: {}'.format(err))



# Generated at 2022-06-10 23:42:50.215503
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:8080/api/') == 'galaxy.ansible.com:8080'
    assert get_cache_id('https://user:pass@galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://user:pass@galaxy.ansible.com:8080') == 'galaxy.ansible.com:8080'

# Generated at 2022-06-10 23:43:00.437456
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Test with no message in the HTTP response
    response = u'{"code": "too_many_requests", "message": "You have exceeded your request rate limit. Please wait before trying again."}'
    http_error = HTTPError(url="https://galaxy.ansible.com/api/v1/users/test_user/roles/", code=429, msg=None, hdrs=None, fp=None)
    http_error.read = lambda x: response
    exception = GalaxyError(http_error, "You have exceeded your request rate limit. Please wait before trying again.")
    assert exception.http_code == 429
    assert exception.url == "https://galaxy.ansible.com/api/v1/users/test_user/roles/"

# Generated at 2022-06-10 23:43:10.213740
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_code = 500
    msg = 'Internal Error'
    lst = list()
    lst.append(dict())
    lst[0]['title'] = msg
    lst[0]['code'] = 'Unknown'
    http_error = HTTPError('', http_code, 'Internal Server Error', {}, None)
    http_error.read = lambda: json.dumps({'errors': lst})
    galaxy_error = GalaxyError(http_error, 'API failure')
    assert galaxy_error.http_code == http_code
    assert galaxy_error.message == 'API failure (HTTP Code: %d, Message: %s Code: %s)' % (http_code, msg, 'Unknown')



# Generated at 2022-06-10 23:44:26.052867
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import json
    import copy
    import uuid
    test_galaxy_error_msg = uuid.uuid4().hex  # create the fake error message for test case
    test_galaxy_error_msg_2 = uuid.uuid4().hex  # create the fake error message for test case
    http_error = HTTPError(url=None, code=500, msg=None, hdrs=None, fp=None, filename=None)
    galaxy_error_v1 = GalaxyError(http_error, message=test_galaxy_error_msg)
    assert test_galaxy_error_msg in galaxy_error_v1.message

    # Testcase for v2
    test_galaxy_error_code = uuid.uuid4().hex  # create the fake error code for test case
    test_galaxy_

# Generated at 2022-06-10 23:44:35.834118
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible_galaxy.models.galaxy_api import GalaxyAPI

    galaxy_api_1 = GalaxyAPI(name='test_name_1',
                             api_server='test_api_server_1',
                             url='test_url_1',
                             token='test_token_1')

    galaxy_api_2 = GalaxyAPI(name='test_name_2',
                             api_server='test_api_server_2',
                             url='test_url_2',
                             token='test_token_2')

    assert (galaxy_api_1 < galaxy_api_2) is True



# Generated at 2022-06-10 23:44:42.273824
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI('ansible', 'https://galaxy.ansible.com')
    assert api.server == 'galaxy.ansible.com'
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.name == 'ansible'
    assert not api.token
    assert not api.user_agent



# Generated at 2022-06-10 23:44:43.736485
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def foo():
        pass

    assert foo



# Generated at 2022-06-10 23:44:50.263384
# Unit test for function g_connect
def test_g_connect():
    # Make sure the __name__ that's populated is that of the calling method
    def my_method(cls, *args, **kwargs):
        return 'my_method'

    _g_connect_decorator = g_connect(('v1', 'v2'))
    _new_method_1 = _g_connect_decorator(my_method)
    assert _new_method_1.__name__ == 'my_method'



# Generated at 2022-06-10 23:44:54.901199
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # just testing that this doesn't error out :)
    GalaxyAPI(galaxy_server_url='https://galaxy.ansible.com',
              galaxy_api_key='CHANGEME',
              galaxy_ignore_certs=True)



# Generated at 2022-06-10 23:44:58.354190
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    import pytest
    import requests.exceptions

    galaxyapi = GalaxyAPI()

    with pytest.raises(requests.exceptions.ConnectionError):
        if galaxyapi <= 'a':
            pass


# Generated at 2022-06-10 23:45:10.633343
# Unit test for function g_connect
def test_g_connect():
    api_server = 'https://galaxy.ansible.com/api/'

    available_versions = {
        u'v1': u'v1/',
        u'v2': u'v2/'
    }

    # Available_versions default to v1 only
    data = {
        'available_versions': available_versions
    }

    available_versions = {
        u'v1': u'v1/',
        u'v2': u'v2/'
    }

    # Available_versions default to v1 only
    data = {
        'available_versions': available_versions
    }

    # Missing available_versions should cause an error
    data = {}

    # Available_versions default to v1 only
    data = {
        'available_versions_': available_versions
    }


# Generated at 2022-06-10 23:45:15.812369
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    arg0 = GalaxyAPI("test_arg0", "test_arg1")
    arg1 = GalaxyAPI("test_arg0", "test_arg1")
    # verify the class type of arg0 is GalaxyAPI
    assert (isinstance(arg0, GalaxyAPI))
    assert (arg0 < arg1)



# Generated at 2022-06-10 23:45:26.841843
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    server_1 = 'https://galaxy.server.1'
    server_2 = 'https://galaxy.server.2'

    apis = [
        # galaxy_server, api_token, name, description, available_api_versions
        GalaxyAPI(server_1, 'token-1', 'test-1', 'Galaxy server at %s' % server_1, ['v2']),
        GalaxyAPI(server_2, 'token-2', 'test-2', 'Galaxy server at %s' % server_2, ['v3']),
        GalaxyAPI(server_1, 'token-1', 'test-1', 'Galaxy server at %s' % server_1, ['v2', 'v3']),
    ]

    # Sorting with __lt__ should same same results as sorting with __cmp__

# Generated at 2022-06-10 23:46:39.610053
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Test the various return codes
    # Test different return codes
    http_error = HTTPError("http://galaxy.ansible.com:80/api", 500, "error message", {}, None)
    http_error.code = 500
    for i in range(400, 418):
        http_error.code = i
        ge = GalaxyError(http_error, "Message")
        assert ge.message == "Message (HTTP Code: %d, Message: error message Code: Unknown)" % i
        assert ge.http_code == i

    for i in range(500, 505):
        http_error.code = i
        ge = GalaxyError(http_error, "Message")
        assert ge.message == "Message (HTTP Code: %d, Message: error message Code: Unknown)" % i
        assert ge.http_code == i



# Generated at 2022-06-10 23:46:42.302362
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError('http_error', 'message')
    except GalaxyError as err:
        assert err.http_code == 'http_error'
        assert err.url == 'http_error'



# Generated at 2022-06-10 23:46:54.316707
# Unit test for function g_connect
def test_g_connect():
    from ansible.module_utils._text import to_native
    @g_connect(versions=[u'v1'])
    def call_v1(self, *args, **kwargs):
        return True

    try:
        call_v1(object())
        # Should raise AnsibleError
        assert False
    except AnsibleError as exc:
        assert 'Galaxy action call_v1 requires API versions' in to_native(exc)
        assert 'v1' in to_native(exc)
        assert 'but' in to_native(exc)

    @g_connect(versions=[u'v1', u'v2'])
    def call_v2(self, *args, **kwargs):
        return True


# Generated at 2022-06-10 23:47:00.694237
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # pos
    a = GalaxyAPI('https://galaxy.ansible.com', None)
    b = GalaxyAPI('https://galaxy.ansible.com/api/v2/', None)
    assert a < b

    # pos
    b = GalaxyAPI('http://galaxy.ansible.com/api/v2/', None)
    assert a < b

    # pos
    b = GalaxyAPI('http://galaxy.ansible.com/api/v3/', None)
    assert a < b

    # pos
    b = GalaxyAPI('http://galaxy.ansible.com/api/v2/', None)
    assert a < b

    # pos
    b = GalaxyAPI('http://galaxy.ansible.com/api/v2/', None)
    assert not b < a

    # pos


# Generated at 2022-06-10 23:47:02.691141
# Unit test for function g_connect
def test_g_connect():
    test_that_g_connect_returns_a_decorator()



# Generated at 2022-06-10 23:47:03.629674
# Unit test for function g_connect
def test_g_connect():
    assert None == None



# Generated at 2022-06-10 23:47:12.219777
# Unit test for function g_connect
def test_g_connect():
    class FakeGalaxyAPI(object):
        name = 'test_galaxy_server'
        api_server = 'http://localhost'

        def __init__(self):
            self._available_api_versions = {}
        def _call_galaxy(self, url, method, **kwargs):
            return {'available_versions': {u'v1': u'v1/'}}
    a = FakeGalaxyAPI()
    @g_connect(versions=[u'v1', u'v2'])
    def test_galaxy_func(self):
        pass
    test_galaxy_func(a)
# End unit test for function g_connect


# Generated at 2022-06-10 23:47:21.325979
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    #Setting up a fake response object as an instance of HTTPError.
    http_data = type('', (object,), {'code': 500, 'geturl': lambda: "http://local:8000/api/v3/", 'reason': 'Internal Server Error'})
    fake_response = http_data()
    fake_response.read = lambda: json.dumps({"errors":[{"code":"api_error","title":"API error","detail":"Internal Server Error"}]})
    try:
        raise GalaxyError(fake_response, 'API error is not good')
    except GalaxyError as e:
        assert e.message, "API error is not good (HTTP Code: 500, Message: API error is not good Code: api_error)"
        assert e.http_code, 500
        assert e.url, "http://local:8000/api/v3/"

# Generated at 2022-06-10 23:47:32.982075
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    msg = 'Ansible Error'
    http_code_result = 500
    galaxy_msg = 'POST to https://galaxy.ansible.com/api/v1/users/ failed (HTTP Code: 500, Message: Internal Server Error)'
    http_error = GalaxyError(http_code_result, msg)
    http_error2 = GalaxyError(http_error, msg)
    assert isinstance(http_error2, AnsibleError)
    assert http_error.http_code == http_error2.http_code
    assert http_error.message == http_error2.message
    assert http_error.url == http_error2.url

    msg, http_code_result, galaxy_msg = 'Ansible Error', 500, 'Internal Server Error'

# Generated at 2022-06-10 23:47:43.588726
# Unit test for function cache_lock
def test_cache_lock():
    class Test:
        def __init__(self):
            self.my_lock = threading.Lock()
            self.cache_lock = threading.Lock()
        @cache_lock
        def test(self):
            assert not self.cache_lock.locked()
            assert not self.my_lock.locked()
            time.sleep(1)
            assert not self.cache_lock.locked()
            assert not self.my_lock.locked()

    test = Test()
    test.my_lock.acquire()
    assert test.my_lock.locked()
    assert not test.cache_lock.locked()
    test.test()
    assert test.my_lock.locked()
    assert not test.cache_lock.locked()


# Generated at 2022-06-10 23:48:59.637490
# Unit test for function g_connect
def test_g_connect():
    assert True



# Generated at 2022-06-10 23:49:08.572493
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError("", http_code=429))
    assert is_rate_limit_exception(GalaxyError("", http_code=520))
    assert not is_rate_limit_exception(GalaxyError("", http_code=401))
    assert not is_rate_limit_exception(GalaxyError("", http_code=403))
    assert not is_rate_limit_exception(GalaxyError("", http_code=404))



# Generated at 2022-06-10 23:49:18.023115
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    display.vvv('Starting GalaxyAPI unit test.')

    from ansible.module_utils.six.moves.urllib.parse import urlparse
    galaxy_url_data = urlparse('https://galaxy.server.com/api/')

    test_inst = GalaxyAPI(galaxy_url_data.scheme + '://' + galaxy_url_data.netloc + '/api/')

    assert test_inst.api_server == 'https://galaxy.server.com/api/'
    assert test_inst.name == 'Galaxy'
    assert test_inst.pulp_ansible_api_server == 'https://galaxy.server.com/pulp/ansible/api/'
    assert not test_inst.api_token

    display.vvv('Finished GalaxyAPI unit test.')

# Unit test

# Generated at 2022-06-10 23:49:32.074167
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import ansible.release
    import http.client

    conn = http.client.HTTPConnection("test.galaxy.server.com")
    http_error = http.client.HTTPException("test exception")
    http_error.code = 500
    http_error.reason = "Server error"
    http_error.geturl = lambda: "https://test.galaxy.server.com/v3/import/?test=testing"
    http_error.read = lambda: "{\"errors\": [{\"detail\": \"Internal Server Error\", \"code\": 500}]}"
    message = "An error occurred communicating with the galaxy API."
    exception = GalaxyError(http_error, message)

    assert exception.http_code == 500
    assert exception.url.endswith("/v3/import/?test=testing")
    assert exception.message.startsw

# Generated at 2022-06-10 23:49:35.409615
# Unit test for function g_connect
def test_g_connect():
    def foo(self):
        return True
    wrapped_foo = g_connect(['v1', 'v3'])(foo)
    assert(isinstance(wrapped_foo, functools.wraps(foo)))
    assert(wrapped_foo(None))



# Generated at 2022-06-10 23:49:39.604107
# Unit test for function cache_lock
def test_cache_lock():
    from ansible.galaxy import collection_cache
    # Test function with cache_lock decorator
    assert hasattr(collection_cache.get_collection_artifact, "__wrapped__")



# Generated at 2022-06-10 23:49:50.566325
# Unit test for function g_connect
def test_g_connect():
    def test_method(self):
        pass

    # Test for no available versions
    conn = GalaxyConnection(name='test_conn', api_server='test_server')
    conn.get_available_api_versions = lambda: {}
    assert test_method(conn) == test_method

    # Test for available versions
    conn.get_available_api_versions = lambda: {u'v1': u'v1/'}
    assert g_connect([u'v1', u'v2'])(test_method)(conn) == test_method
    assert test_method(conn) == test_method



# Generated at 2022-06-10 23:49:59.859607
# Unit test for function g_connect
def test_g_connect():
    class mock_self:
        def __init__(self,api,name=None):
            self.api_server = api
            self.name = name
            self._available_api_versions = {}
    def mock_method(*args, **kwargs):
        return "test_mock"
    _test = g_connect(["v2"])(mock_method)
    self = mock_self("https://galaxy.ansible.com/")
    assert _test(self, None) == "test_mock"
    # Verifies that AnsibleError is raised when current versions are not supported
    self = mock_self("https://galaxy.ansible.com/")
    self._available_api_versions = {"v1":"http://v1/"}

# Generated at 2022-06-10 23:50:09.125228
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class dummyHttpError(Exception):
        def __init__(self, response):
            self.code = response

        @property
        def msg(self):
            return self.code

    exception = GalaxyError(dummyHttpError(429))
    assert is_rate_limit_exception(exception)
    exception = GalaxyError(dummyHttpError(520))
    assert is_rate_limit_exception(exception)
    exception = GalaxyError(dummyHttpError(403))
    assert not is_rate_limit_exception(exception)



# Generated at 2022-06-10 23:50:13.703900
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK = MockLock()

    @cache_lock
    def test_func():
        return None

    test_func()
    assert _CACHE_LOCK.acquired == 1
    _CACHE_LOCK = threading.Lock()

