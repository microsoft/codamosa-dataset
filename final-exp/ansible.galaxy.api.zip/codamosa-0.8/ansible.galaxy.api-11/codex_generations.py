

# Generated at 2022-06-10 23:42:43.305112
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # GalaxyError base case
    message = 'galaxy is not a galaxy'
    http_msg = 'galaxy api not found'
    http_error = HTTPError('/', 404, http_msg, None, None)
    error_obj = GalaxyError(http_error, message)
    assert error_obj.http_code == 404
    assert error_obj.url == '/'
    assert error_obj.message == '{0} (HTTP Code: 404, Message: {1})'.format(message, http_msg)

    # GalaxyError failure case
    message = 'galaxy was not a galaxy'
    http_msg = 'galaxy api not found'
    http_error = HTTPError('/', 404, http_msg, None, None)
    error_obj = GalaxyError(http_error, message)
    assert error_obj.http

# Generated at 2022-06-10 23:42:50.918535
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    test_message = 'Test message'
    test_code = 400
    test_name = 'Test name'
    test_url = 'http://galaxy.test'
    test_api_error_msg = {'default': 'API error message'}
    test_api_error_code = 'Test code'
    test_api_error_msg_v2 = {'message': 'API error message', 'code': 'Test code'}
    test_api_error_msg_v3 = [{'title': 'API error message', 'code': 'Test code'}]

# Generated at 2022-06-10 23:42:58.309322
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://somedomain.com') == 'somedomain.com:443'
    assert get_cache_id('https://somedomain.com:1234') == 'somedomain.com:1234'
    assert get_cache_id('https://user:pass@somedomain.com') == 'somedomain.com:443'
    assert get_cache_id('https://somedomain.com/some/path') == 'somedomain.com:443'



# Generated at 2022-06-10 23:43:06.353191
# Unit test for function cache_lock
def test_cache_lock():
    # Code that protects against race conditions
    # can be difficult to unit test in a race-free
    # environment. Instead of avoiding mocking
    # variables to use threading locks in unit tests,
    # we want to make sure that the behavior of the
    # code is correct, regardless of whether it's
    # using a lock or not. This function indirectly
    # tests for that by making sure that the function
    # being decorated returns its value without raising
    # an exception. The cache_lock decorator's behavior
    # can be verified in integration tests.

    def test_func():
        return True

    wrapped = cache_lock(test_func)
    assert wrapped()



# Generated at 2022-06-10 23:43:11.460728
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test(x):
        display.display("test({})".format(x))
        return x

    for i, x in enumerate(range(2)):
        display.display("Enumeration {}".format(i))
        test(x)
    assert i == 1


# Generated at 2022-06-10 23:43:20.579829
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('url', 404, 'Reason', {}, None)
    message = 'message'
    galaxy_error_obj = GalaxyError(http_error, message)
    assert galaxy_error_obj.http_code == http_error.code
    assert galaxy_error_obj.url == http_error.geturl()
    assert galaxy_error_obj.message == ('message (HTTP Code: %d, Message: %s)' % (galaxy_error_obj.http_code, http_error.reason))


# Import at bottom of module to avoid circular imports
from ansible.galaxy.token import GalaxyToken



# Generated at 2022-06-10 23:43:23.065989
# Unit test for function g_connect
def test_g_connect():
    versions = ["v1"]
    @g_connect(versions=versions)
    def foo(self):
        return "foo"



# Generated at 2022-06-10 23:43:24.541568
# Unit test for function cache_lock
def test_cache_lock():

    def func():
        pass

    assert cache_lock(func)() is None



# Generated at 2022-06-10 23:43:27.263430
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password')
    assert galaxy.api_server == 'https://galaxy.ansible.com'
    assert galaxy.api_key == 'username'
    assert galaxy.api_secret == 'password'


# Generated at 2022-06-10 23:43:31.939154
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxy(object):
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self._available_api_versions = {}
            self.name = 'test'
        def _call_galaxy(self, url, **kwargs):
            return {u'available_versions': {u'v1': u'v1/'}}
    galaxy_ = TestGalaxy()
    @g_connect([u'v1'])
    def test_function(self):
        return 'succeeded'
    test_function(galaxy_)

# Generated at 2022-06-10 23:44:17.706840
# Unit test for function cache_lock
def test_cache_lock():
    result = []

    @cache_lock
    def func(x):
        result.append(x)

    func(1)
    func(2)

    assert result == [1, 2]



# Generated at 2022-06-10 23:44:20.012869
# Unit test for function get_cache_id
def test_get_cache_id():
    url = "https://localhost:8080"
    assert get_cache_id(url) == 'localhost:8080'



# Generated at 2022-06-10 23:44:29.406190
# Unit test for function g_connect
def test_g_connect():
    version_data = [1, "hello"]
    version_data2 = ["1", "2", "3"]

    class Test(object):
        def __init__(self, v):
            self.a = v
            self.b = []

        @g_connect(versions=version_data)
        def method(self, data):
            self.b.append(self.a)
            return self.a

        @g_connect(versions=version_data2)
        def method2(self, data):
            self.b.append(self.a)
            return self.a

    a = Test(0)
    # b = Test(1)
    assert a.method(0) == 0
    # assert b.method(0) == 0



# Generated at 2022-06-10 23:44:40.240627
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible_galaxy.models.galaxy_artifact import GalaxyArtifact
    from ansible_galaxy.models.galaxy_collection_artifact import GalaxyCollectionArtifact


# Generated at 2022-06-10 23:44:44.631730
# Unit test for function g_connect
def test_g_connect():
    collection_name = 'my.collection'
    galaxy_server = 'https://galaxy.ansible.com'
    galaxy = Galaxy(collection_name, None, galaxy_server)
    # connect to galaxy server
    g_connect()



# Generated at 2022-06-10 23:44:57.006064
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # For now use a mocker that does not require a server
    galaxy_mocker = GalaxyAPI.get_mocker(connection=None)

    # Gather the common arguments for all GalaxyAPIs
    common_kwargs = {
        'url': 'http://test.galaxy.server',
        'username': 'bob',
        'password': 'hunter2',
        'ignore_certs': False,
    }

    # Test that a GalaxyAPI can be created when no versions are provided
    galaxy_mocker.patch_init(common_kwargs)
    galaxy = GalaxyAPI(**common_kwargs)
    assert galaxy.available_api_versions == {}

    # Test that a GalaxyAPI can be created when one version is provided
    common_kwargs['api_versions'] = ['v2']
    galaxy_mocker.patch_init

# Generated at 2022-06-10 23:45:02.793313
# Unit test for function get_cache_id
def test_get_cache_id():
    test_cases = [
        (get_cache_id, 'https://foo.bar/v1', 'foo.bar'),
        (get_cache_id, 'https://user:password@foo.bar/v1', 'foo.bar'),
        (get_cache_id, 'https://foo.bar:8443/v1', 'foo.bar:8443'),
        (get_cache_id, 'https://foo.bar:bar/v1', 'foo.bar:bar'),
    ]

    for test_func, test_url, expected_result in test_cases:
        assert test_func(test_url) == expected_result



# Generated at 2022-06-10 23:45:10.633443
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
  from ansiblegalaxy.models.galaxy_api import GalaxyAPI
  galaxy_api = GalaxyAPI(api_server = 'https://galaxy.ansible.com/', name = 'ansible-galaxy')
  galaxy_api2 = GalaxyAPI(api_server = 'https://galaxy2.ansible.com/', name = 'ansible-galaxy')
  assert (galaxy_api.__lt__(galaxy_api2) == True)


# Generated at 2022-06-10 23:45:11.684668
# Unit test for function g_connect
def test_g_connect():
    assert g_connect is not None

# Generated at 2022-06-10 23:45:20.472761
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    idx = GalaxyAPI('galaxy.example.org', 'GalaxyAPI')
    idx_same = GalaxyAPI('galaxy.example.org', 'GalaxyAPI')
    idx_greater = GalaxyAPI('galaxy.example.org', 'GalaxyAPI')
    idx_greater.available_api_versions = ['a', 'b', 'c']
    assert not idx < idx
    assert idx < idx_greater
    assert not idx < idx_greater
    assert not idx_greater < idx


# Generated at 2022-06-10 23:45:54.559822
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    tmp_exception = GalaxyError("some galaxy error", http_code=429)
    assert is_rate_limit_exception(tmp_exception) == True



# Generated at 2022-06-10 23:46:02.125773
# Unit test for constructor of class GalaxyError
def test_GalaxyError():

    test_exception = {
      "code": "Invalid",
      "detail": "Invalid credentials",
      "title": "Invalid"
    }

    test_exception1 = {
      "detail": "Invalid credentials",
      "title": "Invalid"
    }

    test_http_error = HTTPError("url", "http_code", "http_message", None, None)

    test_exception_list = [test_exception, test_exception1]

    try:
        raise GalaxyError(test_http_error, "test message")
    except GalaxyError as e:
        assert e.http_code == test_http_error.code
        assert e.url == test_http_error.geturl()
        assert "HTTP Code: http_code" in e.message


# Generated at 2022-06-10 23:46:09.674037
# Unit test for function g_connect
def test_g_connect():
    class galaxy_server:
        def __init__(self, name, api_server):
            self.name = name
            self.api_server = api_server
            self._available_api_versions = {}
        @g_connect(['v1', 'v2'])
        def server_method(self):
            return "test v1 and or/v2"
    g = galaxy_server("test", "https://galaxy.ansible.com")
    print(g.server_method())
if __name__ == '__main__':
    test_g_connect()


# Generated at 2022-06-10 23:46:14.232852
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError(HTTPError('url', 'status', 'msg', None, None), 'msg')
    except GalaxyError as err:
        assert err.http_code == 'status'
        assert err.url == 'url'
        assert err.message == 'msg (HTTP Code: status, Message: msg)'


# Generated at 2022-06-10 23:46:20.998693
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=520, message='foo'))
    assert not is_rate_limit_exception(GalaxyError(http_code=200, message='foo'))
    assert is_rate_limit_exception(GalaxyError(http_code=429, message='foo'))



# Generated at 2022-06-10 23:46:23.553234
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def get():
        return 123
    assert get() == 123



# Generated at 2022-06-10 23:46:26.287183
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(None, None, None, None, None)
    message = 'test'
    error = GalaxyError(http_error, message)
    assert error.message == message


# Generated at 2022-06-10 23:46:38.867320
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    from ansible.galaxy.api import GalaxyAPI
    from ansible.galaxy.api import get_cache_id

    args1 = dict(
        url='http://example.com/api/ansible/roles',
        token='XXXXXXXXXXXXXXXXXXXXXXXXX',
        ignore_certs=True,
        ignore_cache=True,
        force_basic_auth=True,
        username='username',
        password='password',
        client_cert='/path/to/cert',
        timeout=30,
    )


# Generated at 2022-06-10 23:46:44.928471
# Unit test for function g_connect
def test_g_connect():
    class TestClass(object):
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self._available_api_versions = []
            self.name = 'TestClass'

        @g_connect(["v1"])
        def test_func(self):
            pass

    test_cls = TestClass()
    test_cls.test_func()
test_g_connect()



# Generated at 2022-06-10 23:46:56.008758
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """Unit test for GalaxyAPI constructor"""
    # (1) Verify invalid server_list parameter types
    with pytest.raises(AnsibleError):
        GalaxyAPI(server_list=[1], cache_path=None, enable_cache=True)
    with pytest.raises(AnsibleError):
        GalaxyAPI(server_list={'one': 1}, cache_path=None, enable_cache=True)

    # (2) Verify invalid server_list parameter values
    with pytest.raises(AnsibleError):
        GalaxyAPI(server_list=[""], cache_path=None, enable_cache=True)
    with pytest.raises(AnsibleError):
        GalaxyAPI(server_list=[123], cache_path=None, enable_cache=True)

# Generated at 2022-06-10 23:48:09.088778
# Unit test for function g_connect
def test_g_connect():
    class FakeGConnection():
        class fake_galaxy:
            def __init__(self):
                self.name = "test"
                self.api_server = "test"
                self._available_api_versions = {}
            def _call_galaxy(self, *args):
                pass


        @g_connect(["v1"])
        def fake_g_connect(self):
            pass


        def test_g_connect(self):
            self.fake_g_connect()


    obj = FakeGConnection()
    obj.test_g_connect()


# Generated at 2022-06-10 23:48:14.808525
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://localhost:8080') == 'localhost:8080'
    assert get_cache_id('https://example.com:8080') == 'example.com:8080'
    assert get_cache_id('https://127.0.0.1') == '127.0.0.1'



# Generated at 2022-06-10 23:48:22.104447
# Unit test for function cache_lock
def test_cache_lock():
    run_lock = threading.Lock()
    counter = 0

    def test_func():
        with run_lock:
            nonlocal counter
            counter += 1

    @cache_lock
    def test_decorated():
        test_func()

    for _ in range(10):
        threading.Thread(target=test_decorated).start()
    for _ in range(10):
        threading.Thread(target=test_decorated).start()
    time.sleep(2)
    assert counter == 1



# Generated at 2022-06-10 23:48:33.380880
# Unit test for function g_connect
def test_g_connect():
    # Test with no available API versions (should raise an exception)
    class TestConnection(object):
        def __init__(self):
            self._available_api_versions = None
            self.api_server = 'http://galaxy.ansible.com'
            self.name = 'Galaxy'

        @g_connect(versions=['v1', 'v2'])
        def get_collection(self):
            pass

    g = TestConnection()
    try:
        g.get_collection()
    except AnsibleError as e:
        assert "Tried to find galaxy API root" in to_text(e)
        assert "but no 'available_versions' are available" in to_text(e)

    # Test with one API version (v1) and the requested versions are only v1 (should pass)

# Generated at 2022-06-10 23:48:35.220724
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    server_list = GalaxySERVER_LIST
    galaxyapi1 = GalaxyAPI(server_list, 'galaxy.ansible.com')
    galaxyapi2 = GalaxyAPI(server_list, 'galaxy.example.com')
    assert galaxyapi1 < galaxyapi2



# Generated at 2022-06-10 23:48:39.966317
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Default test
    galaxy_api_1 = GalaxyAPI('test')
    galaxy_api_2 = GalaxyAPI('test')
    galaxy_api_1.available_api_versions = {'v2': 'v2', 'v3': 'v3'}
    #assert galaxy_api_1.__lt__(galaxy_api_2) == False
    assert galaxy_api_1 < galaxy_api_2 == False

# Generated at 2022-06-10 23:48:48.265853
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    url='https://galaxy.ansible.com/api/v2/orgs/sre/collections/nagios-plugins'
    json_msg='{"code": "invalid_collection_content_count", "message": "Collection content count was invalid", "status": 400}'
    http_error=HTTPError(url,400,json_msg,{},None)
    message=GalaxyError(http_error,'Error')
    assert message.message == 'Error (HTTP Code: 400, Message: Collection content count was invalid Code: invalid_collection_content_count)'
    assert message.http_code == 400
    assert message.url == url


# Generated at 2022-06-10 23:48:58.106484
# Unit test for function g_connect
def test_g_connect():
    import unittest
    class TestGalaxyConnection(unittest.TestCase):
        def setUp(self):
            self.galaxy_api_server = 'https://galaxy.ansible.com/api/'
            self.galaxy_name = 'galaxy'
            self.galaxy = GalaxyAPI(galaxy_api_server=self.galaxy_api_server)
            self.error_msg = "Galaxy action %s requires API versions '%s' but only '%s' are available on %s %s"

        def test_g_connect(self):
            @g_connect(versions=['v1', 'v2'])
            def test(self, a, b, c=1):
                return a, b, c

            test = test(self.galaxy, 1, 2)

# Generated at 2022-06-10 23:48:59.655148
# Unit test for function g_connect
def test_g_connect():
    def a_func_that_does_something(*args, **kwargs):
        print('this is called')

    g_connect(['v1', 'v2'])(a_func_that_does_something)



# Generated at 2022-06-10 23:49:03.023151
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test the constructor of class GalaxyAPI
    galaxy_api = GalaxyAPI()
    assert galaxy_api is not None


# Generated at 2022-06-10 23:51:24.342119
# Unit test for function cache_lock
def test_cache_lock():
    # Make sure that cache_lock is keeping its promise to serialize access to
    # the decorated functions. This is tested by two threads simultaneously
    # attempting to update the same key in the cache. A lock is used to read
    # and update the cache value; the decorator is used to serialize access to
    # the update function.

    # Use a global dict to simulate the cache; it is shared across threads.
    # This is to make sure that the cache_lock is actually required (otherwise
    # the test is not testing anything meaningful)
    test_cache = {}
    cache_lock_key = 'test-key'
    initial_test_value = 0

    # Ensure that one thread cannot interfere with the other thread
    assert threading.active_count() == 1

    # Establish the initial cache value

# Generated at 2022-06-10 23:51:36.138771
# Unit test for function g_connect
def test_g_connect():
    test_api_server = "https://test.galaxy.com"
    galaxy_client = GalaxyClient(test_api_server)

    @g_connect(['v1', 'v2'])
    def test_func(self):
        pass

    def fake_call_galaxy(url, method='GET', **kwargs):
        return {'available_versions': {u'v1': u'v1/'}}
    galaxy_client._call_galaxy = fake_call_galaxy
    galaxy_client._available_api_versions = {}

    galaxy_client._available_api_versions = {}
    test_func(galaxy_client)
