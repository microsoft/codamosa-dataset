

# Generated at 2022-06-10 23:43:05.861068
# Unit test for function g_connect
def test_g_connect():
    class GalaxyComm(object):
        def __init__(self, api_server=None, ignore_certs=False, ignore_errors=False, params=None):
            self._available_api_versions = {}
            self.api_server = api_server
            self.ignore_certs = ignore_certs
            self.ignore_errors = ignore_errors
            self.params = params

        def _call_galaxy(self, url, method, error_context_msg=None, cache=False):
            return {}

    # decorator
    def my_method(self):
        return True

    mock_obj = GalaxyComm()
    decorated_func = g_connect(['v1', 'v3'])(my_method)

# Generated at 2022-06-10 23:43:16.322154
# Unit test for function g_connect
def test_g_connect():
    from collections import namedtuple
    from ansible.plugins.action import ActionModule

    class MockActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self.name = 'test_collection'
            self.galaxy_server = 'test_galaxy_server'
            self.api_server = 'test_api_server'
            self.version = 2
            self._available_api_versions = {}
            self.galaxy_token = 'test_token'
            self.galaxy_ignore_certs = False
            self._role_cache = None
            super(MockActionModule, *args, **kwargs)

        @g_connect(['v2'])
        def simple_method(self, *args, **kwargs):
            pass

    action = MockActionModule()
   

# Generated at 2022-06-10 23:43:27.383084
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.module_utils._text import to_bytes
    from units.compat.mock import MagicMock, patch
    from urllib.parse import urlparse


# Generated at 2022-06-10 23:43:35.943989
# Unit test for function g_connect
def test_g_connect():
    class Galaxy:
        def __init__(self):
            self._available_api_versions = {}
            self.name = ""
            self.api_server = ""
            self.auth_token = ""
            self.github_user = ""

        def _call_galaxy(self, *args, **kwargs):
            return {}

    def fn(self):
        pass

    decorated = g_connect(['v1', 'v2'])(fn)
    decorated(Galaxy())



# Generated at 2022-06-10 23:43:41.551279
# Unit test for function g_connect
def test_g_connect():
    class m:

        def __init__(self):
            self._available_api_versions = []

    d = g_connect(versions=[1, 2])(m)
    m = {"available_versions": {u'v1': u'v1/'}}
    with pytest.raises(AnsibleError):
        d(m)



# Generated at 2022-06-10 23:43:47.160077
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    """
    Unit test for method __lt__ of class GalaxyAPI
    """
    mock_self = create_autospec(GalaxyAPI)
    mock_self.name = "foo"
    mock_other = create_autospec(GalaxyAPI)
    mock_other.name = "bar"
    assert not mock_self.__lt__(mock_other)
    assert mock_self.__lt__(mock_self)
    mock_self.name = "bar"
    assert not mock_self.__lt__(mock_other)
    assert mock_self.__lt__(mock_self)
    mock_self.name = "goo"
    assert mock_self.__lt__(mock_other)
    assert not mock_self.__lt__(mock_self)
    assert mock_self

# Generated at 2022-06-10 23:43:50.706683
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    err = GalaxyError(None, "message")
    assert err.message == 'message'
    assert err.http_code == None
    assert err.url == None



# Generated at 2022-06-10 23:44:01.198604
# Unit test for function get_cache_id
def test_get_cache_id():
    url_base = 'https://localhost'
    url_with_port = 'https://localhost:8080'
    url_with_path = 'https://localhost/api'
    url_with_path2 = 'https://localhost/api/'
    url_with_pathes = 'https://localhost/api/v1/collections'

    assert get_cache_id(url_base) == 'localhost'
    assert get_cache_id(url_with_port) == 'localhost'
    assert get_cache_id(url_with_path) == 'localhost'
    assert get_cache_id(url_with_path2) == 'localhost'
    assert get_cache_id(url_with_pathes) == 'localhost'


# Generated at 2022-06-10 23:44:11.151421
# Unit test for function get_cache_id
def test_get_cache_id():
    # Test 'http://galaxy.example.com'
    assert get_cache_id('http://galaxy.example.com') == 'galaxy.example.com'

    # Test 'http://galaxy.example.com:8080'
    assert get_cache_id('http://galaxy.example.com:8080') == 'galaxy.example.com:8080'

    # Test 'https://galaxy.example.com'
    assert get_cache_id('https://galaxy.example.com') == 'galaxy.example.com'

    # Test 'https://galaxy.example.com:8080'
    assert get_cache_id('https://galaxy.example.com:8080') == 'galaxy.example.com:8080'

    # Test 'http://localhost'

# Generated at 2022-06-10 23:44:21.232410
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    class Response:
        code = 403
        reason = 'Forbidden'
        def read(self):
            error = {}
            error['default'] = 'An error occurred.'
            return str(error)
        def geturl(self):
            return 'https://galaxy.ansible.com/api/v1/'
    class HTTPError:
        def __init__(self, url, http_error, message):
            self.url = url
            self.code = http_error.code
            self.message = message
            self.read = http_error.read
            self.geturl = http_error.geturl
            self.reason = http_error.reason
        def __str__(self):
            return self.__unicode__()
        def __unicode__(self):
            return u'%s: %s'

# Generated at 2022-06-10 23:45:05.872253
# Unit test for function g_connect
def test_g_connect():
    class DummyConn:
        def __init__(self, data, name, api_server):
            self._available_api_versions = data
            self.name = name
            self.api_server = api_server
            self.api_server_url = api_server
            self.cache = True
        @g_connect(["v1"])
        def v1_only(self):
            pass
        @g_connect(["v1", "v2"])
        def v1_or_v2(self):
            pass
        @g_connect(["v1", "v2", "v3"])
        def v1_v2_or_v3(self):
            pass
        def reset(self):
            self._available_api_versions = {}

    # Test connection with only api v1 available
   

# Generated at 2022-06-10 23:45:13.588573
# Unit test for function g_connect
def test_g_connect():
    display.vvvv("test g_connect")
    def test_method(self, *args, **kwargs):
        return "hello"
    t = GalaxyAPI()
    m = g_connect(['v1'])(test_method)
    assert m.__name__ == 'wrapped'
    assert m(t) == "hello"
    t = GalaxyAPI()
    try:
        m(t)
        assert False
    except AnsibleError:
        pass
    
    


# Generated at 2022-06-10 23:45:18.079878
# Unit test for function g_connect
def test_g_connect():
    ansible_galaxy_api_versions = ['v3']

    @g_connect(versions=ansible_galaxy_api_versions)
    def wrapper():
        print("Hello World")

    wrapper()

#test_g_connect()


# Generated at 2022-06-10 23:45:25.271182
# Unit test for function g_connect
def test_g_connect():
    class version_test_case(object):
        def __init__(self):
            self.api_server = 'http://galaxy.ansible.com'
            self.name = 'test'
            self._available_api_versions = None

        @g_connect(versions=['v1', 'v2'])
        def v_test_method(self):
            return True

    assert version_test_case().v_test_method()


#
# Testing utils
#


# Generated at 2022-06-10 23:45:32.896109
# Unit test for function g_connect
def test_g_connect():
    assert 'get_role_list' in dir(GalaxyAPI())
    assert 'get_role_list_metadata' in dir(GalaxyAPI())
    assert 'get_role_list_permissions' in dir(GalaxyAPI())
    assert 'get_role_list_compatibility' in dir(GalaxyAPI())
    assert 'get_list' in dir(GalaxyAPI())
    assert 'get_lists' in dir(GalaxyAPI())
    assert 'get_me' in dir(GalaxyAPI())
    assert 'get_user_list' in dir(GalaxyAPI())

# Generated at 2022-06-10 23:45:43.659802
# Unit test for function g_connect
def test_g_connect():
    @g_connect(versions=['v1'])
    def test_method(self):
        return 'test'

    class GalaxyConnection(object):

        def __init__(self, api_server, name='test', token=None, token_ids=None, ignore_certs=None):
            pass

        def _call_galaxy(self, url, method='GET', params=None, data=None, headers=None, files=None, validate_certs=None,
                         force_basic_auth=False, follow_redirects='urllib2', url_username=None, url_password=None,
                         error_context_msg=None, cache=False):
            return {
                u'available_versions': {
                    u'v1': u'v1/'
                }
            }

    g_conn = Galaxy

# Generated at 2022-06-10 23:45:48.954352
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # constructor
    from collections import namedtuple
    galaxy_credentials = namedtuple('galaxy_credentials', ['server', 'api_key', 'validate_certs'])
    GalaxyAPI(galaxy_credentials(server='http://localhost:5000', api_key='', validate_certs=True))



# Generated at 2022-06-10 23:46:03.413365
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Test for v1 error
    message = "Galaxy server expects collection name 'namespace/collection' in content header"
    err_json = dict(default="The request included unknown attributes: content")
    http_error = HTTPError("http://galaxy.example.com/collections", 400, message=err_json, hdrs=None, fp=None)
    ge = GalaxyError(http_error, message)
    assert ge.http_code == 400
    assert ge.url == "http://galaxy.example.com/collections"
    assert ge.message == "Galaxy server expects collection name 'namespace/collection' in content header (HTTP Code: 400, Message: The request included unknown attributes: content)"

    # Test for v2 error
    message = "The specified object does not exist."

# Generated at 2022-06-10 23:46:08.522810
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('url', 400, "Bad Request", [], None)
    message = 'test'
    err = GalaxyError(http_error, message)
    assert(err.http_code == 400)
    assert(err.url == 'url')
    assert(err.message == 'test (HTTP Code: 400, Message: Bad Request)')



# Generated at 2022-06-10 23:46:21.553257
# Unit test for function g_connect
def test_g_connect():
    import inspect
    import sys
    import io
    from ansible.module_utils.six import StringIO

    class TestGalaxyObject:
        def __init__(self, available_versions, name, api_server):
            self._available_api_versions = available_versions
            self.name = name
            self.api_server = api_server

        @g_connect(versions=['v1', 'v2'])
        def sample_method(self):
            return True

    # Test with v1 available
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    test_object = TestGalaxyObject(available_versions={u'v1': u'v1/'}, name='test', api_server='test')
    assert test_object.sample_method() is True
   

# Generated at 2022-06-10 23:46:59.475292
# Unit test for function g_connect
def test_g_connect():
    """
    Unit test for g_connect function
    """
    g_connect([])(lambda self: True)(object)


# Generated at 2022-06-10 23:47:09.239343
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # pylint: disable=too-many-branches
    ex = GalaxyError(HTTPError('https://galaxy.ansible.com', 401, 'Unauthorized', {}, None), 'Auth required')
    assert ex.http_code == 401
    assert ex.url == 'https://galaxy.ansible.com'
    assert ex.message.startswith('Auth required (HTTP Code: 401')
    assert ex.message.endswith(')')

    ex = GalaxyError(HTTPError('https://galaxy.ansible.com/api/v2/', 401, 'Unauthorized', {}, None), 'Auth required')
    assert ex.http_code == 401
    assert ex.url == 'https://galaxy.ansible.com/api/v2/'

# Generated at 2022-06-10 23:47:19.362247
# Unit test for function g_connect
def test_g_connect():
    from ansible.galaxy.collection import CollectionRequirement
    from ansible.galaxy.role import GalaxyRole
    class MockGalaxyClient(object):
        def __init__(self):
            self.name = 'galaxy'
            self.api_server = 'https://galaxy.ansible.com/api/'
            self.token = 'fake.token.com/'
            self.api_key = 'APIKEY'
            self.client_cert = 'client-cert.pem'
            self.client_key = 'client-key.pem'
            self.validate_certs = True
            self._available_api_versions = None


# Generated at 2022-06-10 23:47:21.004368
# Unit test for function cache_lock
def test_cache_lock():
    def f():
        return True

    g = cache_lock(f)
    assert g() == True



# Generated at 2022-06-10 23:47:27.116148
# Unit test for function g_connect
def test_g_connect():
    def test(self, *args, **kwargs):
        return 1
    test = g_connect([u'v1'])(test)
    # No API version set yet
    assert(test(GalaxyAPI("galaxy.ansible.com", "test", "test", "test")) == 1)
    # API version set, but no version
    assert(test(GalaxyAPI("https://galaxy.ansible.com/api/", "test", "test", "test")) == 1)
    # API version set, but incorrect version
    assert(test(GalaxyAPI("https://galaxy.ansible.com/api/", "test", "test", "test", available_api_versions={u'v3': ''})) == 1)
    # API version set, but empty version list

# Generated at 2022-06-10 23:47:34.973812
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api1 = GalaxyAPI('name1', 'api_server1')
    api2 = GalaxyAPI('name2', 'api_server2')

    assert api1 < api2
    assert api2 != api1

    # Make sure using only the Galaxy name, even if the server is different, will result in equality.
    api2 = GalaxyAPI('name1', 'api_server2')
    assert api1 == api2
    assert api2 == api1

# Generated at 2022-06-10 23:47:41.693952
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('http://galaxy.ansible.com/',400, 'Bad Request', {}, None)
    gex = GalaxyError(http_error, 'Invalid request')
    assert gex.http_code == 400
    assert gex.url == 'http://galaxy.ansible.com/'
    assert gex.message == 'Invalid request (HTTP Code: 400, Message: Bad Request)'


# Generated at 2022-06-10 23:47:55.896571
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("http://www.example.com") == "www.example.com:"
    assert get_cache_id("http://www.example.com/") == "www.example.com:"
    assert get_cache_id("http://192.168.1.1:8080/api/") == "192.168.1.1:8080"
    assert get_cache_id("https://galaxy.ansible.com") == "galaxy.ansible.com:"
    assert get_cache_id("https://galaxy.ansible.com/api/") == "galaxy.ansible.com:"
    assert get_cache_id("https://galaxy.ansible.com:8080/api/") == "galaxy.ansible.com:8080"

# Generated at 2022-06-10 23:48:04.086172
# Unit test for function get_cache_id
def test_get_cache_id():
    url_list = [
        "http://galaxy.ansible.com:443/api/",
        "https://galaxy.ansible.com/api/",
        "https://galaxy.ansible.com/api/",
        "http://localhost:8080",
        "http://127.0.0.1:8080",
        "http://galaxy.ansible.com:8080/api?foo=bar",
    ]
    cache_id_list = [
        "galaxy.ansible.com:443",
        "galaxy.ansible.com:",
        "galaxy.ansible.com:",
        "localhost:8080",
        "127.0.0.1:8080",
        "galaxy.ansible.com:8080",
    ]

# Generated at 2022-06-10 23:48:14.891879
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxyAPI(GalaxyAPI):
        def __init__(self, galaxy, force_check):
            self.galaxy = galaxy
            self.force_check = force_check
            self.api_server = galaxy.api_server
            self.name = galaxy.name
            self.verify_ssl = galaxy.verify_ssl
            self.token = galaxy.token
            self._available_api_versions = []
        @g_connect([u'v1'])
        def test_func(self):
            pass
    galaxy = GalaxyAPI(name='test_galaxy_name', api_server='https://fake-galaxy-api', validate_certs=True, token='12345')
    t = TestGalaxyAPI(galaxy, True)
    t.test_func()
    


# Generated at 2022-06-10 23:48:53.006763
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Setup a GalaxyAPI instance,
    g_api = GalaxyAPI('galaxy.example.com')
    # Setup another GalaxyAPI instance,
    g_api2 = GalaxyAPI('galaxy.example.com')
    # Ensure that GalaxyAPI.__lt__() returns False
    assert not g_api < g_api2


# Generated at 2022-06-10 23:48:54.845935
# Unit test for function cache_lock
def test_cache_lock():
    """ """
    #  with _CACHE_LOCK():
    #      return func(*args, **kwargs)
    pass


# Generated at 2022-06-10 23:49:00.862665
# Unit test for function g_connect
def test_g_connect():
    client = Client('https://galaxy.ansible.com', token='123456', force_basic_auth=True, client_name='test_ansible')
    assert isinstance(client._available_api_versions, dict)
    assert client._available_api_versions == {u'v1': u'v1/', u'v2': u'v2/'}
    client._available_api_versions = {}
    assert client._available_api_versions == {}
    client._available_api_versions = {'status': 'Pass'}
    assert client._available_api_versions == {'status': 'Pass'}


# Generated at 2022-06-10 23:49:12.644497
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI('https://galaxy.server', ['v2', 'v3'], "admin", "password")
    assert galaxy_api.name == 'galaxy.server'
    assert galaxy_api.available_api_versions == {'v2': 'api', 'v3': 'api/v3'}
    assert galaxy_api.api_server == "https://galaxy.server"
    assert galaxy_api.verify_ssl
    assert galaxy_api.ignore_certs
    assert not galaxy_api.debug
    assert galaxy_api.url_transport == 'requests'
    assert galaxy_api.http_timeout == 10
    assert galaxy_api.http_auth is None
    assert not galaxy_api._no_verify_ssl
    assert not galaxy_api._no_ignore_certs

    galaxy_

# Generated at 2022-06-10 23:49:17.494841
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("http://testserver.com") == "testserver.com:"
    assert get_cache_id("http://testserver.com:8080") == "testserver.com:8080"
    assert get_cache_id("http://testserver.com/") == "testserver.com:"
    assert get_cache_id("http://testserver.com:8080/") == "testserver.com:8080"



# Generated at 2022-06-10 23:49:24.559117
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    e = GalaxyError('foo', http_code=429)
    assert is_rate_limit_exception(e)

    e = GalaxyError('foo', http_code=500)
    assert not is_rate_limit_exception(e)

    e = GalaxyError('foo', http_code=520)
    assert is_rate_limit_exception(e)



# Generated at 2022-06-10 23:49:34.821583
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    old_msg = "AnsibleError: %s (HTTP Code: %d, Message: %s)"
    http_error = type("FakeHTTPError", (object,), {"code": 200})()
    err = GalaxyError(http_error, "Error Message")
    assert err.http_code == 200
    assert err.message == old_msg % (u"Error Message", err.http_code, u"AnsibleError: %s (HTTP Code: %d, Message: %s)")

    new_msg = "AnsibleError: %s (HTTP Code: %d, Message: %s Code: %s)"
    http_error = type("FakeHTTPError", (object,), {"code": 200})()
    err = GalaxyError(http_error, "Error Message")
    assert err.http_code == 200
    err.url

# Generated at 2022-06-10 23:49:37.841381
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        raise Exception("This should not be raised")

    assert _CACHE_LOCK.locked()



# Generated at 2022-06-10 23:49:46.380956
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'

# Generated at 2022-06-10 23:49:48.484934
# Unit test for function cache_lock
def test_cache_lock():
    # TODO: make a real unit test
    func = cache_lock(lambda: 'hi')
    assert func() == 'hi'

