

# Generated at 2022-06-22 20:25:28.871064
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    c = CollectionVersionMetadata(namespace='cisco', name='aci', version='1.0.0', download_url='https://galaxy.ansible.com/api/v2/artifact/ansible.cisco%2Faci/1.0.0/download/', artifact_sha256='sha256', dependencies='')
    print(c.namespace)
    print(c.name)
    print(c.version)
    print(c.download_url)
    print(c.artifact_sha256)
    print(c.dependencies)

test_CollectionVersionMetadata()



# Generated at 2022-06-22 20:25:35.931338
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://localhost') == 'localhost'
    assert get_cache_id('http://localhost:8088') == 'localhost:8088'
    assert get_cache_id('http://localhost:8088/api/') == 'localhost:8088'
    assert get_cache_id('http://localhost:8088/api/v2/') == 'localhost:8088'
    assert get_cache_id('http://user@localhost:8088/api/v2/') == 'localhost:8088'
    assert get_cache_id('http://user:pass@localhost:8088/api/v2/') == 'localhost:8088'



# Generated at 2022-06-22 20:25:38.731411
# Unit test for function cache_lock
def test_cache_lock():
    func = lambda: 1
    wrapped = cache_lock(func)
    assert wrapped() == 1



# Generated at 2022-06-22 20:25:39.898699
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    return


# Generated at 2022-06-22 20:25:50.634100
# Unit test for function cache_lock
def test_cache_lock():
    import random
    import time

    random.seed(0)

    with _CACHE_LOCK:
        initial_calculation = random.randrange(0, 10)

    @cache_lock
    def func():
        return random.randrange(0, 10)

    # Parallel execution of cache-protected function
    results = []
    start_time = time.time()

    def worker():
        results.append(func())
        time.sleep(0.1)

    threads = [threading.Thread(target=worker) for i in range(10)]
    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    end_time = time.time()
    results.sort()

    # Output
    display.info('initial_calculation: %s' % initial_calculation)

# Generated at 2022-06-22 20:25:53.038124
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxyapi = GalaxyAPI()
    assert isinstance(galaxyapi.__repr__(), str)


# Generated at 2022-06-22 20:25:59.854389
# Unit test for function g_connect
def test_g_connect():
    check = g_connect(['v1', 'v2'])
    test_obj = GalaxyClient()
    def test_func(v1=True, v2=True):
        print(v1)
        print(v2)
        if v1 and v2:
            return True
        else:
            return False
    a = check(test_func)
    print(a)
    print(a(v1=False))
    b = check(test_func)
    print(b)
    print(b(v2=False))
# test_g_connect()


# Generated at 2022-06-22 20:26:07.145489
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    test_metadata = CollectionMetadata('ansible', 'community.general', '2020-06-11T18:57:15.590978')
    assert test_metadata.namespace == 'ansible'
    assert test_metadata.name == 'community.general'
    assert test_metadata.created_str == '2020-06-11T18:57:15.590978'
    assert isinstance(test_metadata.created, datetime.datetime)


# Generated at 2022-06-22 20:26:13.010394
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI('localhost:8080/api')
    assert api.api_server == 'http://localhost:8080/api'
    assert api.name == 'localhost:8080_api'
    assert api.available_api_versions == {'v2': 'v2', 'v3': 'v3'}
    assert api.verify_ssl is True
    assert api.auth_token is None
    assert api.token_path == '~/.ansible/galaxy/server_list'
    assert api.token_file == '%s.yml' % api.name


# Generated at 2022-06-22 20:26:17.680346
# Unit test for function cache_lock
def test_cache_lock():
    test_lock = {}
    @cache_lock
    def get_test_lock():
        return test_lock
    assert get_test_lock() is test_lock



# Generated at 2022-06-22 20:26:24.753872
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Define test values
    api_server = 'https://cloud.redhat.com/api/automation-hub/v1/api/'
    verify_ssl = True
    validate_certs = True
    token = 'master_token'
    scopes = ['invalid-scope']
    allow_collection_data_access = True

    # Create test object
    galaxy_api = GalaxyAPI(api_server, verify_ssl, validate_certs, token,
                           scopes, allow_collection_data_access)


# Generated at 2022-06-22 20:26:30.056951
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    a_collection_data = {
        'namespace': 'namespace',
        'name': 'name',
        'version': 'version',
        'download_url': 'download_url',
        'artifact_sha256': 'artifact_sha256',
        'dependencies': {}
    }
    a_collection_metadata = CollectionVersionMetadata(
        a_collection_data['namespace'],
        a_collection_data['name'],
        a_collection_data['version'],
        a_collection_data['download_url'],
        a_collection_data['artifact_sha256'],
        a_collection_data['dependencies'])
    assert a_collection_metadata.__dict__ == a_collection_data



# Generated at 2022-06-22 20:26:31.289850
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def func():
        return True
    assert func()


# Generated at 2022-06-22 20:26:42.325944
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # type: () -> None
    '''Unit test for function is_rate_limit_exception'''
    class MyException(Exception):
        pass

    class GalaxyError(AnsibleError):
        _ERROR_CODE = "GalaxyError"

        def __init__(self, msg, http_code=None, reason=None):
            self._http_code = http_code
            self._reason = reason
            super(GalaxyError, self).__init__(msg)

        def get_http_code(self):
            return self._http_code

        http_code = property(get_http_code)

    test_exception = GalaxyError(msg='Test msg', http_code=403)
    assert is_rate_limit_exception(test_exception) is False


# Generated at 2022-06-22 20:26:43.571500
# Unit test for function g_connect
def test_g_connect():
    assert True



# Generated at 2022-06-22 20:26:54.402681
# Unit test for function get_cache_id
def test_get_cache_id():

    # Test no port
    url1 = "https://galaxy.ansible.com/api/"
    url2 = "https://galaxy.ansible.com"
    assert get_cache_id(url1) == 'galaxy.ansible.com:443'
    assert get_cache_id(url2) == 'galaxy.ansible.com:443'

    # Test with port
    url1 = "https://galaxy.ansible.com:8080/api/"
    url2 = "https://galaxy.ansible.com:8080"
    assert get_cache_id(url1) == 'galaxy.ansible.com:8080'
    assert get_cache_id(url2) == 'galaxy.ansible.com:8080'



# Generated at 2022-06-22 20:27:02.320288
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    meta_obj = CollectionVersionMetadata('ansible', 'common', '1.0.0', '/somewhere/download_url', '123456789', None)
    assert meta_obj.name == 'common'
    assert meta_obj.namespace == 'ansible'
    assert meta_obj.version == '1.0.0'
    assert meta_obj.download_url == '/somewhere/download_url'
    assert meta_obj.artifact_sha256 == '123456789'
    assert meta_obj.dependencies == None



# Generated at 2022-06-22 20:27:12.234704
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'test'
    name = 'foo'
    version = '1.0.1'
    download_url = 'http://example.com/api/v2/collections/test/foo/1.0.1/download'
    artifact_sha256 = 'abc123'
    dependencies = {'test_dependency_1': '1.0.0', 'test_dependency_2': '2.0.0'}
    test_collection_version_metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert test_collection_version_metadata.namespace == namespace
    assert test_collection_version_metadata.name == name
    assert test_collection_version_metadata.version == version
    assert test_collection_version_metadata.download_url == download_url


# Generated at 2022-06-22 20:27:23.038734
# Unit test for function g_connect
def test_g_connect():
    # -- Test the decorator --
    # Test the decorator by passing in a dummy object and a method that requires v1 and v2. Then, test calling the
    # method before connecting and after with the API version being available and not.
    class Test(object):
        api_server = 'https://api.galaxy.ansible.com'
        name = 'Galaxy API'

        def __init__(self):
            self._available_api_versions = {}

        @g_connect([u'v1', u'v2'])
        def test_method(self):
            return 1

    test = Test()

# Generated at 2022-06-22 20:27:27.345284
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Create http error
    http_error = HTTPError(url="https://galaxy.ansible.com/api/", code=404)

    # create message
    message = "test message"
    real_message = "test message (HTTP Code: 404, Message: Not Found)"

    # Create galaxy error
    galaxy_error = GalaxyError(http_error, message)

    assert galaxy_error.http_code == 404
    assert galaxy_error.message == real_message
    assert galaxy_error.url == "https://galaxy.ansible.com/api/"



# Generated at 2022-06-22 20:27:34.520437
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api_server = 'https://galaxy.example.com'
    remove_tqm_args, token, verify_ssl, ignore_certs = GalaxyAPI._remove_tqm_args_from_kwargs('name',
            token='token', verify_ssl='verify_ssl', ignore_certs='ignore_certs')
    galaxy_api = GalaxyAPI.from_galaxy_instance(api_server, 'name', token=token, verify_ssl=verify_ssl,
            ignore_certs=ignore_certs)

    description = str(galaxy_api)

    assert description == ("API connection 'name' to galaxy server 'https://galaxy.example.com'")

# Generated at 2022-06-22 20:27:46.260490
# Unit test for function get_cache_id
def test_get_cache_id():
    cache_id = get_cache_id('http://localhost')
    assert cache_id == 'localhost:'
    cache_id = get_cache_id('http://localhost:1000')
    assert cache_id == 'localhost:1000'
    cache_id = get_cache_id('http://localhost:')  # Malformed
    assert cache_id == 'localhost:'
    cache_id = get_cache_id('http://localhost:a')  # Malformed
    assert cache_id == 'localhost:'
    cache_id = get_cache_id('http://localhost/')
    assert cache_id == 'localhost:'
    cache_id = get_cache_id('http://localhost/v1')
    assert cache_id == 'localhost:'
    cache_id = get_cache_id('https://localhost/v1')
    assert cache_id

# Generated at 2022-06-22 20:27:51.108964
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(status=429))
    assert is_rate_limit_exception(GalaxyError(status=520))
    assert not is_rate_limit_exception(GalaxyError(status=403))



# Generated at 2022-06-22 20:27:54.340630
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI("https://galaxy.example.com/")
    res = repr(api)
    assert res == "<GalaxyAPI(https://galaxy.example.com/api)>"


# Generated at 2022-06-22 20:27:56.918053
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI()
    assert isinstance(str(api), str)


# Generated at 2022-06-22 20:28:06.832723
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    from ansible.release import __version__
    collection_metadata = CollectionMetadata('ansible_namespace', 'ansible_collection', version='1.2.3',
                                             created_str='2017-12-01T00:00:00.000000Z',
                                             modified_str='2017-12-02T00:00:00.000000Z')
    assert collection_metadata.version == '1.2.3'
    assert collection_metadata.namespace == 'ansible_namespace'
    assert collection_metadata.name == 'ansible_collection'
    assert collection_metadata.created_str == '2017-12-01T00:00:00.000000Z'
    assert collection_metadata.modified_str == '2017-12-02T00:00:00.000000Z'


# Generated at 2022-06-22 20:28:16.868543
# Unit test for function g_connect
def test_g_connect():
    class Test(object):
        def __init__(self, api_server):
            self.api_server = api_server
            self._connection_info = None
            self._available_api_versions = None
            self.name = api_server

        def _call_galaxy(self, url, method, error_context_msg, data=None, params=None, ignore_codes=None, cache=False):
            return {'available_versions': {u'v1': u'v1/'}}

    t = Test('http://test.com')

    @g_connect([u'v1'])
    def test(self):
        return True

    assert test(t) is True



# Generated at 2022-06-22 20:28:21.276528
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    # Create an instance of GalaxyAPI with no arguments passed
    galaxy_api = GalaxyAPI()
    # Verify the name is 'undefined'
    assert galaxy_api.name == 'undefined'

# Generated at 2022-06-22 20:28:23.172412
# Unit test for function cache_lock
def test_cache_lock():
    # not testing cache_lock itself
    # this is to be used to wrap other functions
    pass



# Generated at 2022-06-22 20:28:28.104354
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI(api_server='http://localhost/api/', name='my_galaxy', url='http://localhost')
    assert str(galaxy_api) == "GalaxyAPI(name=my_galaxy, url=http://localhost, api_server=http://localhost/api/)"

# Generated at 2022-06-22 20:28:29.904775
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    assert CollectionMetadata('test', 'test', None, None, None, None)


# Generated at 2022-06-22 20:28:36.002830
# Unit test for function cache_lock
def test_cache_lock():
    lock_value = 2
    @cache_lock
    def get_lock_value(*args, **kwargs):
        return lock_value
    @cache_lock
    def change_lock_value(*args, **kwargs):
        nonlocal lock_value
        lock_value = 3
    assert lock_value == 2
    assert get_lock_value() == 2
    change_lock_value()
    assert lock_value == 2
    assert get_lock_value() == 3



# Generated at 2022-06-22 20:28:43.195937
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429, reason="Rate limit exceeded"))
    assert is_rate_limit_exception(GalaxyError(http_code=520, reason="Some cloudflare error"))
    assert is_rate_limit_exception(GalaxyError(http_code=500, reason="500 Server Error"))
    assert not is_rate_limit_exception(GalaxyError(http_code=403, reason="Not allowed"))



# Generated at 2022-06-22 20:28:47.129635
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI(api_server='https://galaxy.ansible.com', validate_certs=validate_certs, token=token)
    assert(str(galaxy_api) == "GalaxyAPI(api_server='https://galaxy.ansible.com', token='***', validate_certs=False)")



# Generated at 2022-06-22 20:28:49.452984
# Unit test for function g_connect
def test_g_connect():
    @g_connect(['v1'])
    def connect():
        pass
    return connect
# Test to check basic functionality of g_connect.
# It should return a function as output

# Generated at 2022-06-22 20:28:55.261983
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError('', None, 429))
    assert is_rate_limit_exception(GalaxyError('', None, 520))
    assert not is_rate_limit_exception(GalaxyError('', None, 503))
    assert not is_rate_limit_exception(GalaxyError('', None, 403))
    assert not is_rate_limit_exception(GalaxyError('', None, 401))
    assert not is_rate_limit_exception(Exception('Testing'))

# Used only when galaxy supports pagination of collections

# Generated at 2022-06-22 20:29:01.390505
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test connecting to a local Galaxy server
    api = GalaxyAPI(server='http://localhost:8080', token='my-token')
    assert api.name == 'localhost', api.name
    assert api.api_server == 'http://localhost:8080', api.api_server
    assert api.token == 'my-token', api.token
    assert api.validate_certs == True, api.validate_certs

# Generated at 2022-06-22 20:29:10.779391
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'namespace'
    name = 'name'
    version = '1.2.3'
    download_url = 'http://my-galaxy-server.com/namespace/name/1.2.3/'
    artifact_sha256 = 'abcdefghijklmnopqrstuvwxyz0123456789'
    dependencies = { 'namespaceA': { 'nameA': ['1.0.0', '1.0.1'] } }
    collection_version_metadata = CollectionVersionMetadata(
        namespace, name, version, download_url, artifact_sha256, dependencies)


# Generated at 2022-06-22 20:29:16.597534
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection = CollectionMetadata('namespace', 'name', '1.0.0')

    assert collection.name is 'name'
    assert collection.namespace is 'namespace'
    assert collection.version is '1.0.0'



# Generated at 2022-06-22 20:29:25.404940
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://galaxy.example.com/api/') == 'galaxy.example.com:'
    assert get_cache_id('http://galaxy.example.com:8080/api/') == 'galaxy.example.com:8080'
    assert get_cache_id('http://galaxy.example.com') == 'galaxy.example.com:'
    assert get_cache_id('http://galaxy.example.com/') == 'galaxy.example.com:'
    assert get_cache_id('http://galaxy.example.com:8080') == 'galaxy.example.com:8080'
    assert get_cache_id('http://galaxy.example.com:8080/') == 'galaxy.example.com:8080'

# Generated at 2022-06-22 20:29:30.891353
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    # Test with default values
    api = GalaxyAPI()
    assert str(api) == "Unnamed Galaxy Server"

    # Test with custom values
    api = GalaxyAPI(name="foo", api_server="https://foogalaxy.com")
    assert str(api) == "Galaxy Server foo (https://foogalaxy.com)"


# Generated at 2022-06-22 20:29:40.108666
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # We don't have an actual HTTP response for the exception so we make one
    # for the standard rate limit error code.
    response = make_fake_response(code=429)
    exception = GalaxyError.from_response('', '', response=response)
    assert is_rate_limit_exception(exception)

    # But not for a 403 error
    response = make_fake_response(code=403)
    exception = GalaxyError.from_response('', '', response=response)
    assert not is_rate_limit_exception(exception)



# Generated at 2022-06-22 20:29:49.687418
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Create an instance of GalaxyAPI with test values
    api_server = "test_api_server"
    name = "test_name"
    verify_ssl = 123
    token = "test_token"
    cookie_path = "test_cookie_path"
    user_agent = "test_user_agent"
    min_version = "test_min_version"
    max_version = "test_max_version"
    timeout = 123

    galaxy_api = GalaxyAPI(api_server, name, verify_ssl, token, cookie_path, user_agent, min_version, max_version, timeout)

    # The __repr__ method returns a string representation of an object.
    # The string is formatted as: "<class_name 'class_vars_repr'>". In this case, the value of the
    # class_v

# Generated at 2022-06-22 20:29:51.540431
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI('https://galaxy.example.com/', name='test')
    assert repr(api) == "GalaxyAPI(name='test', api_server='https://galaxy.example.com/')"

# Generated at 2022-06-22 20:30:02.725170
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = "robertdebock"
    name = "yum"
    version = "2.6.13"
    download_url = "https://galaxy.ansible.com/api/v2/collections/robertdebock/yum/versions/2.6.13/download/"
    artifact_sha256 = "abcd"
    dependencies = {"robertdebock.yum": "2.6.13"}

    collection_version_meta_data = CollectionVersionMetadata(
        namespace, name, version, download_url, artifact_sha256, dependencies)

    assert collection_version_meta_data.namespace == namespace
    assert collection_version_meta_data.name == name
    assert collection_version_meta_data.version == version
    assert collection_version_meta_data.download_url == download_url
   

# Generated at 2022-06-22 20:30:04.283820
# Unit test for function cache_lock
def test_cache_lock():
    def wrapped():
        with _CACHE_LOCK:
            return True

    assert wrapped() == True



# Generated at 2022-06-22 20:30:14.562602
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import errno
    message = 'Ansible Galaxy API error'

    def test_HTTPError(self, code, message):
        return self

    http_error = HTTPError('test_HTTPError', 500, message, {}, None)
    http_error.code = 500
    http_error.msg = message
    # test http error
    err = GalaxyError(http_error, message)
    # test the return value of GalaxyError
    assert isinstance(err, AnsibleError)
    assert err.http_code == 500
    assert err.url == 'test_HTTPError'
    assert err.message == u"Ansible Galaxy API error (HTTP Code: 500, Message:  Code: Unknown)"

    http_error = HTTPError('test_v2_HTTPError', 500, message, {}, None)

# Generated at 2022-06-22 20:30:22.373055
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    ansible_galaxy_server = 'ansible.galaxy.server.com'
    api_server = 'api.galaxy.server.com'

    galaxy_api = GalaxyAPI(ansible_galaxy_server, api_server)

    actual = repr(galaxy_api)
    assert actual == "<GalaxyAPI name='%s' api_server='%s', available_api_versions='[]'>" % (ansible_galaxy_server, api_server)

# Generated at 2022-06-22 20:30:29.762410
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    example_server = 'https://galaxy.ansible.com'
    api_versions = {
        'v3': '/api/v3/',
        'v2': '/api/v2/',
    }

    g = GalaxyAPI(example_server, api_versions)
    assert g.__unicode__() == '%s (server=%s, available_api_versions=%s)' \
                              % (GalaxyAPI.__name__, example_server, api_versions)



# Generated at 2022-06-22 20:30:41.881229
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    temp_namespace = 'share'
    temp_name = 'test'
    temp_version = '1.0.0'
    temp_url = 'https://galaxy/api/v2/collections/share/test/versions/1.0.0/tar.gz'
    temp_sha256 = '1234567890'
    temp_dependencies = {'test_dependency': '1.0.0'}
    temp_collection = CollectionVersionMetadata(temp_namespace, temp_name, temp_version, temp_url, temp_sha256, temp_dependencies)
    assert temp_collection.namespace == 'share'
    assert temp_collection.name == 'test'
    assert temp_collection.version == '1.0.0'

# Generated at 2022-06-22 20:30:44.987461
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    try:
        assertEqual(GalaxyAPI.__lt__((),{}),NotImplemented)
    except Exception:
        raise AssertionError

# Generated at 2022-06-22 20:30:46.940666
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Create the test case class
    api = GalaxyAPI(name="galaxy-test")
    str_val = str(api)
    # Check for expected value of api attribute
    assert str_val == "GalaxyAPI(name='galaxy-test')"


# Generated at 2022-06-22 20:30:58.567611
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.module_utils.urls import _urlparse

    galaxy_api = GalaxyAPI(
        name="galaxy",
        server_list=["http://localhost", "https://localhost"],
        api_server=_urlparse("http://localhost"),
        ignore_certs=True,
        ignore_errors=True,
        force_basic_auth=True,
        timeout=10,
        token="fake_token",
        username="username",
        password="password",
        available_api_versions={"v2": "api/v2"},
        force_api=False,
        client_cert=None,
        client_key=None
    )


# Generated at 2022-06-22 20:31:01.640765
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI('foo', 'https://galaxy.example.com')
    assert str(api) == 'https://galaxy.example.com'


# Generated at 2022-06-22 20:31:07.966550
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class MyGalaxyError(GalaxyError):
        def __init__(self, http_code):
            self.http_code = http_code

    assert is_rate_limit_exception(MyGalaxyError(429))
    assert not is_rate_limit_exception(MyGalaxyError(403))
    assert not is_rate_limit_exception(MyGalaxyError(200))



# Generated at 2022-06-22 20:31:11.418413
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def mock_func(a, b):
        return a + b

    mock_func(1, 2)
    assert mock_func(1, 2) == 3



# Generated at 2022-06-22 20:31:22.847736
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    '''
    Check that GalaxyAPI object is converted to str correctly
    '''
    galaxy_v2_server = 'http://mygalaxy.server.com:80/galaxy/'
    galaxy_v3_server = 'http://mygalaxy.server.com:80/automation-hub/'

    galaxy_api_v2 = GalaxyAPI(galaxy_v2_server, 'my-team')
    assert str(galaxy_api_v2) == '\n      Server: %s\n      Team: %s\n    ' % (galaxy_v2_server, 'my-team')

    galaxy_api_v3 = GalaxyAPI(galaxy_v3_server, 'my-team')

# Generated at 2022-06-22 20:31:32.555191
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'namespace'
    name = 'name'
    version = 'version'
    download_url = 'download_url'
    artifact_sha256 = 'artifact_sha256'
    dependencies = [{'namespace': 'namespace', 'name': 'name', 'version': 'version'}]
    expected = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert expected.namespace == namespace
    assert expected.name == name
    assert expected.version == version
    assert expected.download_url == download_url
    assert expected.artifact_sha256 == artifact_sha256
    assert expected.dependencies == dependencies



# Generated at 2022-06-22 20:31:42.198346
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import http.client
    response = http.client.HTTPResponse()
    http_error=http.client.HTTPException()
    http_error.code=404
    response.code=404
    http_error.reason="Error"
    http_error.msg="Error"
    response.reason="Error"
    msg="Not Found Error"
    response.read=lambda :'{}'
    http_error.read=lambda :'{}'
    galaxy_error=GalaxyError(http_error,msg)
    assert isinstance(galaxy_error, Exception)
    assert http_error.code == 404
    assert http_error.reason == "Error"
    galaxy_error.http_code == 404
    assert len(galaxy_error.url) > 0
    assert galaxy_error.message == msg



# Generated at 2022-06-22 20:31:46.264385
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    e = GalaxyError()
    e.http_code = 403
    assert not is_rate_limit_exception(e)

    e.http_code = 429
    assert is_rate_limit_exception(e)



# Generated at 2022-06-22 20:31:47.443162
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # TODO
    assert False

# Generated at 2022-06-22 20:31:53.961919
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    '''test_GalaxyAPI'''
    l_galaxy_api = GalaxyAPI('username', 'password', 'https://galaxy.ansible.com')
    assert l_galaxy_api.username == 'username'
    assert l_galaxy_api.password == 'password'
    assert l_galaxy_api.api_server == 'https://galaxy.ansible.com'



# Generated at 2022-06-22 20:32:02.674135
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    collection_version_metadata = CollectionVersionMetadata(namespace='ansible_namespace', name='collection_name', version='1.0.1', download_url='http://someurl', artifact_sha256='A234567890123456789012345678901234567890123456789012345678901234', dependencies={'namespace.name': '1.0.0'})
    assert collection_version_metadata.namespace == 'ansible_namespace'
    assert collection_version_metadata.name == 'collection_name'
    assert collection_version_metadata.version == '1.0.1'
    assert collection_version_metadata.download_url == 'http://someurl'

# Generated at 2022-06-22 20:32:11.028558
# Unit test for function cache_lock
def test_cache_lock():
    called = {'lock_acquired': False}
    def decorated():
        global called
        called['lock_acquired'] = True
        return {'result': 'success'}
    wrapped = cache_lock(decorated)
    try:
        thread = thread_cache_lock(wrapped)
        thread.start()
        time.sleep(1)
        assert called['lock_acquired'] is True
        assert wrapped() == {'result': 'success'}
        thread.join()
    except:
        # TODO: Replace with pytest style skip
        raise AssertionError("Function cache_lock failed.")


# Generated at 2022-06-22 20:32:18.798551
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://some.site/some/place', code=404, msg="Not found", hdrs={}, fp=None,
                           encoding=None)
    obj = GalaxyError(http_error, message="blah")
    assert isinstance(obj, GalaxyError)
    assert obj.http_code == http_error.code
    assert obj.url == http_error.geturl()
    assert obj.message == "blah (HTTP Code: 404, Message: Not found)"


# Generated at 2022-06-22 20:32:20.580490
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_instance = GalaxyAPI()
    assert str(galaxy_instance) == 'GalaxyAPI'

# Generated at 2022-06-22 20:32:32.132955
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    '''
    Test __unicode__ method of class GalaxyAPI
    '''
    # Instantiation of the class to test
    ans_galaxy_api = GalaxyAPI('localhost')
    # Case 1:
    # Input parameters:
    # api_server = 'localhost'
    # username = None
    # password = None
    # token = None
    # no_cache = False
    # Expected output:
    # ans_galaxy_api.__unicode__() = 'galaxy@localhost'
    assert ans_galaxy_api.__unicode__() == 'galaxy@localhost'
    # Case 2:
    # Input parameters:
    # api_server = 'localhost'
    # username = None
    # password = None
    # token = None
    # no_cache = True
    # Expected output:
   

# Generated at 2022-06-22 20:32:38.181793
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    t_api_v2 = GalaxyAPI(
        name='test_api',
        api_server='https://test_api.galaxy.ansible.com',
        token=None,
        ignore_certs=False,
        timeout=10,
    )
    t_api_v2.available_api_versions = {'v2': 'v2'}

    t_api_v3 = GalaxyAPI(
        name='test_api',
        api_server='https://test_api.galaxy.ansible.com',
        token=None,
        ignore_certs=False,
        timeout=10,
    )
    t_api_v3.available_api_versions = {'v3': 'v3'}


# Generated at 2022-06-22 20:32:49.196754
# Unit test for function g_connect
def test_g_connect():
    class A(object):
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'test'
            self._available_api_versions = dict(v1='v1/')
            self._fetch_url = lambda url, **kwargs: dict(available_versions=dict(v1='v1/'))

        @g_connect(versions=['v1', 'v2'])
        def test(self):
            return True

    a = A()
    assert(a.test())

    class B(object):
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'test'
            self._available_api_versions = dict()
            self._fetch

# Generated at 2022-06-22 20:32:56.761658
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error_dict = {"message": "Internal Server Error", "code": "500"}
    json_error_dict = json.dumps(error_dict)
    http_error = HTTPError('https://www.example.com', 500, json_error_dict, {}, None)
    message = "Galaxy server error"
    galaxy_error = GalaxyError(http_error, message)

    assert galaxy_error.message == "Galaxy server error (HTTP Code: 500, Message: Internal Server Error Code: 500)"



# Generated at 2022-06-22 20:33:00.339198
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    # Create the test case
    galaxy_api = GalaxyAPI("http://localhost", "User", "Pass")

    # Run the test
    result = galaxy_api.__unicode__()

    # Verify the results
    assert "http://localhost" == result

# Generated at 2022-06-22 20:33:05.462385
# Unit test for function cache_lock
def test_cache_lock():
    global_var = 0

    def func():
        global global_var
        global_var += 1

    func()  # global_var = 1

    with _CACHE_LOCK:
        func()  # global_var = 2

    func()  # global_var = 3

    for _ in range(10):
        thread = threading.Thread(target=func)
        thread.start()
    thread.join()

    assert global_var == 13



# Generated at 2022-06-22 20:33:11.023562
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    error1 = GalaxyError(http_code=429, message='Too many requests')
    error2 = GalaxyError(http_code=403, message='Forbidden')
    assert is_rate_limit_exception(error1)
    assert not is_rate_limit_exception(error2)



# Generated at 2022-06-22 20:33:14.561558
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    g = GalaxyAPI(api_server='test')
    expected = u"GalaxyAPI('test', 'https://galaxy.ansible.com/')"
    assert expected == str(g)


# Generated at 2022-06-22 20:33:20.052703
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxyapi = GalaxyAPI(name='ansible_galaxy_api', api_server='https://galaxy.server.com/galaxy/api/', api_key='aaaaaaaaaa')
    assert galaxyapi.__repr__() == "GalaxyAPI(name='ansible_galaxy_api', api_server='https://galaxy.server.com/galaxy/api/', api_key='<hidden>')" # noqa


# Generated at 2022-06-22 20:33:26.433535
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    """
    Test method __str__ of class GalaxyAPI
    """
    galaxy_api = GalaxyAPI(name="arbitrary_name_1", api_server="arbitrary_api_server")
    assert galaxy_api.__str__() == "arbitrary_name_1 Galaxy API at arbitrary_api_server\nVersions: {}"

# Generated at 2022-06-22 20:33:30.702749
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI('test_galaxy_api', 'https://fakeserver.com')
    assert galaxy_api.name == 'test_galaxy_api'
    assert galaxy_api.api_server == 'https://fakeserver.com'
    assert galaxy_api.available_api_versions == {}



# Generated at 2022-06-22 20:33:36.195195
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    """
    Test for method __repr__ of class GalaxyAPI
    """
    MockLogger = collections.namedtuple('MockLogger', ['verbosity'])
    def ansible_galaxy_api_server():
        return 'https://galaxy.ansible.com'

    api = GalaxyAPI(api_server=ansible_galaxy_api_server(),
                    token='MockToken',
                    ignore_certs=True,
                    logger=MockLogger(verbosity=True))
    assert repr(api) == '<GalaxyAPI(galaxy.ansible.com)>'

# Generated at 2022-06-22 20:33:41.060579
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    workspace = tempfile.mkdtemp()
    api = GalaxyAPI()

    actual = repr(api)
    expected = "<GalaxyAPI object (https://galaxy.ansible.com/api)>"

    assert actual == expected
    shutil.rmtree(workspace)


# Generated at 2022-06-22 20:33:50.839227
# Unit test for function get_cache_id
def test_get_cache_id():
    import random
    assert get_cache_id("http://www.example.com") == "www.example.com:"
    assert get_cache_id("https://www.example.com") == "www.example.com:"
    assert get_cache_id("http://www.example.com:80") == "www.example.com:"
    assert get_cache_id("http://www.example.com:8080") == "www.example.com:8080"
    assert get_cache_id("https://www.example.com:443") == "www.example.com:"
    assert get_cache_id("https://www.example.com:8443") == "www.example.com:8443"
    assert get_cache_id("https://www.example.com/path") == "www.example.com:"

# Generated at 2022-06-22 20:34:00.364453
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    data = {
        'namespace': 'abc',
        'name': 'def',
        'created_str': '2020-01-20',
        'modified_str': '2020-02-20',
    }
    collection_metadata = CollectionMetadata(**data)

    assert collection_metadata.namespace == data['namespace']
    assert collection_metadata.name == data['name']
    assert collection_metadata.created_str == data['created_str']
    assert collection_metadata.modified_str == data['modified_str']
    assert collection_metadata.created == datetime.datetime(2020, 1, 20)
    assert collection_metadata.modified == datetime.datetime(2020, 2, 20)



# Generated at 2022-06-22 20:34:06.672971
# Unit test for function cache_lock
def test_cache_lock():
    global __test_cache_lock__
    global __test_lock_called__
    __test_cache_lock__ = 0
    __test_lock_called__ = False

    @cache_lock
    def increase_value():
        global __test_lock_called__, __test_cache_lock__
        assert not __test_lock_called__
        __test_lock_called__ = True
        __test_cache_lock__ += 1

    def run_increase_value_threads(threads_count):
        threads = []
        for _num in range(threads_count):
            thread = threading.Thread(target=increase_value)
            thread.start()
            threads.append(thread)

        for thread in threads:
            thread.join()
    # check that we can call the function in a single thread


# Generated at 2022-06-22 20:34:07.893655
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI()



# Generated at 2022-06-22 20:34:15.379790
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error = GalaxyError(404, "message")
    assert error.http_code == 404
    assert error.message == "message (HTTP Code: 404)"

    error = GalaxyError(403, "message")
    assert error.http_code == 403
    assert error.message == "message (HTTP Code: 403)"

    error = GalaxyError(401, "message")
    assert error.http_code == 401
    assert error.message == "message (HTTP Code: 401)"

    error = GalaxyError(500, "message")
    assert error.http_code == 500
    assert error.message == "message (HTTP Code: 500)"



# Generated at 2022-06-22 20:34:20.450099
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_info = {'name': 'Galaxy Name', 'api_server': '', 'available_api_versions': {}}
    g1 = GalaxyAPI(**galaxy_info)
    g2 = GalaxyAPI(**galaxy_info)
    assert (g1 < g2) == False

# Generated at 2022-06-22 20:34:27.965730
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    """
    Test that initializing the class with a namespace, name, and create_str gives a collection with those values.
    """
    namespace = "ansible"
    name = "test_collection"
    created_str = "2019-10-28 20:08:09.764671+00:00"
    metadata = CollectionMetadata(namespace, name, created_str=created_str)
    assert metadata.namespace == namespace
    assert metadata.name == name
    assert metadata.created_str == created_str


# Generated at 2022-06-22 20:34:31.378647
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    gapi = GalaxyAPI(name='MyGalaxy', api_server='https://my.galaxy/api', ignore_certs=True)
    assert str(gapi) == '<GalaxyAPI MyGalaxy (https://my.galaxy/api)>'


# Generated at 2022-06-22 20:34:38.001030
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    ver = CollectionVersionMetadata('namespace', 'name', '1.0.0', 'download_url', 'sha256', [])
    assert ver.version == '1.0.0'

    meta = CollectionMetadata('namespace', 'name', 'created_str', 'modified_str')
    assert meta.namespace == 'namespace'
    assert meta.name == 'name'
    assert meta.created_str == 'created_str'
    assert meta.modified_str == 'modified_str'

    meta = CollectionMetadata(namespace='namespace', name='name', created_str='created_str', modified_str='modified_str')
    assert meta.namespace == 'namespace'
    assert meta.name == 'name'
    assert meta.created_str == 'created_str'

# Generated at 2022-06-22 20:34:48.265734
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'foo'
    name = 'bar'
    version = '1.0.0'
    download_url = 'https://foo.bar/bar-1.0.0.tar.gz'
    artifact_sha256 = 'abc'
    dependencies = {'foo': ['bar'],}
    metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert namespace == metadata.namespace
    assert name == metadata.name
    assert version == metadata.version
    assert download_url == metadata.download_url
    assert artifact_sha256 == metadata.artifact_sha256
    assert dependencies == metadata.dependencies


# Generated at 2022-06-22 20:34:53.852719
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429)) is True
    assert is_rate_limit_exception(GalaxyError(http_code=520)) is True
    assert is_rate_limit_exception(GalaxyError(http_code=400)) is False
    assert is_rate_limit_exception(AnsibleError()) is False



# Generated at 2022-06-22 20:35:04.295244
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = "g"
    name = "nginx"
    version = "0.1.0"
    download_url = "https://galaxy.example.com/api/galaxy-v2/collections/namespace/collection/0.1.0/"
    artifact_sha256 = "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c"
    dependencies = {"redhat.yum": [{"namespace":"r", "name":"nginx", "version": "0.1.0.0"}]}

# Generated at 2022-06-22 20:35:08.902725
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_metadata = CollectionMetadata(namespace='namespace', name='name')
    assert collection_metadata.namespace == 'namespace'
    assert collection_metadata.name == 'name'


# Generated at 2022-06-22 20:35:19.705467
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert( is_rate_limit_exception( GalaxyError('galaxy server error', {}, http_code=429, http_response='sdfsdfsdf') ) )
    assert( is_rate_limit_exception( GalaxyError('galaxy server error', {}, http_code=520, http_response='sdfsdfsdf') ) )
    assert( not is_rate_limit_exception( GalaxyError('galaxy server error', {}, http_code=403, http_response='sdfsdfsdf') ) )
    assert( not is_rate_limit_exception( GalaxyError('galaxy server error', {}, http_code=500, http_response='sdfsdfsdf') ) )

# Generated at 2022-06-22 20:35:21.497507
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Implicit above
    pass


# Generated at 2022-06-22 20:35:25.148913
# Unit test for function cache_lock
def test_cache_lock():
    obj = object()
    lock = threading.Lock()

    @cache_lock
    def f():
        assert lock.locked()
        return obj

    assert not lock.locked()
    assert f() is obj

