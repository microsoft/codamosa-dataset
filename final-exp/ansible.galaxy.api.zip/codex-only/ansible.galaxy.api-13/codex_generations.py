

# Generated at 2022-06-22 20:25:34.411701
# Unit test for function g_connect
def test_g_connect():
    class Galaxy(object):
        def __init__(self, api_server, ignore_certs, name, galaxy_token):
            self.api_server = api_server
            self.ignore_certs = ignore_certs
            self.name = name
            self.galaxy_token = galaxy_token

    class MyGalaxy(Galaxy):
        def __init__(self, api_server, ignore_certs, name, galaxy_token):
            super(MyGalaxy, self).__init__(api_server, ignore_certs, name, galaxy_token)
            self._available_api_versions = {}

        @g_connect(['v1'])
        def v1_a1(self, *args, **kwargs):
            return args, kwargs

    # Test first call to galaxy_server, check for version

# Generated at 2022-06-22 20:25:38.560226
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api_server = 'http://localhost:8080'
    api = GalaxyAPI(api_server)
    assert str(api) == 'localhost:8080'


# Generated at 2022-06-22 20:25:46.900212
# Unit test for function get_cache_id
def test_get_cache_id():
    # Returns a unique string for each unique URL.
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://user:pass@galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:80/api') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'

# Generated at 2022-06-22 20:25:52.469562
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # Create a GalaxyError instance
    galaxy_error = GalaxyError(msg='test', http_code=429)
    assert is_rate_limit_exception(galaxy_error)
    assert not is_rate_limit_exception(AnsibleError(to_native('test ansible error')))
    assert not is_rate_limit_exception(Exception(to_native('test exception')))



# Generated at 2022-06-22 20:25:57.549993
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert not is_rate_limit_exception(GalaxyError('error'))
    assert is_rate_limit_exception(GalaxyError('error', http_code=429))
    assert is_rate_limit_exception(GalaxyError('error', http_code=520))
    assert not is_rate_limit_exception(GalaxyError('error', http_code=403))



# Generated at 2022-06-22 20:26:08.418013
# Unit test for function cache_lock
def test_cache_lock():
    import threading
    import time
    class Test(object):
        lock_value = ""
        lock = threading.Lock()
        def test_func(self, *args, **kwargs):
            assert not self.lock.locked()
            cache_lock(self.test_func_inner)(*args, **kwargs)
            assert not self.lock.locked()

        def test_func_inner(self, *args, **kwargs):
            assert not self.lock.locked()
            with self.lock:
                assert self.lock.locked()
                time.sleep(0.5)
                self.lock_value = "foo"
    tester = Test()
    thr1 = threading.Thread(target=tester.test_func)
    thr2 = threading.Thread(target=tester.test_func)


# Generated at 2022-06-22 20:26:11.803122
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    c = GalaxyAPI('https://galaxy.server.com', 'username', 'password')
    assert c.username == 'username'
    assert c.password == 'password'
    assert c.api_server == 'https://galaxy.server.com'
    assert c.available_api_versions == {}
    assert c.cache_path == '~/.galaxy_api_cache.yml'

    # Ensure the cache is not loaded
    assert c.cache == {}

    # Ensure the options are not set
    assert c.options is None



# Generated at 2022-06-22 20:26:21.594721
# Unit test for function get_cache_id
def test_get_cache_id():
    """
    Test function to get_cache_id
    :return:
    """
    # test case 1
    url = 'http://localhost:5000/v1/'
    assert get_cache_id(url) == 'localhost:5000'

    # test case 2
    url = 'http://test.com/test/test'
    assert get_cache_id(url) == 'test.com'

    # test case 3
    url = 'http://myserver.com/test/test'
    assert get_cache_id(url) == 'myserver.com'



# Generated at 2022-06-22 20:26:31.168928
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'namespace'
    name = 'collection_name'
    created_str = '2018-01-01'
    modified_str = '2018-01-02'

    # Test constructor with namespace, name and dates
    collection_metadata = CollectionMetadata(namespace, name, created_str=created_str, modified_str=modified_str)
    assert isinstance(collection_metadata, CollectionMetadata)

    # Test created_at
    assert collection_metadata.created_at.isoformat() == created_str
    # Test modified_at
    assert collection_metadata.modified_at.isoformat() == modified_str


# Generated at 2022-06-22 20:26:42.326982
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("https://mygalaxyserver.com") == "mygalaxyserver.com:"
    assert get_cache_id("https://mygalaxyserver.com:80") == "mygalaxyserver.com:80"
    assert get_cache_id("https://mygalaxyserver.com:443/") == "mygalaxyserver.com:443"
    assert get_cache_id("https://skvidal@mygalaxyserver.com") == "mygalaxyserver.com:"
    assert get_cache_id("https://skvidal:mypassword@mygalaxyserver.com") == "mygalaxyserver.com:"

# Generated at 2022-06-22 20:26:54.285700
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_metadata = CollectionMetadata('galaxy_collection_test_namespace', 'galaxy_collection_test_name',
                                             'galaxy_collection_test_version', 'galaxy_collection_test_type',
                                             'galaxy_collection_test_license', 'galaxy_collection_test_author',
                                             'galaxy_collection_test_description', 'galaxy_collection_test_issues',
                                             'galaxy_collection_test_homepage', 'galaxy_collection_test_repository',
                                             'galaxy_collection_test_dependencies',
                                             'galaxy_collection_test_min_ansible_version', 'galaxy_collection_test_download_url')
    assert 'galaxy_collection_test_namespace' == collection_metadata.namespace

# Generated at 2022-06-22 20:27:05.207441
# Unit test for function g_connect
def test_g_connect():
    # API version supported by the function
    versions = ['v2']

    # Actual API versions supported by the server
    available_versions = {'v1': 'v1/', 'v2': 'v2/'}

    # Check for API version match
    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                self._available_api_versions = available_versions
                display.vvvv("Found API version '%s' with Galaxy server %s (%s)"
                             % (', '.join(available_versions.keys()), self.name, self.api_server))

            # Verify that the API versions the function works with are available on the server specified.
            available_versions = set(self._available_api_versions.keys())
            common_versions = set

# Generated at 2022-06-22 20:27:10.154921
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func(arg):
        return arg

    r = test_func('foo')
    assert r == 'foo'


# Backport of OrderedDict() class that runs on Python 2.4, 2.5, 2.6, 2.7 and pypy.
# Passes Python2.7's test suite and incorporates all the latest updates.



# Generated at 2022-06-22 20:27:20.949772
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI('ansible',
                           name='ansible',
                           api_server='https://galaxy.ansible.com',
                           ignore_certs=False,
                           ignore_certs_set=False,
                           auth_user=None,
                           auth_pass=None,
                           auth_token=None,
                           auth_url=None,
                           retries=3,
                           delay=2,
                           timeout=5)

# Generated at 2022-06-22 20:27:28.946529
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy = GalaxyAPI("galaxy", "http://foo.com")

    assert galaxy.name == "galaxy"
    assert galaxy.api_server == "http://foo.com"
    assert galaxy.force == False
    assert galaxy.set_verify == True
    assert galaxy.verify_ssl is None
    assert galaxy.token == ""
    assert galaxy.available_api_versions == {}


# Generated at 2022-06-22 20:27:38.635141
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    #https://stackoverflow.com/questions/7831371/python-unit-test-with-urllib2-urlopen

    from urllib.error import HTTPError

    url = "http://galaxy.example.com"
    error_message = "Something bad happened"
    http_code=404
    response_data = {
        "galaxy_error": {
            "message": error_message,
            "code": "UNKNOWN_ERROR"
        }
    }

    fake_response = HTTPError(url=url, code=http_code, msg=error_message, hdrs={}, fp=None, dados=response_data)
    wrapped_error = GalaxyError(http_error=fake_response, message="Something bad happened")


# Generated at 2022-06-22 20:27:44.325849
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    ex = GalaxyError('error', http_code=429)
    assert is_rate_limit_exception(ex) is True
    ex = GalaxyError('error', http_code=403)
    assert is_rate_limit_exception(ex) is False
    ex = Exception('error', http_code=429)
    assert is_rate_limit_exception(ex) is False



# Generated at 2022-06-22 20:27:56.017954
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # HTTP 429
    exception = GalaxyError('429 Client Error: Too Many Requests for url', 429)
    assert is_rate_limit_exception(exception)

    # HTTP 5XX
    exception = GalaxyError('520 origin connection timeout', 520)
    assert is_rate_limit_exception(exception)

    # HTTP 403 (does not match RETRY_HTTP_ERROR_CODES)
    exception = GalaxyError('403 Client Error: Forbidden for url', 403)
    assert not is_rate_limit_exception(exception)

    # Exception is not a GalaxyError
    exception = HTTPError('403 Client Error: Forbidden for url', 403)
    assert not is_rate_limit_exception(exception)
# Note: we need to ensure that exc.http_code fails if the exception is not a GalaxyError.
# Otherwise, we may

# Generated at 2022-06-22 20:28:05.309401
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(429))
    assert is_rate_limit_exception(GalaxyError(520))
    assert not is_rate_limit_exception(GalaxyError(403))
    assert not is_rate_limit_exception(GalaxyError(404))
    assert not is_rate_limit_exception(GalaxyError(500))
    assert not is_rate_limit_exception(GalaxyError(None))
    assert not is_rate_limit_exception(ValueError("Simulated error"))

# Is this a 409 (Conflict) error which can be retried to avoid accidentally
# overwriting a newer release?

# Generated at 2022-06-22 20:28:16.561949
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    with pytest.raises(ValueError):
        CollectionMetadata('ns')
    with pytest.raises(ValueError):
        CollectionMetadata('ns', 'name')
    valid = CollectionMetadata(namespace='ns', name='name', version='1.0.0', created_str='Tue, 17 Sep 2019 13:37:42 GMT',
                               modified_str='Tue, 17 Sep 2019 13:37:42 GMT')
    valid2 = CollectionMetadata(namespace='ns', name='name', version='1.0.0')
    assert valid.namespace == valid2.namespace
    assert valid.name == valid2.name
    assert valid.version == valid2.version
    assert valid.created_str == valid2.created_str
    assert valid.modified_str == valid2.modified_str



# Generated at 2022-06-22 20:28:26.845054
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    setattr(C, 'GALAXY_SERVER', 'https://galaxy.ansible.com')
    assert C.GALAXY_SERVER == 'https://galaxy.ansible.com'
    setattr(C, 'GALAXY_SERVER', 'https://galaxy.ansible.com/api')
    assert C.GALAXY_SERVER == 'https://galaxy.ansible.com/api'
    setattr(C, 'GALAXY_SERVER', 'https://galaxy.ansible.com/api/v2')
    assert C.GALAXY_SERVER == 'https://galaxy.ansible.com/api/v2'
    setattr(C, 'GALAXY_SERVER', 'https://galaxy.ansible.com/api/v3')


# Generated at 2022-06-22 20:28:29.920513
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI(api_server='http://localhost', name='galaxy', ignore_certs=False, force_basic_auth=False,
        auth_user=None, auth_pass=None)
    other = GalaxyAPI(api_server='http://localhost', name='galaxy', ignore_certs=False, force_basic_auth=False,
        auth_user=None, auth_pass=None)
    assert not galaxy_api.__lt__(other)


# Generated at 2022-06-22 20:28:37.400173
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI()
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.name == 'galaxy.ansible.com'
    assert api.available_api_versions == {}
    assert api.token is None

    api = GalaxyAPI('https://galaxy2.ansible.com', 'testToken')
    assert api.api_server == 'https://galaxy2.ansible.com/'
    assert api.name == 'galaxy2.ansible.com'
    assert api.available_api_versions == {}
    assert api.token == 'testToken'

# Generated at 2022-06-22 20:28:43.244265
# Unit test for function cache_lock
def test_cache_lock():
    # this should pass consistently
    with _CACHE_LOCK:
        with _CACHE_LOCK:
            pass
    # these should not deadlock
    t1 = threading.Thread(target=lambda: with_cache_lock())
    t2 = threading.Thread(target=lambda: with_cache_lock())
    t1.start()
    t2.start()
    t1.join()
    t2.join()

# Generated at 2022-06-22 20:28:49.062668
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    x = GalaxyAPI(api_server='https://galaxy.ansible.com',
               name='test',
               token='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9')
    x._http = dict(req=dict(url='https://galaxy.ansible.com/api', method='post', body='name=test'))
    assert u"https://galaxy.ansible.com/api POST <hidden>  'name=test'" == x.__unicode__()


# Generated at 2022-06-22 20:28:52.225114
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    c = CollectionMetadata('namespace', 'collection')
    assert c.namespace == 'namespace', 'Expected namespace but got %s' % c.namespace
    assert c.name == 'collection', 'Expected collection but got %s' % c.name



# Generated at 2022-06-22 20:28:56.039003
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    import pytest
    with pytest.raises(AnsibleError):
        assert GalaxyAPI() < GalaxyAPI()


# Generated at 2022-06-22 20:29:01.139993
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Given
    api_server = "https://galaxy.ansible.com"
    name = "galaxy_server_name"
    api = GalaxyAPI(api_server, name)

    # When
    str_value = str(api)
    # Then
    assert str_value == "Galaxy%s-%s" % (name, api_server)



# Generated at 2022-06-22 20:29:12.693261
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_code = 500

    # Test v1
    http_error = HTTPError('https://api.galaxy.ansible.com', http_code, 'Ansible Galaxy API error', None, None)
    msg = 'Galaxy API response error'
    err = GalaxyError(http_error, msg)
    assert err.http_code == http_code
    assert err.url == 'https://api.galaxy.ansible.com'
    assert err.message == 'Galaxy API response error (HTTP Code: 500, Message: Ansible Galaxy API error)'

    # Test v2
    http_error = HTTPError('https://api.galaxy.ansible.com/v2', http_code, 'Ansible Galaxy API error', None, None)

# Generated at 2022-06-22 20:29:23.553024
# Unit test for function cache_lock
def test_cache_lock():
    with _CACHE_LOCK:
        with _CACHE_LOCK:
            pass
    with _CACHE_LOCK:
        pass
    # These two should raise and exception
    try:
        _CACHE_LOCK.acquire()
        with _CACHE_LOCK:
            pass
    except RuntimeError:
        pass
    else:
        raise AssertionError('RuntimeError not raised')
    finally:
        _CACHE_LOCK.release()
    # These two should raise and exception
    try:
        _CACHE_LOCK.acquire()
        _CACHE_LOCK.acquire()
    except RuntimeError:
        pass
    else:
        raise AssertionError('RuntimeError not raised')
    finally:
        _CACHE_LOCK.release()
        _CACHE_

# Generated at 2022-06-22 20:29:35.380470
# Unit test for function get_cache_id
def test_get_cache_id():
    ret=get_cache_id('https://server.test.com:8443/api/')
    assert(ret=='server.test.com:8443')
    ret=get_cache_id('https://server.test.com:8443/api')
    assert(ret=='server.test.com:8443')
    ret=get_cache_id('https://server.test.com/api')
    assert(ret=='server.test.com')
    ret=get_cache_id('https://server.test.com')
    assert(ret=='server.test.com')
    ret=get_cache_id('https://server.test.com:8443')
    assert(ret=='server.test.com:8443')

# Generated at 2022-06-22 20:29:39.495124
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Verify that we can construct a GalaxyAPI instance.
    #
    player = GalaxyAPI('http://example.com/v1', 'Ansible', 'test@user')
    assert player is not None, "Failed to create GalaxyAPI instance"

# Generated at 2022-06-22 20:29:43.443221
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():

    test_collection_metadata = CollectionMetadata('namespace', 'name', 'created_at', 'modified_at', 'namespace_url')
    assert test_collection_metadata.namespace == 'namespace'
    assert test_collection_metadata.name == 'name'
    assert test_collection_metadata.created_str == 'created_at'
    assert test_collection_metadata.modified_str == 'modified_at'
    assert test_collection_metadata.namespace_url == 'namespace_url'


# Generated at 2022-06-22 20:29:48.678773
# Unit test for function g_connect
def test_g_connect():
    def _nested(versions):
        def decorator(method):
            pass
        return decorator

    _nested.__name__ = '_nested'  # For unit test coverage

    g_connect(list(range(11, 20)))



# Generated at 2022-06-22 20:30:00.376509
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI(
        galaxy='SOME_URL',
        ignore_certs=True,
        validate_certs=False,
        token='SOME_TOKEN',
        name='SOME_NAME',
        allow_duplicates=False,
        client='foo',
        api_server='galaxy.server.com',
    )

    assert api.name == 'SOME_NAME'
    assert api.client == 'foo'
    assert api.api_server == 'galaxy.server.com'
    assert api.galaxy == 'SOME_URL'
    assert api.ignore_certs
    assert not api.validate_certs
    assert api.token == 'SOME_TOKEN'
    assert not api.allow_duplicates
    assert api.cache_path is None
    assert api.cache

# Generated at 2022-06-22 20:30:07.807156
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Setup GalaxyAPI class
    gal_api = GalaxyAPI(api_server="http://myansibleserver.com", token=None, ignore_certs=False, force_basic_auth=False,
                        client_cert=None, follow_redirects='safe', ignore_errors=False, timeout=30,
                        validate_certs=True, user_agent=None, name=None, http_agent=None)

    # Get expected result
    expected_result = "GalaxyAPI(http://myansibleserver.com)"

    # Call GalaxyAPI class method __repr__ and compare with expected result
    assert gal_api.__repr__() == expected_result


# Generated at 2022-06-22 20:30:15.487885
# Unit test for function cache_lock
def test_cache_lock():
    global count
    count = 0

    # simple function to test thread locking
    def incr_count():
        global count
        time.sleep(1)
        count += 1

    # run in parallel 20 times and race to increment count
    threads = []
    for i in range(0, 20):
        t = threading.Thread(target=incr_count)
        t.daemon = True
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print(count)

    # exit with None on success
    return None



# Generated at 2022-06-22 20:30:19.203233
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxyAPI = GalaxyAPI()
    assert galaxyAPI.__lt__("foo") is NotImplemented


# Generated at 2022-06-22 20:30:29.968703
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Test a single GalaxyAPI
    galaxy_api1 = GalaxyAPI(name='test1',
                            url='https://galaxy.ansible.com',
                            token='',
                            ignore_certs=False,
                            ignore_cache=True)
    galaxy_api2 = GalaxyAPI(name='test2',
                            url='https://galaxy.ansible.com',
                            token='',
                            ignore_certs=False,
                            ignore_cache=True)
    g1 = galaxy_api1 < galaxy_api2
    assert g1 == True
    # Test a list of GalaxyAPI

# Generated at 2022-06-22 20:30:38.043687
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("https://galaxy.ansible.com") == 'galaxy.ansible.com'
    assert get_cache_id("https://galaxy.ansible.com:443") == 'galaxy.ansible.com:443'
    assert get_cache_id("https://cache.ansible.com") == 'cache.ansible.com'
    assert get_cache_id("https://cache.ansible.com/") == 'cache.ansible.com'
    assert get_cache_id("https://cache.ansible.com/api/") == 'cache.ansible.com'
    assert get_cache_id("https://cache.ansible.com:8080/") == 'cache.ansible.com:8080'

# Generated at 2022-06-22 20:30:43.379021
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    metadata = CollectionMetadata(namespace='test_namespace', name='test_name', created_str='2019-01-01')
    assert metadata.namespace == 'test_namespace'
    assert metadata.name == 'test_name'
    assert metadata.created_str == '2019-01-01'


# Generated at 2022-06-22 20:30:51.758814
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    # The counters below are meant to be thread-local but we are testing the locking of cache_lock()
    global _instances_used
    _instances_used = collections.Counter()

    @cache_lock
    def increment_instances():
        _instances_used['counter'] += 1
        time.sleep(1)
        return _instances_used['counter']

    threads = []
    for i in range(1, 11):
        threads.append(threading.Thread(target=increment_instances))
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert _instances_used['counter'] == 10, "cache_lock() did not lock"


# Generated at 2022-06-22 20:31:02.415199
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    ver = CollectionVersionMetadata(namespace='testing', name='testing', version='1.0.0', download_url='www.example.com', artifact_sha256='123456789', dependencies={'foo':{'name':'bar', 'version':'1.0.0'}})
    assert ver.namespace == 'testing'
    assert ver.name == 'testing'
    assert ver.version == '1.0.0'
    assert ver.download_url == 'www.example.com'
    assert ver.artifact_sha256 == '123456789'
    assert ver.dependencies == {'foo':{'name':'bar', 'version':'1.0.0'}}


# Generated at 2022-06-22 20:31:04.749181
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    g_api = GalaxyAPI('a', 'b', 'c', True)
    assert g_api.__lt__('b') == True


# Generated at 2022-06-22 20:31:09.360189
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI('test', 'https://galaxy.server/api/v2')
    assert repr(api) == "GalaxyAPI('test', 'https://galaxy.server/api/v2')"


# Generated at 2022-06-22 20:31:14.366064
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    """Unit test for GalaxyAPI.__str__"""
    api = GalaxyAPI(name='test', api_server='test_api_server', ignore_certs=True)
    assert str(api) == 'test_api_server'
    assert repr(api) == 'test_api_server'



# Generated at 2022-06-22 20:31:25.013767
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Testing method __str__(self) of class GalaxyAPI
    # Setup fixture
    #   args, galaxy_server_url, galaxy_ignore_certs, galaxy_ignore_certs,
    #   galaxy_ignore_certs, galaxy_client, galaxy_api_key, galaxy_api_server, galaxy_timeout,
    #   galaxy_requests_cache_path, galaxy_requests_cache_max_age, available_api_versions,
    #   cached_api_versions, cache, api_server, name, url, client, ignore_certs, timeout,
    #   cached_data, use_cache, cache_path, cache_max_age, transport, token_callback, default_retries,
    #   retry_delay, retry_on_status
    galaxy_timeout = None
    galaxy_requests_cache_

# Generated at 2022-06-22 20:31:29.552422
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(429))
    assert not is_rate_limit_exception(GalaxyError(403))
    assert not is_rate_limit_exception(GalaxyError(404))
    assert not is_rate_limit_exception(Exception())



# Generated at 2022-06-22 20:31:37.524645
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # noinspection PyUnusedLocal
    def maybe_error(exception):
        return exception

    g = GalaxyError(('msg',), http_code=429)
    assert is_rate_limit_exception(maybe_error(g))
    assert not is_rate_limit_exception(maybe_error(None))
    assert not is_rate_limit_exception(maybe_error(123))



# Generated at 2022-06-22 20:31:44.732173
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI("https://galaxy.server", "myuser", "mypass", token="mytoken", skip_cert_check=True)
    ans_str = "Galaxy API at 'https://galaxy.server' for user 'myuser'"
    assert ans_str == galaxy_api.__repr__()


# Generated at 2022-06-22 20:31:54.958420
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Dummy class for HTTPError
    class DummyHTTPError(object):
        def __init__(self):
            self.code = 500
            self.url = "https://galaxy.ansible.com/api/"
            self.reason = "Internal server error"

        def read(self):
            return ""

        def geturl(self):
            return self.url

    try:
        raise GalaxyError(DummyHTTPError(), "error message")

    except GalaxyError as e:
        assert e.message == u"error message (HTTP Code: 500, Message: Internal server error)"

    try:
        raise GalaxyError(DummyHTTPError(), "error message")

    except GalaxyError as e:
        assert e.message == u"error message (HTTP Code: 500, Message: Internal server error)"

    # Dummy class for HTTPError


# Generated at 2022-06-22 20:31:58.801973
# Unit test for function cache_lock
def test_cache_lock():
    failure = False
    with _CACHE_LOCK:
        try:
            test_cache_lock()
        except RuntimeError:
            failure = True
    assert failure



# Generated at 2022-06-22 20:32:03.253795
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI('namespace_name', 'name', 'url', 'token', False)
    assert repr(galaxy_api) == "GalaxyAPI(namespace='namespace_name', name='name', api_server='url', token='token', ignore_certs=False)"


# Generated at 2022-06-22 20:32:07.945042
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_metadata = CollectionMetadata('namespace', 'collection', created_str='created', modified_str='modified')
    assert collection_metadata.namespace == 'namespace'
    assert collection_metadata.name == 'collection'
    assert collection_metadata.created_str == 'created'
    assert collection_metadata.modified_str == 'modified'


# Generated at 2022-06-22 20:32:16.710248
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    #test init
    test_metadata = CollectionVersionMetadata('namespace', 'name', 'version', 'download_url',
                                              'artifact_sha256', 'dependencies')
    #test get value from class
    assert test_metadata.namespace == 'namespace'
    assert test_metadata.name == 'name'
    assert test_metadata.version == 'version'
    assert test_metadata.download_url == 'download_url'
    assert test_metadata.artifact_sha256 == 'artifact_sha256'
    assert test_metadata.dependencies == 'dependencies'



# Generated at 2022-06-22 20:32:22.750206
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    obj = GalaxyAPI('myModuleGalaxyServer', 'myUser', 'myPass')
    obj2 = GalaxyAPI('myModuleGalaxyServer', 'myUser', 'myPass')
    assert not obj.__lt__(obj2)
    assert not obj2.__lt__(obj)

    assert obj.__lt__(None)
    assert not None.__lt__(obj)

    assert obj.__lt__(42)

# Generated at 2022-06-22 20:32:30.360576
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Tests the __str__ method of GalaxyAPI
    #
    # Args:
    #     c(GalaxyApi): The GalaxyApi to test
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    c = GalaxyApi(name="ansible_galaxy_api")
    assert str(c) == '%s' % "GalaxyAPI(name=ansible_galaxy_api)"



# Generated at 2022-06-22 20:32:35.234092
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://localhost:8080') == 'localhost:8080'
    assert get_cache_id('http://user:pass@localhost:8080') == 'localhost:8080'
    assert get_cache_id('http://github.com') == 'github.com'
    assert get_cache_id('http://github.com:8080') == 'github.com:8080'



# Generated at 2022-06-22 20:32:41.803458
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    x_GalaxyAPI = GalaxyAPI(
        api_server='my_api_server',
        name='my_name',
        token='my_token'
    )
    x_str = str(x_GalaxyAPI)
    assert x_str == "GalaxyAPI(name='my_name', api_server='my_api_server')"

# Generated at 2022-06-22 20:32:50.052766
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    msg = "test error message"
    code = 404
    reason = "test reason"
    galaxy_msg = "test galaxy_msg"
    error = HTTPError(url="test.com", code=code, reason=reason,
                      headers={"content-type": 'application/json'},
                      fp=open("tests/unit/galaxy_error.json"))
    error.read = lambda: '{"default": "%s"}' % galaxy_msg

    try:
        raise GalaxyError(error, msg)
    except GalaxyError as e:
        assert str(e) == "%s (HTTP Code: %d, Message: %s)" % (msg, code, galaxy_msg)
    finally:
        error.fp.close()



# Generated at 2022-06-22 20:32:53.843429
# Unit test for function g_connect
def test_g_connect():
    conn = GalaxyConnection()
    @g_connect(['v1', 'v2'])
    def method(conn):
        return 'ok'
    assert(method(conn) == 'ok')


# Generated at 2022-06-22 20:32:59.382193
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    g_api = GalaxyAPI(name='test_GalaxyAPI__unicode__', api_server='http://test_GalaxyAPI__unicode__.com',
                      force_api_version=None, token='test_token')
    assert unicode(g_api) == "http://test_GalaxyAPI__unicode__.com (test_GalaxyAPI__unicode__)"



# Generated at 2022-06-22 20:33:00.287978
# Unit test for function get_cache_id
def test_get_cache_id():
    # TODO: Implement
    pass



# Generated at 2022-06-22 20:33:05.716607
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    g_error = GalaxyError(HTTPError(url='http://test/url', code=200, msg='test', hdrs='test', fp='test'), 'test')
    assert g_error.http_code == 200
    assert g_error.url == 'http://test/url'
    assert g_error.message == u"test (HTTP Code: 200, Message: test)"
    #TODO: add assert for GalaxyError.message in
    #  AnsibleError.__unicode__



# Generated at 2022-06-22 20:33:17.509652
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # test v1 & v2 errors
    message = "This is a test!"
    http_code = 123
    err_msg = "Galaxy error message"
    err_code = "GalaxyErrorCode"

    # v1 test
    http_error = HTTPError(url="http://somewhere.com/v1?", code=http_code, msg="HTTP message", hdrs="Headers")
    http_error.read = lambda: json.dumps({"default": err_msg})
    error = GalaxyError(http_error, message)
    assert error.message == "%s (HTTP Code: %d, Message: %s)" % (message, http_code, err_msg)
    assert error.http_code == http_code
    assert error.url == http_error.geturl()

    # v2 test
    err

# Generated at 2022-06-22 20:33:26.691306
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    assert GalaxyError(message='Test Message', http_code=401, url='https://galaxy.ansible.com/v1/').message == 'Test Message (HTTP Code: 401, Message: Unauthorized)'
    assert GalaxyError(message='Test Message', http_code=401, url='https://galaxy.ansible.com/v2/').message == 'Test Message (HTTP Code: 401, Message: Unauthorized Code: Unknown)'
    assert 'token_missing' in GalaxyError(message='Test Message', http_code=403, url='https://galaxy.ansible.com/v2/').message
    assert GalaxyError(message='Test Message', http_code=403, url='https://galaxy.ansible.com/v3/').message == 'Test Message (HTTP Code: 403, Message: Forbidden Code: Unknown)'

# Generated at 2022-06-22 20:33:34.976375
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    c = CollectionVersionMetadata("namespace", "name", "0.0.1", "url", "SHA256", "dependencies")
    assert c.namespace == "namespace"
    assert c.name == "name"
    assert c.version == "0.0.1"
    assert c.download_url == "url"
    assert c.artifact_sha256 == "SHA256"
    assert c.dependencies == "dependencies"


# Generated at 2022-06-22 20:33:37.467859
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI(1, 2, 3, 4)
    assert galaxy_api.__lt__(1) == False

# Generated at 2022-06-22 20:33:39.365420
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxyapi = GalaxyAPI()
    assert str(galaxyapi) == "GalaxyAPI()"



# Generated at 2022-06-22 20:33:43.847395
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    meta = CollectionMetadata('c1', 'd1')
    assert meta.namespace == 'c1'
    assert meta.name == 'd1'
    assert meta.created_str is None
    assert meta.modified_str is None


# Generated at 2022-06-22 20:33:54.269479
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://example.com') == 'example.com'
    assert get_cache_id('https://example.com') == 'example.com'
    assert get_cache_id('http://example.com:8080') == 'example.com:8080'
    assert get_cache_id('http://example.com:8080/path/') == 'example.com:8080'
    assert get_cache_id('http://user:pass@example.com:8080/path/') == 'example.com:8080'
    assert get_cache_id('http://user:pass@example.com:8080/?auth=token:abc') == 'example.com:8080'

# Generated at 2022-06-22 20:33:58.186372
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI('https://galaxy.server.com', 'foo', 'bar')
    assert repr(galaxy_api) == 'GalaxyAPI(name=None, api_server=https://galaxy.server.com, ignore_certs=False, token=your token)'



# Generated at 2022-06-22 20:34:04.953328
# Unit test for function get_cache_id
def test_get_cache_id():
    url = 'https://test.galaxy.com/api/'
    url1 = 'https://test.galaxy.com:123/api/'
    url2 = 'https://test.galaxy.com:123/api/v2/roles/'
    url3 = 'https://test.galaxy.com:123/api/v2/roles/?page_size=100&page=1'
    assert get_cache_id(url) == 'test.galaxy.com:'
    assert get_cache_id(url1) == 'test.galaxy.com:123'
    assert get_cache_id(url2) == 'test.galaxy.com:123'
    assert get_cache_id(url3) == 'test.galaxy.com:123'



# Generated at 2022-06-22 20:34:15.110392
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    with pytest.raises(AnsibleError):    
        with patch('ansible_galaxy.models.ansible_galaxy_api.GalaxyAPI.get_api_versions') as get_api_versions, \
             patch('ansible_galaxy.models.ansible_galaxy_api.GalaxyAPI.get_api_token') as get_api_token, \
             patch('ansible_galaxy.models.ansible_galaxy_api.GalaxyAPI.get_api_server') as get_api_server:
            gA = GalaxyAPI()
            galaxy_api_server = "https://galaxy.ansible.com"
            galaxy_api_token = "f7a96aecec8bd161a25e69c1d7b5833bcae1a7a9"
            galaxy_api_

# Generated at 2022-06-22 20:34:20.197298
# Unit test for function cache_lock
def test_cache_lock():
    # 1. Test example
    test_func = cache_lock(lambda x: 1)
    assert test_func(0) == 1
    with open('ansible/galaxy/api.py', 'r') as f:
        assert 'cache_lock(func):' in f.read().split('\n')



# Generated at 2022-06-22 20:34:25.710891
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api_server = to_unicode('http://api.galaxy.ansible.com/')
    g = GalaxyAPI(api_server=api_server)
    assert isinstance(g, GalaxyAPI)

    assert to_text(g) == 'GalaxyAPI at http://api.galaxy.ansible.com/'
    assert u'display_name' in to_text(g)


# Generated at 2022-06-22 20:34:26.627092
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    pass

# Generated at 2022-06-22 20:34:32.466100
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Setup test
    galaxy_url = 'https://galaxy.ansible.com/api'
    token = 'dummy_token'
    instance = GalaxyAPI(galaxy_url, token)

    # Execute code to be tested
    retval = instance.__repr__()

    # Verify expectations
    assert 'GalaxyAPI(' in retval
    assert '/api' in retval
    # Cleanup after test
    del retval
    tear_down_galaxy(instance)



# Generated at 2022-06-22 20:34:37.879121
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    collection = CollectionVersionMetadata(namespace="mynamespace", name="myname", version="1.0.1",
                                download_url="http://url1", artifact_sha256="sha256",
                                dependencies={"namespace2.name2": "1.0.0"})
    assert collection.namespace == "mynamespace"
    assert collection.name == "myname"
    assert collection.version == "1.0.1"
    assert collection.download_url == "http://url1"
    assert collection.artifact_sha256 == "sha256"
    assert collection.dependencies == {"namespace2.name2": "1.0.0"}


# Generated at 2022-06-22 20:34:41.075428
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    cm = CollectionMetadata("some_author", "some_collection")
    assert cm.author == "some_author"
    assert cm.name == "some_collection"


# Generated at 2022-06-22 20:34:43.191832
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
  galaxy_api = GalaxyAPI()
  assert galaxy_api.__lt__(galaxy_api)


# Generated at 2022-06-22 20:34:48.367690
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exception = GalaxyError('Rate limit exceeded', http_code=429)
    assert is_rate_limit_exception(exception) is True
    exception = GalaxyError('Rate limit exceeded', http_code=520)
    assert is_rate_limit_exception(exception) is True
    exception = GalaxyError('Rate limit exceeded', http_code=403)
    assert is_rate_limit_exception(exception) is False



# Generated at 2022-06-22 20:34:56.523454
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    from ansible.module_utils.six import StringIO
    out = StringIO()
    galaxy = GalaxyAPI(u'test-api-server', u'test-server', u'test-token', u'test-email', out)
    result = repr(galaxy)
    assert result == u"GalaxyAPI(u'test-api-server', u'test-server', u'test-token', u'test-email', <StringIO.StringIO instance at 0x0000000005C5E5C8>, False, False, None)"



# Generated at 2022-06-22 20:35:05.713771
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    return CollectionVersionMetadata(namespace='cnos', name='cnos-6.2.5.5', version={'version': '6.2.5.5'}, download_url='https://galaxy.ansible.com/api/v1/collections/cnos/cnos/6.2.5.5/download/', artifact_sha256='d9f8c9e974b3fdbb78aef04939b2a2f73a27c1ab0491d081d11c9b3e3b0a3d00', dependencies=[{'namespace': 'chouseknecht', 'name': 'avd', 'versions': {'min': '1.0.0', 'max': '2.0.0'}}])



# Generated at 2022-06-22 20:35:12.574423
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://localhost/') == 'localhost:None'
    assert get_cache_id('http://localhost:8080/') == 'localhost:8080'
    assert get_cache_id('http://user:pass@localhost/') == 'localhost:None'
    assert get_cache_id('http://user:pass@localhost:8080/') == 'localhost:8080'


# Generated at 2022-06-22 20:35:16.498941
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI('galaxy_server', 'name', auth_token='token')
    assert str(api) == "GalaxyAPI('name', 'galaxy_server')"

# Generated at 2022-06-22 20:35:19.241811
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    with patch.object(GalaxyAPI, 'get_galaxy_url'):
        assert repr(GalaxyAPI())



# Generated at 2022-06-22 20:35:25.573646
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI('test', None)
    # Test with 'test' for name, and None for api_server
    exc = None
    try:
        api.__unicode__()
    except Exception as err:
        exc = err
    assert isinstance(exc, AnsibleExitJson)
    assert not exc

