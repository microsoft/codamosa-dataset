

# Generated at 2022-06-22 20:25:31.644916
# Unit test for function get_cache_id
def test_get_cache_id():
    # URL with no port and scheme
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com'

    # URL with port and scheme
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'

    # URL with no scheme
    assert get_cache_id('galaxy.ansible.com') == 'galaxy.ansible.com'

    # TODO: Add test for scheme, but we'd need to mock urlparse for that.



# Generated at 2022-06-22 20:25:38.551237
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI(
        "https://galaxy.example.com",
        {
            "v2": "api/v2",
            "v3": "api/v3",
        },
        "user",
        "password",
    )
    assert galaxy_api.name == "galaxy.example.com"
    assert galaxy_api.api_server == "https://galaxy.example.com"
    assert galaxy_api.api_token == "user:password"
    assert galaxy_api.available_api_versions == {"v2": "api/v2", "v3": "api/v3"}
    assert galaxy_api.headers == {"Content-type": "application/json"}
    assert galaxy_api.timeout == 10

# Generated at 2022-06-22 20:25:41.084013
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    data = {'namespace': 'test', 'name': 'test_collection'}
    c = CollectionMetadata(**data)
    assert c.namespace == 'test'
    assert c.name == 'test_collection'


# Generated at 2022-06-22 20:25:45.087699
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'



# Generated at 2022-06-22 20:25:49.063258
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    er0 = GalaxyError(http_code=429, message="foo")
    er1 = GalaxyError(http_code=420, message="foo")
    assert is_rate_limit_exception(er0)
    assert not is_rate_limit_exception(er1)



# Generated at 2022-06-22 20:25:59.022137
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Suppress output of the following code
    display.verbosity = 0

    # HTTPError object with status code 200
    http_error = HTTPError(200, 'OK', {}, None)

    # Assert that GalaxyError is raised
    error_message = 'HTTP Code 200'
    try:
        raise GalaxyError(http_error, error_message)
    except GalaxyError as err:
        pass

    # Check that the http code and message is correct
    expected = 'HTTP Code: 200, Message: OK'
    assert err.message == expected, "GalaxyError has incorrect error message"

    # Check that the http code, message, and code are correct
    # HTTPError object with status code 520
    http_error = HTTPError(520, 'Unknown Error', {}, None)
    # Add JSON error code and message to returned object

# Generated at 2022-06-22 20:26:02.396884
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'namespace'
    name = 'name'
    created_str = None
    modified_str = None
    metadata = CollectionMetadata(namespace, name, created_str, modified_str)
    assert metadata.created_str == created_str
    assert metadata.modified_str == modified_str



# Generated at 2022-06-22 20:26:08.803487
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    c = CollectionMetadata('namespace1', 'foo1')

    assert c.name == 'foo1'
    assert c.namespace == 'namespace1'
    assert c.created_str is None
    assert c.modified_str is None


# Generated at 2022-06-22 20:26:18.614579
# Unit test for function get_cache_id
def test_get_cache_id():
    """ Tests for function get_cache_id """
    class TestData:
        """ Collection for test data for function get_cache_id """
        def __init__(self, input, expected, version=None):
            self.input = input
            self.expected = expected
            self.version = version


# Generated at 2022-06-22 20:26:20.734226
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    CollectionMetadata('namespace_test', 'name_test', '1', 'created_str_test', 'modified_str_test', '1234')


# Generated at 2022-06-22 20:26:31.888405
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id(u'http://server1.example.com') == 'server1.example.com:'
    assert get_cache_id(u'http://server1.example.com:') == 'server1.example.com:'
    assert get_cache_id(u'http://server1.example.com:80') == 'server1.example.com:80'
    assert get_cache_id(u'http://server1.example.com:80/path') == 'server1.example.com:80'
    assert get_cache_id(u'http://server1.example.com:80/path:443') == 'server1.example.com:80'
    assert get_cache_id(u'http://server1.example.com:') == 'server1.example.com:'
    assert get_cache

# Generated at 2022-06-22 20:26:34.410323
# Unit test for function g_connect
def test_g_connect():
    class gc:
        def __init__(self, api_server):
            self.api_server = api_server
            self._available_api_versions = {}
            self.galaxy_token = None
            self.name = ''
            self.verify_ssl = False

        @g_connect(versions=['v1'])
        def test(self):
            return

    gc('https://galaxy.ansible.com')


# Generated at 2022-06-22 20:26:38.039232
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    name = 'name'
    api_server = 'api.server'

    galaxy_api = GalaxyAPI(name=name, api_server=api_server)
    assert len(galaxy_api.__repr__()), 10 > 0



# Generated at 2022-06-22 20:26:43.158192
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    msg = u"Test message"
    err = HTTPError(None, 500, msg, {}, None)
    error = GalaxyError(err, msg)
    assert error.http_code == 500
    assert error.message == to_native(u"Test message (HTTP Code: 500, Message: %s)" % msg)



# Generated at 2022-06-22 20:26:46.001849
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    assert GalaxyAPI('https://galaxy.ansible.com', 'user', 'pass')

# Generated at 2022-06-22 20:26:55.486229
# Unit test for function g_connect
def test_g_connect():
    class DummyGalaxy:
        """
        Dummy Galaxy object for unit testing this function
        """
        def __init__(self, name=None, api_server=None, available_api_versions=None):
            self.name = name
            self.api_server = api_server
            # The following should be a list of API versions
            self._available_api_versions = {} if available_api_versions is None else available_api_versions
            self._cache = {}

        def _call_galaxy(self, url, method='GET', error_context_msg=None, auth=None, raw_body=True,
                         cache=False, **kwargs):
            if cache:
                return self._cache[url]
            else:
                return {}

    # This should work

# Generated at 2022-06-22 20:27:03.161222
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    g1 = GalaxyAPI(galaxy_instance_name='test', galaxy_instance_server='test')
    g2 = GalaxyAPI(galaxy_instance_name='test', galaxy_instance_server='test')
    g3 = GalaxyAPI(galaxy_instance_name='test2', galaxy_instance_server='test')
    g4 = GalaxyAPI(galaxy_instance_name='test', galaxy_instance_server='test2')

    assert g1 < g2
    assert g1 < g3
    assert g1 < g4



# Generated at 2022-06-22 20:27:11.222488
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    '''
    Test the constructor of the class CollectionMetadata

    :return:
    '''
    metadata = CollectionMetadata('namespace', 'name')
    assert metadata.namespace == 'namespace'
    assert metadata.name == 'name'
    assert metadata.created_str is None
    assert metadata.modified_str is None

    metadata = CollectionMetadata('namespace', 'name', created_str='created', modified_str='modified')
    assert metadata.namespace == 'namespace'
    assert metadata.name == 'name'
    assert metadata.created_str == 'created'
    assert metadata.modified_str == 'modified'


# Generated at 2022-06-22 20:27:16.888759
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error_type = type(GalaxyError.__name__, (object,), {})
    galaxy_error = GalaxyError(error_type, 'Error occurred')
    assert galaxy_error.http_code is None
    assert galaxy_error.url is None
    assert galaxy_error.message == 'Error occurred (HTTP Code: None, Message: Error occurred)'



# Generated at 2022-06-22 20:27:25.110185
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    """
    test_GalaxyAPI___str__
    """
    # setup

# Generated at 2022-06-22 20:27:28.091137
# Unit test for function cache_lock
def test_cache_lock():
    def test_decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper

    a = test_decorator(lambda x: x)
    b = cache_lock(lambda x: x)
    assert a.__wrapped__.func_name == 'test_decorator'
    assert b.__wrapped__.func_name == 'wrapped'



# Generated at 2022-06-22 20:27:30.857256
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI(name='TEST', api_server='http://127.0.0.1:8888')
    display.vvv(galaxy_api)


# Generated at 2022-06-22 20:27:32.220386
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    g = GalaxyAPI()
    assert not g < g

# Generated at 2022-06-22 20:27:34.896669
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    ga = GalaxyAPI('')
    assert ga.__str__() in ("<GalaxyAPI('')>", "<GalaxyAPI('http://localhost')>")

# Generated at 2022-06-22 20:27:46.446122
# Unit test for function g_connect
def test_g_connect():
    def decorated_method(self, *args, **kwargs):
        return self

    decorated_method = g_connect([u'v1', u'v2'])(decorated_method)

    class FakeGalaxyAPI(object):
        def __init__(self, name, server, api_server, token, ignore_certs):
            self.name = name
            self.api_server = api_server
            self._available_api_versions = {}
            self._call_galaxy = _call_galaxy_retry
            self.token = token
            self.ignore_certs = ignore_certs

    server, route = "https://galaxy.ansible.com", "/api/"

    # Should allow either the server or api_server to be specified with /api/

# Generated at 2022-06-22 20:27:57.695688
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    assert CollectionMetadata('namespace', 'name')
    assert CollectionMetadata('namespace', 'name', 'version')
    assert CollectionMetadata('namespace', 'name', 'version', 'download_url')
    assert CollectionMetadata('namespace', 'name', 'version', 'download_url', 'sha256')
    assert CollectionMetadata('namespace', 'name', 'version', 'download_url', 'sha256', 'dependencies')
    assert CollectionMetadata('namespace', 'name', 'version', 'download_url', 'sha256', 'dependencies', 'created_str')
    assert CollectionMetadata('namespace', 'name', 'version', 'download_url', 'sha256', 'dependencies', 'created_str', 'modified_str')


# Generated at 2022-06-22 20:28:07.294402
# Unit test for function g_connect
def test_g_connect():
    class Test:
        def __init__(self, name, api_server, api_key=None, ignore_certs=False):
            # self.name = name
            self.name = 'test'
            self.api_server = api_server
            self.api_key = api_key
            self.ignore_certs = ignore_certs
            self._available_api_versions = None
            self._retries = 0
            self._session = None
            self._cache = {}

        @g_connect(['v2'])
        def delete(self, owner, collection_name):
            pass

# Generated at 2022-06-22 20:28:17.916773
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    g1 = GalaxyAPI(name="galaxy1", api_server="api1.com")
    g2 = GalaxyAPI(name="galaxy2", api_server="api2.com")
    g3 = GalaxyAPI(name="galaxy3", api_server="api3.com")
    g3_2 = GalaxyAPI(name="galaxy3", api_server="api3.com")
    g3_3 = GalaxyAPI(name="galaxy3", api_server="api3.com")
    g_d = GalaxyAPI(name="galaxy_default", api_server="api_default.com")

    assert g1 < g_d
    assert g_d < g2
    assert g2 < g3
    assert g3 == g3_2 == g3_3

# Generated at 2022-06-22 20:28:20.627546
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def _test_cache_lock():
        return 'hello'
    assert _test_cache_lock() == 'hello'



# Generated at 2022-06-22 20:28:28.121504
# Unit test for function g_connect
def test_g_connect():
    # create the function with the version requirements
    @g_connect(versions=['v2'])
    def func(self):
        return self.api_server
    # create a mock connection info with bad api_server
    con = GalaxyServer({'name':'test_galaxy', 'api_server':'not_a_galaxy_server'})
    # check that the decorator returns the correct error
    try:
        func(con)
        assert False, 'Should have gotten error'
    except AnsibleError as e:
        assert to_text(e).find('Galaxy action func') >= 0
        assert to_text(e).find('requires API versions \'v2\' but only') >= 0

    # create a mock connection info with api_server that only supports v1

# Generated at 2022-06-22 20:28:30.992912
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def func():
        """
        This is the doc string of func
        """
        pass

    assert func.__doc__ == 'This is the doc string of func'



# Generated at 2022-06-22 20:28:38.319564
# Unit test for function cache_lock
def test_cache_lock():
    called = False
    @cache_lock
    def test_func():
        nonlocal called
        called = True
        return 42

    num = test_func()
    assert called
    assert num == 42

# Unit testing function cache_lock using a Counter (https://docs.python.org/3/library/collections.html#collections.Counter)
# with a defaultdict (https://docs.python.org/3/library/collections.html#collections.defaultdict)
# and a Lock (https://docs.python.org/3/library/threading.html#threading.Lock)

# Generated at 2022-06-22 20:28:47.574607
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://not-real-galaxy.example.com') == 'not-real-galaxy.example.com:443'
    assert get_cache_id('https://not-real-galaxy.example.com:8080') == 'not-real-galaxy.example.com:8080'
    assert get_cache_id('https://user@not-real-galaxy.example.com:8080') == 'not-real-galaxy.example.com:8080'
    assert get_cache_id('https://user:password@not-real-galaxy.example.com') == 'not-real-galaxy.example.com:443'
    assert get_cache_id('ssh://not-real-galaxy.example.com') == 'not-real-galaxy.example.com:22'



# Generated at 2022-06-22 20:28:49.654140
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI()
    assert api.__repr__() == '<GalaxyAPI(name=None)>'



# Generated at 2022-06-22 20:28:57.264157
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI()
    assert galaxy_api.server is None
    assert galaxy_api.api_server is None
    assert galaxy_api.validate_certs is True
    assert galaxy_api.http_timeout is None
    assert galaxy_api.force_api_version is None
    assert galaxy_api.available_api_versions == {}
    assert galaxy_api.timeout is None

    galaxy_api = GalaxyAPI(galaxy_server="https://galaxy.ansible.com",
                           galaxy_token="token",
                           validate_certs=False,
                           http_timeout=10,
                           force_api_version=2,
                           proxy_url='http://localhost')
    assert galaxy_api.server == 'https://galaxy.ansible.com'

# Generated at 2022-06-22 20:29:00.288894
# Unit test for function cache_lock
def test_cache_lock():
    lock = threading.Lock()
    lock.acquire()
    with _CACHE_LOCK:
        lock.release()
    assert lock.acquire(False) is True
    lock.release()



# Generated at 2022-06-22 20:29:12.220770
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    mock_api_server = 'https://galaxy.ansible.com'
    mock_api_token = '1234567890'
    mock_ignore_certs = False
    mock_validate_certs = True
    mock_client_cert = "/path/to/crt.pem"
    mock_client_key = "/path/to/key.pem"
    mock_timeout = 30
    mock_name = 'GalaxyAPI'

    actual_output = GalaxyAPI(mock_api_server, mock_api_token, mock_ignore_certs, mock_validate_certs, mock_client_cert, mock_client_key, mock_timeout, mock_name)

    expected_output = u'GalaxyAPI: https://galaxy.ansible.com'
    assert actual_output.__unicode__()

# Generated at 2022-06-22 20:29:15.223734
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def do_stuff(arg):
        return arg

    do_stuff(1)


# Generated at 2022-06-22 20:29:24.568478
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    """Test that the __unicode__ method returns the expected string representation of the GalaxyAPI class."""
    # Define test variables
    _name = "g.example.com"
    _api_token = "Token 123456789"
    _ignore_certs = True

    # Execute the test code
    api = GalaxyAPI(name=_name,
                    api_server="https://%s" % _name,
                    ignore_certs=_ignore_certs)
    api.api_token = _api_token
    result = unicode(api)

    # Verify the results
    assert result == "<GalaxyAPI(%s)>" % _name, "Expected result: <GalaxyAPI(%s)>, Actual result: %s" % (_name, result)

# Generated at 2022-06-22 20:29:29.111166
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    cm = CollectionMetadata('namespace', 'name', 'created', 'modified')
    assert cm.namespace == 'namespace'
    assert cm.name == 'name'
    assert cm.created_str == 'created'
    assert cm.modified_str == 'modified'
    assert cm.created == datetime.strptime('created', '%Y-%m-%dT%H:%M:%S.%fZ')
    assert cm.modified == datetime.strptime('modified', '%Y-%m-%dT%H:%M:%S.%fZ')

# Generated at 2022-06-22 20:29:36.525497
# Unit test for function g_connect
def test_g_connect():
    class fakeGalaxy:
        def __init__(self,api_server):
            self.api_server=api_server
            self._available_api_versions=[]

        def _call_galaxy(self,n_url,method,error_context_msg,cache):
            return {'available_versions': {u'v1': u'v1/'}}

    class fakeGalaxy2:
        def __init__(self, api_server):
            self.api_server = api_server
            self._available_api_versions = []

        def _call_galaxy(self, n_url, method, error_context_msg, cache):
            raise AnsibleError('AnsibleError')
    api_server='https://galaxy.ansible.com'
    galaxy=fakeGalaxy(api_server)

# Generated at 2022-06-22 20:29:44.658121
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    the_error = GalaxyError(HTTPError('https://galaxy.ansible.com/api/invalid_api/', 500, 'Internal Server Error', {}, None), 'Unable to import collection')
    assert the_error.message == 'Unable to import collection (HTTP Code: 500, Message: Internal Server Error)'
    assert the_error.http_code == 500
    assert the_error.url == 'https://galaxy.ansible.com/api/invalid_api/'


# Generated at 2022-06-22 20:29:48.623685
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(None,'foo')
    test1 = GalaxyError(http_error, None)
    assert test1


# Generated at 2022-06-22 20:30:00.340063
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # API server does not exist
    api = GalaxyAPI('does_not_exist')
    assert not api.api_server
    assert not api.name

    # API server exists but provides 404 or has no API
    api = GalaxyAPI('https://galaxy.ansible.com')
    assert not api.api_server
    assert not api.name

    api = GalaxyAPI('http://localhost:8000/api/')
    assert api.api_server == 'http://localhost:8000/api'
    assert api.name == 'localhost'

    # Test default API server
    api = GalaxyAPI()
    assert api.api_server == 'https://galaxy.ansible.com/api/'
    assert api.name == 'galaxy.ansible.com'


# Generated at 2022-06-22 20:30:08.845908
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():

    from ansible_collections.ansible.community.plugins.module_utils.urls import urljoin
    from ansible_collections.ansible.community.plugins.module_utils.urls import urlparse

    do_not_run_in_travis = unittest.skipIf('TRAVIS' in os.environ, "Cannot run this test in Travis")

    @do_not_run_in_travis
    def test_galaxy_api_default():
        api_server = 'https://galaxy.ansible.com/'

        expected_result = "GalaxyAPI(galaxy_server='https://galaxy.ansible.com/', token='None')"

# Generated at 2022-06-22 20:30:13.552952
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    from ansible_galaxy import GalaxyAPI
    from ansible.module_utils.urls import urlparse

    api_server = 'https://galaxy.ansible.com'
    name = 'testing'
    ignore_certs = False

    api = GalaxyAPI(api_server, name, ignore_certs)

    def url_without_path(url):
        p = urlparse(url)
        return p._replace(path='').geturl()

    assert api.__repr__() == "GalaxyAPI(%s, %s, %s)" % (url_without_path(api_server), name, ignore_certs)

# Generated at 2022-06-22 20:30:25.016894
# Unit test for function g_connect
def test_g_connect():
    @g_connect([u'v1', u'v2'])
    def get_roles(self,namespace=None,name=None):
       return self._call_galaxy(self._make_api_path(namespace=namespace,name=name,role_only=True, api_version='v2'),method='GET',error_context_msg="Error when fetching role list from Galaxy",cache=True)


# class GalaxyApi(object):
#     def __init__(self,galaxy_url=None,client_id=None,client_secret=None,token=None,token_secret=None,force_api_version=None,cache_path=None,verify_ssl=True,retries=10,delay_start=0,delay_max=300,delay_backoff_factor=2,delay_step

# Generated at 2022-06-22 20:30:34.852942
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # arrange
    galaxy_api = GalaxyAPI('https://galaxy.server/',
                             'username',
                             'token',
                             'verify',
                             False,
                             'name',
                             {'v2': '2.0'})
    expected_repr = (
        "GalaxyAPI([{'available_api_versions': {'v2': '2.0'}, 'verify': 'verify', 'name': 'name', 'username': 'username', "
        "'token': 'token', 'api_server': 'https://galaxy.server/', 'cache_path': False, 'cache': {}, 'persist_cache': False}])"
    )

    # act
    actual_repr = repr(galaxy_api)

    # assert
    assert expected_repr == actual_re

# Generated at 2022-06-22 20:30:46.455199
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI('test')
    assert galaxy_api < 'test', 'GalaxyAPI comparison failed!'



# Generated at 2022-06-22 20:30:52.650922
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy = GalaxyAPI(
        'https://galaxy.server.org',
        'username',
        'password',
        ['v3'],
    )

    assert galaxy.available_api_versions == {'v3': '/api/v3'}
    assert galaxy.api_server == 'https://galaxy.server.org'
    assert galaxy.username == 'username'
    assert galaxy.password == 'password'


# Generated at 2022-06-22 20:31:04.216820
# Unit test for function g_connect
def test_g_connect():
    # Static class to test the g_connect decorator
    class MockConn(object):
        def __init__(self):
            self._available_api_versions = {}
            self.name = 'Galaxy'
            self.api_server = 'https://galaxy.ansible.com'

        @g_connect(['v1', 'v2'])
        def test_method(self):
            pass

        @cache_lock
        def _call_galaxy(self, url, *args, **kwargs):
            return {}

    mock_conn = MockConn()
    mock_conn.test_method()

    # Verify version specified works
    mock_conn._available_api_versions = {u'v2': u'v2/'}
    mock_conn.test_method()

    # Verify error on unsupported version
    mock

# Generated at 2022-06-22 20:31:10.130384
# Unit test for function get_cache_id
def test_get_cache_id():
    url = 'https://galaxy.example.net'
    assert get_cache_id(url) == 'galaxy.example.net:'

    url = 'https://galaxy.example.net/'
    assert get_cache_id(url) == 'galaxy.example.net:'

    url = 'https://galaxy.example.net:4000'
    assert get_cache_id(url) == 'galaxy.example.net:4000'

    url = 'https://galaxy.example.net:4000/'
    assert get_cache_id(url) == 'galaxy.example.net:4000'


# Generated at 2022-06-22 20:31:21.767812
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Setup
    galaxy_api = GalaxyAPI()

    # Testing with a small number
    ansible_galaxy.api_servers.GalaxyAPI.api_server = 'https://galaxy.server/api/'
    galaxy_api.api_server = 'https://galaxy.server/api/'
    assert not galaxy_api < galaxy_api

    ansible_galaxy.api_servers.GalaxyAPI.api_server = 'https://galaxy1.server/api/'
    galaxy_api.api_server = 'https://galaxy.server/api/'
    assert galaxy_api < galaxy_api

    ansible_galaxy.api_servers.GalaxyAPI.api_server = 'https://galaxy.server/api/'

# Generated at 2022-06-22 20:31:32.768455
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    api = GalaxyAPI('galaxy_server', 'user@email.com', 'DEADBEEF', verify_ssl=False)
    api.api_server = 'https://example.com/api'
    metadata = api.get_collection_metadata('namespace', 'name')
    assert metadata.created_str == "2020-01-01T01:01+01:00"
    assert metadata.modified_str == "2020-01-01T01:01+01:00"
    assert metadata.namespace == "namespace"
    assert metadata.name == "name"
    assert "2020-01-01 01:01:00+01:00" == metadata.created
    assert "2020-01-01 01:01:00+01:00" == metadata.modified


# Generated at 2022-06-22 20:31:42.690563
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    created = '2020-01-01T01:00:00Z'
    modified = '2020-01-01T01:01:00Z'
    metadata = CollectionMetadata('namespace', 'name', created, modified)

    assert metadata.namespace == 'namespace'
    assert metadata.name == 'name'
    assert metadata.created_str == created
    assert metadata.modified_str == modified

    assert metadata.created == datetime.datetime.strptime(created, "%Y-%m-%dT%H:%M:%SZ")
    assert metadata.modified == datetime.datetime.strptime(modified, "%Y-%m-%dT%H:%M:%SZ")

    assert metadata.created.isoformat() == created
    assert metadata.modified.isoformat() == modified

    assert str

# Generated at 2022-06-22 20:31:47.064613
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    from ansible_galaxy.models.galaxy_api import GalaxyAPI
    obj = GalaxyAPI(name='test', api_server='test')
    assert obj.__unicode__() == "GalaxyAPI(name='test', api_server='test')"


# Generated at 2022-06-22 20:31:57.721989
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    n_namespace = 'ansible'
    n_name = 'test'
    n_created = '2017-01-01 00:00:00'
    n_modified = '2017-01-02 00:00:00'
    n_versions = ['0.0.1', '0.0.2']

    collection1 = CollectionMetadata(n_namespace, n_name)
    assert collection1.name == n_name
    assert collection1.namespace == n_namespace
    assert collection1.created_str is None
    assert collection1.modified_str is None

    collection2 = CollectionMetadata(n_namespace, n_name, created_str=n_created, modified_str=n_modified,
                                     versions=n_versions)
    assert collection2.name == n_name

# Generated at 2022-06-22 20:32:08.729526
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    expected_namespace = 'namespace'
    expected_name = 'name'
    expected_version = 'version'
    expected_download_url = 'download_url'
    expected_artifact_sha256 = 'artifact_sha256'
    expected_dependencies = {'a': '1', 'b': '2'}
    vmd = CollectionVersionMetadata(expected_namespace, expected_name, expected_version, expected_download_url, expected_artifact_sha256, expected_dependencies)
    assert vmd.namespace == expected_namespace
    assert vmd.name == expected_name
    assert vmd.version == expected_version
    assert vmd.download_url == expected_download_url
    assert vmd.artifact_sha256 == expected_artifact_sha256

# Generated at 2022-06-22 20:32:19.976156
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    display.display("Testing GalaxyAPI class constructor")
    # case no config specified
    api = GalaxyAPI(None, None)
    assert api.name is None and api.api_server is None and api.validate_certs is True and api.url == ""
    # case config provided and config file does not exist
    config = MockConfig(foo=dict(url="test_url", name="test_name", validate_certs=False))
    api = GalaxyAPI(config, None)
    assert api.name == "test_name" and api.api_server == "test_url" and api.validate_certs is False
    # case config provided and config file exists
    config_file = u'test_collections/ansible_collections/foo/bar/tests/galaxy.yml'

# Generated at 2022-06-22 20:32:22.843524
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI('http://galaxy.server', 'api_token')
    result = repr(api)
    assert type(result) == str


# Generated at 2022-06-22 20:32:30.360713
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_code = 500
    http_message = u"Internal Server Error"
    url = u"http://www.example.com"
    message = u"Galaxy server error"
    err = GalaxyError(HTTPError(url=url, code=http_code, msg=http_message, hdrs={}, fp=None,
                                filename=None), message)
    assert err.message == u"Galaxy server error (HTTP Code: 500, Message: Internal Server Error)"



# Generated at 2022-06-22 20:32:36.151751
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    from ansible.galaxy.api import GalaxyError
    assert not is_rate_limit_exception(GalaxyError('test', http_code=429, json_obj={'message': 'message'}))
    assert is_rate_limit_exception(GalaxyError('test', http_code=520, json_obj={'message': 'message'}))
    assert not is_rate_limit_exception(GalaxyError('test', http_code=403, json_obj={'message': 'message'}))



# Generated at 2022-06-22 20:32:40.324059
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI('namespace', 'name', 'api_server')
    assert str(galaxy_api) == 'GalaxyAPI(namespace, name, api_server)'


# Generated at 2022-06-22 20:32:41.851142
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    CollectionVersionMetadata('namespace', 'name', 'version', 'url', 'sha256',
                              [{'collection': {'namespace': 'namespace', 'name': 'name'}, 'version': 'version'}])


# Generated at 2022-06-22 20:32:50.052389
# Unit test for function cache_lock
def test_cache_lock():
    l = threading.Lock()

    def lock_function():
        l.acquire()

    def unlock_function():
        l.release()

    def double_lock_function():
        try:
            l.acquire()
            l.acquire()
        finally:
            l.release()

    wrapped_lock = cache_lock(lock_function)
    wrapped_unlock = cache_lock(unlock_function)
    wrapped_double_lock = cache_lock(double_lock_function)

    assert(not l.locked())
    wrapped_lock()
    assert(l.locked())
    wrapped_unlock()
    assert(not l.locked())
    wrapped_double_lock()
    assert(l.locked())



# Generated at 2022-06-22 20:33:00.902466
# Unit test for function get_cache_id
def test_get_cache_id():

    hostname = 'myhost'
    port = '123'
    netloc = '%s:%s' % (hostname, port)
    url = 'http://%s' % netloc
    assert get_cache_id(url) == netloc

    hostname = 'someuser@myhost'
    netloc = '%s:%s' % (hostname, port)
    url = 'http://%s' % netloc
    assert get_cache_id(url) == netloc

    url = 'http://%s/1/' % netloc
    assert get_cache_id(url) == netloc

    url = 'http://%s/1/somedir' % netloc
    assert get_cache_id(url) == netloc

    url = 'http://%s/1/somedir/'

# Generated at 2022-06-22 20:33:04.766299
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    CollectionVersionMetadata("foo", "bar", "2.2.0", "https://foo.bar.com/download.tgz", "12345", {
        "namespace": "foo",
        "name": "bar",
        "version": "1.0.0"
    })



# Generated at 2022-06-22 20:33:15.477188
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    inventory = GalaxyAPI(name='test_GalaxyAPI___unicode__', api_server='test_GalaxyAPI___unicode__', valid_versions=['v2', 'v3'])
    inventory.valid_versions = {
        'v2': 'api/v2',
        'v3': 'api/v3',
    }
    inventory_str = '<GalaxyAPI(name=test_GalaxyAPI___unicode__)>'
    assert str(inventory) == inventory_str
    assert to_text(inventory) == inventory_str
    assert six.text_type(inventory) == inventory_str
    assert repr(inventory) == inventory_str

# Generated at 2022-06-22 20:33:19.872923
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    mygalaxyAPI = GalaxyAPI(GalaxyClientOptions())
    assert mygalaxyAPI.__unicode__() == 'GalaxyAPI(api_server=None,name=None,username=None,ignore_certs=False)'


# Generated at 2022-06-22 20:33:24.632105
# Unit test for function get_cache_id
def test_get_cache_id():
    url = "http://10.0.0.1/api/"
    cache_id = get_cache_id(url)
    assert cache_id == "10.0.0.1"

# Generated at 2022-06-22 20:33:30.916003
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():

    # Empty GalaxyAPI object
    api = GalaxyAPI()
    assert str(api) == 'Ansible Galaxy (API: None)'

    # GalaxyAPI object
    api = GalaxyAPI(api_server='https://test/api/', name='test-name', token='token', available_api_versions={ 'v2': '/api/v2', 'v1': '/api/v1'})
    assert str(api) == 'Ansible Galaxy (test-name API: /api/v2)'



# Generated at 2022-06-22 20:33:37.801660
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise Exception()
    except Exception as e:
        try:
            raise GalaxyError(e, 'TestGalaxyError')
        except AnsibleError as ge:
            assert 'TestGalaxyError' in ge.message
            assert ge.message == 'TestGalaxyError'
            assert ge.http_code == None
            assert ge.url == None


# Generated at 2022-06-22 20:33:50.032986
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    obj = GalaxyAPI(name='foo', api_server='http://127.0.0.1:8080')
    other = GalaxyAPI(name='bar', api_server='http://127.0.0.1:8080')
    assert not (obj < other)
    other = GalaxyAPI(name='foo', api_server='https://127.0.0.1:8080')
    assert not (obj < other)
    other = GalaxyAPI(name='foo', api_server='http://127.0.0.1:8080')
    assert not (obj < other)
    other = GalaxyAPI(name='foo', api_server='http://127.0.0.1:8080', auth=('user', 'pass'))
    assert (obj < other)

# Generated at 2022-06-22 20:34:00.368385
# Unit test for function cache_lock
def test_cache_lock():
    cache = {}
    # test parallel decorator on methods
    class TestCacheLock(object):
        def __init__(self):
            self.cache = cache
            self.test = True
            self.values = []

        def setvalue(self, key, value):
            self.cache[key] = value

        @cache_lock
        def appendvalue(self, value):
            self.values.append(value)

    test1, test2 = TestCacheLock(), TestCacheLock()
    test1.appendvalue("test1")
    test2.appendvalue("test2")
    assert len(test1.values) == 2
    assert test1.values[0] == "test1"
    assert test1.values[1] == "test2"



# Generated at 2022-06-22 20:34:06.418521
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Setup
    galaxy_api = GalaxyAPI(api_server='https://galaxy.server.local',
                           available_api_versions={'v2': 'api/v2',
                                                   'v3': 'api/v3'},
                           ignore_certs=True)
    expected = 'GalaxyAPI(api_server=\'https://galaxy.server.local\', available_api_versions={\'v2\': \'api/v2\', \'v3\': \'api/v3\'}, ignore_certs=True)'

    # Exercise
    actual = galaxy_api.__repr__()

    # Verify
    assert actual == expected



# Generated at 2022-06-22 20:34:08.990936
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # This function raises and tests Exception
    try:
        raise GalaxyError(Exception("test-exception"), "test-message")
    except GalaxyError as e:
        assert e.message == "test-message (HTTP Code: 0, Message: test-exception)"


# Generated at 2022-06-22 20:34:10.654299
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI()
    unicode(api)



# Generated at 2022-06-22 20:34:24.127134
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError
    http_error.code = 500
    http_error.reason = "my_reason"
    http_error.geturl = lambda: "my_url"
    http_error.read = lambda: json.dumps({'default': "my_default"}).encode()
    ge = GalaxyError(http_error, "my_message")
    assert ge.http_code == 500
    assert ge.url == "my_url"
    assert ge.message == "my_message (HTTP Code: 500, Message: my_default)"

    http_error.geturl = lambda: "my_url/v2"
    http_error.read = lambda: json.dumps({'code': 'my_code', 'message': 'my_message'}).encode()

# Generated at 2022-06-22 20:34:30.182086
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError("http://test.test/test","403","test msg",{},"{'default':'wrong'}")
    err = GalaxyError(http_error, "123")
    assert isinstance(err, AnsibleError)
    assert err.http_code == http_error.code
    assert err.url == http_error.geturl()
    assert err.message == u"123 (HTTP Code: 403, Message: wrong)"


# Generated at 2022-06-22 20:34:41.879792
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('http://galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('http://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:9999') == 'galaxy.ansible.com:9999'
    assert get_cache_id('http://galaxy.ansible.com:9999') == 'galaxy.ansible.com:9999'



# Generated at 2022-06-22 20:34:49.631894
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    g = GalaxyAPI("0123456789abcdef0123456789abcdef", "https://galaxy.ansible.com", "name")
    g2 = GalaxyAPI("0123456789abcdef0123456789abcdef", "https://galaxy.ansible.com", "name")
    g3 = GalaxyAPI("fedcba9876543210fedcba9876543210", "https://galaxy.ansible.com", "name")
    g4 = GalaxyAPI("0123456789abcdef0123456789abcdef", "http://galaxy.ansible.com", "name")
    
    assert not g < g2
    assert g < g3
    assert not g < g4

# Generated at 2022-06-22 20:34:51.781457
# Unit test for function cache_lock
def test_cache_lock():
    lock_test = cache_lock(test_cache_lock)
    lock_test(test_cache_lock)



# Generated at 2022-06-22 20:35:02.672594
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error_1 = HTTPError('https://galaxy.ansible.com/api/v2/projects', 429, 'Too Many Requests', headers={}, fp=None)
    try:
        raise GalaxyError(http_error_1, "Message")
    except AnsibleError as e:
        assert e.message == u"Message (HTTP Code: 429, Message: Rate Limit Exceeded Code: TooManyRequests)"
        assert e.http_code == 429
        assert e.url == 'https://galaxy.ansible.com/api/v2/projects'

    http_error_2 = HTTPError('https://galaxy.ansible.com/api/v3/projects', 400, 'Bad Request', headers={}, fp=None)

# Generated at 2022-06-22 20:35:15.136438
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("http://galaxy.server.com/api/") == "galaxy.server.com:"
    assert get_cache_id("http://galaxy.server.com:8080/api/") == "galaxy.server.com:8080"
    assert get_cache_id("https://galaxy.server.com/api/") == "galaxy.server.com:"
    assert get_cache_id("https://galaxy.server.com:8080/api/") == "galaxy.server.com:8080"
    assert get_cache_id("https://galaxy.server.com/api?extra=stuff/") == "galaxy.server.com:"

# Generated at 2022-06-22 20:35:27.335274
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api_server = 'https://galaxy.ansible.com'
    name = 'awx'
    key = 'x'
    email = 'x@example.com'
    force = False
    git_commit = None
    token = None
    ignore_certs = False

    # test without result of available_api_versions
    galaxy = GalaxyAPI(api_server, name, key, email, force, git_commit, token, ignore_certs)
    assert galaxy.key is None
    assert galaxy.header is None
    assert galaxy.email == email
    assert galaxy.git_commit == git_commit
    assert galaxy.token == token
    assert galaxy.ignore_certs == ignore_certs
    # test with the result of the available_api_versions