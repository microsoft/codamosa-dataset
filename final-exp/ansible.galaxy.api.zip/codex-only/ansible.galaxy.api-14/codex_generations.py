

# Generated at 2022-06-22 20:25:26.909845
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    options = GalaxyOptions()
    options.server = 'https://galaxy.ansible.com'
    options.api_key = 'secret'

    api1 = GalaxyAPI('galaxy', options)
    api2 = GalaxyAPI('galaxy', options)
    assert api1 < api2
    assert not api1 > api2

# Generated at 2022-06-22 20:25:34.152080
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import urllib.error
    http_error = urllib.error.HTTPError("https://galaxy.ansible.com", 403, "Forbidden", {}, None)
    error_message = "This is a test message"
    error = GalaxyError(http_error, error_message)
    assert isinstance(error, GalaxyError)
    assert error.http_code == 403
    assert error.url == "https://galaxy.ansible.com"
    assert error.message == "This is a test message (HTTP Code: 403, Message: Forbidden)"



# Generated at 2022-06-22 20:25:44.399817
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Set up mock
    mock_name = mock.Mock(spec_set=str)
    mock_api_server = mock.Mock(spec_set=str)
    mock_ignore_certs = mock.Mock(spec_set=bool)
    mock_timeout = mock.Mock(spec_set=int)
    mock_validate_certs = mock.Mock(spec_set=bool)

    # Invoke method
    result = GalaxyAPI(mock_name, mock_api_server, mock_ignore_certs, mock_timeout,
                       mock_validate_certs).__repr__()

    # Check result
    assert result is not None

# Generated at 2022-06-22 20:25:54.058108
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # This is just a code coverage test, these are not real API servers
    api = GalaxyAPI(None, None, api_server="http://example.com", validate_certs=True, proxies="http://proxy.com",
                    ignore_certs=True, proxy_username="proxyuser", proxy_password="proxypass",
                    timeout=30, auth_url="http://auth.com", refresh_token="refreshtoken",
                    client_id="clientid", client_secret="clientsecret",
                    access_token="accesstoken", username="username", password="password",
                    context={'allow_redirects': True, 'cookies': 3},
                    allow_redirects=True)

# Generated at 2022-06-22 20:25:55.708869
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI()
    assert str(api)



# Generated at 2022-06-22 20:26:00.270849
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_api = GalaxyAPI(name='name', api_server='api_server', ignore_certs=False, force_basic_auth=False)
    result = galaxy_api.__str__()
    expected = "GalaxyAPI(name='name',api_server='api_server',ignore_certs=False,force_basic_auth=False)"
    assert result == expected

# Generated at 2022-06-22 20:26:07.887555
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    test_metadata = CollectionMetadata(namespace='namespace', name='name',
                                       version='version', authors='authors',
                                       description='description', readme='readme')
    assert test_metadata
    assert test_metadata.namespace == 'namespace'
    assert test_metadata.name == 'name'
    assert test_metadata.version == 'version'
    assert test_metadata.authors == 'authors'
    assert test_metadata.description == 'description'
    assert test_metadata.readme == 'readme'



# Generated at 2022-06-22 20:26:12.424213
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_api_object = GalaxyAPI("ansibullbot.test_galaxy_name", "http://test_galaxy_server/", [])
    assert str(galaxy_api_object) == "Galaxy API: http://test_galaxy_server/; Galaxy name: ansibullbot.test_galaxy_name; API versions: []"


# Generated at 2022-06-22 20:26:23.863632
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    collection_version_metadata = CollectionVersionMetadata(namespace='test_namespace',
                                                            name='test_name',
                                                            version='1.0.0',
                                                            download_url='https://test_download_url.com',
                                                            artifact_sha256='test_artifact_sha256',
                                                            dependencies={})
    assert collection_version_metadata.namespace == 'test_namespace'


# Generated at 2022-06-22 20:26:34.164909
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    """ Constructor of CollectionVersionMetadata class """
    collection_meta = CollectionVersionMetadata(
        namespace="mynamespace",
        name="myname",
        version="myversion",
        download_url="mydownload_url",
        artifact_sha256="myartifact_sha256",
        dependencies={'namespace1.name1': '1.0.0', 'namespace2.name2': '2.0.0'}
    )

    assert collection_meta.namespace == "mynamespace"
    assert collection_meta.name == "myname"
    assert collection_meta.version == "myversion"
    assert collection_meta.download_url == "mydownload_url"
    assert collection_meta.artifact_sha256 == "myartifact_sha256"

# Generated at 2022-06-22 20:26:35.431416
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
  """Unit test for method __repr__"""
  fail("No unit test implemented yet")

# Generated at 2022-06-22 20:26:47.066194
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    config_data = dict(
        galaxy_server="https://galaxy.ansible.com",
        galaxy_token="",
        galaxy_ignore_certs=False,
        galaxy_api_key=None,
        galaxy_verify_ssl=True,
    )
    galaxy_api = GalaxyAPI(config_data)
    assert str(galaxy_api) == "GalaxyAPI(https://galaxy.ansible.com)"
    config_data = dict(
        galaxy_server="https://galaxy.ansible.com",
        galaxy_token="abcdf",
        galaxy_ignore_certs=False,
        galaxy_api_key=None,
        galaxy_verify_ssl=True,
    )
    galaxy_api = GalaxyAPI(config_data)

# Generated at 2022-06-22 20:26:56.169923
# Unit test for function g_connect
def test_g_connect():
    class Test_galaxy_server(object):
        def __init__(self,api_server,name,out_path,token=None,ignore_certs=False,ignore_errors=False):
            self._available_api_versions = {'v1': u'v1/'}
            self.api_server = api_server
            self.name = name
            self.out_path = out_path
            self.token = token
            self.ignore_certs = ignore_certs
            self.ignore_errors = ignore_errors
            self.role_cache = None
            self.collections_cache = None
    def blablabla(self):
        pass
    test_galaxy_server = Test_galaxy_server('http://127.0.0.1:8080','test_galaxy_server','.')

# Generated at 2022-06-22 20:27:07.973428
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('http://galaxy.ansible.com:8088') == 'galaxy.ansible.com:8088'
    assert get_cache_id('http://galaxy.ansible.com/api') == 'galaxy.ansible.com:'
    assert get_cache_id('http://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('http://galaxy.ansible.com:8088/api') == 'galaxy.ansible.com:8088'
    assert get_cache_

# Generated at 2022-06-22 20:27:15.926275
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = "namespace"
    name = "name"
    version = "version"
    download_url = "download_url"
    artifact_sha256 = "artifact_sha256"
    dependencies = {"namespace_1" : "name_1" , "namespace_2": "name_2"}

    obj = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert obj.namespace == "namespace"
    assert obj.name == "name"
    assert obj.version == "version"
    assert obj.download_url == "download_url"
    assert obj.artifact_sha256 == "artifact_sha256"
    assert obj.dependencies == {"namespace_1" : "name_1" , "namespace_2": "name_2"}



# Generated at 2022-06-22 20:27:23.291339
# Unit test for function g_connect

# Generated at 2022-06-22 20:27:25.048369
# Unit test for function cache_lock
def test_cache_lock():
    class C(object):
        @cache_lock
        def foo(self):
            return 'bar'

    c = C()
    assert c.foo() == 'bar'



# Generated at 2022-06-22 20:27:33.688387
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # If the old_api_server is None the object will be considered less than
    api1 = GalaxyAPI(None)
    api2 = GalaxyAPI(None)
    assert api1 < api2 is False
    api1 = GalaxyAPI('http://acs.com', name='acs', verify_ssl=True)
    api2 = GalaxyAPI('http://acs.com', name='acs', verify_ssl=True)
    assert api1 < api2 is False
    api1 = GalaxyAPI('http://acs.com', name='acs1', verify_ssl=True)
    api2 = GalaxyAPI('http://acs.com', name='acs2', verify_ssl=True)
    assert api1 < api2 is True
    api1 = GalaxyAPI('http://acs.com', name='acs')

# Generated at 2022-06-22 20:27:45.860741
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    with pytest.raises(AnsibleError):
        galaxy_api = GalaxyAPI("http://galaxy.ansible.com", None, None)
    with pytest.raises(AnsibleError):
        galaxy_api = GalaxyAPI("http://galaxy.ansible.com", "username", None)
    with pytest.raises(AnsibleError):
        galaxy_api = GalaxyAPI("http://galaxy.ansible.com", None, "password")
    with pytest.raises(AnsibleError):
        galaxy_api = GalaxyAPI(None, "username", "password")
    galaxy_api = GalaxyAPI("http://galaxy.ansible.com", "username", "password")
    assert galaxy_api.api_server == "http://galaxy.ansible.com"
    assert galaxy_api.auth_

# Generated at 2022-06-22 20:27:54.091097
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy = GalaxyAPI('https://example.com/')
    assert str(galaxy) == "GalaxyAPI(https://example.com/)"
    galaxy = GalaxyAPI('https://example.com/', {'v2': 'api/v2', 'v3': 'api/v3'})
    assert str(galaxy) == "GalaxyAPI(https://example.com/ '{'v2': 'api/v2', 'v3': 'api/v3'}')"



# Generated at 2022-06-22 20:28:05.229993
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # creating a simple HTTP error
    error_response = {
        'errors': [{
            'detail': 'detail test',
            'title': 'title test',
            'code': 'code test',
        },{
            'detail': 'detail test 2',
            'title': 'title test 2',
            'code': 'code test 2',
        }]
    }

    error_response = {
        'message': 'message test',
        'code': 'code test',
    }

    err = HTTPError(url='https://galaxy.ansible.com/api/v1/',
                    hdrs={},
                    fp=None,
                    errcode=500,
                    errmsg='message test',
                    headers={},
                    filename=None)
    err.code = 500
    err.read = lambda: json

# Generated at 2022-06-22 20:28:08.221638
# Unit test for function get_cache_id
def test_get_cache_id():
    url = 'https://127.0.0.1:8080/api/v1/'
    assert get_cache_id(url) == '127.0.0.1:8080'



# Generated at 2022-06-22 20:28:15.759740
# Unit test for function cache_lock
def test_cache_lock():
    result = []
    @cache_lock
    def thread_test():
        time.sleep(0.1)
        result.append(1)
        time.sleep(0.1)

    threads = [threading.Thread(target=thread_test) for x in range(3)]
    for t in threads:
        t.start()
    time.sleep(0.1)
    # This test will pass if the cache lock is working
    assert len(result) == 1



# Generated at 2022-06-22 20:28:21.360882
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    with_http_code = GalaxyError('test-message', 520)
    assert is_rate_limit_exception(with_http_code) is True
    without_http_code = GalaxyError('test-message', None)
    assert is_rate_limit_exception(without_http_code) is False



# Generated at 2022-06-22 20:28:26.667287
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
  collection_path = ''
  timeout = 0
  namespace = 'namespace'
  name = 'name'
  version = 'version'
  with pytest.raises(AnsibleError) as excinfo:
    GalaxyAPI.__lt__(collection_path, timeout, namespace, name, version)
  assert to_native(excinfo.value) == u"Name or API server not set on this Galaxy API instance"
  # TODO: Add more tests


# Generated at 2022-06-22 20:28:29.813415
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    """
    Test __str__ of class GalaxyAPI
    """
    print(GalaxyAPI('galaxy.ansible.com', 'auser', 'apassword', 'token'))


# Generated at 2022-06-22 20:28:39.139875
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    from ansible_collections.ansible.community.plugins.module_utils.galaxy_client.models.collection_info import CollectionInfo
    from ansible.module_utils.urls import open_url
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.parse import urlencode

    collection_info = CollectionInfo('https://galaxy_server.com', 'org_name', 'collection_name', '0.1.0')


# Generated at 2022-06-22 20:28:46.585670
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI()
    assert galaxy_api.name == 'galaxy'
    assert galaxy_api._galaxy_servers == {}
    assert galaxy_api._cache == {}
    assert galaxy_api.api_server == 'https://galaxy.ansible.com/'
    assert galaxy_api.api_server_list == ['https://galaxy.ansible.com/']
    assert len(galaxy_api.available_api_versions) == 2
    assert galaxy_api.available_api_versions['v2'] == 'api/v2'
    assert galaxy_api.available_api_versions['v3'] == 'api/v3'

# Generated at 2022-06-22 20:28:54.381002
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api_server_1 = 'https://galaxy.example.com'
    api_key_1 = 'FAKE_API_KEY'
    api_key_2 = 'FAKE_API_KEY_2'
    name_1 = 'my galaxy'

    ga_1 = GalaxyAPI(api_server_1, api_key_1, name_1)
    ga_2 = GalaxyAPI(api_server_1, api_key_2, name_1)

    assert repr(ga_1) == "GalaxyAPI(api_server='https://galaxy.example.com') #1"
    assert repr(ga_2) == "GalaxyAPI(api_server='https://galaxy.example.com') #2"


# Generated at 2022-06-22 20:29:01.635862
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_api = GalaxyAPI()
    galaxy_api.name = 'ansible_galaxy_server2'
    galaxy_api.api_server = 'http://localhost:8080/foo/'
    galaxy_api.token = '456'

    assert str(galaxy_api) == "GalaxyAPI('ansible_galaxy_server2', api_server='http://localhost:8080/foo/', " \
                              "token='456')"

# Generated at 2022-06-22 20:29:07.726238
# Unit test for function cache_lock
def test_cache_lock():
    class test_obj:
        count = 0

        @cache_lock
        def test_inc(self):
            self.count += 1

    x = test_obj()
    assert x.count == 0
    x.test_inc()
    assert x.count == 1
    x.test_inc()
    assert x.count == 2



# Generated at 2022-06-22 20:29:15.918415
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """Test constructing the GalaxyAPI class."""
    # create a GalaxyAPI object for an Api server 'https://galaxy.server.com/'
    galaxy_api = GalaxyAPI(api_server='https://galaxy.server.com')
    assert galaxy_api.name == 'galaxy.server.com'
    assert galaxy_api.api_server == 'https://galaxy.server.com/'

    # create a GalaxyAPI object for an Api server 'https://galaxy.server.com/api'
    galaxy_api = GalaxyAPI(api_server='https://galaxy.server.com/api')
    assert galaxy_api.name == 'galaxy.server.com'
    assert galaxy_api.api_server == 'https://galaxy.server.com/api/'

# Generated at 2022-06-22 20:29:25.060940
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("http://server.com") == get_cache_id("http://server.com/")
    assert get_cache_id("https://server.com") == get_cache_id("https://server.com/")
    assert get_cache_id("https://server.com:443") == get_cache_id("https://server.com:")
    assert get_cache_id("https://server.com:443") == get_cache_id("https://server.com:443/")
    assert get_cache_id("https://server.com:5000") == get_cache_id("https://server.com:5000/")
    assert get_cache_id("https://server.com:5000") == get_cache_id("https://server.com:5000/api")

# Generated at 2022-06-22 20:29:36.983112
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api_v2_url = "http://api-server.local:8080/api/"
    api_v3_url = "http://api-server.local:8080/api/v3/"

    api = GalaxyAPI("server1", api_v2_url, api_v3_url)
    # test with invalid type of args
    ansible_galaxy.test.assert_raises_with_regexp_match(AnsibleError, "Invalid type for API server URL.", api.__unicode__, None)

    api = GalaxyAPI("server1", "invalid_server2_url", api_v3_url)
    ansible_galaxy.test.assert_raises_with_regexp_match(AnsibleError, "Invalid API server URL.", api.__unicode__, None)


# Generated at 2022-06-22 20:29:47.911690
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api_server = "https://galaxy.ansible.com"

    # Test with no extra args
    api = GalaxyAPI(api_server)
    assert api.name == 'main'
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.api_token is None
    assert api.verify_ssl is True
    assert api.ignore_certs is False

    # Test with name
    api = GalaxyAPI(api_server, name='test')
    assert api.name == 'test'
    assert api.api_server == 'https://galaxy.ansible.com'

    # Test with insecure
    api = GalaxyAPI(api_server, ignore_certs=True)
    assert api.verify_ssl is False

    # Test with insecure and token

# Generated at 2022-06-22 20:29:54.553370
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    schema = {'description': 'description',
              'name': 'name',
              'version': 'version'}

    galaxy_api = GalaxyAPI(None, 'url', 'server', {}, None)
    galaxy_api_2 = GalaxyAPI(None, 'url', 'server', {}, None)

    assert galaxy_api < galaxy_api_2
    assert isinstance(galaxy_api < galaxy_api_2, bool)


# Generated at 2022-06-22 20:30:03.232980
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection = CollectionMetadata(
        namespace='namespace',
        name='name',
        description='description',
        created_str='2017-01-01T00:00:00.000000Z',
        modified_str='2017-01-01T00:00:00.000000Z'
    )
    errors = []
    if collection.namespace != 'namespace':
        errors.append('namespace')
    if collection.name != 'name':
        errors.append('name')
    if collection.description != 'description':
        errors.append('description')
    if collection.created_str != '2017-01-01T00:00:00.000000Z':
        errors.append('created_str')

# Generated at 2022-06-22 20:30:09.847854
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    """GalaxyError class constructor test method"""
    error_msg = 'test_message'
    message = 'Error when downloading %s (%s) from %s' % ('test_name', 'test_url', 'test_server')
    http_error = HTTPError(url=error_msg, code='404', msg=message, hdrs=None, fp=None)
    try:
        # pylint: disable=unexpected-keyword-arg
        GalaxyError(http_error, message)
    except GalaxyError as err:
        assert err.http_code == '404'
        assert err.url == error_msg
        assert err.message == message


# Generated at 2022-06-22 20:30:15.413672
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    from ansible.module_utils._text import to_bytes
    test_instances = [
        GalaxyAPI("galaxy_server", "galaxy_user", "galaxy_pass")
    ]

    for t_instance in test_instances:
        result = to_bytes(t_instance)
        exp = b"server='galaxy_server', user='galaxy_user', password=u'********'"

        assert result == exp



# Generated at 2022-06-22 20:30:19.928902
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    try:
        galaxy_api = GalaxyAPI('https://galaxy.ansible.com', 'ACME', 'demo')
        assert True
    except:
        assert False

# Generated at 2022-06-22 20:30:27.605637
# Unit test for function cache_lock
def test_cache_lock():
    # Lock must be acquired before executing wrapped func
    @cache_lock
    def before(count):
        return count
    # Lock must be released after executing wrapped func
    @cache_lock
    def after(count):
        return count

    assert before(1) == 1
    # Second function should block if the lock is not released
    if _CACHE_LOCK.acquire(False):
        raise Exception("Lock should not be acquired!")
    _CACHE_LOCK.release()
    assert after(2) == 2



# Generated at 2022-06-22 20:30:39.785367
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    raw = dict(name="ah", api_server="https://automationhub.com", ignore_certs=False)
    galaxy = GalaxyAPI(raw)
    assert_that(str(galaxy), is_("Galaxy server 'ah' (https://automationhub.com)"))



# Generated at 2022-06-22 20:30:50.089795
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    """
    Unit test for constructor of class CollectionMetadata
    """
    import uuid
    t_namespace = 'ansible_collections.' + str(uuid.uuid4().hex)
    t_name = 'collection.' + str(uuid.uuid4().hex)
    metadata = CollectionMetadata(t_namespace, t_name)
    assert metadata.namespace == t_namespace
    assert metadata.name == t_name
    assert metadata.created_str is None
    assert metadata.modified_str is None

    t_namespace = 'ansible_collections.' + str(uuid.uuid4().hex)
    t_name = 'collection.' + str(uuid.uuid4().hex)
    t_created = '2000-01-01 00:00:00'

# Generated at 2022-06-22 20:30:54.075907
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    try:
        from collections import namedtuple
    except ImportError:
        from ansible.utils.collection_compat import namedtuple
    GalaxyServer = namedtuple('GalaxyServer', ['name', 'api_server', 'token'])
    g = GalaxyAPI(GalaxyServer('mygalaxy', 'https://mygalaxy.com', 'mytoken'))
    u = u'mygalaxy https://mygalaxy.com'
    assert g.__unicode__() == u

# Generated at 2022-06-22 20:30:57.612117
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    '''
    Unit test for method __lt__ of class GalaxyAPI
    '''
    test_instance = GalaxyAPI()
    assert not hasattr(test_instance, '__lt__')



# Generated at 2022-06-22 20:31:07.881801
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
  galaxy_api = GalaxyAPI(
    force = False,
    galaxy_server = None,
    ignore_certs = False,
    ignore_cache = False,
    ignore_errors = False,
    timeout = 10,
    token = None,
  )
  # test with invalid name
  assert not galaxy_api.__lt__("not_a_GalaxyAPI")
  
  # test with an invalid name
  assert not galaxy_api.__lt__("namespace")
  
  # test with an invalid name
  assert not galaxy_api.__lt__("name")
  
  # test with an invalid name
  assert not galaxy_api.__lt__("version")
  
  # test with valid name
  assert galaxy_api.__lt__(galaxy_api)
  
  

# Generated at 2022-06-22 20:31:09.527631
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI('server_url')
    assert not(galaxy_api < 'server_url')


# Generated at 2022-06-22 20:31:13.581357
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI(('some name', None, None))
    galaxy_api2 = GalaxyAPI(('another name', None, None))
    result = galaxy_api.__lt__(galaxy_api2)
    assert not result

# Generated at 2022-06-22 20:31:21.867825
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class RateLimitException(GalaxyError):
        http_code = 429

    class ForbiddenException(GalaxyError):
        http_code = 403

    class NotFoundException(GalaxyError):
        http_code = 404

    class InvalidStatusCodeException(GalaxyError):
        http_code = 999

    assert is_rate_limit_exception(RateLimitException())
    assert not is_rate_limit_exception(ForbiddenException())
    assert not is_rate_limit_exception(NotFoundException())
    assert not is_rate_limit_exception(InvalidStatusCodeException())



# Generated at 2022-06-22 20:31:25.783392
# Unit test for function get_cache_id
def test_get_cache_id():
    url = "https://test.example.com:8080/some/path"
    res_url = get_cache_id(url)
    assert res_url == "test.example.com:8080"

# Generated at 2022-06-22 20:31:35.511499
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    test_meta_object = CollectionVersionMetadata('test_namespace',
                                                 'test_name',
                                                 'test_version',
                                                 'test_url',
                                                 'test_checksum',
                                                 {'test_namespace2':'test_name2:test_version2'})
    assert test_meta_object.namespace == 'test_namespace'
    assert test_meta_object.name == 'test_name'
    assert test_meta_object.version == 'test_version'
    assert test_meta_object.download_url == 'test_url'
    assert test_meta_object.artifact_sha256 == 'test_checksum'
    assert test_meta_object.dependencies == {'test_namespace2': 'test_name2:test_version2'}

# Generated at 2022-06-22 20:31:45.563584
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    """GalaxyAPI method __lt__ test wrapper"""
    # Test with positional arguments
    g1 = GalaxyAPI(name='test_galaxy_api1', api_server='test_api_server1',
                   galaxy_token='test_galaxy_token1', ignore_certs=False, ignore_auth=False,
                   force_basic_auth=False, username='test_username1', password='test_password1')
    g2 = GalaxyAPI(name='test_galaxy_api2', api_server='test_api_server2',
                   galaxy_token='test_galaxy_token2', ignore_certs=True, ignore_auth=True,
                   force_basic_auth=True, username='test_username2', password='test_password2')
    assert g1 < g2



# Generated at 2022-06-22 20:31:55.325400
# Unit test for function g_connect
def test_g_connect():
    def g_connect_json(versions):
        return json.dumps(versions)

    def g_connect_set(versions):
        return set(versions)

    def g_connect_none(versions):
        return None

    def test_method(self, *args, **kwargs):
        """
        Args are API versions that method supports, wrapped function is called `wrapped`
        """
        assert all((args[i] == versions[i] for i in range(len(args))))
        assert all((kwargs.get(i, None) == versions[i][1] for i in range(len(kwargs))))
        return True

    versions = [("v1", "v1/"), ("v2", "v2/"), ("v3", "v3/")]

    # test_method can handle all API versions available on the

# Generated at 2022-06-22 20:32:03.995459
# Unit test for function g_connect
def test_g_connect():
    versions = ['v1', 'v2']
    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                self.api_server = 'https://galaxy.ansible.com/api/'
                self._available_api_versions = {'v1': 'v1/', 'v2': 'v2/'}
                display.vvvv("Found API version '%s' with Galaxy server %s (%s)"
                             % (', '.join(self._available_api_versions.keys()), self.name, self.api_server))
            available_versions = set(self._available_api_versions.keys())
            common_versions = set(versions).intersection(available_versions)

# Generated at 2022-06-22 20:32:10.069635
# Unit test for function get_cache_id
def test_get_cache_id():
    """
    Verify that the cache IDs we expect are generated for sample URLs
    """

# Generated at 2022-06-22 20:32:14.947143
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    c = CollectionMetadata('namespace', 'name', None, None)
    assert c.namespace == 'namespace'
    assert c.name == 'name'
    assert c.modified_str is None
    assert c.created_str is None



# Generated at 2022-06-22 20:32:20.325017
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    e403 = GalaxyError(http_code=403)
    e429 = GalaxyError(http_code=429)
    e520 = GalaxyError(http_code=520)
    assert not is_rate_limit_exception(e403)
    assert is_rate_limit_exception(e429)
    assert is_rate_limit_exception(e520)
test_is_rate_limit_exception()



# Generated at 2022-06-22 20:32:25.927934
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # This is a poor test in that it does not confirm the API class or version is set. It is not worth
    # including API URLs here as the API versioning is not directly specified.
    api = GalaxyAPI('https://galaxy.server.com', verify_ssl=False)
    assert str(api) == 'Galaxy API ("https://galaxy.server.com")'



# Generated at 2022-06-22 20:32:36.226516
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'some'
    name = 'namespace'
    created_str = 'created_at'
    modified_str = 'modified_at'
    metadata = CollectionMetadata(namespace, name, created_str=created_str, modified_str=modified_str)
    assert metadata.namespace == namespace
    assert metadata.name == name

    assert metadata.created_str == created_str
    assert metadata.modified_str == modified_str

    assert metadata.created is None
    assert metadata.modified is None

    created_str = '2000-01-01 00:00:00'
    modified_str = '2099-12-31 23:59:59'
    metadata = CollectionMetadata(namespace, name, created_str=created_str, modified_str=modified_str)
    assert metadata.created == datetime.dat

# Generated at 2022-06-22 20:32:44.984031
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    try:
        collections_metadata = CollectionMetadata(namespace='namespace_test', name='name_test', created_str='created_date',
                                                  modified_str='modified_date')
        assert collections_metadata.name == 'name_test'
        assert collections_metadata.namespace == 'namespace_test'
        assert collections_metadata.created_str == 'created_date'
        assert collections_metadata.modified_str == 'modified_date'
    except Exception:
        raise



# Generated at 2022-06-22 20:32:56.808266
# Unit test for function cache_lock
def test_cache_lock():
    run_count = 0
    @cache_lock
    def _cache_lock_handler():
        nonlocal run_count
        run_count += 1
        return run_count
    # Run parallel
    threads = [
        threading.Thread(target=_cache_lock_handler)
        for i in range(3)
    ]
    [t.start() for t in threads]
    [t.join() for t in threads]
    # Run sequentially
    threads = [
        threading.Thread(target=_cache_lock_handler)
        for i in range(3)
    ]
    [t.start() for t in threads]
    [t.join() for t in threads]
    # Only run once
    assert run_count == 2



# Generated at 2022-06-22 20:33:05.824549
# Unit test for function g_connect
def test_g_connect():
    # Success case - v1 of the API is supported
    def test_func(self, *args, **kwargs):
        return True

    wrapped = g_connect(['v1'])(test_func)
    assert (wrapped(GalaxyClient(), 'foo', bar='baz') is True)
    # Error case - v2 of the API is required but we're connecting to a v1-only server
    try:
        wrapped = g_connect('v2')(test_func)
        wrapped(GalaxyClient(), 'foo', bar='baz')
    except AnsibleError as e:
        assert(e.message.startswith("Galaxy action test_func requires API versions 'v2' but only 'v1' are available"))
        return True
    raise Exception("No exception thrown!")



# Generated at 2022-06-22 20:33:12.398396
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_url = 'http://galaxy.ansible.com'
    token = 'abc123'
    galaxy = GalaxyAPI(galaxy_url, token)
    assert str(galaxy) == "GalaxyAPI(galaxy_url='%s', token='%s')" % (galaxy_url, token)


# Generated at 2022-06-22 20:33:21.893839
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://hostname.tld') == 'hostname.tld:'
    assert get_cache_id('http://hostname.tld:') == 'hostname.tld:'
    assert get_cache_id('http://hostname.tld/path/to/something') == 'hostname.tld:'
    assert get_cache_id('http://localhost/path/to/something') == 'localhost:'
    assert get_cache_id('http://localhost') == 'localhost:'
    assert get_cache_id('http://localhost:') == 'localhost:'
    assert get_cache_id('http://localhost:8080') == 'localhost:8080'
    assert get_cache_id('http://127.0.0.1') == '127.0.0.1:'
    assert get_cache_id

# Generated at 2022-06-22 20:33:32.925201
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'
    assert get_cache_id('http://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'
    assert get_cache_id('http://github.com/ansible/galaxy') == 'github.com:'
    assert get_cache_id('http://github.com:80/ansible/galaxy') == 'github.com:80'
    assert get_cache

# Generated at 2022-06-22 20:33:38.532329
# Unit test for function cache_lock
def test_cache_lock():
    import inspect
    _func_name = inspect.getframeinfo(inspect.currentframe()).function
    assert inspect.isfunction(cache_lock)
    assert _func_name == 'test_cache_lock'


if C.DEFAULT_GALAXY_IGNORE_CERTS:
    import ssl
    ssl._create_default_https_context = ssl._create_unverified_context



# Generated at 2022-06-22 20:33:49.102671
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # This test is not good. I need to add some tests that actually do some real json rpc with a server.
    g = GalaxyAPI('http://foo.bar:1234/path/to/api', 'my_token', 'my_auth_user', 'my_auth_pass', 'my_server')
    assert repr(g) == "GalaxyAPI(api_server='http://foo.bar:1234/path/to/api', auth_token='my_token', auth_url='http://foo.bar:1234/path/to/api', auth_user='my_auth_user', auth_pass='my_auth_pass', server_name='my_server')"


# Generated at 2022-06-22 20:33:53.099998
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.example.test/test') == 'galaxy.example.test:', 'Error in get_cache_id'


# Generated at 2022-06-22 20:34:00.568893
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI('api_server_url')
    assert repr(api) == "GalaxyAPI(api_server_url=api_server_url, ignore_certs=False, auth_token=None, validate_certs=False, name=None)"
    api = GalaxyAPI('api_server_url', ignore_certs=True, auth_token='token', validate_certs=True, name='name')
    assert repr(api) == "GalaxyAPI(ignore_certs=True, auth_token=token, validate_certs=True, api_server_url=api_server_url, name=name)"



# Generated at 2022-06-22 20:34:02.560469
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
  # Test the method __unicode__ of class GalaxyAPI for proper operation
  ansible_galaxy_server_config.GalaxyAPI.__unicode__()

# Generated at 2022-06-22 20:34:11.476287
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("https://galaxy.ansible.com/api/") == "galaxy.ansible.com"
    assert get_cache_id("https://galaxy.ansible.com:443/api/") == "galaxy.ansible.com:443"
    assert get_cache_id("https://myuser:mypass@galaxy.ansible.com:8080") == "galaxy.ansible.com:8080"
    assert get_cache_id("https://myuser:mypass@galaxy.ansible.com") == "galaxy.ansible.com"


# Generated at 2022-06-22 20:34:24.219070
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    co_ver_md = CollectionVersionMetadata(namespace='ansible',name='awx',version='1.4.4',download_url='https://galaxy.ansible.com/api/v2/collections/ansible/awx/versions/1.4.4/tarball',artifact_sha256='123456789',dependencies={})
    assert co_ver_md.namespace=='ansible'
    assert co_ver_md.name=='awx'
    assert co_ver_md.version=='1.4.4'
    assert co_ver_md.download_url=='https://galaxy.ansible.com/api/v2/collections/ansible/awx/versions/1.4.4/tarball'

# Generated at 2022-06-22 20:34:29.229991
# Unit test for function cache_lock
def test_cache_lock():
    # Test function decorator applied to a function.
    @cache_lock
    def get_lock():
        return _CACHE_LOCK

    lock = get_lock()
    assert lock == _CACHE_LOCK
    assert lock.locked()
    lock.release()


# TODO: Make this a class method of GalaxyClient

# Generated at 2022-06-22 20:34:36.617404
# Unit test for function cache_lock
def test_cache_lock():
    from ansible.module_utils.basic import AnsibleModule
    import threading
    import time

    module = AnsibleModule(argument_spec={})
    counter = 0
    counter_lock = threading.Lock()

    # Use a module that is imported and that never changes
    @cache_lock
    def increment():
        nonlocal counter
        with counter_lock:
            counter += 1
        return counter

    def increment_until(until):
        while increment() < until:
            time.sleep(0.01)

    threads = []
    for i in range(5):
        threads.append(threading.Thread(target=increment_until, args=(50,)))
        threads[-1].start()
    for i in range(5):
        threads[i].join()

    # The function should be called 5 times for each

# Generated at 2022-06-22 20:34:47.417116
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'ansible'
    name = 'awesome_collection'
    version = '1.2.3'
    download_url = 'http://some-galaxy-server.com/collections/ansible-awesome_collection-1.2.3.tar.gz'
    artifact_sha256 = '87cf3d7afdcd3a1a583f4b4c4b4ca62342f9262a9de8734f0c8069a1b4ddc4e5'
    dependencies = {'namespace': 'ansible', 'name': 'vault', 'version_requirement': '>=2.0.0'}
    collection_version_metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, [dependencies])
    assert collection_version_metadata

# Generated at 2022-06-22 20:34:54.425210
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    '''
    Unit test for method __lt__ of class GalaxyAPI
    '''
    api1 = GalaxyAPI('https://galaxy.ansible.com', 'v2')
    api2 = GalaxyAPI('https://galaxy.ansible.com', 'v3')

    assert api1.__lt__(api2)
    assert api1.__lt__(api1) is False
    assert api2.__lt__(api1) is False

# Generated at 2022-06-22 20:35:04.736321
# Unit test for function g_connect
def test_g_connect():
    versions = [u'v1']
    method = ""
    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                display.vvvv("Initial connection to galaxy_server: %s" % self.api_server)

                # Determine the type of Galaxy server we are talking to. First try it unauthenticated then with Bearer
                # auth for Automation Hub.
                n_url = self.api_server
                error_context_msg = 'Error when finding available api versions from %s (%s)' % (self.name, n_url)


# Generated at 2022-06-22 20:35:08.140851
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy = GalaxyAPI(name='test_api')
    assert unicode(galaxy) == 'test_api'

# Generated at 2022-06-22 20:35:18.235311
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Setup for testing
    test_GalaxyAPI__init()
    test_GalaxyAPI__available_api_versions()

    # Testing
    g1=GalaxyAPI({'name': 'g1','api_server': 'http://g1.com','token': 't1'})
    g2=GalaxyAPI({'name': 'g2','api_server': 'http://g2.com','token': 't2'})

    g1.available_api_versions = {'v1':'v1'}
    g2.available_api_versions = {'v2':'v2'}
    assert not g1<g2
    assert not g2<g1

    g1.available_api_versions = {'v2':'v2'}

# Generated at 2022-06-22 20:35:22.122125
# Unit test for function g_connect
def test_g_connect():
    assert 9 == 3*3
g_connect = g_connect

# This is used to clean up invalid unicode in the return results from Galaxy.