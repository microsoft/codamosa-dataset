

# Generated at 2022-06-25 14:59:49.159150
# Unit test for function detect_encoding
def test_detect_encoding():
    def iter_lines(lines):
        for l in lines:
            yield l

    def readline():
        return next(iter_lines(["# coding: utf-8\n", "var = 42\n"]))

    assert detect_encoding(readline) == ("utf-8", ["# coding: utf-8\n"])



# Generated at 2022-06-25 14:59:58.441203
# Unit test for function detect_encoding
def test_detect_encoding():
    expected = ('iso-8859-1', ['coding: iso-8859-1\r\n'])
    def lines_gen(t):
        yield bytes(t, 'iso-8859-1')
    result = detect_encoding(lines_gen('coding: iso-8859-1\r\n'))
    if not result == expected:
        print("Expected %s, got %s" % (expected, result))
        raise Exception()
    expected = ('iso-8859-1', ['#coding: iso-8859-1\r\n'])
    result = detect_encoding(lines_gen('#coding: iso-8859-1\r\n'))
    if not result == expected:
        print("Expected %s, got %s" % (expected, result))
        raise

# Generated at 2022-06-25 15:00:08.408003
# Unit test for function generate_tokens
def test_generate_tokens():
    try:
        with open(__file__, "r") as source_file:
            source_text = source_file.read()
            source_lines = source_text.splitlines()
    except IOError as e:
        print(e)
        return

    try:
        # Testing with a parser requires a specific version of the grammar.
        from . import python_grammar_37 as parser
    except ImportError:
        parser = None

    if parser:
        for token in generate_tokens(iter(source_lines).__next__, parser):
            print(token)
    else:
        for token in generate_tokens(iter(source_lines).__next__):
            print(token)

if __name__ == "__main__":
    test_case_0()
    test_generate_tok

# Generated at 2022-06-25 15:00:09.835918
# Unit test for function generate_tokens
def test_generate_tokens():
    # Function generate_tokens with arguments (str)
    test_case_0()


# Classes

# Generated at 2022-06-25 15:00:18.726483
# Unit test for function generate_tokens
def test_generate_tokens():
    s = "def foo():\n    pass"

# Generated at 2022-06-25 15:00:19.384374
# Unit test for function generate_tokens
def test_generate_tokens():
    return


# Generated at 2022-06-25 15:00:21.751440
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    var_0 = Untokenizer()
    var_0.compat(var_0,var_0)


# Generated at 2022-06-25 15:00:31.297030
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import *

    readline = StringIO("if 1:\n  pass").readline
    result = list(generate_tokens(readline))


# Generated at 2022-06-25 15:00:34.150212
# Unit test for function printtoken
def test_printtoken():
    token = 'token'
    type = 'type'
    srow = 4
    scol = 3
    erow = 2
    ecol = 5
    line = 'line'
    printtoken(type, token, (srow, scol), (erow, ecol), line)


# Generated at 2022-06-25 15:00:36.129890
# Unit test for function tokenize_loop
def test_tokenize_loop():
    var_0 = tokenize_loop(test_case_0, printtoken)


# Generated at 2022-06-25 15:01:05.211662
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(got, expected):
        assert_equal(got.type, expected[0])
        assert_equal(got.string, expected[1])
        assert_equal(got.start, expected[2])
        assert_equal(got.end, expected[3])
        assert_equal(got.line, expected[4])

    def generate_tokens_check(input, output):
        all_tokens = []
        gt = generate_tokens(iter(input).__next__)
        for token in gt:
            all_tokens.append(token)
        check_token(all_tokens[0], output[0])
        check_token(all_tokens[2], output[2])
        check_token(all_tokens[3], output[3])

   

# Generated at 2022-06-25 15:01:15.978816
# Unit test for function generate_tokens

# Generated at 2022-06-25 15:01:24.801489
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer_0 = Untokenizer()
    start_0 = (1, 1)
    untokenizer_0.add_whitespace(start_0)
    untokenizer_0.add_whitespace((1, 1))
    untokenizer_0.add_whitespace((2, 1))
    untokenizer_0.add_whitespace((1, 1))
    untokenizer_0.add_whitespace((2, 2))
    untokenizer_0.add_whitespace((2, 1))


# Generated at 2022-06-25 15:01:31.777311
# Unit test for function generate_tokens
def test_generate_tokens():
    def compare(input,output):
        with closing(BytesIO(input.encode("utf8"))) as stream:
            generated = list(generate_tokens(stream.readline))
        return generated == output

    comparison = compare("123", [
        (NUMBER, '123', (1, 0), (1, 3), '123'),
        (ENDMARKER, '', (1, 3), (1, 3), '')
    ])
    assert comparison


# Generated at 2022-06-25 15:01:38.966894
# Unit test for function detect_encoding
def test_detect_encoding():
    #test_1
    print(detect_encoding(['# -*- coding: utf-8 -*-\n']))
    #test_2
    print(detect_encoding(['# -*- coding: utf-8 -*-\n', '# -*- coding: utf-8 -*-\n', '# -*- coding: utf-8 -*-\n', '# -*- coding: utf-8 -*-\n', '# -*- coding: utf-8 -*-\n', '# -*- coding: utf-8 -*-\n']))
    #test_3

# Generated at 2022-06-25 15:01:48.020794
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"aaa"
        yield b"   bbb"
    _encoding, _lines = detect_encoding(readline)
    assert (_encoding == "utf-8")
    assert (_lines == [b"aaa", b"   bbb"])
    return _encoding, _lines
# The function detect_encoding tests the codec registry for strict compliance
# with PEP-263.  Since this isn't the case for all builtin codecs, we'll skip
# these tests.
#    try:
#        unicode('\xef\xbb\xbf')
#    except UnicodeError:
#        pass
#    else:
#        def readline2():
#            yield b'\xef\xbb\xbf'
#            yield b'aaa'
#        _encoding, _

# Generated at 2022-06-25 15:01:57.915093
# Unit test for function generate_tokens
def test_generate_tokens():
    def _test(code):
        return [t[0] for t in generate_tokens(iter(code.splitlines()).next)]
    assert _test('a = 1') == [1, 1, 1, 53, 1]
    assert _test('a = 1 + 2\nb = 2 + 3') == [1, 1, 1, 53, 1, 4, 1, 1, 53, 1, 53, 1]
    assert _test('1') == [2, 1]
    assert _test('123') == [2, 123]
    assert _test('1.2') == [2, 1.2]
    assert _test('1e2') == [2, 100.0]
    assert _test('1e-2') == [2, 0.01]

# Generated at 2022-06-25 15:02:03.076959
# Unit test for function detect_encoding
def test_detect_encoding():
    # data = '\x8B\r\x8B\r\xAD\r\xAD\r\x8B\r\x8B\r\xAD\r\xAD\r\xEA\r\xEA'
    data = open("../data/detect_encoding_data.pkl", "rb")
    readline = data.readline
    encoding, lines = detect_encoding(readline)
    print("encoding: {0}".format(encoding))
    print("lines: {0}".format(lines))


# Generated at 2022-06-25 15:02:06.503140
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer = Untokenizer()
    input_string = ""
    expected_output = ""
    output = untokenizer.untokenize(input_string)
    assert expected_output == output, "Expected: {}, Actual: {}".format(expected_output, output)


# Generated at 2022-06-25 15:02:11.774841
# Unit test for function generate_tokens
def test_generate_tokens():
    # The unit test is taken from the tokenize library
    import token
    import io
    import tokenize
    import unittest
    import re

    class TokenizeTests(unittest.TestCase):
        def check_tokenize(self, input, expected):
            with io.StringIO(input) as f:
                #  generate_tokens() should match tokenize.tokenize()
                tokens = list(tokenize.tokenize(f.readline))
            with io.StringIO(input) as f:
                tokens_full = list(tokenize.tokenize(f.readline))
            with io.StringIO(input) as f:
                got = list(generate_tokens(f.readline))
            self.assertEqual(tokens, got, "Tokens differ")
            # Make sure that

# Generated at 2022-06-25 15:02:57.496567
# Unit test for function generate_tokens
def test_generate_tokens():
    def _test_function(readline):
        return list(generate_tokens(readline))

    f = StringIO("def f(x): return 2*x")
    tokens = _test_function(f.readline)

# Generated at 2022-06-25 15:03:08.413184
# Unit test for function tokenize
def test_tokenize():
    # Test with string
    test_string = b'String with (parentheses)'
    token_list = list(tokenize(test_string.splitlines))
    assert token_list[0] == (1, 0, 0, 9, 'String', 'String', 1, 1, 0)
    assert token_list[1] == (1, 8, 1, 9, ' ', ' ')
    assert token_list[2] == (1, 9, 1, 11, 'with', 'with')
    assert token_list[3] == (1, 13, 1, 14, ' ', ' ')
    assert token_list[4] == (1, 14, 1, 20, '(', '(')
    assert token_list[5] == (1, 20, 1, 29, 'parentheses', 'parentheses')

# Generated at 2022-06-25 15:03:12.462065
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-25 15:03:23.082250
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import BytesIO
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize
    #from token import *
    #from tokenize import *
    #from tokenize import test_tokenize
    #from tokenize import _tokenize

    print('>>> test_case_0')
    test_case_0()

    def untokenize(*args, **kwargs):
        return untokenize(*args, **kwargs).rstrip('\r\n')

    def check_tokenize(input: bytes, expected: Sequence[TokenInfo]) -> None:
        f = BytesIO(input)
        result = [token_info for token_info in generate_tokens(f.readline)]
        assert result == expected


# Generated at 2022-06-25 15:03:33.984107
# Unit test for function generate_tokens
def test_generate_tokens():
    token_list = generate_tokens(iter("print('hello world')").__next__)
    assert next(token_list) == (NAME, "print", (1, 0), (1, 5), "print('hello world')")
    assert next(token_list) == (OP, "(", (1, 5), (1, 6), "print('hello world')")
    assert next(token_list) == (STRING, "'hello world'", (1, 6), (1, 18), "print('hello world')")
    assert next(token_list) == (OP, ")", (1, 18), (1, 19), "print('hello world')")
    assert next(token_list) == (ENDMARKER, "", (1, 19), (1, 19), "")


# Generated at 2022-06-25 15:03:45.522848
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer_1 = Untokenizer()
    untokenizer_1.add_whitespace((0, 0))
    untokenizer_1.tokens.append("import ")
    untokenizer_1.prev_row = 0
    untokenizer_1.prev_col = 6
    untokenizer_1.add_whitespace((0, 6))
    untokenizer_1.tokens.append("sys")
    untokenizer_1.prev_row = 0
    untokenizer_1.prev_col = 9
    untokenizer_1.tokens.append("\n")
    untokenizer_1.prev_row = 1
    untokenizer_1.prev_col = 0
    untokenizer_1.add_whitespace((1, 0))
    untokenizer_

# Generated at 2022-06-25 15:03:53.204991
# Unit test for function detect_encoding
def test_detect_encoding():
    def utf8_readline1() -> bytes:
        return b"\xef\xbb\xbfabc\n"
    def utf8_readline2() -> bytes:
        return b" \xef\xbb\xbfabc\n"
    def utf8_readline3() -> bytes:
        return b"# coding=utf-8\n"
    def utf8_readline4() -> bytes:
        return b"# coding: utf-8\n"
    def utf8_readline5() -> bytes:
        return b"1 #coding=uTF-8\n"
    def utf8_readline6() -> bytes:
        return b"2#coding : uTF-8\n"
    def utf8_readline7() -> bytes:
        return

# Generated at 2022-06-25 15:04:03.715196
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import sys
    import token
    from blib2to3.pgen2.tokenize import tokenize_loop

    def readlines(s):
        for c in s:
            yield c

    class TokenTester:
        def __init__(self):
            self.tokens = []
            self.prev_row = 1
            self.prev_col = 0

        def tokenize(self, tok_type, tok_string, start, end, line):
            start_row, start_col = start
            end_row, end_col = end
            (
                prev_row,
                prev_col,
                expected_row_offset,
                expected_col_offset,
            ) = self.tokens.pop(0)
            row_offset = start_row - self.prev_row

# Generated at 2022-06-25 15:04:09.548560
# Unit test for function tokenize_loop
def test_tokenize_loop():
    code = '''
    _ = dict(a='a_')
    a_ = 123; _ = "b"; c = 'c'
    '''
    test_s = io.StringIO(code)
    def _success_case(token_info):
        print("token_info:", token_info)
    tokenize_loop(test_s.readline, _success_case)


# Generated at 2022-06-25 15:04:10.142398
# Unit test for function tokenize
def test_tokenize():
    pass



# Generated at 2022-06-25 15:04:47.070564
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer_0 = Untokenizer()
    token_0 = (None, None)
    iterable_0 = []
    untokenizer_0.compat(token_0, iterable_0)


# Generated at 2022-06-25 15:04:53.755505
# Unit test for function detect_encoding
def test_detect_encoding():

    def _make_generator(lines):
        for line in lines:
            yield line

    # If no encoding is specified, then the default of 'utf-8' will be returned
    assert detect_encoding(_make_generator([bytes()])) == ('utf-8', [])

    # This will return utf-8-sig
    assert detect_encoding(_make_generator([BOM_UTF8])) == ('utf-8-sig', [])

    # Encoding w/ BOM
    assert detect_encoding(_make_generator([BOM_UTF8, bytes()])) == ('utf-8-sig', [])

    # Detect utf-8 encoding
    assert detect_encoding(_make_generator([b"# coding: utf-8"])) == ('utf-8', [])

    # Detect

# Generated at 2022-06-25 15:05:01.273425
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer_compat_0 = Untokenizer()
    untokenizer_compat_0.tokens.append("\n")
    untokenizer_compat_0.tokens.append(")")
    untokenizer_compat_0.prev_col = 1
    untokenizer_compat_0.prev_row = 1
    untokenizer_compat_0.add_whitespace((1,2))
    untokenizer_compat_0.tokens.append(" ")
    untokenizer_compat_0.prev_col = 2



# Generated at 2022-06-25 15:05:05.184919
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def myreadline():
        return "\n"

# Generated at 2022-06-25 15:05:12.927087
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline_0(input_source_0: Text) -> Callable[[], bytes]:
        for line in input_source_0.split("\n"):
            yield line.encode("ascii")
    source_0 = "# coding: utf-8\n"
    encoding_0, lines_0 = detect_encoding(readline_0(source_0))
    print("encoding_0 is %s" % encoding_0)
    print("lines_0 is %s" % lines_0)


# Generated at 2022-06-25 15:05:14.768194
# Unit test for function detect_encoding
def test_detect_encoding():
    readline = open("test_tokenize.py", "rb").readlines
    print(detect_encoding(readline))


# Generated at 2022-06-25 15:05:17.408478
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline_0() -> bytes:
        return bytes()

    result_0 = detect_encoding(readline_0)
    expected_0 = ("utf-8", [])
    assert result_0 == expected_0


# Generated at 2022-06-25 15:05:20.242999
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer_0 = Untokenizer()
    assert untokenizer_0 is not None
    token_info_0 = (NAME, "def")
    list_0 = []
    untokenizer_0.compat(cast(Tuple[int, Text], token_info_0), list_0)


# Generated at 2022-06-25 15:05:22.889441
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer_0 = Untokenizer()
    assert untokenizer_0 != None


# Generated at 2022-06-25 15:05:25.599994
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test for the default value of tokeneater

    def readline_0():
        return '\n'

    tokenize_loop(readline_0, tokeneater=printtoken)

