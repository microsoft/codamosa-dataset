

# Generated at 2022-06-25 14:59:55.848028
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    var_0 = Untokenizer()
    var_1 = var_0.compat((NAME, "NAME"), [(NUMBER, "NUMBER")])


# Generated at 2022-06-25 14:59:56.613442
# Unit test for function tokenize
def test_tokenize():
    test_case_0()


# Generated at 2022-06-25 15:00:03.555388
# Unit test for function detect_encoding
def test_detect_encoding():
    var_0 = [0] if len(var_0) == 0 else var_0

    def readline():
        nonlocal var_0
        var_0[0] += 1
        if var_0[0] == 1:
            return b"# coding: utf-8\n"
        elif var_0[0] == 2:
            return b"if True:\n"
        raise StopIteration()

    assert detect_encoding(readline)[0] == "utf-8"

    var_0[0] = 0

    def readline():
        nonlocal var_0
        var_0[0] += 1
        if var_0[0] == 1:
            return BOM_UTF8 + b"# coding: utf-8\n"

# Generated at 2022-06-25 15:00:12.208137
# Unit test for function generate_tokens
def test_generate_tokens():
    import sys
    import random

    def printtoken(type, token, srow_scol, erow_ecol, line):
        tok_name = tokenize.tok_name[type]
        print(
            f"{tok_name:14}{token!r:20}",
            f"{srow_scol!r:20} {erow_ecol!r:20}",
            f"{line!r}",
        )

    if len(sys.argv) == 1:
        filename = __file__
    else:
        filename = sys.argv[1]
    f = open(filename, "rb")
    try:
        tokenize.tokenize(f.readline, printtoken)
    finally:
        f.close()

    # print('TESTING CORNER CASES

# Generated at 2022-06-25 15:00:15.903530
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    var_0 = Untokenizer()
    assert var_0.untokenize([(1, "hello"), (1, "world")]) == "hello world"
    assert var_0.untokenize([(0, "\\n"), (1, "hello"), (1, "world")]) == "\nhello world"
    var_0 = Untokenizer()
    assert var_0.untokenize([(1, "hello"), (4, "\n"), (1, "world")]) == "hello\nworld"


# Generated at 2022-06-25 15:00:27.370562
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-25 15:00:28.581752
# Unit test for function generate_tokens
def test_generate_tokens():
    """Test generate_tokens()."""
    import token
    import StringIO

# Generated at 2022-06-25 15:00:32.667690
# Unit test for function tokenize_loop
def test_tokenize_loop():
    r=regex.compile(r'#[^\r\n]*')
    readline = lambda: r'#[^\r\n]*'
    tokeneater = printtoken
    try:
        generate_tokens(readline)
        tokenize_loop(readline, tokeneater)
    except StopTokenizing:
        pass


# Generated at 2022-06-25 15:00:35.138713
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    var_1 = Untokenizer()
    var_2 = tuple()
    var_3 = var_1.untokenize(var_2)


# Generated at 2022-06-25 15:00:40.828046
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        yield b"# coding: utf-8"
        yield b"# more comment"
        yield b"def f():"
        yield b"  pass"
    assert detect_encoding(readline) == ("utf-8", [b"# coding: utf-8", b"# more comment"])



# Generated at 2022-06-25 15:01:27.281991
# Unit test for function generate_tokens
def test_generate_tokens():
    import ast
    import io

    buf_0 = io.StringIO(
        "def test_case_0():\n    var_0 = any()\n"
    )  # from ast_2
    token_0 = next(generate_tokens(buf_0.readline))

    # Check for attributes of the first item in generate_tokens output
    def test_0():
        return token_0[
            0
        ]  # Return the first element in the tuple, which should be a string.

    assert test_0() == "NAME"
    assert token_0[
        1
    ] == "def"  # Return the second element in the tuple, which should be a string.

    def test_1():
        return token_0[2]


# Generated at 2022-06-25 15:01:29.158277
# Unit test for function tokenize_loop

# Generated at 2022-06-25 15:01:29.784179
# Unit test for function tokenize_loop
def test_tokenize_loop():
    var_0 = any()


# Generated at 2022-06-25 15:01:37.621789
# Unit test for function detect_encoding
def test_detect_encoding():
    def test(bdata, expected):
        lines = [l for l in bdata.splitlines()]
        encoding, used = detect_encoding(iter(lines).__next__)
        assert encoding == expected, (
            "got %r, expected %r for %r" % (encoding, expected, bdata)
        )
        assert used == lines[: len(used)], (
            "got %r, expected %r for %r" % (used, lines[: len(used)], bdata)
        )

    test(BOM_UTF8 + b"# -*- coding: latin-1 -*-\npass\n", "iso-8859-1")
    test(b"pass\n", "utf-8")

# Generated at 2022-06-25 15:01:44.721137
# Unit test for function generate_tokens
def test_generate_tokens():
    global tabsize, detect_encoding, untokenize, generate_tokens
    import tokenize
    tabsize = 8
    detect_encoding = tokenize.detect_encoding
    untokenize = tokenize.untokenize
    generate_tokens = tokenize.tokenize
    var_0 = generate_tokens(iter(test_case_0.__code__.co_code).__next__).__next__

# Class for writing and reading Python code in tokenized form

# Generated at 2022-06-25 15:01:55.811663
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import tokenize as tokenize_func

    s = "def foo(a, b, c):\n pass\n"
    res = list(tokenize_func(s.encode()))

# Generated at 2022-06-25 15:02:03.106326
# Unit test for function detect_encoding
def test_detect_encoding():
    # Testing for function detect_encoding
    import io
    import sys
    import tokenize
    # file_path = '/home/adit/Btech_project/py_proj/test_cases/test_case_3.py'
    # with open(file_path, 'rb') as fp:
    #     rd_line = fp.readline
    #     encoding, lines = detect_encoding(rd_line)
    #     fp.seek(0)
    #     reader = io.TextIOWrapper(fp, encoding, line_buffering=True)
    #     source = reader.read()

    # print(encoding)
    # print(lines)
    # print("."*50)
    # print(source)
    # print("."*50)

    # lines = source.split

# Generated at 2022-06-25 15:02:04.543693
# Unit test for function tokenize
def test_tokenize():
    assert list[1,2,3] == list[1,2,3]




# Generated at 2022-06-25 15:02:11.565758
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = StringIO('foo = "bar"\n').readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NAME, 'foo', (1, 0), (1, 3), 'foo = "bar"\n')
    assert tokens[1] == (OP, '=', (1, 4), (1, 5), 'foo = "bar"\n')
    assert tokens[2] == (STRING, 'bar', (1, 6), (1, 11), 'foo = "bar"\n')
    readline = StringIO('1 + 1\n').readline
    tokens = list(tokenize(readline))

# Generated at 2022-06-25 15:02:19.908253
# Unit test for function generate_tokens
def test_generate_tokens():
    with open('generate_tokens_data.txt') as f:
        line = f.readline()
        while line:
            input_ = line[:-1]
            test_case = 'test_case_' + input_[0]
            exec(input_)
            tokens = generate_tokens(test_case)
            for t in tokens:
                print(t)
            line = f.readline()

if __name__ == '__main__':
    # test_generate_tokens()
    test_case_0()

# Generated at 2022-06-25 15:02:56.778032
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    input_0 = bytes("# encoding: iso-8859-15", "utf-8")
    input_1 = io.BytesIO(input_0)
    # Line 1
    def readline_0():
        return input_1.readline()
    # Line 3
    expected_0 = "iso-8859-15"
    expected_1 = []
    result_0 = detect_encoding(readline_0)
    assert expected_0 == result_0[0], "detect_encoding(readline_0)[0] == expected_0 is False"
    assert expected_1 == result_0[1], "detect_encoding(readline_0)[1] == expected_1 is False"


# Generated at 2022-06-25 15:03:07.492005
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test if the function detects UTF-8 encoding if there is no BOM
    # or encoding cookie.
    def no_encoding() -> Iterator[bytes]:
        yield b"#!/usr/bin/python3"
        yield b"if True:"
        yield b"    print('hello')"
        yield b"this is the last line"

    assert detect_encoding(no_encoding) == ("utf-8", [b"#!/usr/bin/python3"])

    # Test if the function detects UTF-8 encoding if there is a BOM but no
    # encoding cookie.
    def encoding_bom() -> Iterator[bytes]:
        yield BOM_UTF8
        yield b"#!/usr/bin/python3"
        yield b"if True:"
        yield b"    print('hello')"
        yield b

# Generated at 2022-06-25 15:03:08.463243
# Unit test for function detect_encoding
def test_detect_encoding():
    test_case_1(None)


# Generated at 2022-06-25 15:03:16.728117
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import BytesIO
    from .tokenize import tokenize_loop
    from .tokenize import generate_tokens
    stream = BytesIO(b"alpha beta gamma\n")
    tokeneater = lambda *args: None
    tokenize_loop(stream.readline, tokeneater)
    stream = BytesIO(b"alpha = 1\n")
    tokenize_loop(stream.readline, tokeneater)
    stream = BytesIO(b"def foo():\n")
    tokenize_loop(stream.readline, tokeneater)
    stream = BytesIO(b'def foo():\n    "doc string"\n')
    tokenize_loop(stream.readline, tokeneater)

# Generated at 2022-06-25 15:03:17.626453
# Unit test for function tokenize_loop
def test_tokenize_loop():
    pass  # TODO: implement your test here


# Generated at 2022-06-25 15:03:24.012869
# Unit test for function generate_tokens
def test_generate_tokens():
    def readline():
        raise StopIteration
    def is_async():
        return False
    def is_await():
        return False
    grammar = Grammar(is_async, is_await, None)
    tokens = list(generate_tokens(readline, grammar))
    assert tokens == [
        (ENDMARKER, "", (1, 0), (1, 0), ""),
    ]


# Generated at 2022-06-25 15:03:34.719153
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as builtin_tokenize


    # Ensure that the iterable yielded by tokenize() matches the iterable yielded
    # by tokenize_loop().



# Generated at 2022-06-25 15:03:36.096870
# Unit test for function tokenize_loop
def test_tokenize_loop():
    pass



# Generated at 2022-06-25 15:03:45.481510
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    input = [(NAME, 'def'),
             (NAME, 'a'),
             (OP, '('),
             (NAME, 'b'),
             (NAME, 'c'),
             (OP, ')'),
             (OP, ':'),
             (NEWLINE, '\n'),
             (INDENT, '    '),
             (NAME, 'return'),
             (NAME, 'b'),
             (NAME, 'c'),
             (DEDENT, ''),
             (NEWLINE, '\n')]

    expected = "def a(b c):\n    return b c\n\n"
    untokenizer = Untokenizer()
    result = untokenizer.untokenize(input)
    assert result == expected


# Generated at 2022-06-25 15:03:50.623562
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # untokenizer = untokenize()
    import io
    import tokenize

    # unit test for https://bugs.python.org/issue16896
    try:
        from StringIO import StringIO  # Py 2
    except ImportError:
        from io import StringIO  # Py 3

    content = "def f():\n    print(a)";
    s = StringIO(content)
    tokenize.tokenize_loop(s.readline, print)


# Generated at 2022-06-25 15:04:51.178088
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Checking if the function raises an exception when readline is not a
    # callable object
    try:
        tokenize_loop("test_string", printtoken)
    except TypeError:
        pass
    else:
        raise AssertionError("tokenize_loop failed to raise TypeError on noncallable readline")


# Generated at 2022-06-25 15:04:52.655460
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from test import test_tokenize
    test_tokenize.test_tokenize("test_tokenize_loop")


# Generated at 2022-06-25 15:04:57.550305
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer = Untokenizer()
    iterable = [
        (NUMBER, "123", (1, 0), (1, 3), "123"),
        (STRING, '"hello"', (1, 4), (1, 11), '"hello"'),
        (NEWLINE, "\n", (1, 11), (2, 0), "\n"),
        (NAME, "foo", (2, 0), (2, 3), "foo"),
        (NEWLINE, "\n", (2, 3), (3, 0), "\n"),
        (ENDMARKER, "", (3, 0), (3, 0), ""),
    ]
    assert untokenizer.untokenize(iterable) == "123 'hello'\nfoo\n"


# Generated at 2022-06-25 15:05:00.473499
# Unit test for function detect_encoding
def test_detect_encoding():
    encoding_0, left_1 = detect_encoding(open(__file__, "rb").__iter__)
    # assert left_1 == [b'"""Example of how to tokenize Python code.\n']


# Generated at 2022-06-25 15:05:10.787555
# Unit test for function generate_tokens
def test_generate_tokens():
    file = open('untokenize_testcase_0.py','w')
    file.write("#!/usr/bin/env python3\n")
    file.write("# -*- coding: utf-8 -*-\n")
    file.write("#\n")
    file.write("# This program is dedicated to the public domain under the CC0 license.\n")
    file.write("#\n")
    file.write("# THIS EXAMPLE HAS BEEN UPDATED TO WORK WITH THE BETA VERSION 12 OF PYTHON-TELEGRAM-BOT.\n")
    file.write("# If you're still using version 11.1.0, please see the example at\n")

# Generated at 2022-06-25 15:05:19.302314
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline(lines):
        for line in lines:
            yield line

    lines = (
        '# coding: ascii\n',
        'def f():\n',
    )
    encoding, read_lines = detect_encoding(readline(lines))
    assert encoding == 'ascii'
    assert read_lines == lines[:1]

    lines = (
        'def f():\n',
        '# coding: latin-1\n',
    )
    encoding, read_lines = detect_encoding(readline(lines))
    assert encoding == 'iso-8859-1'
    assert read_lines == lines[1:2]

    lines = (
        '# coding: latin-1\n',
        'def f():\n',
    )

# Generated at 2022-06-25 15:05:24.983821
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"This is a test for detect_encoding, no encoding statement\n"
        yield b"This is a test for detect_encoding, no encoding statement!\n"

    assert detect_encoding(readline) == ('utf-8', [])

    def readline():
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"This is a test for detect_encoding, no encoding statement\n"
        yield b"This is a test for detect_encoding, no encoding statement!\n"

    assert detect_encoding(readline) == ('utf-8', [b"# -*- coding: utf-8 -*-\n"])


# Generated at 2022-06-25 15:05:25.763872
# Unit test for function tokenize

# Generated at 2022-06-25 15:05:28.898886
# Unit test for function generate_tokens
def test_generate_tokens():
    def readline():
        yield "hello world"
    generator_tokens = generate_tokens(readline)
    print(next(generator_tokens))
    print(next(generator_tokens))
    print(next(generator_tokens))
    print(next(generator_tokens))


# Generated at 2022-06-25 15:05:30.582620
# Unit test for function detect_encoding
def test_detect_encoding():
    pass


# Generated at 2022-06-25 15:06:49.955383
# Unit test for function detect_encoding
def test_detect_encoding():
    lines = []
    def readlines():
        for each in lines:
            yield each
    # Test when there is nothing in the file
    for i in range(4):
        lines = ['']
        assert detect_encoding(readlines) == ('utf-8', [''])
    # Test when there is only something in the first line
    lines = ['#!/usr/bin/python']
    assert detect_encoding(readlines) == ('utf-8', ['#!/usr/bin/python'])
    # Test when there is something in the first line,
    # but there is no encoding specified
    lines = ['#!/usr/bin/python', '']
    assert detect_encoding(readlines) == ('utf-8', ['#!/usr/bin/python', ''])
    # Test when the encoding is specified in the first line

# Generated at 2022-06-25 15:06:51.482447
# Unit test for function tokenize_loop
def test_tokenize_loop():
    ts = token.tokenize_loop([])
    assert isinstance(ts, token.TokenStream)


# Generated at 2022-06-25 15:06:53.685901
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # testing Untokenizer.untokenize
    untokenizer_0 = Untokenizer()
    tokener_0 = generate_tokens("")
    untokenizer_0.untokenize(tokener_0)


# Generated at 2022-06-25 15:06:54.347305
# Unit test for function tokenize_loop
def test_tokenize_loop():
    tokenize_loop(foo, printtoken)
    pass


# Generated at 2022-06-25 15:06:59.928124
# Unit test for function generate_tokens
def test_generate_tokens():
    source = """
my_variable = 3
my_tuple=('tuple elements',)
my_tuple=('tuple elements',)
my_tuple=('tuple elements',)
"""
    tokens = list(tokenize.generate_tokens(StringIO(source).readline))


# Generated at 2022-06-25 15:07:01.712958
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer_0 = Untokenizer()
    assert type(untokenizer_0.untokenize([(1, 'a')])) == str


# Generated at 2022-06-25 15:07:13.199683
# Unit test for function detect_encoding
def test_detect_encoding():
    # Checks that encoding is detected correctly
    def check(reader, expected):
        real, lines = detect_encoding(reader)
        if real != expected:
            raise AssertionError(
                'Expected "%s", got "%s"\nLines:\n%r' % (expected, real, lines)
            )


# Generated at 2022-06-25 15:07:14.903676
# Unit test for function tokenize
def test_tokenize():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE, verbose=True)



# Generated at 2022-06-25 15:07:17.433502
# Unit test for function generate_tokens
def test_generate_tokens():
    Generate_tokens_0 = generate_tokens(open('test_generate_tokens.txt').readline)
    Generate_tokens_1 = generate_tokens(open('test_generate_tokens.txt').readline)


# Generated at 2022-06-25 15:07:19.929938
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer_0 = Untokenizer()
    assert untokenizer_0.prev_row == 1
    assert untokenizer_0.prev_col == 0
    start_0 = [2,2]
    untokenizer_0.add_whitespace(start_0)
    assert untokenizer_0.prev_row == 2
    assert untokenizer_0.prev_col == 2
