

# Generated at 2022-06-25 15:00:23.139281
# Unit test for function generate_tokens

# Generated at 2022-06-25 15:00:32.344872
# Unit test for function tokenize_loop
def test_tokenize_loop():

    test_input_1 = [
        ("#tokeneater\n", COMMENT),
        ("def foo(x: int) -> int:\n", NAME, LPAR, NAME, COLON, NAME, RPAR, ARROW, NAME, COLON),
        ("    x += 1\n", INDENT, NAME, PLUSEQUAL, NUMBER),
        ("    return x\n", NAME, NEWLINE),
        ("\n", NEWLINE, DEDENT),
    ]

    def tokeneater(type, token, xxx_todo_changeme, xxx_todo_changeme1, line):
        (srow, scol) = xxx_todo_changeme
        (erow, ecol) = xxx_todo_changeme1
        assert (type, token) == test_

# Generated at 2022-06-25 15:00:45.189340
# Unit test for function generate_tokens

# Generated at 2022-06-25 15:00:50.182742
# Unit test for function generate_tokens

# Generated at 2022-06-25 15:01:00.732524
# Unit test for function generate_tokens
def test_generate_tokens():
    input_string : str = "for i in range(10):\n    print(i)\n"
    input_string_iter: Iterator[str] = iter(input_string.splitlines())
    tokens_0: Iterator[TokenInfo] = generate_tokens(input_string_iter.__next__)

    # Reference values
    ref_token_type : List[int] = [NAME, NAME, OP, NAME, OP, NUMBER, OP, NAME, OP, NL, INDENT, NAME, OP, NAME, OP, OP, NUMBER, OP, OP, NL, DEDENT, ENDMARKER]

# Generated at 2022-06-25 15:01:08.781665
# Unit test for function generate_tokens
def test_generate_tokens():
    program = '''
    x = 3
    # This is a comment
    '''
    tokens = list(generate_tokens(program.splitlines))
    assert len(tokens) == 7
    assert tokens[0] == (1, 'x', (1, 4), (1, 5), 'x = 3')
    assert tokens[1] == (53, ' ', (1, 5), (1, 6), 'x = 3')
    assert tokens[2] == (61, '=', (1, 6), (1, 7), 'x = 3')
    assert tokens[3] == (53, ' ', (1, 7), (1, 8), 'x = 3')
    assert tokens[4] == (2, '3', (1, 8), (1, 9), 'x = 3')

# Generated at 2022-06-25 15:01:10.235719
# Unit test for function tokenize_loop
def test_tokenize_loop():
    test_case_0()


# Generated at 2022-06-25 15:01:12.862838
# Unit test for function generate_tokens
def test_generate_tokens():
    data = untokenize(tokenize(test_input_0))
    if data == test_input_0:
        print('test_generate_tokens passed')
    else:
        print('test_generate_tokens failed')
        print(data)


# Generated at 2022-06-25 15:01:19.831902
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Make sure tokenize_loop works with a real readline-like callback.
    import io
    import io as io
    import io as io
    import io as io
    import io as io
    import io as io
    import io as io
    import io as io
    import io as io
    import io as io
    import io as io
    import io as io
    import io as io

# Generated at 2022-06-25 15:01:28.660369
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test with no lines.
    iterable_0 = [iter(())];
    # Call function detect_encoding
    try:
        result_0 = detect_encoding(iterable_0[0].__next__)
    except StopIteration:
        result_0 = None
    assert (result_0 == ("utf-8", []))
    # Test with only a BOM
    iterable_1 = [iter((b'\xef\xbb\xbf',))];
    # Call function detect_encoding
    try:
        result_1 = detect_encoding(iterable_1[0].__next__)
    except StopIteration:
        result_1 = None
    assert (result_1 == ('utf-8-sig', []))
    # Test with only a cookie