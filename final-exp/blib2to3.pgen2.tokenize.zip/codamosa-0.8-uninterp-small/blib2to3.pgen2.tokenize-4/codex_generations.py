

# Generated at 2022-06-25 14:59:29.614900
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from .tokenize import (untokenize, TokenInfo, NUMBER, NEWLINE, INDENT, DEDENT)
    token_info_0 = (NUMBER, '2')
    token_info_1 = (NEWLINE, '\n')
    token_info_2 = (INDENT, '  |')
    token_info_3 = (NUMBER, '3')
    token_info_4 = (DEDENT, '|')
    token_info_5 = (NEWLINE, '\n')
    token_info_6 = (NUMBER, '4')
    token_info_7 = (NEWLINE, '\n')
    token_info_8 = IndentationError()
    token_info_9 = (INDENT, '  |')
    token_info_10 = (NUMBER, '5')
    token

# Generated at 2022-06-25 14:59:34.241320
# Unit test for function printtoken
def test_printtoken():
    import io
    import sys
    import re
    from test.support import captured_stdout
    from blib2to3.pgen2 import token
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2.tokenize import (
        group,
        StopTokenizing,
        TokenError,
        tok_name,
        printtoken,
        generate_tokens,
    )

    eoln = re.compile(r"\r\n?")
    string_prefix = group("b", "B", "r", "R")


# Generated at 2022-06-25 14:59:36.874649
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    token_error_0 = TokenError()
    def freadline(): return "var_0 = group()"
    var_0 = group()

    def tokeneater(*a):
        print(a)

    readline = freadline
    tokeneater = tokeneater

    try:
        tokenize_loop(readline, tokeneater)
    except StopTokenizing:
        pass



# Generated at 2022-06-25 14:59:41.447306
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer = Untokenizer()
    unt_0 = untokenizer
    var_1 = unt_0

    var_2 = untokenizer.untokenize([])
    var_3 = untokenizer.untokenize([(1, '1')])
    var_4 = untokenizer.untokenize([(1, '1'), (2, '2')])
    var_5 = untokenizer.untokenize([(1, '1'), (2, '2'), (3, '3')])
    var_6 = untokenizer.untokenize([(1, '1'), (2, '2'), (3, '3'), (4, '4')])

# Generated at 2022-06-25 14:59:42.410738
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer_0 = Untokenizer()
    untokenizer_0.compat(('', ''), [])

# Generated at 2022-06-25 14:59:43.623857
# Unit test for function generate_tokens
def test_generate_tokens():
    var_0 = generate_tokens(function)
    add(var_0, var_0)


# Generated at 2022-06-25 14:59:50.276591
# Unit test for function printtoken
def test_printtoken():
    arg1 = 14
    arg2 = "var_0"
    arg3 = (1, 2,)
    arg4 = (3, 4,)
    arg5 = "line_5"
    printtoken(arg1, arg2, arg3, arg4, arg5)
    #print(arg1, arg2, arg3, arg4, arg5)

# Generated at 2022-06-25 14:59:56.976014
# Unit test for function tokenize_loop
def test_tokenize_loop():
    print(
        "Paragraph 1\n"
        "Paragraph 2\n"
        "Paragraph 3\n"
        + "Paragraph 4"
    )
    # string_io = BytesIO(b'Paragraph 1\nParagraph 2\nParagraph 3\nParagraph 4')
    # assert tokenize(string_io.readline) ==
    # 'Paragraph'
    # 1
    # 'Paragraph'
    # 2
    # 'Paragraph'
    # 3
    # 'Paragraph'
    # 4
    return None


# Generated at 2022-06-25 15:00:03.929456
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    var_0 = Untokenizer()
    var_1 = [
        (  # tuple
        ),
        (  # tuple
        ),
    ]

# Generated at 2022-06-25 15:00:08.712247
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from sys import stdout
    from blib2to3.pgen2.tokenize import tabsize, tokenize_loop, untokenize, TokenError
    filename = 'test.py'
    s = "class E: pass\n"
    try:
        tokenize_loop(StringIO(s).readline, None)
    except TokenError:
        pass
    else:
        pass
    var_0 = group()
    var_1 = group()
    var_2 = group()
    var_3 = group()
    var_4 = group()
    var_5 = group()
    var_6 = group()


# Generated at 2022-06-25 15:00:41.463824
# Unit test for function tokenize
def test_tokenize():
    untokenizer_0 = untokenize
    tokenize_loop_0 = tokenize_loop
    tokeneater_0 = printtoken
    readline_0 = input
    tokenize_0 = tokenize
    generated_tokens_0 = generate_tokens
    # test code
    generated_tokens_0(readline_0)
    tokenize_loop_0(readline_0, tokeneater_0)
    untokenizer_0.untokenize(generated_tokens_0(readline_0))
    tokenize_0(readline_0, tokeneater_0)
    # test case:
    class_0 = Token
    def_0 = Token
    while_0 = Token
    name_0 = Token
    colon_0 = Token
    number_0 = Token

# Generated at 2022-06-25 15:00:51.429987
# Unit test for function generate_tokens
def test_generate_tokens():
    line = "line1\n  line2\n"
    result = list(generate_tokens(iter(line.splitlines()).__next__, None))
    assert result == [
        (INDENT, "", (1, 0), (1, 2), "line1\n"),
        (NAME, "line2", (2, 2), (2, 7), "  line2\n"),
        (DEDENT, "", (3, 0), (3, 0), ""),
        (ENDMARKER, "", (3, 0), (3, 0), ""),
    ]



# Generated at 2022-06-25 15:00:56.134947
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        '''Emulates readline method of a file object'''
        return '# -*- coding: utf-8 -*-'
    assert detect_encoding(readline) == ('utf-8', ['# -*- coding: utf-8 -*-'])


# Generated at 2022-06-25 15:01:01.412017
# Unit test for function generate_tokens
def test_generate_tokens():
    def _test():
        toks = generate_tokens(Tokenizer("a = 1").readline)
        print(toks)
        for tok in toks:
            print(tok)
    _test()
    toks = generate_tokens(Tokenizer("\n").readline)
    print(toks)
    for tok in toks:
        print(tok)


# Generated at 2022-06-25 15:01:09.157765
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    # Bytes for "a" in cp1252
    test_case_0_data = (0x61)
    f_0 = io.BytesIO(bytes([test_case_0_data,]))
    f_0_readline = f_0.readline
    test_case_0 = detect_encoding(f_0_readline)
    assert test_case_0 == ('cp1252', [bytes([test_case_0_data,]),])

    # Bytes for "a" in cp1252
    test_case_1_data = (0x61)
    f_1 = io.BytesIO(bytes([test_case_1_data,]))
    f_1_readline = f_1.readline

# Generated at 2022-06-25 15:01:11.676377
# Unit test for function tokenize_loop
def test_tokenize_loop():
    for i in range(4):
        continue
    def fn(x):
        print(x)
    fn(3)

# Generated at 2022-06-25 15:01:17.400948
# Unit test for function generate_tokens
def test_generate_tokens():
    import cStringIO
    from tokenize import generate_tokens, tok_name
    from tokenize import INDENT, DEDENT, COMMENT, NEWLINE
    from tokenize import ENDMARKER, STRING
    test_string = '"def"\n'
    test_string += "if foo:\n"
    test_string += "    bar()\n"
    test_string += "\n"
    test_string += '"""# comment "bar"\n'
    test_string += 'def"\n'
    test_string += "if foo:\n"
    test_string += "    bar()\n"
    test_string += '\n'
    test_string += '    # comment"\n'
    test_string += '    def"\n'

# Generated at 2022-06-25 15:01:27.319905
# Unit test for function detect_encoding
def test_detect_encoding():

    def str_iterator(str1: str) -> Iterator[bytes]:
        for char in str1:
            yield bytes(char, encoding="utf-8")

    def case_0():
        """
        Valid UTF-8 without BOM
        """
        test_data = "utf-8"
        for i in range(len(test_data)):
            str1 = test_data[:i+1]
            print(str1)
            print(detect_encoding(str_iterator(str1)))
        return

    def case_1():
        """
        Valid utf-8 with BOM
        """
        test_data = "utf-8"
        for i in range(len(test_data)):
            str1 = "\ufeff" + test_data[:i + 1]

# Generated at 2022-06-25 15:01:33.599179
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer_1 = Untokenizer()
    untokenizer_1.add_whitespace((1,0))
    untokenizer_1.add_whitespace((2,0))
    untokenizer_1.add_whitespace((2,2))
    untokenizer_1.add_whitespace((1,0))
    untokenizer_1.add_whitespace((2,2))
    untokenizer_1.add_whitespace((3,1))
    untokenizer_1.add_whitespace((2,2))
    untokenizer_1.add_whitespace((2,2))


# Generated at 2022-06-25 15:01:44.382949
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    test_string = "#!"


# Generated at 2022-06-25 15:02:35.414416
# Unit test for function generate_tokens
def test_generate_tokens():
    # Make sure it works for empty string or just newlines
    gtokens = list(generate_tokens(iter(["", "\n", "\n\n\n"]).__next__))
    assert gtokens == [(1, '\n'), (1, '\n'), (1, '\n'), (4, '\n')]

    # Make sure it works with just whitespace
    gtokens = list(generate_tokens(iter(["    ", "\t\t"]).__next__))
    assert gtokens == [(1, '    '), (1, '\t\t')]

    # Make sure it works with leading whitespace and then newlines

# Generated at 2022-06-25 15:02:39.172361
# Unit test for function tokenize_loop
def test_tokenize_loop():
    pass
    # untokenizer_0 = Untokenizer()

    # def tokeneater_0(a,b,c,d,e):
    #     print(a,b,c,d,e)
    
    # readline_0 = lambda : '# TEST 123\n'
    # tokenize_loop(readline_0, tokeneater_0)


# Generated at 2022-06-25 15:02:42.196083
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.untokenize([(1, "foo"), (1, "bar"), (2, "baz")])
    untok.tokens.clear()
    untok.untokenize([(1, "foo"), (2, ""), (2, "bar"), (2, "baz")])


# Generated at 2022-06-25 15:02:45.499919
# Unit test for function detect_encoding
def test_detect_encoding():
    data = bytes("# coding: utf-8\n", 'utf-8')
    encoding, lines = detect_encoding(data.__iter__().__next__)
    assert(encoding == 'utf-8')


# Generated at 2022-06-25 15:02:57.278983
# Unit test for function generate_tokens
def test_generate_tokens():
    # unit test for function generate_tokens()
    import token
    import io

    def test_case_1():
        for t in generate_tokens(io.StringIO("#comment").readline):
            if t[0] == token.COMMENT:
                # print(t[4].strip('\n'))
                pass
            else:
                # print(''.join(tok for _, tok,_,_,_ in generate_tokens(io.StringIO('#comment').readline)))
                __import__('_ast').parse(''.join(tok for _, tok, _, _, _ in generate_tokens(
                    io.StringIO('#comment').readline)))


    def test_case_2():
        # unit test for function generate_tokens()
        import token

# Generated at 2022-06-25 15:03:08.326494
# Unit test for function generate_tokens

# Generated at 2022-06-25 15:03:16.695780
# Unit test for function generate_tokens
def test_generate_tokens():
    for grammar in (None, PythonGrammar(), Python2Grammar(), Python3Grammar()):
        s = "1234"
        first_token = next(generate_tokens(s.encode().splitlines(True), grammar))
        assert first_token == (1, "1234")
        assert first_token[1] == "1234"
        assert first_token[-1] == "1234"
        # The second item in the tuple is the line that the token appears on.
        # It is not included in the "repr" of the token, and it is not
        # included in the "str" of the token.
        assert repr(first_token) == "(1, '1234')"
        assert str(first_token) == "(1, '1234')"

        # A few "repr

# Generated at 2022-06-25 15:03:20.492871
# Unit test for function tokenize
def test_tokenize():
    s = """
a = 1 + 2
print(a)
"""
    tokeneater = lambda a, b, c, d, e: print((a, b, c, d, e))
    tokenize(s.splitlines().__iter__(), tokeneater)


# Generated at 2022-06-25 15:03:32.078135
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer_0 = Untokenizer()
    good_token_info_0 = (1, '', (1, 0), (1, 0), '')
    token_info_0 = (1, '')
    good_token_info_1 = (2, '', (1, 0), (1, 0), '')
    token_info_1 = (2, '')
    good_token_info_2 = (3, '', (1, 0), (1, 0), '')
    token_info_2 = (3, '')
    good_token_info_3 = (4, '', (1, 0), (1, 0), '')
    token_info_3 = (4, '')
    good_token_info_4 = (5, '', (1, 0), (1, 0), '')


# Generated at 2022-06-25 15:03:38.777618
# Unit test for function tokenize_loop
def test_tokenize_loop():
  import io

# Generated at 2022-06-25 15:05:16.982646
# Unit test for function detect_encoding
def test_detect_encoding():
    assert detect_encoding(iter(["# coding: utf-8"]).__next__) == ("utf-8", ["# coding: utf-8"])
    assert detect_encoding(iter(["# coding=utf-8"]).__next__) == ("utf-8", ["# coding=utf-8"])
    assert detect_encoding(iter(["# coding: iso-latin-1"]).__next__) == ("iso-8859-1", ["# coding: iso-latin-1"])
    assert detect_encoding(iter(["# coding=iso-latin-1"]).__next__) == ("iso-8859-1", ["# coding=iso-latin-1"])

# Generated at 2022-06-25 15:05:20.191283
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    test_string = """
# -*- coding: utf-8 -*-
"""
    test_file = io.StringIO(test_string)
    test_readline = test_file.readline
    default, lines = detect_encoding(test_readline)
    print(default, lines)


# Generated at 2022-06-25 15:05:22.568342
# Unit test for function generate_tokens
def test_generate_tokens():
    # TODO: Figure out how to test this function
    pass


# Generated at 2022-06-25 15:05:29.889045
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    unt_0 = Untokenizer()
    unt_0.compat((COMMENT, '#comment'))
    unt_0.compat((NAME, 'name'))
    unt_0.compat((NAME, 'name'), [])
    unt_0.compat((NAME, 'name'), [(NAME, 'name'), (NAME, 'name')])
    unt_0.compat((NAME, 'name'), [(NAME, 'name'), (NUMBER, 1.0)])
    unt_0.compat((NAME, 'name'), [(NAME, 'name'), (NUMBER, 1.0), (NAME, 'name')])
    unt_0.compat((NAME, 'name'), [(NAME, 'name'), (NUMBER, 1.0), (NAME, 'name')])

# Generated at 2022-06-25 15:05:39.433492
# Unit test for function detect_encoding
def test_detect_encoding():
    import tokenize

    def test_readline(line_seq):
        def readline():
            return line_seq.pop(0)

        return readline

    # Check BOM detection
    encoding, lines = tokenize.detect_encoding(
        test_readline(
            [
                b"\xef\xbb\xbf# coding=utf-8\n",
                b"# test\n",
                b"def foo():\n",
                b"    pass\n",
                b"\n",
            ]
        )
    )
    if encoding != "utf-8-sig":
        raise AssertionError("Expected utf-8-sig, got " + encoding)

    # Check line counting

# Generated at 2022-06-25 15:05:44.531680
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens
    string_0 = "first line\nsecond line\n"
    lines_0 = io.StringIO(string_0)
    tokenize_0 = generate_tokens(lines_0.readline)
    next(tokenize_0)
    # assert(tokenize_0[0] == 'first line')


# Generated at 2022-06-25 15:05:52.563217
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # Dummy
    untokenizer_0 = Untokenizer()
    # AssertionError

# Generated at 2022-06-25 15:06:02.719979
# Unit test for function tokenize
def test_tokenize():
    import token
    from io import BytesIO

    untok = Untokenizer()
    out = BytesIO()
    tokeneater = untok.untokenize

    def readline():
        return b""

    def check(input, expected):
        out.seek(0)
        out.truncate()
        untok.reset()
        tokenize(BytesIO(input).readline, tokeneater)
        got = out.getvalue()
        assert got == expected, (got, expected)

    def check_unknown_encoding(input, expected):
        out.seek(0)
        out.truncate()
        untok.reset()
        test_tokenize.old_lookup = token.ENCODING_INPUT_HOOK

# Generated at 2022-06-25 15:06:10.282650
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"1"
        yield b"#"
        yield b" "
        yield b"coding:   utf-8"

    detect_encoding(readline())
    # test utf-8-sig
    def readline_1():
        yield b"\uFEFF"
        yield b"2"
        yield b"#"
        yield b" "
        yield b"coding:  utf-8-sig"

    detect_encoding(readline_1())
    # test iso-8859-1
    def readline_3():
        yield b"3"
        yield b"#"
        yield b" "
        yield b"coding:  iso-8859-1"

    detect_encoding(readline_3())
    # test iso-

# Generated at 2022-06-25 15:06:15.990287
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    test_0 = generate_tokens(lambda :'')
    for i in range(100000):
        test_1 = Untokenizer()
        test_2 = [i for i in test_0]
        untokenizer_1 = test_1.untokenize(test_2)
        assert isinstance(untokenizer_1, str)


# Generated at 2022-06-25 15:07:13.701054
# Unit test for function tokenize
def test_tokenize():
    import io
    tokenize(io.StringIO("hello world\n").readline)
    tokenize(io.StringIO("#hello world\n").readline)
    tokenize(io.StringIO("#hello world").readline)
    tokenize(io.StringIO("#hello world\x01").readline)
    tokenize(io.StringIO("1234#hello world\x01").readline)
    tokenize(io.StringIO("\"\"\"test\nworld\r\n\"\"\"").readline)
    tokenize(io.StringIO("\"\"\"test\nworld\r\n\"\"\"\"\"\"").readline)
    tokenize(io.StringIO("\"\"\"test\nworld\r\n\"\"\"\"\"\"\n").readline)

# Generated at 2022-06-25 15:07:16.639598
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer_0 = test_case_0()
    iterable_0 = ((0, ""), (0, " "), (0, ""))
    token_0 = (0, "")
    untokenizer_0.compat(token_0, iterable_0)



# Generated at 2022-06-25 15:07:17.995697
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # We simulate the `import tokenize` line, thus the rest of the file is
    # tested.
    import tokenize
    tokenize.tokenize_loop(test_case_0, tokenize_loop)



# Generated at 2022-06-25 15:07:23.546645
# Unit test for function detect_encoding
def test_detect_encoding():
    lines = [
        b"# -*- coding: utf-8 -*-\n",
        b"def foo():\n",
        b"    print('foo')\n",
    ]
    encoding, lines = detect_encoding(iter(lines).__next__)
    #print(encoding)
    #print(lines)
    assert(encoding == 'utf-8')
    assert(lines == lines)



# Generated at 2022-06-25 15:07:31.539014
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline1():
        yield b"# -*- coding: latin-1 -*-\n"
        with open("test/input/example.py", "rb") as ex:
            for line in ex:
                yield line
    def readline2():
        yield BOM_UTF8
        with open("test/input/example.py", "rb") as ex:
            for line in ex:
                yield line
    def readline3():
        yield BOM_UTF8
        yield B"# -*- coding: latin-1 -*-\n"
        with open("test/input/example.py", "rb") as ex:
            for line in ex:
                yield line

    output = detect_encoding(readline1)
    assert output[0] == "iso-8859-1"
   

# Generated at 2022-06-25 15:07:34.768231
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield bytes("# coding: utf-8", encoding="utf-8")
        yield bytes("print('Hello, World')", encoding="utf-8")

    assert detect_encoding(readline) == ("utf-8", [b"# coding: utf-8"])
    return 0


# Generated at 2022-06-25 15:07:44.044577
# Unit test for function generate_tokens
def test_generate_tokens():
    # TODO: test module-level functions with a custom grammar.
    def roundtrip(s: Text) -> Text:
        """Round-trip a string through the tokenizer and untokenizer."""
        type_mapping = {
            tokenize.NUMBER: NUMBER,
            tokenize.STRING: STRING,
            tokenize.NEWLINE: NEWLINE,
            tokenize.INDENT: INDENT,
            tokenize.DEDENT: DEDENT,
            tokenize.NAME: NAME,
            tokenize.ERRORTOKEN: ERRORTOKEN,
            tokenize.NL: NL,
            tokenize.COMMENT: COMMENT,
            tokenize.ENCODING: ENCODING,
        }

# Generated at 2022-06-25 15:07:49.229927
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test untokenize on a file
    f = open("untokenize_01.py")
    t1 = [tok[:2] for tok in generate_tokens(f.readline)]
    ut = Untokenizer()
    ut.untokenize(t1)
    f.close()


# Generated at 2022-06-25 15:07:58.735276
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline0() -> bytes:
        return b"#! /usr/bin/env python3\n"

    def readline1() -> bytes:
        return b"#\xf1"

    def readline2() -> bytes:
        return b"#\xf1a"

    def readline3() -> bytes:
        return b"#\n"

    def readline4() -> bytes:
        return b""

    def readline5() -> bytes:
        return b""

    def readline6() -> bytes:
        return b""

    def readline7() -> bytes:
        return b"#! /usr/bin/env python3\n# -*- coding: utf-8 -*-\n"

    def readline8() -> bytes:
        return b""

    # Non UTF-8 BOM

# Generated at 2022-06-25 15:07:59.900610
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Just call the function
    tokenize_loop(None, None)
