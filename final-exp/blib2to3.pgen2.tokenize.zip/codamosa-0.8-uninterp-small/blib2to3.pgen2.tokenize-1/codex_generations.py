

# Generated at 2022-06-25 15:00:51.802982
# Unit test for function tokenize
def test_tokenize():
    test_case_0()
    print('test_tokenize succeeded!')


# Generated at 2022-06-25 15:00:55.745890
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    var_0 = Untokenizer()
    var_0.prev_row = 1
    var_0.prev_col = 1
    var_1 = (2, 2)
    var_0.add_whitespace(var_1)


# Generated at 2022-06-25 15:01:05.337221
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test a simple ascii file with no encoding comment
    def ascii_lines() -> Iterator[str]:
        yield "for _i in range(1):"
        yield "    print(_i)"
    encoding, lines = detect_encoding(lambda: ascii_lines())
    assert encoding == "utf-8"
    assert lines == ["for _i in range(1):", "    print(_i)"]

    # Test a file with an encoding comment, utf-8 bom
    def utf8_with_bom_lines() -> Iterator[str]:
        yield "# coding=utf-8"
        yield "for _i in range(1):"
        yield "    print(_i)"
    encoding, lines = detect_encoding(lambda: utf8_with_bom_lines())

# Generated at 2022-06-25 15:01:11.960567
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    var_0 = generate_tokens(lambda : None)
    var_1 = Untokenizer()
    with pytest.raises(StopTokenizing):
        var_1.untokenize(var_0)



# Generated at 2022-06-25 15:01:22.985189
# Unit test for function detect_encoding

# Generated at 2022-06-25 15:01:27.318580
# Unit test for function tokenize_loop
def test_tokenize_loop():
    test_lines = [
    "test line 1",
    "test line 2",
    "test line 3",
    ]
    def readline():
        try:
            return test_lines.pop(0) + '\n'
        except IndexError:
            return None
    tokeneater = printtoken
    tokenize_loop(readline, tokeneater)


# Generated at 2022-06-25 15:01:27.851788
# Unit test for function generate_tokens

# Generated at 2022-06-25 15:01:30.195509
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def generator(): yield 1
    def tokeneater(token_type,token,srow,scol,erow,ecol,line):
        print(srow,scol,erow,ecol,line)

    tokenize_loop(generator,tokeneater)


# Generated at 2022-06-25 15:01:38.004636
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def function_1(readline, tokeneater):
        for var_0 in generate_tokens(readline):
            tokeneater(*var_0)

    def function_2(readline, tokeneater):
        for var_1 in generate_tokens(readline):
            var_10 = var_1[:4]
            var_11 = var_1[4:]
            tokeneater(*var_10, var_11)

    def function_3(readline, tokeneater):
        for var_2 in generate_tokens(readline):
            var_10 = var_2[:4]
            var_11 = var_2[4:]
            tokeneater(var_11, *var_10)


# Generated at 2022-06-25 15:01:47.346319
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline_mock(data: bytes) -> Callable[[], bytes]:
        i = 0

        def readline() -> bytes:
            nonlocal i
            i += 1
            return data[i - 1 : i]

        return readline

    def test(data: bytes, expected_encoding: str, expected_rest: bytes) -> None:
        encoding, rest = detect_encoding(readline_mock(data))
        assert encoding == expected_encoding
        assert rest == expected_rest

    test(b"# coding: latin-1\n", "latin-1", b"")
    test(b"# coding: latin-1\nbanana", "latin-1", b"banana")

# Generated at 2022-06-25 15:02:15.192871
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    start = (1, 2)
    untokenizer_add_whitespace_0 = Untokenizer()
    untokenizer_add_whitespace_0.add_whitespace(start)


# Generated at 2022-06-25 15:02:19.448711
# Unit test for function tokenize_loop
def test_tokenize_loop():
    fn_name = tokenize_loop.__name__

    # Case 0
    try:
        test_case_0()
        assert False
    except TypeError:
        pass
    # Case 1
    # Write a test case here
    return 0



# Generated at 2022-06-25 15:02:21.275986
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # test basic case
    test_case_0()


# Generated at 2022-06-25 15:02:25.289029
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    """Tests that untokenizing tokens is the identity"""
    ut = Untokenizer()
    tokens = list(generate_tokens(iter([''])))
    result = ut.untokenize(tokens)
    for t in tokens:
        assert t[1] == result[t[2][1]:t[3][1]]


# Generated at 2022-06-25 15:02:33.827980
# Unit test for function detect_encoding
def test_detect_encoding():
    print('Testing detect_encoding()...', end=' ')
    # Test cases adapted from Lib/test/tokenize_tests.txt
    #
    # utf-8 bom, no encoding cookie
    assert detect_encoding(
        iter([BOM_UTF8 + b"a\ntext\na\n#comment\npass\n"]).__next__
    ) == ("utf-8-sig", [])
    # utf-8 bom, iso8859-1 encoding cookie
    assert detect_encoding(
        iter([BOM_UTF8 + b"# coding: iso8859-1\na = 3\n"]).__next__
    ) == ("utf-8-sig", [])
    # iso8859-1 encoding cookie, no utf-8 bom

# Generated at 2022-06-25 15:02:35.154947
# Unit test for function tokenize_loop
def test_tokenize_loop():
    test_case_0()


# Generated at 2022-06-25 15:02:37.077410
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.add_whitespace((1,1))
    assert u.tokens == [" "]


# Generated at 2022-06-25 15:02:38.416812
# Unit test for function tokenize_loop
def test_tokenize_loop():
    test_case_0()
    print("Unit tests for tokenize_loop are done\n")


# Generated at 2022-06-25 15:02:40.514918
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    text = "'.foo %s'"
    stream = StringIO(text)
    untokenized = untokenize(tokenize(stream.readline))
    assert text == untokenized


# Generated at 2022-06-25 15:02:53.275914
# Unit test for function tokenize_loop
def test_tokenize_loop():
    line_number = 0
    def readline():
        nonlocal line_number
        line_number = line_number + 1
        return f"line number: {line_number}".encode()
    token_list = []
    def tokeneater(*args):
        token_list.append(args)
    tokenize_loop(readline, tokeneater)
    assert len(token_list)==5
    assert token_list[0][1]==b"line"
    assert token_list[0][0]==token.NAME
    assert token_list[1][1]==b"number"
    assert token_list[1][0]==token.NAME
    assert token_list[2][1]==b":"
    assert token_list[2][0]==token.OP

# Generated at 2022-06-25 15:03:19.626867
# Unit test for function detect_encoding
def test_detect_encoding():
    doctest.testmod()



# Generated at 2022-06-25 15:03:31.472039
# Unit test for function generate_tokens
def test_generate_tokens():
    normal_case_0 = lambda : [x for x in range(10)]
    token_result_0 = list(generate_tokens(normal_case_0))

# Generated at 2022-06-25 15:03:33.078286
# Unit test for function detect_encoding
def test_detect_encoding():
    assert detect_encoding(None) == ('utf-8-sig', [])


# Generated at 2022-06-25 15:03:39.313292
# Unit test for function tokenize_loop
def test_tokenize_loop():
    print("Testing tokenize_loop...", end="")
    stream = iter(["a = 1 + 2\n", "b = (3 + 4) * 2\n", "c = -5 * 2 + 1\n"])
    result = []

# Generated at 2022-06-25 15:03:49.132149
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test case to test whether the function generate token works
    # input is a string
    # output is a list of tokens
    line = "def add(a,b): return a + b"
    lines = line.splitlines()

    def readline():
        return lines.pop(0)

    tokenGen = generate_tokens(readline)

    for tok in tokenGen:
        print(tok)

    print("Output:")
    output_str = ""
    output_str += "Token type: " + str(tok[0]) + "\n"
    output_str += "Token string: " + tok[1] + "\n"
    output_str += "Start position: line: " + str(tok[2][0]) + " column: " + str(tok[2][1]) + "\n"

# Generated at 2022-06-25 15:03:54.075196
# Unit test for function detect_encoding
def test_detect_encoding():
    assert detect_encoding(lambda : b'') == ('utf-8', [])
    assert detect_encoding(lambda : b'# coding: utf-8') == ('utf-8', [b'# coding: utf-8'])
    assert detect_encoding(lambda : b'\xEF\xBB\xBF# coding: utf-8') == ('utf-8-sig', [b'\xEF\xBB\xBF# coding: utf-8'])
    assert detect_encoding(lambda : b'# coding: latin-1') == ('iso-8859-1', [b'# coding: latin-1'])

# Generated at 2022-06-25 15:03:55.564346
# Unit test for function generate_tokens
def test_generate_tokens():
    test_gen = generate_tokens(iter(['']).__next__)
    try:
        next(test_gen)
    except Exception as exc:
        print(exc)


# Generated at 2022-06-25 15:03:57.194939
# Unit test for function generate_tokens
def test_generate_tokens():
    tokens_0 = []
    def readline_0():
        tokens_0.append('def foo():')
        tokens_0.append('    return')
    generate_tokens(readline_0)


# Generated at 2022-06-25 15:03:58.083025
# Unit test for function tokenize_loop
def test_tokenize_loop():
    test_case_0()


# Generated at 2022-06-25 15:04:00.433142
# Unit test for function generate_tokens
def test_generate_tokens():
    # TODO: Add tests that ensure that the correct line number & column
    #       number is produced for each token
    with open("./test.py") as f:
        readline = f.readline
        for token in generate_tokens(readline):
            print(token)


if __name__ == "__main__":
    test_case_0()
    test_generate_tokens()

# Generated at 2022-06-25 15:04:50.231265
# Unit test for function tokenize_loop
def test_tokenize_loop():
    line = ["def hello():\n", "  print()\n"]
    def tokenize_loop_1():
        nonlocal line
        return line.pop()
    test_tokenize_loop_1 = 0
    def tokenize_loop_2(arg1, arg2, arg3, arg4, arg5):
        nonlocal test_tokenize_loop_1
        test_tokenize_loop_1 += 1
        return None
    tokenize_loop(tokenize_loop_1, tokenize_loop_2)
    return test_tokenize_loop_1


# Generated at 2022-06-25 15:04:59.230848
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    #     test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    u.untokenize(iter(()))
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
   

# Generated at 2022-06-25 15:05:08.544383
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from . import token
    from . import ISTERMINAL, ISNONTERMINAL, ISEOF
    from .pgen2.token import token_map
    from .pgen2 import grammar

    def check_untokenize(grammar):
        for t in grammar.symbol2number.keys():
            if not (token_map[t] == ISTERMINAL or token_map[t] == ISNONTERMINAL or token_map[t] == ISEOF):
                raise Exception("Type specification error: " + t)

        g = token.untokenize(token.tokenize(grammar.str))

        if g == grammar.str:
            return True

        return False

    assert check_untokenize(grammar)

# Generated at 2022-06-25 15:05:17.705152
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline_mock(line):
        def readline() -> bytes:
            return line.encode()
        return readline

    assert detect_encoding(readline_mock("")) == ("utf-8", [])
    assert detect_encoding(readline_mock("# coding: latin-1")) == ("iso-8859-1", [])
    assert detect_encoding(readline_mock("bcoding: latin-1")) == ("utf-8", [])
    assert detect_encoding(readline_mock("# coding: utf-8\n#bla")) == ("utf-8", ["# coding: utf-8".encode()])
    assert detect_encoding(readline_mock("# coding=latin-1")) == ("iso-8859-1", [])
   

# Generated at 2022-06-25 15:05:26.607032
# Unit test for function detect_encoding

# Generated at 2022-06-25 15:05:27.353606
# Unit test for function tokenize_loop
def test_tokenize_loop():
    test_case_0()


# Generated at 2022-06-25 15:05:28.110488
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    test_case_0()


# Generated at 2022-06-25 15:05:33.524712
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer = Untokenizer()
    untokenizer.untokenize([(1, 'hello', (1,0), (1,5), 'hello'), (2, ' ', (1,5), (1,6), ' '), (4, 'ladies', (1,6), (1,12), 'ladies'), (5, ' ', (1,12), (1,13), ' '), (5, 'and', (1,13), (1,16), 'and'), (5, ' ', (1,16), (1,17), ' '), (6, 'gentlemen', (1,17), (1,26), 'gentlemen'), (5, ' ', (1,26), (1,27), ' '), (7, '.', (1,27), (1,28), '.')])


# Generated at 2022-06-25 15:05:35.476050
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # The token to be untokenized is a special case of TokenInfo
    untokenizer_0 = Untokenizer()
    untokenizer_0.untokenize(())


# Generated at 2022-06-25 15:05:45.086930
# Unit test for function tokenize
def test_tokenize():
    text = "if True: print('hello')"
    lines = iter(text.splitlines(True))
    tok = []

    def tokeneater(*args):
        tok.append(args)

    tokenize(lines.__next__, tokeneater)

# Generated at 2022-06-25 15:07:52.607704
# Unit test for function detect_encoding
def test_detect_encoding():
    assert detect_encoding(test_case_0) == ('utf-8', [])



# Generated at 2022-06-25 15:07:57.511112
# Unit test for function tokenize
def test_tokenize():
    try:
        test_case_0()
    except TypeError:
        pass

try:
    import builtins  # python 3.0+
except ImportError:
    import __builtin__ as builtins  # python 2.x
_builtin_open = builtins.open

__all__.append("detect_encoding")



# Generated at 2022-06-25 15:08:05.307665
# Unit test for function detect_encoding
def test_detect_encoding():
    """
    Unit test for function detect_encoding
    """
    def readline():
        yield bytes()
    assert detect_encoding(readline) == ("utf-8", [bytes()])

    def readline():
        yield BOM_UTF8
        yield bytes()
    assert detect_encoding(readline) == ("utf-8-sig", [BOM_UTF8])

    def readline():
        yield BOM_UTF8
        yield b"# coding: utf-8\n"
    assert detect_encoding(readline) == ("utf-8-sig", [BOM_UTF8])

    def readline():
        yield b"# coding: utf-8\n"
        yield BOM_UTF8

# Generated at 2022-06-25 15:08:14.423795
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline_ascii() -> bytes:
        return b"# -*- coding: utf-8 -*-\n"

    def readline_utf8() -> bytes:
        return BOM_UTF8 + b"# -*- coding: utf-8 -*-\n"

    def readline_utf8_sig() -> bytes:
        return BOM_UTF8 + b"# -*- coding: utf-8-sig -*-\n"

    # Ascii encoding
    assert detect_encoding(readline_ascii()) == ("utf-8", [b"# -*- coding: utf-8 -*-\n"])

    # utf-8 encoding

# Generated at 2022-06-25 15:08:16.040170
# Unit test for function tokenize_loop
def test_tokenize_loop():
    token_error_0 = None
    assert_raises(TypeError, tokenize_loop, token_error_0, None)



# Generated at 2022-06-25 15:08:20.815144
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer_0 = Untokenizer()
    iterable_0 = None
    token_0 = (ASYNC, 'async')
    untokenizer_0.compat(token_0, iterable_0)


# Generated at 2022-06-25 15:08:21.653124
# Unit test for function tokenize
def test_tokenize():
    assert tokenize(test_case_0()) == None

# Generated at 2022-06-25 15:08:28.822429
# Unit test for function detect_encoding
def test_detect_encoding():
    assert detect_encoding(lambda: b"")[0] == "utf-8"
    assert detect_encoding(lambda: b"# -*- coding: iso-8859-1 -*-\n")[0] == "iso-8859-1"
    assert detect_encoding(lambda: b"-*- coding: iso-8859-1 -*-\n")[0] == "utf-8"
    assert detect_encoding(lambda: b"# vim:fileencoding=iso-8859-1")[0] == "iso-8859-1"
    assert detect_encoding(lambda: b"; vim:fileencoding=iso-8859-1\n")[0] == "utf-8"

# Generated at 2022-06-25 15:08:29.891863
# Unit test for function tokenize_loop
def test_tokenize_loop():
    token_error_1 = None
    tokenize(token_error_1)



# Generated at 2022-06-25 15:08:30.662569
# Unit test for function tokenize
def test_tokenize():
    yield test_case_0,
