

# Generated at 2022-06-17 17:01:40.284547
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')

# Generated at 2022-06-17 17:01:51.763010
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", " "]
    u.add_whitespace((1, 3))
    assert u.tokens == [" ", " ", " "]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", " ", " ", "\n"]
    u.add_whitespace((2, 1))

# Generated at 2022-06-17 17:01:53.127050
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return "print('Hello World')"
    tokenize_loop(readline, printtoken)



# Generated at 2022-06-17 17:01:58.276824
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from io import BytesIO
    from tokenize import tokenize as tokenize_
    from tokenize import untokenize as untokenize_
    from tokenize import generate_tokens as generate_tokens_
    from tokenize import NL as NL_
    from tokenize import ENCODING as ENCODING_
    from tokenize import NAME as NAME_
    from tokenize import NUMBER as NUMBER_
    from tokenize import ASYNC as ASYNC_
    from tokenize import AWAIT as AWAIT_
    from tokenize import INDENT as INDENT_
    from tokenize import DEDENT as DEDENT_
    from tokenize import NEWLINE as NEWLINE_
    from tokenize import NL as NL_
    from tokenize import ENCODING as ENCODING

# Generated at 2022-06-17 17:02:03.477571
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import TokenInfo
    from blib2to3.pgen2.tokenize import Untokenizer
    from blib2to3.pgen2.tokenize import TokenError
    from blib2to3.pgen2.tokenize import StopTokenizing
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
   

# Generated at 2022-06-17 17:02:12.338488
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import NUMBER
    from tokenize import STRING
    from tokenize import NAME
    from tokenize import OP
    from tokenize import NEWLINE
    from tokenize import INDENT
    from tokenize import DEDENT
    from tokenize import COMMENT
    from tokenize import NL
    from tokenize import ENDMARKER
    from tokenize import TokenInfo
    from tokenize import TokenError
    from tokenize import token_name
    from tokenize import untokenize
    from tokenize import COMMENT
    from tokenize import tokenize
    from tokenize import generate_tokens
    from tokenize import NL
    from tokenize import TokenError

# Generated at 2022-06-17 17:02:22.095568
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import BytesIO
    from tokenize import tokenize as _tokenize
    from tokenize import untokenize as _untokenize
    from tokenize import generate_tokens as _generate_tokens

    def _test(input, output):
        f = BytesIO(input.encode("utf-8"))
        tokens = list(_tokenize(f.readline))
        f = io.StringIO()
        _untokenize(tokens, f.write)
        real = f.getvalue()
        if real != output:
            print("input:", repr(input))
            print("real: ", repr(real))
            print("expected:", repr(output))
            assert 0, "untokenize() produced bad output"


# Generated at 2022-06-17 17:02:32.313724
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3", (1, 0), (1, 1), "3")
    printtoken(STRING, "a", (1, 0), (1, 1), "a")
    printtoken(NEWLINE, "\n", (1, 0), (1, 1), "\n")
    printtoken(INDENT, "", (1, 0), (1, 1), "")
    printtoken(DEDENT, "", (1, 0), (1, 1), "")
    printtoken(NAME, "a", (1, 0), (1, 1), "a")
    printtoken(OP, "=", (1, 0), (1, 1), "=")
    printtoken(ERRORTOKEN, "a", (1, 0), (1, 1), "a")


# Generated at 2022-06-17 17:02:37.147028
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    s = "def f(x): return 2*x"
    f = StringIO(s).readline
    for t in generate_tokens(f):
        print(t)


# Generated at 2022-06-17 17:02:51.220342
# Unit test for function tokenize
def test_tokenize():
    import io
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize, NUMBER, NAME, OP
    readline = io.StringIO('for i in range(10): print(i)\n').readline
    tokens = list(generate_tokens(readline))
    assert tokens[1] == (NAME, 'for', (1, 0), (1, 3), 'for i in range(10): print(i)\n')
    assert tokens[2] == (NAME, 'i', (1, 4), (1, 5), 'for i in range(10): print(i)\n')
    assert tokens[3] == (NAME, 'in', (1, 6), (1, 8), 'for i in range(10): print(i)\n')

# Generated at 2022-06-17 17:03:28.822947
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(generate_tokens(io.StringIO(s).readline))

    def _names(tokens):
        return [tok_name[tok[0]] for tok in tokens]

    assert _names(_tokens("def f():\n  pass\n")) == [
        "NAME",
        "NAME",
        "OP",
        "OP",
        "NEWLINE",
        "INDENT",
        "NAME",
        "NEWLINE",
        "DEDENT",
        "ENDMARKER",
    ]


# Generated at 2022-06-17 17:03:41.477789
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
       

# Generated at 2022-06-17 17:03:49.768865
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize_loop

    def test_tokenize_loop_helper(s, expected):
        f = StringIO(s)
        tokens = []
        tokenize_loop(f.readline, tokens.append)
        assert tokens == expected

    test_tokenize_loop_helper("", [])
    test_tokenize_loop_helper(" ", [(token.INDENT, " ", (1, 0), (1, 1), " ")])
    test_tokenize_loop_helper("\n", [(token.NEWLINE, "\n", (1, 0), (1, 1), "\n")])

# Generated at 2022-06-17 17:03:59.296049
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL

    def test_tokenize(s):
        return list(generate_tokens(StringIO(s).readline))

    def test_untokenize(tokens):
        return untokenize(iter(tokens))

    def check(s):
        tokens = test_tokenize(s)
        assert test_untokenize(tokens) == s

    check("a = 1")
    check("a = 1\n")
    check("a = 1\nb = 2")
    check("a = 1\nb = 2\n")
    check("a = 1\nb = 2\n\n")

# Generated at 2022-06-17 17:04:08.018730
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "abc"), (2, "def")]) == "abc def"
    assert u.untokenize([(0, "abc"), (1, "def")]) == "abc def"
    assert u.untokenize([(0, "abc"), (1, "def"), (0, "ghi")]) == "abc def ghi"
    assert u.untokenize([(0, "abc"), (1, "def"), (0, "ghi"), (1, "jkl")]) == "abc def ghi jkl"
    assert u.untokenize([(0, "abc"), (1, "def"), (0, "ghi"), (1, "jkl"), (0, "mno")]) == "abc def ghi jkl mno"

# Generated at 2022-06-17 17:04:19.108140
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), "\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), "\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), "\n")
    readline = io.BytesIO(b'"""a\\nb"""').readline
    tokens = list(tokenize(readline))

# Generated at 2022-06-17 17:04:29.721447
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    untok.tokens.append("def")
    untok.prev_row = 1
    untok.prev_col = 3
    untok.add_whitespace((1, 3))
    untok.tokens.append("f")
    untok.prev_row = 1
    untok.prev_col = 4
    untok.add_whitespace((1, 4))
    untok.tokens.append("(")
    untok.prev_row = 1
    untok.prev_col = 5
    untok.add_whitespace((1, 5))
   

# Generated at 2022-06-17 17:04:40.139875
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some other comment\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"# -*- coding: iso-latin-1 -*-\n"
        yield b"# vim: set fileencoding=utf-8 :\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b

# Generated at 2022-06-17 17:04:51.705312
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    # Test for untokenize of a string
    assert untok.untokenize([(1, "a"), (2, "b")]) == "ab"
    # Test for untokenize of a list of tuples
    assert untok.untokenize([(1, "a"), (2, "b"), (3, "c")]) == "abc"
    # Test for untokenize of a list of tuples with newline
    assert untok.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "\n")]) == "abc\n"
    # Test for untokenize of a list of tuples with newline and indent

# Generated at 2022-06-17 17:05:00.323151
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 +1\n2\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 +1\n")
    assert tokens[1] == (OP, "+", (1, 1), (1, 2), b"1 +1\n")
    assert tokens[2] == (NUMBER, "1", (1, 2), (1, 3), b"1 +1\n")
    assert tokens[3] == (STRING, "", (2, 0), (2, 0), b"2\n")

# Generated at 2022-06-17 17:05:28.151702
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import tok_name

    s = "def f(x): return 2*x\n"
    f = io.StringIO(s)
    l = []
    tokenize_loop(f.readline, l.append)

# Generated at 2022-06-17 17:05:31.567344
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    readline = io.StringIO("if 1:\n  pass\n").readline
    for token in generate_tokens(readline):
        print(token)
        print(tok_name[token.type], repr(token.string))


# Generated at 2022-06-17 17:05:40.293026
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io
    import unittest

    class Test(unittest.TestCase):
        def test_generate_tokens(self):
            readline = io.StringIO("if 1:\n  pass\n").readline
            tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:05:54.470105
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: iso-8859-1 -*-\n"
        yield b"# vim: set fileencoding=iso-8859-15 :\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# vim: set fileencoding=utf-8 :\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: cp1252 -*-\n"
        yield b"# -*- coding: unknown -*-\n"

# Generated at 2022-06-17 17:06:02.155805
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-8859-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-foo -*-"
        yield b"\n"
        yield b"# -*- coding: unknown -*-"
        yield b"\n"

# Generated at 2022-06-17 17:06:11.817381
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding=utf-8\n"
        yield b"#! /usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=iso-8859-1\n"
        yield b"# coding=iso-latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"

# Generated at 2022-06-17 17:06:17.679952
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    def readline():
        return 'print(1+1)\n'

    def tokeneater(*args):
        tokeneater.tokens.append(args)

    tokeneater.tokens = []
    tokenize_loop(readline, tokeneater)

# Generated at 2022-06-17 17:06:28.419361
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"
    assert detect_encoding(readline) == ("iso-8859-1", [])



# Generated at 2022-06-17 17:06:40.061397
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(tok, toktype, tokval, start, end, line):
        assert tok[0] == toktype, (
            "Token type %r != %r" % (tok[0], toktype)
        )
        assert tok[1] == tokval, (
            "Token value %r != %r" % (tok[1], tokval)
        )
        assert tok[2] == start, (
            "Start index %r != %r" % (tok[2], start)
        )
        assert tok[3] == end, (
            "End index %r != %r" % (tok[3], end)
        )

# Generated at 2022-06-17 17:06:48.023259
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more code\n"
        yield b"# even more code\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# some more code\n"]

    def readline():
        yield b"# coding=latin-1\n"
        yield b"# some more code\n"
        yield b"# even more code\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding=latin-1\n", b"# some more code\n"]

   

# Generated at 2022-06-17 17:07:18.606828
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, generate_tokens, tok_name

    def tokeneater(*args):
        print(tok_name[args[0]], repr(args[1]))

    tokenize_loop(io.StringIO("def f(): pass\n").readline, tokeneater)



# Generated at 2022-06-17 17:07:21.379059
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    iterable = [
        (NAME, "a"),
        (NEWLINE, "\n"),
        (INDENT, "  "),
        (NAME, "b"),
        (DEDENT, ""),
        (NAME, "c"),
    ]
    assert u.compat((NAME, "a"), iterable) == "a \n  b c "



# Generated at 2022-06-17 17:07:33.275549
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:07:43.780662
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# comment\n", b"# another comment\n", b"\n"]

    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:07:55.299954
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    from unittest import TestCase

    class Test(TestCase):
        def test_generate_tokens(self):
            readline = StringIO("if 1:\n  pass\n").readline
            tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:08:06.100948
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import NUMBER
    from tokenize import STRING
    from tokenize import NAME
    from tokenize import OP
    from tokenize import ENDMARKER
    from tokenize import INDENT
    from tokenize import DEDENT
    from tokenize import NEWLINE
    from tokenize import COMMENT
    from tokenize import ENCODING
    from tokenize import NL
    from tokenize import COMMENT
    from tokenize import tokenize
    from tokenize import generate_tokens
    from tokenize import untokenize
    from tokenize import NUMBER
    from tokenize import STRING
    from tokenize import NAME

# Generated at 2022-06-17 17:08:18.249463
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from unittest import TestCase


# Generated at 2022-06-17 17:08:27.022997
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def show_tokens(readline):
        for type, token, (srow, scol), (erow, ecol), line in generate_tokens(readline):
            print("%10s %-14r %r" % (tok_name[type], token, line))

    show_tokens(io.StringIO("if 1:\n  pass\n").readline)

if __name__ == "__main__":
    test_generate_tokens()


# Generated at 2022-06-17 17:08:31.552797
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop

    def readline():
        return "a = 1 + 2\n"

    def tokeneater(*args):
        print(args)

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:08:42.522530
# Unit test for function detect_encoding

# Generated at 2022-06-17 17:09:53.528173
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == [" ", " ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", " ", "\n", " "]
    untok.tokens = []

# Generated at 2022-06-17 17:10:04.969594
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    untok = Untokenizer()
    f = StringIO("def f():\n    print(42)\n")
    tokens = generate_tokens(f.readline)
    result = untok.compat(next(tokens), tokens)
    assert result is None
    assert untok.tokens == ["def", " ", "f", "(", ")", ":", "\n", "    ", "print", "(", "42", ")", "\n"]
    assert untokenize(generate_tokens(f.readline)) == "def f():\n    print(42)\n"



# Generated at 2022-06-17 17:10:16.818052
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"

# Generated at 2022-06-17 17:10:27.530805
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    untok.tokens.append("def")
    untok.prev_row = 1
    untok.prev_col = 3
    untok.add_whitespace((1, 3))
    untok.tokens.append("f")
    untok.prev_row = 1
    untok.prev_col = 4
    untok.add_whitespace((1, 4))
    untok.tokens.append("(")
    untok.prev_row = 1
    untok.prev_col = 5
    untok.add_whitespace((1, 5))
   

# Generated at 2022-06-17 17:10:39.733184
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from io import StringIO
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import NUMBER, STRING, NAME, OP

    # Test round-trip equivalence.
    text = "1 + 1\n"
    f = io.BytesIO(text.encode("utf-8"))
    tokens = []
    tokenize(f.readline, tokens.append)
    newtext = untokenize(tokens).decode("utf-8")
    assert newtext == text

    # Test token types.
    f = StringIO("0 1.2 3.4j 'a' '\\n' \"b\" '''c'''")
    tokens = []
    tokenize(f.readline, tokens.append)

# Generated at 2022-06-17 17:10:46.086009
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    result = []
    tokenize.tokenize(r, result.append)