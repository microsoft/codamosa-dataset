

# Generated at 2022-06-17 17:02:36.527680
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more comments\n"
        yield b"# still more comments\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding: ascii\n"
        yield b"# more comments\n"
        yield b"#!more comments\n"
        yield b"# -*- coding: cp-1252 -*-\n"
        yield b"# coding: latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"

# Generated at 2022-06-17 17:02:44.312618
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    r = io.BytesIO(b"def f(x):\n  return x+1\n")
    tokens = tokenize.generate_tokens(r.readline)
    for tok in tokens:
        print(tok)


# Generated at 2022-06-17 17:02:55.579467
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "abc"), (2, "def")]) == "abc def"
    u = Untokenizer()
    assert u.untokenize([(1, "abc"), (2, "def"), (3, "ghi")]) == "abc def ghi"
    u = Untokenizer()
    assert u.untokenize([(1, "abc"), (2, "def"), (3, "ghi"), (4, "jkl")]) == "abc def ghi jkl"
    u = Untokenizer()
    assert u.untokenize([(1, "abc"), (2, "def"), (3, "ghi"), (4, "jkl"), (5, "mno")]) == "abc def ghi jkl mno"
    u = Untoken

# Generated at 2022-06-17 17:03:05.800858
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:03:08.791359
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize

    r = io.StringIO("def f(x): return 2*x")
    tokenize_loop(r.readline, _tokenize.printtoken)



# Generated at 2022-06-17 17:03:15.924851
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    for token in generate_tokens(readline):
        print(token)
    print("*" * 40)
    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    for token in generate_tokens(readline):
        print(tok_name[token[0]], token[1])

# Generated at 2022-06-17 17:03:25.254578
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    def check(input, expected):
        result = []
        tokenize(StringIO(input).readline, lambda toknum, tokval, _srowcol, _erowcol, _line: result.append((toknum, tokval)))
        assert result == expected

    check('1 + 1\n', [(NUMBER, '1'), (OP, '+'), (NUMBER, '1'), (OP, '\n')])
    check('a = "abc"\n', [(NAME, 'a'), (OP, '='), (STRING, 'abc'), (OP, '\n')])

# Generated at 2022-06-17 17:03:37.743468
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == [" ", " ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", " ", "\n", " "]
    untok.add_whitespace((3, 0))
    assert untok

# Generated at 2022-06-17 17:03:43.758854
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    import tokenize
    readline = StringIO("if 1:\n  pass\n").readline
    tokens = tokenize.generate_tokens(readline)
    for toknum, tokval, _, _, _ in tokens:
        print("%s %s" % (tok_name[toknum], tokval))


# Generated at 2022-06-17 17:03:51.293762
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = StringIO(
        'print(1+1, "foo", -2.3, "bar", +4, "baz", sep="**")\n'
    ).readline
    tokengen = generate_tokens(readline)
    for toktype, token, start, end, line in tokengen:
        print(tokenize.tok_name[toktype], repr(token))
        if toktype == tokenize.NEWLINE:
            break
    print()


# Generated at 2022-06-17 17:04:43.155161
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens
    from token import tok_name
    text = "def f(x): return 2*x"
    g = generate_tokens(StringIO(text).readline)
    for toknum, tokval, _, _, _ in g:
        print(tok_name[toknum], tokval)

test_generate_tokens()


# Generated at 2022-06-17 17:04:54.582683
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b")]) == "ab"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c")]) == "ab c"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d")]) == "ab cd"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")]) == "ab cde"

# Generated at 2022-06-17 17:05:03.050894
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    r = StringIO("def f(x):\n  return x+1\n")
    g = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in g:
        print("%10s %-14s" % (tokenize.tok_name[toknum], repr(tokval)))


# Generated at 2022-06-17 17:05:10.005310
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"print('euro:\xe2\x82\xac')"
        yield b""
    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"print('euro:\xe2\x82\xac')"]



# Generated at 2022-06-17 17:05:20.215289
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.BytesIO(b"def f(x): return x+1\n")
    result = []
    tokenize.tokenize(r.readline, result.append)
    assert result == [
        (token.NUMBER, "1", (1, 0), (1, 1), "\n"),
        (token.NEWLINE, "\n", (1, 1), (1, 2), "\n"),
        (token.ENDMARKER, "", (2, 0), (2, 0), ""),
    ]



# Generated at 2022-06-17 17:05:32.861112
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"# bar"
        yield b"# -*- coding: ascii -*-"
        yield b"# baz"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# qux"
        yield b"# -*- coding: iso-8859-1 -*-"
        yield b"# quux"
        yield b"# -*- coding: unknown -*-"
        yield b"# corge"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# grault"

# Generated at 2022-06-17 17:05:44.477062
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:05:53.794622
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    with open("tokenize_tests.txt") as fp:
        for line in fp:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("L"):
                line = line[1:]
            elif line.startswith("u"):
                line = line[1:].decode("unicode-escape")
            elif line.startswith("b"):
                line = line[1:].decode("unicode-escape").encode("latin-1")
            elif line.startswith("r"):
                line = eval(line[1:])
            elif line.startswith("t"):
                line = eval(line[1:])


# Generated at 2022-06-17 17:06:05.114764
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER
    from blib2to3.pgen2.tokenize import ASYNC, AWAIT
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.tokenize import COMMENT, ENCODING, ENDMARKER, ERRORTOKEN
    from blib2to3.pgen2.tokenize import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER

# Generated at 2022-06-17 17:06:13.446763
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    from unittest import TestCase

    class Test(TestCase):
        def check_tokenize(self, input, expected):
            result = list(tokenize.generate_tokens(StringIO(input).readline))
            self.assertEqual(result, expected)

    test = Test("test_generate_tokens")
    test.check_tokenize("", [(0, "", (1, 0), (1, 0), "")])
    test.check_tokenize("\n", [(0, "", (1, 0), (1, 0), ""), (4, "", (2, 0), (2, 0), "")])
    test.check_tokenize("a", [(1, "a", (1, 0), (1, 1), "a")])

# Generated at 2022-06-17 17:06:53.699020
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(tok, type, string, start, end, line):
        assert tok.type == type, (
            "wrong token type %r (should be %r)" % (tok.type, type)
        )
        assert tok.string == string, (
            "wrong token string %r (should be %r)" % (tok.string, string)
        )
        assert tok.start == start, (
            "wrong token start %r (should be %r)" % (tok.start, start)
        )
        assert tok.end == end, (
            "wrong token end %r (should be %r)" % (tok.end, end)
        )

# Generated at 2022-06-17 17:06:59.839823
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=iso-latin-1\n"
        yield b"# coding=iso-8859-1\n"
        yield b"# coding=iso-8859-15\n"
        yield b"# coding=iso-8859-15\n"
        yield b"# coding=iso-8859-15\n"
        yield b"# coding=iso-8859-15\n"
        yield b"# coding=iso-8859-15\n"
        yield b"# coding=iso-8859-15\n"

# Generated at 2022-06-17 17:07:05.608705
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#! /usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"

# Generated at 2022-06-17 17:07:10.481350
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:07:17.706216
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NAME, "abc", (1, 0), (1, 3), "abc")
    printtoken(STRING, "abc", (1, 0), (1, 3), "abc")
    printtoken(OP, "abc", (1, 0), (1, 3), "abc")
    printtoken(NEWLINE, "abc", (1, 0), (1, 3), "abc")
    printtoken(INDENT, "abc", (1, 0), (1, 3), "abc")
    printtoken(DEDENT, "abc", (1, 0), (1, 3), "abc")
    printtoken(ENDMARKER, "abc", (1, 0), (1, 3), "abc")

# Generated at 2022-06-17 17:07:29.518098
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')
    printtoken(1, 'a', (1, 1), (1, 2), 'a')

# Generated at 2022-06-17 17:07:41.696913
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import TokenInfo
    from blib2to3.pgen2.tokenize import COMMENT
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import ENCODING
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import OP
    from blib2to3.pgen2.tokenize import STRING

# Generated at 2022-06-17 17:07:54.519719
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize

    def readline():
        return next(lines)

    lines = iter(
        [
            "def f(x):\n",
            "  return 2*x\n",
            "\n",
            "print(f(4))\n",
            "\n",
            "# That's the end of the program.\n",
        ]
    )
    toks = []
    tokeneater = toks.append
    _tokenize.tokenize(readline, tokeneater)

# Generated at 2022-06-17 17:08:05.962012
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, ENDMARKER
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, ENDMARKER
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import untokenize

# Generated at 2022-06-17 17:08:08.605276
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    with io.StringIO("def f():\n  pass\n") as f:
        for token in generate_tokens(f.readline):
            print(tok_name[token[0]], repr(token[1]))


# Generated at 2022-06-17 17:08:40.212722
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    with io.StringIO("def f(x): return 2*x") as f:
        for token in generate_tokens(f.readline):
            print(token)

    with io.StringIO("def f(x): return 2*x") as f:
        for token in generate_tokens(f.readline):
            print(tok_name[token[0]], token[1])


# Generated at 2022-06-17 17:08:54.047966
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (2, 'b')])
    assert untok.tokens == ['a', 'b']
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (0, ' '), (2, 'b')])
    assert untok.tokens == ['a', ' ', 'b']
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0

# Generated at 2022-06-17 17:09:07.253936
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"def foo(): pass\n"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])

    def readline():
        yield b"# coding=latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"def foo(): pass\n"


# Generated at 2022-06-17 17:09:14.407439
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')])
    assert untok.tokens == ['a', 'b', 'c', 'd']



# Generated at 2022-06-17 17:09:25.476510
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO

    s = "def f(x): return 2*x\n"
    f = StringIO(s)
    tokens = []
    for t in tokenize.generate_tokens(f.readline):
        tokens.append(t)

# Generated at 2022-06-17 17:09:37.317235
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some other comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding=iso-8859-1\n"
        yield b"\n"
        yield b"# coding=iso-latin-1\n"
        yield b"\n"
        yield b"# coding=iso-latin-1-foo\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8-foo\n"
        yield b"\n"
        yield b"# coding=utf-8-sig\n"
        yield b"\n"

# Generated at 2022-06-17 17:09:52.079749
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more code\n"
        yield b"# still more code\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding: ascii\n"
        yield b"# more code\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: cp1252 -*-\n"
        yield b"# more code\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding=ascii\n"
        yield b"# more code\n"
        yield b"\n"

# Generated at 2022-06-17 17:10:03.803383
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()

# Generated at 2022-06-17 17:10:15.814515
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List, Tuple

    def _format(tok: Tuple[int, str, Tuple[int, int], Tuple[int, int], str]) -> str:
        return "{} {} {} {} {}".format(*tok)

    def _test(source: str) -> List[str]:
        f = io.StringIO(source)
        tokens = list(tokenize.generate_tokens(f.readline))
        return [_format(tok) for tok in tokens]

    assert _test("") == ["0 '' (1, 0) (1, 0) ''"]
    assert _test("\n") == ["4 '' (1, 0) (1, 0) ''", "0 '' (2, 0) (2, 0) ''"]
   

# Generated at 2022-06-17 17:10:22.274847
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import TokenInfo
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import detect_encoding
    from blib2to3.pgen2.tokenize import COMMENT
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import ENCODING
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import OP

# Generated at 2022-06-17 17:10:56.395949
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List

    def _format(tok: GoodTokenInfo) -> str:
        return "{} {} {} {} {}".format(*tok)

    def _test(input: str, expected: List[str]) -> None:
        with io.StringIO(input) as f:
            tokens = list(tokenize.generate_tokens(f.readline))
        actual = [_format(t) for t in tokens]
        assert actual == expected

    _test("", [])
    _test("#", ["1 COMMENT #"])
    _test("#\n", ["1 COMMENT #", "4 NL \n"])
    _test("#\n\n", ["1 COMMENT #", "4 NL \n", "4 NL \n"])
   