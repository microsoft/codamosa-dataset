

# Generated at 2022-06-17 17:02:00.157371
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import TokenInfo
    from blib2to3.pgen2.tokenize import INDENT
    from blib2to3.pgen2.tokenize import DEDENT
    from blib2to3.pgen2.tokenize import NEWLINE
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import NUMBER
    from blib2to3.pgen2.tokenize import ASYNC

# Generated at 2022-06-17 17:02:05.349094
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.BytesIO(b"def f(x): return '#' + x\n")
    result = []
    tokenize.tokenize(r.readline, result.append)

# Generated at 2022-06-17 17:02:12.496773
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:02:22.164013
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == ["  "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == ["  ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == ["  ", "\n", " "]

# Generated at 2022-06-17 17:02:32.386578
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more code\n"
        yield b"# even more code\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# some more code\n"]

    def readline():
        yield b"# coding=latin-1\n"
        yield b"# some more code\n"
        yield b"# even more code\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding=latin-1\n", b"# some more code\n"]

   

# Generated at 2022-06-17 17:02:40.854092
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    import tokenize
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import INDENT, DEDENT, NEWLINE, ENDMARKER
    from blib2to3.pgen2.tokenize import NAME, NUMBER, ASYNC, AWAIT
    from blib2to3.pgen2.tokenize import NL, tokenize
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import INDENT, DEDENT, NEWLINE, ENDMARKER

# Generated at 2022-06-17 17:02:53.094579
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    def test(s):
        f = StringIO(s)
        tokens = generate_tokens(f.readline)
        return untokenize(tokens)

    assert test("a = 1") == "a = 1 "
    assert test("a = 1\nb = 2") == "a = 1\nb = 2 "
    assert test("a = 1\n\nb = 2") == "a = 1\n\nb = 2 "
    assert test("a = 1\n\nb = 2\n") == "a = 1\n\nb = 2\n"

# Generated at 2022-06-17 17:03:03.991202
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from blib2to3.pgen2.token import tok_name

    class Readline:
        def __init__(self, lines):
            self.lines = lines
            self.index = 0

        def __call__(self):
            if self.index >= len(self.lines):
                return ""
            line = self.lines[self.index]
            self.index += 1
            return line

    def tokeneater(*args):
        tokeneater.tokens.append(args)

    tokeneater.tokens = []
    readline = Readline(["def f(x): return x+1  # A comment"])
    tokenize_module.tokenize_loop(readline, tokeneater)
    assert tokene

# Generated at 2022-06-17 17:03:14.437534
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    import tokenize
    from test.test_tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.fixer_util import Name, Number, String, is_tuple
    from blib2to3.fixer_util import Comma, LParen, RParen, Newline
    from blib2to3.fixer_util import syms as fixer_util_syms
    from blib2to3.fixer_util import token as fixer_util_token
    from blib2to3.fixer_util import Call, Node, Attr, ArgList, Dot


# Generated at 2022-06-17 17:03:21.311781
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#! /usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"

# Generated at 2022-06-17 17:04:10.816737
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"\n"
        yield b"# -*- coding: ascii -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: unknown -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"

# Generated at 2022-06-17 17:04:23.480043
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize, NUMBER, NAME, OP
    from blib2to3.pgen2.tokenize import tokenize_loop, tok_name

    s = "3 + 4 * 10\n  + 25 * 2\n"
    readline = io.StringIO(s).readline
    tokens = []
    tokenize_loop(readline, tokens.append)

# Generated at 2022-06-17 17:04:31.779936
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import NUMBER
    from tokenize import STRING
    from tokenize import NAME
    from tokenize import OP
    s = "def f(x): return 2*x"
    g = generate_tokens(StringIO(s).readline)
    l = list(g)
    assert len(l) == 7
    assert l[0] == (token.NAME, "def", (1, 0), (1, 3), s)
    assert l[1] == (token.NAME, "f", (1, 4), (1, 5), s)

# Generated at 2022-06-17 17:04:42.281817
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some other comment\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# some other comment\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# some other comment\n"
        yield b"# coding: utf-8\n"
        yield b"# some other comment\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some other comment\n"
        yield b"# coding: utf-16\n"
        yield b"# some other comment\n"
        yield b"# coding: utf-32\n"

# Generated at 2022-06-17 17:04:53.752681
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    # Test with a file
    with open(__file__, "rb") as f:
        g = generate_tokens(f.readline)
        for toknum, tokval, _, _, _ in g:
            print("%10s %-14r %r" % (tok_name[toknum], tokval, tokval))

    # Test with a text stream
    s = io.StringIO("for i in range(10): print(i)\n")
    g = generate_tokens(s.readline)
    for toknum, tokval, _, _, _ in g:
        print("%10s %-14r %r" % (tok_name[toknum], tokval, tokval))



# Generated at 2022-06-17 17:05:01.737698
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:05:13.213218
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"blah"]

    def readline():
        yield b"# coding=utf-8"
        yield b"blah"

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == [b"# coding=utf-8", b"blah"]

    def readline():
        yield b"#!/usr/bin/python3"
        yield b"# -*- coding: latin-1 -*-"

# Generated at 2022-06-17 17:05:25.333675
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io
    import unittest

    class Test(unittest.TestCase):
        def test_generate_tokens(self):
            readline = io.StringIO("if 1:\n  pass\n").readline
            tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:05:30.429740
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x")
    g = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in g:
        print("%s %s" % (token.tok_name[toknum], repr(tokval)))



# Generated at 2022-06-17 17:05:40.041713
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO

    class Readline:
        def __init__(self, lines: Iterable[Text]) -> None:
            self.lines = iter(lines)

        def __call__(self) -> Text:
            return next(self.lines, "")

    def check(input: Text, expected: List[Tuple[int, Text, Coord, Coord, Text]]) -> None:
        s = StringIO(input)
        rl = Readline(s.readlines())
        result = []

        def tokeneater(*args):
            result.append(args)

        tokenize_loop(rl, tokeneater)
        assert result == expected

    check("", [])

# Generated at 2022-06-17 17:06:10.598317
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!python\n"
        yield b"# -*- coding: iso-latin-1 -*-\n"
        yield b"# vim: set fileencoding=iso-latin-1 :\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"# -*- coding: iso-8859-1 -*-\n"
        yield b"# -*- coding: cp1252 -*-\n"
        yield b"# -*- coding: utf-8 -*-\n"

# Generated at 2022-06-17 17:06:22.546519
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for tok in tokens:
        print(tok)

    # Test round-trip invariant for full input
    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = list(generate_tokens(readline))
    assert untokenize(tokens) == b"if 1:\n  pass\n"

    # Test round-trip invariant for limited input
    readline = io.BytesIO(b"if 1:\n  pass\n").readline
   

# Generated at 2022-06-17 17:06:31.421155
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize as tokenize_
    from tokenize import untokenize


# Generated at 2022-06-17 17:06:43.387100
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    def test(input, expected):
        result = untokenize(generate_tokens(StringIO(input).readline))
        assert result == expected, "%r != %r" % (result, expected)

    test("def f():\n  pass\n", "def f():\n  pass\n")
    test("def f():\n  pass\n\n", "def f():\n  pass\n\n")
    test("def f():\n  pass\n\n\n", "def f():\n  pass\n\n\n")

# Generated at 2022-06-17 17:06:46.535078
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens

    u = Untokenizer()
    readline = StringIO("if 1:").readline
    g = generate_tokens(readline)
    u.compat(next(g), g)
    assert u.tokens == ["if ", "1", ":"]



# Generated at 2022-06-17 17:06:52.999582
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# foo\n"
        yield b"# bar\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding: utf-8\n"
        yield b"# foo\n"
        yield b"# bar\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# foo\n"
        yield b"# bar\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"

# Generated at 2022-06-17 17:06:59.812315
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"

# Generated at 2022-06-17 17:07:05.585780
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"

# Generated at 2022-06-17 17:07:14.646883
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import NUMBER, STRING, NAME, OP

    # Test round-trip invariant for full input
    text = b"1 + 1\n"
    gtokens = tokenize(BytesIO(text).readline)
    tokens = list(gtokens)
    newtext = untokenize(tokens)
    newtokens = list(tokenize(BytesIO(newtext).readline))
    assert tokens == newtokens

    # Test round-trip invariant for limited input
    text = b"1 + 1\n"
    gtokens = tokenize(BytesIO(text).readline)

# Generated at 2022-06-17 17:07:27.093071
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"# coding=latin-1\n"
        yield b"\n"
        yield b"# coding=ascii\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"\n"
        yield b"# coding: utf-8-sig\n"
        yield b"\n"

# Generated at 2022-06-17 17:08:03.307905
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (0, ' '), (1, 'b'), (0, ' '), (1, 'c')])
    assert untok.tokens == ['a', ' ', 'b', ' ', 'c']
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (0, ' '), (1, 'b'), (0, ' '), (1, 'c')])
    assert untok.tokens == ['a', ' ', 'b', ' ', 'c']

# Generated at 2022-06-17 17:08:09.928886
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"pass"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"pass"]

    def readline():
        yield b"#!/usr/bin/python3"
        yield b"# -*- coding: latin-1 -*-"
        yield b"pass"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"#!/usr/bin/python3", b"# -*- coding: latin-1 -*-", b"pass"]


# Generated at 2022-06-17 17:08:20.748768
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b'foo = "bar"\n').readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (
        NAME,
        b"foo",
        (1, 0),
        (1, 3),
        b'foo = "bar"\n',
    )  # Offsets are (row, col)
    assert tokens[1] == (OP, b"=", (1, 4), (1, 5), b'foo = "bar"\n')

# Generated at 2022-06-17 17:08:31.190221
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b")]) == "a b"
    assert u.untokenize([(1, "a"), (0, " "), (2, "b")]) == "a b"
    assert u.untokenize([(1, "a"), (0, "  "), (2, "b")]) == "a   b"
    assert u.untokenize([(1, "a"), (0, "\n"), (2, "b")]) == "a\nb"
    assert u.untokenize([(1, "a"), (0, "\n  "), (2, "b")]) == "a\n  b"

# Generated at 2022-06-17 17:08:42.257289
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name

    def tokeneater(*args):
        tok_type, token, start, end, line = args
        print(tok_name[tok_type], repr(token), start, end, line, sep="\t")

    # Test case from http://bugs.python.org/issue6705
    s = StringIO("if 1:\n  try:\n    2\n")
    for token in generate_tokens(s.readline):
        tokeneater(*token)

    untok = Untokenizer()
    s = StringIO("if 1:\n  try:\n    2\n")
    tokens = generate_tokens(s.readline)
   

# Generated at 2022-06-17 17:08:49.753571
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:09:01.744199
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: ascii -*-"
        yield b"\n"
        yield b"# vim:fileencoding=utf-8"
        yield b"\n"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"\n"
        yield b"# -*- coding: unknown -*-"
        yield b"\n"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"

# Generated at 2022-06-17 17:09:07.496262
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = tokenize.generate_tokens(readline)
    for tok in tokens:
        print(tok)

test_generate_tokens()


# Generated at 2022-06-17 17:09:19.611544
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT

    def test(input, expected):
        result = untokenize(generate_tokens(StringIO(input).readline))
        assert result == expected, (result, expected)

    test("def f():\n    pass\n", "def f():\n    pass\n")
    test("def f():\n    pass\n\n", "def f():\n    pass\n\n")
    test("def f():\n    pass\n\n\n", "def f():\n    pass\n\n\n")

# Generated at 2022-06-17 17:09:29.447222
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for toktype, tokval, _, _, _ in tokens:
        if toktype == NUMBER and tokval == "1":
            print("NUMBER", tokval)
        elif toktype == NAME and tokval == "if":
            print("NAME", tokval)
        elif toktype == NAME and tokval == "pass":
            print("NAME", tokval)

# Generated at 2022-06-17 17:10:05.469958
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    readline = io.StringIO(
        'if 1:\n print("foo")\n print("bar")\n'
    ).readline
    for token in generate_tokens(readline):
        print(token)

test_generate_tokens()


# Generated at 2022-06-17 17:10:11.079283
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    untok.compat((NAME, "def"), [(NAME, "f"), (OP, "("), (OP, ")"), (OP, ":")])
    assert untok.tokens == ["def ", "f", "(", ")", ":"]



# Generated at 2022-06-17 17:10:19.788871
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize
    r = io.BytesIO(b"def f(x):\n  return x+1\n")
    tokens = tokenize(r.readline)
    result = list(tokens)
    assert result[1] == (NAME, 'f', (1, 0), (1, 1), 'def f(x):\n')
    assert result[2] == (OP, '(', (1, 1), (1, 2), 'def f(x):\n')
    assert result[3] == (NAME, 'x', (1, 2), (1, 3), 'def f(x):\n')
    assert result[4] == (OP, ')', (1, 3), (1, 4), 'def f(x):\n')

# Generated at 2022-06-17 17:10:26.947418
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    u = Untokenizer()
    text = "def f():\n    pass\n"
    readline = StringIO(text).readline
    result = u.compat(next(generate_tokens(readline)), generate_tokens(readline))
    assert result is None
    assert u.tokens == ["def ", "f", "(", ")", ":", "\n", "    ", "pass", "\n"]



# Generated at 2022-06-17 17:10:39.280257
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8-sig\n"
        yield

# Generated at 2022-06-17 17:10:45.840486
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b")]) == "ab"
    assert u.untokenize([(1, "a"), (2, "b"), (0, "c")]) == "ab"
    assert u.untokenize([(1, "a"), (2, "b"), (0, "c"), (1, "d")]) == "abd"
    assert u.untokenize([(1, "a"), (2, "b"), (0, "c"), (1, "d"), (0, "e")]) == "abde"