

# Generated at 2022-06-17 17:02:38.411451
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tok_name

    def tokeneater(*args):
        print(tok_name[args[0]], args[1])

    tokenize_loop(io.StringIO("def f(): pass\n").readline, tokeneater)



# Generated at 2022-06-17 17:02:51.466133
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    def test(s):
        f = io.StringIO(s)
        tokens = list(tokenize(f.readline))
        print(tokens)
        print(untokenize(tokens))
        print()

    test("def f(x): return 2*x\n")
    test('s = "a\\\nb"\n')
    test("s = 'a\\\nb'\n")
    test("x = '''\n")
    test("x = '''\n")
    test("x = '''\n")
    test("x = '''\n")
    test("x = '''\n")
    test("x = '''\n")

# Generated at 2022-06-17 17:03:03.089909
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, '1', (1, 0), (1, 1), '')
    printtoken(NUMBER, '1', (1, 0), (1, 1), '')
    printtoken(NUMBER, '1', (1, 0), (1, 1), '')
    printtoken(NUMBER, '1', (1, 0), (1, 1), '')
    printtoken(NUMBER, '1', (1, 0), (1, 1), '')
    printtoken(NUMBER, '1', (1, 0), (1, 1), '')
    printtoken(NUMBER, '1', (1, 0), (1, 1), '')
    printtoken(NUMBER, '1', (1, 0), (1, 1), '')

# Generated at 2022-06-17 17:03:07.437185
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    r = BytesIO(b"def f(x):\n  return x+1\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tokenize.tok_name[toknum], tokval)

test_generate_tokens()


# Generated at 2022-06-17 17:03:18.136422
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")

# Generated at 2022-06-17 17:03:26.548195
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", " "]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", " ", "\n"]
    u.add_whitespace((2, 1))
    assert u.tokens == [" ", " ", "\n", " "]
    u.add_whitespace((2, 2))

# Generated at 2022-06-17 17:03:38.732784
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import untokenize_printable
    from tokenize import _tokenize_whitespace
    from tokenize import _tokenize_whitespace_split
    from tokenize import _tokenize_whitespace_split_re
    from tokenize import _tokenize_whitespace_split_re_compiled
    from tokenize import _tokenize_whitespace_split_re_compiled_optimized
    from tokenize import _tokenize_whitespace_split_re_compiled_optimized_2
    from tokenize import _tokenize_whitespace_split_re_compiled_

# Generated at 2022-06-17 17:03:48.274356
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def tokenize(source: str) -> Iterator[TokenInfo]:
        return generate_tokens(io.StringIO(source).readline)

    def print_token(token: TokenInfo) -> None:
        print(tok_name[token.type], token.string, token.start, token.end, token.line)

    for token in tokenize("a = 1 + 2"):
        print_token(token)

    print()

    for token in tokenize("a = 1 + 2\n"):
        print_token(token)

    print()

    for token in tokenize("a = 1 + 2\n\n"):
        print_token(token)

    print()


# Generated at 2022-06-17 17:03:52.164001
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "a", (1, 2), (1, 3), "")
    printtoken(1, "a", (1, 2), (1, 3), "")



# Generated at 2022-06-17 17:04:02.161603
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import COMMENT
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import OP
    from blib2to3.pgen2.tokenize import STRING
    from blib2to3.pgen2.tokenize import NUMBER
    from blib2to3.pgen2.tokenize import ENDMARKER

# Generated at 2022-06-17 17:04:30.464806
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest

    class TestTokenizeLoop(unittest.TestCase):
        def test_tokenize_loop(self):
            s = "def f(x): return 2*x\n"
            stream = io.StringIO(s)
            l = []

            def tokeneater(*args):
                l.append(args)

            tokenize_loop(stream.readline, tokeneater)

# Generated at 2022-06-17 17:04:40.243793
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    def tokenize(s):
        result = []
        g = generate_tokens(StringIO(s).readline)
        for toknum, tokval, _, _, _ in g:
            result.append((toknum, tokval))
        return result


# Generated at 2022-06-17 17:04:51.839312
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from tokenize import (
        INDENT,
        DEDENT,
        NEWLINE,
        NAME,
        NUMBER,
        ASYNC,
        AWAIT,
    )

    def _test(input, expected):
        f = io.StringIO(input)
        result = tokenize.untokenize(tokenize.generate_tokens(f.readline))
        assert result == expected, (result, expected)

    _test("def f():\n    pass\n", "def f():\n    pass\n")
    _test("def f():\n    pass\n\n", "def f():\n    pass\n\n")

# Generated at 2022-06-17 17:05:00.385860
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some other comment\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"# some other comment\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"# some other comment\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"# some other comment\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b

# Generated at 2022-06-17 17:05:12.403818
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    def check_tokenize(input, expected):
        s = StringIO(input).readline
        result = list(tokenize(s))
        print(result)
        assert result == expected


# Generated at 2022-06-17 17:05:24.620642
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest

    class Test(unittest.TestCase):

        def test_bom(self):
            stream = io.BytesIO(BOM_UTF8 + b"# coding: utf-8\n")
            encoding, lines = detect_encoding(stream.readline)
            self.assertEqual(encoding, "utf-8-sig")
            self.assertEqual(lines, [b"# coding: utf-8\n"])

        def test_cookie(self):
            stream = io.BytesIO(b"# coding: utf-8\n")
            encoding, lines = detect_encoding(stream.readline)
            self.assertEqual(encoding, "utf-8")

# Generated at 2022-06-17 17:05:30.829776
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    from . import tokenize

    def roundtrip(s):
        f = io.StringIO(s)
        tokens = list(tokenize.generate_tokens(f.readline))
        untok = tokenize.Untokenizer()
        out = untok.untokenize(tokens)
        return out

    assert roundtrip("a = 1") == "a = 1 "
    assert roundtrip("a = 1\nb = 2") == "a = 1 b = 2 "
    assert roundtrip("a = 1\n\nb = 2") == "a = 1 b = 2 "
    assert roundtrip("a = 1\n\n\nb = 2") == "a = 1 b = 2 "

# Generated at 2022-06-17 17:05:40.078526
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize as tokenize_orig
    from tokenize import untokenize

    def roundtrip(s):
        # Test that round-tripping works.
        g = generate_tokens(StringIO(s).readline)
        rt = untokenize(g)
        if rt != s:
            print("roundtrip failed on", repr(s))
            print("result:", repr(rt))
        assert rt == s

    def roundtrip_with_indent(s):
        # Test that round-tripping works.
        g = generate_tokens(StringIO(s).readline)
        rt = untokenize(g)
        if rt != s:
            print

# Generated at 2022-06-17 17:05:45.455552
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    from token import tok_name
    readline = StringIO("if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tok_name[toknum], tokval)


# Generated at 2022-06-17 17:05:57.097309
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: ascii\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some comment\n"
        yield b"# another comment\n"

# Generated at 2022-06-17 17:06:31.874930
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more comments\n"
        yield b"# still more comments\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# some more comments\n"
        yield b"# still more comments\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# some more comments\n"
        yield b"# still more comments\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
       

# Generated at 2022-06-17 17:06:43.840293
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import *

    def tokenize(s):
        return list(generate_tokens(io.StringIO(s).readline))

    def test(s, toks_expected):
        toks = tokenize(s)
        if toks != toks_expected:
            print("toks =", toks)
            print("expected =", toks_expected)
        assert toks == toks_expected


# Generated at 2022-06-17 17:06:48.401693
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pytree import Leaf, Node
    from blib2to3.fixer_util import Name, Number, String, syms as fixer_syms
    from blib2to3.fixer_util import token as f_token

# Generated at 2022-06-17 17:06:57.795452
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    u = Untokenizer()
    s = StringIO("if 1:\n  pass\n")
    tokens = generate_tokens(s.readline)
    assert u.untokenize(tokens) == "if 1: pass"
    s = StringIO("if 1:\n  pass\n")
    tokens = generate_tokens(s.readline)
    assert untokenize(tokens) == "if 1:\n  pass"
    s = StringIO("if 1:\n  pass\n")
    tokens

# Generated at 2022-06-17 17:07:09.873997
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize

    def roundtrip(s: Text) -> Text:
        f = io.StringIO(s)
        tokens = tokenize.generate_tokens(f.readline)
        return Untokenizer().untokenize(tokens)

    assert roundtrip("def f():\n  pass\n") == "def f():\n  pass\n"
    assert roundtrip("def f():\r\n  pass\r\n") == "def f():\n  pass\n"
    assert roundtrip("def f():\r\n  pass\r\n") == "def f():\n  pass\n"
    assert roundtrip("def f():\n  pass") == "def f():\n  pass"

# Generated at 2022-06-17 17:07:17.357886
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import tokenize as tokenize_orig
    from tokenize import untokenize
    from tokenize import generate_tokens
    from tokenize import COMMENT, NL, NAME, OP, INDENT, DEDENT, NEWLINE, NUMBER
    from tokenize import ENCODING, STRING, ENDMARKER

    def test(input, expected):
        f = StringIO(input)
        tokens = generate_tokens(f.readline)
        result = untokenize(tokens)
        assert result == expected, (result, expected)

    test("# coding: latin-1\n", "# coding: latin-1\n")
    test("# coding=latin-1\n", "# coding=latin-1\n")

# Generated at 2022-06-17 17:07:22.734331
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO
    from tokenize import tokenize_loop

    readline = StringIO("if 1:\n    pass\n").readline
    tokeneater = tokenize.untokenize
    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:07:29.472103
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    r = StringIO("def f(x): return 2*x\n")
    g = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in g:
        print("%10s %-14s" % (tokenize.tok_name[toknum], repr(tokval)))


# Generated at 2022-06-17 17:07:41.696943
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:07:54.549490
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    readline = io.StringIO("def f(x): return 2*x").readline
    for token in generate_tokens(readline):
        print(token)
    print("-"*40)
    readline = io.StringIO("if 1: # comment\n  print(1)\nelse: pass").readline
    for token in generate_tokens(readline):
        print(token)
    print("-"*40)
    readline = io.StringIO("""
if 1:
    print(1)
    print(2)
""").readline
    for token in generate_tokens(readline):
        print(token)
    print("-"*40)

# Generated at 2022-06-17 17:08:35.161980
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import untokenize
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop
    from tokenize import tokenize_loop

# Generated at 2022-06-17 17:08:43.856463
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:08:57.326555
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in [
            b'# -*- coding: latin-1 -*-\n',
            b'import sys\n',
            b'print(sys.stdin.encoding)\n',
        ]:
            yield line

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [
        b'# -*- coding: latin-1 -*-\n',
        b'import sys\n',
        b'print(sys.stdin.encoding)\n',
    ]


# Generated at 2022-06-17 17:09:09.441039
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.fixer_util import Name, Number, String, Newline, Comma, Dot, LParen, RParen
    from blib2to3.fixer_util import LParen, RParen, LBracket, RBracket, LBrace, RBrace
    from blib2to3.fixer_util import Assign, Add, Sub, Mult, Div, Mod, Pow, LShift, RShift
    from blib2to3.fixer_util import BitOr, BitXor, BitAnd, FloorDiv, In

# Generated at 2022-06-17 17:09:20.824290
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import STOP
    from blib2to3.pgen2.tokenize import ENCODING
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import COMMENT
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import OP
    from blib2to3.pgen2.tokenize import NUMBER

# Generated at 2022-06-17 17:09:31.101925
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# vim: set fileencoding=utf-8\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# -*- coding: utf-8; mode: python -*-\n"
        yield b"# -*- coding: utf-8 -*-\n"

# Generated at 2022-06-17 17:09:41.706610
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from io import StringIO
    from token import tok_name

    readline = io.StringIO("if 1:\n  pass\n").readline
    tokeneater = tokenize_module.untokenize
    tokenize_loop(readline, tokeneater)

# Generated at 2022-06-17 17:09:53.737793
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    # Test a variety of token types
    s = "1+1\nfoo(bar)\n"
    g = generate_tokens(io.StringIO(s).readline)
    t1 = next(g)
    assert t1 == (NUMBER, "1", (1, 0), (1, 1), "1+1\n")
    t2 = next(g)
    assert t2 == (OP, "+", (1, 1), (1, 2), "1+1\n")
    t3 = next(g)
    assert t3 == (NUMBER, "1", (1, 2), (1, 3), "1+1\n")
    t4 = next(g)

# Generated at 2022-06-17 17:09:59.529907
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    u.compat((NAME, "def"), [(NAME, "f"), (OP, "("), (OP, ")"), (OP, ":")])
    assert u.tokens == ["def ", "f", "(", ")", ":"]



# Generated at 2022-06-17 17:10:08.379245
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(generate_tokens(io.StringIO(s).readline))

    def _names(s):
        return [tok_name[toktype] for toktype, _, _, _, _ in _tokens(s)]

    assert _names("def f():\n  pass\n") == [
        "NAME",
        "NAME",
        "OP",
        "OP",
        "NEWLINE",
        "INDENT",
        "NAME",
        "NEWLINE",
        "DEDENT",
        "ENDMARKER",
    ]


# Generated at 2022-06-17 17:10:33.187229
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    u = Untokenizer()
    s = StringIO("def f():\n  pass\n")
    u.compat(next(generate_tokens(s.readline)), generate_tokens(s.readline))
    assert u.tokens == ["def f ( ) :", "  pass", ""]



# Generated at 2022-06-17 17:10:42.510410
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name

    def show_tokens(readline):
        tokgen = generate_tokens(readline)
        for toknum, tokval, _, _, _ in tokgen:
            print("%s %s" % (tok_name[toknum], repr(tokval)))

    show_tokens(StringIO("def foo(): pass\n").readline)
    print()
    show_tokens(StringIO("1 + 1\n").readline)
    print()
    show_tokens(StringIO("#\n").readline)
    print()
    show_tokens(StringIO("#\n\n").readline)
    print()

# Generated at 2022-06-17 17:10:54.603493
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"pass\n"]

    def readline():
        yield b"#!/usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"#!/usr/bin/python\n", b"# coding: latin-1\n", b"pass\n"]
