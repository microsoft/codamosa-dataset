

# Generated at 2022-06-17 17:02:15.800556
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3", (1, 0), (1, 1), "")
    printtoken(STRING, "a", (1, 0), (1, 1), "")
    printtoken(NEWLINE, "\n", (1, 0), (1, 1), "")
    printtoken(INDENT, "", (1, 0), (1, 1), "")
    printtoken(DEDENT, "", (1, 0), (1, 1), "")
    printtoken(ENDMARKER, "", (1, 0), (1, 1), "")


# Generated at 2022-06-17 17:02:23.666866
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "1", (1, 2), (1, 3), "")
    printtoken(NAME, "abc", (1, 2), (1, 5), "")
    printtoken(OP, "+", (1, 2), (1, 3), "")
    printtoken(STRING, "abc", (1, 2), (1, 5), "")
    printtoken(NEWLINE, "\n", (1, 2), (1, 3), "")
    printtoken(INDENT, "", (1, 2), (1, 2), "")
    printtoken(DEDENT, "", (1, 2), (1, 2), "")
    printtoken(ENDMARKER, "", (1, 2), (1, 2), "")


# Generated at 2022-06-17 17:02:30.583486
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    tokenize.tokenize(r)
    r = io.StringIO("def f(x): return 2*x").readline
    tokenize.tokenize(r, print)
    r = io.StringIO("def f(x): return 2*x").readline
    tokenize.tokenize(r, lambda *args: None)



# Generated at 2022-06-17 17:02:40.137583
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.fixer_util import Name

    def tokeneater(*args):
        tok = args[0]
        if tok == token.NAME:
            tok = syms.name
        elif tok == token.NUMBER:
            tok = syms.number
        elif tok == token.STRING:
            tok = sy

# Generated at 2022-06-17 17:02:52.233405
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    untok.tokens.append('def')
    untok.prev_row = 1
    untok.prev_col = 3
    untok.add_whitespace((1, 3))
    untok.tokens.append('f')
    untok.prev_row = 1
    untok.prev_col = 4
    untok.add_whitespace((1, 4))
    untok.tokens.append('(x):')
    untok.prev_row = 1
    untok.prev_col = 8
    untok.add_whitespace((2, 0))

# Generated at 2022-06-17 17:03:03.305776
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", " "]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", " ", "\n"]
    u.add_whitespace((2, 1))
    assert u.tokens == [" ", " ", "\n", " "]
    u.add_whitespace((3, 0))

# Generated at 2022-06-17 17:03:09.893055
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens
    from token import NAME, NUMBER, STRING, NEWLINE, INDENT, DEDENT, ENDMARKER
    from token import ASYNC, AWAIT

    def test_tokenize(s):
        return list(generate_tokens(StringIO(s).readline))

    def test_untokenize(s):
        return Untokenizer().untokenize(test_tokenize(s))

    assert test_untokenize("a = 1") == "a = 1 "
    assert test_untokenize("a = 1\nb = 2") == "a = 1\nb = 2 "
    assert test_untokenize("a = 1\n\nb = 2") == "a = 1\n\nb = 2 "
    assert test_untoken

# Generated at 2022-06-17 17:03:18.914091
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from contextlib import redirect_stdout
    f = io.StringIO()
    with redirect_stdout(f):
        tokenize_loop(iter(["print(1)"]).__next__, printtoken)
    assert f.getvalue() == "1,0-1,5:\tNAME\t'print'\n1,5-1,6:\tOP\t'('\n1,6-1,7:\tNUMBER\t'1'\n1,7-1,8:\tOP\t')'\n1,8-1,9:\tNEWLINE\t'\\n'\n"



# Generated at 2022-06-17 17:03:26.991241
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, ENDMARKER
    from io import BytesIO

    def check(input, output):
        result = Untokenizer().untokenize(generate_tokens(StringIO(input).readline))
        assert result == output, "%r != %r" % (result, output)

    check("def f():\n    pass\n", "def f():\n    pass\n")
    check("def f():\n    pass", "def f():\n    pass\n")
    check("def f():\n    pass\n\n", "def f():\n    pass\n\n")

# Generated at 2022-06-17 17:03:38.860651
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "123", (0, 0), (0, 3), "123")
    printtoken(NAME, "abc", (0, 0), (0, 3), "abc")
    printtoken(OP, "=", (0, 0), (0, 1), "=")
    printtoken(STRING, "abc", (0, 0), (0, 3), "abc")
    printtoken(NEWLINE, "\n", (0, 0), (0, 1), "\n")
    printtoken(INDENT, "", (0, 0), (0, 0), "")
    printtoken(DEDENT, "", (0, 0), (0, 0), "")
    printtoken(COMMENT, "# abc", (0, 0), (0, 5), "# abc")

# Generated at 2022-06-17 17:04:16.781584
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    untok.compat((NAME, "a"), [(NAME, "b"), (NAME, "c")])
    assert untok.tokens == ["a ", "b ", "c "]



# Generated at 2022-06-17 17:04:25.926726
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List

    def tokeneater(type: int, token: str, start: Tuple[int, int], end: Tuple[int, int], line: str) -> None:
        print(tokenize.tok_name[type], repr(token))

    s = "def f(x): return 2*x"
    g = generate_tokens(io.StringIO(s).readline)  # create a generator
    for token in g:
        tokeneater(*token)



# Generated at 2022-06-17 17:04:38.527101
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=iso-8859-1\n"
        yield b"# coding=iso-latin-1\n"
        yield b"# coding=iso-latin-1-foo\n"
        yield b"# coding=iso-latin-1-foo-bar\n"
        yield b"# coding=iso-latin-1-foo-bar-baz\n"
        yield b"# coding=iso-latin-1-foo-bar-baz-quux\n"
        yield b"# coding=iso-latin-1-foo-bar-baz-quux-quuux\n"

# Generated at 2022-06-17 17:04:49.191102
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from io import StringIO
    from typing import Iterable
    from blib2to3.pgen2.token import *
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.pgen import LazyParser
    from blib2to3.pygram import python_grammar_no_print_statement

# Generated at 2022-06-17 17:04:56.318858
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from token import tok_name

    s = "1+1"
    f = StringIO(s)
    l = []
    tokenize_loop(f.readline, l.append)
    assert l == [
        (NUMBER, "1", (1, 0), (1, 1), s),
        (OP, "+", (1, 1), (1, 2), s),
        (NUMBER, "1", (1, 2), (1, 3), s),
        (ENDMARKER, "", (1, 3), (1, 3), s),
    ]



# Generated at 2022-06-17 17:05:08.848561
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:05:22.044634
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:05:29.403606
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    import unittest

    class TestTokenize(unittest.TestCase):
        def test_tokenize(self):
            readline = io.StringIO("if 1:\n  pass\n").readline
            tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:05:36.704623
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#! /usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: latin-1\n"

# Generated at 2022-06-17 17:05:51.702734
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some other comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"\n"
        yield b"# coding: iso-8859-1\n"
        yield b"\n"
        yield b"# coding: iso-latin-1\n"
        yield b"\n"
        yield b"# coding: latin-1-foo\n"
        yield b"\n"
        yield b"# coding: iso-8859-1-foo\n"
        yield b"\n"


# Generated at 2022-06-17 17:06:30.376891
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: ascii -*-"
        yield b"\n"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: unknown -*-"
        yield b"\n"

# Generated at 2022-06-17 17:06:41.918109
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    def test(input, output):
        result = untokenize(generate_tokens(StringIO(input).readline))
        assert result == output, "%r != %r" % (result, output)

    test("def f():\n  pass\n", "def f():\n  pass\n")
    test("def f():\n  pass\n\n", "def f():\n  pass\n\n")
    test("def f():\n  pass\n\n\n", "def f():\n  pass\n\n\n")

# Generated at 2022-06-17 17:06:49.311183
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.tokenize import TokenError
    from blib2to3.pgen2.tokenize import StopTokenizing
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import COMMENT
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import OP
    from blib2to3.pgen2.tokenize import NUMBER

# Generated at 2022-06-17 17:06:55.851360
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(tokenize(io.BytesIO(s.encode("utf-8")).readline))

    def _names(s):
        return [tok_name[toktype] for toktype, _, _, _, _ in _tokens(s)]

    assert _names("a = 1") == ["NAME", "EQUAL", "NUMBER", "NEWLINE"]
    assert _names("a = 1\\\n") == ["NAME", "EQUAL", "NUMBER", "NEWLINE"]
    assert _names("a = 1\\\n\\\n") == ["NAME", "EQUAL", "NUMBER", "NEWLINE"]

# Generated at 2022-06-17 17:07:02.304717
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'# -*- coding: iso-8859-1 -*-\n'
        yield b'# -*- coding: iso-latin-1 -*-\n'
        yield b'# -*- coding: utf-8 -*-\n'
        yield b'# -*- coding: utf-8-sig -*-\n'
        yield b'# -*- coding: utf-8-foo -*-\n'
        yield b'# -*- coding: utf-8-bar -*-\n'
        yield b'# -*- coding: utf-8-baz -*-\n'

# Generated at 2022-06-17 17:07:13.193056
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b")]) == "ab"
    assert u.untokenize([(1, "a"), (0, " "), (2, "b")]) == "a b"
    assert u.untokenize([(1, "a"), (0, "\n"), (2, "b")]) == "a\nb"
    assert u.untokenize([(1, "a"), (0, "\n"), (0, " "), (2, "b")]) == "a\n b"
    assert u.untokenize([(1, "a"), (0, "\n"), (0, " "), (0, "\n"), (2, "b")]) == "a\n\nb"

# Generated at 2022-06-17 17:07:26.151066
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import NUMBER, NAME, NEWLINE, INDENT, DEDENT
    from blib2to3.pgen2.tokenize import tok_name
    from blib2to3.pgen2.tokenize import COMMENT, NL, ENCODING
    from blib2to3.pgen2.tokenize import TokenInfo

    def readline():
        return next(lines)

    def tokeneater(*args):
        toks.append(TokenInfo(*args))


# Generated at 2022-06-17 17:07:30.804754
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name

    def show_tokens(input):
        print("tokens for %r:" % input)
        for token in generate_tokens(StringIO(input).readline):
            print(token)
        print()

    show_tokens("1 + 1")
    show_tokens("1 + 1\n")
    show_tokens("1 + 1\n\n")
    show_tokens("1 + 1\n\n\n")
    show_tokens("1 + 1\n\n\n\n")
    show_tokens("1 + 1\n\n\n\n\n")
    show_tokens("1 + 1\n\n\n\n\n\n")
    show_

# Generated at 2022-06-17 17:07:42.181766
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from token import tok_name
    from unittest import TestCase
    from blib2to3.pgen2.tokenize import untokenize

    class Test(TestCase):
        def test_untokenize(self):
            for t in generate_tokens(StringIO("a = 1").readline):
                self.assertEqual(t[0], NAME)
                self.assertEqual(t[1], "a")
                break
            self.assertEqual(untokenize([t]), "a = 1")

# Generated at 2022-06-17 17:07:54.735566
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    from .tokenize import generate_tokens
    from .token import tok_name

    def untokenize(iterable):
        return Untokenizer().untokenize(iterable)

    def roundtrip(s):
        result = []
        g = generate_tokens(io.StringIO(s).readline)
        for token in g:
            result.append((tok_name[token[0]], token[1]))
        return untokenize(result)

    assert roundtrip("def f(x): return x**2\n") == "def f(x): return x**2\n"
    assert roundtrip("# coding: latin-1\n") == "# coding: latin-1\n"

# Generated at 2022-06-17 17:08:53.625924
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:09:06.771881
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c")]) == "abc"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "")]) == "abc"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, ""), (5, "d")]) == "abc\nd"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, ""), (5, "d"), (6, "")]) == "abc\nd"

# Generated at 2022-06-17 17:09:19.040961
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import untokenize_print
    from tokenize import untokenize_printable
    from tokenize import untokenize_readable
    from tokenize import untokenize_walk
    from tokenize import untokenize_walkable
    from tokenize import untokenize_with_newlines
    from tokenize import untokenize_with_offsets
    from tokenize import untokenize_with_printable
    from tokenize import untokenize_with_readable
    from tokenize import untokenize_with_tabs
    from tokenize import untokenize_with_whitespace

# Generated at 2022-06-17 17:09:28.835896
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tokenize, generate_tokens, tok_name
    from blib2to3.pgen2.tokenize import untokenize, detect_encoding, COMMENT, NL, ENCODING
    from blib2to3.pgen2.tokenize import INDENT, DEDENT, NEWLINE, ENDMARKER, NAME, OP
    from blib2to3.pgen2.tokenize import NUMBER, STRING, ENCODING
    from blib2to3.pgen2.tokenize import TokenInfo
    from blib2to3.pgen2.tokenize import TokenError

    def readline():
        return b"a = 1 + 2\n"

    def tokeneater(*args):
        to

# Generated at 2022-06-17 17:09:40.256814
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    assert untok.untokenize([(1, "a"), (2, "b")]) == "a b"
    assert untok.untokenize([(1, "a"), (2, "b"), (0, "c")]) == "a b c"
    assert untok.untokenize([(1, "a"), (2, "b"), (0, "c"), (3, "d")]) == "a b c d"
    assert untok.untokenize([(1, "a"), (2, "b"), (0, "c"), (3, "d"), (4, "e")]) == "a b c d e"

# Generated at 2022-06-17 17:09:50.101852
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    r = BytesIO(b"def f(x):\n  return x+1\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tokenize.tok_name[toknum], tokval)

test_generate_tokens()


# Generated at 2022-06-17 17:09:57.597560
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:10:02.252493
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    for token in generate_tokens(readline):
        print(token)
        print(tok_name[token.type])

test_generate_tokens()


# Generated at 2022-06-17 17:10:09.871878
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:10:19.183509
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    result = []
    tokenize.tokenize(r, result.append)