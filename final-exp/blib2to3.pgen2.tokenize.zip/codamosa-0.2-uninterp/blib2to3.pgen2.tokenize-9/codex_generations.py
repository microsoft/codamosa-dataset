

# Generated at 2022-06-17 17:01:50.721849
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    ut = Untokenizer()
    ut.compat((NAME, "if"), [(NAME, "a"), (NAME, "b"), (NAME, "c")])
    assert ut.tokens == ["if ", "a ", "b ", "c"]



# Generated at 2022-06-17 17:02:02.258510
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# comment\n"
        yield b"#!python\n"
        yield b"# -*- coding: cp-1252 -*-\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"

# Generated at 2022-06-17 17:02:07.281381
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == [" ", " ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", " ", "\n", " "]
    untok.add_whitespace((3, 0))
    assert untok

# Generated at 2022-06-17 17:02:10.281266
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    r = io.StringIO("def f(x):\n  return x+1\n")
    for t in generate_tokens(r.readline):
        print(tok_name[t[0]], t[1])


# Generated at 2022-06-17 17:02:13.289007
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    r = StringIO("def foo(a, b):\n  print(a)\n  print(b)")
    tokens = tokenize.generate_tokens(r.readline)
    for tok in tokens:
        print(tok)

test_generate_tokens()


# Generated at 2022-06-17 17:02:22.805826
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO

    s = StringIO("def f(x): return x + 1\n")
    tokenize_loop(s.readline, tokenize.printtoken)
    s = StringIO("def f(x): return x + 1\n")
    lst = []
    tokenize_loop(s.readline, lst.append)

# Generated at 2022-06-17 17:02:33.253642
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    # Test empty string
    readline = iter([]).__next__
    tokens = generate_tokens(readline)
    assert next(tokens) == (0, "")

    # Test tokenizing of simple expressions
    readline = iter(["1 + 1\n", "2\n"]).__next__
    tokens = generate_tokens(readline)
    assert next(tokens) == (1, "1")
    assert next(tokens) == (51, "+")
    assert next(tokens) == (1, "1")
    assert next(tokens) == (4, "\n")
    assert next(tokens) == (1, "2")
    assert next(tokens) == (4, "\n")


# Generated at 2022-06-17 17:02:42.023089
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import tokenize as pgen2_tokenize
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.token import Token

# Generated at 2022-06-17 17:02:53.304994
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#! /usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8 with spaces\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig with spaces\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# -*- coding: utf-8-sig -*-\n"
        yield b"# -*- coding: utf-8-sig -*- with spaces\n"
        yield b"# -*- coding: utf-8 -*- with spaces\n"
        yield

# Generated at 2022-06-17 17:03:04.201482
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some other comment\n"
        yield b"# another other comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"# some other comment\n"
        yield b"# another other comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some other comment\n"
        yield b"# another other comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:05:25.332759
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io
    import unittest

    class Test(unittest.TestCase):
        def test_generate_tokens(self):
            readline = io.StringIO("if 1:\n  pass\n").readline
            tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:05:30.288472
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(
        b"""def square(n):
    return n**2

for i in range(10):
    print(square(i))
"""
    ).readline
    tokens = generate_tokens(readline)
    for tokentype, token, start, end, line in tokens:
        print(tokenize.tok_name[tokentype], repr(token))
    print(untokenize(tokens).decode("utf-8"))



# Generated at 2022-06-17 17:05:35.076407
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    r = io.BytesIO(b"def f(x):\n  return x+1\n")
    tokens = generate_tokens(r.readline)
    for tok in tokens:
        print(tok)



# Generated at 2022-06-17 17:05:49.801889
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"blah = 1 + 1\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"blah = 1 + 1\n"
        yield b"# vim: set fileencoding=iso-8859-15:\n"
        yield b"blah = 1 + 1\n"
        yield b"\xef\xbb\xbf# coding: utf-8\n"
        yield b"blah = 1 + 1\n"
        yield b"# coding: ascii\n"
        yield b"blah = 1 + 1\n"

# Generated at 2022-06-17 17:05:59.429215
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import untokenize_printable
    from tokenize import COMMENT
    from tokenize import ENCODING
    from tokenize import ENDMARKER
    from tokenize import INDENT
    from tokenize import NAME
    from tokenize import NEWLINE
    from tokenize import NL
    from tokenize import NUMBER
    from tokenize import OP
    from tokenize import STRING
    from tokenize import TokenError
    from tokenize import TokenInfo
    from tokenize import TokenInfo
    from tokenize import TokenInfo
    from tokenize import TokenInfo
    from tokenize import TokenInfo

# Generated at 2022-06-17 17:06:07.512784
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"def foo(): pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [
        b"# coding: latin-1\n",
        b"# comment\n",
        b"# more comment\n",
        b"\n",
        b"# yet more comment\n",
    ]

    def readline():
        yield b"# coding=utf-8\n"
        yield b"# comment\n"

# Generated at 2022-06-17 17:06:16.595798
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"\n"
        yield b"# -*- coding: ascii -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: utf-16 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-32 -*-"
        yield b"\n"

# Generated at 2022-06-17 17:06:29.475758
# Unit test for function tokenize
def test_tokenize():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b'foo = "bar"\n').readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (
        NAME,
        "foo",
        (1, 0),
        (1, 3),
        "foo = \"bar\"\n",
    )  # type: ignore
    assert tokens[1] == (OP, "=", (1, 4), (1, 5), "foo = \"bar\"\n")
    assert tokens[2] == (
        STRING,
        '"bar"',
        (1, 6),
        (1, 11),
        "foo = \"bar\"\n",
    )  # type: ignore
   

# Generated at 2022-06-17 17:06:36.137502
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b"def f(x):\n  return x+1\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print("%10s %-14s" % (tokenize.tok_name[toknum], repr(tokval)))


# Generated at 2022-06-17 17:06:46.267080
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"# vim: set fileencoding=iso-8859-15 :\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"# vim: set fileencoding=iso-8859-15 :\n"
        yield b"\n"

# Generated at 2022-06-17 17:07:56.687307
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    r = io.StringIO("def f(x): return x+1\n")
    tokenize_module.tokenize_loop(r.readline, tokenize_module.printtoken)
    r = io.StringIO("def f(x): return x+1\n")
    tokenize_module.tokenize_loop(r.readline, tokenize_module.printtoken)



# Generated at 2022-06-17 17:08:03.579128
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    from token import tok_name

    text = "def f(x): return 2*x"
    g = tokenize.generate_tokens(StringIO(text).readline)
    for toknum, tokval, _, _, _ in g:
        print("%10s %-14s" % (tok_name[toknum], repr(tokval)))


# Generated at 2022-06-17 17:08:16.933510
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    with io.StringIO("a = 1 + 2\n") as f:
        for t in generate_tokens(f.readline):
            print(t)

    with io.StringIO("a = 1 + 2\n") as f:
        for t in generate_tokens(f.readline):
            print(tok_name[t[0]], t[1])

    with io.StringIO("a = 1 + 2\n") as f:
        for t in generate_tokens(f.readline):
            print(t[0], tok_name[t[0]], t[1])


# Generated at 2022-06-17 17:08:28.882298
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!python\n"
        yield b"# -*- coding: iso-8859-1 -*-\n"
        yield b"# vim: set fileencoding=iso-8859-15 :\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# coding=ascii\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"

# Generated at 2022-06-17 17:08:35.236234
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x\n")
    result = []
    tokenize.tokenize(r.readline, result.append)

# Generated at 2022-06-17 17:08:43.918568
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some other comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some other comment\n"
        yield b"# coding: ascii\n"
        yield b"# some other comment\n"
        yield b"# coding: utf-8\n"
        yield b"# some other comment\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some other comment\n"
        yield b"# coding: utf-16\n"
        yield b"# some other comment\n"
        yield b"# coding: utf-32\n"
        yield b"# some other comment\n"


# Generated at 2022-06-17 17:08:57.375404
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"pass"
    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"pass"]

    def readline():
        yield b"# -*- coding: ascii -*-"
        yield b"pass"
    try:
        detect_encoding(readline)
    except SyntaxError:
        pass
    else:
        assert 0, "should have raised SyntaxError"

    def readline():
        yield b"# coding: ascii"
        yield b"pass"
    encoding, lines = detect_encoding(readline)

# Generated at 2022-06-17 17:09:09.492205
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    from blib2to3.pgen2.tokenize import untokenize
    untok = Untokenizer()
    f = StringIO("def f():\n  pass\n")
    tokens = generate_tokens(f.readline)
    assert untok.compat(next(tokens), tokens) is None
    assert untok.tokens == ["def "]
    assert untok.compat(next(tokens), tokens) is None
    assert untok.tokens == ["def ", "f", "(", ")"]
    assert untok.compat(next(tokens), tokens) is None


# Generated at 2022-06-17 17:09:19.348540
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:09:29.147871
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), "1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), "1 + 1\n")

# Generated at 2022-06-17 17:10:34.566164
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    readline = io.StringIO("if 1:\n  pass\n").readline
    for token in generate_tokens(readline):
        print(tok_name[token.type], token.string, token.start, token.end, token.line)


# Generated at 2022-06-17 17:10:43.320609
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    r = io.StringIO("def f(x): return x+1").readline
    l = []
    tokenize.tokenize_loop(r, l.append)