

# Generated at 2022-06-17 17:02:01.229541
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b"def f(x):\n  return x**2\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tokenize.tok_name[toknum], tokval)


# Generated at 2022-06-17 17:02:06.495673
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens

    def test(input, expected):
        result = Untokenizer().compat(
            (ENCODING, "utf-8"), generate_tokens(StringIO(input).readline)
        )
        assert result == expected, (result, expected)

    test("def f(x):\n return x\n", "def f ( x ) :\n return x\n")
    test("def f(x):\n return x", "def f ( x ) :\n return x ")
    test("def f(x):\n return x\n\n", "def f ( x ) :\n return x\n\n")

# Generated at 2022-06-17 17:02:13.044611
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    import unittest

    class Test(unittest.TestCase):
        def test_tokenize_loop(self):
            s = io.StringIO("def f(): pass\n")
            result = []
            tokenize.tokenize_loop(s.readline, result.append)

# Generated at 2022-06-17 17:02:18.268725
# Unit test for function detect_encoding

# Generated at 2022-06-17 17:02:25.336976
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b")]) == "ab"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c")]) == "abc"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d")]) == "abcd"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")]) == "abcde"

# Generated at 2022-06-17 17:02:36.113955
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:02:47.783969
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = tokenize(readline)
    token_type, token_string, start, end, line = next(tokens)
    assert token_type == NUMBER
    assert token_string == "1"
    assert start == (1, 0)
    assert end == (1, 1)
    assert line == "1 + 1\n"
    token_type, token_string, start, end, line = next(tokens)
    assert token_type == OP
    assert token_string == "+"
    assert start == (1, 2)
    assert end == (1, 3)

# Generated at 2022-06-17 17:02:56.659941
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import *
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    def remove_prefix(s, prefix):
        if s.startswith(prefix):
            return s[len(prefix) :]
        return s

    def remove_suffix(s, suffix):
        if s.endswith(suffix):
            return s[: -len(suffix)]
        return s

    def remove_quotes(s):
        return remove_prefix(remove_suffix(s, "'"), "'")

    def remove_triple_quotes(s):
        return remove_prefix(remove_suffix(s, "'''"), "'''")


# Generated at 2022-06-17 17:03:06.084957
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize

    readline = io.BytesIO(b"if 1:\n    print(1)\n").readline
    tokens = generate_tokens(readline)
    types = [tokenize.tok_name[toktype] for toktype, _, _, _, _ in tokens]
    assert types == ["NAME", "NUMBER", "NEWLINE", "INDENT", "NAME", "LPAR", "NUMBER", "RPAR", "NEWLINE", "DEDENT", "ENDMARKER"]

    readline = io.BytesIO(b"if 1:\n    print(1)\n").readline
    tokens = tokenize.generate_tokens(readline)

# Generated at 2022-06-17 17:03:11.726674
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List

    def _format(tok: GoodTokenInfo) -> str:
        return "{} {} {} {} {} {}".format(
            *tok,
            repr(tok.string).ljust(10),
            token.tok_name[tok.type],
            tok.start,
            tok.end,
            tok.line,
        )

    def _test(s: str, expected: List[str]) -> None:
        result = []
        for tok in generate_tokens(io.StringIO(s).readline):
            result.append(_format(tok))
        assert result == expected


# Generated at 2022-06-17 17:04:58.743635
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.add_whitespace((1, 0))
    untok.tokens.append("def")
    untok.prev_row = 1
    untok.prev_col = 3
    untok.add_whitespace((1, 4))
    untok.tokens.append("f")
    untok.prev_row = 1
    untok.prev_col = 5
    untok.add_whitespace((1, 6))
    untok.tokens.append("(")
    untok.prev_row = 1
    untok.prev_col = 7
    untok.add_whitespace((1, 8))
    untok.tokens.append(")")
    untok.prev_row = 1

# Generated at 2022-06-17 17:05:11.043072
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c")]) == "abc"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d")]) == "abcd"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")]) == "abcde"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e"), (6, "f")]) == "abcdef"

# Generated at 2022-06-17 17:05:17.994191
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b"if 1:\n  pass\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tokenize.tok_name[toknum], tokval)


# Generated at 2022-06-17 17:05:27.458447
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"

# Generated at 2022-06-17 17:05:34.045803
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print("%s %s" % (token.tok_name[toknum], repr(tokval)))



# Generated at 2022-06-17 17:05:47.237158
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# vim:fileencoding=utf-8\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"# -*- coding: iso-latin-1 -*-\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# -*- coding: latin-9 -*-\n"
        yield b"# -*- coding: cp-1252 -*-\n"

# Generated at 2022-06-17 17:05:57.862509
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List

    def _format(tok: GoodTokenInfo) -> str:
        return "{} {} {} {} {}".format(*tok)

    def _format_tokens(tokens: List[GoodTokenInfo]) -> str:
        return "\n".join(_format(tok) for tok in tokens)

    def _test(source: str, expected: str) -> None:
        source = source.encode("utf-8")
        expected = expected.encode("utf-8")
        tokens = list(tokenize.generate_tokens(io.BytesIO(source).readline))
        got = _format_tokens(tokens)
        assert got == expected, "%r != %r" % (got, expected)


# Generated at 2022-06-17 17:06:06.476725
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"# foo", b"# bar", b"# baz"]

    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:06:14.218918
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT

    def test_tokenize(s):
        return list(generate_tokens(StringIO(s).readline))

    def test_untokenize(tokens):
        untokenizer = Untokenizer()
        return untokenizer.compat(tokens[0], tokens[1:])

    def test_untokenize_string(s):
        return test_untokenize(test_tokenize(s))


# Generated at 2022-06-17 17:06:16.243534
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as tokenize_module
    from blib2to3.pgen2.token import tok_name

    def readline():
        return next(lines)


# Generated at 2022-06-17 17:06:54.853667
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(generate_tokens(io.StringIO(s).readline))

    def _token_names(s):
        return [tok_name[toknum] for toknum, _, _, _, _ in _tokens(s)]

    assert _token_names("") == ["ENDMARKER"]
    assert _token_names("\n") == ["NL", "ENDMARKER"]
    assert _token_names("\n\n") == ["NL", "NL", "ENDMARKER"]
    assert _token_names("\n\n\n") == ["NL", "NL", "NL", "ENDMARKER"]

# Generated at 2022-06-17 17:07:06.475426
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from io import StringIO
    from token import *

    s = "def f(x): return 2*x\n"
    f = StringIO(s)
    rl = f.readline
    result = []
    tokenize_module.tokenize_loop(rl, result.append)

# Generated at 2022-06-17 17:07:11.216055
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b""

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"# foo", b"# bar", b"# baz"]

    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# -*- coding: utf-8 -*-"
        yield b""

    encoding, lines = detect_enc

# Generated at 2022-06-17 17:07:18.172032
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, ENDMARKER
    from unittest import TestCase

    class Test(TestCase):
        def test_untokenize(self):
            untok = Untokenizer()
            untok.compat = False
            f = StringIO("def f():\n    print(1)\n")
            tokens = list(generate_tokens(f.readline))
            self.assertEqual(
                untok.untokenize(tokens), "def f():\n    print(1)\n"
            )
            f = StringIO("def f():\n    print(1)\n")
            tokens = list(generate_tokens(f.readline))

# Generated at 2022-06-17 17:07:30.648542
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == ["  "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == ["  ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == ["  ", "\n", " "]

# Generated at 2022-06-17 17:07:38.769515
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return x+1\n")
    result = []
    tokenize.tokenize(r.readline, result.append)
    assert result == [
        (token.NUMBER, "1", (1, 0), (1, 1), "\n"),
        (token.NEWLINE, "\n", (1, 1), (1, 2), "\n"),
        (token.ENDMARKER, "", (2, 0), (2, 0), ""),
    ]



# Generated at 2022-06-17 17:07:48.081401
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b"if 1:\n  pass\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print("%10s %-14s" % (tokenize.tok_name[toknum], repr(tokval)))


# Generated at 2022-06-17 17:07:51.777197
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b"if 1:\n  pass\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tokenize.tok_name[toknum], tokval)


# Generated at 2022-06-17 17:08:04.541177
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: iso-latin-1 -*-\n"
        yield b"# vim: set fileencoding=iso-latin-1 :\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: 8-bit-ascii -*-\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# -*- coding: utf-8-sig -*-\n"
        yield b"# -*- coding: utf-8-with-signature -*-\n"
        yield

# Generated at 2022-06-17 17:08:17.571608
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io
    import unittest
    import sys

    class Test(unittest.TestCase):
        def test_generate_tokens(self):
            readline = io.BytesIO(b"if 1:\n  pass\n").readline
            tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:09:25.432792
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for tok in tokens:
        print(tok)

    g = generate_tokens(readline)
    for toknum, tokval, _, _, _ in g:
        if toknum == token.NAME and tokval in ("def", "class"):
            break
    else:
        assert 0, "Didn't find 'def' or 'class'"

    # Test untokenize
    g = generate_tokens(readline)

# Generated at 2022-06-17 17:09:31.841544
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "def f(x):"
        yield "  return x+1"
    tokeneater = lambda type, token, start, end, line: print(
        "%d,%d-%d,%d:\t%s\t%s" % (start[0], start[1], end[0], end[1], tok_name[type], repr(token))
    )
    tokenize_loop(readline, tokeneater)


# Generated at 2022-06-17 17:09:42.194055
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name

    def tokenize(s):
        result = []
        g = generate_tokens(StringIO(s).readline)
        for toknum, tokval, _, _, _ in g:
            result.append((tok_name[toknum], tokval))
        return result

    assert tokenize("1") == [("NUMBER", "1")]
    assert tokenize("1.2") == [("NUMBER", "1.2")]
    assert tokenize("1.") == [("NUMBER", "1.")]
    assert tokenize(".1") == [("NUMBER", ".1")]
    assert tokenize("1.2e3") == [("NUMBER", "1.2e3")]

# Generated at 2022-06-17 17:09:53.866836
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (1, 'b'), (1, 'c')])
    assert untok.tokens == ['a', 'b', 'c']
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (1, 'b'), (1, 'c'), (1, 'd'), (1, 'e')])
    assert untok.tokens == ['a', 'b', 'c', 'd', 'e']
    untok.tokens = []

# Generated at 2022-06-17 17:10:00.640769
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize

    class TokenEater:
        def __init__(self):
            self.tokens = []

        def __call__(self, type, token, start, end, line):
            self.tokens.append((type, token))

    s = "def f(x): return 2*x"
    f = io.StringIO(s)
    eater = TokenEater()
    tokenize.tokenize_loop(f.readline, eater)

# Generated at 2022-06-17 17:10:08.871722
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import untokenize

    # Test tokenize on a source string
    src = "def f(x): return 2*x\n"
    tokens = generate_tokens(StringIO(src).readline)
    result = [tok[:2] for tok in tokens]

# Generated at 2022-06-17 17:10:19.005927
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:10:29.836151
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2.tokenize import generate_tokens

    def readline():
        return next(lines)

    def tokeneater(*args):
        tok = Leaf(args, context=None)
        tokens.append(tok)

    lines = iter(
        [
            "def f(x):\n",
            "    return x + 1\n",
            "\n",
            "f(1)\n",
            "f(2)\n",
            "f(3)\n",
        ]
    )
    tokens = []
    tokenize_loop(readline, tokeneater)
    assert tokens

# Generated at 2022-06-17 17:10:41.449497
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import BytesIO
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"print(1+1)\n").readline
    tokens = []
    tokenize_loop(readline, tokens.append)
    for t in tokens:
        assert isinstance(t, tuple)
        assert len(t) == 5
        assert isinstance(t[0], int)
        assert isinstance(t[1], str)
        assert isinstance(t[2], tuple)
        assert len(t[2]) == 2
        assert isinstance(t[2][0], int)
        assert isinstance(t[2][1], int)
        assert isinstance(t[3], tuple)

# Generated at 2022-06-17 17:10:54.448916
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import NUMBER, STRING, NAME, OP
    from tokenize import COMMENT, ENDMARKER, NEWLINE, INDENT, DEDENT
    from tokenize import ENCODING, NL, COMMENT, ERRORTOKEN
    from tokenize import generate_tokens
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import NUMBER, STRING, NAME, OP
    from tokenize import COMMENT, ENDMARKER, NEWLINE, INDENT, DEDENT
    from tokenize import ENCODING, NL, COMMENT, ERRORTOKEN
    from tokenize import generate