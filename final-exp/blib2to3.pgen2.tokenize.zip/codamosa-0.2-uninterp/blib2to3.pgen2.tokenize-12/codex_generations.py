

# Generated at 2022-06-17 17:02:12.524418
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    result = []
    tokenize.tokenize(r, result.append)

# Generated at 2022-06-17 17:02:17.817401
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"# coding=ascii\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-16\n"
        yield b"# coding: utf-16\n"
        yield b"# coding=utf-16-le\n"
        yield b"# coding: utf-16-le\n"
        yield b"# coding=utf-16-be\n"
        yield b"# coding: utf-16-be\n"
        yield b"# coding=utf-32\n"
        yield b

# Generated at 2022-06-17 17:02:25.125306
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()

# Generated at 2022-06-17 17:02:36.113392
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    assert untok.untokenize([(1, "a"), (2, "b")]) == "ab"
    assert untok.untokenize([(1, "a"), (0, " "), (2, "b")]) == "a b"
    assert untok.untokenize([(1, "a"), (0, "\n"), (2, "b")]) == "a\nb"
    assert untok.untokenize([(1, "a"), (0, "\n"), (4, " "), (2, "b")]) == "a\n b"
    assert untok.untokenize([(1, "a"), (0, "\n"), (4, "\t"), (2, "b")]) == "a\n\tb"
    assert untok.untokenize

# Generated at 2022-06-17 17:02:43.397903
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3", (1, 0), (1, 1), "")
    printtoken(STRING, "3", (1, 0), (1, 1), "")
    printtoken(NAME, "3", (1, 0), (1, 1), "")
    printtoken(OP, "3", (1, 0), (1, 1), "")
    printtoken(NEWLINE, "3", (1, 0), (1, 1), "")
    printtoken(INDENT, "3", (1, 0), (1, 1), "")
    printtoken(DEDENT, "3", (1, 0), (1, 1), "")
    printtoken(ENDMARKER, "3", (1, 0), (1, 1), "")

# Generated at 2022-06-17 17:02:54.235991
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import tok_name
    from blib2to3.pgen2.tokenize import COMMENT
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import ENCODING
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import OP
    from blib2to3.pgen2.tokenize import STRING

# Generated at 2022-06-17 17:03:04.919138
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.token import tokenize as _tokenize
    from blib2to3.pgen2.token import untokenize as _untokenize
    from blib2to3.pgen2.token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    from blib2to3.pgen2.token import COMMENT, ENCODING, STRING, ENDMARKER
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.token import generate_tokens as _generate_tokens
    from blib2to3.pgen2.token import untokenize as _untoken

# Generated at 2022-06-17 17:03:15.429887
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s: str) -> Iterator[GoodTokenInfo]:
        return generate_tokens(io.StringIO(s).readline)

    def _token_names(s: str) -> Iterator[str]:
        return (tok_name[toknum] for toknum, _, _, _, _ in _tokens(s))

    assert list(_token_names("a = 1 + 2\n")) == ["NAME", "EQUAL", "NUMBER", "PLUS", "NUMBER", "NEWLINE", "ENDMARKER"]
    assert list(_token_names("a = 1 + 2")) == ["NAME", "EQUAL", "NUMBER", "PLUS", "NUMBER", "ENDMARKER"]

# Generated at 2022-06-17 17:03:22.632543
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3", (1, 0), (1, 1), "")
    printtoken(STRING, "abc", (1, 0), (1, 3), "")
    printtoken(NEWLINE, "\n", (1, 0), (1, 1), "")
    printtoken(INDENT, "", (1, 0), (1, 0), "")
    printtoken(DEDENT, "", (1, 0), (1, 0), "")
    printtoken(ENDMARKER, "", (1, 0), (1, 0), "")



# Generated at 2022-06-17 17:03:27.551494
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == ["  "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == ["  ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == ["  ", "\n", " "]

# Generated at 2022-06-17 17:03:50.897033
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "1", (0, 0), (0, 1), "")


# Generated at 2022-06-17 17:03:59.913055
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: iso-8859-1 -*-\n"
        yield b"# vim: set fileencoding=iso-8859-1 :\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: 8-bit -*-\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# -*- coding: utf-8-sig -*-\n"
        yield b"# -*- coding: utf-8-with-signature -*-\n"

# Generated at 2022-06-17 17:04:04.716426
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    s = "def f(x): return 2*x\n"
    g = generate_tokens(StringIO(s).readline)
    for t in g:
        print(t)


# Generated at 2022-06-17 17:04:15.170660
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    with io.StringIO("def f(x): return x + 1") as f:
        for token in generate_tokens(f.readline):
            print(token)

    with io.StringIO("def f(x): return x + 1") as f:
        for token in generate_tokens(f.readline):
            print(tok_name[token[0]], token[1])

    with io.StringIO("def f(x): return x + 1") as f:
        for token in generate_tokens(f.readline):
            print(tok_name[token[0]], repr(token[1]))


# Generated at 2022-06-17 17:04:27.015834
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"def foo(): pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [
        b"# coding: latin-1\n",
        b"# comment\n",
        b"# more comment\n",
        b"\n",
        b"# yet more comment\n",
    ]

    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"

# Generated at 2022-06-17 17:04:33.797209
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"blah"]

    def readline():
        yield b"# -*- coding: ascii -*-"
        yield b"blah"

    try:
        detect_encoding(readline)
    except SyntaxError:
        pass
    else:
        assert 0, "ascii is an invalid encoding"

    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\xfe"


# Generated at 2022-06-17 17:04:43.381144
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# some comment\n", b"# another comment\n"]

    def readline():
        yield b"# coding=latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:04:54.794104
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "1", (1, 1), (1, 2), "1")
    printtoken(1, "1", (1, 1), (1, 2), "1")
    printtoken(1, "1", (1, 1), (1, 2), "1")
    printtoken(1, "1", (1, 1), (1, 2), "1")
    printtoken(1, "1", (1, 1), (1, 2), "1")
    printtoken(1, "1", (1, 1), (1, 2), "1")
    printtoken(1, "1", (1, 1), (1, 2), "1")
    printtoken(1, "1", (1, 1), (1, 2), "1")

# Generated at 2022-06-17 17:05:07.978399
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"# -*- coding: iso-8859-1 -*-\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-16\n"
        yield b"# coding=utf-16-le\n"
        yield b"# coding=utf-16-be\n"
        yield b"# coding=utf-32\n"
        yield b"# coding=utf-32-le\n"

# Generated at 2022-06-17 17:05:17.437307
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from io import StringIO

    s = "def f(x): return 2*x"
    f = StringIO(s)
    g = tokenize.generate_tokens(f.readline)
    for toknum, tokval, _, _, _ in g:
        print(
            "%s %s" % (token.tok_name[toknum], repr(tokval))
        )  # Will print something like "NAME 'f'".



# Generated at 2022-06-17 17:06:01.682189
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, b"1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, b"+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, b"1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, b"\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:06:10.952379
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding=utf-8\n"
        yield b"# coding=iso-8859-1\n"
        yield b"# coding=iso-latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"

# Generated at 2022-06-17 17:06:17.829768
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#\n"
        yield b"# This is a test\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b

# Generated at 2022-06-17 17:06:29.740157
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:06:35.373667
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import untokenize
    s = "def f(x): return 2*x"
    f = StringIO(s)
    tokens = generate_tokens(f.readline)
    result = untokenize(tokens)
    assert result == s



# Generated at 2022-06-17 17:06:45.867760
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: ascii\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some comment\n"
        yield b"# another comment\n"

# Generated at 2022-06-17 17:06:56.516576
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import tokenize

# Generated at 2022-06-17 17:07:07.500233
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pygram import python_grammar

    def tokeneater(*args):
        tok = args[0]
        if tok == syms.newline:
            print()
        else:
            print(tok_name[tok], end=" ")

    f = io.StringIO("a = 1 + 2\n")
    tokenize_loop(f.readline, tokeneater)



# Generated at 2022-06-17 17:07:15.779230
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    from io import StringIO
    from token import NAME, NUMBER, NEWLINE, INDENT, DEDENT, ENDMARKER

    def tokenize_print(type, token, start, end, line):
        print(tokenize.tok_name[type], repr(token))

    # Test empty source
    f = StringIO("")
    tokenize_loop(f.readline, tokenize_print)
    # Test normal source
    f = StringIO("1 + 1\n")
    tokenize_loop(f.readline, tokenize_print)
    # Test source with encoding declaration
    f = io.TextIOWrapper(io.BytesIO(b"# coding: latin-1\nx = '\xe9'\n"))

# Generated at 2022-06-17 17:07:20.855074
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield 'print("hello world")'
    tokeneater = lambda type, token, start, end, line: print(
        f"{tok_name[type]}\t{token!r}"
    )
    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:07:53.890760
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO

    data = "if 1:\n    pass\n"
    f = StringIO(data)
    rl = f.readline
    tokenize_loop(rl, tokenize.printtoken)
    f = StringIO(data)
    rl = f.readline
    tokens = list(tokenize.generate_tokens(rl))

# Generated at 2022-06-17 17:08:05.929094
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(tokenize(io.BytesIO(s.encode("utf-8")).readline))

    def _token_names(s):
        return [tok_name[toktype] for toktype, _, _, _, _ in _tokens(s)]

    assert _token_names("a = 1") == ["NAME", "EQUAL", "NUMBER", "NEWLINE"]
    assert _token_names("a = 1\n") == ["NAME", "EQUAL", "NUMBER", "NEWLINE"]
    assert _token_names("a = 1\n\n") == ["NAME", "EQUAL", "NUMBER", "NEWLINE"]

# Generated at 2022-06-17 17:08:18.218989
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"blah = 1\n"
    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# comment\n", b"# more comment\n"]

    def readline():
        yield b"#!/usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"blah = 1\n"
    encoding, lines = detect_encoding(readline)

# Generated at 2022-06-17 17:08:23.248621
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    tokens = [
        (NAME, "a"),
        (NUMBER, "1"),
        (NEWLINE, "\n"),
        (NAME, "b"),
        (NUMBER, "2"),
        (NEWLINE, "\n"),
        (NAME, "c"),
        (NUMBER, "3"),
        (NEWLINE, "\n"),
    ]
    assert untok.untokenize(tokens) == "a 1\nb 2\nc 3\n"



# Generated at 2022-06-17 17:08:32.616849
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    readline = io.StringIO('foo = "bar"\n').readline
    result = []
    tokenize.tokenize_loop(readline, result.append)

# Generated at 2022-06-17 17:08:37.342555
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), "1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), "1 + 1\n")

# Generated at 2022-06-17 17:08:52.855608
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"blah = 1\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# comment\n", b"# more comment\n"]

    def readline():
        yield b"#!/usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"blah = 1\n"

    encoding, lines = detect_encoding(readline)

# Generated at 2022-06-17 17:08:55.143153
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    s = "def f():\n    print(1)\n"
    f = StringIO(s).readline
    tokens = generate_tokens(f)
    assert untokenize(tokens) == s



# Generated at 2022-06-17 17:09:07.876570
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from io import StringIO

    s = "def f(x): return 2*x"
    f = StringIO(s)
    g = tokenize.generate_tokens(f.readline)
    for toknum, tokval, _, _, _ in g:
        print("%s %s" % (token.tok_name[toknum], repr(tokval)))
    f = io.BytesIO(s.encode("utf-8"))
    g = tokenize.generate_tokens(f.readline)
    for toknum, tokval, _, _, _ in g:
        print("%s %s" % (token.tok_name[toknum], repr(tokval)))



# Generated at 2022-06-17 17:09:19.907766
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT

    def test(input, expected):
        result = []
        untok = Untokenizer()
        for tok in generate_tokens(StringIO(input).readline):
            result.append(untok.untokenize([tok]))
        assert "".join(result) == expected

    test("def f():\n  pass\n", "def f():\n  pass\n")