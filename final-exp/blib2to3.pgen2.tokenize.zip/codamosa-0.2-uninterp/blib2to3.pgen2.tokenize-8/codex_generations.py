

# Generated at 2022-06-17 17:02:26.665886
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b"def foo():\n  pass\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tokenize.tok_name[toknum], tokval)


# Generated at 2022-06-17 17:02:37.184439
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name

    def show_tokens(input):
        for token in generate_tokens(StringIO(input).readline):
            print(tok_name[token[0]], repr(token[1]))

    show_tokens("1 + 1\n")
    show_tokens("1 + 1 # one plus one\n")
    show_tokens("1 + 1 # one plus one\n   + 2\n")
    show_tokens("1 + 1 # one plus one\n   + 2\n")
    show_tokens("1 + 1 # one plus one\n   + 2\n")
    show_tokens("1 + 1 # one plus one\n   + 2\n")

# Generated at 2022-06-17 17:02:43.990643
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from token import *
    from io import StringIO

    s = "def f(x): return 2*x"
    f = io.StringIO(s)
    tokens = []
    tokenize_module.tokenize_loop(f.readline, tokens.append)

# Generated at 2022-06-17 17:02:50.952035
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
   

# Generated at 2022-06-17 17:03:02.688904
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # Test that the untokenizer works as expected.
    # This is a regression test for SF bug #527349.
    untok = Untokenizer()
    untok.compat((0, "def"), [])
    untok.compat((1, " "), [])
    untok.compat((1, "f"), [])
    untok.compat((1, "("), [])
    untok.compat((1, "x"), [])
    untok.compat((1, ")"), [])
    untok.compat((0, ":"), [])
    untok.compat((0, " "), [])
    untok.compat((0, "\n"), [])
    untok.compat((4, " "), [])

# Generated at 2022-06-17 17:03:13.928537
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 'got ' + repr(x)\n")
    result = []
    tokenize.tokenize(r.readline, result.append)

# Generated at 2022-06-17 17:03:20.529713
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.token import tok_name
    from io import StringIO
    from typing import cast

    def tokeneater(*args):
        print(tok_name[args[0]], args[1])

    s = StringIO("def f(x): return x+1")
    tokenize_loop(s.readline, tokeneater)



# Generated at 2022-06-17 17:03:28.382275
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"import sys\n"
    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])

    def readline():
        yield b"#!/usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"import sys\n"
    assert detect_encoding

# Generated at 2022-06-17 17:03:40.693882
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tokenize, untokenize, NUMBER, STRING, NAME, OP

    def check(input, expected):
        result = []
        tokenize_loop(io.StringIO(input).readline, lambda toknum, tokval, _srowcol, _erowcol, _line: result.append((toknum, tokval)))
        assert result == expected, f"{result} != {expected}"
        # Also test tokenize()
        result = []
        tokenize(io.StringIO(input).readline, lambda toknum, tokval, _srowcol, _erowcol, _line: result.append((toknum, tokval)))
        assert result == expected, f"{result} != {expected}"

# Generated at 2022-06-17 17:03:49.426447
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"blah"]

    def readline():
        yield b"# coding=utf-8"
        yield b"blah"

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == [b"# coding=utf-8", b"blah"]

    def readline():
        yield b"#!/usr/bin/python3"
        yield b"# -*- coding: latin-1 -*-"

# Generated at 2022-06-17 17:04:23.704107
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    result = []
    tokenize.tokenize(r, result.append)

# Generated at 2022-06-17 17:04:31.896860
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    untok.tokens.append("def")
    untok.prev_row = 1
    untok.prev_col = 3
    untok.add_whitespace((1, 3))
    untok.tokens.append("f")
    untok.prev_row = 1
    untok.prev_col = 4
    untok.add_whitespace((1, 4))
    untok.tokens.append("(")
    untok.prev_row = 1
    untok.prev_col = 5
    untok.add_whitespace((1, 5))
   

# Generated at 2022-06-17 17:04:42.347354
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.tokenize import untokenize

    def test(input, expected):
        tokens = list(generate_tokens(StringIO(input).readline))
        untok = untokenize(tokens)
        assert untok == expected, (
            "Untokenizing %r gives %r, not %r" % (input, untok, expected)
        )

    test("def f(x):\n    return x\n", "def f(x):\n    return x\n")
    test("def f(x):\n    return x", "def f(x):\n    return x ")

# Generated at 2022-06-17 17:04:53.795415
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import NUMBER
    from tokenize import NAME
    from tokenize import OP
    from tokenize import STRING
    from tokenize import NEWLINE
    from tokenize import ENDMARKER
    from tokenize import INDENT
    from tokenize import DEDENT
    from tokenize import COMMENT
    from tokenize import NL
    from tokenize import ENCODING
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import NUMBER
    from tokenize import NAME

# Generated at 2022-06-17 17:05:01.766515
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    def tokenize(s):
        result = []
        g = generate_tokens(StringIO(s).readline)
        for toknum, tokval, _, _, _ in g:
            result.append((toknum, tokval))
        return result

    assert tokenize("1") == [(NUMBER, "1")]
    assert tokenize("1.2") == [(NUMBER, "1.2")]
    assert tokenize("1.") == [(NUMBER, "1.")]
    assert tokenize(".1") == [(NUMBER, ".1")]
    assert tokenize("1.2e3") == [(NUMBER, "1.2e3")]
    assert tokenize("1.2e+3") == [(NUMBER, "1.2e+3")]

# Generated at 2022-06-17 17:05:13.260517
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"blah = 1\n"
        yield b"# vim: set fileencoding=utf-8 :\n"
        yield b"# another comment\n"
        yield b"blah = 2\n"
        yield b"\n"
        yield b"# coding=iso-8859-1\n"
        yield b"blah = 3\n"
        yield b"\n"
        yield b"# coding=iso-8859-15\n"
        yield b"blah = 4\n"
        yield b"\n"
        yield b"# coding=utf-8\n"

# Generated at 2022-06-17 17:05:25.332430
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    untok.tokens.append("def")
    untok.prev_row = 1
    untok.prev_col = 3
    untok.add_whitespace((1, 3))
    untok.tokens.append("f")
    untok.prev_row = 1
    untok.prev_col = 4
    untok.add_whitespace((1, 4))
    untok.tokens.append("(")
    untok.prev_row = 1
    untok.prev_col = 5
    untok.add_whitespace((1, 5))
   

# Generated at 2022-06-17 17:05:36.278315
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    l = []
    tokenize.tokenize_loop(r, l.append)

# Generated at 2022-06-17 17:05:45.945471
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")


# Generated at 2022-06-17 17:05:48.076593
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "1", (0,0), (0,1), "")


# Generated at 2022-06-17 17:06:16.712482
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io
    import unittest

    class Test(unittest.TestCase):
        def test_generate_tokens(self):
            readline = io.StringIO("if 1:\n  pass\n").readline
            tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:06:29.554254
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    untok.tokens.append("def")
    untok.prev_row = 1
    untok.prev_col = 3
    untok.add_whitespace((1, 3))
    untok.tokens.append("f")
    untok.prev_row = 1
    untok.prev_col = 4
    untok.add_whitespace((1, 4))
    untok.tokens.append("(")
    untok.prev_row = 1
    untok.prev_col = 5
    untok.add_whitespace((1, 5))
   

# Generated at 2022-06-17 17:06:32.776098
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return "def f(x): return x + 1"

    def tokeneater(*args):
        print(args)

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:06:44.472560
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    from blib2to3.pgen2.tokenize import COMMENT, ENCODING, ERRORTOKEN, ENDMARKER, EOF
    from blib2to3.pgen2.tokenize import OP, STRING, ENDMARKER
    from blib2to3.pgen2.tokenize import generate_tokens

# Generated at 2022-06-17 17:06:49.617333
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield 'print("hello world")'
    def tokeneater(*args):
        print(args)
    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:06:56.075034
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens

    def test(input, expected):
        f = StringIO(input)
        tokens = generate_tokens(f.readline)
        untok = Untokenizer()
        result = untok.compat(next(tokens), tokens)
        assert result == expected, (result, expected)

    test('def f(x):\n  return x+1\n', 'def f ( x ) :\n  return x + 1\n')
    test('@deco\nclass C:\n  pass\n', '@deco\nclass C :\n  pass\n')

# Generated at 2022-06-17 17:07:02.499506
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'print("hello world")\n'
        yield b''
    encoding, lines = detect_encoding(readline)
    assert encoding == 'iso-8859-1'
    assert lines == [b'# -*- coding: latin-1 -*-\n', b'print("hello world")\n']

    def readline():
        yield b'\xef\xbb\xbf# -*- coding: latin-1 -*-\n'
        yield b'print("hello world")\n'
        yield b''
    encoding, lines = detect_encoding(readline)
    assert encoding == 'utf-8-sig'

# Generated at 2022-06-17 17:07:07.888586
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    s = "def f(x): return 2*x"
    g = generate_tokens(StringIO(s).readline)
    for t in g:
        print(t)


# Generated at 2022-06-17 17:07:09.576642
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "a", (1, 1), (1, 2), "")



# Generated at 2022-06-17 17:07:21.966392
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8 with blanks\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig with blanks\n"
        yield b"# coding=utf-8-sig  with  blanks\n"
        yield b"# coding=utf-8-sig\twith\tblanks\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\r\n"

# Generated at 2022-06-17 17:08:13.485161
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    u.compat((NAME, "def"), [(NAME, "f"), (OP, "("), (OP, ")"), (OP, ":")])
    assert u.tokens == ["def ", "f", "(", ")", ":"]



# Generated at 2022-06-17 17:08:22.458601
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "def f(x):"
        yield "  return x + 1"
    tokeneater = []
    tokenize_loop(readline(), tokeneater.append)

# Generated at 2022-06-17 17:08:33.551520
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from blib2to3.pgen2.token import COMMENT, STRING, ENCODING
    from blib2to3.pgen2.token import token_name
    from blib2to3.pgen2.tokenize import TokenError
    from blib2to3.pgen2.tokenize import detect_encoding
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import tokenize

# Generated at 2022-06-17 17:08:43.268279
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tokenize, generate_tokens
    from blib2to3.pgen2.tokenize import tok_name
    from blib2to3.pgen2.token import TokenInfo
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import detect_encoding
    from blib2to3.pgen2.tokenize import COMMENT
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import ENCODING
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import OP
   

# Generated at 2022-06-17 17:08:57.046592
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:09:09.102217
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from unittest import TestCase


# Generated at 2022-06-17 17:09:20.670381
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from io import StringIO
    from token import NAME, NUMBER, STRING, NEWLINE, INDENT, DEDENT, ENDMARKER

    # Test tokenize_loop() with a memory-based input file
    f = StringIO("1 + 1\n")
    result = []
    tokenize_loop(f.readline, result.append)

# Generated at 2022-06-17 17:09:30.942548
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io
    import token
    import unittest

    class Test(unittest.TestCase):
        def test_generate_tokens(self):
            readline = io.BytesIO(b"def f(x):\n  return x+1\n").readline
            tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:09:41.607355
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(generate_tokens(readline))

# Generated at 2022-06-17 17:09:53.690950
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens

    def test(input, expected):
        f = StringIO(input)
        tokens = generate_tokens(f.readline)
        untok = Untokenizer()
        result = untok.untokenize(tokens)
        assert result == expected, repr(result)

    test("def f():\n    pass\n", "def f():\n    pass\n")
    test("def f():\n    pass", "def f():\n    pass")
    test("def f():\n    pass\n\n", "def f():\n    pass\n\n")

# Generated at 2022-06-17 17:10:28.038365
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"\n"
        yield b"# coding: iso-8859-1\n"
        yield b"\n"
        yield b"# coding: iso-latin-1\n"
        yield b"\n"
        yield b"# coding: latin-1-foo\n"
        yield b"\n"
        yield b"# coding: latin-1-bar\n"
        yield b"\n"

# Generated at 2022-06-17 17:10:40.138770
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"blah = 1\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# comment\n", b"# more comment\n"]

    def readline():
        yield b"#!/usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"blah = 1\n"

    encoding, lines = detect_encoding(readline)

# Generated at 2022-06-17 17:10:48.795936
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from io import StringIO
    s = StringIO("def f():\n  pass\n")
    tokens = tokenize.generate_tokens(s.readline)
    u = Untokenizer()
    u.compat(next(tokens), tokens)
    assert u.untokenize(tokens) == "def f ( ) :\n  pass\n"
