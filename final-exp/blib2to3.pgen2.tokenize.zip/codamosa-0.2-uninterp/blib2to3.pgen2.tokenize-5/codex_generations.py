

# Generated at 2022-06-17 17:02:59.548652
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    def test_untokenize(input, expected):
        stream = StringIO(input)
        tokens = generate_tokens(stream.readline)
        actual = untokenize(tokens)
        assert actual == expected, "%r != %r" % (actual, expected)

    test_untokenize("def f(x):\n  return x\n", "def f ( x ) :\n  return x\n")
    test_untokenize("def f(x):\n  return x", "def f ( x ) :\n  return x\n")

# Generated at 2022-06-17 17:03:07.643466
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3", (1, 0), (1, 1), "")
    printtoken(NUMBER, "3.14", (1, 0), (1, 4), "")
    printtoken(NUMBER, "3.14j", (1, 0), (1, 5), "")
    printtoken(NUMBER, "0", (1, 0), (1, 1), "")
    printtoken(NUMBER, "0L", (1, 0), (1, 2), "")
    printtoken(NUMBER, "0777", (1, 0), (1, 4), "")
    printtoken(NUMBER, "0x9af", (1, 0), (1, 5), "")
    printtoken(NUMBER, "0b101010", (1, 0), (1, 8), "")
    print

# Generated at 2022-06-17 17:03:18.370463
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), "1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), "1 + 1\n")

# Generated at 2022-06-17 17:03:24.548292
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.tokenize import TokenError

    def readline():
        return io.StringIO("def f(x): return x+1").readline()

    def tokeneater(*args):
        print(tok_name[args[0]], args[1])

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:03:30.477470
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import NUMBER, STRING, NAME, OP
    from tokenize import COMMENT, ERRORTOKEN, ENDMARKER, INDENT, DEDENT
    from tokenize import NEWLINE, NL, ENCODING
    from tokenize import TokenInfo
    from typing import List, Tuple
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError

# Generated at 2022-06-17 17:03:42.916866
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from io import BytesIO
    from tokenize import tokenize
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from io import BytesIO
    from tokenize import tokenize
    from token import INDENT, DEDENT, NAME, NUMBER, ASYNC, AWAIT, NEWLINE, NL
    from io import StringIO
    from tokenize import generate_t

# Generated at 2022-06-17 17:03:55.046657
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(
        b"""if 1:
# Foobar
  pass\n"""
    ).readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (
        NAME,
        b"if",
        (1, 0),
        (1, 2),
        b"if 1:\n",
    )  # Offset 2 (column number of token)
    assert tokens[1] == (
        NUMBER,
        b"1",
        (1, 3),
        (1, 4),
        b"if 1:\n",
    )  # Offset 3

# Generated at 2022-06-17 17:04:05.768489
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == [" ", " ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", " ", "\n", " "]
    untok.add_whitespace((2, 2))
    assert untok

# Generated at 2022-06-17 17:04:16.967820
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"# coding=ascii\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=iso-8859-15\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"

# Generated at 2022-06-17 17:04:22.953706
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    with io.StringIO("def f(x): return x+1") as f:
        for token in generate_tokens(f.readline):
            print(tok_name[token.type], token.string, token.start, token.end, token.line)


# Generated at 2022-06-17 17:05:26.647234
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import tok_name

    s = io.StringIO("def f(x): return 2*x")
    l = []
    tokenize_loop(s.readline, l.append)

# Generated at 2022-06-17 17:05:37.953021
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from token import NAME, NUMBER, NEWLINE, ENDMARKER
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import generate_tokens
    from tokenize import COMMENT, NL, ENCODING
    from tokenize import INDENT, DEDENT, ENDMARKER
    from tokenize import OP
    from tokenize import STRING
    from tokenize import generate_tokens
    from tokenize import COMMENT, NL, ENCODING
    from tokenize import INDENT, DEDENT, ENDMARKER
    from tokenize import OP
    from tokenize import STRING
    from tokenize import generate_tokens
    from tokenize import COMMENT, NL, ENCODING
    from tokenize import INDENT, DEDENT, ENDM

# Generated at 2022-06-17 17:05:51.992926
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import detect_encoding
    from blib2to3.pgen2.tokenize import TokenInfo

    def tokeneater(*args):
        tok_list.append(args)

    def untokeneater(*args):
        untok_list.append(args)

    def roundtrip(s):
        tok_list[:] = []
        untok_list[:] = []
        sio = StringIO(s)
        encoding = detect_encoding(sio.readline)[0]

# Generated at 2022-06-17 17:06:02.433226
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    import unittest

    class TestTokenize(unittest.TestCase):
        def test_tokenize_empty(self):
            s = io.StringIO("")
            tokens = list(tokenize.tokenize(s.readline))
            self.assertEqual(tokens, [])

        def test_tokenize_simple(self):
            s = io.StringIO("foo = 'bar'\n")
            tokens = list(tokenize.tokenize(s.readline))

# Generated at 2022-06-17 17:06:12.157133
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#\n"
        yield b"# some more\n"
        yield b"#\n"
        yield b"# lines\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"

# Generated at 2022-06-17 17:06:17.918120
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT
    from token import tok_name

    def test_tokenize(s):
        return list(generate_tokens(StringIO(s).readline))

    def test_untokenize(s):
        return Untokenizer().compat(test_tokenize(s)[0], test_tokenize(s)[1:])

    assert test_untokenize("a") == "a "
    assert test_untokenize("1") == "1 "
    assert test_untokenize("async") == "async "
    assert test_untokenize("await") == "await "
    assert test_untokenize("\n")

# Generated at 2022-06-17 17:06:29.738926
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more code\n"
        yield b"# even more code\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# some more code\n"
        yield b"# even more code\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# some more code\n"
        yield b"# even more code\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
       

# Generated at 2022-06-17 17:06:41.388001
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    # Test the tokenize() function.
    text = "1 + 1\n"
    gt = generate_tokens(io.StringIO(text).readline)
    toks = list(gt)
    assert toks[0] == (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n")
    assert toks[1] == (OP, "+", (1, 2), (1, 3), "1 + 1\n")
    assert toks[2] == (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n")
    assert toks[3] == (NEWLINE, "\n", (1, 5), (1, 6), "1 + 1\n")

# Generated at 2022-06-17 17:06:54.592807
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tokenize, untokenize, NUMBER, NAME, OP
    from blib2to3.pgen2.tokenize import generate_tokens, tok_name
    from blib2to3.pgen2.tokenize import COMMENT, ENDMARKER, INDENT, DEDENT, NEWLINE, NL
    from blib2to3.pgen2.tokenize import ENCODING, ERRORTOKEN, STRING
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize, tokenize
    from blib2to3.pgen2.tokenize import COMMENT, NL, tokenize_loop, tok_name

# Generated at 2022-06-17 17:07:00.875833
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"# bar"
        yield b"# -*- coding: ascii -*-"
        yield b"# baz"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# qux"
        yield b"# -*- coding: iso-8859-1 -*-"
        yield b"# quux"
        yield b"# -*- coding: iso-latin-1 -*-"
        yield b"# corge"
        yield b"# -*- coding: latin-1 -*-"
        yield b"# grault"
       

# Generated at 2022-06-17 17:07:38.857437
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    s = "def f(x): return 2*x"
    g = generate_tokens(StringIO(s).readline)
    for t in g:
        print(t)

test_generate_tokens()


# Generated at 2022-06-17 17:07:53.179468
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2 import driver
    from blib2to3.fixer_util import Name

    def tokeneater(*args):
        tok = args[0]
        if tok == syms.testlist_star_expr:
            raise ParseError

# Generated at 2022-06-17 17:08:05.570031
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"pass"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"pass"]

    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# vim: set fileencoding=utf-8 :"
        yield b"pass"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:08:18.185880
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# vim: set fileencoding=utf-8 :"
        yield b"pass"
    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"# vim: set fileencoding=utf-8 :"]

    def readline():
        yield b"#!/usr/bin/python3"
        yield b"# -*- coding: latin-1 -*-"
        yield b"# vim: set fileencoding=utf-8 :"
        yield b"pass"
    encoding, lines = detect_encoding(readline)

# Generated at 2022-06-17 17:08:29.458865
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP
    readline = io.BytesIO(b'foo = "bar"\n').readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (NAME, b'foo', (1, 0), (1, 3), b'foo = "bar"\n')
    assert tokens[1] == (OP, b'=', (1, 4), (1, 5), b'foo = "bar"\n')
    assert tokens[2] == (STRING, b'"bar"', (1, 6), (1, 11), b'foo = "bar"\n')

# Generated at 2022-06-17 17:08:41.048355
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some other comment\n"
        yield b"\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# some other comment\n"
        yield b"\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# some other comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some other comment\n"
        yield b"\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some other comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:08:54.286666
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tok_name

    class Readline:
        def __init__(self, lines):
            self.lines = iter(lines)
            self.line_num = 0

        def __call__(self):
            self.line_num += 1
            return next(self.lines, "")

    def tokeneater(*args):
        tokeneater.tokens.append(args)

    tokeneater.tokens = []
    readline = Readline(["1 + 1", ""])
    tokenize_loop(readline, tokeneater)

# Generated at 2022-06-17 17:09:07.547119
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"

# Generated at 2022-06-17 17:09:16.021058
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize
    from io import StringIO

    s = "def f(x): return 2*x"
    g = _tokenize.generate_tokens(StringIO(s).readline)
    for toknum, tokval, _, _, _ in g:
        print("%10s %-14s" % (_tokenize.tok_name[toknum], repr(tokval)))



# Generated at 2022-06-17 17:09:25.708659
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), "1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), "1 + 1\n")
    assert tokens

# Generated at 2022-06-17 17:10:00.693776
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from io import StringIO
    from tokenize import generate_tokens

    def readline():
        return "1 + 1"

    def tokeneater(*args):
        print(args)

    tokenize_module.tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:10:08.954508
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(generate_tokens(io.StringIO(s).readline))

    def _names(s):
        return [tok_name[toknum] for toknum, _, _, _, _ in _tokens(s)]

    assert _names("") == ["ENDMARKER"]
    assert _names(" ") == ["ENDMARKER"]
    assert _names("\n") == ["NEWLINE", "ENDMARKER"]
    assert _names("\n\n") == ["NEWLINE", "NEWLINE", "ENDMARKER"]
    assert _names("\n\n\n") == ["NEWLINE", "NEWLINE", "NEWLINE", "ENDMARKER"]

# Generated at 2022-06-17 17:10:19.036046
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import tok_name

    s = "def f(x): return 2*x"
    f = io.StringIO(s)
    l = []
    tokenize_loop(f.readline, l.append)

# Generated at 2022-06-17 17:10:29.885546
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"# bar"
        yield b"# -*- coding: ascii -*-"
        yield b"# baz"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# qux"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# quux"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# corge"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# grault"

# Generated at 2022-06-17 17:10:41.450407
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == ["  "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == ["  ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == ["  ", "\n", " "]

# Generated at 2022-06-17 17:10:54.450027
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    def test(s):
        tokens = list(generate_tokens(StringIO(s).readline))
        return untokenize(tokens)

    assert test("a = 1") == "a = 1 "
    assert test("a = 1\n") == "a = 1 "
    assert test("a = 1\nb = 2") == "a = 1 b = 2 "
    assert test("a = 1\nb = 2\n") == "a = 1 b = 2 "
    assert test("a = 1\nb = 2\n\n") == "a = 1 b = 2 "