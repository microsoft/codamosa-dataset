

# Generated at 2022-06-17 17:02:31.503034
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
       

# Generated at 2022-06-17 17:02:40.714082
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"# coding: ascii\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"# coding: utf-8\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"

# Generated at 2022-06-17 17:02:53.090741
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet another comment\n"
        yield b"# coding=ascii\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8-sig\n"
        yield b"\n"
        yield b"# coding=utf-16\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"\n"
        yield b"# coding: utf-8-sig\n"
        yield b"\n"

# Generated at 2022-06-17 17:03:03.990946
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == [" ", " ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", " ", "\n", " "]
    untok.add_whitespace((3, 0))
    assert untok

# Generated at 2022-06-17 17:03:14.531314
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List, Tuple

    def _format(tokens: List[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]) -> str:
        return "".join(
            f"{token.tok_name[type]:<15} {string!r:<15} {start} {end} {line!r}\n"
            for type, string, start, end, line in tokens
        )

    def _test(s: str, expected: str) -> None:
        tokens = list(tokenize.generate_tokens(io.StringIO(s).readline))
        actual = _format(tokens)
        assert actual == expected, f"{actual!r}\n{expected!r}"

    _

# Generated at 2022-06-17 17:03:22.843885
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO

    readline = StringIO("if 1:\n  pass\n").readline
    tokeneater = tokenize.untokenize
    tokenize.tokenize_loop(readline, tokeneater)
    # Test with a bad tokeneater
    def bad_tokeneater(*args):
        raise ValueError
    tokenize.tokenize_loop(readline, bad_tokeneater)
    # Test with a bad readline
    def bad_readline():
        raise ValueError
    tokenize.tokenize_loop(bad_readline, tokeneater)



# Generated at 2022-06-17 17:03:33.289541
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def check(input, output):
        u = Untokenizer()
        result = u.untokenize(input)
        if result != output:
            raise ValueError("%r != %r" % (result, output))

    check([(1, "abc"), (2, "def")], "abc def")
    check([(1, "abc"), (0, " \n"), (2, "def")], "abc\ndef")
    check([(1, "abc"), (0, " \n"), (4, " \n"), (2, "def")], "abc\n\ndef")
    check([(1, "abc"), (0, " \n"), (0, " \n"), (2, "def")], "abc\n\ndef")

# Generated at 2022-06-17 17:03:44.600295
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    from unittest import TestCase


# Generated at 2022-06-17 17:03:51.785327
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"
        yield b"#\n"

# Generated at 2022-06-17 17:03:59.335518
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comments\n"
        yield b"\n"
        yield b"# yet another comment\n"
        yield b"def foo(): pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [
        b"# coding: latin-1\n",
        b"# comment\n",
        b"# more comments\n",
        b"\n",
        b"# yet another comment\n",
    ]



# Generated at 2022-06-17 17:05:11.878097
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import Tuple

    def tokeneater(
        readline: Callable[[], Text], grammar: Optional[Grammar] = None
    ) -> Iterator[Tuple[int, Text, Tuple[int, int], Tuple[int, int], Text]]:
        for token in generate_tokens(readline, grammar):
            print(token)

    s = "def f(x): return 2*x"
    tokeneater(io.StringIO(s).readline)

    # Test round-trip invariant for full input
    g = tokenize.generate_tokens(io.StringIO(s).readline)
    readline = io.StringIO(untokenize(g)).readline

# Generated at 2022-06-17 17:05:17.655398
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    u.compat((NAME, "if"), [(NAME, "a"), (OP, ":"), (NEWLINE, "\n"), (NAME, "b")])
    assert u.tokens == ["if ", "a :", "\n", "    b"]



# Generated at 2022-06-17 17:05:27.269303
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import NUMBER
    from tokenize import STRING
    from tokenize import NAME
    from tokenize import OP
    from tokenize import NEWLINE
    from tokenize import INDENT
    from tokenize import DEDENT
    from tokenize import COMMENT
    from tokenize import NL
    from tokenize import ENDMARKER
    from tokenize import ENCODING
    from tokenize import ERRORTOKEN
    from tokenize import ASYNC
    from tokenize import AWAIT
    from tokenize import tokenize_loop
    from tokenize import detect_encoding
    from tokenize import open
    from tokenize import untokenize


# Generated at 2022-06-17 17:05:38.028561
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    result = []
    tokenize.tokenize(r, result.append)

# Generated at 2022-06-17 17:05:42.906194
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module

    def readline():
        return "1 + 1"

    def tokeneater(*args):
        assert args == (
            tokenize_module.NUMBER,
            "1",
            (1, 0),
            (1, 1),
            "1 + 1",
        )
        raise StopTokenizing

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:05:51.834090
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    s = u.untokenize(
        [
            (1, "a"),
            (0, " "),
            (1, "b"),
            (0, " "),
            (1, "c"),
            (4, "\n"),
            (0, " "),
            (0, " "),
            (1, "d"),
            (0, " "),
            (1, "e"),
            (4, "\n"),
            (0, " "),
            (1, "f"),
        ]
    )
    assert s == "a b c\n  d e\n f"



# Generated at 2022-06-17 17:05:58.089637
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    untok = Untokenizer()
    f = StringIO("def f():\n  pass\n")
    tokens = generate_tokens(f.readline)
    result = untok.compat(next(tokens), tokens)
    assert result is None
    assert untok.tokens == ["def ", "f", "(", ")", ":", "\n", "  ", "pass", "\n"]



# Generated at 2022-06-17 17:06:05.352225
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    r = BytesIO(b"def f(x):\n  return x+1\n")
    g = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in g:
        print("%10s %-14s" % (tokenize.tok_name[toknum], repr(tokval)))


# Generated at 2022-06-17 17:06:13.876836
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    from blib2to3.pgen2.token import token_name
    from blib2to3.pgen2.tokenize import TokenError
    from blib2to3.pgen2.tokenize import StopTokenizing
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens

# Generated at 2022-06-17 17:06:26.560827
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from .tokenize import generate_tokens, untokenize, INDENT, DEDENT, NEWLINE, NL

    def test(input, expected):
        result = untokenize(generate_tokens(StringIO(input).readline))
        assert result == expected, "%r != %r" % (result, expected)

    test("def f():\n    pass\n", "def f():\n    pass\n")
    test("def f():\n    pass\n\n", "def f():\n    pass\n\n")
    test("def f():\n    pass\n\n\n", "def f():\n    pass\n\n\n")

# Generated at 2022-06-17 17:07:28.202968
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List

    def _format(tokens: List[tokenize.TokenInfo]) -> str:
        return "".join(
            [
                "%-20s%s\n" % (token.tok_name[tok[0]], tok[1])
                for tok in tokens
            ]
        )

    def _test(text: str) -> None:
        print("\n>>> _test(%r)" % text)
        tokens = list(tokenize.generate_tokens(io.StringIO(text).readline))
        print(_format(tokens))
        print("%d tokens" % len(tokens))

    _test("a = 1 + 2\n")

# Generated at 2022-06-17 17:07:39.940720
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import NAME, NUMBER, NEWLINE, INDENT, DEDENT, ENDMARKER

    r = io.StringIO("1 + 1\n")
    l = []
    tokenize_loop(r.readline, l.append)
    assert l == [
        (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n"),
        (NAME, "+", (1, 2), (1, 3), "1 + 1\n"),
        (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n"),
        (NEWLINE, "\n", (1, 5), (1, 6), "1 + 1\n"),
        (ENDMARKER, "", (2, 0), (2, 0), ""),
    ]



# Generated at 2022-06-17 17:07:53.741871
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 2))
    untok.tokens.append("a")
    untok.prev_row = 1
    untok.prev_col = 2
    untok.add_whitespace((1, 3))
    untok.tokens.append("b")
    untok.prev_row = 1
    untok.prev_col = 3
    untok.add_whitespace((2, 0))
    untok.tokens.append("c")
    untok.prev_row = 2
    untok.prev_col = 0
    untok.add_whitespace((2, 1))
   

# Generated at 2022-06-17 17:08:05.794318
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import untokenize_compat
    from blib2to3.pgen2.tokenize import untokenize_compat_2_7
    from blib2to3.pgen2.tokenize import untokenize_compat_3_2
    from blib2to3.pgen2.tokenize import untokenize_compat_3_5
    from blib2to3.pgen2.tokenize import untokenize_compat_3_6
    from blib2to3.pgen2.tokenize import untokenize_compat_3_7

# Generated at 2022-06-17 17:08:11.412008
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    u.compat((NAME, "def"), [(NAME, "f"), (OP, "("), (OP, ")"), (OP, ":")])
    assert u.tokens == ["def ", "f", "(", ")", ":"]



# Generated at 2022-06-17 17:08:22.105987
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: ascii -*-"
        yield b"\n"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: unknown -*-"
        yield b"\n"

# Generated at 2022-06-17 17:08:32.014632
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(generate_tokens(io.StringIO(s).readline))

    def _names(tokens):
        return [tok_name[tok[0]] for tok in tokens]

    assert _names(_tokens("a = 1")) == ["NAME", "EQUAL", "NUMBER", "NEWLINE"]
    assert _names(_tokens("a = 1\\\n")) == ["NAME", "EQUAL", "NUMBER", "NEWLINE"]
    assert _names(_tokens("a = 1\\\n\\\n")) == [
        "NAME",
        "EQUAL",
        "NUMBER",
        "NEWLINE",
        "NEWLINE",
    ]
    assert _names

# Generated at 2022-06-17 17:08:42.562165
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding=utf-8\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# vim:set fileencoding=iso-latin-1:\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# -*- coding: utf-8-sig -*-\n"
        yield b"# -*- coding: utf-8-sig -*-\n"

# Generated at 2022-06-17 17:08:55.849429
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List

    def _format(tokens: List[tokenize.TokenInfo]) -> str:
        return "".join(
            [
                "%s_%r" % (token.tok_name[tok[0]], tok[1])
                for tok in tokens
                if tok[0] != token.ENCODING
            ]
        )

    def _format_token(tok: tokenize.TokenInfo) -> str:
        return "%s_%r" % (token.tok_name[tok[0]], tok[1])

    def _test(s: str, expected: str) -> None:
        result = _format(list(tokenize.generate_tokens(io.StringIO(s).readline)))

# Generated at 2022-06-17 17:09:08.410835
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from tokenize import untokenize

    readline = io.StringIO("def f(x): return 2*x").readline
    tokens = []
    tokenize_loop(readline, tokens.append)

# Generated at 2022-06-17 17:09:42.323103
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO

    class Readline:
        def __init__(self, lines: List[Text]) -> None:
            self.lines = lines

        def __call__(self) -> Text:
            return self.lines.pop(0)

    def tokeneater(*args: object) -> None:
        tokeneater.tokens.append(args)

    tokeneater.tokens = []
    readline = Readline(["if 1: #comment\n", "  pass\n"])
    tokenize_loop(readline, tokeneater)

# Generated at 2022-06-17 17:09:49.974341
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.token import COMMENT
    from blib2to3.pgen2.token import NL
    from blib2to3.pgen2.token import NAME
    from blib2to3.pgen2.token import OP
    from blib2to3.pgen2.token import NUMBER
    from blib2to3.pgen2.token import STRING
    from blib2to3.pgen2.token import ENDMARKER
    from blib2to3.pgen2.token import INDENT


# Generated at 2022-06-17 17:09:57.467248
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from io import StringIO

    readline = StringIO(
        'def foo(x, y):\n'
        '    return x + y\n'
        '\n'
        'result = foo(1, 2)\n'
    ).readline

    tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:10:07.010053
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List

    def _format(tokens: List[tokenize.TokenInfo]) -> str:
        return "".join(
            [
                "%s_%s" % (token.tok_name[tok[0]], tok[1])
                for tok in tokens
                if tok[0] != token.ENCODING
            ]
        )

    def _test(s: str, expected: str) -> None:
        result = _format(list(tokenize.generate_tokens(io.StringIO(s).readline)))
        assert result == expected, "%r != %r" % (result, expected)

    _test("", "ENDMARKER_")
    _test("\n", "ENDMARKER_")
   

# Generated at 2022-06-17 17:10:17.710335
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tokenize, generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.fixer_util import Name

    def tokenize_loop_helper(s):
        f = io.StringIO(s)
        tokens = []
        tokenize_loop(f.readline, tokens.append)
        return tokens

    def tokenize_helper(s):
        f = io.StringIO(s)
        tokens = []
        tokenize(f.readline, tokens.append)
        return tokens


# Generated at 2022-06-17 17:10:28.562559
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x\n")
    result = []
    tokenize.tokenize(r.readline, result.append)

# Generated at 2022-06-17 17:10:40.603690
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    readline = io.BytesIO(b'foo = "bar"\n').readline
    tokens = []
    tokenize.tokenize_loop(readline, tokens.append)

# Generated at 2022-06-17 17:10:53.779980
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import tok_name

    s = io.StringIO("def f(x): return 2*x")
    l = []
    tokenize_loop(s.readline, l.append)