

# Generated at 2022-06-17 17:02:40.785012
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-8859-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-some-garbage -*-"
        yield b"\n"
        yield b"# -*- coding: utf-7 -*-"
        yield b"\n"

# Generated at 2022-06-17 17:02:43.962211
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "print('hello world')"
    tokenize_loop(readline, printtoken)



# Generated at 2022-06-17 17:02:54.870720
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT
    u = Untokenizer()
    f = StringIO("if 1:\n  a = 2\n  b = 3\n")
    g = generate_tokens(f.readline)
    result = u.compat(next(g), g)
    assert result is None

# Generated at 2022-06-17 17:03:04.520384
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for toknum, tokval, _, _, _ in tokens:
        if toknum == NUMBER and tokval == "1":
            print("Matched a number")
            break
    else:
        print("Did not find anything")

    readline = io.BytesIO(b'b"foo"').readline
    tokens = generate_tokens(readline)
    token_types = [toknum for toknum, _, _, _, _ in tokens]
    print(token_types)

    readline

# Generated at 2022-06-17 17:03:15.162873
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    from tokenize import tokenize as tokenize_orig
    from tokenize import untokenize as untokenize_orig
    from tokenize import NUMBER, STRING, NAME, OP

    def test_tokenize(input):
        f = io.StringIO(input)
        tokens = list(tokenize.generate_tokens(f.readline))
        output = untokenize_orig(tokens)
        assert input == output

    def test_tokenize_op(input, expected):
        f = io.StringIO(input)
        tokens = list(tokenize.generate_tokens(f.readline))
        output = untokenize_orig(tokens)
        assert input == output
        assert tokens[0][0] == expected


# Generated at 2022-06-17 17:03:20.982815
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    untok = Untokenizer()
    iterable = generate_tokens(StringIO("def f():\n  pass\n").readline)
    assert untok.compat(next(iterable), iterable) is None
    assert untok.tokens == ["def ", "f", "(", ")", ":", "\n", "  ", "pass", "\n"]



# Generated at 2022-06-17 17:03:28.263724
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from io import StringIO
    from tokenize import tokenize as tokenize_orig
    from tokenize import untokenize as untokenize_orig
    from tokenize import TokenInfo
    from tokenize import COMMENT, DEDENT, ENDMARKER, INDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT

    def tokenize(readline):
        return tokenize_orig(readline, None)

    def untokenize(iterable):
        return untokenize_orig(iterable)

    def roundtrip(s):
        f = StringIO(s)
        tokens = list(tokenize(f.readline))
        f.close()
        return untokenize(tokens)

    def compare(s):
        assert roundtrip(s) == s



# Generated at 2022-06-17 17:03:40.555112
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import NUMBER, STRING, NAME, OP

    # Test round-trip through tokenize/untokenize
    s = "def f(x): return 'abc' + 'def'\n"
    readline = io.BytesIO(s.encode("utf-8")).readline
    tokens = list(tokenize(readline))
    untokened = untokenize(tokens)
    assert untokened == s

    # Test round-trip through tokenize/untokenize with a non-ascii character
    s = "def f(x): return 'abc' + 'def'\u2026\n"
    readline = io.BytesIO(s.encode("utf-8")).readline

# Generated at 2022-06-17 17:03:45.119612
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b"def f(x):\n  return x+1\n")
    tokens = tokenize.generate_tokens(r.readline)
    print(list(tokens))

test_generate_tokens()


# Generated at 2022-06-17 17:03:49.742475
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, '1', (0, 0), (0, 1), '1')
    printtoken(NUMBER, '1', (0, 0), (0, 1), '1')


# Generated at 2022-06-17 17:04:30.909735
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", " "]
    u.add_whitespace((1, 4))
    assert u.tokens == [" ", " ", "  "]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", " ", "  "]
    u.add_whitespace((2, 1))

# Generated at 2022-06-17 17:04:40.637749
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _format(tok):
        return tok_name[tok[0]], tok[1]

    def _format_token(tok):
        return _format(tok), tok[2], tok[3]

    def _format_all(toks):
        return [_format_token(tok) for tok in toks]

    def _test(s, expected):
        result = _format_all(generate_tokens(io.StringIO(s).readline))
        assert result == expected, (result, expected)

    _test("", [])
    _test("\n", [((NAME, ""), (1, 0), (1, 0))])

# Generated at 2022-06-17 17:04:52.114213
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    # Test tokenize_loop() with a memoryview
    f = io.BytesIO(b"1 + 1\n")
    tokens = []
    for t in tokenize(f.readline):
        tokens.append(t)
    assert tokens == [
        (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n"),
        (OP, "+", (1, 2), (1, 3), "1 + 1\n"),
        (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n"),
        (OP, "\n", (1, 5), (1, 6), "1 + 1\n"),
    ]

    # Test tokenize_loop

# Generated at 2022-06-17 17:05:04.376001
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return [tok_name[toknum] for toknum, tokval, _, _, _ in generate_tokens(io.StringIO(s).readline)]

    assert _tokens('a = 1') == ['NAME', 'EQUAL', 'NUMBER', 'NEWLINE', 'ENDMARKER']
    assert _tokens('a = 1\n') == ['NAME', 'EQUAL', 'NUMBER', 'NEWLINE', 'ENDMARKER']
    assert _tokens('a = 1\n\n') == ['NAME', 'EQUAL', 'NUMBER', 'NEWLINE', 'NEWLINE', 'ENDMARKER']
    assert _tokens('a = 1\n\n\n')

# Generated at 2022-06-17 17:05:17.491678
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "abc", (1, 2), (1, 5), "abc")
    printtoken(1, "abc", (1, 2), (1, 5), "abc")
    printtoken(1, "abc", (1, 2), (1, 5), "abc")
    printtoken(1, "abc", (1, 2), (1, 5), "abc")
    printtoken(1, "abc", (1, 2), (1, 5), "abc")
    printtoken(1, "abc", (1, 2), (1, 5), "abc")
    printtoken(1, "abc", (1, 2), (1, 5), "abc")
    printtoken(1, "abc", (1, 2), (1, 5), "abc")

# Generated at 2022-06-17 17:05:27.172680
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List

    def generate_tokens_from_string(s: str) -> List[tokenize.TokenInfo]:
        return list(tokenize.generate_tokens(io.StringIO(s).readline))

    def test_tokenize(s: str, expected: List[tokenize.TokenInfo]) -> None:
        actual = generate_tokens_from_string(s)
        assert actual == expected, repr(actual)

    test_tokenize("", [])
    test_tokenize("\n", [(token.NEWLINE, "\n", (1, 0), (1, 1), "\n")])

# Generated at 2022-06-17 17:05:36.767994
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "1", (0, 0), (0, 1), "")
    printtoken(NAME, "a", (0, 0), (0, 1), "")
    printtoken(STRING, "'''", (0, 0), (0, 3), "")
    printtoken(NEWLINE, "\n", (0, 0), (0, 1), "")
    printtoken(INDENT, "", (0, 0), (0, 0), "")
    printtoken(DEDENT, "", (0, 0), (0, 0), "")
    printtoken(ENDMARKER, "", (0, 0), (0, 0), "")


# Generated at 2022-06-17 17:05:51.773577
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# -*- coding: latin-1 -*-"])

    def readline():
        yield b"# coding=utf-8"
        yield b"blah"

    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8"])

    def readline():
        yield b"\xef\xbb\xbf# coding=utf-8"
        yield b"blah"

    assert detect_encoding(readline) == ("utf-8-sig", [b"# coding=utf-8"])

    def readline():
        yield b

# Generated at 2022-06-17 17:06:02.209959
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 'token', (1, 2), (3, 4), 'line')
    printtoken(1, 'token', (1, 2), (3, 4), 'line')
    printtoken(1, 'token', (1, 2), (3, 4), 'line')
    printtoken(1, 'token', (1, 2), (3, 4), 'line')
    printtoken(1, 'token', (1, 2), (3, 4), 'line')
    printtoken(1, 'token', (1, 2), (3, 4), 'line')
    printtoken(1, 'token', (1, 2), (3, 4), 'line')
    printtoken(1, 'token', (1, 2), (3, 4), 'line')

# Generated at 2022-06-17 17:06:06.011555
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import tok_name

    s = io.StringIO("def foo(): pass\n")
    for token in generate_tokens(s.readline):
        print(tok_name[token[0]], repr(token[1]))



# Generated at 2022-06-17 17:07:08.089746
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    s = "def f(x): return 2*x"
    g = generate_tokens(StringIO(s).readline)
    for t in g:
        print(t)
    print()
    g = generate_tokens(StringIO(s).readline)
    for toknum, tokval, _, _, _ in g:
        print(tok_name[toknum], tokval)


# Generated at 2022-06-17 17:07:20.057719
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:07:31.830997
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(generate_tokens(io.StringIO(s).readline))

    def _names(s):
        return [tok_name[toknum] for toknum, _, _, _, _ in _tokens(s)]

    assert _names("") == ["ENDMARKER"]
    assert _names("\n") == ["NL", "ENDMARKER"]
    assert _names("\n\n") == ["NL", "NL", "ENDMARKER"]
    assert _names("a = 1") == ["NAME", "OP", "NUMBER", "ENDMARKER"]

# Generated at 2022-06-17 17:07:42.939977
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return [tok_name[toknum] for toknum, tokval, _, _, _ in generate_tokens(io.StringIO(s).readline)]

    assert _tokens("") == ["ENDMARKER"]
    assert _tokens("\n") == ["NL", "ENDMARKER"]
    assert _tokens("\n\n") == ["NL", "NL", "ENDMARKER"]
    assert _tokens("\n\n\n") == ["NL", "NL", "NL", "ENDMARKER"]
    assert _tokens("\n\n\n\n") == ["NL", "NL", "NL", "NL", "ENDMARKER"]

# Generated at 2022-06-17 17:07:54.997039
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def _tokens(s):
        return list(generate_tokens(io.StringIO(s).readline))

    def _names(s):
        return [tok_name[tok[0]] for tok in _tokens(s)]

    assert _names("a = 1") == ["NAME", "OP", "NUMBER", "NEWLINE"]
    assert _names("a = 1\n") == ["NAME", "OP", "NUMBER", "NEWLINE"]
    assert _names("a = 1\nb = 2") == ["NAME", "OP", "NUMBER", "NEWLINE", "NAME", "OP", "NUMBER", "NEWLINE"]

# Generated at 2022-06-17 17:08:06.017950
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import untokenize_printable
    from tokenize import _tokenize_whitespace
    from tokenize import _tokenize_whitespace_and_comments
    from tokenize import _tokenize_number
    from tokenize import _tokenize_string
    from tokenize import _tokenize_name
    from tokenize import _tokenize_op
    from tokenize import _tokenize_punctuation
    from tokenize import _tokenize_unknown
    from tokenize import _tokenize_open_string
    from tokenize import _tokenize_close_string
    from tokenize import _tokenize_

# Generated at 2022-06-17 17:08:18.249304
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize

    def test(s):
        f = io.StringIO(s)
        g = _tokenize.generate_tokens(f.readline)
        for tok in g:
            print(tok)

    test("def f(x): return 2*x\n")
    test("def f(x): return 2*x\n")
    test("def f(x): return 2*x\n")
    test("def f(x): return 2*x\n")
    test("def f(x): return 2*x\n")
    test("def f(x): return 2*x\n")
    test("def f(x): return 2*x\n")
    test("def f(x): return 2*x\n")

# Generated at 2022-06-17 17:08:22.453978
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.StringIO("def f():\n  pass\n")
    g = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in g:
        print(toknum, tokval)

test_generate_tokens()


# Generated at 2022-06-17 17:08:32.079312
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from blib2to3.pgen2.token import tok_name

    class Readline:
        def __init__(self, lines):
            self.lines = lines
            self.index = 0

        def __call__(self):
            if self.index >= len(self.lines):
                return ""
            line = self.lines[self.index]
            self.index += 1
            return line

    def tokeneater(*args):
        tokeneater.tokens.append(args)

    tokeneater.tokens = []
    readline = Readline(["print('Hello, world!') # a comment"])
    tokenize_module.tokenize_loop(readline, tokeneater)
    assert tokeneater.t

# Generated at 2022-06-17 17:08:36.969695
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == [" ", " ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", " ", "\n", " "]
    untok.add_whitespace

# Generated at 2022-06-17 17:09:52.117350
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tokenize, untokenize, NUMBER, NAME, OP

    def check_tokenize_loop(input, expected):
        f = io.StringIO(input)
        result = []
        tokenize_loop(f.readline, result.append)
        assert result == expected

    check_tokenize_loop("1 + 1", [(NUMBER, "1", (1, 0), (1, 1), "1 + 1"),
                                  (OP, "+", (1, 2), (1, 3), "1 + 1"),
                                  (NUMBER, "1", (1, 4), (1, 5), "1 + 1")])


# Generated at 2022-06-17 17:09:56.691161
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    s = "def f(x): return 2*x"
    g = generate_tokens(StringIO(s).readline)
    for t in g:
        print(t)
    print()
    g = generate_tokens(StringIO(s).readline)
    for t in g:
        print(tok_name[t[0]], t[1])


# Generated at 2022-06-17 17:10:06.311522
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"# coding: ascii\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"\n"
        yield b"# yet more comment\n"
        yield b"# coding: ascii\n"
        yield b"# comment\n"
        yield

# Generated at 2022-06-17 17:10:17.488817
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"blah"]

    def readline():
        yield b"# coding=utf-8"
        yield b"blah"

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == [b"# coding=utf-8", b"blah"]

    def readline():
        yield b"#!/usr/bin/python"
        yield b"# -*- coding: latin-1 -*-"

# Generated at 2022-06-17 17:10:28.410575
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, b"1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, b"+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, b"1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, b"\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:10:40.511679
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List, Tuple

    def _format(tokens: List[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]) -> str:
        return "".join(
            [
                "%-20s%-10s%-10s%-10s%s"
                % (
                    tokenize.tok_name[tok[0]],
                    str(tok[2]),
                    str(tok[3]),
                    str(tok[4]),
                    tok[1],
                )
                for tok in tokens
            ]
        )


# Generated at 2022-06-17 17:10:53.739282
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name

    def show_tokens(input):
        for token in generate_tokens(StringIO(input).readline):
            print(tok_name[token[0]], repr(token[1]))

    show_tokens('foo = "bar"\n')
    show_tokens("""\
    '''a
    multiline
    string'''\
    """)
    show_tokens("""\
    '''a
    multiline
    string'''
    '''another
    multiline
    string'''\
    """)