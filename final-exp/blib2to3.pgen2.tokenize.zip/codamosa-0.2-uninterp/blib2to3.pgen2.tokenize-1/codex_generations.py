

# Generated at 2022-06-17 17:03:28.483669
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from typing import Iterable
    from typing import Iterator
    from typing import List
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import overload
    from typing import TYPE_CHECKING
    from typing import Any
    from typing import Callable
    from typing import Optional
    from typing import Text
    from typing import TypeVar
    from typing import Union
    from typing import cast
    from typing import overload
    from typing import TYPE_CHECKING
    from typing import Any
    from typing import Callable
    from typing import Optional
    from typing import Text
    from typing import TypeVar
    from typing import Union
    from typing import cast
    from typing import overload
    from typing import TYPE_CHECKING
    from typing import Any
    from typing import Call

# Generated at 2022-06-17 17:03:40.834959
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import INDENT, DEDENT, NEWLINE, ENDMARKER
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import NAME, NUMBER, ASYNC, AWAIT
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.tokenize import untokenize

# Generated at 2022-06-17 17:03:44.290726
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import tok_name

    s = io.StringIO("if 1:\n  pass\n")
    for token in generate_tokens(s.readline):
        print(token)



# Generated at 2022-06-17 17:03:47.202617
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "def f(x):"
        yield "  return x + 1"

    def tokeneater(*args):
        print(args)

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:03:58.231724
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:04:07.965544
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", " "]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", " ", "\n"]
    u.add_whitespace((2, 1))
    assert u.tokens == [" ", " ", "\n", " "]
    u.add_whitespace((2, 2))

# Generated at 2022-06-17 17:04:19.049365
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# comment\n"
        yield b"\n"
        yield b"# coding: latin-1  \n"
        yield b"# comment\n"
        yield b"\n"
        yield b"# coding=latin-1\n"
        yield b"# comment\n"
        yield b"\n"
        yield b"# coding=latin-1  \n"
        yield b"# comment\n"
        yield b"\n"
        yield b"# coding: latin-1\r\n"
        yield b"# comment\r\n"
        yield b"\r\n"

# Generated at 2022-06-17 17:04:29.721716
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from typing import List, Tuple

    def _format(tok: Tuple[int, str, Tuple[int, int], Tuple[int, int], str]) -> str:
        return "{:<14} {:<40} {:<20} {:<20}".format(
            token.tok_name[tok[0]], tok[1], tok[2], tok[3]
        )

    def _format_tokens(tokens: List[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]) -> str:
        return "\n".join(_format(tok) for tok in tokens)

    def _test(code: str) -> None:
        print("\n", code)
        print

# Generated at 2022-06-17 17:04:36.872842
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.BytesIO(b"def f(x): return x+1\n")
    g = tokenize.tokenize(r.readline)
    for toknum, tokval, _, _, _ in g:
        print(
            "%s %s" % (token.tok_name[toknum], repr(tokval))
        )  # Will print something like "NAME 'f'".



# Generated at 2022-06-17 17:04:50.589342
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:05:31.959892
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    untok = Untokenizer()
    f = StringIO("def f(x):\n  return x\n")
    g = generate_tokens(f.readline)
    untok.compat(next(g), g)
    assert untok.tokens == ["def", " ", "f", "(", "x", ")", ":", "\n", "  ", "return", " ", "x", "\n"]
    f = StringIO("def f(x):\n  return x\n")
    g = generate_tokens(f.readline)
    assert untokenize(g) == "def f(x):\n  return x\n"


# Generated at 2022-06-17 17:05:40.545664
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import untokenize
    from tokenize import NUMBER, NAME, NEWLINE, INDENT, DEDENT, ENDMARKER
    from tokenize import tok_name
    from tokenize import COMMENT, NL, ENCODING
    from tokenize import ASYNC, AWAIT

    def _tokens(s):
        return list(generate_tokens(StringIO(s).readline))

    def _untokenize(tokens):
        return untokenize(iter(tokens))

    def _compat(s):
        return _untokenize(_tokens(s))


# Generated at 2022-06-17 17:05:50.963385
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    l = []
    tokenize.tokenize_loop(r, l.append)

# Generated at 2022-06-17 17:06:01.171260
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize

# Generated at 2022-06-17 17:06:10.876725
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from tokenize import tokenize as tokenize_orig
    from tokenize import untokenize as untokenize_orig
    from tokenize import NUMBER, STRING, NAME, OP

    def tokenize_loop(readline, tokeneater):
        for token_info in generate_tokens(readline):
            tokeneater(*token_info)

    def test(input):
        stream = io.StringIO(input)
        tokens1 = list(tokenize_orig(stream.readline))
        stream = io.StringIO(input)
        tokens2 = []
        tokenize_loop(stream.readline, tokens2.append)
        stream = io.StringIO(input)
        tokens3 = list(generate_tokens(stream.readline))
        assert tokens1 == tokens2 == tokens3

# Generated at 2022-06-17 17:06:17.781110
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, ENDMARKER
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, ENDMARKER
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2.token import Token
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2 import token
    from blib2to3.pgen2.grammar import Grammar

# Generated at 2022-06-17 17:06:29.739500
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, ENDMARKER
    from io import BytesIO
    from tokenize import tokenize
    from token import NAME, NUMBER, ASYNC, AWAIT

    def check(input, output):
        result = Untokenizer().untokenize(generate_tokens(StringIO(input).readline))
        assert result == output, "%r != %r" % (result, output)

    check("def f():\n    pass\n", "def f():\n    pass\n")
    check("def f():\n    pass", "def f():\n    pass\n")

# Generated at 2022-06-17 17:06:41.351224
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"

# Generated at 2022-06-17 17:06:48.885949
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:06:55.475698
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x\n")
    result = []
    tokenize.tokenize(r.readline, result.append)

# Generated at 2022-06-17 17:07:32.859767
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:07:40.789879
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    tokens = [
        (NAME, "abc"),
        (NUMBER, "123"),
        (NEWLINE, "\n"),
        (NAME, "def"),
        (NUMBER, "456"),
        (NEWLINE, "\n"),
        (NAME, "ghi"),
        (NUMBER, "789"),
    ]
    result = untok.untokenize(tokens)
    assert result == "abc 123\ndef 456\nghi 789 "



# Generated at 2022-06-17 17:07:54.149413
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:08:05.932788
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for toknum, tokval, _, _, _ in tokens:
        print(
            "%s %s" % (token.tok_name[toknum], repr(tokval))
        )  # Should print "NAME 'if' NEWLINE NAME '1' COLON ..."

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = tokenize.generate_tokens(readline)

# Generated at 2022-06-17 17:08:18.218340
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"# foo", b"# bar", b"# baz"]

    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"blah"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
   

# Generated at 2022-06-17 17:08:27.008812
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:08:39.111776
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    from io import StringIO
    r = StringIO("def f(x):\n  return 2*x\n")
    result = list(tokenize.generate_tokens(r.readline))
    assert result[0] == (token.NAME, 'def', (1, 0), (1, 3), 'def f(x):\n')
    assert result[1] == (token.NAME, 'f', (1, 4), (1, 5), 'def f(x):\n')
    assert result[2] == (token.OP, '(', (1, 5), (1, 6), 'def f(x):\n')
    assert result[3] == (token.NAME, 'x', (1, 6), (1, 7), 'def f(x):\n')
    assert result[4]

# Generated at 2022-06-17 17:08:48.193621
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens

    def readline():
        return 'print("hello world")\n'

    def tokeneater(*args):
        print(token.tok_name[args[0]], args[1])

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-17 17:09:00.760818
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b")]) == "a b"
    assert u.untokenize([(1, "a"), (0, " "), (2, "b")]) == "a b"
    assert u.untokenize([(1, "a"), (0, "\n"), (2, "b")]) == "a\nb"
    assert u.untokenize([(1, "a"), (0, "\n"), (0, " "), (2, "b")]) == "a\n b"
    assert u.untokenize([(1, "a"), (0, "\n"), (0, " "), (0, "\n"), (2, "b")]) == "a\n\nb"

# Generated at 2022-06-17 17:09:13.749086
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    r = StringIO("def f(x): return 2*x").readline
    result = list(tokenize.generate_tokens(r))

# Generated at 2022-06-17 17:09:44.569585
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:09:52.246825
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), "1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), "1 + 1\n")

# Generated at 2022-06-17 17:09:59.445174
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def f(x): return 2*x")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print("%s %s" % (token.tok_name[toknum], repr(tokval)))



# Generated at 2022-06-17 17:10:08.288693
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c")]) == "abc"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d")]) == "abcd"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")]) == "abcde"
    assert u.untokenize([(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e"), (6, "f")]) == "abcdef"

# Generated at 2022-06-17 17:10:18.695530
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), "1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), "1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), "1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), "1 + 1\n")

# Generated at 2022-06-17 17:10:23.019746
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io
    import token
    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = tokenize.generate_tokens(readline)
    for tok in tokens:
        print(tok)

test_generate_tokens()


# Generated at 2022-06-17 17:10:27.313976
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        for line in ["def f(x): return 2*x\n", "f(3)\n"]:
            yield line
    tokeneater = printtoken
    tokenize_loop(readline(), tokeneater)



# Generated at 2022-06-17 17:10:33.640350
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import tok_name

    s = io.StringIO("def f(x): return x + 1\n")
    for token in generate_tokens(s.readline):
        print(token)
        assert token[0] == tok_name[token[0]]


# Generated at 2022-06-17 17:10:42.727538
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from io import StringIO

    r = StringIO("def f(x): return 'abc' + 'def'\n")
    result = []
    tokenize.tokenize(r.readline, result.append)

# Generated at 2022-06-17 17:10:48.015143
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        for line in ["def f(x): return 2*x\n", "print(f(4))\n"]:
            yield line
    tokeneater = printtoken
    tokenize_loop(readline(), tokeneater)

