

# Generated at 2022-06-17 17:02:12.350312
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import COMMENT
    from blib2to3.pgen2.tokenize import NL
    from blib2to3.pgen2.tokenize import ENCODING
    from blib2to3.pgen2.tokenize import NAME
    from blib2to3.pgen2.tokenize import OP
    from blib2to3.pgen2.tokenize import STRING
    from blib2to3.pgen2.tokenize import NUMBER

# Generated at 2022-06-17 17:02:22.094697
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == [" ", " ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", " ", "\n", " "]
    untok.add_whitespace((3, 0))
    assert untok

# Generated at 2022-06-17 17:02:32.352549
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more code\n"
        yield b"# even more code\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# some more code\n"
        yield b"# even more code\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# some more code\n"
        yield b"# even more code\n"
        yield b"\n"
        yield b"#!/usr/bin/python\n"
       

# Generated at 2022-06-17 17:02:41.542683
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more comment\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8 with blanks\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig with blanks\n"
        yield b"# coding=utf-8-sig with blanks\n"
        yield b"# coding=utf-8-sig with blanks\n"
        yield b"# coding=utf-8-sig with blanks\n"
        yield b"# coding=utf-8-sig with blanks\n"

# Generated at 2022-06-17 17:02:53.209645
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import NAME, NUMBER, STRING, NEWLINE, INDENT, DEDENT, ENDMARKER

    def tokenize_loop_helper(s, expected):
        f = io.StringIO(s)
        result = []
        tokenize_loop(f.readline, result.append)
        assert result == expected


# Generated at 2022-06-17 17:03:04.115562
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf
    from blib2to3.fixer_util import Name
    from blib2to3.fixer_util import token

    def test(input, expected):
        u = Untokenizer()
        result = u.compat(
            (token.NAME, "x"),
            generate_tokens(StringIO(input).readline),
        )
        assert result == expected, (result, expected)

    test("", "x")
    test("\n", "x\n")

# Generated at 2022-06-17 17:03:07.089537
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    r = io.StringIO("def f(x): return x+1\n")
    tokenize.tokenize_loop(r.readline, printtoken)



# Generated at 2022-06-17 17:03:17.564512
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    import unittest

    class TestTokenize(unittest.TestCase):
        def test_tokenize_empty(self):
            f = io.StringIO("")
            tokens = list(tokenize.tokenize(f.readline))
            self.assertEqual(tokens, [])

        def test_tokenize_simple(self):
            f = io.StringIO("print(1)")
            tokens = list(tokenize.tokenize(f.readline))

# Generated at 2022-06-17 17:03:26.253773
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT

    def test(input, expected):
        result = Untokenizer().untokenize(generate_tokens(StringIO(input).readline))
        assert result == expected, (result, expected)

    test("def f():\n  pass\n", "def f():\n  pass\n")
    test("def f():\n  pass\n\n", "def f():\n  pass\n\n")
    test("def f():\n  pass\n\n\n", "def f():\n  pass\n\n\n")

# Generated at 2022-06-17 17:03:38.689133
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()

# Generated at 2022-06-17 17:05:21.061126
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123")

# Generated at 2022-06-17 17:05:33.009877
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.token import COMMENT, NL, NAME, OP, NUMBER, STRING
    from blib2to3.pgen2.token import ENDMARKER, ENCODING, ERRORTOKEN
    from blib2to3.pgen2.tokenize import TokenError
    from blib2to3.pgen2.tokenize import StopTokenizing
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import detect_encoding


# Generated at 2022-06-17 17:05:41.749595
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, "1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, "+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, "1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, "\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:05:55.256466
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import generate_tokens
    from tokenize import TokenInfo
    from tokenize import TokenError
    from tokenize import NL
    from tokenize import NEWLINE
    from tokenize import INDENT
    from tokenize import DEDENT
    from tokenize import NAME
    from tokenize import NUMBER
    from tokenize import ASYNC
    from tokenize import AWAIT
    from tokenize import ENCODING
    from tokenize import COMMENT
    from tokenize import tokenize_loop
    from tokenize import tokenize
    from tokenize import untokenize
    from tokenize import generate_tokens
    from tokenize import TokenInfo
    from tokenize import TokenError

# Generated at 2022-06-17 17:05:59.075801
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, tok_name

    def tokeneater(*args):
        print(args)

    s = io.StringIO("if 1:\n  pass\n")
    tokenize_loop(s.readline, tokeneater)



# Generated at 2022-06-17 17:06:09.439164
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    from tokenize import generate_tokens
    readline = io.StringIO("def f(x): return 2*x").readline
    tokens = list(generate_tokens(readline))
    print(tokens)
    assert tokens[0] == (token.NAME, "def", (1, 0), (1, 3), "\n")
    assert tokens[1] == (token.NAME, "f", (1, 4), (1, 5), "\n")
    assert tokens[2] == (token.OP, "(", (1, 5), (1, 6), "\n")
    assert tokens[3] == (token.NAME, "x", (1, 6), (1, 7), "\n")

# Generated at 2022-06-17 17:06:13.819294
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    r = BytesIO(b"def f(x):\n  return x**2\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tokenize.tok_name[toknum], tokval)

test_generate_tokens()


# Generated at 2022-06-17 17:06:26.472894
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()

# Generated at 2022-06-17 17:06:33.381853
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"1 + 1\n").readline
    tokens = list(tokenize(readline))
    assert tokens[0] == (NUMBER, b"1", (1, 0), (1, 1), b"1 + 1\n")
    assert tokens[1] == (OP, b"+", (1, 2), (1, 3), b"1 + 1\n")
    assert tokens[2] == (NUMBER, b"1", (1, 4), (1, 5), b"1 + 1\n")
    assert tokens[3] == (NEWLINE, b"\n", (1, 5), (1, 6), b"1 + 1\n")

# Generated at 2022-06-17 17:06:44.779782
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0] == (token.NAME, b"if", (1, 0), (1, 2), b"if 1:\n")
    assert tokens[1] == (token.NUMBER, b"1", (1, 3), (1, 4), b"if 1:\n")
    assert tokens[2] == (token.OP, b":", (1, 4), (1, 5), b"if 1:\n")

# Generated at 2022-06-17 17:07:52.441293
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    r = io.BytesIO(b"def f(x):\n  return x+1\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(token.tok_name[toknum], tokval)


# Generated at 2022-06-17 17:08:05.535124
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import tokenize_loop
    from tokenize import untokenize
    from tokenize import NUMBER, STRING, NAME, OP
    from tokenize import COMMENT, ENDMARKER, INDENT, DEDENT
    from tokenize import NEWLINE, ENCODING

    def test_tokenize(s):
        f = StringIO(s)
        tokens = []
        tokenize_loop(f.readline, tokens.append)
        return tokens

    def test_untokenize(tokens):
        return untokenize(tokens)

    def compare(s, tokens):
        result = test_tokenize(s)
        if tokens != result:
            print("expected:")

# Generated at 2022-06-17 17:08:08.902602
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "1", (0, 0), (0, 1), "")

# End unit test for function printtoken


# Generated at 2022-06-17 17:08:14.229507
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from io import StringIO

    s = "def f(x): return 2*x\n"
    f = StringIO(s)
    tokenize_module.tokenize_loop(f.readline, printtoken)



# Generated at 2022-06-17 17:08:22.858032
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO

    readline = io.StringIO("def f(x): return 2*x").readline
    tokeneater = tokenize.untokenize
    tokenize.tokenize_loop(readline, tokeneater)
    readline = io.StringIO("def f(x): return 2*x").readline
    tokeneater = tokenize.printtoken
    tokenize.tokenize_loop(readline, tokeneater)
    readline = io.StringIO("def f(x): return 2*x").readline
    tokeneater = tokenize.printtoken
    tokenize.tokenize_loop(readline, tokeneater)
    readline = io.StringIO("def f(x): return 2*x").readline


# Generated at 2022-06-17 17:08:32.393291
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# -*- coding: latin-1 -*-"])

    def readline():
        yield b"# coding=utf-8"
        yield b"blah"

    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8"])

    def readline():
        yield b"\xef\xbb\xbf# coding=utf-8"
        yield b"blah"

    assert detect_encoding(readline) == ("utf-8-sig", [b"\xef\xbb\xbf# coding=utf-8"])



# Generated at 2022-06-17 17:08:35.136275
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "a", (1, 1), (1, 2), "")



# Generated at 2022-06-17 17:08:43.887541
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for tok in tokens:
        print(tok)

    # Test untokenize
    g = generate_tokens(io.BytesIO(b"if 1:\n  pass\n").readline)
    readline = iter(untokenize(g).splitlines(1)).__next__
    tokens = generate_tokens(readline)
    for tok in tokens:
        print(tok)

    # Test roundtrip

# Generated at 2022-06-17 17:08:47.453285
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    r = io.BytesIO(b"def f(x):\n  return x**2\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print("%10s %-14s" % (token.tok_name[toknum], repr(tokval)))


# Generated at 2022-06-17 17:09:00.268473
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: ascii\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:10:02.374262
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"# -*- coding: iso-8859-1 -*-\n"
        yield b"# vim: set fileencoding=utf-8 :\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# vi: set fileencoding=latin-1 :\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# vi: set fileencoding=utf-8 :\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield

# Generated at 2022-06-17 17:10:09.923202
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some other comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-16\n"
        yield b"# coding=utf-16-le\n"
        yield b"# coding=utf-16-be\n"
        yield b"# coding=utf-32\n"
        yield b"# coding=utf-32-le\n"
        yield b"# coding=utf-32-be\n"
        yield b"# coding=utf-32-ex\n"

# Generated at 2022-06-17 17:10:21.027307
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()

# Generated at 2022-06-17 17:10:34.116878
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    from io import StringIO

# Generated at 2022-06-17 17:10:39.242235
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# -*- coding: iso-8859-1 -*-\n"
        yield b"# vim: set fileencoding=iso-8859-15 :\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: -*-\n"
        yield b"# coding: cp-1252\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-8-sig\n"

# Generated at 2022-06-17 17:10:45.815147
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import tok_name
    from tokenize import tokenize_loop
    s = io.StringIO("print(1)\n")
    l = []
    tokenize_loop(s.readline, l.append)