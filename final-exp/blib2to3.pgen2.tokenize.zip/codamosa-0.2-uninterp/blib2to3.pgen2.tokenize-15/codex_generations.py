

# Generated at 2022-06-17 17:02:51.417651
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# -*- coding: iso-8859-15 -*-"
        yield b"# bar"
        yield b"# -*- coding: ascii -*-"
        yield b"# baz"
        yield b"# -*- coding: utf-8 -*-"
        yield b"# qux"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"# quux"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"# quuux"
        yield b"# -*- coding: utf-8-sig -*-"

# Generated at 2022-06-17 17:03:03.047258
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#!/usr/bin/python\n"
        yield b"# coding=utf-8\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# vim: set fileencoding=utf-8 :\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"# coding=iso-8859-15\n"
        yield b"# coding=iso-latin-1\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding: latin-1\n"

# Generated at 2022-06-17 17:03:14.293597
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    from io import StringIO
    r = StringIO("def f(x):\n  return 2*x\n")
    result = list(tokenize.generate_tokens(r.readline))
    assert result[0] == (token.NAME, 'def', (1, 0), (1, 3), 'def f(x):\n')
    assert result[1] == (token.NAME, 'f', (1, 4), (1, 5), 'def f(x):\n')
    assert result[2] == (token.OP, '(', (1, 5), (1, 6), 'def f(x):\n')
    assert result[3] == (token.NAME, 'x', (1, 6), (1, 7), 'def f(x):\n')
    assert result[4]

# Generated at 2022-06-17 17:03:24.002475
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from tokenize import tokenize
    from tokenize import untokenize

    def test(input, expected):
        result = []
        tokenize(StringIO(input).readline, result.append)
        assert result == expected

    test("", [])
    test("\n", [(tokenize.NEWLINE, "\n", (1, 0), (1, 1), "\n")])
    test("abc", [(tokenize.NAME, "abc", (1, 0), (1, 3), "abc")])

# Generated at 2022-06-17 17:03:35.441916
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    r = StringIO("def f():\n  return 42").readline
    result = list(tokenize.generate_tokens(r))

# Generated at 2022-06-17 17:03:42.962569
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

    s = "def f(x):\n  return 2*x\n"
    readline = StringIO(s).readline
    result = []
    untok = Untokenizer()
    for t in generate_tokens(readline):
        result.append(t)
    assert untok.compat(result[0], iter(result[1:])) == "def f ( x ) : "
    assert untok.compat(result[4], iter(result[5:])) == "  return 2 * x "



# Generated at 2022-06-17 17:03:50.747853
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from io import StringIO

    s = "def f(x): return 2*x\n"
    f = StringIO(s)
    rl = f.readline
    result = []
    tokenize_module.tokenize_loop(rl, result.append)

# Generated at 2022-06-17 17:03:59.851384
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding=utf-8\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=iso-8859-1\n"
        yield b"# coding=iso-latin-1\n"
        yield b"# coding=iso-8859-15\n"
        yield b"# coding=cp1252\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-16\n"
        yield b"# coding=utf-16-le\n"
        yield b"# coding=utf-16-be\n"
        yield b"# coding=utf-32\n"
        yield b"# coding=utf-32-le\n"

# Generated at 2022-06-17 17:04:04.173161
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize
    r = io.StringIO("def f(x): return 2*x").readline
    _tokenize.tokenize(r)
    r = io.StringIO("def f(x): return 2*x").readline
    _tokenize.tokenize(r, printtoken)


# Generated at 2022-06-17 17:04:16.375335
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#! /usr/bin/env python\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# vim:fileencoding=latin-1\n"
        yield b"\n"
        yield b"# this is a comment\n"
        yield b"#!\n"
        yield b"\n"
        yield b"#!python\n"
        yield b"\n"
        yield b"# coding=utf-8\n"
        yield b"\n"
        yield b"# coding=utf-8-sig\n"
        yield b"\n"
        yield b"# coding=utf-8-sig\n"


# Generated at 2022-06-17 17:04:51.107197
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name

    def tokenize_print(readline):
        for token in generate_tokens(readline):
            print(token)

    # Test empty input
    tokenize_print(io.StringIO("").readline)

    # Test tokenizing of a simple expression
    tokenize_print(io.StringIO("1 + 1").readline)

    # Test tokenizing of a string
    tokenize_print(io.StringIO("'abc'").readline)

    # Test tokenizing of a triple-quoted string
    tokenize_print(io.StringIO("'''abc'''").readline)

    # Test tokenizing of a triple-quoted string spanning lines
    s = "'abc' +\n'def'"

# Generated at 2022-06-17 17:05:03.005367
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize

    def test(input):
        f = io.StringIO(input)
        alltokens = list(generate_tokens(f.readline))
        f.close()
        u = untokenize(alltokens)
        f = StringIO(u)
        alltokens = list(generate_tokens(f.readline))
        f.close()
        return alltokens


# Generated at 2022-06-17 17:05:14.562892
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((1, 3))
    assert untok.tokens == [" ", " ", " "]
    untok.add_whitespace((2, 0))
    assert untok.tokens == [" ", " ", " ", "\n"]
    untok.add_whitespace((2, 1))

# Generated at 2022-06-17 17:05:26.204954
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import untokenize_compat
    from blib2to3.pgen2.tokenize import untokenize_compat_2_7
    from blib2to3.pgen2.tokenize import untokenize_compat_3_2
    from blib2to3.pgen2.tokenize import untokenize_compat_3_3
    from blib2to3.pgen2.tokenize import untokenize_compat_3_4
    from blib2to3.pgen2.tokenize import untokenize_compat_3_5

# Generated at 2022-06-17 17:05:34.467661
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for tok in tokens:
        print(tok)

    g = generate_tokens(readline)
    for toknum, tokval, _, _, _ in g:
        if toknum == token.NAME and tokval == "if":
            break
    for toknum, tokval, _, _, _ in g:
        if toknum == token.NUMBER and tokval == "1":
            break
    else:
        raise RuntimeError("didn't find NUMBER 1")

# Generated at 2022-06-17 17:05:48.314809
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-"]



# Generated at 2022-06-17 17:05:56.656833
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.token import INDENT, DEDENT, NEWLINE, NL, NAME, NUMBER, ASYNC, AWAIT
    u = Untokenizer()
    iterable = generate_tokens(StringIO("a = 1\n  b = 2\n").readline)
    assert u.untokenize(iterable) == "a = 1\n  b = 2\n"

# Generated at 2022-06-17 17:06:08.366281
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pgen2.tokenize import tokenize_loop, generate_tokens, tok_name
    from blib2to3.pgen2.tokenize import TokenInfo
    from blib2to3.pgen2.tokenize import untokenize
    from blib2to3.pgen2.tokenize import STOP, ENCODING
    from blib2to3.pgen2.tokenize import COMMENT, NL, NAME, OP, NUMBER, STRING
    from blib2to3.pgen2.tokenize import INDENT, DEDENT, ENDMARKER
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.tokenize import detect_encoding

# Generated at 2022-06-17 17:06:15.296962
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, ASYNC, AWAIT

    def test(input, expected):
        result = Untokenizer().compat(
            (NAME, "def"),
            generate_tokens(StringIO(input).readline),
        )
        assert result == expected, (result, expected)

    test("f(", "def f( ")
    test("f(\n", "def f(\n")
    test("f(\n    ", "def f(\n    ")
    test("f(\n    x", "def f(\n    x ")
    test("f(\n    x\n", "def f(\n    x\n")

# Generated at 2022-06-17 17:06:28.292669
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name

    def show_tokens(input):
        for token in generate_tokens(StringIO(input).readline):
            print(token)

    show_tokens("1 + 1\n")
    show_tokens("1 + 1 # one plus one\n")
    show_tokens("'''three\nquotes\n'''\n")
    show_tokens('r"Hello \"world\""\n')

# Generated at 2022-06-17 17:07:18.606817
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize

    def _tokeneater(*args):
        tok = _tokenize.TokenInfo(*args)
        print(tok)

    s = io.StringIO("def f(x): return 2*x")
    tokenize(s.readline, _tokeneater)



# Generated at 2022-06-17 17:07:23.120328
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize

    readline = io.BytesIO(b"def f(x): return x+1\n").readline
    with tokenize.TokenError:
        list(tokenize.generate_tokens(readline))

    readline = io.BytesIO(b"def f(x): return x+1\n").readline
    tokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-17 17:07:35.827801
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import StringIO
    from token import *
    r = StringIO("def f(x):\n  return 2*x\n")
    result = list(tokenize.generate_tokens(r.readline))

# Generated at 2022-06-17 17:07:45.756361
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# comment\n"
        yield b"#!python\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# coding=latin-1\n"
        yield b"\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=latin-1\n"

# Generated at 2022-06-17 17:07:55.903296
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    readline = BytesIO(b"if 1:\n  pass\n").readline
    tokens = tokenize.generate_tokens(readline)
    token = next(tokens)
    assert token.type == tokenize.NAME
    assert token.string == "if"
    assert token.start == (1, 0)
    assert token.end == (1, 2)
    assert token.line == "if 1:\n"
    token = next(tokens)
    assert token.type == tokenize.NUMBER
    assert token.string == "1"
    assert token.start == (1, 3)
    assert token.end == (1, 4)
    assert token.line == "if 1:\n"
    token = next(tokens)


# Generated at 2022-06-17 17:08:06.549801
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# more comment\n"
        yield b"# coding=ascii\n"
        yield b"# coding=utf-8\n"
        yield b"# coding=utf-8-sig\n"
        yield b"# coding=utf-16\n"
        yield b"# coding: utf-16-le\n"
        yield b"# coding: utf-16-be\n"
        yield b"# coding: utf-32\n"
        yield b"# coding: utf-32-le\n"
        yield b"# coding: utf-32-be\n"

# Generated at 2022-06-17 17:08:18.334775
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# another comment\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"# -*- coding: iso-latin-1 -*-\n"
        yield b"# -*- coding: iso-8859-15 -*-\n"
        yield b"# -*- coding: utf-8 -*-\n"
        yield b"# -*- coding: utf-8-sig -*-\n"
        yield b"# -*- coding: utf-8-with-signature -*-\n"
        yield b"# -*- coding: utf-16 -*-\n"

# Generated at 2022-06-17 17:08:29.540243
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
        yield b"# bar"
        yield b"# baz"
        yield b"# qux"
        yield b"# quux"
        yield b"# corge"
        yield b"# grault"
        yield b"# garply"
        yield b"# waldo"
        yield b"# fred"
        yield b"# plugh"
        yield b"# xyzzy"
        yield b"# thud"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:08:41.047191
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some other comment\n"
        yield b"if 1:\n"
        yield b"  pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# some other comment\n"]

    def readline():
        yield b"# coding=latin-1\n"
        yield b"# some other comment\n"
        yield b"if 1:\n"
        yield b"  pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-17 17:08:48.951614
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (2, 'b'), (3, 'c')])
    assert untok.tokens == ['a', 'b', 'c']
    assert untok.prev_row == 1
    assert untok.prev_col == 3
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.untokenize([(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')])
    assert untok.tokens == ['a', 'b', 'c', 'd']

# Generated at 2022-06-17 17:09:20.477879
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-latin-1 -*-"
        yield b"\n"
        yield b"# -*- coding: iso-8859-1 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8 -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: utf-8-sig -*-"
        yield b"\n"
        yield b"# -*- coding: unknown -*-"
        yield b"\n"

# Generated at 2022-06-17 17:09:30.316863
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "abc"), (2, "def")]) == "abc def"
    assert u.untokenize([(1, "abc"), (2, "def"), (3, "ghi")]) == "abc def ghi"
    assert u.untokenize([(1, "abc"), (2, "def"), (3, "ghi"), (4, "jkl")]) == "abc def ghi jkl"
    assert u.untokenize([(1, "abc"), (2, "def"), (3, "ghi"), (4, "jkl"), (5, "mno")]) == "abc def ghi jkl mno"

# Generated at 2022-06-17 17:09:37.922744
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    r = BytesIO(b"def f(x):\n  return x+1\n")
    tokens = tokenize.generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in tokens:
        print(toknum, tokval)

test_generate_tokens()


# Generated at 2022-06-17 17:09:52.329573
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.tokens = ["a", "b", "c"]
    untok.prev_row = 1
    untok.prev_col = 2
    untok.add_whitespace((1, 3))
    assert untok.tokens == ["a", "b", "c", " "]
    untok.tokens = ["a", "b", "c"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == ["a", "b", "c", "\n"]
    untok.tokens = ["a", "b", "c"]
    untok.add_whitespace((2, 2))
    assert untok.tokens == ["a", "b", "c", "\n", " "]
    unt

# Generated at 2022-06-17 17:10:04.466007
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: iso-8859-15\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"# coding: utf-8-sig\n"
        yield b"# some comment\n"
        yield b"# another comment\n"


# Generated at 2022-06-17 17:10:16.772797
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "def f(x):"
        yield "  return x + 1"
        yield ""
    tokeneater = []
    tokenize_loop(readline(), tokeneater.append)

# Generated at 2022-06-17 17:10:27.420290
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: utf-8\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-8859-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"
        yield b"# coding: iso-latin-1\n"
        yield b"# some comment\n"
        yield b"# another comment\n"
        yield b"\n"

# Generated at 2022-06-17 17:10:38.925163
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pygram import python_symbols as syms

    def tokenize_with(s):
        tokens = []
        tokeneater = tokens.append
        readline = io.StringIO(s).readline
        tokenize_loop(readline, tokeneater)
        return tokens

    assert tokenize_with("a = 1") == [
        (syms.NAME, "a", (1, 0), (1, 1), "a = 1"),
        (syms.EQUAL, "=", (1, 2), (1, 3), "a = 1"),
        (syms.NUMBER, "1", (1, 4), (1, 5), "a = 1"),
    ]



# Generated at 2022-06-17 17:10:50.737112
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"#! /usr/bin/python\n"
        yield b"# coding: latin-1\n"
        yield b"# coding=latin-1\n"
        yield b"# coding=utf-8\n"
        yield b"#!/usr/bin/python\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# coding: latin-1\n"
        yield b"# coding: utf-8\n"
        yield b"# coding: utf-8\n"
        yield b"# coding: utf-8\n"
        yield b"#!/usr/bin/python\n"