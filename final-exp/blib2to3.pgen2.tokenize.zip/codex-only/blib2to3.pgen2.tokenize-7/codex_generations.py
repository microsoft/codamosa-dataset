

# Generated at 2022-06-23 15:51:23.533912
# Unit test for function printtoken
def test_printtoken():
    printtoken(
        NUMBER, "123", (1, 0), (1, 3), "foo\nbar"
    )  # Expected: 1,0-1,3:	NUMBER	'123'
    printtoken(
        NAME, "foo", (1, 0), (1, 3), "foo\nbar"
    )  # Expected: 1,0-1,3:	NAME	'foo'
    printtoken(
        NEWLINE, "", (1, 0), (1, 0), "foo\nbar"
    )  # Expected: 1,0-1,0:	NEWLINE	''
    printtoken(
        INDENT, "", (1, 0), (1, 4), "foo\nbar"
    )  # Expected: 1,0-1,4:	INDENT	''

# Generated at 2022-06-23 15:51:32.269446
# Unit test for function maybe
def test_maybe():
    assert maybe('a', 'b', 'c') in ('a', 'b', 'c', '')


Whitespace = "[ \\f\\t]*"
Comment = "#[^\\r\\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = "[a-zA-Z_]\\w*"

Hexnumber = "0[xX](?:_?[0-9a-fA-F])+"
Binnumber = "0[bB](?:_?[01])+"
Octnumber = "0[oO](?:_?[0-7])+"
Decnumber = "(?:0(?:_?0)*|[1-9](?:_?[0-9])*)"

# Generated at 2022-06-23 15:51:37.024644
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 2
    untok.prev_col = 1
    untok.add_whitespace((2, 2))
    untok.tokens.append("a")
    untok.add_whitespace((2, 3))
    untok.tokens.append("b")
    untok.add_whitespace((2, 5))
    assert untok.tokens == ["  ", "a", "  ", "b", "  "]



# Generated at 2022-06-23 15:51:38.538979
# Unit test for function tokenize
def test_tokenize():
    import io
    r = io.StringIO("if 1:\n    print(2)\n")
    tokenize(r.readline)



# Generated at 2022-06-23 15:51:40.311250
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?", "maybe test failed"



# Generated at 2022-06-23 15:51:50.319812
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 5
    u.prev_col = 0
    u.add_whitespace((7, 0))  # Same row
    assert u.tokens == ["\n\n"]
    u.tokens = []
    u.prev_row = 5
    u.prev_col = 0
    u.add_whitespace((5, 12))  # Same row + indent
    assert u.tokens == ["\n            "]
    u.tokens = []
    u.prev_row = 5
    u.prev_col = 0
    u.add_whitespace((6, 0))  # One more row
    assert u.tokens == ["\n"]
    u.tokens = []
    u.prev_row = 5
   

# Generated at 2022-06-23 15:52:02.004601
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    (readline, tokeneater) = (io.StringIO("bla bla (1 + 2) * 3\n").readline, None)
    try:
        tokenize_loop(readline, tokeneater)
    except StopTokenizing:
        pass
    print(tokeneater)
    print(list(tokenize_loop(readline, tokeneater)))
    assert tokeneater.tokens[0].type == token.NAME
    assert tokeneater.tokens[1].type == token.NAME
    assert tokeneater.tokens[2].type == token.OP
    assert tokeneater.tokens[3].type == token.NUMBER
    assert tokeneater.tokens[4].type == token.OP
   

# Generated at 2022-06-23 15:52:04.294346
# Unit test for constructor of class TokenError
def test_TokenError():
    t = TokenError("message")
    assert str(t) == "message"



# Generated at 2022-06-23 15:52:08.727230
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import tokenize
    r = io.StringIO("def f():\n  pass\n")
    u = Untokenizer()
    tokenize.tokenize(r.readline, u.tokeneater)
    assert u.untokenize(u.tokens) == "def f():\n  pass\n"



# Generated at 2022-06-23 15:52:19.404729
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        # This code is taken from tokenize.detect_encoding, the only
        # change is the way of constructing the generator.
        yield BOM_UTF8
        yield bytes("# -*- coding: latin-1 -*-", "latin-1")
        yield bytes("\n", "latin-1")
        yield bytes("latin-1", "latin-1")
    assert detect_encoding(readline) == ("utf-8", [BOM_UTF8, "# -*- coding: latin-1 -*-\n"])



# Generated at 2022-06-23 15:52:25.319516
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    u.add_whitespace((1, 1))
    u.add_whitespace((1, 2))
    u.add_whitespace((1, 3))
    u.add_whitespace((1, 4))
    assert u.tokens == ["     "]



# Generated at 2022-06-23 15:52:28.386790
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("a test exception")
    except TokenError as msg:
        assert str(msg) == "a test exception"



# Generated at 2022-06-23 15:52:39.022782
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name


# Generated at 2022-06-23 15:52:44.235199
# Unit test for function untokenize
def test_untokenize():
    from io import StringIO
    from tokenize import generate_tokens, untokenize

    def compare(input, output=None):
        f = StringIO(input)
        g = generate_tokens(f.readline)
        u = untokenize(g)
        if output:
            assert u == output, ("%r != %r" % (u, output))
        return u

    # Test round-trip invariant for full input
    def test_full():
        s = "".join([compare('def f():\n pass\n')])
        compare(s, s)

    # Test round-trip invariant for small input fragments

# Generated at 2022-06-23 15:52:54.464159
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import io
    gt = generate_tokens
    tt = token.tok_name
    toks = list(gt(io.StringIO('print(1)\n').readline))
    assert toks[0][0] == token.NAME
    assert toks[1][0] == token.OP
    assert toks[2][0] == token.NUMBER
    assert toks[3][0] == token.OP
    assert toks[4][0] == token.NL
    assert toks[5][0] == token.ENDMARKER
    #
    toks = list(gt(io.StringIO('print(1)').readline))
    assert toks[0][0] == token.NAME
    assert toks[1][0] == token.OP

# Generated at 2022-06-23 15:52:59.674270
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("bad token")
    except TokenError as excinfo:
        assert excinfo.args == ("bad token",)
        assert str(excinfo) == "bad token"



# Generated at 2022-06-23 15:53:03.776379
# Unit test for function printtoken
def test_printtoken():
    try:
        printtoken(token.NUMBER, '12321', (1,1), (1,3), '1 2 3 2 3')
    except Exception as e:
        print(e)



# Generated at 2022-06-23 15:53:06.332905
# Unit test for constructor of class TokenError
def test_TokenError():

    try:
        raise TokenError("test")
    except TokenError:
        pass
    else:
        raise Exception("TokenError constructor failed to raise exception")



# Generated at 2022-06-23 15:53:10.604425
# Unit test for function untokenize
def test_untokenize():
    # Test un-escaping of escaped tab and newline and unicode
    assert untokenize([(3, " '''\\\t\\\n'''"), (1, " ")]) == " '''\t\n''' "
    assert untokenize([(3, "u'\\xe4'"), (1, " ")]) == "u'\xe4' "



# Generated at 2022-06-23 15:53:16.622185
# Unit test for function tokenize_loop
def test_tokenize_loop():
    test_tokenize_loop.__annotations__ = {
        "readline": Callable[[], Text],
        "tokeneater": Callable[[int, Text, Coord, Coord, Text], None],
    }
    test_tokenize_loop.__doc__ = tokenize_loop.__doc__
    tokenize_loop(test_tokenize_loop.readline, test_tokenize_loop.tokeneater)



# Generated at 2022-06-23 15:53:24.019060
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    buf = io.StringIO("*this is a test*\n**\n")
    f = buf.readline
    result = []
    tokenize_loop(f, result.append)

# Generated at 2022-06-23 15:53:36.738231
# Unit test for function generate_tokens
def test_generate_tokens():
    from token import tok_name
    import io
    import unittest

    class TokenTester(unittest.TestCase):
        def testTokenTypes(self):
            # This test is a sanity check for tokenize().  It checks that
            # for each tokenize() output, tok_name[token_type] == token_type's
            # name, and also that tok_name[token_type] is a valid key in
            # token.__dict__.
            from token import tok_name
            from tokenize import tokenize
            types = set()
            tok_name_types = set(tok_name.values())
            with io.StringIO("") as text:
                for tok in tokenize(text.readline):
                    types.add(tok.type)

# Generated at 2022-06-23 15:53:39.121594
# Unit test for function printtoken
def test_printtoken():
    printtoken(tokenize.NUMBER, "1", (1, 0), (1, 1), "1")
    assert True



# Generated at 2022-06-23 15:53:45.077061
# Unit test for function tokenize
def test_tokenize():
    import io

    data = io.StringIO(
        "  for i in range(10):\n"
        "    print(i, i*i)\n"
        "  \n"
        "if __name__ == '__main__':\n"
        "    print(__name__)\n"
    )
    for tok in generate_tokens(data.readline):
        print(tok)
#        printtoken(*tok)



# Generated at 2022-06-23 15:53:47.347881
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("abc") == "(a|b|c)*"



# Generated at 2022-06-23 15:53:56.973548
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# bla bla\n"

    res = detect_encoding(readline)
    assert res == ("iso-8859-1", [b"# coding: latin-1\n", b"# bla bla\n"])

    def readline():
        yield b"# coding: latin-1\n"
        yield b"# bla bla\n"
        yield b"f=4\n"
        yield b"# foo\n"

    res = detect_encoding(readline)
    assert res == ("iso-8859-1", [b"# coding: latin-1\n", b"# bla bla\n"])


# Generated at 2022-06-23 15:54:05.435509
# Unit test for function tokenize
def test_tokenize():
    """Basic test of tokenize"""

    from io import StringIO

    text = "def foo(a, b): return a + b\n"
    f = StringIO(text)
    for (toknum, tokval, (srow, scol), (erow, ecol), line) in generate_tokens(f.readline):
        if toknum == NEWLINE:
            assert line.endswith("\n")
            line = line[:-1]
            assert line == text
        printtoken(toknum, tokval, (srow, scol), (erow, ecol), line)



# Generated at 2022-06-23 15:54:14.465711
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    from test.support.script_helper import assert_python_ok, assert_python_failure

    def roundtrip(s):
        stream = io.StringIO(s)
        tokens = [t[:2] for t in tokenize.generate_tokens(stream.readline)]
        readline = iter(s.splitlines(True)).__next__
        newcode = untokenize(tokens)
        stream = io.StringIO(newcode)
        tokens2 = [t[:2] for t in tokenize.generate_tokens(stream.readline)]
        assert tokens2 == tokens

    # single line
    roundtrip('a = 1')
    roundtrip('a = [1, 2, ]')

# Generated at 2022-06-23 15:54:27.547188
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"

# Tail end of 'stringprefix'
_stringend = group(r"[rb]?'''", r'[rb]?"""')

whitespace = " \t"
whitespace_or_newline = " \t\r\n"
wordchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_"

# Regular expression flags
_FLAGS = re.UNICODE | re.MULTILINE | re.DOTALL | re.VERBOSE

# Regular expressions for operators

# Generated at 2022-06-23 15:54:38.468215
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    def tokenize_lines(s: Text) -> List[TokenInfo]:
        g = generate_tokens(StringIO(s).readline)
        return list(from_token(token, g) for token in g)


# Generated at 2022-06-23 15:54:40.191337
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:54:41.261749
# Unit test for function maybe
def test_maybe():
    assert maybe('"') == '(")?'



# Generated at 2022-06-23 15:54:49.084727
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    # Create a Token object for each token that you want to test.
    tok_1 = tokenize.TokenInfo(tokenize.NUMBER, '100', (1, 0), (1, 3), '100')
    tok_2 = tokenize.TokenInfo(tokenize.NEWLINE, '\n', (1, 3), (1, 4), '\n')
    tok_3 = tokenize.TokenInfo(tokenize.NAME, 'print', (2, 0), (2, 5), 'print')
    tok_4 = tokenize.TokenInfo(tokenize.OP, '(', (2, 5), (2, 6), '(')
    tok_5 = tokenize.TokenInfo(tokenize.NAME, 'x', (2, 6), (2, 7), 'x')
   

# Generated at 2022-06-23 15:54:51.395063
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        raise StopIteration
    tokenize_loop(readline, printtoken)



# Generated at 2022-06-23 15:54:54.263027
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("test")
    except TokenError as err:
        assert str(err) == "test"



# Generated at 2022-06-23 15:54:56.789593
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    unt = Untokenizer()
    unt.add_whitespace((1, 0))
    unt.add_whitespace((1, 1))
    unt.add_whitespace((1, 80))
    unt.add_whitespace((1, 81))
    unt.add_whitespace((2, 0))
    unt.add_whitespace((3, 0))



# Generated at 2022-06-23 15:55:09.403876
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from test.support import captured_stdout, findfile
    # This test is fragile because the token.c file is different on
    # different machines.  It tries to deal with the variations by
    # normalizing the list of tokens by their position in the stream.
    source_path = findfile("tokenize_tests.txt", subdir="lib2to3")
    with open(source_path, "rb") as f:
        src = f.read()
    src = src.decode("latin-1").encode("utf-8").decode("utf-8")
    def readline():
        if src:
            line, src = src.split("\n", 1)
            return line + "\n"
        else:
            return ""

# Generated at 2022-06-23 15:55:12.427099
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("bad input")
    except TokenError as e:
        assert str(e) == "bad input"
    except Exception as e:
        assert False, "Unexpected exception"



# Generated at 2022-06-23 15:55:17.361078
# Unit test for function group
def test_group():
    assert group("ab", "cd") == "(ab|cd)"


whitespace_re = re.compile(br"\s+", flags=re.DOTALL)
comment_re = re.compile(br"#.*?$", flags=re.MULTILINE)
idprog = re.compile(br"[a-zA-Z_]\w*")

# Generated at 2022-06-23 15:55:20.986571
# Unit test for constructor of class TokenError
def test_TokenError():
    exc = TokenError("test")
    assert exc.args[0] == "test"


# This is indexed by the encoding of the input in order to return the
# correct newline setting.

newline_decoder = {"\n": None, "\r\n": "crlf", "\r": "cr"}



# Generated at 2022-06-23 15:55:29.737737
# Unit test for constructor of class TokenError
def test_TokenError():
    # Test 1: expected argument
    exception = None
    try:
        raise TokenError
    except Exception as err:
        exception = err
    assert (
        str(exception) == TokenError.__doc__
    ), "tokenize.TokenError constructor test failed"
    # Test 2: unexpected argument
    exception = None
    try:
        raise TokenError(42)
    except Exception as err:
        exception = err
    assert (
        str(exception) == TokenError.__doc__
    ), "tokenize.TokenError constructor test failed"



# Generated at 2022-06-23 15:55:31.328414
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "ss", (0, 0), (0, 0), "")



# Generated at 2022-06-23 15:55:42.285703
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize

    s = "def foo():\n    try:\n        pass\n    finally:\n        pass"
    with io.StringIO(s) as f:
        result = tokenize.untokenize(f.readline)
    assert result == s, repr(result)

    s = "if True:\n    pass\nelse:\n    pass"
    with io.StringIO(s) as f:
        result = tokenize.untokenize(f.readline)
    assert result == s, repr(result)

    s = r"if True:\n    pass\n\n\nx = '''\ndef foo():\n    try:\n        pass\n    finally:\n        pass'''\n"
    with io.StringIO(s) as f:
        result = tokenize

# Generated at 2022-06-23 15:55:47.120030
# Unit test for function maybe
def test_maybe():
    assert re.match(maybe("a", "b", "c"), "")
    assert re.match(maybe("a", "b", "c"), "a")
    assert re.match(maybe("a", "b", "c"), "b")
    assert re.match(maybe("a", "b", "c"), "c")



# Generated at 2022-06-23 15:55:53.007453
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    _ut = Untokenizer()
    data = [
        (NAME, "abc"),
        (NEWLINE, "\n"),
        (NUMBER, "42"),
        (NEWLINE, "\n"),
        (NAME, "abc"),
    ]
    assert _ut.untokenize(data) == "abc\n42\nabc"



# Generated at 2022-06-23 15:55:58.112380
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(iterable):
        def readline():
            for l in iterable:
                yield l

        return readline

    test1 = [b"# coding: latin-1\n"]
    assert detect_encoding(readlines(test1)) == ("iso-8859-1", test1)
    test2 = [b'#!/usr/bin/python\n', b"# coding: latin-1\n"]
    assert detect_encoding(readlines(test2)) == ("iso-8859-1", test2)
    test3 = [b"\xef\xbb\xbf# coding: latin-1\n"]
    assert detect_encoding(readlines(test3)) == ("iso-8859-1", test3)

# Generated at 2022-06-23 15:56:08.076973
# Unit test for function untokenize
def test_untokenize():
    # FIXME(nnorwitz): this should really be using StringIO and cStringIO
    # instead of relying on the tokenize module to produce output that
    # is untokenizable.
    import StringIO

    s = 'def f(x): return 37 + x\nprint(f(37))\n'
    readline = iter(s.splitlines(1)).next
    tokgen = generate_tokens(readline)
    out = StringIO.StringIO()
    for tok in tokgen:
        out.write(tok[1])
    res = out.getvalue()
    tmptok = tokenize(iter(res.splitlines(1)).next)
    newres = untokenize(tmptok)
    assert newres == res



# Generated at 2022-06-23 15:56:11.704218
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(actual, expected):
        assert actual == expected, "Expected {!r} but got {!r}".format(expected, actual)
    from io import StringIO
    from tokenize import tok_name

# Generated at 2022-06-23 15:56:13.520596
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:56:20.160962
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    t=Untokenizer()
    t.prev_row=2
    t.prev_col=0
    t.add_whitespace((2, 3))
    assert t.tokens==["   "]
    t.add_whitespace((3, 0))
    assert t.tokens==["   \n"]


# Generated at 2022-06-23 15:56:29.082331
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    token_stream = [
        (NUMBER, "1", (0, 0), (0, 0), ""),
        (NEWLINE, "\n", (0, 0), (0, 0), ""),
        (NUMBER, "2", (0, 1), (0, 1), ""),
    ]
    untokenizer = Untokenizer()
    untokenizer.compat(token_stream[0], token_stream[1:])
    assert "".join(untokenizer.tokens) == "1\n"



# Generated at 2022-06-23 15:56:39.743253
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(lines: List[bytes]) -> Callable[[], bytes]:
        def gen() -> Iterator[bytes]:
            for line in lines:
                yield line

        return gen

    # utf-8
    encoding, _ = detect_encoding(readlines([b"blah blah"]))
    assert encoding == "utf-8"

    # utf-8-sig
    encoding, _ = detect_encoding(readlines([BOM_UTF8 + b"blah blah"]))
    assert encoding == "utf-8-sig"

    # First line is a comment-only line
    encoding, lines = detect_encoding(readlines([b"# -*- coding: utf-8 -*-\n"]))
    assert encoding == "utf-8"

# Generated at 2022-06-23 15:56:51.156443
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    tokens = ("xxx", (1, 2), "   ", (3, 4))
    u.tokens = list(tokens)
    u2 = Untokenizer()
    assert u2.tokens == []
    assert u.prev_row == 4
    assert u2.prev_row == 1
    assert u.prev_col == 4
    assert u2.prev_col == 0
    u2.add_whitespace((0, 0))
    u2.add_whitespace((0, 0))
    u2.add_whitespace((1, 1))
    u2.add_whitespace((4, 4))
    assert u2.tokens == ["", "   ", "  ", "    "]



# Generated at 2022-06-23 15:56:54.655192
# Unit test for function tokenize
def test_tokenize():
    import io
    rio = io.StringIO("""def f(x):
    return x + 1
""")
    tokeneater = printtoken
    tokenize(rio.readline, tokeneater)



# Generated at 2022-06-23 15:56:59.082998
# Unit test for function maybe
def test_maybe():
    assert re.match(maybe(r'\w+', r'\d+'), '1234')
    assert re.match(maybe(r'\w+', r'\d+'), 'foo')
    assert re.match(maybe(r'\w+', r'\d+'), 'fo1234')
    assert not re.match(maybe(r'\w+', r'\d+'), '--')



# Generated at 2022-06-23 15:57:06.814449
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from .tokenize import tokenize, untokenize

    # Read the input file (located in the same directory)
    with open(__file__, 'r', encoding='utf-8') as fp:
        text = fp.read()
    assert text.endswith("\n")

    # Tokenize the input file
    stream = tokenize(StringIO(text).readline)

    # Untokenize a stream of tokens
    output = StringIO()
    untokenize(stream, output.write)
    assert output.getvalue() == text



# Generated at 2022-06-23 15:57:09.308129
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    assert u.prev_row == 1
    assert u.prev_col == 0


# Generated at 2022-06-23 15:57:10.190110
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError("a test")



# Generated at 2022-06-23 15:57:12.740663
# Unit test for function printtoken
def test_printtoken():
    printtoken(0, "a", (0,0), (0,1), "a")
    printtoken(2, "abc", (0,0), (0,0), "abc")
# End unit test



# Generated at 2022-06-23 15:57:15.800419
# Unit test for function printtoken
def test_printtoken():
    assert printtoken(3, 'if', (0, 0), (0,0), '') == '0,0-0,0:\tIF\t\'if\''



# Generated at 2022-06-23 15:57:19.994437
# Unit test for constructor of class TokenError
def test_TokenError():
    # This code should fail without an exception
    try:
        raise TokenError
    except TokenError:
        pass
    try:
        raise TokenError("testing")
    except TokenError:
        pass


# Input-stream interface


# Generated at 2022-06-23 15:57:30.295614
# Unit test for function untokenize
def test_untokenize():
    input1 = (
        "def foo():\n"
        "    bar_baz(spam(1)) # Comment\n"
        "\n"
        "class Bar:\n"
        "    'Doc string'\n"
        "    spam(2)\n"
        "\n"
        "# Another comment\n"
        "\n"
        "def baz():\n"
        '    return "Line %d\\n" % 42\n'
    )
    readline = iter(input1.splitlines(True)).__next__
    tokengen = generate_tokens(readline)
    output1 = untokenize(tokengen)
    readline = iter(output1.splitlines(True)).__next__
    tokengen = generate_tokens(readline)
   

# Generated at 2022-06-23 15:57:40.606916
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    s = u.untokenize(((1, " "), (2, " "), (1, " "), (0, "a")))
    assert s == "   a"
    u = Untokenizer()
    s = u.untokenize(((3, " "), (0, "\n"), (3, " "), (0, "\n")))
    assert s == "\n\n"
    u = Untokenizer()
    s = u.untokenize(((1, " "), (2, " "), (1, " "), (0, "a"), (0, "\n"), (0, "b")))
    assert s == "   a\nb"


# Generated at 2022-06-23 15:57:43.111962
# Unit test for function maybe
def test_maybe():
    assert maybe('ab') == '(ab)?'
    assert maybe('ab','cd') == '(ab|cd)?'
    print('test_maybe ok')
test_maybe()

# Helper for _compile

# Generated at 2022-06-23 15:57:46.199754
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "def f(x): return 2*x"
    g = generate_tokens(iter(s.splitlines()).__next__)
    l = []
    tokenize_loop(iter(s.splitlines()).__next__, l.append)
    assert l == list(g)



# Generated at 2022-06-23 15:57:56.742496
# Unit test for function any
def test_any():
    def validate_regex(regex, strings):
        # type: (Pattern[str], Iterable[str]) -> None
        for string in strings:
            assert regex.fullmatch(string), '{!r} does not match regex {!r}'.format(
                string, regex.pattern
            )

    regex = re.compile(any("ab", "cd"))
    validate_regex(regex, ("cdabcdab", "abab"))
    regex = re.compile(any("abc", "def"))
    validate_regex(regex, ("abcdefabcdef", "defabc"))



# Generated at 2022-06-23 15:58:07.226639
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield "bom".encode("utf-8-sig")
        yield "# coding: cp1252\n".encode("ascii")
        raise StopIteration
    assert detect_encoding(readline) == ("cp1252", [])

    def readline():
        yield "# coding: cp1252\n".encode("ascii")
        yield "bom".encode("utf-8-sig")
        raise StopIteration
    try:
        detect_encoding(readline)
    except SyntaxError as e:
        assert str(e) == "encoding problem: utf-8"
    else:
        assert False

    def readline():
        yield "# coding: cp1252 & bogus\n".encode("ascii")

# Generated at 2022-06-23 15:58:17.539728
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO, StringIO
    from unittest import TestCase

    class TestCaseBase(TestCase):
        def setUp(self):
            self.readline = self.readline_setup()

        def tearDown(self):
            self.readline.close()

    class TestCaseReadline(TestCaseBase):
        def readline_setup(self):
            return BytesIO(b"\n")

        def test_empty_file(self):
            self.assertSequenceEqual(
                list(tokenize.generate_tokens(self.readline.readline)),
                [
                    (tokenize.ENDMARKER, "", (1, 0), (1, 0), "\n"),
                ],
            )


# Generated at 2022-06-23 15:58:28.056428
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test the generation of tokens.
    generate_tokens_copy = tokenize.generate_tokens

# Generated at 2022-06-23 15:58:33.099901
# Unit test for function any
def test_any():  # type: () -> None
    assert re.match(any("abc"), "abcabc")
    assert re.match(any("abc"), "abxabx")
    assert re.match(any("abc"), "abxaby")
    assert re.match(any("abc"), "abxabxaby")
    assert re.match(any("abc"), "")
    assert re.match(any("abc"), "xxxxxx")



# Generated at 2022-06-23 15:58:42.409353
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    from blib2to3.pgen2.tokenize import tokenize_loop, tok_name

    def test(
        input,
        expected_tokens,
        *,
        readline_name='test',
        readline_line=1,
        readline_column=1,
        **kwds,
    ):
        readline = io.StringIO(input).readline
        results = []

        def tokeneater(*token_info):
            results.append(token_info)

        tokenize_loop(readline, tokeneater)

        def format_token_info(token_info):
            if token_info[0] == ENCODING:
                return (ENCODING, token_info[1], None, None, None)
            else:
                return token_info

# Generated at 2022-06-23 15:58:56.001546
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "123.456", ((1, 2), (1, 8)), ((1, 2), (1, 8)), "")
    printtoken(NUMBER, "123.456j", ((1, 2), (1, 9)), ((1, 2), (1, 9)), "")
    printtoken(NUMBER, "0x12ef", ((1, 2), (1, 6)), ((1, 2), (1, 6)), "")
    printtoken(IMAG, "123.456j", ((1, 2), (1, 9)), ((1, 2), (1, 9)), "")
    printtoken(IMAG, "123.456J", ((1, 2), (1, 9)), ((1, 2), (1, 9)), "")

# Generated at 2022-06-23 15:59:03.820799
# Unit test for function maybe
def test_maybe():
    # Test that maybe(...) matches zero or more repetitions of the given
    # patterns.  It should match both the empty string and strings matching
    # the given patterns.  It should not match strings which match none of
    # the given patterns.
    p = maybe("from", "import")
    assert re.match(p, "from")
    assert re.match(p, "import")
    assert re.match(p, "from import")
    assert re.match(p, "import from")
    assert re.match(p, "")
    assert re.match(p, "impfrom") is None

# call unit tests for function maybe
test_maybe()



# Generated at 2022-06-23 15:59:04.928507
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:59:15.276263
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.tokens = ["foo"]
    untok.prev_col = 3
    untok.add_whitespace((1, 3))
    assert untok.tokens == ["foo"]
    untok.add_whitespace((2, 0))
    assert untok.tokens == ["foo", "\n"]
    untok.tokens = []
    untok.prev_col = 3
    untok.add_whitespace((1, 5))
    assert untok.tokens == ["  "]
    untok.add_whitespace((1, 6))
    assert untok.tokens == ["  "]
    untok.add

# Generated at 2022-06-23 15:59:18.038238
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    tok = (1, "3")
    untok.compat(tok, iter([]))

# Interface for tokenizing streams

# Generated at 2022-06-23 15:59:19.776982
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    stop_tokenizing = StopTokenizing()
    assert stop_tokenizing is not None



# Generated at 2022-06-23 15:59:21.589906
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:59:22.484630
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    st = StopTokenizing



# Generated at 2022-06-23 15:59:34.789165
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.prev_col = 4
    ut.tokens = ['Мама мыла раму']

# Generated at 2022-06-23 15:59:39.201259
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        assert not e.args
    try:
        raise StopTokenizing("foo")
    except StopTokenizing as e:
        assert e.args == ("foo",)
    try:
        raise StopTokenizing("foo", "bar")
    except StopTokenizing as e:
        assert e.args == ("foo", "bar")


# tokens
NL = 1
COMMENT = 2


# Generated at 2022-06-23 15:59:40.626445
# Unit test for function group
def test_group():
    assert group("abc", "-") == "(abc|-)"



# Generated at 2022-06-23 15:59:41.443185
# Unit test for function any
def test_any():
    pass



# Generated at 2022-06-23 15:59:53.889085
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    c = (1,1)
    u.add_whitespace(c)
    u.prev_row, u.prev_col = c
    assert u.tokens == []
    u.add_whitespace((1,2))
    assert u.tokens == [" "]
    u.add_whitespace((1,3))
    assert u.tokens == [" ", " "]
    u.add_whitespace((1,4))
    assert u.tokens == [" ", " ", " "]
    u.add_whitespace((2,1))
    assert u.tokens == [" ", " ", " ", "\n"]
    u.add_whitespace((2,4))

# Generated at 2022-06-23 15:59:57.568906
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as _:
        pass



# Generated at 2022-06-23 16:00:06.826371
# Unit test for function group
def test_group():
    # assert group('abc','def') == '(abc|def)'
    assert group("abc", "def") == "(abc|def)", "group failed"


whitespace = "[ \\f\\t]*"
# note that \\f and \\v aren't in string.whitespace
comment = "#[^\\r\\n]*"
blankline = group(whitespace, comment) + "$"

namechars = r"[a-zA-Z_]\w*"

# # Note that \f and \v aren't in string.whitespace
# whitespace = '[ \\f\\t]*'
# comment = '#[^\\r\\n]*'
# blankline = group(whitespace, comment) + '$'



# Generated at 2022-06-23 16:00:18.501930
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    import unittest

    class UntokenizerTestCase(unittest.TestCase):
        def test_add_whitespace(self) -> None:
            u = Untokenizer()
            self.assertEqual(u.tokens, [])
            self.assertEqual(u.prev_row, 1)
            self.assertEqual(u.prev_col, 0)
            u.add_whitespace((1, 0))
            self.assertEqual(u.tokens, [])
            u.add_whitespace((1, 1))
            self.assertEqual(u.tokens, [" "])
            u.add_whitespace((1, 0))
            self.assertEqual(u.tokens, [" ", " "])

# Generated at 2022-06-23 16:00:21.859069
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("a") == "a"
    assert group("a", "", "b") == "(a|b)"



# Generated at 2022-06-23 16:00:27.939410
# Unit test for function tokenize
def test_tokenize():
    import io
    from io import StringIO # type: ignore
    # This is a bit crude, but it will do for now.
    src = "def foo(): pass\n"
    f = StringIO(src)
    try:
        g = tokenize(f.readline)
        while True:
            print(g.__next__())
    except StopTokenizing:
        print("That's all, folks!")



# Generated at 2022-06-23 16:00:33.967086
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    readline = io.BytesIO(b"# coding: latin-1\nreadline").readline
    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])
    readline = io.BytesIO(b"#!/usr/local/bin/python\n# coding: latin-1\nreadline").readline
    assert detect_encoding(readline) == ("iso-8859-1", [b"#!/usr/local/bin/python\n", b"# coding: latin-1\n"])
    readline = io.BytesIO(b"# This is a test\nreadline").readline

# Generated at 2022-06-23 16:00:34.838228
# Unit test for function group
def test_group(): pass



# Generated at 2022-06-23 16:00:41.144361
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    un = Untokenizer()
    tokens = [(NUMBER, "1", (1, 0)), (OP, "+", (1, 1)), (NUMBER, "1", (1, 2))]
    res = un.compat(tokens[0], iter(tokens[1:]))
    assert "".join(res) == "1 + 1"



# Generated at 2022-06-23 16:00:51.470911
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest


# Generated at 2022-06-23 16:01:04.954198
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield bytes("# coding=utf-8", "ascii")
    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == [bytes("# coding=utf-8", "ascii")]

    def readline():
        yield bytes("\ufeff# coding=utf-8", "utf-8")
    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8-sig"
    assert lines == [bytes("# coding=utf-8", "utf-8")]

    def readline():
        yield bytes("\ufeff# coding=ascii", "utf-8")
    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8-sig"

# Generated at 2022-06-23 16:01:06.657450
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "42", (5,5), (5,7), "x = 4")

# Generated at 2022-06-23 16:01:07.892724
# Unit test for function any
def test_any():
    return any("abc", "def") == "(abc|def)*"


# Generated at 2022-06-23 16:01:20.319577
# Unit test for function maybe
def test_maybe():
    test_value = maybe('a', 'b')
    test_reference = r'(a|b)?'
    assert test_value == test_reference


# All the standard whitespace characters
Whitespace = r"[ \f\t]*"
# Note, no newline in Whitespace


# All valid string prefixes
# l prefixes are for literal strings
# u prefixes are for unicode strings
#  - normal string: u?r?
#  - raw string: only one of r, u, or ur
Single = r"[ubU]?[rR]?'''"
Double = r'[ubU]?[rR]?"""'
Single3 = r"[ubU]?[rR]?''"
Double3 = r'[ubU]?[rR]?"""'