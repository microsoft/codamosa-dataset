

# Generated at 2022-06-23 15:51:21.126810
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline1():
        yield "def spam():"
        yield "  x = 3"
        raise StopIteration
    def tokeneater1(type, token, start, end, line):
        print("tokeneater1", type, token, start, end, line)
    tokenize_loop(readline1(), tokeneater1)
    readline2 = iter(["def spam():", "  x = 3"])
    def tokeneater2(type, token, start, end, line):
        print("tokeneater2", type, token, start, end, line)
    tokenize_loop(readline2, tokeneater2)



# Generated at 2022-06-23 15:51:26.168359
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()
    untokenizer.prev_row = 1
    untokenizer.prev_col = 1
    untokenizer.add_whitespace((1, 0))
    untokenizer.add_whitespace((1, 1))
    untokenizer.add_whitespace((1, 2))
    untokenizer.add_whitespace((1, 4))
    untokenizer.add_whitespace((2, 0))
    untokenizer.add_whitespace((2, 1))
    untokenizer.add_whitespace((3, 1))
    assert untokenizer.tokens == [" ", "", "  ", "   "]



# Generated at 2022-06-23 15:51:27.779709
# Unit test for function group
def test_group():
    g = group("a", "b", "c")
    assert g == "(a|b|c)"



# Generated at 2022-06-23 15:51:28.975621
# Unit test for function printtoken
def test_printtoken():
    printtoken(0,"","","","")
# printtoken tests passed



# Generated at 2022-06-23 15:51:35.550924
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    assert untok.tokens == []
    untok.add_whitespace((1, 4))
    assert untok.tokens == ['    ']
    untok.add_whitespace((1, 1))
    assert untok.tokens == ['    ', '   ']
    untok.add_whitespace((2, 3))
    assert untok.tokens == ['    ', '   \n', '   ']
    untok.add_whitespace((1, 1))
    assert untok.tokens == ['    ', '   \n', '   ', '']


# Generated at 2022-06-23 15:51:47.074088
# Unit test for function generate_tokens
def test_generate_tokens():
    tokens = list(generate_tokens(StringIO("print\n").readline))
    assert tokens[0] == (NAME, 'print', (1, 0), (1, 5), 'print\n')
    assert tokens[1] == (NEWLINE, '\n', (1, 5), (1, 6), 'print\n')
    assert tokens[2] == (ENDMARKER, '', (2, 0), (2, 0), '')
    assert len(tokens) == 3

    tokens = list(generate_tokens(StringIO("  a = 1 + 2").readline))
    assert tokens[0] == (NAME, 'a', (1, 2), (1, 3), '  a = 1 + 2')

# Generated at 2022-06-23 15:51:57.858169
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    """Method add_whitespace of class Untokenizer should insert
    the right amount of whitespace."""
    # For example, if the last token ended at column k and the
    # current token starts at column m, and row numbers are equal,
    # it should insert m-k spaces before the new token.
    # This is the function we want to test.
    u = Untokenizer()
    u.prev_row = 10
    u.prev_col = 5
    u.tokens = ['a', 'b', 'c']
    # We don't have to test when row numbers are different, since
    # the method should then do nothing.
    u.add_whitespace((10, 8))
    assert u.tokens == ['a', 'b', 'c', '   ']

# Generated at 2022-06-23 15:52:10.140816
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    from unittest.mock import Mock
    ut = Untokenizer()
    ut.tokens = []
    mock_tokeneater = Mock()
    #
    #
    #
    ut.compat(
        (token.NUMBER, "1"),
        (
            (token.ADD, "+"),
            (token.NUMBER, "2"),
            (token.NEWLINE, "\n"),
            (token.ADD, "+"),
            (token.NUMBER, "3"),
            (token.DEDENT, ""),
            (token.NEWLINE, "\n"),
            (token.ENDMARKER, ""),
        ),
    )

    assert ut.tokens == ["1", "+", "2", "\n", "+", "3", "\n"]



# Generated at 2022-06-23 15:52:13.019341
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:52:16.929046
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"\xef\xbb\xbf"
        yield b'# -*- coding: utf-8 -*-\n'
        yield b"\n"

    print(detect_encoding(readline))



# Generated at 2022-06-23 15:52:22.154877
# Unit test for function group
def test_group():
    assert group('a', 'b', 'c') == r'(a|b|c)'
    assert group('a|b|c') == r'(a\|b\|c)'
    assert group('a', 'a.b', 'a-b') == r'(a|a\.b|a\-b)'


# Generated at 2022-06-23 15:52:28.163035
# Unit test for function tokenize
def test_tokenize():
    import tokenize
    s = "def foo(bar):\n    if bar == 'baz':\n        return 'bar'  # foo\n"
    l = s.split("\n")
    for t in tokenize.generate_tokens(lambda: l.pop(0)):
        print(t)


#def tokenize_loop(readline, tokeneater):
#    for token_info in generate_tokens(readline):
#        tokeneater(*token_info)



# Generated at 2022-06-23 15:52:32.481903
# Unit test for function maybe
def test_maybe():
    p = maybe('x')
    assert p.match('x')
    assert p.match('')
    assert p.match('xx')
    assert not p.match('y')


# Generated at 2022-06-23 15:52:36.012503
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass
    try:
        raise TokenError("my_message")
    except TokenError:
        pass



# Generated at 2022-06-23 15:52:38.205755
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    e = StopTokenizing("test message")
    assert e.args == ("test message",)



# Generated at 2022-06-23 15:52:39.294310
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError()



# Generated at 2022-06-23 15:52:40.400976
# Unit test for function group
def test_group():
    assert group("a", "b")



# Generated at 2022-06-23 15:52:50.558333
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from blib2to3.pgen2.token import tok_name

    r = StringIO("a = 1 + 2\n")
    result = []
    tokenize_loop(r.readline, result.append)


# Generated at 2022-06-23 15:52:59.402531
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(tokens, token):
        if token[0] is NAME:
            token = token[:2] + (token[2] + (fsp,),) + token[3:]
        assert next(tokens) == token

    tokens = generate_tokens(iter('if foo(): pass\n').__next__)
    check_token(tokens, (NAME, 'if', (1, 0), (1, 2), 'if foo(): pass\n'))
    check_token(tokens, (NAME, 'foo', (1, 3), (1, 6), 'if foo(): pass\n'))
    check_token(tokens, (OP, '(', (1, 6), (1, 7), 'if foo(): pass\n'))

# Generated at 2022-06-23 15:53:00.481114
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:53:04.586859
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing("Test")
    except StopTokenizing as e:
        if e.args != ("Test",):
            raise AssertionError("Test")



# Generated at 2022-06-23 15:53:06.661330
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing("example")
    except StopTokenizing as e:
        assert e.args[0] == "example"



# Generated at 2022-06-23 15:53:16.347090
# Unit test for function any
def test_any():
    assert re.match(any("a", "b"), "a").group() == "a"
    assert re.match(any("a", "b"), "b").group() == "b"
    assert re.match(any("a", "b"), "ab").group() == "a"
    assert re.match(any("a", "b"), "ba").group() == "b"
    assert re.match(any("a", "b"), "aba").group() == "a"
    assert re.match(any("a", "b"), "bab").group() == "b"
    assert re.match(any("ab", "a"), "ab").group() == "ab"
    assert re.match(any("ab", "a"), "a").group() == "a"

# Generated at 2022-06-23 15:53:19.876392
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b""
        yield b""
    res = detect_encoding(readline)
    assert res[0] == "iso-8859-1"
    assert res[1] == [b"", b""]
    yield None


# Generated at 2022-06-23 15:53:22.040747
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass
    else:
        assert False, "Failed to trigger StopTokenizing exception"



# Generated at 2022-06-23 15:53:35.212529
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    def testit(seq, expected):
        # type: (Iterable[TokenInfo], str) -> None
        res = u.untokenize(seq)
        if res != expected:
            print("Untokenizing %r gives %r, expected %r" % (seq, res, expected))
    testit([(NUMBER, "1"), (NAME, "a"), (NAME, "b")], "1 a b")
    testit([(NUMBER, "1"), (NAME, "a"), (NAME, "b"), (NEWLINE, "\n")], "1 a b\n")

# Generated at 2022-06-23 15:53:45.439474
# Unit test for function generate_tokens
def test_generate_tokens():
    s = "def f(a, b): return a + b\n"
    result = list(generate_tokens(iter(s.splitlines(True)).__next__))

# Generated at 2022-06-23 15:53:53.634970
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # Initialize the untokenizer
    ut = Untokenizer()
    # Create an iterable to which we will pass to ut.compat
    test = [
        (NAME, "x"),
        (INDENT, "  "),
        (NAME, "y"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (NAME, "z"),
    ]
    a = ut.compat(test[0], test[1:])
    assert a == None # Test to see if a is None



# Generated at 2022-06-23 15:53:59.393911
# Unit test for function printtoken
def test_printtoken():
    printtoken(NAME, 'name1', (0, 0), (0, 0), 'line1')
    printtoken(OP, 'op1', (1, 1), (1, 1), 'line2')
    printtoken(NAME, 'name2', (2, 2), (2, 2), 'line3')



# Generated at 2022-06-23 15:54:03.804911
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    tk = StopTokenizing("\n", 100, "abc")
    tk.args


# A cache that remembers the index of the first line in which a given
# line pattern occurs.  The line patterns are python patterns.  This
# is used for fast rejection of lines that can't possibly start a
# token.

# Generated at 2022-06-23 15:54:12.141988
# Unit test for function any
def test_any():
    for x in "", "a", "abc":
        if x != any("b", "c")(x):
            print(x, "not matched by", any("b", "c"))
    for x in "a", "b", "c", "ab", "bc", "abc":
        if x != any("a", "b", "c")(x):
            print(x, "not matched by", any("a", "b", "c"))
if 0:
    test_any()  # not executed



# Generated at 2022-06-23 15:54:13.596255
# Unit test for function any
def test_any():
    assert any('a', 'b', 'c') == '(a|b|c)*'



# Generated at 2022-06-23 15:54:22.554898
# Unit test for function untokenize

# Generated at 2022-06-23 15:54:27.143127
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():

    # pyi: no-member

    ut = Untokenizer()
    ut.compat(("foo", " "), [("bar", " "),("baz", " ")])
    assert ut.tokens == ["foo ", "bar ", "baz "]



# Generated at 2022-06-23 15:54:32.463935
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test with only a BOM
    readline = lambda: None
    readline.__next__ = lambda: bytes(BOM_UTF8 + b"# coding=utf-8\n", "utf-8")
    encoding, read = detect_encoding(readline)
    assert encoding == "utf-8-sig"
    assert read == []

    # Test with only a cookie
    readline = lambda: None
    readline.__next__ = lambda: bytes("# coding=utf-8\n", "utf-8")
    encoding, read = detect_encoding(readline)
    assert encoding == "utf-8"
    assert read == []

    # Test with a BOM and a cookie
    readline = lambda: None

# Generated at 2022-06-23 15:54:43.950887
# Unit test for function printtoken
def test_printtoken():
    import io
    import os
    import pdb
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    #
    # Capture output to stdout...
    oldstdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    #

# Generated at 2022-06-23 15:54:55.550685
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    class Token:
        def __init__(self, type, token, line_no, char_no):
            self.type = type
            self.token = token
            self.line_no = line_no
            self.char_no = char_no
        def __getitem__(self, key):
            return (self.type, self.token)[key]
    u = Untokenizer()
    t1 = Token(NAME, 'x', 1, 0)
    t2 = Token(NUMBER, '4', 1, 1)
    t3 = Token(NEWLINE, '\n', 1, 2)
    t4 = Token(NAME, 'y', 2, 0)
    t5 = Token(NUMBER, '8', 2, 1)
    t6 = Token(NEWLINE, '\n', 2, 2)
   

# Generated at 2022-06-23 15:55:08.139021
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield bytes("", "utf-8")
        yield bytes("# -*- coding: utf-8 -*-", "utf-8")
        yield bytes("# -*- coding: latin-1 -*-", "utf-8")
        yield bytes("# -*- coding: iso-latin-1 -*-", "utf-8")
        yield bytes("", "utf-8")
        yield bytes("# -*- coding: utf-8 -*-", "utf-8")
        yield bytes("\n", "utf-8")
        yield bytes("\n", "utf-8")
        yield bytes("# -*- coding: utf-8 -*-", "utf-8")
        yield bytes("# -*- coding: latin-1 -*-", "utf-8")

# Generated at 2022-06-23 15:55:14.655816
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    s = u.untokenize(
        [
            (NUMBER, "1", (1, 0), None, None),
            (DOT, ".", (1, 1), None, None),
            (NUMBER, "1", (1, 2), None, None),
            (COMMENT, "#", (1, 3), (1, 4), None),
            (NEWLINE, "\n", (1, 4), None, None),
        ]
    )
    assert s == "1.1 # \n"


# Generated at 2022-06-23 15:55:15.883759
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    from blib2to3.pgen2.tokenize import untokenize


# Generated at 2022-06-23 15:55:22.493204
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline() -> bytes:
        return b"# coding: latin-1\n"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])

    def readline() -> bytes:
        return b"#!/usr/bin/python\n# coding: latin-1\n"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])

    def readline() -> bytes:
        return b"#!/usr/bin/python\n#coding:latin-1\n"

    assert detect_encoding(readline) == ("iso-8859-1", [b"#coding:latin-1\n"])

   

# Generated at 2022-06-23 15:55:23.824272
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 1, (1, 1), (1, 2), 1)


# default line offset

# Generated at 2022-06-23 15:55:25.192084
# Unit test for function printtoken
def test_printtoken():
    printtoken(ENDMARKER, "", (0, 0), (0, 0), "")


# Generated at 2022-06-23 15:55:35.547725
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    from copy import copy
    from . import tokenize as tk
    from .token import *
    u = Untokenizer()
    u.tokens = []
    u.prev_row = 6
    u.prev_col = 0
    u.add_whitespace((6, 2))
    assert u.tokens == ["  "]
    u.tokens = []
    u.add_whitespace((6, 0))
    assert u.tokens == [""]
    u2 = copy(u)
    u2.tokens = ["\n"]
    u2.add_whitespace((7, 2))
    assert u2.tokens == ["\n", "  "]
    u2 = copy(u)
    u2.tokens = ["\n"]
    u2

# Generated at 2022-06-23 15:55:45.125375
# Unit test for function generate_tokens
def test_generate_tokens():
    from token import tok_name

    prog = """
          def __init__(self, multiplier):
              self.mult = multiplier
          def do_it(self, x):
              return x * self.mult

          f = Foo(23)
          g = Foo(37)
          """
    import io

    f = io.StringIO(prog)

    t = generate_tokens(f.readline)
    tt = type(t)
    assert tt is GeneratorType, tt
    tt = type(t.gi_code)
    assert tt is code, tt
    # tt = type(t.gi_frame)
    # assert tt is frame, tt

    for tok in t:
        print(tok_name[tok[0]], tok)


# Test it

# Generated at 2022-06-23 15:55:46.641443
# Unit test for function printtoken
def test_printtoken():
    '''Test printtoken'''
    printtoken(1, 12, (0, 0), (4, 4), '')
# Used for running tests

# Generated at 2022-06-23 15:55:51.045890
# Unit test for function printtoken
def test_printtoken():
    for type, token, (srow, scol), (erow, ecol), line in generate_tokens(iter(["foobar"]).__next__):
        printtoken(type, token, (srow, scol), (erow, ecol), line)



# Generated at 2022-06-23 15:55:56.521594
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"\xef\xbb\xbf"
        yield b"# coding: latin-1\r\n"
    enc, lines = detect_encoding(readline)
    assert enc == "iso-8859-1"
    assert lines == [b"\xef\xbb\xbf", b"# coding: latin-1\r\n"]
    def readline():
        yield b"\xef\xbb\xbf"
        yield b"# coding=latin-1\r\n"
    enc, lines = detect_encoding(readline)
    assert enc == "iso-8859-1"
    def readline():
        yield b"\xef\xbb\xbf"
        yield b"# coding: latin-1\n"
       

# Generated at 2022-06-23 15:55:58.651215
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"



# Generated at 2022-06-23 15:56:01.863113
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        for x in [b"if 1: #\n", b""]:
            yield x
    tokenize_loop(readline().__next__,printtoken)


# Generated at 2022-06-23 15:56:04.170727
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?"
    assert maybe("a") == "a?"
    assert maybe("") == ""



# Generated at 2022-06-23 15:56:09.255473
# Unit test for function printtoken
def test_printtoken():
    """Test function printtoken"""
    srow, scol = (0, 0)
    erow, ecol = (0, 0)
    line = None
    type = NUMBER
    token = "3"
    printtoken(type, token, (srow, scol), (erow, ecol), line)

# Generated at 2022-06-23 15:56:13.735086
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    def foo():
        yield (NUMBER, "1")
        yield (NEWLINE, "\n")
        yield (NUMBER, "2")
        yield (DEDENT, "")

    unt = Untokenizer()
    unt.compat(foo().next(), foo())
    assert unt.tokens == ["1", "\n", "2"], repr(unt.tokens)



# Generated at 2022-06-23 15:56:20.280941
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    test_untok = untok.compat
    assert untok.tokens == []
    test_untok((NAME, "for"), ())
    assert untok.tokens == ["for "]
    test_untok((INDENT, "    "), ())
    assert untok.tokens == ["for ", "    "]
    test_untok((NAME, "int"), ())
    assert untok.tokens == ["for ", "    ", "int "]
    test_untok(
        (NEWLINE, "\n"),
        (
            (NAME, "var"),
            (DEDENT, ""),
            (NEWLINE, "\n"),
            (NAME, "end"),
            (ENDMARKER, ""),
        ),
    )
    assert untok.t

# Generated at 2022-06-23 15:56:31.862175
# Unit test for function tokenize
def test_tokenize():
    import token
    import io

    def get_input(s):
        f = io.StringIO(s)

        def next_line():
            line = f.readline()
            if not line:
                raise EOFError
            return line

        return next_line

    def compare(s, list):
        list = list[:]
        g = tokenize(get_input(s), None)
        while 1:
            tok = next(g)
            if tok[0] == token.ENDMARKER:
                break
            if tok[:2] != list[:2]:
                print("Tokens don't match", tok, list[:2],
                      "for input", s)
                raise ValueError
            list = list[2:]


# Generated at 2022-06-23 15:56:34.472113
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    r = StringIO("def f(x): return 2*x\n")
    tokenize(r.readline)



# Generated at 2022-06-23 15:56:44.406867
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    # testing if the constructor of class Untokenizer works properly
    u.add_whitespace((1, 2))
    assert u.prev_row == 1
    assert u.prev_col == 2
    u.tokens.append("hello")
    assert u.tokens == ["hello"]
    assert u.prev_row == 1
    assert u.prev_col == 2
    u.prev_row, u.prev_col = 2, 3
    u.tokens.append("world")
    assert u.prev_row == 2
    assert u.prev_col == 3
    u.prev_row, u.prev_col = 3, 2
    u.add_whitespace((3, 2))
    assert u.prev_row == 3
    assert u.prev_col == 2

# Generated at 2022-06-23 15:56:46.818240
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:56:50.197390
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize as _tokenize

# Generated at 2022-06-23 15:56:59.345609
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import sys

    class Test:
        def write(self, s):
            self.result += s

        def __init__(self, list):
            self.result = ""
            untok = Untokenizer()
            untok.compat(list, [])
            for tok in list:
                if tok[0] == token.OP:
                    tok = (token.ADD, tok[1])
                untok.tokens.append(tok[1])
            untok.untokenize(iter(list))
            self.result = ""

    def test(list, result):
        list = list[:]
        for tok in list:
            if tok[0] == token.OP:
                tok = (token.ADD, tok[1])

# Generated at 2022-06-23 15:57:09.022696
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    import pytest
    
    untokenizer = Untokenizer()
    
    untokenizer.add_whitespace((1, 0))
    untokenizer.prev_row = 1
    untokenizer.prev_col = 4
    
    untokenizer.add_whitespace((1, 18))
    assert untokenizer.tokens == ['    ', '            ']
    assert untokenizer.prev_row == 1
    assert untokenizer.prev_col == 18
    
    untokenizer.add_whitespace((7, 10))
    assert untokenizer.tokens == ['    ', '            ', '\n' * 6 + '          ']
    assert untokenizer.prev_row == 7
    assert untokenizer.prev_col == 10
    
    untokenizer.add_whitespace

# Generated at 2022-06-23 15:57:20.669912
# Unit test for function untokenize

# Generated at 2022-06-23 15:57:26.975998
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    l = [("a", ("asdf", 56, 56, "asdf")), ("b", ("qwer", 57, 57, "qwer")), ("c", ("zxcv", 58, 58, "zxcv"))]  # noqa: E501
    s = u.untokenize(l)
    assert s == "asdf qwer zxcv"



# Generated at 2022-06-23 15:57:37.113091
# Unit test for function untokenize
def test_untokenize():
    input = "def foo():\n  a = 1\n  b = 2\n"
    f = iter(input.splitlines(1)).next
    out = untokenize(tokenize(f))
    assert out == input


# generate_tokens() can be used to tokenize an input source representation.

# Each token is a 5-tuple with these members: the token type; the token string;
# a 2-tuple (srow, scol) of ints specifying the row and column where the token
# begins in the source; a 2-tuple (erow, ecol) of ints specifying the row and
# column where the token ends in the source; and the line on which the token was
# found. The line passed is the logical line; continuation lines are included.

# Optional arg:
#   readline: callable

# Generated at 2022-06-23 15:57:45.693630
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # Test if the method adds the right number of spaces.
    # NOTE: This test relies on the behaviour of the private
    # variable _token_generator.start_pos in the method generate_tokens of the
    # tokenize module.
    # For more information on the working of this variable, see the PEP:
    # https://www.python.org/dev/peps/pep-0378/
    # AFAIK there is no other way to test for this behaviour.
    # In other words, this test will break if the implementation
    # of tokenize.generate_tokens changes.
    ut = Untokenizer()
    ut.prev_row = 1
    ut.prev_col = 0
    ut.add_whitespace((1, 0))
    assert ut.tokens == []
    ut.add_

# Generated at 2022-06-23 15:57:51.508107
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    file = io.StringIO("a b cd")

    def readline_mock() -> str:
        return file.readline().strip("\n")

    def tokeneater_mock(type, token, start, end, line):
        tok_name = _main.tok_name[type]
        print("%r %r %r %r %r" % (tok_name, token, start, end, line))

    tokenize_loop(readline_mock, tokeneater_mock)



# Generated at 2022-06-23 15:58:01.489002
# Unit test for function detect_encoding
def test_detect_encoding():
    try:
        import cStringIO as StringIO
    except ImportError:
        import StringIO  # type: ignore

    def readline():
        if not hasattr(readline, "next"):
            readline.next = 0

        if readline.next == 0:
            readline.next = 1
            return '# -*- coding: iso-8859-15 -*-\n'
        elif readline.next == 1:
            readline.next = 2
            return "# -*- coding: ascii -*-\n"
        elif readline.next == 2:
            readline.next = 3
            return "# -*- coding: utf-8 -*-\n"
        elif readline.next == 3:
            readline.next = 4

# Generated at 2022-06-23 15:58:14.550542
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output):
        input = untokenize(input)
        print(input)
        print(output)
        if input != output:
            print("untokenize() failed")
            print("Input was:")
            print(input)
            print("Output was:")
            print(output)
            raise ValueError

    compare([(1, "def")], "def")
    compare([(1, "def"), (1, " ")], "def ")
    compare([(3, "\n"), (1, "def")], "\ndef")
    compare([(1, "def"), (2, " "), (1, "(x)")], "def (x)")

# Generated at 2022-06-23 15:58:16.315607
# Unit test for function tokenize_loop
def test_tokenize_loop():
    tokenize_loop(iter(['if 1:']).__next__, printtoken)



# Generated at 2022-06-23 15:58:19.377490
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield "  \t\f # -*- coding: iso-8859-1 -*-\n"
        yield " \n"
        raise StopIteration
    print(detect_encoding(readline()))


# Generated at 2022-06-23 15:58:22.471007
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]



# Generated at 2022-06-23 15:58:26.247672
# Unit test for function tokenize_loop
def test_tokenize_loop():
    f = StringIO("def f():\n  return '42'")
    def t(type, token, start, end, line):
        assert type == token.NUMBER
        assert token == '42'
    tokenize_loop(f.readline, t)


# Generated at 2022-06-23 15:58:35.138530
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    from io import StringIO
    from typing import List, Tuple
    import unittest
    import warnings

    def test_good_line(line, type, expect):
        # type: (str, int, Tuple[str, str, str, str, str]) -> None
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            readline = io.StringIO(line).readline
            tokens : List[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]] = []
            def tokeneater(*args):
                tokens.append(args)
            tokenize.tokenize_loop(readline, tokeneater)

# Generated at 2022-06-23 15:58:36.927056
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:58:39.153061
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:58:41.835981
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("Test TokenError exception", (2, 3))
    except TokenError as e:
        assert str(e) == "Test TokenError exception"



# Generated at 2022-06-23 15:58:51.260012
# Unit test for function tokenize
def test_tokenize():
    import io

    s = "1 + 1\n"

    def readline(typabbr: str) -> Text:
        if typabbr == "readline":
            return s
        elif typabbr == "string":
            return io.StringIO(s)
        elif typabbr == "bytes":
            return io.BytesIO(s.encode("utf-8"))

    for typabbr in "readline string bytes".split():
        print("Type of readline is ", typabbr)
        tokenize(readline(typabbr))



# Generated at 2022-06-23 15:58:53.058540
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()


# Generated at 2022-06-23 15:58:59.603735
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 0
    u.prev_col = 0
    u.tokens = []
    u.add_whitespace((1, 1))
    u.add_whitespace((1, 2))
    u.add_whitespace((1, 3))
    u.add_whitespace((2, 2))
    assert u.tokens == [' ', '  ', '   ', '\n ']



# Generated at 2022-06-23 15:59:01.337230
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    x = StopTokenizing()
    assert x is not None



# Generated at 2022-06-23 15:59:03.902899
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    assert u.prev_row == 1
    assert u.prev_col == 0



# Generated at 2022-06-23 15:59:06.994427
# Unit test for function printtoken
def test_printtoken():
  printtoken(234, '234', (1,1), (1,1), 'foobar\n')
  printtoken(234, '2345', (1,1), (1,5), 'foobar\n')
  printtoken(234, '23456', (1,1), (1,6), 'foobar\n')


# Generated at 2022-06-23 15:59:08.570734
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"



# Generated at 2022-06-23 15:59:17.653847
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    def get_token_list(s: str) -> List[GoodTokenInfo]:
        tokgen = generate_tokens(StringIO(s).readline)
        return list(tokgen)

    # Test irregular tokens

# Generated at 2022-06-23 15:59:23.143154
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output):
        input = iter(input)
        itokens = generate_tokens(input.next)
        otokens = [token[:2] for token in generate_tokens(iter(output.splitlines(1)).next)]
        assert list(itokens) == otokens
        output = "".join(token[1] for token in generate_tokens(iter(output.splitlines(1)).next))
        assert untokenize(itokens) == output

    compare("# coding: latin-1\nu = '\\xe4y'\n", "# coding: latin-1\nu = '\\xe4y'\n")

    # A roundtrip test that is invariant to input differences
    # such as blank lines

# Generated at 2022-06-23 15:59:27.549100
# Unit test for function untokenize
def test_untokenize():
    def compare(x, y):
        y = y.replace('\r\n', '\n')  # untokenize returns \r\n on Windows.
        x = '\n'.join(line.rstrip() for line in x.split('\n') if line.strip() != '')
        y = '\n'.join(line.rstrip() for line in y.split('\n') if line.strip() != '')
        x = x.split('\n')
        y = y.split('\n')
        for i, _ in enumerate(x):
            if not i < len(y):
                assert 0, '\n'.join(x) + '\n----\n' + '\n'.join(y)

# Generated at 2022-06-23 15:59:31.801612
# Unit test for function untokenize
def test_untokenize():
    import io
    import token
    import tokenize
    # readline = iter('a = 1\n'.splitlines(1)).__next__
    readline = io.StringIO('a = 1\n').readline
    tokens = tokenize.generate_tokens(readline)
    it = iter(tokens)
    print(untokenize(it))
    # Test iterable that is less than 2 tokens long
    it = iter([(token.NUMBER, '1')])
    assert untokenize(it) == '1'
    # Test iterable that has just 2 tokens
    it = iter([(token.NAME, 'a'), (token.EQUAL, '=')])
    assert untokenize(it) == 'a ='
    # Test iterable that is longer than 2 tokens

# Generated at 2022-06-23 15:59:43.374423
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ungettext = Untokenizer().untokenize
    # Check that string literals that include double quotes are properly
    # de-tokenized.  SF #1571831
    eq = assertEqual
    eq(ungettext([(1, '"abc"'), (0, " "), (1, '"def"')]), '"abc" "def"')
    eq(ungettext([(1, "b'abc'"), (0, " "), (1, "b'def'")]), "b'abc' b'def'")
    eq(ungettext([(1, "u'abc'"), (0, " "), (1, "u'def'")]), "u'abc' u'def'")

# Generated at 2022-06-23 15:59:50.155117
# Unit test for function tokenize
def test_tokenize():
    try:
        import builtins
        import token
    except:
        try:
            import __builtin__ as builtins
            import token
        except:
            return # No tokens available - this test makes no sense.


# Generated at 2022-06-23 15:59:53.187179
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
    assert any("a", "12") == "(a|12)*"
    assert any("a", "123") == "(a|123)*"



# Generated at 2022-06-23 16:00:02.311077
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import tokenize
    from io import StringIO
    sample = "def f():\n    pass\n"
    expected = "def f ( ) :\n    pass\n"
    file = StringIO(sample)
    result = tokenize.untokenize(tokenize.generate_tokens(file.readline))
    assert result == expected, "Results did not match exepected:\n" + result

# End unit test for method Untokenizer.compat



# Generated at 2022-06-23 16:00:07.258599
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    """Simple test for class StopTokenizing."""
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    else:
        raise Exception("Failed to instantiate class StopTokenizing")



# Generated at 2022-06-23 16:00:18.764049
# Unit test for function printtoken

# Generated at 2022-06-23 16:00:20.418363
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    _ = StopTokenizing()


_tokenize_c = None



# Generated at 2022-06-23 16:00:21.510628
# Unit test for function group
def test_group():
    assert group("abc") == "abc"


# Generated at 2022-06-23 16:00:30.868100
# Unit test for function tokenize
def test_tokenize():
    def testreadlines(s):
        for c in s:
            yield c
        yield ""

    def testtokenize(s, tokeneater=printtoken):
        tokenize(testreadlines(s).__next__, tokeneater)

    # Test empty input
    testtokenize("")
    # Test token types
    testtokenize(" 1999")
    testtokenize(" 1999L")
    testtokenize(" 1e100")
    testtokenize(" 1.0")
    testtokenize(" .1")
    testtokenize(" 1j")
    testtokenize(" 1.j")
    testtokenize(" 1.0j")
    testtokenize(" 1e-100j")
    testtokenize(" 1J")
    testtokenize(" 'abc'")
    testtokenize(' "abc"')
    test

# Generated at 2022-06-23 16:00:43.127522
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest

    class TokenizeTestCase(unittest.TestCase):
        def check_tokenize(self, text, expected_output):
            got_output = []
            tokenize_loop(io.StringIO(text).readline, got_output.append)
            self.assertEqual(got_output, expected_output)

        def test_tokenize(self):
            self.check_tokenize("1 + 1", [(NUMBER, "1", (1, 0), (1, 1), "1 + 1")])

# Generated at 2022-06-23 16:00:53.211459
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.tokens = []
    start = (1, 0)
    ut.add_whitespace(start)
    assert ut.tokens == []
    start = (1, 1)
    ut.add_whitespace(start)
    assert ut.tokens == [" "]
    start = (2, 0)
    ut.add_whitespace(start)
    assert ut.tokens == [" ", "\n"]
    start = (2, 1)
    ut.add_whitespace(start)
    assert ut.tokens == [" ", "\n", " "]
    start = (2, 0)
    ut.add_whitespace(start)
    assert ut.tokens == [" ", "\n", " "]

# Generated at 2022-06-23 16:00:59.625379
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    tokens = [
        (tokenize.NUMBER, "3"),
        (tokenize.NUMBER, "3"),
        (tokenize.NUMBER, "3"),
        (tokenize.NUMBER, "3"),
    ]
    result = u.untokenize(tokens)
    expected = "3 3 3 3"
    assert result == expected



# Generated at 2022-06-23 16:01:02.001312
# Unit test for function group
def test_group():
    assert group('ab', 'bc', 'd') == '(ab|bc|d)'


# Generated at 2022-06-23 16:01:04.515096
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?", maybe("a", "b")



# Generated at 2022-06-23 16:01:08.937248
# Unit test for function group
def test_group():
    g = group('a', 'ab', 'abcdef')
    assert g == '(a|ab|abcdef)', (g,)
    g = group('a')
    assert g == 'a', (g,)
    g = group('a', 'ab', 'abcdef', '')
    assert g == '(a|ab|abcdef|)', (g,)



# Generated at 2022-06-23 16:01:20.820542
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.add_whitespace((1,0))
    untok.add_whitespace((1,2))
    assert untok.tokens[0] == "  "
    assert untok.tokens[1] == ""
    untok.add_whitespace((1,4))
    assert untok.tokens[2] == "    "
    untok.prev_row = 2
    untok.prev_col = 4
    untok.add_whitespace((2,4))
    assert untok.tokens[3] == ""
    untok.prev_row = 1
    untok.prev_col = 2
    untok.add_whitespace((1,0))
    assert untok.tokens[4] == "  "