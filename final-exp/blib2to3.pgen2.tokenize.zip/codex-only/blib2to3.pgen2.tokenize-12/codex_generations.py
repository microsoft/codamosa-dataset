

# Generated at 2022-06-23 15:51:24.768055
# Unit test for function untokenize
def test_untokenize():
    import io
    import token
    import tokenize
    f = io.BytesIO(b"def f(x): return 2*x\n")
    tokens = tokenize.generate_tokens(f.readline)
    result = untokenize(tokens)
    result_string = result.encode()
    assert result_string == b"def f(x): return 2*x\n"
    tokens = [(token.NAME, b"f"), (token.OP, b"("), (token.NAME, b"x"), (token.OP, b")"),
        (token.OP, b":"), (token.NAME, b"return"), (token.NUMBER, b"2"), (token.OP, b"*"),
        (token.NAME, b"x"), (token.NEWLINE, b"\n")]


# Generated at 2022-06-23 15:51:31.038339
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # empty string
    u = Untokenizer()
    s = u.compat((NUMBER, "1"), [])
    assert u.tokens == ['1'], "test_Untokenizer_compat failed"
    # simpy string
    u = Untokenizer()
    s = u.compat((NUMBER, "1"), [(NAME, "a"), (NUMBER, "2")])
    assert u.tokens == ['1', 'a ', '2'], "test_Untokenizer_compat failed"
    # multi-line string
    u = Untokenizer()
    s = u.compat((NUMBER, "1"), [(NAME, "a"), (NEWLINE, "\n"), (NUMBER, "2")])

# Generated at 2022-06-23 15:51:33.730652
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    tok = StopTokenizing()  # noqa: F841



# Generated at 2022-06-23 15:51:41.165824
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import io

    with io.StringIO("a = 1\n") as f:
        tokengen = generate_tokens(f.readline)
        tokens = list(tokengen)
        assert tokens[0] == (token.NAME, "a", (1, 0), (1, 1), "a = 1\n")
        assert tokens[1] == (token.OP, "=", (1, 2), (1, 3), "a = 1\n")
        assert tokens[2] == (token.NUMBER, "1", (1, 4), (1, 5), "a = 1\n")
        assert tokens[3] == (token.NEWLINE, "", (1, 5), (1, 5), "a = 1\n")

# Generated at 2022-06-23 15:51:44.701108
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io, token
    s = "def foo(x): return 2*x\n"
    f = io.StringIO(s)
    tokenize_loop(f.readline, printtoken)


# Generated at 2022-06-23 15:51:55.861471
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    l = [
        [
            (NAME, 'name'),
            (NEWLINE, '\n'),
            (NAME, 'newname'),
            (NEWLINE, '\n'),
            (NAME, 'endname'),
            (NEWLINE, '\n'),
        ],
        [
            (NAME, 'indent'),
            (NEWLINE, '\n'),
            (NAME, 'dedent'),
            (NEWLINE, '\n'),
            (NAME, 'endindent'),
            (NEWLINE, '\n'),
        ],
    ]
    expected = "name\n    newname\nendname\nindent\n    dedent\nendindent\n"
    assert untok.untokenize(l[0]) == expected

# Generated at 2022-06-23 15:52:08.425789
# Unit test for function tokenize

# Generated at 2022-06-23 15:52:16.746586
# Unit test for function untokenize
def test_untokenize():
    def _test(input):
        input = [item for item in input]
        it = iter(input)
        output = untokenize(it)
        return input, output

    def test(input, output):
        result = _test(input)
        assert result == (input, output), result
    test([(1, "def")], "def ")
    test([(1, "def"), (3, "f"), (4, "()")], "def f()")
    test([(1, "def"), (3, "f"), (4, "()"), (0, ";")], "def f();")

# Generated at 2022-06-23 15:52:26.892487
# Unit test for function untokenize
def test_untokenize():
    # This test goes through the tokenize, untokenize cycle for
    # some small programs, and compares them.
    for program in test_untokenize.programs:
        for t in generate_tokens(StringIO(program).readline):
            print(t)
        got = untokenize(generate_tokens(StringIO(program).readline))
        print(repr(got))
        assert got == program, "roundtrip failed for %r" % program



# Generated at 2022-06-23 15:52:37.270839
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("bad token")
    except TokenError:
        # Check that the runtime type of the instance is TokenError.
        assert isinstance(sys.exc_info()[1], TokenError)


# Map operators to their names

# Generated at 2022-06-23 15:52:40.541801
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    exc = StopTokenizing()
    return str(exc) is not None


_tokenize_cache = {}


# Not sure what's used for this, but it's referenced from tokenize.c

# Generated at 2022-06-23 15:52:50.695785
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import os
    import tempfile
    import unittest
    import tokenize
    from io import BytesIO

    class UntokenizeTest(unittest.TestCase):

        def setUp(self):
            self.tempfile = tempfile.NamedTemporaryFile("w+b", delete=False,
                                                        suffix=".py")
            self.filename = self.tempfile.name
            self.addCleanup(self.tempfile.close)
            self.addCleanup(os.unlink, self.filename)

        def tearDown(self):
            pass

        def _compat_untokenize(self, expected, bytes):
            with open(self.filename, "wb") as f:
                f.write(bytes)


# Generated at 2022-06-23 15:52:54.344644
# Unit test for function maybe
def test_maybe():
    m = maybe("a", "b", "c")
    assert re.match(m, "abc")
    assert re.match(m, "bc")
    assert re.match(m, "c")
    assert re.match(m, "")
    assert not re.match(m, "d")


# Generated at 2022-06-23 15:52:56.836325
# Unit test for function any
def test_any():
    assert any('a', 'b') == "(a|b)*"


# Generated at 2022-06-23 15:53:07.596188
# Unit test for function tokenize
def test_tokenize():
    s = "def f(x): return '%(x)s'"
    import sys
    from io import StringIO

    def readline():
        return s

    # @todo: fix this

    # from cStringIO import StringIO
    tokeneater = StringIO()

    def printtoken(type, token, start, end, line):
        tokeneater.write(
            "%s\t%s\t%s\n" % (tok_name[type], token, str(start) + "-" + str(end))
        )

    tokenize(readline, printtoken)
    tokeneater.seek(0)

# Generated at 2022-06-23 15:53:11.386259
# Unit test for function any
def test_any():
    for choices in (tuple(), ("foo",), ("foo", "bar", "baz")):
        for s in ["", "foo", "foobar", "barfoo", "foobarbaz"]:
            assert re.match(any(*choices), s).end() == len(s)
test_any()



# Generated at 2022-06-23 15:53:20.150017
# Unit test for function untokenize
def test_untokenize():
    from tokenize import generate_tokens, untokenize, COMMENT, NAME, OP
    from io import StringIO
    hi = "Hi there # hello world"
    f = StringIO(hi)
    t1 = []
    for tok in generate_tokens(f.readline):
        t1.append(tok)
    newcode = untokenize(t1)
    readline = iter(newcode.splitlines(1)).__next__
    t2 = []
    for tok in generate_tokens(readline):
        t2.append(tok)
    assert t1 == t2


# Generated at 2022-06-23 15:53:21.387990
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:53:24.234481
# Unit test for function group
def test_group():
    r = group("+", "-", "==")
    assert re.match(r, "+") and not re.match(r, "x+")
test_group()

# Helper: match a sequence of one or more string literals.

# Generated at 2022-06-23 15:53:30.342438
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for l in TEST_SOURCE.splitlines(True):
            yield l

    # TEST_SOURCE is defined in a separate file to allow its encoding to
    # be changed.
    from .test_tokenize import TEST_SOURCE

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == []
    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == []
    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: iso-8859-1 -*-\n"]
    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"


# Generated at 2022-06-23 15:53:33.203388
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 2, (3, 4), (5, 6), 7)
    # TODO: test printtoken



# Generated at 2022-06-23 15:53:38.990078
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"pass"
        yield b""

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-", b"pass"]

    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# vim:fileencoding=latin-1"
        yield b"pass"
        yield b""

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-23 15:53:47.898843
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import tokenize
    u = Untokenizer()
    test_list = [
        (tokenize.NAME, "spam"),
        (tokenize.NAME, "spam"),
        (tokenize.ERRORTOKEN, "E"),
        (tokenize.OP, "+"),
        (tokenize.NUMBER, "1"),
        (tokenize.NUMBER, "1"),
        (tokenize.NEWLINE, "\n"),
        (tokenize.INDENT, "\t"),
        (tokenize.DEDENT, "\t"),
    ]
    u.compat((tokenize.DEDENT, ""), test_list)
    assert u.tokens == ["spam", "spam", "E", "+", "1", "1", "\n", "\t"]


_tokenize = tokenize  # to save the

# Generated at 2022-06-23 15:53:49.464099
# Unit test for function group
def test_group():
    assert group("x", "y") == "(x|y)"



# Generated at 2022-06-23 15:53:51.549360
# Unit test for function group
def test_group():
    assert group("a", "b", "c", "de") == "(a|b|c|de)"



# Generated at 2022-06-23 15:54:00.761260
# Unit test for function any
def test_any():
    for choices in [
            ("ab", "abc"),
            ("ab", "cab"),
            ("ab", "cccc"),
            ("ab", ""),
            ("", "ab"),
            ("", ""),
    ]:
        rexp = any(*choices)
        found = re.match("^" + rexp + "$", "ab")
        assert found, choices
        found = re.match("^" + rexp + "$", "")
        assert found, choices
    for choices in [
            ("ab", "babc"),
            ("ab", "aabccc"),
            ("ab", "ababab"),
            ("ab", "c"),
            ("", "ab"),
    ]:
        rexp = any(*choices)
        found = re.match("^" + rexp + "$", "ab")


# Generated at 2022-06-23 15:54:10.621440
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from blib2to3.fixer_util import token

    if sys.version_info < (3,):
        def readline() -> Text:
            return ""

        r = u""
    else:
        # Work-around for http://bugs.python.org/issue3905
        # A copy of io.StringIO with an extra flush method.
        class StringIO(io.StringIO):
            def flush(self) -> None: pass

        def readline() -> Text:
            return StringIO(r).readline()

        r = "def f():\n pass\n f()"

    r = [{"u": 1, "x": 2}, {"u": 1, "x": 2}]

# Generated at 2022-06-23 15:54:18.751444
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Exercise the tokenize_loop function when the input is not empty.
    # The tokenize_loop function should raise a StopTokenizing exception
    # in this case.
    import io, unittest
    from .. import pytokenize
    from .token import (
        NAME,
        NUMBER,
        OP,
        STRING,
        NEWLINE,
        INDENT,
        DEDENT,
        ENDMARKER,
    )
    # Test data
    test_input = io.StringIO("blah = 5\nbaz = 6\n")
    test_output = io.StringIO()
    # Expected output

# Generated at 2022-06-23 15:54:24.805984
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    unt = Untokenizer()
    unt.tokens = ["a", "b", "c"]
    unt.prev_row = 2
    unt.prev_col = 4
    unt2 = Untokenizer()
    assert unt2.tokens == []
    assert unt2.prev_row == 1
    assert unt2.prev_col == 0


# Generated at 2022-06-23 15:54:30.660631
# Unit test for function detect_encoding

# Generated at 2022-06-23 15:54:31.619892
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()



# Generated at 2022-06-23 15:54:41.776484
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    readline = io.StringIO("def f(x): return 2*x\n").readline
    l = []
    tokenize_loop(readline, l.append)

# Generated at 2022-06-23 15:54:51.487888
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer = Untokenizer()
    test_tuples = [(tokenize.NUMBER, "3"),
                   (tokenize.OP, "+"),
                   (tokenize.NUMBER, "4"),
                   (tokenize.NEWLINE, "\n")]
    untokenized = untokenizer.untokenize(test_tuples)
    # When there are no indents, and we are testing with the NUMBER,
    # OP and NEWLINE tokens, then we need to ensure that the final
    # output string is a single space.
    assert untokenized == "3 + 4 ", "test failed"


# Generated at 2022-06-23 15:55:02.162418
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    tokens = (
        (NAME, "a"),
        (NEWLINE, "\n"),
        (NAME, "b"),
        (NEWLINE, "\n"),
        (INDENT, "  "),
        (NAME, "c"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (NAME, "d"),
        (ENDMARKER, ""),
    )
    s = Untokenizer().compat(tokens[0], iter(tokens[1:]))
    assert s == "a\nb\n  c\n  d\n", repr(s)


untokenize = Untokenizer().untokenize



# Generated at 2022-06-23 15:55:09.353170
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from .tokenize import untokenize
    from .token import tok_name
    from io import StringIO
    s = StringIO("# this is a comment\npass\n")
    tokgen = generate_tokens(s.readline)
    toklist = list(tokgen)
    assert untokenize(toklist) == "# this is a comment\npass\n"



# Generated at 2022-06-23 15:55:18.843701
# Unit test for function detect_encoding

# Generated at 2022-06-23 15:55:19.309138
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    pass



# Generated at 2022-06-23 15:55:21.857788
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # set up test fixture
    import io
    f = io.StringIO("hello\nworld\n")
    ut = Untokenizer()
    ut.compat((NAME, "hello"), generate_tokens(f.readline))



# Generated at 2022-06-23 15:55:26.149961
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    out = []
    lines = [
        "def f():",
        "   return '",
        "test'",
        ""
    ]
    for line in lines:
        for tok in generate_tokens(iter([line]).__next__):
            out.append(tok)
    res = untok.untokenize(out)
    assert res == "\n".join(lines)



# Generated at 2022-06-23 15:55:30.516402
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    src = ["def f(a):", "  print a", ""]
    expected = "def f(a):\n  print a\n"
    result = Untokenizer().untokenize(
        generate_tokens(iter(src).__next__, False)
    )
    assert result == expected


# Generated at 2022-06-23 15:55:40.399443
# Unit test for function untokenize
def test_untokenize():
    tests = [
        ([(1, "print"), (1, "8"), (2, ","), (1, "4"), (4, None)], "print 8, 4"),
        (
            [
                (1, "print"),
                (1, "8"),
                (51, "\n"),
                (0, ""),
                (1, "print"),
                (1, "4"),
                (4, None),
            ],
            "print 8\nprint 4\n",
        ),
    ]
    ut = Untokenizer()
    for (test, expected) in tests:
        result = ut.untokenize(iter(test))
        print(result, "|", expected)
        assert result == expected, "%r != %r" % (result, expected)



# Generated at 2022-06-23 15:55:47.752823
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.add_whitespace((1, 0))
    u.tokens = []
    u.prev_row = u.prev_col = None
    u.tokens = ["a", "b", "c"]
    u.prev_row = u.prev_col = 6
    assert "".join(u.tokens) == "abc"
    u.add_whitespace((3, 4))
    assert "".join(u.tokens) == "abc  "
    u.add_whitespace((5, 7))
    assert "".join(u.tokens) == "abc     "
    u.add_whitespace((7, 9))
    assert "".join(u.tokens) == "abc        "



# Generated at 2022-06-23 15:55:50.316215
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, 12, (2, 3), (2, 4), "")

# End unit test for function printtoken



# Generated at 2022-06-23 15:55:56.364579
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    s = untok.untokenize(
        [
            (NAME, "f"),
            (OP, "("),
            (NUMBER, "1"),
            (OP, "+"),
            (NUMBER, "2"),
            (OP, ")"),
        ]
    )
    assert s == "f(1 + 2)"



# Generated at 2022-06-23 15:56:08.143364
# Unit test for function generate_tokens
def test_generate_tokens():
    # Tests basic functionality and round-tripping ability.

    s = """'hel"lo'
"""

    g = generate_tokens(StringIO(s).readline)
    # Test that generate_tokens() accepts the readline argument
    assert list(g) == [(
        STRING,
        "'hel\"lo'",
        (1, 0),
        (1, 8),
        "'hel\"lo'\n",
    )]
    # Test round-tripping ability
    t1 = tokenize.generate_tokens(StringIO(s).readline)
    t2 = generate_tokens(StringIO(untokenize(t1)).readline)
    for t in t1:
        assert t == next(t2)

# Generated at 2022-06-23 15:56:15.600618
# Unit test for function untokenize
def test_untokenize():
    string = "\xef\xbb\xbf"
    string += untokenize(
        [
            (NAME, "foo"),
            (STRING, "'bar'"),
            (NAME, "as"),
            (NAME, "baz"),
            (NEWLINE, "\n"),
            (NAME, "bob"),
            (OP, "+"),
            (NAME, "alice"),
            (NEWLINE, "\n"),
            (NAME, "dill"),
            (OP, "+"),
            (STRING, '"pickle"'),
        ]
    )
    assert string == "\xef\xbb\xbffoo = 'bar' as baz\nbob + alice\ndill + 'pickle'\n"



# Generated at 2022-06-23 15:56:27.198808
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    fake = Untokenizer()
    fake.prev_row = 18
    fake.prev_col = 5
    fake.add_whitespace((18, 6))
    assert " " == fake.tokens[-1]
    fake.add_whitespace((18, 7))
    assert "  " == fake.tokens[-1]
    fake.add_whitespace((19, 5))
    assert "\n" == fake.tokens[-1]
    fake.add_whitespace((19, 4))
    assert "\n " == fake.tokens[-1]
    fake.add_whitespace((20, 2))
    assert "\n  \n" == fake.tokens[-1]
    fake.add_whitespace((21, 4))

# Generated at 2022-06-23 15:56:35.156224
# Unit test for function tokenize_loop
def test_tokenize_loop():
    data = "for x in range(10): pass\n"
    tests = [
        ("Number", "1", 0, 1),
        ("Name", "for", 0, 4),
        ("Name", "x", 5, 1),
        ("Name", "in", 7, 2),
        ("Name", "range", 10, 5),
        ("Number", "10", 15, 2),
        ("Name", "pass", 18, 4),
    ]

    stream = iter(data.splitlines(True))

    def readline():
        try:
            return next(stream)
        except StopIteration:
            return ""

    class TokenEater:
        def __init__(self):
            self.results = []


# Generated at 2022-06-23 15:56:36.648308
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:56:41.578505
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "1", (1, 1), (1, 2), "1")
    printtoken(2, "'1'", (1, 1), (1, 3), "'1'")
    printtoken(3, "1.1", (1, 1), (1, 3), "1.1")
# ----- End unit test -----



# Generated at 2022-06-23 15:56:52.613407
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    import unittest
    
    class DummyToken:
        type = 0
        string = ''
        start = (0, 0)
        end = (0, 0)
        line = ''

    class TokenTester(unittest.TestCase):
        def check_equal(self, tokens, exp_tokens, msg=None):
            if isinstance(tokens, str):
                tokens = tokenize.generate_tokens(io.StringIO(tokens).readline)
            for got, want in zip(tokens, exp_tokens):
                self.assertEqual(got, want, msg)

        def read_tokens(self, s):
            tokens = []
            tokeneater = tokens.append

# Generated at 2022-06-23 15:57:04.502193
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("", "a") == "(a)"

# Tail end of 'stringprefix'
# Note: no longer used by tokenizer
_name_re = "[a-zA-Z_]\\w*"
_string_prefix_re = (
    rf"""([bBuU]?(['"]{3}))"""
)

# Note: no longer used by tokenizer, but used for token.MainClass
_string_re = group(rf"""([bBuU]?(['"]))""", rf"""([rR]?(['"]{3}))""")

# Note: no longer used by tokenizer, but used for token.MainClass

# Generated at 2022-06-23 15:57:07.958593
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"
    assert any("") == "()*"
    assert any("a") == "(a)*"



# Generated at 2022-06-23 15:57:09.912619
# Unit test for function group
def test_group():
    for x in ["1", "2", "3", "4", "5"]:
        assert group(*x) == "(" + x + ")"



# Generated at 2022-06-23 15:57:14.344351
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    def f():
        raise StopTokenizing

    try:
        f()
    except StopTokenizing:
        pass
    else:
        raise AssertionError("StopTokenizing not raised")


# These two helper functions non-recursively decompose the right hand
# side of an imaginary production:
#     atom: '(' [yield_expr|testlist_comp] ')'
# into its constituent parts.



# Generated at 2022-06-23 15:57:15.049378
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass



# Generated at 2022-06-23 15:57:20.434310
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    """
    >>> tokenizer = Untokenizer()
    >>> iterable = [(5, '+'), (0, ''), (2, '+'), (0, ''), (5, '-')]
    >>> tokenizer.compat(tokenizer.tokens, iterable).untokenize()
    '+ + - '
    """
    pass



# Generated at 2022-06-23 15:57:22.833397
# Unit test for function any
def test_any():
    assert any("ab", "c") == "(ab|c)*"



# Generated at 2022-06-23 15:57:26.842689
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    te = StopTokenizing("test")
    # Make sure the exception displays properly
    assert str(te) == "test"
    assert repr(te) == "StopTokenizing('test',)"



# Generated at 2022-06-23 15:57:29.321219
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing("testing")
    except StopTokenizing as msg:
        if str(msg) != "testing":
            raise RuntimeError("wrong message")



# Generated at 2022-06-23 15:57:37.367336
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()

# Generated at 2022-06-23 15:57:39.184613
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding=utf-8\r\n"
        yield b"for i in range(5):\r\n"
    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8\r\n"])



# Generated at 2022-06-23 15:57:48.518915
# Unit test for function tokenize
def test_tokenize():
    import unittest

    import io

    class Test(unittest.TestCase):
        def test_tokenize(self):
            text = "".join(
                [
                    # start of a multiline triple quoted string on line 1
                    "'''\n",
                    # a string with a ' in it
                    "'\n",
                    # line continuation
                    "\\\n",
                    "1\n",
                    # end of a triple quoted string on line 4
                    "'''\n",
                    # tab
                    "\t\n",
                    # more tabs
                    "\t\t\t\n",
                    # no newline should result in EOF
                ]
            )

            f = io.StringIO(text)
            tokens = []

            def tokeneater(*args):
                tokens.append(args)



# Generated at 2022-06-23 15:57:50.509579
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:58:00.928512
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO


# Generated at 2022-06-23 15:58:02.997801
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?", maybe("a", "b")
test_maybe()


# Helper for symbols

# Generated at 2022-06-23 15:58:05.391720
# Unit test for constructor of class TokenError
def test_TokenError():
    t = TokenError()
    assert isinstance(t, Exception)
    return t



# Generated at 2022-06-23 15:58:07.362182
# Unit test for function maybe
def test_maybe():
    assert maybe("abc", "def") == "(abc|def)?"



# Generated at 2022-06-23 15:58:11.427697
# Unit test for function untokenize
def test_untokenize():
    input = "def f(x): return 2*x"
    tokens = generate_tokens(iter(input).next)
    output = untokenize(tokens)
    assert input == output


# End unit tests


# Generated at 2022-06-23 15:58:20.560795
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    r = 'def f(x):\n    return x\n'
    pairs = generate_tokens(r.splitlines().__next__)
    list(pairs)  # consume "def"
    pairs = [(NAME, "def", (1, 0), (1, 3), "def f(x):\n")] + list(pairs)
    u.compat((NAME, "def"), pairs)
    import io, tokenize

    f = io.StringIO("".join(u.tokens))
    g = tokenize.generate_tokens(f.readline)
    l = list(g)

# Generated at 2022-06-23 15:58:22.318303
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize
    data = io.StringIO(
        """def f(x):
    return 2*x
a = 1
"""
    )
    tokenize.tokenize(data.readline)

# Generated at 2022-06-23 15:58:32.200465
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    import unittest
    import textwrap
    unittest.TestCase.maxDiff = None  # make assertMultiLineEqual work properly
    # For self.tokens, use '\n' as a stand-in for a newline character
    unt = Untokenizer()
    unt.tokens = textwrap.dedent("""\
        print('Hello')
        print('World')
        """).splitlines(keepends=False)
    unt.prev_row = 1
    unt.prev_col = 6

    unt.add_whitespace((2, 0))
    assert unt.tokens == textwrap.dedent("""\
        print('Hello')
        print('World')
        """).splitlines(keepends=False)
    unt.add_whitespace((2, 2))
    assert unt.t

# Generated at 2022-06-23 15:58:37.691691
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    from io import StringIO
    from tokenize import generate_tokens

    sample_source = "def foo(bar):\n    return bar"
    sample_tokens = generate_tokens(StringIO(sample_source).readline)

    untok = Untokenizer()
    output = untok.untokenize(sample_tokens)
    assert output == sample_source, output



# Generated at 2022-06-23 15:58:49.410541
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.tokens = ["123", "456", "789"]
    ut.prev_row = 2
    ut.prev_col = 3
    res = ut.untokenize([(tokenize.NL, ""), (tokenize.NEWLINE, "\n"),
                         (tokenize.NAME, "spam"), (tokenize.NAME, "eggs")])
    assert res == "123456789 \nspam eggs"


# ----------------------------------------------------------------------
# our own tokenizer for Python

# Note: this code must be kept compatible with Python 2.1.
# That means that it can only use features available in 2.1, with the
# exception of the string methods, which were backported from 2.2.


# Generated at 2022-06-23 15:59:01.261444
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        return '# -*- coding: latin-1 -*-\n'.encode("latin-1")

    assert detect_encoding(readline) == ("iso-8859-1", [])

    def readline():
        yield b'\xef\xbb\xbf# coding: ascii\n'

    assert detect_encoding(readline) == ("utf-8-sig", [])

    def readline():
        yield b' \n'
        yield b'\xef\xbb\xbf# coding: ascii\n'

    assert detect_encoding(readline) == ("utf-8-sig", [b' \n'])

    def readline():
        yield b'# -*- coding: latin-1 -*-\n'
       

# Generated at 2022-06-23 15:59:02.599238
# Unit test for function any
def test_any():
    any("a", "b")



# Generated at 2022-06-23 15:59:05.616705
# Unit test for function any
def test_any():
    assert any("abc") == "(a|b|c)*"
    assert any("a") == "a*"
    assert any("") == "()*"


# Helper for function 'ungroup'

# Generated at 2022-06-23 15:59:16.214891
# Unit test for function maybe
def test_maybe():
    match = re.compile(maybe("a", "b")).fullmatch
    assert match("") != None
    assert match("ab") != None
    assert match("abbbb") != None
    assert match("babbbb") != None
    assert match("aabbbb") != None
    assert match("ba") == None
    assert match("baaa") == None


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"\w+"


# Generated at 2022-06-23 15:59:20.744509
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?"
    assert maybe("ab", "cd") == "(ab|cd)?"
# End unit test for function maybe



# Generated at 2022-06-23 15:59:22.580783
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3", (0, 0), (0, 0), "")

# Generated at 2022-06-23 15:59:34.076693
# Unit test for function printtoken
def test_printtoken():
  tok_name = {1: "NAME"}
  (srow, scol) = (1, 1)
  (erow, ecol) = (1, 2)
  line = "1,1-1,2:\tNAME\t'abc'"
  
  import io
  try:
    f = io.StringIO()
    stored_stdout = sys.stdout
    sys.stdout = f
    
    printtoken(1, 'abc', (1, 1), (1, 2), "1,1-1,2:\tNAME\t'abc'")
    sys.stdout = stored_stdout
    
    assert f.getvalue() == line
  finally:
    f.close()



# Generated at 2022-06-23 15:59:40.621798
# Unit test for function generate_tokens
def test_generate_tokens():
    source = "a=1;b=2;print(a)\n"

# Generated at 2022-06-23 15:59:42.309411
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group([]) == "()"



# Generated at 2022-06-23 15:59:48.048379
# Unit test for function maybe
def test_maybe():
    # Single character
    assert maybe('a') == '(a)?', 'Single character failed'
    # Multiple characters
    assert maybe('ab') == '(ab)?', 'Multiple characters failed'
    # Character class
    assert maybe('[ab]') == '([ab])?', 'Character class failed'



# Generated at 2022-06-23 15:59:55.126955
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.tokens = ["a", "b"]
    ut.prev_row = 2
    ut.prev_col = 8
    assert ut.untokenize([(1, "c", (2, 8), (2, 9), "foo")]) == "abc"
    assert ut.prev_row == 2
    assert ut.prev_col == 9
    assert ut.tokens == ["a", "b", "c"]


# Unit tests for method add_whitespace of class Untokenizer

# Generated at 2022-06-23 15:59:57.745468
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError("testing TokenError is working")


# Helper for tokenize

# Generated at 2022-06-23 16:00:03.969996
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    assert untok.untokenize([]) == ""
    assert untok.untokenize([(NAME, "a", (1, 0), (1, 1), "a"), (NL, "\n", (1, 1), (2, 0), "a\n")]) == "a\n"
    assert untok.untokenize([(NAME, "a", (1, 0), (1, 1), "a"), (NUMBER, "1", (1, 1), (1, 2), "a1")]) == "a 1"

# Generated at 2022-06-23 16:00:16.898512
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline(line):
        while True:
            yield line
            line = b''

    def check(line, encoding):
        assert detect_encoding(readline(line)) == (encoding, [line])

    check(b'\xef\xbb\xbf', 'utf-8-sig')
    check(b'# coding=utf-8', 'utf-8')
    check(b'# -*- coding: utf-8 -*-', 'utf-8')
    check(b'# vim:fileencoding=utf-8', 'utf-8')
    check(b'# coding=latin1', 'iso-8859-1')
    check(b'# coding: latin1', 'iso-8859-1')

# Generated at 2022-06-23 16:00:23.491860
# Unit test for function untokenize
def test_untokenize():
    f = io.StringIO("def f():\n  return\n\n")
    t1 = list(tokenize(f.readline))
    newcode = untokenize(t1)
    readline = iter(newcode.splitlines(1)).__next__
    t2 = list(tokenize(readline))
    assert t1 == t2, "round-trip test failed"



# Generated at 2022-06-23 16:00:32.006456
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import tokenize

    untokenizer = Untokenizer()

    def test(input, expected):
        tokens = list(tokenize(StringIO(input).readline))
        assert untokenizer.untokenize(tokens) == expected

    test("\n", "\n")
    test("print('Hello World!')\n", "print('Hello World!')\n")
    test("if True:\n  print('Hello World!')\n", "if True:\n  print('Hello World!')\n")
    test("if True:\n  print('Hello World!')\n\n", "if True:\n  print('Hello World!')\n\n")

# Generated at 2022-06-23 16:00:39.643836
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize


    text = "class C: pass\n"
    f = io.StringIO(text)
    tokgen = generate_tokens(f.readline)
    u = Untokenizer()
    u.compat(next(tokgen), tokgen)
    assert u.tokens == ["class", " C:", " pass", "\n"]
    assert "".join(u.tokens) == untokenize(iter(tokgen))
test_Untokenizer_compat()

# Generated at 2022-06-23 16:00:41.144120
# Unit test for constructor of class TokenError
def test_TokenError():
    """Raise TokenError() with a simple message."""
    TokenError()



# Generated at 2022-06-23 16:00:45.240465
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.add_whitespace((1,10))
    ut.tokens.append("    ")
    ut.prev_row = 1
    ut.prev_col = 10
    ut.add_whitespace((1,14))
    assert ut.tokens == ["    ", "    "]



# Generated at 2022-06-23 16:00:52.811884
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "if 1:\n  pass\n"
    def readline():
        return s
    res = []
    tokenize_loop(readline, lambda *t: res.append(t))
    assert res == [(1, 'if', (1, 0), (1, 2), 'if 1:\n'), (1, '1', (1, 3), (1, 4), 'if 1:\n'), (53, ':', (1, 4), (1, 5), 'if 1:\n'), (4, 'pass', (2, 2), (2, 6), '  pass\n'), (53, '\n', (2, 6), (2, 7), '  pass\n')]



# Generated at 2022-06-23 16:01:03.036361
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    input = ""
    assert u.untokenize(input) == ""

    u = Untokenizer()
    input = [
        ("\n", (0, 0), (0, 0), (0, 0), "\n"),
        ("\n", (0, 0), (0, 0), (0, 0), "\n"),
        ("\n", (0, 0), (0, 0), (0, 0), "\n"),
        (1, (2, 3), (2, 3), (2, 3), ""),
    ]
    assert u.untokenize(input) == "\n\n\n1"



# Generated at 2022-06-23 16:01:11.541274
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 2
    untok.prev_col = 1
    untok.tokens = [ "a", "b", "c" ]
    untok.add_whitespace( (2, 2) )
    assert untok.tokens == [ "a", "b", "c", " " ]
    untok.add_whitespace( (1, 1) )
    assert untok.tokens == [ "a", "b", "c", " ", "b", "c", " " ]
    untok.add_whitespace( (2, 3) )
    assert untok.tokens == [ "a", "b", "c", " ", "b", "c", " ", "  " ]

# Generated at 2022-06-23 16:01:14.139522
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing as e:
        assert str(e) == "tokenizing stopped"



# Generated at 2022-06-23 16:01:20.932117
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    assert unt.untokenize(
        [
            (NAME, "abc"),
            (NUMBER, "def"),
            (STRING, "ghi"),
            (OP, "jkl"),
            (NEWLINE, "\n"),
            (INDENT, "\t"),
            (DEDENT, ""),
            (ENDMARKER, ""),
        ]
    ) == "abc def ghi jkl\n\t"

