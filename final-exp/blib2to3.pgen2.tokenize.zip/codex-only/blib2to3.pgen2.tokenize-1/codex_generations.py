

# Generated at 2022-06-23 15:51:16.922878
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    from io import StringIO

    s = StringIO()
    pass_  # TODO: write test



# Generated at 2022-06-23 15:51:24.824423
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import sys
    import token
    import unittest

    class TestTokenizeLoop(unittest.TestCase):
        def setUp(self):
            self.token_stream = []
            self.token_info = {}
            self.save_sys_stdout = sys.stdout
            sys.stdout = io.StringIO()

        def tokeneater(self, type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
            (srow, scol) = xxx_todo_changeme2
            (erow, ecol) = xxx_todo_changeme3
            self.token_stream.append((type, token))

# Generated at 2022-06-23 15:51:35.026362
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline(*args, **kwargs):
        yield "for i in range(10):"
        yield "  print(i)"
        yield ""

    result = []

    def tokeneater(type, token, *args):
        result.append((type, token))

    tokenize_loop(readline, tokeneater)

# Generated at 2022-06-23 15:51:38.022355
# Unit test for function generate_tokens
def test_generate_tokens():
    for t in generate_tokens(iter(['spam\n']).__next__):
        print(t)

test_generate_tokens()
from io import StringIO
from tokenize import generate_tokens

from typing import Generator, Union, List
from pydocstyle import StringIO
 
from openmdao.utils.file_utils import read_file


# Generated at 2022-06-23 15:51:40.554389
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    """Unit test to ensure that StopTokenizing can be constructed.

    This catches the bug where __init__ didn't exist in the base class.
    """
    StopTokenizing()



# Generated at 2022-06-23 15:51:43.384223
# Unit test for function group
def test_group():
    grouptest(r'a', 'a')
    grouptest(r'a|b', 'a', 'b')


# Generated at 2022-06-23 15:51:54.024280
# Unit test for function tokenize
def test_tokenize():
    import io
    import token

    result = [
        (token.NUMBER, "0", (1, 0), (1, 1), ("0",)),
        (token.NEWLINE, "\n", (1, 1), (2, 0), ("\n",)),
    ]
    s = io.StringIO("0\n")
    tokeneater = lambda type, token, start, end, line: result.append(
        (type, token, start, end, line)
    )
    # XXX(nnorwitz): should tokenize_loop call tokeneater?
    # I guess not, too many changes to the tests.
    tokenize(s.readline, tokeneater)

# Generated at 2022-06-23 15:51:55.553669
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError as exc:
        pass



# Generated at 2022-06-23 15:52:00.639484
# Unit test for function tokenize_loop
def test_tokenize_loop():
    data = "def f():\n    0"
    f = StringIOWrapper(data)  # wrap the string as a file
    tokenize_loop(f.readline, printtoken)


CommentJunk = re.compile(r"#.*$", re.MULTILINE)



# Generated at 2022-06-23 15:52:11.671689
# Unit test for function untokenize
def test_untokenize():
    import io
    from tokenize import generate_tokens
    from tokenize import NUMBER, STRING, NAME
    from tokenize import tok_name, untokenize
    r = io.BytesIO(b'a = 1 + 1\nprint "a is", a, "."\n')
    alltokens = generate_tokens(r.readline)
    it = iter(alltokens)
    for t in it:
        if t[0] == NUMBER:
            t = (NAME, 'i', t[2], t[3], t[4])
        elif t[0] == STRING:
            t = (t[0], t[1], t[2], t[3], '"xyzzy"')
        print(t)
    
    print('=====')

# Generated at 2022-06-23 15:52:13.995398
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, '0o160', (0, 0), (0, 4), '0o160')



# Generated at 2022-06-23 15:52:22.787300
# Unit test for function maybe
def test_maybe():
    assert re.match(maybe("elvis", "lives"), "elvis")
    assert re.match(maybe("elvis", "lives"), "lives")
    assert re.match(maybe("elvis", "lives"), "liveselvis")
    assert re.match(maybe("elvis", "lives"), "")


WHITESPACE = r"[ \f\t]*"
COMMENT = r"#[^\r\n]*"
SKIPPABLE = WHITESPACE + any(r"\\\r?\n" + WHITESPACE, COMMENT)

NAME = r"[a-zA-Z_]\w*"


# Generated at 2022-06-23 15:52:28.637719
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.prev_row = 10
    u.prev_col = 5
    u.add_whitespace((10, 0))
    assert u.tokens == ["     "]
    u.tokens = []
    u.add_whitespace((11, 0))
    assert u.tokens == ["\n", "     "]
    u.tokens = []
    u.add_whitespace((10, 9))
    assert u.tokens == ["     "]



# Generated at 2022-06-23 15:52:33.071801
# Unit test for function untokenize
def test_untokenize():
    import token
    import tokenize
    import io
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO
    r = StringIO("def f(x): return x+1\n")
    result = tokenize.generate_tokens(r.readline)
    text = untokenize(result)
    r1 = StringIO(text)
    result1 = tokenize.generate_tokens(r1.readline)
    for t in result1:
        assert t[:2] == next(result)[:2]



# Generated at 2022-06-23 15:52:35.482518
# Unit test for function tokenize
def test_tokenize():
    import io
    print(tokenize(io.StringIO("1 + 1").readline))



# Generated at 2022-06-23 15:52:46.115329
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    from blib2to3.pgen2.tokenize import generate_tokens, INDENT, DEDENT, NEWLINE, NL

    def convert_to_token_info(
        x: Union[Tuple[int, str, int, int], Tuple[int, Text, Coord, Coord, Text]]
    ) -> TokenInfo:
        # python2 - python3.5
        if len(x) == 4:
            return x[:2]
        else:
            # python3.6+
            return x

    # Test with a program of indented code.
    f = io.StringIO("if True:\n    print('hello')")
    tokens = [convert_to_token_info(x) for x in generate_tokens(f.readline)]
    untokenizer = Untokenizer()

# Generated at 2022-06-23 15:52:47.551735
# Unit test for constructor of class TokenError
def test_TokenError():
    e = TokenError()
    if e.args != ():
        print("TokenError should require no arguments")



# Generated at 2022-06-23 15:52:50.465165
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    src = "for i in range(10)"
    result = Untokenizer().untokenize(tokenize(src))
    assert (result == src)
    print("OK")


# Generated at 2022-06-23 15:52:59.168780
# Unit test for function generate_tokens
def test_generate_tokens():
    import io

    def _test(testcase):
        tokens = list(generate_tokens(io.StringIO(testcase).readline))
        got = [(tok[0], str(tok[1])) for tok in tokens]
        expected = [
            (tokenize.NAME, "a"),
            (tokenize.NEWLINE, "\n"),
            (tokenize.INDENT, ""),
            (tokenize.NAME, "b"),
            (tokenize.DEDENT, ""),
        ]
        assert got == expected, f"got {got}, expected {expected}"

    _test("a\n  b")
    _test("a\n \t  b")
    _test("a\n\t\t  b")
    _test("a\n  \t\t  b")
   

# Generated at 2022-06-23 15:53:00.910517
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    assert isinstance(StopTokenizing(), StopTokenizing)
    assert isinstance(StopTokenizing(1, b"foo"), StopTokenizing)



# Generated at 2022-06-23 15:53:12.193163
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output, roundtrip=True):
        toks = generate_tokens(iter(input.splitlines(True)).__next__)
        result = untokenize(toks)
        if roundtrip:
            source = result[:]
            toks = generate_tokens(iter(source.splitlines(True)).__next__)
            result2 = untokenize(toks)
            assert result == result2, "\n" + result + "\n!=\n" + result2
        assert result == output, "\n" + result + "\n!=\n" + output

    compare("def f():\n    return\n\n", "def f():\n    return\n\n")

# Generated at 2022-06-23 15:53:21.301626
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    tokens = ["abc", "(", "1", ",", "2", ")", "\\\n", "3"]

    for t in tokens:
        if t == "\\\n":
            token_info = (token.NL, "\n", (1, 0), (1, 0), "\n")
        else:
            token_info = (token.NAME, t, (1, 0), (1, 0), "\n")
        unt.add_whitespace(token_info[2])
        unt.tokens.append(token_info[1])

    assert unt.untokenize(tokens) == "abc ( 1 , 2 ) 3"



# Generated at 2022-06-23 15:53:34.321302
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    def test(input, expect):
        assert expect == u.untokenize(input)
        u.tokens.clear()
    test([("NUMBER", "1"), ("NAME", "x"), ("NEWLINE", "")], "1 x ")
    test(
        [("NUMBER", "1"), ("NAME", "x"), ("INDENT", "  "), ("NAME", "y"), ("NEWLINE", "")],
        "1 x  y ",
    )
    test(
        [("NUMBER", "1"), ("NAME", "x"), ("INDENT", "  "), ("NAME", "y"), ("NEWLINE", "")],
        "1 x  y ",
    )

# Generated at 2022-06-23 15:53:42.103391
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from . import untokenize

    for input, output in (
        """if 1:
    pass
""",
        """if 1:
    pass
""",
        """if 1:
if 2:
    pass
""",
        """if 1:
    if 2:
        pass
""",
    ):
        output = output.replace(" ", "")
        assert untokenize.Untokenizer().compat(
            [tokenize.NEWLINE, "\n"], generate_tokens(iter(input.splitlines(True)))
        ) == output



# Generated at 2022-06-23 15:53:49.929933
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import io
    import tokenize
    from tokenize import generate_tokens
    readline = io.BytesIO(b"def foo(a, b):\n    print(a, b)\n").readline
    tokens = generate_tokens(readline)

# Generated at 2022-06-23 15:53:51.993302
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    # Test for initialisation
    u = Untokenizer()
    assert u is not None



# Generated at 2022-06-23 15:53:53.995084
# Unit test for function group
def test_group():
    assert group("ab", "cd") == "(ab|cd)"



# Generated at 2022-06-23 15:54:04.804307
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    from . import tokenize

    def detoken(text: Text, dec: int = 0) -> Text:
        f = io.StringIO(text)
        f.mode = "U"
        u = Untokenizer()
        tokenize.tokenize(f.readline, u.compat)

        return "".join(u.tokens[dec:])

    s = '''def f(a):
    return a + 1

f(1)'''

    assert detoken(s) == s
    assert detoken(s, -1) == s[:-1]
    assert detoken(s, 1) == s[1:]
    #raise RuntimeError, "untokenize is not yet supported"



# Generated at 2022-06-23 15:54:14.165321
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    ut = Untokenizer()
    ut.add_whitespace((1, 0))
    ut.tokens.append("xyz")
    ut.prev_row = 0
    assert ut.tokens == ["xyz"]
    ut.add_whitespace((0, 0))
    assert ut.tokens == ["xyz"]
    ut.add_whitespace((0, 1))
    assert ut.tokens == ["xyz ", "xyz"]
    ut.prev_col = 1
    ut.add_whitespace((0, 2))
    assert ut.tokens == ["xyz ", "xyz"]
    ut.prev_row = 1
    ut.prev_col = 1
    ut.add_whitespace((2, 1))

# Generated at 2022-06-23 15:54:22.695857
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import tokenize
    u = Untokenizer()
    iterable = tokenize.generate_tokens(iter(['1 + 1']).__next__)
    res = u.compat((NUMBER, '1'), iterable)
    assert res is None
    assert u.tokens == ['1 ']
    assert list(iterable) == [
        (PLUS, '+'), (NUMBER, '1'), (ENDMARKER, '')]



# Generated at 2022-06-23 15:54:34.000625
# Unit test for function tokenize
def test_tokenize():
    from blib2to3.tests.support import (
        check_token_sum_inc, check_token_sum_exc, check_token_sum_pos,
        type_convert_token,
    )

    # This uses an alternate tokenize_loop to check results without
    # printing tokens.
    def alternate_tokenize(readline, tokeneater):
        for token in generate_tokens(readline):
            tokeneater(*token)

    import sys
    import io
    import tempfile

    # Test the algorithm for determining whether a name is in the
    # keyword dictionary.

# Generated at 2022-06-23 15:54:39.594612
# Unit test for function printtoken
def test_printtoken():
    printtoken(
        4,
        "abcd",
        (1, 2),
        (2, 3),
        "a\nb\nc\nd",
    )
    # Even if the source code is invalid, printtoken should not crash.
    printtoken(
        4,
        "abcd",
        (1, 2),
        (2, 3),
        None,
    )

ENCODING = "utf-8"



# Generated at 2022-06-23 15:54:41.425848
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass


# Generated at 2022-06-23 15:54:47.007787
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize

    def g():
        yield from b'\x8b\x01\x8b\x03def g():\n\tpass\n'

    it = tokenize.generate_tokens(g().__next__)
    tokens = list(it)
    assert tokens[0] == (tokenize.NAME, 'def', (1, 0), (1, 3), 'def g():\n')

test_generate_tokens()


# Generated at 2022-06-23 15:54:48.310790
# Unit test for function maybe
def test_maybe():
    assert maybe(r"\d") == r"(\d)?"



# Generated at 2022-06-23 15:55:00.756742
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import StringIO

    def readline_1() -> bytes:
        yield BOM_UTF8 + b'# -*- coding: latin-1 -*-\n' + b'Rest'
        yield b'Rest'
        yield b'Rest'
        yield b''

    def readline_2() -> bytes:
        yield b'# -*- coding: latin-1 -*-\nRest'
        yield b''

    def readline_3() -> bytes:
        yield b'\nRest'
        yield b''

    for readline in (readline_1(), readline_2(), readline_3()):
        assert detect_encoding(iter(readline)) == ("iso-8859-1", [])

# Generated at 2022-06-23 15:55:08.643620
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return 'if 1:\n print(2)\n'
    tokeneater = []
    def tokeneater_append(type, token, start, end, line):
        tokeneater.append((type, token, start, end, line))
    tokenize_loop(readline, tokeneater_append)
    return tokeneater
# END Unit test for function tokenize_loop

# Backwards compatible interface

# Generated at 2022-06-23 15:55:18.138103
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"#python3.3"
        yield b"#python2.7"
        yield b"#\u3042"
    expected = "utf-8", [b"#python3.3", b"#python2.7", b"#\u3042"]
    assert detect_encoding(readline) == expected

    def readline():
        yield b"# -*- coding: iso-8859-1 -*-"
        yield b"# -*- coding: ascii -*-"
        yield b"#"
    expected = "iso-8859-1", [b"# -*- coding: iso-8859-1 -*-", b"# -*- coding: ascii -*-", b"#"]
    assert detect_encoding(readline) == expected



# Generated at 2022-06-23 15:55:20.531451
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("Bad token", (1, 5), (2, 3))
    except TokenError as e:
        assert e.args == ("Bad token", (1, 5), (2, 3))



# Generated at 2022-06-23 15:55:21.210269
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    StopTokenizing()



# Generated at 2022-06-23 15:55:32.142892
# Unit test for function tokenize
def test_tokenize():
    import copy
    import pprint

    def _tokenize(to_tokenize, flags=0):
        # Runs tokenize() on the given string and returns the generated
        # tokens as a list.
        readline = iter(to_tokenize.splitlines(True)).__next__
        tokens = []
        tokeneater = tokens.append
        tokenize(readline, tokeneater)
        return tokens

    def test_opmap():
        # Verify that all operators have a token.
        from . import operator
        from .token import _compile_opmap
        from .tokenize import opmap
        from . import token

        _compile_opmap()

# Generated at 2022-06-23 15:55:41.061649
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    l = [((10, 'i'), (20, 0), (20, 0), (20, 0), "\n"), ((11, '%'), (20, 0), (20, 0), (20, 0), "\n"), ((4, 'hello'), (3, 0), (3, 5), (3, 5), 'hello\n'), ((1, '\n'), (4, 0), (4, 0), (4, 0), '')]

    output_string = untok.untokenize(l)
    print (output_string)

test_Untokenizer_untokenize()


# Generated at 2022-06-23 15:55:44.207853
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass


# Map filename extensions to tokenizer formats.
_default_format = "blib2to3.pgen2.tokenize:TokenInfo"


encoding_mode = "ignore"

# Test cases

# Generated at 2022-06-23 15:55:45.255543
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:55:58.173784
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

    class Stream:
        def __init__(self, text):
            self.text = text
            self.pos = 0

        def readline(self):
            if self.pos >= len(self.text):
                return ""
            newline = self.text.find("\n", self.pos)
            if newline == -1:
                newline = len(self.text)
            line = self.text[self.pos : newline]
            self.pos = newline + 1
            return line

    for i in range(1, 31):
        for j in range(1, 31):
            unittest_sample = " " * i + "\n" * j + "\t\na = 1\n"
            f = StringIO(unittest_sample)

# Generated at 2022-06-23 15:56:02.176939
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"
    assert group("a|b", "c") == "(a|b|c)"
    assert group("a|b", "c|d") == "(a|b|c|d)"



# Generated at 2022-06-23 15:56:03.346073
# Unit test for function generate_tokens

# Generated at 2022-06-23 15:56:12.756897
# Unit test for function untokenize
def test_untokenize():
    def compare(s):
        t1 = [tok[:2] for tok in generate_tokens(s.splitlines(1).next)]
        newcode = untokenize(t1)
        readline = iter(newcode.splitlines(1)).next
        t2 = [tok[:2] for tok in generate_tokens(readline)]
        assert t1 == t2
    compare("def f():\n  pass\n")
    compare("def f(x, y):\n  return x+y\n")
    compare("def f(x, y):\n  x+=y\n  return x\n")
    compare("def f(((a,b),c),d): return a,b,c,d\n")

# Generated at 2022-06-23 15:56:14.902839
# Unit test for function group
def test_group():
    assert group("ab", "c") == "(ab|c)"
    assert group("a(b|c)*d") == "a(b|c)*d"



# Generated at 2022-06-23 15:56:21.111623
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    from token import tokenize, untokenize, NUMBER, STRING, NAME, OP
    from token import COMMENT, NL, ENDMARKER

    def check(input, roundtrip_cases, tokeneater=None):
        stream = StringIO(input)
        tokens1 = generate_tokens(stream.readline)
        if tokeneater:
            for token in tokens1:
                tokeneater(*token)
        stream.seek(0)
        tokens2 = list(tokenize(stream.readline))
        stream.close()
        # Remove the line number:
        tokens1 = [(token[0], token[1]) for token in tokens1]
        # Compare the two token lists
        if tokens1 != tokens2:
            raise RuntimeError("token lists differ")

# Generated at 2022-06-23 15:56:26.429070
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing(b"before", b"after")
    except StopTokenizing as e:
        assert e.args == (b"before", b"after")
    else:
        assert 0, "StopTokenizing constructor failed"



# Generated at 2022-06-23 15:56:32.463761
# Unit test for function any
def test_any():
    assert any("a", "b", "c") == "(a|b|c)*"
    assert re.match(any("a", "b", "c"), "bbb") is not None
    assert re.match(any("a", "b", "c"), "d") is None



# Generated at 2022-06-23 15:56:36.904307
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 2, (3, 4), (5, 6), 7)
    expected = "3,4-5,6:\tNAME\t2"
    actual = sys.stdout.getvalue().strip()
    assert actual == expected, 'Expected "%s", got "%s"' % (expected, actual)


# backwards compatible interface (see issue 16669)

# Generated at 2022-06-23 15:56:39.952474
# Unit test for function any
def test_any():
    assert any("abc") == "(a|b|c)*"
    assert any("a", "b") == "(a|b)*"
    assert any("a", "bb") == "(a|bb)*"



# Generated at 2022-06-23 15:56:41.923116
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    global StopTokenizing

    class StopTokenizing(Exception):
        pass



# Generated at 2022-06-23 15:56:44.148507
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    import sys
    import token
    import tokenize

# Generated at 2022-06-23 15:56:54.620811
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    n_line = 0

# Generated at 2022-06-23 15:57:00.491781
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    start = (1, 3)
    ut = Untokenizer()
    ut.add_whitespace(start)
    assert ut.tokens == ["   "]
    assert ut.prev_row == 1
    assert ut.prev_col == 3


_COMPAT53 = [x for x in NAME_TOKENS if x[1] != "async"] + [
    (token.ASYNC, "async"),
    (token.AWAIT, "await"),
]
NAME_TOKENS = tuple(_COMPAT53)
del _COMPAT53



# Generated at 2022-06-23 15:57:09.517766
# Unit test for function group
def test_group():
    # group() is useful for making alternations in regular expressions.
    # Simple cases
    assert group("") == "()"
    assert group("a") == "(a)"
    assert group("ab") == "(ab)"
    # Non-trivial excamples
    assert group("a", "b") == "(a|b)"
    assert group("ab", "cd") == "(ab|cd)"
    assert group("abc", "def") == "(abc|def)"
    assert group("a", "b", "c") == "(a|b|c)"
    assert group("abc", "def", "ghi") == "(abc|def|ghi)"
    assert group("abcd", "defghi", "jkl") == "(abcd|defghi|jkl)"
    T = "Halloween is Oct 31st"

# Generated at 2022-06-23 15:57:17.483673
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    unt = Untokenizer()
    unt.compat((token.NAME, "foo"), [
        (token.NAME, "bar"),
    ])
    assert unt.tokens == ["foo ", "bar "]
    unt.tokens = []
    unt.compat((token.NAME, "foo"), [
        (token.INDENT, " "),
        (token.NAME, "bar"),
    ])
    assert unt.tokens == ["foo ", " bar "]
    unt.tokens = []
    unt.compat((token.NAME, "foo"), [
        (token.INDENT, " "),
        (token.NAME, "bar"),
        (token.DEDENT, ""),
    ])
    assert unt.tokens == ["foo ", " bar"]
    unt.tokens = []


# Generated at 2022-06-23 15:57:22.839556
# Unit test for function printtoken
def test_printtoken():
    """ This is a simple unit test for function printtoken.  It verifies
        that the function is callable, and returns None."""
    result = printtoken(0, "", (0, 0), (0, 0), "")
    assert result is None, "printtoken() should return None, returned '%s'" % result

# End unit test for printtoken



# Generated at 2022-06-23 15:57:33.721531
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import token
    from typing import List

    # Untokenize some simple tokens
    ut = Untokenizer()
    input_tokens: List[Tuple[int, str]] = [
        (token.STRING, '"""'),
        (token.INDENT, "  "),
        (token.STRING, 'a'),
        (token.STRING, '"""'),
        (token.DEDENT, ""),
    ]
    result = ut.untokenize(iter(input_tokens))
    expected = '"""\n  a\n"""'
    assert result == expected

    # Untokenize a token sequence produced by tokenize()
    ut = Untokenizer()

# Generated at 2022-06-23 15:57:35.629852
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:57:45.388711
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.INDENT, "INDENT", (1, 2), (1, 2), "illegal token")

# Note regarding future changes to tokenize.py:
#
# At some future point in time it might be nice to recode the tokenize()
# function using a generator approach instead of the current approach of using
# a callback function.  Such an approach would make it very easy to create new
# kinds of tokenizers.  The implementation would look something like this:
#
# import tokenize, token
#
# # The 'tokeneater' argument to this function is called with four arguments:
# # 1. the token type
# # 2. the token string
# # 3. a tuple (srow, scol) of ints specifying the row and column where the
# #    token begins in the source
# # 4. a tuple (erow

# Generated at 2022-06-23 15:57:49.613399
# Unit test for function maybe
def test_maybe():
    e = r'a(?:b|c)?'
    assert maybe(r'ab', r'ac') == e
    assert maybe(r'a(?:b|c)') == e
    assert maybe('a', 'b') == group('a', 'b') + "?"
    assert maybe(r'a(?:b', r'c)') == e


# Generated at 2022-06-23 15:57:53.868930
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    assert untok.tokens == []
    assert untok.prev_row == 1
    assert untok.prev_col == 0



# Generated at 2022-06-23 15:58:03.504629
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    assert u.tokens == []

    u.add_whitespace((1, 1))
    assert u.tokens == [" "]

    u.add_whitespace((1, 1))
    assert u.tokens == [" ", " "]

    u.add_whitespace((2, 1))
    assert u.tokens == [" ", " ", "\n"]


untokenize = Untokenizer().untokenize


# Generated at 2022-06-23 15:58:05.650935
# Unit test for function maybe
def test_maybe():
    assert maybe("abc", "def") == "(abc|def)?", maybe("abc", "def")



# Generated at 2022-06-23 15:58:09.014080
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    else:
        raise RuntimeError("Failed to raise StopTokenizing")



# Generated at 2022-06-23 15:58:15.366974
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from .tokenize import untokenize, NUMBER, STRING
    t = Untokenizer()
    stream = [(NUMBER, "1"), (NUMBER, "23"), (STRING, '"spam"'), (NUMBER, "42"), (STRING, '"eggs"')]
    result = t.untokenize(stream)
    expected = "123 'spam' 42 'eggs'"
    assert result == expected



# Generated at 2022-06-23 15:58:21.441490
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    s = "def f(x): return 2*x\n"
    f = StringIO(s)
    l = []
    tokenize_loop(f.readline, l.append)
    for t in l:
        if t[0] == token.NAME and t[1] == "f":
            break
    else:
        print("Name token not found")
    if l[2][0] == token.OP and l[2][1] == "(":
        print("success")



# Generated at 2022-06-23 15:58:23.086797
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
        raise Exception()
    except TokenError:
        pass



# Generated at 2022-06-23 15:58:31.860891
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_col = 5
    ut.add_whitespace((1,0))
    assert ut.tokens == ["     "]
    ut.prev_col = 10
    ut.add_whitespace((1,0))
    assert ut.tokens == ["     ","          "]
    ut.prev_col = 10
    ut.add_whitespace((1,55))
    assert ut.tokens == ["     ","          ","                                       "]
    ut.add_whitespace((2,3))
    assert ut.tokens == ["     ","          ","                                       ", "\n   "]
    

# Generated at 2022-06-23 15:58:33.682617
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"


# Generated at 2022-06-23 15:58:35.015826
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

# Generated at 2022-06-23 15:58:38.924233
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    def readline():
        return io.BytesIO(b'if 1:\n  print(5)\n').readline()

    def tokeneater(*args):
        print(args)

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-23 15:58:43.382115
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    s = StringIO("print(1, # Comment\n2)")
    l = []
    tokenize_loop(s.readline, l.append)
    assert len(l) == 6  # 5 tokens, plus ENCODING
    assert l[0] == (ENCODING, None, (1, 0), (1, 0), b"\xef\xbb\xbf")



# Generated at 2022-06-23 15:58:45.036182
# Unit test for function group
def test_group():
    assert group("a") == "(a)"
    assert group("a", "b") == "(a|b)"
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-23 15:58:53.795816
# Unit test for function generate_tokens
def test_generate_tokens():
    from pprint import pprint

    def tokenize(code: str) -> Iterator[TokenInfo]:
        return generate_tokens(code.splitlines().__iter__().__next__)

    pprint(list(tokenize("abc")))

    pprint(list(tokenize("abc\ndef.")))

    pprint(list(tokenize("    if True:\n        pass")))

    pprint(list(tokenize("(a+b) * (c+d)")))

    pprint(list(tokenize("# comment")))

    pprint(
        list(
            tokenize(
                """
        # comment

        'single-quoted string'
        """
            )
        )
    )



# Generated at 2022-06-23 15:58:59.860241
# Unit test for function tokenize_loop
def test_tokenize_loop():
    lines = ["1 + 2\n", "3 + 4\n"]
    def readline():
        return lines.pop(0)
    tokens = []
    tokenize_loop(readline, tokens.append)

# Generated at 2022-06-23 15:59:04.510194
# Unit test for function generate_tokens
def test_generate_tokens():
    input_txt = textwrap.dedent(
        """\
        # This is a comment.
        # It is not considered a docstring.
        """
    )

    # Test normal operation
    tokens = list(tokenize.generate_tokens(io.StringIO(input_txt).readline))
    assert len(tokens) == 4
    assert tokens[0] == (
        tokenize.COMMENT,
        "# This is a comment.",
        (1, 0),
        (1, 21),
        input_txt,
    )
    assert tokens[1] == (
        tokenize.NEWLINE,
        "\n",
        (1, 21),
        (1, 22),
        input_txt,
    )

# Generated at 2022-06-23 15:59:11.053269
# Unit test for function maybe
def test_maybe():
    assert maybe("[a-z]", "[0-9]") == "([a-z]|[0-9])?"
    assert maybe("foo") == "foo?"

# _expression expects at least one non-empty alternative; the
# last alternative *may* be empty, but only if it starts with
# a '|' or the very last alternative, and even then it's bad
# style to do that.



# Generated at 2022-06-23 15:59:18.799364
# Unit test for function maybe
def test_maybe():
    for x in ['', 'a', 'ab', 'abc']:
        for y in ['', 'a', 'ab', 'abc', 'abcd']:
            for z in ['', 'a', 'ab', 'abc']:
                assert len(maybe(x, y, z).split(x) or ['']) in (1, 2)
                assert len(maybe(x, y, z).split(y) or ['']) in (1, 2)
                assert len(maybe(x, y, z).split(z) or ['']) in (1, 2)


# Generated at 2022-06-23 15:59:24.300291
# Unit test for function untokenize
def test_untokenize():
    import io


# Generated at 2022-06-23 15:59:31.322408
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        for line in ("print 4", "print 'hello'"):
            yield line
    tokeneater = []
    tokenize_loop(readline(), tokeneater.append)
    assert (
        tokeneater
        == [(1, "print", (0, 0), (0, 5), "print 4"), (1, "4", (0, 6), (0, 7), "print 4")]
    )



# Generated at 2022-06-23 15:59:43.002914
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module
    from io import BytesIO

    def _tokenize_loop_tester(s, expected):
        f = BytesIO(s.encode("utf-8"))
        tokenize_module.tokenize_loop(f.readline, _tokenize_loop_tester.tokeneater)
        _tokenize_loop_tester.tokens == expected

    _tokenize_loop_tester.tokens = []
    _tokenize_loop_tester.tokeneater = lambda type, token, start, end, line: _tokenize_loop_tester.tokens.append((type, token))
    test_tokenize_loop.msg = "tokenize_loop() chops newlines"

# Generated at 2022-06-23 15:59:51.387957
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_row = 2
    ut.prev_col = 3
    ut.add_whitespace((2, 6))
    assert "".join(ut.tokens) == "   "
    ut.add_whitespace((3, 6))
    assert "".join(ut.tokens) == "   \n   "
    ut.add_whitespace((4, 6))
    assert "".join(ut.tokens) == "   \n   \n   "



# Generated at 2022-06-23 15:59:59.627063
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name

    def _format(tok):
        if tok[0] == tok_name["ENCODING"]:
            return "ENCODING   = %-17r" % (tok[1])
        if tok[0] in tok_name:
            return "%s        = %r" % (
                tok_name[tok[0]],
                tok[1],
            )
        elif tok[0] == ERRORTOKEN:
            return "%-15r %r" % tok[:2]
        else:
            return "%r" % (tok[1],)


# Generated at 2022-06-23 16:00:02.408472
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("Test.")
    except TokenError as e:
        if str(e) != "Test.":
            raise RuntimeError("Unexpected error message.")



# Generated at 2022-06-23 16:00:15.973791
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline(data):
        for line in data:
            yield line.encode("ascii")

    def helper(data, expected, bom = None):
        if bom:
            data[:0] = [bom]
        result, lines = detect_encoding(readline(data))
        assert result == expected, repr((result, expected))
        assert lines == [line.encode("ascii") for line in data]

    # Encoding declared and no BOM
    helper(["# coding: utf-8"], "utf-8")
    helper(["# coding=utf-8"], "utf-8")
    helper(["# coding=utf8"], "utf-8")
    helper(["# coding=utf_8"], "utf-8")

# Generated at 2022-06-23 16:00:27.183709
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    from collections import namedtuple
    from difflib import unified_diff
    from io import StringIO
    from os.path import splitext
    from textwrap import dedent

    def test_generate_tokens(test_case, tok):
        u = Untokenizer()
        for tp in tok:
            u.add_whitespace(tp[2])
            u.tokens.append(tp[1])
        expect = dedent(test_case).rstrip()
        got = "".join(u.tokens)
        if expect != got:
            diff = "\n".join(
                unified_diff(
                    expect.splitlines(keepends=True), got.splitlines(keepends=True)
                )
            )
            print("=" * 50, file=sys.stderr)

# Generated at 2022-06-23 16:00:34.246377
# Unit test for function group
def test_group():
    """Verify that (a|b|c) matches 'a' or 'b' or 'c', but not 'd'."""
    assert group("a", "b", "c", "d") == "(a|b|c|d)"
    pat = re.compile(group("a", "b", "c"))
    assert pat.match("a") and pat.match("b") and pat.match("c") and not pat.match("d")



# Generated at 2022-06-23 16:00:46.720201
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import re
    import tokenize
    from tokenize import NUMBER, NAME, NEWLINE

    def emits_nothing(func, *args):
        save_toks = tokenize._untokenize
        tokenize._untokenize = None
        try:
            stream = io.StringIO()
            func(stream, *args)
            stream.seek(0)
            return stream.read()
        finally:
            tokenize._untokenize = save_toks

    def check_tokenize(input, expected):
        stream = io.StringIO(input)
        tokens = list(tokenize.generate_tokens(stream.readline))
        got = tokenize.untokenize(tokens)
        if expected != got:
            print("Input is:")
            print("----------")

# Generated at 2022-06-23 16:00:51.217511
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    text = "a < b or > c"
    ut = Untokenizer()
    ut.compat(tuple(tokenize(iter([text]).__next__).__next__()),
              list(tokenize(iter([text]).__next__)))
    assert "".join(ut.tokens) == text


# Generated at 2022-06-23 16:00:55.639416
# Unit test for function tokenize
def test_tokenize():
    import io

    s = io.StringIO(
        """def f(x):
    return 2*x
"""
    )
    tokenize(s.readline, printtoken)



# Generated at 2022-06-23 16:00:59.191698
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("a", "b") == "(a|b)*"
    assert any("abc123") == "([a-c]|[1-3])*"



# Generated at 2022-06-23 16:00:59.907206
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    pass



# Generated at 2022-06-23 16:01:10.145278
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    # Test Grams are not implemented in .pyi, so we can't import them from
    # ast.
    from typing import Any

    from srouce_tokenize import untokenize

    test_grammar = source_tokenize.Grammar(version=sys.version_info)

    def _make_case(name: str, src: Text, tgt: List[Any]) -> Tuple[Text, List[Any]]:
        comment = "# " + name + ": "
        code = "\n".join((comment + line) if line else line for line in src.splitlines())
        return code, tgt


# Generated at 2022-06-23 16:01:21.573282
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output):
        result = untokenize(input)
        assert result == output, "Results do not match"

    # Test round-trip invariant
    import io, tokenize
    f = io.StringIO("# coding: latin-1\nspam(eggs)\n")
    toks = tokenize.generate_tokens(f.readline)
    compare(toks, "# coding: latin-1\nspam(eggs)\n")

    # Test token types
    def tokens():
        for toknum, tokval, _, _, _ in generate_tokens(f.readline):
            yield toknum, tokval
    f = io.StringIO("def f(((x))): return '%s' % x\n")