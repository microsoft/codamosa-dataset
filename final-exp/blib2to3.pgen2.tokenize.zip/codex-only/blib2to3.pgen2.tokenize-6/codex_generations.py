

# Generated at 2022-06-23 15:51:16.216092
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("Testing")
    except TokenError:
        pass



# Generated at 2022-06-23 15:51:18.447730
# Unit test for function any
def test_any():
    assert group("a") == "a"
    assert any("ab") == "(a|b)*"



# Generated at 2022-06-23 15:51:22.145533
# Unit test for function any
def test_any():
    assert any('a', 'b') == '(a|b)*'
    return



# Generated at 2022-06-23 15:51:24.363750
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    assert u.prev_row == 1
    assert u.prev_col == 0


# Generated at 2022-06-23 15:51:33.013350
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    l = [
        (token.NAME, "a", (1, 0), (1, 0), "a"),
        (token.NEWLINE, "\n", (1, 0), (1, 0), "\n"),
        (token.NAME, "b", (2, 0), (2, 0), "b"),
        (token.NEWLINE, "\n", (2, 0), (2, 0), "\n"),
        (token.NAME, "c", (3, 0), (3, 0), "c"),
        (token.NEWLINE, "\n", (3, 0), (3, 0), "\n"),  # The newline is added to the end of the output to avoid test failure on Windows
    ]
    s = u.untokenize(l)

# Generated at 2022-06-23 15:51:35.278465
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing("foo")
    except StopTokenizing as e:
        assert str(e) == "foo"
    else:
        assert 0, "Failed to raise StopTokenizing"



# Generated at 2022-06-23 15:51:38.878828
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    unt = Untokenizer()
    assert unt.tokens == []
    assert unt.prev_row == 1
    assert unt.prev_col == 0



# Generated at 2022-06-23 15:51:48.593070
# Unit test for function group
def test_group():
    assert group("ab", "cd") == "(ab|cd)"
    assert group("a(b|c)", "d") == "(a(b|c)|d)"


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + r"|" + Comment

# XXX: handle non-ascii decimal points (allowing UnicodeDigit)?
Name = r"\w+"
# Note: we can't use this:
# Hexnumber = r"0[xX](?:_?[0-9a-fA-F])+" # XXX: handle non-BMP characters

# Generated at 2022-06-23 15:51:51.819169
# Unit test for constructor of class TokenError
def test_TokenError():
    token_error = TokenError("testing")
    assert str(token_error) == "testing"



# Generated at 2022-06-23 15:51:53.467953
# Unit test for function group
def test_group():
    assert group("abc", "def") == r"(abc|def)"



# Generated at 2022-06-23 15:51:55.222333
# Unit test for function printtoken
def test_printtoken():
	printtoken(0, 'string', (0, 0), (1, 1), 'line')


# Generated at 2022-06-23 15:51:58.766238
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    t = unt.untokenize(tokenize(iter(["1 + 2", "3", "\n"]).__next__))
    assert t == "1 + 2 3 \n"


# Generated at 2022-06-23 15:52:05.545542
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    # should_be = "if 1:  pass"
    source = [(NAME, 'if'), (NUMBER, '1'), (COLON, ':'),
              (INDENT, '  '), (NAME, 'pass'), (DEDENT, '')]
    newcode = untok.compat(source[0], iter(source[1:]))
    # assert newcode == should_be, newcode
test_Untokenizer_compat()
del test_Untokenizer_compat



# Generated at 2022-06-23 15:52:18.785065
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not readlines:
            raise StopIteration
        line = readlines.pop(0)
        if isinstance(line, bytes):
            return line
        return line.encode("utf-8")

    def check_encoding(readlines, expected):
        stream = list(readlines)
        actual = detect_encoding(lambda: readline())
        if actual != expected:
            print(
                "Wrong result: expected %s, got %s" % (expected, actual),
                file=sys.stderr
                )
            print("with input: %r" % (stream,), file=sys.stderr)
            raise AssertionError

    def u(s):
        return s
        # return s.encode("utf-8")


# Generated at 2022-06-23 15:52:23.711337
# Unit test for function group
def test_group():
    assert group("1", "2") == "1|2"
    assert group("a", "b", "c") == "a|b|c"
    assert group("a", "b|c", "d") == "a|b|c|d"
    assert group("a" + "b" + "c", "d") == "abc|d"


# Generated at 2022-06-23 15:52:31.117955
# Unit test for function untokenize
def test_untokenize():
    def detab(tabsize: int, line: Text) -> Text:
        # For testing purposes, we want to map all TAB characters to
        # spaces, so we can compare the output as a string
        n = len(line)
        i = 0
        res = bytearray()
        while i < n:
            c = line[i:i+1]
            i = i + 1
            if c == b"\t":
                j, k = divmod(i, tabsize)
                res.extend(b" " * (tabsize - k))
            else:
                res.extend(c)
        return bytes(res)

    def roundtrip(s: Text) -> Text:
        result = untokenize(tokenize(io.BytesIO(s).readline))

# Generated at 2022-06-23 15:52:32.847624
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"



# Generated at 2022-06-23 15:52:37.423549
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -\xe7-\xe9-'
        yield b''
    assert detect_encoding(readline) == ('iso-8859-1', [b'# -\xe7-\xe9-'])



# Generated at 2022-06-23 15:52:42.857088
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    r = io.BytesIO(b"if1\n  2\n")
    u = Untokenizer()
    g = tokenize.generate_tokens(r.readline)
    u.compat(next(g), g)
    print(u.tokens)
test_Untokenizer_compat.__test__ = False



# Generated at 2022-06-23 15:52:53.716364
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        return io.BytesIO(b"\xef\xbb\xbf# coding: latin-1\n").readline()

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])

    def readline():
        return io.BytesIO(b"# coding: latin-1\n").readline()

    assert detect_encoding(readline) == ("utf-8", [b"# coding: latin-1\n"])

    def readline():
        return io.BytesIO(b"\xef\xbb\xbf# coding: latin-1\n").readline()


# Generated at 2022-06-23 15:52:57.235408
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    st = StopTokenizing()
    assert st.args == ()


# unit test for line number updating function

# Generated at 2022-06-23 15:53:08.328641
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import generate_tokens, tok_name

    def remove_empty(iterable):
        return filter(lambda token: token[0] != tokenize.NL, iterable)

    def listOfTokens(code):
        return list(remove_empty(generate_tokens(StringIO(code).readline)))

    def numberOfTokens(code):
        return len(listOfTokens(code))

    assert numberOfTokens("#") == 1
    assert numberOfTokens("# ") == 1
    assert numberOfTokens("#\n") == 2
    assert numberOfTokens("'''\n#\n'''") == 4
    assert numberOfTokens("'''\n#\n'''\n") == 5

    assert numberOfTokens("#\n'''\n#\n'''") == 5
   

# Generated at 2022-06-23 15:53:20.034988
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1"
    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1"])
    def readline():
        yield b"\xef\xbb\xbf# coding: latin-1"
    assert detect_encoding(readline) == ("utf-8-sig", [b"# coding: latin-1"])
    def readline():
        yield b"#coding=latin-1"
    assert detect_encoding(readline) == ("iso-8859-1", [b"#coding=latin-1"])
    def readline():
        yield b"#!python\n# coding: latin-1"

# Generated at 2022-06-23 15:53:21.844704
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield 'x=1'
    tokenize_loop(readline(),printtoken)



# Generated at 2022-06-23 15:53:31.101816
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    unt = Untokenizer()
    unt.prev_row = 0
    unt.prev_col = 0
    unt.add_whitespace((0,0))
    assert unt.tokens == []
    unt.add_whitespace((0,1))
    assert unt.tokens == [" "]
    unt.add_whitespace((1,2))
    assert unt.tokens == [" ", " "]

test_Untokenizer_add_whitespace()



# Generated at 2022-06-23 15:53:35.583507
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    from io import StringIO
    from . import tokenize

    u = Untokenizer()
    tokenize.tokenize(StringIO("def f():\n    pass\n").readline, u)
    assert u.untokenize([]) == "def f ( ) :\n    pass\n"



# Generated at 2022-06-23 15:53:45.727944
# Unit test for function printtoken
def test_printtoken():
    def check(src, expected_output):
        import io

        f = io.StringIO()
        tokeneater = lambda *args: printtoken(*args, file=f)

        f = io.StringIO(src)
        generate_tokens(f.readline, tokeneater)

        got = f.getvalue()
        if got[-1:] == "\n":
            got = got[:-1]
        assert got == expected_output

    check('a = 1\n', '1,0-1,1:\tNAME\t\'a\'\n1,2-1,3:\tOP\t\'=\'\n1,4-1,5:\tNUMBER\t\'1\'\n')

# Generated at 2022-06-23 15:53:53.775305
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from blib2to3.pgen2.tokenize import tokenize_loop, ENCODING, untokenize

    s = StringIO("a,b,c\n")
    tokens = []
    tokenize_loop(s.readline, tokens.append)
    untokenized = untokenize(tokens)
    assert untokenized == b"a,b,c\n"
    assert untokenized.decode(ENCODING) == "a,b,c\n"



# Generated at 2022-06-23 15:54:05.363993
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import BytesIO
    from .tokenize import (
        INDENT,
        DEDENT,
        NUMBER,
        NAME,
        NEWLINE,
        NL,
        ASYNC,
        AWAIT,
    )
    u = Untokenizer()
    f = BytesIO(
        b"print(1)\n  async def foo():\n   print(2)\n\nprint(3)\nprint(4)\nprint(5)\n"
    )
    g = tokenize(f.readline)

# Generated at 2022-06-23 15:54:06.637134
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:54:08.322564
# Unit test for function printtoken
def test_printtoken():
	printtoken(1,1,(1,1),(1,1),1)


# Generated at 2022-06-23 15:54:14.303339
# Unit test for function any
def test_any():
    e = re.compile(any("a", "b"))
    e.match("")
    e.match("a")
    e.match("b")
    e.match("ab")
    e.match("ba")
    e.match("aba")
    e.match("bab")
    e.match("baba")
    e.match("abba")
    e.match("abbab")
    e.match("0")
    e.match("1")
    e.match("2")



# Generated at 2022-06-23 15:54:18.524242
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("test message")
    except TokenError as e:
        assert e.msg == "test message"
        assert str(e) == "test message"



# Generated at 2022-06-23 15:54:30.764893
# Unit test for function untokenize
def test_untokenize():
    def check(s: str, n: int) -> None:
        iterable = list(tokenize(BytesIO(s.encode("utf-8")).readline))
        newcode = untokenize(iterable)
        readline = iter(newcode.splitlines(1)).__next__
        assert list(tokenize(readline))[:n] == iterable[:n]

    # test some round-trip cases
    check("a = 1", 1)
    check("a = \\", 1)  # this test checks the BrokenConstant code path
    check("a = '\n'", 1)  # this test checks the BrokenConstant code path
    check("a = '''\n'''", 1)  # this test checks the BrokenConstant code path
    check("a = '''\n", 1)  # this

# Generated at 2022-06-23 15:54:32.749780
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"
    assert group("abc|def") == "(abc\\|def)"



# Generated at 2022-06-23 15:54:34.018060
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:54:45.418675
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_row = 24
    ut.prev_col = 0
    ut.add_whitespace((24, 0))
    ut.add_whitespace((24, 4))
    ut.tokens.append('test')
    ut.add_whitespace((25, 0))
    assert ut.tokens == ['test\n']
    ut.tokens = []
    ut.prev_row = 1
    ut.prev_col = 0
    ut.add_whitespace((1, 0))
    ut.tokens.append('test')
    assert ut.tokens == ['test']
    ut.add_whitespace((1, 2))
    ut.tokens.append('test')

# Generated at 2022-06-23 15:54:51.105577
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test the tokenize_loop function
    import io
    import unittest

    class TokenizeTest(unittest.TestCase):
        def test_tokenize_loop(self):
            tokenize_loop(io.BytesIO(b"def a(): x=3").readline, printtoken)

    unittest.main()


# End of unit test for function tokenize_loop


# Generated at 2022-06-23 15:55:03.605699
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not lines:
            raise StopIteration
        line = lines[0]
        del lines[0]
        return line


# Generated at 2022-06-23 15:55:10.994537
# Unit test for function printtoken
def test_printtoken():
    printtoken(
        token.STRING,
        b'\'Hello, world!\'',
        (1, 0),
        (1, 15),
        b"test"
    )
    if __debug__:
        printtoken(
            token.STRING,
            b'\'Hello, world!\'',
            (1, 0),
            (1, 15),
            b"test"
        )


# Generated at 2022-06-23 15:55:18.574024
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from blib2to3.pgen2.token import tokenize

    def check_token_types(toks, types):
        for tok, typ in zip(toks, types):
            tok = [x for x in tok if x != tokenize.NL]
            if tok != typ:
                raise ValueError("%r != %r" % (tok, typ))

    def tokeneater(*args):
        toks.append(args)

    toks = []
    # test 1
    tokenize(StringIO("def f(x): return x+1").readline, tokeneater)

# Generated at 2022-06-23 15:55:31.029109
# Unit test for function untokenize

# Generated at 2022-06-23 15:55:41.989582
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from . import token
    from . import untokenize
    from . import untoken

    if untokenize.Untokenizer is untoken.Untokenizer:
        return

    untok = untokenize.Untokenizer()
    for t in untok.untokenize(
        tokenize.generate_tokens(iter(["a b c"]).__next__)
    ):
        print(t)
    print("--")
    for t in untok.untokenize(
        tokenize.generate_tokens(iter([" a b c"]).__next__)
    ):
        print(t)
    print("--")

# Generated at 2022-06-23 15:55:51.237077
# Unit test for function detect_encoding
def test_detect_encoding():
    def gen(line: bytes):
        yield line
        yield b""

    def gen_bom(line: bytes):
        yield BOM_UTF8 + line
        yield b""

    def check(expected: str, *lines: str):
        assert detect_encoding(gen(b"".join(lines)))[0] == expected

    # Test default
    check("utf-8", "")
    check("utf-8", "# -*- coding: xxx -*-")  # coding after first line should be ignored

    # Test BOM
    check("utf-8-sig", "", "")
    check("utf-8-sig", "", "# -*- coding: latin-1 -*-")
    check("utf-8-sig", "# -*- coding: latin-1 -*-", "")

# Generated at 2022-06-23 15:55:59.828903
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    test_input = [
        (NAME, "x", (1, 0), (1, 1), "x"),
        (NEWLINE, "", (1, 1), (1, 1), ""),
        (NAME, "y", (2, 0), (2, 1), "y"),
    ]
    result = untok.compat((NAME, "x"), test_input)
    assert result is None, result
    toklist = untok.tokens
    assert toklist == ["x ", "\n", "y"], toklist


# Generated at 2022-06-23 15:56:00.672763
# Unit test for constructor of class TokenError
def test_TokenError():
    exc = TokenError("Test Token Error")



# Generated at 2022-06-23 15:56:01.953057
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:56:03.831947
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 2, (2, 3), (1, 1), 1)

# Generated at 2022-06-23 15:56:13.946288
# Unit test for function generate_tokens
def test_generate_tokens():
    readline = iter("if 1:\n  pass\n#\n".splitlines(1)).__next__
    result = list(generate_tokens(readline))

# Generated at 2022-06-23 15:56:19.425570
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    for i in range(1, 5):
        print("i = ", i)
        tokenlist = [(x, "tok_%d" % x) for x in range(i)]
        u = Untokenizer()
        u.untokenize(iter(tokenlist))



# Generated at 2022-06-23 15:56:23.392113
# Unit test for function printtoken
def test_printtoken():
    printtoken(1,2,(3,4),(5,6),"7")



# Generated at 2022-06-23 15:56:32.828346
# Unit test for function printtoken
def test_printtoken():
    _rowcol = lambda s, t, u, v: (s, t, u, v)
    _tokenize = lambda s: [
        (toktype, tok, _rowcol(1, 1, 2, 2), _rowcol(1, 1, 2, 2), "\n")
        for toktype, tok in tokenize(iter([s]))
    ]
    assert _tokenize("1") == [(NUMBER, "1", (1, 1, 2, 2), (1, 1, 2, 2), "\n")]
    assert _tokenize("+") == [(OP, "+", (1, 1, 2, 2), (1, 1, 2, 2), "\n")]

# Generated at 2022-06-23 15:56:35.982935
# Unit test for function any
def test_any():
    assert any("a", "b", "c") == "(a|b|c)*"



# Generated at 2022-06-23 15:56:37.757842
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:56:40.825630
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("ab", "cd") == "(ab|cd)"


# Generated at 2022-06-23 15:56:50.484233
# Unit test for function untokenize

# Generated at 2022-06-23 15:56:53.553002
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass
    else:
        raise RuntimeError("Failed to raise StopTokenizing exception")



# Generated at 2022-06-23 15:56:55.893125
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:57:07.018774
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()

# Generated at 2022-06-23 15:57:12.178375
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    u = Untokenizer()
    r = io.BytesIO(b'print(1)\n')
    toks = tokenize.generate_tokens(r.readline)
    result = u.compat(next(toks), toks)
    assert result is None
    assert u.tokens == ['print', '(', '1', ')', '\n']



# Generated at 2022-06-23 15:57:19.457445
# Unit test for function maybe
def test_maybe():
  assert re.match(maybe('hello'), 'hello')
  assert re.match(maybe('hello'), '')
  assert re.match(maybe('hello'), 'helloo')
  assert re.match(maybe('hello'), 'hell')


Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"[a-zA-Z_]\w*"

Hexnumber = r"0[xX][\da-fA-F]+[lL]?"
Binnumber = r"0[bB][01]+[lL]?"
Octnumber = r"0[oO]?[0-7]+[lL]?"
Decnumber

# Generated at 2022-06-23 15:57:24.163906
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output):
        # note: tokenize strings as if they are unicode strings
        result = untokenize(tokenize(BytesIO(input.encode("utf-8")).readline))
        if output != result:
            print("Wanted:")
            print(repr(output))
            print("Got:")
            print(repr(result))
        assert output == result
    compare("def f(x): pass\n", "def f ( x ) : pass\n")
    compare("def f( ): pass\n", "def f ( ) : pass\n")
    compare("def f(*args): pass\n", "def f ( * args ) : pass\n")

# Generated at 2022-06-23 15:57:35.253345
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield (b"# coding: utf-8\n")
        yield (b"# -*- coding: utf-8-sig -*-\n")
        yield (b"# -*- coding: latin-1 -*-\n")
        yield (b"# vim: ft=python\n")
        yield (b"# -*- coding: utf-8 -*-\n")
        yield (b"# -*- coding: utf-8-sig -*-\n")
        yield (b"# coding=utf-8\n")
        yield (b"# coding=latin-1\n")
        raise StopIteration
    assert detect_encoding(readline) == ("utf-8", [b"# coding: utf-8\n"])


# Generated at 2022-06-23 15:57:36.626713
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError()



# Generated at 2022-06-23 15:57:39.257083
# Unit test for function printtoken
def test_printtoken():
    for type in _tokenize.__annotations__['type', 'token', 'start', 'end', 'line']:
        # pass
        print(type)


# Generated at 2022-06-23 15:57:47.573010
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == [] and u.prev_row == 1 and u.prev_col == 0
    u.add_whitespace((1, 2))
    assert u.prev_row == 1 and u.prev_col == 2
    u.tokens.append("123")
    u.prev_col = 5
    u.add_whitespace((1, 7))
    assert u.tokens == ["123", "  "]
    assert u.prev_col == 7
    u.add_whitespace((2, 7))
    assert u.prev_row == 2 and u.prev_col == 7
    u.tokens.append("456")
    u.add_whitespace((2, 10))

# Generated at 2022-06-23 15:57:49.308656
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:57:59.161558
# Unit test for function any
def test_any():
    assert regex_match("x", any("x"))
    assert regex_match("xyxx", any("x"))
    assert not regex_match("", any("x"))
    assert regex_match("abc", any("abc"))
    assert regex_match("xyz", any("abc"))
    assert not regex_match("x", any(""))
    assert regex_match("", any(""))
    assert regex_match("", any("abcd", "efg"))
    assert regex_match("abcd", any("abcd", "efg"))
    assert regex_match("efg", any("abcd", "efg"))
    assert not regex_match("abcde", any("abcd", "efg"))



# Generated at 2022-06-23 15:58:08.370595
# Unit test for function tokenize_loop
def test_tokenize_loop():

    def make_readline(lines):
        lines = iter(lines)

        def readline():
            try:
                return next(lines)
            except StopIteration:
                return ""

        return readline

    result = []
    rl = make_readline(["1"])
    tokenize_loop(rl, result.append)
    assert result == [(NUMBER, "1", (1, 0), (1, 1), "1")]

    result = []
    rl = make_readline(["'"])
    tokenize_loop(rl, result.append)
    assert result == [(ERRORTOKEN, "'", (1, 0), (1, 1), "'")]

    result = []
    rl = make_readline(["'''"])

# Generated at 2022-06-23 15:58:18.143972
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    from blib2to3.pygram import python_symbols
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.parse import ParseError
    from tempfile import TemporaryFile
    from io import BytesIO, TextIOWrapper
    from pickle import dumps, loads
    GRAMMAR_ENCODING = "ISO-8859-1"

# Generated at 2022-06-23 15:58:23.221109
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    unit = Untokenizer()
    unit.prev_row = 1
    unit.prev_col = 1
    unit.add_whitespace((1, 1))
    unit.add_whitespace((1, 2))
    unit.add_whitespace((1, 5))
    assert unit.tokens == [' ', '', '   ']



# Generated at 2022-06-23 15:58:32.935857
# Unit test for function tokenize_loop
def test_tokenize_loop():
  import unittest

  class TokenizeTestCase(unittest.TestCase):
    def test_tokenize_loop(self):
      from io import BytesIO
      from types import GeneratorType
      from sys import version_info

      test_data = b"if True:\n\tprint('this is a test')"

# Generated at 2022-06-23 15:58:38.544445
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    from tokenize import tokenize as _tokenize, untokenize as _untokenize

    def roundtrip(s: Text) -> Text:
        tokens = list(_tokenize(io.BytesIO(s.encode("utf-8")).readline))
        return _untokenize(tokens).decode("utf-8")

    assert roundtrip("# coding: utf-8\nfoo = '#'") == "# coding: utf-8\nfoo = '#'"



# Generated at 2022-06-23 15:58:48.270355
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    untokenizer = Untokenizer()
    for tok in tokenize.generate_tokens(io.BytesIO(b'__all__ = ["x"]').readline):
        pass
    res = untokenizer.compat(tok, tokenize.generate_tokens(io.BytesIO(b'"""\n"""').readline))
    assert res == None  # for pytype
    res = untokenizer.tokens
    assert res == ['__all__ = ["x"]', '"""\n"""']  # for pytype



# Generated at 2022-06-23 15:58:52.223520
# Unit test for function printtoken
def test_printtoken():
    # Make sure Token is converted to a tuple.
    from blib2to3.pgen2.token import Token
    class Token2(Token): pass
    printtoken(0, Token2(), (0, 0), (0, 0), "")



# Generated at 2022-06-23 15:58:56.359842
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test the generate_tokens() generator

    # If a test fails, this function raises SyntaxError.
    # if we get to the end without raising an exception,
    # the test passed.

    import token, tokenize

    def test(s):
        g = tokenize.generate_tokens(StringIO(s).readline)
        for tok in g:
            pass

    # check empty input
    test("")

    # check valid tokens
    test("abaaba !== ~")

    # check invalid tokens
    try:
        test("~")
    except tokenize.TokenError as e:
        assert e.args[0] == ("EOF in multi-line statement", (1, 0))
    else:
        raise "Expected TokenError"

    # if we get here, the tests passed
    print

# Generated at 2022-06-23 15:58:59.409783
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("custom message")
    except TokenError as e:
        assert str(e) == "custom message"



# Generated at 2022-06-23 15:59:01.795898
# Unit test for function maybe
def test_maybe():
    pat = maybe('a', 'b', 'c')
    assert pat == "(a|b|c)?"

# Test for tokenize()

# Generated at 2022-06-23 15:59:03.613197
# Unit test for function generate_tokens
def test_generate_tokens():
    import pprint, token
    pprint.pprint(list(tokenize.generate_tokens(StringIO('for i in range(10):\n print(i)').readline)))


# Generated at 2022-06-23 15:59:08.591713
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    a = [
        (1, "def"),
        (4, " "),
        (0, "\n"),
        (4, " "),
        (1, "f"),
        (4, " "),
        (40, "("),
        (1, "x"),
        (41, ")"),
        (0, "\n"),
        (0, "\n"),
        (5, "y"),
    ]
    result = u.untokenize(a)
    assert result == "def f (x)\n\ny", result


# Backwards compatible interface

# Generated at 2022-06-23 15:59:17.627174
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    input = [
        (NAME, "a"),
        (NL, "\n"),
        (INDENT, "\n  "),
        (NAME, "b"),
        (NUMBER, "1234"),
        (DEDENT, "\n"),
    ]
    assert u.untokenize(input) == "a\n  b 1234\n"
    u = Untokenizer()
    input = [(NAME, "a"), (SYNC, "async "), (NAME, "b")]
    assert u.untokenize(input) == "a async b "
    u = Untokenizer()
    input = [(NAME, "a"), (AWAIT, "await "), (NAME, "b")]
    assert u.untokenize(input) == "a await b "



# Generated at 2022-06-23 15:59:28.809222
# Unit test for function maybe
def test_maybe():
    # test some extreme cases
    assert maybe("") == ""
    assert maybe("","") == ""
    assert maybe("a") == "a?"
    assert maybe("a","") == "a?"
    assert maybe("a","b") == "a|b?"
    assert maybe("a","b","") == "a|b?"
    # test whether the choice is correct
    import random
    def test(s):
        return any(maybe(c) for c in s) == (s and (s[0]+s[1:]) or "")
    assert all(test("") for _ in range(10))
    assert all(test("a") for _ in range(10))
    assert all(test("abc") for _ in range(10))

# Generated at 2022-06-23 15:59:34.309116
# Unit test for function generate_tokens

# Generated at 2022-06-23 15:59:41.032506
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(t, expected_type, expected_value, expected_start, expected_end, expected_line):
        assert t.type == expected_type, f"Wrong token type, expected {expected_type!r}, got {t.type!r}"
        assert t.string == expected_value, f"Wrong token value, expected {expected_value!r}, got {t.string!r}"
        assert t.start == expected_start, f"Wrong token start, expected {expected_start!r}, got {t.start!r}"
        assert t.end == expected_end, f"Wrong token end, expected {expected_end!r}, got {t.end!r}"
        assert t.line == expected_line, f"Wrong token line, expected {expected_line!r}, got {t.line!r}"



# Generated at 2022-06-23 15:59:47.279166
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ungettext = Untokenizer().untokenize
    lines = (
        "if (1):\n"
        "    print(2)\n"
        "else:\n"
        "    print(3)\n"
    )
    assert ungettext(tokenize(lines)) == lines



# Generated at 2022-06-23 15:59:50.702302
# Unit test for function maybe
def test_maybe():
    assert bool(maybe("a")("a"))
    assert bool(maybe("a")(""))
    assert bool(maybe("a")("b"))
    assert bool(maybe("a")("ba"))



# Generated at 2022-06-23 16:00:00.716249
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    l = [
        (1, "def"),
        (2, "f"),
        (0, "("),
        (4, "\n"),
        (5, " "),
        (5, " "),
        (1, "pass"),
        (4, "\n"),
        (0, ")"),
    ]
    res = untok.compat((1, "def"), l)
    assert res == "def f(\n        pass\n)"


# End unit test

# Generated at 2022-06-23 16:00:04.089267
# Unit test for function tokenize_loop
def test_tokenize_loop():
    with open("Lib/tokenize.py") as f:
        tokenize_loop(f.readline, printtoken)

# Factored out of tokenize_loop so that tokenize_loop can be used from
# timed_execute.

# Generated at 2022-06-23 16:00:16.898292
# Unit test for function untokenize

# Generated at 2022-06-23 16:00:20.745751
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import BytesIO
    from tokenize import TokenInfo
    from . import untokenize, untokenize_token

    f = BytesIO('o = "a\\n    b"\n')
    l = list(generate_tokens(f))
    print(l)
    assert len(l) == 7, l
    new = ''.join(
        [untokenize_token(TokenInfo(*tok)) for tok in l]
    )
    assert new == 'o = "a\\n    b"\n', repr(new)
    assert untokenize(l) == 'o = "a\\n    b"\n', repr(l)



# Generated at 2022-06-23 16:00:26.591573
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("error message")
    except TokenError:
        pass
    try:
        raise TokenError
    except TokenError:
        pass


# Filter out NUL bytes
Nullchar = "\0"
nl_re = re.compile(r"\n", re.UNICODE)


# This exception is raised when a string passed to compile() is not a valid
# string literal according to the current compiler option state.

# Generated at 2022-06-23 16:00:31.585110
# Unit test for function tokenize
def test_tokenize():
    import io
    r = io.BytesIO(b"def f(x): return 3*x")
    g = tokenize(r.readline)
    for tok in g:
        print(tok)


# Generated at 2022-06-23 16:00:36.100554
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()
    untokenizer.prev_row = 1
    untokenizer.prev_col = 0
    untokenizer.add_whitespace((1, 5))
    assert untokenizer.tokens == [" " * 5]
    untokenizer.add_whitespace((1, 0))
    assert untokenizer.tokens == [" " * 5]
    untokenizer.add_whitespace((2, 0))
    assert untokenizer.tokens == [" " * 5]
    untokenizer.add_whitespace((3, 3))
    assert untokenizer.tokens == [" " * 5, "\n", "\n", " " * 3]



# Generated at 2022-06-23 16:00:48.335898
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP
    u = Untokenizer()
    out = StringIO()
    source = ["1+1", " # the answer"]
    for t in tokenize("\n".join(source)):
        out.write(str(t))
    out.seek(0)
    u.compat(("next", ""), iter(tokenize(out.readline)))
    assert u.tokens == ["1 ", "+", "1 ", "\n", " # the answer"], u.tokens
    # You would think that this would be right, but untokenize doesn't
    # give us feasible input:
    #     u.compat(("NUMBER", "1"),
    #              tokenize(StringIO("1+1 #

# Generated at 2022-06-23 16:00:49.643772
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 16:00:57.425938
# Unit test for function tokenize
def test_tokenize():
    # This is a useful test for tokenize() since it exercises all of the
    # tokenize() logic, including the binary token objects, the
    # round-trip-ability of tokenize(), untokenize(), and tokenize() again, as
    # well as the decoding of input strings.

    def get_tokens(s: str) -> List[Tuple[int, Text, Coord, Coord, Text]]:
        tokens = []
        g = generate_tokens(lambda: s)
        for tok in g:
            tokens.append(tok)
        return tokens

    # test_tokenize_chr() requires the following function.

# Generated at 2022-06-23 16:01:08.799780
# Unit test for function maybe
def test_maybe():
    return maybe(r"[0-9]+", r"\w+", r"\s+")


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"\w+"

Hexnumber = r"0[xX][\da-fA-F]+"
Binnumber = r"0[bB][01]+"
Octnumber = r"0[oO][0-7]+"
Decnumber = r"0[0-7]*|[1-9]\d*"  # Can't use 0[

# Generated at 2022-06-23 16:01:12.264662
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from .tokenize import generate_tokens, COMMENT, NAME, OP, STRING, tokenize

    def untokenize(tokens):
        return Untokenizer().untokenize(tokens)

    # Some code to generate some tokens, taken from T. Good's timestamp.py

# Generated at 2022-06-23 16:01:16.481900
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline() -> bytes:
        return b"# coding=utf-8"

    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8"])

