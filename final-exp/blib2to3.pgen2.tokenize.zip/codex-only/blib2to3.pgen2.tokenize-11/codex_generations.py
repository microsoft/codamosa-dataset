

# Generated at 2022-06-23 15:51:16.502161
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:51:18.094505
# Unit test for function maybe
def test_maybe():
    assert maybe('ab', 'cd') == "(ab|cd)?"
    assert maybe('ab', 'cd') != "(ab|cd)*"


# Generated at 2022-06-23 15:51:21.986324
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    result = untok.untokenize(
        [
            (NUMBER, "3"),
            (NEWLINE, "\n"),
            (NUMBER, "4"),
            (NEWLINE, "\n"),
            (NUMBER, "5"),
            (ENDMARKER, ""),
        ]
    )
    assert result == "3\n4\n5", result



# Generated at 2022-06-23 15:51:24.343337
# Unit test for function any
def test_any():
    assert _guess_encoding(b"\xff", 'utf-8') is None
    print(_guess_encoding(b"# coding: utf-8\n\xff", 'ascii'))



# Generated at 2022-06-23 15:51:33.016065
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", maybe("a")
    def _(s):
        return s
    error = "maybe(%s) == %s, not %s"
    assert maybe(_("a")) == "(a)?", error % (_("a"), "(a)?", maybe(_("a")))
    assert maybe("a", "b") == "((a)|(b))?", error % (
        "a, b", "((a)|(b))?", maybe("a", "b"))
    assert maybe("a", "b", "c") == "(((a)|(b))|(c))?", error % (
        "a, b, c", "(((a)|(b))|(c))?", maybe("a", "b", "c"))
test_maybe()
del test_maybe



# Generated at 2022-06-23 15:51:35.475057
# Unit test for function group
def test_group():
    assert group("a", "b", "c", "def") == r"(a|b|c|def)"



# Generated at 2022-06-23 15:51:37.990356
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:51:39.365782
# Unit test for constructor of class TokenError
def test_TokenError():
    x = TokenError("foo")
    x.args



# Generated at 2022-06-23 15:51:48.876224
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    l = [
        (1, "if", (1, 0), (1, 2), "if 1:\n"),
        (4, "    ", (2, 0), (2, 4), "    2\n"),
        (1, "if", (3, 0), (3, 2), "if 2:\n"),
        (1, "else", (4, 4), (4, 9), "    else:\n"),
        (4, "    ", (5, 0), (5, 4), "    3\n"),
        (0, "", (6, 0), (6, 0), ""),
    ]
    assert untok.untokenize(l) == "if 1:\n    2\nif 2:\n    else:\n    3\n"



# Generated at 2022-06-23 15:51:53.985819
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output, roundtrip=True):
        it = iter(tokenize(io.BytesIO(input.encode("utf-8")).readline))
        tokens = cast(Iterable[Tuple[int, str]], it)
        result1 = untokenize(tokens)
        result2 = result1.encode("latin-1").decode("utf-8")
        result3 = result2.replace("\r\n", "\n")
        # Check roundtrip if requested and possible
        if roundtrip:
            try:
                exec(result3, {})
            except SyntaxError:
                roundtrip = False
        if not roundtrip:
            assert result3 == output, (
                "roundtrip failed:\n" + result3 + "\n---\n" + output
            )

# Generated at 2022-06-23 15:51:59.498109
# Unit test for function generate_tokens

# Generated at 2022-06-23 15:52:04.195783
# Unit test for function maybe
def test_maybe():
    for key in "abc1b5a2b5a8".split("5"):
        assert maybe("a", "b", "c", "[1-9]") + "5" == key



# Generated at 2022-06-23 15:52:07.386524
# Unit test for function any
def test_any():
    assert re.match(any("a", "ab"), "")
    assert re.match(any("a", "ab"), "a")
    assert re.match(any("a", "ab"), "ab")
    assert not re.match(any("a", "ab"), "b")



# Generated at 2022-06-23 15:52:18.157363
# Unit test for function group
def test_group():
    # An attempt to assert that parenthesized expressions are not
    # accidentally over-nested by using the wrong re.group when
    # constructing patterns for REs.
    import re
    for i in 1, 2, 3, 4, 5:
        assert re.match(r"^" + group("a" * i) + "$", "a" * i).lastindex == 1
        assert re.match(r"^" + group("(a" * i) + "$", "a" * i).lastindex == 1
test_group()
del test_group


# Helper to make a string pattern

# Generated at 2022-06-23 15:52:27.468368
# Unit test for function untokenize

# Generated at 2022-06-23 15:52:37.658219
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():  # this is only a readline
        if not test_cases:
            raise StopIteration
        return test_cases.pop(0)


# Generated at 2022-06-23 15:52:47.742099
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return "if a==5:\n  a=1"
    tokeneater = []
    tokenize_loop(readline, tokeneater.append)

# Generated at 2022-06-23 15:52:56.493144
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    global log
    log = []
    s = Untokenizer()

    def tokeneater(*args):
        log.append(args)

    input_tokens = [(NUMBER, "1"), (NL, "\n"), (INDENT, "  "), (NUMBER, "2"), (DEDENT, "")]
    s.compat(input_tokens[0], iter(input_tokens[1:]))
    assert log == [(NUMBER, "1 "), (NL, "\n"), (INDENT, "  "), (NUMBER, "2 ")]
    log = []
    u = Untokenizer()
    u.compat(input_tokens[0], iter(input_tokens[1:]))

# Generated at 2022-06-23 15:53:04.500175
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import BytesIO
    from tokenize import tokenize
    gt = generate_tokens(BytesIO("foo=4\nif bar:\n    print(bar)").readline)
    # print '\n'.join([str(t) for t in gt])
    assert list(gt) == list(tokenize(BytesIO("foo=4\nif bar:\n    print(bar)").readline))
    print("test_generate_tokens done")


test_generate_tokens()

# End Of File

# Generated at 2022-06-23 15:53:06.907882
# Unit test for function any
def test_any():
    assert re.match(any("abc"), "abc")
    assert re.match(any("abc"), "ababc")
    assert not re.match(any("abc"), "d")



# Generated at 2022-06-23 15:53:16.571150
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-23 15:53:25.225005
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    from . import tokenize
    from blib2to3.fixes.fix_import import fix_import
    from blib2to3.pygram import python_symbols as syms

    foo = io.StringIO("import os\n")
    untok = Untokenizer()
    for a, b in tokenize.generate_tokens(foo.readline):
        if (
            a == tokenize.NAME
            and b == "fix_import"
        ):  # look for the name fix_import, when we find it we will change the token type to IMPORT
            a = syms.import_name
        untok.tokens.append((a, b))
    source = untok.untokenize()
    exec(source)
    assert True



# Generated at 2022-06-23 15:53:31.434801
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline() -> Iterator[bytes]:
        yield from [
            b'\xEF\xBB\xBF# -*- coding: latin-2 -*-\n',
            b'assert 1\n',
        ]

    decoding, lines = detect_encoding(readline)
    assert decoding == "iso-8859-2"
    assert lines == [b'\xEF\xBB\xBF# -*- coding: latin-2 -*-\n', b'assert 1\n']

    def readline() -> Iterator[bytes]:
        yield from [
            b'\xEF\xBB\xBF# coding: latin-2\n',
            b'\xC4\x85\n',
        ]

    decoding, lines = detect_encoding(readline)
    assert decoding

# Generated at 2022-06-23 15:53:35.026820
# Unit test for function any
def test_any():
    assert any("a") == "a*"
    assert any("a", "b") == "(a|b)*"
    assert any("a(b|c)*d") == "a(b|c)*d*"



# Generated at 2022-06-23 15:53:35.918585
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError()



# Generated at 2022-06-23 15:53:39.897941
# Unit test for function any
def test_any():
    for (x, y) in (("", ""),
                   ("a", "a"),
                   ("abc", "abc"),
                   ("aecabc", "abc")):
        if any("abc") != y:
            raise AssertionError("any(\"abc\")")



# Generated at 2022-06-23 15:53:45.400300
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    ut = Untokenizer()
    ut.compat(("aaa", "bbb"), [("ddd", "ccc")])
    ut.compat(("aa", "\r\n"), [("d", "\n"), ("d", "\n"), ("end", "marker")])
    assert ut.tokens == ["bbb", "ddd", "ccc", "\n", "\n", "end", "marker"]



# Generated at 2022-06-23 15:53:50.951138
# Unit test for function printtoken
def test_printtoken():
    toktype = 1
    token = '"""'
    (srow, scol) = [1, 2]
    (erow, ecol) = [2, 3]
    line = '1st line'
    printtoken(toktype, token, (srow, scol), (erow, ecol), line)


# Generated at 2022-06-23 15:53:53.823985
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing("a", "b")
    except StopTokenizing as e:
        assert e.args == ("a", "b")



# Generated at 2022-06-23 15:54:03.395015
# Unit test for function untokenize
def test_untokenize():
    input = [
        (NUMBER, "3"),
        (NAME, "abc"),
        (OP, "+"),
        (NUMBER, "2"),
        (OP, "*"),
        (NAME, "xyz"),
    ]
    output = untokenize(input)
    assert output == "3 abc + 2 * xyz"

    input = [(NUMBER, "3"), (NAME, "abc"), (OP, "+"), (NUMBER, "2")]
    output = untokenize(input)
    assert output == "3 abc + 2", "spacing should improve with more tokens"



# Generated at 2022-06-23 15:54:08.092385
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    assert "StopTokenizing" == StopTokenizing.__name__
    assert issubclass(StopTokenizing, Exception)



# Generated at 2022-06-23 15:54:12.707482
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    fake_output = []
    def tokeneater(*args):
        fake_output.append(args)
        return
    def readline():
        return "foo bar"
    tokenize_loop(readline, tokeneater)
    untokenizer = Untokenizer()
    untokenizer.untokenize(fake_output)
    return


# Generated at 2022-06-23 15:54:16.093722
# Unit test for function any
def test_any():
    match = re.compile(any("a", "b")).match
    assert match("a")
    assert match("aaaaaa")
    assert match("ababab")
    assert match("ba")
    assert match("baaaaa")
    assert match("bababa")
    assert match("")



# Generated at 2022-06-23 15:54:21.671426
# Unit test for function any
def test_any():
    assert re.match(any("abc"), "abc")
    assert re.match(any("abc"), "ab")
    assert re.match(any("abc"), "")
    assert not re.match(any("abc"), "abcd")
    assert not re.match(any("abc"), "def")



# Generated at 2022-06-23 15:54:32.920997
# Unit test for function untokenize
def test_untokenize():
    input = [
        (NAME, 'if'),
        (OP, '>'),
        (NAME, 'x'),
        (OP, '+'),
        (NUMBER, '1'),
        (OP, '-'),
        (NAME, 'y'),
        (COLON, ':'),
        (NEWLINE, ''),
        (INDENT, ''),
        (NAME, 'x'),
        (OP, '='),
        (NAME, 'y'),
        (NEWLINE, ''),
        (DEDENT, ''),
        (NAME, 'print'),
        (OP, '('),
        (STRING, '"done"'),
        (OP, ')'),
        (NEWLINE, ''),
    ]
    expected = """
if x + 1 - y:
    x = y
print("done")
"""


# Generated at 2022-06-23 15:54:34.145902
# Unit test for function group
def test_group():
    assert group("abc", "def") == "abc|def"

# Generated at 2022-06-23 15:54:40.180276
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    t = Untokenizer()
    t.prev_row = 1
    t.prev_col = 1
    t.add_whitespace((1, 2))
    assert t.tokens == [" "]
    t.add_whitespace((2, 3))
    assert t.tokens == [" ", "\n  "]



# Generated at 2022-06-23 15:54:48.518794
# Unit test for function maybe
def test_maybe():
    # This test fails if there are extraneous parentheses in the output.
    assert maybe("a", "b") == "(a|b)?", maybe("a", "b")
_test_maybe = test_maybe


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"\w+"

Hexnumber = r"0[xX][\da-fA-F]+"
Binnumber = r"0[bB][01]+"
Octnumber = r"0[oO][0-7]+"
Decnumber = r

# Generated at 2022-06-23 15:54:51.247937
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.tokens = []
    u.prev_row = 1
    u.prev_col = 0



# Generated at 2022-06-23 15:54:55.263536
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == [] # type: ignore
    assert u.prev_row == 1 # type: ignore
    assert u.prev_col == 0 # type: ignore



# Generated at 2022-06-23 15:54:58.875710
# Unit test for function maybe
def test_maybe():
    assert maybe('apple', 'orange') == '(apple|orange)?'
    assert maybe('apple', 'orange') == '(apple|orange)?', 'that was unexpected'

# Helper for _compile

# Generated at 2022-06-23 15:54:59.807108
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    e = StopTokenizing("message")
    assert e.args[0] == "message"



# Generated at 2022-06-23 15:55:12.244637
# Unit test for function printtoken

# Generated at 2022-06-23 15:55:14.521077
# Unit test for function maybe
def test_maybe():
    failUnlessEqual(maybe("ab","cd"),"(ab|cd)?")
    failUnlessEqual(maybe("ab","cd","ef"),"(ab|cd|ef)?")


# Generated at 2022-06-23 15:55:24.653824
# Unit test for function generate_tokens
def test_generate_tokens():
    _tokenize = generate_tokens
    tokens = []
    tokenize = _tokenize(io.StringIO(
        """\
while 1:
    try:
        x = int(input("Please enter a number: "))
        break
    except ValueError:
        print("Oops!  That was no valid number.  Try again...")
"""
    ).readline)
    tokens = list(tokenize)
    assert tokens[0] == (
        NAME,
        "while",
        (1, 0),
        (1, 5),
        "while 1:",
    )
    assert tokens[10] == (
        NUMBER,
        "1",
        (2, 4),
        (2, 5),
        "    try:",
    )

# Generated at 2022-06-23 15:55:25.969624
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # Test __init__ signature
    e = StopTokenizing("foo", 1)
    assert e.args == ("foo", 1)
    # Test constructor without arguments
    token.StopTokenizing()



# Generated at 2022-06-23 15:55:29.959315
# Unit test for function tokenize
def test_tokenize():
    import tokenize as _tokenize, io
    from tokenize import tok_name

    for encoding in ("utf-8", "utf-8-sig", "utf-16", "utf-32"):
        with io.StringIO("# coding: %s\ntest = 1\n" % encoding) as f:
            g = _tokenize.tokenize(f.readline)
            next(g)
            next(g)
            assert next(g)[0] == token.NAME
            assert next(g)[0] == token.EQUAL
            assert next(g)[0] == token.NUMBER
            assert next(g)[0] == token.NEWLINE
            assert next(g) == (_tokenize.ENCODING, encoding, (1, 0), (1, 0), "\n")

# Generated at 2022-06-23 15:55:42.391253
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    global Untokenizer
    print("Testing untokenize...", end="")
    untok = Untokenizer()
    # untokenize(x) should return x
    for x in ["s = 'hello'", "print('hi')", "a, b = 1, 2\n"]:
        assert untok.untokenize(generate_tokens(x.splitlines(True))) == x

    # whitespace behavior
    assert untok.untokenize(
        generate_tokens(["if 1:", "  print(2)"], True)
    ) == "if 1:\n  print(2)\n"
    assert untok.untokenize(generate_tokens(["  print(2)", "\n"])) == "  print(2)\n"

    # test compatability mode
    assert untok.unt

# Generated at 2022-06-23 15:55:45.848397
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"
    assert group("a|b") == "(a|b)"
    assert group("(a|b)") == "((a|b))"



# Generated at 2022-06-23 15:55:53.409739
# Unit test for function detect_encoding
def test_detect_encoding():
    from . import tokenize as tokenize_module

    readline = iter(
        [
            b'#!/usr/bin/env python\n',
            b'\n',
            b'# -*- coding: latin-1 -*-\n',
            b'import os\n',
        ]
    ).__next__

    assert tokenize_module.detect_encoding(readline) == ("iso-8859-1", [])
    # unencoded non-ascii
    readline = iter([b"# -*- coding: latin-1 -*\xe9 -\n", b"# comment\n"]).__next__
    assert tokenize_module.detect_encoding(readline) == ("iso-8859-1", [])
    # no coding spec
    readline = iter

# Generated at 2022-06-23 15:56:04.555787
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import os
    import sys
    import io
    import token
    import tokenize
    from tokenize import generate_tokens as generate

    sys.stdout = io.StringIO()

# Generated at 2022-06-23 15:56:14.540890
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    tokgen = generate_tokens(io.StringIO('''if 1:
    def f():
        return ''').readline)
    for tok in tokgen:
        print(tok)
    print(list(tokenize(io.StringIO('''if 1:
    def f():
        return''').readline)))

test_generate_tokens()

# @todo #335:15min Modify test_generate_tokens() to read from a file.
#  Pretty print the result of tokenize() in the case of exception. In the
#  case of no exception, assert the result of tokenize() to be a list of
#  tuples.
#
#  This shouldn't be hard, but it is needed to increase test coverage.
# 

# Generated at 2022-06-23 15:56:26.596773
# Unit test for function detect_encoding
def test_detect_encoding():
    def get_readline(lines: List[str], stop_at_end=True) -> Callable[[], bytes]:
        def readline() -> bytes:
            return lines.pop(0).encode("utf-8")

        return readline

    assert detect_encoding(get_readline(["a = 2\n"]))[0] == "utf-8"
    assert detect_encoding(get_readline(["a = 2\n"], stop_at_end=False))[0] == "utf-8"
    assert detect_encoding(get_readline(["b'hi'\n"], stop_at_end=False))[0] == "utf-8"

# Generated at 2022-06-23 15:56:30.621969
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-23 15:56:37.025500
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_col = 0
    u.prev_row = 1
    u.tokens = ["a", "b", "c", "d", "e", "f", "g"]
    u.add_whitespace((1, 2))
    assert u.tokens == ["a", " ", "b", "c", "d", "e", "f", "g"]
    u.add_whitespace((1, 4))
    assert u.tokens == ["a", " ", "b", " ", "c", "d", "e", "f", "g"]
    u.add_whitespace((1, 0))
    assert u.tokens == ["a", " ", "b", " ", "c", "d", "e", "f", "g"]
    u

# Generated at 2022-06-23 15:56:40.137437
# Unit test for function group
def test_group():
    e = re.compile(group("a", "bc") + "d" + group("e", "fg"))
    assert e.match("ade") is not None
    assert e.match("adf") is not None
    assert e.match("bcde") is not None
    assert e.match("bcfg") is not None
    assert e.match("axdefg") is None



# Generated at 2022-06-23 15:56:45.203250
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    out = unt.untokenize(tokenize(test_untokenize.__doc__.splitlines()))
    assert out == test_untokenize.__doc__, repr(out)

# Generated at 2022-06-23 15:56:55.334914
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(s):
        yield from s.encode("ascii").splitlines(True)

    def check_encoding(s, expected):
        src = io.BytesIO(s.encode("utf-8")).readlines
        encoding, lines = detect_encoding(src)
        assert (
            expected == encoding
        ), f"{repr(s)} => {repr(encoding)}, expected {repr(expected)}"

    check_encoding("", "utf-8")
    check_encoding("\ufeff", "utf-8-sig")
    check_encoding("\ufeffabc", "utf-8-sig")
    check_encoding('# -*- coding: latin-1 -*-', "iso-8859-1")

# Generated at 2022-06-23 15:57:06.544629
# Unit test for function untokenize
def test_untokenize():
    import sys
    import unittest

    class TestUntokenize(unittest.TestCase):

        def verify(self, untok, tok):
            self.assertEqual(
                untokenize(tok),
                untok.replace("\n" + sys.ps1, "\n")
                .replace("\n" + sys.ps2, "\n")
                .strip("\n"),
            )


# Generated at 2022-06-23 15:57:09.015556
# Unit test for function untokenize
def test_untokenize():  # modified version of test in Lib/test/test_tokenize.py
    doTest = """def f():
    return"""

# Generated at 2022-06-23 15:57:10.955316
# Unit test for function printtoken
def test_printtoken():
    printtoken(3, "hello", (1, 1), (1, 2), "hello")
test_printtoken()



# Generated at 2022-06-23 15:57:15.528239
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    a = Untokenizer()
    iterable = [(1, "a"), (1, "b"), (0, "c"), (4, "\n"), (0, "d")]
    assert a.untokenize(iterable) == "abcd"
    assert a.tokens == ["a", "b", "c", "d"]
    assert a.prev_row == 1
    assert a.prev_col == 1



# Generated at 2022-06-23 15:57:21.500215
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    class MyException(Exception):
        pass

    try:
        raise StopTokenizing(MyException)
    except StopTokenizing as e:
        assert isinstance(e.__cause__, MyException)


# The string passed to detect_encoding() is the first two lines of
# the file.  detect_encoding() looks for the string coding= in those
# two lines, as well as a Unicode byte order mark.  If both are found,
# the byte order mark will be ignored.
_detect_encoding_cookie_re = re.compile(
    br"coding[:=]\s*([-\w.]+)"
    + rb"|"
    + BOM_UTF8.decode("ascii"),
    re.MULTILINE | re.DOTALL,
)



# Generated at 2022-06-23 15:57:32.298695
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    def eq(test, expected):
        if test != expected:
            print("Got     :", test)
            print("Expected:", expected)
            assert False
    eq(u.untokenize([("a", "")]), "a")
    eq(u.untokenize([("a", ""), ("b", "")]), "ab")
    eq(u.untokenize([("a", ""), ("b", ""), (1, "")]), "ab1")
    eq(u.untokenize([("a", ""), ("b", ""), (1, ""), (2, "")]), "ab12")
    eq(u.untokenize([("a", ""), ("b", ""), (1, ""), (2, ""), (3, "")]), "ab123")

# Generated at 2022-06-23 15:57:35.630633
# Unit test for function maybe
def test_maybe():
    m = maybe("a", "b")
    assert re.match(m, "a")
    assert re.match(m, "ab")
    assert re.match(m, "")
test_maybe()



# Generated at 2022-06-23 15:57:39.051042
# Unit test for function group
def test_group():
    assert group(r"\d\d", r"\w\w") == r"(\d\d|\w\w)"
    assert group(r"\d\d") == r"(\d\d)"



# Generated at 2022-06-23 15:57:39.834638
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    unt = Untokenizer()



# Generated at 2022-06-23 15:57:40.788582
# Unit test for constructor of class TokenError
def test_TokenError():
    err = TokenError()
    assert err



# Generated at 2022-06-23 15:57:43.040355
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    """
    >>> try:
    ...     raise StopTokenizing
    ... except StopTokenizing:
    ...     pass
    """



# Generated at 2022-06-23 15:57:44.293654
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:57:52.383533
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from contextlib import redirect_stdout

    text_tokens = []

    def tokeneater(*token_info):
        text_tokens.append(token_info)

    f = io.StringIO('x = "a\\nb"')
    tokenize_loop(f.readline, tokeneater)

    assert text_tokens == [(1, "x", (0, 0), (0, 1), "x = \"a\\nb\""),
                           (4, "=", (0, 2), (0, 3), "x = \"a\\nb\""),
                           (1, "a\nb", (0, 4), (1, 3), "x = \"a\\nb\"")]

test_tokenize_loop()


# Generated at 2022-06-23 15:57:56.697853
# Unit test for function untokenize
def test_untokenize():
    tests = [
        "\n",
        "123\n",
        "abc\n",
        "abc123\n",
        "abc(1,2)\n",
        "abc(1,2) + 3\n",
        "abc('a', 'b')\n",
        "abc('a', 'b') + 3\n",
        'def foo():\n    a = "a"\n    b = "b"\n    return a + b\n\n',
        'def foo():\n    a = 1\n    b = 2\n    return a + b\n\nabc("a", "b")\n',
    ]

# Generated at 2022-06-23 15:58:03.840110
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> Iterator[bytes]:
        for line in (
            b"# coding=utf-8",
            b"",
            b"def foo():",
            b'    print("Hello World!")',
            b'# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4',
        ):
            yield line
        raise StopIteration

    assert detect_encoding(readline) == ("utf-8", [])



# Generated at 2022-06-23 15:58:11.539335
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.add_whitespace((2, 5))
    assert untok.tokens == ["     "]
    untok.tokens = []
    untok.add_whitespace((2, 5))
    assert untok.tokens == ["     "]
    untok.tokens = []
    untok.add_whitespace((0, 0))
    assert untok.tokens == []



# Generated at 2022-06-23 15:58:19.601249
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from . import untokenize as ut
    from . import tokenize as tk
    from io import StringIO
    from contextlib import redirect_stdout

    example_python_code = '''def factorial(n):
    if not isinstance(n, int):
        raise TypeError("Factorial is only defined for integers.")
    elif n < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    elif n == 0:
        return 1
    else:
        return n * factorial(n - 1)

print(factorial(6))'''
    example_python_code_tokenized = tk.tokenize(StringIO(example_python_code).readline)
    example_python_code_untokenized = ut.Untokenizer().untokenize(example_python_code_tokenized)

# Generated at 2022-06-23 15:58:23.241927
# Unit test for function printtoken
def test_printtoken():
    def testcase(type, token, srow, scol, erow, ecol, line):
        printtoken(type, token, (srow, scol), (erow, ecol), line)
        return
    testcase(ERRORTOKEN, "", 1, 1, 1, 1, "")
# end unit test


# Generated at 2022-06-23 15:58:33.587571
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    from tokenize import tokenize
    from token import NAME, OP
    r = StringIO("def f(): pass\n")
    tokens = tokenize(r.readline)
    (token_type, token_string, start, end, token_line) = next(tokens)
    assert token_type == NAME
    assert token_string == "def"
    assert start == (1, 0)
    assert end == (1, 3)
    assert token_line == "def f(): pass\n"
    (token_type, token_string, start, end, token_line) = next(tokens)
    assert token_type == NAME
    (token_type, token_string, start, end, token_line) = next(tokens)
    assert token_type == OP

# Generated at 2022-06-23 15:58:41.136284
# Unit test for function tokenize
def test_tokenize():
    from blib2to3.pgen2.tokenize import tokenize as tkn
    from io import StringIO
    import sys

    def readline():
        return sys.stdin.readline()

    def tokeneater(type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
        (srow, scol) = xxx_todo_changeme2
        (erow, ecol) = xxx_todo_changeme3
        print(
            "%d,%d-%d,%d:\t%s\t%s" % (srow, scol, erow, ecol, tok_name[type], repr(token))
        )

    tkn(readline, tokeneater)



# Generated at 2022-06-23 15:58:45.200201
# Unit test for function tokenize
def test_tokenize():
    # Test with a function that reads one line at a time.
    def readline(prompt: Text = "") -> Text:
        return input(prompt)

    tokenize(readline, printtoken)



# Generated at 2022-06-23 15:58:57.705208
# Unit test for function printtoken
def test_printtoken():
    import io
    import inspect
    import tokenize
    from io import StringIO
    from textwrap import dedent

    s = "def foo():\n  pass"
    f = StringIO(s)
    expect_positions = [
        (0, 0, 0, 4),
        (0, 4, 0, 7),
        (0, 7, 0, 10),
        (1, 0, 1, 4),
        (1, 4, 1, 7),
        (1, 7, 1, 8),
    ]
    expect_types = ["NAME", "(", ")", ":", "NEWLINE", "INDENT"]
    expect_values = ["def", "", "", "", "", ""]
    assert len(expect_positions) == len(expect_types)
    assert len(expect_positions)

# Generated at 2022-06-23 15:59:06.113766
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more code\n"
        yield b"blah = True\n"
    encoding, lines = detect_encoding(readline().__next__)
    assert encoding == "iso-8859-1"
    assert b"".join(lines) == b"# coding: latin-1\n"

    def readline():
        yield b"#! /usr/bin/env python3\n"
        yield b'# -*- coding: ascii -*-\n'
        yield b"# vim:fileencoding=utf-8\n"
        yield b"from __future__ import print_function\n"
    encoding, lines = detect_encoding(readline().__next__)

# Generated at 2022-06-23 15:59:10.286108
# Unit test for function tokenize
def test_tokenize():
    import StringIO
    import token
    s = "def f(x): return 'abc' + x"
    f = StringIO.StringIO(s)
    l = tokenize(f.readline)
    for tok in l:
        print(tok)
# End unit test for function tokenize



# Generated at 2022-06-23 15:59:15.917655
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import sys

    import unittest

    # Issue 7672
    # Test samples provided by Marc-Andre Lemburg
    # (except sample 1 which is mine)

# Generated at 2022-06-23 15:59:19.649754
# Unit test for function maybe
def test_maybe():
    return all(
        maybe("a", "b", "c")
        == x
        for x in ["", "a", "b", "c", "aa", "ab", "ac", "ba", "bb", "bc", "ca", "cb", "cc"]
    )

# Generated at 2022-06-23 15:59:26.199435
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()

    untokenizer.add_whitespace((1, 0))
    assert untokenizer.tokens == []
    untokenizer.add_whitespace((1, 5))
    assert untokenizer.tokens == ["     "]
    untokenizer.add_whitespace((2, 5))
    assert untokenizer.tokens == ["     ", "\n     "]



# Generated at 2022-06-23 15:59:38.624481
# Unit test for function tokenize
def test_tokenize():
    def _make_readline(lines: List[Text]) -> Callable[[], Text]:
        def readline() -> Text:
            try:
                return lines.pop(0)
            except IndexError:
                return ""

        return readline

    def _readline_mock(s: Text, readline: Callable[[], Text]) -> None:
        if s == "":
            raise StopTokenizing
        return readline()

    readline = _make_readline(["foo = 'bar' # baz\n"])
    tokens = []

    def tokeneater(*args: object) -> None:
        tokens.append(args)

    tokenize_loop = tokenize(_readline_mock, tokeneater)

# Generated at 2022-06-23 15:59:40.248967
# Unit test for function printtoken
def test_printtoken():
    printtoken(ENCODING, 'token', (0,0), (1,1), 'line')

    # This code tests printtoken() and is
    # not meant to be executed



# Generated at 2022-06-23 15:59:43.043512
# Unit test for function printtoken
def test_printtoken():
    printtoken(3,'#',(0,0),(0,1),'#')
    printtoken(1,'#',(0,0),(0,1),'#')

# Generated at 2022-06-23 15:59:54.458981
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output, roundtrip=False):
        result = untokenize(input)
        if result != output:
            raise ValueError(
                "untokenize mismatched result:\n%r\n%r" % (result, output)
            )
        elif roundtrip:
            readline = iter(result.splitlines(1)).__next__
            list(generate_tokens(readline))


# Generated at 2022-06-23 16:00:00.092010
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"
    assert group(["a", "b", "c"]) == "(a|b|c)"
    assert group("a") == "(a)"



# Generated at 2022-06-23 16:00:08.379928
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import sys, tokenize
    untok = tokenize.Untokenizer()
    untok.compat = False
    def readline():
        try:
            return next(iter(lines))
        except StopIteration:
            raise EOFError
    def next_line():
        try:
            return next(iter(lines))
        except StopIteration:
            return ""
    lines = iter(["if 1:",
                  "  print('#indentation error')",
                  "  print('#another line')"])
    with tokenize.tokenize(readline) as tokens:
        pass
    print(untok.untokenize(tokens))
    lines = iter(["if 1:",
                  "  print('#indentation error')",
                  "print('#another line')"])

# Generated at 2022-06-23 16:00:20.243418
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def test(input, output):
        result = []
        tokenize_loop(iter(input.splitlines(keepends=True)).__next__, result.append)
        print(result)
        print(output)
        assert result == output
        print("ok")

    test("1\n", [(NUMBER, "1", (1, 0), (1, 1), "1\n")])
    test("1+2\n", [(NUMBER, "1", (1, 0), (1, 1), "1+2\n"), (OP, "+", (1, 1), (1, 2), "1+2\n"), (NUMBER, "2", (1, 2), (1, 3), "1+2\n")])

# Generated at 2022-06-23 16:00:24.168639
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(tok):
        print("%3d: %-15s  %-10r" % (tok[0], tok_name[tok[0]], tok[1]))


# Generated at 2022-06-23 16:00:28.305778
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.add_whitespace((1, 1))
    u.add_whitespace((1, 2))
    u.add_whitespace((2, 3))

    assert list(u.tokens) == ["\n", " "]



# Generated at 2022-06-23 16:00:32.501759
# Unit test for constructor of class TokenError
def test_TokenError():
    # Verify we can create an instance, and the args get set correctly
    exc = TokenError("Test")
    assert exc.args == ("Test",)
    # The default args should be an empty string
    exc = TokenError()
    assert exc.args == ("",)



# Generated at 2022-06-23 16:00:42.057531
# Unit test for function tokenize
def test_tokenize():
    r"""This tests tokenize by feeding it a small Python script and
    comparing the output to a list of expected tokens."""
    import io
    import token
    import tokenize
    r = repr

    script = dedent(
        """\
        # This script tests tokenize.
        a = 2*3 + 4*5
        print(a)
        """
    )


# Generated at 2022-06-23 16:00:45.270415
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    ut = Untokenizer()
    assert ut.tokens == []
    assert ut.prev_row == 1
    assert ut.prev_col == 0


# Generated at 2022-06-23 16:00:47.851306
# Unit test for constructor of class TokenError
def test_TokenError():
    tokenerror = TokenError("test")
    assert str(tokenerror) == "test"
    assert tokenerror.end == (0, 0)



# Generated at 2022-06-23 16:00:56.309755
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from types import GeneratorType
    from token import tok_name
    result = generate_tokens(StringIO('x = 1').readline)
    assert isinstance(result, GeneratorType)
    result = list(result)
    assert result[0][0] == tok_name[NAME]
    assert result[1][0] == tok_name[OP]
    assert result[2][0] == tok_name[NUMBER]
    assert result[3][0] == tok_name[ENDMARKER]

    def readline():
        yield 'x = 1'
        raise StopIteration

    result = generate_tokens(readline())
    assert isinstance(result, GeneratorType)
    result = list(result)
    assert result[0][0] == tok_name

# Generated at 2022-06-23 16:01:05.719793
# Unit test for function any
def test_any():
    assert "" == re.match(any("a", "b"), "").group()
    assert "" == re.match(any("a", "b"), "c").group()
    assert "b" == re.match(any("a", "b"), "b").group()
    assert "ba" == re.match(any("a", "b"), "ba").group()
    assert "ba" == re.match(any("a", "b"), "baa").group()
    assert "baa" == re.match(any("a", "b"), "baaa").group()



# Generated at 2022-06-23 16:01:14.743350
# Unit test for function group
def test_group():

    class DummyToken:
        def __init__(self, token_type: int, attr: Union[str, List[str]]) -> None:
            self.type = token_type
            self.attr = attr
        def __repr__(self) -> str:
            return "%s(%r)" % (self.type, self.attr)

    def _convert(token_list: List[DummyToken]) -> Tuple[List[DummyToken], str]:
        return token_list, ""

    def check_tokenize(expr: str, result: str) -> None:
        tokens, _ = tokenize("", bytearray(expr, 'latin1'), _convert)
        assert tokens == eval(result)


# Generated at 2022-06-23 16:01:20.741043
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    from tokenize import generate_tokens, untokenize

    text = 'def f(x): return 2*x\n'

    f = io.BytesIO(text.encode('utf-8'))
    tokens = generate_tokens(f.readline)

    newcode = untokenize(tokens)
    assert newcode == text

