

# Generated at 2022-06-23 15:51:18.322714
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("a", "bc") == "(a|bc)"



# Generated at 2022-06-23 15:51:19.235338
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError("testing TokenError exception")



# Generated at 2022-06-23 15:51:20.108862
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-23 15:51:23.740964
# Unit test for constructor of class TokenError
def test_TokenError():
    e = None  # type: Optional[TokenError]
    try:
        raise TokenError('test')
    except TokenError as exc:
        e = exc
    assert(str(e) == 'test')



# Generated at 2022-06-23 15:51:32.441879
# Unit test for function maybe
def test_maybe():
    PATTERN = "['`]"
    TEST = "'`\""
    assert re.match(maybe(PATTERN), TEST).group() == TEST
test_maybe()


# Tail end of ' string.
single3 = r"[^\\]'"
double3 = r'[^\\]"'

# For names, operators, etc.
ident_char = r"[\w\d_]";
# ident_chars = ident_char + any(ident_char)

# For a Name, Group(Name) or Name(...).
name = group(ident_char, any(ident_char)) + maybe("(");

# For a String prefix.

# Generated at 2022-06-23 15:51:33.662808
# Unit test for function maybe
def test_maybe():
    pass
    # assert maybe("ab", "cd") == "(ab|cd)?", maybe("ab", "cd")



# Generated at 2022-06-23 15:51:45.808388
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from test.support import gc_collect
    from test.support import check_impl_detail
    from difflib import unified_diff
    for module in token, tokenize:
        # see comment at end of file for _tokenize_pgen()
        u = module.Untokenizer()
        stream = StringIO("while 1:\n    print(1)\n")
        out = u.compat(tokenize._tokenize_pgen(stream.readline),
                       tokenize._tokenize_pgen(stream.readline))
        expected = textwrap.dedent("""\
                                    while 1:
                                        print (1)
                                    """)

# Generated at 2022-06-23 15:51:52.697113
# Unit test for function generate_tokens
def test_generate_tokens():
    import pprint
    import io


# Generated at 2022-06-23 15:52:05.148777
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize

    def test_op(op):
        test_untokenize.op = op
        return op

    def test_op2(op, op2):
        test_untokenize.op2 = op2
        return op, op2
    single3 = "'''"
    double3 = '"""'

# Generated at 2022-06-23 15:52:13.946409
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import BytesIO
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2.tokenize import generate_tokens, tokenize
    body = b"a,b,c"
    generator = generate_tokens(BytesIO(body).readline)
    tokens = list(generator)
    untok = Untokenizer()
    all_toks = list(tokenize(BytesIO(body).readline))
    assert untok.compat(tokens[0], iter(tokens[1:])) is None
    assert untok.untokenize(iter(all_toks)) == "a , b , c "



# Generated at 2022-06-23 15:52:23.109901
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from .pytokenize_helpers import tokenize_helper

    example = '''\
    a = 1
    b = 2
    print(a + b)
    '''


# Generated at 2022-06-23 15:52:25.728364
# Unit test for function any
def test_any():
    assert any('a') == '(a)*'
    assert any('a', 'b') == '(a|b)*'
    assert any('a', 'b', 'c') == '(a|b|c)*'



# Generated at 2022-06-23 15:52:32.224614
# Unit test for function tokenize_loop

# Generated at 2022-06-23 15:52:35.308014
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return input()
    tokenize_loop(readline, print)


# Some simple test cases

# Generated at 2022-06-23 15:52:39.241406
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?"
    assert maybe("a", "b") == "(a|b)?"
    assert maybe("a", "b", "c") == "(a|b|c)?"
    return

# Generated at 2022-06-23 15:52:48.730283
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.tokens = []
    u.add_whitespace((1, 2))
    assert u.tokens == ["  "]
    u.tokens = []
    u.add_whitespace((2, 2))
    assert u.tokens == ["  "]
    u.tokens = []
    u.add_whitespace((0, 2))
    assert u.tokens == ["  "]



# Generated at 2022-06-23 15:52:57.878094
# Unit test for function generate_tokens
def test_generate_tokens():
    """
    Test the generate_tokens() generator.

    This is done using the tokenize() function since it uses the
    generator extensively to tokenize a source string.
    """
    import tokenize, io

    source = "def f(): pass\n"
    g = generate_tokens(io.StringIO(source).readline)
    result = [tok for tok in g]

# Generated at 2022-06-23 15:53:08.327575
# Unit test for function generate_tokens
def test_generate_tokens():
    reset_tokenize()

    # Test that each line contains the correct number of tokens.
    def check_numtokens(readline, expected):
        numtokens, i = 0, 0
        for token in generate_tokens(readline):
            numtokens += 1
            i += 1
        if numtokens != expected:
            raise RuntimeError("I got %d tokens; expected %d" % (numtokens, expected))

    def readline():
        return test_data.readline()

    check_numtokens(readline, expected=138)
    test_data.seek(0)

    # Each element is a 2-tuple containing the number of tokens in the line
    # followed by the line containing the tokens.

# Generated at 2022-06-23 15:53:20.035054
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(sep: Text) -> Iterator[bytes]:
        yield b"\xef\xbb\xbf" + sep.encode("utf-8")
        yield b"3"
        return
    encoding, lines = detect_encoding(readlines("\n"))
    assert encoding == "utf-8-sig", repr(encoding)
    assert lines == [b"\n", b"3"], repr(lines)
    encoding, lines = detect_encoding(readlines("\r\n"))
    assert encoding == "utf-8-sig", repr(encoding)
    assert lines == [b"\r\n", b"3"], repr(lines)
    readlines = iter([b"\xef\xbb\xbf# coding=utf-8\n", b"3\n"]).__next

# Generated at 2022-06-23 15:53:32.276708
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 3
    u.prev_col = 4
    # new row
    u.add_whitespace((4, 1))
    assert u.prev_row == 4
    assert u.prev_col == 1
    assert u.tokens == ["\n"]
    # new col
    u.add_whitespace((4, 8))
    assert u.prev_row == 4
    assert u.prev_col == 8
    assert u.tokens == ["\n", "    "]
    # no change
    u.add_whitespace((4, 8))
    assert u.prev_row == 4
    assert u.prev_col == 8
    assert u.tokens == ["\n", "    "]
    # indent
    u.add_

# Generated at 2022-06-23 15:53:43.425544
# Unit test for function maybe
def test_maybe():
    assert maybe("b") == "(b)?", maybe("b")
    assert maybe("a", "b") == "(a|b)?", maybe("a", "b")
    assert maybe("") == "", maybe("")

whitespace = "[" + N + T + R + "]"

# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.

name = "[^" + T + N + R + "0-9)(][^" + T + N + R + "]*"

hexnumber = "0[xX]" + group(hexdigits, maybe(hexdigits))
octnumber = "0[oO]" + group(octdigits, maybe(octdigits))
binnumber = "0[bB]" + group(bindigits, maybe(bindigits))

# Generated at 2022-06-23 15:53:51.515194
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.tokens = ['a', 'b', 'c']

    u.add_whitespace((1, 4))
    assert u.tokens == ['a', 'b', 'c', '   ']

    u.add_whitespace((1, 3))
    assert u.tokens == ['a', 'b', 'c', '   ', ' ']

    u.add_whitespace((1, 2))
    assert u.tokens == ['a', 'b', 'c', '   ', ' ', ' ']

    u.add_whitespace((1, 1))
    assert u.tokens == ['a', 'b', 'c', '   ', ' ', ' ', ' ']



# Generated at 2022-06-23 15:54:00.718893
# Unit test for function untokenize
def test_untokenize():
    untok_filename = "test_untokenize.py"
    tok_filename = "test_tokenize.py"

    # Verify round-trip "read/write" of file
    with open(tok_filename) as tokfile, \
         open(untok_filename, "w") as untokfile:
        tokfile.seek(0)
        untokfile.write(
            untokenize(
                generate_tokens(tokfile.readline)
            )
        )
    with open(untok_filename, "r") as untokfile:
        assert untokfile.read() == open(tok_filename).read()

    # Verify round-trip "read/read"
    with open(tok_filename) as tokfile:
        readline = tokfile.readline
       

# Generated at 2022-06-23 15:54:10.564240
# Unit test for function detect_encoding
def test_detect_encoding():
    import tokenize
    from io import BytesIO
    import sys

    def test_cookie(encoding, first_line, second_line=None, expected=None):
        def get_line():
            if first_line is not None:
                line = first_line
                first_line = None
                return line
            return second_line

        if expected is None:
            expected = encoding
        result = tokenize.detect_encoding(get_line)
        assert result[0] == expected, (result[0], encoding, first_line,
                                       second_line)

    def test_bom(bom, encoding, expected=None):
        assert tokenize.detect_encoding(BytesIO(bom).readline)[0] == encoding
        if expected is None:
            expected = encoding

# Generated at 2022-06-23 15:54:12.781724
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 'a', (1,2), (2,3), 'b')


# Generated at 2022-06-23 15:54:25.821731
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test that tokenize_loop() is equivalent to tokenize()
    test_input = "one two three"
    tokens = []

    def tokenizer(
        type: int, token: Text, xxx_todo_changeme2: Tuple[int, int],
        xxx_todo_changeme3: Tuple[int, int], xxx_todo_changeme4: Text
    ) -> None:
        (start_row, start_col) = xxx_todo_changeme2
        (end_row, end_col) = xxx_todo_changeme3
        (line) = xxx_todo_changeme4
        assert line == test_input
        assert (start_row, start_col) == (1, 0)

# Generated at 2022-06-23 15:54:32.451271
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    ut = Untokenizer()
    ut.tokens = []
    ut.compat((NAME,'async'), [(NAME,'await'), (RPAR,')'), (RARROW,'->')])
    assert ut.tokens == ['async ', 'await ', ') -> '], repr(ut.tokens)


_compile = re.compile

# These replacements don't work if the keywords are unicode,
# but I'll deal with that later.

# Generated at 2022-06-23 15:54:40.516604
# Unit test for function tokenize_loop
def test_tokenize_loop():
    with open(__file__) as f:
        tokens = [
            x for x in generate_tokens(f.readline)
            if x[0] != tokenize.NL and x[0] != tokenize.COMMENT
        ]
    assert tokens
    # Verify that independent and dependent generators return the same results
    g1 = tokenize.generate_tokens(f.readline)
    g2 = tokenize.generate_tokens(f.readline)
    for i in range(len(tokens)):
        for g in (g1, g2):
            assert next(g) == tokens[i]



# Generated at 2022-06-23 15:54:48.706670
# Unit test for function printtoken
def test_printtoken():
  # Uncomment following line and next lines starting with printtoken will be
  # printed on the screen
  #printtoken = print
  printtoken(55, '{', (1, 1), (1, 1), '')
  printtoken(55, '=', (1, 1), (1, 2), '')
  printtoken(55, '}', (1, 1), (1, 1), '')
  printtoken(55, '-', (1, 1), (1, 2), '')
  printtoken(55, '=', (1, 1), (1, 2), '')
  printtoken(55, 'for', (1, 1), (1, 4), '')
  printtoken(55, '{', (1, 1), (1, 1), '')

# Generated at 2022-06-23 15:54:53.984909
# Unit test for function untokenize
def test_untokenize():
    # Helper to make testing easier.
    def roundtrip(src: Text) -> Text:
        result = untokenize(tokenize(StringIO(src).readline))
        return result

    assert roundtrip("def f(x):\n    return x**2") == "def f(x):\n    return x**2\n"
    assert roundtrip("def f( ):\n    pass\n") == "def f( ):\n    pass\n"
    assert (
        roundtrip(
            """def f():
    try:
        pass
    finally:
        pass"""
        )
        == """def f():
    try:
        pass
    finally:
        pass\n"""
    )
    assert roundtrip("f( )") == "f( )\n"

# Generated at 2022-06-23 15:55:05.595594
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    l = (
        (NAME, "x"),
        (OP, "+"),
        (NUMBER, "1"),
        (NEWLINE, "\n"),
        (INDENT, "    "),
        (NAME, "y"),
        (OP, "="),
        (NUMBER, "2"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (NAME, "z"),
        (OP, "="),
        (NUMBER, "3"),
        (NEWLINE, "\n"),
    )
    untok.compat(l[0], l[1:])
    assert untok.tokens == ["x + 1", "    y = 2", "z = 3"]



# Generated at 2022-06-23 15:55:12.180070
# Unit test for function tokenize
def test_tokenize():
    import io
    from tokenize import untokenize
    f = io.BytesIO(b"   1 + 2\n3*4\r\n")
    g = tokenize(f.readline)
    l = [next(g) for i in range(5)]
    print(l)
    print("Untokenized:", untokenize(l))



# Generated at 2022-06-23 15:55:19.332702
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        for line in io.BytesIO("# coding: latin-1\n# more stuff\n").readlines():
            yield line

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])

    def readline():
        for line in io.BytesIO("#!stuff\ncoding=utf-8\nmore stuff\n").readlines():
            yield line

    assert detect_encoding(readline) == ("utf-8", [b"#!stuff\n", b"coding=utf-8\n"])


# Generated at 2022-06-23 15:55:26.764839
# Unit test for function detect_encoding
def test_detect_encoding():
    def reader(s):
        for c in s:
            yield c
        yield ""

    def readline(s=b"# coding: latin-1\n"):
        return s

    e, ln = detect_encoding(readline)
    assert e == "iso-8859-1"
    assert ln == [b"# coding: latin-1\n"]

    def readline(s=b"#!/usr/bin/python\n# coding=latin-1\n"):
        return s

    e, ln = detect_encoding(readline)
    assert e == "iso-8859-1"
    assert ln == [b"#!/usr/bin/python\n", b"# coding=latin-1\n"]


# Generated at 2022-06-23 15:55:36.809268
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize, generate_tokens

    def _test():
        for i in range(2, 4):
            yield str(i)

        for token in [
            (NAME, "def"),
            (INDENT, "    "),
            (NAME, "f"),
            (OP, "("),
            (OP, ")"),
            (OP, ":"),
            (NEWLINE, "\n"),
            (NEWLINE, "\n"),
            (NAME, "return"),
            (NUMBER, "3"),
            (DEDENT, ""),
            (ENDMARKER, ""),
        ]:
            yield token

# Generated at 2022-06-23 15:55:47.469867
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import tokenize as b2t
    from .tokenize_rt import TokenInfo
    from blib2to3.pgen2.tokenize import detect_encoding

    def readline() -> str:
        if s:
            res = s[:1]
            s = s[1:]
            return res
        raise StopIteration


# Generated at 2022-06-23 15:55:59.229932
# Unit test for function untokenize

# Generated at 2022-06-23 15:56:08.630193
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from . import tokenize

    data = "def f(x): return 2*x\n"
    f = StringIO(data)
    tokens = tokenize.generate_tokens(f.readline)

    u = Untokenizer()
    result = u.compat((1, ""), tokens)
    assert result is None
    assert u.tokens == [
        "def ",
        "f",
        "(",
        "x",
        ")",
        ":",
        " ",
        "return ",
        "2",
        "*",
        "x",
        "\n",
    ]
test_Untokenizer_compat()



# Generated at 2022-06-23 15:56:17.019232
# Unit test for function generate_tokens
def test_generate_tokens():
    # By calling tokenize.generate_tokens(iter("1+1").next), we force
    # generate_tokens to read a line of input at a time, exercising the
    # 'readline' argument.
    def generator(s):
        for c in s:
            yield c
    g = generate_tokens(generator("1+1").__next__)
    t1 = next(g)
    t2 = next(g)
    t3 = next(g)
    t4 = next(g)
    assert t1 == (tokenize.NUMBER, "1", (1, 0), (1, 1), "1+1\n")
    assert t2 == (tokenize.OP, "+", (1, 1), (1, 2), "1+1\n")

# Generated at 2022-06-23 15:56:29.215559
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    from io import StringIO
    from unittest import TestCase

    class Tests(TestCase):

        def roundtrip(self, s):
            f = StringIO()
            g = StringIO(s)
            try:
                tokenize.tokenize(g.readline, untokenize.Untokenizer(f).generate)
            except tokenize.TokenError:
                # XXX what should really happen?
                pass
            self.assertEqual(s, f.getvalue())

        def test_roundtrip(self):
            self.roundtrip("while 1: pass\n")
            self.roundtrip('x = "foo#bar"\n')
            self.roundtrip('x = r"""#"""\n')
            self.roundtrip('values = (1,\n2)\n')

# Generated at 2022-06-23 15:56:32.147579
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO("def foo(): pass")
    tokens = tokenize.tokenize(r.readline)
    print(tokens)
    print("OK")



# Generated at 2022-06-23 15:56:43.856298
# Unit test for function untokenize
def test_untokenize():
    input1 = '''def f(x):
# comment
 return 2*x'''

    readline = iter(input1.splitlines(1)).__next__
    tokens = list(generate_tokens(readline))

    outline1 = untokenize(tokens)

    readline = iter(outline1.splitlines(1)).__next__
    tokens2 = list(generate_tokens(readline))

    outline2 = untokenize(tokens2)
    assert outline1 == outline2

    tokens = tokens[:-1] # Remove the last newline
    readline = iter(input1.splitlines(1)).__next__
    outline1 = untokenize(tokens)

    # Limited round-trip invariant for input

# Generated at 2022-06-23 15:56:46.261026
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing as e:
        pass



# Generated at 2022-06-23 15:56:55.806070
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?"
# End unit test for function maybe


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"\w+"

Hexnumber = r"0[xX][\da-fA-F]+[lL]?"
Binnumber = r"0[bB][01]+[lL]?"
Octnumber = r"0[oO][0-7]+[lL]?"

# Generated at 2022-06-23 15:57:01.866260
# Unit test for function group
def test_group(): # pylint: disable=c0111
    _group = group

    assert _group("a") == "(a)"
    assert _group("a", "b") == "(a|b)"
    assert _group("a", "b", "c") == "(a|b|c)"
    assert _group("a", "b|c") == "(a|b|c)"


# Generated at 2022-06-23 15:57:10.265129
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-23 15:57:12.177394
# Unit test for function any
def test_any():
    for alt in ["", "a", "ab", "aBc"]:
        assert any("abc") == alt
        assert any("abc") == alt

# Generated at 2022-06-23 15:57:13.973035
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    assert StopTokenizing is StopTokenizing



# Generated at 2022-06-23 15:57:22.096822
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.tokens.append("test")
    u.add_whitespace((1, 2))
    assert u.tokens == ["test", " "]
    u.tokens.clear()
    u.prev_row = 1
    u.prev_col = 2
    u.add_whitespace((1, 4))
    assert u.tokens == ["  "]
    u.add_whitespace((2, 2))
    assert u.tokens == ["  ", "\n"]



# Generated at 2022-06-23 15:57:22.666503
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    pass



# Generated at 2022-06-23 15:57:33.547044
# Unit test for method add_whitespace of class Untokenizer

# Generated at 2022-06-23 15:57:35.189998
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing as e:
        assert repr(e) == "TokenError()"


# Generated at 2022-06-23 15:57:44.531904
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from tokenize import tokenize as tokenize1
    from blib2to3.pytree import Leaf
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2 import driver as pgen_driver
    from typing import List

    untokenize = Untokenizer().untokenize

    def verify(source_code: str, tree: Leaf) -> None:
        tree_source = tree.prefix

        if not tree_source.endswith("\n"):
            tree_source += "\n"
        if tree_source != source_code:
            print('tree_source:')
            print(tree_source)
            print('source_code:')
            print(source_code)
            assert 0, "not equal"

        tree.prefix = ""
        assert tree

# Generated at 2022-06-23 15:57:46.008232
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # No tests needed - covered by test_tokenize
    pass



# Generated at 2022-06-23 15:57:56.200686
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    tokenize_loop(lambda: "x = 'abc'", lambda t, tt, s, e, l: untok.tokens.append((s, e, tt)))
    assert untok.untokenize([]) == "x = 'abc' "
    untok.tokens.clear()
    r = untok.untokenize([((1,2), (1,3), "a"), ((1,3), (1,4), "b")])
    assert r == "ab", repr(r)



# Generated at 2022-06-23 15:58:06.779717
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from blib2to3.pgen2.tokenize import tokenize, tok_name
    test_string = "if 1:\n  pass"
    expect_string = "if 1:\n  pass"
    result = []
    untokenizer = Untokenizer()
    for (token_type, token_string, start, end, line_text) in tokenize(
        test_string.splitlines(keepends=True).__iter__()
    ):
        result.append((tok_name[token_type], token_type, token_string, start, end))

# Generated at 2022-06-23 15:58:10.526639
# Unit test for function group
def test_group():
    # Unit test for function group
    assert group("a", "b") == "(a|b)"
    assert group("") == "()"
    assert group("abcd") == "(abcd)"
test_group()


# Generated at 2022-06-23 15:58:14.238413
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "2 ** 3 # XXX"
    rl = s.splitlines(keepends=True).__iter__()
    def eat(*a):
        print(a)
    tokenize_loop(rl.__next__, eat)



# Generated at 2022-06-23 15:58:17.845223
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("Some message")
    except TokenError as inst:
        assert inst.args[0] == "Some message"
    else:
        raise "assertion failed"



# Generated at 2022-06-23 15:58:28.457786
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    toker = Untokenizer()
    toker.compat((token.NAME, "a"), ((token.NAME, "b"),))
    assert toker.tokens == ["a ", "b "]
    toker.tokens = []
    toker.compat((token.DEDENT, ""), ())
    assert toker.tokens == []
    toker.tokens = []
    toker.compat((token.NAME, "a"), ((token.DEDENT, ""), (token.NAME, "b")))
    assert toker.tokens == ["a ", "b "]
    toker.tokens = []
    toker.compat((token.NAME, "a"), ((token.INDENT, "x"), (token.NAME, "b")))
    assert toker.tokens

# Generated at 2022-06-23 15:58:34.921380
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
  data = "foo bar\n  baz"
  ut = Untokenizer()
  ut.compat(("NAME", "foo"),
            [("NAME", "bar"),
             ("NEWLINE", "\n"),
             ("INDENT", "  "),
             ("NAME", "baz"),
             ("DEDENT", "")])
  assert ut.tokens.__repr__() == "['foo ', 'bar\\n', '  baz']"



# Generated at 2022-06-23 15:58:43.644500
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"\xef\xbb\xbf# coding=utf-8\n"
        yield b"# This is a simple test.\n"
        yield b"print(1+1)\n"

    encoding, lines = detect_encoding(readline())
    assert encoding == "utf-8"
    assert lines == [
        b"\xef\xbb\xbf# coding=utf-8\n",
        b"# This is a simple test.\n",
        b"print(1+1)\n",
    ]



# Generated at 2022-06-23 15:58:56.328077
# Unit test for function untokenize
def test_untokenize():
    import sys
    import io
    import unittest
    import test.support

    class TestUntokenize(unittest.TestCase):
        def setUp(self):
            self.save_stdout = sys.stdout
            self.io = io.StringIO()
            sys.stdout = self.io

        def tearDown(self):
            sys.stdout = self.save_stdout

        def test_single_string(self):
            code = rb"'''hi!'''"
            out = untokenize(generate_tokens(iter(code).__next__))
            self.assertEqual(out, "'''hi!'''")

        def test_simple_program(self):
            source = "print('hello world')\n"

# Generated at 2022-06-23 15:58:59.484728
# Unit test for function untokenize
def test_untokenize():
    py = "def f(): print('hi!')\n"
    t = list(generate_tokens(StringIO(py).readline))
    newcode = untokenize(t)
    assert newcode == py



# Generated at 2022-06-23 15:59:05.188579
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # bug reported when metaclass == ()
    u = Untokenizer()
    s = u.untokenize([(NAME, 'class'), (NAME, 'Foo'), (OP, '('), (OP, ')'),
                      (OP, ':'), (NEWLINE, '\n'), (INDENT, ''), (OP, 'pass'),
                      (DEDENT, '')])
    assert s == 'class Foo():\n    pass\n'
    if not False:
        pass
    else:
        pass



# Generated at 2022-06-23 15:59:15.583401
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    from blib2to3.pgen2.tokenize import tokenize, generate_tokens, tok_name

    s = "def f(x): return 'has 3 quotes'"
    f = StringIO(s)
    tokens = list(generate_tokens(f.readline))
    for tok in tokens:
        print(tok_name[tok[0]], tok[1], tok[2])
        g = tokenize(f.readline)  # reinitialize the generator
        tokens = list(g)
        for tok in tokens:
            print(tok_name[tok[0]], tok[1], tok[2])
            #write_results(tok, tok[1])  # tok[1] is the token string
   

# Generated at 2022-06-23 15:59:26.568784
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # Test simple case
    u = Untokenizer()
    stream = [(NUMBER, "1"), (STRING, '"spam"'), (NEWLINE, "\n"), (NUMBER, "2")]
    assert u.compat(stream[0], stream[1:]) == "1 spam\n2 "
    # Test indents
    u = Untokenizer()
    stream = [(INDENT, "  "), (NUMBER, "1"), (NEWLINE, "\n"), (DEDENT, "")]
    assert u.compat(stream[0], stream[1:]) == "  1 \n"
    # Test dedents after two newlines
    u = Untokenizer()

# Generated at 2022-06-23 15:59:30.524428
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group(["a", "b"]) == "(a|b)"
    assert group("a", ["b", "c"]) == "(a|b|c)"


# Generated at 2022-06-23 15:59:31.305962
# Unit test for function any
def test_any():
    assert any("foo", "bar") == "(foo|bar)*"



# Generated at 2022-06-23 15:59:43.002571
# Unit test for function maybe
def test_maybe():
    assert maybe(".") == "(\.)?"


# All the raw strings here are for use inside character sets []
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"[a-zA-Z_]\w*"

Hexnumber = r"0[xX][\da-fA-F]+[lL]?"
Octnumber = r"0[oO]?[0-7]+[lL]?"
Binnumber = r"0[bB][01]+[lL]?"

# Generated at 2022-06-23 15:59:49.299847
# Unit test for function generate_tokens
def test_generate_tokens():
    def tokenize_print(s):
        print("========")
        for t in generate_tokens(StringIO(s).readline):
            print(t)

    tokenize_print("\n")
    tokenize_print(" 1 +  2")
    tokenize_print('if 1: # decorator\n  return None\n')


# Generated at 2022-06-23 15:59:55.829985
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    f = Untokenizer()
    test_tokens = [
        ("NUMBER", "1"),
        ("NEWLINE", "\n"),
        ("NUMBER", "2"),
        ("NEWLINE", "\n"),
        ("INDENT", "    "),
        ("NUMBER", "3"),
        ("ENDMARKER", ""),
    ]
    result = f.compat(next(iter(test_tokens)), iter(test_tokens))
    assert f.tokens == ["1 ", "2 ", "    3 "]



# Generated at 2022-06-23 16:00:00.972697
# Unit test for function any
def test_any():
    assert any(r"a") == "(a)*"
    assert any(r"a", r"b") == "(a|b)*"
    assert any(r"a|b") == "((a|b))*"


# Generated at 2022-06-23 16:00:08.802983
# Unit test for function tokenize
def test_tokenize():
    import io
    from tokenize import untokenize, NUMBER, STRING, NAME, OP


    def tokeneater(type, token, start, end, line):
        print("%d,%d-%d,%d:\t%s\t%s" % (start + (type, token)))


    text = "1 + 1\n'string' b 'string'"
    f = io.StringIO(text)
    f.seek(0)
    tokenize(f.readline, tokeneater)
    f.seek(0)
    g = tokenize(f.readline)
    type, token, start, end, line = next(g)
    assert type == NUMBER and token == "1"
    type, token, start, end, line = next(g)

# Generated at 2022-06-23 16:00:20.625664
# Unit test for function detect_encoding
def test_detect_encoding():
    def getlines(string):
        return iter(string.splitlines(True))

    def check(s, encoding, lines):
        real_encoding, real_lines = detect_encoding(getlines(s))
        assert real_encoding == encoding and lines == real_lines


# Generated at 2022-06-23 16:00:29.815705
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        raise StopIteration

    assert detect_encoding(readline) == ("utf-8", [])

    def readline() -> bytes:
        return BOM_UTF8 + "test"

    assert detect_encoding(readline) == ("utf-8-sig", [BOM_UTF8])

    def readline() -> bytes:
        return "# -*- coding: utf-8 -*-\n"

    assert detect_encoding(readline) == ("utf-8", ["# -*- coding: utf-8 -*-\n"])

    def readline() -> bytes:
        return "# coding: iso-8859-1\n"


# Generated at 2022-06-23 16:00:31.630915
# Unit test for function any
def test_any():
    assert regex(any("a", "b")) == regex("(a|b)*")



# Generated at 2022-06-23 16:00:35.357819
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    l = tokenize(StringIO("print('42')").readline)
    l1 = list(l)
    result = u.untokenize(l1)
    expected = "print('42')"
    assert result == expected



# Generated at 2022-06-23 16:00:38.812871
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO

    s = StringIO("def f(x, y=42): return x + y\n")
    tokenize(s.readline)



# Generated at 2022-06-23 16:00:48.199395
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import unittest
    import io

    class TestTokenize(unittest.TestCase):
        def test_untokenize(self):
            untok = Untokenizer()
            iterable = [(1, "a"), (4, "4"), (4, "4"), (53, "b"), (0, "")]
            self.assertEqual(untok.untokenize(iterable), "a 44b ")

    suite = unittest.TestLoader().loadTestsFromTestCase(TestTokenize)
    unittest.TextTestRunner(stream=io.StringIO(), verbosity=2).run(suite)



# Generated at 2022-06-23 16:00:49.147267
# Unit test for constructor of class TokenError
def test_TokenError():
    # All tests passed!
    TokenError()



# Generated at 2022-06-23 16:00:52.720969
# Unit test for function tokenize
def test_tokenize():
    with open("tokenize_tests.txt") as file:
        tokenize(file.readline)
    from io import StringIO

    tokenize(StringIO("1 + 1").readline)  # test with .readline() interface
# End unit test



# Generated at 2022-06-23 16:01:05.725463
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from blib2to3.pgen2.tokenize import tokenize_loop
    from blib2to3.pgen2.tokenize import TokenInfo

    def tokenize_loop_generator(line_iterable):
        for line in line_iterable:
            for token in generate_tokens(lambda : line):
                yield token

    sample_input = [
        "def func(x): return x ** 2\n",
        "print(func(2) + 3)\n",
    ]


# Generated at 2022-06-23 16:01:14.745056
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    assert unt.untokenize([(NUMBER, "1"), (NAME, "a")]) == "1 a"
    unt = Untokenizer()
    assert unt.untokenize([(NUMBER, "1"), (NAME, "a"), (NEWLINE, "\n")]) == "1 a\n"
    unt = Untokenizer()
    assert unt.untokenize([(NUMBER, "1"), (NAME, "a"), (NEWLINE, "\n"), (NUMBER, "2")]) == "1 a\n2"
    unt = Untokenizer()

# Generated at 2022-06-23 16:01:24.976922
# Unit test for function generate_tokens
def test_generate_tokens():
    import keyword

    # This is used in the following test