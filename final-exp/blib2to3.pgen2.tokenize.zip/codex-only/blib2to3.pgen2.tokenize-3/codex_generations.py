

# Generated at 2022-06-23 15:51:18.061758
# Unit test for function any
def test_any():
    assert any("a", "bc") == "(a|bc)*"



# Generated at 2022-06-23 15:51:29.280327
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize, io

    # Round-trip test.
    def test_one(s):
        result = [
            (toktype, tok, start, end, line[start:end])
            for toktype, tok, start, end, line in tokenize.generate_tokens(io.StringIO(s).readline)
        ]
        text = tokenize.untokenize(result)
        readline = io.StringIO(text).readline
        result2 = [
            (toktype, tok, start, end, line[start:end])
            for toktype, tok, start, end, line in tokenize.generate_tokens(readline)
        ]
        text2 = tokenize.untokenize(result2)
        return text, text2


# Generated at 2022-06-23 15:51:36.663136
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # untokenize(iterable)
    u = Untokenizer()
    t = u.tokens
    t.append(3)
    def g():
        yield (NAME, u"NaMe", (1, 0), (1, 3), "NaMe")
        yield (NUMBER, u"0", (1, 4), (1, 4), "0")
        yield (ASYNC, u"async", (1, 5), (1, 9), "async")
        yield (AWAIT, u"await", (1, 10), (1, 14), "await")
        yield (INDENT, u"", (1, 15), (1, 15), "")
        yield (DEDENT, u"", (1, 16), (1, 16), "")

# Generated at 2022-06-23 15:51:45.408020
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    """With the given inputs, the result of untokenize should equal 'for i\n  print i\n'"""
    ut = Untokenizer()
    iterable = [(5, 'i'), (57, 'print'), (1, ' '), (1, 'i'), (4, '\n')]
    assert ut.compat((0, 'for'), iterable) == None
    assert ut.compat((57, 'print'), iterable) == None
    assert ut.compat((0, 'for'), iterable) == None
    assert ut.untokenize(iterable) == 'for i\n  print i\n'



# Generated at 2022-06-23 15:51:46.993680
# Unit test for function group
def test_group():
    assert group("foo", "bar") == "(foo|bar)"


# Helper for _compile

# Generated at 2022-06-23 15:51:57.858084
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    if not hasattr(token, "COMMENT"):
        return  # no tests possible

# Generated at 2022-06-23 15:52:02.919471
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
    assert any("a", "bb") == "(a|bb)*"
    assert any("a", "bb", "c") == "(a|bb|c)*"



# Generated at 2022-06-23 15:52:10.397065
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    # test for compatibility mode
    u.compat((0, "def"), [(0, " "), (0, "foo"), (0, " "), (0, "(")])
    assert u.tokens[0] == "def "
    assert u.tokens[1] == "foo "
    assert u.tokens[2] == "( "
    # test add_whitespace()
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 3))
    assert u.tokens == ["   "]
    # test untokenize() with normal mode
    u = Untokenizer

# Generated at 2022-06-23 15:52:13.909309
# Unit test for function maybe
def test_maybe():
    #assert maybe("ab", "c") == "(ab|c)?"
    #assert maybe("ab", "c") == "(?:ab|c)?"
    return "ok"

# Support for two kinds of string prefixes



# Generated at 2022-06-23 15:52:17.325500
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_col = 10
    ut.add_whitespace((1, 20))
    assert ut.tokens == [" " * 10]

spaces = re.compile(" +")


# Generated at 2022-06-23 15:52:20.267195
# Unit test for function printtoken
def test_printtoken():
    bom = BOM_UTF8.decode('utf-8')
    printtoken(ENCODING, bom, (0, 0), (0, len(bom)), bom)



# Generated at 2022-06-23 15:52:25.572334
# Unit test for function tokenize
def test_tokenize():
    import re
    import tokenize
    import io
    import unittest
    import test.support
    test.support.requires("refleak")

    f = io.StringIO("def foo(): pass")
    tokens = tokenize.tokenize(f.readline)
    it = iter(tokens)
    # Skip to the string "pass".
    while True:
        tok = next(it)
        if tok[1] == "pass":
            break
    assert tok == (tokenize.NAME, "pass", (1, 10), (1, 14), "\n")
    tok = next(it)
    assert tok == (tokenize.NEWLINE, "\n", (1, 14), (1, 15), "")
    tok = next(it)

# Generated at 2022-06-23 15:52:26.764293
# Unit test for constructor of class TokenError
def test_TokenError():
    exc = TokenError()
    assert exc.args == ()



# Generated at 2022-06-23 15:52:37.183874
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-'
        yield b'import sys'
        raise StopIteration

    enc, lines = detect_encoding(readline)
    assert enc == "iso-8859-1"

    def readline():
        yield b'#!/usr/bin/env python'
        yield b'# -*- coding: latin-1 -*-'
        yield b'import sys'
        raise StopIteration

    enc, lines = detect_encoding(readline)
    assert enc == "iso-8859-1"

    def readline():
        yield b'#!/usr/bin/env python'
        yield b'# -*- coding: ascii -*-'
        yield b'import sys'
        raise StopIteration


# Generated at 2022-06-23 15:52:47.338344
# Unit test for function maybe
def test_maybe():
    print(maybe("hi", "bye"))


# All the tokens recognized; the order of this list is important

# Generated at 2022-06-23 15:52:56.237930
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 5
    untok.prev_col = 3
    untok.tokens = []
    untok.add_whitespace((5,5))
    assert untok.tokens == []
    untok.add_whitespace((5,9))
    assert untok.tokens == [" " * 4]
    untok.add_whitespace((6,3))
    assert untok.tokens == [" " * 4, "\n"]
    untok.add_whitespace((6,9))
    assert untok.tokens == [" " * 4, "\n", " " * 4]
    untok.add_whitespace((7,3))

# Generated at 2022-06-23 15:52:57.510976
# Unit test for function tokenize

# Generated at 2022-06-23 15:53:08.003864
# Unit test for function tokenize
def test_tokenize():
    import unittest
    import codecs
    import io

    class TestTokenize(unittest.TestCase):
        def setUp(self):
            self.test_cases = [
                ("test/test_tokenize/tokenize_test0.txt", "test/test_tokenize/tokenize_test0_output.txt"),
                ("test/test_tokenize/tokenize_test1.txt", "test/test_tokenize/tokenize_test1_output.txt"),
            ]

        def test_tokenize(self):
            for filename, correct_output in self.test_cases:
                with codecs.open(filename, "r", "utf-8") as input, codecs.open(correct_output, "r", "utf-8")\
                        as correct_output_file:
                    correct_output_

# Generated at 2022-06-23 15:53:19.968650
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # Check using the add_whitespace method directly
    untokenize = Untokenizer()
    untokenize.prev_row = 1
    untokenize.prev_col = 0
    untokenize.add_whitespace((1, 1))
    assert untokenize.tokens == [" "], untokenize.tokens
    untokenize.add_whitespace((1, 0))
    assert untokenize.tokens == [" ", ""], untokenize.tokens
    untokenize.add_whitespace((1, 2))
    assert untokenize.tokens == [" ", "", "  "], untokenize.tokens
    untokenize.add_whitespace((2, 0))
    assert untokenize.tokens == [" ", "", "  ", "\n"], unt

# Generated at 2022-06-23 15:53:22.968986
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, '2.3', (3, 4), (3, 6), "if not var:")


# regex for single-character operators
_single_char_operators = re.compile('[><!=]=|[~&\|]')


# Generated at 2022-06-23 15:53:28.806018
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    s = "if 1:\n    print(2)"
    r = io.BytesIO(s.encode())
    result = tokenize.untokenize(tokenize.tokenize(r.readline))
    assert result == s



# Generated at 2022-06-23 15:53:38.280472
# Unit test for function maybe
def test_maybe():
    test_data = [
        ("(a|b)?", "", ""),
        ("(a|b)?", "a", "a"),
        ("(a|b)?", "ab", "a"),
        ("(a|b)?", "b", "b"),
        ("(a|b)?", "bc", "b"),
        ("(a|b)?", "abc", "a"),
    ]
    for regex, text, result in test_data:
        assert result == re.match(regex, text).group(0), (regex, text)
# End unit test for function maybe


# Helper for header decoding:

# Generated at 2022-06-23 15:53:40.160282
# Unit test for constructor of class TokenError
def test_TokenError():
    exc = TokenError("error_message")
    assert exc.args == ("error_message",)



# Generated at 2022-06-23 15:53:43.831235
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    s = StringIO("print # hi\n+ 1\n")
    for t in generate_tokens(s.readline):
        tok_name[t[0]], t[1] # Check groups are correct



# Generated at 2022-06-23 15:53:48.254313
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    result = untok.compat(
        (NAME, "def"),
        [(NAME, "f"), (OP, "("), (NAME, "x"), (OP, ")"), (OP, ":"), (NEWLINE, "\n")],
    )
    assert result is None
    assert "".join(untok.tokens) == "def f ( x ) :\n"



# Generated at 2022-06-23 15:53:49.868471
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError as e:
        pass



# Generated at 2022-06-23 15:53:54.336997
# Unit test for function group
def test_group():
    assert group("a") == "a"
    assert group("a", "b") == "(a|b)"
    assert group(["a", "b"]) == "(a|b)"
    assert group("(", r"\(", "[") == "(\\(|\\[|\\()"


# Generated at 2022-06-23 15:54:00.260747
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    try:
        raise TokenError()
    except TokenError:
        pass
    try:
        raise TokenError("")
    except TokenError:
        pass
    try:
        raise TokenError("", "")
    except TokenError:
        pass



# Generated at 2022-06-23 15:54:09.514548
# Unit test for function detect_encoding
def test_detect_encoding():
    readline = iter([
        "{}\n".format(x).encode() for x in [
            '# -*- coding: ascii -*-',
            'a = 1',
            '',
            '# -*- coding: latin-1 -*-',
            'b = 2',
            '',
            '# coding: utf-8',
            'c = 3',
        ]
    ]).__next__

    def readlines():
        return readline(), readline(), readline()

    def test_encoding(expected):
        assert detect_encoding(readlines)[0] == expected

    test_encoding('ascii')
    test_encoding('iso-8859-1')
    test_encoding('utf-8')


# Generated at 2022-06-23 15:54:16.093662
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    global token, tokenize
    import re
    import blib2to3.pygram as pygram
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.driver as driver
    pygram.init_grammar(pygram.python_grammar_no_print_statement)
    parse._parse = parse._parse_with_tokens
    # Try the Untokenizer on a selection of grammatically correct code fragments.

# Generated at 2022-06-23 15:54:19.071418
# Unit test for function any
def test_any():
    assert any("a", "b", "c") == "(a|b|c)*"


# Generated at 2022-06-23 15:54:31.620458
# Unit test for function generate_tokens
def test_generate_tokens():

    def check_token_equal(received: TokenInfo, expected: TokenInfo) -> None:
        (re_type, re_token, re_spos, re_epos, re_line) = received
        (ex_type, ex_token, ex_spos, ex_epos, ex_line) = expected
        if not isinstance(re_type, type(ex_type)):
            raise AssertionError("Expected %s, found %s" % (type(ex_type), type(re_type)))
        if re_type != ex_type:
            raise AssertionError("Expected %s, found %s" % (ex_type, re_type))

# Generated at 2022-06-23 15:54:41.780298
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test that StopTokenizing is caught
    import io
    from test import support
    from blib2to3.pgen2.tokenize import STOP

    src = 'raise StopTokenizing()\n#\n'
    readline = io.StringIO(src).readline

    for type, token, start, end, line in generate_tokens(readline):
        assert type != STOP
    support.unlink(support.TESTFN)


# these strings are used for detecting numeric literals

# Generated at 2022-06-23 15:54:46.025650
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    st = StopTokenizing("stop tokenizing")
    assert str(st) == "stop tokenizing"
    assert st.args[0] == "stop tokenizing"



# Generated at 2022-06-23 15:54:47.364687
# Unit test for constructor of class TokenError
def test_TokenError():
    err = TokenError()
    assert str(err) == "TokenError"



# Generated at 2022-06-23 15:54:51.276168
# Unit test for function generate_tokens
def test_generate_tokens():
    a = generate_tokens('a = 1')
    print(next(a))
    print(next(a))
    print(next(a))

# Generated at 2022-06-23 15:54:54.098794
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "13", (0,0), (0,2), "")
test_printtoken()



# Generated at 2022-06-23 15:54:56.206227
# Unit test for function any
def test_any():
    assert any("abc") == "(a|b|c)*"



# Generated at 2022-06-23 15:54:58.219164
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:55:00.157258
# Unit test for function printtoken
def test_printtoken():
    for token in generate_tokens(lambda: "a"):
        printtoken(*token)
    return


# Generated at 2022-06-23 15:55:10.908151
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    from io import BytesIO
    from io import TextIOWrapper
    from io import SEEK_END
    sample_code = b"""def f():
    return 1
"""
    b = BytesIO(sample_code)
    stream = TextIOWrapper(b, encoding="utf-8")
    stream.seek(0, SEEK_END)
    u.compat(
        (ENCODING, "utf-8"),
        generate_tokens(lambda: b.getvalue().decode("utf-8")),
    )
    assert u.untokenize([]) == sample_code.decode("utf-8")



# Generated at 2022-06-23 15:55:16.603982
# Unit test for function maybe
def test_maybe():
    assert maybe('a') == '(a)?', maybe('a')
    assert maybe('ab') == '(ab)?', maybe('ab')
    assert maybe('abc') == '(abc)?', maybe('abc')
    assert maybe('a', 'ab') == '(a|ab)?', maybe('a', 'ab')
    assert maybe('a', 'ab', 'abc') == '(a|ab|abc)?', maybe('a', 'ab', 'abc')



# Generated at 2022-06-23 15:55:18.074416
# Unit test for function maybe
def test_maybe():
    # ? should match either 0 or 1 of its preceding RE:
    assert maybe("a", "b") == "ab?"



# Generated at 2022-06-23 15:55:25.748790
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    tokens = [
        (NUMBER, "0", (1, 0), (1, 0), "\n"),
        (NEWLINE, "", (1, 0), (1, 0), "\n"),
        (INDENT, "    ", (1, 0), (1, 0), "\n"),
        (NAME, "a", (1, 4), (1, 4), "\n"),
        (NEWLINE, "", (1, 4), (1, 4), "\n"),
        (DEDENT, "", (1, 8), (1, 8), "\n"),
        (NAME, "print", (1, 8), (1, 8), "\n"),
    ]
    u = Untokenizer()
    assert u.compat(tokens[0], tokens[1:]) == "\n    a\n"


# Generated at 2022-06-23 15:55:35.960477
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # You wrote me a function, and now you're testing it?  I'm flattered.
    # (But we're not going to test printtoken in particular, since its
    # output might change between Python releases, depending on how its
    # author feels about leading spaces on continuation lines.)
    s = "def f(x): return '''\nblah\n'''\n"
    tokeneater = []
    def savetoken(*token_info):
        tokeneater.append(token_info)
    tokenize_loop(s.splitlines().__iter__, savetoken)

# Generated at 2022-06-23 15:55:37.296315
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass



# Generated at 2022-06-23 15:55:46.267463
# Unit test for function tokenize
def test_tokenize():
    import io
    import token

    def tokenize(code: bytes) -> Iterator[Tuple[int, Text, Coord, Coord, Text]]:
        f = io.BytesIO(code)
        tokenize_loop(f.readline, None)

    # ReadPlainString, ReadBytes and Read() have been moved to helpers.py
    # These tests remain to verify that tokenize() handles them correctly.

    # Plain string literals

# Generated at 2022-06-23 15:55:55.402336
# Unit test for function tokenize
def test_tokenize():
    import io

    r = io.StringIO(
        "def foo(): pass\n" +
        "  \t\n" +
        "def bar(): pass\n" +
        "\n" +
        "# foo\n" +
        "def baz(): pass"
    )

    import tokenize

    result = []
    def tokeneater(type, token, start, end, line):
        result.append((type, token, start, end, line))

    tokenize.tokenize(r.readline, tokeneater)
    return result



# Generated at 2022-06-23 15:55:58.721836
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from test.support import run_unittest
    from test import test_tokenize
    run_unittest(test_tokenize.UntokenizeTestCase)

# Helper for tokenize

# Generated at 2022-06-23 15:56:03.620992
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    from tokenize import generate_tokens
    from io import BytesIO
    r = BytesIO(b'def foo(a,b):\n    return a+b\n')
    g = generate_tokens(r.readline)
    print(untokenize(g))

# Generated at 2022-06-23 15:56:05.400998
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "123", (1, 0), (1, 3), "123\n456")



# Generated at 2022-06-23 15:56:07.319814
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError(1, "test_msg")

# Functions used for the string.Template hack



# Generated at 2022-06-23 15:56:09.176683
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:56:11.571990
# Unit test for function any
def test_any():
    assert "ababaababa" == re.sub(
        any('ab'), r'\1', 'ababaababa', flags=re.VERBOSE)


# Generated at 2022-06-23 15:56:14.550616
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    try:
        raise TokenError("")
    except TokenError:
        pass
    try:
        raise TokenError("abc")
    except TokenError:
        pass



# Generated at 2022-06-23 15:56:17.550859
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b'foo = "bar"\n')
    tokens = tokenize.generate_tokens(r.readline)
    print(tokens)
    print(list(tokens))
    print(list(tokens))

test_generate_tokens()


# Generated at 2022-06-23 15:56:27.754454
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    unt = Untokenizer()
    from blib2to3.pytree import Leaf as L
    from blib2to3.pgen2.token import tokenize_list

# Generated at 2022-06-23 15:56:38.037612
# Unit test for function maybe
def test_maybe():
    assert maybe("foo") == "(?:foo)?"


whitespace = r"[ \f\t]*"
# Note, \v isn't in the set of whitespace characters in the token module.
# So, we leave it out here.
comment = r"#[^\r\n]*"
ignore = whitespace + any(r"\\\r?\n" + whitespace) + maybe(comment)
name = r"[a-zA-Z_]\w*"

hexnumber = r"0[xX](?:_?[0-9a-fA-F])+"
binnumber = r"0[bB](?:_?[01])+"
octnumber = r"0[oO](?:_?[0-7])+"

# Generated at 2022-06-23 15:56:43.419792
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    import doctest
    import io
    import sys

    doctest.run_docstring_examples(
        StopTokenizing,
        {
            "Exception": StopTokenizing,
            "tokenize": tokenize,
            "io": io,
            "sys": sys,
        },
    )



# Generated at 2022-06-23 15:56:47.317213
# Unit test for function printtoken
def test_printtoken():
    printtoken(1,2,(3,4),(5,6),7)
    print(
        '3,4-5,6:\tNUMBER\t"2"',
    )


# Generated at 2022-06-23 15:56:56.634663
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import tokenize
    # tokenize.generate_tokens accepts a readline argument, but
    # token.generate_tokens (for backwards compatibility) doesn't
    def readline(s):
        for c in s:
            yield c
    gt = tokenize.generate_tokens(readline("if 1: #SPAM"))
    assert next(gt) == (token.NAME, "if", (1, 0), (1, 2), "if 1: #SPAM")
    assert next(gt) == (token.NUMBER, "1", (1, 3), (1, 4), "if 1: #SPAM")
    assert next(gt) == (token.OP, ":", (1, 4), (1, 5), "if 1: #SPAM")
    assert next(gt)

# Generated at 2022-06-23 15:57:05.289686
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()
    untokenizer.add_whitespace((1, 0))
    untokenizer.tokens.append("a")
    untokenizer.add_whitespace((1, 1))
    untokenizer.tokens.append("a")
    untokenizer.add_whitespace((1,  2))
    untokenizer.tokens.append("a")
    untokenizer.add_whitespace((2, 0))
    assert untokenizer.tokens == ["a", "a", "a", "\na"]


# Generated at 2022-06-23 15:57:07.251808
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:57:19.126036
# Unit test for function tokenize
def test_tokenize():
    import io

    # test on simple tests from tokenize docstring
    def readline(buf):
        for line in buf.splitlines(keepends=True):
            yield line

    buf = "a = 1 + 2\n"
    result1 = [
        (NUMBER, "1", (1, 4), (1, 5), "a = 1 + 2\n"),
        (OP, "+", (1, 6), (1, 7), "a = 1 + 2\n"),
        (NUMBER, "2", (1, 8), (1, 9), "a = 1 + 2\n"),
    ]
    tokeneater = iter(result1).__next__
    tokenize_loop(readline(buf), tokeneater)

    buf = '''
"a = 1 + 2"
'''

    result2

# Generated at 2022-06-23 15:57:21.693883
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("testing")
    except TokenError as exc:
        assert str(exc) == "testing", "Failed to initialize Exception"



# Generated at 2022-06-23 15:57:30.009390
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u=Untokenizer()
    u.add_whitespace((1,1))
    assert "".join(u.tokens) == ""
    u.add_whitespace((4,4))
    assert "".join(u.tokens) == "\n\n"
    u.add_whitespace((4,6))
    assert "".join(u.tokens) == "\n\n  "
    u.add_whitespace((6,1))
    assert "".join(u.tokens) == "\n\n  \n\n"


# Generated at 2022-06-23 15:57:39.819055
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_col = 10
    ut.prev_row = 2
    ut.add_whitespace((2,5))
    assert(ut.tokens == [" " * 5])
    ut.add_whitespace((2,10))
    assert(ut.tokens == [" " * 5])
    ut.add_whitespace((2,11))
    assert(ut.tokens == [" " * 5, " "])
    ut.tokens = []
    ut.add_whitespace((2,10))
    assert(ut.tokens == [" " * 10])
    ut.add_whitespace((3,5))
    assert(ut.tokens == [" " * 10, "\n    "])
    ut.tokens = []
    ut

# Generated at 2022-06-23 15:57:41.113089
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:57:46.805531
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    from tokenize import generate_tokens

    r = io.StringIO("def f(x): return 2*x")
    g = generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in g:
        if toknum == token.NAME and tokval == "f":
            break
    else:
        assert False, "function f not found"



# Generated at 2022-06-23 15:57:58.912908
# Unit test for function maybe
def test_maybe():
    # here "a" must be preceded by whitespace
    # otherwise it is part of the regular expression.
    re.compile(maybe("a") + "a")
    re.compile(maybe("\n") + "\n")


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any("\\\n" + Whitespace)  # continued lines
Name = r"[a-zA-Z_]\w*"

Hexnumber = r"0[xX][\da-fA-F]+[lL]?"
Octnumber = r"0[oO]?[0-7]+[lL]?"


# Generated at 2022-06-23 15:58:01.910097
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("foo")
    except TokenError:
        pass
    else:
        raise TestFailed("TokenError constructor failed")



# Generated at 2022-06-23 15:58:04.517816
# Unit test for function tokenize
def test_tokenize():
    tokenize(b"def f(x): return x+1".splitlines())



# Generated at 2022-06-23 15:58:07.731431
# Unit test for function maybe
def test_maybe():
    # These should match:
    maybe(r"a")
    maybe(r"a") + r"bc"
    r"bc" + maybe(r"a")
    # These should not match:
    maybe(r"a") + "a"
    "a" + maybe(r"a")


# Generated at 2022-06-23 15:58:17.776584
# Unit test for function detect_encoding

# Generated at 2022-06-23 15:58:24.663853
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from lib2to3.tests.support import captured_stdout, test_support
    from io import StringIO
    import tokenize
    with captured_stdout() as stdout:
        tokenize.untokenize(tokenize.generate_tokens(StringIO('def x():\n  pass\n').readline))
    out = stdout.getvalue()
    expected = 'def x ( ) :\n  pass\n  \n'
    test_support.check_impl_detail(expected, out)


# Generated at 2022-06-23 15:58:29.553988
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    from difflib import ndiff
    from importlib import util


# Generated at 2022-06-23 15:58:39.942261
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.tokens = ['#', ' ', '!']
    row1 = 1
    col1 = 0
    u.add_whitespace((row1, col1))
    assert u.tokens == ['#', ' ', '!']
    u.prev_col = 2
    u.tokens = ['#', ' ', '!']
    row2 = 1
    col2 = 5
    u.add_whitespace((row2, col2))
    assert u.tokens == ['#', ' ', '!', ' ' * 3]
    u.prev_row = 1
    u.prev_col = 5
    u.tokens = ['#', ' ', '!']
    row3

# Generated at 2022-06-23 15:58:52.225400
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    import unittest

    class TestCase(unittest.TestCase):
        def __init__(self, *args):
            super().__init__(*args)
            self.u = Untokenizer()

        def test_add_whitespace(self):
            # Test case for add_whitespace method
            # test 1
            self.u.add_whitespace((0, 5))
            self.assertEqual(self.u.tokens, [' '*4])
            self.u.add_whitespace((0, 4))
            self.assertEqual(self.u.tokens, [' '*4])
            self.u.add_whitespace((1, 10))

# Generated at 2022-06-23 15:58:55.689743
# Unit test for function maybe
def test_maybe():
    assert maybe('something') == '(' + '|'.join(['something']) + ')?'
    assert maybe('something', 'maybe') == '(' + '|'.join(['something', 'maybe']) + ')?'


# Generated at 2022-06-23 15:58:58.874001
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in ["", "# coding: utf-8\n", "\n"]:
            yield line.encode()

    assert detect_encoding(readline) == ("utf-8", [])



# Generated at 2022-06-23 15:59:09.908838
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    readline = io.BytesIO(b"foo = 'bar'\nbaz = (1, )").readline
    tokens = tokenize(readline)
    # Test normal operation
    assert next(tokens) == (
        token.NAME,
        b"foo",
        (1, 0),
        (1, 3),
        b"foo = 'bar'\n",
    )
    assert next(tokens) == (token.OP, b"=", (1, 4), (1, 5), b"foo = 'bar'\n")

# Generated at 2022-06-23 15:59:11.458598
# Unit test for function untokenize
def test_untokenize():
    input = list(generate_tokens(StringIO("def x(): pass").readline))
    assert untokenize(input) == "def x(): pass"



# Generated at 2022-06-23 15:59:18.490925
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    u.add_whitespace((1, 5))
    assert u.tokens == []
    u.add_whitespace((1, 5))
    assert u.tokens == ["    "]
    u.add_whitespace((1, 0))
    assert u.tokens == ["    "]
    u.add_whitespace((2, 0))
    assert u.tokens == ["    ", "\n"]
    u.add_whitespace((2, 5))
    assert u.tokens == ["    ", "\n", "     "]
    u.add_whitespace((2, 5))
    assert u.tokens == ["    ", "\n", "     "]



# Generated at 2022-06-23 15:59:27.432008
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", (maybe("a"), "(a)?")
    assert maybe("ab") == "((a)(b))?", (maybe("ab"), "((a)(b))?")


#################
# Grammar

_atom = (
    "<>|&=!+-*/%~^:\\\\,.()[]{}@`"
    "is not or and if else elif while for in try except lambda yield async with def class"  # noqa: E501
    "from as global nonlocal assert"
)

_namechars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_"

_namechars2 = _namechars + "0123456789"

_namerest = _namechars2

# Generated at 2022-06-23 15:59:29.209624
# Unit test for constructor of class TokenError
def test_TokenError():
    _ = TokenError()
    assert _ is not None



# Generated at 2022-06-23 15:59:41.297478
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize as tokenize_module

    class Readline(object):
        def __init__(self, lines: List[str]) -> None:
            self.lines = lines
            self.index = 0

        def __call__(self) -> Text:
            try:
                line = self.lines[self.index]
                self.index += 1
                return line
            except IndexError:
                return ""

    def compare(readline: List[str], result: List[tokenize_module.TokenInfo]) -> None:
        rl = Readline(readline)
        result = list(result)
        got = []
        tokenize_loop(rl, got.append)
        assert len(got) == len(result)
        for got, expected in zip(got, result):
            assert got == expected

   

# Generated at 2022-06-23 15:59:48.504376
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 1
    u.add_whitespace((1, 2))
    u.add_whitespace((1, 3))
    u.add_whitespace((2, 2))
    assert u.tokens == [" ", "  ", "\n"]


# Generated at 2022-06-23 15:59:56.381250
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # The following two lists are expected to be equivalent.
    untok_list = []
    untok = Untokenizer()
    fake = [(tok_name[token], sym) for token, sym in input_tokens]
    untok_list.append(untok.untokenize(fake))
    untok2_list = []
    untok2 = Untokenizer()
    tok_gen = generate_tokens(lambda: next(iter(input_tokens)))
    untok2_list.append(untok2.compat(next(tok_gen), tok_gen))
    assert untok_list == untok2_list


# Generated at 2022-06-23 16:00:03.068799
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return "a,b = ['hello', 'world']"

    tok_info_list = []

    def tokeneater(*tok_info):
        tok_info_list.append(tok_info)

    tokenize_loop(readline, tokeneater)


# Generated at 2022-06-23 16:00:09.298828
# Unit test for function tokenize
def test_tokenize():

    import io
    import token
    import tokenize
    r = io.StringIO("""\
if 1:
    print(2)
""")
    with tokenize.tokenize(r.readline) as tokens:
        for token in tokens:
            print(token)

test_tokenize()


# Generated at 2022-06-23 16:00:12.104829
# Unit test for function maybe
def test_maybe():
    assert maybe("[a-z]", "[0-9]") == "([a-z]|[0-9])?"



# Generated at 2022-06-23 16:00:23.299888
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    from textwrap import dedent

    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == [""]

    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 2))
    assert u.tokens == ["  "]

    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((2, 0))
    assert u.tokens == [""]

    # Test that a single backslash is not lost in the process
    u = Untokenizer()
    u.prev_row = 1

# Generated at 2022-06-23 16:00:31.300933
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import StringIO
    from tokenize import detect_encoding

    def readline():
        return next(blines)


# Generated at 2022-06-23 16:00:40.208715
# Unit test for function printtoken
def test_printtoken():
    import io
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    import sys
    string = 'def fun():\n    print("Hello, world!")'
    tokens = list(generate_tokens(io.StringIO(string).readline))
    untok_string = untokenize(tokens)
    string = string.expandtabs(tabsize=8)
    try:
        if untok_string != string:
            print("Failed test of printtoken.  String mismatch")
        else:
            print("Success!")
    except:
        print("Failed test of printtoken.  Exception raised")
    print("Exiting test_printtoken")
# End unit test function

# Generated at 2022-06-23 16:00:47.991064
# Unit test for function printtoken
def test_printtoken():
    printtoken(ENCODING, 'utf-8', (1, 0), (1, 5), '')
    printtoken(NAME, 'abc', (1, 0), (1, 3), '')
    printtoken(OP, '+', (1, 0), (1, 1), '')
    printtoken(STRING, 'a', (1, 0), (1, 1), '')
    printtoken(STRING, 'a"b', (1, 0), (1, 3), '')


_cache = {}
_builtin_open = open



# Generated at 2022-06-23 16:00:49.688625
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    e = StopTokenizing("test")
    assert e.args == ("test",)



# Generated at 2022-06-23 16:00:57.453397
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: iso-8859-1 -*-"
        yield b"\n"
        yield b"# A comment"

    first, second = detect_encoding(readline)
    assert first == "iso-8859-1"
    assert second == [b"# -*- coding: iso-8859-1 -*-", b"\n"]

    def readline():
        yield b"\n"
        yield b"# coding: iso-8859-1"
        yield b"\n"
        yield b"# A comment"

    first, second = detect_encoding(readline)
    assert first == "iso-8859-1"
    assert second == [b"\n", b"# coding: iso-8859-1", b"\n"]

# Generated at 2022-06-23 16:01:07.619923
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError as err:
        assert str(err) == "", "default arg of TokenError not honored"
    except:
        raise AssertionError("wrong exception raised")


# Note: these constants are not exported.
NUMBER = "NUMBER"
STRING = "STRING"
NEWLINE = "NEWLINE"
INDENT = "INDENT"
DEDENT = "DEDENT"
ENDMARKER = "ENDMARKER"
NAME = "NAME"
ERRORTOKEN = "ERRORTOKEN"
COMMENT = "COMMENT"
NL = "NL"
ENCODING = "ENCODING"



# Generated at 2022-06-23 16:01:09.972887
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?"



# Generated at 2022-06-23 16:01:21.422471
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
    assert "latin-1" == detect_encoding(readline)[0]
    def readline():
        yield b"#!/usr/bin/python"
        yield b"# -*- coding: latin-1 -*-"
        yield b"# foo"
    assert "utf-8" == detect_encoding(readline)[0]
    def readline():
        yield b"\xef\xbb\xbf# -*- coding: latin-1 -*-"
        yield b"# foo"
    assert "utf-8-sig" == detect_encoding(readline)[0]
    def readline():
        yield b"#!/usr/bin/python"
       