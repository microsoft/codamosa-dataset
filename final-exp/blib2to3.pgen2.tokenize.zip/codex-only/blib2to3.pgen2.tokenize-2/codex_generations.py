

# Generated at 2022-06-23 15:51:16.927266
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("TokenError message")
    except TokenError as inst:
        assert inst.args[0] == "TokenError message"



# Generated at 2022-06-23 15:51:18.677799
# Unit test for function printtoken
def test_printtoken():
    assert printtoken(1,2,(3,4),(5,6),7) == '3,4-5,6:\t1\t2'


# Generated at 2022-06-23 15:51:20.608890
# Unit test for function maybe
def test_maybe():
    assert maybe('a', 'b', 'c') == "([a][b][c])*"
    assert maybe('a') == "[a]*"



# Generated at 2022-06-23 15:51:22.602840
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:51:29.809719
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens, untokenize

    def roundtrip(input):
        output = untokenize(generate_tokens(StringIO(input).readline))
        return output.split("\n")

    # Check roundtripping of empty program
    assert roundtrip("") == [""]
    # Check simple roundtripping of a few tokens
    assert roundtrip("def f(): pass") == ["def f():", "    pass"]
    # Check that tabs are not expanded
    assert roundtrip("def f():\n\tpass\n") == ["def f():", "\tpass"]
    # Check that newline is not inserted if indents are empty
    assert roundtrip("pass") == ["pass"]
    # Check that indents are stripped on empty input

# Generated at 2022-06-23 15:51:38.604892
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", maybe("a")
    assert maybe("ab") == "((ab)?)", maybe("ab")
    assert maybe("a", "b") == "((a)|(b))?", maybe("a", "b")
    assert maybe("a", "ab") == "((a)|(ab))?", maybe("a", "ab")
    assert maybe("abc", "abc") == "((abc)|(abc))?", maybe("abc", "abc")
    assert maybe("abc", "ab") == "((abc)|(ab))?", maybe("abc", "ab")
    assert maybe("a", "abc") == "((a)|(abc))?", maybe("a", "abc")



# Generated at 2022-06-23 15:51:40.774723
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 15:51:46.449767
# Unit test for function tokenize_loop
def test_tokenize_loop():
    with open("blib2to3/pgen2/token.py", "rb") as f:
        data = f.read()
    readline = data.splitlines().__iter__().__next__
    tokenize_loop(readline, lambda x,y,z,w,v: print(x,y,z,w))

# End unit test for function tokenize_loop



# Generated at 2022-06-23 15:51:59.369238
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield '  # comment'
        yield 'a = 1 + 1 # and another'
        yield '  """'
        yield '  multi-line string...'
        yield '  """'
        yield ''
        yield 'class foo:'
        yield '    pass'
        yield ''
        yield '# last comment'
    it = tokenize_loop(readline, printtoken)
    token = next(it)
    assert token == (4, '"', (2, 0), (2, 3), '  "')
    token = next(it)
    assert token == (4, '"', (2, 3), (2, 6), '  "')
    token = next(it)
    assert token == (0, '\n', (2, 6), (2, 6), '  """\n')


# Generated at 2022-06-23 15:52:10.992792
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()

# Generated at 2022-06-23 15:52:14.716290
# Unit test for constructor of class TokenError
def test_TokenError():
    e = TokenError()
    assert str(e) == ""
    e = TokenError("test error")
    assert str(e) == "test error"



# Generated at 2022-06-23 15:52:17.537419
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    """Tests that the Untokenizer constructor works."""
    t = Untokenizer()
    assert t.tokens == []
    assert t.prev_row == 1
    assert t.prev_col == 0



# Generated at 2022-06-23 15:52:22.133589
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def tokenizer():
        yield (1, "hello", (1, 1), (1, 5), "hello")

    def test(type, token, start, end, line):
        assert type == 1
        assert token == "hello"
        assert start == (1, 1)
        assert end == (1, 5)
        assert line == "hello"

    tokenize_loop(tokenizer, test)



# Generated at 2022-06-23 15:52:23.857401
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3.4", (1, 5), (1, 7), "3.4")


# Generated at 2022-06-23 15:52:35.607735
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline(data: str) -> Callable[[], bytes]:
        line = io.BytesIO(data)
        return line.readline

    assert detect_encoding(readline(b"")) == ("utf-8", [])
    assert detect_encoding(readline(BOM_UTF8)) == ("utf-8-sig", [])
    assert detect_encoding(readline(BOM_UTF8 + b"# coding: latin-1\n")) == (
        "utf-8-sig",
        [b"# coding: latin-1\n"],
    )
    assert detect_encoding(readline(BOM_UTF8 + b"\n")) == ("utf-8-sig", [b"\n"])

# Generated at 2022-06-23 15:52:46.250357
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize

    untok = Untokenizer()
    with io.StringIO("2 + 2 == 5") as f:
        tokens = tokenize.generate_tokens(f.readline)
        for t in tokens:
            if t[0] == tokenize.NUMBER:
                untok.compat(t, tokens)
                break
        res = "".join(untok.tokens)
    assert res == "2 + 2 == 5 ", res

    import io
    import tokenize

    untok = Untokenizer()
    with io.StringIO("2 + 2 == 5") as f:
        tokens = tokenize.generate_tokens(f.readline)
        res = untok.untokenize(tokens)
    assert res == "2 + 2 == 5 ", res

# Generated at 2022-06-23 15:52:55.544342
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # Sample code, with comments.
    code_with_comments = """
    def f(a, b):
        return a, b  # the returned tuple contains a and b
    """
    # Sample code, without comments.
    code_without_comments = """
    def f(a, b):
        return a, b
    """
    # Sample tuple of token.

# Generated at 2022-06-23 15:53:00.421938
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
    assert any("hello", "world") == "(hello|world)*"
    assert any("", "spam") == "(|spam)*"



# Generated at 2022-06-23 15:53:08.454443
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    inst = Untokenizer()
    inst.add_whitespace((1, 10))
    res = inst.untokenize([])
    assert res == "          "
    inst = Untokenizer()
    inst.tokens = ["a", "b", "c"]
    inst.add_whitespace((1, 2))
    inst.tokens.append("d")
    inst.prev_row = 1
    inst.prev_col = 4
    res = inst.untokenize([])
    assert res == "ab  c d"



# Generated at 2022-06-23 15:53:20.074843
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    import io, unittest
    from . import tokenize
    from tokenize import STRING

    data = io.BytesIO(BOM_UTF8 + b"a =\n    1\n")
    ut = Untokenizer()

    def decode_token(x):
        # type: (Tuple[int, str, Tuple[int, int], Tuple[int, int], str]) -> str
        return x[1]

    tokens = [t for t in tokenize.generate_tokens(data.readline) if t[0] != STRING]
    untok = ut.untokenize(tokens)
    # Can't check in detail because of different spacing conventions on
    # different platforms.
    assert untok == "a =    1"

# Generated at 2022-06-23 15:53:22.914102
# Unit test for function group
def test_group():
    tests = [
        "abcd", "a|b|c", "(a|b)|c",
    ]
    for t in tests:
        assert group(*t.split("|")) == t, (t, group(*t.split("|")))
test_group()



# Generated at 2022-06-23 15:53:36.114197
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # This test is based on Lib/test/tokenize_cases.txt
    import io
    import unittest
    import tokenize as tk
    from token import ENDMARKER
    from types import GeneratorType

    class Test(unittest.TestCase):
        CASES = """
            # This is a comment.

            # This is a future statement.
            from __future__ import division

            # This is a docstring.
            '''Triple single-quoted'''
            """

        def verify_tokenize(self, readline):
            tokens = list(tk.generate_tokens(readline))
            self.assertEqual(tokens[-1], (ENDMARKER, "", (1, 0), (1, 0), ""))

            untok = tk.Untokenizer()
            out

# Generated at 2022-06-23 15:53:45.035909
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    input = (
        (NAME, "spam"),
        (NUMBER, "23"),
        (NAME, "spam"),
        (NUMBER, "42"),
        (STRING, 's = "s\np\ta\0m"'),
        (NEWLINE, "\n"),
        (NAME, "eggs"),
        (OP, "="),
        (NAME, "None"),
        (NEWLINE, "\n"),
    )
    ut = Untokenizer()
    ut.compat(input[0], input)
    assert ut.untokenize(input) == "spam 23 spam 42 s = 's\\np\\ta\\x00m'\neggs = None\n"



# Generated at 2022-06-23 15:53:48.945556
# Unit test for function any
def test_any():
    assert any('a', 'b', 'c' ) == '(a|b|c)*'
    assert any('a') == 'a*'
    assert any() == '()*'


# Generated at 2022-06-23 15:53:59.153726
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.add_whitespace((1, 0)) # Initial.
    assert ut.prev_row == 1 and ut.prev_col == 0
    # Just works.
    ut.add_whitespace((2, 3))
    assert ut.prev_row == 2 and ut.prev_col == 3
    # Indent.
    ut.add_whitespace((2, 5))
    assert ut.prev_row == 2 and ut.prev_col == 5
    # Dedent.
    ut.add_whitespace((3, 2))
    assert ut.prev_row == 3 and ut.prev_col == 2
    # Line rollback.
    ut.add_whitespace((2, 10))
    assert ut.prev_row == 2 and ut.prev_col == 10
    # E

# Generated at 2022-06-23 15:54:01.150375
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 'abc', (1,2), (1,4), 'abc')



# Generated at 2022-06-23 15:54:10.664434
# Unit test for function any
def test_any():
    for name, string in [
        ["empty", ""],
        ["one_a", "a"],
        ["two_a", "aa"],
        ["five_a", "aaaaa"],
        ["one_ab", "ab"],
        ["two_ab", "abab"],
        ["one_abc", "abc"],
        ["one_abx", "abx"],
        ["two_abx", "abxabx"],
    ]:
        my_re = re.compile(r"^" + any("a", "ab") + "$")
        if my_re.match(string):
            print(string, "matches", repr(my_re.pattern))
        else:
            print(string, "doesn't match", repr(my_re.pattern))



# Generated at 2022-06-23 15:54:12.320503
# Unit test for function printtoken
def test_printtoken():
    printtoken(0, 'token', (0, 0), (0, 0), '')



# Generated at 2022-06-23 15:54:19.213032
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return "x=1"
    def tokeneater(*args):
        print(args)
    tokenize_loop(readline, tokeneater)


#
# Generator that breaks a stream of characters into tokens.
#
# This is a generator function; it returns an iterator that produces all
# the tokens.
#


# Generated at 2022-06-23 15:54:31.666128
# Unit test for function untokenize
def test_untokenize():
    # See http://www.python.org/dev/peps/pep-0263/#implementation for the
    # specification of how this test must be conducted.
    #
    # The first test checks that utokenize() preserves round-trip invariance
    # for a full input.
    f = io.StringIO("# coding: latin-1\n\nspam\n")
    s = f.readline
    t1 = [tok[:2] for tok in generate_tokens(s)]
    newcode1 = untokenize(t1)
    f.close()

    f = io.StringIO(newcode1)
    s = f.readline
    t2 = [tok[:2] for tok in generate_tokens(s)]

# Generated at 2022-06-23 15:54:34.000885
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "2", (1, 0), (1, 1), "")


# Generated at 2022-06-23 15:54:35.821040
# Unit test for function printtoken
def test_printtoken():
  print("test_printtoken not implemented")
# End unit test for function printtoken



# Generated at 2022-06-23 15:54:46.542343
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    ut = Untokenizer()
    u = ut.compat
    def L(tokens, expected):
        actual = ut.untokenize(iter(list(tokens)))
        if actual != expected:
            print(f'Token List: {tokens}')
            print(f'Expected: {expected}')
            print(f'Actual: {actual}')
            assert False
    L([(OP, '('), (DEDENT, ''), (OP, ')'), (INDENT, '    '), (OP, ')')], '()')
    L([(OP, '('), (DEDENT, ''), (OP, ')'), (INDENT, '    '), (OP, ')')], '()')

# Generated at 2022-06-23 15:54:47.137571
# Unit test for function printtoken
def test_printtoken():
    pass



# Generated at 2022-06-23 15:54:52.762076
# Unit test for function untokenize

# Generated at 2022-06-23 15:54:58.637031
# Unit test for function maybe
def test_maybe():
    assert maybe("x1y1")("x1y1")
    assert maybe("x1y1")("xy1")
    assert maybe("x1y1")("x1y")
    assert maybe("x1y1")("xy")
    assert maybe("x1y1")("")


# Generated at 2022-06-23 15:55:04.346824
# Unit test for function maybe
def test_maybe():
    # This pattern might be used to match strings in a domain-specific
    # language.  For example, the string "edu" could be part of a
    # domain name such as "www.python.org".
    pattern = maybe(r"www\.") + r"[\w\.]+"
    string = "edu"
    assert re.match(pattern, string)



# Generated at 2022-06-23 15:55:15.326821
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    x = u.untokenize(
        [
            (ENDMARKER, ""),
            (NAME, "abc"),
            (OP, "+"),
            (NAME, "def"),
            (NEWLINE, "\n"),
            (NAME, "ghi"),
            (NEWLINE, "\n"),
            (ENDMARKER, ""),
        ]
    )
    assert x == "abc +def\nghi\n", repr(x)
    u = Untokenizer()

# Generated at 2022-06-23 15:55:22.855015
# Unit test for function generate_tokens
def test_generate_tokens():
    from StringIO import StringIO

    source = "xyz"
    token_list = [
        (NAME, "xyz", (1, 0), (1, 3), "xyz"),
        (NEWLINE, "\n", (1, 3), (1, 4), "xyz\n"),
        (ENDMARKER, "", (2, 0), (2, 0), "\n"),
    ]

    r = StringIO(source).readline
    assert list(generate_tokens(r)) == token_list



# Generated at 2022-06-23 15:55:34.014509
# Unit test for function detect_encoding
def test_detect_encoding():
    # Create a file with a BOM, and an encoding cookie
    import tempfile

    f = tempfile.NamedTemporaryFile("w+")
    f.write(BOM_UTF8.decode("latin-1") + "# coding=utf-8\n")
    f.seek(0)
    encoding, lines = detect_encoding(lambda: f.readline())
    assert encoding == 'utf-8-sig'
    assert lines[0].decode("ascii") == "# coding=utf-8\n"

    f = tempfile.NamedTemporaryFile("w+")
    f.write("# -*- coding: ascii -*-\n")
    f.write("# -*- coding: latin-1 -*-\n")

# Generated at 2022-06-23 15:55:39.099606
# Unit test for function any
def test_any():
    try:
        any('')
    except AssertionError:
        pass
    else:
        raise AssertionError
    try:
        any()
    except AssertionError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 15:55:46.927085
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # First row is 1, first column is 0
    u = Untokenizer()
    # Check that we can add whitespace to fill a complete line
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    # Add another whitespace
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", " "]
    # Make sure that we don't add whitespace if we're already past the end
    # of a line
    u.add_whitespace((1, 1))
    assert u.tokens == [" ", " "]
    # Make sure we can add whitespace when jumping to an earlier column
    u.add_whitespace((1, 0))
    assert u.tokens == [" ", " "]
    # Make sure we can

# Generated at 2022-06-23 15:55:50.805926
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.COMMENT, "#foo", (0, 0), (0, 0), '#foo')
    printtoken(token.OP, "!", (0, 0), (0, 0), '!')
test_printtoken()



# Generated at 2022-06-23 15:56:02.611906
# Unit test for function maybe
def test_maybe():
    pattern = re.compile("^" + maybe("a", "b"))
    assert pattern.match("a")
    assert pattern.match("aa")
    assert pattern.match("aaa")
    assert pattern.match("b")
    assert pattern.match("ba")
    assert pattern.match("baa")
    assert pattern.match("")
    pattern = re.compile("^" + maybe(""))
    assert pattern.match("")
    pattern = re.compile("^" + maybe("a"))
    assert pattern.match("a")
    assert pattern.match("")
    return
# End of unit test for function maybe

# This RE handles continued lines and triple-quoted strings

# Generated at 2022-06-23 15:56:09.349516
# Unit test for function printtoken
def test_printtoken():
    printtoken(
        token.OP, "=", (1, 0), (1, 1), "abc\ndef\nghi\n"
    )  # => "1,0-1,1:\tOP\t'='"
    printtoken(
        token.NAME, "a", (2, 0), (2, 2), "abc\ndef\nghi\n"
    )  # => "2,0-2,2:\tNAME\t'a'"



# Generated at 2022-06-23 15:56:13.871702
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    untokenize = Untokenizer().untokenize
    f = io.StringIO("def f():\n  pass\n")
    g = io.StringIO()
    for e in tokenize.tokenize(f.readline):
        tokenize.tokenize(f.readline, g.write)
    assert g.getvalue() == untokenize(tokenize.tokenize(f.readline))



# Generated at 2022-06-23 15:56:18.556647
# Unit test for function maybe
def test_maybe():
    assert maybe('x') == '(x)?'
    assert maybe('x', 'y') == '(x|y)?'
    assert maybe('x', 'y', 'z') == '(x|y|z)?'



# Generated at 2022-06-23 15:56:28.213263
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    rio = io.StringIO("if 1:\n  pass\n")
    result = []
    tokenize.tokenize_loop(rio.readline, result.extend)

# Generated at 2022-06-23 15:56:30.238800
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    exc = StopTokenizing(4, 5)
    assert exc.args == (4, 5), "incorrect args attribute"



# Generated at 2022-06-23 15:56:31.748360
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-23 15:56:39.911181
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize
    import unittest

    class TestTokenize(unittest.TestCase):
        def test_issue1722515(self):
            r = io.StringIO("if 1:")
            tokens = _tokenize.generate_tokens(r.readline)
            first_token = next(tokens)
            self.assertEqual(first_token[:2], (1, b"if"))
            second_token = next(tokens)
            self.assertEqual(second_token[:2], (1, 1))
            third_token = next(tokens)
            self.assertEqual(third_token[:2], (1, b":"))

        def test_eof(self):
            r = io.StringIO("")
            self

# Generated at 2022-06-23 15:56:46.474911
# Unit test for function tokenize
def test_tokenize():
    import StringIO as io
    s = "def f(x): return 'abc'"
    g = tokenize(io.StringIO(s).readline)
    for toktype, tok, startend, line in g:
        printtoken(toktype, tok, startend[0], startend[1], line)
        if toktype == NEWLINE:
            break



# Generated at 2022-06-23 15:56:56.035737
# Unit test for function generate_tokens
def test_generate_tokens():
    lines = ["print('<{bla}'),1,"]
    tokens = list(generate_tokens(iter(lines).__next__))

# Generated at 2022-06-23 15:56:58.213231
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        return e



# Generated at 2022-06-23 15:57:03.777017
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.add_whitespace((1, 0))
    untok.add_whitespace((1, 2))
    untok.add_whitespace((1, 2))
    untok.add_whitespace((2, 0))
    untok.add_whitespace((1, 2))



# Generated at 2022-06-23 15:57:11.029952
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import unittest

    class TestableToken(unittest.TestCase):
        def setUp(self):
            self.token = []
            self.types = []
            self.values = []
            self.expected_tokens = []

        def tearDown(self):
            self.token = []
            self.types = []
            self.values = []
            self.expected_tokens = []

        def reader(self, filename):
            with open(filename) as file:
                lines = file.readlines()
                for line in lines:
                    yield line

        def tokenize(self, filename):
            tokenize_loop(self.reader(filename), self.tokenize_callback)

        def tokenize_callback(self, type, token, start, end, line):
            self

# Generated at 2022-06-23 15:57:13.423113
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass



# Generated at 2022-06-23 15:57:24.078926
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    untokenize = Untokenizer().compat

    def all_untokenize(s):
        return untokenize(tokenize.generate_tokens(io.StringIO(s).readline))

    assert all_untokenize("def f():\n    pass") == "def f ( ) :\n    pass "
    assert all_untokenize("def f():\n  pass\n") == "def f ( ) :\n  pass "

    assert all_untokenize("def f():\n  pass\n  pass") == "def f ( ) :\n  pass\n  pass "


# Generated at 2022-06-23 15:57:35.095497
# Unit test for function maybe
def test_maybe():
    match = re.compile(maybe(r'\s*#', r'[^\n"\\]*'
                             r'(?:' r'\\.[^\n"\\]*' r')*'))
    multiline = r'(?:' r'\\\n' r'[^\n"\\]*' r'(?:' r'\\.[^\n"\\]*' r')*'

    # Test long, non-terminated string.
    s = '"' + "x" * 10000 + r'\"'
    assert match.match(s)

    # Test long, non-terminated string, with comment.
    s = '"' + "x" * 10000 + r'\"#'
    assert match.match(s)

    # Test long, terminated string.

# Generated at 2022-06-23 15:57:36.801913
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:57:46.312646
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import unittest
    import io
    from typing import Any
    from textwrap import dedent

    class Testcases(unittest.TestCase):
        def _test(self, format: str, inp: str, exp: str) -> None:
            """Verify that the untokenizer works regardless of the input format."""
            with self.subTest(inp=inp, exp=exp):
                self.assertEqual(
                    dedent(format).format(inp=dedent(inp)).rstrip("\n"),
                    dedent(exp).rstrip("\n"),
                )

        def test_no_whitespace(self) -> None:
            self._test("{inp}", "a = 1", "a = 1")

        def test_leading_indent(self) -> None:
            self

# Generated at 2022-06-23 15:57:55.003436
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_row = 0
    ut.prev_col = 1
    # print(ut.tokens)
    ut.add_whitespace((0, 2))
    # print(ut.tokens)
    assert ut.tokens[0] == " "
    assert ut.prev_row == 0
    assert ut.prev_col == 2


endprog = None



# Generated at 2022-06-23 15:58:05.085217
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    unt = Untokenizer()
    unt.prev_row = 1
    unt.prev_col = 0
    unt.add_whitespace((1, 10))
    assert unt.tokens == [" " * 10]
    unt.add_whitespace((2, 0))
    assert unt.tokens == [" " * 10, "\n"]
    unt.add_whitespace((2, 2))
    assert unt.tokens == [" " * 10, "\n", " " * 2]
    unt.add_whitespace((1, 5))
    assert unt.tokens == [" " * 10, "\n", " " * 2]



# Generated at 2022-06-23 15:58:16.428836
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    """This is just a sanity check, not a proper unit test."""
    import io
    from .tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    sample_input = io.StringIO(
        "def foo(x):\n"
        "    print('%s = %s' % (x, x)) # A comment\n"
        "    if 1:\n"
        '        print("%s = %s" % (x, x))\n'
    )
    tokens = generate_tokens(sample_input.readline)
    result1 = untokenize(tokens)
    result2 = "".join(t[1] for t in tokens if t[0] != COMMENT)
    assert result1 == result2

    ut = Untokenizer()
   

# Generated at 2022-06-23 15:58:21.671365
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import cStringIO as StringIO
    import tokenize
    f = StringIO.StringIO("def f():\n  return 42")
    tokens = tokenize.generate_tokens(f.readline)
    u = Untokenizer()
    res = u.untokenize(tokens)
    assert res == "def f():\n  return 42"



# Generated at 2022-06-23 15:58:22.781941
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"
test_group()


# Generated at 2022-06-23 15:58:29.340267
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    # Readline function that returns the lines in the given list
    def readlines(lines: Iterable[bytes]) -> Callable[[], bytes]:

        def _readline() -> bytes:
            try:
                return next(line_iter)
            except StopIteration:
                return bytes()

        line_iter = iter(lines)
        return _readline

    def read_with_bom(encoding: str) -> bytes:
        with io.open("Lib/tokenize.py", "rb") as f:
            return f.read()

    def read_no_bom(encoding: str) -> bytes:
        with io.open("Lib/tokenize.py", encoding=encoding) as f:
            return f.read().encode(encoding)

    # test_bom_found
    #


# Generated at 2022-06-23 15:58:37.735568
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test the "tokeneater" argument
    from io import StringIO
    from token import tok_name

    output = StringIO()
    data = "1 + 1\n"
    tokenize_loop(data.__iter__().__next__, output.write)
    expected = "1,0-1,1:\tNAME\t'1'\n1,2-1,3:\tOP\t'+'\n1,4-1,5:\tNAME\t'1'\n"
    assert output.getvalue() == expected, "tokenize_loop()"



# Generated at 2022-06-23 15:58:39.659039
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:58:52.064730
# Unit test for function maybe
def test_maybe():
    assert maybe('a') == '(a)?', maybe('a')
    assert maybe('a', 'b') == '(a|b)?', maybe('a', 'b')

whitespace = r"[ \f\t]*"
comment = r"#[^\r\n]*"
ignore = whitespace + any(r"\\\r?\n" + whitespace) + maybe(comment)

name = r"[a-zA-Z_]\w*"

hex_num = r"0[xX][\da-fA-F]+[lL]?"
oct_num = r"0[oO][0-7]+[lL]?"
bin_num = r"0[bB][01]+[lL]?"

# Generated at 2022-06-23 15:59:03.085414
# Unit test for function tokenize
def test_tokenize():
    import io
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize, tokenize


# Generated at 2022-06-23 15:59:04.731580
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:59:05.643882
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    x = Untokenizer()
    return x



# Generated at 2022-06-23 15:59:14.921388
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    unt = Untokenizer()
    unt.prev_row = 1
    unt.prev_col = 10
    unt.add_whitespace((1, 15))
    assert unt.tokens == ["     "]
    unt.add_whitespace((2, 5))
    assert unt.tokens == ["     ", "\n     "]

    unt2 = Untokenizer()
    unt2.prev_row = 1
    unt2.prev_col = 0
    unt2.add_whitespace((1, 0))
    assert unt2.tokens == []
    unt2.add_whitespace((2, 5))
    assert unt2.tokens == ["\n     "]



# Generated at 2022-06-23 15:59:20.151521
# Unit test for function untokenize
def test_untokenize():
    items = [
        (1, "def"),
        (1, " "),
        (1, "f"),
        (1, "("),
        (1, ")"),
        (1, " "),
        (1, ":"),
        (1, "\n"),
        (0, "    "),
        (3, "# hi\n"),
        (1, "    "),
        (1, "a"),
        (1, "\n"),
    ]
    got = untokenize(items)
    assert got == "def f():\n    # hi\n    a\n"
    got = untokenize(item for item in items if item[0] != 0)
    assert got == "def f():\n    # hi\n    a\n"

# Generated at 2022-06-23 15:59:25.869294
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    from blib2to3.pgen2 import tokenize as tokenize_module
    from . import untokenize as untokenize_module
    text = "a = 12\n"
    result = untokenize_module.Untokenizer().untokenize(
        tokenize_module.generate_tokens(io.StringIO(text).readline)
    )
    if result != "a = 12 ":
        raise Exception("bad result: " + repr(result))



# Generated at 2022-06-23 15:59:38.304980
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    import unittest
    import sys

    class Test(unittest.TestCase):
        def add_whitespace(self, initial, final, expected):
            untokenizer = Untokenizer()
            untokenizer.prev_row, untokenizer.prev_col = initial
            untokenizer.add_whitespace(final)
            self.assertEqual(expected, untokenizer.tokens)

        def test_one_line(self):
            self.add_whitespace((1, 0), (1, 2), ["  "])

        def test_same_line(self):
            self.add_whitespace((1, 10), (1, 20), ["          "])


# Generated at 2022-06-23 15:59:41.487556
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    result=u.compat((NUMBER,''),((DEDENT,''),(NAME,''),(NEWLINE,''),(NUMBER,'')))
    return result



# Generated at 2022-06-23 15:59:53.933042
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    def add_whitespace(row, col):
        u.add_whitespace((row, col))

    def check(expected):
        assert "".join(u.tokens) == expected

    u = Untokenizer()
    add_whitespace(1, 0)
    check("")
    add_whitespace(2, 0)
    check("\n")
    add_whitespace(3, 0)
    check("\n\n")
    add_whitespace(2, 1)
    check("\n \n")
    add_whitespace(2, 4)
    check("\n    \n")
    add_whitespace(2, 2)
    check("\n  \n")
    add_whitespace(1, 1)

# Generated at 2022-06-23 16:00:06.164543
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenize = Untokenizer().untokenize
    ut = untokenize

    assert ut([(1, "hi"), (3, " "), (1, "there")]) == "hi there"
    assert ut([(1, "hi"), (2, " "), (1, "there")]) == "hi there"
    assert ut([(1, "hi"), (3, " "), (0, "")]) == "hi"
    assert ut([(1, "hi"), (3, " "), (0, ""), (1, "there")]) == "hi there"
    assert ut([(1, "hi"), (3, " "), (0, ""), (1, "there"), (4, "\nhi"), (3, " ")]) == (
        "hi there\nhi"
    )

# Generated at 2022-06-23 16:00:18.040436
# Unit test for function tokenize
def test_tokenize():
    import tokenize as tokenize_real  # avoid recursion
    import io
    import unittest


    class TestTokenize(unittest.TestCase):
        def test_tokenize_empty(self):
            stream = io.StringIO("")
            # The first line is always ignored
            tokens = list(tokenize_real.tokenize(stream.readline))
            self.assertEqual(len(tokens), 0)
        def test_tokenize_nothing(self):
            stream = io.StringIO("pass")
            # The first line is always ignored
            tokens = list(tokenize_real.tokenize(stream.readline))
            self.assertEqual(len(tokens), 1)

# Generated at 2022-06-23 16:00:28.306565
# Unit test for function detect_encoding

# Generated at 2022-06-23 16:00:38.602488
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    import tokenize
    from io import BytesIO
    ut = Untokenizer()

# Generated at 2022-06-23 16:00:49.826241
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
  import io
  from blib2to3.pgen2.tokenize import untokenize, untokenize_compat
  stream = 'yield from itervalues(x)'
  stream_tokens = list(tokenize(io.StringIO(stream).readline))
  assert untokenize_compat(stream_tokens) == ('yield from itervalues(x)\n',), "test_Untokenizer_compat (1)"
  stream = 'yield from itervalues(x) \n'
  stream_tokens = list(tokenize(io.StringIO(stream).readline))
  assert untokenize_compat(stream_tokens) == ('yield from itervalues(x) \n',), "test_Untokenizer_compat (2)"

# Generated at 2022-06-23 16:01:02.279170
# Unit test for function untokenize
def test_untokenize():
    _tokenize_print = printtoken
    def _printtoken(type, token, srow_scol, erow_ecol, line):
        print(
            "%d,%d-%d,%d:\t%s\t%s" % (srow_scol + erow_ecol + (tok_name[type], repr(token)))
        )

    def roundtrip(s):
        g = generate_tokens(StringIO(s).readline)
        t1 = list(g)
        newcode = untokenize(t1)
        readline = iter(newcode.splitlines(1)).__next__
        t2 = list(generate_tokens(readline))
        diff_tokens(t1, t2)
        return newcode


# Generated at 2022-06-23 16:01:11.144132
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in TESTDATA:
            yield line.encode("latin-1")

    encoding, lines = detect_encoding(readline())
    assert encoding == "utf-16"

    def readline():
        for i, line in enumerate(TESTDATA):
            if i == 2:
                yield line[:1].encode("latin-1")
            else:
                yield line.encode("latin-1")

    encoding, lines = detect_encoding(readline())
    assert encoding == "utf-16"
    assert len(lines) == 1
    assert lines[0] == TESTDATA[0].encode("latin-1")

    def readline():
        for line in TESTDATA:
            yield line.encode("latin-1")

    encoding, lines = detect_

# Generated at 2022-06-23 16:01:22.433848
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import unittest
    from test import support
    untok = Untokenizer()
    from blib2to3.pgen2.tokenize import (
        generate_tokens,
        untokenize,
        detect_encoding,
        NL,
        )

    def source_tokenizer(source):
        readline = io.BytesIO(source.encode('utf-8')).readline
        return generate_tokens(readline)

    def compare(source):
        source = source.decode('utf-8')
        # Test the source code after encoding detection
        # We must not use the encoding parameter of open to support
        # detecting encodings with BOM present
        s = detect_encoding(source)[0]
        tokens = list(source_tokenizer(s))