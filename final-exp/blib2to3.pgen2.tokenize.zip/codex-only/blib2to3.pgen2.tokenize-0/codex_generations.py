

# Generated at 2022-06-23 15:51:14.463621
# Unit test for function any
def test_any():
    assert any("abc") == "(a|b|c)*"



# Generated at 2022-06-23 15:51:22.497842
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline_helper(lines: List[bytes]) -> Callable[[], bytes]:
        def readline() -> bytes:
            if lines:
                res = lines.pop(0)
                return res
            else:
                raise StopIteration()

        return readline

    def check_encoding(
        lines: List[bytes], expected: str, expected_lines: List[bytes]
    ) -> None:
        res = detect_encoding(readline_helper(lines))
        assert res == (expected, expected_lines)

    def check_syntax_error(lines: List[bytes], expected: str) -> None:
        try:
            detect_encoding(readline_helper(lines))
        except SyntaxError as e:
            assert str(e) == expected

# Generated at 2022-06-23 15:51:24.968248
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    e = StopTokenizing()



# Generated at 2022-06-23 15:51:26.272045
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    raise NotImplementedError()



# Generated at 2022-06-23 15:51:29.403374
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    exc = StopTokenizing()
    assert str(exc) == repr(exc)


# A cache for the most recently read line.
cached_line = None



# Generated at 2022-06-23 15:51:39.184454
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pygram import python_grammar as grammar
    import blib2to3.pytree as pytree

    def get_compat(data: Text) -> List[TokenInfo]:
        ut = Untokenizer()
        g = generate_tokens(StringIO(data).readline)
        return [t for t in g if t[0] != ENCODING]

    def untokenize_compat(data: Text) -> Text:
        return Untokenizer().compat(get_compat(data)[0], get_compat(data)[1:])

    def test_async():
        data = "async def coro():\n pass"
        assert untokenize_comp

# Generated at 2022-06-23 15:51:41.329015
# Unit test for function maybe
def test_maybe():
    assert maybe("abra", "cad") == "(abra|cad)?"
# End unit test for function maybe



# Generated at 2022-06-23 15:51:45.894214
# Unit test for function any
def test_any():
    assert re.match(any("a", "b"), "")
    assert re.match(any("a", "b"), "b")
    assert re.match(any("a", "b"), "ab")
    assert re.match(any("a", "b", "cdef"), "cdef")



# Generated at 2022-06-23 15:51:56.597185
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    expected = "class X(object):\n    def m(self):\n        print 2\n"

# Generated at 2022-06-23 15:51:59.436747
# Unit test for constructor of class TokenError
def test_TokenError():
    ex = TokenError("TokenError test message")
    assert "TokenError test message" == str(ex)



# Generated at 2022-06-23 15:52:11.031225
# Unit test for function group
def test_group():
    for choice in "", "a", "ab", "abc":
        assert eval(group(choice)) == choice
    for a, b in (("a", "b"), ("a", "bc"), ("ab", "c"), ("abc", "")):
        assert eval(group(a, b)) == a + "|" + b
    for a, b, c in (("a", "b", "c"), ("a", "", "c"), ("", "b", "c")):
        pat = group(a, b, c)
        assert eval(pat) == pat[1:-1]

# Test the group() unit test
test_group()
del test_group


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.

# Generated at 2022-06-23 15:52:16.665726
# Unit test for function untokenize
def test_untokenize():
    # Test round-tripping of tiny snippets
    for s in [
        "",
        "a",
        "@",
        "@foo",
        "a + 1",
        "a ; b ; c",
        "def f():\n  '''doc'''",
        "def f():\n  1\n  '''doc'''",
        "def f():\n  '''doc'''\n  1",
    ]:
        assert untokenize(tokenize(StringIO(s).readline)) == s



# Generated at 2022-06-23 15:52:18.345611
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()


# Generated at 2022-06-23 15:52:27.618042
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    linesep = os.linesep
    src = (
        "this is a normal line" + linesep
        + "    this is an indented line" + linesep
        + "        this is another indented line" + linesep
        + "this is yet another normal line" + linesep
    )
    expected_tokens = [
        "this is a normal line" + linesep,
        "    this is an indented line" + linesep,
        "        this is another indented line" + linesep,
        "this is yet another normal line" + linesep,
    ]
    srcb = cast(bytes, BOM_UTF8 + src.encode("utf-8"))
    u = Untokenizer()
    result = []
    from blib2to3.tokenize import tokenize as pytokenize


# Generated at 2022-06-23 15:52:32.462466
# Unit test for function maybe
def test_maybe():
    m = maybe("python", "source")
    mre = re.compile(m, re.I)
    assert mre.match("python")
    assert mre.match("source")
    s = maybe("<string>")
    sre = re.compile(s)
    assert sre.match("<string>")
    assert sre.match("")



# Generated at 2022-06-23 15:52:35.481988
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing("a")
    except StopTokenizing as e:
        assert str(e) == "a"



# Generated at 2022-06-23 15:52:46.369034
# Unit test for function generate_tokens
def test_generate_tokens():
    # Check a token list against expected results.
    # Expected results should have token types as token number,
    # and token strings as token string.
    # Optional third entry can be a list giving start and end
    # row/column.  Optional fourth entry can give the line
    # on which the token was found.
    def check_token_list(result, expected):
        for got, exp in zip(result, expected):
            (toknum, tokval, (srow, scol), (erow, ecol), ltext) = got
            if exp[0] != toknum:
                return False
            if exp[1] != tokval:
                return False
            # third entry, if given, is row/col starting position

# Generated at 2022-06-23 15:52:47.511816
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    exc = StopTokenizing()
    assert type(exc) is StopTokenizing



# Generated at 2022-06-23 15:52:48.882303
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"



# Generated at 2022-06-23 15:52:57.877026
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        yield b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        yield b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        yield b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        raise StopIteration

# Generated at 2022-06-23 15:53:00.805477
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as err:
        pass



# Generated at 2022-06-23 15:53:09.821696
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize

    src = io.StringIO("a = 1 + 2")
    g = tokenize.generate_tokens(src.readline)
    tokens = list(g)
    assert tok_name[tokens[1][0]] == "NAME"
    assert tok_name[tokens[2][0]] == "OP"
    assert tok_name[tokens[4][0]] == "OP"
    untok = Untokenizer()
    text = untok.untokenize(tokens)
    assert text == "a = 1 + 2"



# Generated at 2022-06-23 15:53:11.848700
# Unit test for function printtoken
def test_printtoken():
    printtoken(tokenize.NL, '\n', (1,1), (1,1), '')


# Generated at 2022-06-23 15:53:20.965132
# Unit test for function tokenize
def test_tokenize():

    def getline(buf):
        return None if not buf else buf.pop(0) + "\n"


# Generated at 2022-06-23 15:53:22.022312
# Unit test for constructor of class TokenError
def test_TokenError():
    exc = TokenError()
    assert str(exc) == ""



# Generated at 2022-06-23 15:53:24.228987
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
test_any()



# Generated at 2022-06-23 15:53:36.738638
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # method add_whitespace(self, start) -> None
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.tokens = []
    u.add_whitespace((1, 2))
    assert u.tokens == [" "]
    u.add_whitespace((1, 4))
    assert u.tokens == [" ", "  "]
    u.prev_row = 1
    u.prev_col = 3
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", "  ", " "]
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == [" ", "  ", " "]
    u.prev

# Generated at 2022-06-23 15:53:48.053140
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    g = ((NUMBER, "1"), (NAME, "2"), (NEWLINE, "\n"), (NUMBER, "3"))
    assert u.compat((NUMBER, "1"), g) == None
    assert u.tokens == ["1 "]
    assert u.compat((NAME, "2"), g) == None
    assert u.tokens == ["1 ", "2 "]
    assert u.compat((NEWLINE, "\n"), g) == None
    assert u.tokens == ["1 ", "2 \n"]
    assert u.compat((NUMBER, "3"), g) == None
    assert u.tokens == ["1 ", "2 \n", "3"]



# Generated at 2022-06-23 15:53:52.882856
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    from textwrap import dedent
    from .pytokenize import untokenize

    code = dedent(
        """\
    if True:
        pass
    # This is a comment with a
    # second line
    if True:
        pass
    """
    )

    # Verify that adding the comment does not add a
    # newline
    comment = dedent(
        """\
    pass

    # This is a comment with a
    # second line
    """
    )
    assert untokenize(tokenize(comment.splitlines(keepends=True))) == comment

    assert untokenize(tokenize(code.splitlines(keepends=True))) == code



# Generated at 2022-06-23 15:53:54.372355
# Unit test for function generate_tokens

# Generated at 2022-06-23 15:53:56.534107
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass



# Generated at 2022-06-23 15:54:06.788380
# Unit test for constructor of class Untokenizer

# Generated at 2022-06-23 15:54:09.397453
# Unit test for function maybe
def test_maybe():
    assert maybe('x') == "(x)?"
    assert maybe('x', 'y') == "(x|y)?"
    assert maybe('x', 'y', 'z') == "(x|y|z)?"



# Generated at 2022-06-23 15:54:15.260751
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    #pylint: disable=unused-variable
    untok = Untokenizer()
    untok.prev_col = 100
    # Moving to the same line
    untok.add_whitespace((1, 102))
    # Moving to a new line at the same column
    untok.add_whitespace((2, 100))
    # Moving to a new line at a different column
    # (any indentation is lost)
    untok.add_whitespace((3, 200))



# Generated at 2022-06-23 15:54:17.729770
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    # Issue 15866: Untokenizer constructor should not crash on bad argument
    Untokenizer()



# Generated at 2022-06-23 15:54:29.997438
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import sys
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):

        def test_indent(self):
            ut = Untokenizer()
            pairs = [(token.INDENT, "   "),
                     (token.STRING, "''"),
                     (token.NEWLINE, "\n"),
                     (token.STRING, '""'),
                     (token.DEDENT, "")]
            out = ut.compat(pairs.pop(0), iter(pairs))
            self.assertEqual(ut.tokens, ["   ", "'", "'", "\n", '"', '"'])
            self.assertIs(out, None)

    # Run tests
    unittest.main(TestCase, verbosity=2, exit=False)

# Generated at 2022-06-23 15:54:34.660750
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", maybe("a")
    assert maybe("") == "(" + "|".join("") + ")?" == "()?", maybe("")
    assert maybe("a", "b") == "(a|b)?", maybe("a", "b")
    assert maybe("", "b") == "(|b)?", maybe("", "b")



# Generated at 2022-06-23 15:54:41.323822
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenize = Untokenizer().untokenize
    for args in (
        (("text",), "text"),
        ((("text", (1, 0)),), "text"),
        ((("text", (1, 0)), ("more", (1, 4))), "textmore"),
        ((("text", (2, 0)), ("more", (2, 4))), "\n    textmore"),
        (
            (("text", (2, 0)), ("more", (1, 4))),
            "text\n    more",
        ),
    ):
        assert untokenize(args[0]) == args[1]



# Generated at 2022-06-23 15:54:42.811114
# Unit test for function printtoken
def test_printtoken():
    printtoken(NAME, 'spam', (1,1), (1,2), 'spam')



# Generated at 2022-06-23 15:54:45.356352
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.NAME, 'def', (1, 0), (1, 3), 'def')



# Generated at 2022-06-23 15:54:51.860106
# Unit test for function maybe
def test_maybe():
    any = re.compile("^[ \f\t]*(#.*)?$").match
    assert maybe(r"[ \f\t]+", r"#.*")
    assert any("       #")
    assert any("#")
    assert any("       # ")
    assert any("       #  ")
    assert not any("  #")
    assert not any("  # ")

    whitespace = maybe(r"[ \f\t]*", r"#.*")



# Generated at 2022-06-23 15:54:54.263055
# Unit test for function group
def test_group():
    assert group("a", "b", "cd") == "(a|b|cd)"



# Generated at 2022-06-23 15:55:03.282173
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    toksrc = [(1, "def"), (1, " "), (1, "f"), (1, "("), (1, "x"), (1, ")"), (1, ":"), (1, "\n"), (2, " "), (2, "return"), (2, " "), (2, "x"), (1, "\n"), (0, "")]
    src = untok.untokenize(toksrc)
    assert src == "def f(x):\n  return x\n"


# Generated at 2022-06-23 15:55:14.423996
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import unittest
    from unittest.mock import Mock, patch

    # Using MicroPython's unittest module
    # Test for correct tokens
    class Test_test_Untokenizer(unittest.TestCase):
        def test_untokenize(self):
            untokenize = Untokenizer()
            # Test for correct tokens
            self.assertEqual(
                untokenize.untokenize(
                    [
                        (NUMBER, "1", (1, 0), (1, 1), "1"),
                        (NEWLINE, "\n", (1, 1), (2, 0), "1\n"),
                        (NUMBER, "2", (2, 0), (2, 1), "2"),
                    ]
                ),
                "1\n2 ",
            )
            # Test for correct spacing

# Generated at 2022-06-23 15:55:21.088252
# Unit test for function maybe
def test_maybe():
    set(maybe("a", "b", "c", "def")) == {"abdef", "abcd", "aef",
                                        "acdef", "acd", "ac",
                                        "ab", "ad", "abd"}


Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"[a-zA-Z_]\w*"

Binnumber = r"0[bB][01]*"
Hexnumber = r"0[xX][\da-fA-F]*[lL]?"
Octnumber = r"0[oO]?[0-7]*[lL]?"
Decnumber

# Generated at 2022-06-23 15:55:32.151808
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from .tokenize import generate_tokens
    with open(__file__) as f:
        contents = f.read()
    tokens = generate_tokens(lambda: contents)
    assert tokens is not None
    untok_with_compat = Untokenizer().compat(next(tokens), tokens)
    # assert untok_with_compat is None, "unexpected value %r" % (untok_with_compat,)
    #untok with compat is None
    untok_without_compat = Untokenizer().untokenize(
        generate_tokens(lambda: contents)
    )
    assert untok_without_compat is not None, "unexpected value %r" % (
        untok_without_compat,
    )
    #untok without compat is not None

# Generated at 2022-06-23 15:55:43.274360
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        assert hasattr(e, "args")


# A regular expression matching a piece of text that can be ignored
ignored_text = Ignore.ignore

# Match a string that is not a Python keyword, operator, identifier or literal
# This is what we use to figure out what a token is.

# Generated at 2022-06-23 15:55:52.055453
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    r = io.StringIO("def f(x): return 2*x").readline
    l = []
    tokenize_loop(r, l.append)
    import token

# Generated at 2022-06-23 15:55:55.107145
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", maybe("a")
    assert maybe("a", "b") == "(a|b)?", maybe("a", "b")



# Generated at 2022-06-23 15:55:57.900583
# Unit test for function tokenize
def test_tokenize():
    import io

    rl = io.StringIO("def f(x):\n  return x+1\n").readline
    list(tokenize(rl))



# Generated at 2022-06-23 15:56:00.473957
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing as e:
        assert str(e) == "tokenizing stopped"



# Generated at 2022-06-23 15:56:10.888780
# Unit test for function generate_tokens
def test_generate_tokens():
    # template for testing; populate the 'tests' list at the end
    global tests
    tests = []

    def norm(toktup):
        toktype, tok = toktup[0:2]
        toksource = '"%s"' % tok
        return (toktype, toksource, toktup[2], toktup[3])

    def test(input, output):
        print("test:")
        print(" input: %s" % input)
        print("output: %s" % output)
        print("")
        generate_tokens(iter(input.splitlines()).next, None)
        global tests
        tests.append((input, output))

    # Examples taken from Lib/tokenize.py

    # Control chars.

# Generated at 2022-06-23 15:56:15.018384
# Unit test for function maybe
def test_maybe():
    testcase = ["any", "", "asdf", "asdf"]
    for t in testcase:
        res = re.match(maybe("a", "b", "c"), t)
        assert res

# Generated at 2022-06-23 15:56:20.286450
# Unit test for function any
def test_any():
    assert any('a') == '(a)*'
    assert any('a', 'b') == '(a|b)*'
    assert any('', 'a') == '(|a)*'
    assert any('', '', 'a') == '(|a)*'



# Generated at 2022-06-23 15:56:23.960437
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():  # type: () -> None
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:56:33.276865
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    f = io.StringIO("if 1: #bla\n    x=1\n")
    g = tokenize.generate_tokens(f.readline)
    l = list(g)
    assert len(l) == 7
    assert l[1][0] == token.NUMBER
    assert l[4][0] == token.NAME
    assert l[1][1] == l[4][1] == l[6][1] == "1"
    assert l[3][0] == l[3][0] == token.COMMENT
    assert l[3][1] == "#bla"
    assert l[0][0] == tokenize.INDENT
    assert l[0][1] == "\n"
    assert l[-1][0]

# Generated at 2022-06-23 15:56:42.817509
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("bad token")
    except TokenError as exc:
        assert str(exc) == "bad token"
    try:
        raise TokenError("bad token", (1, 2))
    except TokenError as exc:
        assert str(exc) == "bad token (1, 2)"
    try:
        raise TokenError("bad token", (1, 2), "error")
    except TokenError as exc:
        assert str(exc) == "bad token (1, 2): error"


# Helper functions for marking errors in tokenizer.
# Note that tokenize.TokenError is a subclass of SyntaxError,
# so these may be raised as well.



# Generated at 2022-06-23 15:56:44.515911
# Unit test for function any
def test_any():
    assert any("a", "b") == '(a|b)*'



# Generated at 2022-06-23 15:56:46.479679
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass



# Generated at 2022-06-23 15:56:55.999486
# Unit test for function untokenize
def test_untokenize():
    input = [
        (NAME, 'if'),
        (NAME, 'x'),
        (OP, '>'),
        (NUMBER, '2'),
        (COLON, ':'),
        (NEWLINE, '\n'),
        (INDENT, '    '),
        (NAME, 'print'),
        (NAME, 'x'),
        (NEWLINE, '\n'),
        (DEDENT, ''),
        (NAME, 'else'),
        (COLON, ':'),
        (NEWLINE, '\n'),
        (INDENT, '    '),
        (NAME, 'print'),
        (NAME, 'y'),
        (NEWLINE, '\n'),
        (DEDENT, '')
    ]

# Generated at 2022-06-23 15:56:58.694015
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    class EmptyClass:
        pass

    try:
        raise StopTokenizing()
    except StopTokenizing as e:
        print(e)



# Generated at 2022-06-23 15:57:08.714871
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    result = u.untokenize(
        [
            (NUMBER, "123", (0, 0), (0, 3), "123"),
            (NAME, "var", (0, 4), (0, 7), "var"),
            (OP, "=", (0, 8), (0, 9), "="),
            (STRING, "'value'", (0, 10), (0, 17), "'value'"),
            (NEWLINE, "\n", (0, 17), (1, 0), "\n"),
        ]
    )
    assert result == "123 var = 'value'\n"

    # XXX is this a good default?

# Generated at 2022-06-23 15:57:11.371443
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 'test', (11, 16), (120, 156), 'this is a string')
    assert True
if __name__ == '__main__':
    test_printtoken()


# Generated at 2022-06-23 15:57:13.546631
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass


tok_name = {
    token.ENCODING: "ENCODING",
}



# Generated at 2022-06-23 15:57:15.388851
# Unit test for function tokenize_loop
def test_tokenize_loop():
    tokenize_loop(iter(["if True:"]).__next__, printtoken)



# Generated at 2022-06-23 15:57:27.069264
# Unit test for function group
def test_group():
    # See issue #13415
    assert re.match(group(r"\s+"), " "), "group didn't work (1)"
    assert not re.match(group(r"\s+"), "x"), "group didn't work (2)"
    assert re.match(group(r"\s", "[a-z]"), " "), "group didn't work (3)"
    assert re.match(group(r"\s", "[a-z]"), "a"), "group didn't work (4)"
    assert not re.match(group(r"\s", "[a-z]"), "A"), "group didn't work (5)"
    s = group(r"xx", r"xxxx")
    assert re.match(s, "xxxx"), "group didn't work (6)"

# Generated at 2022-06-23 15:57:37.577625
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    # Read a file and untokenize it, then retokenize and compare the result.
    f = io.BytesIO(b'def f(x): return 2*x\n')
    r = tokenize.generate_tokens(f.readline)
    f.close()
    g = io.BytesIO()
    tokenize.untokenize(r).encode("utf-8").tofile(g)
    g.seek(0, 0)
    result = g.read()
    g.close()
    assert result == b'def f(x):\n return 2*x\n'
    f = io.BytesIO(result)
    result = list(tokenize.generate_tokens(f.readline))
    f.close()

# Generated at 2022-06-23 15:57:46.516371
# Unit test for function detect_encoding
def test_detect_encoding():
    # test no BOM
    def readline_helper():
        yield b"# coding: latin-1"
        yield b"blah blah"
    encoding, lines = detect_encoding(readline_helper())
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1", b"blah blah"]

    # test with BOM
    def readline_helper():
        yield BOM_UTF8
        yield b"# coding: latin-1"
        yield b"blah blah"
    encoding, lines = detect_encoding(readline_helper())
    assert encoding == "utf-8-sig"
    assert lines == [b"# coding: latin-1", b"blah blah"]

    # test with BOM and blank line
   

# Generated at 2022-06-23 15:57:53.260689
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "   doe re mi \n  fa \n\n\n so la ti do  "
    lines = iter(s.splitlines(keepends=True))
    tokenize_loop(lambda: next(lines), printtoken)
    print("-" * 40)



# Generated at 2022-06-23 15:58:00.681111
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.STRING, '"Hello"', (1,0), (1,6), '"Hello"')
    if __name__ == "__main__":
        test_printtoken()

# The following functions are used for the tokenize() generator.
# This generator breaks a stream of text into Python tokens.
# Its structure is inspired by the tokenize() function in tokenize.c.



# Generated at 2022-06-23 15:58:13.921849
# Unit test for function untokenize
def test_untokenize():
    def compare(untok, from_tokens):
        tok = untokenize(iter(from_tokens))
        eq_(tok, untok)
    compare("\n",
            [(tokenize.NL, '\n'), (0, '')])
    compare("''\n",
            [(tokenize.OP, "''"), (tokenize.NL, '\n'), (0, '')])
    compare("x  # comment ends NL\n",
            [(tokenize.NAME, 'x'), (tokenize.NL, '  # comment ends NL\n'),
             (0, '')])

# Generated at 2022-06-23 15:58:22.706534
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()

    # Current values don't matter
    u.prev_col = 5
    u.prev_row = 0

    u.add_whitespace((1, 0))
    assert u.tokens == ["\n"]
    u.tokens[:] = []

    # No change
    u.add_whitespace((0, 5))
    assert u.tokens == []

    # Add whitespace
    u.add_whitespace((0, 10))
    assert u.tokens == ["     "]
    u.tokens[:] = []
    # More whitespace
    u.add_whitespace((0, 20))
    assert u.tokens == ["                    "]
    u.tokens[:] = []

    # New line
    u.add_

# Generated at 2022-06-23 15:58:32.519392
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def check_loop(s, toks):
        tokens = []
        tokenize_loop(s.splitlines().__iter__, tokens.append)
        return tokens == toks
    assert check_loop('a = 1\n', [
        (NAME, 'a', (1, 0), (1, 1), 'a = 1\n'),
        (OP, '=', (1, 2), (1, 3), 'a = 1\n'),
        (NUMBER, '1', (1, 4), (1, 5), 'a = 1\n'),
        (NEWLINE, '\n', (1, 5), (1, 6), 'a = 1\n'),
    ])


ENCODING = "utf-8"
UTF8_BOM = BOM_UTF8.decode(ENCODING)



# Generated at 2022-06-23 15:58:41.973772
# Unit test for function maybe
def test_maybe():
    assert maybe("foo") == "(foo)?", repr(maybe("foo"))
    assert "(foo)?", repr(maybe("foo"))

# Tail end of ' string.
single3 = r"[^'\\]*(?:\\.[^'\\]*)*'''"
double3 = r'[^"\\]*(?:\\.[^"\\]*)*"""'


# Tail end of ''' string.
# single_quoted is used to match outer ''' strings only
# triple_single is used to match inner ''' strings only
single_quoted = r"(?:[^'\\]|\\.)*'"
triple_single = r"(?:[^'\\]|\\.)*'''"

# Tail end of """ string.
# double_quoted is used to match outer """ strings only
# triple_double is used to match inner """ strings

# Generated at 2022-06-23 15:58:52.277060
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import BytesIO
    toks = []
    def tokeneater(*args):
        toks.append(args)
    g = generate_tokens(BytesIO(b"1 +2").readline)
    tokenize_loop(g.__next__, tokeneater)
    assert toks == [
        (NUMBER, "1", (1, 0), (1, 1), "\n"),
        (OP, "+", (1, 1), (1, 2), "\n"),
        (NUMBER, "2", (1, 2), (1, 3), "\n"),
    ]


# Backwards compatible interface

# Generated at 2022-06-23 15:58:54.125790
# Unit test for function printtoken
def test_printtoken():
    printtoken(0, '1+2', (0,0), (0,0), '3.14')



# Generated at 2022-06-23 15:58:59.977853
# Unit test for function generate_tokens
def test_generate_tokens():
    s = "[1, 2, 3]"
    result = []
    for tok in generate_tokens(iter(s.splitlines()).__next__):
        result.append(tok)

# Generated at 2022-06-23 15:59:11.221871
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from collections import namedtuple

    def Test(iterable, output):
        result = Untokenizer().untokenize(iterable)
        assert result == output, (result, output)

    Token = namedtuple("Token", "type string start end line")


# Generated at 2022-06-23 15:59:16.639520
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    toks = u.compat((NUMBER, "1"), [(NAME, "a"), (NAME, "b"), (NUMBER, "2")])
    assert u.tokens == [NUMBER, "1", "a", "b", NUMBER, "2"], u.tokens


compat_tokenize = tokenize



# Generated at 2022-06-23 15:59:26.714486
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    for i in range(2):
        for j in range(1, 5):
            u.prev_row = i
            u.prev_col = 0
            u.add_whitespace((i, j))
            assert " " * j == u.tokens[-1]
            u.tokens = []

        u.prev_row = i
        for j in range(5):
            for k in range(1 + i * 10, 11 + i * 10):
                u.prev_col = k
                u.add_whitespace((i, k + j + 1))
                assert " " * (j + 1) == u.tokens[-1]
                u.tokens = []



# Generated at 2022-06-23 15:59:39.280950
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    """
    test the untokenize function for a few different input cases
    """
    import unittest

    class TestCompat(unittest.TestCase):
        def test_basic(self):
            """test simple, basic functionality of Untokenizer.compat"""
            un = Untokenizer()
            iterable = [(1, "a"), (5, " "), (5, "\n"), (5, "\n")]
            self.assertEqual(un.compat(iterable[0], iterable[1:]), None)
            self.assertEqual(un.tokens, ["a"])

        def test_indent(self):
            """test that indents are correctly skipped and continued"""
            un = Untokenizer()

# Generated at 2022-06-23 15:59:45.168401
# Unit test for function tokenize
def test_tokenize():
    s = "def f():\n  return 'abc'"
    g = generate_tokens(iter(s.splitlines(1)).__next__)
    for toktuple in g:
        toktype, toktext = toktuple[0:2]
        print(toktype, toktext)



# Generated at 2022-06-23 15:59:48.966983
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 2))
    assert u.tokens == ["  "]



# Generated at 2022-06-23 16:00:02.360173
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # This tests the case where the next token follows the previous one
    # without a newline, and where it is indented more than the previous
    # token, and where the previous token ended exactly at the previous
    # line's end.

    # The expected result is that the untokenized string has a tab in it
    # where the new token starts.

    # Construct an Untokenizer object.
    untokenizer = Untokenizer()

    # Set initial values of its prev_row, prev_col attributes.
    untokenizer.prev_row = 1
    untokenizer.prev_col = 8

    # Set its tokens attribute to an empty list.
    untokenizer.tokens = []

    # Call its add_whitespace method.
    untokenizer.add_whitespace((1, 9))

    # Check that its tokens attribute

# Generated at 2022-06-23 16:00:06.308302
# Unit test for function generate_tokens
def test_generate_tokens():
    data = "for i in range(10): print(i)"
    gt = generate_tokens(iter(data.splitlines()).next)
    print(list(gt))

    def readline(x):
        try:
            return x.next()
        except AttributeError:
            return next(x)

    # Generate tokens from a list
    data = ["100", "2.3", "4", "a", "'''"]
    gt = generate_tokens(readline, data)
    print(list(gt))


# Generated at 2022-06-23 16:00:13.496413
# Unit test for function any
def test_any():
    # Match any occurrences of the given strings, separated by any amount of
    # whitespace.
    assert any("a", "b", "c") == "(a|b|c)*"
    assert any("a", "b", "c", "d") == "(a|b|c|d)*"
    assert any("a") == "(a)*"
    assert any() == "()*"
# End unit test for function any



# Generated at 2022-06-23 16:00:15.973599
# Unit test for constructor of class TokenError
def test_TokenError():
    # test constructor calls
    TokenError()
    TokenError("testing")
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 16:00:21.006395
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    result = untok.compat((NAME, "abc"), [(NAME, "def"), (NAME, "ghi")])
    assert untok.tokens == ["abc ", "def ", "ghi"]


# backwards compatible interface

# Generated at 2022-06-23 16:00:23.120771
# Unit test for function maybe
def test_maybe():
    result = maybe("abc", "def")
    assert result == "(abc|def)?"



# Generated at 2022-06-23 16:00:29.847211
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_col = 4
    u.prev_row = 1
    u.add_whitespace((1, 6))
    assert u.tokens == ["  "]
    u.add_whitespace((1, 4))
    assert u.tokens == ["  "]
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", "  "]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", "  ", "\n"]



# Generated at 2022-06-23 16:00:38.957661
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    _tokens = [
        (tokenize.ERRORTOKEN, "invalid"),
        (tokenize.NAME, "string1"),
        (tokenize.NAME, "string2"),
        (token.NEWLINE, "\n"),
        (token.INDENT, "    "),
        (token.NAME, "string3"),
        (token.DEDENT, ""),
    ]
    ret = "invalid string1 string2\nstring3"
    assert u.untokenize(_tokens) == ret



# Generated at 2022-06-23 16:00:48.246092
# Unit test for function untokenize
def test_untokenize():
    test_cases = [
        ("", ""),
        ("a", "a"),
        ("a b", "a b"),
        ("a\nb", "a\nb"),
        ("a b c", "a b c"),
        ("a \n\n  b", "a\n\n  b"),  # check no blank line between a & b
        ("a # foo\n\n  b", "a\n\n  b"),
        ("a#foo\n\n  b", "a\n\n  b"),
        ("a#foo\n  b", "a\n  b"),
        ("a # foo\n  b", "a\n  b"),
        ("a # foo\nb", "a\nb"),
        ("a\n# foo\nb", "a\nb"),
        ]
   

# Generated at 2022-06-23 16:00:56.527407
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from blib2to3.pgen2.tokenize import (
        TokenInfo,
        generate_tokens,
    )
    from blib2to3.pgen2.tokenize import untokenize

    u = Untokenizer()
    in_lines = [
        "def f(x):",
        "    print x",
        "    yield 1",
        "    yield x + 5",
        "",
        "def g():",
        "    if 1:",
        "        print('one')",
        "    if 2:",
        "        print('two')",
        "",
        "g(f(1),",
        "  f(2),",
        "  f(3))",
    ]

# Generated at 2022-06-23 16:01:08.283808
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from io import BytesIO
    from blib2to3.pytree import convert
    with open("Lib/tokenize.py") as f:
        text = f.read()
    text = text.replace("\n", " ")
    encoding = "utf-8"
    fileobj = io.BytesIO(text.encode(encoding))
    fileobj.mode = "r"
    t1 = convert(tokenize.generate_tokens(fileobj.readline))
    untok = tokenize.Untokenizer()
    text = untok.untokenize(t1)
    fileobj = io.BytesIO(text.encode(encoding))
    fileobj.mode = "r"

# Generated at 2022-06-23 16:01:11.322072
# Unit test for function any
def test_any():
    assert re.sub(any('a', 'bc'), ' ', 'abc') == ' '



# Generated at 2022-06-23 16:01:22.547246
# Unit test for function tokenize
def test_tokenize():
    lines = []
    for i in range(1,11): lines.append(str(i)+"\n")
    lines.append("")
    def readline():
        try: return lines.pop(0)
        except IndexError: return ""
    tokenize(readline)
    def readline():
        try: return lines.pop(0)
        except IndexError: raise StopTokenizing
    tokenize(readline)
    def readline():
        try: return lines.pop(0)
        except IndexError: raise TokenError
    try:
        tokenize(readline)
    except TokenError:
        pass
    def readline():
        try:
            return lines.pop(0)
        except IndexError:
            raise ValueError