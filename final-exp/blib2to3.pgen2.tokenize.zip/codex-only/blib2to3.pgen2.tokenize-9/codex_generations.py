

# Generated at 2022-06-23 15:51:25.386856
# Unit test for function tokenize_loop

# Generated at 2022-06-23 15:51:29.850331
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    data = [(1, 'def'), (0, ' '), (1, 'f'), (0, '('), (1, ')'), (0, ':')]
    un = Untokenizer()
    res = un.compat(data[0], data[1:])
    assert un.tokens == ['def ', '(', ')', ':'], un.tokens
    assert res is None, res



# Generated at 2022-06-23 15:51:34.100983
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from six import StringIO

    s = StringIO("tokenize_loop\n")
    tokenize_loop(s.readline, printtoken)



# Generated at 2022-06-23 15:51:35.551745
# Unit test for constructor of class TokenError
def test_TokenError():
    err = TokenError()
    assert err.args == ()



# Generated at 2022-06-23 15:51:46.993899
# Unit test for function generate_tokens
def test_generate_tokens():
    from unittest import TestCase

    class Test(TestCase):
        def check_tokenize(self, source, tokens):
            result = [tok[:2] for tok in generate_tokens(iter(source.splitlines(1)).__next__)]
            self.assertEqual(result, tokens)


# Generated at 2022-06-23 15:51:59.369150
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    r = io.StringIO("print('Hi Mom')\n")
    result = []
    def tokeneater(*args):
        result.append(args)
    tokenize_loop(r.readline, tokeneater)
    assert result[1] == (token.NAME, "print", (1, 0), (1, 5), "print('Hi Mom')\n")
    assert result[2] == (token.OP, "(", (1, 5), (1, 6), "print('Hi Mom')\n")
    assert result[3] == (token.STRING, "'Hi Mom'", (1, 6), (1, 14), "print('Hi Mom')\n")

# Generated at 2022-06-23 15:52:03.327868
# Unit test for constructor of class TokenError
def test_TokenError():
    assert TokenError(3).args == (3,)

    try:
        raise TokenError(1, 2, 3)
    except TokenError as exc:
        assert exc.args == (1, 2, 3)
    else:
        assert False, "TokenError not raised"



# Generated at 2022-06-23 15:52:07.488253
# Unit test for function generate_tokens

# Generated at 2022-06-23 15:52:20.658666
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    result = u.untokenize([(NUMBER, "1"), (NEWLINE, "\n"), (NUMBER, "2")])
    assert result == "1 2"
    result = u.untokenize([(NUMBER, "1"), (INDENT, "  "), (NUMBER, "2")])
    assert result == "1  2"
    result = u.untokenize([(NUMBER, "1"), (INDENT, "  "), (NUMBER, "2"), (DEDENT, "")])
    assert result == "1  2"
    result = u.untokenize([(NUMBER, "1"), (DEDENT, "")])
    assert result == "1"

# Generated at 2022-06-23 15:52:33.946447
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"pass\n"
    result = detect_encoding(readline)
    assert result == ("iso-8859-1", [b"# coding: latin-1\n"])
    readline = iter(
        [
            b"#!/usr/bin/python\n",
            b"# coding: latin-1\n",
            b"pass\n",
            b"# more\n",
            b"# coding=utf-8\n",
            b"pass\n",
            b"# more\n",
            b"# coding=cp437\n",
            b"pass\n",
        ]
    ).__next__
    result = detect_encoding(readline)

# Generated at 2022-06-23 15:52:45.444432
# Unit test for function generate_tokens
def test_generate_tokens():
    def readline():
        for line in lines:
            yield line

    lines = ["xxx = 3\n", "yy = 4\n", "zzz = 5\n"]

# Generated at 2022-06-23 15:52:55.104786
# Unit test for function maybe
def test_maybe():
    assert maybe(r'123') == r'(123)?', maybe(r'123')
    assert maybe(r'123', r'456') == r'(123|456)?', maybe(r'123', r'456')

# Returning a string here causes problems because of the way Python handles
# string constants (by interning them!)
_whitespace = group(r'[ \f\t]*', r'#[^\r\n]*')
_name = r'[a-zA-Z_]\w*'

# A name is a general name, or the name of an import, or an attribute name.
_name_or_import = group(_name, r'\.\.\.', r'[.]' + _name, r'[.]' + _name )

# Note that a dot can also be part of a

# Generated at 2022-06-23 15:53:06.173410
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import tokenize
    untok = tokenize.Untokenizer()
    untok.tokens = []
    untok.prev_row = 1
    untok.prev_col = 0
    f = io.StringIO("hi\nbye\n")
    for token in tokenize.generate_tokens(f.readline):
        untok.add_whitespace(token[2])
        untok.tokens.append(token[1])
        untok.prev_row, untok.prev_col = token[3]
    print(untok.tokens)
    print(untok.untokenize(tokenize.generate_tokens(f.readline)))



# Generated at 2022-06-23 15:53:14.970667
# Unit test for function untokenize
def test_untokenize():
    def compare(untok, expected):
        untok = untok.replace("\r\n", "\n")
        expected = expected.replace("\r\n", "\n")
        assert untok == expected, (
            "expected %r, got %r" % (expected, untok)
        )


# Generated at 2022-06-23 15:53:16.889055
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "20", (0,0), (0,1), "")

# unit test
# test_printtoken()


# Generated at 2022-06-23 15:53:21.161959
# Unit test for function maybe
def test_maybe():
# #XXX Doesn't compile with mypy
#     """
#     >>> assert maybe('"') == '("?)'
#     >>> assert maybe('"', "\\w") == '("|\\\\w)*'
#     """
    assert maybe('"') == '("?)'
    assert maybe('"', "\\w") == '("|\\\\w)*'


# Generated at 2022-06-23 15:53:25.667514
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    ut = Untokenizer()

# intraline whitespace
# technically, the rows below should not be joined, but we don't care
# XXX what if there is no newline at the end of the file?
# tokeneater is a generator

# Generated at 2022-06-23 15:53:30.406025
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token

    tokens = []
    for t in generate_tokens(io.StringIO("a = 1 + 2").readline):
        tokens.append(t)

    assert tokens[0] == (1, "a")
    assert tokens[1] == (61, "=")
    assert tokens[2] == (1, "1")
    assert tokens[3] == (43, "+")
    assert tokens[4] == (1, "2")
    assert tokens[5] == (0, "")

    assert tokens[6] == (token.ENDMARKER, "")



# Generated at 2022-06-23 15:53:41.292960
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    """
    Verify that the untokenize method of the Untokenizer class returns a
    semantically equivalent program to the one fed to it as input.

    Limitations:
        - All tokens must be on a single line.
        - The input must only contain complete statements.  In
        particular, compound statements (those containing '{' and '}'
        tokens) must each be on a single line.
    """
    import io
    import tokenize
    import unittest
    import types
    import textwrap

    class UntokenizeTest(unittest.TestCase):
        def _test_equal(self, input):
            pretty, ugly = textwrap.dedent(input).strip().split("\n\n")
            io_obj = io.StringIO(ugly)

# Generated at 2022-06-23 15:53:54.107844
# Unit test for function group
def test_group():
    assert group("ab", "cd") == "(ab|cd)"
    assert group("a(?:b|c)", "d") == "(a(?:b|c)|d)"

# Tailor token.py to hardcode the regexes we need to match here.
token.tok_name["COMMENT"] = "COMMENT"
token.NL = r"(?:\r\n|[\n\r])"
token.COMMENT = token.N_TOKENS
token.tok_name[token.COMMENT] = "COMMENT"
token.tok_regex = [
    token.endmarker,
    token.name,
    token.number,
    token.string,
    token.NEWLINE,
    token.ENDMARKER,
]


# Generated at 2022-06-23 15:54:05.515481
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 3
    u.prev_col = 5
    u.add_whitespace((3, 10))
    assert u.tokens == ["     "]
    u.add_whitespace((4, 0))
    assert u.tokens == ["     ", "\n"]
    u.add_whitespace((3, 7))
    assert u.tokens == ["     ", "\n", "  "]
    #
    class Bogus:
        pass

    try:
        u.add_whitespace(Bogus())
    except AssertionError:
        pass
    else:
        raise AssertionError("expected an AssertionError")

# Generated at 2022-06-23 15:54:06.763311
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:54:15.671468
# Unit test for function detect_encoding
def test_detect_encoding():
    invalid_cookie = "# coding: 1234\n"
    correct_cookie = "# coding: iso-8859-15\n"
    utf8_bom = "\xef\xbb\xbf"
    utf8_cookie = "# coding: utf-8\n"
    no_bom_no_cookie = "test = 1\n"
    blank_line = "\n"

    def create_test(first="", second="", third=""):
        def readline_gen():
            for line in first, second, third:
                yield line
        return readline_gen

    def assert_encoding(first, second, third, expected):
        res = detect_encoding(create_test(first, second, third))
        assert res == (expected, [first, second, third])

# Generated at 2022-06-23 15:54:17.985425
# Unit test for function printtoken
def test_printtoken():
    r = printtoken(0,'',(0,0),(1,1),'')


# Generated at 2022-06-23 15:54:30.124561
# Unit test for function tokenize
def test_tokenize():
    import io

    test_tokenize_doc = """>>> from io import StringIO
>>> from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP, printtoken
>>> readline = StringIO('  1 + 1  ').readline
>>> def tokeneater(*args):
...     printtoken(*args)
>>> tokenize(readline, tokeneater)
2,0-2,1:    NUMBER     '1'
2,2-2,3:    OP         '+'
2,4-2,5:    NUMBER     '1'
"""

    save_stdout = sys.stdout

# Generated at 2022-06-23 15:54:31.797083
# Unit test for function group
def test_group():
    assert group(r"\(", r"\)") == r"\(\)|\)"

# Generated at 2022-06-23 15:54:37.016538
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    try:
        raise TokenError("xyz")
    except TokenError as e:
        assert e.args[0] == "xyz"


_tokenize_cache: List[Tuple[Text, Callable[[Union[Text, bytes]], Text]]] = []



# Generated at 2022-06-23 15:54:39.594706
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"



# Generated at 2022-06-23 15:54:45.908765
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 1
    u.add_whitespace((1, 1))
    u.add_whitespace((1, 2))
    assert "".join(u.tokens) == ""

    u.tokens = []
    u.add_whitespace((1, 2))
    assert "".join(u.tokens) == " "

    u.tokens = []
    u.prev_row = 1
    u.prev_col = 2
    u.add_whitespace((1, 0))
    assert "".join(u.tokens) == ""

    u.tokens = []
    u.prev_row = 1
    u.prev_col = 1
    u.add_whitespace

# Generated at 2022-06-23 15:54:52.763487
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    s = """while 1:
    print '%d %d\\n' % (x, y)
"""
    from io import StringIO
    from blib2to3.pgen2.tokenize import tokenize

    f = StringIO(s)
    tokens = list(tokenize(f.readline))

    u = Untokenizer()
    s = u.compat(tokens[0], iter(tokens[1:]))
    assert "".join(u.tokens) == s



# Generated at 2022-06-23 15:54:57.304054
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass


# Exception raised when encoding/decoding tokens fails.
# Note that all strings passed to the tokenizer are Unicode.

# Generated at 2022-06-23 15:55:09.902822
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    unt = Untokenizer()
    unt.add_whitespace((1, 0))
    unt.tokens.append('a')
    unt.tokens.append('b')
    unt.tokens.append('c')
    unt.tokens.append('d')
    unt.tokens.append('e')
    unt.tokens.append('f')
    unt.tokens.append('g')
    assert unt.tokens == ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    unt.add_whitespace((1, 4))
    assert unt.tokens == ['a', 'b', 'c', 'd', ' ', 'e', 'f', 'g']
    unt.prev_col = 7
    unt.add_whitespace

# Generated at 2022-06-23 15:55:11.203098
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:55:20.344839
# Unit test for function printtoken
def test_printtoken():
    def check_toks(toks, expect):
        print("toks:", toks)
        print("expect:", expect)
        result = []
        if hasattr(toks, "__enter__"):
            with toks as gen:
                for token in gen:
                    result.append(token)
        else:
            for token in toks:
                result.append(token)
        if result != expect:
            raise ValueError(
                f"generate tokens output mismatch:\nresult:\n{result}\nexpect:\n{expect}"
            )


# Generated at 2022-06-23 15:55:23.113430
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import BytesIO
    tokenize_loop(lambda: BOM_UTF8 + b"def f():\n  return 3", printtoken)
    tokenize_loop(
        lambda: BytesIO(BOM_UTF8 + b"def f():\n  return 3").readline, printtoken
    )



# Generated at 2022-06-23 15:55:34.332628
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    uns = Untokenizer()
    assert uns.tokens == []
    uns.tokens.append("asdf")
    uns.add_whitespace((1, 5))
    assert uns.tokens == ["asdf", " "]
    uns.tokens.append("asdf")
    uns.add_whitespace((1, 3))
    assert uns.tokens == ["asdf", " ", "asd"]
    uns.tokens.append("asdf")
    uns.add_whitespace((1, 0))
    assert uns.tokens == ["asdf", " ", "asd"]
    uns.tokens.append("asdf")
    uns.add_whitespace((2, 0))

# Generated at 2022-06-23 15:55:42.635026
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 4))
    assert u.tokens == ["    "]
    u.add_whitespace((2, 0))
    assert u.tokens == ["    "]
    u.add_whitespace((3, 0))
    assert u.tokens == ["    "]
    u.add_whitespace((3, 4))
    assert u.tokens == ["    ", "    "]



# Generated at 2022-06-23 15:55:44.003863
# Unit test for function group
def test_group():
    assert group(["abc", "def"]) == "(abc|def)"



# Generated at 2022-06-23 15:55:49.842847
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "x"), (2, " "), (3, "y")]) == "x y"
    assert u.untokenize([(0, "x"), (0, " "), (0, "y")]) == "x y"
    assert u.untokenize([(0, "x"), (0, "\n"), (0, ""), (0, "y")]) == "x\ny"



# Generated at 2022-06-23 15:55:51.593644
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:55:55.454831
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        if e.__class__ is StopTokenizing:
            print("Passed")
        else:
            print("Failed")



# Generated at 2022-06-23 15:56:05.083959
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    expr = [(_tokenize("42"),
        [('NAME', 'x', 0, 1, ''), ('NAME', '=', 2, 3, ''), ('NUMBER', '42', 4, 7, ''), ('NEWLINE', '\n', 7, 7, ''), ('ENDMARKER', '', 7, 7, '')],
        "x = 42\n")]
    for toklist, resultlist, src in expr:
        u.compat(toklist, iter(resultlist))
        assert u.tokens == [src], ("%r != %r" % (u.tokens, [src]))
        u.tokens = []



# Generated at 2022-06-23 15:56:08.581233
# Unit test for constructor of class TokenError
def test_TokenError():
    # type: () -> None
    try:
        raise TokenError("test")
    except TokenError as err:
        assert str(err) == "test"
    else:
        assert False



# Generated at 2022-06-23 15:56:12.037075
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()

    # Test the untokenize method of the Untokenizer class
    #    untok.compat((NAME, "name"), ((NAME, "name"), (NUMBER, "num")))



# Generated at 2022-06-23 15:56:19.228486
# Unit test for function tokenize
def test_tokenize():
    from blib2to3.pgen2.tokenize import (
        tokenize,
        OpenBracket,
        CloseBracket,
        String,
        INDENT,
        DEDENT,
        ENCODING,
        tok_name,
        NUMBER,
        NAME,
        opmap,
        NL,
    )

    from io import StringIO

    f = StringIO("def f(x): return x+1\n")
    l = []
    g = tokenize(f.readline)
    for t in g:
        l.append(t)

# Generated at 2022-06-23 15:56:24.052021
# Unit test for function generate_tokens
def test_generate_tokens():
    readline = iter(test_tokenize.test_cases).__next__
    for args in generate_tokens(readline):
        print(args)



# Generated at 2022-06-23 15:56:25.664916
# Unit test for constructor of class TokenError
def test_TokenError():
    x = TokenError("bad token")
    assert str(x) == "bad token"



# Generated at 2022-06-23 15:56:34.173365
# Unit test for function generate_tokens
def test_generate_tokens():
    def _tokens(s: str) -> Iterator[TokenInfo]:
        import io

        return generate_tokens(io.StringIO(s).readline)

    def _reprtokens(tokens: Iterator[GoodTokenInfo]) -> str:
        return "".join(f"{repr(t[:4])}#{t[4].rstrip()}\n" for t in tokens)

    def test(s: str) -> str:
        return _reprtokens(_tokens(s))

    assert test("") == ""
    assert test("#") == repr((COMMENT, "#", (1, 0), (1, 1), "#\n")) + "\n"

# Generated at 2022-06-23 15:56:44.175170
# Unit test for function detect_encoding

# Generated at 2022-06-23 15:56:50.890886
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_row = 1
    ut.prev_col = 0
    ut.add_whitespace((1, 5))
    assert ut.tokens == ["     "]
    ut.add_whitespace((1, 7))
    assert ut.tokens == ["     ", "  "]
    ut.add_whitespace((5, 5))
    assert ut.tokens == ["     ", "  ", "\n\n\n\n  "]



# Generated at 2022-06-23 15:56:57.182463
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize, tok_name
    from typing import List
    s = """\
    def f():
        a = 1
        b = 2
        [x for x in range(5)]
    """
    tokens = list(generate_tokens(StringIO(s).readline))
    print(tokens)
    print(untokenize(tokens))

test_Untokenizer_compat()


# Generated at 2022-06-23 15:57:02.280448
# Unit test for function printtoken
def test_printtoken():
    printtoken('TEST', 'TEST', (1,0), (1,4), 'TEST')

_compile_regex = re.compile("[*+?]?=|(\\{\\d+,\\d+\\}|\\{\\d+,\\})")
_find_repeats = re.compile("\\({\\d+,}|{\\d+,}|\\({\\d+,\\d+\\}|{,\\d+}")
_compile_error = re.error


# Generated at 2022-06-23 15:57:04.116887
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "token", (0, 0), (0, 0), "line")



# Generated at 2022-06-23 15:57:11.817749
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    U = Untokenizer()
    U.add_whitespace( (1,2) )
    U.prev_row = 2
    U.prev_col = 3
    U.add_whitespace( (2,3) )
    U.add_whitespace( (2,4) )
    U.add_whitespace( (2,5) )
    U.add_whitespace( (2,6) )
    assert U.tokens == [" ", " ", " ", " ", " "]


# Generated at 2022-06-23 15:57:17.710425
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# foo\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# foo\n"]

    def readline():
        yield b"#! /usr/bin/env python # coding: latin-1\n"
        yield b"# foo\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"#! /usr/bin/env python # coding: latin-1\n", b"# foo\n"]


# Generated at 2022-06-23 15:57:28.997911
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def test_tokenize(input_string):
        def return_lines():
            for line in input_string.split("\n"):
                yield line

        readline = return_lines().__next__
        tokeneater = generate_tokens("").send
        return list(generate_tokens(readline))

    def test_tokenize_input(input_string, expected):
        result = test_tokenize(input_string)
        assert result == expected, (result, expected)

    test_tokenize_input("1234", [(NUMBER, "1234", (1, 0), (1, 4), "1234")])
    test_tokenize_input("1234 #comment\n", [(NUMBER, "1234", (1, 0), (1, 4), "1234")])
    test_token

# Generated at 2022-06-23 15:57:39.128346
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.add_whitespace( (1,0) )
    assert u.tokens==[], "Wrong untokenizer add_whitespace implementation"
    u.add_whitespace( (2,0) )
    assert u.tokens==[], "Wrong untokenizer add_whitespace implementation"
    u.add_whitespace( (2,2) )
    assert u.tokens==['  '], "Wrong untokenizer add_whitespace implementation"
    u.add_whitespace( (3,0) )
    assert u.tokens==['  '], "Wrong untokenizer add_whitespace implementation"
    u.add_whitespace( (3,2) )

# Generated at 2022-06-23 15:57:44.466947
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row, u.prev_col = 1, 0
    u.add_whitespace((1, 0))
    u.add_whitespace((1, 2))
    assert u.tokens == ["  "]
    u.add_whitespace((1, 0))
    assert u.tokens == ["  "]
    u.add_whitespace((2, 0))



# Generated at 2022-06-23 15:57:52.684592
# Unit test for function maybe
def test_maybe():
    _regex_maybe = regex.compile(maybe('aaa', 'bbb'))
    assert _regex_maybe.match('bbb')
    assert _regex_maybe.match('aaaaaaaaaaa')
    assert _regex_maybe.match('cccc') is None


Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)

Name = r"[a-zA-Z_]\w*"

Hexnumber = r"0[xX][\da-fA-F]+[lL]?"
Octnumber = r"(0[oO][0-7]+)|(0[0-7]*)[lL]?"
Binn

# Generated at 2022-06-23 15:57:58.486388
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    iterable = [('NAME_Y', 'import'),
                ('NAME_Z', 'sys'),
                ('OP_GLOB', '*'),
                ('ENDMARKER_1', '')]
    untok.compat(iterable[0], iterable[1:])
    assert untok.tokens == ['import ', 'sys ', '*']
test_Untokenizer_compat()
del test_Untokenizer_compat



# Generated at 2022-06-23 15:58:00.588091
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []



# Generated at 2022-06-23 15:58:13.740295
# Unit test for function untokenize
def test_untokenize():
    import io, tempfile, tokenize
    # Return the next line of a stream
    def getline(stream):
        return stream.readline()
    # Test the round-trip invariant for small inputs
    test_string = "def f(x): return 2*x"
    readline = iter(test_string.splitlines()).__next__
    tokens = tokenize.generate_tokens(getline)
    newcode = untokenize(tokens)
    newreadline = iter(newcode.splitlines()).__next__
    newtokens = tokenize.generate_tokens(newreadline)
    assert list(tokens) == list(newtokens)
    # Create a temporary file containing a function definition
    fd, filename = tempfile.mkstemp()
    f = os

# Generated at 2022-06-23 15:58:24.756734
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    f = io.StringIO("if 1:\n  pass\n")
    tokens = tokenize.generate_tokens(f.readline)

# Generated at 2022-06-23 15:58:34.216608
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from textwrap import dedent

    source = dedent(
        """\
        # This is test code
        class Test(object):
            a = 1
            b = 2
        """
    )

# Generated at 2022-06-23 15:58:41.464912
# Unit test for function untokenize
def test_untokenize():
    # Round-trip test for tokenize
    def test():
        for i in range(1, len(tokenize.__doc__)-1):
            s = tokenize.__doc__[i : i+1]
            t1 = [tok[:2] for tok in generate_tokens(iter(s).next)]
            newcode = untokenize(t1)
            readline = iter(newcode.splitlines(1)).next
            t2 = [tok[:2] for tok in generate_tokens(readline)]
            assert t1 == t2
    test()
    print('untokenize: The round-trip test passes...')
    # Test: untokenizing something untokenizable
    teststr = 'class="foo"'

# Generated at 2022-06-23 15:58:43.838911
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:58:50.406458
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import tokenize
    r = io.BytesIO(b"def f(x):\n    return 2*x\n")
    u = Untokenizer()
    alltokens = list(tokenize.generate_tokens(r.readline))
    res = u.untokenize(alltokens)
    assert res == "def f(x):\n    return 2*x\n", res



# Generated at 2022-06-23 15:58:54.819525
# Unit test for constructor of class TokenError
def test_TokenError():
    global TokenError
    try:
        TokenError("Test")
    except TokenError:
        pass
    except Exception:
        print("FAIL: Incorrect exception raised")



# Generated at 2022-06-23 15:58:56.912731
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
    assert any("ab") == "(ab)*"



# Generated at 2022-06-23 15:59:04.504451
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO

    from . import token

    with StringIO("ho 'hello' 'hi ") as fin:
        fin.line = "ho 'hello' 'hi "
        for (
            type,
            token,
            (srow, scol),
            (erow, ecol),
            line,
        ) in generate_tokens(fin.readline):
            print(
                "%-20s%-15r %-20s %s"
                % (
                    tokenize.tok_name.get(type, type),
                    token,
                    "{}:{}".format(srow, scol),
                    line,
                )
            )



# Generated at 2022-06-23 15:59:14.872784
# Unit test for function maybe
def test_maybe():
    assert maybe(r"a*", r"b*") == r"(a*|b*)?"


_NAME_RE = r"[a-zA-Z_]\w*"

_DEC_INT = r"0|[1-9]\d*"
_OCT_INT = r"0[oO]\d+"
_HEX_INT = r"0[xX][\da-fA-F]+"

_BIN_INT = r"0[bB][01]+"

# Tail end of ' string.
_STR_END = r"(?:%(eol)s|\Z)"

# Tail end of " string.
_SQ3_RE = r"(?:%(eol)s|\Z)"



# Generated at 2022-06-23 15:59:25.829752
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.tokens = []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]

    u.tokens = []
    u.add_whitespace((1, 2))
    assert u.tokens == ["  "]

    u.tokens = []
    u.add_whitespace((2, 0))
    assert u.tokens == ["\n"]

    u.tokens = []
    u.add_whitespace((2, 1))
    assert u.tokens == ["\n", " "]

    u.tokens = []
    u.add_whitespace((0, 0))
    u.prev

# Generated at 2022-06-23 15:59:28.289024
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "for i in range(10): print(i)\n"
    g = tokenize_loop(s.splitlines().__iter__().__next__, printtoken)
    # if __name__ == '__main__': tokenize_loop(readline, printtoken)



# Generated at 2022-06-23 15:59:40.578961
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    def _test_Untokenizer(input_, *outputs):
        ut = Untokenizer()
        result = ut.compat(input_, [])
        assert result == outputs
    #
    def _test_input(inputStr):
        return (ENCODING, inputStr)
    #
    _test_Untokenizer(_test_input("utf8"), "utf8")
    _test_Untokenizer(_test_input("utf-8"), "utf-8")
    _test_Untokenizer(
        _test_input("utf-8"), "utf16", "utf16-be", "utf16-le", "utf-8-sig"
    )
    _test_Untokenizer(_test_input("utf-16"), "utf-16")

# Generated at 2022-06-23 15:59:44.902085
# Unit test for function maybe
def test_maybe():
    import unittest

    class TestMaybe(unittest.TestCase):
        def test_maybe(self):
            self.assertEqual(maybe('a'), '(a)?')
            self.assertEqual(maybe('a', 'b'), '(a|b)?')

    try:
        unittest.main()
    except SystemExit:
        pass



# Generated at 2022-06-23 15:59:46.375081
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", maybe("a")



# Generated at 2022-06-23 15:59:48.967439
# Unit test for function group
def test_group():
    result = group("a", "bb", "ccc")
    assert result == "(a|bb|ccc)", result



# Generated at 2022-06-23 15:59:58.021431
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding=utf-8\n"
        if False:
            yield None

    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8\n"])
    def readline():
        yield b'\xef\xbb\xbf# coding=utf-8\n'
        if False:
            yield None

    assert detect_encoding(readline) == ("utf-8-sig", [b'# coding=utf-8\n'])
    def readline():
        yield b"#coding=utf-8\n"
        if False:
            yield None

    assert detect_encoding(readline) == ("utf-8", [b"#coding=utf-8\n"])
    def readline():
        yield

# Generated at 2022-06-23 16:00:07.282515
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from random import randint

    from .tokenize import tokenize, NUMBER, STRING, NAME, OP

    test_input = [
        (NAME, "test"),
        (OP, "+"),
        (NAME, "test"),
        (STRING, '"'),
        (STRING, '"'),
        (OP, "+"),
        (NUMBER, "10"),
        (OP, "+"),
        (OP, "+"),
        (NUMBER, "12"),
    ]

    u = Untokenizer()
    u.compat(test_input[0], test_input[1:])

    t = tokenize(iter(u.tokens).__next__)
    for expected, got in zip(test_input, t):
        assert expected == got



# Generated at 2022-06-23 16:00:14.530156
# Unit test for function any
def test_any():
    # Any number of any of these
    assert any('a', 'b', 'c') == "(a|b|c)*"
    # Any number of any of anything
    assert any(['a', 'b', 'c']) == "(a|b|c)*"
    # Any number of any of these, with a bit at the start
    assert any('a', 'b', 'c', prefix='x') == "x(a|b|c)*"



# Generated at 2022-06-23 16:00:26.470515
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline_mock(lines: List[str]):
        def readline():
            return lines.pop().encode("utf-8")

        return readline

    def test_detect(lines: List[str], expected: str) -> None:
        encoding, lines = detect_encoding(readline_mock(lines + []))
        assert encoding == expected
        assert lines == []

    test_detect([], "utf-8")
    test_detect(["\ufeffabc"], "utf-8-sig")
    test_detect(["abc"], "utf-8")
    test_detect(["# -*- coding: ascii -*-"], "ascii")

# Generated at 2022-06-23 16:00:34.299250
# Unit test for function tokenize
def test_tokenize():
    import io, sys
    if sys.version_info[0] >= 3:
        readline = io.StringIO(u"def f(x): return 2*x").readline
    else:
        readline = io.BytesIO(b"def f(x): return 2*x").readline
    tokenize(readline)
    readline = io.StringIO(u"def g(): return 'abc'+'def'\n").readline
    tokenize(readline)



# Generated at 2022-06-23 16:00:46.719851
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io, _tokenize
    readline = _tokenize.BytesIO(
        b'def f(x):\n    return x+1\n'
        ).readline
    l = []
    tokenize_loop(readline, l.append)

# Generated at 2022-06-23 16:00:54.941791
# Unit test for function untokenize
def test_untokenize():
    from io import StringIO


# Generated at 2022-06-23 16:01:05.189375
# Unit test for function generate_tokens
def test_generate_tokens():
    from StringIO import StringIO

    readline = StringIO("a = 2 + 3 - 4\n").readline
    tokens = list(generate_tokens(readline))
    for t in tokens:
        print(t)
test_generate_tokens()

import cProfile, pstats
cProfile.run('test_generate_tokens()', 'restats')
p = pstats.Stats('restats')
p.strip_dirs().sort_stats(-1).print_stats()

# We will now test the effect of using `tabsize=6` in `tokenize.generate_tokens`.

# Generated at 2022-06-23 16:01:07.743467
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    e = StopTokenizing("arg")
    assert e.args == ("arg",)



# Generated at 2022-06-23 16:01:09.698574
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()


# Generated at 2022-06-23 16:01:16.579679
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    input = [
        (NAME, 'test'),
        (OP, '('),
        (NEWLINE, '\n'),
        (NAME, 'x'),
        (OP, ')'),
        (NEWLINE, '\n'),
    ]
    untokenizer = Untokenizer()
    output = untokenizer.untokenize(input)
    output = output.split('\n')
    assert output == ['test(', 'x)']



# Generated at 2022-06-23 16:01:20.619007
# Unit test for function any
def test_any():
    assert re.match(any("a", "b"), "")
    assert re.match(any("a", "b"), "a")
    assert re.match(any("a", "b"), "b")
    assert re.match(any("a", "b"), "ab")

