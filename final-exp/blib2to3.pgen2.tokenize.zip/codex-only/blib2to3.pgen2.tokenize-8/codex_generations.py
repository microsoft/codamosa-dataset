

# Generated at 2022-06-23 15:51:22.373149
# Unit test for function tokenize
def test_tokenize():
    import io

    readline = io.StringIO("def f(x): return 2*x").__next__

    result = []

    def tokeneater(*args):
        result.append(args)

    tokenize(readline, tokeneater)


# Generated at 2022-06-23 15:51:28.683241
# Unit test for function maybe
def test_maybe():
    def match(s):
        if re.match(maybe("a", "b", "c") + "$", s):
            return True

    def fail(s):
        if re.match(maybe("a", "b", "c") + "$", s):
            return False

    assert match("")
    assert match("a")
    assert match("abcabcabc")
    assert match("cba")
    assert match("cbcab")
    assert fail("cbac")
    assert fail("aabbcc")
    assert fail("   ")



# Generated at 2022-06-23 15:51:31.292408
# Unit test for function group
def test_group():
    assert group("1", "23", "456") == "(1|23|456)"


# Generated at 2022-06-23 15:51:34.434121
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("a", "b") == "((a)|(b))*"



# Generated at 2022-06-23 15:51:45.895289
# Unit test for function printtoken
def test_printtoken():
    class X:
        def __init__(self, tup):
            self.tup = tup
        def lineno(self):
            return self.tup[0]
        def col(self):
            return self.tup[1]
        def __len__(self):
            return self.tup[2]

    printtoken(
        NAME, "abc", X((1, 2, 3)), X((1, 5, 3)), "def\n"
    )  # 2,5-2,8:   NAME    'abc'
    printtoken(
        STRING, "abc", X((1, 2, 3)), X((1, 5, 3)), "def\n"
    )  # 2,5-2,8:   STRING  'abc'

# Generated at 2022-06-23 15:51:50.354727
# Unit test for function untokenize
def test_untokenize():
    def check(input, output, roundtrip=True):
        self.assertEqual(untokenize(input), output)
        if roundtrip:
            t1 = [tok[:2] for tok in input]
            newcode = untokenize(t1)
            readline = iter(newcode.splitlines(1)).next
            t2 = list(generate_tokens(readline))
            self.assertEqual(t1, t2)
    # Try strings
    check([(1, 'a = "foo"'), (0, '')], 'a = "foo"')
    # Try encoded strings
    check([(1, 'u = "foo"'), (0, '')], 'u = "foo"')
    # Try numbers

# Generated at 2022-06-23 15:51:58.107762
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize

    # Use the standard library's test to ensure the output is valid.
    with tokenize.open(__file__) as fp:
        for t in tokenize.tokenize(fp.readline):
            pass

    # tokenize.tokenize doesn't strip whitespace, so we'll do it here.
    text = io.StringIO(textwrap.dedent('''
                   def foo(bar):
                       return bar + 1
    ''').strip())

    tokens = generate_tokens(text.readline)
    assert next(tokens) == (tokenize.NAME, 'def', (1, 0), (1, 3), 'def foo(bar):\n')

# Generated at 2022-06-23 15:52:01.625563
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
    assert any("a") == "a*"
    assert any() == "()*"



# Generated at 2022-06-23 15:52:06.186924
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        print("Constructor of class StopTokenizing works.")
    except Exception as e:
        print("Constructor of class StopTokenizing did not work.")



# Generated at 2022-06-23 15:52:15.406550
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    assert u.prev_row == 1
    assert u.prev_col == 0
    u.add_whitespace((1,0))
    assert u.tokens == []
    u.add_whitespace((1,5))
    u.add_whitespace((1,4))
    assert u.tokens == [' ', '    ']
    u.add_whitespace((2,0))
    assert u.tokens == [' ', '    ', '\n']
    u.add_whitespace((2,0))
    assert u.tokens == [' ', '    ', '\n']
    u.add_whitespace((3,9))
    assert u.tokens == [' ', '    ', '\n', '\n    ']
    u

# Generated at 2022-06-23 15:52:25.528205
# Unit test for function untokenize
def test_untokenize():
    import sys, tokenize
    if sys.version[:3] == '1.5':
        print('Skipping test_untokenize for Python 1.5')
        return

# Generated at 2022-06-23 15:52:36.298369
# Unit test for function detect_encoding
def test_detect_encoding():
    def reader(s):
        for c in s:
            yield bytes([ord(c)])

    def readline():
        return next(g)

    g = reader("# -*- coding: iso-8859-1 -*-\n")
    assert detect_encoding(readline) == ("iso-8859-1", [bytes([35, 32, 45, 42])])
    g = reader("#\n# -*- coding: iso-8859-1 -*-\n")
    assert detect_encoding(readline) == ("iso-8859-1", [bytes([35]), bytes([35, 32])])
    g = reader("\n\n# -*- coding: iso-8859-1 -*-\n")

# Generated at 2022-06-23 15:52:38.524662
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"
test_group()



# Generated at 2022-06-23 15:52:46.655014
# Unit test for function maybe
def test_maybe():
    try:
        assert maybe("a") == "(a)?", maybe("a")
        assert maybe("a", "b") == "((a)|(b))?"
        return "tests passed"
    except:
        return "test failed"
# print(test_maybe())


# Helper for letters replacement below.
# The sys.maxunicode value should be updated every time a new Unicode version is
# out (and is likely to be updated for the 3.2 series).
# See http://docs.python.org/3/whatsnew/3.2.html#unicode
_MAXUNICODE_FOR_LETTERS = 0x10FFFF



# Generated at 2022-06-23 15:52:47.604863
# Unit test for function tokenize_loop

# Generated at 2022-06-23 15:52:57.468235
# Unit test for function generate_tokens
def test_generate_tokens():
    import sys
    import token as py_token
    import io

    def _add_encoding_line(line):
        import re
        if re.match(r"[ \t\f]*#.*coding[=:]", line):
            line = line.rstrip("\n") + " -*- coding: utf-8 -*-\n"
        return line

    def _tokenize(readline, tokeneater=printtoken):
        for token_info in generate_tokens(readline):
            tokeneater(*token_info)

    def printtoken(type, token, srow_scol, erow_ecol, line):
        (srow, scol) = srow_scol
        (erow, ecol) = erow_ecol
        if token:
            token = repr

# Generated at 2022-06-23 15:53:01.132025
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, [10, 100], [10, 100], [10, 100], "abc")

tok_name[OP] = "Operator"



# Generated at 2022-06-23 15:53:07.708453
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    g = tokenize(iter(["x = 2 + 3\n"]).__next__)
    l = []
    for t in g:
        l.append(t)
    out = u.untokenize(iter(l))
    e = "x = 2 + 3\n"
    assert out == e, f"got {out} instead of {e!r}"



# Generated at 2022-06-23 15:53:14.358874
# Unit test for function printtoken

# Generated at 2022-06-23 15:53:18.142442
# Unit test for function untokenize
def test_untokenize():
    import tokenize
    from io import BytesIO
    f = BytesIO(b'print(1)\n')
    g = tokenize.generate_tokens(f.readline)
    result = untokenize(g)
    f.seek(0)
    reference = f.read()
    assert result == reference


# Generated at 2022-06-23 15:53:22.311584
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import tokenize
    file_stream = io.StringIO("print('hello world')")
    root = tokenize.tokenize(file_stream.readline)
    ut = tokenize.Untokenizer()
    ut.compat(next(root), root)
    assert ut.untokenize(root) == "print ( 'hello world' ) "



# Generated at 2022-06-23 15:53:35.119891
# Unit test for function group
def test_group():
    assert group("abc") == "abc"
    assert group("(", "a", ")") == "\(|a|\)"
    assert group("ab", ("cd", "e")) == "a|b|cd|e"
    assert group("ab", ("cd", "e"), "f") == "a|b|cd|e|f"
    assert group("ab", ("cd", "e"), "f") == "a|b|cd|e|f"
    assert group(("a", "b")) == "a|b"
    assert group("abc", "def") == "abc|def"
    assert group("class", "def") == "class|def"
    assert group("class", "def", "if") == "class|def|if"



# Generated at 2022-06-23 15:53:46.733330
# Unit test for function untokenize
def test_untokenize():
    # Test round-trip invariant for full input
    lines = [
        "def f():",
        "\tpass",
        "",
        "f()",
        "",
        '"""Docstring"""'
    ]
    source = "\n".join(lines)

    readline = iter(source.splitlines(1)).__next__
    tokens = list(tokenize(readline))
    newcode = untokenize(tokens)

    readline = iter(newcode.splitlines(1)).__next__
    tokens2 = list(tokenize(readline))

    assert tokens == tokens2

    # Test round-trip invariant for limited input
    # XXX Would be nice to add this as a real test.
    # readline = iter(source.splitlines(1)).__next__
    # tokens = [tok[

# Generated at 2022-06-23 15:53:49.515931
# Unit test for function group
def test_group():
    assert group("1", "2") == "(1|2)"
    assert group(["a", "b"]) == "(a|b)"



# Generated at 2022-06-23 15:53:54.467906
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    unt = Untokenizer()
    unt.add_whitespace((1, 1))
    assert unt.tokens == [" "]
    unt.add_whitespace((1, 0))
    assert unt.tokens == [" ", " "]


Utf8ByteDecoder = Callable[[Text], Text]



# Generated at 2022-06-23 15:54:00.363533
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    def check(exc):
        assert isinstance(exc, StopTokenizing)
        assert isinstance(exc, Exception)
        assert str(exc) == "end of line"
        raise exc

    try:
        check(StopTokenizing("end of line"))
    except StopTokenizing as e:
        assert str(e) == "end of line"



# Generated at 2022-06-23 15:54:10.337806
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()
    untokenizer.add_whitespace((0,0))
    assert untokenizer.tokens == []
    untokenizer.prev_row = 1
    untokenizer.prev_col = 0
    untokenizer.add_whitespace((1,1))
    assert untokenizer.tokens == [" "]
    untokenizer.prev_row = 1
    untokenizer.prev_col = 4
    untokenizer.add_whitespace((1,9))
    assert untokenizer.tokens == [" ", " "*4]
    untokenizer.prev_row = 2
    untokenizer.prev_col = 0
    untokenizer.add_whitespace((2,2))

# Generated at 2022-06-23 15:54:16.340827
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens

    text = "def f():\n  pass\n"
    untok = Untokenizer()
    with StringIO(text) as stream:
        untok.compat((ENCODING, "utf-8"), generate_tokens(stream.readline))
    assert untok.tokens == ["def", " ", "f", "(", ")", ":", "\n", "  ", "pass", "\n"]


# Generated at 2022-06-23 15:54:20.076069
# Unit test for function printtoken
def test_printtoken():
    printtoken(
        token.STRING,
        "Hello World!",
        (1, 2),
        (1, 14),
        "Hello World!",
    )


# Generated at 2022-06-23 15:54:32.367605
# Unit test for function generate_tokens
def test_generate_tokens():
    def greed_get_tokens(func):
        def wrapper(*args, **kwargs):
            g = func(*args, **kwargs)
            tokens = list(g)
            return tokens
        return wrapper
    globs = globals()
    globs['get_tokens'] = greed_get_tokens(globs['get_tokens'])
    globs['detect_encoding'] = greed_get_tokens(globs['detect_encoding'])
    globs['tokenize'] = greed_get_tokens(globs['tokenize'])
    globs['generate_tokens'] = greed_get_tokens(globs['generate_tokens'])
    import test.tokenize_tests

# Generated at 2022-06-23 15:54:36.317902
# Unit test for function maybe
def test_maybe():
    assert re.match(maybe("ab"), "")
    assert re.match(maybe("ab"), "ab")
    assert re.match(maybe("ab"), "abab")
    assert not re.match(maybe("ab"), "abc")


# Generated at 2022-06-23 15:54:46.880180
# Unit test for function untokenize
def test_untokenize():
    from io import BytesIO

    def compare(input, expected):
        result = untokenize(generate_tokens(BytesIO(input).readline))
        if result != expected:
            print("Untokenizing", repr(input), "expected", repr(expected))
            print("Untokenized", repr(result))

    def compare_roundtrip(input):
        compare(input, input)

    compare("abc", "abc")
    compare("abc = def = 5", "abc = def = 5")
    compare("abc\n", "abc")
    compare("abc\ndef", "abc\ndef")
    compare_roundtrip("a = (1)\n")
    compare_roundtrip("a = [1]\n")
    compare_roundtrip("a = {\n1: 2\n}\n")

# Generated at 2022-06-23 15:54:58.683493
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# coding=iso8859-15\n"
        yield b"# -*- coding: utf8 -*-\n"
        yield b"\xa3 = 0\n"
        yield b"\n"

    # The part of the test that actually matters.  The rest is just
    # scaffolding.
    assert detect_encoding(readline) == ("latin-1", [b"# coding: latin-1\n"])


encoding_cookie_re = re.compile(r"^[ \t\f]*#.*?coding[:=][ \t]*([-\w.]+)", re.ASCII)



# Generated at 2022-06-23 15:55:05.466172
# Unit test for function generate_tokens
def test_generate_tokens():
    with tokenize.open("tokenize_tests.py") as f:
        tokens = list(tokenize.generate_tokens(f.readline))

    # check that we found the right number of each token type
    token_types = set(type for type, text, start, end, line in tokens)
    assert token_types == set(
        [NUMBER, STRING, NAME, COMMENT, NL, NEWLINE, ENCODING]
        + list(tokenize.tok_name.values())
    ), "wrong number of tokens found"

    keywords = set(KEYWORD for type, text, start, end, line in tokens if type == KEYWORD)
    assert keywords == set(["def"]), "wrong keywords found"


# Generated at 2022-06-23 15:55:16.566153
# Unit test for function detect_encoding
def test_detect_encoding():
    for encoding in \
        "ascii", "utf-8", "utf-8-sig", "latin-1", "utf-16", "utf-16-le", \
        "utf-16-be", "shift_jis", "iso2022-jp":
        f = open("Lib/test/input/tokenize_tests/tokenize_test_" + encoding + ".py",
                "rb")
        encoding_expected, lines_expected = detect_encoding(f.readline)
        f.close()
        assert encoding_expected == encoding, (encoding_expected, encoding)
        assert lines_expected == [
            b'# coding: ' + encoding.encode("ascii") + b'\n'
        ], lines_expected



# Generated at 2022-06-23 15:55:18.096311
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:55:30.997871
# Unit test for function generate_tokens
def test_generate_tokens():
    class pseudo_token:
        def __init__(self, type, string, start, end, line):
            self.type = type
            self.string = string
            self.start = start
            self.end = end
            self.line = line
        def __repr__(self):
            annotated_type = self.type
            if annotated_type == tokenize.OP and tokenize.N_TOKENS <= self.type < tokenize.N_TOKENS + 26:
                annotated_type = "%s (as an operator)" % (tokenize.tok_name[tokenize.OP],)

# Generated at 2022-06-23 15:55:32.565662
# Unit test for function any
def test_any():
    assert any("a", "b", "c") == "(a|b|c)*"



# Generated at 2022-06-23 15:55:42.909860
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    u.prev_row = 4
    u.prev_col = 4
    u.add_whitespace((4, 8))
    assert u.tokens == ["    "]
    u.tokens = []
    u.add_whitespace((6, 0))
    assert u.tokens == ["\n\n"]
    u.tokens = []
    u.add_whitespace((6, 12))
    assert u.tokens == ["\n\n            "]
    u.tokens = []
    u.add_whitespace((5, 2))
    assert u.tokens == ["\n"]


# Generated at 2022-06-23 15:55:46.680783
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("abc") == "(abc)"
    assert group("a", "", "b") == "(a||b)"


# Shorthand for non-empty named groups

# Generated at 2022-06-23 15:55:53.733679
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield "a\xc3\xa9"
        yield "\xc3\xa0"
        yield "\xc3\xa7"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"a\xc3\xa9", b"\xc3\xa0", b"\xc3\xa7"]

    def readline():
        yield b"#!/usr/bin/env python3\n"
        yield b'# -*- coding: utf-8 -*-\n'
        yield b"#\n"
        yield b"a\xc3\xa9"

# Generated at 2022-06-23 15:55:58.705577
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

# Generated at 2022-06-23 15:56:09.674111
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield "\xef\xbb\xbf# -*- coding: latin-1 -*-\n"
        yield "# -*- coding: ascii -*-\n"
        yield "# -*- coding: 1234 -*-\n"
        yield "# -*- coding: utf-8 -*-\n"
        yield "# coding=utf-8\n"
        yield "# coding=1234\n"
        yield "# coding=latin-1\n"
        yield "pass\n"

    for line in readline():
        assert len(line) == len(line.encode("ascii"))

    assert detect_encoding(readline) == ("latin-1", [])


# Generated at 2022-06-23 15:56:12.188411
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # verify that the class object is valid
    e = StopTokenizing("foo")
    assert e.args == ("foo",)
    assert str(e) == "foo"



# Generated at 2022-06-23 15:56:19.311087
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    def compare(input, output):
        u = Untokenizer()
        s = u.untokenize(input)
        assert s == output, "expected %r, got %r" % (output, s)

    compare([(1, "foo")], "foo ")
    compare([(1, "foo"), (2, "bar")], "foo bar")
    compare([(1, "\n"), (1, "foo")], "\nfoo ")
    compare([(1, "foo"), (1, "\n")], "foo \n")

# Generated at 2022-06-23 15:56:21.231631
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"



# Generated at 2022-06-23 15:56:29.400333
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    sequence = iter(
        [
            (token.STRING, "abc"),
            (token.NEWLINE, "\n"),
            (token.DEDENT, ""),
            (token.NUMBER, "42"),
            (token.ENDMARKER, ""),
        ]
    )
    unt = Untokenizer()
    unt.compat((token.NL, ""), sequence)
    res = unt.tokens
    assert res == ["abc", "\n", "42"]


# Generated at 2022-06-23 15:56:30.754258
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "abc", (1, 2), (3, 4), "")



# Generated at 2022-06-23 15:56:37.112302
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    assert u.prev_row == 1
    assert u.prev_col == 0

    u.add_whitespace((1,0))
    assert u.prev_row == 1
    assert u.prev_col == 0
    assert len(u.tokens) == 0

    u.add_whitespace((1,1))
    assert u.prev_row == 1
    assert u.prev_col == 1
    assert len(u.tokens) == 1
    assert u.tokens[0] == " "

    u.add_whitespace((1,5)) # Add 3 spaces, resulting in 4
    assert u.prev_row == 1
    assert u.prev_col == 5
    assert len(u.tokens) == 2

# Generated at 2022-06-23 15:56:49.265858
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import tokenize
    fname = __file__
    if fname.endswith((".pyc", ".pyo")):
        fname = fname[:-1]

    with io.open(fname, "rb") as f:
        encoding, lines = detect_encoding(f.readline)
    f = io.open(fname, "r", encoding=encoding)
    r = f.readline
    if lines:
        line = lines[0]
        r = lambda : line if line else f.readline()
    tokgen = tokenize.tokenize(r)
    for toktype, toktext, (srow, scol), (erow, ecol), line in tokgen:
        if srow > 20:
            break

# Generated at 2022-06-23 15:56:58.656581
# Unit test for function detect_encoding
def test_detect_encoding():
    import codecs

    def readline_mock(*lines: str) -> Callable[[], bytes]:
        def readline_helper() -> bytes:
            try:
                return lines.pop(0).encode("utf-8")
            except IndexError:
                raise StopIteration

        return readline_helper

    # Test empty file
    assert detect_encoding(readline_mock()) == ("utf-8", [])
    # BOM only
    assert detect_encoding(readline_mock(codecs.BOM_UTF8)) == ("utf-8-sig", [])
    # BOM + coding cookie

# Generated at 2022-06-23 15:57:06.046457
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def reader(s):
        for c in s:
            yield bytes([c])

    # test default
    g = reader("a")
    assert detect_encoding(lambda: next(g)) == ("utf-8", [b"a"])

    # test encoding in BOM
    g = reader("\xef\xbb\xbf# -*- coding: latin-1 -*-\nanother line")
    assert detect_encoding(lambda: next(g)) == ("utf-8-sig", [b"# -*- coding: latin-1 -*-\n"])

    g = reader("\xef\xbb\xbf# coding=utf-8\nanother line")

# Generated at 2022-06-23 15:57:14.617384
# Unit test for function tokenize
def test_tokenize():
    import io
    from blib2to3.pgen2 import tokenize as _tokenize
    lines = "for x in range(2):\n\tprint(x)"
    stream = io.StringIO(lines)
    try:
        _tokenize.tokenize(stream.readline)
    except _tokenize.TokenError:
        pass
    stream = io.StringIO(lines)
    try:
        _tokenize.tokenize(stream.readline, lambda x: None)
    except _tokenize.TokenError:
        pass


# Generated at 2022-06-23 15:57:26.214404
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io

    # test_untokenize.py - test for the untokenize() function

    import untokenize
    import tokenize
    import io
    import token

    def test_untok(input_string, expected):
        input_stream = io.BytesIO(input_string.encode("utf-8"))
        tokens = tokenize.tokenize(input_stream.readline)
        output = untokenize.untokenize(tokens)
        assert output == expected

    # Test untokenize() with a simple example.
    test_untok('x = "\\n"', 'x = "\\n"')

    # Test that untokenize() preserves the newlines at the end of input.
    test_untok('x = "\\n"\n', 'x = "\\n"\n')
    test

# Generated at 2022-06-23 15:57:34.233209
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import random

    for i in range(10):
        # Generate some random data.
        r1 = random.randrange(0, 65535)
        r2 = random.randrange(0, 65535)
        r3 = random.randrange(0, 65535)
        ut = Untokenizer()
        untok = ut.untokenize([(r1, chr(r2), (r2, r1), (r2, r1), chr(r3))])
        if untok != chr(r3):
            raise RuntimeError("Bad result: %d %d %d" % (r1, r2, r3))



# Generated at 2022-06-23 15:57:44.710701
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline_mock(iterable):
        def readline():
            next_item = iterable.pop(0)
            if next_item == "":
                raise StopIteration
            return next_item

        return readline

    def tokeneater_mock(expected_token_info):
        def tokeneater(*token_info):
            if expected_token_info == token_info:
                token_info_is_correct[0] = True
            else:
                msg = f"tokeneater called with {token_info} instead of {expected_token_info}"
                raise Exception(msg)

        return tokeneater

    token_info_is_correct = [False]

# Generated at 2022-06-23 15:57:46.153129
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"



# Generated at 2022-06-23 15:57:49.491687
# Unit test for function group
def test_group():
    assert group("a", "b") == r"(a|b)"


# Helper for non-letter tokens

# Generated at 2022-06-23 15:57:55.536277
# Unit test for function maybe
def test_maybe():
    assert maybe('a') == '(a)?', maybe('a')
    assert maybe('a', 'b') == '(a|b)?', maybe('a', 'b')
    assert maybe('a', 'b', 'c') == '(a|b|c)?', maybe('a', 'b', 'c')


# Helpers for string patterns

# Generated at 2022-06-23 15:58:02.786097
# Unit test for function any
def test_any():
    # Test that any() produces the same results as group()*
    import random
    for i in range(100):
        length = random.randrange(100)
        choices = [random.choice(["abc", "def", "ghi", "jkl"]) for j in range(length)]
        assert re.match(any(*choices), "".join(choices))
        assert re.match(any(*choices) + "a", "".join(choices)) is None


# Generated at 2022-06-23 15:58:15.098137
# Unit test for function tokenize
def test_tokenize():
    import token
    import io
    import sys


    # Define a generator which generates all kinds of tokens
    def generate_tokens(readline):
        for t in (
            INDENT,
            token.NAME,
            token.NUMBER,
            token.STRING,
            NEWLINE,
            DEDENT,
            token.OP,
            COMMENT,
            NL,
        ):
            yield None, t, None, None, None


    class Readline:
        def __init__(self, lines):
            self.lines = lines
            self.i = 0


        def __call__(self):
            if self.i >= len(self.lines):
                return ""
            line = self.lines[self.i]
            self.i += 1
            return line


    # Define a generator

# Generated at 2022-06-23 15:58:20.200001
# Unit test for function any
def test_any():
    assert any("a")
    assert not any("")
    assert any(r"[a-z]", r"[0-9]")
    assert not any(r"[a-z]", r"[0-9]", "^")
    assert any("a", "b")
    assert any("a", "")
    assert not any("^")



# Generated at 2022-06-23 15:58:22.996567
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    s = untok.untokenize(generate_tokens(iter(["1 + 2"]).__next__))
    assert s == "1 + 2 "



# Generated at 2022-06-23 15:58:25.091383
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    ts = Untokenizer()
    assert ts.prev_row == 1
    assert ts.prev_col == 0



# Generated at 2022-06-23 15:58:29.975207
# Unit test for function untokenize
def test_untokenize():
    global tokens

# Generated at 2022-06-23 15:58:39.983913
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest


# Generated at 2022-06-23 15:58:45.687295
# Unit test for function tokenize
def test_tokenize():
    import io
    r = io.StringIO(
        """while 1:
    try:
        x = int(input("Please enter a number: "))
        break
    except ValueError:
        print("Oops!  That was no valid number.  Try again...")
"""
    )
    tokenize(r.readline)



# Generated at 2022-06-23 15:58:57.930017
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?"

# End unit tests for function maybe


# Regular expression components
whitespace = "[ \\f\\t]*"
comment = "#[^\\r\\n]*"
ignore = whitespace + any(r"\\\r?\n" + whitespace) + maybe(comment)
name = "[a-zA-Z_]\\w*"

hexnumber = "0[xX](?:_?[0-9a-fA-F])+"
binumber = "0[bB](?:_?[01])+"
octnumber = "0[oO](?:_?[0-7])+"
decnumber = "(?:0(?:_?0)*|[1-9](?:_?[0-9])*)"

# Generated at 2022-06-23 15:58:59.547835
# Unit test for function maybe
def test_maybe():
    assert maybe('a', 'b') == "(a|b)?"


# Generated at 2022-06-23 15:59:07.437259
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more comment\n"
        yield b"spam\n"

    readline = readline()

    def readline():
        yield b"\xef\xbb\xbf# coding: latin-1\n"
        yield b"# some more comment\n"
        yield b"spam\n"

    readline = readline()

    def readline():
        yield b"# coding: latin-1\n"
        yield b"\xef\xbb\xbf# some more comment\n"
        yield b"spam\n"

    readline = readline()


# Generated at 2022-06-23 15:59:10.887894
# Unit test for function group
def test_group():
    return str(group("aa", "bb", "ccccc"))
assert test_group() == "((aa)|(bb)|(ccccc))"



# Generated at 2022-06-23 15:59:18.259530
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io, tokenize

    u = Untokenizer()
    assert u.tokens == []
    assert u.prev_row == 1
    assert u.prev_col == 0
    u.add_whitespace((1,2))
    assert u.tokens == ["  "]
    u.add_whitespace((1, 2))
    assert u.tokens == ["  "]
    u.add_whitespace((1, 4))
    assert u.tokens == ["  ", "  "]
    u.add_whitespace((3, 0))
    assert u.tokens == ["  ", "  ", "\n\n"]
    u.add_whitespace((3, 4))

# Generated at 2022-06-23 15:59:27.278712
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ungettext = Untokenizer().untokenize
    assert ungettext([(1, "a"), (2, "b"), (1, "c")]) == "abc"
    assert ungettext([(57, "a"), (0, "\n"), (0, "\n"), (57, "b")]) == "a\n\nb"

# Generated at 2022-06-23 15:59:39.872159
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import tokenize
    u = Untokenizer()
    tok = tokenize.generate_tokens
    def test(s, want):
        L = list(u.compat((tokenize.NAME, s), []))
        if L != [want]:
            print("test_Untokenizer_compat")
            print("%r => %r != %r" % (s, L, want))
    test("if", "if ")
    test("elif", "elif ")
    test("def", "def ")
    test("class", "class ")
    test("for", "for ")
    test("while", "while ")
    test("return", "return ")
    test("foo", "foo ")
    test("1", "1 ")


# Generated at 2022-06-23 15:59:42.217899
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    else:
        raise RuntimeError("Failed to raise exception TokenError")



# Generated at 2022-06-23 15:59:45.126372
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:59:51.489616
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    def test(input):
        return u.untokenize(tokenize(StringIO(input).readline))
    assert test('a = 1\nb = 2\n') == 'a = 1\nb = 2\n'
    assert test('def f():\n  def g():\n    pass\n') == 'def f():\n  def g():\n    pass\n'


# Generated at 2022-06-23 16:00:03.143321
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert "\n" == u.untokenize([(3, "\n\n")])
    assert "    a b" == u.untokenize([(3, "    "), (1, "a"), (1, "b")])
    assert "  \n        a b" == u.untokenize(
        [(3, "  \n    "), (0, "    "), (1, "a"), (1, "b")]
    )
    assert "\n   a b" == u.untokenize([(3, "\n"), (0, "   "), (1, "a"), (1, "b")])



# Generated at 2022-06-23 16:00:16.577578
# Unit test for function untokenize
def test_untokenize():
    # Helper to encode tokens as UTF-8
    def utf8(ti: Union[GoodTokenInfo, str]) -> Union[GoodTokenInfo, bytes]:
        if isinstance(ti, str):
            return ti.encode("utf-8")
        else:
            return (ti[0], ti[1].encode("utf-8"), ti[2], ti[3], ti[4].encode("utf-8"))

    # Test round-trip invariant for full input
    def rt_full(source: Text) -> None:
        # tokens => untokenize => source
        tokens = generate_tokens(StringIO(source).readline)
        usource = untokenize(tokens)
        assert usource == source

    # Test round-trip invariant for limited input

# Generated at 2022-06-23 16:00:27.530790
# Unit test for function generate_tokens
def test_generate_tokens():
    def tokenize_1_7(string: str) -> Iterator[TokenInfo]:
        readline = io.StringIO(string).readline
        return generate_tokens(readline)

    def check_tokenize_1_7(s: str, tokens: List[TokenInfo]):
        alltokens = list(tokenize_1_7(s))
        if tokens != alltokens:
            print("tokens=" + str(tokens))  # NOQA
            print("differs from " + str(alltokens))  # NOQA

    #    >>> from tokenize import tokenize
    #    >>> g = tokenize(StringIO('xxx\n').readline)
    #    >>> for toknum, tokval, _, _, _  in g:
    #    ...    

# Generated at 2022-06-23 16:00:38.038339
# Unit test for function tokenize
def test_tokenize():
    # Copyright (c) 2014-2016, PyPy project
    from io import BytesIO
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.token import tok_name

    TESTLINE = "if sys.version_info < (3,): print 'Hello, world!'\n"

    def test_tokenize(testline):
        file_obj = BytesIO(testline.encode("utf-8"))
        list(tokenize(file_obj.readline))

    # Test when the last line doesn't end with a newline
    test_tokenize(TESTLINE)

    # Test when the last line does end with a newline
    test_tokenize(TESTLINE.rstrip() + "\n")



# Generated at 2022-06-23 16:00:49.512159
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from unittest import TestCase, main

    untok = Untokenizer()

    s = "class a(b):\n pass"
    f = StringIO(s)
    tk = tokenize(f.readline)
    # call this to advance generator to first token
    tk.send(None)
    result = untok.untokenize(tk)
    print(result)
    self.assertEqual(result, s)


# Generated at 2022-06-23 16:00:57.342173
# Unit test for function group
def test_group():
    print("a" in group("a", "b"))
    print("b" in group("a", "b"))
    print("x" in group("a", "b"))
    print("ab" in group("a", "b"))
    print("abc" in group("abc", "def"))
    print("def" in group("abc", "def"))
    print("ghi" in group("abc", "def"))
    print("abcd" in group("abc", "def"))

# All the tokenize_* functions take as arguments a readline function, and
# a tokeneater function, and use the former to obtain lines (strings) and
# call the latter with groups of tokens found on those lines, e.g. a
# quad of (token_type, token_string, start_row, start_col, end_col).
#


# Generated at 2022-06-23 16:01:08.765042
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-'
        yield b''
        yield b'print(1)'
        raise StopIteration

    with pytest.raises(SyntaxError):
        detect_encoding(readline)

    def readline():
        yield b'# -*- coding: latin-1 -*-'
        yield b''
        yield b'print(1)'
        raise StopIteration

    assert detect_encoding(readline) == ('iso-8859-1', [b'# -*- coding: latin-1 -*-', b'', b'print(1)'])

    def readline():
        yield b'# -*- coding: utf-8 -*-'
        yield b''
        yield b'print(1)'
        raise Stop

# Generated at 2022-06-23 16:01:13.355183
# Unit test for function any
def test_any():
    assert any('a', 'b') == '(a|b)*'
    try:
        any('a')
    except TypeError:
        pass
    else:
        raise AssertionError('any with 1 argument fails')
test_any()
