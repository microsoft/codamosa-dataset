

# Generated at 2022-06-23 15:51:23.267495
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 'Name', (1, 1), (1, 4), 'foobar')

# Unit tests for function test_printtoken are below



# Generated at 2022-06-23 15:51:27.629312
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    """Test for two features of the constructor of StopTokenizing:
    allow it to be called with no arguments, and assign the
    default argument None to the instance variable msg."""
    e = StopTokenizing()
    assert e.msg is None
    e = StopTokenizing("spam")
    assert e.msg == "spam"



# Generated at 2022-06-23 15:51:37.765589
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO

    def readline():
        # Reminder: the next line starts with a BOM mark.
        for l in [
            b"# coding=latin-1\n",
            b"#!/usr/bin/python\n",
            b"# -*- coding: ascii -*-\n",
            BOM_UTF8 + b"# -*- coding: utf-8 -*-\n",
            b"pass\n",
        ]:
            yield l

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8-sig"

# Generated at 2022-06-23 15:51:43.304728
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ungettext = Untokenizer()
    assert ungettext.untokenize([(1, "a"), (1, "1")]) == "a 1"
    assert ungettext.untokenize([(1, "a"), (3, "3")]) == "a3"
    assert ungettext.untokenize([(1, "a"), (0, "\n"), (1, "b")]) == "a\nb"
    assert ungettext.untokenize([(1, "a"), (0, "\n"), (0, "\n"), (1, "b")]) == "a\n\nb"
    assert ungettext.untokenize([(1, "a"), (0, "\n"), (0, "\n"), (1, "b"), (0, "\n")]) == "a\n\nb\n"

# Generated at 2022-06-23 15:51:48.012670
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group(["a", "b"]) == "(a|b)"
    assert group("a", "b", "c") == "(a|b|c)"
    assert group(["a", "b", "c"]) == "(a|b|c)"
    assert group("a") == "(a)"
    assert group("") == ""


# Generated at 2022-06-23 15:51:54.314105
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    infile = open("untokenize_data")
    outfile = open("untokenize_out", "wb")
    try:
        for line in infile:
            print(untokenize(readline(line)), file=outfile)
    finally:
        infile.close()
        outfile.close()



# Generated at 2022-06-23 15:51:59.787961
# Unit test for function tokenize

# Generated at 2022-06-23 15:52:05.072449
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline():
        for line in (
            b'# -*- coding: iso-8859-1 -*-\n',
            b'some text\n',
            b'\xbfpublicidad\n',
            b'# -*- coding: utf-8 -*-\n',
            b'def foo(): pass\n',
            b'# -*- coding: iso-8859-15 -*-\n',
        ):
            yield line
        raise StopIteration

    assert detect_encoding(readline) == ("iso-8859-1", [b'some text\n', b'\xbfpublicidad\n'])
    assert detect_encoding(readline) == ("utf-8", [b'some text\n', b'\xbfpublicidad\n'])
    assert detect

# Generated at 2022-06-23 15:52:14.749631
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    import unittest

    class TokenizeTest(unittest.TestCase):
        # This tests against a list of hard-coded tokens rather than using the
        # tokenize() function in order to pick up changes to the token
        # names/values (e.g. COMMENT was added in Python 3.5)

        def test_tokenize_op(self):
            stream = io.StringIO("1 << 2")
            stream.seek(0)
            expected = [(token.NUMBER, "1", (1, 0)), (token.LSHIFT, "<<", (1, 2))]
            actual = list(tokenize.generate_tokens(lambda: stream.readline()))[:2]
            self.assertEqual(expected, actual)


# Generated at 2022-06-23 15:52:15.307895
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    ut = Untokenizer()



# Generated at 2022-06-23 15:52:20.216181
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 3
    untok.prev_col = 10
    untok.add_whitespace((3, 20))
    assert untok.prev_col == 20
    untok.add_whitespace((4, 0))
    assert untok.prev_col == 0



# Generated at 2022-06-23 15:52:21.963420
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 2, (3, 4), (5, 6), 7)



# Generated at 2022-06-23 15:52:28.014607
# Unit test for constructor of class TokenError
def test_TokenError():
    # Uncomment this line if you're running this module standalone
    # message = "You're caught!\n"
    try:
        raise TokenError("You're caught!\n")
    except TokenError as e:
        if str(e) != message:
            print("TokenError constructor received %r but produced %r"
                  % (message, str(e)))
            print("test_TokenError:  FAILED")
            return 0
    print("test_TokenError:  SUCCEEDED")
    return 1


# Generated at 2022-06-23 15:52:31.568800
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    else:
        raise Exception("failed to raise StopTokenizing")



# Generated at 2022-06-23 15:52:39.206834
# Unit test for function tokenize
def test_tokenize():
    # Tests that tokenize accepts a readline argument that may raise
    # StopIteration, and that it does nothing when that happens.
    class FakeFile:
        def readline(self) -> Text:
            raise StopIteration

    tokenize(FakeFile().readline)

    # Tests that tokenize accepts a readline argument that returns an empty
    # string, and that it does nothing when that happens.
    class FakeFile:
        def readline(self) -> Text:
            return ""

    tokenize(FakeFile().readline)



# Generated at 2022-06-23 15:52:44.423341
# Unit test for function untokenize
def test_untokenize():
    from io import StringIO
    s = StringIO("def f(x): return 2*x")
    gen = generate_tokens(s.readline)
    out = untokenize(gen)
    assert out == (
        "def f(x):\n"
        "    return 2 * x\n"
    )
    s = StringIO("def f(x): return 2*x")
    gen = generate_tokens(s.readline)
    t = next(gen)
    # Just untokenizing the NAME token and NEWLINE should give an error
    # message because the INDENT isn't generated
    out = untokenize([t, next(gen)])
    assert out == (
        "def f(x):\n"
        "    return 2 * x\n"
    )

    # Test roundtrip

# Generated at 2022-06-23 15:52:52.626775
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    for s, n in (("def f(): pass", 21), ("for i in range(10): print(i)", 37)):
        text = s.expandtabs()
        gtext = text.replace(" ", "  ")
        toks = list(tokenize(StringIO(text).readline))
        gtoks = list(tokenize(StringIO(gtext).readline, True))
        assert len(toks) == len(gtoks) == n
        for t, gt in zip(toks, gtoks):
            assert t == gt


# Generated at 2022-06-23 15:52:53.823753
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        return



# Generated at 2022-06-23 15:53:06.441670
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except Exception as e:
        if not isinstance(e, TokenError):
            raise AssertionError

# See tokenize.tests for additional test cases

# Generated at 2022-06-23 15:53:07.917008
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    assert untok.tokens == []
    assert untok.prev_row == 1
    assert untok.prev_col == 0



# Generated at 2022-06-23 15:53:19.471332
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(s: str) -> Iterator[bytes]:
        for line in s.splitlines(keepends=True):
            yield line.encode("ascii")


# Generated at 2022-06-23 15:53:31.319048
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def check(s, want):
        u = Untokenizer()
        got = u.untokenize(tokenize(io.StringIO(s).readline))
        assert got == want, repr(got) + " != " + repr(want)
    check("a,b,c=1,2,3\n", "a,b,c= 1, 2, 3\n")
    check("a,b,c=1,2,3\n\n", "a,b,c= 1, 2, 3\n\n")
    check("a,b,c=1,2,3\n\n\n", "a,b,c= 1, 2, 3\n\n\n")

# Generated at 2022-06-23 15:53:38.787968
# Unit test for function printtoken
def test_printtoken():
    tok = []
    for d in range(4):
        for t in range(2):
            for s in range(10):
                for e in range(4):
                    for l in range(4):
                        tok.append((d, t, (s, e), (s, e), (s, e), l))
    for t in tok:
        tk = (t[0], t[1], t[2], t[3], t[5],)
        test_printtoken.arg = tk
        printtoken(*tk)



# Generated at 2022-06-23 15:53:41.060992
# Unit test for function maybe
def test_maybe():
    assert maybe('"a"', '"b"') == '(?:(?:"a")|(?:"b"))?'



# Generated at 2022-06-23 15:53:49.243630
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    readline = io.StringIO('x = ("a", "\"", "\\\\", "\'")\n').readline
    r = list(generate_tokens(readline))
    assert len(r) == 16
    assert r[0] == (NUMBER, "0", (1, 0), (1, 0), "0")
    assert r[1] == (NAME, "x", (1, 2), (1, 3), "x")
    assert r[2] == (OP, "=", (1, 4), (1, 5), "=")
    assert r[3] == (OP, "(", (1, 6), (1, 7), "(")

# Generated at 2022-06-23 15:53:51.759985
# Unit test for function group
def test_group():
    grp = group("a", "ab", "abc")
    assert grp == "((a)|(ab)|(abc))"



# Generated at 2022-06-23 15:54:01.043913
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    """Test the compatibility wrapping of the Untokenizer class."""
    import io
    import tokenize as _tokenize
    untokenize = Untokenizer().compat

    def source_tokens(toks):
        it = iter(toks)
        for t in it:
            # Ignore ENCODING, for simplicity
            if t[0] == ENCODING:
                continue
            if t[0] == NEWLINE:
                # Replace NEWLINE with NL and treat NL as NEWLINE, for
                # simplicity
                yield t[:2]
                continue
            if t[0] == ENDMARKER:
                # Insert a NL before the ENDMARKER, for simplicity
                yield (NEWLINE, "\n"),
            yield t

    def test_untokenize(src, should_be):
        src_toks

# Generated at 2022-06-23 15:54:03.348297
# Unit test for function printtoken
def test_printtoken():
    printtoken(0,1,(1,1),(1,2), '')
    assert False, "Tests done"



# Generated at 2022-06-23 15:54:14.620446
# Unit test for function untokenize
def test_untokenize():
    input1 = [
        (1, 'x'),
        (3, '='),
        (1, 'y'),
        (0, ''),
        (54, '\n'),
        (4, 'lambda'),
        (1, 'x'),
        (3, ':'),
        (1, 'x'),
        (54, '\n'),
        (0, ''),
        (54, '\n'),
        (0, '')
    ]
    fix1 = ['x', '=', 'y', '', '\n', 'lambda x: x', '\n', '', '\n', '']
    assert untokenize(input1) == "".join(fix1)

# Generated at 2022-06-23 15:54:27.679903
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # Issue24330: Ensure that coordinate differences are computed correctly.
    ut = Untokenizer()
    ut.add_whitespace((0, 0))
    assert ut.tokens == []
    ut.add_whitespace((1, 0))
    assert ut.tokens == ["\n"]
    ut.add_whitespace((1, 4))
    assert ut.tokens == ["\n", "    "]
    ut.add_whitespace((1, 8))
    assert ut.tokens == ["\n", "    ", "    "]
    ut.add_whitespace((2, 0))
    assert ut.tokens == ["\n", "    ", "    ", "\n"]
    ut.add_whitespace((4, 0))

# Generated at 2022-06-23 15:54:38.570637
# Unit test for function maybe
def test_maybe():
    assert maybe("foo", "bar") == "(foo|bar)?"

Whitespace = "[ \\f\\t]*"
Comment = "#[^\\r\\n]*"
Ignore = Whitespace + any("\\\\\\r?\\n" + Whitespace) + maybe(Comment)
Name = "[a-zA-Z_]\\w*"

Hexnumber = "0[xX][\\da-fA-F]+[lL]?"
Octnumber = "(0[oO]?[0-7]+)|(0[0-7]*)[lL]?"
Binnumber = "0[bB][01]+[lL]?"
Decnumber = "[1-9]\\d*[lL]?"
Intnumber = group(Hexnumber, Binnumber, Octnumber, Decnumber)

# Generated at 2022-06-23 15:54:40.984917
# Unit test for constructor of class TokenError
def test_TokenError():  # noqa: D202
    try:
        raise TokenError("some message")
    except TokenError as e:
        pass



# Generated at 2022-06-23 15:54:44.272848
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from .token import generate_tokens

    u = Untokenizer()
    g = generate_tokens(lambda: "print('hi')")
    assert u.compat(next(g), g) == "print ('hi') "



# Generated at 2022-06-23 15:54:50.744164
# Unit test for function generate_tokens
def test_generate_tokens():
    import re
    import io
    import token
    import tokenize
    import unittest


    class TestTokenize(unittest.TestCase):
        def test_tokenize(self):
            readline = io.BytesIO(
                b"if 1:\n"
                b"    print(2)\n"
                b"    \n"
                b"3\n"
                b"#abc\n"
                b"#def\n"
                b"#ghi\n"
                b"#\n"
                b"4"
            ).readline

            gt = generate_tokens(readline)

            self.assertEqual(tokenize.tok_name[token.INDENT], "INDENT")

# Generated at 2022-06-23 15:55:02.215205
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    str = 'foo = "foo"\nbar = "bar"'
    untok = Untokenizer()
    tokens = []
    utokens = []
    g = generate_tokens(str.splitlines().__iter__().__next__)
    for t in g:
        toknum, tokval = t[:2]
        if toknum == STRING:
            tokval = '""'
        tokens.append((toknum, tokval))
    utokens = untok.compat(tokens.pop(0), iter(tokens))
    assert untok.untokenize(generate_tokens(str.splitlines().__iter__().__next__)) == str


# Generated at 2022-06-23 15:55:03.886927
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    e = StopTokenizing()
    if e.__class__ is not StopTokenizing:
        raise RuntimeError



# Generated at 2022-06-23 15:55:07.281940
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO

    s = StringIO("for i in range(10): print(i)\n")
    g = tokenize(s.readline)
    for t in g:
        print(t)



# Generated at 2022-06-23 15:55:12.284669
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    e = StopTokenizing()
    assert isinstance(e, StopTokenizing)
    assert isinstance(e, Exception)


# this is a subclass of StopTokenizing, used only in untokenize.
# untokenize is the only part of the tokenize module which catches
# and synthesizes exceptions.

# Generated at 2022-06-23 15:55:13.769070
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError as e:
        assert str(e) == ""



# Generated at 2022-06-23 15:55:15.462807
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    test_instance = StopTokenizing()
    assert isinstance(test_instance, Exception)



# Generated at 2022-06-23 15:55:18.295040
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "for i in range(10): print(i)"
    result = [x for x in generate_tokens(s.splitlines().__iter__().__next__)]
    tokenize_loop(s.splitlines().__iter__().__next__, printtoken)



# Generated at 2022-06-23 15:55:22.115107
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    else:
        pass



# Generated at 2022-06-23 15:55:26.248933
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    try:
        raise TokenError("message")
    except TokenError as e:
        assert e.args[0] == "message"
    try:
        raise TokenError("message", ("filename", 1))
    except TokenError as e:
        assert e.args[0] == "message"
        assert e.args[1] == ("filename", 1)



# Generated at 2022-06-23 15:55:36.047808
# Unit test for function tokenize
def test_tokenize():
    import io
    from tokenize import tokenize as tokenize_orig, untokenize
    from tokenize import generate_tokens, tok_name, NUMBER, STRING, NAME, OP

    readline = io.StringIO(
        "def f(x):\n"
        "    return 2*x\n"
        "\n"
        "z = 37\n"
        'print("done")\n'
        "# That's it\n"
    ).readline

    g = tokenize_orig(readline)
    result = []
    for toknum, tokval, _, _, _ in g:
        result.append((toknum, tokval))

# Generated at 2022-06-23 15:55:44.651133
# Unit test for function printtoken
def test_printtoken():
    printtoken(
        55,
        "print(12345)",
        (0, 0),
        (10, 10),
        "Python 3.6.4 (default, Jan  6 2018, 18:41:22) \n[GCC 7.2.1 20171011] on linux2\n",
    )
    printtoken(
        1,
        "TPOT_STRING_ARRAY = ['one', 'two', 'three']",
        (0, 0),
        (10, 10),
        "Python 3.6.4 (default, Jan  6 2018, 18:41:22) \n[GCC 7.2.1 20171011] on linux2\n",
    )



# Generated at 2022-06-23 15:55:52.819854
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test whether tokenize_loop is backward-compatible with tokenize
    import io

    r = io.StringIO("if 1:\n\tprint(2)\n")
    l = []

    def tokeneater(*args):
        l.append(args)

    tokenize_loop(r.readline, tokeneater)

# Generated at 2022-06-23 15:55:55.107247
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "1", (0,0), (1,1), "# Comment: 1.0")

# Helper tokenize functions

# Generated at 2022-06-23 15:56:05.819470
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.StringIO("if 1:\n  pass")
    g = tokenize.generate_tokens(r.readline)
    tokens_list = list(g)
    print(tokens_list)

# Generated at 2022-06-23 15:56:14.794501
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.out = []
            self.tokeneater = self.out.append

        def test_tokenize_loop(self):
            tokenize_loop(StringIO("1 + 1").readline, self.tokeneater)
            self.assertEqual(self.out, [(NUMBER, "1", (1, 0), (1, 1), "\n"),
                                        (OP, "+", (1, 2), (1, 3), "\n"),
                                        (NUMBER, "1", (1, 4), (1, 5), "\n")])

    from unittest import main

    main()



# Generated at 2022-06-23 15:56:18.319368
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b", "c") == "(a|b|c)?", repr(maybe("a", "b", "c"))



# Generated at 2022-06-23 15:56:20.968259
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    except Exception:
        assert False, "failed to raise StopTokenizing"



# Generated at 2022-06-23 15:56:29.347357
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest

    class Tests(unittest.TestCase):
        def test_only_bom(self):
            r = io.BytesIO(BOM_UTF8 + b"# -*- coding: latin-1 -*-\n")
            self.assertTrue(detect_encoding(r.readline), "utf-8-sig")

        def test_only_cookie(self):
            r = io.BytesIO(b"# coding=latin-1\n")
            self.assertTrue(detect_encoding(r.readline), "iso-8859-1")

        def test_cookie_only_second_line(self):
            r = io.BytesIO(b"\n# coding=latin-1\n")

# Generated at 2022-06-23 15:56:36.362806
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenize = Untokenizer().untokenize
    assert untokenize([(1, "a"), (2, "b"), (0, "")]) == "ab"
    assert untokenize([(0, "1"), (1, "\n"), (0, "2")]) == "1\n2"
    assert untokenize([(3, ""), (0, "1"), (1, "\n"), (0, "2")]) == "\n1\n2"
    assert (
        untokenize([(0, "class"), (4, " "), (0, "Foo")])
        == "class Foo"
    )

# Generated at 2022-06-23 15:56:46.770427
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from test.support import captured_stdout
    import io
    import sys
    s = "def f(x): return 2+x\n"
    with captured_stdout() as stdout:
        tokenize_loop(io.StringIO(s).readline, printtoken)
    stdout = stdout.getvalue()
    lines = stdout.splitlines()
    assert len(lines) == 6
    assert lines[0] == "1,0-1,3:\tNAME\t'def'"
    assert lines[1] == "1,4-1,5:\tNAME\t'f'"
    assert lines[2] == "1,5-1,6:\tOP\t'('"
    assert lines[3] == "1,6-1,7:\tNAME\t'x'"

# Generated at 2022-06-23 15:56:57.585075
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize

    def check(input, output):
        s = io.StringIO(input).readline
        result = Untokenizer().untokenize(tokenize.generate_tokens(s))
        if result != output:
            print(f'Source: {input!r}')
            print(f'Result: {result!r}')
            print(f'Expect: {output!r}')
            raise ValueError

    # Check to make sure we don't mangle indentation
    check("def foo():\n    print('foo')\n", "def foo():\n    print('foo')\n")

    # Check to make sure we don't output excess newlines
    check("print(5)\n\nprint(6)\n", "print(5)\n\nprint(6)\n")

# Generated at 2022-06-23 15:57:08.084744
# Unit test for function tokenize_loop
def test_tokenize_loop():
    "Basic test of tokenize_loop()"
    import io
    import sys
    import token
    result = []
    tokeneater = result.append
    readline = io.BytesIO(
        b'del x\nprint(42)\n'
    ).readline
    tokenize_loop(readline, tokeneater)

# Generated at 2022-06-23 15:57:12.740552
# Unit test for function any
def test_any():
    pattern = re.compile(any("a", "b", "c"))
    assert pattern.findall("b") == ["b"]
    assert pattern.findall("ab") == ["ab"]
    assert pattern.findall("aab") == ["aab"]
    assert pattern.findall("abb") == ["abb"]
    assert pattern.findall("ababab") == ["ababab"]



# Generated at 2022-06-23 15:57:19.433544
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import BytesIO
    from io import TextIOWrapper
    import tokenize, untokenize

    x = b"class Test:\\n    @staticmethod\\n    def assertEqual(foo, bar): pass"
    readline = BytesIO(x).readline
    tokenize_compat_gen = tokenize.generate_tokens(readline)

    untokenizer = untokenize.Untokenizer()
    untokenizer.compat(next(tokenize_compat_gen), tokenize_compat_gen)

    y = untokenizer.tokens[0]
    assert y == "class "

    y = untokenizer.tokens[1]
    assert y == "Test"



# Generated at 2022-06-23 15:57:20.853791
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:57:22.927954
# Unit test for function any
def test_any():
    assert any("a", "bb") == "(a|bb)*"
    assert any("abc", "d") == "(abc|d)*"



# Generated at 2022-06-23 15:57:33.683352
# Unit test for function untokenize
def test_untokenize():
    tests = [
        ("one two three".split(), "one two three"),
        ("one two three four five six seven eight nine ten".split(), "one two three four five six seven eight nine ten"),
        ("one two three\nfour five six\nseven eight nine ten".split(), "one two three\nfour five six\nseven eight nine ten"),
        ("one two three\n\nfour five six\n\n\nseven eight nine ten".split(), "one two three\n\nfour five six\n\n\nseven eight nine ten"),
        ("""
            one two three
              four five six
                seven eight nine ten
        """.split(), """\
            one two three
              four five six
                seven eight nine ten"""),
        ]

# Generated at 2022-06-23 15:57:44.168551
# Unit test for function tokenize_loop
def test_tokenize_loop():

    def readline() -> Text:
        line = next(tokens, "")
        if line.startswith("#"):
            line = "\n"
        return line

    def tokeneater(type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
        (start_row, start_col) = xxx_todo_changeme2
        (end_row, end_col) = xxx_todo_changeme3
        assert (
            start_row == end_row
        ), f"{type}: {(start_row, start_col)}-{(end_row, end_col)}: {token!r}, {line!r}"

# Generated at 2022-06-23 15:57:50.632599
# Unit test for function untokenize

# Generated at 2022-06-23 15:58:00.961797
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # tests for bug #663101
    uto = Untokenizer()
    input_data = [
        (tokenize.NAME, "abc"),
        (tokenize.NEWLINE, "\n"),
        (tokenize.INDENT, "  "),
        (tokenize.NAME, "def"),
    ]
    expected_output = "abc\n  def"
    assert uto.untokenize(iter(input_data)) == expected_output

    uto = Untokenizer()
    input_data = [
        (tokenize.NAME, "abc"),
        (tokenize.NEWLINE, "\r\n"),
        (tokenize.NAME, "def"),
    ]
    expected_output = "abc\r\ndef"
    assert uto.untokenize(iter(input_data)) == expected_output

   

# Generated at 2022-06-23 15:58:14.290538
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    def check(input, expected):
        result = []
        tokenize_loop(input.splitlines().__next__, result.append)
        for i, token in enumerate(expected):
            if result[i][:-1] != list(token):
                print("item", i, "expected", token, "got", result[i])
        if len(result) != len(expected):
            print("number of items expected", len(expected), "got", len(result))


# Generated at 2022-06-23 15:58:15.519282
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()



# Generated at 2022-06-23 15:58:23.917079
# Unit test for function untokenize
def test_untokenize():
    s = "def f(): return 'test\\\\n'\n"

# Generated at 2022-06-23 15:58:29.586709
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import tokenize as _tokenize
    u = Untokenizer()
    readline = io.BytesIO(b"if 1:\n  pass\n").readline
    u.untokenize(_tokenize.generate_tokens(readline))
    assert u.tokens == ["if ", "1", ":", "\n", "  ", "pass", "\n"]



# Generated at 2022-06-23 15:58:38.983933
# Unit test for function untokenize
def test_untokenize():
    def check(input, output):
        result = untokenize(input)
        if result != output:
            print("Result does not match expected output.")
            print("Input:")
            for line in input:
                print(line)
            print("Expected:")
            print(output)
            print("Received:")
            print(result)
    input = [(NUMBER, '1'), (NAME, 'abc'), (OP, '+'), (NUMBER, '2'),
             (OP, '*'), (NUMBER, '3'), (NEWLINE, ''),
             (NAME, 'a'), (OP, '='), (NUMBER, '42'), (NEWLINE, ''),
             (NAME, 'a'), (OP, '+'), (NUMBER, '1'), (NEWLINE, '')]

# Generated at 2022-06-23 15:58:42.701744
# Unit test for function generate_tokens
def test_generate_tokens():
    global tabsize
    tabsize = 8
    readline = StringIO("def square(n):\n  \"\"\"Return the square of a number.\"\"\"\n  return n ** 2\n").readline
    for token in generate_tokens(readline): print(token)

if __name__ == "__main__":
    test_generate_tokens()
 
 
    from io import StringIO
    from tokenize import generate_tokens, untokenize

# Generated at 2022-06-23 15:58:48.371372
# Unit test for function maybe
def test_maybe():
    assert maybe("abc", "def") == "(abc|def)?"
    assert maybe("def") == "def?"
# end unit test for function maybe

# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\n" + Whitespace, Comment)
Name = r"\w+"

Hexnumber = r"0[xX][0-9a-fA-F]+"
Binnumber = r"0[bB][01]+"
Octnumber = r"0[oO][0-7]+"
Decnumber = r"\d+"

# Generated at 2022-06-23 15:59:00.308372
# Unit test for function detect_encoding
def test_detect_encoding():
    # Create a readline function that knows about encoding cookies and BOMs
    def readline():
        if not lines:
            raise StopIteration
        line = lines.pop(0)
        if isinstance(line, str):
            line = line.encode("ascii")
        return line

    lines = [b"# coding: latin-1\n"]
    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])

    lines = [
        "#!/usr/bin/python\n",
        "# coding: latin-1\n",
        "import string\n",
        "\n",
    ]
    assert detect_encoding(readline) == ("iso-8859-1", lines[:-1])


# Generated at 2022-06-23 15:59:06.547904
# Unit test for function group
def test_group():
    """
    >>> test_group()
    ('(', '|', ')')
    """
    import re
    # Just make sure that the regex engine got what we wanted.
    m = re.match(group("a", "b", "c"), "a")
    assert m is not None
    m = re.match(group("a", "b", "c"), "b")
    assert m is not None
    m = re.match(group("a", "b", "c"), "c")
    assert m is not None
    m = re.match(group("a", "b", "c"), "d")
    assert m is None



# Generated at 2022-06-23 15:59:09.130943
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass
    try:
        raise TokenError("test")
    except TokenError:
        pass



# Generated at 2022-06-23 15:59:11.874006
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
test_any()



# Generated at 2022-06-23 15:59:17.357802
# Unit test for function untokenize
def test_untokenize():
    input = [
        (NAME, "if"),
        (NAME, "x"),
        (OP, ":"),
        (NEWLINE, "\n"),
        (INDENT, "\t"),
        (NAME, "y"),
        (OP, "="),
        (NUMBER, "2"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (NAME, "else"),
        (OP, ":"),
        (NEWLINE, "\n"),
        (INDENT, "\t"),
        (NAME, "y"),
        (OP, "="),
        (NUMBER, "3"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (NAME, "print"),
        (NAME, "y"),
        (NEWLINE, "\n"),
    ]

# Generated at 2022-06-23 15:59:18.793322
# Unit test for constructor of class TokenError
def test_TokenError():
    te = TokenError("test")
    assert str(te) == "test"



# Generated at 2022-06-23 15:59:30.205038
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    un = Untokenizer()

    # First token
    un.add_whitespace((1, 0))
    assert un.tokens == []
    un.prev_row = 1
    un.prev_col = 0

    # Second token, same line
    un.add_whitespace((1, 2))
    assert un.tokens == ["  "]
    un.prev_row = 1
    un.prev_col = 2

    # Third token, same line
    un.add_whitespace((1, 5))
    assert un.tokens == ["  ", "   "]
    un.prev_row = 1
    un.prev_col = 5

    # Fourth token, on next line
    un.add_whitespace((2, 0))

# Generated at 2022-06-23 15:59:37.799511
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Iterator version
    readline = iter(
        ("if 1: #foo\n", "  print(2)\n")
    ).__next__  # type: Callable[[], Text]
    tokeneater = lambda x, y, z, w, v: print(
        tok_name[x], repr(y), z, w, v.strip()
    )
    tokenize_loop(readline, tokeneater)
    # Function version
    readline = lambda: next(readline)  # type: Callable[[], Text]
    tokeneater = lambda x, y, z, w, v: print(
        tok_name[x], repr(y), z, w, v.strip()
    )
    tokenize_loop(readline, tokeneater)
    # Test StopTokenizing

# Generated at 2022-06-23 15:59:42.090971
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize

# Generated at 2022-06-23 15:59:50.354689
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import generate_tokens
    tests = [
        """def f():
    pass
""",
        "1+2\n",
        '"""a\\nb"""\nc',
        """def f():
    pass # comment
# another
""",
        ]
    for test in tests:
        print(test)
        for token in generate_tokens(io.StringIO(test).readline):
            print(token)


# Generated at 2022-06-23 15:59:56.520223
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io  # testing requires StringIO
    inp = io.StringIO("""def f(x):
    print('xxx')
    return 42
""")
    out = io.StringIO()
    rl = inp.readline
    untok = Untokenizer()
    try:
        tokenize_loop(rl, untok.tokeneater)
    except StopTokenizing:
        pass
    untok.untokenize(untok.tokens)
    print(untok.tokens)



# Generated at 2022-06-23 15:59:58.488356
# Unit test for function maybe
def test_maybe():
    assert (maybe("a", "b") == "(a|b)?")
    assert (maybe("a") == "(a)?")
    assert (maybe() == "()?")



# Generated at 2022-06-23 16:00:07.737715
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    u.add_whitespace((1,0))
    u.tokens.append("test")
    assert u.tokens == ["test"]
    u.prev_row = 1
    u.prev_col = 4
    u.add_whitespace((1,5))
    assert u.tokens == ["test ", " "]
    u.prev_col = 5
    assert u.untokenize([("test", "test")]) == "test"
    assert u.prev_col == 9
    assert u.untokenize([("test", "test"), (NEWLINE, "\n"), ("test", "test")]) == "test\n    test"
    assert u.prev_col == 9



# Generated at 2022-06-23 16:00:13.381484
# Unit test for function tokenize
def test_tokenize():
    def _get_readline():
        yield "import sys"
        yield "print('beep')"

    readline = _get_readline().__next__
    #readline = iter(_get_readline()).__next__
    tokeneater = printtoken

    tokenize(readline, tokeneater)



# Generated at 2022-06-23 16:00:20.286783
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    input = [
        (NAME, "abc"),
        (NUMBER, "123"),
        (NEWLINE, "\n"),
        (NAME, "def"),
        (NUMBER, "456"),
        (ENDMARKER, ""),
    ]
    output = "abc 123\ndef 456"
    u = Untokenizer()
    result = u.untokenize(iter(input))
    assert result == output, "unexpected untokenize() output"


# Generated at 2022-06-23 16:00:21.885918
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.NAME, "abc", (1, 2), (1, 4), "xyz")



# Generated at 2022-06-23 16:00:26.597010
# Unit test for function maybe
def test_maybe():
    assert maybe("abc") == "(abc)?", "maybe(\"abc\")==\"(abc)?\", not \"%s\"" % maybe(
        "abc")
    modname = "test_maybe"
    if modname in sys.modules:
        del sys.modules[modname]



# Generated at 2022-06-23 16:00:38.128374
# Unit test for function untokenize
def test_untokenize():

    from io import StringIO

    from .tests.test_tokenize import detokenize, round_trip_unsupported_source

    def test_single_string(s):
        f = StringIO(s)
        tokens = list(tokenize(f.readline))
        newcode = untokenize(tokens)
        assert detokenize(newcode) == s

    def test_round_trip(s):
        f = StringIO(s)
        tokens = cast(TokenInfo, list(tokenize(f.readline)))
        newcode = untokenize(tokens)
        f = StringIO(newcode)
        newtokens = cast(TokenInfo, list(tokenize(f.readline)))
        assert newtokens == tokens


# Generated at 2022-06-23 16:00:41.556998
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == [] and u.prev_row == 1 and u.prev_col == 0
    u = Untokenizer()
    u.tokens = ["before"]
    assert u.tokens == ["before"]



# Generated at 2022-06-23 16:00:50.874976
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import BytesIO

    f = BytesIO(b"def foo(): pass\n")
    l = f.readline

    def check_token(type, token, start, end, line):
        (srow, scol) = start
        (erow, ecol) = end
        assert (
            type == NAME
        ), "type must be NAME in tokenize_loop, got %s" % tok_name[type]
        assert token == "def", "token must be `def` in tokenize_loop, got %s" % token
        assert srow == 0, "srow must be 0 in tokenize_loop, got %d" % srow
        assert scol == 0, "scol must be 0 in tokenize_loop, got %d" % scol

# Generated at 2022-06-23 16:00:54.274698
# Unit test for function printtoken
def test_printtoken():
    s = '''\
    for i in range(10):
        print i
'''
    tokenize(s, printtoken)


# Generated at 2022-06-23 16:00:59.286783
# Unit test for function tokenize_loop

# Generated at 2022-06-23 16:01:06.081690
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline_generator(text):
        line = ""
        for c in text:
            if c == "\n":
                yield line
                line = ""
            else:
                line += c

        yield line

    def tokeneater(*args):
        pass

    tokenize_loop(readline_generator("abc\ndef").__next__, tokeneater)



# Generated at 2022-06-23 16:01:07.200382
# Unit test for constructor of class TokenError
def test_TokenError():
    x = TokenError()



# Generated at 2022-06-23 16:01:16.426427
# Unit test for function printtoken
def test_printtoken():
    printtoken(NAME, "abc", (1, 1), (1, 4), "")

# Return the encoding of source code string in the given file.
#
# The encoding is extracted according to PEP 263, i.e. the first or second
# line in the file is matched by the regular expression
#
#   "#.*coding[:=]\s*([-\w.]+)".
#
# If no encoding is specified, UTF-8 is returned.  If the regular
# expression matches but the encoding is not known, a LookupError is
# raised.



# Generated at 2022-06-23 16:01:25.896423
# Unit test for function printtoken
def test_printtoken():
    test_string = "one two three"
    test_token_list = [(NAME, "one", (1,0), (1,3), "one two three"),
                       (NAME, "two", (1,4), (1,7), "one two three"),
                       (NAME, "three", (1,8), (1,13), "one two three")]
    assert [x for x in test_token_list] == list(tokenize(test_string))

    test_string = "1+2"
    test_token_list = [(NUMBER, "1", (1,0), (1,1), "1+2"),
                       (OP, "+", (1,1), (1,2), "1+2"),
                       (NUMBER, "2", (1,2), (1,3), "1+2")]
