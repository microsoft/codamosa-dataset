

# Generated at 2022-06-23 15:51:22.583193
# Unit test for function tokenize
def test_tokenize():
    def tokenize_print(readline):
        tokenize(readline, printtoken)

    def generate_tokens_print(readline):
        for token in generate_tokens(readline):
            printtoken(*token)

    for meth in (tokenize_print, generate_tokens_print):
        print("====", meth.__name__)
        try:
            # read from stdin
            meth(None)
        except TypeError as e:
            # read from a string
            meth(iter(["print('Hello world')"]).__next__)



# Generated at 2022-06-23 15:51:24.049953
# Unit test for function printtoken
def test_printtoken():
    printtoken(5, None, (1,1), (1,1), '+')



# Generated at 2022-06-23 15:51:30.730304
# Unit test for function untokenize
def test_untokenize():
    from tokenize import generate_tokens, tok_name

    def remove_encoding_declaration(source: str) -> str:
        for idx, tok in enumerate(generate_tokens(iter(source.splitlines(1)).__next__)):
            if tok[0] == ENCODING:
                return "".join(source.splitlines(1)[idx:])
        return source

    def check_token_roundtrip(f, source_as_tokens: bool = True) -> None:
        if source_as_tokens:
            source = untokenize(f)
        else:
            source = f.__next__()
        source = remove_encoding_declaration(source)
        readline = iter(source.splitlines(1)).__next__
        newt

# Generated at 2022-06-23 15:51:37.672587
# Unit test for function generate_tokens
def test_generate_tokens():
    import unittest
    import io

    def tokenize(source):
        # Get tokens, preserving line numbers
        result = []
        for t in generate_tokens(io.StringIO(source).readline):
            result.append(t)
        return result

    class Test(unittest.TestCase):
        def check_equal(self, input, expected):
            result = tokenize(input)
            self.assertEqual(result, expected)

        def test_endmarker(self):
            self.check_equal('', [(0, '')])
            self.check_equal('\n', [(4, '\n'), (0, '')])
            self.check_equal('a\n', [(1, 'a'), (4, '\n'), (0, '')])


# Generated at 2022-06-23 15:51:40.219604
# Unit test for function tokenize
def test_tokenize():
    "Simple test for tokenize"
    source = "for i in range(10): print(i)"
    tokenize(source.splitlines().__iter__().__next__)



# Generated at 2022-06-23 15:51:43.321015
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass


# Specialize the exception for the tokenize method.
# Currently it does not add any attributes to the exception.
# However, there is a strong possibility that it will add
# attributes in the future.

# Generated at 2022-06-23 15:51:50.971606
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 14
    untok.prev_col = 18
    untok.tokens = ["aaaaa", "bbbbb", "ccccc", "dddd", "eeeee", "fffff", "ggggg"]
    untok.add_whitespace((14, 25))
    s = ''.join(untok.tokens)
    assert s == 'aaaaabbbbbcccccddddeeeeefffffggggg  '


# Generated at 2022-06-23 15:51:53.013997
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-23 15:51:58.568506
# Unit test for function tokenize

# Generated at 2022-06-23 15:52:08.383558
# Unit test for function maybe

# Generated at 2022-06-23 15:52:21.141203
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", "maybe(a) has wrong regex"
    assert maybe("a", "b") == "((a)|(b))?", "maybe(a,b) has wrong regex"
test_maybe()

# regex fragments
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"[a-zA-Z_]\w*"

Hexnumber = r"0[xX][\da-fA-F]+[lL]?"
Octnumber = r"(0[oO][0-7]+)|(0[0-7]*)[lL]?"

# Generated at 2022-06-23 15:52:26.855051
# Unit test for function untokenize
def test_untokenize():
    # Helper to compare token lists
    def check_one(tokens, want):
        src = untokenize(iter(tokens)).rstrip("\n")
        got = repr(src)
        if want != got:
            raise ValueError("untokenize: want %r, got %r" % (want, got))

    # Single-line examples
    check_one([(1, "def"), (2, " "), (1, "x"), (3, "(")], "def x(")
    check_one([(1, "1"), (2, "+"), (1, "1"), (3, ","),], "1+1,")
    # No whitespace control

# Generated at 2022-06-23 15:52:37.309264
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    readline = StringIO('print("""hello\nworld""")').readline
    result = list(generate_tokens(readline))
    print("Source")
    print("======")
    print('print("""hello\nworld""")')
    print()
    print("Tokens")
    print("======")
    pprint.pprint(result)
    print()
    print("Untokenized")
    print("===========")
    print(untokenize(result))

# Generated at 2022-06-23 15:52:47.834400
# Unit test for function printtoken
def test_printtoken():
  def run(x):
    printtoken(*x)
  run((string, "foo", (1,1), (1,1), "foo"))
  run((string, "foo", (1,1), (1,2), "foo"))
  run((string, "foo", (1,1), (1,3), "foo"))
  run((string, "foo", (1,1), (2,2), "foo"))
  run((string, "foo", (2,2), (2,2), "foo"))
  run((string, "foo", (3,3), (3,3), "foo"))
  run((string, "foo", (4,4), (4,4), "foo"))
  run((string, "foo", (5,5), (5,5), "foo"))

# Generated at 2022-06-23 15:52:57.675794
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    r = tokenize.generate_tokens(StringIO('if 1:\n print(2)\n').readline)
    assert next(r) == (tokenize.NAME, 'if', (1, 0), (1, 2), 'if 1:')
    assert next(r) == (tokenize.NUMBER, '1', (1, 3), (1, 4), 'if 1:')
    assert next(r) == (tokenize.OP, ':', (1, 4), (1, 5), 'if 1:')
    assert next(r) == (tokenize.NEWLINE, '\n', (1, 5), (1, 6), 'if 1:\n')
    assert next(r) == (tokenize.INDENT, '', (2, 0), (2, 0), 'print(2)')

# Generated at 2022-06-23 15:53:08.140747
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    def compare_str(str1, str2):
        assert str1 == str2, f"{str1!r} != {str2!r}"

    def compare_file(filename):
        f = open(filename, "rb")
        encoding, lines = detect_encoding(f.readline)
        f.seek(0)
        readline = get_readline(f, encoding)
        u = Untokenizer()
        tokens = generate_tokens(readline)
        compare_str(detokenize(tokens), u.compat(next(tokens), tokens))

    def detect_encoding(readline):
        bom_found = False
        encoding = None
        def readline_wrapper():
            nonlocal bom_found
            nonlocal encoding
            if bom_found:
                return readline()


# Generated at 2022-06-23 15:53:12.248732
# Unit test for function maybe
def test_maybe():
    success = True
    assert maybe("[a-z]") == "([a-z])?"
    assert maybe("[a-z]", "[0-9]") == "([a-z]|[0-9])?"
    return success


# Generated at 2022-06-23 15:53:13.919895
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-23 15:53:21.449274
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0

    u.add_whitespace((2, 0))
    assert u.prev_row == 2
    assert u.prev_col == 0

    u.add_whitespace((3, 4))
    assert u.prev_row == 3
    assert u.prev_col == 4

    u.add_whitespace((3, 6))
    assert u.prev_row == 3
    assert u.prev_col == 6
    assert u.tokens == ["\n", "\n  "]



# Generated at 2022-06-23 15:53:25.479444
# Unit test for function maybe
def test_maybe():
    assert maybe('abc') == '(abc)?', maybe('abc')
    assert maybe('abc') == maybe('def'), maybe('abc')

# Generated at 2022-06-23 15:53:31.739064
# Unit test for function detect_encoding
def test_detect_encoding():
    import re
    import io
    # encodings other than utf-8 need to be tested here
    # because they don't trigger the utf-8 bom check
    # in tokenizer.c.
    tests = [
        (b"# coding: latin-1\xe8", "latin-1"),
        (b"#!/usr/bin/python\n# coding: latin-1\xe8", "latin-1"),
        (b"# -*- coding: latin-1 -*-\xe8", "latin-1"),
        (b"# vim:fileencoding=latin-1\xe8", "latin-1"),
    ]
    for test in tests:
        stream = io.BytesIO(test[0])
        detected = detect_encoding(stream.readline)[0]

# Generated at 2022-06-23 15:53:37.235673
# Unit test for function detect_encoding
def test_detect_encoding():
    def _test1():
        f = StringIO("\xef\xbb\xbf# -*- coding: iso-8859-15 -*-\nfoo = 'äöü'\n")
        f.readline = f.readline
        e, l = detect_encoding(f.readline)
        assert e == "iso-8859-15"
        assert l == ['# -*- coding: iso-8859-15 -*-\n']
    _test1()
    def _test2():
        f = StringIO("#!/usr/bin/python\n# -*- coding: cp1252 -*-\n")
        e, l = detect_encoding(f.readline)
        assert e == "cp1252"

# Generated at 2022-06-23 15:53:38.748039
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:53:43.796106
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # Normal case.
    untok = Untokenizer()
    tokens = [
        (NL, "\n", (0, 0), (0, 0), ""),
        (INDENT, "\n    ", (1, 0), (1, 4), ""),
        (NAME, "foo", (1, 4), (1, 7), ""),
        (NAME, "bar", (1, 8), (1, 11), ""),
        (DEDENT, "", (1, 11), (1, 11), ""),
        (OP, "+", (1, 11), (1, 11), ""),
        (NUMBER, "2", (1, 12), (1, 12), ""),
        (NEWLINE, "\n", (1, 12), (1, 12), ""),
    ]
    for t in tokens:
        print(t)

# Generated at 2022-06-23 15:53:50.821659
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io

    sample = (
        "if 1: # my comment\n"
        '  print("# not a comment")\n'
        '  x = 1 # another comment'
    )
    f = io.StringIO(sample)
    # Feed the instance with some tokens
    untok = Untokenizer()
    tokenize(f.readline, untok.tokeneater)
    # Check that the non-weird tokens are passed through untouched
    assert untok.compat(sample, "strict") == sample


# Generated at 2022-06-23 15:54:00.267816
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test the ability of the tokenize module to cope with EOF
    # Moved from test_tokenize because it's a test of the interface,
    # not the implementation.
    import io
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    source = u"def f():\n    return\n"
    readline = io.BytesIO(source.encode("utf-8")).readline
    tokens = list(generate_tokens(readline))
    readline = io.BytesIO(source.encode("utf-8")).readline
    tokens2 = list(generate_tokens(readline))
    result = untokenize(tokens)
    result2 = untokenize(tokens2)
    result == result2



# Generated at 2022-06-23 15:54:05.676362
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    s = "for x in range(6):\n    print(x)\n"
    lst = []
    for t in generate_tokens(StringIO(s).readline):
        lst.append(t)
    assert u.compat(lst.pop(0), lst) is None
    assert "".join(u.tokens) == s



# Generated at 2022-06-23 15:54:14.664252
# Unit test for function untokenize
def test_untokenize():
    utok = untokenize
    eq = assert_equals = assertEqual
    neq = assert_not_equals = assertNotEqual

    # Test token sequences with only two elements
    test_cases = [
        ([(0, "def")], "def "),
        ([(0, "123")], "123"),
        ([(0, "123"), (1, " ")], "123 "),
        ([(1, " "), (0, "123")], " 123"),
        ([(0, "123"), (2, "\n"), (0, "456")], "123\n456"),
    ]

    for token_seq, expected_result in test_cases:
        result = utok(token_seq)
        eq(expected_result, result)

    # Test token sequences with multiple elements
    test_cases

# Generated at 2022-06-23 15:54:19.698473
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?"
    assert maybe("a", "b") == "(a|b)?"
    assert maybe("a", "b", "c") == "(a|b|c)?"


# Generated at 2022-06-23 15:54:32.021971
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # Test 1: Row of start is before prev_row
    untokenizer = Untokenizer()
    untokenizer.prev_row = 5
    untokenizer.prev_col = 0
    untokenizer.add_whitespace((4, 2))
    assert untokenizer.prev_row == 4
    assert untokenizer.prev_col == 2
    assert untokenizer.tokens == []

    # Test 2: Row of start is same as prev_row
    untokenizer.prev_row = 2
    untokenizer.prev_col = 4
    untokenizer.add_whitespace((2, 8))
    assert untokenizer.prev_row == 2
    assert untokenizer.prev_col == 8
    assert untokenizer.tokens == ["    "]

    # Test 3: Row of start is

# Generated at 2022-06-23 15:54:43.584795
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    # Test cases are all from the Python 3.3.3 grammar test suite

# Generated at 2022-06-23 15:54:46.392172
# Unit test for constructor of class TokenError
def test_TokenError():
    # TODO:  RHEL 8 (at least) has a version of pytest that doesn't
    # recognize "def test_TokenError()" as a valid test.  As a result the
    # argument is not tested.  Investigate.
    pass



# Generated at 2022-06-23 15:54:52.531123
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import tokenize

    data = "\n\n  def f(x):\n    return x + 1\n\n"  # No dedent
    f = io.StringIO(data)

    ut = Untokenizer()
    ut.compat(tokenize.tokenize(f.readline), tokenize.tokenize(f.readline))
    assert "".join(ut.tokens) == data



# Generated at 2022-06-23 15:55:00.089872
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield bytes(b'#coding: gbk\n')
        yield bytes(b'#new encoding\n')
        yield bytes(b'\n')

    result = detect_encoding(readline)
    assert result[0] == "gbk"
    assert result[1] == [b'#coding: gbk\n', b'#new encoding\n', b'\n']



# Generated at 2022-06-23 15:55:01.633680
# Unit test for function any
def test_any():
    any("ab", "c") == "(ab|c)*"



# Generated at 2022-06-23 15:55:13.513513
# Unit test for function tokenize
def test_tokenize():
    import io

    class Readline:
        def __init__(self, lines: List[Text]):
            self.lines = lines

        def __call__(self) -> Text:
            if self.lines:
                line = self.lines[0]
                del self.lines[0]
                return line
            else:
                return ""

    text = "1 + 2\n"
    rl = Readline(text.split("\n"))

    # write tokens to a list
    tok = []

    def tokeneater(*args):
        tok.append(args)

    tokenize(rl.__call__, tokeneater)

# Generated at 2022-06-23 15:55:15.599373
# Unit test for constructor of class TokenError
def test_TokenError():
    # There's no good way to test that a class can be instantiated,
    # but this is better than nothing
    TokenError()



# Generated at 2022-06-23 15:55:18.561678
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    Untokenizer.compat(Untokenizer(), (NAME, "test"))
    Untokenizer.compat(
        Untokenizer(), (NUMBER, "test")
    )  # Suppressing "unused" warning


# Generated at 2022-06-23 15:55:19.395434
# Unit test for constructor of class TokenError
def test_TokenError():
    return TokenError



# Generated at 2022-06-23 15:55:20.051243
# Unit test for constructor of class TokenError
def test_TokenError():
    e = TokenError()



# Generated at 2022-06-23 15:55:20.832674
# Unit test for function group
def test_group():
    return



# Generated at 2022-06-23 15:55:22.305041
# Unit test for function any
def test_any():
    assert any("xyz") == "(xyz)*"



# Generated at 2022-06-23 15:55:32.428420
# Unit test for function generate_tokens
def test_generate_tokens():
    """Test the generate_tokens() generator."""
    import tokenize

    def tokenize_print(readline):
        """Print tokens of a Python script."""
        tokgen = generate_tokens(readline)
        for toktype, tokval, _, xtokval, _ in tokgen:
            if toktype == tokenize.ENCODING:
                print("ENCODING", tokval)
                continue
            print("%20s %-20r" % (
                token.tok_name[toktype], tokval))
    with open("tokenize_tests.txt") as f:
        tokenize_print(f.readline)


# This example from the docs is actually broken.
# The indentation in the first line should be 0,
# but is in fact 4


# Generated at 2022-06-23 15:55:39.634430
# Unit test for function generate_tokens
def test_generate_tokens():
    from token import tok_name

    with open("tokenizer.py", "rb") as f:
        toks = generate_tokens(f.readline)
        for tok in toks:
            print("%20s   %-14r %s" % (
                tok_name[tok[0]], tok[1], tok[4].rstrip()))

# End of unit test for generate_tokens

# Generated at 2022-06-23 15:55:43.595945
# Unit test for function detect_encoding
def test_detect_encoding():
    import codecs
    from io import StringIO

    def readline():
        line = "Test"
        return line.encode()
    encoding, lines = detect_encoding(readline)
    assert True



# Generated at 2022-06-23 15:55:45.400923
# Unit test for function printtoken
def test_printtoken():
    printtoken(4, "Hello", (1, 2), (1, 5), "Hello")



# Generated at 2022-06-23 15:55:58.226419
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from unittest import TestCase, main
    from contextlib import contextmanager

    class CheckCallsMixin:
        def setUp(self):
            self.called = []

        def check_called(self, expected):
            self.assertEqual(len(self.called), len(expected))
            for i, args in enumerate(expected):
                self.assertEqual(self.called[i], args)

        @contextmanager
        def check_calls(self, expected):
            self.setUp()
            try:
                with self:
                    yield
            except Exception:
                print("Called:", self.called)
                raise
            else:
                self.check_called(expected)


# Generated at 2022-06-23 15:56:09.161629
# Unit test for function generate_tokens
def test_generate_tokens():
    import sys
    import io
    import token

    # This is used to test tokenize.generate_tokens
    with io.StringIO(
        "def foo(): pass\n"
        'a = "x = 1"\n'
        'if a:\n'
        "  a = a + 1"
    ) as f:
        g = generate_tokens(f.readline)
        tok = next(g)
        while tok[0] != token.INDENT:
            tok = next(g)
        tok = (yield tok)
        while tok[0] != token.DEDENT:
            tok = next(g)
        tok = (yield tok)
        for tok in g:
            yield tok



# Generated at 2022-06-23 15:56:16.771775
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?"
    assert maybe("a") == "a?"
    assert maybe() == ""
test_maybe()


Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"[a-zA-Z_]\w*"

Hexnumber = r"0[xX](?=[\da-fA-F_])[\da-fA-F_]+"
Binnumber = r"0[bB][01_]+"
Octnumber = r"0[oO][0-7_]+"

# Generated at 2022-06-23 15:56:18.880623
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"



# Generated at 2022-06-23 15:56:28.857567
# Unit test for function untokenize
def test_untokenize():
    untok = untokenize([(1, 'hi'), (1, '\n')])
    assert untok == 'hi\n'
    untok = untokenize([(1, 'a'), (1, 'b'), (1, 'c')])
    assert untok == 'ab c'
    untok = untokenize([(1, 'a'), (1, 'b'), (1, 'c')],)
    assert untok == 'abc'
    untok = untokenize([(1, 'hi'), (1, '\n')],)
    assert untok == 'hi\n'



# Generated at 2022-06-23 15:56:37.453434
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import BytesIO

    input = b"&^\xab"
    buf = BytesIO(input)

    def readline():
        return buf.readline().decode("charmap")

    def tokeneater(type, token, start, end, line):
        assert token == input[start[1] : end[1]].decode("charmap")
        assert line == input.decode("charmap")
        assert start[0] == end[0] == 1
        assert type == OP

    tokenize_loop(readline, tokeneater)


# Generated at 2022-06-23 15:56:47.384589
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    global tabsize
    for orig_tabsize in (1, 2, 4, 8):
        tabsize = orig_tabsize
        untok = Untokenizer()

        untok.prev_row = 5
        untok.prev_col = 0
        untok.add_whitespace((6, 0))
        untok.tokens == ["\n"]
        untok.prev_row, untok.prev_col = untok.prev_row + 1, untok.prev_col

        untok.prev_row = 5
        untok.prev_col = 0
        untok.add_whitespace((5, 5))
        untok.tokens == ["\n", " " * 5]
        untok.prev_col = 5

        untok.prev_row = 5
        untok.prev_col

# Generated at 2022-06-23 15:56:57.988481
# Unit test for function tokenize
def test_tokenize():
    import io

    text = """def f(x):
    return 2*x"""
    toks = list(generate_tokens(io.StringIO(text).readline))

# Generated at 2022-06-23 15:57:07.183476
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    io = io.StringIO("1 + 1\n")
    readline = io.readline
    tokeneater = type("Eater", (), dict(addtoken=untok.compat, toks=[]))()
    results = [
        (1, '1'),
        (3, ' '),
        (1, '+'),
        (3, ' '),
        (1, '1'),
        (4, '')
    ]
    for test, result in zip(tokenize(readline, tokeneater), results):
        assert test[:2] == result, repr(test) + repr(result)



# Generated at 2022-06-23 15:57:15.074256
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    """
    >>> from io import StringIO
    >>> from blib2to3.pgen2.tokenize import generate_tokens
    >>> from untokenize import untokenize
    >>> untok = Untokenizer()
    >>> for token in generate_tokens(StringIO("x = 'foo'").readline):
    ...     print(token)
    ...     break
    (1, 'x', (1, 0), (1, 1), "x = 'foo'")
    >>> untok.compat(token, generate_tokens(StringIO("x = 'foo'").readline))
    >>> print(untok.tokens)
    ['x', ' ', '=']
    """
    pass



# Generated at 2022-06-23 15:57:26.843125
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from io import BytesIO
    from typing import Optional

    class _DebugWriter:
        """Writes tokenize output to stdout for easy debugging."""

        def __init__(self) -> None:
            self.last_lineno = 1
            self.last_col = 0


# Generated at 2022-06-23 15:57:36.934431
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(lines: List[str]) -> Iterator[Optional[str]]:
        for line in lines:
            return line

    def read_or_stop() -> Iterator[Optional[str]]:
        try:
            return next(lines)
        except StopIteration:
            return None

    assert detect_encoding(read_or_stop) == ("utf-8", [])
    assert detect_encoding(read_or_stop) == ("utf-8", ["\xef\xbb\xbf"])
    assert detect_encoding(read_or_stop) == ("utf-8", ["#!\n"])
    assert detect_encoding(read_or_stop) == ("utf-8", ["# -\*- coding: UTF-8 -\*-\n"])

# Generated at 2022-06-23 15:57:38.104753
# Unit test for function generate_tokens

# Generated at 2022-06-23 15:57:41.243469
# Unit test for function group
def test_group():
    # function group(*choices)
    # returns "(" + "|".join(choices) + ")"
    assert group("abc") == "(abc)"
    assert group("abc", "def") == "(abc|def)"



# Generated at 2022-06-23 15:57:43.608101
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    assert untok.tokens == []
    assert untok.prev_row == 1
    assert untok.prev_col == 0



# Generated at 2022-06-23 15:57:52.383770
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import sys
    import io
    from .tokenize_rt import tokenize_rt

    def test_roundtrip(s):
        # Convert s to tokens
        readline = io.StringIO(s).readline
        tokens = list(tokenize_rt(readline))
        # Convert tokens to s
        untok = Untokenizer()
        out = untok.compat(iter(tokens))
        # Check that s == out
        assert s == out, (
            "roundtrip failed on %a\nproduced: %a" % (s, out)
        )

    test_roundtrip("def foo():\n    a = 4\n    b = 3\n")

# Generated at 2022-06-23 15:57:53.536003
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
    assert any("a") == "(a)*"
# End unit test


# Generated at 2022-06-23 15:58:01.235845
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    l = ["Hello", "world", "!"]
    s = u.untokenize(l)
    assert s == "Hello world!", "Simple test failed"
    s = u.untokenize([('NUMBER', '12', (0, 0), (0, 2), '12')])
    assert s == "12", "Untokenize number failed"



# Generated at 2022-06-23 15:58:14.508511
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()

    untok.prev_row = 0
    untok.prev_col = 0
    untok.add_whitespace((0, 0))
    assert untok.tokens == []

    untok.tokens = []
    untok.prev_row = 0
    untok.prev_col = 0
    untok.add_whitespace((0, 1))
    assert untok.tokens == [" "]

    untok.tokens = []
    untok.prev_row = 0
    untok.prev_col = 0
    untok.add_whitespace((0, 2))
    assert untok.tokens == [" ", " "]

    untok.tokens = []
    untok.prev_row = 1
    untok.prev_

# Generated at 2022-06-23 15:58:23.206234
# Unit test for function detect_encoding

# Generated at 2022-06-23 15:58:24.528960
# Unit test for function any
def test_any():
    assert any('a', 'b') == '(a|b)*'



# Generated at 2022-06-23 15:58:28.728729
# Unit test for constructor of class TokenError
def test_TokenError():
    exc = TokenError()
    assert hasattr(exc, "msg")
    assert hasattr(exc, "lineno")
    assert hasattr(exc, "offset")
    assert hasattr(exc, "text")
    assert hasattr(exc, "filename")



# Generated at 2022-06-23 15:58:35.344563
# Unit test for function tokenize
def test_tokenize():
    import io

    lines = [
        "def f(x):\n",
        '    """has a triple-quoted string"""\n',
        '    return "with a\\\n',
        "multi-line\\\n",
        'string"'
    ]

    with io.StringIO() as stream:
        stream.write(''.join(lines))
        stream.seek(0)
        for token in generate_tokens(lambda: stream.readline()):
            print(token)

    stream = io.StringIO(''.join(lines))
    tokenize(lambda: stream.readline())
# End test



# Generated at 2022-06-23 15:58:42.678928
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

    example = r'''def f(x):
    return x+1
f(4)
'''

    for detection in (False, True):
        stream = StringIO(example)
        result = StringIO()
        ut = Untokenizer()
        for t in generate_tokens(stream.readline):
            token_type = t[0]
            if token_type == NEWLINE and detection:
                # turn NEWLINE into NL
                t = (NL) + t[1:]
            result.write(ut.untokenize([t]))

        # XXX: should probably test result.getvalue()



# Generated at 2022-06-23 15:58:47.685719
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untokenize = Untokenizer().untokenize
    untokenize([(1, "2"), (3, "4")])
    untokenize([(1, "2"), (3, "4")], [(1, "2"), (3, "4")])



# Generated at 2022-06-23 15:58:59.485619
# Unit test for function untokenize
def test_untokenize():
    import tokenize
    import io
    import sys

    if sys.version_info < (3, 5):

        def reindent(code, indent):
            if not code or not indent:
                return code
            return ("\n" + indent).join(line.strip() for line in code.splitlines()) + "\n"

        def roundtrip(code):
            # XXX check roundtrip invariant for limited input
            g = tokenize.generate_tokens(io.StringIO(code).readline)
            newcode = untokenize(g)
            g = tokenize.generate_tokens(io.StringIO(newcode).readline)
            newnewcode = untokenize(g)
            assert newcode == newnewcode


# Generated at 2022-06-23 15:59:07.409084
# Unit test for function tokenize
def test_tokenize():
    import tokenize as tok
    import io
    import unittest

    class TestTokenize(unittest.TestCase):
        def reader(self, s):
            for c in s:
                yield c

        def test_tokenize_empty(self):
            s = io.StringIO()
            tokens = tok.tokenize(self.reader(""))
            for tok in tokens:
                self.fail("No tokens should be produced")

        def test_tokenize_simple(self):
            s = io.StringIO()
            tokens = tok.tokenize(self.reader("print(42)\n"))

# Generated at 2022-06-23 15:59:10.969961
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_col = 3
    ut.prev_row = 0
    start = (1, 0)
    ut.add_whitespace(start)
    assert ut.tokens == ["\n"]



# Generated at 2022-06-23 15:59:21.459770
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    """
    >>> ut = Untokenizer()
    >>> ut.untokenize([("a", "b"), ("c", "d")])
    'abcd'
    >>> ut.untokenize([("a", "b"), ("c", "d"), ("e", "f")])
    'abcdef'
    >>> ut.untokenize([("a", "b"), ("c", "d"), ("e", "f"), ("g", "h")])
    'abcdefgh'
    >>> ut.untokenize([("a", "b"), ("c", "d"), ("e", "f"), ("g", "h")])
    'abcdefgh'
    >>> ut.untokenize([("a", "b"), ("c", "d"), ("e", "f"), ("g", "h")])
    'abcdefgh'
    """

# Generated at 2022-06-23 15:59:29.783033
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    toktypes = token.tok_name
    toktypes[tokenize.ENDMARKER] = "ENDMARKER"
    toktypes[tokenize.COMMENT] = "COMMENT"

    def _format(token_info):
        tok_type, token, start, end, line = token_info
        return "%s %r %r" % (toktypes[tok_type], token, line[start[1] : end[1]])


# Generated at 2022-06-23 15:59:31.766292
# Unit test for function any
def test_any():
    assert any(r"\d", r"\s") == '(\\d|\\s)*'


# Generated at 2022-06-23 15:59:34.217227
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline() -> bytes:
        return io.BytesIO(b"# -*- coding: latin-1 -*-\n").readline()

    assert detect_encoding(readline) == ("iso-8859-1", [b"# -*- coding: latin-1 -*-\n"])



# Generated at 2022-06-23 15:59:38.064532
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.untokenize([(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')])
    res = ut.untokenize([(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')])
    assert res == 'abcd'


# Generated at 2022-06-23 15:59:46.909400
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    import tokenize as tokenize_module


# Generated at 2022-06-23 15:59:51.636412
# Unit test for function maybe
def test_maybe():
    assert regex.match(maybe('a', 'b'), "ababa")
    assert regex.match(maybe('a', 'b'), "bbba")
    assert regex.match(maybe('a', 'b'), "")
    assert not regex.match(maybe('a', 'b'), "c")



# Generated at 2022-06-23 16:00:04.701016
# Unit test for function tokenize
def test_tokenize():
    import io
    r = io.StringIO("def f():\n\treturn 'hello, world'\n").readline
    tokenize(r)
    r = io.StringIO("f(a=1, b=2)\n").readline
    tokenize(r)
    r = io.StringIO("def f(a=1, b=2):\n\treturn a+b\n").readline
    tokenize(r)
    r = io.StringIO('assert False, "foo"\n').readline
    tokenize(r)
    r = io.StringIO('assert a is None, "foo"\n').readline
    tokenize(r)
    r = io.StringIO('assert a is not None, "foo"\n').readline
    tokenize(r)

# Generated at 2022-06-23 16:00:09.517798
# Unit test for function generate_tokens

# Generated at 2022-06-23 16:00:17.799625
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output):
        input = iter(input.splitlines(1))
        output = iter(output.splitlines(1))

        for line in input:
            if line.strip():
                break
        for line in output:
            if line.strip():
                break

        readline = input.__next__
        tokens = generate_tokens(readline)
        result = untokenize(tokens)

        while 1:
            a, b = line, result[:len(line)]
            a = a.rstrip()
            b = b.rstrip()

# Generated at 2022-06-23 16:00:28.120592
# Unit test for function detect_encoding
def test_detect_encoding():
    try:
        from test.support import findfile, run_unittest
    except ImportError:
        return

    import codecs
    from unittest import TestCase, skipIf

    def open_with_readline(filename: str) -> Iterator[Text]:
        with open(filename, "rb") as fp:
            for line in fp:
                yield line.decode("latin-1")


# Generated at 2022-06-23 16:00:34.048204
# Unit test for function untokenize
def test_untokenize():
    # Test when untokenizing to strings
    inp = "def foo(x, y): print(x) # Comment"
    out = "def foo(x, y): print(x) # Comment"
    it = generate_tokens(iter(inp.splitlines(True)).next)
    assert out == untokenize(it)

    # Test when untokenizing to lists
    inp = "def foo(x, y): return x * y\n"
    out = "def foo(x, y): return x * y\n"
    it = generate_tokens(iter(inp.splitlines(True)).next)
    assert out == untokenize(list(it))

    # Test round-trip
    inp = "def foo(x): # comment\n\treturn x\n"
    it = generate

# Generated at 2022-06-23 16:00:38.327938
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        yield from io.BytesIO(b"\nline2").readline()

    assert detect_encoding(readline) == ("utf-8-sig", [b"\n"])



# Generated at 2022-06-23 16:00:40.295358
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert isinstance(u, Untokenizer)


# Generated at 2022-06-23 16:00:42.243569
# Unit test for constructor of class TokenError
def test_TokenError():
    """No test needed, this is just to silence pylint."""
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 16:00:51.475560
# Unit test for function generate_tokens
def test_generate_tokens():
    import types
    import token
    with open(__file__) as f:
        lst = list(tokenize(f.readline))
    assert lst[:-1] == generate_tokens(f.readline), lst[:-1]
    assert type(generate_tokens(f.readline)) == types.GeneratorType
    with open(__file__) as f:
        lst = []
        gt = generate_tokens(f.readline)
        for x in gt:
            lst.append(x)
        assert lst[:-1] == tokenize(f.readline), lst[:-1]
    with open(__file__) as f:
        s = f.read()
        f.seek(0)
        assert list(tokenize(s)) == generate

# Generated at 2022-06-23 16:00:54.220816
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 16:01:06.390402
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.tests import support

    with support.captured_stdout() as stdout:
        tokenize_loop(io.StringIO("a = 1 + 1\n").readline, printtoken)

    out = stdout.getvalue()
    tokens = out.split("\n")

# Generated at 2022-06-23 16:01:11.674724
# Unit test for function tokenize
def test_tokenize():
    import sys

    def readline():
        return sys.stdin.readline()


# Generated at 2022-06-23 16:01:13.823230
# Unit test for function group
def test_group():
    assert group(*["1", "2", "3"]) == "(1|2|3)"



# Generated at 2022-06-23 16:01:16.913710
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("test")
    except TokenError as e:
        assert str(e) == "test"
        assert e.args == ("test",)
