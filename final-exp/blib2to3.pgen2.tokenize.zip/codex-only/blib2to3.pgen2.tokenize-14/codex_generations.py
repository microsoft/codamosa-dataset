

# Generated at 2022-06-23 15:51:22.578843
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize

    # add EOF marker for test purposes
    # will raise StopTokenizing when EOF marker is read
    def test_readline():
        f = io.StringIO(
            """abc 'def' "ghi" \'\'\'jkl # mno pqr''' \\\n  stu vwx
                  # yz
            """
        )
        # NOTE: since Python 2.4, we cannot test for a specific EOF token
        # as the exact type and value have changed several times
        for line in f:
            yield line
        yield ""

    tokens = _tokenize.generate_tokens(test_readline)
    assert tokens is not None

# Generated at 2022-06-23 15:51:29.784296
# Unit test for function group
def test_group():
    assert group(*["x", "y"]) == "(x|y)"
    assert group(*["x y"]) == "(x y)"
    assert group(*["x\\ y"]) == "(x\\ y)"


# These are just character classes, but with more readable names.
Whitespace = "[ \\f\\t]*"
Comment = "#[^\\r\\n]*"
Ignore = Whitespace + "|" + Comment
Name = "[a-zA-Z_]\\w*"

Hexnumber = "0[xX](?:_?[0-9a-fA-F])+"
Binnumber = "0[bB](?:_?[01])+"
Octnumber = "0[oO](?:_?[0-7])+"

# Generated at 2022-06-23 15:51:32.728389
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    x = StopTokenizing()



# Generated at 2022-06-23 15:51:37.023676
# Unit test for function untokenize

# Generated at 2022-06-23 15:51:40.311128
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    toktypes = token.tok_name
    ut = Untokenizer()
    ut.compat((NAME, "for"), ((NAME, "a"), (NAME, "in"), (NAME, "b")))
# End unit test



# Generated at 2022-06-23 15:51:47.637771
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 5
    u.prev_col = 2
    def tokens_join(tokens):
        return "".join(tokens)
    assert tokens_join(u.tokens) == ""
    u.add_whitespace((5, 4))
    assert tokens_join(u.tokens) == "  "
    u.add_whitespace((10, 0))
    assert tokens_join(u.tokens) == "  \n\n\n\n\n"



# Generated at 2022-06-23 15:51:50.933355
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    result = u.untokenize([(3, "line_one "), (4, "line_two"), (5, "line_three")])
    assert result == "line_one line_two line_three", "result was %s" % repr(result)



# Generated at 2022-06-23 15:51:52.956610
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"


# Generated at 2022-06-23 15:51:57.004046
# Unit test for function tokenize_loop
def test_tokenize_loop():
    tokenize_loop(iter(["while 1: #spam\n  pass"]).__next__, printtoken)
    # $Id: tokenize_tests.py 30268 2004-10-12 07:14:25Z tim_one $
    # XXX Test this
# end unit test for function tokenize_loop



# Generated at 2022-06-23 15:52:09.534269
# Unit test for function untokenize
def test_untokenize():

    import io
    import token
    import tokenize
    import tokenize

    # Some of the tests below may trigger deprecation warnings
    # in the tokenize module.  We silence those warnings
    # to avoid spurious test failures on deprecation.
    def silence_tokenize_deprecation_warnings(testfunc):
        def wrapper(*args, **kw):
            with warnings.catch_warnings():
                warnings.simplefilter('ignore', DeprecationWarning)
                return testfunc(*args, **kw)
        wrapper.__name__ = testfunc.__name__
        return wrapper

    @silence_tokenize_deprecation_warnings
    def roundtrip(input):
        s = io.StringIO(input)
        t1 = tokenize.generate_tokens(s.readline)
        output = untoken

# Generated at 2022-06-23 15:52:21.365114
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-23 15:52:25.891206
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    u.tokens = []
    u.prev_row = 1
    u.prev_col = 0
    r = u.untokenize(((1, 'a'), (1, 'b'), (0, 'c'), (3, 'd')))
    expected = 'abcd'
    assert r == expected


# Generated at 2022-06-23 15:52:28.019276
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    raises(TypeError, StopTokenizing)
    raises(TypeError, StopTokenizing, 1)
    raises(TypeError, StopTokenizing, "hello", "world", 42)



# Generated at 2022-06-23 15:52:29.688062
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    test = StopTokenizing()



# Generated at 2022-06-23 15:52:32.690301
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.tokens = []
    ut.compat((0, ""), [(0, "")])



# Generated at 2022-06-23 15:52:35.307433
# Unit test for function printtoken
def test_printtoken():
    printtoken(type, token, (srow, scol), (erow, ecol), line)
    


# Generated at 2022-06-23 15:52:40.154901
# Unit test for function tokenize_loop
def test_tokenize_loop():  # Generates no output
    tokenized = []
    tokenize_loop(lambda: "print 123", tokenized.append)
    assert tokenized[0][0] == token.NAME
    assert tokenized[1][0] == token.NUMBER
    assert tokenized[2][0] == token.ENDMARKER



# Generated at 2022-06-23 15:52:50.276402
# Unit test for function maybe
def test_maybe():
    assert maybe("ab", "cd") == "(ab|cd)?", maybe("ab", "cd")
# End unit tests for function maybe

# Tail end of 'stringprefix' EBNF.
# Note: the first alternative is intentionally not grouped so that the
# match can only succeed if all the string prefix alternatives have failed.

# Generated at 2022-06-23 15:52:54.282271
# Unit test for function printtoken
def test_printtoken():
    import io
    s = "def f():\n  return 'abc'"
    g = tokenize(io.BytesIO(s.encode('utf-8')).readline)  # convert string to input stream
    for t in g:
        printtoken(*t)
# End of unit test for function printtoken


# Generated at 2022-06-23 15:53:06.491850
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # To really test this, we have to execute a program in a virtual file
    # system that captures semantically significant whitespace.
    import unittest
    from test import support

    class WhitespaceTest(unittest.TestCase):

        def setUp(self):
            self.readline = support.findfile("tokenize_tests.txt").readline

        def test_spaces(self):
            # Whitespace should be significant between the following tokens
            # because they could have different meanings if the whitespace
            # was dropped.
            tokens = "def f (x):".split()

            untok = Untokenizer()
            stream = generate_tokens(self.readline)
            self.assertEqual(untok.untokenize(stream), " ".join(tokens))

    unittest.main()



# Generated at 2022-06-23 15:53:11.036011
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    readline = StringIO('for i in range(10):\n print(i)\n').readline
    tokeneater = (lambda type, token, start, end, line: print(token))
    tokenize_loop(readline, tokeneater)


# Generated at 2022-06-23 15:53:14.706770
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"
    assert any("") == "()*"
    assert any("a") == "(a)*"
    assert any("abc", "") == "(abc|)*"
# End unit test


# Generated at 2022-06-23 15:53:18.425134
# Unit test for function group
def test_group():
    assert group("", "") == ""
    assert group("a") == "a"
    assert group("ab") == "ab"
    assert group("a", "bc") == "(a|bc)"
    assert group("a|b") == "a|b"
    assert group("a", "|", "b") == "(a|\\||b)"



# Generated at 2022-06-23 15:53:20.904364
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    assert u.prev_row == 1
    assert u.prev_col == 0



# Generated at 2022-06-23 15:53:23.049388
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    else:
        assert 0, "Did not trigger StopTokenizing exception"



# Generated at 2022-06-23 15:53:31.812925
# Unit test for function any
def test_any():
    return any(r'\s*\\\n', r'\s*\\\r\n', r'\s*\\\r', r'\s*\\\u\S{4}', r'\s*\\\U\S{8}', r'\s*\\\N\{[A-Za-z0-9 ]+\}', r'\s*#.*', r'\s+', r'\S+')



# Generated at 2022-06-23 15:53:35.684352
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    assert untok
    untok.prev_row = 2
    untok.prev_col = 3
    untok.tokens = ["abc", "def"]
    assert untok.tokens == ["abc", "def"]



# Generated at 2022-06-23 15:53:36.962284
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()



# Generated at 2022-06-23 15:53:38.440264
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"



# Generated at 2022-06-23 15:53:41.561070
# Unit test for function group
def test_group():
    assert group("a", "b") == r"(a|b)"
    assert group("abc") == r"(abc)"
    assert group("(", r"\(") == r"(\(|\\\()"



# Generated at 2022-06-23 15:53:44.052222
# Unit test for function group
def test_group():
    r = group(r"[0-9]", r"[a-z]")
    assert r == r"([0-9]|[a-z])"


# Generated at 2022-06-23 15:53:47.111441
# Unit test for function generate_tokens
def test_generate_tokens():
    s = "def test(a=5):\n    print(a)"
    stream = iter(s.splitlines(True))
    tokens = generate_tokens(stream.__next__)
    print(tokens)
    print(list(tokens))


# Generated at 2022-06-23 15:53:52.973981
# Unit test for function tokenize
def test_tokenize():
    import io
    import token

    data = "for i in range(10): print(i)"
    with io.StringIO(data) as f:
        tokeneater = printtoken
        for token in generate_tokens(f.readline):
            tokeneater(*token)
        print(token.tok_name[token.ENCODING])



# Generated at 2022-06-23 15:53:56.867060
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("Sample")
    except TokenError as e:
        assert str(e) == "Sample"



# Generated at 2022-06-23 15:54:04.383768
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"
    assert group(["a", "b"], ["c", "d"]) == "(a|b|c|d)"
    assert group("a", ["b", "c"], "d") == "(a|b|c|d)"
    assert group("(", ")") == "((|))"
    assert group("a(b|c)", "d") == "(a(b|c)|d)"
    assert group(r"\s+") == "(\\s+)"


# Generated at 2022-06-23 15:54:13.817341
# Unit test for function tokenize
def test_tokenize():
    import io
    from tokenize import tokenize

    s = io.StringIO("def x(): pass\n")
    tokens = []
    for tok in tokenize(s.readline):
        tokens.append(tok)

# Generated at 2022-06-23 15:54:27.282337
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import unittest

    class TestTokenize(unittest.TestCase):
        def test_tokenize_empty(self):
            stream = io.StringIO("")
            t = list(tokenize(stream.readline))  # type: ignore
            self.assertEqual(t, [])

        def test_tokenize_simple(self):
            stream = io.StringIO("for i in range(10):\n    print i")
            t = list(tokenize(stream.readline))  # type: ignore

# Generated at 2022-06-23 15:54:28.800026
# Unit test for function maybe
def test_maybe(): assert maybe("a", "b") == "(a|b)?"



# Generated at 2022-06-23 15:54:40.003046
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import sys

    def getline(string):
        for c in string:
            yield c

    def normalize(string):
        string = string.replace('\r\n', '\n')
        string = string.replace('\r', '\n')
        return string

    data = io.StringIO()

# Generated at 2022-06-23 15:54:42.011750
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-23 15:54:54.831769
# Unit test for function tokenize_loop
def test_tokenize_loop():
    class Readline():
        def __init__(self, lines: Iterable[Text]) -> None:
            self.lines = lines
            self.count = 0

        def __call__(self) -> Text:
            try:
                return next(self.lines)
            except StopIteration:
                return ""

    class TokenEater():
        def __init__(self) -> None:
            self.tokens: List[Tuple] = []

        def __call__(self, *token_info) -> None:
            self.tokens.append(token_info)


# Generated at 2022-06-23 15:54:58.896473
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # This test is written according to the discussion at
    # https://bugs.python.org/issue9019#msg183928
    token_list = [
        ('ERRORTOKEN', '<string>'),
        ('NUMBER', '1'),
        ('NEWLINE', ''),
        ('NAME', 'foo'),
        ('NEWLINE', ''),
        ('NL', ''),
        ('ENDMARKER', ''),
    ]
    def tokeneater(*token_info):
        assert(token_info == token_list.pop(0))
    def readline():
        data = '<string>\n1\nfoo\n'
        return data
    tokenize_loop(readline, tokeneater)


# Generated at 2022-06-23 15:55:03.803398
# Unit test for function printtoken
def test_printtoken():
  type = 1
  token = 'abc'
  (srow, scol) = (2, 3)
  (erow, ecol) = (4, 5)
  line = 'line'
  printtoken(type, token, (srow, scol), (erow, ecol), line)



# Generated at 2022-06-23 15:55:04.799498
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(?:a|b)?"


# Generated at 2022-06-23 15:55:16.039550
# Unit test for function generate_tokens
def test_generate_tokens():
    def generate_tokens_check(readline):
        try:
            for token in generate_tokens(readline):
                pass
            for token in generate_tokens(readline): # verify it can be called twice
                pass
        except IndentationError:
            pass


# Generated at 2022-06-23 15:55:22.607161
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

    from .tokenize import generate_tokens, untokenize

    def check_untok(s, expected):
        untok = untokenize(list(generate_tokens(StringIO(s).readline)))
        assert untok == expected, (untok, expected)

    check_untok("", "")
    check_untok("foo", "foo ")
    check_untok("foo = 124", "foo = 124 ")
    check_untok("foo = 124\nbar = 'hello'\n", "foo = 124\nbar = 'hello'\n")
    check_untok(
        "foo = 'hello'\nbar = 'hello'\n", "foo = 'hello'\nbar = 'hello'\n"
    )

# Generated at 2022-06-23 15:55:29.351815
# Unit test for function maybe
def test_maybe():
    # None is fine
    assert maybe("foo") == "(foo)?"

    # String is fine
    assert maybe("foo") == "(foo)?"

    # Single value of list is fine
    assert maybe("foo", "bar", "baz") == "(foo|bar|baz)?"

    # Multiple values in list is fine
    assert maybe("foo", "bar", "baz") == "(foo|bar|baz)?"

    # At least one value in list is required
    try:
        maybe()
    except TypeError:
        pass
    else:
        raise Exception("Should raise TypeError")



# Generated at 2022-06-23 15:55:39.061918
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    if False:
        def f():
            x = 3

        def g():
            x = 4
    else:
        def f():
            y = 5

        def g():
            y = 6
            z = 7
    u.compat(
        (
            NAME,
            "if",
        ),
        tokenize("if False:\n    def f():\n        x = 3\n    def g():\n        x = 4\nelse:\n    def f():\n        y = 5\n    def g():\n        y = 6\n        z = 7"),
    )

# Generated at 2022-06-23 15:55:40.708700
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"


# Generated at 2022-06-23 15:55:47.898603
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from unittest import TestCase, main

    class Tests(TestCase):
        def check(self, input, output):
            self.assertEqual(Untokenizer().untokenize(input), output)

        def test_empty(self):
            self.check([], "")

        def test_end_of_line(self):
            self.check([(NAME, "spam"), (NEWLINE, "\n")], "spam\n")
            self.check([(NAME, "spam"), (NEWLINE, "\r\n")], "spam\r\n")
            self.check([(NAME, "spam"), (NEWLINE, "\r")], "spam\r")


# Generated at 2022-06-23 15:55:50.043068
# Unit test for constructor of class TokenError
def test_TokenError():
    t = TokenError()
    assert isinstance(t, TokenError)
    assert isinstance(t, Exception)



# Generated at 2022-06-23 15:55:58.121202
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import generate_tokens
    # Sample python program
    prog = r"""# -*- coding: utf-8 -*-async def coro():
    await foo
    foo = "bar"
    """
    print("Code:")
    print(prog)
    print()
    print()
    print("Tokens:")
    ls = list(generate_tokens(prog.splitlines))
    for token in ls:
        print(token)
test_generate_tokens()


# Generated at 2022-06-23 15:56:02.451875
# Unit test for function maybe
def test_maybe():
    assert cast(bool, maybe("foo"))
    assert cast(bool, maybe("foo", "bar"))
    assert cast(bool, maybe("foo", "bar", "baz"))
    assert cast(bool, maybe("foo", "bar", "baz", "quux"))
# End Unit test



# Generated at 2022-06-23 15:56:03.977730
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError

    except TokenError:
        pass



# Generated at 2022-06-23 15:56:14.026102
# Unit test for function printtoken
def test_printtoken():
    from unittest import TestCase
    import io

    class Test(TestCase):
        def test_printtoken(self):
            self.maxDiff = None

            def tokenize_stream(stream: Iterable[Text], func=printtoken, **kwargs) -> None:
                try:
                    tokens = generate_tokens(stream.__next__, **kwargs)
                except StopIteration:
                    tokens = []
                for token in tokens:
                    func(*token)

            def tokenize_stream_to_list(stream: Iterable[Text], **kwargs) -> List[Tuple]:
                result = []
                tokenize_stream(stream, result.append, **kwargs)
                return result

            # ATOM, SDM: 'test_printtoken', DATE: 'Jul 7, 2009'

# Generated at 2022-06-23 15:56:25.371860
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 3
    untok.prev_col = 3
    untok.add_whitespace((4, 0))  # does nothing
    untok.add_whitespace((4, 1))
    untok.add_whitespace((4, 2))
    untok.add_whitespace((4, 3))  # does nothing
    untok.add_whitespace((3, 3))  # does nothing
    untok.add_whitespace((3, 4))
    untok.add_whitespace((3, 5))
    untok.add_whitespace((2, 0))  # should raise AssertionError



# Generated at 2022-06-23 15:56:33.956324
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 0
    u.prev_col = 1
    u.tokens = ["test"]
    u.add_whitespace((0, 0))
    assert u.tokens == ["test", "\n"]

    u.tokens = ["test"]
    u.add_whitespace((0, 2))
    assert u.tokens == ["test", " "]

    u.tokens = ["test"]
    u.add_whitespace((0, 3))
    assert u.tokens == ["test", "  "]

    u.tokens = ["test"]
    u.add_whitespace((1, 3))
    assert u.tokens == ["test", "\n   "]



# Generated at 2022-06-23 15:56:38.136317
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    t = Untokenizer()
    o = [ (token.INDENT, "a"), (token.INDENT, "b")]
    s = t.compat((token.OP, "*"), o)
    assert s == None



# Generated at 2022-06-23 15:56:39.538930
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError()



# Generated at 2022-06-23 15:56:51.340849
# Unit test for function untokenize
def test_untokenize():
    # Test round trips
    import io
    import tokenize
    with open(tokenize.__file__) as fp:
        f = io.BytesIO(fp.read())
    try:
        f.seek(0)
        g = tokenize.generate_tokens(f.readline)
        newcode = untokenize(g)
        readline = iter(newcode.splitlines(1)).__next__
        g = tokenize.generate_tokens(readline)
        for tok in g:
            if tok[0] == tokenize.ENCODING:
                break
        for tok in g:
            pass
    except tokenize.TokenError as e:
        # print e.args
        assert e.args[0].startswith("EOF in multi-line statement")
   

# Generated at 2022-06-23 15:57:00.187793
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    # test empty input
    input = StringIO()
    tokenize_string(input)

    # input with multiple tokens on one line
    input = StringIO("a b c")
    tokens = list(tokenize_string(input))
    assert len(tokens) == 3
    assert tokens[0].type == NAME
    assert tokens[0].string == "a"
    assert tokens[1].type == NAME
    assert tokens[1].string == "b"
    assert tokens[2].type == NAME
    assert tokens[2].string == "c"

    # input with multiple lines
    input = StringIO("a b\nc d e")
    tokens = list(tokenize_string(input))
    assert len(tokens) == 5
    assert tokens[0].type == NAME

# Generated at 2022-06-23 15:57:01.769809
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 15:57:10.240678
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens
    from token import tok_name
    result = []
    test_string = StringIO("import os.path\n")
    for token in generate_tokens(test_string.readline):
        result.append(token)
    assert result[0] == (1, 'import', (1, 0), (1, 6), 'import os.path\n')
    assert tok_name[result[0][0]] == 'NAME'
    assert result[1] == (1, 'os.path', (1, 7), (1, 14), 'import os.path\n')
    assert tok_name[result[1][0]] == 'NAME'

# Generated at 2022-06-23 15:57:18.053207
# Unit test for function maybe
def test_maybe():
    s = r'a(\d\d|[a-z]+)'
    m = re.match(s, 'a123')
    assert m
    m = re.match(s, 'abcd')
    assert m
    m = re.match(s, 'a')
    assert not m

    p = re.compile(maybe(r'\d\d') + '\w+')

    m = p.match('abc')
    assert m

    m = p.match('12abc')
    assert m

    m = p.match('')
    assert not m

# For better performance and nicer source code, the main tokenizing loop
# is coded as a giant state machine.  It is divided up into a series of
# functions on the "tokeneater" object.  Each of these functions advances
# the text a

# Generated at 2022-06-23 15:57:29.237223
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from test.test_tokenize import (
        untokenize_helper,
        tokenize_print,
        untokenize,
        tokenize_print,
        detect_encoding,
        readline,
    )
    from test.input_examples import (
        be_exp_examples,
        fp_exp_examples,
        leading_tabs_examples,
        te_exp_examples
    )

    errors_be = 0
    errors_te = 0
    errors_fp = 0
    errors_lt = 0

    # Test bad encoding tokens
    for example in be_exp_examples:
        text, expected = example.text, example.expected
        got = list(tokenize_print(StringIO(text).readline))
        error = untokenize_

# Generated at 2022-06-23 15:57:37.309203
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pygram import python_grammar
    from blib2to3.pgen2.parse import ParseError

    text = "abc [1, 2, 3]"
    untok = Untokenizer()
    try:
        tokens = list(generate_tokens(StringIO(text).readline))
    except ParseError as e:
        print("ParseError:", e.msg)
    else:
        result = untok.compat(tokens[0], tokens[1:])
        print("result: %s" % repr(result))


# Generated at 2022-06-23 15:57:39.214304
# Unit test for function printtoken
def test_printtoken():
    assert printtoken(NUMBER, '0', (0, 0), (0, 1), "") == None


# Generated at 2022-06-23 15:57:42.053768
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("foo", "bar", "baz")
    except TokenError as exc:
        assert exc.args == ("foo", "bar", "baz"), exc.args



# Generated at 2022-06-23 15:57:51.022836
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize

    def test(input: Text, expected: Text) -> None:
        f = io.StringIO(input)
        tok = tokenize.generate_tokens(f.readline)
        untok = Untokenizer()
        output = untok.compat(next(tok), tok)
        assert output == expected, f"{output!r} should be {expected!r}"

    test("class C: pass\n", "class C:")
    test("class C(object): pass\n", "class C(object):")
    test("if foo == 'foo':\n    pass\n", "if foo == 'foo':")
    test("if foo == '''foo''':\n    pass\n", "if foo == '''foo''':")

# Generated at 2022-06-23 15:58:01.189820
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest

    class TestCase(unittest.TestCase):
        def _check_cookie(self, cookie, expected_encoding):
            f = io.BytesIO(cookie.encode("utf8"))
            encoding, lines = detect_encoding(f.readline)
            self.assertEqual(encoding, expected_encoding)

        def test_detect_encoding(self):
            self._check_cookie("# coding=utf-8", "utf-8")
            self._check_cookie("# coding=latin-1", "iso-8859-1")
            self._check_cookie("#!/usr/bin/python\n# coding=latin-1", "iso-8859-1")
            # Invalid encoding

# Generated at 2022-06-23 15:58:06.347231
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():

    class Fake:
        def __init__(self):
            self._tokens = []

    ut = Untokenizer()
    ut.tokens = Fake()

    ut.prev_row = 5
    ut.prev_col = 0

    assert ut.tokens._tokens == []

    ut.add_whitespace((6, 0))
    assert ut.tokens._tokens == ["\n\n"]



# Generated at 2022-06-23 15:58:15.320514
# Unit test for function tokenize
def test_tokenize():
    for i in range(len(test_cases)):
        readline = iter(test_cases[i].splitlines(True)).__next__
        result = [t for t in iter(generate_tokens(readline))]
        assert result == expected_results[i], "test %d failed" % i
        # print("test %d ok" % i)
    readline = iter("[0] for j in range(10)").__next__
    assert [t for t in iter(generate_tokens(readline))] == expected_results[-1]
    print("test ok")



# Generated at 2022-06-23 15:58:20.556139
# Unit test for function group
def test_group():
    def test(pat):
        res = re.compile(pat)
        m = res.match("")
        assert not m, "not match empty string"
    test(group("a", "b"))
    test(group("a", "bc", "de"))
    test(group(group("a", "bc"), "de"))


# Generated at 2022-06-23 15:58:22.533821
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    else:
        print("Could not raise StopTokenizing")


# Convert possible raw bytes in the JavaScript source to Unicode
# using UTF-8

# Generated at 2022-06-23 15:58:31.349535
# Unit test for function group
def test_group():
    p = group("a", "b", "c")
    #
    m = re.compile(p).match("a")
    assert m.group() == "a"
    #
    m = re.compile(p).match("b")
    assert m.group() == "b"
    #
    m = re.compile(p).match("c")
    assert m.group() == "c"
    #
    m = re.compile(p).match("d")
    assert m is None
del test_group

any = "[\r\n\t !#%&'()*+,-./:;<=>?@[\\]^_`{|}~]"

# Generated at 2022-06-23 15:58:33.587416
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing as exc:
        pass

# Mapping between token types and printable names.

# Generated at 2022-06-23 15:58:42.758175
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    # Make Untokenizer.tokens be empty
    # (Test for empty line)
    untokenizer = Untokenizer()
    # Make iterable be empty
    # (Test for empty line)
    iterable: Iterable[TokenInfo] = []
    untokenizer.compat(iterable)
    assert untokenizer.tokens == []

    # Make Untokenizer.tokens be empty
    # (Test for non-empty line)
    untokenizer = Untokenizer()
    # Make iterable be non-empty
    # (Test for non-empty line)

# Generated at 2022-06-23 15:58:43.894537
# Unit test for function maybe
def test_maybe():
    m = maybe("a", "b")
    assert m == "(a|b)?"



# Generated at 2022-06-23 15:58:46.144555
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer = Untokenizer()
    untokenizer.compat((1,"a"))


# Generated at 2022-06-23 15:58:56.143957
# Unit test for function detect_encoding

# Generated at 2022-06-23 15:58:58.527878
# Unit test for function maybe
def test_maybe():
    assert "".join(maybe("(a)","(b)")) == "(a|b)?"



# Generated at 2022-06-23 15:59:06.814288
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

    def listtokens(reader):
        for t in generate_tokens(reader.readline):
            print(t)
            yield t

    text = """\
x = "foo" + "bar"
x
"""
    reader = StringIO(text)
    tokens = list(listtokens(reader))
    untok = Untokenizer()
    res = untok.compat(tokens[0], tokens)
    assert res is None
    assert untok.tokens == ["x", " ", "=", " ", '"', "foo", '"', " ", "+", " ", '"', "bar", '"']



# Generated at 2022-06-23 15:59:09.511797
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        pass



# Generated at 2022-06-23 15:59:12.230712
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
    assert any("a|b") == "(a|b)*"



# Generated at 2022-06-23 15:59:21.846837
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    #pylint: disable=unused-variable
    untok = Untokenizer()
    untok.prev_row = 2
    #print("Hello")
    untok.add_whitespace((1,0))
    #print("Hello")
    untok.add_whitespace((2,3))
    #print("Hello")
    untok.add_whitespace((1,8))
    #print("Hello")
    untok.add_whitespace((3,0))
    #print("Hello")
    untok.add_whitespace((2,3))
    #print("Hello")
    untok.add_whitespace((2,8))
    #print("Hello")
    return



# Generated at 2022-06-23 15:59:32.925627
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    unt = Untokenizer()
    unt.add_whitespace((0, 0))
    unt.tokens.append("foo")
    assert unt.tokens == ["foo"]
    unt.tokens.append("bar")
    assert unt.tokens == ["foo", "bar"]
    unt.add_whitespace((0, 3))
    assert unt.tokens == ["foo", "bar", "   "]
    assert unt.untokenize([]) == "foobar   "
    unt = Untokenizer()
    assert unt.untokenize([(0, "foo"), (1, " "), (0, "bar")]) == "foo bar"

test_Untokenizer()
del test_Untokenizer



# Generated at 2022-06-23 15:59:35.570078
# Unit test for function maybe
def test_maybe():
    assert maybe('"') == '("?)'
    assert maybe('"', "a") == '("|a)?', maybe('"', "a")



# Generated at 2022-06-23 15:59:44.989427
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        return None
        yield

    def read_ascii(*args, **kwargs):
        lines = ["# -*- coding: utf-8 -*-\n", "spam\n"]
        for line in lines:
            yield line.encode("ascii")

    def read_utf8(*args, **kwargs):
        lines = ["# -*- coding: latin-1 -*-\n", "spam\n"]
        for line in lines:
            yield line.encode("utf-8")

    assert detect_encoding(readline) == ("utf-8", [])
    assert detect_encoding(read_ascii) == ("utf-8", [b"# -*- coding: utf-8 -*-\n"])

# Generated at 2022-06-23 15:59:55.345552
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 2))
    untok.add_whitespace((1, 4))
    assert untok.tokens == ["  ", " "]
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 2))
    untok.add_whitespace((1, 4))
    assert untok.tokens == ["  ", " ", "  ", " "]
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1, 2))
    untok.add_whitespace((1, 4))
    assert unt

# Generated at 2022-06-23 16:00:06.390262
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    assert u.tokens == []
    u.add_whitespace((1, 0))
    u.add_whitespace((1, 2))
    assert u.tokens == ["  "]
    u.add_whitespace((2, 0))
    assert u.tokens == ["  ", ""]
    u.add_whitespace((2, 4))
    assert u.tokens == ["  ", "    "]
    u.add_whitespace((2, 4))
    assert u.tokens == ["  ", "    "]
    u.add_whitespace((1, 10))
    assert u.tokens == ["  ", "    ", "          "]

# Utility functions

# Generated at 2022-06-23 16:00:13.077752
# Unit test for function any
def test_any():
    e = re.compile(any("a", "b"))
    assert e.match("") is not None
    assert e.match("a") is not None
    assert e.match("b") is not None
    assert e.match("c") is None
    assert e.match("aab") is not None
    assert e.match("aba") is not None
    assert e.match("bba") is not None



# Generated at 2022-06-23 16:00:17.552588
# Unit test for function group
def test_group():
    assert group("x") == "(x)"
    assert group("x", "y") == "(x|y)"
    assert group("x", "y", "z") == "(x|y|z)"
    assert group("x", "y", "z", "t") == "(x|y|z|t)"


# Generated at 2022-06-23 16:00:19.709638
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("TokenError string")
    except TokenError as e:
        pass



# Generated at 2022-06-23 16:00:29.470707
# Unit test for function maybe
def test_maybe():
    return 'hello'

# Forward declarations for regex patterns.
whitespace_group = r"[ \f\t]*"
comment_group = r"(\#[^\r\n]*(\r|\n|\r\n))+"
name_group = r"[a-zA-Z_][a-zA-Z0-9_]*"
hex_group = r"0[xX][0-9a-fA-F]+"
bin_group = r"0[bB][01]+"
oct_group = r"0[oO][0-7]+"
dec_group = r"(0+(?![0-9a-fA-F]))|([1-9][0-9]*)"

# Generated at 2022-06-23 16:00:37.948725
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    input = [
        (NAME, "def"),
        (NAME, "f"),
        (OP, "("),
        (OP, ")"),
        (OP, ":"),
        (NEWLINE, "\n"),
        (INDENT, "  "),
        (NAME, "return"),
        (NAME, "None"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
    ]
    unt = Untokenizer()
    unt.compat((NAME, "def"), iter(input))
    output = unt.tokens
    assert output == ["def f():\n  return None\n"]


untokenize = Untokenizer().untokenize



# Generated at 2022-06-23 16:00:40.444381
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-23 16:00:49.923318
# Unit test for function detect_encoding
def test_detect_encoding():
    fail_under("2.9")
    import os
    import sys

    def readline():
        if os.path.exists("/usr/bin/python3.3"):
            yield b'#!/usr/bin/python3.3\n'
            yield b'# coding: latin-9\n'
        else:
            yield b'#!/usr/bin/python3.1\n'
            yield b'# coding: latin-10\n'

    def readline_bad():
        yield b'#!/usr/bin/python3.1\n'
        yield b'# coding: latin-100\n'

    assert detect_encoding(readline()) == ("latin-9", [b'#!/usr/bin/python3.3\n'])

# Generated at 2022-06-23 16:00:54.725773
# Unit test for function group
def test_group():
    assert re.match(group(r'a', r'b', r'c', r'd', r'e'), 'b')
    assert re.match(group(r'ab?', r'cd*', r'ef*', r'gh*'), 'ef')


# Generated at 2022-06-23 16:01:06.826478
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    s = untok.untokenize([(1, ""), (3, ""), (1, ""), (3, "")])
    assert s == "", repr(s)
    s = untok.untokenize([(2, "spam"), (1, ""), (2, "spam")])
    assert s == "spam spam"
    s = untok.untokenize([(1, ""), (2, "spam"), (1, ""), (2, "spam")])
    assert s == " spam spam"
    s = untok.untokenize([(3, ""), (2, "spam"), (1, ""), (2, "spam")])
    assert s == "spam spam"

# Generated at 2022-06-23 16:01:19.209423
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    s = StringIO("a = 5 # comment\nb=10\n")
    tokens = [i for i in generate_tokens(s.readline)]
    assert tokens[0][0] == token.NAME
    assert tokens[0][1] == "a"
    assert tokens[1][0] == token.OP
    assert tokens[1][1] == "="
    assert tokens[2][0] == token.NUMBER
    assert tokens[2][1] == "5"
    assert tokens[3][0] == token.COMMENT
    assert tokens[3][1] == "# comment"
    assert tokens[4][0] == token.NL
    assert tokens[4][1] == "\n"
    assert tokens[5][0] == token.NAME