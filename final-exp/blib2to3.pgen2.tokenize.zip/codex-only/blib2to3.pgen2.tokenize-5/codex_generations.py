

# Generated at 2022-06-23 15:51:28.901810
# Unit test for function untokenize
def test_untokenize():
    import io
    import token

    def compare(input, output):
        result = []
        g = tokenize(io.StringIO(input).readline)
        for toknum, tokval, _, _, _ in g:
            result.append((toknum, tokval))
        output2 = untokenize(result)
        print(repr(output2))
        assert output2 == output

    compare("def f(): pass\n", "def f():\n    pass\n")
    compare("if 1: #abc\n  pass\n", "if 1:  # abc\n    pass\n")
    compare("def f():\n  pass\n", "def f():\n    pass\n")

# Generated at 2022-06-23 15:51:38.859842
# Unit test for function detect_encoding
def test_detect_encoding():
    readline = iter([bytes([239, 187, 191]), b"# coding: latin-1\n"]).__next__
    assert detect_encoding(readline) == ("utf-8-sig", [b"# coding: latin-1\n"])
    readline = iter([bytes([239, 187, 191]), b"# coding=ascii\n"]).__next__
    assert detect_encoding(readline) == ("utf-8-sig", [b"# coding=ascii\n"])
    readline = iter([b"# coding=ascii\n", bytes([239, 187, 191])]).__next__
    assert detect_encoding(readline) == ("ascii", [b"# coding=ascii\n"])

# Generated at 2022-06-23 15:51:48.593000
# Unit test for function tokenize
def test_tokenize():

    # Keyword arguments
    # The tokenize function accepts two arguments, the line of code to tokenize
    # and the token to look for.

    # Tests if tokenize will return an empty list if there are no tokens
    # present in the given code.
    def empty_test():
        assert [] == tokenize("")

    # Tests that tokenize will return an empty list if there is no specified
    # token in a given line of code.
    def empty_test_with_token():
        assert [] == tokenize("", token.NUMBER)

    # Tests that tokenize will return a tuple of length 3 if a given token is
    # present in the code.
    def token_found_test():
        assert [("token", 1, 2)] == tokenize("1+1", token.NUMBER)

    # Tests that tokenize will return a tuple

# Generated at 2022-06-23 15:51:53.707496
# Unit test for function printtoken
def test_printtoken():
    tok = printtoken
    tok(NAME, "abc", (3, 4), (3, 6), "abc = 1")
    tok(NEWLINE, "\n", (3, 6), (3, 6), "abc = 1")
    tok(NUMBER, "1", (3, 7), (3, 7), "abc = 1")



# Generated at 2022-06-23 15:52:05.220422
# Unit test for function untokenize
def test_untokenize():
    input = (
        (NAME, 'if'),
        (NAME, 'x'),
        (OP, '<'),
        (NUMBER, '0'),
        (OP, '<'),
        (NAME, 'y'),
        (NAME, 'and'),
        (NAME, 'z'),
        (NAME, 'or'),
        (NAME, 'not'),
        (NAME, 'a'),
        (OP, '<'),
        (NAME, 'b'),
        (NAME, 'not'),
        (NAME, 'c'),
        (OP, 'in'),
        (NAME, 'd'),
        (NAME, 'or'),
        (NAME, 'not'),
        (NAME, 'a'),
    )
    output = 'if x<0<y and z or not a<b not c in d or not a'
    result = unt

# Generated at 2022-06-23 15:52:08.284793
# Unit test for function tokenize
def test_tokenize():
    import StringIO

    s = StringIO.StringIO("  for x in  \n  range(1, 10)  \n\n")
    for t in tokenize(s.readline) : pass



# Generated at 2022-06-23 15:52:20.483544
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1"
        yield b"#"
        yield b"# some more"

    r = list(readline())

    # The tokenize module is always used as part of the interpreter, so
    # exit prominently if it doesn't work as expected.
    try:
        encoding, lines = detect_encoding(r.pop)
    except SyntaxError as e:
        assert 0, "Could not detect encoding: " + str(e)
    else:
        assert encoding == "iso-8859-1", "Wrong encoding detected"
        assert lines == [b"# coding: latin-1", b"#", b"# some more"]
        assert r == []



# Generated at 2022-06-23 15:52:33.902059
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        if not lines:
            raise StopIteration
        line = lines.pop(0)
        return bytes(line, "ascii").replace(b"\n", b"")

    lines = ["# -*- coding: latin-1 -*-", "", ""]
    assert detect_encoding(readline) == ("iso-8859-1", lines)

    lines = ["", "# coding=iso-8859-1", ""]
    assert detect_encoding(readline) == ("iso-8859-1", lines)

    lines = ["\xef\xbb\xbf# -*- coding: utf-8 -*-", "", ""]
    assert detect_encoding(readline) == ("utf-8-sig", lines)


# Generated at 2022-06-23 15:52:43.626280
# Unit test for function tokenize
def test_tokenize():
    import tokenize as t
    import io

    tokgen = t.generate_tokens(io.BytesIO(
        b"def f():\n  print(1)\n"
    ).readline)
    l = list(tokgen)
    assert len(l) > 0
    print(l)
    tokgen = t.generate_tokens(io.StringIO(
        "def f():\n  print(1)\n"
    ).readline)
    l = list(tokgen)
    assert len(l) > 0
    print(l)

test_tokenize()


# Generated at 2022-06-23 15:52:53.702749
# Unit test for function detect_encoding
def test_detect_encoding():
    try:
        lookup("ascii")
    except LookupError:
        import codecs

        codecs.register(lambda encoding: codecs.lookup("utf-8") if encoding == "ascii" else None)

    def readline(lines):
        def rl():
            if not lines:
                raise StopIteration
            return lines.pop(0)

        return rl


# Generated at 2022-06-23 15:53:06.441089
# Unit test for function maybe
def test_maybe():
    m = re.match(maybe(r"[a-z]"), "abc")
    assert m.group() == "abc"

    m = re.match(maybe(r"[a-z]"), "1abc")
    assert m.group() == ""

Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"[a-zA-Z_]\w*"

Binnumber = r"0[bB][01]+(?:_[01]+)*"
Hexnumber = r"0[xX][\da-fA-F]+(?:_[\da-fA-F]+)*"

# Generated at 2022-06-23 15:53:07.954270
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"
    assert group("a(b|c)+") == "a(b|c)+"



# Generated at 2022-06-23 15:53:13.780651
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass


_cols_re = re.compile(
    r"(\s*)(?:(\d+)|([^\d\n]*))(?:((?:\n|\r(?!\n)|\r\n)(?:\s*)(?:\d+|[^\d\n]*))|$)"
)
#    x-----------------------x------------------------------------------x



# Generated at 2022-06-23 15:53:16.564295
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 15:53:19.488139
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    iterable = tokenize(iter(["x=1"]).__next__)
    u.compat(next(iterable), iterable)
    assert u.tokens == ["x", " ", "=", " ", "1", " "]



# Generated at 2022-06-23 15:53:31.321374
# Unit test for function tokenize
def test_tokenize():
    # Test tokenize by feeding it the Tokens examples,
    # and comparing the output.

    import sys

    test_cases = {}

    # Read the expected results.
    f = open(__file__, "rb")
    try:
        source = f.read()
    finally:
        f.close()

    start = 0
    prefix = "Tokens"
    while 1:
        pos = source.find(prefix, start)
        if pos < 0:
            break
        start = pos + len(prefix)

        # Skip the example number.
        start = start + source.find("\n", start) + 1
        if source[start] == "\n":
            start = start + 1

        # Find the start of the next example.
        endpos = source.find(prefix, start)

# Generated at 2022-06-23 15:53:38.084845
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

    u = Untokenizer()
    output = StringIO()
    def tokeneater(toktype, tokval, _, _, _):
        if toktype in (NEWLINE, NL):
            print(file=output, end="")
        else:
            print(tokval, end="", file=output)
    test_untokenize = u.compat


# Generated at 2022-06-23 15:53:43.488785
# Unit test for function untokenize

# Generated at 2022-06-23 15:53:51.622875
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in test_case[0]:
            yield line.encode("ascii")
        yield b""


# Generated at 2022-06-23 15:53:56.427447
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # class StopTokenizing inherits from class Exception
    assert issubclass(StopTokenizing, Exception)
    # class StopTokenizing does not inherit from class TokenError
    assert not issubclass(StopTokenizing, TokenError)
    # variable x is not an instance of class StopTokenizing
    x = 1
    assert not isinstance(x, StopTokenizing)



# Generated at 2022-06-23 15:53:59.926958
# Unit test for function generate_tokens
def test_generate_tokens():
    with open("grammar.py") as f:
        for token in generate_tokens(f.readline):
            pass


if __name__ == "__main__":
    test_generate_tokens()

# Generated at 2022-06-23 15:54:03.489415
# Unit test for function any
def test_any():
    assert any("abc") == "(a|b|c)*"
    assert any("a", "b") == "(a|b)*"
    assert any("a") == "(a)*"
    assert any() == "()*"



# Generated at 2022-06-23 15:54:13.096822
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO

    f = StringIO("class A:\n  pass\n")
    for tok in generate_tokens(f.readline):
        print(tuple(tok))

    ut = Untokenizer()
    f = StringIO("class A:\n  pass\n")
    for tok in generate_tokens(f.readline):
        print(tuple(tok))
        ut.compat(tok, generate_tokens(f.readline))
    untokenized_source = ut.untokenize(generate_tokens(f.readline))
    print(untokenized_source)
    assert untokenized_source == "class A: pass\n"
    f = StringIO(untokenized_source)
    untokenized_tokens = []


# Generated at 2022-06-23 15:54:17.064632
# Unit test for function any
def test_any():
    for x in ("", "a", "b", "ab", "aaab"):
        assert x == untokenize(list(generate_tokens(StringIO(x).readline)))


# Generated at 2022-06-23 15:54:27.281536
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    t = Untokenizer()
    l = (
        (NAME, "def"),
        (INDENT, "  "),
        (NAME, "f"),
        (OP, "("),
        (OP, ")"),
        (OP, ":"),
        (NEWLINE, "\n"),
    )
    assert t.compat(l[0], l) == ["def ", "  f():"]
    assert t.tokens == ["def ", "  f():"]
    assert t.prev_row == 1
    assert t.prev_col == 6


async_generator_functions = None



# Generated at 2022-06-23 15:54:38.215575
# Unit test for function tokenize_loop
def test_tokenize_loop():
    """
    Test tokenize_loop.

    This shouldn't really be an automated test case, since it's testing the
    printtoken() method defined above.
    """
    for x in [
        "a = 1",
        "a = 1 #",
        "#",
        "#\n",
        "#\t",
        "a = 1\n",
        "a = 1 #\n",
        "a = 1 #\n #",
        'a = "foo"\n',
        "a = 'foo'\n",
        'a = """\nfoo"""\n',
        "a = '''\nfoo'''\n",
        "if 1:\n  pass\n",
        'if 1:\n  pass\nelse:\n  pass\n',
    ]:
        print("==========")


# Generated at 2022-06-23 15:54:41.736875
# Unit test for function printtoken
def test_printtoken():
    printtoken(ERRORTOKEN, "Traceback", (1, 10), (1, 10), "Traceback")
if __name__ == "__main__":
    test_printtoken()



# Generated at 2022-06-23 15:54:51.913508
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    filename = "tokenize_tests.txt"
    with open(filename, "rb") as fp:
        tokenized_lines = [
            line.decode("ascii", "backslashreplace") for line in fp.readlines()
        ]
    for line in tokenized_lines:
        if len(line) > 1:
            tokens = line.split()
            tokenized_iter = iter(tokens)
            untokenizer = Untokenizer()
            untokenized_line = untokenizer.untokenize(tokenized_iter)
            assert line.strip() == untokenized_line.strip()



# Generated at 2022-06-23 15:55:01.204295
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO

    s = r"""def square(x):
    return x * x
"""
    f = StringIO(s)
    tokens = generate_tokens(f.readline)
    untokenizer = Untokenizer()
    def undo(token):
        print(token, end=" ")
    for token in tokens:
        undo(token)
    print()
    print(untokenizer.untokenize(tokens))
    f.close()
    assert s == untokenizer.untokenize(tokens)



# Generated at 2022-06-23 15:55:10.540936
# Unit test for function generate_tokens
def test_generate_tokens():
    from types import GeneratorType
    from test.test_tokenize import tokenize_cases
    for input, want_tokens in tokenize_cases:
        # "a, b = c, d"
        got_tokens = list(generate_tokens(iter(input.splitlines(True)).__next__))
        # The first one is always a NEWLINE token, so skip it, since
        # we don't include it in the test cases.
        got_tokens = got_tokens[1:]
        if len(got_tokens) != len(want_tokens):
            message = "got wrong number of tokens; input: %r" % input
            raise AssertionError(message)

# Generated at 2022-06-23 15:55:12.128310
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", "maybe(a)"



# Generated at 2022-06-23 15:55:20.973073
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline():
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'# test\n'
        yield b'# -*- coding: iso-8859-1 -*-'

    e, ln = detect_encoding(readline)
    assert e == 'iso-8859-1'
    assert ln == [
        b'# -*- coding: latin-1 -*-\n',
        b'# test\n',
        b'# -*- coding: iso-8859-1 -*-'
    ]

    def readline():
        yield b'\xef\xbb\xbf# -*- coding: latin-1 -*-\n'
        yield b'# test\n'

# Generated at 2022-06-23 15:55:22.751819
# Unit test for function tokenize

# Generated at 2022-06-23 15:55:29.297538
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    l = unt.untokenize(
        [
            (NUMBER, "1"),
            (NAME, "print"),
            (STRING, '"hello"'),
            (OP, "("),
            (OP, ")"),
            (OP, ":")
        ]
    )
    result = "1 print \"hello\"()\n"
    assert l == result, l



# Generated at 2022-06-23 15:55:38.971210
# Unit test for function untokenize
def test_untokenize():
    def check(input, output):
        if isinstance(input, str):
            input = input.encode("latin-1")
        output = output.encode("latin-1")
        if output[-1:] == b"\n" and output[-2:-1] != b"\r":
            output = output[:-1] + b"\r\n"
        readline = iter(input.splitlines(1)).__next__
        tokens = list(tokenize(readline))
        out = untokenize(tokens)
        print(tokens)
        print(out)
        assert out == output

    check(
        r"""def f():
    x = 3; y = 4
""",
        r"""def f():
    x = 3; y = 4
""",
    )

   

# Generated at 2022-06-23 15:55:40.614621
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError("TokenError message")
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-23 15:55:47.852757
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    def untok(seq):
        return ut.untokenize(iter(seq))
    assert untok([(1, ""), (2, ""), (3, ""), (3, "")]) == "   "
    assert untok([(1, ""), (2, ""), (3, ""), (3, ""), (0, "")]) == "   "
    assert untok([(1, ""), (2, ""), (3, ""), (3, ""), (0, ""), (1, "")]) == "   "
    assert untok([(1, ""), (2, ""), (3, ""), (3, ""), (0, ""), (4, "")]) == "   "
    assert untok([(1, ""), (0, ""), (3, "")])

# Generated at 2022-06-23 15:55:59.460335
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    utok=Untokenizer()
    utok.add_whitespace((1,2))
    assert utok.tokens[0]==" "
    utok.add_whitespace((1,3))
    assert utok.tokens[1]==" "
    utok.add_whitespace((2,0))
    assert len(utok.tokens)==1
    utok.add_whitespace((1,4))
    assert utok.tokens[1]=="  "
    utok.add_whitespace((2,0))
    assert utok.tokens[1]=="\n"
    utok.add_whitespace((2,2))
    assert utok.tokens[2]=="  "
    utok.add_wh

# Generated at 2022-06-23 15:56:03.400201
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(iterable):
        def gen():
            for line in iterable:
                yield line.encode("latin-1")

        return gen

    def read_or_stop():
        try:
            return next(lines)
        except StopIteration:
            return b""

    lines = readlines(
        [
            '# -*- coding: latin-1 -*-\n',
            '"m\xe9t\xe9o"\n',
            'print(x)\n',
        ]
    )
    encoding = detect_encoding(read_or_stop)[0]
    assert encoding == "latin-1"


__all__.append("detect_encoding")



# Generated at 2022-06-23 15:56:07.270713
# Unit test for function printtoken
def test_printtoken():
    toktype = token.NUMBER
    toktext = '23'
    startpos = (0, 0)
    endpos = (0, 2)
    line = '23'
    printtoken(toktype, toktext, startpos, endpos, line)


# Generated at 2022-06-23 15:56:09.070156
# Unit test for function any
def test_any():
    assert(any("a", "b") == "(a|b)*")
    assert(any("") == "*")


# Generated at 2022-06-23 15:56:10.753386
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    # Constructor adds no tokens
    u = Untokenizer()
    assert u.tokens == []


# Generated at 2022-06-23 15:56:17.358131
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    token_info1 = (NAME, "a", (1, 0), (1, 1), "a")
    token_info2 = (DEDENT, "", (1, 1), (1, 1), "")
    token_info3 = (NEWLINE, "\n", (1, 1), (1, 2), "\n")
    token_info4 = (NUMBER, "1", (2, 0), (2, 1), "1")
    token_info5 = (NL, "\n", (2, 1), (2, 2), "\n")
    token_info6 = (INDENT, "\t", (3, 0), (3, 1), "\t")
    token_info7 = (NAME, "b", (3, 1), (3, 2), "b")

# Generated at 2022-06-23 15:56:29.808330
# Unit test for function untokenize
def test_untokenize():
    tests = [
        ('x = 1', 'x\x20=\x201\x20'),
        ('x = 1\n', 'x\x20=\x201\n'),
        ('x = 1\n\n', 'x\x20=\x201\n\n'),
    ]
    ut = Untokenizer()
    for i, (test, result) in enumerate(tests):
        tt = [
            (token.NAME, 'x'),
            (token.OP, '='),
            (token.NUMBER, '1'),
            (token.NEWLINE, '\n'),
        ]

# Generated at 2022-06-23 15:56:34.650040
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize

    f = io.StringIO("class A: pass\n")
    tokens = tokenize.generate_tokens(f.readline)
    untok = Untokenizer()
    s = untok.untokenize(tokens)
    assert s == "class A: pass\n"



# Generated at 2022-06-23 15:56:43.335570
# Unit test for function maybe
def test_maybe():
    matching = [
        "foo",
        "bar",
        "foobar",
        "barfoo",
    ]
    nonmatching = [
        "foobarfoo",
        "foobarbar",
        "barbarfoo",
        "barbarbar",
    ]
    for s in matching:
        m = re.match(maybe("foo", "bar"), s)
        assert m, "matching %s" % s
        assert m.end() == len(s)
    for s in nonmatching:
        m = re.match(maybe("foo", "bar"), s)
        assert not m, "non-matching %s" % s


# Generated at 2022-06-23 15:56:45.045584
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"



# Generated at 2022-06-23 15:56:47.406467
# Unit test for function maybe
def test_maybe():
    assert maybe('a', 'b', 'c') == "(a|b|c)?"



# Generated at 2022-06-23 15:56:56.672778
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    u = Untokenizer()
    test_values = (
        (1, "return"),
        (4, "   "),
        (2, "1"),
        (4, "   "),
        (2, "2"),
        (0, "\n"),
    )
    actual = tuple(u.compat(test_values[0], test_values[1:]))
    assert actual == ("return ", 1, "   ", 2, "   ", 4, "1 ", 2, "2 ", 3, "\n", 0)

# Generated at 2022-06-23 15:57:07.748932
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()

# Generated at 2022-06-23 15:57:13.373340
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    iterable = [
        (NAME, "abc"),
        (NL, "\n"),
        (INDENT, "    "),
        (NAME, "def"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (NAME, "ghi"),
    ]
    untok.compat((NAME, "abc"), iterable)
    assert untok.tokens == ["abc ", "def", "    ", "ghi "]



# Generated at 2022-06-23 15:57:18.722045
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io

    u = Untokenizer()
    t3 = (3, "x")
    t4 = (4, "y")
    t1 = (1, "a")
    t2 = (2, "b")
    iterable = (t1, t2, t3, t4)
    expected = ["a", "b", "x", "y"]
    expected = "".join(expected)
    result = u.untokenize(iterable)
    assert result == expected, "'%s' differs from '%s'" % (result, expected)



# Generated at 2022-06-23 15:57:29.422243
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?"


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"\w+"

Hexnumber = r"0[xX][0-9a-fA-F]+"
Binnumber = r"0[bB][01]+"
Octnumber = r"0[oO][0-7]+"
Decnumber = r"(?:0+|[1-9][0-9]*)"

# Generated at 2022-06-23 15:57:35.190344
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "1", (1, 2), (1, 3), "bla")
    printtoken(STRING, "1", (1, 2), (1, 3), "bla")
    printtoken(NAME, "a", (1, 2), (1, 3), "bla")
    printtoken(OP, "<", (1, 2), (1, 3), "bla")
    printtoken(ERRORTOKEN, "err", (1, 2), (1, 5), "bla")



# Generated at 2022-06-23 15:57:36.938454
# Unit test for constructor of class TokenError
def test_TokenError():
    e = TokenError("foo")  # type: TokenError



# Generated at 2022-06-23 15:57:46.417779
# Unit test for function any
def test_any():
    def test(result, *choices):
        pattern = re.compile(r"^%s$" % any(*choices))
        assert pattern.match(result), pattern.pattern
    test("", "a")
    test("a", "a")
    test("aaa", "a")
    test("", "a", "b")
    test("a", "a", "b")
    test("b", "a", "b")
    test("ab", "a", "b")
    test("ba", "a", "b")
    test("aba", "a", "b")
    test("bab", "a", "b")
    test("babaaab", "a", "b")
    test("aaaaaaaaaa", "a", "bb")
    test("bbbbbbbbbb", "a", "bb")

# Generated at 2022-06-23 15:57:58.907569
# Unit test for function untokenize
def test_untokenize():
    import io, tokenize
    from tokenize import untokenize

    # Untokenizing an empty sequence produces an empty string.
    eq(untokenize([]), '')

    # Test round-trip invariant for full input
    source_lines = "def f(): pass\n"
    readline = iter(source_lines.splitlines(1)).next
    tokens = [tok[:2] for tok in tokenize.generate_tokens(readline)]
    roundtrip = untokenize(tokens)
    readline = iter(roundtrip.splitlines(1)).next
    tokens2 = [tok[:2] for tok in tokenize.generate_tokens(readline)]
    eq(tokens2, tokens)

    # Test round-trip invariant for limited input

# Generated at 2022-06-23 15:58:08.285101
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    assert u.tokens == []
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", " "]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", " "]
    u.tokens = []
    u.add_whitespace((2, 2))
    assert u.tokens == ["\n", " "]
    u.add_whitespace((3, 4))

# Generated at 2022-06-23 15:58:10.862872
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO, BytesIO
    from tokenize import generate_tokens
    from .token import tok_name


# Generated at 2022-06-23 15:58:13.397561
# Unit test for constructor of class TokenError
def test_TokenError():

    try:
        raise TokenError("foo")
    except TokenError as exc:
        assert str(exc) == "foo"



# Generated at 2022-06-23 15:58:20.455599
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = io.StringIO('''
while 1:
    print('foo')
    print('bar')
''')
    def readline():
        line = s.readline()
        if not line:
            raise EOFError
        return line
    def tokeneater(*args):
        tok_name[args[0]]

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-23 15:58:23.536828
# Unit test for function any
def test_any():
    assert any(*["a", "b"]) == "(a|b)*"
    assert any(*["a"]) == "a*"
    assert any(*[""]) == ""
    assert any() == ""
    assert any(*[]) == ""



# Generated at 2022-06-23 15:58:24.842865
# Unit test for constructor of class TokenError
def test_TokenError():
    exc = TokenError("message")
    assert exc.msg == "message"



# Generated at 2022-06-23 15:58:34.483957
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'#!/usr/bin/env python3'
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'print(1)\n'
    assert detect_encoding(readline) == ('iso-8859-1', [
        b'#!/usr/bin/env python3',
        b'# -*- coding: latin-1 -*-\n',
        b'print(1)\n'])
    def readline():
        yield b'#!/usr/bin/env python3'
        yield b'# -*- coding: ascii -*-\n'
        yield b'print(1)\n'
    try:
        detect_encoding(readline)
    except SyntaxError:
        pass

# Generated at 2022-06-23 15:58:43.443970
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    test1 = "def foo(arg): return arg + 1"
    test2 = test1.replace(" ", "\t")
    for input, output in ((test1, test2), (test2, test1)):
        infp = io.StringIO(input)
        tokens = list(generate_tokens(infp.readline))
        infp.close()
        assert len(tokens) == 9
        for i, token in enumerate(tokens):
            assert isinstance(token, tuple)
            assert len(token) == 5
            assert isinstance(token[0], int)
            assert isinstance(token[1], str)
            assert isinstance(token[2], tuple)
            assert len(token[2]) == 2

# Generated at 2022-06-23 15:58:46.147180
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    def token_info(type, token, start, end, line):
        print("%s %s %s" % (tok_name[type], repr(token), start))

    s = StringIO("abc\ndef")
    tokenize_loop(s.readline, token_info)



# Generated at 2022-06-23 15:58:48.593438
# Unit test for function group
def test_group():
    assert group(r"\d", r"\w", r"\s") == r"(\d|\w|\s)"



# Generated at 2022-06-23 15:58:54.686267
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    f = Untokenizer()
    tok = ((token.NAME, "a"), (token.NL, "\n"), (token.INDENT, "  "), (token.NAME, "b"),)
    f.compat(tok[0], tok[1:])
    print(f.tokens)



# Generated at 2022-06-23 15:59:03.970474
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import textwrap

# Generated at 2022-06-23 15:59:05.446321
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    x = StopTokenizing()
    assert x.args == ()



# Generated at 2022-06-23 15:59:16.007555
# Unit test for function tokenize_loop

# Generated at 2022-06-23 15:59:26.892685
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO

    input = "if 1:    # A comment\n    x = 2  # Another comment"

# Generated at 2022-06-23 15:59:30.421482
# Unit test for function group
def test_group():
    assert group("a", "bb") == "(a|bb)"
    assert group("") == "()"
    assert group("abc", "", "def") == "(abc|()|def)"
    return



# Generated at 2022-06-23 15:59:42.399974
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token_stream(data, expected_tokens):
        it = generate_tokens(iter(data.splitlines(True)).__next__, None)
        got = [token[:3] for token in it]
        assert got == expected_tokens
    #
    data = '''
    for i in range(10):
        print(i)
    '''

# Generated at 2022-06-23 15:59:50.405710
# Unit test for function untokenize
def test_untokenize():
    def compare(untok_str, exp_str):
        readline = iter(untok_str.splitlines(1)).__next__
        tokens = generate_tokens(readline)
        newcode = untokenize(tokens)
        assert newcode == exp_str
    compare('def x(): pass\n', 'def x(): pass\n')
    compare('s = r"\\\\"\n', 's = r"\\\\"\n')



# Generated at 2022-06-23 15:59:54.851300
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untokenizer = Untokenizer()
    token_info = (
        1,
        "hi",
        (0, 0),
        (0, 2),
        "hi\n",
    )
    a = untokenizer.untokenize(iter([token_info]))
    assert a == "hi\n"



# Generated at 2022-06-23 15:59:57.505004
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?"


# Generated at 2022-06-23 16:00:05.617706
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    e = StopTokenizing()
    assert isinstance(e, Exception)
    assert isinstance(e, StopTokenizing)


# Utility to convert from a word (e.g., "september") to a month number
# (9)
#
# We add this as a method to str (which subclasses bytes)
#
# FIXME: This assumes US English, but Python is generally "language-neutral"
# and thus this should probably be replaced by a locale-neutral algorithm
# that maps a word to its corresponding integer (e.g., if the locale is
# French it should map "septembre" to 9).

# Generated at 2022-06-23 16:00:17.908488
# Unit test for function untokenize
def test_untokenize():
    import io
    import sys
    from . import tokenize

    def roundtrip(s1):
        f = io.StringIO(s1)
        t1 = list(tokenize.tokenize(f.readline))
        newcode = untokenize(t1)
        readline = iter(newcode.splitlines(1)).__next__
        t2 = list(tokenize.tokenize(readline))
        return t1 == t2

    assert roundtrip("")
    assert roundtrip("a")
    assert roundtrip("a b")
    assert roundtrip("a(1)")
    assert roundtrip('a(1.2)')
    assert roundtrip('a(1,2)')
    assert roundtrip('a(1,2,)')
    assert roundtrip('a(1,2,3)')

# Generated at 2022-06-23 16:00:21.971687
# Unit test for function maybe
def test_maybe():
    # Test_maybe sets the variables below
    global test_maybe_inputs
    global test_maybe_outputs
    global test_maybe_count
    global test_maybe_at
    # Initial test condition
    if test_maybe_count == 0:
        # Initialize list of inputs and outputs
        test_maybe_inputs = []
        test_maybe_outputs = []
        # List of inputs and outputs to test function maybe
        test_maybe_inputs.extend(['a'])
        test_maybe_outputs.extend(['(a)?'])
        # List of inputs and outputs to test function maybe
        test_maybe_inputs.extend(['a', 'a'])
        test_maybe_outputs.extend(['(a)?', '(a)?', '(a)?'])
        # List of inputs

# Generated at 2022-06-23 16:00:26.676468
# Unit test for function printtoken
def test_printtoken():
    data = ["bogus", "", " ", "\t", "\n", "#", "abc", "'abc'", '"abc"']
    for datum in data:
        printtoken(token.OP, datum, (0, 0), (0, len(datum)), datum)



# Generated at 2022-06-23 16:00:37.069724
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    tokenize._untokenize = None
    untok = tokenize.Untokenizer()
    untok.untokenize(tokenize.generate_tokens(io.BytesIO(b"def f():\n  pass\n")))
    assert untok.tokens == ["def f ( ) : ","\n","  pass ","\n"]
    untok.tokens = []
    untok.untokenize(tokenize.generate_tokens(io.BytesIO(b"def f():\n  pass")))
    assert untok.tokens == ["def f ( ) : ","\n","  pass "]



# Generated at 2022-06-23 16:00:41.195240
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"
    assert any("") == "()*"
    assert any("a") == "(a)*"
    assert any("abc") == "(abc)*"



# Generated at 2022-06-23 16:00:46.822495
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    from io import BytesIO as StringIO

    def tokenize_roundtrip(s: Text, dec: int = None) -> Text:
        if dec is None:
            stream = StringIO(s.encode("utf-8"))
        else:
            stream = StringIO(s.encode("utf-8"), read_encoding="utf-8")
        stream.seek(0)
        out = untokenize(generate_tokens(stream.readline))
        return out.decode("utf-8")

    assert tokenize_roundtrip("a = 1 \n") == "a = 1 \n"

# Generated at 2022-06-23 16:00:54.625253
# Unit test for function maybe
def test_maybe():
    assert maybe('abc') == '(abc)?', maybe('abc')
    assert maybe(r'ab(c|d)') == r'(ab(c|d))?', maybe(r'ab(c|d)')

_hash_chars = r"\x23\u0023\U00000023"
_hash_logical_line_prefix = r"(?<!\x23\s*)(:?{hash_chars})[ \t]*(\\\n[ \t]*)*".format(hash_chars=_hash_chars)

_namechars = r"\w\u00A0-\U0010FFFF"
_name_startchars = r"(_|{namechars})".format(namechars=_namechars)

# Generated at 2022-06-23 16:00:56.444160
# Unit test for function any
def test_any():
    assert any('a', 'b', 'c') == '(a|b|c)*'


# Generated at 2022-06-23 16:01:03.144253
# Unit test for function tokenize
def test_tokenize():
    import io
    from tokenize import tokenize

    s = "def f(x): return 'abc'"
    with io.StringIO(s) as f:
        g = tokenize(f.readline)
        for toknum, tokval, _, _, _ in g:
            print("%s %s" % (tok_name[toknum], tokval))



# Generated at 2022-06-23 16:01:05.731124
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("bad")
    except TokenError:
        pass



# Generated at 2022-06-23 16:01:07.448620
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-23 16:01:10.688347
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # type: () -> None

    # If this raises an exception, it's a bug
    raise StopTokenizing  # Does not return



# Generated at 2022-06-23 16:01:19.434331
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untokenizer = Untokenizer()
    untokenizer.tokens = []

    # Test add_whitespace
    untokenizer.add_whitespace((1, 1))
    untokenizer.add_whitespace((1, 2))
    assert untokenizer.tokens == [" ", " "]
    untokenizer.prev_row = 2
    untokenizer.prev_col = 0
    untokenizer.add_whitespace((2, 0))
    assert untokenizer.tokens == [" ", " ", ""]

    # Test untokenize
    untokenizer.tokens = []
    untokenizer.prev_row = 1
    untokenizer.prev_col = 0
    iter1 = ((NAME, 'name'), (INDENT, ''), (NAME, 'name2'))
   