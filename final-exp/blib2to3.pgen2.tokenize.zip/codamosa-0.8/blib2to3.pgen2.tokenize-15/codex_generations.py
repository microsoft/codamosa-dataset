

# Generated at 2022-06-11 19:58:07.305678
# Unit test for function generate_tokens
def test_generate_tokens():
    from token import tok_name
    from io import StringIO
    r = StringIO("""\
if 1:
    print('foo')
""")
    l = list(tokenize.generate_tokens(r.readline))
    for t in l:
        print(tok_name[t[0]], repr(t[1]))
 
test_generate_tokens()


# Generated at 2022-06-11 19:58:15.654160
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    src = "'''hi'''\n"
    result = list(tokenize.generate_tokens(io.BytesIO(src.encode("utf-8")).readline))
    assert result[0] == (tokenize.ENCODING, "utf-8", (1, 0), (1, 0), b"")
    assert result[1] == (
        tokenize.STRING,
        "'''hi'''",
        (1, 0),
        (1, 7),
        b"'''hi'''\n",
    )
    assert result[2] == (
        tokenize.NEWLINE,
        "\n",
        (1, 7),
        (1, 8),
        b"'''hi'''\n",
    )
    assert result

# Generated at 2022-06-11 19:58:20.135771
# Unit test for function tokenize_loop
def test_tokenize_loop():
    if not PyCF_ONLY_AST:
        import io
        import tokenize

        def readline(self):
            return self.readline()

        s = io.StringIO("1 + 1\n")
        tok = tokenize.generate_tokens(readline(s))
        tokenize_loop(readline(s), tokenize.printtoken)



# Generated at 2022-06-11 19:58:29.357620
# Unit test for function generate_tokens
def test_generate_tokens():

    # Example of testing a generator
    def gen_tokens(readline, grammar=None):
        for type, token, (srow, scol), (erow, ecol), line in generate_tokens(readline, grammar):
            print("%10s %-14r %-20s %s" % (tokenize.tok_name.get(type), token, (srow, scol), line))

    text = """if 1:
    print(__name__)
    x = 5
    y = 3

"""
    gen_tokens(text.splitlines().__iter__().next)

test_generate_tokens()


# Generated at 2022-06-11 19:58:32.937100
# Unit test for function generate_tokens
def test_generate_tokens():
    a = generate_tokens('print("Hello World")')
    print(list(a))
test_generate_tokens()

# Get the encoding of a file

# Generated at 2022-06-11 19:58:37.334128
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from test import test_tokenize
    test_tokenize.test_tokenize_loop(tokenize_loop)



# Generated at 2022-06-11 19:58:41.514285
# Unit test for function generate_tokens
def test_generate_tokens():
    from token import tok_name
    from io import StringIO
    from typing import Callable

    data = "for i in range(10): print(i)"
    with StringIO(data) as f:
        for tok in generate_tokens(f.readline):
            print(tok)

test_generate_tokens()

# Note: The tokenize() function is not used very much in cpython.
# It is used as the implementation of tokenize.tokenize() which we
# will not be using.


# Generated at 2022-06-11 19:58:49.959925
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    def check(s, iterable):
        res = u.untokenize(iterable)
        assert res == s, "got %r" % res
    #
    check("a()", [(NAME, "a", (1, 0), (1, 1), "a")] + [(OP, "("), (OP, ")")])
    check("a  ()", [(NAME, "a", (1, 0), (1, 1), "a")] + [(OP, "("), (OP, ")")])
    check("\n\n", [(NEWLINE, "\n", (3, 0), (3, 1), "\n")])

# Generated at 2022-06-11 19:59:02.801198
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not test_source:
            raise StopIteration
        return test_source.pop(0)


# Generated at 2022-06-11 19:59:14.355361
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    from tokenize import (
        COMMENT,
        ERRORTOKEN,
        INDENT,
        NEWLINE,
        NAME,
        OP,
        STRING,
        TokenInfo,
    )
    result = list(tokenize.generate_tokens(iter(["x=1"]).__next__))

# Generated at 2022-06-11 19:59:55.633629
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.NUMBER, "999", (1, 0), (1, 4), "999")
    printtoken(token.STRING, "999", (1, 0), (1, 4), "999")
    printtoken(token.NAME, "999", (1, 0), (1, 4), "999")
    printtoken(token.OP, "999", (1, 0), (1, 4), "999")



# Generated at 2022-06-11 20:00:06.200006
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.add_whitespace((1, 0))
    def test(iterable, want):
        got = ut.untokenize(iterable)
        assert got == want, f"unexpected output '{got}', wanted '{want}'"
    test(
        [(NUMBER, "1", (1, 1), (1, 2), "1"), (NUMBER, "2", (1, 2), (1, 3), "12")],
        "12",
    )
    test(
        [(NUMBER, "1", (1, 1), (1, 2), "1"), (NUMBER, "2", (2, 1), (2, 2), "2")],
        "1\n2",
    )

# Generated at 2022-06-11 20:00:14.222647
# Unit test for function tokenize
def test_tokenize():
    import io
    from contextlib import redirect_stdout

    tokengen = generate_tokens(io.BytesIO(b"#testing\nspam(1)\n").readline)
    f = io.StringIO()
    with redirect_stdout(f):
        for token in tokengen:
            print(token)
    expected = """
(1, 0, 1, 7) COMMENT '#testing'
(2, 0, 2, 5) NAME 'spam'
(2, 5, 2, 6) OP '('
(2, 6, 2, 7) NUMBER '1'
(2, 7, 2, 8) OP ')'
(2, 8, 2, 8) NEWLINE '\\n'
""".split(
        "\n"
    )

# Generated at 2022-06-11 20:00:24.759612
# Unit test for function detect_encoding
def test_detect_encoding():
    "Test detect_encoding()."
    def readline():
        return next(lines)

    # No encoding
    lines = iter(["spam\n", "eggs\n"])
    assert detect_encoding(readline) == ("utf-8", [])

    # UTF-8 encoding with BOM
    lines = iter([BOM_UTF8 + "spam\n", "eggs\n"])
    assert detect_encoding(readline) == ("utf-8-sig", [BOM_UTF8])

    # No encoding but only blank lines
    lines = iter([" \t\f\n", "\v\r\n", "\n"])
    assert detect_encoding(readline) == ("utf-8", [])

    # Encoding with only blank lines

# Generated at 2022-06-11 20:00:35.002419
# Unit test for function printtoken
def test_printtoken(): printtoken(0, 0, (0, 0), (0, 0), 0)
test_printtoken()
del test_printtoken


try:
    import _bisect
except ImportError:
    # Python 2.5+ compatibility
    def _bisect(a, x):
        """Replacement for deprecated insort_left in Python 2.5.

        This does the same thing, but always returns 0 as per modern
        docs.

        """
        a.insert(bisect_left(a, x), x)
        return 0

    import bisect as bisect_left
else:
    def _bisect(a, x):
        return _bisect.insort_left(a, x)

    def bisect_left(a, x):
        return _bisect.bisect_left(a, x, 0, len(a))

# Generated at 2022-06-11 20:00:43.090817
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize

    stream = (
        "async def f():\n"
        "    pass\n"
        "print(3)\n"
        "async def g():\n"
        "    pass\n"
        "if __name__ == '__main__':\n"
        "    import sys\n"
        "    async def main():\n"
        "        pass\n"
    )

    # Test with file interface
    tokengen = tokenize.generate_tokens(io.StringIO(stream).readline)
    tokens = list(tokengen)

# Generated at 2022-06-11 20:00:55.447708
# Unit test for function tokenize_loop
def test_tokenize_loop():

    def readline():
        yield from ["123         \n", "456 a b c\n", "789\n", "abc\n"]

    tokeneater = []  # type: List[Tuple[int, Text, Tuple[int, int], Tuple[int, int], Text]]


# Generated at 2022-06-11 20:01:06.719910
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2.tokenize import generate_tokens


# Generated at 2022-06-11 20:01:12.407040
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test that StopTokenizing exception is caught
    tokenize_loop(lambda: b"", printtoken)
    # Exercise all branches of tokenize_loop
    tokenize_loop(
        lambda: b"a\n",
        printtoken,
    )
    tokenize_loop(
        lambda: b"a\nb\n",
        printtoken,
    )



# Generated at 2022-06-11 20:01:21.908514
# Unit test for function printtoken
def test_printtoken():
    stmt = '''if a > 1:
    print "hello"
    '''

# Generated at 2022-06-11 20:01:54.752867
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def compare(input, output):
        u = Untokenizer()
        result = u.untokenize(iterable=input)
        if result != output:
            print()
            print("-" * 40)
            print("Input:", repr(input))
            print("Expected:", repr(output))
            print("Received:", repr(result))
            return False
        return True

    compare([("number", "1")], "1 ")
    compare([("number", "1.0")], "1.0 ")
    compare(
        [("number", "1"), ("newline", "\n"), ("number", "2")],
        "1 \n2",
    )

# Generated at 2022-06-11 20:02:06.182569
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # Test that untokenize() correctly handles leading NL and DEDENT.
    from io import StringIO

    class TestTokenizer:

        def __iter__(self):
            for t in [
                (token.INDENT, "    "),
                (token.IF, "if "),
                (token.NAME, "x"),
                (token.NL, "\n"),
                (token.INDENT, "    "),
                (token.NAME, "print"),
                (token.NAME, "x"),
                (token.NL, "\n"),
                (token.DEDENT, ""),
                (token.NAME, "print"),
                (token.NAME, "y"),
                (token.ENDMARKER, ""),
            ]:
                yield t

    out = StringIO()
    untok = Untokenizer()


# Generated at 2022-06-11 20:02:08.573408
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: ascii"
        yield b"pass"

    encoding, lines = detect_encoding(readline)
    assert encoding == "ascii"
    assert len(lines) == 2



# Generated at 2022-06-11 20:02:17.089317
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        line = yield
        while line:
            yield line
            line = yield

    def tokeneater(*args):
        toks.append(args)

    toks = []
    r = readline()
    r.send(None)
    tokenize_loop(r.send, tokeneater)
    r.send('123')
    r.close()
    assert toks == [(NUMBER, '123', (1, 0), (1, 3), '123')]



# Generated at 2022-06-11 20:02:27.605714
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    def tt(s, expect):
        u = Untokenizer()
        result = u.compat(tokenize(s).next(), tokenize(s))
        assert expect == "".join(u.tokens), (expect, "".join(u.tokens))
    tt('class X: pass\n', 'class X: pass\n')
    tt('class X (object): pass\n', 'class X(object): pass\n')
    tt('foo ("bar", **baz)\n', 'foo("bar", **baz)\n')
    tt('foo (bar, *baz, **bing)\n', 'foo(bar, *baz, **bing)\n')
    tt('foo (1, 2, /, 3)\n', 'foo(1, 2, 3)\n')
   

# Generated at 2022-06-11 20:02:30.364380
# Unit test for function tokenize
def test_tokenize():
    test_generator(
        "tokenize",
        tokenize,
        "abc",
        [("NAME", "abc", (1, 0), (1, 3), "abc")],
        lambda x, l, r: [tok_name[t[0]] for t in x] == l,
        False,
    )



# Generated at 2022-06-11 20:02:40.832377
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        yield io.BytesIO(b"# coding: latin-1\n")
        yield io.BytesIO(b"pass  ")

    encoding, lines = detect_encoding(readline())
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n"]

    def readline():
        yield io.BytesIO(b"#!/usr/bin/python3\n")
        yield io.BytesIO(b"# coding: latin-1\n")
        yield io.BytesIO(b"pass  ")

    encoding, lines = detect_encoding(readline())
    assert encoding == "iso-8859-1"

# Generated at 2022-06-11 20:02:47.484705
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:02:58.418159
# Unit test for function generate_tokens
def test_generate_tokens():

    def tokens_list(code):
        return list(tokenize(BytesIO(code.encode('utf-8')).readlines))

    def input_tokenizer(code):
        return '\n'.join(
            "%-20s%-15s%-10s%s" % (token, repr(string), start, end)
            for token, string, start, end, line in tokenize(BytesIO(code.encode('utf-8')).readline)
        )

    def input_source(code):
        return '\n'.join(line for line in tokenize(BytesIO(code.encode('utf-8')).readline))

    assert tokens_list("") == [(0, '')]
    assert tokens_list(" ") == [(0, '')]
    assert tokens_list("\t") == [(0, '')]

# Generated at 2022-06-11 20:03:10.377803
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    data = "def a(x,y):\n return x+y"
    for token in tokenize(io.StringIO(data).readline):
        print(token)
    print()
    for token in generate_tokens(io.StringIO(data).readline):
        print(token)

test_generate_tokens()

# Test the function generate_tokens()
# print(generate_tokens(io.StringIO(data).readline))

# Test the function tokenize()
# data = "x = 1 + 2 + 3"
# print(tokenize(io.StringIO(data).readline))

tokens = list(tokenize(io.StringIO(data).readline))
print(tokens)

# from pytokenize import tokenize


# Generated at 2022-06-11 20:04:07.023897
# Unit test for function generate_tokens
def test_generate_tokens():
    import io

    with io.StringIO(
        "if 1:\n"
        "  pass\n"
        "elif 2:\n"
        '  sys.exit("something")\n'
        "else:\n"
        "  print("
    ) as f:
        tokens = list(tokenize.generate_tokens(f.readline))
    print(tokens)

# Generated at 2022-06-11 20:04:16.981246
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # type: () -> None
    from blib2to3.pgen2.tokenize import tokenize
    from .token import generate_tokens
    from io import StringIO


# Generated at 2022-06-11 20:04:17.853353
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize

# Generated at 2022-06-11 20:04:21.754035
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    test_tokens = [
        (2, "test"),
        (0, "\n"),
        (3, "test"),
        (0, "\n"),
        (0, "\n"),
    ]
    u = Untokenizer()
    assert u.compat(test_tokens[0], test_tokens[1:]) == None
    assert u.compat(test_tokens[2], test_tokens[3:]) == None



# Generated at 2022-06-11 20:04:28.268694
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    readline = StringIO("if x:\n    print(x)\n").readline
    for ttype, tstring, start, end, line in generate_tokens(readline):
        print("%10s %-14r %-20r %r" % (tok_name[ttype], tstring, start, end))


# Generated at 2022-06-11 20:04:36.361655
# Unit test for function generate_tokens
def test_generate_tokens():
    import re
    import keyword
    import token

    text = """
            def f(x):
                return 2*x
        """

    def _tokens(text: str) -> Iterable[TokenInfo]:
        backslash = False
        for match in tokenprog.finditer(text):
            kind, value = match.lastgroup, match.group()
            if kind == "string" and backslash:
                value = value.replace("\\\n", "")
                backslash = False
            elif kind == "backslash" and not backslash:
                backslash = True
                continue
            elif kind in ("nl", "comment") and backslash:
                backslash = False

# Generated at 2022-06-11 20:04:40.708454
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    readline = io.StringIO('print("foo")\n').readline
    def tokeneater(*args):
        print(args)
    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-11 20:04:51.828778
# Unit test for function generate_tokens
def test_generate_tokens():
    import re
    import tokenize
    from io import StringIO

    def show_tokens(s:str) -> str:
        print("\n[%r]" % s)
        for tok in tokenize.generate_tokens(StringIO(s).readline):
            print("%10s %-14s %-20r %r" % tok)
        return ""

    show_tokens("foo = 42")
    show_tokens("foo = \\")
    show_tokens("        42")
    show_tokens("foo = \\")
    show_tokens("        42")
    show_tokens("# this is a comment\\")
    show_tokens("pass")
    show_tokens("x = x + 1 # increment x")
    show_t

# Generated at 2022-06-11 20:05:02.436433
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def test_one(input: List[TokenInfo], output: Text) -> None:
        t = Untokenizer()
        result = t.untokenize(iter(input))
        assert result == output


# Generated at 2022-06-11 20:05:13.725743
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import BytesIO
    from tokenize import tokenize as _tokenize
    from tokenize import untokenize as _untokenize

    def tokenize(s):  # same as _tokenize, but use str strings instead of bytes
        return _tokenize(BytesIO(s.encode("utf-8")).readline)

    def untokenize(tokens):  # same as _untokenize, but use str strings
        tokens = ((toknum, tokval.decode("utf-8")) for (toknum, tokval, _0, _1, _2) in tokens)
        return _untokenize(tokens).decode("utf-8")

    u = Untokenizer()
    t = tokenize("def f(): pass\n")

# Generated at 2022-06-11 20:05:54.687290
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test with a text file
    with open("simple_grammar.txt","r") as f:
        tokens = generate_tokens(f.readline)
        for token in tokens:
            print(token)

# Read the test file
with open("simple_grammar.txt","r") as f:
    tokens = generate_tokens(f.readline)
    for token in tokens:
        print(token)

# Write the test file
with open("simple_grammar.txt","w") as f:
    f.write("'''\n")
    f.write("this is a comment\n")
    f.write("'''\n")
    f.write("x = 'asdf'\n")
    f.write("y = \"asdf\"\n")

# Generated at 2022-06-11 20:05:58.290500
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "def f(): pass\n"
    _init_tests()
    def rl():
        return s
    def te(*args):
        printtoken(*args)
    tokenize(rl, te)


# Generated at 2022-06-11 20:06:05.258205
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    assert ut.untokenize([(1, "foo"), (1, "bar")]) == "foobar"
    assert ut.untokenize([(1, "foo"), (1, "")]) == "foo "
    assert ut.untokenize([(1, "foo"), (0, "")]) == "foo"
    assert ut.untokenize([(1, "foo\nfoo")]) == "foo\nfoo"
    assert ut.untokenize([(1, "foo\nfoo"), (1, "bar")]) == "foo\nfoo bar"



# Generated at 2022-06-11 20:06:14.416463
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    itok = [
        (NUMBER, "3", (1, 0), (1, 1), "3"),
        (NAME, "x", (1, 1), (1, 2), "x"),
        (OP, "+", (1, 2), (1, 3), "+"),
        (NUMBER, "4", (1, 3), (1, 4), "4"),
    ]
    assert (
        untok.untokenize(itok)
        == "3 x + 4 "
    )
    assert untok.prev_row == 1
    assert untok.prev_col == 4



# Generated at 2022-06-11 20:06:26.379137
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"a=1; print(a)\n"
        raise StopIteration

    encoding, _ = detect_encoding(readline())
    assert encoding == "iso-8859-1"

    def readline():
        yield b"# coding: ascii\n"
        yield b"a=1; print(a)\n"
        raise StopIteration

    try:
        encoding, _ = detect_encoding(readline())
        assert 0, "failed to detect invalid encoding"
    except SyntaxError:
        pass

    def readline():
        return b"\xef\xbb\xbf# coding: utf-8\n"

    encoding, _ = detect_encoding(readline)

# Generated at 2022-06-11 20:06:36.284180
# Unit test for function detect_encoding
def test_detect_encoding():
    import tempfile
    testdata = []
    testdata.append(
        b'#!/usr/bin/env python\n'
        b'\n'
        b'# coding: utf-8\n'
        b'print("# coding: utf-8")\n'
    )
    testdata.append(
        b'#!/usr/bin/env python\n'
        b'\n'
        b'# -*- coding: latin-1 -*-\n'
        b'print("# -*- coding: latin-1 -*-")\n'
    )