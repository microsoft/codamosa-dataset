

# Generated at 2022-06-11 19:58:24.859024
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import generate_tokens
    from io import StringIO
    from tokenize import TokenInfo
    from unittest.mock import MagicMock
    readline = MagicMock()

# Generated at 2022-06-11 19:58:36.609578
# Unit test for function detect_encoding

# Generated at 2022-06-11 19:58:39.469031
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    with open('tokenize_module.py', 'rb') as f:
        tokens = tokenize.generate_tokens(f.readline)
        for toknum, tokval, _, _, _ in tokens:
            print(toknum, tokval)

# Generated at 2022-06-11 19:58:45.992525
# Unit test for function detect_encoding
def test_detect_encoding():
    import codecs
    import io
    import re
    import sys

    def open_with_bom(filename, *args, **kwargs):
        f = open(filename, "rb")
        try:
            if f.read(3) != codecs.BOM_UTF8:
                f.seek(0)
            return codecs.getreader("utf-8-sig")(f, *args, **kwargs)
        except:
            f.close()
            raise

    def roundtrip(filename):
        with open_with_bom(filename, "rb") as f:
            encoding, lines = detect_encoding(f.readline)
            try:
                f.seek(0)
                data = f.read().decode(encoding)
            except UnicodeError:
                data = f.read().dec

# Generated at 2022-06-11 19:58:59.955565
# Unit test for function detect_encoding
def test_detect_encoding():
    firstline = b"# -*- coding: ascii -*-\n"
    secondline = b"# -*- coding: latin-1 -*-\n"
    thirdline = b"blah blah blah\n"
    def readline():
        if firstline:
            try:
                return firstline
            finally:
                firstline = b""
        if secondline:
            try:
                return secondline
            finally:
                secondline = b""
        if thirdline:
            try:
                return thirdline
            finally:
                thirdline = b""
        raise StopIteration
    assert detect_encoding(readline) == ("ascii", [firstline])
    firstline = b"# -*- coding: ascii -*-  \n"
    assert detect_encoding

# Generated at 2022-06-11 19:59:02.715250
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO

    s = StringIO("def f(x): return 2*x")
    for token in generate_tokens(s.readline):
        print(token)



# Generated at 2022-06-11 19:59:14.355878
# Unit test for function printtoken
def test_printtoken():
    printtoken(59, '(', (0, 0), (0, 0), 'foo')
    assert True, 'this test was created for passing travis-ci'

triple_quoted_dict = {
    "'''" : single3prog,
    '""' : double3prog,
    # _strprefixes: triple_quoted
}

single_quoted_dict = {
    "'" : single3prog,
    '"' : double3prog,
    # _strprefixes: single_quoted,
}


# Generated at 2022-06-11 19:59:26.068682
# Unit test for function tokenize
def test_tokenize():
    #    from cStringIO import StringIO
    from io import StringIO


# Generated at 2022-06-11 19:59:32.323711
# Unit test for function detect_encoding
def test_detect_encoding():
    comment = b"# coding=utf-8\n"
    utf8 = BOM_UTF8 + b"".join(
        comment + bytes(chr(i), "utf-8") for i in range(1, 999)
    )


# Generated at 2022-06-11 19:59:36.653598
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    for i in range(1, 5):
        x = untok.untokenize([(1, "first item"), (2, "second item")])
        assert x == "first item second item "



# Generated at 2022-06-11 20:00:34.928622
# Unit test for function tokenize_loop
def test_tokenize_loop():
    try:
        import StringIO
    except ImportError:
        import io as StringIO

    def readline():
        return """\
while 1:
    print 'foo'
"""

    tok_s = StringIO.StringIO()
    tok_writer = getattr(tok_s, "write", tok_s.write)
    tokenize_loop(readline, tok_writer)
    tok_s = tok_s.getvalue()

# Generated at 2022-06-11 20:00:45.772860
# Unit test for function tokenize
def test_tokenize():
    global tabsize
    import pprint

    readline = iter(
        """def foo(x):
        return x * x

      class bar:
        pass
    """.splitlines()
    ).__next__

    def printtoken(*args):
        print(args)

    tabsize = 2
    tokenize(readline, printtoken)

    # repr() in Python 3.0 uses {} for sets, but for backward-compatibility,
    # we'll use set([])

# Generated at 2022-06-11 20:00:57.347800
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import tokenize

# Generated at 2022-06-11 20:01:08.824830
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> Iterator[bytes]:
        yield b"# -*- coding: cp1252 -*-"
        yield b"if 1:"
        raise StopIteration

    assert detect_encoding(readline) == ("cp1252", [b"# -*- coding: cp1252 -*-"])

    def readline() -> Iterator[bytes]:
        yield b"# coding=utf-8"
        yield b"import enc"
        raise StopIteration

    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8"])

    def readline() -> Iterator[bytes]:
        yield b"#!/usr/bin/python"
        yield b"# coding=utf-8"
        yield b""
        yield b"import enc"
        raise StopIteration



# Generated at 2022-06-11 20:01:21.230731
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from unittest.mock import Mock
    import io
    import io
    import io
    import io
    with open(io.__file__, encoding='utf-8') as f:
        lines = f.readlines()
        f.seek(0)
        g = generate_tokens(f.readline)
        first_token = next(g)
        t = Untokenizer()
        newtext = t.untokenize(g)
    if newtext != "".join(lines):
        non_python_lines = [
            line
            for line in lines
            if line[0] != '#' and line.strip().find('"""') == -1 and line.strip().find("'''") == -1
        ]
        # import dis as d
        # lines = []
        # for row in d.

# Generated at 2022-06-11 20:01:32.350376
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    from typing import Iterator

    from . import tokenize

    def tok_check(input, token_list):
        if isinstance(input, str):
            input = StringIO(input)
        tokens = tokenize.generate_tokens(input.readline)
        result = []
        for toknum, tokval, _, _, _ in tokens:
            result.append((toknum, tokval))
        if result != token_list:
            pos = 0
            for i in range(min(len(result), len(token_list))):
                if result[i] != token_list[i]:
                    pos = i
                    break
            print("tokens differ at position %s" % pos)
            print("expected: %r" % token_list)
            print

# Generated at 2022-06-11 20:01:42.483104
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import tokenize, NUMBER, STRING, NAME, OP, NL

    f = StringIO("1 + 1\nabc = 'a' + \"b\" + '''c''' + r'd'")
    tokengen = tokenize(f.readline)
    tokens = list(tokengen)

# Generated at 2022-06-11 20:01:54.829440
# Unit test for function detect_encoding
def test_detect_encoding():
    def reader(match, encoding, bom_encoding, too_many=b''):
        def readline():
            if match:
                enc = match.group(1).lower().replace('_', '-')
                if enc.startswith('utf-8'):
                    enc = 'utf-8'
                elif enc in ('iso-latin-1', 'iso-8859-1', 'latin-1'):
                    enc = 'iso-8859-1'
                if enc == 'utf-8' and bom_encoding == 'utf-8':
                    enc = 'utf-8-sig'
                if enc != encoding:
                    raise SyntaxError('encoding problem: %s with %s' %
                                      (encoding, enc))
            return readline._lines.pop(0)
        readline._lines

# Generated at 2022-06-11 20:02:01.062318
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest


    class MockFile:
        def __init__(self, lines: List[bytes]) -> None:
            self._lines = lines
            self._index = 0

        def readline(self) -> bytes:
            line = self._lines[self._index]
            self._index += 1
            return line


    class Test(unittest.TestCase):
        def test_detect_encoding(self) -> None:
            f = MockFile([b"", b"# coding:iso-8859-1"])
            self.assertEqual(detect_encoding(f.readline), ("iso-8859-1", [b""]))


        def test_detect_encoding_comment(self) -> None:
            f = MockFile([b"#"])
           

# Generated at 2022-06-11 20:02:08.056479
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield 'def f(): pass\n'

# Generated at 2022-06-11 20:02:44.338176
# Unit test for function generate_tokens
def test_generate_tokens():
    from sys import argv

    if len(argv) > 1:
        tokenize(open(argv[1]).readline)
    else:  # read from stdin
        tokenize(sys.stdin.readline)



# Generated at 2022-06-11 20:02:55.125297
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from typing import List
    from typing import Optional
    from typing import Tuple
    from typing import Union
    from . import token

    program = io.StringIO("for i in range(10): print(i)")
    tokens: List[Union[Tuple[int, str, int, int, int], Tuple[int, str, Tuple[int, int],
    Tuple[int, int], str]]] = list(tokenize(program.readline))
    print("TOKENS:")
    for toknum, tokval, _, _, _ in generate_tokens(program.readline):
        print("%10s %-14s" % (token.tok_name[toknum], repr(tokval)))
    print("DONE:")



# Generated at 2022-06-11 20:03:04.259102
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unit_test_cases = [
        (
            "",
            "",
        ),
        (
            "a,b,c",
            "a , b , c",
        ),
    ]
    for (expected, program) in unit_test_cases:
        tokens = list(
            generate_tokens(
                iter([program]).__next__
            )
        )
        untokenizer = Untokenizer()
        result = untokenizer.untokenize(tokens)
        assert expected == result


# Generated at 2022-06-11 20:03:13.156724
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not lines:
            raise StopIteration
        return lines.pop(0)


# Generated at 2022-06-11 20:03:23.662741
# Unit test for function tokenize_loop
def test_tokenize_loop():
    if __name__ == "__main__":
        import io
        import token
        f = io.StringIO(
            """# This is a test\n"""
            """print(4)\n"""
            """3\n"""
            """4\n"""
            """5\n"""
            """x_y\n"""
            """\n"""
            """"#"""
        )
        d = f.readline
        result = []

        def collect_result(type, token, start, end, line):
            result.append((type, token))

        tokenize_loop(d, collect_result)

# Generated at 2022-06-11 20:03:28.351825
# Unit test for function tokenize_loop
def test_tokenize_loop():
    test_str = 'str = "\\n\\n\\n"'
    readline = test_str.splitlines
    def test_tokeneater(*args):
        print(*args)
    tokenize_loop(readline, test_tokeneater)


# Generated at 2022-06-11 20:03:37.996757
# Unit test for function tokenize_loop
def test_tokenize_loop():
    tokenize_loop(lambda: "<EOF>", printtoken)
    print(
        # 2.7+
        "tokenize_loop(lambda: '')\n"
        "tokenize_loop(lambda: '', printtoken)\n"
        "tokenize_loop(list('').__iter__())\n"
        "tokenize_loop(iter([]))\n"
        "tokenize_loop(iter(('' for _ in [])))\n"
        "tokenize_loop(lambda: list(''))\n"
        "tokenize_loop(lambda: ('' for _ in []))\n"
        # 2.7+; 3.2+
        "tokenize_loop(lambda: '' if False else '', printtoken)\n"
    )



# Generated at 2022-06-11 20:03:48.055048
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more\n"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n", b"# some more\n"])

    def readline():
        yield b"# coding: latin-1\n"
        yield b"# some more\n"
        yield b"\n"
        yield b"# coding: cp932\n"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n", b"# some more\n"])

    def readline():
        yield b"# coding: latin-1\n"

# Generated at 2022-06-11 20:03:56.333412
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest

    class TestTokenizeLoop(unittest.TestCase):
        def test_simple(self):
            s = "def f(a): return a+1\n"
            stream = io.BytesIO(s.encode("utf-8"))
            tokens = []


# Generated at 2022-06-11 20:04:06.691620
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    readline = BytesIO(b'foo = "bar"\n').readline
    tokens = tokenize.generate_tokens(readline)
    assert next(tokens) == (tokenize.NAME, b'foo', (1, 0), (1, 3), b'foo = "bar"\n')
    assert next(tokens) == (tokenize.OP, b'=', (1, 4), (1, 5), b'foo = "bar"\n')
    assert next(tokens) == (tokenize.STRING, b'"bar"', (1, 6), (1, 11), b'foo = "bar"\n')

# Generated at 2022-06-11 20:04:48.441641
# Unit test for function tokenize_loop
def test_tokenize_loop():
    global verbose
    readline = iter(["if 1: #spam\n"]).__next__
    verbose = 1
    result = [
        (token.NAME, "if", (1, 0), (1, 2), "\n"),
        (token.NUMBER, "1", (1, 3), (1, 4), "\n"),
        (token.OP, ":", (1, 5), (1, 6), "\n"),
        (token.COMMENT, "#spam", (1, 7), (1, 12), "\n"),
        (token.NEWLINE, "\n", (1, 12), (1, 13), ""),
    ]
    tokenize_loop(readline,
                  lambda x, y, z, w, v: result.append((x, y, z, w, v)))

# Generated at 2022-06-11 20:04:51.134780
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize
    r = io.StringIO("print('foo')")
    _tokenize.tokenize(r.readline)



# Generated at 2022-06-11 20:05:00.561634
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "def f(x): return g('ab') + h[3]"
    t = []
    tokenize_loop(s.splitlines().__iter__().__next__, t.append)
    assert t == [(2, 'def'), (2, 'f'), (2, '('), (2, 'x'), (2, ')'),
        (2, ':'), (2, 'return'), (2, 'g'), (2, '('),
        (2, "'ab'"), (2, ')'), (2, '+'), (2, 'h'), (2, '['),
        (2, '3'), (2, ']')]
test_tokenize_loop()



# Generated at 2022-06-11 20:05:11.706668
# Unit test for function generate_tokens
def test_generate_tokens():

    def _make_fake_source(source):
        return iter(source.splitlines(keepends=True))

    def _make_fake_source_from_file(filename):
        lines = []
        with open(filename) as f:
            for line in f:
                lines.append(line)
        return iter(lines)

    def _compare_token_lists(test_case, expected, actual):
        # compare lengths
        expected_len = len(expected)
        actual_len = len(actual)
        if expected_len != actual_len:
            test_case.fail("Expected %d tokens, got %d: %s" %
                           (expected_len, actual_len, actual))

        # compare tokens one by one

# Generated at 2022-06-11 20:05:20.338137
# Unit test for function tokenize
def test_tokenize():
    import io

    r = io.StringIO(
        '''\
# This is a test Python program.
import sys
msg = "Hello, world!"
print(msg)\
'''
    )
    tokens = list(tokenize(r.readline))

# Generated at 2022-06-11 20:05:25.923253
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        yield b"# comment"
        yield b"# coding: utf8"
        yield b"text"
        yield b"more"
        yield StopIteration
    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == [b"# comment", b"# coding: utf8"]



# Generated at 2022-06-11 20:05:37.119203
# Unit test for function detect_encoding
def test_detect_encoding():
    def _fake_tokenize(s):
        try:
            tok = next(tokens)
        except StopIteration:
            return
        if s:
            yield 0, s
        while 1:
            yield tok
            try:
                tok = next(tokens)
            except StopIteration:
                break

    # Try with BOM
    lines = [b'\xef\xbb\xbf' +
             b"# coding: latin-1\n",
             b'print("foo")\n',
             ]
    tokens = _fake_tokenize(b"")
    encoding, consumed = detect_encoding(iter(lines).__next__)
    assert encoding == "iso-8859-1"
    for line in consumed:
        assert tokens.send(line) == 2

   

# Generated at 2022-06-11 20:05:41.440826
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize

    input = io.StringIO(
        '''for i in range(10): print(i)
... '''
    )
    with tokenize.tokenize(input.readline) as tokgen:
        for tok in tokgen:
            print(tok)



# Generated at 2022-06-11 20:05:44.898592
# Unit test for function generate_tokens
def test_generate_tokens():
    for t in generate_tokens(iter(["print\n"]).next):
        print(t)

if __name__ == "__main__":
    test_generate_tokens()


# Generated at 2022-06-11 20:05:49.062435
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield "encoding = 'utf-16'"

    assert detect_encoding(readline) == ("utf-16", ["encoding = 'utf-16'"])

