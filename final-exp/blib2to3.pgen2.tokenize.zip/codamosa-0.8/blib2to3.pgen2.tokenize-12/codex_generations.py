

# Generated at 2022-06-11 19:58:25.180169
# Unit test for function tokenize
def test_tokenize():
    s = \
    "while 1:\n" \
    "\ttry:\n" \
    "\t\tx = 'abc'\n" \
    "\t\traise ValueError\n" \
    "\texcept ValueError:\n" \
    "\t\tpass\n"
    tokenize(iter(s.splitlines()).__next__)


# Generated at 2022-06-11 19:58:33.565712
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from .tokenize_tests import generate_tokens_normalize, dedenter

    readline = StringIO(dedenter("""\
    def f():
      pass
    """))
    tokens = generate_tokens_normalize(readline.readline)
    tokens = list(tokens)
    assert tokens[0][1] == "def"



# Generated at 2022-06-11 19:58:41.671400
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    class MockIterable(list):

        def __iter__(self):
            return iter(self)

    lines = ["example_1 = '''"]
    lines.append('example_2 = """')
    lines.append("example_3 = '''")
    lines.append('example_4 = """')
    source = "\n".join(lines)
    untok = Untokenizer()
    result = untok.untokenize(tokenize(MockIterable(lines).__iter__))
    assert result == source


# Backwards compatible interface

# Generated at 2022-06-11 19:58:50.762881
# Unit test for function generate_tokens
def test_generate_tokens():
    def testtokenize(input, expected_tokens, **kwargs):
        tokens = list(tokenize(StringIO(input).readline, **kwargs))
        # Truncate the repr of each token to make the test output easier to read.
        tokens = [(type, repr(string[:40])) for type, string, start, end, line in tokens]
        assert tokens == expected_tokens

    testtokenize("", [])
    testtokenize("\x00", [
        (ERRORTOKEN, "'\\x00'"),
    ])
    testtokenize("\x00\n", [
        (ERRORTOKEN, "'\\x00'"),
        (NL, '\n'),
        (ENDMARKER, ''),
    ])

# Generated at 2022-06-11 19:58:57.473517
# Unit test for function generate_tokens
def test_generate_tokens():
    # Generate tokens from a string
    s = "for i in range(10): print(i)"
    result = list(tokenize.generate_tokens(io.StringIO(s).readline))
    for token in result:
        print(token)

# Run the unit test
test_generate_tokens()


# Generated at 2022-06-11 19:58:59.342821
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO


# Generated at 2022-06-11 19:59:08.429704
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import untokenize, NUMBER, STRING, NEWLINE, NAME, OP
    from io import StringIO
    from test.support import captured_stdout, captured_stdin, run_unittest


# Generated at 2022-06-11 19:59:17.511849
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"\xef\xbb\xbf# coding: latin-1\n"
        yield b"# comment\n"
        yield b"\n"

    assert detect_encoding(readline()) == ("iso-8859-1", [b"# coding: latin-1\n"])
    def readline():
        yield b"\xef\xbb\xbf# coding: ascii\n"
        yield b"# comment\n"
        yield b"\n"

    assert detect_encoding(readline()) == ("ascii", [b"# coding: ascii\n"])
    def readline():
        yield b"\xef\xbb\xbf# coding=ascii\n"
        yield b"# comment\n"
       

# Generated at 2022-06-11 19:59:21.393906
# Unit test for function tokenize
def test_tokenize():
    text = '''"abc" 'def' """ghi""" '''
    g = generate_tokens(iter(text.splitlines(True)).__next__)
    for tokt in g:
        print(tokt)



# Generated at 2022-06-11 19:59:32.606440
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def generate_tokens_example():
        from io import StringIO

        tokenize_loop(StringIO("def f(x, y=2):\n    return x ** y\n").readline, print)

    import sys

    generate_tokens_example()

    # Issue 3613: Check that tokenize_loop() doesn't modify its argument.
    # This is important because tokenize_loop() is called many times during
    # the execution of the test suite.
    if sys.flags.optimize < 2:
        import _testcapi

        _testcapi.crash_no_current_frame(2)



# Generated at 2022-06-11 20:00:00.369729
# Unit test for function detect_encoding

# Generated at 2022-06-11 20:00:05.627070
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(token, expected_type, expected_string, expected_start, expected_end, expected_line):
        assert token.type == expected_type, "%d != %d" % (token.type, expected_type)
        assert token.string == expected_string, "%r != %r" % (token.string, expected_string)
        assert (token.start, token.end) == (expected_start, expected_end), "(%d, %d) != (%d, %d)" % (token.start, token.end, expected_start, expected_end)
        assert token.line == expected_line, "%r != %r" % (token.line, expected_line)

    token = tokenize.TokenInfo(tokenize.NUMBER, "0", (1, 0), (1, 1), "\n")
    check_

# Generated at 2022-06-11 20:00:13.875567
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Utility functions
    def test_tokenize(code: Text) -> Iterator[Tuple[int, Text, Coord, Coord, Text]]:
        readline = code.splitlines().__iter__
        tokgen = generate_tokens(readline)
        for tok in tokgen:
            yield tok
        readline = code.splitlines().__iter__
        tokenize_loop(readline, lambda type, token, start, end, line: tokgen.send(
            (type, token, start, end, line)
        ))

# Generated at 2022-06-11 20:00:18.079440
# Unit test for function generate_tokens
def test_generate_tokens():
    program = r'''
while 1:
    print('foo'+"bar")
'''

    from .tokenize import generate_tokens

    for token in generate_tokens(program.splitlines):
        print(token)


# Generated at 2022-06-11 20:00:27.072067
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def test_tokenize_loop_run(readline, tokenizer):
        tokens = []
        tokenize_loop(readline, tokens.append)
        tokenizer(tokens)
    def test_tokenize_loop_single_line(readline, tokenizer):
        test_tokenize_loop_run(
            readline,
            lambda t: tokenizer(*t[0])
        )
    def test_tokenize_loop_run_iter(readline, tokenizer):
        test_tokenize_loop_run(
            readline,
            lambda t: tokenizer(iter(t))
        )

# Generated at 2022-06-11 20:00:33.272523
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'# foo\n'

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b'# -*- coding: latin-1 -*-\n', b'# foo\n']

    def readline():
        yield b"#\n"
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'# foo\n'

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-11 20:00:36.338435
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        for line in _tokenize_tests:
            yield line
        raise StopIteration

    stream = readline()
    tokeneater = printtoken
    tokenize_loop(stream.__next__, tokeneater)


# Generated at 2022-06-11 20:00:46.125014
# Unit test for function tokenize
def test_tokenize():
    global _error
    import io
    import token

    def test_tokenize_loop(readline, tokeneater):
        tokenize_loop(readline, tokeneater)

    def test():
        input = io.StringIO(
            """if 1:
        # Spam
        pass"""
        )
        it = iter(tokenize_loop(input.readline, tokeneater))
        token = next(it)
        assert token[0] == tokenize.NAME
        assert token[1] == "if"
        token = next(it)
        assert token[0] == tokenize.NUMBER
        assert token[1] == "1"
        token = next(it)
        assert token[0] == tokenize.OP
        assert token[1] == ":"
        token = next(it)

# Generated at 2022-06-11 20:00:57.588224
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # Test empty input
    u = Untokenizer()
    u.add_whitespace((1,0))
    assert u.prev_row == 1 and u.prev_col == 0
    assert u.tokens == []

    # Test empty token
    u = Untokenizer()
    u.add_whitespace((1,0))
    assert u.prev_row == 1 and u.prev_col == 0
    assert u.tokens == []

    # Test newline token
    u = Untokenizer()
    u.tokens.append("\n")
    u.add_whitespace((2,0))
    assert u.prev_row == 2 and u.prev_col == 0
    assert u.tokens == ["\n"]

    # Test invalid input
    u = Untokenizer()


# Generated at 2022-06-11 20:01:09.164103
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize

# Generated at 2022-06-11 20:01:42.307407
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:01:54.611358
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io, token
    from typing import List
    from .tokenize import tokenize_loop


# Generated at 2022-06-11 20:02:06.030708
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(1, "a")]) == "a"
    assert u.untokenize([(1, "a"), (1, "b")]) == "ab"
    assert u.untokenize([(1, "a"), (2, "b")]) == "a b"
    assert u.untokenize([(1, "a"), (3, 2, (0, 0), (0, 0), "")]) == "a 2"
    assert (
        u.untokenize([(1, "a"), (3, 2, (0, 2), (0, 3), ""), (1, "b")])
        == "a  2b"
    )

# Generated at 2022-06-11 20:02:12.552323
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize

    unt = Untokenizer()
    unt.compat(tokenize.tokenize(io.BytesIO("3x").readline), iter([]))
    assert unt.tokens == ["3 x "]
    unt = Untokenizer()
    unt.compat(tokenize.tokenize(io.BytesIO("\n if 1:\n    pass").readline), iter([]))
    assert unt.tokens == ["\n", " ", "if", " ", "1", ":", "\n", "    ", "pass"]



# Generated at 2022-06-11 20:02:25.134393
# Unit test for function generate_tokens
def test_generate_tokens():
    foo = Token(type=NUMBER, string='123', start=(1,0), end=(1,3))

    assert generate_tokens('123')[0] == foo
    assert generate_tokens('  123')[0] == foo
    assert generate_tokens('123  ')[0] == foo
    assert generate_tokens('  123  ')[0] == foo

    assert generate_tokens('foo')[0].type == NAME
    assert generate_tokens('foo ')[0].type == NAME

    assert generate_tokens('foo()')[0].type == NAME
    assert generate_tokens('foo()')[1].type == OP
    assert generate_tokens('foo()')[2].type == OP


# Generated at 2022-06-11 20:02:31.986428
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import tokenize

    untok = Untokenizer()
    f = StringIO("a = 10\n")
    untok.compat(next(tokenize(f.readline)), tokenize(f.readline))
    assert untok.untokenize(iter([])) == "a = 10 "


# Generated at 2022-06-11 20:02:41.848789
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from test.support import captured_stdout
    text = (
        "if 2 + 2 == 5:\n"
        "  print('unlikely')\n"
        "   \n"
        "def f():\n"
        "    return 42\n"
        "\n"
        "\n"
        "class C:\n"
        "    a = 0\n"
        "    b = 1\n"
    )
    stream = io.BytesIO()
    stream.write(text.encode("utf-8"))
    stream.seek(0)

    tokgen = tokenize.generate_tokens(stream.readline)

    untok = Untokenizer()

# Generated at 2022-06-11 20:02:47.802401
# Unit test for function tokenize
def test_tokenize():
    import tokenize
    import io
    import sys
    src = "a = 23 * 42\n"
    src = src.encode(sys.getdefaultencoding(), "replace")
    r = tokenize.BytesIO(src)
    r.mode = "<testfile>"
    tokenize.tokenize(r.readline, test_tokenize.tokeneater)



# Generated at 2022-06-11 20:02:58.810793
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    with open("tokenize_tests.txt") as fp:
        data = fp.read()
    readline = io.StringIO(data).readline
    tokengen = generate_tokens(readline)
    for expected in tokenize.tokenize(readline):
        got = next(tokengen)
        print(got, expected)
        assert expected == got
test_generate_tokens()
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 
 
 
 


# Generated at 2022-06-11 20:03:10.504570
# Unit test for function tokenize
def test_tokenize():
    def tokenize_print(type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
        (srow, scol) = xxx_todo_changeme2
        (erow, ecol) = xxx_todo_changeme3
        print('%d,%d-%d,%d:\t%s\t%s' % (srow, scol, erow, ecol, token.tok_name.get(type), repr(token)))

    import io
    import token
    tokenize_print = tokenize_print
    token = token
    readline = io.StringIO('for i in range(10): print(i)\n').readline
    tokenize(readline, tokenize_print)
    readline = io.StringIO

# Generated at 2022-06-11 20:03:40.024156
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    string = "def f():\n  a = 1\n  return\n"
    untok = Untokenizer()
    from io import StringIO

    untok.compat(tokenize(StringIO(string).readline).__next__(), tokenize(StringIO(string).readline))



# Generated at 2022-06-11 20:03:51.071073
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest

    from blib2to3.pgen2.tokenize import _tokenize

    class BytesIO(io.BytesIO):
        """A version of io.BytesIO that uses str as input."""

        def read(self, size=-1) -> bytes:
            """Read and return at most size bytes, instead of a str."""
            return super().read(size).encode("raw-unicode-escape")

    class TestTokenize(unittest.TestCase):
        def setUp(self):
            self.readline = self.pos = None

        def fake_open(self, filename):
            self.filename = filename
            self.buf = io.StringIO("\n".join(self.lines))
            self.encoding = "utf-8"
            return self.buf

       

# Generated at 2022-06-11 20:03:55.107062
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as real_tokenize

    r = io.BytesIO(b"print('abc')\n")
    def readline():
        return r.readline().decode("utf-8")
    lst = []
    tokenize(readline, lst.append)
    assert lst == real_tokenize.tokenize(r.readline)



# Generated at 2022-06-11 20:04:06.099065
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from .tokenize_rt import _python_tokenize as tokenize
    readline = StringIO("a = 1 + 2 + 3").readline
    tokens = []
    tokenize(readline, tokens.append)

# Generated at 2022-06-11 20:04:14.942393
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    def _gen_tokens(readline):
        for t in generate_tokens(readline):
            yield t

    text = """
        for i in range(10):
            print(i)
        """
    readline = iter(text.splitlines(keepends=True)).__next__
    tokens = list(_gen_tokens(readline))
    assert len(tokens) == 18
    assert tokens[0] == (
        NAME,
        "for",
        (2, 8),
        (2, 11),
        "        for i in range(10):\n",
    )
    assert tokens[1] == (NAME, "i", (2, 12), (2, 13), "        for i in range(10):\n")

# Generated at 2022-06-11 20:04:19.270547
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import token
    import io
    import sys

    readline = io.StringIO("a = 2 + 3\n").readline
    untok = Untokenizer()
    result = untok.untokenize(tokenize(readline))
    if result != "a = 2 + 3\n":
        print(f"Wrong result: {repr(result)}", file=sys.stderr)



# Generated at 2022-06-11 20:04:26.130034
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    r = StringIO(
        "  # Comment followed by an empty line\n\nfrom sklearn import datasets\n"
    )
    g = tokenize.generate_tokens(r.readline)
    for tok in g:
        print(tok)


if __name__ == "__main__":
    test_generate_tokens()


# Generated at 2022-06-11 20:04:29.622959
# Unit test for function tokenize
def test_tokenize():
    import io
    from tokenize import tokenize
    r = io.StringIO("print('hello world')").readline
    list(tokenize(r))
    return



# Generated at 2022-06-11 20:04:33.592197
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    src = "def f():\n  print('hello')"
    expected = "def f ( ):\n  print ( 'hello' ) "
    toks = generate_tokens(iter(src).__next__)
    actual = untok.untokenize(toks)
    assert actual == expected



# Generated at 2022-06-11 20:04:39.573591
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    from blib2to3.tokenize import tokenize
    from blib2to3.pygram import python_symbols as syms

    f = io.StringIO("import xyz\n")
    tok = Untokenizer()
    tokenize(f.readline, tok.compat)
    assert tok.tokens == ["import", " ", "xyz", "\n"]



# Generated at 2022-06-11 20:05:48.918798
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    ut.untokenize([(1, "a"), (2, "b"), (3, "c")])
    assert 1



# Generated at 2022-06-11 20:05:49.803235
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:06:01.394219
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import tokenize
    import io
    import re

    def get_tokens(in_text: str) -> List[TokenInfo]:
        """
        The yield statement
        """
        readline = io.BytesIO(in_text.encode()).readline
        tokens = tokenize.generate_tokens(readline)
        return list(tokens)


# Generated at 2022-06-11 20:06:08.490944
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:06:16.802177
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import tokenize, untokenize

    source = "a = 1\n"
    f = StringIO(source)

    class TokenInfo:
        pass

    ti = TokenInfo()
    ti.encoding = "utf-8"
    tokenized = tokenize(f.readline)
    try:
        while True:
            t = next(tokenized)
            setattr(ti, "type", t[0])
            setattr(ti, "string", t[1])
            setattr(ti, "start", t[2])
            setattr(ti, "end", t[3])
            setattr(ti, "line", t[4])
    except StopIteration:
        pass
    un = Untokenizer()

# Generated at 2022-06-11 20:06:21.237484
# Unit test for function tokenize
def test_tokenize():
    for filename in [
        "blib2to3/tests/data/tokenize_error.txt",
        "blib2to3/tests/data/tokenize_examples.txt",
    ]:
        with open(filename, "rb") as fp:
            tokenize(fp.readline)



# Generated at 2022-06-11 20:06:27.483476
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# foo"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# -*- coding: latin-1 -*-\n"]



# Generated at 2022-06-11 20:06:33.753698
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test whether tokenize_loop() works with a list, based on
    # the example in the Library Reference.
    from cStringIO import StringIO
    from token import UNKNOWN
    from tokenize import generate_tokens
    input = ["x = 1\n", 'print x\n']
    for token_info in generate_tokens(iter(input).next):
        print(token_info)

