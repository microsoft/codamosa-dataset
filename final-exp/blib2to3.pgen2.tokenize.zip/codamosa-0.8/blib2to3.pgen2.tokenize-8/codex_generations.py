

# Generated at 2022-06-11 19:58:16.354428
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test for Issue #9878: readline argument is required, readline=None fails
    inn = iter(
        [
            b"# coding=iso-8859-1\n",
            b'print("Raymond Hettinger" + " & '
            b'GvR")  # Latin-1 special characters\n',
            b"# coding=iso-8859-15\n",
            b"# coding=cp1252\n",
            b"# coding=ascii\n",
            b'from __future__ import print_function, unicode_literals\n',
        ]
    )
    iexpected = (
        "iso-8859-1",
        "iso-8859-15",
        "cp1252",
        "ascii",
        "ascii",
    )

# Generated at 2022-06-11 19:58:23.285102
# Unit test for function generate_tokens
def test_generate_tokens():
    input_string = '''\
if a > b:
  print(a)
  if a > b:
    print(a)
    print(b)
'''

# Generated at 2022-06-11 19:58:29.026103
# Unit test for function tokenize
def test_tokenize():
    for decode in (False, True):
        for encoding in ("utf-8", "utf-8-sig", "iso-8859-1"):
            for text in (b"\xc3\xa9", "\u00E9"):
                s = text.encode(encoding)
                if decode:
                    s += b'\n# coding: %s\n"%s"' % (encoding, text)
                else:
                    s += b'\n"%s"' % text
                toktypes = [NUMBER, STRING, NEWLINE, COMMENT, STRING]
                if decode:
                    toktypes = toktypes[-1:] + toktypes[:-1]
                tok = generate_tokens(BytesIO(s).readline)

# Generated at 2022-06-11 19:58:35.252879
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "a"
        yield "b"
        yield "c"
        yield ""
    #
    # Fake tokenize_loop()
    #
    readline_obj = readline()
    for token_info in generate_tokens(readline_obj.__next__):
        tokeneater(*token_info)


# TODO: Should this be an iterator? There's not really a good reason for it
# to be one.

# Generated at 2022-06-11 19:58:39.526264
# Unit test for function detect_encoding
def test_detect_encoding():
    # XXX: the following test is bogus, as it should have a readline mock.
    #      The test is commented out until someone care enough to fix it.
    ##    def readline():
    ##        yield b'# -*- coding: latin-1 -*-\n'
    ##    encoding, lines = detect_encoding(readline)
    ##    assert encoding == 'iso-8859-1', encoding
    ##    assert len(lines) == 1, lines
    pass



# Generated at 2022-06-11 19:58:46.052514
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        for s in _test_detect_encoding_lines:
            yield s.encode("utf-8")
            yield b"\n"

    def test(lines: List[str], expected_encoding: str) -> None:
        global _test_detect_encoding_lines
        _test_detect_encoding_lines = lines
        encoding, _ = detect_encoding(readline)
        assert encoding == expected_encoding

    test([], "utf-8")
    test([""], "utf-8")
    test(["# -*- coding: latin-1 -*-"], "iso-8859-1")
    test(["blah"], "utf-8")

# Generated at 2022-06-11 19:59:00.142713
# Unit test for function generate_tokens

# Generated at 2022-06-11 19:59:09.018642
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: iso8859-1 -*-"
        yield b"from __future__ import barry_as_FLUFL"
    encoding, lines = detect_encoding(readline)
    if encoding != "iso-8859-1":
        raise ValueError("wrong encoding: {!r}".format(encoding))
    if lines != [b"# -*- coding: iso8859-1 -*-"]:
        raise ValueError("wrong lines: {!r}".format(lines))

    def readline():
        yield b"# -*- coding: utf-8 -*-"
        yield b"from __future__ import barry_as_FLUFL"
    encoding, lines = detect_encoding(readline)

# Generated at 2022-06-11 19:59:13.711757
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    readline = io.BytesIO(
        b"if 1:\n\tprint('done')\n"
    ).readline
    with tokenize.tokenize(readline) as tokens:
        for token in tokens:
            print(token)



# Generated at 2022-06-11 19:59:25.991287
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        raise StopIteration

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])
    def readline():
        yield b"#!/usr/bin/python\n"
        yield b"# coding=utf-8\n"
        raise StopIteration
    assert detect_encoding(readline) == ("utf-8", [b"#!/usr/bin/python\n", b"# coding=utf-8\n"])
    def readline():
        yield b"\xef\xbb\xbf# coding: latin-1\n"
        raise StopIteration

# Generated at 2022-06-11 19:59:54.631546
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    # Tokenize the UTF-8 encoding declaration at the top of the file, and make
    # sure the encoding that tokenize ends up with matches the actual UTF-8
    # encoding.
    with open(__file__, "rb") as f:
        encoding = find_cookie(f)[0]
    with open(__file__, "rt", encoding=encoding) as f:
        result = [(x[0], x[1]) for x in tokenize.generate_tokens(f.readline)]
    if result[0][0] == tokenize.ENCODING:
        assert result[0][1] == encoding



# Generated at 2022-06-11 20:00:04.643671
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    u.compat((N_TOKENS, "N_TOKENS"), [])
    assert u.tokens == []
    u.compat((NAME, "NAME"), [])
    assert u.tokens == ["NAME "]
    u.compat((NEWLINE, "NEWLINE"), [])
    assert u.tokens == ["NAME ", "NEWLINE"]
    u.compat((INDENT, "INDENT"), [])
    assert u.tokens == ["NAME ", "NEWLINE"]
    u.compat((DEDENT, "DEDENT"), [])
    assert u.tokens == ["NAME ", "NEWLINE"]
    u.compat((NEWLINE, "NEWLINE"), [])

# Generated at 2022-06-11 20:00:08.024442
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    from ast import parse

    def test(s):
        f = io.StringIO(s)
        toks = [tok for tok in tokenize.generate_tokens(f.readline)]
        ptoks = [tok for tok in generate_tokens(f.readline)]
        for t1, t2 in zip(toks, ptoks):
            print(t1)
            print(t2)
            assert t1[:4] == t2[:4]
        # assert toks == ptoks


# Generated at 2022-06-11 20:00:10.656062
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    g = tokenize_loop(io.StringIO("# one\nred# two\nblue\n#three").readline, print)
    next(g)
    next(g)



# Generated at 2022-06-11 20:00:20.971371
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io

    text = "def f():\n    return"
    # Because the untokenize function is not intended to be used by end-users
    # directly, it is not covered by tests. Therefore, it is not in the
    # namespace of blib2to3.pgen2.tokenize and must be imported explicitly.
    from blib2to3.pgen2.tokenize import untokenize

    text = untokenize(generate_tokens(io.StringIO(text).readline))
    assert text == "def f ():\n    return "



# Generated at 2022-06-11 20:00:28.962720
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import *

    # Example showing how to use generate_tokens
    def tokenize_rows(code):
        gt = generate_tokens(StringIO(code).readline)
        for tok in gt:
            print(tok)

    # Example showing how to convert tokenize.generate_tokens
    # into a generator
    def get_tokens(code):
        gt = generate_tokens(StringIO(code).readline)
        tok = gt.send(None)
        while tok[0] is not ENDMARKER:
            yield tok
            tok = gt.send(None)

    # Test of the example code
    text = "1 + 1\n"
    tokenize_rows(text)
    assert list

# Generated at 2022-06-11 20:00:34.786694
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        raise NotImplementedError("this is just a test stub")

    orig_readline = readline

# Generated at 2022-06-11 20:00:45.776142
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    code = "a = 1 + 2"
    f = StringIO(code)
    tokens = []

    def tokeneater(*args):
        tokens.append(args)

    tokenize_loop(f.readline, tokeneater)
    expected = [
        (token.NAME, "a", (1, 0), (1, 1), "\n"),
        (token.EQUAL, "=", (1, 2), (1, 3), "\n"),
        (token.NUMBER, "1", (1, 4), (1, 5), "\n"),
        (token.PLUS, "+", (1, 6), (1, 7), "\n"),
        (token.NUMBER, "2", (1, 8), (1, 9), "\n"),
    ]
    assert tokens == expected

# Generated at 2022-06-11 20:00:57.351690
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize

    src = """\
    # Test multi-line list
    a = [
        1, 2, 3,
        4, 5, 6,
        ]
    # Test multi-line call
    f(
        1, 2, 3,
        4, 5, 6,
        )
    # Test multi-line string
    s = "\\
        Hello, World!\\
        "
    """
    tokens = list(generate_tokens(iter(src.splitlines(True)).__next__))

# Generated at 2022-06-11 20:01:08.824837
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # copied from tokens.py in cpython
    import io
    import unittest


    class UntokenizeTest(unittest.TestCase):
        def assertEqualTokens(self, tokenstream, expected):
            untok = Untokenizer()
            self.assertEqual(untok.compat(next(tokenstream), tokenstream), expected)


        def test_simple(self):
            # copied from test_tokenize
            stream = generate_tokens(io.StringIO("def f():\n\tpass\n").readline)
            self.assertEqualTokens(stream, "def f():\n\tpass\n")



# Generated at 2022-06-11 20:02:11.627786
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        raise StopIteration

    def readline_45():
        yield "This is the first line\n"

    def readline_5():
        yield "\n"

    def readline_45_5():
        yield "This is the first line\n"
        yield "\n"

    def readline_1():
        yield "#coding=latin-1\n"

    def readline_15():
        yield "#coding=latin-1\n"
        yield "\n"

    def readline_1_45():
        yield "#coding=latin-1\n"
        yield "This is the first line\n"

    def readline_1_45_42():
        yield "#coding=latin-1\n"
        yield "This is the first line\n"
       

# Generated at 2022-06-11 20:02:24.381368
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def eat_token(type, t, srow_scol, erow_ecol, line):
        assert type == tokenize.COMMENT
        assert t == "#bla\n"
        assert srow_scol == (1, 0)
        assert erow_ecol == (2, 4)
        assert line == t

    # should be able to accept a string
    s = "#bla\n  \n"
    it = tokenize_loop(s.splitlines().__iter__(), eat_token)
    try:
        next(it)
    except StopIteration:
        pass

    # ...or a callable object
    class Callable:
        def __init__(self, s):
            self.lines = s.splitlines()
            self.n = 0


# Generated at 2022-06-11 20:02:37.095561
# Unit test for method compat of class Untokenizer

# Generated at 2022-06-11 20:02:45.244687
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline() -> Iterator[bytes]:
        yield b" # coding: latin-1\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"\x00\x00\x00\x00\x00\x00\x00\x00\x00" + BOM_UTF8 + b"\x00\x00\x00\x00"
        yield b" #coding:utf-8\n"
        yield b" # coding=utf-8\n"
        yield b" #coding=ISO-8859-2\n"
        yield b" # coding=cp65001\n"
        yield b" # coding: utf-8-sig\n"
        yield b" # coding: cp65001\n"

    assert detect_

# Generated at 2022-06-11 20:02:55.595865
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    try:
        import __main__

        __main__.__dict__.clear()
        __main__.__dict__.update({"__name__": "__main__", "__file__": "untokenize"})
    except (ImportError, AttributeError):
        pass
    # import sys, tokenize


# Generated at 2022-06-11 20:03:07.876956
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def untokens(s):
        return Untokenizer().untokenize(generate_tokens(iter(s).__next__))

    # Test issue #22356
    assert untokens("('')") == "('') "

    assert untokens("async \\\n  def f():\n  pass") == "async \\\n  def f():\n  pass "
    assert untokens("class F:\n  pass\nx = F()") == "class F:\n  pass\nx = F() "

    # Test issue #23552
    assert untokens("x = F()\nclass F: pass") == "x = F()\nclass F: pass "

    # Tests issue #25194
    assert untokens("\na = 1") == "\n\na = 1 "
   

# Generated at 2022-06-11 20:03:20.103910
# Unit test for function detect_encoding
def test_detect_encoding():
    def _test(s, expected_encoding, expected_lines):
        lines = []
        def readline():
            try:
                return s.pop(0)
            except IndexError:
                raise StopIteration
        encoding, lines = detect_encoding(readline)
        assert expected_encoding == encoding
        assert expected_lines == lines

    _test([b"# -*- coding: ascii -*-"], "ascii", [b"# -*- coding: ascii -*-"])
    _test([b"# coding=ascii"], "ascii", [b"# coding=ascii"])
    _test([b"#!/usr/bin/python"], "utf-8", [b"#!/usr/bin/python"])

# Generated at 2022-06-11 20:03:31.505813
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    token_list = []
    with io.StringIO('spam\n#comment\n#comment=eggs') as f:
        def tokeneater(*args):
            token_list.append(args)
        tokenize.tokenize_loop(f.readline, tokeneater)
    assert token_list == [
        (token.NAME, 'spam', (1, 0), (1, 4), 'spam\n'),
        (token.COMMENT, '#comment', (2, 0), (2, 7), '#comment\n'),
        (token.COMMENT, '#comment=eggs', (3, 0), (3, 14), '#comment=eggs'),
    ]


# Generated at 2022-06-11 20:03:38.914732
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        for i, line in enumerate(tokenize_loop.test_cases.split('\n')):
            yield f"{i+1:02}: {line}\n"
    tokenize_loop.test_cases = """def f(x):
    return x + 1
"""

# Generated at 2022-06-11 20:03:45.252366
# Unit test for method add_whitespace of class Untokenizer

# Generated at 2022-06-11 20:04:33.262194
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline(n):
        if n == 0:
            return "<?xml version='1.0' encoding='utf8'?>\n".encode("utf-8")
        raise StopIteration

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8", "wrong encoding detected"
    assert lines == [b"<?xml version='1.0' encoding='utf8'?>\n"], lines

    del readline

    def readline(n):
        if n == 0:
            return "# -*- coding: utf-8 -*-\n".encode("utf-8")
        elif n == 1:
            return "# coding=utf-8\n".encode("utf-8")
        raise StopIteration

    encoding, lines = detect_encoding(readline)

# Generated at 2022-06-11 20:04:44.476716
# Unit test for function generate_tokens
def test_generate_tokens():
    """generate_tokens() returns tokens with the right line numbers."""
    import StringIO
    import token
    import tokenize
    stream = StringIO.StringIO("1\n22\n\n333\n4444\n")
    gt = tokenize.generate_tokens(stream.readline)
    for toknum, tokval, _, (sr, sc), _ in gt:
        if toknum == token.NUMBER and tokval != "1":
            raise AssertionError(
                "tokenize did not return NUMBER tokens with "
                "the right start row"
            )

# Generated at 2022-06-11 20:04:47.333276
# Unit test for function detect_encoding
def test_detect_encoding():
    import pdb

    def _run_tests(tests: List[Tuple[bytes, str]]) -> None:
        for test in tests:
            yield (test,)

# Generated at 2022-06-11 20:04:57.870320
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO

    def readline():
        yield b"\n"

    def readline():
        yield b"# -*- coding: latin-1 -*-\n"

    def readline():
        yield b"\xef\xbb\xbf# coding=utf-8\n"

    def readline():
        yield b"\xef\xbb\xbf# coding=ascii\n"

    def readline():
        for x in [
            b"\n",
            b"# coding: ascii\n",
            b"\n",
            b"# coding=utf-8\n",
            b"# coding=latin-1\n",
        ]:
            yield x


# Generated at 2022-06-11 20:05:08.796950
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return "print(37)\n"
    token_list = []
    tokenize_loop(readline, token_list.append)

# Generated at 2022-06-11 20:05:15.322105
# Unit test for function generate_tokens
def test_generate_tokens():
    #import sys
    #if sys.hexversion < 0x020400f0:
    #    raise RuntimeError("tokenize.generate_tokens needs Python 2.4 or later")
    import StringIO
    s = StringIO.StringIO("for i in range(10): print(i)\n")
    for tok in generate_tokens(s.readline):
        print(tok)



# Generated at 2022-06-11 20:05:28.253102
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def check(input: str, output: str) -> None:
        assert untokenize(tokenize(iter(input).__next__)).rstrip("\n") == output

    check("", "")
    check(" ", " ")
    check("1", "1 ")
    check("1 2", "1 2 ")
    check("1 2\n", "1 2\n")
    check("1 2\n3", "1 2\n3 ")
    check("1 2\n3 4", "1 2\n3 4 ")
    check("\n", "\n")
    check("\n\n", "\n\n")
    check("a\nb", "a\nb")
    check("a\n  b", "a\n  b")

# Generated at 2022-06-11 20:05:35.620501
# Unit test for function generate_tokens
def test_generate_tokens():
    g = generate_tokens(iter(['print "test!"\n']).next)
    assert list(g) == [
        (NAME, 'print', (1, 0), (1, 5), 'print "test!"\n'),
        (STRING, '"test!"', (1, 6), (1, 12), 'print "test!"\n'),
        (NEWLINE, '\n', (1, 12), (1, 13), 'print "test!"\n'),
        (ENDMARKER, '', (2, 0), (2, 0), ''),
    ]


# Generated at 2022-06-11 20:05:41.915180
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"a=1\n"
        yield b"\xb2\n"
        yield b"\xf4\n"
    encoding, consumed = detect_encoding(readline)
    assert consumed == [b"# -*- coding: latin-1 -*-\n", b"a=1\n"]
    assert encoding == "iso-8859-1"



# Generated at 2022-06-11 20:05:54.698168
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in test_lines:
            yield line

    # callable that raises StopIteration when called
    def stop():
        raise StopIteration

    test_lines_1 = [
        b"# coding: utf-8\n",
        b'print "hello, world"\n',
        b'print "vikings", "are", "coming!"\n',
    ]
    test_lines_2 = [b"#!/usr/bin/env python\n", b"\n", b"print 'hi'\n"]
    test_lines_3 = [b"#!/usr/bin/python\n", b"# -*- coding: latin-1 -*-\n", b"print 'hola'\n"]