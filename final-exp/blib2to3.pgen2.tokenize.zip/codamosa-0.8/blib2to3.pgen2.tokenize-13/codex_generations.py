

# Generated at 2022-06-11 19:58:20.721036
# Unit test for function detect_encoding
def test_detect_encoding():
    _, lines = detect_encoding(
        lambda: b"# -*- coding: utf-8 -*-\n"
        + b"# nothing except utf-8\n"
        + b""
    )
    assert lines == [b"# -*- coding: utf-8 -*-\n", b"# nothing except utf-8\n"]
    _, lines = detect_encoding(lambda: b"\xef\xbb\xbf\n" + b"# nothing except utf-8\n")
    assert lines == [b"\xef\xbb\xbf\n", b"# nothing except utf-8\n"]

# Generated at 2022-06-11 19:58:32.939178
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(token_type, token_string, start, end, line):
        assert token_type == token[0]
        assert token_string == token[1]
        assert start == token[2]
        assert end == token[3]
        assert line == token[4]

    from io import StringIO

    buf = StringIO("here = (1)")
    for token in generate_tokens(buf.readline):
        check_token(token, (NAME, "here", (1, 0), (1, 4), "here = (1)"))
        check_token(token, (OP, "=", (1, 5), (1, 6), "here = (1)"))
        check_token(token, (OP, "(", (1, 7), (1, 8), "here = (1)"))
       

# Generated at 2022-06-11 19:58:44.198085
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from unittest import TestCase


# Generated at 2022-06-11 19:58:49.626776
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()
    untokenizer.tokens = ["abc", "def"]
    untokenizer.prev_row = 1
    untokenizer.prev_col = 3
    untokenizer.add_whitespace((1, 5))
    if untokenizer.tokens != ["abc", "  def"]:
        raise ValueError("unexpected result")


_escape = {"'": "\'", '"': '"', "\\": "\\"}



# Generated at 2022-06-11 19:59:02.802039
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline():
        raise StopIteration

    assert detect_encoding(readline) == ("utf-8", [])

    def readline():
        yield b"# coding: latin-1\n"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# coding: latin-1\n"])

    def readline():
        yield BOM_UTF8 + b"# coding: latin-1\n"

    assert detect_encoding(readline) == (
        "utf-8-sig",
        [BOM_UTF8 + b"# coding: latin-1\n"],
    )

    def readline():
        yield b'\xff\xfe# coding: latin-1\n'


# Generated at 2022-06-11 19:59:11.332329
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test roundtrip of token generation, with and without whitespace.
    source_chars = "a = 1"
    source_tokens = [(NAME, "a", (1, 0), (1, 1), "a = 1"),
            (OP, "=", (1, 2), (1, 3), "a = 1"),
            (NUMBER, "1", (1, 4), (1, 5), "a = 1"),
            (NEWLINE, "\n", (1, 5), (1, 6), "a = 1"),
            (ENDMARKER, "", (2, 0), (2, 0), "")]
    new_chars = untokenize(source_tokens)
    new_tokens = list(tokenize(BytesIO(new_chars.encode("utf-8")).readline))

# Generated at 2022-06-11 19:59:14.467961
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    tmp = u.compat(token.NAME, None)
    assert tmp is None
    assert u.tokens[0] == " "
    assert u.tokens[0] == token.NAME

# Generated at 2022-06-11 19:59:17.395249
# Unit test for function tokenize
def test_tokenize():
    """Simple unit test for tokenize"""
    import io
    import token
    r = io.StringIO(
        "if 1:\n print(2)\n"
    )  # An arbitrary input source
    tokenize(r.readline, tokeneater=token.printtoken)



# Generated at 2022-06-11 19:59:27.535836
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    r = io.StringIO("def x(): pass\n")
    l = []
    tokenize.tokenize_loop(r.readline, l.append)
    # tokenize_loop uses printtoken, so these tests
    # don't match.
    assert len(l) == 8
    assert l[0][0] == token.ENCODING
    assert l[1][0] == token.NEWLINE
    assert l[2][0] == token.NAME and l[2][1] == "def"
    assert l[3][0] == token.NAME and l[3][1] == "x"
    assert l[4][0] == token.OP and l[4][1] == "("

# Generated at 2022-06-11 19:59:33.322729
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from pprint import pprint


# Generated at 2022-06-11 20:00:01.906527
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:00:07.157391
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(tok, type, text, start, end, line):
        tok_type, tok_text, tok_start, tok_end, tok_line = tok
        if (tok_type != type or tok_text != text or tok_start != start or
            tok_end != end or tok_line != line):
            print("bad token", tok, "should be", (type, text, start, end, line))

    def check_untokenize(input, output):
        result = untokenize(input)
        if result != output:
            print("bad untokenize", input, "should be", output)
            print("got", result)

    tokenize_file(check_token, "tokenize_tests.txt")

# Generated at 2022-06-11 20:00:13.978866
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    test_seq = [
        (NAME, "if"),
        (OP, "<"),
        (NAME, "x"),
        (OP, "<"),
        (NAME, "y"),
        (COLON, ":"),
        (NEWLINE, "\n"),
        (INDENT, "\n    "),
        (NAME, "return"),
        (NAME, "x"),
        (DEDENT, "\n"),
    ]
    res = u.compat(test_seq[0], test_seq[1:])
    assert u.tokens == ["\n", "if ", "< ", "x ", "< ", "y ", ":", "\n", "\n", "    "]
    assert res is None



# Generated at 2022-06-11 20:00:24.564516
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    # test multiple readline calls per logical line
    f = io.StringIO("def f():\n    pass\n")
    toks = []  # type: List[tokenize.TokenInfo]
    tokenize.tokenize(lambda: f.readline(), toks.append)
    toktypes = [tok[0] for tok in toks]
    assert toktypes == [
        token.NAME,
        token.NAME,
        token.OP,
        token.OP,
        token.NEWLINE,
        token.INDENT,
        token.NAME,
        token.NEWLINE,
        token.DEDENT,
    ]
    f = io.StringIO("def f():\n    pass\n")
    toks = []  # type: List

# Generated at 2022-06-11 20:00:34.966535
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    for g in generate_tokens, _generate_tokens:
        s = StringIO("def f(a): return a + 1\n")
        expected = [
            (NAME, 'def'),
            (NAME, 'f'),
            (OP, '('),
            (NAME, 'a'),
            (OP, ')'),
            (OP, ':'),
            (NEWLINE, '\n'),
            (INDENT, ''),
            (NAME, 'return'),
            (NAME, 'a'),
            (OP, '+'),
            (NUMBER, '1'),
            (NEWLINE, '\n'),
            (DEDENT, ''),
            (ENDMARKER, ''),
        ]
        got = list(g(s.readline))
        assert expected == got

# Generated at 2022-06-11 20:00:40.549045
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from blib2to3.tests import support

    readline = support.make_reading_function(["abc", "def"])
    def tokeneater(*args):
        print(args)

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-11 20:00:52.299952
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import tokenize

# Generated at 2022-06-11 20:00:54.756753
# Unit test for function tokenize
def test_tokenize():
    import io

    with io.StringIO("spam = 23") as f:
        tokenize(f.readline, printtoken)



# Generated at 2022-06-11 20:01:05.706605
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    for expr, want in [
        ('2 ** 3', '2 3 **'),
        ('x**-1', 'x 1 - **'),
        ('b < c and c < d', 'b c < c d < and'),
        ]:
        text = 'print (%s)' % expr
        s = StringIO(text)
        got = ' '.join(tok[1] for tok in generate_tokens(s.readline))
        assert got == want, '%r => %r' % (text, got)
test_generate_tokens()

if __name__ == '__main__':
    for line in sys.stdin:
        for t in generate_tokens(StringIO(line).readline):
            print(t)

# Generated at 2022-06-11 20:01:18.085800
# Unit test for function generate_tokens
def test_generate_tokens():
    # This unit test shows what the tokens are for a few cases.
    import io
    import tokenize

    s = "def f(x): return 2*x\n"
    g = tokenize.generate_tokens(io.StringIO(s).readline)  # type: ignore
    print("Source:", s)
    print("Tokenized:")
    print(g)
    for token in g:
        print(token)

    s = "def g(m):\n    return m+1\n"
    g = tokenize.generate_tokens(io.StringIO(s).readline)  # type: ignore
    print("Source:", s)
    print("Tokenized:")
    print(g)
    for token in g:
        print(token)


# Generated at 2022-06-11 20:02:13.378840
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:02:16.163724
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    import tokenize

# Generated at 2022-06-11 20:02:22.762744
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import tokenize

    def g():
        for i in range(10):
            yield str(i)

    print(
        Untokenizer().compat(
            (tokenize.NAME, "as"),
            ((tokenize.NAME, "as"), (tokenize.NUMBER, "1"), (tokenize.NEWLINE, "\n")),
        )
    )



# Generated at 2022-06-11 20:02:30.303902
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import token
    import tokenize

    if __name__ == "__main__":
        def readline() -> bytes:
            return bytes(input(), "utf-8")

        tokenize_loop = tokenize.tokenize(readline)
        tok = tokenize_loop.__next__()
        if tok[0] == token.ENCODING:
            print(tok[1])
    else:
        f = io.BytesIO(
            b"""\
# coding=utf-8
# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# this is the "hello, world" program
msg = "Hello, World"
print(msg)
"""
        )
        encoding, lines = detect_encoding(f.readline)
    assert encoding == "utf-8"

# Generated at 2022-06-11 20:02:40.796600
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def tokenize_loop_return_tokens(readline, tokeneater):
        tokeneater.tokens = []
        try:
            tokenize_loop(readline, tokeneater)
        except StopTokenizing:
            return tokeneater.tokens

    readline = iter(['def f(((x))):  # comment\n  return x\n']).__next__
    tokeneater = lambda *args: tokeneater.tokens.append(args)
    tokens = tokenize_loop_return_tokens(readline, tokeneater)
    first_token = tokens[0]
    assert first_token[:2] == (NAME, 'def')
    last_token = tokens[-1]

# Generated at 2022-06-11 20:02:51.709106
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline_test1() -> bytes:
        return b"# -*- coding: iso-8859-1 -*-\012"

    def readline_test2() -> bytes:
        return b"# coding: 'iso-8859-1'\012"

    def readline_test3() -> bytes:
        return b"# coding: utf-8\012"

    def readline_test4() -> bytes:
        return b"\xEF\xBB\xBF"

    def readline_test5() -> bytes:
        return b"\xEF\xBB\xBF# -*- coding: iso-8859-1 -*-\012"

    def readline_test6() -> bytes:
        return b"\xFE\xFF\x00a"


# Generated at 2022-06-11 20:03:04.505713
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(token_test):
        r = tokenize.generate_tokens(token_test[0].__call__)
        for i in range(len(token_test[1])):
            tok = r.next()
            assert tok[0:2] == token_test[1][i][0:2]
    try:
        tokenize.tokenize
    except AttributeError:
        print("WARNING: tokenize module is not supporting tokenize\n")
        return
    check_token(tokenize_tests[0])
    check_token(tokenize_tests[1])
    check_token(tokenize_tests[2])
    check_token(tokenize_tests[3])
    check_token(tokenize_tests[4])

    # test round trip by tokenizing a test file
   

# Generated at 2022-06-11 20:03:10.070187
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    l = ["spam", "eggs"]
    l_gen = iter(l)
    def get_token():
        try:
            return next(l_gen)
        except StopIteration:
            raise StopTokenizing
    res = u.compat((NAME, "for"), get_token)
    assert res == None
    assert u.tokens == ["for "]


# Generated at 2022-06-11 20:03:18.566692
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    iterable = [
        (NAME, "a"),
        (NUMBER, "9"),
        (OP, "+"),
        (NUMBER, "0"),
        (NEWLINE, ""),
        (NAME, "b"),
        (OP, "="),
        (NAME, "a"),
        (OP, "+"),
        (NUMBER, "9"),
        (NEWLINE, ""),
    ]
    untok.compat(iterable[0], iterable[1:])
    print(" ".join(untok.tokens))


# Generated at 2022-06-11 20:03:30.474097
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    default = "utf-8"
    bom_default = "utf-8-sig"

    # Empty or just a bom
    assert detect_encoding(io.BytesIO(b"").readline) == (default, [])
    assert detect_encoding(io.BytesIO(BOM_UTF8).readline) == (bom_default, [])

    # Empty or just whitespace
    assert detect_encoding(io.BytesIO(b" ").readline) == (default, [b" "])
    assert detect_encoding(io.BytesIO(b"\n  \t  \r ").readline) == (default, [b"\n  \t  \r "])

    # Whitespace + comments

# Generated at 2022-06-11 20:04:55.622375
# Unit test for function tokenize_loop
def test_tokenize_loop():
    tokeneater = printtoken
    readline = "".join(open("Lib/tokenize.py").readlines())
    tokenize_loop(readline, tokeneater)


# Generated at 2022-06-11 20:04:57.919539
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize
    r = io.StringIO("1 + 1\n")
    t = tokenize.tokenize(r.readline)
    print(next(t)[:2])
    print(next(t)[:2])



# Generated at 2022-06-11 20:05:08.892675
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize


# Generated at 2022-06-11 20:05:10.926447
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    import tokenize

    def noop(*args):
        pass


# Generated at 2022-06-11 20:05:19.955628
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens, tok_name
    from unittest.mock import patch

    with patch.object(StringIO, "readline", return_value=""):
        for token in generate_tokens(lambda: ""):
            assert False, f"Did not expect iteration to get {tok_name[token[0]]}"
        else:
            assert True

    with patch.object(
        StringIO, "readline", return_value='"double quotes"'
    ) as mock_iter:
        token = next(generate_tokens(mock_iter))
        assert token[0] == tokenize.STRING
        assert token[1] == '"double quotes"'


# Generated at 2022-06-11 20:05:26.018669
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from blib2to3.pgen2.token import generate_tokens
    r = Untokenizer()
    for token in generate_tokens(StringIO("next(x for x in range(10))").readline):
        print(token)
    print(r.untokenize(generate_tokens(StringIO("next(x for x in range(10))").readline)))


# Generated at 2022-06-11 20:05:37.196301
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in [
            "# -*- coding: latin-1 -*-",
            "a = 1",
            "",
            "# foo",
            "b = 2",
        ]:
            yield line

    assert detect_encoding(readline) == ("iso-8859-1", ["# -*- coding: latin-1 -*-\n"])

    def readline():
        for line in ["# vim:fileencoding=latin-1", "a = 1", "", "# foo", "b = 2"]:
            yield line

    assert detect_encoding(readline) == ("iso-8859-1", ["# vim:fileencoding=latin-1\n"])


# Generated at 2022-06-11 20:05:45.979904
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> Text:
        raise RuntimeError("shouldn't call this")

    assert detect_encoding(readline) == ("utf-8", [])

    def readline() -> Text:
        yield ""

    assert detect_encoding(readline) == ("utf-8", [])

    def readline() -> Text:
        yield "# coding: latin-1\n"

    assert detect_encoding(readline) == ("iso-8859-1", ["# coding: latin-1\n"])

    def readline() -> Text:
        yield "#!/usr/bin/python\n"
        yield "# blah blah blah\n"
        yield "# coding: latin-1\n"


# Generated at 2022-06-11 20:05:58.859423
# Unit test for function generate_tokens
def test_generate_tokens():
    # A generator that produces a stream of tokens from a string
    def generate_tokens_from_string(s: str) -> Iterator[GoodTokenInfo]:
        for line in s.splitlines(keepends=True):
            yield from generate_tokens(iter([line]).__next__)


# Generated at 2022-06-11 20:06:07.241684
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        if not lines:
            raise StopIteration
        line = lines.pop(0)
        if isinstance(line, bytes):
            return line
        return line.encode("ascii")

    def readlines_until(stop_line: int) -> List[bytes]:
        result = []
        while lines:
            line = readline()
            if line.strip() == stop_line:
                break
            result.append(line)
        return result

    def test_encoding(
        lines: List[Union[str, bytes]],
        expected_encoding: Text,
        expected_lines: List[bytes],
    ) -> None:
        global lines
        lines = lines[:]
        actual_encoding, actual_lines = detect_encoding(readline)
        assert actual