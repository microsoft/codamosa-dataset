

# Generated at 2022-06-11 19:57:31.965094
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize

# Generated at 2022-06-11 19:57:43.231744
# Unit test for function detect_encoding
def test_detect_encoding():

    def reader(s):
        for c in s:
            yield bytes(c, "ASCII")

    def readlines(sep, lines):
        total = sep.join(lines)
        return reader(total)

    def check_encoding(sep, lines, encoding, first_lines):
        readline = readlines(sep, lines)
        obtained_encoding, obtained_lines = detect_encoding(readline)
        assert obtained_encoding == encoding, (
            "got %r, expected %r" % (obtained_encoding, encoding)
        )
        if first_lines is not None:
            assert obtained_lines == list(map(bytes, first_lines)), (
                "got %r, expected %r" % (obtained_lines, first_lines)
            )


# Generated at 2022-06-11 19:57:48.068545
# Unit test for function generate_tokens

# Generated at 2022-06-11 19:57:59.907961
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        # returns a next line including newline character or
        # StopIteration if there is no more lines
        line = input_stream.readline()
        if line:
            return line
        raise StopIteration

    # example 1
    input_stream = io.BytesIO(b"abc='#coding:euc-jp'")
    assert detect_encoding(readline) == ("euc-jp", [b"abc='#coding:euc-jp'"])

    # example 2

# Generated at 2022-06-11 19:58:09.717102
# Unit test for function detect_encoding
def test_detect_encoding():
    from blib2to3.pgen2.tokenize import detect_encoding, StringIO


# Generated at 2022-06-11 19:58:19.300454
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

# Generated at 2022-06-11 19:58:22.207011
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize

    tokenize.tokenize_loop(io.BytesIO(b"def f():\n\tpass\n").readline, print)



# Generated at 2022-06-11 19:58:34.647449
# Unit test for function generate_tokens

# Generated at 2022-06-11 19:58:40.780572
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"#!/usr/bin/python3"
        yield b""
        yield b""
        yield b"# -*- coding: latin-1 -*-"
        yield b"# -*- coding: iso-8859-1 -*-"
        yield b""
        yield b"print('Alphabet')"

    assert detect_encoding(readline) == ("iso-8859-1", [b"#!/usr/bin/python3", b""])

    def readline():
        yield b"# -*- coding: unknown -*-"
        yield b""

    try:
        detect_encoding(readline)
    except SyntaxError as e:
        assert str(e) == "unknown encoding: unknown"
    else:
        assert False, "expected exception"


# Generated at 2022-06-11 19:58:43.523694
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # This is a really simple test.
    t = Untokenizer()
    assert t.compat((1, "a"), [(2, "b")]) == None
test_Untokenizer_compat()



# Generated at 2022-06-11 19:59:22.227803
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield "a"

    def readline():
        yield '\xff'
        yield '# -*- coding: latin-1 -*-'
        raise StopIteration

    for readline in [readline, readline]:
        assert detect_encoding(readline) == ("ascii", ["a"])
    import io

    def readline():
        yield io.BytesIO("# -*- coding: latin-1 -*-\nabc".encode("latin-1")).readline()

    assert detect_encoding(readline) == ("iso-8859-1", [])



# Generated at 2022-06-11 19:59:35.781683
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "for i in range(10): print(i)\n"
    tokens = []

    def tokeneater(*args):
        tokens.append(args)
    tokenize_loop(s.__iter__().__next__, tokeneater)

# Generated at 2022-06-11 19:59:39.025567
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    s = io.StringIO('for x in range(10): print(x*x)\n')
    # Feed the tokenizer some input
    readline = s.readline
    tokenize_loop(readline, printtoken)



# Generated at 2022-06-11 19:59:49.856203
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test of multiple iterators
    gen1 = generate_tokens(iter(['hey(1,2)\n', 'hoo(3,4)\n']).__next__)
    gen2 = generate_tokens(iter(['hey(1,2)\n', 'hoo(3,4)\n']).__next__)
    for token1 in gen1:
        print("TOKEN1")
        print(token1)
        break
    for token2 in gen2:
        print("TOKEN2")
        print(token2)
        break

test_generate_tokens()
 
gen = generate_tokens(iter(['hey(1,2)\n', 'hoo(3,4)\n']).__next__)
for token in gen:
    print(token)
# Unit test

# Generated at 2022-06-11 19:59:59.256922
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    untok_text = u.untokenize([(57, 'i'), (0, '0'), (1, '#'), (0, '1'), (57, 'i'), (0, '0'), (1, '#'), (0, '1'), (1, '{'), (4, '\n'), (56, '    '), (1, '}'), (4, '\n'), (0, '2'), (1, '#'), (0, '2'), (1, '{'), (4, '\n'), (56, '    '), (1, '}'), (4, '\n')])
    assert untok_text == 'i0#1i0#1{    }2#2{    }', "Wrong untokenization."



# Generated at 2022-06-11 20:00:04.513297
# Unit test for function generate_tokens
def test_generate_tokens():
    import re
    import io
    import token
    import tokenize
    from typing import Tuple

    # This is the grammar used:
    #
    # seq_stmt: simple_stmt NEWLINE | compound_stmt
    # simple_stmt: small_stmt (';' small_stmt)* [';'] NEWLINE
    # small_stmt: (expr_stmt | del_stmt | pass_stmt | flow_stmt |
    #              import_stmt | global_stmt | nonlocal_stmt | assert_stmt)
    # del_stmt: 'del' exprlist
    # pass_stmt: 'pass'
    # flow_stmt: break_stmt | continue_stmt | return_stmt | raise_stmt | yield_stmt
    # break_stmt: 'break

# Generated at 2022-06-11 20:00:09.525456
# Unit test for function generate_tokens
def test_generate_tokens():
    def remove_linebreaks(s):
        return s.replace("\n", "\\n").replace("\r", "\\r")
    def test_generate_tokens():
        def get_tokens(tokens, token_types=False):
            return [(t if token_types else remove_linebreaks(t)) for _s, t, _e, _l, _line in tokens]
        # The following tests are copied from the tokenize module
        # test_generate_tokens:
        s = "def f(x):\n return x\n"
        g = generate_tokens(StringIO(s).readline)

# Generated at 2022-06-11 20:00:12.916352
# Unit test for function printtoken
def test_printtoken():
    from io import BytesIO

    file = BytesIO(b"\"\n'\"'")
    printtoken(*next(generate_tokens(file.readline)))
    printtoken(*next(generate_tokens(file.readline)))
    printtoken(*next(generate_tokens(file.readline)))



# Generated at 2022-06-11 20:00:21.270450
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    iterable = [
        (NAME, "if"),
        (NAME, "x"),
        (OP, "|"),
        (NAME, "y"),
        (COLON, ":"),
        (INDENT, "    "),
        (NAME, "print"),
        (OP, "+"),
        (NAME, "x"),
    ]
    equal = untok.compat, iterable
    equal(untok.tokens, ["if x | y : \n", "    print + x "])



# Generated at 2022-06-11 20:00:33.659086
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize

    s = "def f(x): pass\n"
    f = io.StringIO(s)
    l = []
    def tokeneater(*args):
        l.append(args)

    tokenize.tokenize_loop(f.readline, tokeneater)

# Generated at 2022-06-11 20:01:07.099596
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'some text'

    encoding, _ = detect_encoding(readline)
    assert encoding == 'iso-8859-1'
    def readline():
        yield b'\xef\xbb\xbf# coding: ascii\n'
        yield b'some text'

    encoding, _ = detect_encoding(readline)
    assert encoding == 'ascii'
    def readline():
        yield b'\xef\xbb\xbf# -*- coding: ko_KR.eucKR -*-\n'
        yield b'some text'

    encoding, _ = detect_encoding(readline)
    assert encoding == 'euc-kr'

# Generated at 2022-06-11 20:01:12.318732
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-'
        yield b''
    encoding, lines = detect_encoding(readline)
    assert encoding == 'iso-8859-1'
    assert lines == [b'# -*- coding: latin-1 -*-', b'']



# Generated at 2022-06-11 20:01:23.900214
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest


    class TestTokenize(unittest.TestCase):
        def check_tokenize(self, input, tokens_list):
            stream = io.StringIO(input)

            def readline():
                return stream.readline()

            gen = generate_tokens(readline)
            for values_token in gen:
                token = TokenInfo(*values_token)
                self.assertEqual(token.type, tokens_list[0])
                self.assertEqual(token.string, tokens_list[1])
                self.assertEqual(token.start, tokens_list[2])
                self.assertEqual(token.end, tokens_list[3])
                self.assertEqual(token.line, tokens_list[4])

# Generated at 2022-06-11 20:01:31.548982
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    l = [
        (NAME, "a"),
        (NUMBER, "2"),
        (ADD, "+"),
        (NAME, "b"),
        (NAME, "foo"),
        (STRING, '"bar"'),
        (NEWLINE, "\n"),
        (NAME, "a"),
        (STRING, '"b"'),
    ]
    assert untok.untokenize(l) == "a 2 + b foo 'bar'\na 'b' "



# Generated at 2022-06-11 20:01:42.245408
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import unittest
    from test.support import cpython_only

    class Test(unittest.TestCase):
        def tokeneater(self, *args):
            pass

        def test_basic(self):
            u = Untokenizer()
            self.assertEqual(
                u.untokenize(
                    generate_tokens(
                        io.StringIO("def x(): pass\n").readline,
                    )
                ),
                "def x(): pass\n",
            )

        def test_newline_in_string(self):
            u = Untokenizer()

# Generated at 2022-06-11 20:01:54.572245
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import StringIO

    def readline() -> str:
        return StringIO("\xef\xbb\xbf# coding: latin-1\n").readline()

    def readline_error() -> str:
        return StringIO("\xef\xbb\xbf# coding: latin-1\n").readline()

    assert detect_encoding(readline) == ("iso-8859-1", ["# coding: latin-1\n"])
    assert detect_encoding(lambda: "") == ("utf-8", [])
    assert detect_encoding(lambda: "#coding:") == ("utf-8", [b"#coding:"])


# Generated at 2022-06-11 20:02:02.759957
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from .test_tokenize import generate_tokens

    for i in range(9):
        t = Untokenizer()
        t.prev_row = 1 + i
        t.prev_col = i
        source = "".join(" " * i + "def f():\n" + " " * i + "return\n")
        tokens = list(generate_tokens(source.__iter__().__next__))
        u = t.untokenize(tokens)
        assert u == source



# Generated at 2022-06-11 20:02:09.949804
# Unit test for function detect_encoding
def test_detect_encoding():
    def reader(lines):
        for line in lines:
            yield bytes(line)
    assert detect_encoding(reader([])[0] == "utf-8")
    assert detect_encoding(reader([BOM_UTF8])[0] == "utf-8-sig")
    assert detect_encoding(reader([BOM_UTF8 + b"# comment"])[0] == "utf-8-sig")
    assert detect_encoding(reader([b"# coding=utf-8"])[0] == "utf-8")
    assert detect_encoding(reader([BOM_UTF8 + b"# coding=utf-8-sig"])[0] == "utf-8-sig")
    assert detect_encoding(reader([b"# coding=utf-16"])[0] == "utf-16")
   

# Generated at 2022-06-11 20:02:17.714715
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    print("Inside test_Untokenizer_untokenize")
    u = Untokenizer()
    tkns = [('NUMBER', '1'),
            ('PLUS', '+'),
            ('NUMBER', '2')]
    s = u.untokenize(tkns)
    expected = "1 + 2 "
    print("s = ", s)
    print("expected = ", expected)
    assert s == expected



# Generated at 2022-06-11 20:02:20.465600
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.NUMBER, '123456789', (1, 0), (1, 9), '123456789')


# Generated at 2022-06-11 20:02:49.834700
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        if len(lines) > 0:
            return lines.pop(0)
        return

    def tokeneater(type, token, srow_scol, erow_ecol, line):
        print(type, token, srow_scol, erow_scol, line)

    lines = [
        r"if 1:",
        r"  print('foo#bar')",
        r"  x = 3",
    ]
    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-11 20:03:02.101273
# Unit test for function tokenize
def test_tokenize():
    import io
    r = io.StringIO("def f(x): return 2*x")
    l = []
    tokenize(r.readline, l.append)
    return l


# Generated at 2022-06-11 20:03:03.599393
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-11 20:03:12.944710
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline_func(lines: List[str]) -> Callable[[], bytes]:
        return lambda: bytes(lines.pop(0), "ascii")

    assert detect_encoding(readline_func([])) == ("utf-8", [])
    assert detect_encoding(readline_func([''])) == ("utf-8", [])
    assert detect_encoding(readline_func(['#a'])) == ("utf-8", [b'#a'])
    assert detect_encoding(readline_func(['#a\n'])) == ("utf-8", [b'#a\n'])
    assert detect_encoding(readline_func(['# a'])) == ("utf-8", [b'# a'])

# Generated at 2022-06-11 20:03:23.571337
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest
    import unittest.mock

    class MockTokenEater:
        def __init__(self, expected_tokens):
            self.expected_tokens = expected_tokens
            self.called = 0

        def __call__(self, *args):
            self.called += 1
            self.assertEqual(self.expected_tokens.pop(0), args)


# Generated at 2022-06-11 20:03:26.937441
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    untok = Untokenizer()
    with io.StringIO("") as f:
        tokenize.untokenize(untok.compat,f.readline)

# Generated at 2022-06-11 20:03:32.477588
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens

    readline = StringIO("if 1:\n  pass\n").readline
    tokens = generate_tokens(readline)
    for tok in tokens:
        print(tok)


test_generate_tokens() 


# Generated at 2022-06-11 20:03:41.285582
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline() -> bytes:
        raise StopIteration

    def readline_from_string(s: str) -> Callable[[], bytes]:
        s = s.encode("latin-1", "replace")

        def reader() -> bytes:
            return s

        return reader

    # Blank lines
    assert detect_encoding(readline) == ("utf-8", [])
    assert detect_encoding(readline_from_string(" ")) == ("utf-8", [" "])
    assert detect_encoding(readline_from_string("\t")) == ("utf-8", ["\t"])
    assert detect_encoding(readline_from_string("\n")) == ("utf-8", ["\n"])

    # #comments

# Generated at 2022-06-11 20:03:45.025340
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    r = StringIO("def foo():\n  if True:\n    return True\n")
    for t in generate_tokens(r.readline):
        print(t)



# Generated at 2022-06-11 20:03:55.107245
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "42", (1, 0), (1, 2), "42")
    printtoken(NUMBER, "42.9", (1, 0), (1, 4), "42.9")
    printtoken(NUMBER, "42j", (1, 0), (1, 3), "42j")
    printtoken(STRING, "42", (1, 0), (1, 2), "'42'")
    printtoken(STRING, '42"', (1, 0), (1, 3), '"42"')
    printtoken(NAME, "42", (1, 0), (1, 2), "42")


# ======================================================================
# Nested scopes

# A class for encoding the position of a nested block.  This is just a
# container for a pair of strings.  The first is the name of

# Generated at 2022-06-11 20:05:05.658948
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import generate_tokens, tok_name
    text = "1 + 1\n"
    # sio = StringIO(text)
    # sio.readline()
    # print(sio.readline())
    tokens = generate_tokens(StringIO(text).readline)
    for toknum, tokval, _, _, _ in tokens:
        print(tok_name[toknum], tokval)

# test_generate_tokens()

# Generated at 2022-06-11 20:05:16.894898
# Unit test for function generate_tokens
def test_generate_tokens():
    readline = iter(
        """\
while 1:
    print 'The Bright Side ' + 'of Life...'
""".splitlines(1)
    ).__next__

    tokens = list(generate_tokens(readline))

    if tokens[-1][0] != ENDMARKER:
        print("didn't get ENDMARKER")
    elif tokens[0][0] != NAME:
        print("didn't get NAME token")
    elif tokens[2][0] != OP:
        print("didn't get OP token")
    elif tokens[3][0] != NUMBER:
        print("didn't get NUMBER token")
    elif tokens[-2][1] != ":":
        print("didn't get colon")
    else:
        print("tokens OK")


# doctest

# Generated at 2022-06-11 20:05:29.298986
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def check_generator(g, expected):
        l = []
        try:
            while 1:
                l.append(next(g))
        except StopIteration:
            pass
        assert l == expected

    def readline(s=''):
        for c in s:
            yield c


# Generated at 2022-06-11 20:05:38.889274
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from unittest import TestCase

    class Tests(TestCase):
        def check(self, input, output):
            u = Untokenizer()
            u.compat(input, [])
            self.assertEqual(u.tokens, [output])
            u.tokens = []
            u.compat(input, [input])
            self.assertEqual(u.tokens, [output, output])

        def test_op(self):
            self.check((ADD, "+"), "+")
            self.check((MULT, "*"), "*")

        def test_number(self):
            self.check((NUMBER, "1"), "1 ")

# Generated at 2022-06-11 20:05:46.830564
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Regression test for issue #3078: the tokenize_loop() function
    # should not read past the end of a line of input.
    import token
    lines = [("a = 1", [("NAME", "a"), ("OP", "="), ("NUMBER", "1"), ("NEWLINE", "\n")]),
             ("b = 2", [("NAME", "b"), ("OP", "="), ("NUMBER", "2"), ("NEWLINE", "\n")])]
    def readers():
        for line, result in lines:
            def reader(l=line, r=result):
                if reader.lines:
                    l = reader.lines.pop(0)
                    if not l.strip():
                        l = reader.lines.pop(0)
                else:
                    l = ""
                return l

# Generated at 2022-06-11 20:05:49.850533
# Unit test for function generate_tokens
def test_generate_tokens():
   for tok in generate_tokens(open(sys.argv[1]).__next__):
      print(tok)

# Generated at 2022-06-11 20:05:57.181370
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    with open("blib2to3/pgen2/tokenize.py", "r") as fp:
        for t in tokenize(fp.readline):
            pass
    ut = Untokenizer()
    with open("blib2to3/pgen2/tokenize.py", "r") as fp:
        text = ut.untokenize(generate_tokens(fp.readline))
    assert text == fp.read()



# Generated at 2022-06-11 20:06:06.460668
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from blib2to3.pytokenize import untokenize
    from io import StringIO
    import unittest

    # Synthesize some sample data;
    # Note: untokenize isn't idempotent, so we have to tokenize
    #       the tokens before generating the final string

# Generated at 2022-06-11 20:06:10.135889
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO as _StringIO
    input = _StringIO("""if 1:
    print(23)""")
    tokenize(input.readline)



# Generated at 2022-06-11 20:06:17.484570
# Unit test for function detect_encoding
def test_detect_encoding():
    txt_utf8 = b"# coding=utf-8\n\n"
    txt_utf8_leadin = b"\n# coding=utf-8\n\n"

    txt_latin = b"# coding=latin-1\n\n"
    txt_latin_leadin = b"\n# coding=latin-1\n\n"

    txt_bom = BOM_UTF8 + txt_utf8

    txt_utf8_bom = BOM_UTF8 + txt_utf8
    txt_utf8_bom_leadin = b"\n" + txt_utf8_bom

    txt_latin_bom = BOM_UTF8 + txt_latin
    txt_latin_bom_leadin