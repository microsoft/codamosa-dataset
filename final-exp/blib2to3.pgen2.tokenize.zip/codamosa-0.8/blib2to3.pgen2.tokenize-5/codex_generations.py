

# Generated at 2022-06-11 19:59:24.007728
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from unittest import TestCase
    from blib2to3.pgen2.tokenize import Untokenizer

    un = Untokenizer()
    a = untokenize([(NUMBER, 1), (NUMBER, 2)])
    assert (a == "1  2 ")
    a = untokenize([(NUMBER, 1), (NAME, "def")])
    assert (a == "1 def ")

    # The following is a regression test for buglet 1152089.
    un.compat((3, "a"), [(3, "\n"), (3, "b")])
    assert un.tokens == ["a", "\n", "b"]


# Generated at 2022-06-11 19:59:31.813000
# Unit test for function tokenize_loop
def test_tokenize_loop():
    f = open('tokenize_loop.txt', 'w')
    f.write('a = "dfasd\\n"\n')
    f.close()
    f = open('tokenize_loop.txt', 'r')
    tokenize_loop(f.readline, lambda *args: print(args))
    f.close()


# backwards compatible interface

# Generated at 2022-06-11 19:59:40.773047
# Unit test for function detect_encoding
def test_detect_encoding():  # htest #
    from math import isnan  # htest #
    from io import BytesIO  # htest #

    def readline():  # htest #
        try:
            return next(lines)
        except StopIteration:
            return b""


# Generated at 2022-06-11 19:59:51.657246
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in [
            "# coding: latin-1\n",
            "#!/usr/bin/python\n",
            "# -*- coding: latin-1 -*-\n",
            "blah blah blah\n",
            "blah blah blah\n",
        ]:
            yield line.encode("latin-1")

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == []

    def readline():
        yield BOM_UTF8
        yield "#!/usr/bin/python\n".encode("utf-8")
        yield "# -*- coding: latin-1 -*-\n".encode("utf-8")

# Generated at 2022-06-11 19:59:59.002748
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline():
        yield b'# coding=utf_8\n'
        yield b'class Klass(object): pass\n'

    encoding, lines = detect_encoding(readline)
    assert encoding == 'utf_8'
    assert len(lines) == 2
    assert lines == [b'# coding=utf_8\n', b'class Klass(object): pass\n']

    def readline():
        yield b'\xef\xbb\xbf# coding=utf_8\n'
        yield b'class Klass(object): pass\n'

    encoding, lines = detect_encoding(readline)
    assert encoding == 'utf-8-sig'
    assert len(lines) == 2

# Generated at 2022-06-11 20:00:09.173150
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    import unittest

    class TestableBuiltInFile(io.TextIOBase):
        def __init__(self, content: str) -> None:
            self.readlines = content.splitlines
            # to simulate self.readlines()
            self.line_num = 0
            # to track line number

        def readline(self) -> str:
            try:
                return self.readlines()[self.line_num]
            finally:
                self.line_num += 1

    class TestTokenizeLoop(unittest.TestCase):
        def testTokenizeLoop(self):
            code = 'for i in range(10):\n    print(i)'
            tokens = []

# Generated at 2022-06-11 20:00:21.869678
# Unit test for function tokenize_loop
def test_tokenize_loop():
    "Test tokenize_loop using test.test_tokenize as tokeneater"
    import unittest

    readline = unittest.mock.Mock()
    # Make sure the generator is exhausted.
    readline.side_effect = ['line1', 'line2', StopIteration]
    tokeneater = unittest.mock.Mock()
    tokenize_loop(readline, tokeneater)
    # We should have called tokeneater twice, with five arguments each.
    assert tokeneater.mock_calls == [
        unittest.mock.call(
            *token_info
        )
        for token_info in generate_tokens(['line1', 'line2'])
    ]
    assert readline.call_count == 3



# Generated at 2022-06-11 20:00:27.539369
# Unit test for function tokenize_loop
def test_tokenize_loop():

    def my_readline():
        return "if True:\n  pass\n"

    def my_tokeneater(*args):
        print(args)

    tokenize_loop(my_readline, my_tokeneater)



# Generated at 2022-06-11 20:00:33.623671
# Unit test for function detect_encoding
def test_detect_encoding():
    if __name__ == "__main__":
        import unittest

        class Test(unittest.TestCase):
            def test_bom(self):
                bom = BOM_UTF8
                readline = iter([b"# coding: utf-8", bom]).__next__
                encoding, _ = detect_encoding(readline)
                self.assertEqual(encoding, "utf-8-sig")

            def test_cookie_eats_first_line(self):
                readline = iter([b"# coding: utf-8\nfrom __future__ import braces"]).__next__
                encoding, lines = detect_encoding(readline)
                self.assertEqual(encoding, "utf-8")
                self.assertEqual(lines, [b"from __future__ import braces"])

# Generated at 2022-06-11 20:00:40.989784
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def tokeneater(*args):
        print(args)
    import io
    tokenize_loop(io.StringIO("# hello, world!\n").readline, tokeneater)
    print(list(generate_tokens(io.StringIO("# hello, world!\n").readline)))



# Generated at 2022-06-11 20:01:31.802486
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# coding utf-8\n'
        yield b'import blib\n'

    encoding, lines = detect_encoding(readline)
    assert encoding == 'utf-8'
    assert lines == [b'# coding utf-8\n', b'import blib\n']

    encoding, lines = detect_encoding(readline)
    assert encoding == 'utf-8'
    assert lines == [b'# coding utf-8\n', b'import blib\n']

    def readline():
        yield b'\xff'
        yield b'import blib\n'

    try:
        detect_encoding(readline)
    except SyntaxError:
        pass
    else:
        assert False, "Didn't raise"


# Generated at 2022-06-11 20:01:42.278108
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    try:
        import io
    except:
        import io as io
    u = Untokenizer()
    toks = [
        (NAME, "def"),
        (NAME, "g"),
        (OP, "("),
        (NAME, "x"),
        (OP, ")"),
        (OP, ":"),
        (NEWLINE, "\n"),
        (INDENT, "\t"),
        (NAME, "return"),
        (NAME, "x"),
        (OP, "+"),
        (NUMBER, "5"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
    ]
    s = u.untokenize(toks)
    f = io.StringIO(s)
    g = tokenize(f.readline)
    toks1 = list(g)

# Generated at 2022-06-11 20:01:50.504269
# Unit test for function generate_tokens
def test_generate_tokens():
    """Simple unit test for function generate_tokens."""
    import tokenize
    import io

    test_string = "some string\n    foo\n    bar\n"

    tokens_list = list(
        generate_tokens(io.StringIO(test_string).readline)
    )
    new_string = tokenize.untokenize(tokens_list)

    assert new_string == test_string
    

# Generated at 2022-06-11 20:01:58.612902
# Unit test for function generate_tokens
def test_generate_tokens():
    def get_cookie(filename: str) -> str:
        with open(filename, "rb") as fp:
            lines = []
            while True:
                line = fp.readline()
                if not line:
                    break
                lines.append(line)
                if line.strip().startswith(b"#"):
                    continue
                else:
                    break
            for i, line in enumerate(lines[::-1]):
                if line.strip().startswith(b"#"):
                    continue
                else:
                    break
            cookie_line = lines[-i - 1]
            encoding, _ = detect_encoding(lambda: cookie_line, False)
            return encoding

    filename = "Lib/tokenize.py"
    encoding = get_cookie(filename)

# Generated at 2022-06-11 20:02:08.754466
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import tokenize as _tokenize
    import unittest

    # Some test strings to test for default encoding
    # For ASCII and LATIN-1, best ASCII and LATIN-1 text.
    def _normalize(enc, text):
        return text.decode(enc).encode('latin1')

    ascii_text = _normalize('ascii', "# This is just a test")
    latin1_text = _normalize('latin1', "# This is just a test")

    class EncodingDetectionTest(unittest.TestCase):

        def build_stream(self, *lines, **kwargs):
            encoding = kwargs.pop('encoding', 'utf-8')
            stream = io.BytesIO(b''.join(l.encode(encoding) for l in lines))

# Generated at 2022-06-11 20:02:21.871242
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO

    def make_readline(lines):
        buf = b"\n".join(lines)
        b = BytesIO(buf)

        def readline():
            return b.readline()

        return readline

    # Default to utf-8
    readline = make_readline([b"# coding=utf-8"])
    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8\n"])

    # With BOM
    readline = make_readline([BOM_UTF8 + b"# coding=utf-8"])
    assert detect_encoding(readline) == ("utf-8-sig", [b"# coding=utf-8"])

    # With utf-8-sig
    readline = make_

# Generated at 2022-06-11 20:02:29.898433
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_equal(x, y):
        print("%r == %r ?" % (x, y))
        assert x == y, "%r != %r" % (x, y)

    source = """def f(x):
    return x + 1
"""
    import tokenize
    g = tokenize.generate_tokens(source.__iter__().__next__)

    # First token is tokenize.ENCODING
    check_equal(next(g), (tokenize.ENCODING, "utf-8", (1, 0), (1, 0), ""))

    # Then tokenize.NEWLINE
    check_equal(next(g), (tokenize.NEWLINE, "\n", (1, 0), (1, 0), ""))

    # Then the function definition

# Generated at 2022-06-11 20:02:40.426582
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        try:
            return next(lines) + "\n"
        except StopIteration:
            return ""

    lines = iter(["print('hello world') # a test", "print('done')"])
    l = []
    tokenize_loop(readline, l.append)

# Generated at 2022-06-11 20:02:43.243743
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():

    t = Untokenizer()
    class fake_iterable:
        def __iter__(self):
            return iter([(3, "test")])
    t.compat((3, "test"), fake_iterable())
    assert t.tokens == ["test "]



# Generated at 2022-06-11 20:02:54.069927
# Unit test for function generate_tokens
def test_generate_tokens():
    import re
    import tokenize
    import io
    import token

    def _tok_names(toks: List[TokenInfo]) -> List[str]:
        return [token.tok_name[tok[0]] for tok in toks]

    def _loc_str(toks: List[TokenInfo]) -> List[str]:
        return ["%d:%d" % tok[2] for tok in toks]

    def _val_str(toks: List[TokenInfo]) -> List[str]:
        return [tok[1] for tok in toks]

    def _set_exc(exc_type: type, exc_msg: str):
        class ParserError(tokenize.TokenError):
            def __init__(self, msg, line):
                super().__init__(msg)


# Generated at 2022-06-11 20:03:55.950499
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import sys
    import types

    def test(inp, *expected):
        print(inp)
        infp = io.StringIO(inp)
        outfp = io.StringIO()
        tokenize_loop(infp.readline, outfp.write)
        got = outfp.getvalue()
        print(got)
        if len(expected) == 1 and isinstance(expected[0], Exception):
            if sys.version_info >= (3, 6):
                # The exception message changed in 3.6
                expected = expected[0]
                exc_class, exc_message = expected.__class__, "no exception"
                try:
                    exec(inp, {})
                except exc_class as err:
                    exc_message = str(err)

# Generated at 2022-06-11 20:04:06.456955
# Unit test for function tokenize
def test_tokenize():
    from cStringIO import StringIO
    import token
    toktypes = set(token_type.split()[1] for token_type in dir(token) if token_type.startswith("NT_"))
    def generate_tokens(readline):
        prev_start = (1,0)
        for token_type in generate_tokens(readline):
            if token_type[0] in toktypes:
                yield token_type + prev_start
                prev_start = token_type[3]
    tokenize_loop = generate_tokens
    def readline():
        return readline.next_line

    readline.next_line = "def f(x): return 2*x\n"
    toks = list(tokenize_loop(readline))

# Generated at 2022-06-11 20:04:15.208176
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test with a bogus tokenize function that checks correctness of
    # the test input

    def tokenizefunc(readline):
        match = pseudoprog.match(readline())
        if not match:
            raise ValueError("bad input")
        if match.end() != len(match.group()):
            raise ValueError("input too long")
        for s, e in match.regs[1:]:
            if s != -1:  # should always match
                raise ValueError("matched junk")

    s = "for i in range(10): print(i)\n"
    tokenize_loop(s.splitlines(True).__iter__, tokenizefunc)



# Generated at 2022-06-11 20:04:20.473501
# Unit test for function generate_tokens
def test_generate_tokens():
    from token import tok_name
    from io import StringIO

    def _print_token(token: GoodTokenInfo) -> None:
        for tok in token:
            print(tok_name.get(tok[0], tok[0]), end=' ')
        print()

    src = "def f():\n  return\n"
    tokens = generate_tokens(iter(src.splitlines()).__next__)
    for t in tokens:
        _print_token(t)



# Generated at 2022-06-11 20:04:27.121882
# Unit test for function generate_tokens
def test_generate_tokens():
    readline = iter(
        r"""def f(x):
        yield x
        for y in x:
            yield y
    """.splitlines(1)
    ).__next__
    tokengen = generate_tokens(readline)
    for t in tokengen:
        print(t)
    
    
if __name__ == "__main__":
    test_generate_tokens()


# Generated at 2022-06-11 20:04:36.025105
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest
    import re

    class Test(unittest.TestCase):
        def test_get_normal_name(self):
            self.assertEqual(_get_normal_name("ISO-8859-1"), "iso-8859-1")
            self.assertEqual(_get_normal_name("iso8859-1"), "iso-8859-1")
            self.assertEqual(_get_normal_name("ISO_8859-1"), "iso-8859-1")
            self.assertEqual(_get_normal_name("latin-1"), "iso-8859-1")
            self.assertEqual(_get_normal_name("latin-1-"), "iso-8859-1")

# Generated at 2022-06-11 20:04:48.173158
# Unit test for function generate_tokens
def test_generate_tokens():
    def check(input_string, expected):
        from typing import List
        from token import TokenInfo

        actual = list(generate_tokens(iter(input_string.splitlines(keepends=True)).__next__))

        assert len(actual) == len(expected), (actual, expected)

        for actual_token, expected_token in zip(actual, expected):
            assert len(actual_token) == 5, actual_token
            assert actual_token[0:2] == expected_token[0:2], (actual_token, expected_token)

            string_start = actual_token[2]
            string_end = actual_token[3]
            assert isinstance(string_start, tuple) and len(string_start) == 2, actual_token

# Generated at 2022-06-11 20:04:58.689030
# Unit test for function tokenize
def test_tokenize():
    r"""
    >>> from io import BytesIO
    >>> s = b"""

# Generated at 2022-06-11 20:05:03.035381
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    for token in generate_tokens(StringIO("1 + 1\n").readline):
        print(token)

test_generate_tokens()

# The following is modified from the Python stdlib's `tokenize`, licensed under
# the PSFL

# Generated at 2022-06-11 20:05:15.089673
# Unit test for function generate_tokens
def test_generate_tokens():
    def gen(s: str) -> TokenInfo:
        g = generate_tokens(s.splitlines(True).__iter__)
        return g.__next__()

    eq = assert_equal
    eq(gen(""), (ENDMARKER, "", (1, 0), (1, 0), "\n"))
    eq(gen(" "), (INDENT, "", (1, 0), (1, 1), " "))
    eq(gen("a b"), (NAME, "a", (1, 0), (1, 1), "a b"))
    eq(gen("a b"), (NAME, "b", (1, 2), (1, 3), "a b"))
    eq(gen("a b"), (ENDMARKER, "", (1, 4), (1, 4), "a b"))

# Generated at 2022-06-11 20:06:36.078283
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest

    from . import tokenize

    sample1 = (
        b'# -*- coding: iso-latin-1 -*-\n'
        b'# nothing else matters\n'
        b'pass\n'
        b'# -*- coding: ascii -*-\n'
    )
    sample2 = (
        b'# coding=iso-latin-1\n'
        b'pass\n'
        b'# coding=ascii\n'
    )
    sample3 = (
        b'#!/usr/bin/python\n'
        b'# -*- coding: iso-latin-1 -*-\n'
        b'pass\n'
    )