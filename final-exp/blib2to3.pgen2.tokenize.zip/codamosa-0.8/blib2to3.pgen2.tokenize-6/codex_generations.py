

# Generated at 2022-06-11 19:58:04.940998
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    global ut
    ut = Untokenizer()
    ut.untokenize([(1, "a"), (2, "b")])
    ut.untokenize([(0, "c")])
    ut.untokenize([(1, "d"), (2, "e")])
    ut.untokenize([(0, "f")])



# Generated at 2022-06-11 19:58:15.475854
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    text = "123\n456\n89abc\n123"
    tok = tokenize(io.StringIO(text).readline)
    t_iter = iter(tok)
    unt = Untokenizer()
    t = next(t_iter)
    unt.add_whitespace(t[3])
    unt.tokens.append(text[t[0]:t[3][0]])
    t = next(t_iter)
    unt.add_whitespace(t[3])
    unt.tokens.append(text[t[0]:t[3][0]])
    t = next(t_iter)
    unt.add_whitespace(t[3])
    unt.tokens.append(text[t[0]:t[3][0]])
    t = next

# Generated at 2022-06-11 19:58:19.983970
# Unit test for function tokenize
def test_tokenize():
    # A smoke test
    import io
    import tokenize
    r = io.StringIO(
        "def square(a):\n"
        + "    return a**2\n"
        + "\n"
        + "\n"
        + "print square(2)"
    ).readline
    list(tokenize.generate_tokens(r))



# Generated at 2022-06-11 19:58:25.092548
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # test that untokenize() works regardless of the number of arguments
    # passed to it by generate_tokens()
    for i in range(1, 7):
        l = []
        for j in range(i):
            l.append("x")
        x = tuple(l)
        u = Untokenizer()
        s = u.untokenize([x])
        assert s == "x" + (" " * (i - 1))



# Generated at 2022-06-11 19:58:36.668886
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Note: Tokenize's global variable 'tokenizer' is a side effect and it is
    # implemented only because the tokenize module is written in Python.
    # When it is implemented in C, there won't be a global variable in
    # tokenize and it will be easier to test tokenize.
    saved_tokenizer = tokenizer

# Generated at 2022-06-11 19:58:42.632475
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: utf-8 -*-"
        yield b"blah = 'blah blah'"
        yield b""

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert list(lines) == [
        b"# -*- coding: utf-8 -*-",
        b"blah = 'blah blah'",
    ]

    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah = 'blah blah'"
        yield b""

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"

# Generated at 2022-06-11 19:58:48.504058
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    with open("test_tokenize.py") as f:
        for t in generate_tokens(f.readline):
            if t[0] == tokenize.ENDMARKER:
                break
            print(t)
    for t in generate_tokens("if __name__ != '__main__':\n    print(v)"):
        print(t)

if __name__ == "__main__":
    test_generate_tokens()

# End of tokenize.py

# Generated at 2022-06-11 19:59:02.194748
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from . import tokenize
    # Check for correct number of tokens in each of these:

# Generated at 2022-06-11 19:59:13.978983
# Unit test for function generate_tokens
def test_generate_tokens():
    import token

# Generated at 2022-06-11 19:59:26.034990
# Unit test for function generate_tokens
def test_generate_tokens():
    # Simple tests based on the tokenize module's unit tests
    def check_tokenize(s):
        result = list(tokenize.generate_tokens(io.StringIO(s).readline))
        # Remove encoding cookie
        if result:
            if result[0][0] == tokenize.ENCODING:
                result = result[1:]
        return result

    import unittest


# Generated at 2022-06-11 19:59:52.679664
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # setup
    ut = Untokenizer()
    # exercise
    ut.compat((NAME, "abc"), [(NAME, "abc"), (NEWLINE, ""), (DEDENT, "")])
    # verify
    assert ut.tokens == ["abc ", "\n", ""]



# Generated at 2022-06-11 19:59:57.477579
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.tokens = ["aaa"]
    ut.prev_row, ut.prev_col = 1, 3
    ut.add_whitespace((1, 6))
    ut.add_whitespace((2, 1))
    ut.add_whitespace((3, 0))
    assert ut.tokens == ["aaa   ", "   ", ""]



# Generated at 2022-06-11 20:00:03.092873
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    untok = Untokenizer()
    r = io.StringIO("def foo():\n  pass\n")
    g = tokenize.generate_tokens(r.readline)
    toks = list(g)
    source = untok.untokenize(iter(toks))
    assert source == "def foo ():\n    pass\n"



# Generated at 2022-06-11 20:00:12.376817
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    t1 = untok.untokenize(
        [
            (NUMBER, "42", (1, 0), (1, 2), "42"),
            (NAME, "spam", (1, 2), (1, 6), "spam"),
            (OP, "+", (1, 6), (1, 7), "+"),
            (NUMBER, "1", (1, 7), (1, 8), "1"),
        ]
    )
    assert t1 == "42 spam + 1 "

    utok = Untokenizer()
    t2 = utok.untokenize([(ENDMARKER, "", (1, 0), (1, 0), ""), (ENCODING, "utf-8", (1, 0), (1, 0), "")])
    assert t2 == ""



# Generated at 2022-06-11 20:00:19.831191
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = 'for i in range(10): print(i)'
    result = []
    tokenize_loop(s.splitlines().__iter__().__next__, result.append)
    assert result == [(5, 'for'), (3, 'i'), (11, 'in'), (3, 'range'), (21, ':'),
                      (3, 'print'), (21, '('), (3, 'i'), (21, ')'), (6, '\n')]


# Generated at 2022-06-11 20:00:28.422020
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest

    class DetectEncodingTestCase(unittest.TestCase):
        def test_no_bom(self):
            def readline() -> bytes:
                return b'# -*- coding: latin-1 -*-'

            encoding = detect_encoding(readline)
            self.assertEqual(encoding, ('iso-8859-1', [b'# -*- coding: latin-1 -*-']))

        def test_with_bom(self):
            def readline() -> bytes:
                return b'\xef\xbb\xbf# -*- coding: utf-8 -*-'

            encoding = detect_encoding(readline)

# Generated at 2022-06-11 20:00:37.355507
# Unit test for function generate_tokens
def test_generate_tokens():
    """
    Test coverage of tokenization:
    * one physical line -> 1 logical line
    * multiple physical lines -> 1 logical line
    * comments
    * triple-quoted strings
    * various types of whitespace
    * continued statements
    * implicit string concatenation
    """

# Generated at 2022-06-11 20:00:47.757401
# Unit test for function generate_tokens
def test_generate_tokens():
    import re
    import sys
    import tokenize
    # Read from a text file, generate tokens and write them to sys.stdout
    if len(sys.argv) == 1:
        infile = sys.stdin
        outfile = sys.stdout
    elif len(sys.argv) == 2:
        infile = open(sys.argv[1], "r")
        outfile = sys.stdout
    elif len(sys.argv) == 3:
        infile = open(sys.argv[1], "r")
        outfile = open(sys.argv[2], "w")
    else:
        raise RuntimeError("invalid number of arguments")
    tokengen = tokenize.generate_tokens(lambda: infile.readline())

# Generated at 2022-06-11 20:00:53.398116
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    test_untok = Untokenizer()
    test_untok.add_whitespace((1, 0))
    assert test_untok.tokens == ['']
    test_untok.tokens = []
    test_untok.add_whitespace((1, 1))
    assert test_untok.tokens == [' ']
    test_untok.tokens = []
    test_untok.add_whitespace((2, 0))
    assert test_untok.tokens == ['\n']
    test_untok.tokens = []
    test_untok.add_whitespace((2, 1))
    assert test_untok.tokens == ['\n', ' ']



# Generated at 2022-06-11 20:01:04.855334
# Unit test for function detect_encoding

# Generated at 2022-06-11 20:01:42.901734
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # Create some tokens
    t1 = (token.NAME, 'a', (1, 0), (1, 0), 'a')
    t2 = (token.NL, '\n', (1, 0), (1, 0), '\n')
    t3 = (token.NAME, 'a', (2, 0), (2, 0), 'a')
    t4 = (token.INDENT, '    ', (2, 0), (2, 0), '    ')
    t5 = (token.NAME, 'a', (3, 0), (3, 0), 'a')
    t6 = (token.DEDENT, '    ', (3, 0), (3, 0), '    ')
    t7 = (token.NAME, 'a', (4, 0), (4, 0), 'a')

# Generated at 2022-06-11 20:01:46.593425
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline():
        yield from u"# coding: latin-1\n".encode()

    encoding, _ = detect_encoding(readline)
    assert encoding == "iso-8859-1"



# Generated at 2022-06-11 20:01:54.487124
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        yield b"#coding:koi8-r"

    # BytesIO requires bytes
    readline = io.BytesIO(b"#coding:koi8-r").readline

    # This should raise a SyntaxError
    try:
        detect_encoding(readline)
    except SyntaxError:
        pass
    else:
        raise SyntaxError("detect_encoding did not raise SyntaxError")



# Generated at 2022-06-11 20:02:00.889716
# Unit test for function generate_tokens
def test_generate_tokens():
    def _test_generate_tokens(
        s: str, tokens: List[GoodTokenInfo], columns: bool = False
    ) -> None:
        tokens2 = list(generate_tokens(iter(s.splitlines(True)).__next__))
        # print(tokens2)
        # Truncate token lists to those tokens which have a column value (-2 in tuple)
        # of 0, since the other column values are not reliable across tokenize versions.
        if not columns:
            tokens = [(t, v) for (t, v, (srow, scol), (erow, ecol), l) in tokens if scol == 0]

# Generated at 2022-06-11 20:02:11.746204
# Unit test for function detect_encoding
def test_detect_encoding():
    import io as _io
    from blib2to3.pgen2.tokenize import detect_encoding

    def readlines(lines):
        for line in lines:
            yield line.replace("\n", "\r\n")

    def get_encoding(lines):
        return detect_encoding(readlines(lines))[0]

    s = "# coding=utf-8\n\nprint('abc'\n"

    # Default should be utf-8
    assert get_encoding(["\n"]) == "utf-8"

    # No coding cookie
    assert get_encoding(["#\n"]) == "utf-8"
    assert get_encoding(["# coding: utf-8\n"]) == "utf-8"

# Generated at 2022-06-11 20:02:13.860137
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import generate_tokens
    # I have no idea how to test this.



# Generated at 2022-06-11 20:02:26.106522
# Unit test for function detect_encoding
def test_detect_encoding():
    from itertools import chain

    def readline() -> bytes:
        return source.pop(0)

    source = [
        b"# -*- coding: latin-1 -*-\n",
        b"pass\n",
    ]
    assert detect_encoding(readline) == ("iso-8859-1", source)
    source = [
        b"# coding=utf-8\n",
        b"pass\n",
    ]
    assert detect_encoding(readline) == ("utf-8", source)
    source = [
        BOM_UTF8 + b"# -*- coding: latin-1 -*-\n",
        b"pass\n",
    ]
    assert detect_encoding(readline) == ("utf-8-sig", source[1:])


# Generated at 2022-06-11 20:02:38.242027
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(seq):
        for s in seq:
            yield s


# Generated at 2022-06-11 20:02:49.553064
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize
    from io import BytesIO

    for args in (
        ("a = 1",),
        ("\nb=2",),
        ("\n\nc = 3",),
        ("if 1:\n  pass\n",),
        ("if 1:\n  pass\n\n\n# comment\n",),
        ("1 + 2\n",),
        ("1 + 2\n\n",),
        ("\n\ncontinue  # end the loop",),
        ('# -*- coding: utf-8 -*-\n"föö"\n', ),
        ('"""föö"""\n', ),
    ):
        readline = iter(args).__next__
        empty_gen = generate_tokens(readline)  #

# Generated at 2022-06-11 20:02:59.460869
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    # Test with a simple byte string
    s = untok.untokenize([(NUMBER, "1", (1, 0), (1, 0), "1")])
    assert s == "1 "
    # Test with a tuple containing a byte string
    s = untok.untokenize([(NUMBER, "2", (1, 0), (1, 0), "2")])
    assert s == "2 "
    # Test with a tuple containing a unicode string
    s = untok.untokenize([(NUMBER, "3", (1, 0), (1, 0), "3")])
    assert s == "3 "



# Generated at 2022-06-11 20:03:32.522585
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # Untokenizer.untokenize()
    import io
    import tokenize
    data = "def f(x):\n  return 2*x"
    readline = io.BytesIO(data.encode("utf-8")).readline
    tokens = list(tokenize.generate_tokens(readline))
    result = tokenize.Untokenizer().untokenize(tokens)
    assert result == data



# Generated at 2022-06-11 20:03:41.322870
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline():
        yield "# coding=utf-8\n"
        yield "def foo():\n"
        yield "\tpass\n"
        yield "\n"

    assert detect_encoding(readline) == ("utf-8", ["# coding=utf-8\n"])

    def readline():
        yield "#!/usr/bin/python\n"
        yield "# coding=latin-1\n"
        yield "def foo():\n"
        yield "\tpass\n"
        yield "\n"

    assert detect_encoding(readline) == ("iso-8859-1", ["# coding=latin-1\n"])

    def readline():
        yield "#!/usr/bin/python\n"
        yield "# coding=latin-1\n"

# Generated at 2022-06-11 20:03:52.541363
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Setup code
    import io
    import token

    def tokeneater(*args):
        f = tokenize_loop.f
        f.write("%d,%d-%d,%d:\t%s\t%s\n" % (args + (token.tok_name[args[0]],)))

    tokenize_loop.f = io.StringIO()
    # Test code
    tokenize_loop(
        iter(["abcd", "efg\n", "hijk\n", "\n", "\n", "lmno\n", "pqr "]).__next__,
        tokeneater,
    )
    # Verification code
    tokenize_loop.f.seek(0)
    verify = tokenize_loop.f.read()

# Generated at 2022-06-11 20:04:05.441165
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:04:16.444390
# Unit test for function tokenize
def test_tokenize():
    import io


# Generated at 2022-06-11 20:04:22.898637
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    from blib2to3.pgen2.tokenize import detect_encoding

    good_cookies = [
        ("# coding=utf-8", "utf-8"),
        ("# -*- coding: utf-8 -*-", "utf-8"),
        ("# coding=UTF-8", "utf-8"),
        ("# -*- coding: UTF-8 -*-", "utf-8"),
        ("# coding=utf-8  \n", "utf-8"),
        ("# -*- coding: utf-8 -*-  \n", "utf-8"),
        ("# coding=UTF-8 \t\n", "utf-8"),
        ("# -*- coding: UTF-8 -*-\t\n", "utf-8"),
    ]


# Generated at 2022-06-11 20:04:34.007564
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from typing import IO

    from .tokenize_rt import StringIO
    from .tokenize_rt import untokenize

    f = StringIO("   a1 = 1 + 2\n")

    def gen():
        for x in range(3):
            yield (INDENT, "   ", (0, 0), (0, 0), "")
        while True:
            yield next(genfromfile(f))

    s = untokenize(gen())
    assert s == "   a1 = 1 + 2\n\n\n"
    f.close()

    f = StringIO("   a2 = 1 + 2\n")

    def gen():
        yield (INDENT, "   ", (0, 0), (0, 0), "")
        while True:
            yield next(genfromfile(f))

    s = untoken

# Generated at 2022-06-11 20:04:40.041884
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    unt.compat = unt.add_whitespace = lambda a, b: None
    unt.tokens = []
    unt.prev_row = 1
    unt.prev_col = 0
    unt.untokenize([(tokenize.NAME, "a"), (tokenize.NL, "")])
    assert unt.tokens == ["a "]



# Generated at 2022-06-11 20:04:51.007626
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Testing this function works the same way as testing tokenize() above.
    # See that test for further details.
    import io
    import tokenize

    class Readline:
        def __init__(self, lines: List[Text]):
            self.lines = lines
            self.index = 0

        def __call__(self) -> Text:
            self.index += 1
            if self.index > len(self.lines):
                return ""
            return self.lines[self.index - 1]

    s = "def f(x): return 2*x\n"
    rl = Readline(s.splitlines(True))
    result = []

    def tokeneater(*args):
        result.append(args)

    tokenize_loop(rl, tokeneater)
    # We have to convert the tokens in

# Generated at 2022-06-11 20:05:01.622746
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from token import NAME, NUMBER, NEWLINE, INDENT, DEDENT, ENDMARKER
    from token import generate_tokens
    from blib2to3.pgen2.tokenize import tokenize_loop

    with io.StringIO("print expr\n") as reader:
        result = -1
        result_string = ""

        def consume(token_number, token_string, start_location, end_location, line):
            nonlocal result, result_string
            result = token_number
            result_string = token_string
            # tokenize_loop consumes the entire file, so consume() should only
            # be called once per call to tokenize_loop
            raise StopIteration()


# Generated at 2022-06-11 20:06:38.969719
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    import tokenize as real_tokenize

    def readline():
        return ('s = "a\\"\\na"\n' 't = s.splitlines()\n' 'print(t)\n')

    result = []
    real_tokenize.tokenize(readline().__next__, result.append)
