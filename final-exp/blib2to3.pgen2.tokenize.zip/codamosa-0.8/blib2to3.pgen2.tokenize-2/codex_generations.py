

# Generated at 2022-06-11 19:59:10.588723
# Unit test for function generate_tokens
def test_generate_tokens():
    from . import tokenize

    # With a filename
    with open(__file__, "rb") as f:
        g = tokenize.generate_tokens(f.readline)
        for toknum, tokval, _, _, _ in g:
            if toknum == tokenize.ENCODING:
                break
        assert tokval == "utf-8"
    with open(__file__, "rb") as f:
        g = tokenize.generate_tokens(f.readline)
        for toknum, tokval, _, _, _ in g:
            if toknum == tokenize.NAME and tokval == "test_generate_tokens":
                break
        assert tokval == "test_generate_tokens"

    # Without a filename

# Generated at 2022-06-11 19:59:18.563895
# Unit test for function generate_tokens
def test_generate_tokens():
    def remove_line_numbers(lines):
        return [(t[:2], t[2:]) for t in lines]

    def test_tokenizer(input, expected, start=0, end=sys.maxsize):
        output = remove_line_numbers(list(tokenize(BytesIO(input).readline)))
        assert output[start:end] == expected

    # Test examples from the tokenize docstring (pasted below)

# Generated at 2022-06-11 19:59:28.274022
# Unit test for function tokenize

# Generated at 2022-06-11 19:59:30.212102
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline1(str):
        fp = StringIO(str)
        return fp.readline



# Generated at 2022-06-11 19:59:32.850122
# Unit test for function tokenize_loop

# Generated at 2022-06-11 19:59:41.598276
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io

    ut = Untokenizer()
    test_tokens = [
        (string.ascii_letters, "abc"),
        (NEWLINE, ""),
        (string.ascii_letters, "def"),
    ]

    test_reader = io.StringIO("abc\ndef")
    result = ut.compat(next(tokenize(test_reader.readline)), test_tokens)
    assert result == None
    assert ut.tokens == ["abc\n", "def"]

    test_reader = io.StringIO("abcdef")
    result = ut.compat(next(tokenize(test_reader.readline)), test_tokens)
    assert result == None
    assert ut.tokens == ["abc\n", "def", "abcdef"]



# Generated at 2022-06-11 19:59:49.725817
# Unit test for function tokenize_loop
def test_tokenize_loop():
    global test_tokenize_loop
    test_tokenize_loop = None

    global token, tok_name
    global NUMBER, STRING, NEWLINE, ENDMARKER
    import token
    import io

    def ck(s, want):
        f = io.StringIO(s)
        result = []
        tokenize_loop(f.readline, result.append)
        if result != want:
            raise ValueError(
                "tokenize_loop was %r; want %r"
                % ([(_[0], _[1]) for _ in result], want)
            )

    ck("\n", [(token.NEWLINE, "\n"), (token.ENDMARKER, "")])

# Generated at 2022-06-11 19:59:57.758857
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import generate_tokens, NUMBER, STRING, NAME, OP
    from io import StringIO
    from random import shuffle
    def generate_input(loops=3, maxsize=10):
        # Randomly generate tokens for testing
        for dummy in range(loops):
            for j in range(maxsize):
                if j==0 or (random.random() < 0.8):
                    yield random.choice(('if', 'def', 'class'))
                    yield ' '
                if random.random() < 0.2:
                    yield ' \n\t'
                yield random.choice(string.ascii_letters)
            yield '\n'
    inputs = ''.join(list(generate_input()))

# Generated at 2022-06-11 20:00:01.508287
# Unit test for function generate_tokens
def test_generate_tokens():
    # This is the key line that shows how to use the tokenize function
    tokgen = tokenize.generate_tokens(open('/Users/white/Desktop/language_processing.py').readline)
    # For each token...
    for toktype, tokvalue, _, _, _ in tokgen:
        # Print it out
        if toktype == tokenize.NEWLINE:
            toktype = "NEWLINE"
        else:
            toktype = tokenize.tok_name[toktype]
        print("(%s, %s)" % (toktype, repr(tokvalue)))
test_generate_tokens()


# Generated at 2022-06-11 20:00:10.397907
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import contextlib
    import tokenize

    @contextlib.contextmanager
    def tokenize_with_hook(hook):
        saved = tokenize.tokenize
        try:
            tokenize.tokenize = hook
            yield
        finally:
            tokenize.tokenize = saved

    with tokenize_with_hook(lambda *args, **kwargs: None):
        s = io.StringIO("""\
print(x)
print(y)
""")
        tokens = list(tokenize.tokenize(s.readline))

    u = tokenize.Untokenizer()
    assert u.untokenize(tokens) == """\
print(x)
print(y)
"""



# Generated at 2022-06-11 20:00:38.415603
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    # No encoding
    s = io.BytesIO(b"# coding=utf-8\n")
    encoding = detect_encoding(s.readline)[0]
    assert encoding == "utf-8"
    # Only BOM
    s = io.BytesIO(b"\xef\xbb\xbf# coding=utf-8\n")
    encoding = detect_encoding(s.readline)[0]
    assert encoding == "utf-8-sig"
    # BOM and coding
    s = io.BytesIO(b"\xef\xbb\xbf# coding=utf-8\n")
    encoding, lines = detect_encoding(s.readline)
    assert encoding == "utf-8-sig"

# Generated at 2022-06-11 20:00:39.853738
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from token import tok_name
    from typing import cast


# Generated at 2022-06-11 20:00:52.194664
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not test_lines:
            raise StopIteration
        return test_lines.pop(0)

    # Try once with just a utf-8 bom
    test_lines = [BOM_UTF8]
    e, l = detect_encoding(readline)
    assert e == "utf-8-sig"
    assert l == []
    # Try without a utf-8 bom
    test_lines = [b"# coding: latin-1\n", b"print 1 + 1\n", b"# vim:set fileencoding=utf-8:"]
    e, l = detect_encoding(readline)
    assert e == "iso-8859-1"
    assert l == test_lines
    # Try twice, once with a utf8 bom and once without
    test_lines

# Generated at 2022-06-11 20:00:55.128032
# Unit test for function tokenize
def test_tokenize():
    def get_input():
        yield "if 1:  # Spam"
        yield "  pass"
    tokenize(get_input().__next__)



# Generated at 2022-06-11 20:01:06.370541
# Unit test for function tokenize_loop

# Generated at 2022-06-11 20:01:12.092377
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from .tokenize import generate_tokens
    untok = Untokenizer()
    f = StringIO("def foo():\n  pass\n")
    tokens = generate_tokens(f.readline)
    s = untok.untokenize(tokens)
    assert s == "def foo ( ) : pass\n"



# Generated at 2022-06-11 20:01:23.745781
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if nottest_data:
            raise StopIteration
        return test_data.pop(0)

    test_data = []
    lines = [
        b"# coding=utf-8\n",
        b"\xEF\xBB\xBF# coding=utf-8\n",
        b"\xEF\xBB\xBF\x00# coding=utf-8\n",
        b"\xEF\xBB\xBF# coding=utf-8\xFF\n",
        b"# coding=utf-8 \xFF\n",
        b"# coding=utf-8\xff\n",
    ]
    for line in lines:
        test_data.append(line)

# Generated at 2022-06-11 20:01:32.092735
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def replace_with_a_1tuple(readline):
        while 1:
            line = readline()
            if not line:
                break
            yield (line,)
    def tokeneater(token_type, token_string, start_index,
                   end_index, line):
        print(token_type, token_string, start_index, end_index, line)
    tokenize_loop(replace_with_a_1tuple(iter(["hi"]).__next__).__next__,
                  tokeneater)
# end unit test for function tokenize_loop


# Generated at 2022-06-11 20:01:42.369164
# Unit test for function tokenize_loop
def test_tokenize_loop():
    text = "for i in range(10): print(i)"
    from blib2to3.pgen2.tokenize import tokenize_loop, tok_name

    def check_tokenize_loop(text, expected, callback=lambda *args: print(*args)):
        stream = (line + "\n" for line in text.split("\n"))
        token_stream = []

        def record_token(type, token, start, end, line):
            token_stream.append((type, token))

        callback_factory = record_token
        tokenize_loop(stream.__next__, record_token)
        print(
            "expected: ",
            [
                (tok_name[type], token)
                for type, token in expected
                if token is not None
            ],
        )

# Generated at 2022-06-11 20:01:47.226950
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from .tokenize import generate_tokens
    unt = Untokenizer()
    unt.compat((1, 'a'), generate_tokens(StringIO('c b').readline))
    assert unt.tokens == ['a', 'c', 'b']



# Generated at 2022-06-11 20:02:40.097055
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'\xef\xbb\xbf'
        yield b'# -*- coding: latin-1 -*-'
        yield b'print 1\n'
        yield b'\xc3\xbc print 2\n'
        yield b'# -*- coding: utf-8 -*-'
        yield b'\xc3\xbc = 2\n'
        yield b'print 1,\xc3\xbc\n'

# Generated at 2022-06-11 20:02:50.774706
# Unit test for function detect_encoding
def test_detect_encoding():
    # check BOM detection
    def readbytes(line):
        while line is not None:
            yield line[:2]
            line = line[2:]

    def readline(b):
        return b

    bom = BOM_UTF8.decode("latin-1")
    enc, lines = detect_encoding(readline)
    assert enc == "utf-8"
    assert lines == [bom]

    # check various combinations of unicode literals and encodings

# Generated at 2022-06-11 20:03:03.152018
# Unit test for function detect_encoding

# Generated at 2022-06-11 20:03:12.787750
# Unit test for function generate_tokens
def test_generate_tokens():
    import inspect
    import io
    import token
    import tokenize
    if sys.version_info >= (3, 8):
        text = "async def foo(*args): await bar()"
    elif sys.version_info >= (3, 7):
        text = "def foo(*args): await bar()"
    else:
        text = "def foo(*args): pass"
    g = generate_tokens(io.BytesIO(text.encode('utf-8')).readline)
    for tok in g:
        print(tok)
    assert inspect.isgenerator(g)
    assert inspect.getgeneratorstate(g) == 'GEN_CLOSED'

test_generate_tokens()

if __name__ == "__main__":
    doctest.testmod()

# Generated at 2022-06-11 20:03:20.056869
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    unt.untokenize([(NUMBER, "1"),(NAME, "a"),(NEWLINE, "\n"),(NUMBER, "2")])
    unt.untokenize([(NUMBER, "1"),(NAME, "a"),(NEWLINE, "\n"),(NUMBER, "2")])
    unt.untokenize([(NUMBER, "1"),(NAME, "a"),(NEWLINE, "\n"),(NUMBER, "2")])



# Generated at 2022-06-11 20:03:32.205510
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import sys
    import warnings

    with warnings.catch_warnings():
        if sys.flags.ignore_first_line:
            warnings.simplefilter("ignore", DeprecationWarning)

        def readline() -> bytes:
            return b"\xef\xbb\xbf# coding: cp-1252\n"

        encoding, lines = detect_encoding(readline)
        assert encoding == "cp1252"
        assert b"".join(lines) == b"# coding: cp-1252\n"

        encoding, lines = detect_encoding(iter(()).__next__)
        assert encoding == "utf-8"
        assert lines == []

        def readline() -> bytes:
            return b"# coding: cp-1252\n"


# Generated at 2022-06-11 20:03:41.068378
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO

    def readline():
        yield b"a\n"

    assert detect_encoding(readline) == ("utf-8", [b"a\n"])

    def readline():
        yield b"b"
        yield b"\n"

    assert detect_encoding(readline) == ("utf-8", [b"b\n"])

    def readline():
        yield BOM_UTF8 + b"c\n"

    assert detect_encoding(readline) == ("utf-8-sig", [b"c\n"])

    def readline():
        yield b"# coding: latin-1\n"
        yield b"d\n"


# Generated at 2022-06-11 20:03:52.272159
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    test_tokens = [
        (0, "abc"),
        (1, " "),
        (0, "def"),
        (1, "\n"),
        (0, "ghi"),
        (1, " "),
        (0, "jkl"),
        (1, "\n"),
        (0, "mno"),
        (1, " "),
        (0, "pqr"),
    ]
    assert u.untokenize(test_tokens) == "abc def\nghi jkl\nmno pqr"
    test_tokens = [(1, " "), (0, "abc"), (1, "\n"), (0, "def"), (1, "\n"), (0, "ghi")]

# Generated at 2022-06-11 20:03:53.918493
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:04:05.670911
# Unit test for function tokenize
def test_tokenize():
    import io, tokenize
    readline = io.BytesIO(
        b"if 1:\n"
        b"  pass #comment\n"
        b"  # another comment\n"
        b"  '''\n"
        b"  multi-line\n"
        b"  comment\n"
        b"  '''\n"
        b"class C:\n"
        b"  '''\n"
        b"  bla\n"
        b"  '''\n"
        b"  x = 3.14\n"
        b"  # a comment\n"
        b"  def m(self):\n"
        b"    '''\n"
        b"    bla bla\n"
        b"    '''\n"
    ).read

# Generated at 2022-06-11 20:04:35.455615
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "if 1: pass\n"
    g = tokenize_loop(s.splitlines().__iter__().__next__, printtoken)



# Generated at 2022-06-11 20:04:47.425226
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from . import tokenize_rt as tokenize_rt1

    tokenize_rt1.tokenize_loop(lambda: "", tokenize_rt1.printtoken)


# Generated at 2022-06-11 20:04:57.911841
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    untok.untokenize([(1, 'a'), (1, 'b'), (1, 'c')])
    untok.untokenize([(0, ' '), (1, 'd'), (0, ' '), (1, 'e')])
    untok.untokenize([(2, 'f'), (3, 'g'), (3, 'h'), (3, 'i')])
    untok.untokenize([(4, 'j'), (5, 'k'), (5, 'l'), (5, 'm')])
    untok.untokenize([(6, 'n'), (7, 'o'), (7, 'p')])
    untok.untokenize([(0, ' '), (8, 'q')])

# Generated at 2022-06-11 20:05:02.942413
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"\xef\xbb\xbf# -*- coding: latin-1 -*-"

    encoding, consumed = detect_encoding(readline())
    assert encoding == "iso-8859-1"
    assert consumed == [b"\xef\xbb\xbf# -*- coding: latin-1 -*-"]



# Generated at 2022-06-11 20:05:09.482726
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name

    text = """def test(a, b, c=5, d=6, e=None, f=None):
    def inner():
        pass
    print('this is a test')
"""
    tokens = generate_tokens(StringIO(text).readline)
    for token in tokens:
        print(tok_name[token[0]], token)

# Generated at 2022-06-11 20:05:19.270581
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from types import GeneratorType

    if not isinstance(generate_tokens(iter([]).__next__), GeneratorType):
        self.fail("test_generate_tokens: generate_tokens() doesn't return")

    gt = generate_tokens(iter(["1 + 1"]).__next__)
    tok = gt.__next__()
    self.assertEqual(tok, (NUMBER, "1", (1, 0), (1, 1), "1 + 1"))
    tok = gt.__next__()
    self.assertEqual(tok, (OP, "+", (1, 2), (1, 3), "1 + 1"))
    tok = gt.__next__()

# Generated at 2022-06-11 20:05:31.053963
# Unit test for function detect_encoding
def test_detect_encoding():

    def _run_test(buffer: List[bytes], expected: Tuple[str, List[bytes]]) -> None:
        def readline():
            for b in buffer:
                yield b

        actual = detect_encoding(readline())
        if expected != actual:
            if expected[0] != actual[0]:
                print(
                    f"test_detect_encoding(): Expected encode[0] {expected[0]}, "
                    f"got {actual[0]}"
                )
            if expected[1] != actual[1]:
                print(
                    f"test_detect_encoding(): Expected encode[1] {expected[1]}, "
                    f"got {actual[1]}"
                )
        assert expected == actual


# Generated at 2022-06-11 20:05:39.609839
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenize = Untokenizer().untokenize

    def test(iterable):
        return untokenize(iterable)

    assert test([(1, "1"), (2, "2")]) == "1 2"
    assert (
        test(
            [
                (NAME, "spam"),
                (NUMBER, "1"),
                (NAME, "spam"),
                (NUMBER, "2"),
                (NEWLINE, "\n"),
                (NAME, "spam"),
                (NUMBER, "3"),
                (NAME, "spam"),
                (NUMBER, "4"),
            ]
        )
        == "\nspam 1 spam 2\nspam 3 spam 4"
    )

# Generated at 2022-06-11 20:05:47.193063
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        """Pretend file for test_detect_encoding."""
        if not test_detect_encoding.lines:
            raise StopIteration
        line = test_detect_encoding.lines.pop(0)
        if isinstance(line, str):
            line = line.encode("ascii")
        return line


# Generated at 2022-06-11 20:05:59.566643
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline() -> bytes:
        return line.read(1)


# Generated at 2022-06-11 20:06:27.234660
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    tokens = [
        (NAME, "variable"),
        (INDENT, "\n    "),
        (NAME, "a"),
        (DEDENT, "\n"),
        (NAME, "b"),
        (NEWLINE, "\n"),
        (NAME, "c"),
    ]
    print(ut.untokenize(tokens))



# Generated at 2022-06-11 20:06:36.680003
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    from blib2to3.pygram import python_grammar
    from blib2to3.pgen2.convert import pytree_convert
    from blib2to3.pgen2 import tokenize as _tokenize
    from blib2to3.pgen2 import driver
    lines = [
        "def foo(n):\n",
        "  if n > 0:\n",
        "    return foo(n-1)\n",
        "  else:\n",
        "    return n\n",
        "\n",
    ]
    infile = StringIO("".join(lines))
    _tokenize.tokenize(infile.readline, printtoken)
    # Test that it works with the grammar as well