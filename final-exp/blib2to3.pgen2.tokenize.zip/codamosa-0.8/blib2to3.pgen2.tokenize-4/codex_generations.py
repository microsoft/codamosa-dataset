

# Generated at 2022-06-11 19:59:08.367220
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token

    readline = io.BytesIO(b"if 1: #foo\n  pass").readline
    tokens = list(generate_tokens(readline))
    assert tokens[0][:2] == (
        token.NAME,
        "if",
    )
    assert tokens[1][:2] == (
        token.NUMBER,
        "1",
    )
    assert tokens[2][:2] == (
        token.COLON,
        ":",
    )
    assert tokens[3][:2] == (
        token.COMMENT,
        "#foo",
    )
    assert tokens[4][:2] == (
        token.NEWLINE,
        "\n",
    )

# Generated at 2022-06-11 19:59:16.225596
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    unt = Untokenizer()
    unt.compat((NEWLINE, ""), [])
    assert unt.tokens == ["\n"]
    unt.compat((NAME, "abc"), [])
    assert unt.tokens == ["\n", "abc "]
    unt.tokens = []
    unt.compat((NAME, "abc"), [(NAME, "def")])
    assert unt.tokens == ["def "]
    unt.tokens = []
    unt.compat((NEWLINE, ""), [(NAME, "def")])
    assert unt.tokens == ["\n", "def "]



# Generated at 2022-06-11 19:59:27.375571
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"\xef\xbb\xbf# This is an encoding cookie!"
        yield b"pass"

    assert detect_encoding(readline) == ("utf-8-sig", [b"", b"pass"])

    def readline():
        yield b"# This is an encoding cookie!"
        yield b"pass"

    assert detect_encoding(readline) == ("utf-8", [b"", b"pass"])

    def readline():
        yield b"\xef\xbb\xbf# -*- coding: latin-1 -*-"
        yield b"pass"

    assert detect_encoding(readline) == ("utf-8-sig", [b"", b"pass"])


# Generated at 2022-06-11 19:59:29.487217
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize

    S = StringIO("print(1)\n")
    for t in tokenize.generate_tokens(S.readline):
        print(t)


# Generated at 2022-06-11 19:59:37.575916
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for c in "\n" "  # -*- coding: latin-1 -*-\n" "föö":
            yield c

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == ["", "# -*- coding: latin-1 -*-\n"]



# Generated at 2022-06-11 19:59:39.087437
# Unit test for function tokenize_loop
def test_tokenize_loop():
    for token_info in generate_tokens(test_tokenize.readline):
        tokeneater(*token_info)



# Generated at 2022-06-11 19:59:49.853615
# Unit test for function detect_encoding
def test_detect_encoding():
    # Read data in the style of tokenize.tokenize_loop
    def readline() -> bytes:
        return next(lines)

    # Test both text and binary modes
    for mode in ["r", "rb"]:
        # Some examples of valid UTF-8, with and without both BOM and cookie
        for data in (BOM_UTF8 + b"# coding: utf-8\n", BOM_UTF8 + b"# coding=utf-8\n",
            BOM_UTF8 + b"# coding=utf-8\n", b"\n", b"# coding=utf-8\n"):
            lines = iter([data])
            encoding, lines = detect_encoding(readline)
            assert encoding == "utf-8"

        # Some examples of valid UTF-8, with and without both BOM and cookie

# Generated at 2022-06-11 19:59:57.785809
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        return next(lines)

    def readline_random():
        return random.choice(lines)

    def readline_illegal():
        line = lines[0].decode("ascii", "replace")
        return line.encode("ascii", "replace")

    lines = []
    lines.append(b"# -*- coding: utf-8 -*-\n")
    lines.append(b"# comment\n")
    lines.append(b"# comment\n")
    lines.append(b"pass\n")

    assert detect_encoding(readline) == ("utf-8", lines[:2])

    lines = []
    lines.append(b"# -*- coding: iso-8859-1 -*-\n")

# Generated at 2022-06-11 20:00:01.906126
# Unit test for function generate_tokens
def test_generate_tokens():
    gt = generate_tokens("print('5x5 is %d' % 5**2)")
    gt2 = generate_tokens("await x")
    gt3 = generate_tokens("async def x(): pass")
    gt4 = generate_tokens("async for x in y: pass")
    gt5 = generate_tokens("async with x as y: pass")
    print(list(gt))
    print(list(gt2))
    print(list(gt3))
    print(list(gt4))
    print(list(gt5))


# Generated at 2022-06-11 20:00:11.626996
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test the tokenize loop with a modified tokenize_loop that accumulates
    # tokens in a list and also prints them, like tokenize_loop used to.
    # This will catch, for example, a bug that affects DebugTokens
    # where certain token types are not emitted by tokenize_loop.
    #
    # The point of this test is to check the interface of tokenize_loop,
    # not its behavior, so it's fine that we only test tokenize_loop
    # with the default printtoken handler.
    tokens = []
    def record_tokens_and_print(type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
        (srow, scol) = xxx_todo_changeme2
        (erow, ecol) = xxx_

# Generated at 2022-06-11 20:00:45.677221
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_col = 0
    u.prev_row = 1
    u.tokens = []
    u.add_whitespace((0, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.add_whitespace((1, 2))
    assert u.tokens == [" ", " "]
    u.add_whitespace((2, 2))
    assert u.tokens == [" ", " ", "\n"]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", " ", "\n", "\n"]
    u.add_whitespace((2, 1))

# Generated at 2022-06-11 20:00:49.615588
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import tokenize
    readline = iter(("True # a comment", "  +  2")).__next__
    tokenize._untokenize = Untokenizer().compat
    tokenize.tokenize(readline)



# Generated at 2022-06-11 20:01:00.785261
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import itertools
    import unittest

    class DetectEncodingTestCase(unittest.TestCase):
        def test_bom_only(self):
            stream = io.BytesIO(BOM_UTF8)
            encoding, lines = detect_encoding(stream.readline)
            self.assertEqual(encoding, "utf-8-sig")
            self.assertEqual(lines, [])

        def test_no_encoding(self):
            stream = io.BytesIO(b"#!/usr/bin/env python\n")
            encoding, lines = detect_encoding(stream.readline)
            self.assertEqual(encoding, "utf-8")
            self.assertEqual(lines, [b"#!/usr/bin/env python\n"])


# Generated at 2022-06-11 20:01:12.368171
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer = Untokenizer()


# Generated at 2022-06-11 20:01:23.927456
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO

    def readline(s):
        return BytesIO(s).readline

    def check(s, expected):
        assert detect_encoding(readline(s))[0] == expected

    # No encoding
    check(b"", "utf-8")
    check(b"\xc3\xa9\n", "utf-8")
    check(b"foo\n", "utf-8")
    check(b"#\n", "utf-8")
    check(b"#!\n", "utf-8")
    check(b"#!\n", "utf-8")
    check(b" #!\n", "utf-8")
    check(b"#! \n", "utf-8")

# Generated at 2022-06-11 20:01:33.991898
# Unit test for function detect_encoding

# Generated at 2022-06-11 20:01:43.206016
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in ("\n", "# coding: latin-1\n", "print('foo')"):
            yield line.encode("utf-8")
        raise StopIteration

    encoding, lines = detect_encoding(readline())
    assert encoding == "latin-1"
    assert lines[0] == b"\n"
    assert lines[1] == b"# coding: latin-1\n"
    assert lines[2] == b"print('foo')"
    assert len(lines) == 3

    def readline():
        yield "# coding: latin-1\n".encode("utf-8")
        raise StopIteration

    encoding, lines = detect_encoding(readline())
    assert encoding == "latin-1"

# Generated at 2022-06-11 20:01:55.457031
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize, tok_name

    def t1(x):
        # Generate token types
        for t in generate_tokens(iter(x).__next__):
            yield t[0]

    def t2(x):
        # Generate token values
        for t in generate_tokens(iter(x).__next__):
            yield t[1]

    def t12(x):
        # Generate token types, and then values
        for t in generate_tokens(iter(x).__next__):
            yield t[0]
            yield t[1]


# Generated at 2022-06-11 20:02:01.712571
# Unit test for function generate_tokens
def test_generate_tokens():
    import cStringIO
    import tokenize
    import token
    readline = cStringIO.StringIO('print "Hello World"\nx = 3\ny = 2\nif x < y:\n    print "x is less than y"\nelse:\n    print "x is not less than y"\n').readline
    tokens = generate_tokens(readline)
    token_list = list(tokens)
    expected_token_list = tokenize.generate_tokens(readline)


# Generated at 2022-06-11 20:02:09.856056
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield "# -*- coding: latin-1 -*-"
        yield ""
        yield "# Hi!"

    e, l = detect_encoding(readline)
    assert e == "iso-8859-1"
    assert l == ["# -*- coding: latin-1 -*-", "", "# Hi!"]

    def readline():
        yield "# coding: UTF-8"
        yield ""
        yield "# Hi!"

    e, l = detect_encoding(readline)
    assert e == "utf-8"
    assert l == ["# coding: UTF-8", "", "# Hi!"]

    def readline():
        yield "hi!"

    def readline():
        yield BOM_UTF8
        yield "# -*- coding: latin-1 -*-"
        yield ""

# Generated at 2022-06-11 20:03:01.997894
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in [
            b"# coding=utf-8",
            b"",
            b"",
            b"# coding=iso-8859-1",
            b"uid",
        ]:
            yield line

    encoding, _ = detect_encoding(readline)
    assert encoding == "utf-8"



# Generated at 2022-06-11 20:03:11.981074
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not lines:
            raise StopIteration
        line = lines[0]
        del lines[0]
        return line

    lines = [b"# -*- coding: latin-1 -*-"]
    encoding = detect_encoding(readline)[0]
    assert encoding == "iso-8859-1"

    lines = [b"blah blah"]
    encoding = detect_encoding(readline)[0]
    assert encoding == "utf-8"

    lines = [b"blah blah", b"# vim:fileencoding=latin-1"]
    encoding = detect_encoding(readline)[0]
    assert encoding == "iso-8859-1"


# Generated at 2022-06-11 20:03:22.879858
# Unit test for function tokenize_loop
def test_tokenize_loop():
    """Unit test for tokenize_loop"""
    import io
    import unittest
    from typing import List

    class FakeStream:
        """Fake stream for testing tokenize_loop"""

        lst: List[Text]
        index: int

        def __init__(self):
            self.lst = []
            self.index = 0

        def __call__(self):
            if self.index >= len(self.lst):
                return ""
            line = self.lst[self.index]
            self.index = self.index + 1
            return line

    class TestTokenizeLoop(unittest.TestCase):
        """Unit test for tokenize_loop"""

        def test_tokenize_loop(self):
            """Unit test for tokenize_loop"""
            fake_stream = FakeStream()

# Generated at 2022-06-11 20:03:34.095149
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from .token import tok_name, generate_tokens

    def show_tokens(input):
        print(repr(input))
        output = Untokenizer().untokenize(list(generate_tokens(input)))
        print(repr(output))

    show_tokens("def _f():\n  pass\n")
    show_tokens("def _g():\n  pass\n def h():\n  pass\n")
    show_tokens(" class C:\n  pass\n")
    show_tokens(" class D:\n  pass\n class E:\n  pass\n")

    # Test that large amounts of input whitespace are handled properly.
    # A single space will be left between non-whitespace tokens.

# Generated at 2022-06-11 20:03:42.427318
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def check_tokenize_loop(buf, result):
        import io
        import tokenize as tokenize_module
        from .token import tok_name
        result = list(result)
        toknum = tuple(x[0] for x in result)
        tokval = tuple(x[1] for x in result)
        with io.StringIO(buf) as f:
            tokenize_module.tokenize_loop(f.readline, tokeater=result.pop)
        assert toknum == tuple(x[0] for x in result)
        assert tokval == tuple(x[1] for x in result)
        # Each token type is checked against tokenize.tok_name

# Generated at 2022-06-11 20:03:51.026936
# Unit test for function tokenize
def test_tokenize():
    input = """\
a = 7
if a == 5:
    print 'a is 5'
elif a == 6:
    print 'a is 6'
else:
    print 'a is something else'
print 'done'"""
    import StringIO

    stream = StringIO.StringIO(input)

    def readline():
        return stream.readline()

    tokeneater = printtoken
    #        for token in tokenize(readline, tokeneater):
    #            pass
    tokenize(readline, tokeneater)



# Generated at 2022-06-11 20:03:57.997257
# Unit test for function detect_encoding
def test_detect_encoding():
    def _get_data(present: str) -> bytes:
        return bytes(present + '\n"abc"\n', "ascii")

    def _check_encoding(present: str, expect: str) -> None:
        data = _get_data(present)
        encoding, lines = detect_encoding(data.splitlines)
        assert encoding == expect, f"failed on {present!r}: got {encoding!r}"

    _check_encoding("# coding=utf-8", "utf-8")
    _check_encoding("#coding=utf-8", "utf-8")
    _check_encoding(" # coding=utf-8", "utf-8")
    _check_encoding("#coding:utf-8", "utf-8")

# Generated at 2022-06-11 20:04:07.111510
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not test_cases:
            raise StopIteration
        return test_cases.pop(0)

    test_cases = [
        bytes(
            """\
# -*- coding: latin-1 -*-
from __future__ import division, unicode_literals
""",
            "ascii",
        ),
        bytes(
            """\
#!/usr/bin/python
# -*- coding: ascii -*-
"""
        ),
        bytes(
            """\
# This is the Python code to accompany
# "The Ultimate Computer Scientist Fit Test" by Guido van Rossum.
# -*- coding: utf-8 -*-
"""
        ),
    ]
    encodings = ["latin-1", "ascii", "utf-8"]
   

# Generated at 2022-06-11 20:04:17.062975
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        return bytes()

    assert detect_encoding(readline) == ("utf-8", [])

    def readline():
        yield b"# -*- coding: iso-8859-1 -*-"

    assert detect_encoding(readline) == ("iso-8859-1", [b"# -*- coding: iso-8859-1 -*-"])

    def readline():
        yield b"#!/usr/bin/python"

    assert detect_encoding(readline) == ("utf-8", [b"#!/usr/bin/python"])

    def readline():
        yield b"#!/usr/bin/python"
        yield b"# -*- coding: latin-1 -*-"


# Generated at 2022-06-11 20:04:22.191252
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    t = (NAME, "test")
    iterable = ((NUMBER, "1"), (NEWLINE, ""), (NEWLINE, ""), (NAME, "test"))
    res = u.compat(t, iterable)
    assert res is None
    assert u.tokens == ["test ", "1\n", "\ntest"]



# Generated at 2022-06-11 20:04:58.913874
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        # simulate opening a file in "rU" mode
        yield b"^# coding: latin-1\n"
        yield b"import sys"
        yield b"\n"
        raise StopIteration

    encoding, first_two_lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert first_two_lines == [b"^# coding: latin-1\n", b"import sys"]

    def readline():
        yield b"^# coding: latin-1\n"
        yield b"#!/usr/bin/env python\n"
        yield b"# This comment is completely ignored\n"
        yield b"\n"
        yield b"print('hi')\n"
        raise StopIteration

    encoding, first_

# Generated at 2022-06-11 20:05:09.841848
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test detection of UTF-8 BOM
    bomless = open("tokenize_tests.txt", "rb")
    bomful = open("tokenize_tests.txt.bom", "rb")
    encoding, lines = detect_encoding(bomless.readline)
    assert encoding == "utf-8"
    assert lines == []
    encoding, lines = detect_encoding(bomful.readline)
    assert encoding == "utf-8-sig"
    assert lines == []
    bomless.close()
    bomful.close()

    # Test detection of coding spec
    coding_spec_path = "tokenize_tests.txt.coding"
    coding_spec = open(coding_spec_path, "rb")
    encoding, lines = detect_encoding(coding_spec.readline)

# Generated at 2022-06-11 20:05:18.438569
# Unit test for function tokenize
def test_tokenize():
    import sys
    import test.test_tokenize
    test.test_tokenize.tokenize_test(tokenize)
    try:
        tokenize(iter([]).__next__)
    except StopTokenizing:
        pass
    else:
        raise Exception("failed to raise StopTokenizing")
    tokenize(iter(["raise StopTokenizing  # exception"]).__next__)
    try:
        from io import StringIO

        f = StringIO("raise StopTokenizing  # exception\n")
        tokenize(f.readline)
    except StopTokenizing:
        pass
    else:
        raise Exception("failed to raise StopTokenizing")



# Generated at 2022-06-11 20:05:26.841572
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    # Make sure that the tokenize() generator is working properly.
    examples = [
        """def f(x):
        return 2*x"""
    ]

    for ex in examples:
        infile = StringIO(ex)
        toks = generate_tokens(infile.readline)
        toks = list(toks)

        for (tok, tokval) in toks:
            print("%s:%s" % (toknames[tok], tokval))


# Generated at 2022-06-11 20:05:37.776221
# Unit test for function generate_tokens
def test_generate_tokens():
    def testit(input, expected):
        readline = iter(input.split('\n')).__next__
        result = list(generate_tokens(readline))
        if result != expected:
            raise ValueError('lines differ:\n%r\n%r' % (result, expected))

    def test(input):
        testit(input, expected)
        # Try it with a trailing newline
        testit(input + '\n', expected)
        # Try it with CRLF
        testit(input.replace('\n', '\r\n'), expected)
        # Try it with a trailing CRLF
        testit(input.replace('\n', '\r\n') + '\r\n', expected)

    test('''\
        def f():
            pass
    ''')

# Generated at 2022-06-11 20:05:46.443809
# Unit test for function generate_tokens
def test_generate_tokens():
    def test_input(input: str, expected: List[TokenInfo]) -> None:
        tokens = list(tokenize(StringIO(input).readline))
        assert tokens == expected

    test_input('"asdf"\n', [(STRING, '"asdf"', (1, 0), (1, 5), '"asdf"\n')])
    test_input('"""asdf"""\n', [(STRING, '"""asdf"""', (1, 0), (1, 8), '"""asdf"""\n')])
    test_input(
        '"""asdf\\n"""\n', [(STRING, '"""asdf\\n"""', (1, 0), (2, 0), '"""asdf\\n"""\n')]
    )

# Generated at 2022-06-11 20:05:59.479769
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    s = """def f(x):
    return 2*x
"""
    f = io.BytesIO(s.encode("utf-8"))
    results = []

    def tokeneater(*args):
        results.append(args)
    tokenize_loop(f.readline, tokeneater)

# Generated at 2022-06-11 20:06:07.298243
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def check(input, expected):
        tokens = tokenize_loop(iter([input]).__next__, lambda *args: None)
        assert list(tokens) == expected
    check('x = "foo"', [
        (1, 'x', (1, 0), (1, 1), 'x = "foo"'),
        (51, '=', (1, 2), (1, 3), 'x = "foo"'),
        (3, '"foo"', (1, 4), (1, 9), 'x = "foo"'),
        ])
    check('"""\n"""', [
        (3, '"""\n"""', (1, 0), (2, 3), '"""\n"""'),
        ])

# Generated at 2022-06-11 20:06:12.076559
# Unit test for function generate_tokens
def test_generate_tokens():
    from pprint import pprint
    with open("untokenize.py") as f:
        pprint(list(tokenize.generate_tokens(f.readline)))


if __name__ == "__main__":
    test_generate_tokens()

# Generated at 2022-06-11 20:06:22.384274
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import BytesIO
    from tokenize import tokenize as _tokenize, untokenize as _untokenize
    from tokenize import COMMENT, NL, NAME, NUMBER, OP, STRING, tok_name

    def tokenize(*args):
        return (tok[:2] for tok in _tokenize(*args))

    def untokenize(iterable):
        return _untokenize(iterable).decode("utf-8")

    def untokenize_compat(iterable):
        ut = Untokenizer()
        return ut.compat(next(iterable), iterable)

    def check(code_bytes):
        check_iterable(tokenize(BytesIO(code_bytes).readline))
        assert untokenize(tokenize(BytesIO(code_bytes).readline)) == code_bytes