

# Generated at 2022-06-11 19:58:10.421224
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # gensrc: ignore
    from blib2to3.tests import test_tokenize

    u = Untokenizer()
    input = test_tokenize.untokenize(iter([(0, "x")]))
    assert u.compat((0, "x"), iter([(0, "y")])) == None
    assert u.untokenize(iter([])) == "xy\n"



# Generated at 2022-06-11 19:58:19.772182
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    readline = io.StringIO("""if 1:
    print('foo')
""").readline
    result = [
        (token.NAME, "if"),
        (token.NUMBER, "1"),
        (token.OP, ":"),
        (token.NEWLINE, "\n"),
        (token.INDENT, "\t"),
        (token.NAME, "print"),
        (token.OP, "("),
        (token.STRING, "'foo'"),
        (token.OP, ")"),
        (token.NEWLINE, "\n"),
        (token.DEDENT, ""),
        (token.ENDMARKER, ""),
    ]
    for t in result:
        tok = next(generate_tokens(readline))

# Generated at 2022-06-11 19:58:31.385203
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in lines[:1]:
            yield line
    lines = [b'# -*- coding: latin-1 -*-\n']
    assert detect_encoding(readline) == ('iso-8859-1', lines)
    lines = [b'\xef\xbb\xbflatin-1\n']
    assert detect_encoding(readline) == ('utf-8-sig', lines)
    lines = [b'\xef\xbb\xbflatin-1\n', b'# -*- coding: latin-1 -*-\n']
    assert detect_encoding(readline) == ('utf-8-sig', lines)

# Generated at 2022-06-11 19:58:36.578487
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    r = tokenize.generate_tokens(iter(['a,b = 1,2']).__next__)
    map(print, r)
    print('=' * 20)
    r = tokenize.generate_tokens(iter(['x = "\\"y\\""']).__next__)
    map(print, r)
                  
test_generate_tokens()

from tokenize import tokenize, untokenize, untokenize_nested
from io import BytesIO


# Generated at 2022-06-11 19:58:37.317187
# Unit test for function generate_tokens

# Generated at 2022-06-11 19:58:43.234064
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1"
        yield b"\n"
        yield b"# coding=ascii"
    encoding, consumed = detect_encoding(readline().__next__)
    assert encoding == "iso-8859-1"
    assert consumed == [b"# coding: latin-1\n", b"# coding=ascii"]
    def readline():
        yield b"#! /usr/bin/env python3\n"
        yield b"# -*- coding: ascii -*-"
    encoding, consumed = detect_encoding(readline().__next__)
    assert encoding == "ascii"

# Generated at 2022-06-11 19:58:50.930284
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # Create a list of tokens to be untokenized
    token_list = [
        (tokenize.NUMBER, '1'),
        (tokenize.NUMBER, '2'),
        (tokenize.NUMBER, '3'),
        (tokenize.NEWLINE, ''),
        (tokenize.INDENT, ''),
        (tokenize.NUMBER, '4'),
        (tokenize.DEDENT, ''),
        (tokenize.DEDENT, ''),
        (token.ENDMARKER, ''),
        ]
    # Instantiate an Untokenizer
    untok = tokenize.Untokenizer()
    # Get the output of method untokenize
    output = untok.untokenize(token_list)
    # Compare the output with the expected string

# Generated at 2022-06-11 19:59:03.508698
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-11 19:59:14.393922
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenize = Untokenizer().untokenize
    def check(input, output):
        result = untokenize(generate_tokens(iter(input).__next__))
        # if result != output:
        #     import pprint, difflib
        #     pprint.pprint(input)
        #     print("->")
        #     pprint.pprint(result)
        #     print("Expected ->")
        #     pprint.pprint(output)
        #     print("Diff ->")
        #     print(''.join(difflib.ndiff(result.splitlines(1), output.splitlines(1))))
        assert result == output, "\n" + str(result) + "\n" + str(output)

# Generated at 2022-06-11 19:59:26.068821
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io, unittest
    from test.support import captured_stdout

    class TestTokenize(unittest.TestCase):
        def setUp(self):
            self.readline = io.StringIO("def f(x): return 2*x\n").readline
            self.tokeneater = TestTokenize.TokenEater()
        def test_tokenize(self):
            tokenize_loop(self.readline, self.tokeneater)

# Generated at 2022-06-11 20:00:36.946091
# Unit test for function generate_tokens
def test_generate_tokens():
    # Create a sample source file
    with open("_test_tokenize.txt", "w") as f:
        f.write("if a > 3: #comment\r\n  pass\r\n")

    # Tokenize the file
    with open("_test_tokenize.txt", "r") as f:
        tokengen = generate_tokens(f.readline)
        tokens = list(tokengen)

    # Remove the temporary file
    import os
    os.unlink("_test_tokenize.txt")

    # Check the results

# Generated at 2022-06-11 20:00:41.575325
# Unit test for function detect_encoding
def test_detect_encoding():
    b = bytes
    def make_readline(s):
        s = iter(s.split(b("\n")))
        def readline():
            return next(s) + b("\n")
        return readline
    def assert_encoding_result(s, encoding, lines=None):
        eq = assert_equal
        if lines is None:
            lines = [b(s)]
        rl = make_readline(s)
        res = detect_encoding(rl)
        eq(res, (encoding, lines))
    assert_encoding_result(b"\xef\xbb\xbf# coding: latin-1\n", "latin-1")

# Generated at 2022-06-11 20:00:53.270237
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'\xEF\xBB\xBF# coding: utf8\n'
        yield b'# more comment on the 1st line'
        yield b'\n'
        yield b'b = 5\n'
    assert detect_encoding(readline) == ('utf-8-sig', [b'# coding: utf8\n', b'b = 5\n'])

    def readline():
        yield b'# -*- coding: utf8 -*-\n'
        yield b'# more comment on the 1st line'
        yield b'\n'
        yield b'b = 6\n'

# Generated at 2022-06-11 20:00:56.704411
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    it = iter(((1, 'a'), (2, 'b'), (3, 'c')))
    assert untok.untokenize(it) == 'a b c'



# Generated at 2022-06-11 20:01:07.928792
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens, untokenize, NUMBER, NAME, STRING

    def remove_comments(tokens):
        """Remove comments and NLs from the token stream"""
        for toknum, tokval, _, _, _ in tokens:
            if toknum != NUMBER:
                yield (toknum, tokval)

    def norm(s):
        """Normalize NLs"""
        return s.replace("\r\n", "\n")

    text = '''1 + 1
    # A comment
    a, b = ''' + repr(r'a\r\nb') + '''
    a'''
    f = StringIO(text)
    tok1 = list(remove_comments(generate_tokens(f.readline)))


# Generated at 2022-06-11 20:01:20.357657
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test tokenize_loop function

    # Save the standard tokeneater
    stdtokeneater = tokenize.tokeneater
    # Define another tokeneater that appends the token to a list
    token_list = []

    def listtokeneater(type, token, start, end, line):
        token_list.append(token)

    try:
        # Set listtokeneater as tokeneater
        tokenize.tokeneater = listtokeneater
        # Call tokenize_loop
        tokenize_loop(iter(["x = 3"]).__next__, None)
        # Check the list
        assert token_list == ["x", "=", "3"]
    finally:
        # Restore the standard tokeneater
        tokenize.tokeneater = stdtokene

# Generated at 2022-06-11 20:01:31.768809
# Unit test for function tokenize_loop
def test_tokenize_loop():

    def generate_tokens_1(readline):
        yield 1, 'foo', (0, 0), (0, 3), 'foo'

    def generate_tokens_2(readline):
        yield 1, 'foo', (0, 0), (0, 3), 'foo'
        raise StopTokenizing

    def generate_tokens_3(readline):
        yield 1, 'foo', (0, 0), (0, 3), 'foo'
        yield 2, 'bar', (0, 0), (0, 3), 'bar'
        raise StopTokenizing

    def generate_tokens_4(readline):
        yield 1, 'foo', (0, 0), (0, 3), 'foo'
        yield 2, 'bar', (0, 0), (0, 3), 'bar'


# Generated at 2022-06-11 20:01:42.278024
# Unit test for function tokenize
def test_tokenize():
    import io
    import token as py_token
    import blib2to3.pgen2.token as token

    # This is all bytes on py2, str on py3
    f = io.StringIO("if 1: # Not a comment\n  pass\n# A comment\nif 1: # Not a comment\n  pass\n")
    result = []
    tokeneater = result.append
    tokenize(f.readline, tokeneater)


# Generated at 2022-06-11 20:01:54.691195
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens, COMMENT, ENDMARKER, NAME, OP, STRING
    readline = StringIO("# A comment\n"
                        "a + 3 # Another\n"
                        '"""A\\\n'
                        'multiline\\\n'
                        'string"""\n'
                        '"""Another"""\n'
                        '""\n'
                        '"\n'
                        '"\x00"').readline
    tokengen = generate_tokens(readline)
    for token in tokengen:
        print(token)
    print("--")
    for tokentype, token, start, end, line in generate_tokens(readline):
        assert token == line[start[1] : end[1]]
       

# Generated at 2022-06-11 20:02:01.012820
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    data = (
        'for i in range(10): print(i)\n'
        '  \f\t\vprint("done")\n'
    )
    toklist = [tok[:2] for tok in tokenize.generate_tokens(iter(data.splitlines(1)).__next__)]

# Generated at 2022-06-11 20:02:36.648108
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    fp = io.StringIO("def f():\n  pass\n")
    tokens = list(tokenize(fp.readline))


# Generated at 2022-06-11 20:02:42.089275
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untk = Untokenizer()
    from io import StringIO
    from . import tokenize
    tk = tokenize.generate_tokens(StringIO("1 + 2").readline)
    untk.untokenize(tk)
    tokenize.tokenize(StringIO("1 + 2").readline, untk.tokeneater)
    assert untk.tokens == ["1 ", "+ ", "2 "]


from typing import overload



# Generated at 2022-06-11 20:02:48.469900
# Unit test for function detect_encoding
def test_detect_encoding():
    def tokenize_helper(source, expected_encoding, expected_tokens):
        sio = io.StringIO(source)
        encoding, lines = detect_encoding(sio.readline)
        assert encoding == expected_encoding
        assert lines == expected_tokens
        next_line = sio.readline
        tokens = []
        for token in generate_tokens(next_line):
            tokens.append(token)
        return tokens

    # No encoding specifier.
    tokens = tokenize_helper("", "utf-8", [])
    assert tokens == []

    # BOM.
    tokens = tokenize_helper("\ufeff\n", "utf-8-sig", ["\n"])

# Generated at 2022-06-11 20:03:00.500401
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token

    input_src = io.StringIO("if 1:\n  pass\n")
    expected_tokens = [
        (token.NAME, "if"),
        (token.NUMBER, "1"),
        (token.OP, ":"),
        (token.NEWLINE, "\n"),
        (token.INDENT, "\n  "),
        (token.NAME, "pass"),
        (token.NEWLINE, "\n"),
        (token.DEDENT, ""),
        (token.ENDMARKER, ""),
    ]
    tokeneater = []  # type: List[Tuple[int, Text]]
    tokenize_loop(input_src.readline, tokeneater.append)
    assert tokeneater == expected_tokens



# Generated at 2022-06-11 20:03:02.584597
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:03:12.429928
# Unit test for function generate_tokens
def test_generate_tokens():
    tests = {}

# Generated at 2022-06-11 20:03:16.733906
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    """
    >>> from StringIO import StringIO
    >>> untok = Untokenizer()
    >>> untok.untokenize(generate_tokens(StringIO('a = 1 + 1\\n').readline))
    'a = 1 + 1\\n'
    """



# Generated at 2022-06-11 20:03:25.243457
# Unit test for function tokenize
def test_tokenize():
    import io
    import token

    readline = io.BytesIO(b"def f(a): return a+1").readline
    tokens = []
    tokeneater = tokens.append
    tokenize(readline, tokeneater)

# Generated at 2022-06-11 20:03:36.173271
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: UTF-8 -*-"
        yield b"pass"

    assert detect_encoding(readline) == ("utf-8", [b"# -*- coding: UTF-8 -*-\n"])

    def readline():
        yield b"# coding: GBK"
        yield b"pass"

    assert detect_encoding(readline) == ("gbk", [b"# coding: GBK\n"])

    def readline():
        yield b"# -*- coding: UTF-8 -*-"
        yield b"# -*- coding: cp932 -*-"
        yield b"pass"

    try:
        detect_encoding(readline)
    except SyntaxError:
        pass

# Generated at 2022-06-11 20:03:40.357694
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    # Test with a source string.
    token_list = generate_tokens(io.StringIO("x = 3 + 4").readline)
    correct_answer = [
        (1, "x", (1, 0), (1, 1), "x = 3 + 4"),
        (2, "=", (1, 2), (1, 3), "x = 3 + 4"),
        (1, "3", (1, 4), (1, 5), "x = 3 + 4"),
        (2, "+", (1, 6), (1, 7), "x = 3 + 4"),
        (1, "4", (1, 8), (1, 9), "x = 3 + 4"),
        (0, "", (1, 9), (1, 9), "x = 3 + 4"),
    ]
   

# Generated at 2022-06-11 20:04:19.593833
# Unit test for function detect_encoding

# Generated at 2022-06-11 20:04:31.909957
# Unit test for function detect_encoding
def test_detect_encoding():

    # Encoding is utf-8 and no BOM.
    def readline1() -> bytes:
        yield "abc = 'abc'"
    encoding, lines = detect_encoding(readline1)
    assert encoding == "utf-8"
    assert lines == [b"abc = 'abc'"]

    # Encoding is utf-8 and BOM.
    def readline2() -> bytes:
        yield BOM_UTF8
        yield "abc = '中文'"
    encoding, lines = detect_encoding(readline2)
    assert encoding == "utf-8-sig"

# Generated at 2022-06-11 20:04:43.141264
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    r = "[a-zA-Z_]\w*" # using this as a pattern for matching identifiers
    s = generate_tokens(open('tokenize_generator.py').readline)
    for i in s:
        if i[0] == token.NAME:
            if i[1] != "r": 
                print(i)
                print(repr(i[1]))
            assert i[1] == r
    print('ok')
test_generate_tokens()

import token
from utils import extract_all_identifiers

ids = extract_all_identifiers(open('tokenize_generator.py').readline)
print(len(ids))

from itertools import islice

# Generated at 2022-06-11 20:04:53.562510
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(t_type, t_string, t_start, t_end, t_line, line_num, column,
                    token_list=None):
        assert t_type == token_list[0]
        assert t_string == token_list[1]
        assert t_start[0] == line_num
        assert t_start[1] == column
        assert t_end[0] == line_num
        assert t_end[1] == column + len(token_list[1])
        assert t_line == token_list[4]

    def check_indent(token_type, token_string, start_pos, end_pos, line,
                     num_indents, line_num, column=0, token_list=None):
        assert token_type == token_list[0]

# Generated at 2022-06-11 20:04:58.236731
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    unt = Untokenizer()
    unt.add_whitespace((1, 0))
    unt.add_whitespace((1, 10))
    assert unt.untokenize([]) == "          "
    unt = Untokenizer()
    unt.add_whitespace((2, 0))
    unt.add_whitespace((1, 10))
    assert unt.untokenize([]) == "\n          "
    unt = Untokenizer()
    unt.add_whitespace((2, 10))
    unt.add_whitespace((1, 0))
    assert unt.untokenize([]) == "\n\n"



# Generated at 2022-06-11 20:04:58.946264
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # TODO: Needs unit tests.
    pass



# Generated at 2022-06-11 20:05:02.798435
# Unit test for function tokenize_loop
def test_tokenize_loop():
    global count
    count = 0
    def readline():
        global count
        count += 1
        return "line %d\n" % count
    tokenize_loop(readline, lambda toktype, tok, srow_scol, erow_ecol, line: None)
    assert count == 101  # 50 + 51 for expected end-of-line tokens


# ========================================================================
#
#   The "tokenize" function itself, with no external dependencies.
#
# ========================================================================

# Note: this code (from tokenize.c) is also used to tokenize single-line
# strings.  That's why it's not necessary to check for a newline in
# the string (any newline in a one-line string is an error).


# Generated at 2022-06-11 20:05:14.797859
# Unit test for function tokenize
def test_tokenize():
    import sys, tokenize

    def readline():
        return sys.stdin.readline()


# Generated at 2022-06-11 20:05:27.776047
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test that the tokenize_loop() function doesn't crash.
    def loopback(readline):
        for token in generate_tokens(readline):
            yield token

        # Test that tokenize_loop() doesn't crash on bad input
        for bad_input in ("\x00\x00\x00\x00\x00", "\x00\x00\x00\x01\x00"):
            try:
                tokenize_loop(lambda: bad_input, tokeneater=None)
                raise AssertionError("should have raised a TokenError")
            except TokenError:
                pass

        # Test that tokenize_loop() doesn't crash on bad token
        def bad_token():
            yield (1, "", (1, 0), (1, 0), "")
            raise ValueError("bad token")

# Generated at 2022-06-11 20:05:38.196304
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test ascii as a default
    assert detect_encoding(iter("").__next__)[0] == "utf-8"
    assert detect_encoding(iter(" \n").__next__)[0] == "utf-8"

    # Test blank line detection
    assert detect_encoding(iter("\n").__next__)[0] == "utf-8"
    assert detect_encoding(iter(" \n").__next__)[0] == "utf-8"
    assert detect_encoding(iter("\n ").__next__)[0] == "utf-8"
    assert detect_encoding(iter("\n # \n").__next__)[0] == "utf-8"
    assert detect_encoding(iter(" \n \n").__next__)[0] == "utf-8"
    assert detect

# Generated at 2022-06-11 20:06:14.416203
# Unit test for function generate_tokens
def test_generate_tokens():
    import sys, tokenize
    if sys.argv[1:]:
        fn = sys.argv[1]
    else:
        fn = __file__  # Case this is run embedded in test suite
    f = open(fn, "rb")
    try:
        tokens = tokenize.generate_tokens(f.readline)
        for token in tokens:
            print(tokenize.tok_name[token[0]], token[1])
    finally:
        f.close()


# Generated at 2022-06-11 20:06:22.161643
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    toksource = iter(
        [
            (NAME, "if"),
            (NAME, "True"),
            (OP, ":"),
            (NEWLINE, "\n"),
            (INDENT, "\t"),
            (NAME, "print"),
            (NAME, "True"),
            (NEWLINE, "\n"),
            (DEDENT, ""),
        ]
    )
    assert untok.untokenize(toksource) == "if True:\n\tprint True\n"



# Generated at 2022-06-11 20:06:34.275884
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(iterable):
        def readline():
            try:
                return iterable.pop(0)
            except IndexError:
                raise StopIteration
        return readline
    def check(expected_encoding, lines, expected_buffer=None):
        if expected_buffer is None:
            expected_buffer = []
        result = tuple(detect_encoding(readlines(lines)))
        if result != (expected_encoding, expected_buffer):
            raise ValueError(
                'detect_encoding() returned %r, expected (%r, %r)' %
                (result, expected_encoding, expected_buffer))
    check("utf-8",
          [b"# coding=utf-8\n"],
          [b"# coding=utf-8\n"])

# Generated at 2022-06-11 20:06:39.926114
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    def match(input: Iterable[TokenInfo], expected: Text) -> None:
        assert untok.compat(input[0], input[1:]) == expected
    match([(NUMBER, "1 "), (PLUS, "+"), (NUMBER, "2")], "1 + 2")
    match([(NAME, "abc"), (EQUAL, "="), (NAME, "def"), (PLUS, "+"), (NAME, "ghi")], "abc = def + ghi")
    match([(NAME, "abc"), (COMMA, ","), (NEWLINE, "\n"), (NAME, "def")], "abc,\ndef")
    # Unit test for method add_whitespace of class Untokenizer