

# Generated at 2022-06-11 19:58:28.290456
# Unit test for function tokenize
def test_tokenize():
    # check the correctness of the tokens generated
    readline = iter(
        """if 1:
# foo
        # bar
        pass# baz
        pass
        """.splitlines(keepends=True)
    ).__next__
    tokeneater = token.TokenInfo.from_tuple

    tokens = []

    def collector(type, token, start, end, line):
        assert line == readline()
        tokens.append(token.encode("ascii"))

    tokenize(readline, collector)
    assert tokens == [
        b"if",
        b"1",
        b":",
        b"pass",
        b"pass",
        b"",
    ]



# Generated at 2022-06-11 19:58:31.631308
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.STRING, "1", (1, 1), (1, 1), "1")



# Generated at 2022-06-11 19:58:37.898424
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test BOM's
    lines = [
        (b"coding=utf-8", "utf-8"),
        (b"#coding:utf-8", "utf-8"),
        (b"# -*- coding: utf-8 -*-", "utf-8"),
    ]
    for line in lines:
        assert detect_encoding(iter(line[0:1]).__next__) == (line[1], [line[0]])
    # Test BOM without coding
    assert detect_encoding(iter(BOM_UTF8).__next__) == ("utf-8-sig", [])


# generate_tokens() creates a sequence of tokens from an input string.

# Generated at 2022-06-11 19:58:43.800044
# Unit test for function detect_encoding
def test_detect_encoding():
    def _try_detect_encoding1(line1: bytes, line2: bytes, expected: str) -> None:
        lines = []
        def readline() -> bytes:
            lines.append(line1)
            line1[:] = line2
            return lines.pop()
        got = detect_encoding(readline)
        assert (
            got[0] == expected
        ), f"encoding detection failed, expected {expected}, got {got[0]}"
        assert lines == [], f"encoding detection read too many lines, got {lines}"

    def _try_detect_encoding2(line1: bytes, expected: str) -> None:
        lines = []
        def readline() -> bytes:
            lines.append(line1)
            raise StopIteration

# Generated at 2022-06-11 19:58:56.510474
# Unit test for function detect_encoding
def test_detect_encoding():
    if sys.version_info[:2] < (2, 7):
        raise ImportError("this test requires Python 2.7")
    def readline():
        yield "this is a test"
        yield "# coding: latin-1"
        raise StopIteration
    encoding, lines = detect_encoding(readline().__next__)
    assert encoding == "iso-8859-1"
    assert lines == ["this is a test", "# coding: latin-1"]
    def readline():
        yield "#! /usr/bin/env python3"
        yield "# coding=foo-bar"
        raise StopIteration
    pytest.raises(SyntaxError, detect_encoding, readline().__next__)
    def readline():
        yield "#! /usr/bin/env python3"

# Generated at 2022-06-11 19:59:02.200138
# Unit test for function printtoken
def test_printtoken():
    test("a")
    test("a b")
    test("a\n")
    test("a\n\n")
    test("a b\n")
    test("a\nb\n")
    test("a\nb")
    test("a \"a\"")
    test("a\n\"a\"\n")
    test("a\n\"a\"")
    test("a\n\"a\" b")
    test("a 'a'")
    test("a\n'a'\n")
    test("a\n'a'")
    test("a\n'a' b")
    test("a \"a\" 'b' c")
    test("a \"a\"\n'b'\nc")
    test("a \"a\"\n'b'\nc\n")

# Generated at 2022-06-11 19:59:13.935627
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    unt = Untokenizer()
    test_tokens = [
        (NAME, "for"),
        (NAME, "x"),
        (IN, "in"),
        (NAME, "range"),
        (OPEN_PAREN, "("),
        (NUMBER, "0"),
        (COMMA, ","),
        (NUMBER, "5"),
        (CLOSE_PAREN, ")"),
        (COLON, ":"),
        (NEWLINE, "\n"),
        (INDENT, "    "),
        (NAME, "print"),
        (NAME, "x"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (NAME, "print"),
        (NAME, "x"),
        (ENDMARKER, ""),
    ]

# Generated at 2022-06-11 19:59:19.655149
# Unit test for function printtoken
def test_printtoken():
    printtoken(tokenize.NAME, 'name', (2, 3), (2, 4), 'this is a line')
    # XXX This line should not throw an exception
    printtoken(tokenize.NAME, 'name', (2, 3), 'this is a line')
test_printtoken()



# Generated at 2022-06-11 19:59:23.529664
# Unit test for function generate_tokens
def test_generate_tokens():
    res = list(generate_tokens(iter(['>>> x=1']).__next__))
    assert (res[0] == (NAME, 'x', (1, 3), (1, 4), '>>> x=1'))

# Test generate_tokens for keywords

# Generated at 2022-06-11 19:59:33.746863
# Unit test for function tokenize
def test_tokenize():
    import io

    src = io.StringIO("foo = 'bar'\n")

    def readline(x):
        return src.readline()

    def tokeneater(type, token, srow_scol, erow_ecol, logical_lineno):
        print(
            (
                tokenize.tok_name[type],
                token,
                srow_scol,
                erow_ecol,
                logical_lineno,
                len(tokenize.untokenize([(type, token)]))
            )
        )

    tokenize(readline, tokeneater)



# Generated at 2022-06-11 20:00:19.654323
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from unittest.mock import patch

    def get_token_list(input_string: str) -> List[GoodTokenInfo]:
        tokens = []
        with patch("builtins.print") as pr:
            with patch("tokenize.detect_encoding", lambda x: ("utf-8", [])):
                with patch("tokenize.open", lambda x: StringIO(input_string)):
                    for token in tokenize.generate_tokens(tokenize.open("foo").readline):
                        tokens.append(token)
        return tokens


# Generated at 2022-06-11 20:00:28.290070
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test encoding detection
    s = "def foo():\n    pass"
    t0 = [
        (token.NAME, "def"),
        (token.NAME, "foo"),
        (token.OP, "("),
        (token.OP, ")"),
        (token.OP, ":"),
        (token.NEWLINE, "\n"),
        (token.INDENT, "\t"),
        (token.NAME, "pass"),
        (token.DEDENT, ""),
        (token.ENDMARKER, ""),
    ]
    for name, encoding in ("test_tokenize", "utf-8"), ("test_tokenize", "latin-1"):
        sname = name + "." + encoding

# Generated at 2022-06-11 20:00:30.889728
# Unit test for function printtoken
def test_printtoken():
    tok = tokenize.TokenInfo(token.NAME, "print", (0, 0), (0, 5), "print(1)")
    printtoken(*tok)



# Generated at 2022-06-11 20:00:38.813933
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    from token import *
    toks = generate_tokens(StringIO("def f():\n  return").readline)

# Generated at 2022-06-11 20:00:50.209863
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    def strip(input_string: str) -> str:
        """Return a version of the input with the whitespace removed."""
        return "".join(c for c in input_string if not c.isspace())


# Generated at 2022-06-11 20:01:01.456922
# Unit test for function generate_tokens
def test_generate_tokens():
    import sys
    src = """
for i in range(10):
    print(i)
"""
    if sys.version_info[0] == 3:
        src = src.encode('ascii')
    # Testing round-trip identity (tokens->string->tokens), and
    # verifying that the string matches the original source for
    # multiple levels of pretty-print.

# Generated at 2022-06-11 20:01:05.471192
# Unit test for function tokenize
def test_tokenize():
    import io

    s = io.StringIO("def f(x): return 'x'*x")
    g = generate_tokens(s.readline)
    for t in g:
        printtok(t)



# Generated at 2022-06-11 20:01:12.368080
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io, token
    f = io.StringIO("if 1:\n    x = 2\n")
    for token in generate_tokens(f.readline):
        print(token)
    f = io.StringIO("if 1:\n    x = 2\n")
    readline = f.readline
    def tokeneater(*args):
        print(args)
    tokenize_loop(readline, tokeneater)
test_tokenize_loop()



# Generated at 2022-06-11 20:01:13.314915
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    pass



# Generated at 2022-06-11 20:01:18.812442
# Unit test for function generate_tokens
def test_generate_tokens():
    import pprint
    import sys
    try:
        import _tokenize
    except ImportError:
        return
    sys.stdin.reconfigure(encoding='utf-8')
    pprint.pprint(list(_tokenize.generate_tokens(sys.stdin.readline)))

# Generated at 2022-06-11 20:01:54.278325
# Unit test for function tokenize
def test_tokenize():
    import tokenize as tokenize_mod
    import io
    import sys

    # This code based on the lib2to3 test_tokenize
    for filename in ["tokenize_tests.txt", "tokenize_pythontokens.txt"]:
        with open(
            filename, encoding="utf-8", errors="surrogateescape"
        ) as tokenize_tests:
            for line in tokenize_tests:
                if not line.strip():
                    continue

                # Tokenize the line.
                f = io.StringIO(line)
                tokens = []
                try:
                    generate_tokens(f.readline, tokens.append)
                except tokenize_mod.TokenError as msg:
                    # If self.debug is set, raise an exception instead of
                    # continuing
                    if __debug__:
                        raise


# Generated at 2022-06-11 20:02:05.721099
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # Disassembler version
    untok = Untokenizer()
    def untok_test(input: str, output: str) -> None:
        # Do it all at once, so that the tests can count on the entire
        # input being passed through the tokenizer at once.
        it = generate_tokens(input.splitlines().__next__)
        result = untok.untokenize(it)
        assert result == output, result + " != " + output

    untok_test("def f():\n  print(42)\n", "def f():\n  print(42)\n")
    untok_test('if 1: print(2)\nelse: print(3)\n', 'if 1: print(2)\nelse: print(3)\n')

# Generated at 2022-06-11 20:02:13.168994
# Unit test for function generate_tokens
def test_generate_tokens():
    # This file has conditional compilation, so ignore the warning
    # about missing tokens.
    import warnings

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", ".*", DeprecationWarning, "tokenize")
        from tokenize import tokenize

    with open(__file__) as f:
        tokens = list(tokenize(f.readline))
    # Remove token_index, which can change
    for t in tokens:
        del t[-1]
    # Change everything to tuples
    tokens = [tuple(t) for t in tokens]
    assert list(tokenize(iter(tokens).__next__)) == tokens



# Generated at 2022-06-11 20:02:25.583714
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline_generator(s):
        for line in s.splitlines(keepends=True):
            yield line
    def tokeneater_collector(arg):
        printtoken(arg)
    s = 'for i in range(10):\n    print(i)'
    tokens = []
    tokenize_loop(readline_generator(s), tokens.append)

# Generated at 2022-06-11 20:02:31.003160
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def nop(type, token, start, end, line):
        pass
    tokenize_loop(iter("").__next__, nop)
    tokenize_loop(iter("abc").__next__, nop)


# Factored out so it can be called recursively.

# Generated at 2022-06-11 20:02:32.644268
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

# Generated at 2022-06-11 20:02:42.259149
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        if test_cookie_lines:
            return test_cookie_lines.pop(0)
        raise StopIteration

    def readline_bom() -> bytes:
        if test_bom_lines:
            return test_bom_lines.pop(0)
        raise StopIteration

    def readline_bad_bom() -> bytes:
        if test_bad_bom_lines:
            return test_bad_bom_lines.pop(0)
        raise StopIteration

    def readline_cookie() -> bytes:
        if test_cookie_lines:
            return test_cookie_lines.pop(0)
        raise StopIteration

    global test_cookie_lines, test_bom_lines, test_bad_bom_lines

# Generated at 2022-06-11 20:02:53.233282
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize

    readline = io.BytesIO(b"\nabc\nabc").readline
    tokens = generate_tokens(readline)
    result = list(tokens)
    expected = [
        (token.ENCODING, b'', (1, 0), (1, 0), b'\n'),
        (token.NAME, b'abc', (2, 0), (2, 3), b'abc\n'),
        (token.NAME, b'abc', (3, 0), (3, 3), b'abc'),
        (token.ENDMARKER, b'', (4, 0), (4, 0), b''),
    ]

    assert result == expected


# Generated at 2022-06-11 20:03:05.897965
# Unit test for function tokenize_loop
def test_tokenize_loop():
    buf = ["if 1: #Spam", "    print(#Eggs)", "#Bacon"]

# Generated at 2022-06-11 20:03:14.351158
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    from blib2to3.pgen2.tokenize import detect_encoding, tokenize

    def readline_generator(*lines: Union[str, bytes]) -> Iterator[bytes]:
        for line in lines:
            yield line if isinstance(line, bytes) else line.encode("ascii")
        while True:
            yield b""

    def readlines(*lines: Union[str, bytes]) -> Iterator[bytes]:
        raw = readline_generator(*lines)
        readline = lambda: next(raw)

        encoding, bom_lines = detect_encoding(readline)
        assert not bom_lines, f"Shouldn't find a BOM: {bom_lines!r}!"
        tokenize(readline)


# Generated at 2022-06-11 20:05:15.217061
# Unit test for function tokenize
def test_tokenize():
    from io import BytesIO
    from io import StringIO

    def get_readline(s: str) -> Callable[[], Text]:
        def readline() -> Text:
            try:
                return next(s)
            except StopIteration:
                return ""

        return readline

    def _io_from_str(s: str) -> BytesIO:
        return BytesIO(s.encode("utf-8"))

    def test(s: str) -> None:
        import sys

        tokenize(get_readline(iter(s.splitlines(keepends=True))), printtoken)

    def roundtrip(s: str) -> None:
        readline = get_readline(iter(s.splitlines(keepends=True)))
        tokens = list(generate_tokens(readline))
       

# Generated at 2022-06-11 20:05:18.865737
# Unit test for function tokenize_loop
def test_tokenize_loop():
    readline = iter("a = 1 + 2").__next__
    tokeneater = printtoken
    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-11 20:05:22.667352
# Unit test for function tokenize
def test_tokenize():
    def readline():
        with open("../Lib/tokenize.py") as f:
            for line in f:
                yield line
    tokenize(readline())



# Generated at 2022-06-11 20:05:28.114120
# Unit test for function generate_tokens
def test_generate_tokens():
    # Testing the tokenize module
    import token as tokenize
    # Set up input lines
    lines = [
        'print("foo") # some comment',
        "'''docstring with a quote (\") character in it'''",
        '2**38 # -> 274877906944L',
        'a = -47\nb=a+1\nprint (b)',
    ]

    # This is required because tokenize does not accept Unicode strings
    # in Python 2.
    import sys

    lines = [line if sys.version_info.major < 3 else line.encode("latin-1") for line in lines]

    # Feed the lines to the tokenizer
    for t in tokenize.generate_tokens(iter(lines).__next__):
        print(t)

    # Expected output:


# Generated at 2022-06-11 20:05:38.289659
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest

    from test import support

    # Issue #9703: a buffer object returned from readline() keeps the
    # tokenizer from ending.
    class Devnull(io.RawIOBase):
        def read(self, n=None):
            return b""
        def readline(self, n=None):
            return b""

    def readline():
        return ""
    with support.captured_stdout() as stdout:
        tokenize_loop(readline, print)
    # It should end normally.
    self.assertEqual(stdout.getvalue(), "")

    def readline():
        return io.BytesIO(b"")
    with support.captured_stdout() as stdout:
        tokenize_loop(readline, print)
    # It should not send anything

# Generated at 2022-06-11 20:05:40.073981
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from . import pytokenize


# Generated at 2022-06-11 20:05:43.461745
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    ut = Untokenizer()
    it = iter([(1, "a")])
    assert ut.compat((1, "a"), it) is None
    assert ut.tokens == ["a"]
    assert isinstance(ut, Untokenizer)

# Generated at 2022-06-11 20:05:56.224919
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from io import StringIO

    s = "x = 10"
    f = io.StringIO(s)
    l = []
    tokenize_loop(f.readline, l.append)
    assert l == [(tokenize.NAME, 'x', (1, 0), (1, 1), 'x = 10'),
                 (tokenize.OP, '=', (1, 2), (1, 3), 'x = 10'),
                 (tokenize.NUMBER, '10', (1, 4), (1, 6), 'x = 10'),
                 ]

    def g():
        yield "x = 10 # foo"
        yield ""
    f = io.StringIO(s)
    l = []
    tokenize_loop(f.readline, l.append)

# Generated at 2022-06-11 20:06:01.978719
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    s = "0123456789\n"
    f = io.StringIO(s)
    t = tokenize.generate_tokens(f.readline)
    u = Untokenizer()
    assert u.compat(next(t), t) is None
    assert u.tokens == ["0123456789", "\n"]


# Generated at 2022-06-11 20:06:08.708078
# Unit test for function tokenize
def test_tokenize():
    # This is not a complete
    # test of tokenize, but it tests the output of tokenize
    # on a small representative sample of input
    import io
    import tokenize as pytokenize

    text = "def f(x): return 2*x\n"
    tokeneater = pytokenize.untokenize
    readline = io.StringIO(text).readline

    with open("_test.py", "wb") as fp:
        try:
            tokenize(readline, tokeneater)
        except pytokenize.TokenError:
            return
        except Exception:
            import traceback

            traceback.print_exc(file=fp)
        else:
            fp.write(bytes(tokeneater))

    import difflib
