

# Generated at 2022-06-11 19:58:18.676123
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not lines:
            return b""
        line = lines[0]
        del lines[0]
        return line

    def readline_error():
        if not lines:
            return b""
        line = lines[0]
        del lines[0]
        return line + b'\xff'

    # Encoding detected from BOM
    lines = [b'\xef\xbb\xbf' + b'# coding: utf-8\n', b'print("hello world")\n']
    assert detect_encoding(readline) == ("utf-8-sig", [b'\xef\xbb\xbf' + b'# coding: utf-8\n'])

    # Encoding detected from BOM and cookie

# Generated at 2022-06-11 19:58:28.813482
# Unit test for function generate_tokens
def test_generate_tokens():
    import unittest
    import re
    from io import BytesIO
    from typing import List, Tuple, Iterator
    from collections import namedtuple

    from mypy.test.data import DataDrivenTestCase, DataSuite

    Token = namedtuple('Token', 'type string start end line')

    class TokenizeTest(DataDrivenTestCase):
        def run_case(self, testcase: DataDrivenTestCase.TestCase) -> None:
            stream = BytesIO(testcase.input.encode('utf-8'))
            tokens = list(tokenize(stream.readline))  # type: List[Token]
            stream.close()

            self.assertEqual(len(tokens), len(testcase.output),
                             'incorrect number of tokens')


# Generated at 2022-06-11 19:58:37.626571
# Unit test for function generate_tokens

# Generated at 2022-06-11 19:58:38.588797
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io


# Generated at 2022-06-11 19:58:48.359388
# Unit test for function printtoken
def test_printtoken():
    import io
    import sys
    save_stdout = sys.stdout

# Generated at 2022-06-11 19:59:02.058983
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    class MockTokenizer:
        tokens: List[Tuple[int, str]]

        def tokenize(self, input: str) -> List[Tuple[int, str]]:
            self.tokens = list(tokenize(StringIO(input).readline))
            return self.tokens

    tok = MockTokenizer()

# Generated at 2022-06-11 19:59:12.665799
# Unit test for function tokenize
def test_tokenize():  # htest #
    r"""
    >>> import tokenize
    >>> readline = iter(['if 1:\n', '  print(2)\n']).__next__
    >>> tokenize.tokenize(readline)
    1,0-1,2:	NAME	'if'
    1,3-1,4:	NUMBER	'1'
    1,4-1,5:	OP	':'
    2,0-2,4:	NAME	'print'
    2,4-2,5:	OP	'('
    2,5-2,6:	NUMBER	'2'
    2,6-2,7:	OP	')'
    """



# Generated at 2022-06-11 19:59:16.656668
# Unit test for function tokenize_loop
def test_tokenize_loop():
    with tokenize.open(__file__) as fp:
        tokenize_loop(fp.readline, printtoken)



# Generated at 2022-06-11 19:59:26.825946
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    # bug 1:  untokenize((tokenize_loop.tok_name[token.NAME], 'print'))
    # is "print " instead of "print"
    assert u.compat((token.NAME, "print"), []) == ""
    text = "    spam(1)"
    stream = [
        (token.INDENT, "    "),
        (token.NAME, "spam"),
        (token.OP, "("),
        (token.NUMBER, "1"),
        (token.OP, ")"),
        (token.NEWLINE, "\n"),
        (token.DEDENT, ""),
    ]
    assert u.compat((token.INDENT, "    "), stream) == text



# Generated at 2022-06-11 19:59:33.131588
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    source = "a = 1\n"

    result = io.BytesIO()
    tokenize.tokenize(io.BytesIO(source.encode("utf-8")).readline, result.write)

    untok = Untokenizer()
    untok.compat((tokenize.ENCODING, "utf-8"), result)
    assert untok.untokenize([]) == source


# Generated at 2022-06-11 20:00:45.641370
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = 'print(x)\n'
    def readline():
        global s
        r = s
        s = ''
        return r
    def tokeneater(*args):
        printargs(*args)
    def printargs(*args):
        print(args)

    tokenize_loop(readline, tokeneater)

# For testing tokenize_loop, provide the following output:
# (0, 'print', (1, 0), (1, 5), 'print(x)\n')
# (1, '(', (1, 5), (1, 6), 'print(x)\n')
# (1, 'x', (1, 6), (1, 7), 'print(x)\n')
# (1, ',', (1, 7), (1, 8), 'print(x)\n')
# (0, '

# Generated at 2022-06-11 20:00:52.195373
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from . import tokenize
    s = StringIO("for i in range(10): print i\n")
    result = []
    tokenize.tokenize(s.readline, result.append)
    if result[0][0] is not tokenize.ENCODING:
        test.testmod()
test_tokenize_loop.__test__ = False # HACK: prevent creation of tests



# Generated at 2022-06-11 20:01:03.693725
# Unit test for function tokenize
def test_tokenize():
    # Test the ability to remove comments
    readline = iter(
        [
            "x = 35  # Initialize x\n",
            "y = x+5  # Add five\n",
            "x = y^2 # Square it\n",
        ]
    ).__next__
    result = []
    tokenize(readline, tokenize.tokeneater(result.append))

# Generated at 2022-06-11 20:01:10.996172
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import sys
    import io
    import tokenize
    from io import BytesIO

    readline = io.BytesIO(b"def f(x):\n  print(x)\n").readline
    untok = Untokenizer()
    tokenize.tokenize(readline(), untok.compat)
    assert untok.tokens == ["def ", "f", "(", "x", ")", ":", "\n", "  ", "print", "(", "x", ")", "\n"]



# Generated at 2022-06-11 20:01:22.680880
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from string import whitespace
    for input in (
        "def f(x): return x+1",
        "'abc' 'def'\n" * 100,
        "'abc\\\n'def'\n" * 100,
        "'\\\n'\n" * 100,
    ):
        buf = StringIO(input)
        buf.seek(0)
        tokens = []
        tokenize_loop(buf.readline, tokens.append)
        print(repr(input))
        print(tokens)
        output = untokenize(tokens)
        print(repr(output))
        print(whitespace)
        print(repr(whitespace))
        print()
        assert output == input



# Generated at 2022-06-11 20:01:33.518787
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline() -> bytes:
        return readline.lines.pop(0)

    def readline_and_check(lines: List[bytes], expected: Tuple[str, List[bytes]]) -> None:
        readline.lines = lines[:]
        actual = detect_encoding(readline)
        assert actual == expected, "detect_encoding(%r) = %r != %r" % (lines, actual, expected)

    readline_and_check([b'\xef\xbb\xbf# coding=utf-8\n'], ("utf-8", [b'\xef\xbb\xbf']))

# Generated at 2022-06-11 20:01:42.954501
# Unit test for function detect_encoding
def test_detect_encoding():
    test_cookie = "  # coding=ascii\n"
    test_bom = BOM_UTF8 + "# coding=utf-8-sig\n"
    test_no_encoding = "\n"
    def _readline(l):
        def f():
            for line in l:
                yield line
            raise StopIteration
        return f
    # Test no encoding
    r = _readline([test_no_encoding])
    assert detect_encoding(r) == ("utf-8", [])
    # Test encoding in a comment
    r = _readline([test_cookie])
    assert detect_encoding(r) == ("ascii", [test_cookie])
    # Test utf-8-sig encoding
    r = _readline([test_bom])
    assert detect_enc

# Generated at 2022-06-11 20:01:54.973722
# Unit test for function printtoken
def test_printtoken():
    global srow, scol, erow, ecol, token, type, line
    from io import StringIO

    s = StringIO()
    out = sys.stdout
    try:
        sys.stdout = s
        # FIXME: printtoken should be inlined here
        printtoken(type, token, (srow, scol), (erow, ecol), line)
        sys.stdout = out
    except:
        sys.stdout = out
        raise
    assert s.getvalue() == "%d,%d-%d,%d:\t%s\t%s\n" % (
        srow,
        scol,
        erow,
        ecol,
        tok_name[type],
        repr(token),
    )



# Generated at 2022-06-11 20:02:06.107435
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    readline = io.StringIO("if 1:\n  pass  # XX").__next__
    tokeneater = TestEater()
    tokeneater.add("NAME", "if")
    tokeneater.add("NUMBER", "1")
    tokeneater.add("NEWLINE", "\n")
    tokeneater.add("INDENT", "  ")
    tokeneater.add("NAME", "pass")
    tokeneater.add("COMMENT", "  # XX")
    tokeneater.add("DEDENT", "")
    tokenize_loop(readline, tokeneater.match)
    tokeneater.done("generate_tokens() eats all tokens")



# Generated at 2022-06-11 20:02:16.431288
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize as _tokenize

    import token
    import tokenize

    # Some of the tests below are from tokenize.py

# Generated at 2022-06-11 20:03:08.884037
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test the iterability of the generator
    def tokens(func):
        return list(tokenize.generate_tokens(StringIO(func).readline))

    def check_token(func, expected):
        result = tokens(func)
        assert result == expected, ("got {!r}, expected {!r}".format(result, expected))


# Generated at 2022-06-11 20:03:20.826344
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    l = []
    u.compat((NAME, "class"), l)
    assert u.tokens == ["class "]
    l.append((NAME, "C"))
    u.compat((AS, "as"), l)
    assert u.tokens == ["class ", "C"]
    l.append((NAME, "D"))
    u.compat((NEWLINE, "\n"), l)
    assert u.tokens == ["class ", "C", "as ", "D"]
    u.compat((INDENT, "\t"), l)
    assert u.tokens == ["class ", "C", "as ", "D"]
    u.compat((NAME, "def"), l)
    assert u.tokens == ["class ", "C", "as ", "D"]
   

# Generated at 2022-06-11 20:03:28.120359
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    tokens = [
        ("NAME", "name", (1, 0), (1, 4), "name"),
        ("NEWLINE", "\n", (1, 4), (2, 0), "name"),
        ("NAME", "name2", (2, 0), (2, 5), "name2"),
    ]
    assert u.untokenize(tokens) == "name name2"



# Generated at 2022-06-11 20:03:38.122427
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    l1 = [
        (tokenize.NAME, "def"),
        (tokenize.OP, "("),
        (tokenize.NAME, "x"),
        (tokenize.OP, ")"),
        (tokenize.OP, ":"),
        (tokenize.INDENT, "   "),
        (tokenize.NAME, "return"),
        (tokenize.NAME, "x"),
        (tokenize.OP, "+"),
        (tokenize.NAME, "2"),
        (tokenize.DEDENT, ""),
    ]

# Generated at 2022-06-11 20:03:41.290764
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\012other stuff"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\012"]


# unit tests

# Generated at 2022-06-11 20:03:52.497272
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not hasattr(readline, "lines"):
            readline.lines = [
                "  \n",
                "# -*- coding: utf-8 -*-\n",
                "  \n",
                '"""docstring"""\n',
            ]

        return readline.lines.pop(0)

    assert detect_encoding(readline) == ("utf-8", ["  \n", "# -*- coding: utf-8 -*-\n"])


# Generated at 2022-06-11 20:04:05.440407
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize

    def _detokenize(toks):
        # XXX - it would be cool if this function could take the output
        # of tokenize.generate_tokens(), too...
        #
        # XXX - the original code (in untokenize.py) does not generate
        #       any NEWLINE tokens; I don't know if that is intentional,
        #       or if it's a bug (leaving it out could cause the
        #       semantically-equivalent but lexically-different encoding of
        #       a trailing newline to not round-trip)
        src = ''
        tok = toks[0]
        prevrow = prevcol = 0

# Generated at 2022-06-11 20:04:10.863354
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    r = tokenize.generate_tokens(iter('some_code_here()').next)
    for toknum, tokval, _, _, _ in r:
        print(tokenize.tok_name[toknum], tokval)

test_generate_tokens()


# Generated at 2022-06-11 20:04:19.742140
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-11 20:04:31.948916
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    r = io.StringIO(
        " # comment\nclass foo(object):\n  '''docstring'''\n  a = 2\n  def __init__(self):\n    1 + 1\n    '''docstring'''\n    self.a = 5\n  '''docstring'''\n"
    )

# Generated at 2022-06-11 20:06:21.324005
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import tok_name
    s = "def f(x): return 2*x\n"
    for token in generate_tokens(StringIO(s).readline):
        print(tok_name[token[0]], token[1])


# Generated at 2022-06-11 20:06:33.716230
# Unit test for function detect_encoding
def test_detect_encoding():

    def readline():
        yield bytes(b"\N{BOM UTF-8}# -*- coding: utf-8 -*-\n")
        yield bytes(b"# -*- coding: utf-8 -*-\n")
        yield bytes(b"\N{BOM UTF-8}# -*- coding: unknown -*-\n")

    assert detect_encoding(readline) == ("utf-8-sig", [])
    assert detect_encoding(readline) == ("utf-8", [])
    raises(SyntaxError, detect_encoding, readline)

    def readline():
        for line in (b"# -*- coding: utf-8 -*-\n", b"# -*- coding: unknown -*-\n"):
            yield bytes(line)

# Generated at 2022-06-11 20:06:36.756126
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    ut = Untokenizer()
    ut.compat((NAME, "foo"), [(NUMBER, "1"), (NEWLINE, "\n"), (NAME, "bar")])
    assert ut.tokens == ["foo ", "1\n", "bar"]

