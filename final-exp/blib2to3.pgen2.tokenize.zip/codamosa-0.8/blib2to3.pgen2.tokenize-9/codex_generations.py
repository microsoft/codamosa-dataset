

# Generated at 2022-06-11 19:58:54.880877
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# coding: latin-1\n"
        yield b"# foo\n"
        yield b"# bar\n"

    encoding, lines = detect_encoding(readline())
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n", b"# foo\n", b"# bar\n"]



# Generated at 2022-06-11 19:59:06.141353
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import tokenize
    from io import StringIO
    r = StringIO(u"def f(x):\n  return 3*x\n")
    tokens = tokenize.generate_tokens(r.readline)
    assert next(tokens) == (
        token.NAME,
        u'def',
        (1, 0),
        (1, 3),
        u'def f(x):\n',
    )
    assert next(tokens) == (
        token.NAME,
        u'f',
        (1, 4),
        (1, 5),
        u'def f(x):\n',
    )

# Generated at 2022-06-11 19:59:15.986492
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO

    def readline() -> bytes:
        if stream.tell() >= len(stream.getvalue()):
            raise StopIteration
        return stream.readline()

    # Non-BOM UTF8 with coding cookie
    stream = BytesIO(b"# coding: utf-8\npass\n")
    assert detect_encoding(readline) == ("utf-8", [b"# coding: utf-8\n"])

    # Non-BOM UTF8 with coding cookie and blank line
    stream = BytesIO(b"\n\n# coding: utf-8\npass\n")
    assert detect_encoding(readline) == ("utf-8", [b"\n", b"\n# coding: utf-8\n"])

    # BOM UTF8

# Generated at 2022-06-11 19:59:27.358708
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        readline.counter -= 1
        if readline.counter > 0:
            return bytes()
        else:
            raise StopIteration

    readline.counter = 1
    assert detect_encoding(readline) == ("utf-8", [])
    readline.counter = 2
    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8\n"])
    readline.counter = 2
    assert detect_encoding(readline) == ("ascii", [b"# coding=ascii\n"])
    readline.counter = 2
    try:
        detect_encoding(readline)
    except SyntaxError as e:
        assert str(e) == "unknown encoding: ascii-8bit", str(e)


# Generated at 2022-06-11 19:59:28.114411
# Unit test for function generate_tokens

# Generated at 2022-06-11 19:59:38.198027
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    from tokenize import tokenize, untokenize

    src = "a + b\n"
    try:
        tokens_with_start_line = list(tokenize(StringIO(src).readline))
    except TypeError:
        # Python 2.6+
        tokens_with_start_line = list(tokenize(StringIO(src).readline))
    tokens = [(x[0], x[1]) for x in tokens_with_start_line]
    assert tokens == [
        (token.NAME, "a"),
        (token.PLUS, "+"),
        (token.NAME, "b"),
        (token.NEWLINE, "\n"),
        (token.ENDMARKER, ""),
    ]

    # Make sure untokenize works as expected
    src_with_nl = token

# Generated at 2022-06-11 19:59:40.985449
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    pass


# Generated at 2022-06-11 19:59:43.456286
# Unit test for function tokenize
def test_tokenize():
    # test cases are from Lib/_testcapi_tokenize.c
    with open(__file__) as input:
        tokenize(input.readline, printtoken)


# Generated at 2022-06-11 19:59:48.335220
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    import tokenize
    readline = io.StringIO('x=4').readline
    out = []
    def tokeneater(*args):
        out.append(args)
    try:
        tokenize.tokenize_loop(readline, tokeneater)
    except tokenize.TokenError:
        print('TokenError!')
    print(out)
    assert len(out) == 3


# Generated at 2022-06-11 19:59:56.949499
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def compare(input, output, truncate_buf_size=60):
        """Compare input to output.

        The comparison is performed in three steps. First the raw data is
        compared. If they disagree a more detailed comparison is performed. If
        they still disagree the actual tokens are displayed.
        """
        it1 = iter(input)
        it2 = iter(output)
        s = slice(0, truncate_buf_size + 20)
        ok = True
        for i, (x, y) in enumerate(zip(it1, it2)):
            xs = str(x)
            ys = str(y)
            if xs != ys:
                ok = False
                break
        if not ok:
            # Compare a larger context.
            it1 = iter(input)
            it2 = iter(output)

# Generated at 2022-06-11 20:00:48.388139
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    # Test for cpython issue 2361:
    # http://bugs.python.org/issue2361
    g = generate_tokens(StringIO('.a = 1').readline)
    assert next(g) == (NAME, '.a', (1, 0), (1, 2), '.a = 1')
    assert next(g) == (OP, '=', (1, 3), (1, 4), '.a = 1')
    assert next(g) == (NUMBER, '1', (1, 5), (1, 6), '.a = 1')
    assert next(g) == (NEWLINE, '', (1, 6), (1, 6), '.a = 1')
    assert next(g) == (ENDMARKER, '', (2, 0), (2, 0), '')

   

# Generated at 2022-06-11 20:00:54.194898
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # Check that untokenize_compat() can untokenize its own output
    untok = Untokenizer()

# Generated at 2022-06-11 20:00:58.832402
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(b'if 1:\n  print(2)\n')
    tokens = tokenize.generate_tokens(r.readline)
    print(tuple(tokens))

test_generate_tokens()


# Generated at 2022-06-11 20:01:10.530645
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield bytes("# coding: latin-1\n", "ascii")
        raise StopIteration

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [bytes("# coding: latin-1\n", "ascii")]

    def readline():
        yield bytes("#!/usr/bin/python\n", "ascii")
        yield bytes("# coding=utf-8\n", "ascii")
        raise StopIteration

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == [bytes("#!/usr/bin/python\n", "ascii"), bytes("# coding=utf-8\n", "ascii")]

   

# Generated at 2022-06-11 20:01:21.953506
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # Test that convert works
    import io
    import tokenize
    from blib2to3.pgen2.token import *

    input = io.StringIO(
        "if 1: print(2)"
    )  # An example program
    output = io.StringIO()
    untok = Untokenizer()
    alltoks = tokenize.generate_tokens(input.readline)
    untok.compat(next(alltoks), alltoks)
    untok.compat(next(alltoks), alltoks)
    for tok in alltoks:
        untok.compat(tok, alltoks)
    assert output.getvalue() == "if 1: print(2)"



# Generated at 2022-06-11 20:01:26.943026
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    class Wrapper:
        def __init__(self, tokenize, untokenize):
            self.tokenize = tokenize
            self.untokenize = untokenize
    wrapper = Wrapper(tokenize, untokenize)
    wrapper.test_main()



# Generated at 2022-06-11 20:01:39.319482
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    token_in = (NAME, "foo")

    def fake_tokenize(readline):
        yield token_in
        yield (NAME, "bar")

    expected = "foo bar "
    assert untok.compat(token_in, fake_tokenize(None)) == expected


_compat_tokenize = tokenize
_tokenize = _compat_tokenize



# Generated at 2022-06-11 20:01:50.726338
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    def test(prog, expect, out=None):
        ss = StringIO(prog)
        if out is None:
            out = []

        def ntoc(x):
            return x and (x[0], x[1] + 1)

        for x in generate_tokens(ss.readline):
            t2 = list(x)
            t2[2] = ntoc(t2[2])
            t2[3] = ntoc(t2[3])
            out.append(t2)
        assert out == expect


# Generated at 2022-06-11 20:01:58.728120
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import unittest

    class TestCase(unittest.TestCase):

        def format(self, string):
            sio = io.StringIO(string)
            utokens = tokenize(sio.readline)
            untokenizer = Untokenizer()
            return untokenizer.compat(next(utokens), utokens)

        def check(self, input, output):
            self.assertEqual(self.format(input), output)

        def test_leading_newline(self):
            self.check("if 1:\n    pass\n", "\nif 1:\n    pass\n")

        def test_leading_indent(self):
            self.check("if 1:\n    pass", "if 1:\n    pass")


# Generated at 2022-06-11 20:02:08.683270
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import BytesIO
    from token import tok_name
    from unittest import TestCase, mock

    class TestTokenizer(TestCase):
        def setUp(self):
            self.readline = BytesIO(b"# A comment\npass\n").readline
            self.addCleanup(self.readline.close)
            self.tokeneater = mock.Mock()

        def assertReadToken(self, type, token, start, end, line):
            # The first five calls to tokeneater should match the expected
            # tokens. The final call is ENCODING, and is forced to always
            # be at the end of the line, so just ignore it.
            calls = self.tokeneater.call_args_list[:5]

# Generated at 2022-06-11 20:02:44.734447
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize


# Generated at 2022-06-11 20:02:55.332745
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "n = 0\n"
        yield "while n < 10:\n"
        yield "    print(n)"
        yield "    n = n + 1\n"

    tokeneater = []
    tokenize_loop(readline, tokeneater.append)

# Generated at 2022-06-11 20:03:07.645581
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield "# -*- coding: latin-1 -*-"
        yield "blah"
        yield "# -*- coding: latin-1 -*-"
        raise StopIteration

    encoding, lines = detect_encoding(readline())
    assert encoding == "iso-8859-1"
    assert lines == ["# -*- coding: latin-1 -*-\n", "blah\n"]

    def readline():
        yield "# -*- coding: latin-1 -*-"
        yield "# foo"
        yield "# bar"
        raise StopIteration

    encoding, lines = detect_encoding(readline())
    assert encoding == "iso-8859-1"

# Generated at 2022-06-11 20:03:20.011219
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import tokenize

    # We'd like untokenize() to support annotated token tuples generated
    # by tokenize().  Untokenize() is careful to only use those
    # tokenize() arguments that are also supported by blib2to3.pgen2.tokenize().
    #
    # This test ensures that blib2to3.pgen2.tokenize() and tokenize()
    # return the same set of tokens, except for the annotated tokens.
    #
    # (Formerly, methods of the Untokenizer class were called directly from
    # tokenize().  This was a bad idea.  tokenize() shouldn't have to know
    # about the internal structure of the Untokenizer class.)


# Generated at 2022-06-11 20:03:23.844129
# Unit test for function tokenize_loop
def test_tokenize_loop():
    rl = token.compile_pattern(f"{Ignore}{PseudoToken}")
    tokeneater = token.untokenize
    tokenize_loop(rl, tokeneater)



# Generated at 2022-06-11 20:03:34.907525
# Unit test for function detect_encoding
def test_detect_encoding():
    # Encoding is determined by which lines are passed in. Note that
    # the first line could be a line of code, not just whitespace.
    def readline():
        while lines:
            yield lines.pop(0)

    lines = [b"\n", b"# coding: utf-8\n"]
    assert detect_encoding(readline) == ("utf-8", [b"\n"])

    lines = [b"\n", b"#! /usr/bin/env python2.5\n", b"# coding: utf-8\n"]
    assert detect_encoding(readline) == ("utf-8", [b"\n"])

    lines = [b"# coding: latin-1\n", b"\n"]

# Generated at 2022-06-11 20:03:38.761836
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield bytes("# coding=utf-8\n", "ASCII")
        yield bytes("class Foo:\n", "UTF-8")
    assert detect_encoding(readline) == ("utf-8", [bytes("# coding=utf-8\n", "ASCII")])



# Generated at 2022-06-11 20:03:39.674704
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:03:50.712757
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    # Testing untokenize
    test1 = (
        "if 1:\n"
        "  print('one')\n"
        "  print('two')\n"
    )
    gtokens = generate_tokens(StringIO(test1).readline)
    tok = None
    for tok in gtokens:
        pass
    gtokens = None
    assert tok[0] == token.ENDMARKER
    reassembled = untokenize(generate_tokens(StringIO(test1).readline))
    assert test1 == reassembled
    # Testing random stuff
    test2 = "if 1:\n  pass\n"
    gtokens = generate_

# Generated at 2022-06-11 20:03:57.776385
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test detection of encodings
    for encoding in [
        "utf-8",
        "iso-8859-1",
        "iso-latin-1",
        "latin-1",
        "utf-8-sig",
    ]:
        s = "# coding: " + encoding + "\n"
        result, lines = detect_encoding(s.encode(encoding).__iter__().__next__)
        assert result == encoding, (result, encoding)
    for encoding in ["unknown", "utf-8-sig"]:
        s = "# coding: " + encoding + "\n"
        try:
            result, lines = detect_encoding(s.encode("utf-8").__iter__().__next__)
        except SyntaxError:
            pass

# Generated at 2022-06-11 20:05:02.897073
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest

    class TestDetectEncoding(unittest.TestCase):
        def test_only_bom(self):
            stream = io.BytesIO(b"\xef\xbb\xbf")
            encoding, _ = detect_encoding(stream.readline)
            self.assertEqual(encoding, "utf-8-sig")

        def test_only_cookie_utf8(self):
            stream = io.BytesIO(b"# coding=utf-8")
            encoding, _ = detect_encoding(stream.readline)
            self.assertEqual(encoding, "utf-8")

        def test_only_cookie_latin1(self):
            stream = io.BytesIO(b"# -*- coding: latin-1 -*-")
            encoding

# Generated at 2022-06-11 20:05:14.897363
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def f():
        yield ""
        yield "#!"
        yield "print(3)"
    t = []
    tokenize_loop(f, t.append)

# Generated at 2022-06-11 20:05:27.822423
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        if not lines:
            raise StopIteration
        return lines.pop(0)

    # no cookie
    lines = ["abc\n", "def\n"]
    assert detect_encoding(readline) == ("utf-8", lines)

    # valid cookie
    lines = ["# -*- coding: iso-latin-1 -*-\n", "abc\n"]
    assert detect_encoding(readline) == ("iso-8859-1", lines)

    # invalid cookie
    lines = ["# -*- coding: blah blah blah -*-\n", "abc\n"]
    try:
        detect_encoding(readline)
    except SyntaxError:
        pass
    else:
        assert 0, "Should have raised SyntaxError"

    # both B

# Generated at 2022-06-11 20:05:35.186621
# Unit test for function generate_tokens
def test_generate_tokens():
    def test(s, want):
        import io
        import tokenize

        r = io.StringIO(s)
        g = tokenize.generate_tokens(r.readline)
        got = [(token, s) for token, s, _, _, _ in g]
        if want != got:
            print(got)
            assert 0, "{} != {}".format(want, got)

    test('"abc"\n', [(tokenize.STRING, '"abc"\n')])
    test('"abc\ndef"\n', [(tokenize.ERRORTOKEN, '"abc\ndef"\n')])

# Generated at 2022-06-11 20:05:37.573642
# Unit test for function tokenize
def test_tokenize():
    import sys
    import tokenize
    tokenize.tokenize(sys.stdin.readline)
    # should print each token, one per line, in a pretty form



# Generated at 2022-06-11 20:05:43.261876
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from blib2to3.pgen2 import driver

    source = '''def foo(x):
    return x+1
    '''
    file = StringIO(source)
    tokens = driver.generate_tokens(file.readline)
    untokenizer = Untokenizer()
    untokenized = untokenizer.compat(next(tokens), tokens)
    assert untokenized == source



# Generated at 2022-06-11 20:05:56.092590
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from .tokenize import (
        tokenize,
        Untokenizer,
        NAME,
        OP,
        NUMBER,
        NEWLINE,
        INDENT,
        DEDENT,
        ENDMARKER,
        STRING,
    )
    input_stream = StringIO("def f():\n  name = 'value'")
    untok = Untokenizer()
    result = untok.untokenize(tokenize(input_stream.readline))
    assert result == "def f ( ) :\n  name = 'value'\n"
    #
    input_stream = StringIO("def f():\n  name = 'value'")
    untok = Untokenizer()
    tokens = list(tokenize(input_stream.readline))
    result = untok.comp

# Generated at 2022-06-11 20:06:01.588058
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize

    text = "1+1"
    result = io.StringIO()

    def tokeneater(type, token, start, end, line):
        # print('%10s %5s %2d %2d %-15r %r' % (tokenize.tok_name[type], tokenize.COMMENT, start[0], start[1], line[:end[1]], line))
        result.write(tokenize.tok_name[type])
        result.write(" ")
        result.write(token)
        result.write(" ")
        result.write("%d" % start[0])
        result.write(" ")
        result.write("%d" % start[1])
        result.write(" ")

# Generated at 2022-06-11 20:06:07.591396
# Unit test for function generate_tokens
def test_generate_tokens():
    import io, token
    readline = io.StringIO('if 1:\n  print(2)\n').readline
    result = list(tokenize.generate_tokens(readline))
    expected = [token.NAME('if'), token.NUMBER('1'), token.OP(':'), token.NEWLINE('\n'),
                token.INDENT('  '), token.NAME('print'), token.OP('('), token.NUMBER('2'),
                token.OP(')'), token.NEWLINE('\n'), token.DEDENT(''), token.ENDMARKER('')
               ]
    assert result == expected

# Generated at 2022-06-11 20:06:12.603616
# Unit test for function generate_tokens
def test_generate_tokens():
    from cStringIO import StringIO

    # Support for 3.2 and later.
    # In 3.2, the Grammar and ParserBase classess are moved to the tokenize module
    grammar_base_class = getattr(tokenize, "Grammar", object)

    class MockGrammar(grammar_base_class):
        pass

    class MockParser(object):

        def __init__(self, grammar, tokens):
            self.grammar = grammar
            self.tokens = tokens
            self.tokens_taken = 0

        def _next_token(self):
            token = self.tokens[self.tokens_taken]
            self.tokens_taken += 1
            return token

        def error_func(self, message, token, *args):
            self.errtoken