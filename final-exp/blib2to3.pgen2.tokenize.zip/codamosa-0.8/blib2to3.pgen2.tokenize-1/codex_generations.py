

# Generated at 2022-06-11 19:58:38.821286
# Unit test for function detect_encoding

# Generated at 2022-06-11 19:58:44.125430
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    def readline():
        return 'x=3'

    def tokeneater(*token_info):
        toks.append(token_info)

    toks = []
    tokenize_loop(readline, tokeneater)

    if len(toks) != 3:
        raise RuntimeError(
            "tokenize_loop misses tokens, got %d instead of 3" % len(toks)
        )



# Generated at 2022-06-11 19:58:48.478484
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    tokeneater = StringIO()
    tokenize_loop(StringIO("def foo(): pass").readline, tokeneater.write)
    assert tokeneater.getvalue() == "1,0-1,3:\tNAME\t'def'\n"



# Generated at 2022-06-11 19:59:02.194284
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test the newline tokenizing behavior of the tokenize module.
    from tokenize import generate_tokens, NL, NEWLINE, ENDMARKER
    readline = iter(["  1", "  2", ""]).__next__
    tokens = generate_tokens(readline)
    types = [token[0] for token in tokens]
    assert types == [
        NUMBER,
        NEWLINE,
        NUMBER,
        NEWLINE,
        ENDMARKER,
    ], "Tokenize newline test failed: %s" % types

    # Test the tokenizing of an empty line
    readline = iter([""]).__next__
    tokens = generate_tokens(readline)
    types = [token[0] for token in tokens]

# Generated at 2022-06-11 19:59:13.934912
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield 'def f(x):'
        yield '  return x + 1'

    res = []
    tokenize_loop(readline, lambda *x: res.append(x))

    # Verify everything before the first NEWLINE token

# Generated at 2022-06-11 19:59:26.031974
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    #
    # Untokenizer doesn't implement tokens that don't exist in the new
    # token format
    #
    u = Untokenizer()
    def tokeneater(num, token, start, end, line):
        assert 0, "tokeneater should not be called"
    try:
        u.compat((ENCODING, "utf8"), iter([(0, "")]))
    except NotImplementedError:
        pass
    #
    # A simple example that tests indent and dedent detection
    #
    u = Untokenizer()
    def tokeneater(num, token, start, end, line):
        assert 0, "tokeneater should not be called"

# Generated at 2022-06-11 19:59:32.298115
# Unit test for function detect_encoding
def test_detect_encoding():
    if sys.version_info[:2] >= (3, 8):
        def readlines(s: Text) -> Iterator[bytes]:
            yield from s.splitlines(True)

        def readlines_with_bom(s: Text) -> Iterator[bytes]:
            for line in s.splitlines(True):
                yield BOM_UTF8 + line.encode("utf-8")

        assert detect_encoding(readlines("")) == ("utf-8", [])
        assert detect_encoding(readlines("\n")) == ("utf-8", ["\n"])
        assert detect_encoding(readlines("# coding: latin-1\n")) == (
            "iso-8859-1",
            ["# coding: latin-1\n"],
        )

# Generated at 2022-06-11 19:59:41.420999
# Unit test for function detect_encoding
def test_detect_encoding():

    def helper(lines, expected_encoding="utf-8", expected_lines=()):
        sentinel = object()
        result = detect_encoding(iter(lines).__next__)
        encoding = result[0] if result[0] else sentinel
        lines = result[1]
        assert encoding != sentinel, "No encoding found"
        assert encoding == expected_encoding, (
            "Encoding %r is not %r" % (encoding, expected_encoding)
        )
        assert lines == list(expected_lines), "Lines %r are not %r" % (lines, expected_lines)


# Generated at 2022-06-11 19:59:45.424402
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import warnings

    warnings.filterwarnings("ignore")

    src = "print(1)\n # comment\nprint(2)"
    with open("_test", "w") as _test:
        _test.write(src)
    with open("_test") as _test:
        tokenize_loop(_test.readline, printtoken)



# Generated at 2022-06-11 19:59:56.067432
# Unit test for function detect_encoding
def test_detect_encoding():
    # It should return an encoding and only the first two lines
    encoding, lines = detect_encoding([
        lambda: bytes("# coding=utf-8\n", "utf-8"),
        lambda: bytes("# a=b\n", "utf-8"),
        lambda: bytes("print('and now for something completely different')\n", "utf-8")
    ])
    assert encoding == 'utf-8'
    assert lines == [bytes("# coding=utf-8\n", "utf-8"),
                     bytes("# a=b\n", "utf-8")]

    # It should return an encoding and only the first two lines
    # even if there is a blank line at the front

# Generated at 2022-06-11 20:00:26.113438
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield from b"\xef\xbb\xbf# -*- coding: latin-1 -*- ".splitlines(True)
    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b'\xef\xbb\xbf# -*- coding: latin-1 -*- ']



# Generated at 2022-06-11 20:00:32.472458
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        return next(lines)

    lines = (b"# -*- coding: utf-8 -*-\n",)
    assert detect_encoding(readline) == ("utf-8", [b"# -*- coding: utf-8 -*-\n"])

    lines = (b"# coding=utf-8\n",)
    assert detect_encoding(readline) == ("utf-8", [b"# coding=utf-8\n"])

    lines = (b"# vim:fileencoding=utf-8\n",)
    assert detect_encoding(readline) == ("utf-8", [b"# vim:fileencoding=utf-8\n"])

    lines = (b"\xef\xbb\xbf\n",)

# Generated at 2022-06-11 20:00:37.725650
# Unit test for function tokenize
def test_tokenize():
    import io
    r = io.StringIO("def f(x): return 2*x\n")
    list(generate_tokens(r.readline))
    r = io.StringIO("1+1\n")
    for token in generate_tokens(r.readline):
        type, attr = token[0], token[1]
        if type == NUMBER and float(attr) == 2.0:
            break
    else:
        print("Error in tokenize()")



# Generated at 2022-06-11 20:00:41.734621
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize

    readline = io.BytesIO(b'foo = "bar"\nbaz = 1').readline
    with tokenize.tokenize(readline) as tokens:
        for token in tokens:
            print(token)



# Generated at 2022-06-11 20:00:47.509853
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    r = io.BytesIO(b"a = 1")
    u = tokenize.Untokenizer()
    try:
        tokenize.tokenize(r.readline, u.compat)
    except tokenize.TokenError:
        pass
    assert u.tokens[0] == "a"
    assert u.tokens[1] == " "
    assert u.tokens[2] == "="
    assert u.tokens[3] == " "
    assert u.tokens[4] == "1"
    assert len(u.tokens) == 5

# Generated at 2022-06-11 20:00:50.077699
# Unit test for function tokenize
def test_tokenize():
    import io

    readline = io.StringIO("if 1:\n\tprint(1)\nxx = (1)\n").readline
    tokeneater = lambda *args: None
    tokenize(readline, tokeneater)



# Generated at 2022-06-11 20:00:55.394922
# Unit test for function tokenize_loop
def test_tokenize_loop():
    input_str = 'a_b_c = 1 + 2 + 3 + 4'
    _line = input_str.splitlines(True)
    def _readline ():
        return _line.pop(0) if _line else ''
    def f(*a):
        pass
    tokenize_loop(_readline, f)



# Generated at 2022-06-11 20:01:03.431353
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import BytesIO
    iterable = generate_tokens(open("tokenize.py", "rb").__next__)
    test_generate_tokens.tokens = list(iterable)
    iterable = generate_tokens(BytesIO(b"x = 2").__next__)
    test_generate_tokens.tokens = list(iterable)
test_generate_tokens()
test_generate_tokens.tokens  #doctest: +ELLIPSIS


# Generated at 2022-06-11 20:01:15.362210
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for i in range(len(lines)):
            yield lines[i]

    # Try bom with no encoding cookie
    lines = [BOM_UTF8 + b"# coding: latin-1\n", b"pass\n"]
    encoding, msg = detect_encoding(readline)
    assert encoding == "utf-8-sig"
    assert msg == [BOM_UTF8 + b"# coding: latin-1\n"]

    # Try bom with encoding cookie, but wrong encoding
    lines = [BOM_UTF8 + b"# coding: latin-1\n", b"pass\n"]
    try:
        encoding, msg = detect_encoding(readline)
    except SyntaxError:
        pass  # expected

# Generated at 2022-06-11 20:01:18.812356
# Unit test for function tokenize
def test_tokenize():
    from .tokenize_pgen import generate_tokens
    # Testing
    for token in generate_tokens(test_tokenize.__code__.co_code):
        print(token)



# Generated at 2022-06-11 20:02:25.088749
# Unit test for function detect_encoding
def test_detect_encoding():
    # Source files should start with an encoding cookie, or a utf-8 BOM if
    # the encoding is utf-8.

    # All examples below should pass with no exception raised.
    def check_utf8(source_lines: List[bytes]) -> None:
        from io import BytesIO

        def readline() -> bytes:
            for b in source_lines:
                yield b

        encoding, _ = detect_encoding(readline)
        assert encoding == "utf-8"

    check_utf8([b"# coding=utf-8"])
    check_utf8([BOM_UTF8 + b"# coding=utf-8", b""])
    check_utf8([BOM_UTF8])


# Generated at 2022-06-11 20:02:37.972327
# Unit test for function tokenize
def test_tokenize():
    examples = [
        # input, output
        ("def f(x): return 2*x", "1,0-1,3:\tNAME\t'def'"),
        ("f(3)", "1,0-1,1:\tNAME\t'f'\n1,1-1,2:\tOP\t'('\n1,2-1,3:\tNUMBER\t'3'\n1,3-1,4:\tOP\t')'"),
        ("2**31-1", "1,0-1,7:\tNUMBER\t'2**31-1'"),
        ('"""a\\nb"""', "1,0-3,3:\tSTRING\t'\"\"\"a\\\\nb\"\"\"'"),
    ]
    for i, o in examples:
        g = generate_t

# Generated at 2022-06-11 20:02:45.730246
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    tl = []
    def tokeneater(*args):
        tl.append(args)
    tokenize_loop(io.StringIO("def f(): pass\n").readline, tokeneater)

# Generated at 2022-06-11 20:02:53.145179
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> Iterator[bytes]:
        yield b"# coding: latin-1\r"
        yield b"pass\r"
    # Call it once
    assert detect_encoding(readline) == ("latin-1", [b"# coding: latin-1\r", b"pass\r"])
    # Call it again to make sure it isn't affected by a previous call's state
    assert detect_encoding(readline) == ("latin-1", [b"# coding: latin-1\r", b"pass\r"])
    def readline() -> Iterator[bytes]:
        yield b"# -*- coding: latin-1 -*-\r"
        yield b"pass\r"

# Generated at 2022-06-11 20:02:55.291568
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'import sys\n'

    expected = "latin-1", [b'# -*- coding: latin-1 -*-\n', b'import sys\n']
    actual = detect_encoding(readline())
    assert expected == actual



# Generated at 2022-06-11 20:02:56.774671
# Unit test for function tokenize_loop

# Generated at 2022-06-11 20:03:02.997867
# Unit test for function tokenize_loop
def test_tokenize_loop():
    readline = lambda: 'print 42'
    tokens = []
    tokenize_loop(readline, tokens.append)

    assert tokens[0][:2] == (token.NAME, 'print')
    assert tokens[1][:2] == (token.NUMBER, '42')
    assert len(tokens) == 2



# Generated at 2022-06-11 20:03:12.625299
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest

    class MockStringIO(io.TextIOBase):
        def __init__(self, lines):
            # isinstance(lines, Sequence)
            self.lines = lines
            self.i = 0
            self.line = ""

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def readline(self):
            if self.i >= len(self.lines):
                return ""
            line = self.lines[self.i]
            self.i += 1
            return line


# Generated at 2022-06-11 20:03:23.318345
# Unit test for function detect_encoding
def test_detect_encoding():
    # The only encoding that matters is utf-8, as all others are UTF-8
    # compatible.
    def assert_equal(readlines, expected):
        got, lines = detect_encoding(iter(readlines).__next__)
        assert got == expected, "detect_encoding() -> %r, expected: %r, lines: %r" % (
            got,
            expected,
            lines,
        )

    assert_equal([], "utf-8")
    assert_equal([b""], "utf-8")
    assert_equal([b"# coding=utf-8"], "utf-8")
    assert_equal([b"# coding: utf-8"], "utf-8")
    assert_equal([b" \t\f# coding: utf-8"], "utf-8")
    assert_equal

# Generated at 2022-06-11 20:03:34.939964
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import token
    import tokenize

    def test_untokenize_with_string(s: str) -> None:
        g = tokenize.generate_tokens(io.BytesIO(s.encode("utf-8")).readline)
        result = Untokenizer().untokenize(g)
        expected = s
        assert result == expected

    def test_untokenize_with_bytes(s: str) -> None:
        g = tokenize.generate_tokens(io.BytesIO(s.encode("utf-8")).readline)
        result = Untokenizer().untokenize(g)
        expected = s
        assert result == expected

    def test_untokenize_with_file(filename: str) -> None:
        g = tokenize.generate_tokens

# Generated at 2022-06-11 20:05:16.354761
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # No test needed
    pass



# Generated at 2022-06-11 20:05:27.821695
# Unit test for function generate_tokens
def test_generate_tokens():

    # Test empty string
    print("Test 1 - empty string")
    test_string = ""
    test_tokens = []
    for token in generate_tokens(iter(test_string.splitlines(True)).__next__):
        test_tokens.append(token)
    print("Done\n")

    # Test single newline
    print("Test 2 - newline")
    test_string = "\n"
    test_tokens = []
    for token in generate_tokens(iter(test_string.splitlines(True)).__next__):
        test_tokens.append(token)
    print("Done\n")

    # Test everything
    print("Test 3 - everything")

# Generated at 2022-06-11 20:05:35.150691
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokens = Untokenizer()
    untokens.compat((NAME, "abc"), [(NAME, "def"), (ASYNC, "async"), (NEWLINE, "\n")])
    assert untokens.tokens == ["abc", "def ", "async\n"]

    untokens = Untokenizer()

# Generated at 2022-06-11 20:05:44.554498
# Unit test for function generate_tokens
def test_generate_tokens():

    # Testing the tokenizer on a real file
    import token
    from unittest import TestCase

    sample_file = open("sample_file")
    sample_code = sample_file.read()
    sample_file.close()

    tokens = generate_tokens(iter(sample_code.splitlines()).__next__)
    tokens = list(tokens)
    token_type = [token.tok_name[token[0]] for token in tokens]

# Generated at 2022-06-11 20:05:56.313544
# Unit test for function generate_tokens
def test_generate_tokens():
    # Read in token list from stdin

    # Create token list
    token_list = []
    while 1:
        line = sys.stdin.readline()
        if line == "":
            break
        if line[-1] == "\n":
            line = line[:-1]
        token_list.append(eval(line))

    # Generate tokens
    tokens = []
    for tok in generate_tokens(token_list.pop):
        tokens.append(tok)

    # Compare tokens to input
    if token_list != tokens:
        print("token list != tokens!")
        print("token list:")
        print(token_list)
        print("tokens:")
        print(tokens)



# Generated at 2022-06-11 20:06:01.395374
# Unit test for function generate_tokens
def test_generate_tokens():
    # Test with string
    tokenize_test = "print('hello world')"
    print('token test: ',tokenize_test)
    tokens = list(generate_tokens(tokenize_test.splitlines().__iter__()))
    print('Tokens: ',tokens)
    print(tokens[0])


# Generated at 2022-06-11 20:06:13.231337
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        return line[0]

    def readline_random() -> bytes:
        return line.pop(0)

    def readline_bad() -> bytes:
        raise StopIteration

    line = [b"a = 1\n"]
    assert detect_encoding(readline) == ("utf-8", line)

    line = [b"# coding: latin-1\n", b"a = 1\n"]
    assert detect_encoding(readline) == ("iso-8859-1", line)

    line = [b"#!/usr/bin/python\n", b"# coding: latin-1\n", b"a = 1\n"]
    assert detect_encoding(readline) == ("iso-8859-1", line)


# Generated at 2022-06-11 20:06:24.696025
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

    with open("tokenize.txt") as f:
        d = f.read()

    def _tokenize_string(s):
        bits = []
        g = tokenize(StringIO(s).readline)
        for toknum, tokval, _, _, _ in g:
            bits.extend((toknum, tokval))

        return bits

    def check(s):
        toks = _tokenize_string(s)
        untoks = untokenize(toks)
        toks2 = _tokenize_string(untoks)
        assert toks == toks2


# Generated at 2022-06-11 20:06:35.479731
# Unit test for function tokenize
def test_tokenize():
    import io
    import unittest
    import sys

    if sys.flags.optimize >= 2:
        # Under -O2 and above, the assert_* functions never actually raise an
        # AssertionError, and the whole code gets optimized away.  This seems
        # to be a bug in the optimizer or inlining, or maybe in the
        # stackoverflow recursion limit.  In any case, there's no point
        # running this test when it's guaranteed to fail.
        return

    def assert_token_equal(token, type, string, start, end, line):
        assert token.type == type, "Got token type %s, expected %s" % (
            token.type,
            type,
        )