

# Generated at 2022-06-11 19:58:23.580196
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import StringIO
    import encodings

    # Check utf16-ish bom
    for bom, encoding in (
        (BOM_UTF8, "utf-8"),
        (BOM_UTF16, "utf-16"),
        (BOM_UTF16_LE, "utf-16-le"),
        (BOM_UTF16_BE, "utf-16-be"),
        (BOM_UTF32, "utf-32"),
        (BOM_UTF32_LE, "utf-32-le"),
        (BOM_UTF32_BE, "utf-32-be"),
    ):
        f = StringIO()
        f.write(bom)
        f.seek(0)
        assert detect_encoding(f.readline)[0] == encoding

    # Check utf8 bom
    f

# Generated at 2022-06-11 19:58:29.026003
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import unittest
    import tokenize

    class TestCase(unittest.TestCase):
        def test_method_untokenize(self):
            expected = "def f(x): return 2*x\n"
            untok = tokenize.Untokenizer()
            with io.StringIO() as f:
                f.write(expected)
                f.seek(0)
                tokens = list(tokenize.generate_tokens(f.readline))
            actual = untok.untokenize(tokens)
            self.assertEqual(expected, actual)
            self.assertTrue(tokens[-2][0] == tokenize.ERRORTOKEN)

    unittest.main()


# Generated at 2022-06-11 19:58:37.696391
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        if not lines:
            raise StopIteration
        return lines.pop(0)

    lines = [
        b"abc123\n",
    ]
    encoding, unused = detect_encoding(readline)
    assert (encoding, unused) == ("utf-8", [])

    lines = [
        b"# coding: utf8\n",
        b"abc123\n",
    ]
    encoding, unused = detect_encoding(readline)
    assert (encoding, unused) == ("utf-8", [b"# coding: utf8\n"])

    lines = [
        b"\xef\xbb\xbfabc123\n",
    ]
    encoding, unused = detect_encoding(readline)

# Generated at 2022-06-11 19:58:39.657507
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.NAME, "name", (1, 2), (1, 5), "line of text")

# unit test for function test_printtoken
test_printtoken()


# Generated at 2022-06-11 19:58:46.199311
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    lines = [
        "# -*- coding: latin-1 -*-\n",
        "# -*- coding: iso-8859-15 -*-\n",
        "b'\\xe4\\xf6\\xfc'\n",
        "u'\\xe4\\xf6\\xfc'\n",
        "b'\\xa4\\xd6\\xdc'\n",
        "u'\\xa4\\xd6\\xdc'\n",
        "b'\\xdf'\n",
        "b'\\xdf\\xdf'\n",
        "u'\\xdf\\xdf'\n",
        "\n",
    ]
    for line in lines:
        reader = io.StringIO(line)

# Generated at 2022-06-11 19:59:00.182163
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from .common import gbk_decode_tokens
    from .tokenize import untokenize, generate_tokens, open

    def gen(s):
        return generate_tokens(gbk_decode_tokens(s).__next__)

    def test(s):
        toks = list(gen(s))
        u = untokenize(toks)
        print(u)
        toks2 = list(gen(u))
        print(toks2)
        assert toks == toks2

    test("print('hi')")
    test("print('hi # no!')")
    test("x = 3 # XXX")
    test("""def f(x):
    print(x);
    return x**x;
""")


# Generated at 2022-06-11 19:59:05.600750
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return "tokenize_loop()"

    def tokeneater(type, token, start, end, line):
        assert type == NAME
        assert token == "tokenize_loop"
        assert start == (1, 0)
        assert end == (1, 13)
        assert line == "tokenize_loop()"

    tokenize_loop(readline, tokeneater)



# Generated at 2022-06-11 19:59:15.537189
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest
    from test import support
    byte_stream = io.BytesIO(b"def f():\n  return 'blah'\n")
    utf8_stream = io.TextIOWrapper(byte_stream, "utf-8")
    tokens = []
    tokenize_loop(utf8_stream.readline, tokens.append)

# Generated at 2022-06-11 19:59:26.490363
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO


# Generated at 2022-06-11 19:59:32.485905
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def f():
        yield ""
        yield "def f(): pass"
        yield "a=1"
        yield ""
    tokenize_loop(f().__next__, printtoken)
    def f():
        yield "def f(): pass"
        yield "a=1"
        yield ""
    tokenize_loop(f().__next__, printtoken)

# Generated at 2022-06-11 20:00:09.545830
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import generate_tokens, NUMBER, ENDMARKER, NAME, OP
    
    def test(expected, program):
        """
        Compare the output of the tokenizer to the list of expected tokens.

        The comparison is done in a stable way, comparing a token's
        ordinal (the token's position) in the expected sequence to its
        ordinal in the actual output.

        This prevents cases where reordering the tokens would make the
        test succeed.
        """
        gen = generate_tokens(program)
        
        tokens = list(gen)
        expected = sorted(expected, key=lambda x: (x[0], x[-1]))
        tokens = sorted(tokens, key=lambda x: (x[0], x[-1]))
        return tokens == expected


# Generated at 2022-06-11 20:00:22.277503
# Unit test for function detect_encoding
def test_detect_encoding():
    import unittest
    import io

    class DetectEncodingTest(unittest.TestCase):
        def test_detect_encoding1(self):
            s = "coding: latin-1\nspam = 1\n"
            fh = io.StringIO(s)

            self.assertEqual(detect_encoding(fh.readline)[0], "latin-1")

        def test_detect_encoding2(self):
            s = "spam = 1\n# coding: latin-1\n"
            fh = io.StringIO(s)

            self.assertEqual(detect_encoding(fh.readline)[0], "utf-8")


# Generated at 2022-06-11 20:00:34.201219
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    from tokenize import (
        tokenize,
        NUMBER,
        STRING,
        NAME,
        OP,
        encode_utf8,
        untokenize as untokenize_original,
    )
    import token
    import unittest

    class TestCase(unittest.TestCase):
        def do_test(self, f, *expected_tokens):
            result = []
            try:
                tokenize(f.readline, result.append)
            except tokenize.TokenError as e:
                self.fail(f"\n{e.args[0]}")
            self.assertEqual(result, [*expected_tokens])

# Generated at 2022-06-11 20:00:39.004077
# Unit test for function printtoken
def test_printtoken():
    printtoken(1,1,1,1,1)
    printtoken(1,1,1,1,1)



# Generated at 2022-06-11 20:00:46.874085
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    assert untok.tokens == []
    assert untok.prev_row == 1
    assert untok.prev_col == 0
    untok.add_whitespace((1, 0))
    assert untok.tokens == []
    assert untok.prev_row == 1
    assert untok.prev_col == 0
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" "]
    assert untok.prev_row == 1
    assert untok.prev_col == 1
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " "]
    assert untok.prev_row == 1
    assert untok.prev_col == 2
    untok.add_wh

# Generated at 2022-06-11 20:00:58.246305
# Unit test for function detect_encoding
def test_detect_encoding():
    import re
    import tokenize as tokenize_mod  # avoid shadowing

    stringio = lambda s: iter(s.splitlines(keepends=True))

    def assertEncoding(s, expected):
        with tokenize_mod.open(stringio(s)) as f:
            encoding, consumed = detect_encoding(f.__next__)
            lines = consumed + list(f)
        assert encoding == expected, (
            "Got encoding %r but expected %r for %r"
            % (encoding, expected, s)
        )
        return lines

    assertEncoding("", "utf-8")
    assertEncoding("\n", "utf-8")
    assertEncoding(" ", "utf-8")
    assertEncoding(" \n", "utf-8")

# Generated at 2022-06-11 20:01:09.917857
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        return next(lines)

    lines = iter([
        BOM_UTF8 + b'# -*- coding: utf-8 -*-\n',
        b'\r',
    ])
    assert detect_encoding(readline) == ('utf-8-sig', [BOM_UTF8 + b'# -*- coding: utf-8 -*-\n', b'\r'])

    lines = iter([
        BOM_UTF8 + b'\n',
    ])
    assert detect_encoding(readline) == ('utf-8-sig', [BOM_UTF8 + b'\n'])

    lines = iter([
        BOM_UTF8 + b'"""\n',
        b'"""\n',
    ])

# Generated at 2022-06-11 20:01:22.133331
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    from textwrap import dedent
    from tempfile import NamedTemporaryFile


# Generated at 2022-06-11 20:01:29.449248
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from token import NAME

    s = "for i in range(10): pass\n"
    f = StringIO(s).readline
    l = []
    tokenize_loop(f, l.append)
    assert len(l) == 7, "expected 7 tokens"
    assert l[0][0] == NAME, "expected a NAME token"
# end unit test



# Generated at 2022-06-11 20:01:40.774067
# Unit test for function tokenize
def test_tokenize():
    # Tests taken from tokenize.tests package
    import io


# Generated at 2022-06-11 20:02:08.752661
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO


# Generated at 2022-06-11 20:02:10.710934
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "42", (1, 1), (1, 2), "42")



# Generated at 2022-06-11 20:02:23.812461
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from blib2to3.pgen2.tokenize import Untokenizer
    # test for the roundtrip of a sample program
    u = Untokenizer()

# Generated at 2022-06-11 20:02:29.590405
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import BytesIO
    from blib2to3.pgen2.tokenize import generate_tokens
    ut = Untokenizer()
    f = BytesIO(b"def f(x):\n  if x: print x\n")
    out = ut.compat(next(generate_tokens(f.readline)), generate_tokens(f.readline))
    assert (
        out == "def f ( x ) :\n  if x : print x\n"
    ), "Untokenizer.compat() did not untokenize properly"



# Generated at 2022-06-11 20:02:40.181497
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield (
            b'#!/usr/bin/env python\n'
            b'\n'
            b'# -*- coding: iso-latin-1 -*-\n'
            b'\n'
            b'import sys\n'
        )
    assert detect_encoding(readline) == ("iso-8859-1", [b'#!/usr/bin/env python\n'])

    def readline():
        yield (
            b'\xef\xbb\xbf#!/usr/bin/env python\n'
            b'\n'
            b'\n'
            b'import sys\n'
        )

# Generated at 2022-06-11 20:02:45.290139
# Unit test for function tokenize
def test_tokenize():
    import io
    from typing import Union

    input_stream = io.StringIO("print(3)\n")  # type: Union[io.StringIO, io.TextIOWrapper]
    for token in generate_tokens(input_stream.readline):
        print(token)



# Generated at 2022-06-11 20:02:55.702635
# Unit test for function generate_tokens
def test_generate_tokens():
    import sys
    import tokenize
    from io import BytesIO

    def tokenize_print(readline):
        tokgen = tokenize.generate_tokens(readline)
        for toktype, tokval, _, _, _ in tokgen:
            print("%10s %-20r" % (tokenize.tok_name.get(toktype, toktype), tokval))

    if sys.version_info < (3, 0):
        tokenize_print(BytesIO("if 1:\n    x = 3\n").next)
    else:
        tokenize_print(BytesIO("if 1:\n    x = 3\n").__next__)

if __name__ == '__main__':
    test_generate_tokens()

# Generated at 2022-06-11 20:03:07.965689
# Unit test for function tokenize_loop
def test_tokenize_loop():
    value = """
      def t(a):
         '''
         hello
         '''
         return a
    """
    stream = iter(value.splitlines(True))
    output = []
    tokenize_loop(lambda: next(stream), output.append)

# Generated at 2022-06-11 20:03:13.576521
# Unit test for function generate_tokens
def test_generate_tokens():
    def test(s):
        for t in generate_tokens(iter(s.splitlines(True)).next):
            print(t[2], str(t[0]).rjust(20), t[1], repr(t[1]))

    test("""\
for x in range(10):
    pass""")



# Generated at 2022-06-11 20:03:23.954734
# Unit test for function tokenize
def test_tokenize():
    import io

    src = "for x in range(11): print(x)"
    toks = list(tokenize(io.StringIO(src).readline))

# Generated at 2022-06-11 20:04:31.395571
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import sys
    import token

    # Test binary data
    encoding = "latin-1"
    data = bytes([239, 187, 191] + list(range(32)) + [127] + list(range(128, 256)))
    for args in ((data, encoding), (io.BytesIO(data), encoding)):
        if sys.version_info[:2] >= (3, 3):
            tokens = list(tokenize(*args))
        else:
            tokens = list(tokenize(args[0]))

# Generated at 2022-06-11 20:04:41.977931
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    readline = StringIO("asdf").readline
    tokeneater = printtoken
    out = []
    _printtoken = printtoken

    def kaka(type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
        (srow, scol) = xxx_todo_changeme2
        (erow, ecol) = xxx_todo_changeme3
        out.append((type, token, srow, scol, erow, ecol, line))

    tokenize_loop(readline, kaka)
    assert out == [(1, 'asdf', 1, 0, 1, 4, 'asdf')]



# Generated at 2022-06-11 20:04:47.049418
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    s = "def f():\n  x = 3\n"
    g = generate_tokens(s.splitlines)
    r = u.untokenize(g)
    expected = "def f ():\n x = 3\n"
    assert r == expected


# backwards compatible interface

# Generated at 2022-06-11 20:04:54.730658
# Unit test for function tokenize
def test_tokenize():
    import io
    from . import tokenize

    f = io.StringIO("def foo(): pass")
    tokenize.tokenize(f.readline, printtoken)
    # Output:
    # 1,0-1,3:   NAME    'def'
    # 1,4-1,7:   NAME    'foo'
    # 1,8-1,11:  OP      '('
    # 1,11-1,12: OP      ')'
    # 1,12-1,16: OP      ':'
    # 1,16-1,20: NAME    'pass'



# Generated at 2022-06-11 20:05:05.867913
# Unit test for function generate_tokens

# Generated at 2022-06-11 20:05:17.008738
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'\xef\xbb\xbf'
        yield b'# -*- coding: latin-1 -*-'
        yield b'print("hello world")'
        yield b''

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b'\xef\xbb\xbf', b'# -*- coding: latin-1 -*-', b'print("hello world")']

    def readline():
        yield b'\xef\xbb\xbf'
        yield b'#!/usr/bin/env python3'
        yield b''

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8-sig"

# Generated at 2022-06-11 20:05:23.021677
# Unit test for function printtoken
def test_printtoken():
    printtoken(NAME, 'print', (0, 0), (0, 5), 'print')
    printtoken(NEWLINE, '\n', (0, 0), (0, 5), 'print')
    printtoken(STRING, '"spam"', (1, 0), (1, 5), 'print')


# Generated at 2022-06-11 20:05:28.305176
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def check(toks, exp):
        got = Untokenizer().untokenize(iter(toks))
        if got != exp:
            print("%r ret %r != expected %r" % (toks, got, exp))

    check(
        [("a", "x"), ("b", "y")],
        "xy",
    )

    check(
        [("a", "x"), (")", ")"), ("("), ("b", "y")],
        "x) (y",
    )

    check(
        [(NL, "\n")],
        "\n",
    )

    check(
        [(NAME, "a"), (NL, "\n"), (NAME, "b")],
        "a\nb",
    )


# Generated at 2022-06-11 20:05:37.167474
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test encodings w/o BOM
    def readline():
        yield b"#!/usr/bin/python3\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"pass\n"
        yield b"\n"
        raise StopIteration

    assert detect_encoding(readline) == ("iso-8859-1", [b"# -*- coding: latin-1 -*-\n"])

    def readline():
        yield b"#!/usr/bin/python3\n"
        yield b"# -*- coding: ascii -*-\n"
        yield b"pass\n"
        yield b"\n"
        raise StopIteration


# Generated at 2022-06-11 20:05:45.974988
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline(encoding):
        if encoding == "utf-8":
            yield b"# -*- coding: utf-8 -*-"
            yield b"\n"
        elif encoding == "utf-8-sig":
            yield b"\xef\xbb\xbf"
            yield b"# -*- coding: utf-8 -*-"
            yield b"\n"
        elif encoding == "iso-8859-1":
            yield b"# -*- coding: latin-1 -*-"
            yield b"\n"
        elif encoding == "iso-8859-15":
            yield b"# -*- coding: iso-8859-15 -*-"
            yield b"\n"