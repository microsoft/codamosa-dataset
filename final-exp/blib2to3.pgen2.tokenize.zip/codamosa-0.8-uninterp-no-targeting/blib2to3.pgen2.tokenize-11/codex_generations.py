

# Generated at 2022-06-21 10:21:49.769894
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:21:51.561534
# Unit test for constructor of class TokenError
def test_TokenError():
    err = TokenError("message")
    assert err.msg == "message"



# Generated at 2022-06-21 10:21:53.298558
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:21:57.808135
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        yield b"# coding: latin-1\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "latin-1"
    assert lines == [b"# coding: latin-1\n"]

    def readline() -> bytes:
        yield b"\xef\xbb\xbf# coding: latin-1\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8-sig"
    assert lines == [b"# coding: latin-1\n"]

    def readline() -> bytes:
        yield b"\xef\xbb\xbf# coding: utf-8\n"

    encoding, lines = detect_encoding(readline)

# Generated at 2022-06-21 10:22:04.367872
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output):
        # Test untokenize's ability to roundtrip tokenize
        readline = iter(input.splitlines(1)).__next__
        tokens = tokenize(readline)
        reconstructed = untokenize(tokens)
        readline = iter(reconstructed.splitlines(1)).__next__
        tokens = list(tokenize(readline))
        assert untokenize(tokens) == reconstructed
        if output:
            # Test that output matches either input or the roundtrip
            # value. This is just a sanity check; the test_tokenize
            # tests exercise untokenize() in detail.
            assert untokenize(tokens) in (input, reconstructed)

    compare('a = 1+1\n', 'a = 1 + 1\n')

# Generated at 2022-06-21 10:22:05.259817
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:22:05.927361
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    exc = StopTokenizing()
    assert isinstance(exc, Exception)



# Generated at 2022-06-21 10:22:10.393225
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 1
    untok.add_whitespace((2, 1))
    assert untok.tokens == ["\n"]
    untok.add_whitespace((2, 3))
    assert untok.tokens == ["\n", "  "]
    untok.tokens = []
    untok.add_whitespace((1, 5))
    assert untok.tokens == ["    "]
    untok.tokens = []
    untok.prev_row = 2
    untok.prev_col = 0
    untok.add_whitespace((2, 2))
    assert untok.tokens == ["  "]
    untok.tokens = []


# Generated at 2022-06-21 10:22:14.371853
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.tokens = ["Hello ", "world!"]
    u.prev_row = 1
    u.prev_col = 0
    assert u.tokens == ["Hello ", "world!"]
    assert u.prev_row == 1
    assert u.prev_col == 0



# Generated at 2022-06-21 10:22:16.377772
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        pass



# Generated at 2022-06-21 10:22:42.644681
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
test_any()



# Generated at 2022-06-21 10:22:44.824084
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def untokenize(iterable):
        ut = Untokenizer()
        return ut.untokenize(iterable)



# Generated at 2022-06-21 10:22:46.505091
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    res = untok.untokenize([("a", "b"), ("c", "d")])
    assert res == "bd"



# Generated at 2022-06-21 10:22:54.519406
# Unit test for function tokenize
def test_tokenize():
    import io
    from blib2to3.pgen2 import tokenize as _tokenize
    from tokenize import check_tokenize_raw_str

    def tokenize(iterable):
        for item in iterable:
            if isinstance(item, bytes):
                item = item.decode("iso8859-1")
            yield(item)
    check_tokenize_raw_str(tokenize)



# Generated at 2022-06-21 10:23:03.559465
# Unit test for function detect_encoding
def test_detect_encoding():
    from unittest import TestCase

    from blib2to3.pytree import Leaf

    class TokenTest(TestCase):
        def check(self, input, expected):
            result, lines = detect_encoding(iter(input).__next__)
            self.assertEqual(result, expected)

    # Examples taken from PEP-0263.
    t = TokenTest()
    t.check(
        ["# coding=<encoding name>\n", "# blah blah\n", "pass\n"], "<encoding name>"
    )
    t.check(
        [
            "#!/usr/bin/python\n",
            "# -*- coding: <encoding name> -*-\n",
            "# blah blah\n",
            "pass\n",
        ],
        "<encoding name>",
    )

# Generated at 2022-06-21 10:23:09.001750
# Unit test for function generate_tokens
def test_generate_tokens():
    r"""Test tokenize.generate_tokens().

    This is not really a useful test, but it does exercise the
    full tokenizing logic.
    """
    import io
    import token
    from tokenize import generate_tokens

    # This example code is taken from Lib/tokenize.py
    readline = io.BytesIO(
        b"if 1:\n"
        + b"    # comment\n"
        + b"    x = 3\n"
    ).readline

    for token in generate_tokens(readline):
        print(token)

    # tokenize a Python expression
    string = "3 + 4j"
    readline = io.BytesIO(string.encode("utf-8")).readline


# Generated at 2022-06-21 10:23:16.288139
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def fp(s: Text) -> Iterator[bytes]:
        yield s.encode("utf-8")

    assert detect_encoding(fp("coding: latin-1")) == ("iso-8859-1", [])
    assert detect_encoding(fp("blah blah")) == ("utf-8", [])
    assert detect_encoding(fp("blah blah")) == ("utf-8", [])
    assert detect_encoding(fp("")) == ("utf-8", [])
    assert detect_encoding(fp("\ufeffblah blah")) == ("utf-8-sig", [])
    assert detect_encoding(fp("\ufeff")) == ("utf-8-sig", [])

# Generated at 2022-06-21 10:23:26.957027
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
  u = Untokenizer()
  s = u.untokenize([(NUMBER, '1234'), (NAME, 'spam'), (NAME, 'eggs')])
  assert s == '1234spam eggs '
  s = u.untokenize([(NUMBER, '1234'), (NAME, 'spam'), (NAME, 'eggs'),
                    (OP, '+'), (OP, '+'), (OP, '+')])
  assert s == '1234spam eggs +++'
  s = u.untokenize([(OP, '+'), (OP, '+'), (OP, '+'),
                    (NUMBER, '1234'), (NAME, 'spam'), (NAME, 'eggs')])
  assert s == '+++ 1234spam eggs '

# Generated at 2022-06-21 10:23:33.098342
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        return 'print(fun(x))'
    def check_token(type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
        (srow, scol) = xxx_todo_changeme2
        (erow, ecol) = xxx_todo_changeme3
        assert (srow, scol, erow, ecol) == (0,0,0,6)
    tokenize_loop(readline, check_token)



# Generated at 2022-06-21 10:23:39.106894
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():

    from io import StringIO

    from .tokenize import _tokenize

    u = Untokenizer()
    f = StringIO("a = 0\n")
    g = _tokenize(f.readline, u.compat)
    list(g)
    assert u.tokens == ["a ", "= ", "0", "\n"]



# Generated at 2022-06-21 10:24:07.496572
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readlines():
        yield "abc"
        yield "def"
        yield ""

    tokenized_lines = []
    def tokeneater(*args):
        tokenized_lines.append(args)

    tokenize_loop(readlines, tokeneater)
    expected = [
        (NAME, "abc", (1, 0), (1, 3), ""),
        (NAME, "def", (2, 0), (2, 3), ""),
        (ENDMARKER, "", (3, 0), (3, 0), ""),
    ]
    assert tokenized_lines == expected



# Generated at 2022-06-21 10:24:09.670760
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    assert tokenize == tokenize_loop, "!="
    assert tokenize == tokenize, "!="


# Generated at 2022-06-21 10:24:11.865855
# Unit test for function tokenize_loop
def test_tokenize_loop():
    x = tokenize_loop(iter(["a b c"]).__next__, lambda *x: print(x))
    assert x is None



# Generated at 2022-06-21 10:24:13.648206
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        e.args is not None



# Generated at 2022-06-21 10:24:15.634635
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("test token error")
    except TokenError as e:
        assert str(e) == "test token error"



# Generated at 2022-06-21 10:24:26.519965
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_row = 5
    ut.prev_col = 2
    ut.add_whitespace((7, 3))
    assert ut.prev_row == 7
    assert ut.prev_col == 3
    assert ut.tokens == [], ut.tokens

    ut = Untokenizer()
    ut.prev_row = 5
    ut.prev_col = 2
    ut.add_whitespace((5, 3))
    assert ut.prev_row == 5
    assert ut.prev_col == 3
    assert ut.tokens == [" "], ut.tokens

    ut = Untokenizer()
    ut.prev_row = 5
    ut.prev_col = 2
    ut.add_whitespace((5, 5))
    assert ut.prev_

# Generated at 2022-06-21 10:24:34.884045
# Unit test for constructor of class TokenError
def test_TokenError():
    import re
    import tokenize

    s = "xyz"
    try:
        raise tokenize.TokenError(1, 2, 3, s)
    except tokenize.TokenError as e:
        pass
    assert e.args == (1, 2, 3, s)
    assert e.start == 1
    assert e.end == 2
    assert e.lineno == 3
    assert e.line == s
    assert e.text is None
    assert re.search(r"\(1, 2, 3, 'xyz'\)", str(e))



# Generated at 2022-06-21 10:24:47.244354
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass


# A table identifying the token prefix to use for each token type,
# when untokenizing.

# Generated at 2022-06-21 10:24:48.767316
# Unit test for function group
def test_group():

    assert group('abc', 'def') == '(abc|def)'


# Generated at 2022-06-21 10:24:55.793016
# Unit test for function detect_encoding
def test_detect_encoding():
    from blib2to3.pgen2.tokenize import detect_encoding
    from blib2to3.pgen2.token import tokenize

    # Encoding is detected from utf-8 BOM
    source = bytes("# coding=utf-8\nc = 1\n", "utf-8")
    source = source[3:]
    encoding, lines = detect_encoding(iter([source]).__next__)
    assert encoding == "utf-8-sig"
    tokenize(iter([source]).__next__)

    # Encoding is detected from utf-8 BOM and next line
    source = bytes("# coding=utf-8\nc = 1\n", "utf-8")
    encoding, lines = detect_encoding(iter([source]).__next__)

# Generated at 2022-06-21 10:26:41.373281
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:26:49.635860
# Unit test for function any
def test_any():
    test_s = lambda s: bool(re.match(any(*"abc"), s))
    assert test_s("c")
    assert test_s("")
    assert test_s("b")
    assert not test_s("d")
    assert test_s("aca")
    assert test_s("aab")
    assert test_s("abbbbb")
    assert not test_s("abbbbbd")
    assert test_s("abbd")
    assert test_s("abbbda")



# Generated at 2022-06-21 10:26:50.719840
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()



# Generated at 2022-06-21 10:26:53.364857
# Unit test for function generate_tokens
def test_generate_tokens():
    from types import GeneratorType 
    from unittest import TestCase

    class GenerateTokensTests(TestCase):

        def test_generate_tokens(self):
            def gen():
                yield ""
            self.assertIsInstance(generate_tokens(gen), GeneratorType)

    tests = GenerateTokensTests()
    tests_gen = getattr(tests, 'test_generate_tokens')
    tests_gen()

# Generated at 2022-06-21 10:27:04.494631
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import pprint, io

    u = Untokenizer()
    toksource = iter(
        [
            (1, "def"),
            (0, " "),
            (1, "f"),
            (0, "("),
            (1, "x"),
            (0, ")"),
            (3, ":"),
            (4, "\n"),
            (0, " "),
            (0, " "),
            (0, " "),
            (0, " "),
            (1, "return"),
            (0, " "),
            (1, "None"),
            (0, "\n"),
        ]
    )
    result = u.untokenize(toksource)
    handle = io.StringIO(result)
    pprint.pprint(list(handle))

# Generated at 2022-06-21 10:27:07.796770
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    tok = ((0, '3'), (-4, '4'), (4, '5'))
    u.untokenize(tok)



# Generated at 2022-06-21 10:27:11.219217
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([]) == ""
    assert u.untokenize([("a", "a"), ("newline", "\n"), ("b", "b")]) == "a b"
    assert u.untokenize([("newline", "\n"), ("b", "b"), ("newline", "\n")]) == "b "
    assert u.untokenize([("a", "a"), ("c", "c"), ("b", "b")]) == "a bb"



# Generated at 2022-06-21 10:27:12.372491
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:27:14.178576
# Unit test for function maybe
def test_maybe():
    assert maybe('foo') == '(foo)?'
    assert maybe('foo', 'bar') == '(foo|bar)?'


# Generated at 2022-06-21 10:27:19.347145
# Unit test for function printtoken
def test_printtoken():
    printtoken(3, "abc", (0, 0), (0, 3), "abc")
    printtoken(3, "abc", (0, 0), (0, 3), "abc")



# Generated at 2022-06-21 10:28:25.490210
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    from blib2to3.pgen2.tokenize import StringIO
    r = io.BytesIO(
        b"def foo(param): return 'bar'\n"
        b'"""test docstring"""\n'
        b"def baz(): return 'baz'"
    )
    s = StringIO()
    tokenize_loop(r.readline, s.write)
    s.seek(0)

# Generated at 2022-06-21 10:28:30.457792
# Unit test for function maybe
def test_maybe():
    eol = r"[ \t]*(#[^\r\n]*)?[\r\n]"
    assert re.match(maybe(eol), "")
    assert re.match(maybe(eol), "\n")
    assert re.match(maybe(eol), " # comment\n")


_namechars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_"
_first_idchars = _namechars + "0123456789"
_idchars = _first_idchars + "\\"



# Generated at 2022-06-21 10:28:38.108020
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    ut = Untokenizer()
    inp = [("KEYWORD", "if"), ("NAME", "True"),("OP", ":"),("NEWLINE", "\n"),("INDENT","    "),("NAME","print"),("OP","("),("NUMBER","1"),("OP",")"),("NEWLINE","\n"),("DEDENT",""),("NAME","print"),("OP","("),("NUMBER","2"),("OP",")")]
    outp = "if True:\n    print(1)\n\nprint(2)"
    assert ut.untokenize(inp) == outp


# Generated at 2022-06-21 10:28:50.304737
# Unit test for function maybe
def test_maybe():
    assert maybe('a', 'b') == '(a|b)?'


# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.
Whitespace = r"[ \f\t]*"
Comment = r"\#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"\w+"

# This is needed for tokenize.untokenize to work backwards; it is the MULTILINE
# variant of the Sre_Pattern type, which is used to represent compiled regular
# expressions in the Python standard library.
#
# The regular expression type is obtained by calling type(re.compile('')).

# Generated at 2022-06-21 10:29:01.017545
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():

    class MockTokenInfo:

        def __init__(self, token_info):
            self.token_info = token_info

        def __getitem__(self, item):
            return self.token_info[item]

    def test_Untokenizer(self, test_case):
        text = test_case[0]
        iterable = map(MockTokenInfo, test_case[1])
        untokenizer = Untokenizer()
        result = untokenizer.untokenize(iterable)
        assert text == result, f"Expected '{text}', got '{result}'"


# Generated at 2022-06-21 10:29:05.038765
# Unit test for function maybe
def test_maybe():
    # Empty string
    assert re.match(maybe("a"), "")
    # Present, normal case
    assert re.match(maybe("a"), "a")
    # Present, degenerate case
    assert re.match(maybe("a"), "aa")



# Generated at 2022-06-21 10:29:07.314647
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, '1',  (0, 0), (0, 0), '')



# Generated at 2022-06-21 10:29:10.036221
# Unit test for function any
def test_any():
    assert any("a", "b", "c") == "(a|b|c)*"
    assert any("abc") == "(abc)*"


# Generated at 2022-06-21 10:29:10.862281
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "token", (2, 3), (4, 5), "line")



# Generated at 2022-06-21 10:29:14.643231
# Unit test for function any
def test_any():
    a, b, c = any("a", "b", "c")
    assert a.pattern == "a*"
    assert b.pattern == "b*"
    assert c.pattern == "c*"
test_any()

