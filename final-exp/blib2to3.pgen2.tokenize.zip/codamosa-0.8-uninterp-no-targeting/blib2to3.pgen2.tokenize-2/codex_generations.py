

# Generated at 2022-06-21 10:21:44.749367
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    StopTokenizing()



# Generated at 2022-06-21 10:21:50.377449
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import tokenize

    from tokenize import detect_encoding

    def _test(s: str, exp_encoding: str, exp_first_line: str) -> None:
        lines = s.splitlines(True)
        if not lines[-1].endswith("\n"):
            lines[-1] += "\n"

        def readline() -> str:
            return lines.pop(0)

        encoding, first_line = detect_encoding(readline)
        assert encoding == exp_encoding, f"encoding = {encoding!r}, expected {exp_encoding!r}"
        assert first_line == exp_first_line, f"first line = {first_line!r}, expected {exp_first_line!r}"

    # Blank.

# Generated at 2022-06-21 10:21:57.709648
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as _tokenize
    r = io.BytesIO(
        "if 1:\n  pass\n"
        "#\n"
        '"""\n'
        '"""\n'
        "#\n"
    )
    # This works because tokenize's generator does a .next() at the end.
    all = list(_tokenize.tokenize(r.readline))

# Generated at 2022-06-21 10:22:03.429343
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import unittest
    import io
    import difflib
    import tokenize
    import token

    class TestUntokenizer(unittest.TestCase):

        def cmp_output(self, input, output):
            sout = io.StringIO()
            tokenize.tokenize(io.StringIO(input).readline, untokenize.Untokenizer(sout).untokenize)
            sres = sout.getvalue()
            if sres != output:
                d = difflib.Differ()
                sres = "".join(d.compare(output.splitlines(1), sres.splitlines(1)))
                self.fail("Untokenizing:\n" + sres)


# Generated at 2022-06-21 10:22:05.393589
# Unit test for function group
def test_group():
    assert group("al", "bums") == "(al|bums)"

# Generated at 2022-06-21 10:22:15.468668
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    with StringIO("def f():\n    a = 1") as f:
        tokens = tuple(generate_tokens(f.readline))

# Generated at 2022-06-21 10:22:20.332661
# Unit test for function printtoken
def test_printtoken():
    # (type, token, (srow, scol), (erow, ecol), line)
    printtoken(NUMBER, "1", (1, 0), (1, 1), "")
    printtoken(NUMBER, "1", (0, 0), (0, 1), "")



# Generated at 2022-06-21 10:22:27.945561
# Unit test for function tokenize

# Generated at 2022-06-21 10:22:29.575215
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    assert str(StopTokenizing()) == "No more input"



# Generated at 2022-06-21 10:22:33.833753
# Unit test for function untokenize
def test_untokenize():
    sample = '''def f():
    return "foo"  '''
    readline = iter(sample.splitlines(1)).__next__
    tokengen = generate_tokens(readline)
    try:
        token1 = tokengen.__next__()
    except StopIteration:
        print("ERROR: No tokens found")
    newcode = untokenize(iter([token1]))
    readline = iter(newcode.splitlines(1)).__next__
    tokengen = generate_tokens(readline)
    token2 = tokengen.__next__()
    assert token1[0:2] == token2[0:2], "Untokenize failed"
    import io, tokenize
    s = io.StringIO("x = '''\\\n    '''")

# Generated at 2022-06-21 10:23:01.709895
# Unit test for function generate_tokens
def test_generate_tokens():
    import untokenize
    from io import StringIO

    def get_tokens(s: str) -> Iterator[TokenInfo]:
        return generate_tokens(StringIO(s).readline)

    for fn in [
        "test_tokenize",
        "test_opmap",
        "test_future",
        "test_tokenize_empty",
        "test_tokenize_empty_bytes",
        "test_tokenize_string_literal_unterminated",
        "test_tokenize_bytes_literal_unterminated",
    ]:
        source = getattr(tokenize_tests, fn)
        got = list(get_tokens(source))
        want = getattr(tokenize_tests, fn + "_ex")
        got_text = untokenize.untokenize(got)

# Generated at 2022-06-21 10:23:06.788705
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import token
    import io
    import tokenize
    r = io.BytesIO(
        b"""def function(a, b):
    pass
"""
    )
    result = []
    untok = Untokenizer()
    tokenize.tokenize(r.readline, result.append)
    x = untok.untokenize(result)
    x
    assert x == "def function(a, b):\n    pass\n"



# Generated at 2022-06-21 10:23:14.778017
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    untok.add_whitespace((1, 1))
    untok.tokens.append("test")
    assert untok.tokens == [" ", "test"]
    untok.prev_row = 1
    untok.prev_col = 10
    untok.add_whitespace((1, 10))
    assert untok.tokens == [" ", "test"]
    untok.add_whitespace((1, 15))
    assert untok.tokens == [" ", "test", " ", " ", " ", " ", " ", " ", " "]
    untok.add_whitespace((2, 10))
    assert untok.tokens == [" ", "test", " ", " ", " ", " ", " ", " ", " ", "\n", " "]
    unt

# Generated at 2022-06-21 10:23:19.760388
# Unit test for function maybe
def test_maybe():
    assert maybe(r'a') == '(a)?', maybe(r'a')
    assert maybe(r'a', r'b') == '(a|b)?', maybe(r'a', r'b')
test_maybe()

# Tail recursion optimised

# Generated at 2022-06-21 10:23:26.078770
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", maybe("a")
    assert maybe("ab") == "((ab)?)", maybe("ab")
    assert maybe("abc") == "((abc)?)", maybe("abc")
    assert maybe("a", "ab") == "((a)|(ab))?", maybe("a", "ab")
    assert maybe("a", "ab", "abc") == "((a)|(ab)|(abc))?", maybe("a", "ab", "abc")



# Generated at 2022-06-21 10:23:28.608190
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    assert issubclass(StopTokenizing, Exception)



# Generated at 2022-06-21 10:23:30.380984
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:23:42.418155
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    unt = Untokenizer()
    toklist = [(NUMBER, "42"), (NEWLINE, "\\n"), (NAME, "spam"), (OP, "+"),
               (NAME, "eggs"), (NEWLINE, "\\n"), (ENDMARKER, "")]
    toksrc = unt.untokenize(toklist)
    if toksrc != "42\nspam + eggs\n":
        print("problem untokenizing tokens")
        print("wanted: '42\\nspam + eggs\\n'")
        print("untokenized:", toksrc)
        print("difference:", difflib.ndiff(toksrc, "42\nspam + eggs\n"))
        return 0
    # Issue 10371: Check that adding a trailing newline works too.

# Generated at 2022-06-21 10:23:46.691872
# Unit test for function detect_encoding
def test_detect_encoding():

    def reader(lines: List[bytes]) -> Callable[[], bytes]:
        def _reader():
            for line in lines:
                yield line

        return _reader

    def check(expected: str, *lines: List[bytes]) -> None:
        encoding, lines = detect_encoding(reader(lines)())
        assert encoding == expected, encoding

    check("ascii", b"# -*- coding: ascii -*-\n")
    check("ascii", b"# coding: ascii\n")
    check("ascii", b" \t# coding: ascii\n")
    check("ascii", b"# -*- coding: ascii -*- \t\n")
    check("ascii", b"# vim:fileencoding=ascii\n")
   

# Generated at 2022-06-21 10:23:50.555821
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io

    f = io.StringIO()
    u = Untokenizer()
    u.tokens = []
    u.prev_row = 1
    u.prev_col = 0
    assert u.tokens == []
    assert u.prev_row == 1
    assert u.prev_col == 0



# Generated at 2022-06-21 10:24:27.869973
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Test case for tokenize()
    def test_tokenize(s, expected):
        result_list = []
        result_list.append(None)
        def tokeneater(*args):
            result_list.append(args)
        line_iterator = iter(s.splitlines(True))
        tokenize_loop(line_iterator.__next__, tokeneater)
        result_list.pop(0)
        if result_list != expected:
            print(s, expected, result_list)
            assert expected == result_list
    test_tokenize("\n", [])
    test_tokenize("a", [(tok_name[NAME], "a", (1, 0), (1, 1), "a")])
    test_tokenize(" ", [])

# Generated at 2022-06-21 10:24:34.288028
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    from io import BytesIO
    from typing import Iterator
    from . import tokenize
    from .token import GoodTokenInfo

    def _tokenize_example(source: Union[str, bytes]) -> Iterator[GoodTokenInfo]:
        return tokenize.tokenize(BytesIO(source if isinstance(source, bytes) else source.encode("utf-8")).readline)

    def test(source: Union[str, bytes], token_list: List[Union[GoodTokenInfo, str]]) -> None:
        compact = False
        if len(token_list) >= 1 and isinstance(token_list[0], str) and token_list[0].startswith("compact"):
            compact = True
            del token_list[0]
        tokens = list(_tokenize_example(source))

# Generated at 2022-06-21 10:24:37.787951
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    def test():
        raise StopTokenizing

    try:
        test()
    except StopTokenizing:
        pass
    else:
        raise AssertionError("Failed to raise StopTokenizing exception.")



# Generated at 2022-06-21 10:24:49.973855
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import tokenize

    def readline() -> bytes:
        line = infp.readline()
        if not line:
            raise tokenize.TokenError
        return line

    # With BOM
    inf = io.BytesIO(
        BOM_UTF8
        + b'# -*- coding: latin-1 -*-\n'
        + b'a = "\\xe4"\n'
        + b'print(a)\n'
    )
    infp = inf.detach()
    encoding, lines = tokenize.detect_encoding(readline)
    assert encoding == "utf-8-sig"
    # With coding cookie

# Generated at 2022-06-21 10:24:54.259500
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    try:
        raise TokenError("some message")
    except TokenError as e:
        assert str(e) == "some message"



# Generated at 2022-06-21 10:24:58.388921
# Unit test for function printtoken
def test_printtoken():
    printtoken(4, 'token', (1, 2), (1, 4), 'line')
    printtoken(5, 'token', (1, 2), (1, 4), 'line')



# Generated at 2022-06-21 10:25:06.753027
# Unit test for function tokenize
def test_tokenize():
    from . import token, tokenize

    def tokens(s):
        toktypes = []
        tok = []
        parenlevel = 0
        with open_as_bytes(__file__) as fp:
            g = tokenize.generate_tokens(fp.readline)  # @UndefinedVariable
            for toknum, tokval, _, _, _ in g:
                tok.append(tokval)
                toktypes.append(toknum)
                if toknum == token.LPAR:
                    parenlevel += 1
                elif toknum == token.RPAR:
                    parenlevel -= 1
                    if parenlevel <= 0:
                        break
        return toktypes[tok.index(s) + 1]


# Generated at 2022-06-21 10:25:14.620690
# Unit test for function untokenize
def test_untokenize():
    import tokenize
    from io import BytesIO, StringIO

    def compare(expected, result):
        if expected != result:
            raise AssertionError((expected, result))

    eq = compare
    eq(untokenize([(1, "1")]), "1")
    eq(untokenize([(1, "1"), (0, " "), (1, "2")]), "1 2")
    eq(untokenize([(0, " "), (1, "1"), (0, " "), (1, "2")]), " 1 2")



# Generated at 2022-06-21 10:25:16.986396
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass


# Helper functions for class TokenInfo

# Generated at 2022-06-21 10:25:30.341586
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    from io import StringIO

    from token import (
        INDENT,
        DEDENT,
        NEWLINE,
        NAME,
        INTEGER,
        COMMENT,
        STRING,
        NL,
        ASYNC,
        AWAIT,
    )


# Generated at 2022-06-21 10:26:40.312630
# Unit test for function tokenize
def test_tokenize():
    import io
    global token, tokenize
    import tokenize as _tokenize

    # Wrap io.BytesIO with an encoding-aware reader.
    def bytesio(s):
        return io.TextIOWrapper(io.BytesIO(s), encoding="utf-8")

    # Wrap an iterable of binary bytes with an encoding-aware reader.
    def byteslist(l):
        return bytesio(b"".join(l))

    # Wrap a binary string with an encoding-aware reader.
    def bytesstring(s):
        return bytesio(s.encode("utf-8"))

    # Wrap an iterable of unicode strings with an encoding-aware reader.
    def textlist(l):
        return io.StringIO("".join(l))

    # Wrap a unicode string with an encoding-aware reader.

# Generated at 2022-06-21 10:26:52.492290
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    result = u.compat((NEWLINE, '\n'), [])
    assert not result

    u = Untokenizer()
    token1 = (NAME, 'name', (1, 0), (1, 4), 'str')
    token2 = (NEWLINE, '\n', (1, 4), (1, 5), 'str')
    token3 = (INDENT, '\t', (2, 0), (2, 1), 'str')
    token4 = (NAME, 'name', (2, 1), (2, 5), 'str')
    token5 = (DEDENT, '\n', (2, 5), (2, 6), 'str')
    result = u.compat((NEWLINE, '\n'), [token1, token2, token3, token4, token5])
   

# Generated at 2022-06-21 10:26:55.020045
# Unit test for function maybe
def test_maybe():
    return maybe(*["a"]) == "a?"

# Forward declarations for regex parsing functions



# Generated at 2022-06-21 10:26:56.959241
# Unit test for function printtoken
def test_printtoken(): printtoken(1,2,(3,4),(5,6),7)


# Generated at 2022-06-21 10:27:03.653007
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3.4", (1,0), (1,2), "")
    printtoken(STRING, "3.4", (1,0), (1,2), "")
    printtoken(OP, "3.4", (1,0), (1,2), "")
    printtoken(COMMENT, "3.4", (1,0), (1,2), "")

test_printtoken()


# Generated at 2022-06-21 10:27:13.506408
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    # test case
    untokenizer_compat_test_case = (
        (
            "class A:",
            (NEWLINE, "\n"),
            ("    ", INDENT, "\n"),
            ("    def __init__(self):", NEWLINE, "\n"),
            ("        pass", NEWLINE, "\n"),
            ("    ", DEDENT, "\n"),
        ),
        "class A:\n    def __init__(self):\n        pass\n",
    )
    untok = Untokenizer()
    result = untok.compat(*untokenizer_compat_test_case[0])
    assert untok.tokens == untokenizer_compat_test_case[1]



# Generated at 2022-06-21 10:27:26.578800
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    utok = Untokenizer()

# Generated at 2022-06-21 10:27:28.459458
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:27:30.787005
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    else:
        assert 0, "constructor for StopTokenizing failed"



# Generated at 2022-06-21 10:27:43.707012
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    import tokenize
    text = "def f(): pass\n"
    r = io.BytesIO(text.encode('utf-8')).readline
    g = generate_tokens(r)
    compare = [
        (token.NAME, 'def'),
        (token.NAME, 'f'),
        (token.OP, '('),
        (token.OP, ')'),
        (token.OP, ':'),
        (token.NAME, 'pass'),
        (tokenize.NEWLINE, '\n'),
        (token.ENDMARKER, ''),
    ]
    for want, got in zip(compare, g):
        assert want == got, "wanted %s, got %s" % (want, got)
    # Now make sure the generator can be resumed


# Generated at 2022-06-21 10:29:19.657513
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    """This is a test method for the constructor of class Untokenizer."""
    input_tokens = [("k", "is_keyword")]
    ut = Untokenizer()
    ut.compat(input_tokens[0], iter([]))
    assert ut.tokens == ["is_keyword "]



# Generated at 2022-06-21 10:29:23.775617
# Unit test for function any
def test_any():
    def check(s):
        a = any(*s)
        assert a
    check(["hello", "world"])
    check([])



# Generated at 2022-06-21 10:29:31.535564
# Unit test for function untokenize
def test_untokenize():
    import tokenize

# Generated at 2022-06-21 10:29:43.539958
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError()



# Generated at 2022-06-21 10:29:45.621415
# Unit test for function tokenize
def test_tokenize():
    for t in tokenize(iter(['"Hello World"', 'print("Hello World")'])):
        print(t)



# Generated at 2022-06-21 10:29:47.166051
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # The test is that this doesn't crash or raise an exception
    t = StopTokenizing()



# Generated at 2022-06-21 10:29:58.665064
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import generate_tokens
    from blib2to3.pgen2.tokenize import TokenInfo
    from . import untokenize
    ut = untokenize
    pyr = (
        "def func():\n"
        "    x = 1\n"
        "    # comment\n"
        "\n"
        "def func2():\n"
        "    x = 2\n"
    )
    items: List[TokenInfo] = list(generate_tokens(StringIO(pyr).readline))
    out = ut.Untokenizer().compat(items[0], iter(items[1:]))
    assert out == pyr, repr(out)



# Generated at 2022-06-21 10:30:01.683549
# Unit test for function group
def test_group():
    if not group(*"abcd") == "([abcd])": raise AssertionError
    if not group(*["a", group("b", group("c", "d"))]) == "([a]([b]([cd])))": raise AssertionError

# Generated at 2022-06-21 10:30:10.984746
# Unit test for function printtoken
def test_printtoken():
    for args in (
        (NUMBER, "3", (1, 1), (1, 2), ""),
        (NAME, "foo", (1, 1), (1, 4), ""),
        (STRING, "", (1, 1), (1, 0), ""),
        (STRING, '"""', (1, 1), (1, 3), ""),
        (OP, "<=", (1, 1), (1, 3), ""),
    ):
        printtoken(*args)


ENCODING = "utf-8"

# Helper for grouping

# Generated at 2022-06-21 10:30:14.324901
# Unit test for function tokenize
def test_tokenize():
    lines = ["if 1:", "  pass", ""]
    next_line = iter(lines).__next__
    tokeneater = printtoken
    tokenize(next_line, tokeneater)
