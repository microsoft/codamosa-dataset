

# Generated at 2022-06-21 10:22:02.901025
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("test error")
    except TokenError as err:
        assert str(err) == "test error"



# Generated at 2022-06-21 10:22:06.684351
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", (maybe("a"), "(a)?")
    assert maybe("a", "b") == "(a|b)?", (maybe("a", "b"), "(a|b)?")



# Generated at 2022-06-21 10:22:11.174179
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from .tokenize_rt import source_tokenizer

    def check(source):
        tokens = list(source_tokenizer(source))
        untokenizer = Untokenizer()
        result = untokenizer.untokenize(tokens)
        assert result == source
        tokens = list(source_tokenizer(result))
        result2 = untokenizer.untokenize(tokens)
        assert result == result2
        tokens = list(source_tokenizer(result2))
        result3 = untokenizer.untokenize(tokens)
        assert result == result3

    # test validating data
    check("#abc\n'''abc'''\n")
    check('#abc\n"""abc"""\n')
    check("#abc\n#def\n")

# Generated at 2022-06-21 10:22:15.102786
# Unit test for function untokenize
def test_untokenize():
    def compare(input, result):
        input = iter(input.splitlines(keepends=True))
        tokens = generate_tokens(input.__next__)
        output = untokenize(tokens)
        result = result.splitlines(keepends=True)
        diff = False
        for got, expected in zip_longest(output.splitlines(keepends=True), result):
            if got != expected:
                print("Untokenizing")
                print("expected:", repr(expected))
                print("     got:", repr(got))
                diff = True
        assert not diff, "Untokenized source differs"


# Generated at 2022-06-21 10:22:16.740801
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:22:25.788518
# Unit test for function group
def test_group():
    assert ("[ab]", "[ab]") == (group("[ab]"), "[ab]")
    assert ("a", "a") == (group("a"), "a")
    assert ("ab", "ab") == (group("ab"), "ab")
    assert ("a|b", "a|b") == (group("a", "b"), "a|b")
    assert ("a|bc", "a|bc") == (group("a", "bc"), "a|bc")
    assert ("(?:ab)|c", "ab|c") == (group("ab", "c"), "ab|c")
    assert ("(?:ab)|(?:c)", "ab|c") == (group("ab", "c", nongroup=False), "ab|c")



# Generated at 2022-06-21 10:22:35.582489
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    for i in [
        (NAME, "def"),
        (NAME, "f"),
        (OP, "("),
        (NAME, "x"),
        (OP, ")"),
        (OP, ":"),
        (NEWLINE, "\n"),
        (INDENT, "\t"),
        (NAME, "return"),
        (NAME, "x"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (ENDMARKER, ""),
    ]:
        u.compat(i, [])
    return "".join(u.tokens)



# Generated at 2022-06-21 10:22:45.525105
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    src = [
        (NAME, "foo", (1, 0), (1, 3), "foo"),
        (NUMBER, "2", (1, 4), (1, 5), "2"),
        (NEWLINE, "\n", (1, 5), (1, 6), "\n"),
        (NAME, "bar", (2, 0), (2, 3), "bar"),
        (OP, "+", (2, 3), (2, 4), "+"),
        (NAME, "baz", (2, 5), (2, 8), "baz"),
    ]
    expected = "foo 2\nbar + baz "
    assert untok.untokenize(src) == expected



# Generated at 2022-06-21 10:22:55.021129
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()
    untokenizer.prev_row = 1
    untokenizer.prev_col = 1
    untokenizer.add_whitespace((1,2))
    assert untokenizer.tokens == [' ']
    untokenizer.prev_col = 3
    untokenizer.add_whitespace((1,2))
    assert untokenizer.tokens == [' ',' ']
    untokenizer.add_whitespace((2,3))
    assert untokenizer.tokens == [' ',' ']



# Generated at 2022-06-21 10:23:03.850533
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    toksource = [
        ("keyword", "while"),
        ("op", "<op>"),
        ("whitespace", " "),
        ("name", "i"),
        ("op", "="),
        ("name", "n"),
        ("newline", "\n"),
        ("indent", " " * 4),
        ("name", "print"),
        ("op", "<op>"),
        ("whitespace", " "),
        ("string", "'x'"),
        ("newline", "\n"),
        ("dedent", ""),
        ("dedent", ""),
        ("newline", "\n"),
        ("endmarker", ""),
    ]
    toksource = [list(x) for x in toksource]

# Generated at 2022-06-21 10:24:06.515244
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "\"\"\"", (0,0), (0,0), "")



# Generated at 2022-06-21 10:24:08.060638
# Unit test for function untokenize
def test_untokenize():
    inbytes = b'foo = "\\n"\n'
    outbytes = untokenize(tokenize(io.BytesIO(inbytes).readline))
    assert inbytes == outbytes, "Output not round-trip invariant"



# Generated at 2022-06-21 10:24:17.348329
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    assert u.tokens == [" "]
    u.add_whitespace((1, 3))
    assert u.tokens == [" ", "  "]
    u.add_whitespace((2, 0))
    assert u.tokens == [" ", "  ", "\n"]
    u.add_whitespace((2, 1))
    assert u.tokens == [" ", "  ", "\n", " "]
    u.add_whitespace((2, 3))

# Generated at 2022-06-21 10:24:23.186558
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():

    from . import tokenize

    def tokeneater(*tokens):
        for t in tokens:
            print(t)
        print()


# Generated at 2022-06-21 10:24:29.040204
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    ut = Untokenizer()
    ut.compat((token.NAME, "spam"), [(token.NAME, "ham"), (token.NUMBER, "1"), (token.STRING, '"s"')])
    expected = "spam ham 1 \"s\""
    actual = "".join(ut.tokens)
    assert actual == expected, f"{actual!r} != {expected!r}"

# Generated at 2022-06-21 10:24:34.714801
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import tokenize

    f = io.StringIO("if 1:\n  x = 2\n")
    tokens = tokenize.generate_tokens(f.readline)
    u = Untokenizer()
    s = u.untokenize(tokens)
    assert s == "if 1:\n  x = 2\n"



# Generated at 2022-06-21 10:24:46.968141
# Unit test for function maybe
def test_maybe():
    assert maybe(*("("+re.escape("an")+")")+"*") == re.escape("an")+"*"


Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + maybe(Comment)

Name = r'[a-zA-Z_]\w*'

Hexnumber = r"0[xX][\da-fA-F]+[lL]?"
Octnumber = r"0[oO][0-7]+[lL]?"
Binnumber = r"0[bB][01]+[lL]?"
Decnumber = r"([1-9]\d*|0)([eE][+-]?\d+)?[lL]?"

# Generated at 2022-06-21 10:24:50.152684
# Unit test for function any
def test_any():
    # print(any("a", "b", "c", "d"))
    assert any("a", "b", "c", "d") == '(a|b|c|d)*'


# Generated at 2022-06-21 10:25:02.348815
# Unit test for function generate_tokens
def test_generate_tokens():
    # Copy-paste from library_tokenize:
    import pprint, io
    from token import *
    from tokenize import tokenize

    # Read from a text file, format it, and return the reformatted text.
    def reformat(file, tabsize=8, outfile=sys.stdout):
        result = []
        generator = tokenize(file.readline)
        for toknum, tokval, _, _, _ in generator:
            if toknum == NUMBER and "." in tokval:  # replace NUMBER tokens
                result.extend([
                    (NAME, "Decimal"),
                    (OP, "("),
                    (STRING, repr(tokval)),
                    (OP, ")"),
                ])

# Generated at 2022-06-21 10:25:04.244521
# Unit test for function any
def test_any():
    assert any("b", "cd") == "(b|cd)*"
    assert any("", "cd") == "(|cd)*"



# Generated at 2022-06-21 10:25:40.545517
# Unit test for function tokenize
def test_tokenize():
    def getline(s):
        if s:
            return s
        raise StopTokenizing
    lines = [
        ("1 + 1\n", '1', '+', '1'),
        (
            'print(1, end=" ")\n',
            "print",
            "(",
            "1",
            ",",
            "end",
            '=',
            '" "',
            ")",
        ),
    ]
    for input_, *output in lines:
        expected = list(zip([NUMBER] * len(output), output))

        tokens = []

        tokenize(getline(input_).__next__, tokens.append)

        assert tokens[:-1] == expected



# Generated at 2022-06-21 10:25:43.032660
# Unit test for function group
def test_group():
    assert group('a', 'b', 'c') == '(a|b|c)'



# Generated at 2022-06-21 10:25:53.338101
# Unit test for function untokenize
def test_untokenize():
    input = [
        (1, "def"),
        (1, " "),
        (1, "f"),
        (1, "("),
        (1, "a"),
        (1, ","),
        (1, " "),
        (1, "b"),
        (1, ")"),
        (3, "\n"),
        (1, " "),
        (1, "c"),
        (1, "+"),
        (1, " "),
        (1, "d"),
    ]

    result = untokenize(input)
    assert result == "def f(a, b):\n c+d"
# /Unit test for function untokenize


# Generated at 2022-06-21 10:26:05.404299
# Unit test for function any
def test_any():
    for s in ["", "1", "12", "123"]:
        assert re.match(any("1", "2", "3"), s)


_Printable = "".join(
    [chr(i) for i in range(32, 127)]
    + ["\n", "\r", "\t", " "]
)
del i

# Regular expression patterns used for tokenizing
# This regexp matches a non-empty token unless it is a comment:
_token_regexp = "[{0}]+|[^\s{0}]+".format(_Printable)

# This regexp is used to split a line into tokens:
_all_regexp = re.compile(_token_regexp)

# Sequence used to detect the encoding of a source file with only a BOM

# Generated at 2022-06-21 10:26:16.636936
# Unit test for function tokenize_loop
def test_tokenize_loop():
    # Careful: the tokenize_loop() function has a call to printtoken()
    # that prints to sys.stderr, which isn't available when we're started
    # with -m. Catch the output so that test runs pass.
    import io
    import sys
    import unittest
    from test import support

    @tokenize_loop
    def tokenize_loop_printer(toknum, tokval, start, end, line):
        print(start, end, toknum, tokval)

    class TestTokenizeLoop(unittest.TestCase):
        def test_tokenize_loop(self):
            s = io.StringIO()
            save = sys.stdout
            sys.stdout = s
            try:
                tokenize_loop_printer('import sys')
            finally:
                sys

# Generated at 2022-06-21 10:26:22.460934
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    tok = [(0, "hello"), (1, " "), (0, "my"), (1, " "), (0, "name"), (1, " "), (0, "is"), (1, " "), (0, "fred"), (2, "\n"), (3, "\t"), (0, "hi"), (2, "\n"), (1, " "), (0, "there"), (1, " "), (0, "fred"), (2, "\n"), (3, "   "), (4, "\n")]
    assert u.untokenize(tok) == "hello my name is fred\n\thi\n there fred\n   \n"



# Generated at 2022-06-21 10:26:26.118845
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError('a')
    except TokenError:
        pass
    else:
        assert False, "TokenError did not raise"



# Generated at 2022-06-21 10:26:37.200593
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    untok.tokens = []
    untok.add_whitespace((1, 0))
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" ", ""]
    untok.add_whitespace((1, 0))
    untok.add_whitespace((2, 0))
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", "", "", " "]
    try:
        untok.add_whitespace((0, 1))
    except AssertionError:
        pass
    else:
        raise Exception("Should have raised an AssertionError")



# Generated at 2022-06-21 10:26:42.258540
# Unit test for function printtoken
def test_printtoken():
    try:
        printtoken(DEDENT, 'dedent', (0, 0), (0, 1), None)
    except:
        print("Failed")

test_printtoken()

# These are used for untokenizing when comparing tokens to their
# input.  (The last two are not used but defined here for symmetry.)


# Generated at 2022-06-21 10:26:44.016644
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:27:38.143329
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens, untokenize
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.readline = StringIO("print('bla')").readline

        def test_roundtrip(self):
            tokengen = generate_tokens(self.readline)
            tokens = list(tokengen)
            result = untokenize(tokens)
            self.readline = StringIO(result).readline
            tokengen = generate_tokens(self.readline)
            tokens2 = list(tokengen)
            self.assertEqual(tokens, tokens2)

    unittest.main()

# Generated at 2022-06-21 10:27:41.531128
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    s = u.untokenize([(NAME, "foo"), (NUMBER, "5"), (NAME, "bar")])
    assert s == "foo 5 bar "


# Generated at 2022-06-21 10:27:50.693090
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import BytesIO
    from tokenize import generate_tokens, tokenize, untokenize

    lines = [
        b"def f(x):",
        b"    return x + 2",
        b"print(f(3))",
        b"",
        b"# This is a comment",
        b"def g():",
        b"    return 2",
        b"",
        b"def h(x):",
        b"    return x",
        b"",
        b"def i(x):",
        b"    return x",
        b"print(f(1))",
    ]

    for encoding in ("utf-8", "ascii"):
        f = BytesIO()
        for line in lines:
            f.write(line + b"\n")
        f

# Generated at 2022-06-21 10:27:55.262312
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import unittest

    class DetectEncodingTest(unittest.TestCase):

        def test_only_bom(self):
            r = io.BytesIO(BOM_UTF8)
            self.assertEqual(detect_encoding(r.readline), ("utf-8-sig", []))

        def test_only_bom_with_extra_data(self):
            bytes = BOM_UTF8 + b"blah blah blah\nblah blah"
            r = io.BytesIO(bytes)
            self.assertEqual(detect_encoding(r.readline), ("utf-8-sig", [bytes[3:]]))


# Generated at 2022-06-21 10:28:07.894646
# Unit test for function untokenize
def test_untokenize():
    import io, token, tokenize

    with io.StringIO() as f:
        f.write("def f(a, (b, c), d):\n    pass\n")
        f.seek(0)
        g = tokenize.generate_tokens(f.readline)
        assert untokenize(g) == f.read()

    with io.StringIO() as f:
        f.write("def f(a, (b, c), d):\n    pass\n")
        f.seek(0)
        g = tokenize.generate_tokens(f.readline)
        tok = next(g)
        assert tok[0] == token.INDENT
        assert untokenize([list(tok), next(g), next(g), next(g), next(g)])

# Generated at 2022-06-21 10:28:19.971808
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    import tokenize
    from . import untokenize
    from .tokenize import DetectionError, UntokenizeError
    untokenizer = untokenize.Untokenizer()

# Generated at 2022-06-21 10:28:26.559611
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_row = 8
    ut.prev_col = 2
    ut.add_whitespace((8, 5))
    assert ut.tokens == ["   "]
    ut.add_whitespace((9, 2))
    assert ut.tokens == ["   ", "\n"]
    ut.add_whitespace((9, 5))
    assert ut.tokens == ["   ", "\n", "   "]


# Generated at 2022-06-21 10:28:36.091751
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    t = [
        (tokenize.NUMBER, "1"),
        (tokenize.NAME, "abc"),
        (tokenize.NEWLINE, "\n"),
        (tokenize.INDENT, ""),
        (tokenize.NUMBER, "2"),
        (tokenize.NAME, "def"),
        (tokenize.DEDENT, ""),
        (tokenize.NUMBER, "3"),
        (tokenize.NAME, "ghi"),
        (tokenize.ENDMARKER, ""),
    ]
    s = "1 abc\n  2 def\n3 ghi"
    assert u.untokenize(t) == s



# Generated at 2022-06-21 10:28:43.007733
# Unit test for function tokenize_loop
def test_tokenize_loop():
    """Test the tokenize_loop() function."""
    # This does not test indentation-sensitive tokenizing
    from io import BytesIO

    def readline():
        if not lines:
            return ""
        line = lines.pop(0)
        if isinstance(line, bytes):
            line += b"\n"
        else:
            line += "\n"
        buf.write(line)
        return line

    def check(input, *output):
        global lines
        global buf

        if isinstance(input, str):
            input = input.encode("utf-8")
        buf = BytesIO()
        lines = input.split(b"\n")
        tokvals = []
        tokenize_loop(readline, tokvals.append)

# Generated at 2022-06-21 10:28:48.309637
# Unit test for function untokenize

# Generated at 2022-06-21 10:29:22.747787
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from cStringIO import StringIO

    from . import tokenize, _tokenize

    def roundtrip(s):
        return Untokenizer().untokenize(tokenize.generate_tokens(StringIO(s).readline))

    def roundtrip_unquoted(s):
        return Untokenizer().untokenize(
            _tokenize.Untokenizer(StringIO(s).readline).generate_tokens()
        )

    assert roundtrip("foo = 'bar'") == "foo = 'bar'\n"
    assert roundtrip("def f(x=1, *y, **z): pass") == "def f(x=1, *y, **z): pass\n"

# Generated at 2022-06-21 10:29:24.658446
# Unit test for function group
def test_group():
    assert group("a", "b", "c", "d") == "(a|b|c|d)"



# Generated at 2022-06-21 10:29:26.970212
# Unit test for function tokenize_loop
def test_tokenize_loop():
    tokenize_loop(lambda: "", printtoken)
    tokenize_loop(lambda: "", lambda *a: None)



# Generated at 2022-06-21 10:29:29.439780
# Unit test for function group
def test_group():
    assert group("abc", "def", "") == "((abc)|(def)|())", repr(group("abc", "def", ""))



# Generated at 2022-06-21 10:29:33.822693
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"

Combinator = Union[str, Pattern]
# A Combinator is either a string or a compiled regular expression object



# Generated at 2022-06-21 10:29:38.389685
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    import io
    import sys
    if sys.version_info < (2, 6):
        # Source code is taken from Python 2.7 and it uses format strings.
        return
    r = io.BytesIO(
        b"""def f():
    return
    """
    ).readline
    tokens = [(tok[0], tok[1]) for tok in tokenize.generate_tokens(r)]

# Generated at 2022-06-21 10:29:39.742026
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"



# Generated at 2022-06-21 10:29:44.778483
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    input = [('NAME', 'token'),
             ('NAME', 'token'),
             ('INDENT', ''),
             ('INDENT', ''),
             ('NAME', 'token'),
             ('NEWLINE', ''),
             ('NEWLINE', ''),
             ('DEDENT', ''),
             ('NAME', 'token'),
             ('DEDENT', '')]
    output = untokenize(input)
    assert output == 'token token\n  token\n\n  token\n'



# Generated at 2022-06-21 10:29:49.078202
# Unit test for function untokenize
def test_untokenize():
    tests = [("1234", "1234"),
             ("1234\n", "1234\n"),
             ("1234\n5678", "1234\n5678"),
             ("1234\n5678\n", "1234\n5678\n"),
             ("1234 \n5678", "1234 \n5678"),
             ("1234\n 5678", "1234\n 5678"),
             ("1234\n  5678", "1234\n  5678"),
             ("1234  \n  5678", "1234  \n  5678"),
             ("\n  1234  \n  5678", "\n  1234  \n  5678"),
             ("   1234  ", "   1234  ")]
    for test in tests:
        readline = iter

# Generated at 2022-06-21 10:29:59.357632
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    l = [
        (NAME, "a"),
        (NEWLINE, "\n"),
        (NUMBER, "1"),
        (STRING, '"a"'),
        (NEWLINE, "\n"),
        (INDENT, "  "),
        (NAME, "b"),
        (NEWLINE, "\n"),
        (NUMBER, "2"),
        (DEDENT, ""),
        (NUMBER, "3"),
        (NEWLINE, "\n"),
    ]
    assert u.untokenize(l) == "a 1 'a'\n  b\n2 3\n"

