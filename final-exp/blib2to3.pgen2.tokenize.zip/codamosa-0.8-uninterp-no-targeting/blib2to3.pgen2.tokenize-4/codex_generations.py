

# Generated at 2022-06-21 10:22:39.342829
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from test.test_tokenize import tokenize_loop, untokenize  # type: ignore
    import io
    infile = io.StringIO(
        "'''Python tokenizer test'''\n"
        's = "string"\n'
        "u = u'One line unicode string'\n"
        "'a single line string'\n"
        '"another single line string"\n'
        "'''\n"
        "Another string\n"
        "spanning multiple lines\n"
        "'''\n"
        'r"yet another single line string"\n'
        "ur'unicode string'\n"
        "rf'''raw string'''\n"
    )


# Generated at 2022-06-21 10:22:48.404593
# Unit test for function generate_tokens
def test_generate_tokens():
    import tokenize
    from io import BytesIO
    class F:
        def __init__(self, s):
            self.s = s
            self.i = 0

        def readline(self):
            if self.i >= len(self.s):
                raise StopIteration
            j = self.s.find("\n", self.i)
            if j < 0:
                j = len(self.s)
            line = self.s[self.i:j]
            self.i = j + 1
            return line + "\n"

    f = F('def foo(x):\n   return 2*x\n')
    for token in tokenize.generate_tokens(f.readline):
        print(token)

    # parser heavily depends on the sequence of tokens.
    # to test generator

# Generated at 2022-06-21 10:22:58.187886
# Unit test for function untokenize
def test_untokenize():
    s = 'def f(x, y): return "x=%s, y=%s" % (x, y)'

# Generated at 2022-06-21 10:23:07.826654
# Unit test for function untokenize
def test_untokenize():
    # Simple test for function "untokenize"

    # Test 1
    source = "def x():\n    return 1"
    readline = iter(source.splitlines(1)).__next__
    tokens = generate_tokens(readline)
    newcode = untokenize(tokens)
    readline = iter(newcode.splitlines(1)).__next__
    tokens = generate_tokens(readline)
    assert untokenize(tokens) == newcode

    # Test 2
    source = "def x():\n  return 2"
    readline = iter(source.splitlines(1)).__next__
    tokens = generate_tokens(readline)
    newcode = untokenize(tokens)
    readline = iter(newcode.splitlines(1)).__next__


# Generated at 2022-06-21 10:23:09.940986
# Unit test for function group
def test_group():
    assert group('abc', 'def') == '(abc|def)'
    assert group(['abc', 'def']) == '(abc|def)'


# Generated at 2022-06-21 10:23:12.220436
# Unit test for function tokenize
def test_tokenize():
    with open(__file__) as f:
        source = f.read()
    result = []
    tokenize(iter(source.splitlines(True)).__next__, result.append)
    return result



# Generated at 2022-06-21 10:23:14.106427
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("test")
    except TokenError as te:
        if str(te) != "test":
            raise AssertionError



# Generated at 2022-06-21 10:23:22.696804
# Unit test for function printtoken
def test_printtoken():
    def get_printtoken_values(inp):
        for type, token, (srow, scol), (erow, ecol), line in generate_tokens(inp):
            yield (srow, scol, erow, ecol, tok_name[type], repr(token))
    
    expected = (1, 0, 1, 1, 'NAME', "'\\n\\n'")
    assert next(get_printtoken_values(b"\n\n")) == expected
    
test_printtoken()



# Generated at 2022-06-21 10:23:24.938935
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("%s", "bad token")
    except TokenError as err:
        assert err.args == ("%s", "bad token")



# Generated at 2022-06-21 10:23:30.335561
# Unit test for function tokenize
def test_tokenize():
    data = "3.14+4j"
    def readline():
        return data
    for type, token, a, b, line in generate_tokens(readline):
        tokeneater(type, token, (a, b), (0, 0), line)


# Generated at 2022-06-21 10:23:55.297493
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    g = generate_tokens(lambda: next(tokenize_lines(
        b"foo = 42 + 42 +\n"
        b"      42 + 42\n"
        b"print(foo)\n"
    )))
    s = io.StringIO()
    tokenize_loop(g.send, s.write)

# Generated at 2022-06-21 10:24:07.738211
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    import copy
    import io
    import unittest

    class Example(unittest.TestCase):
        def runTest(self):
            u = Untokenizer()
            self.assertEqual(u.tokens, [])
            self.assertEqual(u.prev_row, 1)
            self.assertEqual(u.prev_col, 0)
            u.add_whitespace(start=(1, 1))
            self.assertEqual(u.tokens, [" "])
            self.assertEqual(u.prev_row, 1)
            self.assertEqual(u.prev_col, 1)
            u.add_whitespace(start=(2, 2))
            self.assertEqual(u.tokens, [" ", "\n", "  "])
            self.assertE

# Generated at 2022-06-21 10:24:09.162116
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("a", "b") == "(a|b)*"
    assert any("a(?:b|c)*d") == "(a(?:b|c)*d)*"



# Generated at 2022-06-21 10:24:17.622472
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.add_whitespace((1, 0))
    u.tokens.append("name")
    u.prev_col = 4
    u.prev_row = 1
    u.add_whitespace((2, 3))
    u.tokens.append("num234")
    u.prev_col = 8
    u.prev_row = 2
    u.add_whitespace((3, 0))
    u.tokens.append("def")
    u.prev_col = 3
    u.prev_row = 3
    assert "".join(u.tokens) == "name\n\tnum234\ndef"

indent_level = 0


# Generated at 2022-06-21 10:24:21.897309
# Unit test for function detect_encoding

# Generated at 2022-06-21 10:24:28.285570
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from io import BytesIO
    r = BytesIO(b"print(1)\n")
    g = tokenize.tokenize(r.readline)
    tok = next(g)
    assert tok == tokenize.TokenInfo(
        type=token.NAME, string="print", start=(1, 0), end=(1, 5), line="print(1)\n"
    )



# Generated at 2022-06-21 10:24:29.891373
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()
    result = untok.untokenize([(1, "abc"), (0, " "), (1, "def")])
    assert result == "abc def", repr(result)



# Generated at 2022-06-21 10:24:39.355118
# Unit test for function tokenize
def test_tokenize():
    from io import BytesIO
    from .tokenize_tests import testcases

    for inputstring, tokens in testcases:
        type_patterns = {
            NUMBER: "NUMBER",
            NAME: "NAME",
            STRING: "STRING",
            ERRORTOKEN: "ERRORTOKEN",
            ENDMARKER: "ENDMARKER",
        }
        types = {
            tok_name[token[0]]: type_patterns.get(token[0], token[0])
            for token in tokens
        }
        sio = BytesIO(inputstring.encode("utf-8"))
        result = list(tokenize(sio.readline))
        result_types = {tok_name[token[0]]: token[1] for token in result}

# Generated at 2022-06-21 10:24:51.463797
# Unit test for function generate_tokens
def test_generate_tokens():  # TODO: Rename to test_tokenize
    def _test(text):
        type_tag = "TYPE"

        parsed = [
            (type_tag, token)
            for token in tokenize(iter(text.splitlines(True)).__next__)
            if token.type != ENDMARKER
        ]
        unparsed = untokenize(parsed)

        parsed_lines = [tok for tok in parsed if tok[1].type == NEWLINE]
        unparsed_lines = unparsed.count("\n")
        assert (
            unparsed_lines
        ) == len(parsed_lines), "parsed {} lines, unparsed {} lines".format(
            len(parsed_lines), unparsed_lines
        )

        yield parsed

        assert text == unp

# Generated at 2022-06-21 10:24:57.690786
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    text = ["if", " ", "a", " ", "==", " ", "b", ":", "\n", " ", " ", "c", " "]
    ut = Untokenizer()
    assert ut.untokenize(map(lambda x: (NAME, x), text)) == "if a == b:\n   c "


# Generated at 2022-06-21 10:25:27.122157
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    exc = StopTokenizing()
    assert isinstance(exc, Exception)


# We use a custom class to track token positions
#  so we can substitute "None" in for positions when
#  we want to indicate that a token was inserted.

# Generated at 2022-06-21 10:25:30.978131
# Unit test for function maybe
def test_maybe():
    assert maybe(r'[a-z]', r'[A-Z]') == r'([a-z]|[A-Z])?'
    return True



# Generated at 2022-06-21 10:25:36.397837
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
        l = [" ", "", "\n", "\n\n", " \n \n", "a", "\n\n\nb", "c", "\n", "\n\n"]
        u = Untokenizer()
        s = u.untokenize(map(tokenize(iter(l).__next__).__next__, l))
        assert s == "a\n\n\nb\nc\n\n\n"


# Generated at 2022-06-21 10:25:43.026489
# Unit test for function untokenize
def test_untokenize():
    # Test round-trip invariant for limited input
    def roundtrip(s):
        tokens = tokenize(BytesIO(s.encode("utf-8")).readline)
        newcode = untokenize(tokens)
        readline = iter(newcode.splitlines(1)).__next__
        tokens = list(tokenize(readline))
        return tokens

    def compare(s):
        t1 = tokenize(BytesIO(s.encode("utf-8")).readline)
        t2 = roundtrip(s)
        t1 = [(num if num != ERRORTOKEN else STRING, val)
             for (num, val) in t1]
        t2 = [(num if num != ERRORTOKEN else STRING, val)
             for (num, val) in t2]

# Generated at 2022-06-21 10:25:50.993234
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    r = io.StringIO("def f():\n  pass\n")
    tokenize(r.readline)
    assert token.tok_name[1] == "NAME"
    assert token.__all__ == [
        "COMMENT",
        "ENCODING",
        "ENDMARKER",
        "ERRORTOKEN",
        "INDENT",
        "NEWLINE",
        "NT_OFFSET",
        "NUMBER",
        "OP",
        "STRING",
        "tok_name",
        "tok_str",
        "tokenize",
        "untokenize",
    ]



# Generated at 2022-06-21 10:26:03.537732
# Unit test for function generate_tokens
def test_generate_tokens():
    """Unit test for function generate_tokens"""
    data = """#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""

    def readline():
        """helper function for testing function generate_tokens"""
        nonlocal data
        if not data:
            raise StopIteration
        result, data = data[:1], data[1:]
        return result

    results = list(generate_tokens(readline))

# Generated at 2022-06-21 10:26:07.604370
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()
    untokenizer.add_whitespace((2, 0))
    untokenizer.add_whitespace((1, 1))
    assert untokenizer.tokens == [' ', '\n']



# Generated at 2022-06-21 10:26:11.693976
# Unit test for function printtoken
def test_printtoken():
    input = "This is a string"
    printtoken(token.NAME, "This", (0,0), (0,3), input)
    printtoken(token.NAME, "is", (0,4), (0,5), input)



# Generated at 2022-06-21 10:26:13.344745
# Unit test for function any
def test_any():
    assert any("abc") == group("abc") + "*"



# Generated at 2022-06-21 10:26:20.586144
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.tokens = []
    u.add_whitespace((1,2))
    assert u.tokens == [" "]
    u.add_whitespace((1,4))
    assert u.tokens == [" ", "  "]
    u.add_whitespace((2,0))
    assert u.tokens == [" ", "  ", "\n", " "]
    u.add_whitespace((2,2))
    assert u.tokens == [" ", "  ", "\n", " ", "  "]
test_Untokenizer_add_whitespace()



# Generated at 2022-06-21 10:28:51.954768
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat(): # noqa
    import io
    from .tokenize import (
        tokenize,
        NUMBER,
        ASYNC,
        AWAIT,
        NAME,
        NEWLINE,
        NL,
        INDENT,
        DEDENT,
    )
    data = io.BytesIO(b"x = 1\nwhile (a==b):\n    b=c\n    c=d\n")
    result = []
    for (toknum, tokval, _, _, _) in tokenize(data.readline):
        result.append((toknum, tokval))

# Generated at 2022-06-21 10:28:53.411944
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError as e:
        pass



# Generated at 2022-06-21 10:28:54.015571
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    pass



# Generated at 2022-06-21 10:29:03.871711
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    input = [(tokenize.NUMBER, '42'), (tokenize.NAME, 'spam'), (0, 'eol')]
    assert u.untokenize(input) == '42spam eol'
    input = [(2, '42'), (1, 'spam'), (0, 'eol')]
    assert u.compat(input[0], input[1:]) is None

# These are used for pretty-printing and should match _tokenize.py
RPAREN = ")"
LPAREN = "("
LSQB = "["
RSQB = "]"
COLON = ":"
COMMA = ","
SEMI = ";"
PLUS = "+"
MINUS = "-"
STAR = "*"
SLASH = "/"
VBAR = "|"
AM

# Generated at 2022-06-21 10:29:15.582029
# Unit test for function tokenize

# Generated at 2022-06-21 10:29:21.503463
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # Verify that the constructor takes zero arguments.
    try:
        StopTokenizing(42)
    except TypeError:
        pass
    else:
        raise AssertionError("expected TypeError: StopTokenizing(42)")


# The following import is *not* redundant and is *not* equivalent to
# ``from . import grammar``. The latter would not make ``grammar`` a
# submodule of ``tokenize``, so the former is required.
from . import grammar  # NOQA

_ISNONTERMINAL = re.compile("[A-Z]").match
_ISIDENT = re.compile("[a-z_]").match



# Generated at 2022-06-21 10:29:25.402512
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    try:
        raise TokenError("foo")
    except TokenError as e:
        if str(e) != "foo":
            raise ValueError



# Generated at 2022-06-21 10:29:28.179206
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
    assert any("ab", "cd") == "(ab|cd)*"
    assert any("abc", "def") == "(abc|def)*"



# Generated at 2022-06-21 10:29:34.537881
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline() -> bytes:
        yield BOM_UTF8
        yield "# -*- coding: latin-1 -*-\n"  # coding in comment
        yield "blah"  # first line in content

    encoding = detect_encoding(readline)
    assert encoding[0] == "utf-8-sig"



# Generated at 2022-06-21 10:29:42.477307
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    t = Untokenizer()
    inp = [
        (1, "x"),
        (3, "\n"),
        (2, " "),
        (1, "y"),
        (3, "\n"),
        (2, "    "),
        (1, "z"),
        (3, "\n"),
    ]
    out = t.untokenize(inp)
    assert out == "x\ny\n    z\n", repr(out)


# General function to format tokens into indented and formatted strings

# Generated at 2022-06-21 10:30:40.873053
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token

# Generated at 2022-06-21 10:30:50.928491
# Unit test for function any
def test_any():
    a_eq_b = any("a", "b")
    assert re.match(a_eq_b, "a")
    assert re.match(a_eq_b, "b")
    assert re.match(a_eq_b, "ab")
    assert re.match(a_eq_b, "ba")
    assert re.match(a_eq_b, "aa")
    assert re.match(a_eq_b, "bb")
    assert re.match(a_eq_b, "abba")
    assert re.match(a_eq_b, "baba")
    assert not re.match(a_eq_b, "c")  # No match

