

# Generated at 2022-06-21 10:22:25.233832
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    try:
        raise TokenError("some error")
    except TokenError:
        pass



# Generated at 2022-06-21 10:22:37.374377
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import sys
    import unittest

    class MockTokenEater:
        def __init__(self):
            self.tokens: List[Tuple[int, Text, Coord, Coord, Text]] = []

        def __call__(self, type, token, xxx_todo_changeme, xxx_todo_changeme1, line):  # noqa: E501
            (srow, scol) = xxx_todo_changeme
            (erow, ecol) = xxx_todo_changeme1
            self.tokens.append((type, token, srow, scol, erow, ecol, line))

    class TestTokenizeLoop(unittest.TestCase):
        def setUp(self):
            self.mockTokenEater = Mock

# Generated at 2022-06-21 10:22:41.824716
# Unit test for function detect_encoding
def test_detect_encoding():
    # When the first two characters are a UTF-8 BOM, the BOM should be
    # ignored, and the encoding detected as 'utf-8'.
    bom = codecs.BOM_UTF8
    eq = assert_equal
    eq(detect_encoding(iter([b'# -*- coding: utf-8 -*-'])), ('utf-8', [b'# -*- coding: utf-8 -*-']))
    eq(detect_encoding(iter([b'#!/usr/bin/env python3'])), ('utf-8', [b'#!/usr/bin/env python3']))

# Generated at 2022-06-21 10:22:43.593613
# Unit test for function printtoken
def test_printtoken():
    printtoken(5, "name", (1,2), (3,4), "asf")



# Generated at 2022-06-21 10:22:45.605967
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("invalid token")
    except TokenError as e:
        assert str(e) == "invalid token"



# Generated at 2022-06-21 10:22:46.738952
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-21 10:22:55.546027
# Unit test for function tokenize
def test_tokenize():
    def tokeneater(type, token, srow_scol, erow_ecol, line):
        print("%d,%d-%d,%d:\t%s\t%s" % (srow_scol[0], srow_scol[1], erow_ecol[0], erow_ecol[1], tok_name[type], repr(token)))
    tokenize(open("tokenize_tests").readline, tokeneater)



# Generated at 2022-06-21 10:23:02.260407
# Unit test for function generate_tokens
def test_generate_tokens():
    def tokenize_print(readline):
        import token
        tokgen = generate_tokens(readline)
        for toktype, toktext, (srow, scol), (erow, ecol), tokline in tokgen:
            print("%10s %5s %-15r %r" % (
                token.tok_name.get(toktype, toktype),
                "%d.%d-%d.%d" % (srow, scol, erow, ecol),
                toktext,
                tokline[scol:ecol]
            ))

    def make_readline(s):
        def readline():
            return s
        return readline


# Generated at 2022-06-21 10:23:11.302044
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    def tv(s):
        return ("test", s)

    # no previous whitespace
    u.add_whitespace(tv("\n"))  # blank line
    assert u.tokens == ["\n"]
    u.add_whitespace(tv(" "))   # one space
    assert u.tokens == ["\n", " "]
    u.add_whitespace(tv("  "))  # multiple spaces
    assert u.tokens == ["\n", " ", "  "]
    u.add_whitespace(tv("\t"))  # tab
    assert u.tokens == ["\n", " ", "  ", "\t"]

    # reset; previous whitespace is one space
    u.tokens = []
    u.add_wh

# Generated at 2022-06-21 10:23:24.476646
# Unit test for function maybe
def test_maybe():
    s = "spam eggs"
    # Test cases from the documentation
    assert re.findall(maybe("aa"), "") == [""]
    assert re.findall(maybe("aa"), "aa") == ["aa"]
    assert re.findall(maybe("aa"), "aaaaa") == ["aa"]
    # This test is from Lib/test/test_re.py#TestMatchObjects
    assert re.findall(maybe(r"a(.)\1"), s) == [""]
    # This test is from Lib/test/test_re.py#TestEmptyMatch
    assert re.findall(r"(\b)?(?(1)yes|no)", "yes") == ["", "yes"]
    # This test is from Lib/test/test_re.py#TestRepeatMinMax

# Generated at 2022-06-21 10:24:06.898881
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-21 10:24:13.378928
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    a = [
        (1, 'NR1'), (1, 'NR2'), (4, '4'), (5, 'NL') , (0, 'DEDENT'), 
        (1, '1'), (1, 'NR3')
    ]
    t = u.compat(a[0], a[1:])
    assert u.tokens == ['NR1 NR2 ', '4', '\n', 'DEDENT', '1 NR3']


# Generated at 2022-06-21 10:24:18.133882
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO

    def readline(s=b"") -> bytes:
        while True:
            yield s

    def get_readline(s):
        def read():
            try:
                return s.pop(0)
            except IndexError:
                raise StopIteration

        return read

    # Tests begin
    ENC = "utf-16"
    L = []
    BOM = BOM_UTF8
    ENCODING = "# coding: " + ENC

    # Test #1
    # BOM + ENCODING + BLANKLINE
    # The BOM should be stripped off
    L = [BOM + ENCODING.encode("utf-16"), b""]

# Generated at 2022-06-21 10:24:22.003689
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    assert u.prev_row == 1
    assert u.prev_col == 0



# Generated at 2022-06-21 10:24:29.981008
# Unit test for function maybe
def test_maybe():
    # Test that maybe pattern is equal to re.compile(r'^(|)$')
    choices = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    assert maybe(*choices) == f"^({choices}|)$", "Patterns do not match!"

# Whitespace (n)+
_ws = "|".join(["[" + s + "]+" for s in r"\ \t\r\n\v\f"])

# Comments

# Generated at 2022-06-21 10:24:32.281833
# Unit test for function maybe
def test_maybe():
    assert maybe("foo") == "(foo)?", maybe("foo")
# End unit test



# Generated at 2022-06-21 10:24:40.603732
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untokenizer = Untokenizer()
    untokenizer.compat((tokenize.NUMBER, '42'), [(tokenize.NAME, 'spam'), (tokenize.NEWLINE, '\n')])
    untokenizer.compat((tokenize.NAME, 'spam'), [(tokenize.NAME, 'eggs'), (tokenize.NEWLINE, '\n')])
    untokenizer.compat((tokenize.NAME, 'eggs'), [(tokenize.INDENT, '    '), (tokenize.NAME, 'ham'), (tokenize.NEWLINE, '\n')])
    untokenizer.compat((tokenize.NAME, 'ham'), [(tokenize.NUMBER, '42'), (tokenize.DEDENT, ''), (tokenize.NEWLINE, '\n')])

# Generated at 2022-06-21 10:24:52.323878
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # Tests that the same value of prev_col and prev_row but with
    # a different value of col will add whitespace of the difference
    # between col and prev_col
    u = Untokenizer()
    u.add_whitespace((1, 2))
    assert u.tokens == ["  "]
    u.tokens = []
    u.add_whitespace((1, 3))
    assert u.tokens == ["   "]
    u.tokens = []
    # Tests that the same value of col and prev_col will add 0
    # whitespace
    u.add_whitespace((1, 1))
    assert u.tokens == []
    u.tokens = []
    # Tests that a newline resets prev_col to 0
    u.add_whites

# Generated at 2022-06-21 10:25:03.636378
# Unit test for function generate_tokens
def test_generate_tokens():
    import unittest
    import io

    class MockFile:
        def __init__(self, buffer: Iterator[str]):
            self._buffer = buffer

        def __iter__(self) -> Iterator[str]:
            return self._buffer

    def _get_line(line: str) -> str:
        if line.endswith("\n"):
            return line
        else:
            return line + "\n"

    def _get_expected_tokens(
        source: str, *, normalize_lines: bool = True
    ) -> List[TokenInfo]:
        result = [
            token for token in tokenize(io.StringIO(source).readline)
            if token[0] != NEWLINE
        ]
        if normalize_lines:
            for token in result:
                token.pop()

# Generated at 2022-06-21 10:25:11.650600
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize

    def get_readline() -> Callable[[], Text]:
        # Test with readline-based tokenizer.
        f = io.BytesIO(b'foo = "bar"\n')
        def readline() -> str:
            return f.readline().decode("utf-8")
        return readline

    readline = get_readline()
    tokenize.tokenize(readline)
    # Test with string-based tokenizer.
    readline = 'foo = "bar"\n'.splitline
    tokenize.tokenize(readline)
    # Test tokenize accepts bytes.
    f = io.BytesIO(b'foo = "bar"\n')
    def readline() -> str:
        return f.readline()
    tokenize.tokenize(readline)



# Generated at 2022-06-21 10:25:51.928743
# Unit test for function tokenize
def test_tokenize():
    import io

    # This test may fail if the tokenize function was created with tabs.
    readline = io.StringIO("1 + 1\n").readline

    # Test the default format
    result = list(tokenize(readline))

# Generated at 2022-06-21 10:26:04.343848
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untk = Untokenizer()

# Generated at 2022-06-21 10:26:13.011805
# Unit test for function tokenize
def test_tokenize():
    from io import StringIO
    from .tokenize import tokenize

    token_list = []

    def tokeneater(type, token, start, end, line):
        token_list.append((type, token))

    text = "'abc' # hello\n"
    tokenize(StringIO(text).readline, tokeneater)
    assert token_list == [
        (token.STRING, "'abc'"),
        (token.COMMENT, "# hello"),
        (token.NEWLINE, "\n"),
    ]



# Generated at 2022-06-21 10:26:17.735902
# Unit test for function untokenize
def test_untokenize():
    def compare(s, iterable):
        result = untokenize(iterable)
        if result != s:
            raise AssertionError(
                "Untokenizing:\n{0!r}\n should result in:\n{1!r}\n, not {2!r}".format(
                    iterable, s, result
                )
            )


# Generated at 2022-06-21 10:26:21.033521
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"



# Generated at 2022-06-21 10:26:27.455701
# Unit test for function tokenize_loop
def test_tokenize_loop():
    lines = []
    def readline():
        try:
            return lines.pop(0)
        except IndexError:
            return ''
    tokeneater = lines.append
    data = 'def f(x): return x**2\n'
    tokenize_loop(readline, tokeneater)
    assert lines == list(generate_tokens(readline))



# Generated at 2022-06-21 10:26:38.446228
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import re
    import io
    s = "def f(x): return 2*x"
    f = io.StringIO(s)
    result = []
    tokenize_loop(f.readline, result.append)

# Generated at 2022-06-21 10:26:41.374025
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"



# Generated at 2022-06-21 10:26:45.908339
# Unit test for function untokenize
def test_untokenize():
    # Check that untokenize is idempotent on a simple input file.
    f = open(__file__, encoding="utf-8")
    s = f.read()
    f.close()
    t1 = tokenize(BytesIO(s.encode("utf-8")).readline)
    newcode = untokenize(t1)
    readline = iter(newcode.splitlines(1)).__next__
    t2 = tokenize(readline)
    for t in zip(t1, t2):
        assert t[0] == t[1], "%s != %s" % (t[0], t[1])



# Generated at 2022-06-21 10:26:49.721644
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    ex = StopTokenizing()
    assert ex.__class__.__name__ == "StopTokenizing"
    assert ex.__class__.__module__ == __name__
    assert str(ex) == ""



# Generated at 2022-06-21 10:27:18.108237
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token

    readline = io.StringIO("foobar").readline
    tokeneater = token
    tokenize_loop(readline, tokeneater)


TokenInfo = Tuple[int, Text, Coord, Coord, Text]
TokenIterator = Iterator[TokenInfo]



# Generated at 2022-06-21 10:27:29.003210
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from StringIO import StringIO

    # Set up input
    input = StringIO("if 1:\n  pass\n")
    # Set up expected output
    output = StringIO()
    for t_info in generate_tokens(input.readline):
        output.write(
            str(t_info)
            + " "
            + tok_name[t_info[0]]
            + " "
            + repr(t_info[1])
            + "\n"
        )

# Generated at 2022-06-21 10:27:40.557206
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from sys import stdout
    from .tokenize import tok_name
    from .tokenize import untokenize

    def tokeneater(*args):
        (type, token, start, end, line) = args
        if token.strip():
            print("%s %s %s %s %s" % (start, tok_name[type], token, end, line))
        else:
            print("%s%s%s\t%s" % (start, tok_name[type], end, repr(line)))

    data = "if 1: #abc\n  pass\n"
    f = StringIO(data)
    try:
        tokenize_loop(f.readline, tokeneater)
    except StopTokenizing:
        pass
    f.close()
   

# Generated at 2022-06-21 10:27:43.402537
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:27:44.339939
# Unit test for function printtoken
def test_printtoken():
    pass # test not implemented
# End unit test


# Generated at 2022-06-21 10:27:46.003935
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass
    except Exception as e:
        raise RuntimeError("Unexpected exception: ", e)



# Generated at 2022-06-21 10:27:48.296862
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from token import classify


# Generated at 2022-06-21 10:27:53.059402
# Unit test for function detect_encoding
def test_detect_encoding():
    def read_or_stop():
        for x in lines:
            yield x
        raise StopIteration

    lines = ["# coding: ascii", "a = 1"]
    assert detect_encoding(read_or_stop) == ("ascii", lines)

    lines = [b'\xef\xbb\xbf# coding: ascii', "a = 1"]
    assert detect_encoding(read_or_stop) == ("utf-8-sig", lines)

    lines = [b"\xef\xbb\xbf# coding: ascii", "a = 1"]
    assert detect_encoding(read_or_stop) == ("utf-8-sig", lines)

    lines = [b"foobar", b""]

# Generated at 2022-06-21 10:28:05.032981
# Unit test for function untokenize
def test_untokenize():
    untok = untokenize([(token.NUMBER, "1"), (token.NAME, "a"),
        (token.STRING, '""'), (token.NEWLINE, "\n"), (token.NEWLINE, "\n"),
        (token.INDENT, " "), (token.NAME, "print"), (token.NAME, "b"),
        (token.DEDENT, ""), (token.NEWLINE, "\n"),
        (token.NUMBER, "1"), (token.NAME, "a"), (token.STRING, '""'),
        (token.ENDMARKER, "")
    ])
    assert untok.splitlines()[1:] == ["1 a ''", "", " print b", "1 a ''"]



# Generated at 2022-06-21 10:28:09.461974
# Unit test for function printtoken
def test_printtoken():
    printtoken(tokenize.NUMBER, "123", (1, 2), (1, 5), "abc")
    printtoken(tokenize.OP, "+", (4, 5), (4, 6), "a+b")

# Function to convert bytes to Hex Encoding

# Generated at 2022-06-21 10:29:17.419745
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    from tokenize import tokenize, untokenize, NAME, OP, ENDMARKER
    readline = io.StringIO('foo = "bar"\n').readline
    tokens = generate_tokens(readline)

# Generated at 2022-06-21 10:29:26.836868
# Unit test for function group
def test_group():
    def group_test(items, expected):
        actual = group(*items)
        assert actual == expected, "%s != %s" % (actual, expected)

    group_test(["abc", "def", "123"], "(abc|def|123)")
    group_test(["a(b", "d)e", "123"], "(a\\(b|d\\)e|123)")
    group_test(["a(b", "d)e", "(((((((12"],
               "(a\\(b|d\\)e|\\(\\(\\(\\(\\(\\(\\(12)")


# Generated at 2022-06-21 10:29:39.697107
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 10
    u.prev_col = 5
    u.add_whitespace((10, 8))
    assert u.tokens == ["   "]
    u = Untokenizer()
    u.prev_row = 10
    u.prev_col = 5
    u.add_whitespace((11, 8))
    assert u.tokens == ["\n   "]
    u = Untokenizer()
    u.prev_row = 10
    u.prev_col = 5
    u.add_whitespace((9, 8))
    assert u.tokens == [""]
    u = Untokenizer()
    u.prev_row = 10
    u.prev_col = 5
    u.add_whitespace((10, 3))


# Generated at 2022-06-21 10:29:45.957434
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.add_whitespace((1, 0))
    assert not u.tokens
    u.add_whitespace((1, 3))
    assert u.tokens == ["   "]
    u.add_whitespace((1, 2))
    assert u.tokens == ["   ", "  "]
    u.add_whitespace((2, 20))
    assert u.tokens == ["   ", "  ", "\n                    "]



# Generated at 2022-06-21 10:29:48.241600
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "if 1: # hi"
    tokeneater = lambda *args: None
    tokenize_loop(readline(), tokeneater)



# Generated at 2022-06-21 10:29:53.077405
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO

    def _format(toktype, toktext, srow_scol, erow_ecol, line):
        return (
            "%d, %d, %d, %d, %d, %s, %s"
            % (
                toktype,
                srow_scol[0],
                srow_scol[1],
                erow_ecol[0],
                erow_ecol[1],
                repr(toktext),
                line,
            )
        )

    def _tokenize(input, expected):
        stream = StringIO(input)
        tokens = generate_tokens(stream.readline)
        result = [_format(*token) for token in tokens]
        return result == expected


# Generated at 2022-06-21 10:29:55.254716
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"



# Generated at 2022-06-21 10:30:04.138755
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not hasattr(readline, "done"):
            readline.done = True
            return b"# coding: latin-1\n"
        raise StopIteration

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"# coding: latin-1\n"]

    def readline():
        if not hasattr(readline, "done"):
            readline.done = True
            return b"#!/usr/bin/python\n"
        raise StopIteration

    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == [b"#!/usr/bin/python\n"]


# Generated at 2022-06-21 10:30:16.096672
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import tokenize
    from io import StringIO
    s = "'''abc''' 'a' \"\"\"def\"\"\" \"d\" '''\nabc\n''' \"\"\"\ndef\n\"\"\" 'a\\\nbc'\ndef"
    g = tokenize.generate_tokens(StringIO(s).readline)

# Generated at 2022-06-21 10:30:18.304870
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"

