

# Generated at 2022-06-21 10:23:38.861914
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    """
    Untokenizer.untokenize() should untokenize a token list.
    """
    input_tokens = [
        (1, "a"),
        (1, "b"),
        (0, " "),
        (1, "c"),
        (4, "\n"),
        (0, " "),
        (0, "\t"),
        (1, "d"),
    ]
    untokenizer = Untokenizer()
    output_string = untokenizer.untokenize(input_tokens)
    assert output_string == "a b c\n \t d"



# Generated at 2022-06-21 10:23:42.641678
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    """Test the constructor of class StopTokenizing"""
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass
    except:
        raise AssertionError


_tokenize_cache: Dict[Tuple[int, Text], List[token]] = {}



# Generated at 2022-06-21 10:23:51.879907
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from .token import untokenize
    from . import token

    text = "'''hi''' #'''\n"
    # Test with just the readline argument
    gen1 = generate_tokens(StringIO(text).readline)
    rv1 = list(gen1)
    tokenize_loop(StringIO(text).readline, printtoken)
    gen2 = generate_tokens(StringIO(text).readline)
    rv2 = list(gen2)
    assert token.untokenize(rv1) == token.untokenize(rv2)
    # Test with readline and tokeneater
    file = StringIO(text)
    rv = []
    tokenize_loop(file.readline, rv.append)
    assert token.unt

# Generated at 2022-06-21 10:24:04.419723
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    #
    #   Happy path
    #
    unt = Untokenizer()
    unt.prev_row = 1
    unt.prev_col = 0
    unt.add_whitespace((1,0))
    unt.add_whitespace((1,4))
    unt.add_whitespace((2,4))
    unt.add_whitespace((3,4))
    assert unt.tokens == ['', '    ', '    ', '']

    #
    #   This path is sad
    #
    unt = Untokenizer()
    unt.prev_row = 1
    unt.prev_col = 0
    with pytest.raises(AssertionError):
        unt.add_whitespace((2,0))
# in case of future problems with backslash continuation, this regexp
# matches

# Generated at 2022-06-21 10:24:14.857270
# Unit test for function tokenize_loop
def test_tokenize_loop():

    def tokeneater(*args):
        tokeneater.tokens.append(args)

    tokeneater.tokens = []
    tokenize_loop(iter("def f(x):\n  return x+1").__next__, tokeneater)

# Generated at 2022-06-21 10:24:24.980949
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    from .test import support as test_support

    with test_support.captured_stdout() as source:
        source_code = inspect.getsource(
            test_support.unload(test_support.unload(test_support.detect_api_mismatch))
        )
    readline = io.BytesIO(source_code.encode("utf-8")).readline
    tokens = tokenize.generate_tokens(readline)
    result = untokenize(tokens)
    # If result is not a unicode object, untokenize will not have decoded
    # the tokens properly.
    assert isinstance(result, str)
    # If result does not match the original source, untokenize did not roundtrip.
    assert result == source_code



# Generated at 2022-06-21 10:24:29.867694
# Unit test for function detect_encoding
def test_detect_encoding():
    def read_or_stop():
        raise StopIteration

    def read_lines(*lines):
        for line in lines:
            yield line

    def normalize(encoding):
        if encoding == "utf-8-sig":
            return "utf-8"
        return encoding

    # Check default encoding
    assert normalize(detect_encoding(read_or_stop)[0]) == "utf-8"

    # Check BOM in first line
    assert normalize(detect_encoding(read_lines(BOM_UTF8))[0]) == "utf-8"

    # Check BOM with encoding cookie in first two lines
    assert normalize(detect_encoding(read_lines(BOM_UTF8, b"# coding: utf-8"))[0]) == "utf-8"
    assert normalize

# Generated at 2022-06-21 10:24:33.079237
# Unit test for function group
def test_group():
    # Test singleton
    assert group("abc") == "abc"
    # Test two items
    assert group("abc", "def") == "abc|def"


# Generated at 2022-06-21 10:24:44.612725
# Unit test for function any
def test_any():
    any_re = any(*["a", "b"])
    assert re.match(any_re, "") is not None
    assert re.match(any_re, "a") is not None
    assert re.match(any_re, "b") is not None
    assert re.match(any_re, "aa") is not None
    assert re.match(any_re, "bb") is not None
    assert re.match(any_re, "ab") is not None
    assert re.match(any_re, "ba") is not None
    assert re.match(any_re, "aab") is not None
    assert re.match(any_re, "aba") is not None
    assert re.match(any_re, "abab") is not None

# Generated at 2022-06-21 10:24:48.074875
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("ab", "cd") == "(ab|cd)"


# Helper: "raw" strings

# Generated at 2022-06-21 10:25:26.209734
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = "for x in range(10): print(x)\n"
    result = []
    tokenize_loop(s.splitlines().__iter__().__next__, result.append)

    expected = [
        (NAME, "for"),
        (NAME, "x"),
        (NAME, "in"),
        (NAME, "range"),
        (OP, "("),
        (NUMBER, "10"),
        (OP, ")"),
        (OP, ":"),
        (NAME, "print"),
        (OP, "("),
        (NAME, "x"),
        (OP, ")"),
    ]
    assert result == expected



# Generated at 2022-06-21 10:25:29.111527
# Unit test for function printtoken
def test_printtoken():
    printtoken(1,1,(1,1),(1,2),1)


# Generated at 2022-06-21 10:25:33.366840
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    class MyClass(object):
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b

    x = MyClass()
    x.__dict__
    # This should not crash.
    x = StopTokenizing()
    x.__dict__



# Generated at 2022-06-21 10:25:41.287500
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_row = 1
    ut.prev_col = 0
    ut.add_whitespace((1, 0))
    assert ut.tokens == []
    ut.add_whitespace((2, 0))
    assert ut.tokens == ["\n"]
    ut.add_whitespace((3, 0))
    assert ut.tokens == ["\n", "\n"]
    ut.add_whitespace((3, 1))
    assert ut.tokens == ["\n", "\n", " "]
    ut.add_whitespace((3, 3))
    assert ut.tokens == ["\n", "\n", "   "]
    ut.tokens = []
    ut.prev_col = 4

# Generated at 2022-06-21 10:25:47.971685
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    x = [
        (NAME, 'foo'),
        (NUMBER, '3.14159265359'),
        (NEWLINE, ''),
        (INDENT, ' '),
        (NUMBER, '42'),
        (DEDENT, ''),
        (NUMBER, '42'),
    ]
    assert u.untokenize(x) == 'foo 3.14159265359\n 42\n42 '


# Generated at 2022-06-21 10:25:52.373685
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import BytesIO
    from io import StringIO
    from typing import BinaryIO
    import tokenize
    from tokenize import tok_name
    # Test input is a file-like object; test output is a byte stream.

# Generated at 2022-06-21 10:26:04.698676
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()

# Generated at 2022-06-21 10:26:16.173603
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 3
    u.prev_col = 2
    u.tokens = ["a", "bc"]
    u.add_whitespace((4, 1))
    assert "a\nbc" == "".join(u.tokens)
    u.add_whitespace((5, 0))
    assert "a\nbc\n" == "".join(u.tokens)
    u.add_whitespace((5, 10))
    assert "a\nbc\n          " == "".join(u.tokens)
    u.add_whitespace((6, 1))
    assert "a\nbc\n          \n" == "".join(u.tokens)
    u.add_whitespace((7, 1))

# Generated at 2022-06-21 10:26:20.818853
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    def f():
        raise StopTokenizing("test")

    try:
        f()
    except StopTokenizing:
        pass
    # If a Python implementation raises two exceptions in a row, the first
    # one is lost.  So texttestrunner doesn't see the StopTokenizing
    # exception and complains.  Make sure it sees something.
    raise RuntimeError(
        "test_StopTokenizing did not properly raise StopTokenizing"
    )


# Check for generator expressions (which we can't handle)

# Generated at 2022-06-21 10:26:23.255046
# Unit test for function maybe
def test_maybe():
    fail("maybe('') didn't return '?'")
    fail("maybe('a') didn't return '(a)?'")
    fail("maybe('a', 'b') didn't return '(a|b)?'")



# Generated at 2022-06-21 10:27:04.494243
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # Check initial state
    ut = Untokenizer()
    assert ut.tokens == []
    assert ut.prev_row == 1
    assert ut.prev_col == 0

    # Test trivial case
    ut.add_whitespace((1, 0))
    assert ut.tokens == []
    assert ut.prev_row == 1
    assert ut.prev_col == 0

    # Test with zero column spacing
    ut.add_whitespace((1, 1))
    assert ut.tokens == ['']
    assert ut.prev_row == 1
    assert ut.prev_col == 1

    # Test with single column spacing
    ut.add_whitespace((1, 2))
    assert ut.tokens == ['', ' ']
    assert ut.prev_row == 1
    assert ut.prev

# Generated at 2022-06-21 10:27:06.902002
# Unit test for function printtoken
def test_printtoken():
    import io
    import tokenize

# Generated at 2022-06-21 10:27:15.887588
# Unit test for function untokenize
def test_untokenize():
    # Test round-trip identity for small input pieces
    def check(s):
        t1 = [tok[:2] for tok in generate_tokens(iter(s.splitlines(True)).next)]
        newcode = untokenize(t1)
        readline = iter(newcode.splitlines(True)).next
        t2 = [tok[:2] for tok in generate_tokens(readline)]
        assert t1 == t2

    check('def foo ():\n  pass\n')

# Generated at 2022-06-21 10:27:25.433605
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    unt = Untokenizer()
    unt.add_whitespace((0, 0))
    assert unt.tokens == []
    unt.add_whitespace((0, 1))
    assert unt.tokens == [" "]
    unt.add_whitespace((1, 1))
    assert unt.tokens == [" ", "\n"]
    unt.add_whitespace((1, 2))
    assert unt.tokens == [" ", "\n", " "]
    unt.add_whitespace((2, 2))
    assert unt.tokens == [" ", "\n", " ", "\n"]



# Generated at 2022-06-21 10:27:36.335362
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import tokenize
    from io import StringIO

    def _format(tokens):
        return "".join("%-20s" % t for t in tokens)

    def _format_tokens(tokens):
        return "".join("%-20s" % tokenize.tokenize_printables[t.type] for t in tokens)

    def _format_token_value(tokens):
        return "".join("%-20r" % t.string for t in tokens)

    def _format_token_loc(tokens):
        return "".join("(%-2d,%2d-%2d) " % t[2:5] for t in tokens)

    def test_tokenitzation(data, tokens):
        src = StringIO(data.expandtabs(4)).readline

# Generated at 2022-06-21 10:27:39.553324
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    assert u.tokens == []
    assert u.prev_row == 1
    assert u.prev_col == 0



# Generated at 2022-06-21 10:27:40.994692
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:27:50.397778
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    untok = Untokenizer()

    result = untok.compat((NAME, "@"), [])
    assert result == None
    assert untok.tokens == ['@ ', '']

    untok1 = Untokenizer()
    with open("blib2to3/pgen2/token.py", "rb") as file:
        tokens = tokenize.tokenize(file.readline)
    tokens = iter(tokens)
    for i in range(10):
        next(tokens) # Skip to the first indented line
    for i in range(10):
        # Just read the next 10 lines
        untok1.compat(next(tokens), tokens)

# Generated at 2022-06-21 10:27:53.191922
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("description")
    except TokenError as inst:
        assert inst.args == ("description",)
        assert str(inst) == "'description'"



# Generated at 2022-06-21 10:28:00.245603
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    s = io.StringIO("def foo():\n  if True:\n    print ('foo')")
    it1 = generate_tokens(s.readline)
    it2 = generate_tokens(s.readline) # this one is essential for the bug to occur
    ut = Untokenizer()
    ut.untokenize(it1)
    ut.untokenize(it2)



# Generated at 2022-06-21 10:28:55.335953
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"# -*- coding: iso-8859-1 -*-"
    encoding, lines = detect_encoding(readline)
    assert encoding == 'iso-8859-1'


# Generated at 2022-06-21 10:29:04.402294
# Unit test for function maybe
def test_maybe():
    assert maybe(r'\w+', r'\d+') == r'(\w+|\d+)?', maybe(r'\w+', r'\d+')


# Note: we use {EPSILON} in our tokens instead of the empty string
# so that we can distinguish tokens that have been EMPTY by default
# from those that have actually been assigned the empty string.

# Helper for header
Name = r'[a-zA-Z_]\w*'

Hexnum = r'0[xX][\da-fA-F]+(?:_[\da-fA-F]+)*'
Binnum = r'0[bB][01]+(?:_[01]+)*'
Octnum = r'0[oO][0-7]+(?:_[0-7]+)*'


# Generated at 2022-06-21 10:29:14.902398
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token

    def tokeneater(type: int, token: Text, start: Tuple[int, int], end: Tuple[int, int], line: Text
                   ) -> None:
        print(tokenize.tok_name[type], repr(token))

    with open("tokenize_tests.txt") as fp:
        while 1:
            line = fp.readline()
            if not line:
                break
            if line.startswith("#"):
                print(line, end="")
            else:
                break
        print("###", line, end="")
        generate_tokens(io.StringIO(line).readline, tokeneater)

# Generated at 2022-06-21 10:29:21.946275
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO

    from blib2to3.pgen2.token import tok_name

    stream = StringIO("# A simple module to square numbers.\n"
                      "def sq(x):\n"
                      "    return x * x\n")
    results = []

    def tokeneater(*args):
        # Collect the token info.  The tokenizer doesn't have
        # line numbers, so this is a bit of a cheat.
        results.append(args + (stream.getvalue().splitlines()[args[2][0] - 1],))

    tokenize_loop(stream.readline, tokeneater)

    # The first four tokens are always (ENCODING, None, (0, 0), (0, 0), '')
    tokens = results[4:]

    # The last two tokens are

# Generated at 2022-06-21 10:29:27.100697
# Unit test for function maybe
def test_maybe():
    m = maybe('a') + maybe('b')
    #assert m.match('ab')
    assert m.match('a')
    assert m.match('b')
    assert m.match('')
    assert not m.match('c')
    assert not m.match('ac')
    assert not m.match('ba')
# End unit test for function maybe



# Generated at 2022-06-21 10:29:40.143561
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    from tokenize import generate_tokens

    # Test the 'tokenize' function
    from tokenize import tokenize as tokenize_function, untokenize, TokenInfo, NUMBER, STRING, NAME, OP
    readline = io.BytesIO(
        b'i = 1 + 1\nprint(i)\ndel i\n'
    ).readline

# Generated at 2022-06-21 10:29:44.417579
# Unit test for function tokenize
def test_tokenize():
    import io
    import token

    data = "1 + 1"
    data_io = io.StringIO(data)
    for toknum, tokval, _, _, _ in generate_tokens(data_io.readline):
        if toknum == token.NUMBER and tokval == "1":
            break
    else:
        print("Couldn't find first number")



# Generated at 2022-06-21 10:29:48.157332
# Unit test for function printtoken
def test_printtoken():
    xxx_todo_changeme2 = (2, 3)
    xxx_todo_changeme3 = (3, 4)
    printtoken(1, "hello\t", xxx_todo_changeme2, xxx_todo_changeme3, "hi there")



# Generated at 2022-06-21 10:29:52.255175
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    input = [("abc", "abc"), (" ", " "), ("1", "1"), (" ", " "), ("def", "def")]
    u = Untokenizer()
    assert u.untokenize(input) == "abc 1 def"



# Generated at 2022-06-21 10:30:01.383960
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from .token import tok_name
    from io import StringIO
    toks = []
    def tokeneater(*args):
        toks.append(args)
    tokenize_loop(StringIO("def foo(): pass\n").readline, tokeneater)
    print(toks)
    assert toks[0][0] == tok_name["NAME"] == toks[1][0]
    assert toks[0][1] == "def" == toks[1][1]
    assert toks[2][0] == tok_name["NEWLINE"]
    print("test_tokenize_loop done")

