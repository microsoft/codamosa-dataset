

# Generated at 2022-06-21 10:22:40.145722
# Unit test for function tokenize_loop
def test_tokenize_loop():
    tokenize_loop(
        readline=lambda: "for i in range(10): # comment\n  print(i)\n", tokeneater=printtoken
    )



# Generated at 2022-06-21 10:22:48.807305
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    from typing import Type

    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize
    from . import tokenize


# Generated at 2022-06-21 10:23:01.272090
# Unit test for function detect_encoding
def test_detect_encoding():  # htest #
    def readline():
        yield b"# -*- coding: cp1252 -*-"
        yield b"blah blah"

    assert detect_encoding(readline) == "cp1252", "cookie test failed"

    def readline():
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah\xe3 blah"

    assert detect_encoding(readline) == "iso-8859-1", "cookie test failed"

    def readline():
        yield BOM_UTF8
        yield b"# -*- coding: latin-1 -*-"
        yield b"blah blah"

    assert detect_encoding(readline) == "utf-8-sig", "cookie and BOM test failed"

    def readline():
        yield BOM

# Generated at 2022-06-21 10:23:06.281703
# Unit test for function maybe
def test_maybe():
    assert maybe('ab') == '((ab))?'
    assert maybe('a', 'ab') == '((a)|(ab))?'
    assert maybe() == ''
    assert maybe('') == ''
    assert maybe('', '') == ''

# translate str to unicode, using BOM detection.
# The input might be bytes, or it might be a str containing encoded bytes.

# Generated at 2022-06-21 10:23:07.885069
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    assert StopTokenizing.__module__ == "blib2to3.pgen2.tokenize"



# Generated at 2022-06-21 10:23:10.657969
# Unit test for function tokenize
def test_tokenize():
    import io
    import token

    r = io.StringIO("import sys\n")
    tokenize(r.readline, token.printtoken)
test_tokenize()



# Generated at 2022-06-21 10:23:13.502815
# Unit test for function group
def test_group():
    assert (group("a", "ab") == "(a|ab)")


# Generated at 2022-06-21 10:23:22.946828
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b'# -*- coding: latin-1 -*-\n'
        yield b'def foo(): pass\n'
        yield b'\n'
    assert detect_encoding(readline) == ('iso-8859-1',
                                         [b'# -*- coding: latin-1 -*-\n'])

    def readline():
        yield b'\xEF\xBB\xBF# coding: ascii\n'
        yield b'def foo(): pass\n'
        yield b'\n'
    assert detect_encoding(readline) == ('utf-8-sig',
                                         [b'\xEF\xBB\xBF# coding: ascii\n'])


# Generated at 2022-06-21 10:23:31.127537
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.NAME, 'foo', (0,0), (0,3), 'foo')
    printtoken(token.INDENT, '', (0,2), (0,2), '  foo')
    printtoken(token.NUMBER, 42, (0,5), (0,7), 'foo 42 bar')
    printtoken(token.OP, '+', (1,2), (1,3), 'foo +')
    printtoken(token.RARROW, '->', (1,4), (1,6), 'foo ->')
    printtoken(token.NEWLINE, '\n', (1,6), (1,7), 'foo\n')
    printtoken(token.ENDMARKER, '', (1,7), (1,7), 'foo   \n')

# Test with the default grammar


# Generated at 2022-06-21 10:23:32.964947
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # should not raise an exception
    StopTokenizing()



# Generated at 2022-06-21 10:24:32.281490
# Unit test for function tokenize
def test_tokenize():
    import io
    import tokenize as tokenize_module
    from blib2to3.pgen2.token import tok_name

    # Test input that's an iterable, not a file
    data = b'for i in range(10): print(i)\n'
    for _token in tokenize_module.tokenize(io.BytesIO(data).readline):
        print(tokenize_module.tok_name[_token.type])

    # Test valid data
    data = b"if 1:\n    x=1\n#comment\n"
    tokens = list(tokenize_module.tokenize(io.BytesIO(data).readline))
    assert len(tokens) == 6
    assert tokens[0].exact_type == tokenize_module.NAME

# Generated at 2022-06-21 10:24:43.188594
# Unit test for function detect_encoding
def test_detect_encoding():
    def _run(data: bytes, expected: str) -> None:
        assert detect_encoding(iter(data.splitlines(True)).__next__)[0] == expected

    def _check(data: bytes, expected: str) -> None:
        _run(data, expected)
        _run(data.replace(b"\n", b"\r\n"), expected)

    _check(b"\xef\xbb\xbf# coding: ascii\n", "ascii")
    _check(b"# -*- coding: latin-1 -*-\n", "iso-8859-1")
    _check(b"# vim:fileencoding=iso-8859-1\n", "iso-8859-1")

# Generated at 2022-06-21 10:24:53.535159
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from tokenize import generate_tokens

    def check(expected, given, msg):
        if given != expected:
            print(
                "Expected:\n%r\nGot:\n%r\n-- %s"
                % (expected, given, msg or "mismatch"),
                end="",
            )

    # The same source works with both Python 2 and Python 3.
    source = "x = x + 1\n"

    # Test incompatible input (Python 2-style input).
    buf = StringIO(source)
    tokens = list(generate_tokens(buf.readline))
    untok = Untokenizer()
    check(source, untok.compat(tokens[0], iter(tokens[1:])), "compat")

    # Test compatible input

# Generated at 2022-06-21 10:24:59.807722
# Unit test for function tokenize
def test_tokenize():
    import io

    def tokeneater(type, token, start, end, line):
        tok = TokenInfo(type, token, start, end, line)
        print(tok)

    tokenize(io.BytesIO(BOM_UTF8 + b"def f(x):\n return x + 1\n").readline, tokeneater)



# Generated at 2022-06-21 10:25:09.482786
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def _strip_id(s, id_str):
        return s.replace(id_str, "")
    def _untok(s, id_str=_tid_new) -> Text:
        return Untokenizer().untokenize(
            tokenize(BytesIO(s).readline, id_str=id_str)
        )
    def _untok_ret(s, id_str=_tid_new) -> Text:
        return _strip_id(_untok(s, id_str), id_str)
    assert _untok_ret(b"x = 37\n") == "x = 37"

# Generated at 2022-06-21 10:25:12.853956
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing("dummy")
    except StopTokenizing as e:
        assert str(e) == "dummy"
        assert e.args == ("dummy",)
        assert type(e) == StopTokenizing



# Generated at 2022-06-21 10:25:25.846392
# Unit test for function any
def test_any():
    # Verify that 'any' and 'group' work as advertised
    for op in ("*", "+", "?"):
        pat = any(r"\d" + op, "[a-zA-Z_]" + op, "[ \t\f]") + "[^ \t\f]"
        assert re.match(pat, "1+2")
        assert re.match(pat, "a+b")
        assert re.match(pat, "\t + \t")
        assert re.match(pat, "\f+\f")
        assert not re.match(pat, "1 +2")
        assert not re.match(pat, "a +b")
        assert not re.match(pat, "\t+ \t")
        assert not re.match(pat, "\f +\f")
test_any()
del test_any



# Generated at 2022-06-21 10:25:36.849723
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output, roundtrip=True):
        readline = iter(input.splitlines(1)).__next__
        tokens = generate_tokens(readline)
        result = untokenize(tokens)
        if result != output:
            fail_msg = "Results do not match"
            if roundtrip:
                fail_msg += "; roundtrip test failed"
            raise AssertionError(
                fail_msg
                + "\ninput: "
                + repr(input)
                + "\nresult: "
                + repr(result)
                + "\nexpected: "
                + repr(output)
            )
        if roundtrip:
            readline = iter(result.splitlines(1)).__next__

# Generated at 2022-06-21 10:25:47.971663
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    text = 'def f(x): return "a\\n" + \\'
    with io.StringIO(text) as f:
        readline = f.readline
        tokens = []
        tokenize_loop(readline, tokens.append)

# Generated at 2022-06-21 10:26:00.531729
# Unit test for function untokenize
def test_untokenize():
    assert untokenize([
        (1, "def"), (1, " "), (1, "foo"), (1, "("), (1, "x"), (1, ","),
        (1, " "), (1, "y"), (1, ")"), (3, ":"), (4, " "), (4, "\n"),
        (0, " "), (1, "return"), (1, " "), (1, "x"), (1, "+"), (1, "y"), (3, "\n")
    ]) == "def foo(x, y):\n    return x+y\n"


# A table identifying binary operators

# Generated at 2022-06-21 10:27:09.993186
# Unit test for function group
def test_group():
    assert group("a", "b") == "ab|"
    assert group("a", "b", "c") == "abc|"
    assert group("a", "b", "c", "d") == "abcd|"


# Generated at 2022-06-21 10:27:20.383060
# Unit test for function maybe
def test_maybe():
    assert maybe('"') == '(")?'


Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"[a-zA-Z_]\w*"

# NOTE: Since this is a hand-coded lexer, we do not use unicode regexp
# matching. The tok_name() function takes care of translating tokens like
# OP into the appropriate unicode symbol.
Binnumber = r"0[bB][01]+(?:_[01]+)*"
Hexnumber = r"0[xX][\da-fA-F]+(?:_[\da-fA-F]+)*"

# Generated at 2022-06-21 10:27:30.833252
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
  # Test that Untokenizer.tokenize() preserves the order of tokens
  # and the whitespace between them.

  ut = Untokenizer()

  # Make this deterministic.
  ut.prev_row = 1
  ut.prev_col = 0

  # Fake token generator, mimicking the output of generate_tokens().
  # The token strings do not correspond to actual Python tokens
  # (we use "A" and "B" instead of "def" and ":", for example).
  def token_stream(s):
    for line in s.splitlines(keepends=True):
      for col, char in enumerate(line):
        yield col + 1, col + 2, "A", char

  # Test various combinations of whitespace.

# Generated at 2022-06-21 10:27:35.701983
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline(line):
        yield line


# Generated at 2022-06-21 10:27:47.054036
# Unit test for function tokenize
def test_tokenize():
    import unittest

    class TokenizeTest(unittest.TestCase):
        def setUp(self):
            self.reads = []
            self.dummy_file = lambda: self.reads.pop(0)
            self.tokens = []
            self.tokeneater = self.tokens.append


# Generated at 2022-06-21 10:27:51.220397
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("a") == "a"
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-21 10:28:03.697276
# Unit test for function untokenize
def test_untokenize():
    import io, token, tokenize

# Generated at 2022-06-21 10:28:08.679606
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    # Testing tok_first_2tuple
    untok.compat((NAME, "abs"), [(OP, "+"), (NAME, "b"), (OP, "+"), (STRING, "'a'")])
    assert untok.tokens == ["abs ", "+", "b ", "+", "'a'"]



# Generated at 2022-06-21 10:28:17.871829
# Unit test for function printtoken
def test_printtoken():
    test_input = "a = 10"
    test_output = "1,1-1,5:\tNAME\t'a'\n1,7-1,9:\tNUMBER\t'10'\n"
    import io

    fp = io.StringIO(test_input)
    save_stdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        tokenize(fp.readline, printtoken)
    finally:
        sys.stdout = save_stdout
    assert sys.stdout.getvalue() == test_output


# Generated at 2022-06-21 10:28:22.073541
# Unit test for function any
def test_any():
    # Pick out an optional sequence of words
    pat = regex.compile(r"\s*(?:(%s)\s*)+" % any("word", "this", r"\d+"))
    pat.match("this 1").end()  # Out: 8



# Generated at 2022-06-21 10:28:49.626883
# Unit test for function any
def test_any():
    assert any("ab", "cd") == "(ab|cd)*"
    assert any() == "()*"



# Generated at 2022-06-21 10:29:00.388413
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    sample = b"# coding: latin-1\npass\n"
    for i in range(0, len(sample), 2):
        sample = sample[:i] + b"\0" + sample[i:]
        for j in range(0, len(sample), 2):
            text = sample[:j] + b"\0" + sample[j:]
            bom = bytes()
            if not (i & 1):
                bom = BOM_UTF8
            for prefix in [b"", bom]:
                stream = io.BytesIO(prefix + text)
                encoding, lines = detect_encoding(stream.readline)
                assert "latin-1" == encoding, "wrong encoding: %r" % (encoding,)

# Generated at 2022-06-21 10:29:03.838470
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    unt = Untokenizer()
    unt.compat((NAME, "hello"))
    unt.compat((NEWLINE, "\n"))
    unt.compat((NUMBER, "42"))
    unt.compat((ENDMARKER, ""))
    assert unt.tokens == ["hello ", "42 "]



# Generated at 2022-06-21 10:29:07.326799
# Unit test for function untokenize
def test_untokenize():
    tests = [
        ("def f():\n    return", "def f():\n    return"),
        ("1", "1"),
        ("[1]", "[1]"),
        ]

    for input, output in tests:
        if untokenize(tokenize(io.StringIO(input).readline)) != output:
            print("Error in untokenize")
            print("In:  ", repr(input))
            print("Out: ", repr(untokenize(tokenize(io.StringIO(input).readline))))
            print("Should be:", repr(output))
            
test_untokenize()


# Generated at 2022-06-21 10:29:12.137760
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from blib2to3.pygram import python_symbols as syms
    u = Untokenizer()
    assert u.compat((syms.async_stmt, "async"), [(syms.expr_stmt, "f()")]) == None


# Generated at 2022-06-21 10:29:20.284020
# Unit test for function tokenize
def test_tokenize():
    # Syntax tests
    import StringIO
    from tokenize import tokenize as test_tokenize, tok_name
    from io import BytesIO


# Generated at 2022-06-21 10:29:22.995429
# Unit test for function any
def test_any():
    assert any("abc", "def") == "(abc|def)*"


# Generated at 2022-06-21 10:29:31.187049
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import unittest

    data = (
        "b=A.from_bytes(b'abc', 'little')\n"
        'print("{}, {:x}, {}".format(b, int.from_bytes(b, "little"), list(b)))\n'
    )
    t = tokenize(io.BytesIO(data.encode("utf-8")).readline)

# Generated at 2022-06-21 10:29:33.600663
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:29:44.579961
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        return source.pop(0)
    source = [
        "# -*- coding: latin-1 -*-\n",
        "# vim:filetype=python\n",
    ]
    assert detect_encoding(readline) == ("iso-8859-1", source)

    source = [
        "# -*- coding: latin-1 -*-\n",
    ]
    assert detect_encoding(readline) == ("iso-8859-1", source)

    source = [
        "# -*- coding: latin-1 -*-\n",
        "\n",
    ]
    assert detect_encoding(readline) == ("iso-8859-1", source)


# Generated at 2022-06-21 10:30:23.794982
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:30:32.603385
# Unit test for function tokenize
def test_tokenize():
    from types import GeneratorType

    tokens_gen = generate_tokens(iter(['def f(x):\n', '  return x\n']).__next__)
    assert isinstance(tokens_gen, GeneratorType)
    tokens = [tok for tok in tokens_gen]

# Generated at 2022-06-21 10:30:36.476492
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield "# coding: utf-8\n"

    assert detect_encoding(readline) == ("utf-8", ["# coding: utf-8\n"])



# Generated at 2022-06-21 10:30:41.606490
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    test_cases = [
        ("def f(x): return 2*x", "def f(x):\n    return 2 * x"),
        (
            "class C:\n    pass",
            "class C:\n    pass",
        ),
        (
            "if 1:\n    print(1)",
            "if 1:\n    print(1)",
        ),
        (
            'if 1:\n    print(1)  # One comment\n   # Another comment',
            "if 1:\n    print(1)  # One comment\n    # Another comment",
        ),
    ]