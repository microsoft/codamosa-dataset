

# Generated at 2022-06-21 10:22:39.350269
# Unit test for function group
def test_group():
    p = group("a", "b")
    assert re.match(p, "a").group(0) == "a"
    assert re.match(p, "b").group(0) == "b"
    assert re.match(p, "b").group(1) == "b"
    assert re.match(p, "c") is None


# Generated at 2022-06-21 10:22:48.372693
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    s = "x + 1"
    u = Untokenizer()
    u.add_whitespace((1, 0))
    assert u.tokens == [], "Untokenizer.add_whitespace: failed on empty line"
    u.tokens = []
    u.add_whitespace((1, 1))
    assert (
        u.tokens == [" "],
        "Untokenizer.add_whitespace: failed on same col (1, 1) as previous col (1, 0)",
    )
    u.tokens = []
    u.prev_col = 3
    u.add_whitespace((1, 7))

# Generated at 2022-06-21 10:22:52.609506
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # type: () -> None
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:23:02.373786
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    print("Running unit test for add_whitespace")
    u = Untokenizer()
    u.prev_row = 1; u.prev_col = 0
    u.add_whitespace((1,1))
    assert u.tokens == [" "]
    u.prev_row = 1; u.prev_col = 1
    u.add_whitespace((1,3))
    assert u.tokens == [" ", "  "]
    u.prev_row = 3; u.prev_col = 0
    u.add_whitespace((3,3))
    assert u.tokens == [" ", "  ", "   "]
    u.prev_row = 2; u.prev_col = 0
    u.add_whitespace((3,3))

# Generated at 2022-06-21 10:23:05.505799
# Unit test for function group
def test_group():
    assert group(r"[a-z]+", r"[0-9]+", r"[ \t\r\f\v]+") == r"([a-z]+|[0-9]+|[ \t\r\f\v]+)"



# Generated at 2022-06-21 10:23:08.605168
# Unit test for function maybe
def test_maybe():
    assert maybe(r"[a-z ]") == r"([a-z ])*"
    assert maybe(r"[a-z ]", r"[0-9]") == r"([a-z ]|[0-9])*"



# Generated at 2022-06-21 10:23:22.332032
# Unit test for function untokenize
def test_untokenize():
    def check(input, output):
        result = untokenize(input)
        if result != output:
            print("Test failed")
            print("Untokenized data:")
            print(result)
            print("Expected data:")
            print(output)

    input = [
        (NUMBER, "0xab"),
        (NAME, "c"),
        (OP, "+"),
        (NUMBER, "0xab"),
        (NAME, "c"),
    ]
    output = "0xab c + 0xab c"
    check(input, output)


# Generated at 2022-06-21 10:23:24.991387
# Unit test for function any
def test_any():
    assert any('a') == '(a)*'
    assert any('a', 'b') == '(a|b)*'
    assert any('a', 'b', 'c') == '(a|b|c)*'


# Generated at 2022-06-21 10:23:34.796035
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    from tokenize import tokenize as tokenize_function
    from io import BytesIO, StringIO
    read_and_tokenize_bytes = lambda input: list(
        tokenize_function(BytesIO(input).readline)
    )
    read_and_tokenize_str = lambda input: list(tokenize_function(StringIO(input).readline))

# Generated at 2022-06-21 10:23:47.037808
# Unit test for function tokenize
def test_tokenize():
    global count
    count = 0
    text = "def f(x): return 2*x"

# Generated at 2022-06-21 10:25:17.801717
# Unit test for function printtoken
def test_printtoken():
    """Test function printtoken()."""
    s=r"def func(a, b): pass"
    printtoken(*tokenize(s).__next__())



# Generated at 2022-06-21 10:25:21.364032
# Unit test for constructor of class TokenError
def test_TokenError():
    exc = TokenError("message")

    import builtins

    assert isinstance(exc, builtins.Exception)
    assert str(exc) == "message"



# Generated at 2022-06-21 10:25:24.043104
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"


# Generated at 2022-06-21 10:25:31.215724
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import unittest
    unittest.main(module="blib2to3.pgen2.tokenize", exit=False)
    ut = Untokenizer()
    assert ut.compat((NEWLINE, ""), [(NAME, "hello"), (NEWLINE, "")]) is None
    assert ut.compat((NEWLINE, ""), [(NAME, "hello"), (NEWLINE, ""), (INDENT, "")]) is None



# Generated at 2022-06-21 10:25:38.784694
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from test.test_tokenize import Untokenizer
    u = Untokenizer()
    toks = [
        (token.NAME, "spam"),
        (token.NAME, "Eggs"),
        (token.NEWLINE, "\n"),
        (token.INDENT, "    "),
        (token.NAME, "class"),
        (token.NAME, "Ham"),
        (token.NEWLINE, "\n"),
        (token.DEDENT, ""),
        (token.NAME, "Ham"),
    ]
    output = u.compat(toks[3], toks[3:])
    assert output == "    class Ham\nHam\n"



# Generated at 2022-06-21 10:25:49.592866
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untokenizer = Untokenizer()
    tokens = [
        (1, "a"),
        (2, "b"),
        (0, ""),
        (3, "c"),
        (0, ""),
        (4, "d"),
        (0, ""),
        (5, "e"),
        (0, ""),
        (6, "f"),
        (0, ""),
        (0, ""),
        (7, "g"),
        (0, ""),
        (0, ""),
        (8, "h"),
        (0, ""),
        (0, ""),
        (9, "i"),
    ]

# Generated at 2022-06-21 10:26:02.398239
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((2,0))
    assert u.tokens == ['\n']
    u.add_whitespace((2,5))
    assert u.tokens == ['\n', ' ' * 5]
    u.add_whitespace((1,6))
    assert u.tokens == ['\n', ' ' * 5, ' ']
    u.add_whitespace((1,0))
    assert u.tokens == ['\n', ' ' * 5, ' ']
    u.add_whitespace((0,0))
    assert u.tokens == ['\n', ' ' * 5, ' ']

# Generated at 2022-06-21 10:26:06.752078
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield bytes("# -*- coding: utf-8 -*-\n", "ASCII")
        yield bytes("# ☃\n", "UTF-8")

    encoding, _ = detect_encoding(readline)
    assert encoding == "utf-8"

    def readline():
        yield bytes("# -*- coding: latin-1 -*-\n", "ASCII")
        yield bytes("# ☃\n", "latin-1")

    encoding, _ = detect_encoding(readline)
    assert encoding == "iso-8859-1"

    def readline():
        yield bytes("# ☃\n", "UTF-8")

    encoding, _ = detect_encoding(readline)
    assert encoding == "utf-8"


# Generated at 2022-06-21 10:26:13.845342
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    toklist = [(NUMBER, "3"), (NAME, "a")]
    assert untok.compat((NUMBER, "3"), toklist) == None
    assert untok.tokens == ["3 "]
    assert untok.compat((NAME, "b"), toklist) == None
    assert untok.tokens == ["3 ", "b "]

# Unit tests for the Untokenizer class

# Generated at 2022-06-21 10:26:16.519502
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import tokenize
    data = b'foo = "bar"\n'
    f = io.BytesIO(data).readline
    tokenize_loop(f, tokenize.printtoken)



# Generated at 2022-06-21 10:28:10.353954
# Unit test for function generate_tokens
def test_generate_tokens():
    from token import tok_name
    from io import StringIO


# Generated at 2022-06-21 10:28:11.662282
# Unit test for function group
def test_group():
    assert group("a", "b") == "a|b"



# Generated at 2022-06-21 10:28:24.011531
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
  u=Untokenizer()
  u.compat((1,"abc"),[(2,"def")])
  assert u.tokens==["abc","def"]
  u.tokens=[]
  u.compat((1,"abc\n"),[(2,"def")])
  assert u.tokens==["abc","\n","def"]
  u.tokens=[]
  u.compat((1,"abc\n\n"),[(2,"def")])
  assert u.tokens==["abc","\n","\n","def"]
  u.tokens=[]
  u.compat((1,"abc\n\n"),[(4,"  "),(2,"def")])
  assert u.tokens==["abc","\n","\n","  ","def"]
  u

# Generated at 2022-06-21 10:28:24.980117
# Unit test for function any
def test_any():
    return any("abc")



# Generated at 2022-06-21 10:28:35.565244
# Unit test for function maybe
def test_maybe():
    print(re.compile(maybe("hello","hell")).match("hell"))
    print(re.compile(maybe("hello","hell")).match("hellllo"))
    print(re.compile(maybe("hello","hell")).match("helllllllllllllllllllllll"))
    print(re.compile(maybe("hello","hell")).match("hello"))
    print(re.compile(maybe("hello","hell")).match("hellohello"))
    print(re.compile(maybe("hello","hell")).match("hellohellohello"))
    print(re.compile(maybe("hello","hell")).match("hellohellohellohello"))
    print(re.compile(maybe("hello","hell")).match("hellhellohellohello"))

# Generated at 2022-06-21 10:28:43.423440
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    def check(start, expected):
        u.prev_row = u.prev_col = 0
        u.tokens = []
        u.add_whitespace(start)
        actual = "".join(u.tokens)
        assert actual == expected, f"{actual} != {expected}"

    yield check, (1, 0), ""
    yield check, (1, 1), " "
    yield check, (1, 2), "  "
    yield check, (2, 2), "\n  "
    yield check, (2, 0), "\n"
    yield check, (2, 1), "\n "


# Generated at 2022-06-21 10:28:49.070502
# Unit test for function untokenize
def test_untokenize():
    def _test(s, d):
        t = [tokenize.untokenize(d)]
        assert t == [s], "untokenize(%s) -> %s != %s" % (d, t, s)
        t2 = tokenize.generate_tokens(iter([s]).__next__)
        assert t2 == d, "generate_tokens(%s) -> %s != %s" % (s, t2, d)


# Generated at 2022-06-21 10:28:50.447059
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"


# Generated at 2022-06-21 10:28:54.801235
# Unit test for function maybe
def test_maybe():
    assert maybe(r"[A-Z]", r"\d") == r"([A-Z]|\d)?"
    assert maybe(r"[A-Z]") == r"[A-Z]?"
    assert maybe(r"\d") == r"\d?"


# Generated at 2022-06-21 10:28:56.756531
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass

