

# Generated at 2022-06-21 10:23:04.918135
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    it = iter([(token.NAME, 'abc', (3, 4), (3, 7), 'def')])
    untok.add_whitespace((3, 4))
    assert untok.tokens == ["    "]
    untok.tokens = []
    assert untok.compat((token.NAME, "abc"), it) is None
    assert untok.tokens == ["abc "]
    it1 = iter([(token.NEWLINE, "\n"), (token.NAME, 'abc', (3, 4), (3, 7), 'def')])
    assert untok.compat((token.NAME, "abc"), it1) is None
    assert untok.tokens == ["abc ", "   "]
    untok.tokens = []
    assert unt

# Generated at 2022-06-21 10:23:07.084100
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():

    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:23:14.964356
# Unit test for function detect_encoding
def test_detect_encoding():
    # Check the coding cookie is found for a number of encodings.
    for encoding in ['utf-8', 'utf-8-sig', 'utf-16', 'iso-8859-1', 'iso-8859-2']:
        cookie = '# coding: %s' % encoding
        comment = cookie.encode(encoding) + b'\n'
        assert detect_encoding(lambda: comment)[0] == encoding

    # Check the coding cookie is found when a bom is present.
    for encoding in ['utf-8', 'utf-16', 'iso-8859-1', 'iso-8859-2']:
        cookie = '# coding: %s' % encoding
        bom = getattr(codecs, 'BOM_%s' % encoding.upper().replace('-', '_'))
        comment = bom

# Generated at 2022-06-21 10:23:26.218303
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # test normal case
    from io import StringIO
    from .tokenize import tokenize, tok_name
    import token

    code = "if True:\n    print(1)"
    tokens: Iterator[TokenInfo] = tokenize(StringIO(code).readline)
    ut = Untokenizer()
    last_end = (1, 0)
    for tok in tokens:
        if len(tok) == 2:
            ut.compat(tok, tokens)
            break
        ut.add_whitespace(last_end)
        last_end = tok[3]
    assert ut.tokens == code.split()

    # test empty string
    ut = Untokenizer()
    ut.add_whitespace((1, 0))
    assert ut.tokens == [" " * 8]

# Generated at 2022-06-21 10:23:28.384136
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    """Test the constructor of class Untokenizer"""
    un = Untokenizer()
    assert un.__dict__ == {'tokens': [], 'prev_row': 1, 'prev_col': 0}



# Generated at 2022-06-21 10:23:40.973026
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from unittest import TestCase

    class TestCase(TestCase):
        def check_tokenize_loop(self, text, tokens):
            stream = io.StringIO(text)
            result = []

            def tokeneater(*args):
                result.append(args)

            tokenize.tokenize_loop(stream.readline, tokeneater)
            self.assertEqual(tokens, result)

        def test_syntax_error(self):
            with self.assertRaises(tokenize.TokenError):
                self.check_tokenize_loop("def f(x):\n return 1/0", [])


# Generated at 2022-06-21 10:23:42.940833
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("a", "b") == "(a|b)*"
    assert any("a", "b", "c") == "(a|b|c)*"



# Generated at 2022-06-21 10:23:52.028873
# Unit test for function detect_encoding
def test_detect_encoding():
    def easy_readline(q):
        def readline():
            assert q, "Too many readline() calls"
            try:
                return q.pop(0)
            except IndexError:
                raise StopIteration
        return readline

    def good(lines: List[bytes], expected: str) -> None:
        assert detect_encoding(easy_readline(lines)) == (expected, [])

    def bad(lines: List[bytes]) -> None:
        try:
            detect_encoding(easy_readline(lines))
        except SyntaxError:
            pass
        else:
            print(lines, "... did not raise SyntaxError")

    # Try bom
    good([b"\xef\xbb\xbf" + b"# coding: ascii"], "ascii")

# Generated at 2022-06-21 10:23:54.485107
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing:
        pass

# Utility functions

# Generated at 2022-06-21 10:23:55.424400
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError("foo")



# Generated at 2022-06-21 10:24:38.504559
# Unit test for function printtoken
def test_printtoken():
    import io
    import sys

    s = io.StringIO()
    printtoken(token.STRING, 'xyz', (1, 1), (1, 4), '')
    printtoken(token.NEWLINE, '', (1, 1), (1, 1), '')
    printtoken(token.NEWLINE, '', (1, 1), (2, 2), '')
    printtoken(token.STRING, 'xyz', (1, 1), (1, 4), '')
    printtoken(token.INDENT, '', (1, 1), (2, 2), '')
    printtoken(token.STRING, 'xyz', (1, 1), (1, 4), '')
    printtoken(token.DEDENT, '', (1, 1), (2, 2), '')

# Generated at 2022-06-21 10:24:40.003209
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:24:51.859456
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-21 10:25:03.421020
# Unit test for function tokenize
def test_tokenize():
    """Basic test of tokenize"""
    import io
    r = io.BytesIO(b"def f(x): return 'hello'*x\n")
    tokens = list(tokenize(r.readline))
    print(tokens)
    print("")

# Generated at 2022-06-21 10:25:12.261414
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize
    from typing import List

    def roundtrip(s: Text) -> Text:
        # Return the tokenized form of s, untokenized
        f = io.StringIO(s)
        alltokens = list(tokenize.generate_tokens(f.readline))
        f.close()
        newcode = untokenize(alltokens)
        return newcode

    def compare(s: Text) -> None:
        # Verify that round-tripping is idempotent for s
        assert roundtrip(s) == s


# Generated at 2022-06-21 10:25:22.686315
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    tokens = [("KEYWORD", "def"), ("NAME", "f"), ("OP", "("), ("OP", ")"), ("OP", ":")]
    u.add_whitespace((1, 0))
    assert u.tokens == [""]
    for t in tokens:
        u.add_whitespace((1, 2))
    assert u.tokens == ["", "  ", "  ", "  ", "  ", ""]
    u.prev_row = 1
    u.prev_col = 2
    assert u.untokenize(tokens) == "def f(): "



# Generated at 2022-06-21 10:25:34.563684
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    import unittest
    import io
    import tokenize
    class Test_untokenize(unittest.TestCase):
        def setUp(self) -> None:
            def get_tokens(
                source: str,
            ) -> Iterator[Union[Tuple[int, Text, Coord, Coord, Text], Tuple[int, Text]]]:
                reader = io.BytesIO(bytes(source, "utf-8"))
                for token in tokenize.generate_tokens(reader.readline):
                    yield token
            self.string_tokens = get_tokens
        def test_add_whitespace(self):
            untokenizer = tokenize.Untokenizer()
            # assert first element of tuple start is row number, second is column number

# Generated at 2022-06-21 10:25:41.986353
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    tokens = [(0, "def"), (1, " "), (2, "f"), (3, "("), (0, "x"), (3, ")"), (4, ":"), (5, "\n"), (1, " "), (1, " "), (0, "a"), (1, " "), (0, "="), (1, " "), (2, "1"), (4, "\n"), (0, "x"), (1, " "), (0, "="), (1, " "), (0, "x"), (1, " "), (0, "+"), (1, " "), (0, "a"), (4, "\n"), (6, "")]
    print(u.untokenize(tokens))

# Generated at 2022-06-21 10:25:51.815471
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from tokenize import generate_tokens, untokenize, INDENT, DEDENT, COMMENT
    with open("untokenize_test.txt", "w") as f:
        f.write('def f(x):\n    # comment\n    return x + 1\n')
    with open("untokenize_test.txt") as f:
        t = [token for token in generate_tokens(StringIO(f.read()).readline)]
    with open("untoken_test.py", "w") as f:
        f.write(untokenize(t))
    assert open("untokenize_test.txt", "r").read() == open("untoken_test.py", "r").read()
    # test if INDENT and DEDENT tokens are generated properly

# Generated at 2022-06-21 10:25:56.893256
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import pytest
    test_input = "def to_str(x): return str(x)\n"
    g = tokenize_loop(test_input.splitlines(keepends=True).__next__, printtoken)
    pytest.skip("Unreachable code")



# Generated at 2022-06-21 10:26:31.481620
# Unit test for function group
def test_group():
    assert group("hey") == "hey"  # singleton
    assert group("hey", "ho") == "(hey|ho)"  # two only
    assert group("hey", "ho", "let's go") == "(hey|ho|let's go)"  # three only
    return "and that's all, folks!"



# Generated at 2022-06-21 10:26:33.355841
# Unit test for function tokenize
def test_tokenize():
    input_lines = iter(
        """Hello
"Hello"
'Hello'
'''Hello'''
"""
        .split("\n")
    )

    def readline():
        try:
            return next(input_lines)
        except StopIteration:
            return ""

    tokenize(readline, printtoken)



# Generated at 2022-06-21 10:26:36.106635
# Unit test for function group
def test_group():
    # import re
    assert re.match(group('a', '(b|c)', 'd'), 'ad')
    assert not re.match(group('a', '(b|c)', 'd'), 'abd')
    assert not re.match(group('a', '(b|c)', 'd'), 'ab')


# Generated at 2022-06-21 10:26:42.223183
# Unit test for function tokenize
def test_tokenize():

    def tokeneater(type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
        (srow, scol) = xxx_todo_changeme2
        (erow, ecol) = xxx_todo_changeme3
        print("%d,%d-%d,%d:\t%s\t%s" % (srow, scol, erow, ecol, tok_name[type], repr(token)))

    import io

    import tokenize as tokenize_module


# Generated at 2022-06-21 10:26:54.938432
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from io import StringIO
    from token import NAME

    s = "for i in range(10): print(i)"
    stream = StringIO(s)
    tokenize_loop(stream.readline, printtoken)

# Generated at 2022-06-21 10:27:07.121350
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from blib2to3.pygram import python_symbols as syms
    ul = Untokenizer()

# Generated at 2022-06-21 10:27:15.982367
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.add_whitespace((1, 0))
    assert u.tokens[0] == ""
    u.tokens = []
    u.add_whitespace((1, 1))
    assert u.tokens[0] == " "
    u.tokens = []
    u.add_whitespace((1, 2))
    assert u.tokens[0] == "  "
    u.tokens = []
    u.add_whitespace((2, 1))
    assert u.tokens[0] == "\n "
    u.tokens = []
    u.add_whitespace((3, 1))
    assert u.tokens[0]

# Generated at 2022-06-21 10:27:24.112774
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untokenizer = Untokenizer()
    untokenizer.add_whitespace((1, 0))
    untokenizer.add_whitespace((2, 0))
    assert untokenizer.tokens == ["\n"]
    untokenizer.add_whitespace((2, 5))
    assert untokenizer.tokens == ["\n", "     "]
    untokenizer.add_whitespace((1, 10))
    assert untokenizer.tokens == ["\n", "     ", "          "]



# Generated at 2022-06-21 10:27:35.160427
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
    import tokenize
    result = []
    readline = io.BytesIO(b'foo = "bar"\nbaz = 1').readline
    type = token.STRING
    token = b'foo'
    start = (1, 0)
    end = (1, 3)
    line = b'foo = "bar"\n'
    result.append((type, token, start, end, line))
    type = token.OP
    token = b'='
    start = (1, 4)
    end = (1, 5)
    line = b'foo = "bar"\n'
    result.append((type, token, start, end, line))
    type = token.STRING
    token = b'"bar"'
    start = (1, 6)

# Generated at 2022-06-21 10:27:46.546568
# Unit test for function printtoken
def test_printtoken():
    print = printtoken
    print(1, "yep", (4, 5), (2, 3), "some text")
    print(1, "yep", (4, 5), (2, 3), (b"some text"))

# A table identifying binary operators
# and their priority.  Based on:
# https://docs.python.org/3.4/reference/expressions.html#operator-precedence
#
# Note: if you change this table, it also needs to be changed in
#       blib2to3.fixer_util.precedence

# Generated at 2022-06-21 10:28:17.297114
# Unit test for function untokenize
def test_untokenize():
    iterable = [
        (1, "test"),
        (2, "test"),
        (0, "test"),
        (1, "test"),
        (1, "test"),
        (3, "test"),
        (4, "test"),
        (0, "test"),
        (4, "test"),
        (4, "test"),
    ]
    assert untokenize(iterable) == "test testtest\ntesttest"



# Generated at 2022-06-21 10:28:19.552249
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError(3)
    except TokenError:
        pass



# Generated at 2022-06-21 10:28:29.566626
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from io import StringIO
    from unittest import skipIf
    from .support import import_fresh_module
    from .support import import_module
    from .support import run_unittest
    from .support import TESTFN

    mod = import_fresh_module("blib2to3.pgen2.tokenize", fresh=["blib2to3"])
    gen = generate_tokens(StringIO("def f(): a = 1").readline)
    untok = mod.Untokenizer()
    result = untok.compat(next(gen), gen)
    with open(TESTFN, "w") as f:
        f.write(result)

# Generated at 2022-06-21 10:28:39.659184
# Unit test for function group
def test_group():
    eq = assert_equal

    eq(group(r"a", r"def"), r"(a|def)")
    eq(group(r"a", "def"), r"(a|def)")
    eq(group("a", r"def"), r"(a|def)")
    eq(group("a", "def"), r"(a|def)")
    eq(group(r"a"), r"a")
    eq(group("a"), r"a")
    eq(group(r"a|def"), r"a|def")
    eq(group("a|def"), r"a|def")
    eq(group(r"(a)"), r"\((a)\)")
    eq(group("(a)"), r"\((a)\)")

NL = r"\n|\r\n?"

# When

# Generated at 2022-06-21 10:28:44.036792
# Unit test for function untokenize
def test_untokenize():
    tokens = [
        (NUMBER, "1"),
        (NAME, "a"),
        (OP, "+"),
        (NUMBER, "2"),
        (OP, "*"),
        (NAME, "a"),
        (NEWLINE, "\n"),
        (NAME, "if"),
        (NAME, "a"),
        (OP, ":"),
        (NEWLINE, "\n"),
        (INDENT, "    "),
        (NAME, "print"),
        (NAME, "a"),
        (NAME, "+"),
        (NUMBER, "2"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
        (NAME, "print"),
        (NAME, "a"),
        (NEWLINE, "\n"),
    ]

# Generated at 2022-06-21 10:28:56.176973
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 0
    u.tokens = []

    u.add_whitespace((1, 0))
    assert u.tokens == []

    u.add_whitespace((1, 1))
    assert u.tokens == [" "]

    u.tokens = []
    u.add_whitespace((1, 5))
    assert u.tokens == [" ", " ", " ", " ", " "]

    u.tokens = []
    u.add_whitespace((2,0))
    assert u.tokens == []

    u.tokens = []
    u.add_whitespace((2, 1))
    assert u.tokens == [" "]


# Generated at 2022-06-21 10:28:58.143465
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"

# Helper for _compile

# Generated at 2022-06-21 10:29:02.397782
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    toks = Untokenizer()
    toks.tokens = ["hi"]
    toks.prev_row = 1
    toks.prev_col = 0
    assert toks.tokens == ["hi"]
    assert toks.prev_row == 1
    assert toks.prev_col == 0



# Generated at 2022-06-21 10:29:14.680516
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    test_tokens = [
        (tokenize.COMMENT, "hi"),
        (tokenize.NAME, "def"),
        (tokenize.OP, "("),
        (tokenize.NAME, "f"),
        (tokenize.OP, ")"),
        (tokenize.OP, ":"),
        (tokenize.COMMENT, " comment"),
        (tokenize.NL, "\n    "),
        (tokenize.COMMENT, " more comment"),
        (tokenize.NL, "\n"),
        (tokenize.NL, "\n"),
        (tokenize.NAME, "return"),
        (tokenize.NAME, "x"),
        (tokenize.COMMENT, " comment"),
        (tokenize.NL, "\n"),
    ]
    untok.compat

# Generated at 2022-06-21 10:29:15.625253
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    Untokenizer()



# Generated at 2022-06-21 10:29:53.345143
# Unit test for function any
def test_any():
    assert any("a", "b", "c") == "(a|b|c)*"



# Generated at 2022-06-21 10:29:59.346293
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import tokenize

    def tokeneater(type_: int, token: str, start: Coord, end: Coord, line: str) -> None:
        pass

    with open("lib2to3/pygram.py", "r") as file:
        tokenize.tokenize(file.readline, tokeneater)



# Generated at 2022-06-21 10:30:06.163821
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        if not test_data:
            raise StopIteration
        return test_data.pop(0)

    test_data = [b'# -*- coding: latin-1 -*-\n']
    assert detect_encoding(readline) == ('iso-8859-1', [])

    test_data = [b'# coding: latin-1\n']
    assert detect_encoding(readline) == ('iso-8859-1', [])

    test_data = [b'\x1a\n']  # Ctrl+Z
    assert detect_encoding(readline) == ('ascii', [b'\x1a\n'])

    test_data = [b'# coding: latin-1\n', b'\x1a\n']
    assert detect

# Generated at 2022-06-21 10:30:10.154032
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("foo message")
    except TokenError as exc:
        assert str(exc) == "foo message"
    else:
        assert False, "TokenError did not raise"



# Generated at 2022-06-21 10:30:18.509211
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pytree import Leaf, type_repr
    from blib2to3.pgen2.token import tok_name
    from io import StringIO
    from string import whitespace
    import pickle
    from pickletools import optimize


    def untokenize(iterable):
        from untokenize import Untokenizer, tok_name
        tokens = []
        prev_row = 1
        prev_col = 0
        indents = []
        toks_append = tokens.append
        for tok in iterable:
            toknum, tokval = tok[:2]
            if toknum in (NAME, NUMBER, ASYNC, AWAIT):
                tokval += " "



# Generated at 2022-06-21 10:30:28.147545
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
  from .tokenize_rt import generate_tok
  from io import StringIO
  s = StringIO()
  s.write("if 1:")
  s.write("\n  print 'spam'")
  s.write("\nelse:")
  s.write("\n  print 'eggs'")
  s.seek(0)
  u = Untokenizer()
  u.compat(generate_tok(s.readline), generate_tok(s.readline))
  assert u.tokens == ['if 1:', '\n', '  print ', "'", 'spam', "'", '\n', 'else:', '\n', '  print ', "'", 'eggs', "'"]



# Generated at 2022-06-21 10:30:37.759058
# Unit test for method untokenize of class Untokenizer

# Generated at 2022-06-21 10:30:49.388070
# Unit test for function tokenize
def test_tokenize():
    import io
    import token
