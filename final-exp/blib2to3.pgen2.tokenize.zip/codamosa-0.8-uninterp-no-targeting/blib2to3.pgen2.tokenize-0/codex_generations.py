

# Generated at 2022-06-21 10:22:56.872237
# Unit test for function untokenize
def test_untokenize():
    def check(input, output):
        result = untokenize(input)
        if result != output:
            print("Source: %r" % input)
            print("Expected: %r" % output)
            print("Received: %r" % result)
    check([(1, "")], "")
    check([(1, "abc")], "abc")
    check([(1, "a"), (1, "b"), (1, "c")], "abc")
    check([(1, "a"), (0, " "), (1, "b"), (0, " "), (1, "c")], "a b c")

# Generated at 2022-06-21 10:23:05.320306
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    "Verify method untokenize of class Untokenizer"
    ul = Untokenizer()
    info = [(tokenize.NUMBER, '1'),
            (tokenize.NUMBER, '2'),
            (tokenize.OP, '+'),
            (tokenize.NUMBER, '3'),
            (tokenize.OP, '*'),
            (tokenize.LPAR, '('),
            (tokenize.STRING, "'four'"),
            (tokenize.RPAR, ')'),
            (tokenize.NEWLINE, '\n'),
            (tokenize.NAME, 'pow'),
            (tokenize.OP, '='),
            (tokenize.NAME, 'pow'),
            (tokenize.NAME, 'sendmoremoney')
            ]
    text = ul.untokenize(iter(info))
   

# Generated at 2022-06-21 10:23:07.535387
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "123", (0, 0), (0, 3), "")


# Generated at 2022-06-21 10:23:13.485026
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    untok.prev_row = 1
    untok.prev_col = 0
    start = (1, 1)
    untok.add_whitespace(start)
    assert untok.tokens == []
    start = (1, 10)
    untok.add_whitespace(start)
    assert untok.tokens == [" " * 9]
    start = (2, 0)
    untok.add_whitespace(start)
    assert untok.tokens == [" " * 9]



# Generated at 2022-06-21 10:23:25.289099
# Unit test for function printtoken
def test_printtoken():
    test_cases = [
        ("#def f():\n    pass",
         ['# 1,0-1,7:\tCOMMENT\t#def f():\n', '    1,8-1,11:\tINDENT\t', '\n', '    1,11-1,14:\tNAME\tpass', '\n', '    1,14-1,18:\tDEDENT\t']),
    ]
    for test in test_cases:
        lines = test[0].split("\n")
        ans = test[1]
        results = list()

# Generated at 2022-06-21 10:23:29.581605
# Unit test for function group

# Generated at 2022-06-21 10:23:31.205615
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:23:37.186012
# Unit test for function generate_tokens
def test_generate_tokens():
    with open("tokenize_tests.txt", "r") as f:
        lines = f.read().split("\n")
    f.close()

    def gen_tokens(readline):
        for line in lines:
            if not line:
                continue
            try:
                tup = ast.literal_eval(line)
            except:
                print("failed: %r" % line)
                raise
            yield GoodTokenInfo(*tup)

    failures = 0
    for x, y in zip_longest(gen_tokens(None), generate_tokens(iter(lines).__next__)):
        if x != y:
            print("failed: %r != %r" % (x, y))
            failures += 1
    assert not failures



# Generated at 2022-06-21 10:23:43.963743
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from blib2to3.pygram import python_grammar

    def tokenize_loop(readline, tokeneater):
        for token_info in generate_tokens(readline):
            tokeneater(*token_info)

    def tokeneater(*args):
        print(args)

    tokenize_loop(iter(['if a > b:']).__next__, tokeneater)



# Generated at 2022-06-21 10:23:52.601743
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    ut = Untokenizer()
    ut.prev_row = 1
    ut.prev_col = 2
    ut.tokens = ["a", "b"]
    ut.add_whitespace((1, 5))
    assert ut.tokens == ["a", "b", "   "]
    ut.add_whitespace((2, 0))
    assert ut.tokens == ["a", "b", "   ", "\n"]
    ut.add_whitespace((2, 5))
    assert ut.tokens == ["a", "b", "   ", "\n", "     "]
    ut.add_whitespace((3, 5))
    assert ut.tokens == ["a", "b", "   ", "\n", "     ", "\n", "     "]
    ut.add_whites

# Generated at 2022-06-21 10:24:37.364544
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    untok = Untokenizer()
    assert untok.tokens == []
    untok.prev_row = 1
    untok.prev_col = 0
    untok.add_whitespace((1,0))
    assert untok.tokens == []
    untok.add_whitespace((1,1))
    assert untok.tokens == [" "]
    untok.add_whitespace((2,2))
    assert untok.tokens == [" ", "\n", " "]
    untok.add_whitespace((2,0))
    assert untok.tokens == [" ", "\n", " "]
    untok.add_whitespace((2,1))
    assert untok.tokens == [" ", "\n", " ", " "]

# Generated at 2022-06-21 10:24:45.185705
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline_generator(string):
        for line in string.splitlines(keepends=True):
            yield line

    token_iter = generate_tokens(readline_generator("print(1+1)\n"))
    tokens = list(token_iter)
    tokenize_loop(readline_generator("print(1+1)\n"), printtoken)
    for (t1, t2) in zip(tokens, token_iter):
        assert t1 == t2



# Generated at 2022-06-21 10:24:52.826331
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.add_whitespace((1,2))
    assert u.tokens == ["  "]
    u.tokens = []
    u.prev_row = 2
    u.prev_col = 4
    u.add_whitespace((2,5))
    assert u.tokens == [" "]
    u.add_whitespace((2,5))
    assert u.tokens == [" ", " "]
    u.add_whitespace((3,5))
    assert u.tokens == [" ", " ", "\n"]



# Generated at 2022-06-21 10:25:03.938237
# Unit test for function generate_tokens
def test_generate_tokens():
    # To work, the function should be able to turn the following string
    # into a series of tokens, which it returns one by one:
    #                                 STRING   NAME       OP
    #                                        'x = "a b" # c'
    # Generate tokens:
    r = generate_tokens(iter(['x = "a b" # c']).__next__)
    # Verify the first token is what we expect:
    assert next(r) == (STRING, 'x', (1, 0), (1, 1), 'x = "a b" # c')
    # Make sure the rest of the tokens are as expected:
    result = list(r)

# Generated at 2022-06-21 10:25:05.594026
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    return isinstance(StopTokenizing(0, 1, "text"), Exception)



# Generated at 2022-06-21 10:25:12.712909
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import sys, StringIO, tokenize

    stream = StringIO.StringIO(
        '''if 1:
        a = 2
        if 1:
            b = 3
''')
    out = StringIO.StringIO()
    tokenize_loop(stream.readline, tokenize.printtoken)

# Generated at 2022-06-21 10:25:16.772950
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def readline():
        yield "a + b"
    def tokeneater(*args):
        print(args)
    tokenize_loop(readline, tokeneater)
# Backwards compatible interface

# Generated at 2022-06-21 10:25:19.188671
# Unit test for function printtoken
def test_printtoken():
    printtoken(2, 3, (4, 5), (6, 7), 8)



# Generated at 2022-06-21 10:25:23.729743
# Unit test for function maybe
def test_maybe():
    re = maybe("a", "b")
    m = re.match("a")
    assert m is not None
    m.end() == 1
    m = re.match("")
    assert m is not None
    m.end() == 0


# Generated at 2022-06-21 10:25:35.089469
# Unit test for function untokenize
def test_untokenize():
    def compare(s1, s2):
        if s1 != s2:
            s1, s2 = list(s1), list(s2)
            for i in range(max(len(s1), len(s2))):
                if s1[i] != s2[i]:
                    print(s1[max(i-5,0):i+5])
                    print(s2[max(i-5,0):i+5])
                    break
            assert s1 == s2
    def roundtrip(s1):
        compare(s1, untokenize(generate_tokens(iter(s1.splitlines(1)).__next__)))
    roundtrip(u"def f(x): return x**2")
    roundtrip(u"def f(x):\n    return x**2")


# Generated at 2022-06-21 10:27:13.227271
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    readline = io.BytesIO("\n\n# coding=utf8\n").readline
    encoding, lines = detect_encoding(readline)
    assert encoding == "utf-8"
    assert lines == [b"\n", b"\n"]

    readline = io.BytesIO("\r\n\r\n# coding:ascii\r\n").readline
    encoding, lines = detect_encoding(readline)
    assert encoding == "ascii"
    assert lines == [b"\r\n", b"\r\n"]

    readline = io.BytesIO("\n\n# coding=iso-latin-1\n").readline
    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
   

# Generated at 2022-06-21 10:27:16.915253
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    # Test constructor
    untokenize = Untokenizer().untokenize



# Generated at 2022-06-21 10:27:23.272459
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest

    class Stream:
        def __init__(self, data):
            self.data = data
            self.pos = 0

        def readline(self):
            if self.pos >= len(self.data):
                return ""
            result = self.data[self.pos]
            self.pos += 1
            return result

    class Dummy:
        def __init__(self):
            self.tokens = []

        def tokenize(self, token_info):
            self.tokens.append(token_info)

    class TestTokenizeLoop(unittest.TestCase):
        def test_tokenize_loop(self):
            text = io.StringIO("def f(): pass\nfor i in range(10): pass\n")
            dummy = Dummy()
           

# Generated at 2022-06-21 10:27:34.314929
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    # We can't use the test string given in the docstring, since it
    # uses triple-quote strings not supported by the tokenize module.
    s = "a = u'abc'\n"
    f = io.StringIO(s)
    l = []
    tokenize_loop(f.readline, l.append)

# Generated at 2022-06-21 10:27:41.482251
# Unit test for function tokenize_loop
def test_tokenize_loop():
    string_gen = ['def f(x: int) -> int:', '  return x + 4']
    def readline():
        return string_gen.pop()

    def tokeneater(*args):
        print('{}'.format(args))

    tokenize_loop(readline, tokeneater)
    # assert tokeneater('NAME', 'def', (1, 0), (1, 3), 'def f(x: int) -> int:')
test_tokenize_loop()



# Generated at 2022-06-21 10:27:45.639766
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing(1, 2)
    except StopTokenizing as e:
        # Python 2:  e.args = ((1, 2),)
        assert e.args == (1, 2)



# Generated at 2022-06-21 10:27:51.688899
# Unit test for function maybe
def test_maybe():
    assert(re.match("(:?)", ":foo::").span(1) == (0, 0))
    assert(re.match("(:?)", ":foo::").span(1) == (0, 0))
    assert(re.match("((:?))", ":foo::").span(1) == (0, 0))
    assert(re.match("((:?))", ":foo::").span(2) == (0, 0))
    assert(re.match(maybe(":"), ":foo::").span(1) == (0, 0))
    assert(re.match(maybe(":"), ":foo::").span(1) == (0, 0))



# Generated at 2022-06-21 10:27:52.785454
# Unit test for constructor of class TokenError
def test_TokenError():
    token_error = TokenError()



# Generated at 2022-06-21 10:28:03.351184
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 4
    u.prev_col = 20
    u.add_whitespace((4, 20))
    assert len(u.tokens) == 0
    u.add_whitespace((4, 21))
    assert u.tokens == [" "]
    u.tokens = []
    u.add_whitespace((5, 15))
    assert u.tokens == ["\n", "               "]
    u.tokens = []
    u.add_whitespace((3, 15))
    assert u.tokens == ["\n" * 2, "               "]



# Generated at 2022-06-21 10:28:15.175018
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    #    simple tests
    u = Untokenizer()
    eq = u.untokenize([("word", "spam"), (" ", " "), ("word", "eggs")])
    assert eq == "spam eggs"
    u = Untokenizer()
    eq = u.untokenize([("word", "1"), (" ", " "), ("word", "2")])
    assert eq == "1 2"
    #    newlines are tricky, and the auto-inserted indentation is the
    #    trickiest part
    u = Untokenizer()
    eq = u.untokenize(
        [("word", "if"), (" ", " "), ("word", "a"), (" ", " "), ("word", "b")]
    )
    assert eq == "if a b"
    u = Untokenizer()

# Generated at 2022-06-21 10:30:31.832261
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    pass



# Generated at 2022-06-21 10:30:42.311538
# Unit test for function generate_tokens
def test_generate_tokens():
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    source = "1 + 1\n'a'"  # add some parens to make it more interesting
    g = generate_tokens(iter(source.splitlines(True)).next)
    result = []
    for toknum, tokval, _, _, _ in g:
        result.extend([toknum, tokval])
    # This should produce the same tokens as in this test case

# Generated at 2022-06-21 10:30:44.197776
# Unit test for constructor of class TokenError
def test_TokenError():
    token_error = TokenError("message")
    assert str(token_error) == "message"

