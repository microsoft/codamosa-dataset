

# Generated at 2022-06-21 10:21:50.956747
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    iterable = [
        (NUMBER, '1', (1, 0), (1, 1), '1'),
        (NUMBER, '2', (1, 2), (1, 3), '1'),
        (NUMBER, '3', (1, 4), (1, 5), '1'),
        (NUMBER, '4', (1, 6), (1, 7), '1'),
    ]

    t = u.untokenize(iterable)
    assert t == "1 2 3 4"


#
# End unit test


# Generated at 2022-06-21 10:21:51.879356
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    pass



# Generated at 2022-06-21 10:21:56.325328
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        for line in _test_lines:
            yield line

    def readline_random_eol():
        for line in _test_lines_random_eol:
            yield line

    def readline_fake_bom():
        for line in _test_lines_fake_bom:
            yield line

    def readline_fake_bom_random_eol():
        for line in _test_lines_fake_bom_random_eol:
            yield line


# Generated at 2022-06-21 10:22:00.687379
# Unit test for function group
def test_group():
    assert group("a") == "a"
    assert group("a", "b") == "(a|b)"
    assert group("a", "b", "cd") == "(a|b|cd)"

# Helper function for _compile

# Generated at 2022-06-21 10:22:03.307845
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    decode_tokens = Grammar().decode_tokens
    encode_tokens = Untokenizer().untokenize
    for test in decode_tokens.tests:
        itoks = decode_tokens(test.inp)
        assert test.out == encode_tokens(itoks)


# Generated at 2022-06-21 10:22:07.539526
# Unit test for function untokenize
def test_untokenize():
    import token
    import io
    import tokenize
    f = io.StringIO('def foo(x):\n    return x\n')
    tokens = tokenize.generate_tokens(f.readline)
    print(tokens)
    print(list(tokens))
    result = untokenize(tokens)
    print(result)


test_untokenize()

# --- end of copied code ---



# Generated at 2022-06-21 10:22:09.167426
# Unit test for function printtoken
def test_printtoken():
    printtoken(
        54,
        " \"'\t\n\r\v\f\\",
        (6, 6),
        (6, 6),
        " \"'\t\n\r\v\f\\",
    )



# Generated at 2022-06-21 10:22:14.023672
# Unit test for function untokenize
def test_untokenize():
    eq = assertEqual
    u = untokenize
    eq(u([(1, "def"), (1, " "), (1, "f"), (1, "("), (3, "):"),
         (4, "\n"), (0, " "), (0, " "), (0, " "), (5, "return"),
         (1, " "), (6, "0")]), "def f():\n   return 0")

# Generated at 2022-06-21 10:22:24.407581
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    d1 = "blah"
    d2 = "blah #bleh"
    d3 = "# YES\nblah"
    d4 = "if x:\n    blah"
    d5 = 'r"\\\n"'
    d6 = "''\n"
    d7 = "'''\\\n'''"
    d8 = '"""\\\n"""'
    d9 = "3$"
    d10 = "3$#"
    d11 = "3$#: blah\n"
    d12 = "3$#: blah\n    blah"
    d13 = "3$#: blah\\\n    blah"
    d14 = "()"
    d15 = "((()))"
    d16 = "((())) #"
    d17

# Generated at 2022-06-21 10:22:26.510579
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-21 10:23:35.288764
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        import sys

        tb = sys.exc_info()[2]
        tokenize_tb(tb, None)


STRING = token.STRING

# Generated at 2022-06-21 10:23:47.366518
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "5", (0, 0), (2, 3), "")


# table for tokenize()

# Blank lines are ignored by tokenize
blankline = re.compile(r"^[ \t]*(?:\r\n|\r|\n)?$")

# Each entry consists of the token type, a regular expression for the
# token text, and a handler subroutine. The order in which the entries
# appear matters; a token matches the first pattern that fits.  handler
# is passed the match object and returns a tuple containing the token
# type, and the text. The resulting token is a pair (type, text).

# startprogs is a list of (type, regex, func) tuples. The first regex
# that matches determines the token type. The func is passed the match
# object and returns a

# Generated at 2022-06-21 10:23:58.812352
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def my_readline():
        yield "while 1:"
        yield "  x = 2"
        yield ""
    def my_tokeneater(*args):
        printtoken(*args)
    tokenize_loop(my_readline(), my_tokeneater)
    # =>
    # 2,0-2,5:	NAME	'while'
    # 2,6-2,8:	NUMBER	'1'
    # 2,8-2,9:	OP	':'
    # 3,0-3,1:	INDENT	''
    # 3,2-3,3:	NAME	'x'
    # 3,4-3,5:	OP	'='
    # 3,6-3,7:	NUMBER	'2'
    # 4,0-4,0:	

# Generated at 2022-06-21 10:24:03.064506
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    """ Test that StopTokenizing(msg) works."""
    try:
        raise StopTokenizing("foo")
    except StopTokenizing as e:
        if str(e) != "foo":
            raise ValueError("StopTokenizing(msg) failed")



# Generated at 2022-06-21 10:24:11.419519
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import re
    import tokenize

    s = "def f(x):\n    return 2*x\n"
    f = io.StringIO(s).readline
    t = tokenize.generate_tokens(f)
    u = Untokenizer()
    new_s = u.untokenize(t)
    assert re.match(s, new_s)
    print(repr(new_s))
    t = tokenize.generate_tokens(f)
    new_s = u.untokenize(t)
    assert new_s == ""



# Generated at 2022-06-21 10:24:13.872370
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    s = StopTokenizing()
    assert isinstance(s, Exception)
    # Check that the constructor is indeed empty
    assert not vars(s)



# Generated at 2022-06-21 10:24:14.812343
# Unit test for method compat of class Untokenizer

# Generated at 2022-06-21 10:24:21.445371
# Unit test for function printtoken
def test_printtoken():
    test_input = [
        (1, 0, 1, 3, OP, "("),
        (1, 4, 1, 20, NAME, "test_function"),
        (1, 21, 1, 22, OP, ")"),
        (2, 0, 2, 1, OP, "{"),
        (3, 4, 3, 7, NAME, "pass"),
        (4, 0, 4, 1, OP, "}"),
    ]
    from io import StringIO
    from contextlib import redirect_stderr

    f = StringIO()
    with redirect_stderr(f):
        for token in test_input:
            printtoken(*token, "")
    output = f.getvalue().strip()

# Generated at 2022-06-21 10:24:23.245323
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:24:34.614912
# Unit test for function tokenize
def test_tokenize():
    from blib2to3.tests.test_pytree import generate_tokens
    from io import StringIO

    def compare(input, output):
        tokengen = generate_tokens(StringIO(input).readline)
        for t in generate_tokens(StringIO(input).readline):
            printtoken(*t)
        result = "".join(t[4] for t in tokengen)
        assert result == output, "%r != %r" % (result, output)


# Generated at 2022-06-21 10:27:02.677112
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    global StopTokenizing
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass


# Helper for tokenize

# Generated at 2022-06-21 10:27:13.368177
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.tokens = ["This", " ", "is", " ", "a", "\n"]
    u.prev_row = 1
    u.prev_col = 5
    u.add_whitespace((1, 7))
    assert u.tokens == ["This", " ", "is", " ", "a", "\n", "  "]
    u.add_whitespace((1, 8))
    assert u.tokens == ["This", " ", "is", " ", "a", "\n", "  ", " "]
    u.add_whitespace((2, 0))
    assert u.tokens == ["This", " ", "is", " ", "a", "\n", "  ", " ", "\n"]
    u.add_whitespace((2, 3))


# Generated at 2022-06-21 10:27:26.579379
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    def stest(**kwargs):
        try:
            raise StopTokenizing(**kwargs)
        except StopTokenizing as e:
            for arg, value in kwargs.items():
                if getattr(e, arg) != value:
                    raise AssertionError(f"{arg}: {value!r} != {getattr(e, arg)!r}")

    stest()
    stest(msg=None)
    stest(msg="")
    stest(msg="foo")
    stest(msg="foo", start=None)
    stest(msg="foo", start=(1, 0))
    stest(msg="foo", start=(1, 0), end=None)
    stest(msg="foo", start=(1, 0), end=(2, 0))

# Generated at 2022-06-21 10:27:37.545917
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    # initial row > prev. row
    untokenizer = Untokenizer()
    untokenizer.add_whitespace((3,0))
    assert untokenizer.tokens == ["\n\n"]
    # initial row == prev. row
    untokenizer = Untokenizer()
    untokenizer.add_whitespace((1,1))
    assert untokenizer.tokens == [" "]
    # initial column > prev. column
    untokenizer = Untokenizer()
    untokenizer.tokens.append("\n")
    untokenizer.prev_row = 2
    untokenizer.prev_col = 0
    untokenizer.add_whitespace((2,7))

# Generated at 2022-06-21 10:27:48.508775
# Unit test for function generate_tokens

# Generated at 2022-06-21 10:28:01.125177
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    class MockIterable:
        def __init__(self, iterable: Iterable[TokenInfo]) -> None:
            self.iterable = iterable
            self.i = 0

        def __iter__(self):
            return self

        def __next__(self) -> TokenInfo:
            self.i += 1
            return next(self.iterable)

    def assert_untokenize_equal(iterable, expected):
        assert (
            expected
            == "\n".join(
                _line.decode("ascii")
                for _line in Untokenizer().untokenize(MockIterable(iterable)).splitlines()
            )
        )


# Generated at 2022-06-21 10:28:10.929413
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    s = u.untokenize([(1, "hello"), (1, "world")])
    assert s == "hello world"
    u = Untokenizer()
    s = u.untokenize([(1, "hello"), (4, " "), (1, "world")])
    assert s == "hello world"
    u = Untokenizer()
    s = u.untokenize([(1, "hello"), (0, "\n"), (1, "world")])
    assert s == "hello\nworld"
    u = Untokenizer()
    s = u.untokenize([(0, "hello\nworld\n")])
    assert s == "hello\nworld\n"
    u = Untokenizer()

# Generated at 2022-06-21 10:28:17.401111
# Unit test for constructor of class TokenError
def test_TokenError():
    # Test simple instantiation
    token_err = TokenError("test")
    assert token_err is not None
    assert token_err.args == ("test",)

    # Test with positional argument
    token_err = TokenError("test", "positional")
    assert token_err is not None
    assert token_err.args == ("test", "positional")



# Generated at 2022-06-21 10:28:18.943012
# Unit test for function any
def test_any():

    assert any("a", "b") == "(a|b)*"


# Generated at 2022-06-21 10:28:29.259057
# Unit test for function printtoken
def test_printtoken():

    def test(s, result = None, **kwargs):
        import io
        f = io.StringIO(s)
        result = result or s
        g = generate_tokens(f.readline, **kwargs)
        for t in g:
            printtoken(*t)
        print()

    test('"abc\ndef"')
    test('u"abc\n  def"')
    test('ur"abc\n  def"')
    test('b"abc\n  def"')
    test('br"abc\n  def"')
    test('r"abc\n  def"')
    test('R"abc\n  def"')
    test('f"abc\n  def"')
    test('F"abc\n  def"')

# Generated at 2022-06-21 10:30:21.088403
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"


# Generated at 2022-06-21 10:30:25.334264
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing("Test StopTokenizing")
    except StopTokenizing as e:
        assert(str(e) == "Test StopTokenizing")


# Hack for python -Qnew, which doesn't like the round() builtin.



# Generated at 2022-06-21 10:30:32.749501
# Unit test for function maybe
def test_maybe():
    # Start simple
    assert maybe("a") == "(a)?", maybe("a")
    # Add two or three alternatives
    assert maybe("a", "b") == "(a|b)?", maybe("a", "b")
    assert maybe("a", "b", "c") == "(a|b|c)?", maybe("a", "c")
    # Try with a group
    assert maybe("a", group("b", "c")) == "(a|(b|c))?", maybe("a", group("b", "c"))
    assert maybe("a", group("b", "c", "d")) == "(a|(b|c|d))?", maybe("a", group("b", "c", "d"))


# Generated at 2022-06-21 10:30:41.798588
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.add_whitespace((1, 0))
    assert u.tokens == []
    u.add_whitespace((1, 1))
    u.tokens.append("foo")
    u.prev_row = 2
    u.prev_col = 3
    u.add_whitespace((2, 1))
    assert u.tokens == [" ", "foo"]
    u.add_whitespace((2, 3))
    assert u.tokens == [" ", "foo"]
    u.add_whitespace((2, 4))
    assert u.tokens == [" ", "foo", " "]



# Generated at 2022-06-21 10:30:52.167683
# Unit test for function any
def test_any():
    # This is a non-exhaustive test: the exact set of acceptable
    # whitespace chars in reStructuredText is complex, cf.
    # http://docutils.sourceforge.net/docs/ref/rst/restructuredtext.html#white-space-in-markup
    assert regex.match("abc" + any(" \t") + "def",
                       "abc \tdef")
    assert regex.match("abc" + any(" \t") + "def",
                       "abcdef")
    assert regex.match("abc" + any(" \t") + "def",
                       "abc \t \tdef")
    assert not regex.match("abc" + any(" \t") + "def",
                           "abc\tdef")
