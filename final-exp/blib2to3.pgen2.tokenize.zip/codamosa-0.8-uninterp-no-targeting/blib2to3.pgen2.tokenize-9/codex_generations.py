

# Generated at 2022-06-21 10:22:58.328877
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO

    # test encoding declaration
    src = "'''\n# coding: utf-8\n'''\npass\n"
    out = StringIO()
    tok = tokenize(StringIO(src).readline)
    tok = untokenize(encode_utf8(tok))
    out.write(tok)
    assert out.getvalue() == src

    # test encoding declaration after shebang
    src = "#!/usr/bin/env python3.5\n'''\n# coding: utf-8\n'''\npass\n"
    out = StringIO()
    tok = tokenize(StringIO(src).readline)
    tok = untokenize(encode_utf8(tok))
    out.write(tok)
    assert out

# Generated at 2022-06-21 10:22:59.449935
# Unit test for function any
def test_any():
    assert any("abc") == "(abc)*"



# Generated at 2022-06-21 10:23:04.079592
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    g = [
        (TYPE_IGNORE, ""),
        (NAME, "first_line"),
        (NEWLINE, "\n"),
        (TYPE_IGNORE, "    "),
        (NAME, "second_line"),
        (NUMBER, "123"),
        (NEWLINE, "\n"),
        (TYPE_IGNORE, ""),
        (ENDMARKER, ""),
    ]
    output = u.compat((NAME, "first_line"), iter(g))
    assert output == "first_line\n    second_line 123\n"



# Generated at 2022-06-21 10:23:07.644003
# Unit test for function any
def test_any():
    assert any('a(?:bc)?', 'xyz') == '((a(?:bc)?)|xyz)*'
    assert any('a(?:bc)?', 'xyz', flags=re.I) == '((a(?:bc)?)|xyz)*'



# Generated at 2022-06-21 10:23:11.338008
# Unit test for function tokenize
def test_tokenize():
    s = """
if 1:  # An if statement
    print 'foo'
"""
    readline = iter(s.splitlines()).__next__
    tokeneater = printtoken
    tokenize(readline, tokeneater)
test_tokenize.__test__ = False



# Generated at 2022-06-21 10:23:14.300449
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-21 10:23:25.747823
# Unit test for function untokenize
def test_untokenize():
    # Verify that empty input gives empty output
    assert untokenize([]) == ""

    # If no NEWLINE and no ENDMARKER, output should be a single line
    assert untokenize([(NAME, 'a'), (NUMBER, '1')]) == "a 1"

    # If input only contains NEWLINE and ENDMARKER, output should be blank
    assert untokenize([(ENDMARKER, ''), (NEWLINE, '\n')]) == ""

    # An optional trailing NEWLINE should be swallowed
    assert untokenize([(NAME, 'a'), (NUMBER, '1'), (NEWLINE, '\n')]) == "a 1"

    # Trailing whitespace is kept with NL token

# Generated at 2022-06-21 10:23:31.527874
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    print(u.compat((NAME, "Test1"),
                   [(NAME, "Test1"), (NAME, "Test2"), (NEWLINE, "\n"),
                    (INDENT, "    "), (NAME, "Test3"), (DEDENT, ""),
                    (NEWLINE, "\n"), (NAME, "Test4")]))


# Generated at 2022-06-21 10:23:36.966121
# Unit test for function untokenize
def test_untokenize():
    t1 = [
        (1, "def"),
        (1, " "),
        (1, "f"),
        (1, "("),
        (1, "x"),
        (0, ")"),
        (1, ":"),
        (4, "\\n"),
        (0, " "),
        (0, " "),
        (4, "\\n"),
        (0, " "),
        (0, " "),
        (0, " "),
        (1, "return"),
        (1, " "),
        (1, "x"),
        (5, "\\n"),
    ]
    s = untokenize(t1)



# Generated at 2022-06-21 10:23:48.773020
# Unit test for function generate_tokens
def test_generate_tokens():
    # Set up test inputs
    import io
    import tokenize
    sample_text = ["a = 1 + 2\n", "b = [3, 4]\n"]
    sample_stream = io.StringIO("".join(sample_text))

    # Call tested function
    token_list = generate_tokens(sample_stream.readline)

    # Test assertions
    assert next(token_list)[0] == tokenize.NAME
    assert next(token_list)[0] == tokenize.OP
    assert next(token_list)[0] == tokenize.NUMBER
    assert next(token_list)[0] == tokenize.OP
    assert next(token_list)[0] == tokenize.NUMBER
    assert next(token_list)[0] == tokenize.NEWLINE
    assert next(token_list)[0]

# Generated at 2022-06-21 10:24:14.157819
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    test_e = StopTokenizing()
    assert isinstance(test_e, StopTokenizing)



# Generated at 2022-06-21 10:24:14.757008
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    exc = StopTokenizing()
    assert exc



# Generated at 2022-06-21 10:24:21.409440
# Unit test for function untokenize

# Generated at 2022-06-21 10:24:23.675334
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    # pylint: disable=pointless-statement
    StopTokenizing  # make pyflakes happy



# Generated at 2022-06-21 10:24:28.261413
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        return b"blah blah\n"
    encoding = detect_encoding(readline)[0]
    assert encoding == "utf-8"

    def readline():
        return b"# -*- coding: Latin-1 -*-\n"
    encoding = detect_encoding(readline)[0]
    assert encoding == "iso-8859-1"

    def readline():
        return b"# vim:fileencoding=latin-1\n"
    encoding = detect_encoding(readline)[0]
    assert encoding == "iso-8859-1"

    def readline():
        return b"\xef\xbb\xbf# -*- coding: Latin-1 -*-\n"
    encoding = detect_encoding(readline)[0]

# Generated at 2022-06-21 10:24:38.539530
# Unit test for function untokenize

# Generated at 2022-06-21 10:24:50.502777
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import token
    reader = io.StringIO("abc (1)")
    tokens = generate_tokens(reader.readline)
    expected = [
        (token.NAME, "abc", (1, 0), (1, 3), "\n"),
        (token.OP, "(", (1, 3), (1, 4), "\n"),
        (token.NUMBER, "1", (1, 4), (1, 5), "\n"),
        (token.OP, ")", (1, 5), (1, 6), "\n"),
        (token.ENDMARKER, "", (1, 6), (1, 6), "\n"),
    ]
    for each, exp_token in zip(tokens, expected):
        assert each == exp_token



# Generated at 2022-06-21 10:24:58.749474
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 10
    # Move to left
    u.add_whitespace((1,9))
    assert u.tokens == []

    # Move to right
    u.add_whitespace((1,13))
    assert u.tokens == [' ' * 4]

    # Leave altogther
    u.add_whitespace((2,2))



# Generated at 2022-06-21 10:25:05.637675
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    uh = Untokenizer()
    t = [
        (None, None, None, None, ""),
        (INDENT, "    ", (1, 0), (1, 4), "    "),
        (STRING, "'\"'", (1, 4), (1, 7), "    '\"'"),
        (NEWLINE, "\n", (1, 7), (2, 0), "    '\"'\n"),
        (DEDENT, "", (2, 0), None, "    '\"'\n"),
    ]
    assert uh.untokenize(t) == "    '\"'\n"



# Generated at 2022-06-21 10:25:06.498258
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    raise NotImplementedError



# Generated at 2022-06-21 10:25:39.608762
# Unit test for function tokenize_loop
def test_tokenize_loop():
    s = b'print(1)\n'
    readline = iter(s.splitlines(keepends=True)).__next__
    t = []  # type: List[Tuple[int, Text, Coord, Coord, Text]]
    tokenize_loop(readline, t.append)

# Generated at 2022-06-21 10:25:49.530830
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    input = (
        (NAME, "Yields"),
        (OP, ","),
        (NAME, "r"),
        (OP, "="),
        (NUMBER, "1"),
        (STRING, "'abc'"),
        (NEWLINE, "\n"),
        (NAME, "print"),
        (OP, "("),
        (STRING, "'abc'"),
        (OP, ")"),
        (NEWLINE, "\n"),
        (ENDMARKER, ""),
    )
    tokoutput = ''.join(tok[1] for tok in input).replace("'", '"')
    assert u.untokenize(input) == tokoutput



# Generated at 2022-06-21 10:25:52.914446
# Unit test for function maybe
def test_maybe():
    r"""[0-9] maybe
    >>> expr = br'[0-9] maybe'
    >>> r = maybe(r'[0-9]')
    >>> p = re.compile(r)
    >>> match = p.match(expr)
    >>> assert match.group(0) == expr
    """

# Generated at 2022-06-21 10:26:05.200752
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer = Untokenizer()
    iterable = [(1, ""), (4, " ")]
    untokenizer.add_whitespace((0, 0))
    assert untokenizer.tokens == []
    untokenizer.add_whitespace((0, 2))
    assert untokenizer.tokens == ["  "]
    untokenizer.add_whitespace((0, 0))
    assert untokenizer.tokens == ["  "]
    untokenizer.add_whitespace((2, 6))
    assert untokenizer.tokens == ["  ", "      "]
    untokenizer.tokens = []
    untokenizer.prev_row = 1
    untokenizer.prev_col = 0
    untokenizer.untokenize(iterable)
    assert unt

# Generated at 2022-06-21 10:26:12.532328
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    source = u.untokenize(
        [
            (
                NUMBER,
                "123",
                (1, 0),
                (1, 3),
                "123",
            ),
            (
                NAME,
                "a",
                (1, 3),
                (1, 4),
                "a",
            ),
        ]
    )
    assert source == "123 a"



# Generated at 2022-06-21 10:26:20.585884
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    unt = Untokenizer()
    unt.prev_row = 1
    unt.prev_col = 17
    unt.add_whitespace((2, 0))
    unt.tokens.append("A")
    unt.prev_row = 2
    unt.prev_col = 1
    unt.add_whitespace((2, 1))
    unt.tokens.append("B")
    unt.prev_row = 2
    unt.prev_col = 2
    unt.add_whitespace((2, 17))
    unt.tokens.append("C")
    unt.prev_row = 2
    unt.prev_col = 18
    unt.add_whitespace((3, 0))
    unt.tokens.append("D")
    unt.prev_row = 3
    unt.prev_col

# Generated at 2022-06-21 10:26:23.743502
# Unit test for function group
def test_group():
    assert group("1", "2", "3") == "(1|2|3)"
    assert group(group("a", "b", "c"), "d") == "((a|b|c)|d)"


# Generated at 2022-06-21 10:26:26.119671
# Unit test for constructor of class TokenError
def test_TokenError():
    x = TokenError("test message")
    assert x.msg == "test message"



# Generated at 2022-06-21 10:26:31.047965
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import StringIO
    from blib2to3.pgen2.tokenize import detect_encoding

    def readline() -> bytes:
        return next(fake_readline)

    # Single line with no encoding.
    fake_readline = iter(['"x";x\n'])
    encoding, lines = detect_encoding(readline)
    assert encoding == 'utf-8'
    assert lines == [b'"x";x\n']

    # Single line with utf-8 encoding.
    fake_readline = iter(['# -*- coding: utf-8 -*-\n'])
    encoding, lines = detect_encoding(readline)
    assert encoding == 'utf-8'
    assert lines == [b'# -*- coding: utf-8 -*-\n']

   

# Generated at 2022-06-21 10:26:33.450443
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("a", "b") == "((a)|(b))*"



# Generated at 2022-06-21 10:27:12.604326
# Unit test for function tokenize_loop
def test_tokenize_loop():
    for t in [
        "",
        " ",
        " 0",
        " 1",
        "2",
        "3.0",
        "04",
        "0x5",
        "123\n",
        "a",
        "if",
        "1+1\n",
    ]:
        tokenize_loop(iter([t]).__next__, printtoken)
        print()



# Generated at 2022-06-21 10:27:14.067111
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-21 10:27:26.839274
# Unit test for function tokenize
def test_tokenize():
    def _tokenize(readline):
        lines = []

# Generated at 2022-06-21 10:27:34.270255
# Unit test for function maybe
def test_maybe():
    assert maybe("a") == "(a)?", repr(maybe("a"))
    assert maybe("a", "b", "c") == "(a|b|c)?", repr(maybe("a", "b", "c"))
    assert maybe(maybe("a", "b"), "c") == "((a|b)?|c)", repr(maybe(maybe("a", "b"), "c"))

# Note: we use unicode matching for names ("\w") but ascii matching for
# number literals.

# Generated at 2022-06-21 10:27:38.685683
# Unit test for function detect_encoding
def test_detect_encoding():
    def readlines(*lines: bytes) -> Iterator[bytes]:
        for line in lines:
            yield line

    def check_encoding(
        expected: str, expected_lines: List[bytes], *lines: bytes
    ) -> None:
        actual_encoding, actual_lines = detect_encoding(readlines(*lines))
        actual_lines = list(actual_lines)
        pytest.testoutput_line("Encoding", repr(actual_encoding))
        pytest.testoutput_line("Lines", repr(actual_lines))
        assert actual_encoding == expected
        assert actual_lines == expected_lines

    check_encoding("utf-8", [], b"")
    check_encoding("utf-8", [b"# coding:utf-8\n"], b"# coding:utf-8\n")

# Generated at 2022-06-21 10:27:49.043374
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import BytesIO
    from .token import tok_name
    from . import tokenize

    def toklist(s):
        return [(tok_name[num], tokval) for num, tokval, _, _, _ in tokenize.tokenize(BytesIO(s.encode("utf-8")).readline)]

    u = tokenize.Untokenizer()
    untokenized = u.untokenize(toklist("def f(x):\n    return x**2"))
    assert untokenized == "def f ( x ) :\n    return x ** 2\n"
    untokenized = u.untokenize(toklist("@classmethod\ndef f(x):\n    return x**2"))

# Generated at 2022-06-21 10:28:01.352536
# Unit test for function generate_tokens
def test_generate_tokens():
    def tokenize_lines(code):
        return [
            toktype
            for toktype, _, _, _, _ in generate_tokens(iter(code.splitlines()).__next__)
        ]

    assert tokenize_lines("import math, string") == [
        NAME,
        NAME,
        COMMA,
        NAME,
        NEWLINE,
    ]
    assert tokenize_lines('if 1:\n    print "foo"\n') == [
        NAME,
        NUMBER,
        COLON,
        NEWLINE,
        INDENT,
        NAME,
        STRING,
        NEWLINE,
        DEDENT,
    ]
    assert tokenize_lines("assert False") == [NAME, NAME, NEWLINE]

# Generated at 2022-06-21 10:28:05.250545
# Unit test for function any
def test_any():
    assert "ab" == regex_sub(any("a", "ab"), "abab")
    assert "" == regex_sub(any("a", "ab"), "bc")



# Generated at 2022-06-21 10:28:14.845910
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.add_whitespace((1, 0))
    assert u.tokens == [' ' * u.prev_col]
    u.add_whitespace((3, 0))
    assert u.tokens == [' ' * u.prev_col]
    u.add_whitespace((2, 10))
    assert u.tokens == [' ' * u.prev_col, ' ' * 10]
    u.add_whitespace((1, 1))
    assert u.tokens == [' ' * u.prev_col, ' ' * 10, ' ' * (1 - u.prev_col)]


# Generated at 2022-06-21 10:28:18.849078
# Unit test for function maybe
def test_maybe():
    assert maybe('a') == '(a)?', maybe('a')
    assert maybe('a', 'b') == '(a|b)?', maybe('a', 'b')

# i.e., _all but not _any

# Generated at 2022-06-21 10:28:50.705986
# Unit test for function detect_encoding
def test_detect_encoding():
    # UCS-2
    lines = [
        codecs.BOM_UTF16 + b"# coding: utf-16\n",
        b"#!/usr/bin/env python\n",
        b"import sys; sys.exit(0)\n",
    ]
    assert detect_encoding(iter(lines).__next__) == ("utf-16", [lines[1], lines[2]])

    # UCS-2 with BOM
    lines = [
        codecs.BOM_UTF16_BE + b"# coding: utf-16-be\n",
        b"#!/usr/bin/env python\n",
        b"import sys; sys.exit(0)\n",
    ]

# Generated at 2022-06-21 10:28:54.984574
# Unit test for function untokenize
def test_untokenize():
    # Test round-trip invariance
    import tokenize, io
    source = io.BytesIO(b'foo = "bar"\n')
    encoding = tokenize.detect_encoding(source.readline)[0]
    source.seek(0)
    g = tokenize.generate_tokens(source.readline)
    first_line = next(g)
    assert tokenize.untokenize(first_line) == 'foo = "bar"\n'
    readline = iter(tokenize.untokenize(g).splitlines(1)).next
    second_g = tokenize.generate_tokens(readline)
    first_line = next(second_g)
    assert tokenize.untokenize(first_line) == 'foo = "bar"\n'


# Generated at 2022-06-21 10:28:57.333238
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("a", "b|c") == "(a|b|c)"



# Generated at 2022-06-21 10:29:04.994684
# Unit test for function generate_tokens
def test_generate_tokens():
    # Unit tests for tokenize.generate_tokens
    import tokenize
    from io import BytesIO
    from token import *

    readline = BytesIO(b"if 1:\n  pass\n").readline
    gtokens = list(tokenize.generate_tokens(readline))

# Generated at 2022-06-21 10:29:16.411810
# Unit test for function printtoken
def test_printtoken():
    f = printtoken
    f(NAME, "if", (0, 0), (0, 2), "if 1:")
    f(NUMBER, "1.41421356", (0, 3), (0, 13), "if 1.41421356:")
    f(OP, ":", (0, 14), (0, 15), "if 1.41421356:")
    f(NEWLINE, "\n", (0, 15), (0, 16), "if 1.41421356:\n")
    f(INDENT, "", (1, 0), (1, 1), "\tprint(1)")
    f(NAME, "print", (1, 1), (1, 6), "\tprint(1)")

# Generated at 2022-06-21 10:29:18.148604
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    assert untok.compat((2, 3), [(4, 5)]) == None



# Generated at 2022-06-21 10:29:25.216297
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    iterable = [
        (NUMBER, '1', (1, 0), (1, 1), "\n"), 
        (DOT, '.', (1, 1), (1, 2), "\n")
    ]
    untok.compat((NUMBER, '1'), iterable)
    assert untok.tokens == ['1 ', '.']



# Generated at 2022-06-21 10:29:27.102392
# Unit test for function any
def test_any():
    test_expression(any(r"[a-z]", r"[0-9]"), "a3")


# Generated at 2022-06-21 10:29:40.134762
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    g = tokenize(lambda x: "a += b")
    r = u.untokenize(g)
    assert r == "a += b ", g

    u = Untokenizer()
    g = tokenize(lambda x: "a += b", "utf-8")
    r = u.untokenize(g)
    assert r == "a += b ", g

    u = Untokenizer()
    g = tokenize(lambda x: 'a += b"b')
    r = u.untokenize(g)
    assert r == 'a += b"b'

    u = Untokenizer()
    g = tokenize(lambda x: "a[1:10:2]")
    r = u.untokenize(g)

# Generated at 2022-06-21 10:29:44.291005
# Unit test for function tokenize
def test_tokenize():
    import io

    s = "def f(x):\n return 2*x"
    f = io.StringIO(s)
    result = []  # type: List[Tuple[int, str, Coord, Coord, str]]
    for t in generate_tokens(f.readline):
        result.append(t)
    return result

