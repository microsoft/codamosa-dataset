

# Generated at 2022-06-21 10:22:19.756978
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"



# Generated at 2022-06-21 10:22:27.897399
# Unit test for function tokenize
def test_tokenize():
    data = '"hello"\tworld\n @integer 1234 # this is a comment'
    def readline():
        return data
    def printtoken(type, token, xxx_todo_changeme2, xxx_todo_changeme3, line):
        (srow, scol) = xxx_todo_changeme2
        (erow, ecol) = xxx_todo_changeme3
        print(
            "%d,%d-%d,%d:\t%s\t%s" % (srow, scol, erow, ecol, tok_name[type], repr(token))
        )
    tokenize(readline, printtoken)
# End unit test for function tokenize


# Generated at 2022-06-21 10:22:29.099951
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError("test")



# Generated at 2022-06-21 10:22:32.281593
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    untok = Untokenizer()
    print(untok.compat(("", ""), "abcd".__iter__()))



# Generated at 2022-06-21 10:22:43.594416
# Unit test for function generate_tokens
def test_generate_tokens():
    import token
    import tokenize
    data = "if 1:\n    print(12)\n"
    g = tokenize.generate_tokens(data.__iter__().__next__)
    for toknum, tokval, _, _, _ in g:
        print("%10s %-14s %r" % (token.tok_name[toknum], tokval, tokval))


if __name__ == "__main__":
    test_generate_tokens()

# Tokenizer for Python
#
# Copyright (C) 2019 Daniele Varrazzo  <daniele.varrazzo@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free

# Generated at 2022-06-21 10:22:48.505665
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    tokenizer = Untokenizer()
    tokenizer.add_whitespace((2, 3))
    assert tokenizer.tokens == ["\n", "   "]
    tokenizer.add_whitespace((3, 7))
    assert tokenizer.tokens == ["\n", "   ", "\n", "      "]
    try:
        tokenizer.add_whitespace((1, 1))
        assert False, "Exception not raised"
    except AssertionError:
        pass



# Generated at 2022-06-21 10:22:59.813926
# Unit test for function tokenize_loop
def test_tokenize_loop():
    text = b'1+1\n'
    import io
    from token import tok_name
    from .pgen2.token import token

    def tokeneater(*args):
        print(tok_name[args[0]], repr(args[1]))
        assert tok_name[args[0]] == 'NAME', "not a NAME token"
        assert (args[0], args[1]) == token[0], "not the expected token"
        raise StopTokenizing

    tokenize_loop(iter(io.BytesIO(text)).__next__, tokeneater)
test_tokenize_loop()
del test_tokenize_loop



# Generated at 2022-06-21 10:23:05.465538
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import re
    from . import tokenize

    u = Untokenizer()
    s = "for i in range(10):\n    print(i)\n"
    all = []
    for t in tokenize.generate_tokens(s.__iter__().__next__):
        all.append(t)
    all = u.untokenize(all)
    assert s == all

    # Issue1876: string.whitespace is different in unicode and str
    u = Untokenizer()
    all = []
    for t in tokenize.generate_tokens(u"a\nb\xA0c\n".__iter__().__next__):
        all.append(t)
    assert u.untokenize(all) == "a\nb\xc2\xa0c\n"




# Generated at 2022-06-21 10:23:10.000167
# Unit test for function untokenize
def test_untokenize():
    input = [
        (tokenize.NUMBER, "0"),
        (tokenize.NEWLINE, "\n"),
        (tokenize.INDENT, "  "),
        (tokenize.NAME, "a"),
        (tokenize.NAME, "b"),
        (tokenize.NEWLINE, "\n"),
        (tokenize.DEDENT, ""),
        (tokenize.NUMBER, "1"),
    ]
    output = untokenize(input)
    expected = "0\n  a b\n1"
    assert output == expected, "output={!r}\nexpected={!r}".format(output, expected)
test_untokenize()


# Generated at 2022-06-21 10:23:23.568879
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?", "test 1 failed"
    assert maybe("abc") == "(abc)?", "test 2 failed"


# Tail end of ' string.
Single = r"[^'\\]*(?:\\.[^'\\]*)*'"
# Tail end of " string.
Double = r'[^"\\]*(?:\\.[^"\\]*)*"'
# Tail end of ''' string.
Single3 = r"[^'\\]*(?:(?:\\.|'(?!''))[^'\\]*)*'''"
# Tail end of """ string.
Double3 = r'[^"\\]*(?:(?:\\.|"(?!""))[^"\\]*)*"""'
Triple = group(Single3, Double3)
# Single-line ' or " string

# Generated at 2022-06-21 10:23:45.144728
# Unit test for function printtoken
def test_printtoken():
    printtoken(1,'a',(1,1),(1,2),'aa')



# Generated at 2022-06-21 10:23:49.068238
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untokenizer = Untokenizer()
    assert untokenizer.untokenize(
        [("NAME", "Hello", (1, 0), (1, 5), "Hello"), ("OP", ",", (1, 5), (1, 6), ",")]
    ) == "Hello ,"



# Generated at 2022-06-21 10:23:55.152928
# Unit test for function detect_encoding
def test_detect_encoding():
    # If no encoding is specified, then the default of 'utf-8' is returned.
    testcase = [("\r\n", "utf-8"), ("\r\n #comment\r\n", "utf-8")]
    for (x, y) in testcase:
        assert detect_encoding(iter([x]).__next__) == (y, [x])
        assert detect_encoding(iter([x, "\r\n"]).__next__) == (
            y,
            [x, "\r\n"],
        )

    # Encoding specification by utf-8 bom

# Generated at 2022-06-21 10:24:07.596319
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO
    from io import BytesIO
    from io import TextIOWrapper

    def fake_open(data: str) -> BytesIO:
        return TextIOWrapper(BytesIO(data.encode("latin-1")))

    tests = [
        (["a b c"], "a b c"),
        (["a", "b", "c"], "a b c"),
        (["a", ("b", " "), "c"], "a b c"),
        (["a", ("b", ""), "c"], "a b c"),
        (["", ("", "a\n"), "b", ("", "\nc\n"), "d"], "a\nb\nc\nd"),
    ]

    for test in tests:
        test_toks = test[0]
        expect_str = test

# Generated at 2022-06-21 10:24:13.603413
# Unit test for function maybe
def test_maybe():
    assert not maybe(*["[a-z]"])
    assert maybe(*["[a-z]"]) == maybe(*["[a-z]",])
    assert maybe(*["[a-z]", "[A-Z]"]) == maybe(*["[A-Z]", "[a-z]"])
    assert maybe(*["[a-z]", "foo", "[A-Z]"]) == maybe(*["[A-Z]", "[a-z]", "foo"])


# Generated at 2022-06-21 10:24:14.930797
# Unit test for function generate_tokens
def test_generate_tokens():
    for token in generate_tokens(iter(("x = 3\n",)).__next__):
        print(token)

test_generate_tokens()


# Generated at 2022-06-21 10:24:15.945112
# Unit test for function printtoken
def test_printtoken():
    printtoken(ENDMARKER, '', (0,0), (0,0), '')


# Generated at 2022-06-21 10:24:17.611896
# Unit test for function tokenize
def test_tokenize():
    import tokenize

    def readline():
        return "if 1:  #pragma: no cover\n"

    tokenize.tokenize(readline, printtoken)



# Generated at 2022-06-21 10:24:30.029597
# Unit test for function tokenize
def test_tokenize():
    import io

    s = "def f(x): return 2*x"
    f = io.StringIO(s)
    result = []

    def tokeneater(*args):
        result.append(args)

    tokenize(f.readline, tokeneater)

# Generated at 2022-06-21 10:24:30.764098
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    pass


# Generated at 2022-06-21 10:24:53.483894
# Unit test for function printtoken
def test_printtoken():
    printtoken(*tuple(range(6)))



# Generated at 2022-06-21 10:24:56.047666
# Unit test for function maybe
def test_maybe():
    print("Test maybe")
    assert maybe("a") == "(a)?", "maybe"



# Generated at 2022-06-21 10:25:05.472183
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    from . import token
    from . import tokenize
    from . import token as token_module

    encoding = "utf-8"
    text = (
        b'foo = "bar"\n'
        b'\n'
        b'print(\\\'single\\\')\n'
        b"print('single')\n"
        b'print("double")\n'
    )

# Generated at 2022-06-21 10:25:08.518785
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        assert str(e) == ""
    try:
        raise StopTokenizing("stop")
    except StopTokenizing as e:
        assert str(e) == "stop"



# Generated at 2022-06-21 10:25:14.612474
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        raise StopIteration

    assert detect_encoding(readline) == ("utf-8", [])

    def readline():
        yield b"# coding: latin-1\n"
        yield b"# comment\n"
        yield b"# also comment\n"

    assert detect_encoding(readline) == ("latin-1", [b"# coding: latin-1\n"])

    def readline():
        yield b"#!python\n"
        yield b"# -*- coding: iso-8859-1 -*-\n"
        yield b"blah blah\n"

    assert detect_encoding(readline) == ("iso-8859-1", [b"#!python\n"])


# Generated at 2022-06-21 10:25:17.776358
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    print(u.untokenize(tokenize("# -*- coding: utf-8 -*-\n")))



# Generated at 2022-06-21 10:25:19.399197
# Unit test for function any
def test_any():
    return _all_tests(any)



# Generated at 2022-06-21 10:25:25.954528
# Unit test for function maybe
def test_maybe():
    assert maybe("[a-z]", "[0-9]") == "[a-z0-9]*"
    assert maybe("a*") == "a*?"

Whitespace = "[ \\f\\t]*"
Comment = "#[^\\r\\n]*"
Ignore = Whitespace + any("\\\\\\r?\\n" + Whitespace) + maybe(Comment)

# Generated at 2022-06-21 10:25:29.475959
# Unit test for function group
def test_group():
    assert group("1", "2", "3") == "(1|2|3)"
    assert group(".") == "\."


# Generated at 2022-06-21 10:25:38.639533
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"


# Helper patterns.
#

# Regular expression to find a non-zero decimal integer.
_non_decimal_int = re.compile(r"[1-9][0-9]*[lLjJ]?")

# Pattern used to detect an operator

# Generated at 2022-06-21 10:26:21.738295
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError()
    except TokenError:
        pass
    try:
        raise TokenError('message')
    except TokenError:
        pass
    try:
        raise TokenError('message', 1, 2, 3)
    except TokenError:
        pass



# Generated at 2022-06-21 10:26:24.454656
# Unit test for function maybe
def test_maybe():
    return maybe("a", "b", "c")

# End unit test



# Generated at 2022-06-21 10:26:35.439022
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    def check(input, output):
        u = Untokenizer()
        result = u.untokenize(input)
        if result != output:
            print("Error in untokenize:")
            print("Untokenizer untokenized %r to:\n%r" % (input, result))
            print("Should have been:\n%r" % (output,))
            exit(1)

    check([(1, "abc")], "abc")
    check([(1, "abc"), (1, "def")], "abc def")
    check([(1, "abc"), (3, "def")], "abc\n\n\ndef")
    check([(1, "abc"), (0, "\n"), (1, "def")], "abc\ndef")

# Generated at 2022-06-21 10:26:43.261945
# Unit test for function tokenize
def test_tokenize():
    import io

    # Test whether untokenize() is able to restore the original tokenization
    # of a given piece of Python code.
    def test_roundtrip(c, b=None):
        r = io.BytesIO(c.encode("utf-8")).readline
        l = []
        g = generate_tokens(r)
        for t in g:
            l.append(t)
        newcode = untokenize(l).decode("utf-8")
        if b is None:
            b = c
        if newcode != b:
            raise ValueError("Untokenize failed on", repr(c))

    test_roundtrip("def f(x): return 2*x")
    test_roundtrip("x = 1; y = 2")
    test_roundtrip("if 1: pass")
    test

# Generated at 2022-06-21 10:26:55.483760
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import tokenize

    class CustomUntokenizer(Untokenizer):
        pass

    untoken = CustomUntokenizer.untokenize

# Generated at 2022-06-21 10:27:07.893290
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    import tokenize
    r = io.BytesIO(bytes(dedent(
        """\
        if 1:
        #\tPass#
        elif 1:
        pass#
        """
    ), "utf-8"))
    result = []
    gt = generate_tokens(r.readline)
    for toknum, tokval, _, _, _ in gt:
        result.append((toknum, tokval))
    print(result)

# Generated at 2022-06-21 10:27:10.399541
# Unit test for function any
def test_any():
    for i in range(0, len(token.tok_name) + 1):
        value = ""
        for j in range(1, i + 1):
            value = value + "a"
        regex = any(*["a"] * i)
        m = re.match(regex, value)
        if not m:
            raise "Failed"



# Generated at 2022-06-21 10:27:12.154345
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing as e:
        assert repr(e) == "tokenize.StopTokenizing"
        assert str(e) == "tokenize.StopTokenizing"



# Generated at 2022-06-21 10:27:18.861612
# Unit test for function any
def test_any():
    testcases = [
        ['"abc" xyz', '"abc" xyz',
         "group match failed to consume trailing characters"],
        ['abc" def" xyz', 'abc" def" xyz',
         "group match failed to consume trailing characters"],
        ['"" xyz', '"" xyz',
         "group match failed to consume trailing characters"],
        ['', '',
         "group match failed to match empty string"]
    ]
    try:
        re.compile('|'.join(map(re.escape, testcases)))
    except re.error:
        return ["Bad group in test_any()"]
    for [text, expected, errmsg] in testcases:
        initmsg = "Test: '%s'\n" % text

# Generated at 2022-06-21 10:27:29.492570
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO
    from tokenize import tokenize as tokenize_source

    def test_token_stream(s: Text) -> None:
        # Note: tokenize_source splits the tokens by newlines,
        # whereas tokenize splits by lines.
        # The output is a generator, so convert it to a list to compare.
        tokvals1 = list(Untokenizer().compat(next(tokenize_source(StringIO(s).readline)), tokenize_source(StringIO(s).readline)))
        tokvals2 = [token[1] for token in generate_tokens(StringIO(s).readline)]
        assert tokvals1 == tokvals2

    test_token_stream('x = "foo"\\nprint(x)\n')

# Generated at 2022-06-21 10:28:17.615407
# Unit test for function untokenize
def test_untokenize():
    from io import StringIO
    from tokenize import generate_tokens, untokenize

    def compare(s1, s2):
        if s1 != s2:
            print(f"{s1!r} != {s2!r}")

    # The first line is there merely to please the tokenize module; the rest
    # is for the actual unit test.

# Generated at 2022-06-21 10:28:28.226539
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()

# Generated at 2022-06-21 10:28:38.643556
# Unit test for function generate_tokens
def test_generate_tokens():
    import io
    with io.StringIO() as f:
        f.write("def foo():\n")
        f.write("    print('foo()')\n")
        f.write("\n")
        f.write("\n")
        f.write("\n")
        f.write("foo()\n")

        f.seek(0)    # "rewind" to the beginning of the file
        for token in tokenize.generate_tokens(f.readline):
            print(token)

test_generate_tokens()
#!/usr/bin/env python3
import tokenize
from io import BytesIO

data = b"""
for i in 'spam':
    print('i =', i)
"""


# Generated at 2022-06-21 10:28:50.607242
# Unit test for function maybe
def test_maybe():
    """
    >>> assert maybe("a") == "(a)?", maybe("a")
    """
# End unit test for function maybe


Whitespace = r"[ \f\t]*"
Comment = r"#[^\r\n]*"
Ignore = Whitespace + any(r"\\\r?\n" + Whitespace) + maybe(Comment)
Name = r"[a-zA-Z_]\w*"

Hexnumber = r"0[xX][\da-fA-F]+[lL]?"
Octnumber = r"(0[oO][0-7]+)|(0[0-7]*)[lL]?"
Binnumber = r"0[bB][01]+[lL]?"
Decnumber = r"[1-9]\d*[lL]?"
Intnumber

# Generated at 2022-06-21 10:28:51.809910
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    StopTokenizing()



# Generated at 2022-06-21 10:28:53.635506
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"



# Generated at 2022-06-21 10:29:03.607825
# Unit test for function maybe
def test_maybe():
    # assert maybe('a') == 'a?'
    assert maybe("(", ")") == "\\(?\\)?"
    assert maybe("(", ")") == "\\(?\\)?"
    assert maybe("\\\\") == "\\\\?"
    assert maybe("\\\\") == "\\\\?"


whitespace = r"[ \f\t]*"
comment = r"#[^\r\n]*"
blankline = whitespace + r"(?:\r?\n" + whitespace + r")+"
name = r"[a-zA-Z_]\w*"

hexint = r"0[xX](?>[0-9a-fA-F]+)?"
octint = r"0[oO]?[0-7]+"
binint = r"0[bB][01]+"


# Generated at 2022-06-21 10:29:15.315305
# Unit test for function tokenize
def test_tokenize():
    import io
    f = io.StringIO("if 1:\n  return")
    g = generate_tokens(f.readline)
    lgt = list(g)
    assert lgt[0] == (NAME, "if", (1, 0), (1, 2), "if 1:\n  return")
    assert lgt[1] == (NUMBER, "1", (1, 3), (1, 4), "if 1:\n  return")
    assert lgt[2] == (OP, ":", (1, 4), (1, 5), "if 1:\n  return")
    assert lgt[3] == (NEWLINE, "\n", (1, 5), (1, 6), "if 1:\n  return")

# Generated at 2022-06-21 10:29:22.186345
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():

    def roundtrip(s: str) -> str:
        return untokenize(tokenize(s))

    assert roundtrip("if True:\n  pass\n") == "if True:\n  pass"
    assert roundtrip("if True: pass\n") == "if True: pass"
    assert roundtrip("if True:\n  pass") == "if True:\n  pass"

    # A more extensive test, taken from the Python-3.6.1 tokenize module.
    # In Python 3.6.1:
    #       result = untokenize(tokenize(source)),
    #       assert result == source, f"{result!r} != {source!r}"

# Generated at 2022-06-21 10:29:30.739747
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io

    result = []

    def tokeneater(*args):
        result.append(args)

    tokenize_loop(io.StringIO("def f():\n  return None\n").readline, tokeneater)
    res = result[0]
    assert res[0] == token.NAME, res[0]
    assert res[1] == "def", res[1]
    assert res[2] == (1, 0), res[2]
    assert res[3] == (1, 3), res[3]
    assert res[4] == "def f():\n", res[4]
    res = result[1]
    assert res[0] == token.NAME, res[0]
    assert res[1] == "f", res[1]