

# Generated at 2022-06-21 10:22:11.653161
# Unit test for function maybe
def test_maybe():
    assert maybe("a", "b") == "(a|b)?"

_namechars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_"
_namechars += _namechars.lower() + _namechars.upper()
_namechars += "0123456789"

_schars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_"
_schars += _schars.lower() + _schars.upper()
_schars += "0123456789!@#$%^&*()-=+[]{},./?<>:"

# Since we can't use \x in raw strings, do the following.

# Generated at 2022-06-21 10:22:22.856700
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    class Interpreter:
        def __init__(self):
            self.code = []
            self.stack = []
        def push(self, val):
            self.code.append(("push", val))
            self.stack.append(val)
        def inc_stack_ptr(self):
            self.code.append("inc_stack_ptr")
            self.stack.append("None")
        def pop_stack_ptr(self):
            self.code.append("pop_stack_ptr")
            del self.stack[-1]
        def print_stack(self):
            print("Stack=", ",".join(map(str, self.stack)))
        # This method is not required by the untokenize interface, but
        # it allows the test to find out what it's supposed to look like

# Generated at 2022-06-21 10:22:24.985894
# Unit test for function tokenize
def test_tokenize():
    text = "a b c\nd e f\n end"
    def readline():
        return text
    tokenize(readline, printtoken)


# Generated at 2022-06-21 10:22:29.249573
# Unit test for function untokenize
def test_untokenize():
    def compare(input, output):
        input = iter(input.splitlines(1))
        output = iter(output.splitlines(1))
        readline = lambda: next(input)
        out = untokenize(generate_tokens(readline))
        for out_line, expected_line in zip(out.splitlines(1), output):
            assert out_line == expected_line, (out_line, expected_line)

    yield compare, "class Square: pass", "class Square: pass"
    yield compare, "a = 3 + 5 * 2", "a = 3 + 5 * 2"
    yield compare, "def f(x, y, z):\n    return x + y * z", "def f(x, y, z):\n    return x + y * z"

# Generated at 2022-06-21 10:22:30.810229
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:22:38.634704
# Unit test for function tokenize
def test_tokenize():
    import io

    # Test the "correct" tokenization of a bytes literal
    f = io.StringIO("b'abc'")
    g = generate_tokens(f.readline)
    toks = []
    for toknum, tokval, _, _, _ in g:
        toks.append((toknum, tokval))
    assert toks == [(NAME, "b"), (STRING, "'abc'")]



# Generated at 2022-06-21 10:22:48.081514
# Unit test for function generate_tokens
def test_generate_tokens():
    import random
    import io
    def test_tokenize(input, tokenize_kwargs=None):
        if tokenize_kwargs is None:
            tokenize_kwargs = {}
        return [tok[:4] for tok in generate_tokens(io.StringIO(input).readline, **tokenize_kwargs)]


# Generated at 2022-06-21 10:22:58.235488
# Unit test for function printtoken
def test_printtoken():
    import io
    import tokenize
    src = io.StringIO("foo = 00  # comment")
    tokenize.printtoken(*tokenize.generate_tokens(src.readline).__next__())

# In various places below, the spelling "token" means a 5-tuple
# containing the token type, the token string, the starting
# (row, col) indices of the token string, and the ending (row, col)
# indices of the token string.  These 5-tuples are also produced by
# generate_tokens().


# Helper for get_token()

# Generated at 2022-06-21 10:23:02.174548
# Unit test for function detect_encoding
def test_detect_encoding():
    from io import BytesIO

    def readline():
        return BytesIO(b"# coding: latin-1\npass").readline()

    res = detect_encoding(readline)
    assert res[0] == "iso-8859-1" and res[1] == [b"# coding: latin-1\n"]



# Generated at 2022-06-21 10:23:13.621521
# Unit test for function untokenize
def test_untokenize():
    import io
    import tokenize


# Generated at 2022-06-21 10:23:33.399083
# Unit test for constructor of class TokenError
def test_TokenError():
    TokenError()



# Generated at 2022-06-21 10:23:35.399500
# Unit test for function printtoken
def test_printtoken():
    printtoken(NAME, "spam", (1, 0), (1, 4), "spam")


# Generated at 2022-06-21 10:23:45.999521
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tempfile
    import tokenize

    with tempfile.TemporaryDirectory() as tmpdir:
        with open(tmpdir + "/tst.py", "w") as file:
            file.write('# A comment\na = 1 + 2\nprint(a)')
            file.flush()
            with open(file.name) as f:
                data = f.read()
        with tokenize.tokenize(io.BytesIO(data.encode("utf-8")).readline) as tokens:
            untokenize_data = Untokenizer().compat(next(tokens), tokens)

    assert untokenize_data == data



# Generated at 2022-06-21 10:23:48.237961
# Unit test for function any
def test_any():
    assert any("abc") == "(a|b|c)*"
    assert any("abc", "d") == "((a|b|c)*(d))*"



# Generated at 2022-06-21 10:23:49.456961
# Unit test for constructor of class TokenError
def test_TokenError():
    err = TokenError()
    assert str(err) == ""



# Generated at 2022-06-21 10:23:51.147873
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()

# unit test for Untokenizer.compat

# Generated at 2022-06-21 10:23:53.654720
# Unit test for function any
def test_any():
    for x in ["", "f", "foo", "bar"]:
        assert any("foo", "bar")(x) == x



# Generated at 2022-06-21 10:24:02.016289
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    import io
    ut = Untokenizer()
    ut.injest_token(token.STRING, 'abc\n')
    ut.injest_token(token.STRING, 'def\n')
    ut.injest_token(token.STRING, 'ghi\n')
    f = io.StringIO()
    f.write(ut.untokenize())
    assert f.getvalue() == 'abc\ndef\nghi\n'



# Generated at 2022-06-21 10:24:02.626627
# Unit test for function printtoken
def test_printtoken():
    return



# Generated at 2022-06-21 10:24:08.580643
# Unit test for function maybe
def test_maybe():
    assert maybe(r"a") == "(a)?", maybe(r"a")
    assert maybe(r"a", r"b") == "((a)|(b))?", maybe(r"a", r"b")
    assert maybe(r"a", r"b", r"c") == "((a)|(b)|(c))?", maybe(r"a", r"b", r"c")


# Generated at 2022-06-21 10:24:59.515938
# Unit test for function untokenize

# Generated at 2022-06-21 10:25:07.736168
# Unit test for function untokenize
def test_untokenize():
    def roundtrip(s, want_repr=False, **kw):
        roundtrip_iter(tokenize(io.StringIO(s).readline), want_repr, **kw)

    def roundtrip_iter(iterable, want_repr=False, **kw):
        rt = untokenize(iterable)
        if want_repr:
            rt = repr(rt)
        compare(s, rt, **kw)

    def compare(src, rt, **kw):
        if kw:
            raise ValueError(kw)
        src = src.replace("\r\n", "\n")
        rt = rt.replace("\r\n", "\n")

# Generated at 2022-06-21 10:25:14.054444
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    itest = ((NAME, "abc"), (OP, "+"), (NUMBER, "1"))
    u.compat(itest.__next__(), itest)
    assert u.tokens == ["abc ", "+ 1 "]
    u = Untokenizer()
    toks = [
        (OP, "+"),
        (NAME, "a"),
        (NEWLINE, ""),
        (OP, "-"),
        (NAME, "b"),
        (NEWLINE, ""),
        (OP, "*"),
        (NAME, "c"),
        (NEWLINE, ""),
        (NUMBER, "1"),
        (NEWLINE, ""),
        (NUMBER, "2"),
        (NEWLINE, ""),
        (NUMBER, "3"),
    ]

# Generated at 2022-06-21 10:25:16.720168
# Unit test for function group
def test_group():
    g = group(r'\+', r'-')
    assert g == r'(\+|-)'

# Generated at 2022-06-21 10:25:18.194247
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:25:21.266434
# Unit test for function any
def test_any():
    assert any('a') == "(a)*"
    assert any('a', 'b') == "(a|b)*"



# Generated at 2022-06-21 10:25:24.720219
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    a = Untokenizer()
    assert a.tokens == []
    assert a.prev_row == 1
    assert a.prev_col == 0



# Generated at 2022-06-21 10:25:35.942747
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    p, prevrow, prevcol, prevline = (None, 1, 0, "")

# Generated at 2022-06-21 10:25:38.064243
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    exc = StopTokenizing("test")
    assert str(exc) == "test"



# Generated at 2022-06-21 10:25:42.032236
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()
    assert u.untokenize([(9, "...")]) == "..."
    assert (u.untokenize([(1, ""), (4, "a"), (4, "b"), (0, "\n")]) == "ab\n")


# Generated at 2022-06-21 10:27:48.329164
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import StringIO

    class TokenInput:
        def __init__(self, token_stream):
            self.token_stream = token_stream


# Generated at 2022-06-21 10:27:51.136778
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"
test_any()



# Generated at 2022-06-21 10:27:53.437972
# Unit test for function maybe
def test_maybe():
    assert maybe(r'\d+') == r'(\d+)?', maybe(r'\d+')
# End unit test



# Generated at 2022-06-21 10:27:56.857413
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass
    else:
        assert 0, "Unable to create TokenError instance"

# Unit tests for class TokenError

# Generated at 2022-06-21 10:28:01.076463
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    """
    >>> from blib2to3.pgen2 import tokenize
    >>> try:
    ...     raise tokenize.StopTokenizing()
    ... except tokenize.StopTokenizing:
    ...     print("yes")
    ...
    yes
    """



# Generated at 2022-06-21 10:28:05.401112
# Unit test for function tokenize
def test_tokenize():
    import io
    r = io.StringIO("def x(): pass")
    tokens = generate_tokens(r.readline)
    for t in tokens:
        print(t)



# Generated at 2022-06-21 10:28:08.941813
# Unit test for function group
def test_group():
    assert group("", "a", "aa") == "(|a|aa)"
    assert group("abc", "def") == "(abc|def)"
    assert group("abc|def") == "(abc\\|def)"



# Generated at 2022-06-21 10:28:20.985608
# Unit test for function generate_tokens
def test_generate_tokens():
    import sys
    import io
    import tokenize
    if sys.version_info >= (3, 8):
        constants = vars(tokenize).keys()
        # tokenize.py _tokenize() generates EXTENDED_ARG now
        constants.remove("EXTENDED_ARG")
    else:
        constants = list(vars(tokenize).keys())
        constants.remove("COMMENT")

    Constants = {}
    for constant in constants:
        Constants[getattr(tokenize, constant)] = constant

    def tokens(s):
        result = list(tokenize.tokenize(io.BytesIO(s.encode("utf-8")).readline))
        t = result[0]
        if Constants[t[0]] == "ENCODING":
            del result[0]

# Generated at 2022-06-21 10:28:26.427592
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token
    r = io.StringIO("def f(): pass\n")
    tokenize_loop(r.readline, printtoken)
    r = io.StringIO("def f(): pass\n")
    tokenize_loop(r.readline, lambda t, v, _, _, _: print("%s %s" % (v, token.tok_name[t])))



# Generated at 2022-06-21 10:28:27.633438
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as st:
        pass



# Generated at 2022-06-21 10:29:28.658759
# Unit test for function untokenize
def test_untokenize():
    s = "a = 0"
    t1 = [tok[:2] for tok in generate_tokens(StringIO(s).readline)]
    newcode = untokenize(t1)
    readline = iter(newcode.splitlines(1)).__next__
    t2 = [tok[:2] for tok in generate_tokens(readline)]
    assert t1 == t2



# Generated at 2022-06-21 10:29:41.636152
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        yield b"# coding=utf-8\n"
        yield b"x = 'hello world!'\n"

    encoding, lines = detect_encoding(readline)
    input = io.BytesIO(b"".join(lines))
    tokens = list(tokenize(input.readline))
    # The expected tokens are:
    #  (1, b'# coding=utf-8\n')
    #  (1, b'x')
    #  (51, b'=')
    #  (1, b"'hello world!'")
    #  (4, b'\n')

# Generated at 2022-06-21 10:29:51.458540
# Unit test for function tokenize
def test_tokenize():
    import sys
    import untokenize
    from io import StringIO

    class Readline:
        def __init__(self, lines: Iterable[Text]) -> None:
            self.lines = iter(lines)
            self.line = ""

        def __call__(self) -> Text:
            try:
                return next(self.lines)
            except StopIteration:
                raise EOFError

    class TokenEater:
        def __init__(self) -> None:
            self.types: List[int] = []
            self.tokens: List[Text] = []
            self.startlines: List[Coord] = []
            self.endlines: List[Coord] = []
            self.lines: List[Text] = []


# Generated at 2022-06-21 10:29:55.652558
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    assert untok
    # assert untok.tokens == []
    # assert untok.prev_row == 1
    # assert untok.prev_col == 0



# Generated at 2022-06-21 10:29:56.077688
# Unit test for function untokenize

# Generated at 2022-06-21 10:29:57.942829
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, 10, (1, 4), (2, 4), "")



# Generated at 2022-06-21 10:30:04.168769
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, "3", (1,0), (1,1), "")
    printtoken(NAME, "age", (1,0), (1,3), "")
    printtoken(OP, "+", (1,0), (1,1), "")

# Workaround for http://bugs.python.org/issue1602:
# see http://www.python.org/dev/peps/pep-0263/ for details of unicode-escape
# decoding in Python source code
#
# We also accept \Uxxxxxxxx escapes (8 digits, not necessarily ASCII
# characters) because they are used by Mercurial's i18n support.

# Generated at 2022-06-21 10:30:14.785457
# Unit test for constructor of class TokenError
def test_TokenError():
    # Constructor of class TokenError must take exactly two arguments
    try:
        raise TokenError
    except TypeError:
        pass
    except Exception as e:
        raise AssertionError(
            "Expected TypeError when TokenError constructor called with no "
            f"arguments, got {e.__class__.__name__}."
        )

    try:
        raise TokenError("foo", 42, 42)
    except TypeError:
        pass
    except Exception as e:
        raise AssertionError(
            "Expected TypeError when TokenError constructor called with too "
            f"many arguments, got {e.__class__.__name__}."
        )



# Generated at 2022-06-21 10:30:16.268750
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing as e:
        pass



# Generated at 2022-06-21 10:30:18.431871
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing()
    except StopTokenizing as e:
        assert e.args == ()

