

# Generated at 2022-06-21 10:22:38.581475
# Unit test for function group
def test_group():
    assert group("a", "b") == "(a|b)"
    assert group("abc") == "(abc)"
    assert group(["a", "b"]) == "(a|b)"
    assert group(["a", ("b", "c")]) == "(a|(b|c))"



# Generated at 2022-06-21 10:22:43.787203
# Unit test for function tokenize_loop
def test_tokenize_loop():
    expected = [
        (token.NUMBER, '0', (1, 0), (1, 1), '0'),
        (token.ENDMARKER, '', (1, 1), (1, 1), '')
    ]
    actual = []
    tokenize_loop(iter(['0']).__next__, actual.append)
    assert expected == actual

# Generated at 2022-06-21 10:22:45.115578
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:22:46.616825
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("foo")
    except TokenError as inst:
        assert "foo" in inst.args[0]



# Generated at 2022-06-21 10:22:59.607265
# Unit test for function group
def test_group():
    assert group("a", "b", "c") == "(a|b|c)"

# A string is a '<...>' delimited string.
_string_re = r"[uU]?[rR]?(?:%s)(?:%s)*" % (
    group(r'[rubUB]?[rR]?("""(?:[^\\]|\\.)*?"""|.+?(?<!\\)")'),
    group(r"[rubUB]?[rR]?'(?:[^\\]|\\.)*?'|.+?(?<!\\)'"),
)


# Interpolated strings both look like '...%s...' and '...${...}...'.

# Generated at 2022-06-21 10:23:05.342281
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    from io import BytesIO

    untok = Untokenizer()

    # Test string (source is the same as target)
    test_string = b'2 + 2\n'

    # Create a pseudo-file, which gives the tokenize module
    # access to the BytesIO object
    pseudo_file = BytesIO(test_string)

    # Create a generator which feeds the pseudo-file to the
    # tokenize function
    token_generator = generate_tokens(pseudo_file.readline)

    # Create a compat generator by feeding the iterator to
    # the compat method
    compat_generator = untok.compat(next(token_generator), token_generator)

    # Use untokenize to create the final output
    # If untokenize outputs the same as the
    # test string, the test passes

# Generated at 2022-06-21 10:23:11.923358
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 0
    u.prev_col = 0
    u.add_whitespace((0, 0))
    u.add_whitespace((0, 1))
    assert u.tokens == [" ", ""]
    u.prev_row = 1
    u.tokens = []
    u.add_whitespace((0, 0))
    u.add_whitespace((1, 2))
    assert u.tokens == ["\n", "  "]



# Generated at 2022-06-21 10:23:24.633440
# Unit test for function tokenize_loop
def test_tokenize_loop():
    from six import StringIO

    test_string = "class MyClass(object):\n" \
                  "  def __init__(self, f):\n" \
                  "    self.name = f"

# Generated at 2022-06-21 10:23:33.754908
# Unit test for function detect_encoding
def test_detect_encoding():
    readline = iter([
      BOM_UTF8 + bytes(b'#!/usr/bin/env python\n'),
      bytes(b'# -*- coding: utf-8 -*-\n'),
      bytes(b'# -*- coding: iso-8859-15 -*-\n'),
      bytes(b'# coding: ascii\n'),
    ]).__next__
    e = detect_encoding(readline)
    assert e == ("utf-8-sig", [bytes(b'#!/usr/bin/env python\n')])
    e = detect_encoding(readline)
    assert e == ("utf-8", [bytes(b'# -*- coding: utf-8 -*-\n')])
    e = detect_encoding(readline)
    assert e

# Generated at 2022-06-21 10:23:46.048144
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    class Token:
        def __init__(self, type, string, start, end, line):
            self.type, self.string, self.start, self.end, self.line = type, string, start, end, line
        def __getitem__(self, index):
            return (self.type, self.string)[index]

# Generated at 2022-06-21 10:25:24.388333
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing(1, 2)
    except StopTokenizing as e:
        assert e.args == (1, 2)



# Generated at 2022-06-21 10:25:33.093256
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import unittest

    from .tokenize_tests import test_tokenize_loop as example

    from . import untokenize

    class Test(unittest.TestCase):
        def test_tokenize_loop(self):
            readline = io.BytesIO(example).readline
            # Need to convert back to bytes for Python 2.
            result = b"".join(list(untokenize(tokenize_loop(readline, None))))
            self.assertEqual(example, result)

    unittest.main(__name__)



# Generated at 2022-06-21 10:25:41.142843
# Unit test for function untokenize
def test_untokenize():
    untok = untokenize
    eq = assertEqual
    eq(untok([(1, "spam")]), "spam")
    eq(untok([(1, "1"), (1, " "), (1, "spam")]), "1 spam")
    eq(untok([(1, "1"), (0, " "), (1, "spam")]), "1 spam")
    eq(untok([(3, "def")]), "def")
    eq(untok([(3, "def"), (1, "\n"), (1, "  "), (1, "pass")]), "def\n  pass")
    eq(untok([(3, "def"), (1, "\n"), (3, "@"), (3, "staticmethod")]), "def\n@staticmethod")
    # def f():


# Generated at 2022-06-21 10:25:50.612150
# Unit test for function any
def test_any():
    assert any("a")("") == ""
    assert any("a")("a") == "a"
    assert any("a")("b") == ""
    assert any("a")("ab") == "a"
    assert any("a")("ba") == "a"
    assert any("ab")("") == ""
    assert any("ab")("a") == "a"
    assert any("ab")("b") == "b"
    assert any("ab")("ab") == "ab"
    assert any("ab")("ba") == "ba"
    assert any("ab")("aba") == "aba"
    assert any("ab")("bab") == "ab"
    assert any("ab")("abab") == "abab"


# Generated at 2022-06-21 10:25:53.113905
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("test message")
    except TokenError as e:
        assert str(e) == "test message"



# Generated at 2022-06-21 10:26:01.220696
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    class FakeTestCase:
        def fail(self, msg):
            raise AssertionError(msg)

    def check(s):
        try:
            raise StopTokenizing(s)
        except StopTokenizing as err:
            if err.args != (s,):
                raise FakeTestCase().fail("bad args for StopTokenizing")

    check("spam")
    check("")
    check("x" * 100)
    check("x" * 1000)



# Generated at 2022-06-21 10:26:13.008073
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import token

    def tokeneater(*args):
        tokens.append(args)

    f = io.StringIO("a = 1 + 2\n")
    tokens = []
    tokenize_loop(f.readline, tokeneater)
    print(tokens)

# Generated at 2022-06-21 10:26:18.823078
# Unit test for function any
def test_any():
    for func in (re.compile, re.compile):
        if func is re.compile:
            assert func(any("abc")).match("abc")
            assert not func(any("abc")).match("a")
            assert func(any("abc")).match("abcb")
        else:
            assert func(any("abc"), re.S).match("abc")
            assert not func(any("abc"), re.S).match("a")
            assert func(any("abc"), re.S).match("a\nb")


# Generated at 2022-06-21 10:26:21.329944
# Unit test for function group
def test_group():
    assert group("abc", "def") == "(abc|def)"


# Generated at 2022-06-21 10:26:26.227030
# Unit test for function generate_tokens
def test_generate_tokens():
    def check_token(tok, typ, val, start, end=None, line=None):
        if end is None:
            end = start
        assert tok.type == typ, (tok.type, typ)
        assert tok.string == val, (tok.string, val)
        assert tok.start == start, (tok.start, start)
        assert tok.end == end, (tok.end, end)
        assert tok.line == line, (tok.line, line)

# Generated at 2022-06-21 10:27:52.558788
# Unit test for function generate_tokens
def test_generate_tokens():
    if (
        list(generate_tokens(iter(["hi"]).__next__, None))
        != [(ERRORTOKEN, "hi", (1, 0), (1, 2), "hi")]
    ):
        print("generate_tokens() does not fetch tokens one at a time")
        return 0

# Generated at 2022-06-21 10:28:04.533225
# Unit test for function untokenize
def test_untokenize():
    s = "def f():\n    pass\n"
    t1 = [
        (NAME, "def"),
        (NAME, "f"),
        (OP, "("),
        (OP, ")"),
        (OP, ":"),
        (NEWLINE, "\n"),
        (INDENT, "\n"),
        (NAME, "pass"),
        (NEWLINE, "\n"),
        (DEDENT, ""),
    ]
    newcode = untokenize(t1)
    t2 = [
        (x[0], str(x[1]))
        for x in generate_tokens(iter(newcode.splitlines(1)).__next__)
    ]
    assert t1 == t2



# Generated at 2022-06-21 10:28:15.881393
# Unit test for function tokenize_loop
def test_tokenize_loop():
    def test(input):
        tokenize_loop(iter(input).__next__, printtoken)

    test("")
    test("abc")
    test("  abc")
    test("  'abc'")
    test('  "abc"')
    test("a b c")
    test("a b c\n")
    test("\n")
    test("# comment\n")
    test("# comment 1\n# comment 2\n")
    test("1\n2\n3\n")
    test("1   \n2 \n3 \n")
    test("1   #\n2 \n3 \n")
    test("1   #\n2 \n3 #\n")
    test("(spam, eggs,\n       ham)\n")
    test("(\n)\n")


# Generated at 2022-06-21 10:28:27.210503
# Unit test for function tokenize
def test_tokenize():
    #
    #    Generate tokens from a string
    #
    s = "1 + 2\n"
    result = [
        (NUMBER, "1", (1, 0), (1, 1), s),
        (OP, "+", (1, 2), (1, 3), s),
        (NUMBER, "2", (1, 4), (1, 5), s),
        (NEWLINE, "\n", (1, 5), (1, 6), s),
        (ENDMARKER, "", (2, 0), (2, 0), s),
    ]
    tokens = tokenize(s.__iter__().__next__)
    for x in result:
        t = next(tokens)
        assert x[:2] == t[:2], t

# Generated at 2022-06-21 10:28:30.677045
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("Test TokenError")
    except TokenError as e:
        if e.args[0] != "Test TokenError":
            raise ValueError("TokenError doesn't return an error correctly.")

        # else this test passed



# Generated at 2022-06-21 10:28:36.477240
# Unit test for function maybe
def test_maybe():
    assert maybe("") == "?"
    assert maybe("a") == "a?"
    assert maybe("ab") == "(ab)?"
    assert maybe("a", "b", "c") == "(a|b|c)?"

_NAME = r"[a-zA-Z_]\w*"
_NAME_SINGLE = r"[a-zA-Z_]\w"

# Generated at 2022-06-21 10:28:43.199734
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    u = Untokenizer()
    toklist = [
        (1, ".."),
        (2, ".."),
        (3, ".."),
        (4, ".."),
        (5, ".."),
        (6, ".."),
        (7, ".."),
        (8, ".."),
        (9, ".."),
        (10, ".."),
        (11, ".."),
        (12, ".."),
        (13, ".."),
        (14, ".."),
        (15, ".."),
        (16, ".."),
        (17, ".."),
        (18, ".."),
        (19, ".."),
        (20, ".."),
    ]

# Generated at 2022-06-21 10:28:55.425967
# Unit test for function detect_encoding
def test_detect_encoding():
    def readline():
        yield b"#!/usr/bin/python3\n"
        yield b"# -*- coding: latin-1 -*-\n"
        yield b"# vim: set fileencoding=utf-8 :\n"
        yield b"pass\n"

    encoding, lines = detect_encoding(readline)
    assert encoding == "iso-8859-1"
    assert lines == [b"#!/usr/bin/python3\n", b"# -*- coding: latin-1 -*-\n"]

    def readline():
        yield b"# coding: -*- utf-8 -*-\n"
        yield b"import mod\n"
        yield b"\n"
        yield b"print(mod.__doc__)\n"

    encoding,

# Generated at 2022-06-21 10:28:56.388715
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError
    except TokenError:
        pass



# Generated at 2022-06-21 10:29:01.923877
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    unt = Untokenizer()
    unt.add_whitespace((1, 0))
    unt.add_whitespace((1, 5))
    unt.add_whitespace((2, 0))
    unt.add_whitespace((2, 3))
    unt.add_whitespace((3, 0))
    assert unt.tokens == ["", "     ", "\n", "   ", "\n"]
