

# Generated at 2022-06-21 10:22:29.621592
# Unit test for function group
def test_group():
  assert group("a", "ab", "abc") == "(a|ab|abc)"
  assert group("a|b", "ab", "abc") == "(a|b|ab|abc)"



# Generated at 2022-06-21 10:22:38.904325
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    with open("pgen2/tests/test_pgen_grammar.py", "rb") as f:
        data = f.read()
    tokens1 = list(generate_tokens(lambda: data))
    untokenizer = Untokenizer()
    string1 = untokenizer.untokenize(tokens1)
    tokens2 = list(generate_tokens(lambda: string1))
    string2 = untokenizer.untokenize(tokens2)
    assert tokens2 == tokens1
    assert string2 == string1



# Generated at 2022-06-21 10:22:43.376816
# Unit test for function detect_encoding
def test_detect_encoding():
    import codecs
    from io import BytesIO
    from blib2to3.pgen2.tokenize import detect_encoding

    stream = BytesIO(b"# coding: latin-1\n")
    assert detect_encoding(stream.readline) == ("iso-8859-1", [])
    stream = BytesIO(b"#!/usr/bin/python\n# coding: latin-1\n")
    assert detect_encoding(stream.readline) == ("iso-8859-1", [b"#!/usr/bin/python\n"])
    assert detect_encoding(
        (lambda: b"\xe2\x89\xa0")
    ) == ("utf-8", [])  # utf-8

# Generated at 2022-06-21 10:22:48.929760
# Unit test for function printtoken
def test_printtoken():
    # import sys
    # sys.stderr = sys.stdout
    printtoken(1, '"', (3, 5), (3, 6), '')
    printtoken(1, '"', (3, 9), (3, 10), '')
    printtoken(1, '"""', (3, 9), (3, 12), '')
    printtoken(1, '"', (4, 0), (4, 1), '')
    printtoken(1, '"""', (4, 0), (4, 3), '')



# Generated at 2022-06-21 10:22:52.667680
# Unit test for function any
def test_any():
    assert any("a", "b") == "(a|b)*"


# Generated at 2022-06-21 10:23:02.407450
# Unit test for function printtoken
def test_printtoken():
  from io import StringIO
  from contextlib import contextmanager
  @contextmanager
  def captured_output():
    new_out, new_err = StringIO(), StringIO()
    old_out, old_err = sys.stdout, sys.stderr
    try:
      sys.stdout, sys.stderr = new_out, new_err
      yield sys.stdout, sys.stderr
    finally:
      sys.stdout, sys.stderr = old_out, old_err
  with captured_output() as (out, err):
    printtoken(token.OP, ":", (0,0), (0,1), "")
  assert out.getvalue().strip() == "0,0-0,1:\tOP\t':'"
test_printtoken()



# Generated at 2022-06-21 10:23:05.119473
# Unit test for function group
def test_group():
    g = group(*["abc", "def"])
    assert g == r"(abc|def)"
    assert re.match(g, "abc")
    assert re.match(g, "def")



# Generated at 2022-06-21 10:23:07.195226
# Unit test for function maybe
def test_maybe():
    if maybe("a", "bc") != "(a|bc)?":
        return "failed"
    return "ok"

# Generated at 2022-06-21 10:23:20.469826
# Unit test for function untokenize
def test_untokenize():
    import io
    import token
    from tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

# Generated at 2022-06-21 10:23:29.049831
# Unit test for function any
def test_any():
    any("a")
    any("a", "b")
    any("a", "b", "c")
    any("a", "b", "c", "d")
    any("a", "b", "c", "d", "e")
    any("a", "b", "c", "d", "e", "f")
    any("a", "b", "c", "d", "e", "f", "g")
    any("a", "b", "c", "d", "e", "f", "g", "h")
    any("a", "b", "c", "d", "e", "f", "g", "h", "i")
    any("a", "b", "c", "d", "e", "f", "g", "h", "i", "j")

# Generated at 2022-06-21 10:24:06.313073
# Unit test for function untokenize
def test_untokenize():
    from io import StringIO
    import untokenize

    sample_tokens = [
        (untokenize.NUMBER, "1"),
        (untokenize.OP, "+"),
        (untokenize.NUMBER, "2"),
        (untokenize.NEWLINE, "\n"),
        (untokenize.NAME, "print"),
        (untokenize.OP, "("),
        (untokenize.NUMBER, "1"),
        (untokenize.OP, "+"),
        (untokenize.NUMBER, "2"),
        (untokenize.OP, ")"),
        (untokenize.NEWLINE, "\n"),
    ]

    # test round trip
    result = untokenize.untokenize(sample_tokens)

# Generated at 2022-06-21 10:24:16.180582
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    """
    Test case for the compat method of the Untokenizer class

    The following is an example of the tokens it will generate
    Number = 3
    [NEWLINE]
    Number = 2 + 3
    """
    # Test 1
    readline = [
        (NUMBER, "3"),
        (NEWLINE, "\n"),
        (NUMBER, "2"),
        (OP, "+"),
        (NUMBER, "3"),
    ]
    ut = Untokenizer()
    ut.compat(readline[0], readline[1:])
    print(ut.tokens)
    # Test 2

# Generated at 2022-06-21 10:24:27.615254
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    # Input and expected output.
    # Three cases:
    #   * tokenize.tok_name[x] is a simple string
    #   * tokenize.tok_name[x] is a parenthesized list, where the parenthesis should be removed.
    #   * tokenize.tok_name[x] is a parenthesized list, where the parenthesis should be removed and the list has multiple elements.
    # The NEWLINE token is explicitly tested.

# Generated at 2022-06-21 10:24:31.882986
# Unit test for function printtoken
def test_printtoken():
    tok = tokenize.generate_tokens(StringIO("x = 3").readline)
    for type, token, start, end, line in tok:
        printtoken(type, token, start, end, line)


# Generated at 2022-06-21 10:24:42.039386
# Unit test for function detect_encoding
def test_detect_encoding():
    # Test BOM
    result = detect_encoding(lambda: BOM_UTF8)
    assert result == ("utf-8-sig", [])

    # Test UTF8-COOKIE
    def readline1() -> bytes:
        if readline1.lines:
            return readline1.lines.pop(0)
        else:
            raise StopIteration

    readline1.lines = [br"# coding: utf-8"]
    result = detect_encoding(readline1)
    assert result == ("utf-8", [])
    # Test UTF8-COOKIE with a space
    readline1.lines = [br"# coding:utf-8"]
    result = detect_encoding(readline1)
    assert result == ("utf-8", [])
    # Test UTF8-COOKIE

# Generated at 2022-06-21 10:24:45.585562
# Unit test for constructor of class TokenError
def test_TokenError():
    try:
        raise TokenError("bad token")
    except TokenError as ex:
        assert str(ex) == "bad token"



# Generated at 2022-06-21 10:24:54.583800
# Unit test for function untokenize
def test_untokenize():
    import tokenize
    import io

    untokenize = untokenize
    readline = io.BytesIO(b"# a\n#\n# b\n").readline
    result = untokenize(tokenize.generate_tokens(readline))
    assert result == "# a\n\n# b\n"

    untokenize = Untokenizer().untokenize
    readline = io.BytesIO(b"# a\n#\n# b\n").readline
    result = untokenize(tokenize.generate_tokens(readline))
    assert result == "  # a\n\n  # b\n"



# Generated at 2022-06-21 10:25:02.964723
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 1
    u.prev_col = 8
    u.add_whitespace((1, 10))
    assert u.tokens, ["  "]
    u.add_whitespace((1, 11))
    assert u.tokens, ["    "]
    u.add_whitespace((2, 0))
    assert u.tokens, ["    "]
    u.add_whitespace((2, 5))
    assert u.tokens, ["    ", "     "]



# Generated at 2022-06-21 10:25:06.224457
# Unit test for function printtoken
def test_printtoken():
    input = '''
    fname = input("Enter file name:")
    '''
    lines = input.split('\r')
    list(generate_tokens(lines.__iter__().__next__))



# Generated at 2022-06-21 10:25:11.587958
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    # All tests give the same output to make it easier to compare the different
    # cases.
    u = Untokenizer()
    inp = [
        (1, "a"),
        (2, "b"),
        (0, ""),
        (4, ""),
        (1, ""),
        (1, "c"),
        # This is an empty token, to test adding whitespace before the endmarker.
        (0, ""),
    ]
    assert u.untokenize(inp) == "a b\n\n\n\nc"



# Generated at 2022-06-21 10:25:38.775905
# Unit test for function printtoken
def test_printtoken():
    printtoken(1, "abc", (1,2), (2,3), "def")
    assert 1 == 1

# End unit test

tokenize = None



# Generated at 2022-06-21 10:25:49.592791
# Unit test for function detect_encoding
def test_detect_encoding():
    import io
    import tokenize as _tokenize
    from tokenize import detect_encoding

    def assert_detect_encoding(
        expected_encoding: str,
        text: Union[str, bytes],
        expected_text_lines: Optional[List[str]] = None,
    ) -> None:
        if isinstance(text, str):
            text = text.encode(expected_encoding)
        if expected_text_lines is None:
            expected_text_lines = text.splitlines(False)
        expected_text_lines = [
            s.encode(expected_encoding) for s in expected_text_lines
        ]
        encoding, lines = detect_encoding(io.BytesIO(text).readline)

# Generated at 2022-06-21 10:25:55.103869
# Unit test for function maybe
def test_maybe():
    assert maybe("a")("") == ""
    assert maybe("a")("a") == "a"
    assert maybe("a")("b") == ""
    assert maybe("a")("ab") == "a"
    assert maybe("a")("ba") == ""
    assert maybe("a")("aba") == "a"
    assert maybe("a")("aab") == "aa"
    assert maybe("a")("baa") == ""
    assert maybe("ab")("") == ""
    assert maybe("ab")("a") == ""
    assert maybe("ab")("b") == ""
    assert maybe("ab")("ab") == "ab"
# /Unit test for function maybe


# Generated at 2022-06-21 10:25:57.556390
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("a", "b") == "((a)|(b))*"



# Generated at 2022-06-21 10:26:01.586031
# Unit test for function generate_tokens
def test_generate_tokens():
    with open('test_tokenize.py', 'rb') as f:
        tokens = generate_tokens(f.readline)
        for t in tokens:
            print(t)



# Generated at 2022-06-21 10:26:13.347305
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    from io import StringIO

    from blib2to3.pgen2.tokenize import generate_tokens, tok_name

    def detokenize(iterable):
        ut = Untokenizer()
        return ut.untokenize(iterable)

    def get_tokens(line, utoktype=None):
        tokens = list(generate_tokens(StringIO(line).readline))
        if utoktype is not None:
            tokens.append((utoktype, line))
        return tokens

    # single line

# Generated at 2022-06-21 10:26:16.773585
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    s = "\n".join(
        [
            "def foo():",
            "    bar = 2",
            "    print(f'{bar}')",
            "",
            "",
            "",
            "foo()",
        ]
    )
    from tokenize import tokenize

    from io import BytesIO

    tokens = list(tokenize(BytesIO(s.encode("utf-8")).readline))
    ut = Untokenizer()
    s2 = ut.untokenize(tokens)
    assert s == s2



# Generated at 2022-06-21 10:26:23.470782
# Unit test for function maybe
def test_maybe():
    m = maybe("a")
    assert m.match("")
    assert m.match("a")
    assert not m.match("aa")
    m = maybe("a", "b")
    assert m.match("")
    assert m.match("a")
    assert m.match("b")
    assert not m.match("aa")
    assert not m.match("ab")



# Generated at 2022-06-21 10:26:31.384258
# Unit test for method add_whitespace of class Untokenizer
def test_Untokenizer_add_whitespace():
    u = Untokenizer()
    u.prev_row = 3
    u.prev_col = 0
    assert u.tokens == []
    u.add_whitespace((3, 0))
    assert u.tokens == []
    u.add_whitespace((4, 0))
    assert u.tokens == ["\n"]
    u.tokens = []
    u.add_whitespace((3, 8))
    assert u.tokens == ["        "]



# Generated at 2022-06-21 10:26:40.850669
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()

# Generated at 2022-06-21 10:27:03.946367
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO


# Generated at 2022-06-21 10:27:14.351193
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    untok = Untokenizer()
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" "]
    untok.add_whitespace((1, 1))
    assert untok.tokens == [" ", " "]
    untok.add_whitespace((1, 2))
    assert untok.tokens == [" ", " ", " "]
    untok.add_whitespace((2, 2))
    assert untok.tokens == [" ", " ", " ", "\n"]
    untok.add_whitespace((2, 1))
    assert untok.tokens == [" ", " ", " ", "\n", " "]
    untok.add_whitespace((2, 10))

# Generated at 2022-06-21 10:27:18.657740
# Unit test for constructor of class TokenError
def test_TokenError():
    import sys
    try:
        raise TokenError
    except TokenError as e:
        assert isinstance(e, TokenError)
        assert isinstance(e, SyntaxError)



# Generated at 2022-06-21 10:27:29.449451
# Unit test for function tokenize_loop
def test_tokenize_loop():
    import io
    import sys
    import tokenize

    if sys.version_info[0] >= 3:
        def isid(s):
            return s.isidentifier()

        def is_int(s):
            return s.isdigit()

        def is_string(s):
            return repr(s) != s or s.endswith("'") or s.endswith('"')

        readline = getattr(io, "BytesIO", io.StringIO).__new__(io.StringIO)
    else:
        def isid(s):
            return s.isidentifier()

        def is_int(s):
            return s.isdigit()


# Generated at 2022-06-21 10:27:41.044713
# Unit test for function group
def test_group():
    print(group('abc', 'def'))
test_group()

# Tail end of 'stringprefix' in the grammar (we defer compiling this
# until we know what the prefix string is).
#
# Note: we use the "trick" from PEP 293 to enable the BOM mark to be included
# in the string prefix, even though it really is not part of the prefix.
#
StringPrefix_re = None  # type: Pattern[Text]

# Note: since we're using a raw-byte string here, use the rb prefix
#
whitespace_re = re.compile(br"[ \f\t]*")

# Note: since we're using a raw-byte string here, use the rb prefix
#

# Generated at 2022-06-21 10:27:43.402440
# Unit test for function any
def test_any():
    assert any("abc", "def") == "(abc|def)*"



# Generated at 2022-06-21 10:27:50.789163
# Unit test for method compat of class Untokenizer
def test_Untokenizer_compat():
    import io
    import tokenize
    from io import BytesIO
    r = io.StringIO("<html>\n<head>\n<title>test</title>\n</head>\n</html>\n")
    x = tokenize.generate_tokens(r.readline)
    tokenize.tokenize(r.readline, x)
    x = Untokenizer()
    result = x.compat(((1, '<'),), x)
    print(result)




# Generated at 2022-06-21 10:27:52.689291
# Unit test for function printtoken
def test_printtoken():
    printtoken(NAME, "f", (1,0), (1,1), "f()")

# Utility functions

# Generated at 2022-06-21 10:27:55.086436
# Unit test for function any
def test_any():
    assert any("a") == "(a)*"
    assert any("a", "b") == "(a|b)*"



# Generated at 2022-06-21 10:27:57.376408
# Unit test for function detect_encoding
def test_detect_encoding():
    import io

    def readline():
        yield io.BytesIO(
            b"# -*- coding: latin-1 -*-\n"
            b"# vim: et sts=4 sw=4 ts=4\n"
            b"print('coucou')\n"
        ).readline()

    assert detect_encoding(readline) == ("iso-8859-1", [])



# Generated at 2022-06-21 10:28:39.826451
# Unit test for function generate_tokens
def test_generate_tokens():
    import unittest

    class Case(unittest.TestCase):
        def check_tokenize(self, source, expected_tokens, **kwargs):
            expected_result = [(x[0], x[1], [(y, z) for (y, z) in x[2:]]) for x in expected_tokens]
            self.assertEqual(list(tokenize(io.BytesIO(source.encode("utf-8")).readline, **kwargs)), expected_result)


# Generated at 2022-06-21 10:28:40.396622
# Unit test for function group
def test_group(): pass



# Generated at 2022-06-21 10:28:45.239876
# Unit test for constructor of class TokenError
def test_TokenError():
    # Check that str() of exception works correctly
    try:
        raise TokenError
    except TokenError as e:
        assert str(e) == ""
    # Check that str(exception(value)) works correctly
    try:
        raise TokenError(3)
    except TokenError as e:
        assert str(e) == "3"



# Generated at 2022-06-21 10:28:51.152922
# Unit test for function generate_tokens
def test_generate_tokens():
    from io import StringIO
    from types import GeneratorType

    tokens = generate_tokens(StringIO('print(1)\n').readline)
    assert isinstance(tokens, GeneratorType), repr(tokens)
    assert next(tokens) == (NAME, 'print', (1, 0), (1, 5), 'print(1)\n')
    assert next(tokens) == (OP, '(', (1, 5), (1, 6), 'print(1)\n')
    assert next(tokens) == (NUMBER, '1', (1, 6), (1, 7), 'print(1)\n')
    assert next(tokens) == (OP, ')', (1, 7), (1, 8), 'print(1)\n')

# Generated at 2022-06-21 10:28:59.567944
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    import io
    import tokenize
    from io import BytesIO

    u = Untokenizer()
    # a sample program
    text = (
        'def square(x):\n'
        '    """Return the square of x."""\n'
        '    return x ** 2\n'
    )
    # a BytesIO instance is required to mimic a file
    g = tokenize.generate_tokens(BytesIO(text.encode('utf-8')).readline)
    # feed it to the untokenizer
    r = u.untokenize(g)
    assert r == text



# Generated at 2022-06-21 10:29:00.936493
# Unit test for constructor of class StopTokenizing
def test_StopTokenizing():
    try:
        raise StopTokenizing
    except StopTokenizing:
        pass



# Generated at 2022-06-21 10:29:12.842065
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    u = Untokenizer()

# Generated at 2022-06-21 10:29:20.667003
# Unit test for function tokenize
def test_tokenize():
    import io

    f = io.StringIO("def foo(x):\n  return x**2\n")
    g = generate_tokens(f.readline)
    token_type = token.ENDMARKER
    for token in g:
        assert token == next(g)
        token_type = token[0]
    assert token_type == token.ENDMARKER
    f = io.StringIO("def foo(x):\n  return x**2\n")
    token_type = token.ENDMARKER
    for token in generate_tokens(f.readline):
        token_type = token[0]
    assert token_type == token.ENDMARKER
    f = io.StringIO("def foo(x):\n  return x**2\n")

# Generated at 2022-06-21 10:29:25.497989
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    tokgen = generate_tokens(iter(["print 1\n", "print 2\n"]).__next__)
    print(u.untokenize(tokgen))


untokenize = Untokenizer().untokenize



# Generated at 2022-06-21 10:29:28.799229
# Unit test for function group
def test_group():
    assert group("a", "ab") == "(a|ab)"
    assert re.match(group("a", "ab"), "a")
    assert re.match(group("a", "ab"), "ab")
    assert not re.match(group("a", "ab"), "b")



# Generated at 2022-06-21 10:30:14.450862
# Unit test for constructor of class Untokenizer
def test_Untokenizer():
    u = Untokenizer()
    u.add_whitespace((1, 0))
    u.tokens.append("if")
    u.tokens.append(" ")
    u.tokens.append("True")
    u.tokens.append(":")
    u.tokens.append("\n")
    u.prev_row = 2
    u.tokens.append("  pass")
    result = u.untokenize([(1, "if"), (1, " "), (1, "True"), (1, ":"), (1, "\n"), (1, "  pass")])
    assert result == "if True:\n  pass"



# Generated at 2022-06-21 10:30:17.924402
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    untok = Untokenizer()

    # issue1733:
    def check(result, iterable):
        print('result: "%s"' % result)
        assert untok.untokenize(iterable) == result

    check("name 0\n", [(NAME, "name"), (NUMBER, "0"), (NEWLINE, "\n")])


# Generated at 2022-06-21 10:30:19.089380
# Unit test for function any
def test_any():
    assert any('a', 'b') == '(a|b)*'



# Generated at 2022-06-21 10:30:29.358141
# Unit test for method untokenize of class Untokenizer
def test_Untokenizer_untokenize():
    global token, tokenize
    global string, regex
    import token
    import tokenize
    import re as regex
    import io

    class Capture:
        """
        Capture generator.
        """

        _capture: Text

        def __init__(self, generator, join: bool = False) -> None:
            self._capture = ""
            self._join = join
            for value in generator:
                self._capture += repr(value)

        def __str__(self) -> Text:
            return self._capture

        def __repr__(self) -> Text:
            return repr(str(self))

    def check_tokenize_result(input: Text, *, output: Text = "") -> None:
        """
        Checks that the tokenized string is equal to the expected output.
        """
        # Read the

# Generated at 2022-06-21 10:30:32.641336
# Unit test for function printtoken
def test_printtoken():
    printtoken(token.ENCODING, b"utf-8", (0,0), (0,0), b"")
    printtoken(token.ENCODING, "utf-8", (0,0), (0,0), "")

# Unit tests for tabsize

# Generated at 2022-06-21 10:30:38.889681
# Unit test for function printtoken
def test_printtoken():
    printtoken(NUMBER, 42, (0,0), (0,5), '\n')
    printtoken(NUMBER, 42, (0,0), (0,4), '\n')
    printtoken(NUMBER, 42, (0,0), (0,0), '\n')

# Data structure used by tokenize()
TokenInfo = Tuple[int, Text, Text, Tuple[int, int], Tuple[int, int], Text]



# Generated at 2022-06-21 10:30:43.753946
# Unit test for function untokenize
def test_untokenize():
    src1 = "def f():\n    print(1)\n"
    src2 = "def f(a, b, c,\n    d, e, f):\n    print(1)\n"
    src3 = "def g(a, b, c,\n    d, e, f,\n    g):\n    print(1)\n"
    src4 = "def h(a, b, c,\n    d, e, f,\n    g,):\n    print(1)\n"
    src5 = "def i(a, b, c,\n    d, e, f,\n    g,\n    ):\n    print(1)\n"