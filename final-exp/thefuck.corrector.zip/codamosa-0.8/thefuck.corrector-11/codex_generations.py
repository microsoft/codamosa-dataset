

# Generated at 2022-06-12 10:00:54.278001
# Unit test for function organize_commands

# Generated at 2022-06-12 10:01:00.294920
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    Result = namedtuple('Result', 'corrected priority')
    command = CorrectedCommand('f', 'f', '', 0)
    commands = (
        Result('f', 3),
        Result('f', 1),
        Result('g', 1),
        Result('g', 3)
    )
    results = [cmd for cmd in organize_commands([CorrectedCommand(c, c.corrected, c.priority) for c in commands])]
    assert len(results) == 3
    assert results[0].corrected == 'f'
    assert results[0].priority == 1
    assert results[1].corrected == 'g'
    assert results[1].priority == 1

# Generated at 2022-06-12 10:01:01.125654
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 20

# Generated at 2022-06-12 10:01:03.209724
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    paths = get_rules_import_paths()
    for path in paths:
        assert isinstance(path, Path)
        assert path.name == 'rules'
        

# Generated at 2022-06-12 10:01:13.552265
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    import os
    import shutil
    import tempfile
    import textwrap

    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)


# Generated at 2022-06-12 10:01:16.006626
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    # finds rule path even if it is in a python package
    assert Path(__file__).parent.joinpath('rules') in list(get_rules_import_paths())


# Generated at 2022-06-12 10:01:25.204283
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    import os.path, imp
    import inspect
    import thefuck.conf as conf
    def get_module_from_filename(path):
        """
        Imports and returns the module at the given path,
        relative to the thefuck project root directory.
        """
        rel_path = os.path.relpath(path, conf.ROOT_DIR)
        module_name, _ = os.path.splitext(rel_path.replace(os.path.sep, '.'))
        return imp.load_source(module_name, path)
    
    def get_rules_from_module(module):
        """
        Returns all 'rules' defined in the given module (the rules must be
        subclasses of Rule).
        """

# Generated at 2022-06-12 10:01:36.904165
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    # Get the path of the source code and append the /thefuck to it
    # because it is the parent folder of the __init__.py
    source_code_path = Path(os.path.dirname(os.path.realpath(__file__)))
    source_code_path = source_code_path.joinpath('thefuck')
    # Append /test/test_rules to the path
    test_rules_path = source_code_path.joinpath('test').joinpath('test_rules')
    # Append the path to the python path
    sys.path.append(str(source_code_path))
    # Get the rules import paths

# Generated at 2022-06-12 10:01:46.270556
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))
    __rules_path__ = '/'.join([__location__] + ['rules'])
    __user_path__ = '/'.join([__location__] + ['..', '..', '..', '.config', 'thefuck', 'rules'])
    __contrib_path__ = '/'.join([__location__] + ['..', '..', '..', '..', 'thefuck_contrib_progval_rules-bf6a2b23', 'rules'])
    actual_result = get_rules_import_paths()
    expected_result = [__rules_path__, __user_path__, __contrib_path__]

# Generated at 2022-06-12 10:01:54.750702
# Unit test for function organize_commands
def test_organize_commands():
    CorrectedCommand = Command.CorrectedCommand
    command_1 = CorrectedCommand("cd /src", 200)
    command_2 = CorrectedCommand("cd /src", 100)
    command_3 = CorrectedCommand("cd /src", 300)
    assert [command_1] == list(organize_commands((command_1, command_2, command_3)))
    assert [command_1] == list(organize_commands((command_1, command_2)))
    assert [command_1] == list(organize_commands((command_1, command_2, command_2)))
    assert [command_1] == list(organize_commands((command_2, command_2, command_1)))

# Generated at 2022-06-12 10:02:05.219599
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    # Test that organizing results works correctly
    test_command = Command('git branchh', 'git branch', '', 0)
    test_command_corrected = Command('git branch', 'git branch', '', 1)
    test_get_corrected_commands_results = [test_command, test_command_corrected]
    assert get_corrected_commands(test_command) == test_get_corrected_commands_results

# Generated at 2022-06-12 10:02:07.304471
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(get_rules_import_paths().__next__()) == Path(__file__).parent.joinpath('rules')
    assert Path(get_rules_import_paths().__next__()) == settings.user_dir.joinpath('rules')



# Generated at 2022-06-12 10:02:16.332869
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rule_1 = Rule.from_path(Path(__file__).parent.joinpath('rules').joinpath('git.py'))
    rule_2 = Rule.from_path(Path(__file__).parent.joinpath('rules').joinpath('java.py'))
    assert list(get_loaded_rules([rule_1.path, rule_2.path])) == [rule_1, rule_2]
    assert list(get_loaded_rules([rule_1.path])) == [rule_1]
    rule_3 = Rule.from_path(Path(__file__).parent.joinpath('rules').joinpath('__init__.py'))
    assert list(get_loaded_rules([rule_3.path])) == []


# Generated at 2022-06-12 10:02:17.026336
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    get_rules_import_paths()

# Generated at 2022-06-12 10:02:19.045278
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    command = Command('uname', '')
    corrected = tuple(get_corrected_commands(command))
    assert len(corrected) > 0
    assert corrected[0].script == 'uname -a'

# Generated at 2022-06-12 10:02:25.145872
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .utils import which


# Generated at 2022-06-12 10:02:27.260414
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    rules_import_paths = get_rules_import_paths()

# Generated at 2022-06-12 10:02:35.285265
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

    class DuplicateCommand(CorrectedCommand):
        def __init__(self):
            super(DuplicateCommand, self).__init__(
                u'echo 1; echo 2', u'echo 1; echo 2', priority=1)

    class DummyCommand(CorrectedCommand):
        def __init__(self, priority):
            super(DummyCommand, self).__init__(
                u'echo 3', u'echo 3', priority=priority)

    result = organize_commands([
        DummyCommand(0.5), DummyCommand(0.7), DummyCommand(0.4),
        DummyCommand(0.6), DummyCommand(0.9), DuplicateCommand()])


# Generated at 2022-06-12 10:02:43.557609
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.sudo import match, get_corrected_commands
    from .rules.git_svn import match, get_corrected_commands

    command = Command("git chckout aa", "git: 'chckout' is not a git command. See 'git --help'.\n")

    corrected_commands = get_corrected_commands(command)

    res = []
    for c in corrected_commands:
        res.append(c)

    assert len(res) == 2
    assert res[0].script == "git checkout aa"
    assert res[1].script == "git svn checkout aa"

    command = Command("sudo echo 2", "sudo: echo: command not found\n")

    corrected_commands = get_corrected_commands(command)



# Generated at 2022-06-12 10:02:47.315152
# Unit test for function organize_commands
def test_organize_commands():
    assert list(organize_commands([
        CorrectedCommand('foo'),
        CorrectedCommand('bar'),
        CorrectedCommand('foo')])) == [
            CorrectedCommand('foo'),
            CorrectedCommand('bar')]

    assert list(organize_commands([
        CorrectedCommand('foo', priority=1),
        CorrectedCommand('bar', priority=2),
        CorrectedCommand('baz', priority=3)])) == [
            CorrectedCommand('foo'),
            CorrectedCommand('bar'),
            CorrectedCommand('baz')]

# Generated at 2022-06-12 10:03:02.999237
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():

    path = list(get_rules_import_paths())
    assert path[0] == 'thefuck/rules'
    assert path[1] == '~/.config/thefuck/rules'
    assert path[2] == 'thefuck/contrib_rules/rules'

# Generated at 2022-06-12 10:03:06.485850
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rule_path = Path(__file__).parent.joinpath('rules')
    rule_paths = [rule_path.joinpath('alias.py')]
    assert len(list(get_loaded_rules(rule_paths))) > 0


# Generated at 2022-06-12 10:03:15.077431
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    # Test with no duplicates
    commands = [CorrectedCommand("ls", 3),
                CorrectedCommand("ls -a", 4),
                CorrectedCommand("ls -a -l", 2)]
    assert list(organize_commands(commands)) == [commands[1], commands[0], commands[2]]

    # Test with duplicates
    commands = [CorrectedCommand("ls", 3),
                CorrectedCommand("ls", 4),
                CorrectedCommand("ls -a", 2)]
    assert list(organize_commands(commands)) == [commands[1], commands[2]]

# Generated at 2022-06-12 10:03:19.174049
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    assert set(get_corrected_commands('apt-get install vi')) == set([CorrectedCommand(script='sudo apt-get install vim', side_effect=None, priority=200), CorrectedCommand(script='sudo apt-get install vim-gtk', side_effect=None, priority=200)])

# Generated at 2022-06-12 10:03:20.532717
# Unit test for function get_rules
def test_get_rules():
    assert [Rule('foo')] == get_rules()

# Generated at 2022-06-12 10:03:23.794398
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = Path(__file__).parent.joinpath('rules')
    rule_list = get_rules()
    rules_paths_str = rules_paths.strpath

    for rule in rule_list:
        assert(rule.path.strpath.startswith(rules_paths_str))

# Generated at 2022-06-12 10:03:29.026348
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from tests.utils import Command
    assert len(list(get_corrected_commands(Command('truie')))) == 1
    assert len(list(get_corrected_commands(Command('fuck')))) == 6
    assert len(list(get_corrected_commands(Command('echo')))) == 1
    assert len(list(get_corrected_commands(Command('webstorm')))) == 0

# Generated at 2022-06-12 10:03:33.097537
# Unit test for function organize_commands
def test_organize_commands():
    """Tests that organize_commands doesn't yield duplicates."""
    fake_commands = [
        CorrectedCommand(command=Command(script='ls',
                                         stdout='stdout',
                                         stderr='stderr'),
                         output='output',
                         priority=100)
        for _ in range(20)]
    assert len(list(organize_commands(fake_commands))) == 1



# Generated at 2022-06-12 10:03:38.815822
# Unit test for function organize_commands
def test_organize_commands():
    # organize_commands is a generator, so we need to extract the result to
    # compare it
    commands = [CorrectedCommand(u'yeah', u'No', u'yeah')]
    # Should yield an unique element
    assert list(organize_commands(commands)) == commands
    # Adding more elements to the array
    commands.append(CorrectedCommand(u'yeah', u'No', u'yeah'))
    commands.append(CorrectedCommand(u'yeah', u'No', u'yes'))
    assert list(organize_commands(commands)) == [
        CorrectedCommand(u'yeah', u'No', u'yeah'),
        CorrectedCommand(u'yeah', u'No', u'yes')]



# Generated at 2022-06-12 10:03:44.600330
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    correct1 = CorrectedCommand('ls', 'ls', 80)
    correct2 = CorrectedCommand('dir', 'dir', 90)
    correct3 = CorrectedCommand('ls', 'ls', 100)
    correct4 = CorrectedCommand('dir', 'dir', 90)
    correct5 = CorrectedCommand('ls', 'ls', 80)
    correct6 = CorrectedCommand('dir', 'dir', 90)
    corrected_commands = [correct1, correct2, correct3, correct4, correct5, correct6]
    assert list(organize_commands(corrected_commands)) == [correct3, correct2]

# Generated at 2022-06-12 10:04:11.793569
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    """
    >>> import os
    >>> print(get_corrected_commands(os.system))
    """
    pass

# Generated at 2022-06-12 10:04:20.470723
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    import subprocess
    """
    test_rules_path = Path(Path(__file__).parent.joinpath('rules'))
    test_rule = Rule.from_path(test_rules_path.joinpath('__init__.py'))
    test_command = Command('fuck')
    if test_rule.is_match(test_command):
        test_result = test_rule.get_corrected_commands(test_command)
        print(test_result)
    """
    # test_rules_path = Path(Path(__file__).parent.joinpath('rules'))
    test_rules_path = Path(Path(__file__).parent.joinpath('rules'))
    paths = [rule_path for rule_path in sorted(test_rules_path.glob('*.py'))]

# Generated at 2022-06-12 10:04:25.253466
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'),
                                              settings.user_dir.joinpath('rules'),
                                              Path(sys.path[0]).joinpath('thefuck_contrib_django')]

# Generated at 2022-06-12 10:04:34.142047
# Unit test for function organize_commands
def test_organize_commands():
    import types
    import thefuck
    new_rule1 = type(str('test_rule1'), (object,), {
        'is_match': lambda _, __: True,
        'get_corrected_commands': lambda _, __: [thefuck.types.CorrectedCommand(
            script='test_script1', side_effect='test_side_effect1',
            priority=40,
            _fix=lambda: None)],
        'is_enabled': True,
        'priority': 50})

# Generated at 2022-06-12 10:04:38.177728
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert [file.name for file in get_rules_import_paths()] == [
        '__init__.py', 'git.py', 'gem.py', 'ls_cd.py', 'ruby.py', 'npm.py']


# Generated at 2022-06-12 10:04:47.235293
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .conf import settings
    from .utils import get_all_executables
    from .utils import get_closest

    settings.cache_user_rules = False
    settings.user_rules = {
        'fuck': [{'match': '*', 'get_new_command': 'echo test', 'priority': 0}],
        'fuck_alias': [{'match': '*', 'get_new_command': 'echo test', 'priority': 0}],
        'fuck_alias_2': [{'match': '*', 'get_new_command': 'echo test', 'priority': 0}]}
    correct_command = str(get_closest(get_all_executables(), 'fuck'))

# Generated at 2022-06-12 10:04:49.034353
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    get_loaded_rules(['/tmp'])

if __name__ == '__main__':
    test_get_loaded_rules()

# Generated at 2022-06-12 10:04:50.452176
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert(len(list(get_rules_import_paths())) > 2)


# Generated at 2022-06-12 10:04:51.606198
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path.cwd().joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-12 10:05:00.737493
# Unit test for function organize_commands
def test_organize_commands():
    CorrectedCommand = collections.namedtuple('CorrectedCommand',
                                              'corrected, priority')
    # Duplicates
    assert list(organize_commands(iter([
        CorrectedCommand(corrected='ls', priority=10),
        CorrectedCommand(corrected='ls', priority=9),
    ]))) == [CorrectedCommand(corrected='ls', priority=10)]
    # Sorting

# Generated at 2022-06-12 10:06:01.974883
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .test import get_test_data

    test_data = get_test_data()
    assert {corrected_command
            for test in test_data for corrected_command in
            organize_commands([CorrectedCommand(test.script,
                                                test.script,
                                                None,
                                                test.priority - 1)])} == {
                CorrectedCommand('echo "The Fuck"',
                                 'echo "The Fuck"',
                                 None),
                CorrectedCommand('fuck', 'echo "The Fuck"', None)}

# Generated at 2022-06-12 10:06:09.664532
# Unit test for function organize_commands
def test_organize_commands():
    class Command:
        def __init__(self, command_string, priority):
            self.script = command_string
            self.priority = priority

        def __repr__(self):
            return self.script

        def __str__(self):
            return self.script

    first_command = Command('git status', 100)
    commands = organize_commands([
        Command('git reset --hard', 90),
        Command('git reset --hard', 80),
        Command('git status', 100),
        Command('git status', 95),
        Command('git log', 99),
        Command('git reset --hard', 100),
        Command('git commit -v', 90),
        first_command])  # duplicate

# Generated at 2022-06-12 10:06:15.244634
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([]))) == 0
    assert len(list(get_loaded_rules([Path('')]))) == 0
    assert len(list(get_loaded_rules([Path('__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/init.py/')]))) == 0
    assert len(list(get_loaded_rules([Path('/deinit.py/')]))) == 0
    assert len(list(get_loaded_rules([Path('/de_init.py/')]))) == 0
    assert len(list(get_loaded_rules([Path('/init.pyc')]))) == 0
    assert len(list(get_loaded_rules([Path('/init.pyo')]))) == 0

# Generated at 2022-06-12 10:06:17.311573
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    command = types.Command('echo test', '', 'echo $TEST')
    result = list(get_corrected_commands(command))
    assert len(result) > 0

# Generated at 2022-06-12 10:06:25.897295
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    rules_import_paths = [str(x) for x in get_rules_import_paths()]

# Generated at 2022-06-12 10:06:33.454722
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    commands = [CorrectedCommand(['ls'], '', 1), CorrectedCommand(['ls'], '', 2),
                CorrectedCommand(['ls'], '', 3)]
    assert [cmd.priority for cmd in organize_commands(commands)] == [3, 2, 1]

    commands = [CorrectedCommand(['ls'], '', 1), CorrectedCommand(['ls'], '', 2),
                CorrectedCommand(['ls'], '', 3), CorrectedCommand(['ls'], '', 1)]
    assert [cmd.priority for cmd in organize_commands(commands)] == [3, 2, 1]


# Generated at 2022-06-12 10:06:36.549991
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    from . import main
    from os.path import abspath, dirname, join
    def _join_rel_to(rel_path):
        return abspath(join(dirname(__file__), rel_path))
    expected = [_join_rel_to('rules'),
                main.settings.user_dir.joinpath('rules')]
    assert expected == list(get_rules_import_paths())

# Generated at 2022-06-12 10:06:37.376305
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths()



# Generated at 2022-06-12 10:06:45.597637
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    import thefuck.rules
    thefuck_pkg_path = Path(thefuck.rules.__file__).parent.parent
    user_dir = thefuck_pkg_path.parent
    paths = list(get_rules_import_paths())
    assert Path(thefuck.rules.__file__).parent in paths
    assert user_dir.joinpath('rules') in paths

    new_pkg_path = thefuck_pkg_path.joinpath('thefuck_contrib_1')
    new_pkg_path.mkdir()
    new_pkg_path.joinpath('rules').mkdir()
    sys.path.append(str(new_pkg_path))

# Generated at 2022-06-12 10:06:52.619508
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    # Test for getting corrected commands
    global get_rules
    get_rules = lambda : [Rule(r'^echo "test"$', 'echo test', 1, True)]

    assert [command.script for command in get_corrected_commands(Command())] == ['echo test']

    # Test for correct sorted command
    global get_rules
    get_rules = lambda : [Rule(r'^echo "test"$', 'echo test1', 1, True), Rule(r'^echo "test"$', 'echo test2', 2, True)]

    assert [command.script for command in get_corrected_commands(Command())] == ['echo test1', 'echo test2']

# Generated at 2022-06-12 10:09:11.601754
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules').as_posix() in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules').as_posix() in get_rules_import_paths()
    assert 'thefuck_contrib_go' in get_rules_import_paths()

# Generated at 2022-06-12 10:09:14.264230
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = [sys.modules[__name__].__file__, 'not_a_file']
    assert list(get_loaded_rules(rules_paths))


# Generated at 2022-06-12 10:09:22.296740
# Unit test for function organize_commands
def test_organize_commands():
    from faketha.types import CorrectedCommand as CC
    assert list(organize_commands([])) == []
    assert list(organize_commands([CC('ls', '', '', 1)])) == [CC('ls', '', '', 1)]

# Generated at 2022-06-12 10:09:30.696026
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .shells import Bash
    from .utils import wrap_settings

    assert list(get_corrected_commands(Command('ff', ''))) == [
        CorrectedCommand(rule_name='brew',
                         new_command='brew update && brew upgrade',
                         priority=2),
        CorrectedCommand(rule_name='git',
                         new_command='git fetch && git pull',
                         priority=3)]


# Generated at 2022-06-12 10:09:31.184591
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    pass

# Generated at 2022-06-12 10:09:34.458519
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command

    corrected_commands = get_corrected_commands(
        Command('find . -name *some_file_name*', '.'))

    #After get_corrected_commands, the list of commands is sorted,
    # and has duplicates removed
    assert len(corrected_commands) == 1

# Generated at 2022-06-12 10:09:41.647973
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rule_paths = [Path('rules/bash.py'), Path('rules/git.py'), Path('rules/ls.py'),
                  Path('rules/python.py'), Path('rules/__init__.py')]
    rules = list(get_loaded_rules(rule_paths))

    assert len(rules) == 4

    for rule in rules:
        assert rule.is_enabled

    bash_rule = list(filter(lambda rule: rule.name == 'bash', rules))[0]

# Generated at 2022-06-12 10:09:51.058307
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    import pytest
    # Create CorrectedCommand object
    crr_command = CorrectedCommand
    # Send a mass of the same commands
    correct_commands = [crr_command(u'ls', u'ls', u'ls', u''),
                        crr_command(u'ls', u'ls', u'ls', u''),
                        crr_command(u'ls', u'ls', u'ls', u'')]
    # Checking for the presence of dublicates
    # and the absence of sorting
    result = list(organize_commands(correct_commands))
    assert len(result) == 1
    assert result[0].script == u'ls'
    # Send a mass of different commands

# Generated at 2022-06-12 10:09:57.555109
# Unit test for function get_loaded_rules
def test_get_loaded_rules():

    def _mocked_rules_module(name):
        return Mock(__name__=name, is_enabled=True)

    mocked_rules = [_mocked_rules_module('mocked_rule_1'),
                    _mocked_rules_module('mocked_rule_2')]
    with patch('thefuck.rules.builtins', mocked_rules):
        assert [rule._rule for rule in get_loaded_rules([])] == mocked_rules
        assert [rule._rule for rule in get_loaded_rules([Mock()])] == mocked_rules

# Generated at 2022-06-12 10:09:59.085781
# Unit test for function get_rules
def test_get_rules():
    assert_that(len(list(get_rules()))).is_equal_to(11)