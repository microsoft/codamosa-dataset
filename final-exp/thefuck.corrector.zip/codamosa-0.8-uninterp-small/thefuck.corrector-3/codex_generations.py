

# Generated at 2022-06-26 04:40:28.092210
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    # Make sure the current dir is the parent dir of this file
    os.chdir(os.path.abspath(os.path.dirname(__file__)))

    # Load sys.path with custom paths
    paths = []
    custom_path = 'thefuck_contrib_0'
    path_to_thefuck = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for i, p in enumerate(sys.path):
        if p.startswith(path_to_thefuck):
            sys.path[i] = os.path.dirname(path_to_thefuck)
            sys.path.insert(i, path_to_thefuck)
            sys.path.insert(i, custom_path)
            break

    # Create directories for rules

# Generated at 2022-06-26 04:40:32.258257
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    var_0 = get_rules_import_paths
    var_0 = get_rules
    var_0 = organize_commands
    var_0 = get_loaded_rules
    var_0 = get_corrected_commands
    var_0 = get_corrected_commands
    # First assert
    assert var_0 == get_corrected_commands
    # Second assert
    assert var_0 == get_corrected_commands
    # Third assert
    assert var_0 == get_corrected_commands
    # Fourth assert
    assert var_0 == get_corrected_commands
    # Fifth assert
    assert var_0 == get_corrected_commands

# Generated at 2022-06-26 04:40:40.828012
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    # Store return values from get_rules_import_paths
    var_0 = list(get_rules_import_paths())

    # Check if the value returned from function is equal to the expected value
    assert var_0 == [Path('/Users/kallenkang/anaconda/lib/python2.7/site-packages/thefuck/rules'),
                     Path('/Users/kallenkang/.config/thefuck/rules')], \
        'Function get_rules_import_paths returned a value that did not match the expected value'



# Generated at 2022-06-26 04:40:45.380645
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    var_0 = Path(__file__).parent.joinpath('rules')
    var_1 = var_0.joinpath('always_correct.py').joinpath('always_correct.py')
    var_2 = get_loaded_rules([var_1])
    var_3 = Rule.from_path(var_1)
    var_4 = list(var_2)
    assert var_3 in var_4
    assert var_3.is_active()


# Generated at 2022-06-26 04:40:48.803576
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    print("Testing function: get_rules_import_paths")
    assert (len(list(get_rules_import_paths())) == 3)
    print("Passed")


# Generated at 2022-06-26 04:40:59.423754
# Unit test for function organize_commands
def test_organize_commands():
    list_0 = ['echo $test_test_test', 'ls']
    list_1 = [u'echo $test_test_test', u'ls']

# Generated at 2022-06-26 04:41:09.109357
# Unit test for function organize_commands
def test_organize_commands():
    # Verify the correctness of the execution results
    var_0 = get_rules_import_paths()

    var_1 = Path(__file__).parent.joinpath('..', '..', 'rules')
    var_2 = settings.user_dir.joinpath('rules')

    var_3 = []
    for path in sys.path:
        for contrib_module in Path(path).glob('thefuck_contrib_*'):
            contrib_rules = contrib_module
            if contrib_rules.is_dir():
                var_3.append(contrib_rules)

    var_4 = []

# Generated at 2022-06-26 04:41:13.406692
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    # command = 'cd /etc/kd/skdskd/skdskd'
    command = 'cd desktop'
    # command = 'cd /home/nitin'
    corrected_commands = get_corrected_commands(command)
    return corrected_commands



# Generated at 2022-06-26 04:41:21.015333
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    var_1 = [Path(__file__).parent.joinpath('rules')]
    var_2 = sorted([Rule.from_path(path) for path in var_1[0].glob('*.py') if path.name != '__init__.py'],key=attrgetter('priority'),key=attrgetter('is_enabled'))
    var_3 = sorted(get_loaded_rules(var_1),key=attrgetter('priority'),key=attrgetter('is_enabled'))
    assert var_2 == var_3


# Generated at 2022-06-26 04:41:31.743963
# Unit test for function organize_commands
def test_organize_commands():
    import types
    import thefuck.rules.correct
    var_0 = getattr
    var_0 = (var_0(thefuck.rules.correct, 'Command'))
    var_0 = var_0
    var_1 = getattr
    var_1 = (var_1(thefuck.rules.correct, 'CorrectedCommand'))
    var_2 = types.BuiltinFunctionType
    var_1 = (var_1)
    var_1 = (isinstance(var_1, var_2))
    var_1 = (var_1)
    var_2 = var_0
    var_3 = Command((u'date'))
    var_3 = var_3
    var_3 = (var_3)
    var_4 = CorrectedCommand(var_3, var_2, 0)
   

# Generated at 2022-06-26 04:41:45.707721
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    var_0 = get_rules_import_paths()
    assert len(var_0) == 5


# Generated at 2022-06-26 04:41:48.651728
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('').joinpath('rules', 'git.py'), Path('').joinpath('rules', 'git_add.py')])



# Generated at 2022-06-26 04:41:57.754675
# Unit test for function organize_commands

# Generated at 2022-06-26 04:42:09.284912
# Unit test for function organize_commands
def test_organize_commands():
    corrected_commands = [CorrectedCommand('ls -al /usr/bin', 1), CorrectedCommand('ls -al /usr/bin', 1), CorrectedCommand('ls -al /usr/bin', 0)]
    expected = [CorrectedCommand('ls -al /usr/bin', 0), CorrectedCommand('ls -al /usr/bin', 1)]
    ret = organize_commands(corrected_commands)

# Generated at 2022-06-26 04:42:20.354775
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Correction

    command_1 = CorrectedCommand('1', '2', Correction(0, [], []), '4')
    command_1.priority = 1
    command_2 = CorrectedCommand('1', '2', Correction(0, [], []), '3')
    command_2.priority = 0
    command_3 = CorrectedCommand('1', '2', Correction(1, [], []), '5')
    command_3.priority = 2
    commands = [command_1, command_2, command_3]

    correct_commands = organize_commands(commands)
    assert correct_commands[0] == command_2
    assert correct_commands[1] == command_1
    assert correct_commands[2] == command_3


# Unit test

# Generated at 2022-06-26 04:42:29.513984
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    # Function testing
    var_1 = get_corrected_commands('/bin/bash')
    try:
        var_0 = type(var_1) == types.GeneratorType
    except Exception as e:
        var_0 = False
    assert var_0
    assert not var_1.gi_running
    var_0 = isinstance(var_1, types.GeneratorType)
    assert var_0
    try:
        var_1.send(None)
    except StopIteration as e:
        var_2 = e.value
    assert var_2.script == '/bin/bash'
    assert var_2.priority == 0.0


# Generated at 2022-06-26 04:42:30.955009
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    class Command():
        stderr = ''
        script = ''
    command = Command()
    assert (len(list(get_corrected_commands(command))) > 0)

# Generated at 2022-06-26 04:42:35.357558
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    var_0 = [rule_path for path in get_rules_import_paths() for rule_path in sorted(path.glob('*.py'))]


# Generated at 2022-06-26 04:42:36.743128
# Unit test for function get_rules
def test_get_rules():
    var_0 = get_rules()

# Generated at 2022-06-26 04:42:42.948757
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    var_0 = get_corrected_commands(Command('echo "ls | grep .py"'))
    var_1 = get_corrected_commands(Command('ls -la'))
    var_2 = get_corrected_commands(Command('cd ..'))
    var_3 = get_corrected_commands(Command('sudo cd ..'))
    var_4 = get_corrected_commands(Command('git push origin master'))
    var_5 = get_corrected_commands(Command('vim /etc/hosts'))
    var_6 = get_corrected_commands(Command('gcc -Wall main.c'))
    var_7 = get_corrected_commands(Command('cd thefuck && thefuck -h'))

# Generated at 2022-06-26 04:43:07.090813
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    var_1 = get_corrected_commands('lsd')


# Generated at 2022-06-26 04:43:14.135121
# Unit test for function organize_commands
def test_organize_commands():
    from . import types
    from . import logging
    logging.init_log(level=logging.DEBUG)
    lst = [types.CorrectedCommand('echo', 'echo', 1), types.CorrectedCommand('echo', 'echo', 1),
           types.CorrectedCommand('command', 'command', 2)]
    assert [c for c in organize_commands(lst)] == [types.CorrectedCommand('echo', 'echo', 1),
                                               types.CorrectedCommand('command', 'command', 2)]

# Generated at 2022-06-26 04:43:23.756385
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert '/home/bill/Documents/thefuck/thefuck/rules' in get_rules_import_paths()
    assert '/home/bill/.config/thefuck/rules' in get_rules_import_paths()
    assert '/usr/local/lib/python3.6/dist-packages/thefuck_contrib_rbenv' in get_rules_import_paths()
    assert '/usr/local/lib/python3.6/dist-packages/thefuck_contrib_pip' in get_rules_import_paths()
    assert '/usr/local/lib/python3.6/dist-packages/thefuck_contrib_virtualenv' in get_rules_import_paths()
    assert '/usr/local/lib/python3.6/dist-packages/thefuck_contrib_docker' in get_rules_

# Generated at 2022-06-26 04:43:32.764257
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    from .types import Rule
    rule1 = Rule("cd", "echo [command]", ["cd"], False, 1, "Rule Name")
    rule2 = Rule("cd", "echo [command]", ["cd"], False, 10, "Rule Name")
    rule3 = Rule("ls", "echo [command]", ["ls"], True, 1, "Rule Name")
    rule4 = Rule("ls", "echo [command]", ["ls"], False, 1, "Rule Name")
    rule5 = Rule("ls", "echo [command]", ["ls"], True, 10, "Rule Name")

    rule_list = [rule1, rule2, rule3, rule4, rule5]
    rule_list_result = [rule3, rule5, rule2]

    rule_test_list = get_loaded_rules(rule_list)

# Generated at 2022-06-26 04:43:40.597908
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .rules.titul import correct
    fake_rule = Rule('fake', correct, 'py')
    fake_corrected_command = CorrectedCommand(fake_rule, '0', 2)

    assert(list(organize_commands([])) == [])

    list_1element = [fake_corrected_command]
    assert(list(organize_commands(list_1element)) == [fake_corrected_command])

    list_duplicate = [fake_corrected_command, fake_corrected_command]
    assert(list(organize_commands(list_duplicate)) == [fake_corrected_command])
    list_sorted = [fake_corrected_command]

# Generated at 2022-06-26 04:43:52.698065
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    import sys
    import inspect
    import os.path
    import unittest
    import thefuck
    from thefuck.rules import *
    from thefuck import rules

    def filtered_rules():
        for name, obj in inspect.getmembers(rules):
            if inspect.isclass(obj) and issubclass(obj, thefuck.rules.Rule) and obj != Rule:
                yield obj

    paths = [Path(os.path.realpath(name.replace(".", "/")) + ".py") for name, obj in inspect.getmembers(sys.modules["thefuck.rules"]) if inspect.ismodule(obj)]
    found_files = []
    for f in paths:
        found_files.append(f.name[:-3])

    modules = []

# Generated at 2022-06-26 04:43:58.106133
# Unit test for function organize_commands
def test_organize_commands():
    command = Command("ls", "ls '-l'")
    rule = Rule("ls", "ls '-l'", "ls -l", None)
    rule2 = Rule("ls", "ls '-l'", "ls -la", None)
    corrected_commands = CorrectedCommand("ls", "ls '-l'", "ls -l", rule)
    corrected_commands2 = CorrectedCommand("ls", "ls '-l'", "ls -la", rule2)
    corrected_commands3 = CorrectedCommand("ls", "ls '-l'", "ls -l", rule)
    cmds = organize_commands([corrected_commands, corrected_commands3, corrected_commands2])
    assert next(cmds) == corrected_commands
    assert next(cmds) == corrected_commands2



# Generated at 2022-06-26 04:44:03.170618
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    # Argument: [Path]
    rules_paths = [Path("/Users/knuthaug/Desktop/test.py"), Path("/Users/knuthaug/Desktop/test2.py")]

    # Return: [Rule]
    Rule.from_path = lambda x: x
    return_value = [Path("/Users/knuthaug/Desktop/test.py"), Path("/Users/knuthaug/Desktop/test2.py")]

    for i, j in zip(get_loaded_rules(rules_paths), return_value):
        i == j


# Generated at 2022-06-26 04:44:13.135972
# Unit test for function organize_commands
def test_organize_commands():
    """Tests for function organize_commands"""

    class TestCase:
        def __init__(self, command, priority, is_corrected, corrected_command, is_forced, is_manual):
            self.command = command
            self.is_corrected = is_corrected
            self.corrected_command = corrected_command
            self.priority = priority
            self.is_forced = is_forced
            self.is_manual = is_manual

    correct_command = CorrectedCommand("", 0, True, False, False)

    # Test case 0
    test_case_0 = []

    # Test case 1
    test_case_1 = [
        TestCase("echo a", 0, True, "echo b", False, False)
    ]

    # Test case 2

# Generated at 2022-06-26 04:44:14.183392
# Unit test for function get_rules
def test_get_rules():
    var_0 = get_rules()


# Generated at 2022-06-26 04:44:45.900911
# Unit test for function get_rules
def test_get_rules():
    import pytest
    test_data0 = [1, 2, 3]
    with pytest.raises(Exception):
        get_rules(3)
    with pytest.raises(Exception):
        get_rules(test_data0)
    with pytest.raises(Exception):
        get_rules(test_data0)
        get_rules(get_rules_import_paths())


# Generated at 2022-06-26 04:44:57.900825
# Unit test for function organize_commands
def test_organize_commands():
    command_1 = Command('ls')
    command_2 = Command('ls')
    command_3 = Command('clear')
    command_4 = Command('clear')
    command_5 = Command('cd')

    corrected_commands = [
        CorrectedCommand(command_1, 'some rule', 'ls -l'),
        CorrectedCommand(command_2, 'some rule', 'ls -a')
    ]

    assert list(organize_commands(corrected_commands)) == [
        corrected_commands[0],
        corrected_commands[1]
    ]

    corrected_commands = [
        CorrectedCommand(command_2, 'some rule', 'ls -l'),
        CorrectedCommand(command_5, 'some rule', 'cd ./src')
    ]


# Generated at 2022-06-26 04:45:01.472504
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    var_0 = get_rules_import_paths()


# Generated at 2022-06-26 04:45:03.237620
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    var_1 = 'echo'
    var_2 = get_corrected_commands(var_1)
    return var_2


# Generated at 2022-06-26 04:45:05.446097
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .main import Command, CorrectedCommand
    assert list(get_corrected_commands(Command('asd'))) == []


# Generated at 2022-06-26 04:45:08.293430
# Unit test for function get_corrected_commands
def test_get_corrected_commands():

    var_0 = get_corrected_commands(types.Command("", ""))


# Generated at 2022-06-26 04:45:17.794433
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    import os
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()

    temp_dir_path = os.path.join(temp_dir.name, 'rules')

    os.makedirs(temp_dir_path)

    temp_dir_path_2 = os.path.join(temp_dir.name, 'thefuck_contrib_test')

    os.makedirs(temp_dir_path_2)

    temp_dir_path_3 = os.path.join(temp_dir_path_2, 'rules')

    os.makedirs(temp_dir_path_3)

    assert temp_dir_path in test_get_rules_import_paths.__wrapped__()
    assert temp_dir_path_3 in test_get_rules_import_paths.__wrapped__

# Generated at 2022-06-26 04:45:19.117391
# Unit test for function get_rules
def test_get_rules():
    var_1 = get_rules()


# Generated at 2022-06-26 04:45:20.135389
# Unit test for function organize_commands
def test_organize_commands():
    var_0 = organize_commands()

# Generated at 2022-06-26 04:45:26.826239
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    print("\n"*10)
    print("Unit test for function get_rules_import_paths")

    var_0 = get_rules_import_paths()
    _test_get_rules_import_paths_0(var_0)

    print("\n")


# Generated at 2022-06-26 04:46:04.057077
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert [Rule.from_path(Path(__file__).parent.joinpath('rules').joinpath('npm.py')),
            Rule.from_path(Path(__file__).parent.joinpath('rules').joinpath('no_command.py'))] == get_loaded_rules(['/home/christine/.local/share/virtualenvs/thefuck-8rHrOGlN/lib/python3.5/site-packages/thefuck/rules/npm.py',
                                                                                                                  '/home/christine/.local/share/virtualenvs/thefuck-8rHrOGlN/lib/python3.5/site-packages/thefuck/rules/no_command.py'])

# Generated at 2022-06-26 04:46:05.463120
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    var_0 = get_corrected_commands()

# Generated at 2022-06-26 04:46:11.835767
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    import imp
    import os
    rules_paths = os.path.join(os.path.dirname(__file__), 'rules')
    rules_paths = os.path.join(os.path.dirname(__file__), 'rules')
    rules_paths = os.path.join(os.path.dirname(__file__), 'rules')
    result = []
    for path in rules_paths:
        if path.name != '__init__.py':
            rule = imp.load_source('rules.{}'.format(path.name), path)
            if rule and rule.is_enabled:
                result.append(rule)
    return result

# Generated at 2022-06-26 04:46:19.995278
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from . import types
    from . import commands
    from . import rules
    from . import correctors

    command = Command(script='cd /usr', stdout='/usr')
    corrected_commands = list(get_corrected_commands(command))
    logs.debug('corrected commands: {}'.format(corrected_commands))

if __name__ == '__main__':
    test_case_0()
    test_get_corrected_commands()

# Generated at 2022-06-26 04:46:25.275256
# Unit test for function get_rules
def test_get_rules():
    # Expected result
    expected_result = []
    # Getting actual result
    actual_result = get_rules()
    # Actual and expected result must be equal
    assert actual_result == expected_result

# Generated at 2022-06-26 04:46:32.644554
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('some command', 'some command')
    corrected_1 = CorrectedCommand(command, 'some command', 5)
    corrected_2 = CorrectedCommand(command, 'some command', 0)
    corrected_3 = CorrectedCommand(command, 'some other command', 0)
    corrected_4 = CorrectedCommand(command, 'some other command', 5)
    corrected_5 = CorrectedCommand(command, 'some command', 0)

    assert list(organize_commands([corrected_1, corrected_2, corrected_3, corrected_4, corrected_5])) == [corrected_2, corrected_3, corrected_4, corrected_1]

# Generated at 2022-06-26 04:46:43.581013
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    var_1 = ['thefuck.rules.apt_get', 'thefuck.rules.git', 'thefuck.rules.npm', 'thefuck.rules.python', 'thefuck.rules.sudo', 'thefuck.rules.vagrant']

# Generated at 2022-06-26 04:46:47.530341
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    var_0 = Path(__file__).parent.joinpath("rules")
    var_1 = Path(__file__).parent.joinpath("rules/__init__.py")
    var_2 = Rule.from_path(var_1)
    var_3 = get_loaded_rules([var_1])


# Generated at 2022-06-26 04:46:50.234654
# Unit test for function get_rules
def test_get_rules():
    var_0 = get_rules()

# Test for function get_corrected_commands

# Generated at 2022-06-26 04:46:52.862709
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    var_0 = Command('vim', 'Vim: Caught deadly signal ABRT', '', '', 4934)
    var_1 = get_corrected_commands(var_0)
    var_1 = list(var_1)
    var_2 = len(var_1)
    assert var_2 == 0


# Generated at 2022-06-26 04:47:13.200458
# Unit test for function get_rules
def test_get_rules():
    # Test1:
    assert 1==1

# Generated at 2022-06-26 04:47:15.191141
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    assert organize_commands('ls -a')


# Generated at 2022-06-26 04:47:18.382329
# Unit test for function organize_commands
def test_organize_commands():
    corrected_commands = ["echo", "hello", "world!"]
    var_2 = organize_commands(corrected_commands)


# Generated at 2022-06-26 04:47:23.922690
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    try:
        correct = Command('git branch', '', '')
        var_0 = get_corrected_commands(correct)
        print(var_0)
        print(type(var_0))
        print(next(var_0))
    except StopIteration:
        print('StopIteration')


# Generated at 2022-06-26 04:47:27.076864
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert len(list(get_rules_import_paths())) == 3


# Generated at 2022-06-26 04:47:31.872614
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    var_0 = Path(__file__).parent.joinpath('rules').joinpath('git.py')
    var_1 = Rule.from_path(var_0)
    assert var_1.is_enabled


# Generated at 2022-06-26 04:47:37.242623
# Unit test for function organize_commands
def test_organize_commands():
    assert ([CorrectedCommand('ls .', 'ls /', 6.8),
     CorrectedCommand('ls .', 'ls /', 6.8),
     CorrectedCommand('ls .', 'ls /', 6.8)] ==
            organize_commands([CorrectedCommand('ls .', 'ls /', 6.8),
     CorrectedCommand('ls .', 'ls /', 6.8),
     CorrectedCommand('ls .', 'ls /', 6.8)]))


# Generated at 2022-06-26 04:47:40.881960
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')] == test_case_0()


# Generated at 2022-06-26 04:47:44.458003
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert next(get_loaded_rules([Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]))


# Generated at 2022-06-26 04:47:55.132451
# Unit test for function organize_commands
def test_organize_commands():
    logs.debug( "unit test for function organize_commands - start")

    var_0 = organize_commands([CorrectedCommand(
        command='', side_effect=None, priority=0), CorrectedCommand(
        command='', side_effect=None, priority=0)])

    logs.debug( "unit test for function organize_commands - end")


if __name__ == "__main__":
    test_case_0()
    test_organize_commands()

# Generated at 2022-06-26 04:48:08.687098
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    var_0 = get_rules_import_paths()

# Generated at 2022-06-26 04:48:17.283317
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    if not hasattr(sys.stdout, "getvalue"):
        unittest.TestCase.skipTest(
            "you should run this test in buffered mode")
    sys.stdout = io.StringIO()
    var_0 = get_corrected_commands('ls')
    assert str(
        var_0) == '<generator object organize_commands at 0x10f873c50>', 'Incorrect return value found'
    sys.stdout = sys.__stdout__

# Generated at 2022-06-26 04:48:20.559264
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    # Ensure that this directory is in sys.path
    assert os.path.exists(get_rules_import_paths()[0].path)

# Generated at 2022-06-26 04:48:21.623274
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    get_rules_import_paths();


# Generated at 2022-06-26 04:48:30.637620
# Unit test for function organize_commands
def test_organize_commands():
    str_0 = '[CorrectedCommand(command=\'sudo {}\', priority=10000, is_corrected=False)]'
    str_1 = "[CorrectedCommand(command='sudo {} --help', priority=0, is_corrected=False)]"
    str_2 = "[CorrectedCommand(command='sudo {} --help', priority=0, is_corrected=False), CorrectedCommand(command='sudo --help', priority=0, is_corrected=False)]"
    str_3 = "[CorrectedCommand(command='sudo {} -h', priority=0, is_corrected=False)]"
    str_4 = "[CorrectedCommand(command='sudo {} -h', priority=0, is_corrected=False), CorrectedCommand(command='sudo -h', priority=0, is_corrected=False)]"


# Generated at 2022-06-26 04:48:38.378146
# Unit test for function get_rules
def test_get_rules():
    var_0 = get_rules()
    expected = [(lambda x: (print('AssertionError: %s' % x), all(x))[1], "type(get_rules()) == list")]
    expected.append((lambda x: (print('AssertionError: %s' % x), all(x))[1], "len(get_rules()) >= 4"))
    expected.append((lambda x: (print('AssertionError: %s' % x), all(x))[1], "all(rule.is_enabled for rule in get_rules()) == True"))
    expected.append((lambda x: (print('AssertionError: %s' % x), all(x))[1], "all(type(rule) == <class 'thefuck.rules.base.Rule'>"))

# Generated at 2022-06-26 04:48:43.801075
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    var_0 = get_corrected_commands(
        thefuck.types.Command('mkdir -l', 'bash: mkdir: -l: invalid option\nusage: mkdir [-vp] [-m mode] directory ...')
    )

# Generated at 2022-06-26 04:48:49.171465
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from . import run

    x = CorrectedCommand('ls', 'ls /', run.FunctionRunner())
    y = CorrectedCommand('ls', 'ls -al', run.FunctionRunner())
    z = CorrectedCommand('ls', 'ls -l', run.FunctionRunner())

    assert list(organize_commands([x, x, y, z])) == [x, z, y]

# Generated at 2022-06-26 04:48:51.423014
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    var_0 = sys.modules['__main__'].get_rules_import_paths()


# Generated at 2022-06-26 04:48:52.723291
# Unit test for function get_rules
def test_get_rules():
    assert pi_type(get_rules()) == "generator"



# Generated at 2022-06-26 04:49:21.320166
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    try:
        var_1 = get_corrected_commands((Command('ls /usr/', '', '')))
        var_2 = get_corrected_commands((Command('fs .', '', '')))
        var_3 = get_corrected_commands((Command('git ls-stash', '', '')))
    except:
        raise

# Generated at 2022-06-26 04:49:23.108893
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) == 27

# Generated at 2022-06-26 04:49:28.954939
# Unit test for function organize_commands
def test_organize_commands():
    assert organize_commands([CorrectedCommand('fuck', '', 3), CorrectedCommand('fuck', '', 1)]) == [CorrectedCommand('fuck', '', 3), CorrectedCommand('fuck', '', 1)]


# Generated at 2022-06-26 04:49:33.144699
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    command = Command(' '.join(sys.argv[1:]))
    # test_get_corrected_commands should always return a list
    var_1 = []
    for corrected_command in get_corrected_commands(command):
        var_1.append(corrected_command.script)
    return var_1


__test__ = {
    'test_case_0': test_case_0,
    'test_get_corrected_commands': test_get_corrected_commands
}

# Generated at 2022-06-26 04:49:37.846661
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    import os
    import sys
    sys.path.append(os.getcwd())

    # Test case 0
    assert len(list(get_rules_import_paths())) == 3


# Generated at 2022-06-26 04:49:39.307154
# Unit test for function get_rules
def test_get_rules():
    assert get_rules() is not None



# Generated at 2022-06-26 04:49:48.518075
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rule1 = get_rules_import_paths()
    rule2 = sorted(get_loaded_rules(rule1), key=lambda rule: rule.priority)
    for rule in rule2:
        if rule.name == 'NoSuchCommand.py':
            assert rule.priority == 100
        elif rule.name == 'HistoryCorrection.py':
            assert rule.priority == 200
        elif rule.name == 'AppendCommand.py':
            assert rule.priority == 1
        elif rule.name == 'SpellCorrection.py':
            assert rule.priority == 300
        elif rule.name == 'ChangeDirectory.py':
            assert rule.priority == 400
        elif rule.name == 'EchoCommand.py':
            assert rule.priority == 500

# Generated at 2022-06-26 04:49:56.270197
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    # Tests for correct executable name
    assert next(get_corrected_commands(Command('ls a b c', '', ''))).script == 'ls a b c'
    assert next(get_corrected_commands(Command('echo test ', '', ''))).script == 'echo test'
    assert next(get_corrected_commands(Command('pwd ', '', ''))).script == 'pwd'
    assert next(get_corrected_commands(Command('ls -l', '', ''))).script == 'ls -l'
    assert next(get_corrected_commands(Command('cat test.txt', '', ''))).script == 'cat test.txt'
    assert next(get_corrected_commands(Command('env', '', ''))).script == 'env'

# Generated at 2022-06-26 04:50:05.957495
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    # Test parameters
    test_var_0 = ''
    test_var_1 = mock.Mock()
    test_var_1.script = test_var_0

    # Test expected values
    test_expected_0 = False
    test_expected_1 = None

    # Test actual values
    test_actual_0 = get_corrected_commands(test_var_1)
    test_actual_1 = next(test_actual_0, test_expected_1)

    # Assert function results
    assert test_expected_0 == test_actual_0
    assert test_expected_1 == test_actual_1

# Generated at 2022-06-26 04:50:16.567261
# Unit test for function get_loaded_rules