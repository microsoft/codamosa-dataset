

# Generated at 2022-06-18 06:35:40.561968
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:35:50.948171
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:36:00.386830
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .conf import load_settings
    from .conf import reload_settings
    from .conf import clear_settings
    from .conf import get_all_settings
    from .conf import get_all_settings_names
    from .conf import get_all_settings_values
    from .conf import get_all_settings_types
    from .conf import get_all_settings_descriptions
    from .conf import get_all_settings_defaults
    from .conf import get_all_settings_choices
    from .conf import get_all_settings_env_names
    from .conf import get_all_settings_env_defaults
    from .conf import get_all_settings_

# Generated at 2022-06-18 06:36:09.001969
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    path = Path(__file__).parent.joinpath('rules')
    assert list(get_loaded_rules([path.joinpath('bash.py')])) == [Rule.from_path(path.joinpath('bash.py'))]
    assert list(get_loaded_rules([path.joinpath('bash.py'), path.joinpath('__init__.py')])) == [Rule.from_path(path.joinpath('bash.py'))]
    assert list(get_loaded_rules([path.joinpath('bash.py'), path.joinpath('__init__.py'), path.joinpath('git.py')])) == [Rule.from_path(path.joinpath('bash.py')), Rule.from_path(path.joinpath('git.py'))]

# Generated at 2022-06-18 06:36:20.371534
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')),
                                                               Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:36:28.785164
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')),
                                                              Rule.from_path(Path('/tmp/rule2.py'))]



# Generated at 2022-06-18 06:36:40.076590
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:36:49.017611
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyo')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py~')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swo')])) == []

# Generated at 2022-06-18 06:36:49.867476
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()

# Generated at 2022-06-18 06:37:00.639358
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.default import match, get_new_command

# Generated at 2022-06-18 06:37:08.131750
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:18.288949
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')), Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:37:28.075690
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd_parent
    from .rules import git_push
    from .rules import python_command
    from .rules import apt_get
    from .rules import pip_install
    from .rules import npm_install
    from .rules import gem_install
    from .rules import java_command
    from .rules import cabal_install
    from .rules import stack_install
    from .rules import rust_cargo
    from .rules import rust_rustup
    from .rules import perl_command
    from .rules import php_command
    from .rules import lua_luarocks
    from .rules import lua_luarocks_2
    from .rules import lua_luarocks_3
    from .rules import lua_luarocks_5
    from .rules import lua_luar

# Generated at 2022-06-18 06:37:35.613339
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py'), Path(__file__).parent.joinpath('rules/git.py')]))) == 1


# Generated at 2022-06-18 06:37:37.491864
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:39.391044
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:45.452569
# Unit test for function organize_commands
def test_organize_commands():
    from thefuck.types import CorrectedCommand
    from thefuck.rules.git import match, get_new_command
    from thefuck.types import Command

    command = Command('git', '', '')
    corrected_commands = [CorrectedCommand(get_new_command(command),
                                           priority=match(command))]
    assert list(organize_commands(corrected_commands)) == corrected_commands

# Generated at 2022-06-18 06:37:53.560351
# Unit test for function get_rules

# Generated at 2022-06-18 06:38:01.934472
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
   

# Generated at 2022-06-18 06:38:12.577982
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    from .rules import bash
    from .rules import brew
    from .rules import cp
    from .rules import git
    from .rules import ls
    from .rules import man
    from .rules import npm
    from .rules import pip
    from .rules import python
    from .rules import sudo
    from .rules import svn
    from .rules import vagrant
    from .rules import virtualenv
    from .rules import yum
    from .rules import zsh
    from .rules import docker
    from .rules import apt
    from .rules import apt_get
    from .rules import apt_cache
    from .rules import aptitude
    from .rules import gem
    from .rules import gem_install
    from .rules import gem_update
    from .rules import gem_uninstall
    from .rules import gem_cleanup

# Generated at 2022-06-18 06:38:35.035357
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.pyo')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py.swo')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py~')])) == []

# Generated at 2022-06-18 06:38:46.595945
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.no import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.npm import match, get_new_command

# Generated at 2022-06-18 06:38:55.515696
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.man import man_rule
    from .rules.misc import misc_rule
    from .rules.pip import pip_rule
    from .rules.npm import npm_rule
    from .rules.gem import gem_rule
    from .rules.brew import brew_rule
    from .rules.apt import apt_rule
    from .rules.yum import yum_rule
    from .rules.docker import docker_rule
    from .rules.systemd import systemd_rule
    from .rules.systemctl import systemctl_rule
    from .rules.service import service_rule
    from .rules.alias import alias_rule
    from .rules.cd import cd_

# Generated at 2022-06-18 06:39:05.598206
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .conf import load_settings
    from .conf import get_all_settings
    from .conf import get_all_executables
    from .conf import get_all_rules
    from .conf import get_all_aliases
    from .conf import get_all_wait_rules
    from .conf import get_all_no_colors
    from .conf import get_all_require_confirmation
    from .conf import get_all_wait_slow_commands
    from .conf import get_all_slow_commands
    from .conf import get_all_exclude_rules
    from .conf import get_all_env
    from .conf import get_all_history

# Generated at 2022-06-18 06:39:10.724301
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:39:24.035918
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.brew import match as match_brew, get_new_command as get_new_command_brew
    from .rules.gem import match as match_gem

# Generated at 2022-06-18 06:39:35.738933
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .conf import settings
    settings.priority = lambda x: x.priority


# Generated at 2022-06-18 06:39:36.567423
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:39:44.709225
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')), Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:39:48.181525
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules'),
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:16.219143
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:40:20.761535
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:40:23.296390
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:40:33.749474
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    def get_corrected_commands(command):
        return [CorrectedCommand(command, '', '', 0),
                CorrectedCommand(command, '', '', 0),
                CorrectedCommand(command, '', '', 1),
                CorrectedCommand(command, '', '', 1),
                CorrectedCommand(command, '', '', 2),
                CorrectedCommand(command, '', '', 2),
                CorrectedCommand(command, '', '', 3),
                CorrectedCommand(command, '', '', 3),
                CorrectedCommand(command, '', '', 4),
                CorrectedCommand(command, '', '', 4)]

    command = Command('ls')
    assert list(organize_commands(get_corrected_commands(command)))

# Generated at 2022-06-18 06:40:43.093376
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.python import match, get_new_command
    from .rules.git import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.vagrant import match, get_new_command
    from .rules.docker import match, get_new_command
    from .rules.systemctl import match

# Generated at 2022-06-18 06:40:44.960829
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:45.829130
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:40:55.155126
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command

# Generated at 2022-06-18 06:41:05.065567
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd_parent
    from .rules import git_push
    from .rules import python_pip
    from .rules import python_pip_m
    from .rules import python_pip_m_editable
    from .rules import python_pip_editable
    from .rules import python_pip_requirements
    from .rules import python_pip_uninstall
    from .rules import python_pip_uninstall_editable
    from .rules import python_pip_uninstall_requirements
    from .rules import python_pip_uninstall_user
    from .rules import python_pip_user
    from .rules import python_pip_user_editable
    from .rules import python_pip_user_requirements
    from .rules import python_pip

# Generated at 2022-06-18 06:41:13.050783
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    # Test for empty rules
    assert list(get_loaded_rules([])) == []
    # Test for rules with __init__.py
    assert list(get_loaded_rules([Path('__init__.py')])) == []
    # Test for rules without __init__.py
    assert list(get_loaded_rules([Path('test.py')])) == []
    # Test for rules with __init__.py and without __init__.py
    assert list(get_loaded_rules([Path('__init__.py'), Path('test.py')])) == []
    # Test for rules with __init__.py and without __init__.py and with enabled rule

# Generated at 2022-06-18 06:41:42.670952
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:54.241284
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:42:03.674097
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .conf import load_settings
    from .conf import load_settings_from_pyfile
    from .conf import load_settings_from_module
    from .conf import load_settings_from_env
    from .conf import load_settings_from_json
    from .conf import load_settings_from_yaml
    from .conf import load_settings_from_ini
    from .conf import load_settings_from_toml
    from .conf import load_settings_from_dict
    from .conf import load_settings_from_path
    from .conf import load_settings_from_file
    from .conf import load_settings_from_module_path

# Generated at 2022-06-18 06:42:13.114913
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd_parent
    from .rules import python_command
    from .rules import apt_get
    from .rules import brew_install
    from .rules import brew_uninstall
    from .rules import brew_upgrade
    from .rules import brew_update
    from .rules import brew_cleanup
    from .rules import brew_cask_install
    from .rules import brew_cask_uninstall
    from .rules import brew_cask_upgrade
    from .rules import brew_cask_cleanup
    from .rules import brew_cask_update
    from .rules import brew_cask_reinstall
    from .rules import brew_cask_home
    from .rules import brew_cask_info
    from .rules import brew_cask_search

# Generated at 2022-06-18 06:42:14.126540
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:42:15.512007
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0


# Generated at 2022-06-18 06:42:24.180120
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .conf import settings
    from .system import Path
    from . import logs
    from . import rules
    from . import utils
    import sys
    import os
    import shutil
    import tempfile
    import unittest

    class TestRule(Rule):
        def __init__(self, name, match, get_new_command):
            self.name = name
            self.match = match
            self.get_new_command = get_new_command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.get_new_command(command),
                                     self.priority)]

    class TestCase(unittest.TestCase):
        def setUp(self):
            self

# Generated at 2022-06-18 06:42:25.394836
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert len(list(get_rules_import_paths())) == 3

# Generated at 2022-06-18 06:42:34.452177
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.composer import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command

# Generated at 2022-06-18 06:42:39.441889
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')),
                                                               Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:43:20.000997
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')])) == [Rule.from_path(Path(__file__).parent.joinpath('rules/git.py'))]


# Generated at 2022-06-18 06:43:21.744745
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:43:27.670184
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .shells import Shell
    from .utils import memoize
    from . import types
    import pytest
    import mock

    @memoize
    def get_shell():
        return Shell()


# Generated at 2022-06-18 06:43:28.862150
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths()

# Generated at 2022-06-18 06:43:31.114425
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:43:39.974869
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import MatchedRule
    from .types import RuleExecutor
    from .types import RuleExecutorResult
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResultType
    from .types import RuleExecutorResult

# Generated at 2022-06-18 06:43:41.609923
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    assert get_corrected_commands(Command('ls', '', '')) == [CorrectedCommand('ls', '', '')]

# Generated at 2022-06-18 06:43:42.383960
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:43:50.379771
# Unit test for function organize_commands

# Generated at 2022-06-18 06:43:50.891240
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()

# Generated at 2022-06-18 06:45:10.584291
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '', '', '', '', '')
    corrected_commands = [CorrectedCommand(command, 'ls -l', '', '', '', '', '', ''),
                          CorrectedCommand(command, 'ls -a', '', '', '', '', '', ''),
                          CorrectedCommand(command, 'ls -l', '', '', '', '', '', '')]

    assert list(organize_commands(corrected_commands)) == [CorrectedCommand(command, 'ls -l', '', '', '', '', '', ''),
                                                           CorrectedCommand(command, 'ls -a', '', '', '', '', '', '')]

# Generated at 2022-06-18 06:45:21.362906
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule('rule', '/tmp/rule.py')]
    assert list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/__init__.py')])) == [Rule('rule', '/tmp/rule.py')]
    assert list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule_disabled.py')])) == [Rule('rule', '/tmp/rule.py')]
    assert list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule_disabled.py'), Path('/tmp/rule_disabled.py')]))

# Generated at 2022-06-18 06:45:30.354685
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.git_branch import match, get_new_command
    from .rules.git_checkout import match, get_new_command
    from .rules.git_commit import match, get_new_command
    from .rules.git_push import match, get_new_command
