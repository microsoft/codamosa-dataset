

# Generated at 2022-06-18 06:35:46.745182
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import RegexRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule


# Generated at 2022-06-18 06:35:49.140013
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:35:53.114857
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1


# Generated at 2022-06-18 06:36:02.980204
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd_parent
    from .rules import python_command
    from .rules import git_push_command
    from .rules import apt_get_install
    from .rules import apt_get_update
    from .rules import apt_get_upgrade
    from .rules import apt_get_dist_upgrade
    from .rules import apt_get_remove
    from .rules import apt_get_purge
    from .rules import apt_get_autoremove
    from .rules import apt_get_autoclean
    from .rules import apt_get_clean
    from .rules import apt_get_update_upgrade_dist_upgrade
    from .rules import apt_get_update_upgrade
    from .rules import apt_get_update_dist_upgrade
    from .rules import apt

# Generated at 2022-06-18 06:36:05.296828
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:09.789956
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/rules/__init__.py'),
                                  Path('/rules/rule.py')])) == [Rule(name='rule',
                                                                     priority=500,
                                                                     is_enabled=True,
                                                                     match=None,
                                                                     get_new_command=None)]


# Generated at 2022-06-18 06:36:12.405778
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:23.956239
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.docker import match, get_new_command
    from .rules.nvm import match

# Generated at 2022-06-18 06:36:30.920058
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptSuffix
    from .types import ScriptPrefix
    from .types import ScriptSuffixAndPrefix
    from .types import ScriptSuffixOrPrefix
    from .types import ScriptSuffixAndPrefixOrSuffix
    from .types import ScriptPrefixAndSuffix
    from .types import ScriptPrefixAndSuffixOrPrefix
    from .types import ScriptPrefixOrSuffix
    from .types import ScriptPrefixOrSuffixAndPrefix
    from .types import ScriptPrefixOrSuffixAndSuffix
    from .types import ScriptPrefixAndSuffixOrSuffix
    from .types import ScriptPrefixOrSuffixAndSuff

# Generated at 2022-06-18 06:36:38.708221
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:36:55.325864
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule.py')])) == [Rule(
        'rule', 'echo "fuck"', '', '', '', '', '', '', '', '', '', '')]
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule.py'),
                                  Path('/tmp/rules/rule_disabled.py')])) == [Rule(
        'rule', 'echo "fuck"', '', '', '', '', '', '', '', '', '', '')]

# Generated at 2022-06-18 06:36:58.377556
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2


# Generated at 2022-06-18 06:37:03.438045
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = [Path(__file__).parent.joinpath('rules/__init__.py'),
                   Path(__file__).parent.joinpath('rules/git.py')]
    assert len(list(get_loaded_rules(rules_paths))) == 1


# Generated at 2022-06-18 06:37:13.863048
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import CommandOutput
    from .types import Output

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

        def match(self, command):
            return True

        def get_priority(self, command):
            return self.priority

    class TestCommand(Command):
        def __init__(self, script):
            self.script = script

        def script(self):
            return self.script

    class TestCorrectedCommand(CorrectedCommand):
        def __init__(self, priority, command):
            self.priority = priority

# Generated at 2022-06-18 06:37:17.825945
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:37:20.787008
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/foo.py')]))) == 1

# Generated at 2022-06-18 06:37:30.295535
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLineInput
    from .types import CommandLineOutput
    from .types import CommandLineError
    from .types import CommandLineHistory
    from .types import CommandLineHistoryItem
    from .types import CommandLineHistoryItemInput
    from .types import CommandLineHistoryItemOutput
    from .types import CommandLineHistoryItemError
    from .types import CommandLineHistoryItemTime
    from .types import CommandLineHistoryItemTimeStart
    from .types import CommandLineHistoryItemTimeStop
    from .types import CommandLineHistoryItemTimeElapsed
    from .types import CommandLineHistoryItemTimeElapsedSeconds
    from .types import CommandLineHistoryItemTimeEl

# Generated at 2022-06-18 06:37:32.353875
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:34.278335
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:38.551955
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')])) == [Rule.from_path(Path(__file__).parent.joinpath('rules/git.py'))]


# Generated at 2022-06-18 06:37:58.948541
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule('rule', '/tmp/rule.py')]
    assert list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/__init__.py')])) == [Rule('rule', '/tmp/rule.py')]
    assert list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/__init__.py'), Path('/tmp/rule2.py')])) == [Rule('rule', '/tmp/rule.py'), Rule('rule2', '/tmp/rule2.py')]

# Generated at 2022-06-18 06:38:02.448401
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptTemplate
    from .types import Regex
    from .types import CommandOutput
    from .types import CommandOutputTemplate
    from .types import CommandTemplate
    from .types import CommandScript
    from .types import CommandScriptTemplate
    from .types import CommandRegex
    from .types import CommandRegexTemplate
    from .types import CommandOutputRegex
    from .types import CommandOutputRegexTemplate
    from .types import CommandOutputScript
    from .types import CommandOutputScriptTemplate
    from .types import CommandRegexScript
    from .types import CommandRegexScriptTemplate
    from .types import CommandOutputRegexScript
    from .types import CommandOutputRegexScriptTemplate


# Generated at 2022-06-18 06:38:07.029489
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:38:17.551466
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .system import Path
    from . import logs
    from . import rules
    from . import utils
    from . import __version__
    from . import __main__
    from . import __init__
    from . import __about__
    from . import __pkginfo__
    from . import __copyright__
    from . import __license__
    from . import __docformat__
    from . import __author__
    from . import __author_email__
    from . import __url__
    from . import __download_url__
    from . import __description__
    from . import __long_description__
    from . import __keywords__

# Generated at 2022-06-18 06:38:20.688790
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    assert get_corrected_commands('ls') == ['ls']

# Generated at 2022-06-18 06:38:31.468905
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Command
    from .types import Script
    from .types import CommandOutput

    class TestRule(Rule):
        def __init__(self, priority):
            super(TestRule, self).__init__(priority)

        def match(self, command):
            return True

        def get_new_command(self, command):
            return 'echo {}'.format(self.priority)


# Generated at 2022-06-18 06:38:33.260675
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:43.941287
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.man import man_rule
    from .rules.cd import cd_rule
    from .rules.pip import pip_rule
    from .rules.ls import ls_rule
    from .rules.no import no_rule
    from .rules.misc import misc_rule
    from .rules.any_command import any_command_rule
    from .rules.bash import bash_rule
    from .rules.brew import brew_rule
    from .rules.cargo import cargo_rule
    from .rules.composer import composer_rule
    from .rules.docker import docker_rule
    from .rules.gem import gem_rule

# Generated at 2022-06-18 06:38:53.575024
# Unit test for function get_rules
def test_get_rules():
    from .types import Rule
    from .system import Path
    from .conf import settings
    from . import logs
    from . import rules
    from . import rules_test
    from . import rules_test_test
    from . import rules_test_test_test
    from . import rules_test_test_test_test
    from . import rules_test_test_test_test_test
    from . import rules_test_test_test_test_test_test
    from . import rules_test_test_test_test_test_test_test
    from . import rules_test_test_test_test_test_test_test_test
    from . import rules_test_test_test_test_test_test_test_test_test
    from . import rules_test_test_test_test_test_test_test_test_

# Generated at 2022-06-18 06:39:00.184001
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:39:25.270871
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]


# Generated at 2022-06-18 06:39:28.753160
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:31.021411
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:33.242989
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:34.361419
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:39:36.760305
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:38.596846
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:40.970110
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:50.340825
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py~')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swo')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swpx')])) == []

# Generated at 2022-06-18 06:39:54.831916
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:40:41.846954
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:50.727456
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.npm import match as match_npm, get_new_command as get_new_command_npm
    from .rules.man import match as match_man, get_new_command as get_new_command_man

# Generated at 2022-06-18 06:40:59.773312
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Command

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

    class TestCommand(Command):
        def __init__(self, script):
            self.script = script

        @property
        def script(self):
            return self._script

        @script.setter
        def script(self, value):
            self._script = value

        def __eq__(self, other):
            return self.script == other.script

        def __ne__(self, other):
            return not self.__eq__(other)


# Generated at 2022-06-18 06:41:00.476679
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()

# Generated at 2022-06-18 06:41:03.169057
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:12.074881
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.composer import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.brew import match, get_new_command

# Generated at 2022-06-18 06:41:16.297543
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:41:27.976203
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_force
    from .rules import git_push_set_upstream
    from .rules import git_push_set_upstream_force
    from .rules import git_push_set_upstream_force_with_lease
    from .rules import git_push_set_upstream_with_lease
    from .rules import git_push_set_upstream_with_lease_force
    from .rules import git_push_with_lease
    from .rules import git_push_with_lease_force
    from .rules import git_push_with_lease_force_with_lease
    from .rules import git_push_with_lease_set_upstream
    from .rules import git_push_with_lease_set_upstream_force
    from .rules import git_push

# Generated at 2022-06-18 06:41:30.557738
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:32.622744
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:43:19.295381
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.pyo')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py.swo')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py.swpx')])) == []

# Generated at 2022-06-18 06:43:25.696891
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')),
                                                               Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:43:29.151502
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'),
                                        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:43:29.972834
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:43:37.269450
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    assert list(organize_commands([
        CorrectedCommand('ls', 'ls', 1),
        CorrectedCommand('ls', 'ls', 2),
        CorrectedCommand('ls', 'ls', 3),
        CorrectedCommand('ls', 'ls', 4),
        CorrectedCommand('ls', 'ls', 5)])) == [
        CorrectedCommand('ls', 'ls', 1),
        CorrectedCommand('ls', 'ls', 5),
        CorrectedCommand('ls', 'ls', 4),
        CorrectedCommand('ls', 'ls', 3),
        CorrectedCommand('ls', 'ls', 2)]

# Generated at 2022-06-18 06:43:38.998647
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:43:47.217344
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.general import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.systemctl import match, get_new_command
    from .rules.docker import match, get_new_command

# Generated at 2022-06-18 06:43:50.287449
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '')
    corrected_commands = [CorrectedCommand(command, 'ls', 'ls', 'ls', 1),
                          CorrectedCommand(command, 'ls', 'ls', 'ls', 1),
                          CorrectedCommand(command, 'ls', 'ls', 'ls', 2)]
    assert list(organize_commands(corrected_commands)) == [corrected_commands[2]]

# Generated at 2022-06-18 06:43:52.417227
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:43:53.223527
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths()