

# Generated at 2022-06-18 06:35:41.333187
# Unit test for function get_loaded_rules

# Generated at 2022-06-18 06:35:51.661087
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    import os
    import sys
    import tempfile
    import shutil
    import unittest

    class TestRule(Rule):
        def __init__(self, priority, command, corrected_command):
            self.priority = priority
            self.command = command
            self.corrected_command = corrected_command

        def is_match(self, command):
            return self.command == command.script

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.corrected_command, self.priority)]

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_rules_dir = os

# Generated at 2022-06-18 06:35:52.156743
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:36:01.671187
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_push
    from .rules.pip import pip_install
    from .rules.python import python
    from .rules.sudo import sudo
    from .rules.system import cd
    from .rules.system import ls
    from .rules.system import man
    from .rules.system import mkdir
    from .rules.system import rm
    from .rules.system import touch
    from .rules.system import vim
    from .rules.system import which
    from .rules.system import yum
    from .rules.system import apt_get
    from .rules.system import aptitude
    from .rules.system import emerge
    from .rules.system import pacman
    from .rules.system import zypper
    from .rules.system import pip
    from .rules.system import pip

# Generated at 2022-06-18 06:36:06.580936
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('__init__.py'), Path('test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('__init__.py'), Path('test.py'), Path('test2.py')]))) == 2


# Generated at 2022-06-18 06:36:11.942118
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.git_branch import match, get_new_command

# Generated at 2022-06-18 06:36:23.483193
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .system import Path

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.command, self.priority)]

    class TestCommand(Command):
        def __init__(self, script):
            self.script = script

        def __eq__(self, other):
            return self.script == other.script

    def test_organize_commands(corrected_commands, expected_commands):
        assert list(organize_commands(corrected_commands)) == expected_commands


# Generated at 2022-06-18 06:36:26.476970
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules'),
        Path(__file__).parent.parent.joinpath('contrib', 'rules')]

# Generated at 2022-06-18 06:36:27.344667
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:36:33.227329
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py'), Path('/tmp/thefuck/rules/git.py')]))) == 2


# Generated at 2022-06-18 06:36:46.708891
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    from .rules import bash, brew, cd, cp, docker, git, ls, npm, python, sudo, svn, system
    assert set(get_loaded_rules([Path(__file__).parent.joinpath('rules')])) == {
        bash.Match,
        brew.Match,
        cd.Match,
        cp.Match,
        docker.Match,
        git.Match,
        ls.Match,
        npm.Match,
        python.Match,
        sudo.Match,
        svn.Match,
        system.Match
    }

# Generated at 2022-06-18 06:36:54.384148
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:37:03.356721
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .main import organize_commands
    from .main import get_rules
    from .main import get_corrected_commands
    from .main import get_rules_import_paths
    from .main import get_loaded_rules
    from .main import get_rules
    from .main import organize_commands
    from .main import get_corrected_commands
    from .main import get_rules_import_paths
    from .main import get_loaded_rules
    from .main import get_rules
    from .main import organize_commands
    from .main import get_corrected_commands
    from .main import get_rules_import_paths

# Generated at 2022-06-18 06:37:03.952812
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()

# Generated at 2022-06-18 06:37:14.519536
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py~')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swo')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swpx')])) == []

# Generated at 2022-06-18 06:37:21.909768
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/test.py')]) == []
    assert get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]) == []
    assert get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py'), Path('/tmp/test3.py')]) == []


# Generated at 2022-06-18 06:37:31.294095
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .conf import load_settings
    from .conf import reload_settings
    from .conf import clear_settings
    from .conf import DEFAULT_SETTINGS
    from .conf import DEFAULT_SETTINGS_PATH
    from .conf import USER_SETTINGS_PATH
    from .conf import load_default_settings
    from .conf import load_user_settings
    from .conf import merge_settings
    from .conf import save_user_settings
    from .conf import get_all_settings
    from .conf import get_all_settings_names
    from .conf import get_all_settings_values
    from .conf import get_all_settings_docs

# Generated at 2022-06-18 06:37:33.377251
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:39.594239
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([])) == []
    assert list(get_loaded_rules([Path('__init__.py')])) == []
    assert list(get_loaded_rules([Path('__init__.py'), Path('test.py')])) == [Rule.from_path(Path('test.py'))]
    assert list(get_loaded_rules([Path('__init__.py'), Path('test.py'), Path('test2.py')])) == [Rule.from_path(Path('test.py')), Rule.from_path(Path('test2.py'))]


# Generated at 2022-06-18 06:37:44.040128
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:37:59.400308
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.nvm import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.mkdir import match, get_new_command
    from .rules.mv import match, get_new_command

# Generated at 2022-06-18 06:38:08.910240
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output

    class Rule1(Rule):
        def match(self, command):
            return True

        def get_new_command(self, command):
            return 'echo 1'

    class Rule2(Rule):
        def match(self, command):
            return True

        def get_new_command(self, command):
            return 'echo 2'

    class Rule3(Rule):
        def match(self, command):
            return True

        def get_new_command(self, command):
            return 'echo 3'

    class Rule4(Rule):
        def match(self, command):
            return True


# Generated at 2022-06-18 06:38:19.114691
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.mkdir import match, get_new_command
    from .rules.cp import match, get_new_command
    from .rules.mv import match, get_new_command
    from .rules.rm import match, get_new_command
    from .rules.ssh import match, get_new_command

# Generated at 2022-06-18 06:38:22.549542
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:32.729436
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedCommand
    from .types import CorrectedOutput
    from .types import CorrectedResponse
    from .types import CorrectedScript
    from .types import CorrectedRule
    from .types import CorrectedCommandOutput
    from .types import CorrectedOutput
    from .types import CorrectedResponse
    from .types import CorrectedScript
    from .types import CorrectedRule
    from .types import CorrectedCommandOutput
    from .types import CorrectedOutput
    from .types import CorrectedResponse
    from .types import CorrectedScript
    from .types import CorrectedRule
    from .types import CorrectedCommandOutput


# Generated at 2022-06-18 06:38:33.744299
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:38:41.398554
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:38:51.567785
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.docker import match, get_new_command
    from .rules.systemctl import match, get_new_command
    from .rules.systemd import match

# Generated at 2022-06-18 06:38:58.944192
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.composer import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.svn import match, get_new_command
    from .rules.apt import match, get_new_command

# Generated at 2022-06-18 06:39:09.657430
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script

    class TestRule(Rule):
        def __init__(self, priority, command, corrected_command):
            self.priority = priority
            self.command = command
            self.corrected_command = corrected_command

        def is_match(self, command):
            return command == self.command

        def get_corrected_commands(self, command):
            return [self.corrected_command]

    class TestScript(Script):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def __eq__(self, other):
            return self.command == other.command

        def __repr__(self):
            return self.command

   

# Generated at 2022-06-18 06:39:28.258304
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.brew import match as match_brew

# Generated at 2022-06-18 06:39:38.396750
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.system import system_rule
    from .rules.man import man_rule
    from .rules.pip import pip_rule
    from .rules.npm import npm_rule
    from .rules.gem import gem_rule
    from .rules.composer import composer_rule
    from .rules.brew import brew_rule
    from .rules.apt import apt_rule
    from .rules.yarn import yarn_rule
    from .rules.docker import docker_rule
    from .rules.vagrant import vagrant_rule
    from .rules.gcloud import gcloud_rule
    from .rules.kubectl import kubectl_rule
   

# Generated at 2022-06-18 06:39:47.729160
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd
    from .rules import python
    from .rules import git
    from .rules import apt_get
    from .rules import sudo
    from .rules import npm
    from .rules import pip
    from .rules import gem
    from .rules import java
    from .rules import javac
    from .rules import mvn
    from .rules import docker
    from .rules import docker_compose
    from .rules import docker_machine
    from .rules import docker_swarm
    from .rules import docker_stack
    from .rules import docker_network
    from .rules import docker_image
    from .rules import docker_container
    from .rules import docker_volume
    from .rules import docker_system
    from .rules import docker_build
    from .rules import docker_run
   

# Generated at 2022-06-18 06:39:56.886845
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .conf import load_settings
    from .conf import reload_settings
    from .conf import clear_settings_cache
    from .conf import clear_cache
    from .conf import clear_all_caches
    from .conf import clear_all_settings
    from .conf import clear_all
    from . import main
    from . import types
    from . import conf
    from . import system
    from . import logs
    from . import shell
    from . import utils
    from . import __main__
    from . import __init__
    from . import __version__
    from . import __about__
    from . import __copyright__
    from . import __license__


# Generated at 2022-06-18 06:39:58.664133
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:04.674801
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path('/home/nvbn/projects/thefuck/thefuck/rules'),
        Path('/home/nvbn/.config/thefuck/rules'),
        Path('/home/nvbn/.local/lib/python2.7/site-packages/thefuck_contrib_git/rules'),
        Path('/home/nvbn/.local/lib/python2.7/site-packages/thefuck_contrib_python/rules')]

# Generated at 2022-06-18 06:40:14.764879
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import CommandOutput
    from .types import Output

    class TestRule(Rule):
        def __init__(self, priority, command, corrected_command):
            self.priority = priority
            self.command = command
            self.corrected_command = corrected_command

        def is_match(self, command):
            return command == self.command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.corrected_command, self.priority)]

    class TestSettings(Settings):
        def __init__(self, rules):
            self.rules = rules

        def get_rules(self):
            return self.rules


# Generated at 2022-06-18 06:40:17.601855
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:26.997176
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = [Path(__file__).parent.joinpath('rules/__init__.py'),
                   Path(__file__).parent.joinpath('rules/bash.py'),
                   Path(__file__).parent.joinpath('rules/git.py'),
                   Path(__file__).parent.joinpath('rules/man.py'),
                   Path(__file__).parent.joinpath('rules/pip.py'),
                   Path(__file__).parent.joinpath('rules/python.py'),
                   Path(__file__).parent.joinpath('rules/sudo.py'),
                   Path(__file__).parent.joinpath('rules/system.py'),
                   Path(__file__).parent.joinpath('rules/yarn.py')]
    rules = get_loaded_rules(rules_paths)

# Generated at 2022-06-18 06:40:31.620572
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1


# Generated at 2022-06-18 06:41:10.175974
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Command

    class TestRule(Rule):
        def __init__(self, priority):
            self.priority = priority

        def is_match(self, command):
            return True

        def get_corrected_commands(self, command):
            return [CorrectedCommand(command, '', self.priority)]


# Generated at 2022-06-18 06:41:10.577380
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:41:19.715847
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptTemplate
    from .types import Regex
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLineInput
    from .types import CommandLineOutput
    from .types import CommandLineError
    from .types import CommandLineHistory
    from .types import CommandLineHistoryItem
    from .types import CommandLineHistoryItemInput
    from .types import CommandLineHistoryItemOutput
    from .types import CommandLineHistoryItemError
    from .types import CommandLineHistoryItemTime
    from .types import CommandLineHistoryItemTimeStamp
    from .types import CommandLineHistoryItemTimeDelta
    from .types import CommandLineHistoryItemTimeDeltaDays
    from .types import CommandLineHistoryItem

# Generated at 2022-06-18 06:41:25.415017
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:41:35.036949
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.php import match, get_new_command

# Generated at 2022-06-18 06:41:45.721939
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    def get_corrected_commands(command):
        return [CorrectedCommand(Command('ls'), 'ls', 1),
                CorrectedCommand(Command('ls'), 'ls', 2),
                CorrectedCommand(Command('ls'), 'ls', 3),
                CorrectedCommand(Command('ls'), 'ls', 4),
                CorrectedCommand(Command('ls'), 'ls', 5),
                CorrectedCommand(Command('ls'), 'ls', 6)]


# Generated at 2022-06-18 06:41:48.293210
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:50.651551
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:56.914301
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == [Rule('test', '/tmp/test.py')]
    assert list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')])) == [Rule('test', '/tmp/test.py'), Rule('test2', '/tmp/test2.py')]


# Generated at 2022-06-18 06:41:58.775244
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:42:40.141623
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import Priority
    from .conf import settings
    from . import logs
    from . import types
    from . import conf
    from . import system
    from . import logs
    from . import utils
    from . import main
    from . import rules
    from . import loader
    from . import __main__
    from . import __init__
    from . import __version__
    from . import __about__
    from . import __pkginfo__
    from . import __copyright__
    from . import __license__
    from . import __doc__
    from . import __all__
    from . import __author__
    from . import __author_email__
    from . import __m

# Generated at 2022-06-18 06:42:48.677768
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.bower import match

# Generated at 2022-06-18 06:42:54.399161
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:42:55.469221
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:42:56.380269
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:43:03.452255
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output

    class TestRule(Rule):
        def __init__(self, priority, command, output):
            self.priority = priority
            self.command = command
            self.output = output

        def is_match(self, command):
            return True

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.command, self.output, self.priority)]


# Generated at 2022-06-18 06:43:05.904464
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:43:06.685489
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:43:16.935932
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import PythonRule
    from .types import PythonScriptRule
    from .types import RegexRule
    from .types import RegexScriptRule


# Generated at 2022-06-18 06:43:18.615126
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:44:52.345292
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.no import match, get_new_command
    from .rules.everything import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt_get import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command

# Generated at 2022-06-18 06:44:55.072873
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:44:56.800637
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:01.535764
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:45:08.405159
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule.py')])) == [Rule(
                                      name='rule',
                                      match=None,
                                      get_new_command=None,
                                      enabled_by_default=True,
                                      priority=100)]


# Generated at 2022-06-18 06:45:20.819561
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.no import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.default import match, get_new_command
    from .rules.git_branch import match

# Generated at 2022-06-18 06:45:21.691396
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:45:23.989324
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'),
                                        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:26.729939
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules'), Path(sys.path[0]).joinpath('thefuck_contrib_git')]