

# Generated at 2022-06-18 06:35:50.043015
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match2, get_new_command as get_new_command2
    from .rules.pip import match as match3, get_new_command as get_new_command3
    from .rules.sudo import match as match4, get_new_command as get_new_command4
    from .rules.cd import match as match5, get_new_command as get_new_command5
    from .rules.man import match as match6, get_new_command as get_new_command6
    from .rules.apt import match as match7, get_new_command as get_new_command7
    from .rules.brew import match as match8, get_new_command as get_new_command8
   

# Generated at 2022-06-18 06:35:52.463510
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:35:54.653456
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:04.515473
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:36:05.508243
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:09.865997
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')])) == [Rule.from_path(Path(__file__).parent.joinpath('rules/git.py'))]


# Generated at 2022-06-18 06:36:11.364116
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:36:22.945374
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.systemctl import match, get_new_command
    from .rules.docker import match, get_new_command

# Generated at 2022-06-18 06:36:30.387226
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.system import match as match_system

# Generated at 2022-06-18 06:36:31.710730
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0


# Generated at 2022-06-18 06:36:48.116225
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.brew import match as match_brew

# Generated at 2022-06-18 06:36:59.114405
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import AndRule
    from .types import OrRule
    from .types import NotRule
    from .types import AlwaysRule
    from .types import NeverRule
    from .types import AnyRule
    from .types import AllRule
    from .types import Match
    from .types import NoMatch
    from .types import Result
    from .types import Success
    from .types import Failure
    from .types import Command
    from .types import Command
    from .types import Command
    from .types import Command
    from .types import Command
    from .types import Command

# Generated at 2022-06-18 06:37:00.159476
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:37:10.965535
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output

    class TestRule(Rule):
        def __init__(self, priority, command, corrected_command):
            self.priority = priority
            self.command = command
            self.corrected_command = corrected_command

        def is_match(self, command):
            return self.command == command

        def get_corrected_commands(self, command):
            return [self.corrected_command]

    class TestScript(Script):
        def __init__(self, command, output):
            self.command = command
            self.output = output

        def run(self, command):
            return CommandOutput(self.output, self.command)



# Generated at 2022-06-18 06:37:16.093559
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1


# Generated at 2022-06-18 06:37:26.276038
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:37:28.189469
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:32.392479
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = [Path(__file__).parent.joinpath('rules/__init__.py'),
                   Path(__file__).parent.joinpath('rules/bash.py'),
                   Path(__file__).parent.joinpath('rules/git.py')]
    assert len(list(get_loaded_rules(rules_paths))) == 2


# Generated at 2022-06-18 06:37:40.495984
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import CommandOutput

    class TestRule(Rule):
        def __init__(self, priority, command, output):
            self.priority = priority
            self.command = command
            self.output = output

        def is_match(self, command):
            return True

        def get_new_command(self, command):
            return self.command

        def get_output(self, command):
            return CommandOutput(self.output, '', 0)

    class TestSettings(Settings):
        def __init__(self, no_colors):
            self.no_colors = no_colors

    class TestCommand(Command):
        def __init__(self, script):
            self.script

# Generated at 2022-06-18 06:37:43.516860
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:59.223007
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:38:08.719597
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CorrectedCommand
    from .types import CorrectedScript
    from .types import CorrectedOutput
    from .types import CommandNotFound
    from .types import CommandExecuted
    from .types import CommandFailed
    from .types import CommandRunning
    from .types import CommandTimeoutExpired
    from .types import CommandKilled
    from .types import CommandTerminated
    from .types import CommandNotFound
    from .types import CommandNotFound
    from .types import CommandNotFound
    from .types import CommandNotFound
    from .types import CommandNotFound
    from .types import CommandNotFound
    from .types import CommandNotFound
    from .types import CommandNotFound

# Generated at 2022-06-18 06:38:11.548818
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:13.654980
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:17.751897
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:38:30.424152
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLineInput

    class TestRule(Rule):
        def __init__(self, priority):
            self.priority = priority


# Generated at 2022-06-18 06:38:32.920514
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:38:43.845301
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.composer import match, get_new_command
    from .rules.gem import match, get_new_command

# Generated at 2022-06-18 06:38:48.542613
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:38:56.932960
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command


# Generated at 2022-06-18 06:39:35.496607
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:39:44.668664
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.permission import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.mkdir import match, get_new_command
    from .rules.rm import match, get_new_command
    from .rules.cp import match, get_new_command
    from .rules.mv import match, get_new_command

# Generated at 2022-06-18 06:39:54.010019
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLineInput
    from .types import CommandLineOutput
    from .types import CommandLineError
    from .types import CommandLineHistory
    from .types import CommandLineHistoryItem
    from .types import CommandLineHistoryItemInput
    from .types import CommandLineHistoryItemOutput
    from .types import CommandLineHistoryItemError

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

        def match(self, command):
            return True


# Generated at 2022-06-18 06:39:56.339235
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:04.437595
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/rules/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/rules/__init__.py'),
                             Path('/tmp/rules/rule.py')]) == [Rule.from_path(Path('/tmp/rules/rule.py'))]
    assert get_loaded_rules([Path('/tmp/rules/__init__.py'),
                             Path('/tmp/rules/rule.py'),
                             Path('/tmp/rules/rule2.py')]) == [Rule.from_path(Path('/tmp/rules/rule.py')), Rule.from_path(Path('/tmp/rules/rule2.py'))]


# Generated at 2022-06-18 06:40:05.334247
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:40:15.459559
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:40:25.214815
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Command

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

        def match(self, command):
            return True


# Generated at 2022-06-18 06:40:26.140442
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:40:28.816570
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:33.848324
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_force
    from .rules import git_push_set_upstream
    from .rules import git_push_set_upstream_with_branch
    from .rules import git_push_set_upstream_with_branch_and_force
    from .rules import git_push_set_upstream_with_force
    from .rules import git_push_with_force
    from .rules import git_push_with_set_upstream
    from .rules import git_push_with_set_upstream_and_force
    from .rules import git_push_with_set_upstream_and_branch
    from .rules import git_push_with_set_upstream_and_branch_and_force
    from .rules import git_push_with_set

# Generated at 2022-06-18 06:41:36.977752
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == [Rule('test', '/tmp/test.py', 'test', 'test')]


# Generated at 2022-06-18 06:41:48.236446
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Response
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
   

# Generated at 2022-06-18 06:41:50.144672
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:41:55.916178
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    commands = [CorrectedCommand(command='ls -la', priority=1),
                CorrectedCommand(command='ls -l', priority=2),
                CorrectedCommand(command='ls -la', priority=3)]
    assert list(organize_commands(commands)) == [
        CorrectedCommand(command='ls -la', priority=3),
        CorrectedCommand(command='ls -l', priority=2)]

# Generated at 2022-06-18 06:42:05.523543
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.apt import match as match_apt, get_new_command as get_new_command_apt
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.man import match as match_man, get_new_command as get_new_command_man

# Generated at 2022-06-18 06:42:15.418298
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:42:21.910230
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py'), Path('/tmp/__init__.py')]))) == 2


# Generated at 2022-06-18 06:42:30.860994
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
   

# Generated at 2022-06-18 06:42:34.662435
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/__init__.py'),
                             Path('/tmp/test.py')]) == [Rule.from_path(Path('/tmp/test.py'))]


# Generated at 2022-06-18 06:45:00.457364
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.no import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.virtualenv import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.npm import match

# Generated at 2022-06-18 06:45:02.868845
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:11.132966
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')),
                                                               Rule.from_path(Path('/tmp/rule2.py'))]
   

# Generated at 2022-06-18 06:45:13.252428
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:45:20.121607
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('__init__.py')])) == []
    assert list(get_loaded_rules([Path('__init__.py'), Path('rule.py')])) == [Rule.from_path(Path('rule.py'))]
    assert list(get_loaded_rules([Path('__init__.py'), Path('rule.py'), Path('rule2.py')])) == [Rule.from_path(Path('rule.py')), Rule.from_path(Path('rule2.py'))]


# Generated at 2022-06-18 06:45:22.285181
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:26.132475
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:45:30.353872
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
