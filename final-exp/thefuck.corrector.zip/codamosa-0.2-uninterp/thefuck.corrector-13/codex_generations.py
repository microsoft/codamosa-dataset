

# Generated at 2022-06-18 06:35:49.247599
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .conf import settings
    from .system import Path
    from . import logs
    from . import rules
    from . import utils
    import sys
    import os
    import shutil
    import tempfile
    import unittest

    class TestRule(Rule):
        def __init__(self, command, corrected_command, priority=1):
            self.command = command
            self.corrected_command = corrected_command
            self.priority = priority

        def is_match(self, command):
            return command.script == self.command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.corrected_command, self.priority)]


# Generated at 2022-06-18 06:35:59.108417
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_force
    from .rules import git_push_set_upstream
    from .rules import git_push_set_upstream_with_branch
    from .rules import git_push_with_branch
    from .rules import git_push_with_set_upstream
    from .rules import git_push_with_set_upstream_and_branch
    from .rules import git_push_with_set_upstream_and_branch_and_force
    from .rules import git_push_with_set_upstream_and_force
    from .rules import git_push_with_set_upstream_and_force_and_branch
    from .rules import git_push_with_set_upstream_and_force_and_branch_and_

# Generated at 2022-06-18 06:36:01.145338
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:03.286485
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:10.555981
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command

# Generated at 2022-06-18 06:36:22.328681
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_force
    from .rules import git_push_set_upstream
    from .rules import git_push_set_upstream_force
    from .rules import git_push_set_upstream_force_with_lease
    from .rules import git_push_set_upstream_with_lease
    from .rules import git_push_with_lease
    from .rules import git_push_with_lease_and_set_upstream
    from .rules import git_push_with_lease_and_set_upstream_force
    from .rules import git_push_with_lease_force
    from .rules import git_push_with_lease_force_with_lease
    from .rules import git_push_with_lease_with_lease
    from .rules import git_

# Generated at 2022-06-18 06:36:30.015980
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .conf import settings
    settings.priority = lambda x: x.priority

# Generated at 2022-06-18 06:36:32.862385
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:33.791495
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:36:45.178150
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.cargo import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.brew import match, get_new_command

# Generated at 2022-06-18 06:37:01.925452
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Priority
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Priority
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Priority
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Priority
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Priority
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Priority
    from .types import CorrectedCommand
    from .types import Command

# Generated at 2022-06-18 06:37:04.601252
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path('/home/user/.config/thefuck/rules'), Path('/usr/local/lib/python3.5/dist-packages/thefuck/rules')]

# Generated at 2022-06-18 06:37:09.730623
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/rules/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/rules/__init__.py'),
                             Path('/tmp/rules/rule.py')]) == [Rule.from_path(Path('/tmp/rules/rule.py'))]


# Generated at 2022-06-18 06:37:21.117574
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output


# Generated at 2022-06-18 06:37:30.631283
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.apt_get import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command

# Generated at 2022-06-18 06:37:31.487291
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:37:33.145559
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:35.360641
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:37:36.154178
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:37:38.318800
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:01.788868
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []

# Generated at 2022-06-18 06:38:12.380285
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match2, get_new_command as get_new_command2
    from .rules.sudo import match as match3, get_new_command as get_new_command3
    from .rules.man import match as match4, get_new_command as get_new_command4
    from .rules.cd import match as match5, get_new_command as get_new_command5
    from .rules.pip import match as match6, get_new_command as get_new_command6
    from .rules.npm import match as match7, get_new_command as get_new_command7
    from .rules.gem import match as match8, get_new_command as get_new_command8


# Generated at 2022-06-18 06:38:15.275557
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:25.988040
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_current_branch
    from .rules import git_push_current_branch_with_sudo
    from .rules import git_push_current_branch_with_sudo_and_remote
    from .rules import git_push_current_branch_with_remote
    from .rules import git_push_current_branch_with_remote_and_sudo
    from .rules import git_push_current_branch_with_remote_and_sudo_and_branch
    from .rules import git_push_current_branch_with_remote_and_branch
    from .rules import git_push_current_branch_with_remote_and_branch_and_sudo
    from .rules import git_push_current_branch_with_remote_and_br

# Generated at 2022-06-18 06:38:32.690815
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:38:43.410819
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.mkdir import match, get_new_command
    from .rules.rm import match, get_new_command
    from .rules.ssh import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command

# Generated at 2022-06-18 06:38:53.109602
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command
    from .rules.dnf import match, get_new_command

# Generated at 2022-06-18 06:38:59.917545
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.no import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.pwd import match, get_new_command
    from .rules.ls import match, get_new_command

# Generated at 2022-06-18 06:39:10.665648
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.composer import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.svn import match, get_new_command

# Generated at 2022-06-18 06:39:23.995400
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .rules.git import git_rule
    from .rules.pip import pip_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.system import system_rule
    from .rules.cd import cd_rule
    from .rules.man import man_rule
    from .rules.brew import brew_rule
    from .rules.apt import apt_rule
    from .rules.gem import gem_rule
    from .rules.npm import npm_rule
    from .rules.yarn import yarn_rule
    from .rules.bower import bower_rule
    from .rules.vagrant import vagrant_rule
    from .rules.docker import docker_rule
    from .rules.docker_compose import docker_compose_rule
   

# Generated at 2022-06-18 06:39:52.201807
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths()

# Generated at 2022-06-18 06:39:54.591412
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'),
                                        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:02.972392
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import RegexRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule


# Generated at 2022-06-18 06:40:04.116126
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:40:14.162820
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command, CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.brew import match

# Generated at 2022-06-18 06:40:24.045265
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import RegexRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule


# Generated at 2022-06-18 06:40:34.451913
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')),
                                                               Rule.from_path(Path('/tmp/rule2.py'))]
   

# Generated at 2022-06-18 06:40:36.668660
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:43.595232
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py'), Path('/tmp/__init__.py')]))) == 2


# Generated at 2022-06-18 06:40:45.829541
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:42.388103
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:53.984903
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Command

    class TestRule(Rule):
        def __init__(self, name, priority, is_match, get_corrected_commands):
            self.name = name
            self.priority = priority
            self.is_match = is_match
            self.get_corrected_commands = get_corrected_commands

    def test_is_match(command):
        return True


# Generated at 2022-06-18 06:41:55.634517
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:57.401154
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:42:06.813842
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_current_branch
    from .rules import git_push_current_branch_to_upstream
    from .rules import git_push_current_branch_to_upstream_with_tags
    from .rules import git_push_current_branch_to_upstream_with_force
    from .rules import git_push_current_branch_to_upstream_with_tags_and_force
    from .rules import git_push_current_branch_to_upstream_with_force_and_tags
    from .rules import git_push_current_branch_to_upstream_with_tags_and_force_and_set_upstream
    from .rules import git_push_current_branch_to_upstream_with_force_and_

# Generated at 2022-06-18 06:42:16.178103
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:42:24.824430
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import RegexRule
    from .types import CommandRule
    from .types import StringRule
    from .types import FunctionRule
    from .types import load_source
    from .types import get_all_executables
    from .types import get_all_scripts
    from .types import get_all_aliases
    from .types import get_all_functions
    from .types import get_all_rules
    from .types import get_all_rules_names
    from .types import get_all_rules_descriptions
    from .types import get_all_rules_examples
    from .types import get_all_rules_options

# Generated at 2022-06-18 06:42:28.316470
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == [Rule.from_path(Path('/tmp/test.py'))]


# Generated at 2022-06-18 06:42:29.749259
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:42:37.464803
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Command
    from .types import Script
    from .types import CommandOutput
    from .types import Output

    class TestRule(Rule):
        def match(self, command):
            return True

        def get_new_command(self, command):
            return u'echo "test"'

    class TestRule2(Rule):
        def match(self, command):
            return True

        def get_new_command(self, command):
            return u'echo "test"'

    class TestRule3(Rule):
        def match(self, command):
            return True

        def get_new_command(self, command):
            return u'echo "test"'

    class TestRule4(Rule):
        def match(self, command):
            return True

       

# Generated at 2022-06-18 06:45:00.048357
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2


# Generated at 2022-06-18 06:45:02.708070
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:06.271788
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = [Path(__file__).parent.joinpath('rules/__init__.py'),
                   Path(__file__).parent.joinpath('rules/git.py')]
    assert len(list(get_loaded_rules(rules_paths))) == 1


# Generated at 2022-06-18 06:45:10.792589
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__)]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules')]))) == 3
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules'),
                                      Path(__file__).parent.joinpath('rules')]))) == 3


# Generated at 2022-06-18 06:45:21.422817
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .conf import settings
    from .system import Path
    from . import logs
    import sys

    class TestRule(Rule):
        def __init__(self, name, priority):
            self.name = name
            self.priority = priority

        def is_match(self, command):
            return True

        def get_corrected_commands(self, command):
            return [CorrectedCommand(command.script,
                                     '{} {}'.format(command.script, self.name),
                                     self.priority)]

    class TestCommand(Command):
        def __init__(self, script):
            self.script = script


# Generated at 2022-06-18 06:45:30.353554
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import Priority
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput