

# Generated at 2022-06-18 06:35:41.546390
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]) == []
    assert get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]) == [Rule.from_path(Path(__file__).parent.joinpath('rules/git.py'))]


# Generated at 2022-06-18 06:35:51.944441
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .system import Path
    from . import logs
    import sys
    import os
    import shutil
    import tempfile
    import unittest

    class TestOrganizeCommands(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.old_user_dir = settings.user_dir
            settings.user_dir = Path(self.tempdir)
            self.old_sys_path = sys.path
            sys.path.append(self.tempdir)
            self.old_log_level = logs.log_level
            logs.log_level = logs.DEBUG


# Generated at 2022-06-18 06:35:54.002646
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:35:58.385357
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1


# Generated at 2022-06-18 06:36:07.491266
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule

    # Test for ScriptRule
    script_rule = ScriptRule(
        'git',
        Script(
            'git',
            'git commit -am "{}"',
            'git commit -am "{}"',
            'git commit -am "{}"'
        )
    )
    script_rule.priority = 1
    script_rule.is_enabled = True
    script_rule.is_match = lambda command: True

# Generated at 2022-06-18 06:36:09.109091
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:21.240768
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .rules import get_rules
    from .rules import organize_commands
    from .rules import get_corrected_commands

    # Test for organize_commands
    # Test for organize_commands with one command
    assert list(organize_commands([CorrectedCommand(Command('ls'), 'ls', 1)])) == [CorrectedCommand(Command('ls'), 'ls', 1)]

    # Test for organize_commands with two commands
    assert list(organize_commands([CorrectedCommand(Command('ls'), 'ls', 1), CorrectedCommand(Command('ls'), 'ls', 1)])) == [CorrectedCommand(Command('ls'), 'ls', 1)]

    # Test for organize_commands with three commands

# Generated at 2022-06-18 06:36:23.618736
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:25.814491
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:27.621158
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:44.979961
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/test/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test/test.py')])) == [Rule('test', '/tmp/test/test.py')]
    assert list(get_loaded_rules([Path('/tmp/test/test.py'), Path('/tmp/test/test2.py')])) == [Rule('test', '/tmp/test/test.py'), Rule('test2', '/tmp/test/test2.py')]

# Generated at 2022-06-18 06:36:45.512039
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()

# Generated at 2022-06-18 06:36:48.499471
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:54.010515
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:36:56.698400
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:00.023855
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules'),
        Path(__file__).parent.joinpath('rules')]

# Generated at 2022-06-18 06:37:05.616675
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')])) == [Rule.from_path(Path(__file__).parent.joinpath('rules/git.py'))]


# Generated at 2022-06-18 06:37:16.194451
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')),
                                                              Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:37:26.359309
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptSuffix
    from .types import ScriptPrefix
    from .types import ScriptReplace
    from .types import ScriptReplacePattern
    from .types import ScriptResult
    from .types import ScriptSide
    from .types import ScriptContains
    from .types import ScriptContainsPattern
    from .types import ScriptEqual
    from .types import ScriptNotEqual
    from .types import ScriptEqualPattern
    from .types import ScriptNotEqualPattern
    from .types import ScriptAnd
    from .types import ScriptOr
    from .types import ScriptNot
    from .types import ScriptGlob
    from .types import ScriptGlobPattern
    from .types import ScriptRegex

# Generated at 2022-06-18 06:37:34.467545
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.ruby import match as match_ruby

# Generated at 2022-06-18 06:37:50.812983
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:37:53.118638
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:01.577846
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandExecuted
    from .types import CommandNotFound
    from .types import NoRuleMatched
    from .types import IncorrectUsage
    from .types import UnexpectedError
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode
    from .types import FailedToDecode

# Generated at 2022-06-18 06:38:06.579052
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/test.py')])) == [Rule(name='test',
                                                                                match=None,
                                                                                get_new_command=None,
                                                                                enabled_by_default=True,
                                                                                priority=1000)]


# Generated at 2022-06-18 06:38:17.100815
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd_parent
    from .rules import git_push
    from .rules import python_pip
    from .rules import python_pip_m
    from .rules import python_pip_uninstall
    from .rules import python_pip_uninstall_m
    from .rules import python_pip_uninstall_m_v
    from .rules import python_pip_uninstall_v
    from .rules import python_pip_v
    from .rules import python_pip_venv
    from .rules import python_pip_venv_m
    from .rules import python_pip_venv_m_v
    from .rules import python_pip_venv_v
    from .rules import python_pip_venv_uninstall

# Generated at 2022-06-18 06:38:23.564545
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:38:26.046468
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:35.165482
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import Regex
    from .types import Priority
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput

# Generated at 2022-06-18 06:38:42.725432
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule1.py'),
                                  Path('/tmp/rule2.py')])) == [Rule('rule1', '/tmp/rule1.py'),
                                                               Rule('rule2', '/tmp/rule2.py')]


# Generated at 2022-06-18 06:38:47.861404
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2


# Generated at 2022-06-18 06:39:21.229809
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:39:27.134706
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:39:37.811583
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import Regex
    from .types import CommandRule
    from .types import CommandScript
    from .types import CommandRegex
    from .types import Priority
    from .types import PriorityValue
    from .types import PriorityType
    from .types import PriorityOrder
    from .types import PriorityOrderType
    from .types import PriorityOrderValue
    from .types import PriorityOrderScript
    from .types import PriorityOrderRegex
    from .types import PriorityOrderCommand
    from .types import PriorityOrderCommandScript
    from .types import PriorityOrderCommandRegex
    from .types import PriorityOrderCommandRule
    from .types import PriorityOrderRule
    from .types import PriorityOrderScriptRegex
    from .types import PriorityOrderScript

# Generated at 2022-06-18 06:39:47.118158
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/test_get_loaded_rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test_get_loaded_rules/test_rule.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test_get_loaded_rules/test_rule.py'), Path('/tmp/test_get_loaded_rules/test_rule2.py')]))) == 2

# Generated at 2022-06-18 06:39:56.446765
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    import os
    import sys
    import tempfile
    import shutil
    import subprocess

    def create_temp_rule(rule_name, rule_priority, rule_command):
        rule_path = os.path.join(temp_dir, rule_name + '.py')
        with open(rule_path, 'w') as rule_file:
            rule_file.write(
                'from thefuck.types import Command\n'
                'from thefuck.types import CorrectedCommand\n'
                'def match(command):\n'
                '    return True\n'
                'def get_new_command(command):\n'
                '    return CorrectedCommand({}, {})\n'.format(
                    rule_command, rule_priority))
        return

# Generated at 2022-06-18 06:40:04.557738
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')),
                                                               Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:40:06.555839
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:17.426942
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.vagrant import match, get_new_command
    from .rules.docker import match

# Generated at 2022-06-18 06:40:26.532859
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')), Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:40:36.589531
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match

# Generated at 2022-06-18 06:41:26.750220
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:28.932087
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:37.612663
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    import unittest
    class TestOrganizeCommands(unittest.TestCase):
        def test_organize_commands(self):
            class TestRule(Rule):
                def __init__(self, priority, command, corrected_command):
                    self.priority = priority
                    self.command = command
                    self.corrected_command = corrected_command
                def is_match(self, command):
                    return command == self.command
                def get_corrected_commands(self, command):
                    return [self.corrected_command]
            command = Command('ls')

# Generated at 2022-06-18 06:41:40.701583
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:52.483463
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.vagrant import match, get_new_command
    from .rules.virtualenv import match, get_new_command

# Generated at 2022-06-18 06:42:00.488224
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command

# Generated at 2022-06-18 06:42:10.106603
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.python import match, get_new_command
    from .rules.git import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command

# Generated at 2022-06-18 06:42:15.147170
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    import tempfile
    import shutil
    import os


# Generated at 2022-06-18 06:42:16.377423
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0


# Generated at 2022-06-18 06:42:25.118971
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import RegexRule
    from .types import CommandRule
    from .types import StringRule
    from .types import FunctionRule
    from .types import AlwaysRule
    from .types import NeverRule
    from .types import AnyRule
    from .types import NotRule
    from .types import AndRule
    from .types import OrRule
    from .types import AllRule
    from .types import AnyRule
    from .types import NotRule
    from .types import AndRule
    from .types import OrRule
    from .types import AllRule
    from .types import AnyRule
    from .types import NotRule
    from .types import AndRule
    from .types import OrRule


# Generated at 2022-06-18 06:44:36.696640
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptSuffix
    from .types import ScriptPrefix
    from .types import CommandSuffix
    from .types import CommandPrefix
    from .types import CommandRegex
    from .types import CommandOutputRegex
    from .types import CommandOutput

    class TestRule(Rule):
        def __init__(self, priority, command_output, corrected_command):
            self.priority = priority
            self.command_output = command_output
            self.corrected_command = corrected_command

        def get_new_command(self, command):
            return self.corrected_command

        def match(self, command):
            return self.command_output == command.output


# Generated at 2022-06-18 06:44:43.504076
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py'), Path('/tmp/thefuck/rules/__init__.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:44:44.984694
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:44:53.822979
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptSuffix
    from .types import ScriptPrefix
    from .types import ScriptReplace
    from .types import ScriptReplaceWithPrefix
    from .types import ScriptReplaceWithSuffix
    from .types import ScriptInsertBefore
    from .types import ScriptInsertAfter
    from .types import ScriptDelete
    from .types import ScriptDeleteBefore
    from .types import ScriptDeleteAfter
    from .types import ScriptDeleteBeforeAndAfter
    from .types import ScriptDeleteBeforeAndInsertAfter
    from .types import ScriptDeleteAfterAndInsertBefore
    from .types import ScriptDeleteBeforeAndAfterAndInsertAfter
    from .types import ScriptDeleteBeforeAndAfterAndInsertBefore
    from .types import ScriptDeleteBeforeAnd

# Generated at 2022-06-18 06:45:00.821582
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    # Test for empty rules_paths
    assert not list(get_loaded_rules([]))
    # Test for rules_paths with __init__.py
    assert not list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))
    # Test for rules_paths with __init__.py and disabled rule
    assert not list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py'), Path(__file__).parent.joinpath('rules/bash.py')]))
    # Test for rules_paths with enabled rule
    assert list(get_loaded_rules([Path(__file__).parent.joinpath('rules/bash.py')]))


# Generated at 2022-06-18 06:45:10.267580
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.ls import match as match_ls, get_new_command as get_new_command_ls
    from .rules.mkdir import match as match_

# Generated at 2022-06-18 06:45:15.601528
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1


# Generated at 2022-06-18 06:45:19.644830
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'),
                                        settings.user_dir.joinpath('rules'),
                                        Path(sys.path[0]).joinpath('thefuck_contrib_*')]


# Generated at 2022-06-18 06:45:23.112935
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:45:31.586111
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    import unittest

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

        def match(self, command):
            return True

    class TestCase(unittest.TestCase):
        def test_organize_commands(self):
            command = Command('ls', '', '')