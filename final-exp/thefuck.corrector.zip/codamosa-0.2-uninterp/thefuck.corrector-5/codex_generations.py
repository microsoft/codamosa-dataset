

# Generated at 2022-06-18 06:35:41.301592
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:35:51.702525
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []

# Generated at 2022-06-18 06:35:52.221272
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:36:01.756722
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt_get import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.grep import match, get_new_command

# Generated at 2022-06-18 06:36:09.866322
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import Script

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

        def match(self, command):
            return True

    class TestScript(Script):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

        def match(self, command):
            return True

    command = Command('ls')

# Generated at 2022-06-18 06:36:22.064353
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .conf import settings
    settings.priority = lambda x: x.priority

# Generated at 2022-06-18 06:36:24.038857
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:26.772860
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/etc/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/etc/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:36:30.761550
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:36:42.736519
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.brew import match as match_brew, get_new_command as get_new_command_brew
    from .rules.apt import match as match

# Generated at 2022-06-18 06:36:51.089611
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:01.569185
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '', '', '', '', '')

# Generated at 2022-06-18 06:37:02.474252
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:37:03.517302
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:37:13.961504
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import CommandOutput
    from .types import Script
    from .types import ScriptOutput
    from .types import ScriptError
    from .types import ScriptStdout
    from .types import ScriptStderr
    from .types import ScriptStdin
    from .types import ScriptStdoutStderr
    from .types import ScriptStdoutStderrStdin
    from .types import ScriptStdoutStderrStdinPipe
    from .types import ScriptStdoutStderrPipe
    from .types import ScriptStdoutPipe
    from .types import ScriptStderrPipe
    from .types import ScriptStdinPipe
    from .types import ScriptStdoutStderrStdinPipe

# Generated at 2022-06-18 06:37:24.077322
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule('rule', '/tmp/rule.py')]
    assert list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule.py')])) == [Rule('rule', '/tmp/rule.py')]
    assert list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule2.py')])) == [Rule('rule', '/tmp/rule.py'), Rule('rule2', '/tmp/rule2.py')]


# Generated at 2022-06-18 06:37:28.396527
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2


# Generated at 2022-06-18 06:37:35.829603
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLineInput
    from .types import CommandLineOutput
    from .types import CommandLineError
    from .types import CommandLineHistory
    from .types import CommandLineHistoryItem
    from .types import CommandLineHistoryItemInput
    from .types import CommandLineHistoryItemOutput
    from .types import CommandLineHistoryItemError

    class TestRule(Rule):
        def __init__(self, priority, is_match, get_corrected_commands):
            self.priority = priority
            self.is_match = is_match
            self.get_corrected_commands = get_corrected_commands


# Generated at 2022-06-18 06:37:38.728257
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:37:48.402852
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

        def match(self, command):
            return True

    class TestCommand(Command):
        def __init__(self, script):
            self.script = script

        def script(self):
            return self.script

    class TestScript(Script):
        def __init__(self, script):
            self.script = script

        def script(self):
            return self.script


# Generated at 2022-06-18 06:38:04.908473
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py'),
                                  Path('/tmp/thefuck/rules/git.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/git.py'))]

# Generated at 2022-06-18 06:38:07.092744
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:17.591496
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '', '', '', '')

# Generated at 2022-06-18 06:38:30.290503
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', 'ls')

# Generated at 2022-06-18 06:38:37.870460
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
    from .types import CommandLine
   

# Generated at 2022-06-18 06:38:49.282163
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py~')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swo')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swpx')])) == []

# Generated at 2022-06-18 06:38:55.281908
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:39:05.053620
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip

    class GitRule(Rule):
        name = 'git'
        priority = 1000
        is_enabled = True
        match = staticmethod(match)
        get_

# Generated at 2022-06-18 06:39:14.685282
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Command
    from .types import Script

    rule_1 = Rule(
        name='rule_1',
        match=lambda command: True,
        get_new_command=lambda command: 'rule_1',
        enabled_by_default=True)

    rule_2 = Rule(
        name='rule_2',
        match=lambda command: True,
        get_new_command=lambda command: 'rule_2',
        enabled_by_default=True)

    rule_3 = Rule(
        name='rule_3',
        match=lambda command: True,
        get_new_command=lambda command: 'rule_3',
        enabled_by_default=True)


# Generated at 2022-06-18 06:39:25.822120
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    # Test for empty list
    assert list(organize_commands([])) == []

    # Test for list with one element
    assert list(organize_commands([CorrectedCommand(Command('ls'), 'ls')])) == [CorrectedCommand(Command('ls'), 'ls')]

    # Test for list with two equal elements
    assert list(organize_commands([CorrectedCommand(Command('ls'), 'ls'), CorrectedCommand(Command('ls'), 'ls')])) == [CorrectedCommand(Command('ls'), 'ls')]

    # Test for list with two different elements

# Generated at 2022-06-18 06:39:41.740490
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    commands = [CorrectedCommand('ls', 'ls', 1),
                CorrectedCommand('ls', 'ls', 2),
                CorrectedCommand('ls', 'ls', 3),
                CorrectedCommand('ls', 'ls', 4),
                CorrectedCommand('ls', 'ls', 5)]
    assert list(organize_commands(commands)) == [commands[2], commands[3], commands[4]]

# Generated at 2022-06-18 06:39:51.333205
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command

# Generated at 2022-06-18 06:39:55.221205
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:40:00.312262
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py'), Path('/tmp/thefuck/rules/git.py')]))) == 2


# Generated at 2022-06-18 06:40:02.546367
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:04.987912
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:15.048569
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.git import match_file_not_found, get_new_command_file_not_found
    from .rules.git import match_file_not_found_in_submodule, get_new_command_file_not_found_in_submodule
    from .rules.git import match_file_not_found_in_submodule_short, get_new_command_file_not_found_in_submodule_short
    from .rules.git import match_file_not_found_in_submodule_short_no_submodule_name, get_new_command_file_not_found_in_submodule_short_no_submodule_name
    from .rules.git import match

# Generated at 2022-06-18 06:40:24.875943
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '', '', '', '')

# Generated at 2022-06-18 06:40:27.735635
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:37.415580
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command

# Generated at 2022-06-18 06:41:06.625431
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    import os
    import tempfile
    import shutil
    import sys

    def _create_rule(name, priority, command):
        rule_path = os.path.join(temp_dir, name + '.py')

# Generated at 2022-06-18 06:41:13.979442
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule

    class TestRule(Rule):
        def __init__(self, priority):
            self.priority = priority

        def is_match(self, command):
            return True

        def get_corrected_commands(self, command):
            return [CorrectedCommand(command.script, priority=self.priority)]


# Generated at 2022-06-18 06:41:25.262394
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:41:34.970471
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import Script
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Script
    from .types import Script
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Script
    from .types import Script
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Script
    from .types import Script
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Script
    from .types import Script
    from .types import Command
    from .types import Corrected

# Generated at 2022-06-18 06:41:45.723016
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.mkdir import match, get_new_command
    from .rules.cp import match, get_new_command
    from .rules.mv import match, get_new_command
    from .rules.rm import match, get_new_command
    from .rules.ssh import match, get_new_command

# Generated at 2022-06-18 06:41:52.888497
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py'), Path('/tmp/thefuck/rules/git.py')]))) == 2


# Generated at 2022-06-18 06:41:59.543152
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]) == []
    assert get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]) == [Rule.from_path(Path(__file__).parent.joinpath('rules/git.py'))]
    assert get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]) == [Rule.from_path(Path(__file__).parent.joinpath('rules/git.py'))]


# Generated at 2022-06-18 06:42:09.256692
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.no import match, get_new_command
    from .rules.cp import match, get_new_command
    from .rules.mv import match, get_new_command
    from .rules.rm import match, get_new_command
    from .rules.mkdir import match, get_new_command

# Generated at 2022-06-18 06:42:11.587899
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'),
                                        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:42:20.919853
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    import os
    import tempfile
    import shutil

    def create_rule(name, priority, command):
        rule_path = os.path.join(temp_dir, name)

# Generated at 2022-06-18 06:42:54.057947
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command

# Generated at 2022-06-18 06:43:02.221142
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py'),
                                  Path('/tmp/thefuck/rules/git.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/git.py'))]

# Generated at 2022-06-18 06:43:11.971080
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command

# Generated at 2022-06-18 06:43:22.049837
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptSuffix
    from .types import ScriptPrefix
    from .types import ScriptReplace
    from .types import ScriptReplacePattern
    from .types import ScriptResult
    from .types import ScriptSide
    from .types import ScriptType
    from .types import ScriptMatch
    from .types import ScriptMatchPattern
    from .types import ScriptMatchSide
    from .types import ScriptMatchType

    class TestRule(Rule):
        def __init__(self, name, priority, command, corrected_command):
            self.name = name
            self.priority = priority
            self.is_enabled = True
            self.command = command
            self.corrected_command = corrected_command


# Generated at 2022-06-18 06:43:32.373962
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_push
    from .rules.pip import pip_install
    from .rules.python import python
    from .rules.sudo import sudo
    from .rules.system import cd
    from .rules.system import cp
    from .rules.system import mv
    from .rules.system import rm
    from .rules.system import touch
    from .rules.system import which
    from .rules.system import mkdir
    from .rules.system import ls
    from .rules.system import cat
    from .rules.system import echo
    from .rules.system import grep
    from .rules.system import man
    from .rules.system import history
    from .rules.system import alias
    from .rules.system import unalias
    from .rules.system import env

# Generated at 2022-06-18 06:43:35.983948
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == [Rule.from_path(Path('/tmp/test.py'))]


# Generated at 2022-06-18 06:43:44.689362
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.cargo import match, get_new_command
    from .rules.composer import match, get_new_command
    from .rules.docker import match, get_new_command

# Generated at 2022-06-18 06:43:52.490671
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.cp import match, get_new_command
    from .rules.rm import match, get_new_command
    from .rules.mkdir import match, get_new_command
    from .rules.mv import match

# Generated at 2022-06-18 06:44:00.762625
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.pwd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.mkdir import match, get_new_command
    from .rules.rm import match, get_new_command
    from .rules.cp import match, get_new_command

# Generated at 2022-06-18 06:44:03.779076
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:45:12.870597
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptSuffix
    from .types import ScriptPrefix
    from .types import ScriptReplace
    from .types import ScriptReplacePattern
    from .types import ScriptResult
    from .types import ScriptSide
    from .types import ScriptType
    from .types import ScriptWhen
    from .types import ScriptWhere
    from .types import ScriptWho
    from .types import ScriptWhy
    from .types import ScriptHow
    from .types import ScriptWhat
    from .types import ScriptWhich
    from .types import ScriptWhere
    from .types import ScriptHow
    from .types import ScriptWhy
    from .types import ScriptWho
    from .types import ScriptWhen
    from .types import ScriptWhere

# Generated at 2022-06-18 06:45:22.452075
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.misc import match as match_misc, get_new_command as get_new_command_misc
    from .rules.no import match as match_no

# Generated at 2022-06-18 06:45:23.316915
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:45:26.493240
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules'),
        Path(__file__).parent.joinpath('../contrib/rules')
    ]

# Generated at 2022-06-18 06:45:28.776314
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]