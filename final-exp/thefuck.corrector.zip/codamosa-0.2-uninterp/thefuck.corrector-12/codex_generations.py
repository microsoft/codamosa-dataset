

# Generated at 2022-06-18 06:35:49.466544
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.python_pip import match, get_new_command
    from .rules.python_brew import match, get_new_command
    from .rules.python_conda import match, get_new_command
    from .rules.python_pipenv import match, get_new_command
    from .rules.python_poetry import match, get_new_command
    from .rules.python_venv import match, get_new_command
    from .rules.python_virtualenv import match, get_new_command
    from .rules.python_virtualenvwrapper import match, get_new_command
    from .rules.python_venvwrapper import match, get_new_

# Generated at 2022-06-18 06:35:52.183080
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:01.713434
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule(
        name='rule',
        priority=500,
        is_enabled=True,
        module=sys.modules['thefuck.rules.rule'])]
    assert list(get_loaded_rules([Path('/tmp/rule_disabled.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule_with_priority.py')])) == [Rule(
        name='rule_with_priority',
        priority=1000,
        is_enabled=True,
        module=sys.modules['thefuck.rules.rule_with_priority'])]

# Generated at 2022-06-18 06:36:09.841740
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import Priority
    from .conf import settings
    from .conf import load_settings
    from .conf import reload_settings
    from .conf import clear_settings
    from .conf import get_settings
    from .conf import get_all_settings
    from .conf import get_all_settings_names
    from .conf import get_all_settings_paths
    from .conf import get_all_settings_modules
    from .conf import get_all_settings_values
    from .conf import get_all_settings_default_values
    from .conf import get_all_settings_help_texts
    from .conf import get_all_settings_types
    from .conf import get_all_settings_

# Generated at 2022-06-18 06:36:22.064869
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == [Rule(
        name='test',
        match=None,
        get_new_command=None,
        enabled_by_default=True,
        priority=1000)]

# Generated at 2022-06-18 06:36:24.376404
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:26.206759
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:35.986003
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command, CorrectedCommand
    from .rules.git import match, get_new_command
    import tempfile
    import os
    import shutil
    import sys
    import subprocess
    import thefuck
    import thefuck.rules.git
    import thefuck.rules.python
    import thefuck.rules.sudo
    import thefuck.rules.man
    import thefuck.rules.misc
    import thefuck.rules.pip
    import thefuck.rules.git_add
    import thefuck.rules.git_commit
    import thefuck.rules.git_push
    import thefuck.rules.git_branch
    import thefuck.rules.git_checkout
    import thefuck.rules.git_diff
    import thefuck.rules.git_merge
    import thefuck.rules.git_pull

# Generated at 2022-06-18 06:36:39.102676
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:43.335635
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules'),
        Path(__file__).parent.joinpath('..').joinpath('contrib').joinpath('rules')
    ]

# Generated at 2022-06-18 06:37:00.108466
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command

# Generated at 2022-06-18 06:37:06.779680
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.cargo import match, get_new_command

# Generated at 2022-06-18 06:37:18.052983
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import AndRule
    from .types import OrRule
    from .types import NotRule
    from .types import AlwaysRule
    from .types import NeverRule
    from .types import AnyRule
    from .types import AllRule
    from .types import AnyOfRule
    from .types import AllOfRule
    from .types import NoneOfRule
    from .types import OneOfRule
    from .types import HasRule
    from .types import HasAllRule
    from .types import HasAnyRule
    from .types import HasNoneRule
    from .types import HasOneRule


# Generated at 2022-06-18 06:37:18.964227
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:37:23.197604
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/test.py')]) == [Rule.from_path(Path('/tmp/test.py'))]


# Generated at 2022-06-18 06:37:25.157557
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:27.076446
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:32.894247
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:37:34.532485
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:36.266236
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:54.201792
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:37:56.194699
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:57.257813
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0


# Generated at 2022-06-18 06:38:06.504247
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput

    class TestRule(Rule):
        def __init__(self, priority, command, output):
            self.priority = priority
            self.command = command
            self.output = output

        def is_match(self, command):
            return True

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.command, self.output, self.priority)]

    command = Command('ls', '', CommandOutput('', '', '', ''))

# Generated at 2022-06-18 06:38:08.021531
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules')]

# Generated at 2022-06-18 06:38:18.500187
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import AndRule
    from .types import OrRule
    from .types import NotRule
    from .types import AnyRule
    from .types import AllRule
    from .types import NoRule
    from .types import AlwaysRule
    from .types import NeverRule
    from .types import PriorityRule
    from .types import Priority
    from .types import EnabledRule
    from .types import Enabled
    from .types import TitleRule
    from .types import Title
    from .types import DescriptionRule
    from .types import Description
    from .types import get_rule

    # Test

# Generated at 2022-06-18 06:38:22.400244
# Unit test for function get_rules
def test_get_rules():
    rules = get_rules()
    assert len(rules) > 0
    assert all(isinstance(rule, Rule) for rule in rules)

# Generated at 2022-06-18 06:38:32.305851
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '', '', '', '')
    corrected_commands = [CorrectedCommand(command, 'ls -la', '', '', '', ''),
                          CorrectedCommand(command, 'ls -l', '', '', '', ''),
                          CorrectedCommand(command, 'ls -a', '', '', '', '')]
    assert list(organize_commands(corrected_commands)) == [
        CorrectedCommand(command, 'ls -la', '', '', '', ''),
        CorrectedCommand(command, 'ls -l', '', '', '', ''),
        CorrectedCommand(command, 'ls -a', '', '', '', '')]

# Generated at 2022-06-18 06:38:34.049969
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:36.244817
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:39:08.414994
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.composer import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.systemd import match, get_new_command

# Generated at 2022-06-18 06:39:09.511705
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:39:10.431482
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:39:17.411306
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from thefuck.types import Command
    from thefuck.rules.git_branch import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import match, get_new_command

# Generated at 2022-06-18 06:39:27.141650
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import FunctionRule
    from .types import Function

    # Test for ScriptRule
    def test_script_rule():
        script = Script('echo "fuck"', 'fuck')
        script_rule = ScriptRule(script)
        command = Command('echo "fuck"', 'fuck')
        corrected_commands = script_rule.get_corrected_commands(command)
        assert next(corrected_commands) == CorrectedCommand(script, command)

    # Test for CommandRule

# Generated at 2022-06-18 06:39:33.167084
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/path/to/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/path/to/rules/__init__.py'),
                                  Path('/path/to/rules/rule.py')])) == [Rule.from_path(Path('/path/to/rules/rule.py'))]


# Generated at 2022-06-18 06:39:42.572337
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .system import Path
    from .conf import settings
    from . import logs
    from . import rules
    from . import types
    from . import system
    from . import conf
    from . import main
    from . import utils
    from . import scripts
    from . import __main__
    from . import __init__
    from . import __version__
    from . import __about__
    from . import __pkginfo__
    from . import __copyright__
    from . import __license__
    from . import __doc__
    from . import __author__
    from . import __author_email__
    from . import __maintainer__
    from . import __maintainer_email__
    from . import __

# Generated at 2022-06-18 06:39:52.202716
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command

# Generated at 2022-06-18 06:39:55.572171
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/test.py')]) == [Rule.from_path(Path('/tmp/test.py'))]


# Generated at 2022-06-18 06:40:04.257707
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command, CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command

# Generated at 2022-06-18 06:40:54.049140
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = [Path(__file__).parent.joinpath('rules/__init__.py'),
                   Path(__file__).parent.joinpath('rules/git.py')]
    assert get_loaded_rules(rules_paths)


# Generated at 2022-06-18 06:41:03.323365
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_rule
    from .rules.pip import pip_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.system import system_rule
    from .rules.cd import cd_rule
    from .rules.man import man_rule
    from .rules.brew import brew_rule
    from .rules.npm import npm_rule
    from .rules.gem import gem_rule
    from .rules.grep import grep_rule
    from .rules.vagrant import vagrant_rule
    from .rules.docker import docker_rule
    from .rules.docker_compose import docker_compose_rule
    from .rules.docker_machine import docker_machine_rule
    from .rules.docker_swarm import docker_

# Generated at 2022-06-18 06:41:10.633909
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py'), Path('/tmp/rule.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'), Path('/tmp/rule.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:41:11.162351
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:41:13.003777
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:20.306307
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:41:31.506827
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_current_branch
    from .rules import git_push_current_branch_with_set_upstream
    from .rules import git_push_current_branch_with_set_upstream_and_force
    from .rules import git_push_current_branch_with_force
    from .rules import git_push_current_branch_with_force_and_set_upstream
    from .rules import git_push_current_branch_with_force_and_set_upstream_and_force
    from .rules import git_push_current_branch_with_force_and_set_upstream_and_force_and_set_upstream
    from .rules import git_push_current_branch_with_force_and_set_upstream

# Generated at 2022-06-18 06:41:39.271010
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.mkdir import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command

# Generated at 2022-06-18 06:41:51.546236
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '')

# Generated at 2022-06-18 06:41:59.637919
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import CommandOutput
    from .types import Script
    from .types import ScriptOutput
    from .types import ScriptError

    class TestRule(Rule):
        def __init__(self, priority, command, output):
            self.priority = priority
            self.command = command
            self.output = output

        def is_match(self, command):
            return command.script == self.command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(
                self.command,
                self.output,
                self.priority)]

    command = Command(Script('ls', 'ls'),
                      ScriptOutput('', '', '', '', '', ''),
                      ScriptError('', '', ''))



# Generated at 2022-06-18 06:43:53.758597
# Unit test for function organize_commands
def test_organize_commands():
    from thefuck.types import CorrectedCommand
    from thefuck.rules.git import match, get_new_command
    from tests.utils import Command


# Generated at 2022-06-18 06:44:01.954281
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command

# Generated at 2022-06-18 06:44:02.743838
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:44:05.949119
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = [Path(__file__).parent.joinpath('rules/__init__.py'),
                   Path(__file__).parent.joinpath('rules/git.py'),
                   Path(__file__).parent.joinpath('rules/pip.py')]
    assert len(list(get_loaded_rules(rules_paths))) == 2


# Generated at 2022-06-18 06:44:07.017341
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:44:11.124383
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:44:19.729756
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '', '', '', '')

# Generated at 2022-06-18 06:44:27.326093
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/rule.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/__init__.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule2.py')]))) == 2
    assert len(list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule2.py'), Path('/tmp/__init__.py')]))) == 2


# Generated at 2022-06-18 06:44:29.025590
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:44:30.884596
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]