

# Generated at 2022-06-18 06:35:48.163061
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import NoRuleMatched
    from .types import CommandNotFound
    from .types import IncorrectUsage
    from .types import UnexpectedError
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import NoRuleMatched
    from .types import CommandNotFound
    from .types import IncorrectUsage
    from .types import UnexpectedError
    from .types import CorrectedCommand
    from .types import Command

# Generated at 2022-06-18 06:35:58.130123
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py~')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swo')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swpx')])) == []

# Generated at 2022-06-18 06:36:07.245560
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python
    from .rules.python import get_new_command as get_new_command_python
    from .rules.pip import match as match_pip
    from .rules.pip import get_new_command as get_new_command_pip
    from .rules.sudo import match as match_sudo
    from .rules.sudo import get_new_command as get_new_command_sudo
    from .rules.cd import match as match_cd
    from .rules.cd import get_new_command as get_new_command_cd
    from .rules.man import match as match_man
    from .rules.man import get_new_command as get_new_command_man

# Generated at 2022-06-18 06:36:09.071423
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:09.986310
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:36:11.514961
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:36:23.076993
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import CorrectedOutput
    from .types import CommandMatches
    from .types import Matches
    from .types import Match
    from .types import CommandScript
    from .types import Script
    from .types import CommandScript
    from .types import Script
    from .types import CommandScript
    from .types import Script
    from .types import CommandScript
    from .types import Script
    from .types import CommandScript
    from .types import Script
    from .types import CommandScript
    from .types import Script
    from .types import CommandScript
    from .types import Script
    from .types import CommandScript
    from .types import Script
   

# Generated at 2022-06-18 06:36:24.972113
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:28.795148
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]

# Generated at 2022-06-18 06:36:40.136618
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput

# Generated at 2022-06-18 06:36:57.580212
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.bower import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command

# Generated at 2022-06-18 06:36:59.755678
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:06.566183
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py'), Path(__file__).parent.joinpath('rules/brew.py')]))) == 2


# Generated at 2022-06-18 06:37:17.825724
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule1.py')])) == [Rule.from_path(Path('/tmp/rules/rule1.py'))]
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule1.py'),
                                  Path('/tmp/rules/rule2.py')])) == [Rule.from_path(Path('/tmp/rules/rule1.py')),
                                                                     Rule.from_path(Path('/tmp/rules/rule2.py'))]


# Generated at 2022-06-18 06:37:27.614992
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd_parent
    from .rules import git_push_force
    from .rules import python_pip_install
    from .rules import python_pip_uninstall
    from .rules import python_pip_upgrade
    from .rules import python_pip_upgrade_all
    from .rules import python_pip_upgrade_pip
    from .rules import python_pip_upgrade_setuptools
    from .rules import python_pip_upgrade_wheel
    from .rules import python_pip_upgrade_virtualenv
    from .rules import python_pip_upgrade_virtualenvwrapper
    from .rules import python_pip_upgrade_virtualenvwrapper_win
    from .rules import python_pip_upgrade_virtualenv_win
   

# Generated at 2022-06-18 06:37:29.927153
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    rules_paths = [Path(__file__).parent.joinpath('rules')]
    assert len(list(get_loaded_rules(rules_paths))) == 0


# Generated at 2022-06-18 06:37:30.816984
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:37:33.146356
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:42.082128
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_force
    from .rules import git_push_set_upstream
    from .rules import git_push_set_upstream_to_push
    from .rules import git_push_set_upstream_to_push_with_set_upstream
    from .rules import git_push_set_upstream_to_push_with_set_upstream_and_force
    from .rules import git_push_set_upstream_to_push_with_force
    from .rules import git_push_set_upstream_to_push_with_set_upstream_and_force_and_push_with_set_upstream_and_force
    from .rules import git_push_set_upstream_to_push_with_set_upstream_and_force_

# Generated at 2022-06-18 06:37:46.265900
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:38:00.594612
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:38:01.577229
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()


# Generated at 2022-06-18 06:38:02.437896
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:38:13.084121
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .shells import Bash
    from .shells import Zsh
    from .shells import Fish
    from .shells import Powershell
    from .shells import Shell

    def get_corrected_command(shell, command, priority):
        return CorrectedCommand(shell, command, priority)

    def get_corrected_commands(shell, commands, priority):
        return [get_corrected_command(shell, command, priority)
                for command in commands]

    def get_corrected_commands_with_priority(shell, commands_with_priority):
        return [get_corrected_command(shell, command, priority)
                for command, priority in commands_with_priority]


# Generated at 2022-06-18 06:38:15.567637
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:17.753342
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:30.424907
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.nvm import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.gem import match, get_new_command

# Generated at 2022-06-18 06:38:31.531144
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:38.630058
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import NoRuleMatched
    from .types import CommandNotFound
    from .types import IncorrectUsage
    from .types import Failed
    from .types import UnexpectedError
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor
    from .types import RuleExecutor

# Generated at 2022-06-18 06:38:42.501269
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_rule
    from .rules.pip import pip_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.system import system_rule
    from .rules.man import man_rule
    from .rules.cd import cd_rule
    from .rules.gem import gem_rule
    from .rules.npm import npm_rule
    from .rules.composer import composer_rule
    from .rules.docker import docker_rule
    from .rules.vagrant import vagrant_rule
    from .rules.bundle import bundle_rule
    from .rules.brew import brew_rule
    from .rules.gcloud import gcloud_rule
    from .rules.kubectl import kubectl_rule
   

# Generated at 2022-06-18 06:39:10.523988
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1


# Generated at 2022-06-18 06:39:23.914517
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Command

    class TestRule(Rule):
        def __init__(self, priority):
            self.priority = priority

        def get_corrected_commands(self, command):
            return [CorrectedCommand(
                command.script,
                'echo {}'.format(self.priority),
                priority=self.priority)]

    assert list(organize_commands([])) == []

    assert list(organize_commands([
        CorrectedCommand(Command('ls', 'ls'), 'ls', priority=1)])) == [
            CorrectedCommand(Command('ls', 'ls'), 'ls', priority=1)]


# Generated at 2022-06-18 06:39:31.062391
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    from .rules import bash, brew, git, npm, pip, python, ruby, sudo, system
    assert set(get_loaded_rules([Path(__file__).parent.joinpath('rules')])) == {
        bash.Rule(),
        brew.Rule(),
        git.Rule(),
        npm.Rule(),
        pip.Rule(),
        python.Rule(),
        ruby.Rule(),
        sudo.Rule(),
        system.Rule()}

# Generated at 2022-06-18 06:39:40.745087
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.no import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.pip_requirements import match, get_new_command
    from .rules.pip_user import match, get_new_command
    from .rules.ruby import match, get_new_command

# Generated at 2022-06-18 06:39:44.667378
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:39:54.007514
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLineInput
    from .types import CommandLineOutput
    from .types import CommandLineError
    from .types import CommandLineHistory
    from .types import CommandLineHistoryItem
    from .types import CommandLineHistoryItemInput
    from .types import CommandLineHistoryItemOutput
    from .types import CommandLineHistoryItemError
    from .types import CommandLineHistoryItemType
    from .types import CommandLineHistoryItemStatus
    from .types import CommandLineHistoryItemPid
    from .types import CommandLineHistoryItemTime
    from .types import CommandLineHistoryItemDuration
    from .types import CommandLineHistoryItemWorkingDirectory
    from .types import Command

# Generated at 2022-06-18 06:40:02.626001
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import AndRule
    from .types import OrRule
    from .types import NotRule
    from .types import AnyRule
    from .types import AllRule
    from .types import PriorityRule
    from .types import AlwaysRule
    from .types import NeverRule
    from .types import Rule

    # Test for ScriptRule
    script_rule = ScriptRule(
        script=Script(
            script='echo "test"',
            stderr='',
            stdout='test',
            code=0),
        priority=10)

# Generated at 2022-06-18 06:40:04.749183
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:14.844269
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .conf import Config
    from .conf import load_config
    from .conf import get_config_path
    from .conf import get_config_paths
    from .conf import get_config_paths_for_tests
    from .conf import get_config_paths_for_tests
    from .conf import get_config_paths_for_tests
    from .conf import get_config_paths_for_tests
    from .conf import get_config_paths_for_tests
    from .conf import get_config_paths_for_tests
    from .conf import get_config_paths_for_tests
    from .conf import get_config_paths

# Generated at 2022-06-18 06:40:21.857561
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:40:57.248052
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:57.999550
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:40:58.496773
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()

# Generated at 2022-06-18 06:41:08.573616
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.git_branch import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_remote import match, get_new_command
    from .rules.git_checkout import match, get_new_command
   

# Generated at 2022-06-18 06:41:15.106587
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from . import logs
    from . import utils
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __version__
    from . import __

# Generated at 2022-06-18 06:41:26.544322
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .types import NoRuleMatched
    from .types import CommandNotFound
    from .types import IncorrectUsage
    from .types import Failed
    from .types import UnexpectedError
    from .types import CorrectedCommand

    class TestRule(Rule):
        def __init__(self, priority, command, corrected_command):
            self.priority = priority
            self.command = command
            self.corrected_command = corrected_command

        def is_match(self, command):
            return command == self.command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.corrected_command, self.priority)]


# Generated at 2022-06-18 06:41:35.875395
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .conf import settings
    settings.no_colors = True

# Generated at 2022-06-18 06:41:42.004537
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py'), Path('/tmp/thefuck/rules/git.py')]))) == 2


# Generated at 2022-06-18 06:41:49.224088
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    from .rules import bash, brew, cd, cp, git, ls, npm, python, rails, sudo
    assert set(get_loaded_rules([Path(__file__).parent.joinpath('rules')])) == {
        bash.Rule(),
        brew.Rule(),
        cd.Rule(),
        cp.Rule(),
        git.Rule(),
        ls.Rule(),
        npm.Rule(),
        python.Rule(),
        rails.Rule(),
        sudo.Rule()}

# Generated at 2022-06-18 06:41:54.491242
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule.py')])) == [Rule.from_path(Path('/tmp/rules/rule.py'))]


# Generated at 2022-06-18 06:42:36.895698
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.pyo')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py.swo')])) == []
    assert list(get_loaded_rules([Path('/tmp/rule.py.swpx')])) == []

# Generated at 2022-06-18 06:42:44.387465
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_rule
    from .rules.pip import pip_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.system import system_rule
    from .rules.man import man_rule
    from .rules.no import no_rule
    from .rules.cd import cd_rule
    from .rules.ls import ls_rule
    from .rules.mkdir import mkdir_rule
    from .rules.mv import mv_rule
    from .rules.rm import rm_rule
    from .rules.cp import cp_rule
    from .rules.grep import grep_rule
    from .rules.find import find_rule
    from .rules.which import which_rule
    from .rules.ssh import ssh_rule

# Generated at 2022-06-18 06:42:45.774587
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()


# Generated at 2022-06-18 06:42:56.663489
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git_branch import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_checkout import match, get_new_command
    from .rules.git_add import match, get_new_command
    from .rules.git_commit import match, get_new_command
    from .rules.git_merge import match, get_new_command
    from .rules.git_pull import match, get_new_command
    from .rules.git_rebase import match, get_new_command
    from .rules.git_reset import match, get_new_command
    from .rules.git_stash import match, get_new_command
    from .rules.git_status import match, get_new_command


# Generated at 2022-06-18 06:43:03.653052
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.bower import match, get_new_command

# Generated at 2022-06-18 06:43:06.118185
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:43:16.331589
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .conf import settings
    from .system import Path
    from . import logs
    import sys
    import os
    import shutil
    import tempfile
    import unittest
    import mock

    class OrganizeCommandsTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_path = Path(self.temp_dir)
            self.old_user_dir = settings.user_dir
            settings.user_dir = self.temp_path
            self.old_path = sys.path[:]
            sys.path.append(self.temp_dir)
            self.old_log_level = logs.level

# Generated at 2022-06-18 06:43:20.509771
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:43:30.191493
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.cargo import match, get_new_command
    from .rules.composer import match, get_new_command
    from .rules.docker import match, get_new_command

# Generated at 2022-06-18 06:43:30.975439
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:44:50.140143
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
    from .types import Script
   

# Generated at 2022-06-18 06:44:52.138061
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:44:54.868339
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:44:58.263933
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')])) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:45:07.594533
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd

    command = Command('git branch', '', '', '')
    corrected_commands = (
        corrected for rule in get_rules()
        if rule.is_match(command)
        for corrected in rule.get_corrected_commands(command))

# Generated at 2022-06-18 06:45:09.448286
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:10.864935
# Unit test for function get_rules
def test_get_rules():
    assert get_rules()

# Generated at 2022-06-18 06:45:14.002210
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:16.268184
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:20.278084
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules'),
        Path(__file__).parent.joinpath('../thefuck_contrib_*')]