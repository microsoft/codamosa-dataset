

# Generated at 2022-06-18 06:35:39.201063
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:35:49.713196
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedCommand
    from .types import CorrectedScript
    from .types import CorrectedOutput
    from .types import CorrectedResponse
    from .types import CorrectedRule
    from .types import CorrectedOutput
    from .types import CorrectedResponse
    from .types import CorrectedRule
    from .types import CorrectedScript
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:35:59.569761
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.no import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.npm import match, get_new_command

# Generated at 2022-06-18 06:36:02.055570
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:36:09.962945
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import RegexRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule
    from .types import CommandRule


# Generated at 2022-06-18 06:36:22.152984
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:36:29.899816
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule1.py')])) == [Rule.from_path(Path('/tmp/rules/rule1.py'))]
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule1.py'),
                                  Path('/tmp/rules/rule2.py')])) == [Rule.from_path(Path('/tmp/rules/rule1.py')),
                                                                     Rule.from_path(Path('/tmp/rules/rule2.py'))]


# Generated at 2022-06-18 06:36:38.017443
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/rule.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule2.py')]))) == 2


# Generated at 2022-06-18 06:36:47.686684
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git_branch import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_push import match, get_new_command

# Generated at 2022-06-18 06:36:58.614702
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    assert list(organize_commands([
        CorrectedCommand('ls', 'ls', 'ls', 0),
        CorrectedCommand('ls', 'ls', 'ls', 0),
        CorrectedCommand('ls', 'ls', 'ls', 0)])) == [
            CorrectedCommand('ls', 'ls', 'ls', 0)]

    assert list(organize_commands([
        CorrectedCommand('ls', 'ls', 'ls', 0),
        CorrectedCommand('ls', 'ls', 'ls', 1),
        CorrectedCommand('ls', 'ls', 'ls', 2)])) == [
            CorrectedCommand('ls', 'ls', 'ls', 2),
            CorrectedCommand('ls', 'ls', 'ls', 1),
            CorrectedCommand('ls', 'ls', 'ls', 0)]


# Generated at 2022-06-18 06:37:16.142306
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd_parent
    from .rules import python_command
    from .rules import git_push_command
    from .rules import apt_get_command
    from .rules import apt_get_install_command
    from .rules import apt_get_update_command
    from .rules import apt_get_upgrade_command
    from .rules import apt_get_remove_command
    from .rules import apt_get_purge_command
    from .rules import apt_get_autoremove_command
    from .rules import apt_get_autoclean_command
    from .rules import apt_get_dist_upgrade_command
    from .rules import apt_get_moo_command
    from .rules import apt_get_check_command
    from .rules import apt_get_build_dep

# Generated at 2022-06-18 06:37:26.318427
# Unit test for function organize_commands
def test_organize_commands():
    from thefuck.types import CorrectedCommand
    from thefuck.rules.git import match, get_new_command
    from tests.utils import Command

    assert list(organize_commands([])) == []

    assert list(organize_commands([
        CorrectedCommand(Command('git'), 'git', 'git', 1),
        CorrectedCommand(Command('git'), 'git', 'git', 1),
        CorrectedCommand(Command('git'), 'git', 'git', 1)])) == [
        CorrectedCommand(Command('git'), 'git', 'git', 1)]


# Generated at 2022-06-18 06:37:34.446907
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedScript
    from .types import CorrectedOutput
    from .types import CorrectedResponse

    test_command = Command('ls', '', '', '', '', '', '')
    test_rule = Rule(Script('ls', 'ls'),
                     CommandOutput(Output('', '', '', '', '', '', ''),
                                   Response('')),
                     CorrectedScript('ls', 'ls'),
                     CorrectedOutput(Output('', '', '', '', '', '', ''),
                                     CorrectedResponse('')))

# Generated at 2022-06-18 06:37:36.119943
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:46.097912
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import RegexRule
    from .types import CommandRule
    from .types import Priority
    from .types import CommandResult
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLineInput
    from .types import CommandLineOutput
    from .types import CommandLineError
    from .types import CommandLineHistory
    from .types import CommandLineHistoryEntry
    from .types import CommandLineHistoryEntryInput
    from .types import CommandLineHistoryEntryOutput
    from .types import CommandLineHistoryEntryError
    from .types import CommandLineHistoryEntryTime
    from .types import CommandLineHistoryEntryCommand
    from .types import CommandLineHistoryEntryCommandInput


# Generated at 2022-06-18 06:37:54.280364
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py~')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyo')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swo')])) == []

# Generated at 2022-06-18 06:37:56.530920
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]


# Generated at 2022-06-18 06:37:59.909767
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:38:00.508103
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0


# Generated at 2022-06-18 06:38:05.686798
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2


# Generated at 2022-06-18 06:38:13.916297
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules')]))) > 0

# Generated at 2022-06-18 06:38:22.501017
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .conf import load_settings
    from .conf import reload_settings
    from .conf import clear_settings
    from .conf import get_all_settings
    from .conf import get_all_settings_names
    from .conf import get_all_settings_values
    from .conf import get_all_settings_types
    from .conf import get_all_settings_descriptions
    from .conf import get_all_settings_defaults
    from .conf import get_all_settings_choices
    from .conf import get_all_settings_env_names
    from .conf import get_all_settings_env_types
    from .conf import get_all_settings_env

# Generated at 2022-06-18 06:38:27.185425
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1


# Generated at 2022-06-18 06:38:35.800351
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_current_branch
    from .rules import python_command
    from .rules import npm_install_global
    from .rules import npm_install_save
    from .rules import npm_install_save_dev
    from .rules import npm_install_save_optional
    from .rules import npm_install_save_exact
    from .rules import npm_install_save_bundle
    from .rules import npm_install_save_peer
    from .rules import npm_install_save_prod
    from .rules import npm_install_save_only
    from .rules import npm_install_save_dev_only
    from .rules import npm_install_save_optional_only
    from .rules import npm_install_save_exact_only
    from .rules import npm_

# Generated at 2022-06-18 06:38:44.256415
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/rules/__init__.py'),
                                  Path('/rules/rule.py')])) == [Rule('rule')]
    assert list(get_loaded_rules([Path('/rules/__init__.py'),
                                  Path('/rules/rule.py'),
                                  Path('/rules/disabled.py')])) == [Rule('rule')]


# Generated at 2022-06-18 06:38:46.670179
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:49.037735
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:57.179881
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput

# Generated at 2022-06-18 06:38:58.101197
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths()

# Generated at 2022-06-18 06:39:08.777239
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.bower import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match

# Generated at 2022-06-18 06:39:21.130922
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:23.857871
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:30.371831
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/rule.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/rule.py'), Path('/tmp/rule.py')]))) == 1


# Generated at 2022-06-18 06:39:31.288855
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:39:40.925162
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.general import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.docker import match, get_new_command
    from .rules.systemctl import match

# Generated at 2022-06-18 06:39:50.302514
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.apt import match as match_apt, get_new_command as get_new_command_apt
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.brew import match as match_brew

# Generated at 2022-06-18 06:39:59.217656
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import FunctionRule
    from .types import AndRule
    from .types import OrRule
    from .types import NotRule
    from .types import AnyRule
    from .types import AllRule
    from .types import Rule
    from .types import Priority
    from .types import CorrectedCommand
    from .types import Command
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import FunctionRule
    from .types import AndRule

# Generated at 2022-06-18 06:40:00.176512
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:40:04.005537
# Unit test for function get_loaded_rules

# Generated at 2022-06-18 06:40:07.992254
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules'),
        Path(__file__).parent.joinpath('..', '..', 'thefuck_contrib_git', 'rules')]

# Generated at 2022-06-18 06:40:36.940958
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from . import conf
    from . import logs
    from . import system
    from . import types
    from . import utils
    from . import which

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.command, self.priority)]

    test_command = Command('test_command', 'test_script')
    test_rule1 = TestRule(1, 'test_command1')
    test_rule2 = TestRule(2, 'test_command2')
    test_rule3 = TestRule(3, 'test_command3')
    test

# Generated at 2022-06-18 06:40:46.225594
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:40:46.748842
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:40:48.507240
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    command = Command('ls', '', '', '', '', '', '')
    corrected_commands = get_corrected_commands(command)
    assert next(corrected_commands).script == 'ls'

# Generated at 2022-06-18 06:40:56.687195
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    command = Command('ls', 'ls')
    corrected_commands = [CorrectedCommand(command, 'ls -l', 'ls -l'),
                          CorrectedCommand(command, 'ls -la', 'ls -la'),
                          CorrectedCommand(command, 'ls -l', 'ls -l'),
                          CorrectedCommand(command, 'ls -la', 'ls -la')]
    assert list(organize_commands(corrected_commands)) == [CorrectedCommand(command, 'ls -l', 'ls -l'),
                                                           CorrectedCommand(command, 'ls -la', 'ls -la')]

# Generated at 2022-06-18 06:41:01.224014
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    commands = [CorrectedCommand('ls', 'ls', 1),
                CorrectedCommand('ls', 'ls', 2),
                CorrectedCommand('ls', 'ls', 3),
                CorrectedCommand('ls', 'ls', 4)]
    assert list(organize_commands(commands)) == [commands[2], commands[3]]

# Generated at 2022-06-18 06:41:04.436115
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:41:12.665444
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:41:13.937859
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:41:14.771808
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:42:01.627277
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    import re
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    import unittest.mock
    import thefuck.rules.git

    class TestRule(Rule):
        def __init__(self, priority, command, corrected_command):
            self.priority = priority
            self.command = command
            self.corrected_command = corrected_command
            self.is_enabled = True
            self.is_match = lambda command: True
            self.get_new_command = lambda command: self.corrected_command

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 06:42:10.772087
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.brew import match as match_brew, get_new_command as get_new_command_brew
    from .rules.apt import match as match_apt

# Generated at 2022-06-18 06:42:20.219167
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import git_push
    from .rules.pip import pip_install
    from .rules.python import python
    from .rules.sudo import sudo
    from .rules.system import system
    from .rules.cd import cd
    from .rules.man import man
    from .rules.npm import npm
    from .rules.vagrant import vagrant
    from .rules.git_branch import git_branch
    from .rules.git_checkout import git_checkout
    from .rules.git_commit import git_commit
    from .rules.git_merge import git_merge
    from .rules.git_pull import git_pull
    from .rules.git_rebase import git_rebase
    from .rules.git_remote import git_remote

# Generated at 2022-06-18 06:42:22.419942
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:42:31.356807
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.docker import match, get_new_command
    from .rules.system import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match

# Generated at 2022-06-18 06:42:38.788597
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.docker import match, get_new_command


# Generated at 2022-06-18 06:42:47.251180
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyo')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py~')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swo')])) == []

# Generated at 2022-06-18 06:42:50.573589
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:42:57.709948
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:43:04.414978
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match as match_python, get_new_command as get_new_command_python
    from .rules.sudo import match as match_sudo, get_new_command as get_new_command_sudo
    from .rules.man import match as match_man, get_new_command as get_new_command_man
    from .rules.cd import match as match_cd, get_new_command as get_new_command_cd
    from .rules.ls import match as match_ls, get_new_command as get_new_command_ls
    from .rules.pip import match as match_pip, get_new_command as get_new_command_pip
    from .rules.apt import match as match_apt

# Generated at 2022-06-18 06:44:56.108787
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    assert list(organize_commands([
        CorrectedCommand('ls', 'ls', 'ls', 1),
        CorrectedCommand('ls', 'ls', 'ls', 2),
        CorrectedCommand('ls', 'ls', 'ls', 3)])) == [
            CorrectedCommand('ls', 'ls', 'ls', 1),
            CorrectedCommand('ls', 'ls', 'ls', 3)]

# Generated at 2022-06-18 06:45:04.456251
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.any_command import match, get_new_command
    from .rules.no_command import match, get_new_command
    from .rules.rm import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_add import match, get_new_command
    from .rules.git_commit import match, get_new_command
    from .rules.git_checkout import match, get_new_command

# Generated at 2022-06-18 06:45:11.989262
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/__init__.py'),
                             Path('/tmp/foo.py')]) == []
    assert get_loaded_rules([Path('/tmp/__init__.py'),
                             Path('/tmp/foo.py'),
                             Path('/tmp/bar.py')]) == []
    assert get_loaded_rules([Path('/tmp/__init__.py'),
                             Path('/tmp/foo.py'),
                             Path('/tmp/bar.py'),
                             Path('/tmp/baz.py')]) == []

# Generated at 2022-06-18 06:45:16.124541
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == [Rule.from_path(Path('/tmp/test.py'))]


# Generated at 2022-06-18 06:45:19.201654
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:21.315699
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:30.287678
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command