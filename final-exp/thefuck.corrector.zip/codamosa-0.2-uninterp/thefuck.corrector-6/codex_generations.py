

# Generated at 2022-06-18 06:35:48.032804
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import cd
    from .rules import ls
    from .rules import python
    from .rules import git
    from .rules import pip
    from .rules import npm
    from .rules import apt_get
    from .rules import brew
    from .rules import pacman
    from .rules import emerge
    from .rules import dnf
    from .rules import yum
    from .rules import zypper
    from .rules import aptitude
    from .rules import apm
    from .rules import gem
    from .rules import cabal
    from .rules import stack
    from .rules import cargo
    from .rules import rustup
    from .rules import go
    from .rules import pip3
    from .rules import pip2
    from .rules import pip_install
    from .rules import pip_uninstall

# Generated at 2022-06-18 06:35:52.807303
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2


# Generated at 2022-06-18 06:36:02.562659
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import Scripts
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings
    from .types import Settings


# Generated at 2022-06-18 06:36:10.191293
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command

# Generated at 2022-06-18 06:36:22.285427
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .conf import settings
    settings.no_colors = True
    settings.wait_command = 0
    settings.priority = {}
    settings.exclude_rules = []
    settings.require_confirmation = False
    settings.wait_slow_command = 0
    settings.slow_commands = []
    settings.alias = {}
    settings.debug = False
    settings.history_limit = 0
    settings.env = {}
    settings.rules = []
    settings.exclude_rules = []
    settings.no_colors = True
    settings.wait_command = 0
    settings.priority = {}
    settings.require_confirmation = False
    settings.wait_slow_command = 0
    settings.slow_commands = []
    settings.alias = {}

# Generated at 2022-06-18 06:36:29.987437
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.pip import match as pip_match, get_new_command as pip_get_new_command
    from .rules.python import match as python_match, get_new_command as python_get_new_command
    from .rules.sudo import match as sudo_match, get_new_command as sudo_get_new_command
    from .rules.system import match as system_match, get_new_command as system_get_new_command

    # Test for git rule
    git_rule = Rule(match, get_new_command, 'git', True)
    git_command = Command('git', '', '', '', '', '', '')
    git_corrected_commands = git_rule.get_corrected_

# Generated at 2022-06-18 06:36:41.411386
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_new_command(self, command):
            return self.command

    class TestScript(Script):
        def __init__(self, output):
            self.output = output

        def __call__(self, *args, **kwargs):
            return self.output

    command = Command('ls', '', '')
    output = Output('', '')
    command_output = CommandOutput(command, output)
    script = TestScript(command_output)


# Generated at 2022-06-18 06:36:49.740897
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Settings
    from .conf import settings
    from .conf import load_settings
    from .conf import reload_settings
    from .conf import clear_settings
    from .conf import get_settings
    from .conf import get_all_settings
    from .conf import get_all_settings_names
    from .conf import get_all_settings_values
    from .conf import get_all_settings_types
    from .conf import get_all_settings_descriptions
    from .conf import get_all_settings_defaults
    from .conf import get_all_settings_choices
    from .conf import get_all_settings_env_names
    from .conf import get_all_settings_env_prefixes

# Generated at 2022-06-18 06:36:53.022963
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')
    ]

# Generated at 2022-06-18 06:36:58.130413
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.pyc')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py~')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swp')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swo')])) == []
    assert list(get_loaded_rules([Path('/tmp/test.py.swpx')])) == []

# Generated at 2022-06-18 06:37:14.569126
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:37:25.590400
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Command

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.command, self.priority)]


# Generated at 2022-06-18 06:37:27.486148
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:37:28.398477
# Unit test for function get_rules
def test_get_rules():
    assert len(list(get_rules())) > 0

# Generated at 2022-06-18 06:37:33.930663
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:37:43.150963
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []

# Generated at 2022-06-18 06:37:44.039568
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:37:52.631609
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.misc import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command

# Generated at 2022-06-18 06:37:54.587506
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:38:03.100824
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command

    command = Command('ls', '', '')

# Generated at 2022-06-18 06:38:21.879928
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.nvm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command

# Generated at 2022-06-18 06:38:32.225612
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandLine
    from .types import CommandLineHistory
    from .types import CommandHistory
    from .types import CommandOutputHistory
    from .types import ScriptHistory
    from .types import ScriptOutputHistory
    from .types import ScriptOutput
    from .types import ScriptLine
    from .types import ScriptLineHistory
    from .types import ScriptLineOutputHistory
    from .types import ScriptLineOutput
    from .types import ScriptLineOutputHistory
    from .types import ScriptLineOutput
    from .types import ScriptLineOutputHistory
    from .types import ScriptLineOutput
    from .types import ScriptLineOutputHistory
    from .types import ScriptLineOutput
    from .types import ScriptLineOutputHistory

# Generated at 2022-06-18 06:38:42.724832
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import LazyRule
    from .types import LazyRegexRule
    from .types import LazyStringRule
    from .types import LazyScriptRule
    from .types import LazyCommandRule
    from .types import LazyRegexRule
    from .types import LazyStringRule
    from .types import LazyScriptRule
    from .types import LazyCommandRule
    from .types import LazyRegexRule
    from .types import LazyStringRule
    from .types import LazyScriptRule
    from .types import LazyCommandRule

# Generated at 2022-06-18 06:38:49.879268
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py')]))) == 1
    assert len(list(get_loaded_rules([Path(__file__).parent.joinpath('rules/git.py'), Path(__file__).parent.joinpath('rules/__init__.py')]))) == 1


# Generated at 2022-06-18 06:38:57.806304
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z/__init__.py')])) == []

# Generated at 2022-06-18 06:38:58.912471
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:39:09.656937
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand

# Generated at 2022-06-18 06:39:15.721377
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/thefuck/rules/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/thefuck/rules/bash.py')]) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]
    assert get_loaded_rules([Path('/tmp/thefuck/rules/bash.py'), Path('/tmp/thefuck/rules/__init__.py')]) == [Rule.from_path(Path('/tmp/thefuck/rules/bash.py'))]


# Generated at 2022-06-18 06:39:26.369557
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules import git_push_current_branch
    from .rules import git_push_current_branch_with_set_upstream
    from .rules import git_push_current_branch_with_set_upstream_to_origin
    from .rules import git_push_current_branch_with_set_upstream_to_origin_master
    from .rules import git_push_current_branch_with_set_upstream_to_origin_master_with_force
    from .rules import git_push_current_branch_with_set_upstream_to_origin_master_with_force_and_delete
    from .rules import git_push_current_branch_with_set_upstream_to_origin_master_with_force_and_delete_and_verbose

# Generated at 2022-06-18 06:39:27.877972
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:39:53.017330
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:39:56.629896
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()
    assert settings.user_dir.joinpath('rules') in get_rules_import_paths()
    assert Path(__file__).parent.joinpath('rules') in get_rules_import_paths()

# Generated at 2022-06-18 06:40:00.175841
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert get_loaded_rules([Path('/tmp/__init__.py')]) == []
    assert get_loaded_rules([Path('/tmp/__init__.py'), Path('/tmp/rule.py')]) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:40:04.350175
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:40:06.411259
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:40:16.541507
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptSuffix
    from .types import ScriptPrefix
    from .types import ScriptSuffixAndPrefix
    from .types import ScriptSuffixOrPrefix
    from .types import ScriptSuffixAndPrefixOrSuffix
    from .types import ScriptSuffixOrPrefixOrSuffix
    from .types import ScriptSuffixAndPrefixOrPrefix
    from .types import ScriptSuffixOrPrefixOrPrefix
    from .types import ScriptSuffixAndPrefixOrPrefixOrSuffix
    from .types import ScriptSuffixOrPrefixOrPrefixOrSuffix
    from .types import ScriptSuffixAndPrefixOrPrefixOrSuff

# Generated at 2022-06-18 06:40:26.277983
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.git_push import match, get_new_command
    from .rules.git_add import match, get_new_command
    from .rules.git_commit import match, get_new_command
    from .rules.git_checkout import match, get_new_command
   

# Generated at 2022-06-18 06:40:33.440223
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:40:42.807872
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    command = Command('ls', 'ls: command not found')
    corrected_commands = get_corrected_commands(command)
    assert next(corrected_commands).script == 'ls'
    assert next(corrected_commands).script == 'ls --color=auto'
    assert next(corrected_commands).script == 'ls --color=always'
    assert next(corrected_commands).script == 'ls --color=never'
    assert next(corrected_commands).script == 'ls --color=tty'
    assert next(corrected_commands).script == 'ls --color=yes'
    assert next(corrected_commands).script == 'ls --color=no'
    assert next(corrected_commands).script == 'ls --color=none'

# Generated at 2022-06-18 06:40:46.935252
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert len(list(get_loaded_rules([Path('/tmp/__init__.py')]))) == 0
    assert len(list(get_loaded_rules([Path('/tmp/test.py')]))) == 1
    assert len(list(get_loaded_rules([Path('/tmp/test.py'), Path('/tmp/test2.py')]))) == 2


# Generated at 2022-06-18 06:41:39.300505
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
    from .types import CommandOutput
   

# Generated at 2022-06-18 06:41:44.903369
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/rules/__init__.py'),
                                  Path('/tmp/rules/rule.py')])) == [Rule.from_path(Path('/tmp/rules/rule.py'))]


# Generated at 2022-06-18 06:41:55.999909
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []

# Generated at 2022-06-18 06:42:00.602600
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]


# Generated at 2022-06-18 06:42:10.231150
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import ScriptRule
    from .types import CommandRule
    from .types import RegexRule
    from .types import StringRule
    from .types import AlwaysRule
    from .types import AndRule
    from .types import OrRule
    from .types import NotRule
    from .types import AnyRule
    from .types import AllRule
    from .types import NoRule
    from .types import Rule

    class TestRule(Rule):
        def __init__(self, priority, command):
            self.priority = priority
            self.command = command

        def get_corrected_commands(self, command):
            return [CorrectedCommand(self.command, self.priority)]


# Generated at 2022-06-18 06:42:11.095686
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0

# Generated at 2022-06-18 06:42:20.549145
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command

# Generated at 2022-06-18 06:42:23.327991
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules'), Path(sys.path[0]).joinpath('thefuck_contrib_*')]

# Generated at 2022-06-18 06:42:26.093825
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules'), Path(sys.path[0]).joinpath('thefuck_contrib_git')]

# Generated at 2022-06-18 06:42:28.050148
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:44:27.495583
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert list(get_rules_import_paths()) == [
        Path(__file__).parent.joinpath('rules'),
        settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:44:34.213752
# Unit test for function get_loaded_rules
def test_get_loaded_rules():
    assert list(get_loaded_rules([Path('/tmp/__init__.py')])) == []
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py')])) == [Rule.from_path(Path('/tmp/rule.py'))]
    assert list(get_loaded_rules([Path('/tmp/__init__.py'),
                                  Path('/tmp/rule.py'),
                                  Path('/tmp/rule2.py')])) == [Rule.from_path(Path('/tmp/rule.py')), Rule.from_path(Path('/tmp/rule2.py'))]


# Generated at 2022-06-18 06:44:35.929096
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:44:36.925414
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) == 1


# Generated at 2022-06-18 06:44:45.804995
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.sudo import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt_get import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.yarn import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.vagrant import match, get_new_command

# Generated at 2022-06-18 06:44:54.729146
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .conf import settings
    from .conf import load_settings
    from .conf import get_settings_path
    from .conf import get_settings_dir
    from .conf import get_user_settings_path
    from .conf import get_user_settings_dir
    from .conf import get_user_settings
    from .conf import get_user_settings_path
    from .conf import get_user_settings_dir
    from .conf import get_user_settings
    from .conf import get_user_settings_path
    from .conf import get_user_settings_dir
    from .conf import get_user_settings
    from .conf import get_user_settings_path
    from .conf import get_user_settings_dir
    from .conf import get_user

# Generated at 2022-06-18 06:45:02.790068
# Unit test for function get_corrected_commands
def test_get_corrected_commands():
    from .types import Command
    from .types import CorrectedCommand
    from .types import Rule
    from .types import Script
    from .types import ScriptSuffix
    from .types import ScriptPrefix
    from .types import ScriptSuffixAndPrefix
    from .types import ScriptSuffixOrPrefix
    from .types import ScriptSuffixAndPrefixOrSuffix
    from .types import ScriptSuffixOrPrefixOrSuffix
    from .types import ScriptSuffixAndPrefixOrPrefix
    from .types import ScriptSuffixOrPrefixOrPrefix
    from .types import ScriptSuffixAndPrefixOrPrefixOrSuffix
    from .types import ScriptSuffixOrPrefixOrPrefixOrSuffix
    from .types import ScriptSuffixAndPrefixOrPrefixOrSuff

# Generated at 2022-06-18 06:45:11.133734
# Unit test for function organize_commands
def test_organize_commands():
    from .types import CorrectedCommand
    from .types import Command
    from .types import Rule
    from .types import Script
    from .types import CommandOutput
    from .types import Output
    from .types import Response
    from .types import MatchedRule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule
    from .types import Rule

# Generated at 2022-06-18 06:45:12.303486
# Unit test for function get_rules_import_paths
def test_get_rules_import_paths():
    assert get_rules_import_paths() == [Path(__file__).parent.joinpath('rules'), settings.user_dir.joinpath('rules')]

# Generated at 2022-06-18 06:45:13.502839
# Unit test for function get_rules
def test_get_rules():
    assert len(get_rules()) > 0