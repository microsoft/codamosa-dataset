

# Generated at 2022-06-23 06:24:06.562496
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    _play_ = Play()
    assert isinstance(_play_, Play)
    # test with data as a dict
    ds = {"foo": "bar"}
    _play_._play_ds = ds
    assert _play_._play_ds == {"foo": "bar"}
    # test with data as a sequence
    ds = [{"foo": "bar"}, {"bar": "foo"}]
    _play_._play_ds = ds
    assert _play_._play_ds == [{"foo": "bar"}, {"bar": "foo"}]
    # test with data as None
    ds = None
    _play_._play_ds = ds
    assert _play_._play_ds == None

# Generated at 2022-06-23 06:24:20.804383
# Unit test for constructor of class Play
def test_Play():
    """
    Construct a play with pre/post tasks.
    """

# Generated at 2022-06-23 06:24:26.711125
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None 
    play.hosts = 'localhost'
    assert play.get_name() == 'localhost'
    #play.name = None
    play.hosts = None
    assert play.get_name() == ''

# Generated at 2022-06-23 06:24:37.037428
# Unit test for method copy of class Play
def test_Play_copy():
    a = Play()
    a.ROLE_CACHE = {}
    a._included_conditional = {}
    a._included_path = ""
    a._action_groups = {}
    a._group_actions = {}
    b = a.copy()
    assert len(b.ROLE_CACHE) == 0
    assert len(b._included_conditional) == 0
    assert b._included_path == ""
    assert len(b._action_groups) == 0
    assert len(b._group_actions) == 0
    assert type(b) == Play


# Generated at 2022-06-23 06:24:40.191403
# Unit test for method get_roles of class Play
def test_Play_get_roles():

    my_play = Play()
    my_play_roles = my_play.get_roles()

    assert [] == my_play_roles


# Generated at 2022-06-23 06:24:42.485000
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass


# Generated at 2022-06-23 06:24:51.372756
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    p._ds = {'hosts': 'bla', 'user': 'bla'}
    p.preprocess_data(p._ds)
    assert p.get_ds() == {'hosts': 'bla', 'remote_user': 'bla', 'vars': {}}
    p._ds = ['hosts', 'user']
    p.preprocess_data(p._ds)
    assert p.get_ds() == ['hosts', 'remote_user']
    p._ds = {'hosts': 'bla', 'user': 'bla', 'tasks': [{'name': 'test'}]}
    p.preprocess_data(p._ds)

# Generated at 2022-06-23 06:25:05.656377
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    '''
    Test get_handlers() method of class Play
    '''

# Generated at 2022-06-23 06:25:08.567961
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    play.roles = []
    assert play.get_roles() == []
    play.roles = ['r1']
    assert play.get_roles() == ['r1']


# Generated at 2022-06-23 06:25:09.775743
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.serialize()


# Generated at 2022-06-23 06:25:12.590314
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()

    assert play._ds is None
    assert play.vars == {}


# Generated at 2022-06-23 06:25:16.553091
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    return p.__repr__()



# Generated at 2022-06-23 06:25:24.554156
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    role_include_1 = RoleInclude()
    role_include_1.name="role_1"
    handler_1 = Handler()
    handler_1.name="handler_1"
    handler_1.block=[]
    handler_1.notify=["handler_1"]

    role_include_2 = RoleInclude()
    role_include_2.name="role_2"
    handler_2 = Handler()
    handler_2.name="handler_2"
    handler_2.block=[]
    handler_2.notify=["handler_2"]

    play = Play()

    play.roles.append(role_include_1)
    play.roles.append(role_include_2)

    play.roles[0]._compiled_handlers = []

# Generated at 2022-06-23 06:25:35.208481
# Unit test for constructor of class Play
def test_Play():

    play1 = Play()
    play2 = Play()

    assert play1.name == ''
    assert play1.hosts == ''
    assert play1.remote_user == ''
    assert play1.connection == ''
    assert play1.task_limit == 0
    assert play1.timeout == 10
    assert play1.max_retries == 3
    assert play1.become == False
    assert play1.become_method == ''
    assert play1.become_user == ''
    assert play1.gather_facts == 'yes'
    assert play1.delegate_to == ''
    assert play1.become_flags == ''
    assert play1.tags == []
    assert play1.skip_tags == []
    assert play1.active_user == ''
    assert play1.active_password == ''


# Generated at 2022-06-23 06:25:43.267725
# Unit test for method load of class Play
def test_Play_load():
    from ansible.playbook.play import Play
    data = [{"name": "debug", "debug": "msg={{SERVER_ROLE}}"}]
    result = Play.load(data=data,vars ={"SERVER_ROLE": "etcd"})
    assert result.get_tasks() == [{'action': 'debug', 'args': {'msg': '{{SERVER_ROLE}}'}, 'register': 'debug_result', 'name': 'debug'}]


# Generated at 2022-06-23 06:25:54.812402
# Unit test for method load of class Play
def test_Play_load():
    from ansible import context
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)

    # input data
    data = {}
    data_list = [{}]
    data_dict = {}

    # function under test
    play = Play()
    play.load_data(data)
    play.load_data(data, variable_manager)
    play.load_data(data, variable_manager, loader)
    play.load(data_list)
    play.load(data_list, variable_manager)
    play.load(data_list, variable_manager, loader)

# Generated at 2022-06-23 06:25:57.485311
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    test_object = Play()
    test_object.get_name = MagicMock(return_value='fake_name')
    assert test_object.__repr__() == 'fake_name'


# Generated at 2022-06-23 06:26:01.569987
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = [1, 2]
    assert p.get_handlers() == [1, 2]
    assert p.get_handlers() is not p.handlers


# Generated at 2022-06-23 06:26:14.557649
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-23 06:26:16.744355
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # init
    play_obj = Play()
    # invoke
    play_obj.preprocess_data(play_obj)

# Generated at 2022-06-23 06:26:23.046811
# Unit test for method copy of class Play
def test_Play_copy():
    '''
    Unit test for method copy of class Play
    '''
    pass

    # class_obj = Play()
    # new_me = class_obj.copy()


    # # Check for class
    # if new_me.__class__ !=  Play:
    #     raise Exception("Method `copy` does not preserve class of object")

    # # Check for equal
    # if new_me != class_obj:
    #     raise Exception("Method `copy` does not preserve content of object")



# Generated at 2022-06-23 06:26:24.057324
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    assert callable(play.compile)

# Generated at 2022-06-23 06:26:30.171060
# Unit test for method copy of class Play
def test_Play_copy():
    data = {'name': 'test_play',
            'hosts': 'all'}
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()
    play.load(data, variable_manager, loader)

    assert play.copy() == play
    assert play.copy() is not play

# Generated at 2022-06-23 06:26:34.425940
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['tests/unit/get_vars_files/vars_files.yaml']
    assert play.get_vars_files() == ['tests/unit/get_vars_files/vars_files.yaml']



# Generated at 2022-06-23 06:26:44.287227
# Unit test for method serialize of class Play

# Generated at 2022-06-23 06:26:46.423003
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    new_play = play.copy()
    assert new_play._included_conditional == None
    assert new_play._included_path == None


# Generated at 2022-06-23 06:26:49.688330
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    play1 = Play()

# Generated at 2022-06-23 06:26:54.289679
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    new_me = play.copy()

    assert new_me.ROLE_CACHE == {}
    assert new_me._included_conditional == None
    assert new_me._included_path == None
    assert new_me._action_groups == {}
    assert new_me._group_actions == {}

# Generated at 2022-06-23 06:27:04.960732
# Unit test for method copy of class Play
def test_Play_copy():

    def init_roles():
        roles = []
        for i in range(10):
            role = Role()
            role.ROLE_CACHE = {'a': 'b'}
            roles.append(role)
        return roles

    play = Play()
    play.ROLE_CACHE = {'a': 'b'}
    play._included_conditional = True
    play._included_path = "included_path"
    play._action_groups = {'group_name': 'group_actions'}
    play._group_actions = {'group_name': 'group_actions'}
    play._roles = init_roles()

    # test object copy
    new_me = play.copy()
    assert play._roles is not new_me._roles

# Generated at 2022-06-23 06:27:16.495818
# Unit test for method copy of class Play
def test_Play_copy():
  from ansiblelint.rules.AlwaysRun import AlwaysRun
  from ansiblelint.tests import TestPlay,TestPlay2
  p = Play()
  p._included_conditional = None
  p._included_path = None
  p._action_groups = {}
  p._group_actions = {}
  p.ROLE_CACHE = {}
  #data = TestPlay.test_data()
  #new_me = p.load_data(data)
  new_me = p.copy()
  assert new_me._included_conditional == 0, 'Test copy of class Play fails'
  assert new_me._included_path == None, 'Test copy of class Play fails'
  assert new_me._action_groups == {}, 'Test copy of class Play fails'
  assert new_me._group_

# Generated at 2022-06-23 06:27:28.410972
# Unit test for method load of class Play
def test_Play_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-23 06:27:28.985300
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-23 06:27:29.956765
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    pass


# Generated at 2022-06-23 06:27:42.046298
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play._ds = {'a': 1}
    play._handlers = 'a_handlers'
    play._included_path = 'a_included_path'
    play._included_conditional = 'a_included_conditional'
    play._removed_hosts = ['a_removed_hosts']
    play._roles = ['a_roles']
    play._pre_tasks = ['a_pre_tasks']
    play._post_tasks = ['a_post_tasks']
    play._tasks = ['a_tasks']
    play.ROLE_CACHE = {'a': 2}
    play._action_groups = {'a': 3}
    play._group_actions = {'a': 4}

# Generated at 2022-06-23 06:27:53.220707
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # Create Play object
    play_ds = dict(
        name="Ansible Play 1",
        hosts='all',
        connection='local',
        gather_facts='no'
    )
    variable_manager = VariableManager()
    variable_manager.set_host_variable({'test_host': {}}, 'test_host')
    variable_manager.set_host_variable({'test_host': {'ansible_connection': 'local'}}, 'test_host')

# Generated at 2022-06-23 06:27:54.589463
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass


# Generated at 2022-06-23 06:28:02.223067
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = 'foo'
    assert play.get_vars_files() == ['foo']
    play.vars_files = []
    assert play.get_vars_files() == []
    play.vars_files = ['foo']
    assert play.get_vars_files() == ['foo']
    play.vars_files = None
    assert play.get_vars_files() == []



# Generated at 2022-06-23 06:28:16.401060
# Unit test for constructor of class Play
def test_Play():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    the_play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'host1',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    ), variable_manager=variable_manager, loader=loader)

    # the test should match the

# Generated at 2022-06-23 06:28:19.511858
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data(ds=None)

# Generated at 2022-06-23 06:28:30.818173
# Unit test for method copy of class Play
def test_Play_copy():
    # Set up the object to be copied
    play = Play()
    r = Role()
    r.name = 'role_name'
    r.default_vars = {'a': 1, 'b': 2}
    r.dep_attrs = ['name', 'default_vars']
    play.roles = [r]
    play._ds = {'connection': 'network_cli'}
    play.vars = {'f': 1}
    play.get_vars_files()
    play.get_roles()
    play.get_tasks()
    play.serialize()
    play.deserialize(play._ds)
    play.ROLE_CACHE = {'role_key': 'role_value'}
    play._included_conditional = {}
    play._included_path

# Generated at 2022-06-23 06:28:35.108670
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_obj = Play()
    test_obj.deserialize(None)
    assert test_obj._included_path == None
    assert test_obj._action_groups == {}
    assert test_obj._group_actions == {}



# Generated at 2022-06-23 06:28:36.774048
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    assert play.get_roles() == []


# Generated at 2022-06-23 06:28:40.845860
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    # Check the type of return
    assert isinstance(play.get_roles(), list)
    # Check that the list is actually empty
    assert play.get_roles() == []

# Generated at 2022-06-23 06:28:43.678634
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    p.ROLE_CACHE = {}
    p._load_roles([], [{'foo': 'bar'}])
    assert p.get_roles() == p.roles


# Generated at 2022-06-23 06:28:53.369689
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    play.ROLE_CACHE={'1':'1'}
    play._included_path='2'
    play._action_groups={'3':'3'}
    play._group_actions={'4':'4'}
    new_play = play.copy()
    assert play.ROLE_CACHE==new_play.ROLE_CACHE
    assert play._included_path==new_play._included_path
    assert play._action_groups==new_play._action_groups
    assert play._group_actions==new_play._group_actions

# Generated at 2022-06-23 06:28:55.238928
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == list()
test_Play_compile_roles_handlers()

# Generated at 2022-06-23 06:28:58.340425
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
  ds=dict(a=1,b=2,c=3)
  p = Play()
  assert p.preprocess_data(ds) == ds

# Generated at 2022-06-23 06:28:59.076280
# Unit test for method get_vars of class Play
def test_Play_get_vars():
	pass

# Generated at 2022-06-23 06:29:00.788631
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
  play = Play()
  ds = dict(user='user_value')
  assert play.preprocess_data(ds) == dict(remote_user='user_value')


# Generated at 2022-06-23 06:29:06.415333
# Unit test for method compile of class Play
def test_Play_compile():
    # import any class and/or function that you need to build your test case
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Don't forget to add your test case to the list in the main function
    # below this test case.
    # Create an instance of your class to use for testing
    p = Play()

    # Test for method compile of class Play.
    #
    # This test case is simply here to show you how to build a unit test
    # for a method. When you add a new test case, use this one as
    # a template, and make sure the test is run in the list of test cases
    # in the main function below this test case.

# Generated at 2022-06-23 06:29:15.221618
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    def _create_role(name, tasks, handlers):
        role = {
            'name': name,
            'tasks': tasks,
            'handlers': handlers,
        }
        return role

    def _create_task(name, meta=None):
        task = {
            'name': name,
        }
        if meta:
            task['meta'] = meta
        return task

    def _create_handler(name):
        return {'name': name}

    task1 = _create_task('task1')
    task2 = _create_task('task2', 'flush_handlers')
    task3 = _create_task('task3')
    task4 = _create_task('task4', 'flush_handlers')
    task5 = _create_task('task5')
    task6 = _create_task

# Generated at 2022-06-23 06:29:27.486159
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # create a play object
    p = Play()

    # create a variable_manager object
    variable_manager = VariableManager()

    # create a loader object
    loader = DataLoader()

    # create a inventory object
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost,')

    # create a variable manager object
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a task queue manager object
    tqm = None

    # create a play context object
    play_context = PlayContext(play=p, variable_manager=variable_manager, loader=loader)

    # create a ansible options object

# Generated at 2022-06-23 06:29:28.463862
# Unit test for method compile of class Play
def test_Play_compile():
    depr

# Generated at 2022-06-23 06:29:35.241556
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class MockPlay(Play):
        def __init__(self, tasks):
            self._tasks = tasks
            self._roles = []

    play = MockPlay([1, 2, 3])
    result = play.get_tasks()
    assert 3 == len(result)
    assert 1 == result[0]
    assert 2 == result[1]
    assert 3 == result[2]

    play = MockPlay(['a', 'b', 'c'])
    result = play.get_tasks()
    assert 3 == len(result)
    assert 'a' == result[0]
    assert 'b' == result[1]
    assert 'c' == result[2]

    class MockBlock(object):
        def __init__(self, block, rescue, always):
            self.block = block
            self.res

# Generated at 2022-06-23 06:29:36.636354
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # test default case
    Play().get_handlers() == []


# Generated at 2022-06-23 06:29:37.160283
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass

# Generated at 2022-06-23 06:29:41.740377
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    [tasks]
    - name: test task
    '''
    play = load_from_file('./from_file/basic')[0]
    assert play.get_tasks()[0].name == 'test task'


# Generated at 2022-06-23 06:29:56.979121
# Unit test for method copy of class Play
def test_Play_copy():
    '''
    Test Play.copy() method
    '''
    mock_play = Play()
    play = Play()
    play.ROLE_CACHE = mock_play.ROLE_CACHE
    play._included_conditional = mock_play._included_conditional
    play._included_path = mock_play._included_path
    play._action_groups = mock_play._action_groups
    play._group_actions = mock_play._group_actions
    result = play.copy()
    assert result.ROLE_CACHE == play.ROLE_CACHE
    assert result._included_conditional == play._included_conditional
    assert result._included_path == play._included_path
    assert result._action_groups == play._action_groups
    assert result._group_

# Generated at 2022-06-23 06:30:03.874755
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    '''TestCase:deserialize'''

    #Testing Play class by using it to load an existing play
    data = """
- hosts: test
  tasks:
  - name: test task
    debug:
      msg: "Hello world"
"""

    #Convert the data string to a data structure
    play_ds = yaml.safe_load(data)

    #Create an instance of Play
    play = Play.load(play_ds)

    #Serialize the play object and then Deserialize it
    #The resulting object should be the same as the original object
    data = play.serialize()
    new_play = Play()
    new_play.deserialize(data)

    assert play.hosts == new_play.hosts
    assert play.name == new_play.name
    assert play.vars == new

# Generated at 2022-06-23 06:30:10.389653
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    fake_play_handlers = ["handlers_1", "handlers_2", "handlers_3"]

    # Mocking the class Play
    dummy_Play = type('Play', (), {"handlers": fake_play_handlers})

    # Call the object and expect to get []
    play_instance = dummy_Play()
    assert play_instance.get_handlers() == fake_play_handlers

# Generated at 2022-06-23 06:30:13.073702
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    p.preprocess_data([])

# Generated at 2022-06-23 06:30:16.197347
# Unit test for method load of class Play
def test_Play_load():
    play = Play.load(dict(name="test play"), variable_manager=None, loader=None)
    assert play.name == "test play"


# Generated at 2022-06-23 06:30:21.107181
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    vars = {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}
    p = Play()
    p.vars = vars
    vars['var1'] = 'new_value1'
    assert p.get_vars()['var1'] == 'value1'


# Generated at 2022-06-23 06:30:21.800433
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data({})


# Generated at 2022-06-23 06:30:25.671945
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    name = 'setup'
    hosts = ['host1', 'host2']
    p = Play(name, hosts)
    assert p.__repr__() == name


# Generated at 2022-06-23 06:30:34.579692
# Unit test for method copy of class Play
def test_Play_copy():
    # given:
    # test Play object
    play = Play()
    play.ROLE_CACHE = {}
    play._included_conditional = None
    play._included_path = None
    play._action_groups = {}
    play._group_actions = {}
    # when:
    # copying the Play object
    new_me = play.copy()
    # then:
    # all attributes are the same
    assert play.ROLE_CACHE == new_me.ROLE_CACHE
    assert play._included_conditional == new_me._included_conditional
    assert play._included_path == new_me._included_path
    assert play._action_groups == new_me._action_groups
    assert play._group_actions == new_me._group_actions

# Generated at 2022-06-23 06:30:36.008143
# Unit test for method load of class Play
def test_Play_load():
    pass




# Generated at 2022-06-23 06:30:41.653201
# Unit test for method load of class Play
def test_Play_load():
    _Loader = namedtuple('Loader', ['path_dwim'])
    _loader = _Loader(lambda path: path)
    _VariableManager = namedtuple('VariableManager', ['get_vars', 'get_vars_by_path'])
    _variable_manager = _VariableManager(lambda add_undefined: dict(), lambda x, y, z: dict())
    play_ds = dict(
        name='test play',
        hosts=['all'],
        gather_facts='no',
        roles=['test_role']
    )
    play = Play.load(play_ds, _variable_manager, _loader)
    assert play.get_name() == 'test play'
    for attr in play._play_hosts:
        assert attr is None or attr == 'all'
    assert play.g

# Generated at 2022-06-23 06:30:44.255602
# Unit test for method compile of class Play
def test_Play_compile():
    myplay = Play()

# Generated at 2022-06-23 06:30:57.183115
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    unit test for Play.compile_roles_handlers
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible import context
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_result import AggregateResult
    from ansible.executor.task_queue_manager import TaskQueueManager

    p = Play()
    # block 1
    block1 = Block()
    # handler1
    handler1 = Task()
    handler1.action = 'meta'
    handler1.args = dict()
    handler1.args['_raw_params'] = 'notify1'
    handler1.action = 'debug'
    handler1.set_loader(data_loader=DataLoader())
   

# Generated at 2022-06-23 06:31:00.774848
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    """
    Test that the ``__repr__`` method of the :class:`Play` class
    returns the string of the ``get_name`` method.
    """

    p = Play()
    assert p.__repr__() == p.get_name()


# Generated at 2022-06-23 06:31:07.941850
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    print(p, p.ROLE_CACHE, p._included_conditional, p._included_path, p._action_groups, p._group_actions)

    p.ROLE_CACHE = {'a' : 1}
    p._included_conditional = '<test>'
    p._included_path = '<test>'
    p._action_groups = {'a' : 1}
    p._group_actions = {'a' : 1}
    print(p, p.ROLE_CACHE, p._included_conditional, p._included_path, p._action_groups, p._group_actions)
    
    p2 = p.copy()

# Generated at 2022-06-23 06:31:15.471659
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = object.__new__(Play)
    
    play.name = "foo"
    assert play.get_name() == "foo"
    
    play.name = None
    play.hosts = ["foo"]
    assert play.get_name() == "foo"
    assert play.get_name() == play.name
    
    play.hosts = []
    assert play.get_name() == ""
    
    play.hosts = None
    assert play.get_name() == ""

# Generated at 2022-06-23 06:31:23.675845
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    F = {}
    with patch('ansible.playbook.play.Play._validate_vars_file_path', Mock(return_value=F)):
        p = Play()
        p.vars = {1:2}
        p.vars_prompt = {3:4}
        p.vars_files = [{5:6}]
        assert p.get_vars() == {1:2, 3:4, 5:6}


# Generated at 2022-06-23 06:31:30.855264
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert(p.get_vars_files() == [])
    p.vars_files = 'file1'
    assert(p.get_vars_files() == ['file1'])
    p.vars_files = ['file1', 'file2']
    assert(p.get_vars_files() == ['file1', 'file2'])
    p.vars_files = None
    assert(p.get_vars_files() == [])


# Generated at 2022-06-23 06:31:33.461256
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    Play_obj = Play()
    Play_obj.roles = []
    assert Play_obj.get_roles()==[]

# Generated at 2022-06-23 06:31:41.607346
# Unit test for constructor of class Play
def test_Play():
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None)
    variable_manager.options_vars = load_options_vars(loader=None, options=None)
    hosts = 'localhost'
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = hosts,
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    ), variable_manager=variable_manager)
    play.post_validate(variable_manager=variable_manager, all_vars=dict())
    tq

# Generated at 2022-06-23 06:31:44.859919
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = 'httpd'
    assert repr(play) == 'httpd', 'Failed Play<__repr__>'

# Generated at 2022-06-23 06:31:53.142595
# Unit test for method load of class Play
def test_Play_load():
    play = Play()
    play = play.load(data={}, variable_manager=None, loader=None, vars=None)
    assert play.__repr__() == play.get_name()
    assert play.get_vars_files() == []
    assert play.serialize() == {}
    assert play.copy().__repr__() == play.get_name()
    assert play.copy().get_vars_files() == []
    assert play.copy().serialize() == {}

# Generated at 2022-06-23 06:32:05.077931
# Unit test for method compile of class Play
def test_Play_compile():
    from collections import namedtuple
    import os
    import random
    import string
    from ansible.parsing.vault import VaultLib

    from ansible_collections.ansible.community.tests.unit.plugins.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    if not os.path.isdir(fixtures_path):
        os.makedirs(fixtures_path)

    FixtureClass = namedtuple('FixtureClass', ['tmp_path', 'vault_password'])
    fixture = None

    def setUpModule():
        global fixture

# Generated at 2022-06-23 06:32:09.425522
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.deserialize(play.serialize())


# Generated at 2022-06-23 06:32:18.586134
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = []
    play.tasks = []
    play.post_tasks = []
    assert play.get_tasks() == []
    play.post_tasks = [('block1', 'block2', 'block3')]
    assert play.get_tasks() == [('block1', 'block2', 'block3')]
    play.tasks = [('block4', 'block5')]
    play.post_tasks = [('block1', 'block2', 'block3')]
    assert play.get_tasks() == [('block4', 'block5'), ('block1', 'block2', 'block3')]

# Generated at 2022-06-23 06:32:27.194269
# Unit test for constructor of class Play
def test_Play():
    p = Play().load({})
    assert isinstance(p, Play)
    if not hasattr(p, "name"):
        raise AssertionError("Play instance has no name attribute")
    if not hasattr(p, "vars"):
        raise AssertionError("Play instance has no vars attribute")
    if not hasattr(p, "vars_files"):
        raise AssertionError("Play instance has no vars_files attribute")
    if not hasattr(p, "roles"):
        raise AssertionError("Play instance has no roles attribute")
    if not hasattr(p, "tasks"):
        raise AssertionError("Play instance has no tasks attribute")

# Generated at 2022-06-23 06:32:36.398805
# Unit test for constructor of class Play

# Generated at 2022-06-23 06:32:47.984663
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    vars = dict(
        hosts = 'all',
        user = 'ansible',
        serial = 1,
    )

# Generated at 2022-06-23 06:32:57.370196
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = dict(
        name='ping',
        hosts='localhost',
        connection='local',
        gather_facts='no',
        roles=['role1'],
        tasks=[dict(action=dict(module='shell', args='ls'))]
    )
    p = Play.load(data)
    assert p.serialize() == dict(
        name='ping',
        hosts='localhost',
        connection='local',
        gather_facts='no',
        roles=['role1'],
        tasks=[dict(action=dict(module='shell', args='ls'))],
        included_path=None,
        action_groups={},
        group_actions={}
    )



# Generated at 2022-06-23 06:33:03.313695
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a dummy Play object
    play = Play()
    play.hosts = 'host1'

    # Create some dummy roles
    role1 = Role()

    # Compile roles handlers
    result = play.compile_roles_handlers()

    # Assert that result is expected
    assert result == []


# Generated at 2022-06-23 06:33:06.725103
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    self = Play()
    result = self.__repr__()
    assert result is not None
    assert isinstance(result, text_type)

# Generated at 2022-06-23 06:33:15.768915
# Unit test for method copy of class Play
def test_Play_copy():
    data = dict(
        name = "foo",
        hosts = "host1",
        gather_facts = "False",
        connection = "local",
        remote_user = "remoteuser",
        roles = [
            dict(
                name = "role1",
                tasks = [
                    dict(
                        name = "task1"
                    ),
                ],
            ),
        ],
    )
    play = Play.load(data, variable_manager=VariableManager(), loader=DictDataLoader())
    play_copy = play.copy()
    assert play_copy.name == play.name
    assert play_copy.hosts == play.hosts
    assert play_copy.gather_facts == play.gather_facts
    assert play_copy.connection == play.connection
    assert play_copy.remote_user == play.remote

# Generated at 2022-06-23 06:33:30.643881
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
        for i in range(50):
            pre_tasks = [fake_task1, fake_task2]
            tasks = [fake_task3, fake_task4, fake_task5]
            post_tasks = [fake_task6, fake_task7]
            play = Play()
            play.pre_tasks = pre_tasks
            play.rescue = pre_tasks
            play.always = pre_tasks
            play.tasks = tasks
            play.post_tasks = post_tasks
            assert len(play.tasks) == len(pre_tasks + tasks + post_tasks)
            assert len(play.get_tasks()) == len(pre_tasks + tasks + post_tasks)


# Generated at 2022-06-23 06:33:37.848706
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    my_play = Play()

    my_role = Role()
    my_role.name = 'my_role_name'
    my_role.default_vars = 'my_role_default_vars'
    my_role.vars = 'my_role_vars'
    my_role.tags = 'my_role_tags'
    my_role.tasks = 'my_role_tasks'
    my_role.handlers = 'my_role_handlers'
    my_role.meta = 'my_role_meta'
    my_role.file_vars = 'my_role_file_vars'
    my_role.always_run = 'my_role_always_run'
    my_role.run_once = 'my_role_run_once'
    my_role.included

# Generated at 2022-06-23 06:33:46.993308
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    my_data = dict(
        name='Example Play',
        hosts=['host1', 'host2'],
        user='someuser',
        gather_facts=True,
        roles=['some_role'],
        roles_path=['some_path'],
        vars_files=['vars_files.yml'],
        vars_prompt=['vars_prompt.yml'],
        tasks=['tasks.yml'],
        handlers=['handlers.yml']
    )
    me = Play()
    me.preprocess_data(my_data)


# Generated at 2022-06-23 06:33:57.778626
# Unit test for method load of class Play
def test_Play_load():
    host = "localhost"
    vars = {"ansible_connection": "local", "ansible_python_interpreter": "/usr/bin/python"}
    play = Play.load(
        data={"hosts": "localhost", "gather_facts": "no", "tasks": [{"name": "Test", "debug": {"msg": "Hello world"}}]},
        variable_manager=VariableManager(),
        loader=DataLoader(),
        vars=vars
    )
    assert play.tasks[0].name == "Test"
    assert play.tasks[0].action == "debug"
    assert play.tasks[0].args == {"msg": "Hello world"}

"""
Unit tests for class PlayContext
"""
