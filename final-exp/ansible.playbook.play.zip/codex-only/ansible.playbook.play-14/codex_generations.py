

# Generated at 2022-06-23 06:24:08.175158
# Unit test for constructor of class Play

# Generated at 2022-06-23 06:24:17.043150
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    roles = [{
        'role': 'foo',
        'subscriptions': [
            {
                'local_action': 'bar',
                'listeners': ['listener1']
            },
            {
                'local_action': 'foo',
                'listeners': ['listener2']
            },
        ]
    }]
    p = Play()
    p.roles = roles
    result = p.compile_roles_handlers()
    assert result[0].name == "listener1"
    assert result[1].name == "listener2"

# Generated at 2022-06-23 06:24:23.194831
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    _play = Play()
    _block_list = _play.compile_roles_handlers()

    assert isinstance(_block_list, list)
    assert _block_list == []


# Generated at 2022-06-23 06:24:23.883001
# Unit test for method compile of class Play
def test_Play_compile():
    pass

# Generated at 2022-06-23 06:24:37.146573
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    data = '''
- hosts: localhost
  tasks:
  - name: do the thing
    debug: msg="{{ lookup('env','HOME') }}"
    tags:
    - test1
'''
    p = Play.load(data)
    # assert p.get_tasks() == [{'name':'do the thing', 'action': {'__ansible_module__': 'debug', 'msg': '{{ lookup('env','HOME') }}'}}]

# Generated at 2022-06-23 06:24:46.239267
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    playbook_dir = 'dir of playbook'
    data = {'tasks': [{'import_role': 'role_name', 'tasks_from': 'other dir'}, {'import_role': 'role_name'}]}
    variable_manager = 'var_manager'
    loader = 'loader'
    vars = 'vars'
    play = Play.load(data=data, variable_manager=variable_manager, loader=loader, vars=vars)
    play.ROLE_CACHE['role_name'] = [play]
    role_include = RoleInclude.load(
        data={'name': 'role_name', 'tasks_from': 'other dir'}, play=play, from_include=False,
        variable_manager=variable_manager, loader=loader, collection_name=None)
    role

# Generated at 2022-06-23 06:24:58.911295
# Unit test for method get_name of class Play
def test_Play_get_name():
    ansible = Ansible()

    # Given the playbook
    play = Play()
    play.vars = ansible.vars
    play.loader = ansible.loader
    play.variable_manager = ansible.variable_manager
    play.name = 'foo'
    assert play.get_name() == 'foo'

    play.hosts = None
    assert play.get_name() == 'foo'

    # When play.hosts is a string
    play.hosts = 'bar'
    # Then play.name should be the hosts value
    assert play.get_name() == 'bar'

    # When play.hosts is a list
    play.hosts = ['bar', 'baz']
    # Then play.name should be the comma-separated list

# Generated at 2022-06-23 06:25:09.813820
# Unit test for method compile of class Play
def test_Play_compile():
    from . import host, variable_manager
    from .host import Host
    from .variable_manager import VariableManager
    from .task import Task
    from .block import Block
    from .role import RoleInclude
    import os

    Play.ROLE_CACHE = {}

    play = Play()

    play.name = "test play"

    host = Host(name="test host")
    host.set_variable('ansible_ssh_pass', '123')

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'password': '123'}
    variable_manager.host_vars = {"test host": {"password": "123"}}
    variable_manager.set_inventory(Inventory(host_list=[host]))

    play.hosts = "test host"

# Generated at 2022-06-23 06:25:15.775183
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    data = '''
---
- name: test
  connection: local
  hosts: localhost
  become: yes
  become_method: sudo
  become_user: root

  roles:
  - test
  '''

    data_file = StringIO(dedent(data))
    play = Play().load(data_file, variable_manager=variable_manager, loader=loader)
    config.init(args, variable_manager, loader)
    variable_manager.set_play_context(play)
    variable_manager.set_host_variable('localhost', 'ansible_python_interpreter', '/usr/bin/python3')

    block_list = play.compile_roles_handlers()

    # print('block_list: %s'% block_list)
    assert len(block_list) == 1

   

# Generated at 2022-06-23 06:25:24.258900
# Unit test for method get_tasks of class Play

# Generated at 2022-06-23 06:25:34.968768
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_obj = Play()
    vars_files = [{"host1":{"path":"host1/group_vars/all","name":"host1","type":"yaml"}},
                  {"host1":{"path":"host1/group_vars/all","name":"host1","type":"json"}}]
    play_obj.vars_files = vars_files
    result = play_obj.get_vars_files()
    assert result == vars_files
    play_obj = Play()
    data = {"host1":{"path":"host1/group_vars/all","name":"host1","type":"yaml"}}
    play_obj.vars_files = data
    result = play_obj.get_vars_files()
    assert result == [data]
    return True


# Generated at 2022-06-23 06:25:45.630991
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    data = dict()
    data['hosts'] = 'all'
    data['_hosts'] = ['all']
    data['id'] = 'id1'
    data['vars'] = dict()
    data['_variable_manager'] = dict()
    data['_removed_hosts'] = ['removed']
    data['ROLE_CACHE'] = dict()
    data['_included_conditional'] = '_included_conditional1'
    data['_included_path'] = '/test'
    data['_action_groups'] = dict()
    data['_group_actions'] = dict()
    data['serial'] = 100
    data['_serial'] = 100

# Generated at 2022-06-23 06:25:57.081036
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a play
    play = Play()

    # create a role
    role1 = Role()
    role1.name = "rolename1"
    role1.name = "rolename1"
    role1._finalize_data()

    role_handler_block = Block()
    role_handler_block._add_task(Task())
    role_handler_block._add_task(Task())
    role_handler_block._add_task(Task())

    role1.handlers.append(role_handler_block)

    # add the created role to the play
    play.roles.append(role1)

    # get the handler blocks
    role_handler_block_list = play.compile_roles_handlers()

    # check if the handler blocks are returned

# Generated at 2022-06-23 06:26:09.877979
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    ds = {'hosts':'10.0.0.1', 'roles':[{'name':'httpd'}]}
    play = Play.load(ds, variable_manager=None, loader=None)
    assert play.compile_roles_handlers() == []

    ds = {'hosts':'10.0.0.1', 'roles':[
        {'name':'httpd', 'handlers':[{'name':'restart apache', 'remote_user':'ubuntu',
                                      'tasks':[{'name':'restart apache', 'action':'service', 'args':{'name':'apache2'}}]}]}]}
    play = Play.load(ds, variable_manager=None, loader=None)
    assert play.compile_roles_handlers()

# Generated at 2022-06-23 06:26:12.310942
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.compile()

# Generated at 2022-06-23 06:26:13.855032
# Unit test for method load of class Play
def test_Play_load():
    log_info('Testing method load of class Play')



# Generated at 2022-06-23 06:26:21.546166
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    assert play.get_name() == play.hosts
    assert play.get_name() is None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = []
    assert play.get_name() == ''
    play.hosts = ['test1', 'test2']
    assert play.get_name() == 'test1,test2'
    assert play.get_name() != 'test2,test1'


# Generated at 2022-06-23 06:26:23.068405
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    ds = {'user': 'nonny'}
    result = p.preprocess_data(ds)
    expected = {'remote_user': 'nonny'}
    assert expected == result

# Generated at 2022-06-23 06:26:23.841450
# Unit test for method serialize of class Play
def test_Play_serialize():
    # (no tests)
    pass

# Generated at 2022-06-23 06:26:32.048374
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ['/etc/ansible/play.yml']
    assert p.get_vars_files() == ['/etc/ansible/play.yml']
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = '/etc/ansible/play.yml'
    assert p.get_vars_files() == ['/etc/ansible/play.yml']


# Generated at 2022-06-23 06:26:37.122336
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play1 = Play()
    play1._ds = {'test': 'test'}
    data = {'test':'test', 'roles':[{'name': 'test', 'dependencies': [], 'tasks': []}]}
    play1.deserialize(data)
    assert play1.roles[0].name == 'test'


# Generated at 2022-06-23 06:26:46.237673
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    new_p = p.deserialize({"name": "test", "connection": "local", "hosts": "all", "roles": [{"name": "test", "tasks": [{"name": "task 1", "action": {"module": "debug", "args": {"msg": 1}}}, {"name": "task 2", "action": {"module": "debug", "args": {"msg": 2}}}]}]})
    assert new_p.hosts == "all"
    assert new_p.roles[0].name == "test"
    assert new_p.roles[0].tasks[0].name == "task 1"
    assert new_p.roles[0].tasks[0].action_args.get("msg") == 1

# Generated at 2022-06-23 06:26:54.412540
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    class Play(BasePlay):
        _list_of_attributes = {'tasks': [_load_tasks, 'list of tasks'],
                               'pre_tasks': [_load_pre_tasks, 'list of pre_tasks'],
                               'post_tasks': [_load_post_tasks, 'list of post_tasks']}
        def _load_tasks(self, attr, ds):
            return ds or []
        def _load_pre_tasks(self, attr, ds):
            return ds or []
        def _load_post_tasks(self, attr, ds):
            return ds or []
        def __init__(self):
            super(Play, self).__init__()
            self.tasks = []
            self.pre

# Generated at 2022-06-23 06:27:04.985537
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    #
    # Play test cases
    #

    # Check a dict with 'user' and 'remote_user' keys
    play = Play()
    ds = {}
    ds['user'] = 'admin'
    ds['remote_user'] = 'root'
    new_ds = play.preprocess_data(ds)
    assert 'user' not in new_ds
    assert 'remote_user' in new_ds
    assert new_ds['remote_user'] == 'admin'

    # Check a dict with 'user' key
    play = Play()
    ds = {}
    ds['user'] = 'admin'
    new_ds = play.preprocess_data(ds)
    assert 'user' not in new_ds
    assert 'remote_user' in new_ds

# Generated at 2022-06-23 06:27:07.064573
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    vars = play.vars
    assert vars == vars, "Test failed"

# Generated at 2022-06-23 06:27:11.752882
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    r1 = Role()
    r2 = Role()
    expect = [r1,r2]
    p.roles = expect
    assert p.get_roles() == expect
    assert p.roles == expect

# Generated at 2022-06-23 06:27:17.280347
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    obj = Play()
    obj._ds = {'name': "obj"}
    obj._included_path = None
    obj._action_groups = {}
    obj._group_actions = {}
    assert repr(obj) == "obj"


# Generated at 2022-06-23 06:27:29.060147
# Unit test for constructor of class Play
def test_Play():
    # Test all initializing attributes type as threading object.
    obj = Play()
    assert isinstance(obj._ds, Mapping)
    assert isinstance(obj._ds_attrs, Mapping)
    assert isinstance(obj.ROLE_CACHE, MutableMapping)
    assert isinstance(obj._included_conditional, MutableSequence)
    assert isinstance(obj._included_path, MutableSequence)
    assert isinstance(obj._removed_hosts, MutableSequence)
    assert isinstance(obj.only_tags, MutableSet)
    assert isinstance(obj.skip_tags, MutableSet)
    assert isinstance(obj._action_groups, MutableMapping)
    assert isinstance(obj._group_actions, MutableMapping)

    # Test all initializing attributes type

# Generated at 2022-06-23 06:27:41.967913
# Unit test for method get_vars of class Play

# Generated at 2022-06-23 06:27:46.281916
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.name = 'foo'
    assert p.__repr__() == p.get_name()
    p = Play()
    assert p.__repr__() == p.get_name()



# Generated at 2022-06-23 06:27:55.340008
# Unit test for method __repr__ of class Play
def test_Play___repr__(): # unit test for Play method __repr__
    from collections import Mapping
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.constants import DEFAULT_HANDLER_NAME
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-23 06:28:05.703226
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vars_loader

    ds = dict(a = dict(b = "test"))
    # ds = None #should raise AnsibleAssertionError
    # ds = [] #should raise AnsibleAssertionError

    # if ds is not None:
    #     assert isinstance(ds, dict) # should raise AssertionError
    #     assert isinstance(ds, (dict, list))

    # Instantiate Play
    p = Play()
    try:
        ds = p.preprocess_data(ds)
    except AnsibleAssertionError:
        print("Error: 'while preprocessing data (%s), ds should be a dict but was a %s'" % (ds, type(ds)))

# Unit test

# Generated at 2022-06-23 06:28:18.257884
# Unit test for method copy of class Play
def test_Play_copy():
    pl = Play()
    pl.ROLE_CACHE = {'ROLE_CACHE'}
    # TODO pl._included_conditional
    pl._included_path = {'_included_path'}
    pl._action_groups = {'_action_groups'}
    pl._group_actions = {'_group_actions'}

    new_me = pl.copy()

    assert new_me.ROLE_CACHE is not pl.ROLE_CACHE
    assert new_me.ROLE_CACHE == pl.ROLE_CACHE 

    # TODO assert new_me._included_conditional == pl._included_conditional
    assert new_me._included_path is not pl._included_path
    assert new_me._included_path == pl

# Generated at 2022-06-23 06:28:20.093665
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    pass



# Generated at 2022-06-23 06:28:20.800145
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-23 06:28:24.447729
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {"key1": "value1", "key2": "value2"}
    assert(play.get_vars() == {"key1": "value1", "key2": "value2"})

# Generated at 2022-06-23 06:28:34.320380
# Unit test for method compile of class Play
def test_Play_compile():
	p = Play()
	p.roles = []
	p.pre_tasks = []
	p.tasks = []
	p.post_tasks = []
	assert p.compile() == []
	p.tasks = [
		None,
		"str",
		{},
		"str",
		{},
		{},
		None,
		[],
		"str",
		None,
		"str",
		{},
		None,
		None
	]

# Generated at 2022-06-23 06:28:45.246698
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test get_name() with no variable for hosts
    # Expected result:
    #   The name is an empty string
    p = Play()
    p.hosts = None
    assert p.get_name() == ''

    # Test get_name() with hosts containing only one element
    # Expected result:
    #   The name contains only one element, too
    p = Play()
    p.hosts = '127.0.0.1'
    p.name = None
    assert p.get_name() == '127.0.0.1'

    # Test get_name() with hosts containing multiple elements
    # Expected result:
    #   The name contains the elements of hosts separated by comma
    p = Play()
    p.hosts = '127.0.0.1, 192.168.0.1'

# Generated at 2022-06-23 06:28:46.713337
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    Play.get_vars_files(None)

# Generated at 2022-06-23 06:28:51.170143
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    assert p._validate_vars({'test': 'ansible'})
    assert p.get_vars() == {'test': 'ansible'}


# Generated at 2022-06-23 06:28:58.961768
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    role = Role()
    role.name = 'name'
    role.default_vars = {}
    role.default_vars['var1'] = 'val1'
    role.default_vars['var2'] = 2
    role.default_vars['var2'] = 3
    role.default_vars['var3'] = 'val3'

    play.roles = []
    play.roles.append(role)

    role2 = role.copy()
    role2.default_vars['var3'] = 'val3'
    role2.default_vars['var4'] = 'val4'

    play.roles.append(role2)

    roles = play.get_roles()
    assert len(roles) > 0
    assert roles[0].__class__

# Generated at 2022-06-23 06:29:04.240234
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    obj = Play()
    assert obj.preprocess_data({"hosts": "all"}) == {"hosts": "all"}

    obj = Play()
    assert obj.preprocess_data({"hosts": "all", "user": "root"}) == {"hosts": "all", "remote_user": "root"}

# Generated at 2022-06-23 06:29:07.383600
# Unit test for method compile of class Play
def test_Play_compile():
    '''
    Unit test for method compile of class Play
    '''
    p = Play()
    p.vars = {'key': 'value'}
    p.post_validate()
    p.compile()
    assert p.vars == {'key': 'value'}


# Generated at 2022-06-23 06:29:08.983764
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert repr(play) == play.get_name()

# Generated at 2022-06-23 06:29:17.018220
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import become_loader, vars_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Arguments used by the mock
    def _loader_constructor(*args, **kwargs):
        raise AnsibleParserError

    def _vault_decrypt_text(*args, **kwargs):
        raise AnsibleParserError

    def _templar_constructor(*args, **kwargs):
        raise AnsibleParserError

    # Patching methods
    m_loader_constructor = mocker.patch('ansible.plugins.loader.get_all_plugin_loaders', side_effect=_loader_constructor)

# Generated at 2022-06-23 06:29:18.487214
# Unit test for constructor of class Play
def test_Play():
    p = Play()

# Generated at 2022-06-23 06:29:20.889537
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    assert play.get_roles==[]
    
    

# Generated at 2022-06-23 06:29:25.088405
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    t = Play()
    t.vars = {'k1':'v1', 'k2':'v2'}
    assert(t.get_vars() == t.vars)


# Generated at 2022-06-23 06:29:33.710382
# Unit test for method load of class Play
def test_Play_load():
    print('Testing class Play...')
    play = Play.load(dict(
        name='test',
        hosts=['192.168.0.1', '192.168.0.2'],
        remote_user='user',
        gather_facts='no'))
    assert play.hosts == ['192.168.0.1', '192.168.0.2']
    assert play.remote_user == 'user'
    assert play.gather_facts == 'no'
    print('Play class passed unit tests.')

if __name__ == '__main__':
    test_Play_load()

# Generated at 2022-06-23 06:29:40.364975
# Unit test for method copy of class Play
def test_Play_copy():
    data = {'name': 'test_play',
            'vars': {'play_var_1': 'play_var_1_value'},
            'hosts': 'localhost',
            'tasks': [{'name': 'a task'}],
            'roles': [{'name': 'a_role'}]}
    play = Play.load(data)
    assert play.name == 'test_play'
    assert play.vars == {'play_var_1': 'play_var_1_value'}
    assert play.hosts == 'localhost'
    assert len(play.tasks) == 1
    assert isinstance(play.tasks[0], Task)
    assert play.tasks[0].name == 'a task'
    assert isinstance(play.roles, list)
    assert len

# Generated at 2022-06-23 06:29:55.612516
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # Create test objects
    play = Play()

    # Test with invalid values
    invalid_values = [True, False, 123, 0, -1, [1, 2, 3], {'a': 1, 'b': 2, 'c': 3}]
    for value in invalid_values:
        with pytest.raises(AnsibleParserError) as ex:
            play.compile_roles_handlers(value)
        assert 'invalid value' in str(ex.value)

    # Test with valid but bad values
    with pytest.raises(AnsibleParserError) as ex:
        play.compile_roles_handlers(None)
    assert 'empty or None' in str(ex.value)




# Generated at 2022-06-23 06:29:57.212259
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.__repr__()


# Generated at 2022-06-23 06:29:58.468128
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass


# Generated at 2022-06-23 06:30:03.692313
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert(play.get_name() == '')
    play.name = 'test_name'
    assert(play.get_name() == 'test_name')
    test_str = play.__repr__()
    assert(test_str == 'test_name')


# Generated at 2022-06-23 06:30:06.847984
# Unit test for method copy of class Play
def test_Play_copy():
  play = Play()
  play.tasks = [Task()]
  play.handlers = [Handler()]
  play.copy()


# Generated at 2022-06-23 06:30:17.809894
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  from ansible.playbook.handler import Handler
  from ansible.playbook.block import Block
  from ansible.playbook.role.definition import RoleDefinition
  from ansible.playbook.task import Task
  from ansible.playbook.play import Play
  play = Play()
  role = RoleDefinition.load(data={'name': 'test', 'tasks': [{'name': 'test', 'action': 'test'}]}, play=play)
  play.roles = [role,]
  t = play.compile_roles_handlers()
  assert(len(t)) == 1 # Play.compile_roles_handlers returns a list of blocks
  assert(len(t[0].block)) == 1 # Each block has a single task

# Generated at 2022-06-23 06:30:19.017444
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    play.compile()

# Generated at 2022-06-23 06:30:25.383940
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # Initialize a test variable
    play = Play()

    # Test method __repr__ of class Play
    result = play.__repr__()
    assert result == '', 'Expected: %s, but returned: %s' % ('', result)

# Generated at 2022-06-23 06:30:27.078923
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
	P = Play()
	assert P.get_handlers() == P.handlers

# Generated at 2022-06-23 06:30:35.828327
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [
        Task(),
        Task()
    ]
    play.tasks = [
        Task()
    ]
    play.post_tasks = [
        Task()
    ]
    expected = [play.pre_tasks[0], play.pre_tasks[1], play.tasks[0], play.post_tasks[0]]
    got = play.get_tasks()
    assert expected == got

# Generated at 2022-06-23 06:30:45.177996
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    role = Role()
    role.ROLE_CACHE = {}
    role.__included_roles = []
    role.defaults = {}
    role.handlers = []
    role.vars = {}
    role.pre_tasks = []
    role.post_tasks = []
    role.tasks = []
    role.tags = ['all']
    role.dep_attrs = {}
    role.hints = {}
    role.role_path = os.path.abspath('../contrib')
    role.name = 'Docker'
    role.collections = []
    role.metadata = {}
    role.ROLE_PRINT_DEPTH = 0
    role.UPGRADE_STRATEGY_ORDER = []
    role.no_log = False

# Generated at 2022-06-23 06:30:45.933434
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    pass

# Generated at 2022-06-23 06:30:58.391094
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    test_play = Play()
    test_play.vars = {"who": "me", "favorite_color": "Blue"}
    assert test_play.get_vars()["who"] == "me"
    assert test_play.get_vars()["favorite_color"] == "Blue"

    # Test with a single file, then a list
    test_play.vars_files = ("test_vars_file.yml")
    assert test_play.get_vars_files() == ["test_vars_file.yml"]

    test_play.vars_files = ["test_vars_file1.yml", "test_vars_file2.yml"]

# Generated at 2022-06-23 06:31:05.058597
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    new_play = play.copy()
    assert new_play.ROLE_CACHE == {}
    assert new_play._included_conditional == None
    assert new_play._included_path == None
    assert new_play._action_groups == {}
    assert new_play._group_actions == {}



# Generated at 2022-06-23 06:31:06.621461
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    print(play.get_roles())


# Generated at 2022-06-23 06:31:08.618986
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    assert play.get_vars() is not None

# Generated at 2022-06-23 06:31:10.506987
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name == ''
    assert play.hosts == ''



# Generated at 2022-06-23 06:31:15.460661
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # Create an instance of class Play with its attribute _ds set to {}
    # and its attribute _data set to EmptyData()
    play_instance = Play()
    # Unit test for method __repr__ of class Play
    # Since __repr__ of class Play returns self.get_name(), it is tested below
    assert play_instance.__repr__() == play_instance.get_name()

# Generated at 2022-06-23 06:31:17.604457
# Unit test for method compile of class Play
def test_Play_compile():
        obj = Play()
        obj.compile()

# Generated at 2022-06-23 06:31:22.311310
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play._ds['vars'] = {'hosts': 'localhost'}
    vars = play.get_vars()
    assert vars == {'hosts': 'localhost'}


# Generated at 2022-06-23 06:31:32.281784
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import mock
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    # Create a mock task, it will only check parameter passed to constructor
    task1 = mock.create_autospec(Task)
    task1.module_vars = {}

    # Create a mock block, it will only check parameter passed to constructor
    block = mock.create_autospec(Block)
    block.rescue.return_value = []
    block.always.return_value = []
    block.block.return_value = [task1, task1]

    play = Play()
    play.pre_tasks = [task1]
    play.tasks = [block, task1]
    play.post_tasks = [task1]

    #

# Generated at 2022-06-23 06:31:39.788114
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    from ansible.playbook.play import Play
    from ansible.playbook.play import Playbook
    host, port = 'localhost', 22
    connection = dict(host=host, port=port)
    play = Play(
        playbook=Playbook(),
        name='foo',
        hosts='bar',
        connection=connection,
        gather_facts='no',
        remote_user='baz',
        become=True,
        become_method='qux',
        become_user='beasley',
        check=True,
        become_ask_pass=False
    )
    assert repr(play) == 'foo'


# Generated at 2022-06-23 06:31:46.630835
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_obj = Play()
    # Test for vars_files attribute of type string
    play_obj.vars_files = "test.yml"
    assert play_obj.get_vars_files() == ["test.yml"]

    # Test for vars_files attribute of type list
    play_obj.vars_files = ["test1.yml", "test2.yml"]
    assert play_obj.get_vars_files() == ["test1.yml", "test2.yml"]


# Generated at 2022-06-23 06:31:52.924199
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import Role

    p = Play()
    p.roles = [ Role() ]

    assert len(p.get_roles()) == 1
    assert p.get_roles()[0] is p.roles[0]

    assert len(p.roles) == 1


# Generated at 2022-06-23 06:31:55.318916
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "play1"
    assert play.get_name() == 'play1'


# Generated at 2022-06-23 06:31:57.492568
# Unit test for method copy of class Play
def test_Play_copy():
    try:
        Play().copy()
    except Exception:
        raise AssertionError('Unit test for method copy of class Play failed.')


# Generated at 2022-06-23 06:32:03.154996
# Unit test for method copy of class Play
def test_Play_copy():
    play1 = Play()
    play2 = play1.copy()
    play1._roles = [1,2,3]
    play1._task_list = [1,2,3]
    assert play1._roles is not play2._roles
    assert play1._task_list is not play2._task_list


# Generated at 2022-06-23 06:32:11.297408
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    """
    Ansible 2.6 - playbook.py-class

    """
    # returns a instance of Play
    import codecs
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from collections import namedtuple
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    import yaml
    yaml.warnings({'YAMLLoadWarning': False})
    # for testing purposes

# Generated at 2022-06-23 06:32:22.552083
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_obj = Play()

    # Test with roles parameter
    data = {}
    data['roles'] = [{'_tasks': [{'_loop': None, '_raw_params': 'setup', '_role': None}],
                      '_role_name': 'setup',
                      '_role_path': '/etc/ansible/roles/setup'}]
    data['included_path'] = '/etc/ansible/playbooks/init_play.yml'
    data['action_groups'] = {'all': {'hosts': ['localhost'],
                                     'vars': {'ansible_connection': 'local'}},
                             'ungrouped': {'hosts': ['localhost'],
                                           'vars': {'ansible_connection': 'local'}}}

# Generated at 2022-06-23 06:32:25.163070
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() == ''

    p.name = 'name'

    assert p.get_name() == 'name'


# Generated at 2022-06-23 06:32:31.578136
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """

    """
    with pytest.raises(AnsibleAssertionError) as excinfo:
        pass

    assert "while preprocessing data (%s), ds should be a dict but was a %s" in str(excinfo)


# Generated at 2022-06-23 06:32:44.302873
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_files1 = [
        {
            'vars_files': [
                {
                    'first': 'hello'
                },
                {
                    'second': 'world'
                },
                {
                    'third': 'python'
                }
            ]
        }
    ]

    vars_files2 = [
        {
            'vars_files': 'testing'
        }
    ]

    vars_files3 = [
        {
            'vars_files': {
                'first': 'hello'
            }
        }
    ]

    p1 = Play(vars_files=vars_files1)
    assert p1.get_vars_files() == vars_files1
    p2 = Play(vars_files=vars_files2)

# Generated at 2022-06-23 06:32:46.979541
# Unit test for method copy of class Play
def test_Play_copy():
    play_copy = Play().copy()
    assert isinstance(play_copy, Play)

# Generated at 2022-06-23 06:32:47.921823
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()



# Generated at 2022-06-23 06:32:59.137405
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import ansible.parsing.dataloader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    #playbook = Playbook.load('./test.yml', variable_manager=variable_manager, loader=loader)
    playbook = Playbook.load('./test1.yml', variable_manager=variable_manager, loader=loader)
    print(playbook)
    #print(playbook.get

# Generated at 2022-06-23 06:33:09.320368
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    p.name = 'foo'
    p.vars = dict(a='foo', b='bar')
    p.hosts = 'host1'
    p.remote_user = 'userX'
    p.any_errors_fatal = False
    p.roles = [ Role() ]
    p.default_vars = dict(c='faz', d='baz')
    p.vars_prompt = dict(e=dict(name='f'))
    p.tasks = [ Task() ]
    p.pre_tasks = [ Task() ]
    p.post_tasks = [ Task() ]
    p.handlers = [ Handler() ]
    p.serial = [ 1, 2, 3 ]
    p.max_fail_percentage = 20

# Generated at 2022-06-23 06:33:24.350492
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    # create a play object
    play = Play()

    # test with tasks as empty or not
    play.tasks = []
    assert len(play.get_tasks()) == 0
    play.tasks = ['t1','t2','t3']
    assert len(play.get_tasks()) == 3
    assert play.get_tasks() == ['t1','t2','t3']

    # test with pre_tasks as empty or not
    play.pre_tasks = []
    assert len(play.get_tasks()) == 3
    assert play.get_tasks() == ['t1','t2','t3']
    play.pre_tasks = [{'meta': 'flush_handlers'}]
    assert len(play.get_tasks()) == 4
    assert play.get_tasks

# Generated at 2022-06-23 06:33:38.505095
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play = Play()
    play.compile()

    pre_tasks = []
    pre_tasks.append(Task())
    pre_tasks.append(Task())
    setattr(play, 'pre_tasks', pre_tasks)

    post_tasks = []
    post_tasks.append(Task())
    post_tasks.append(Task())
    setattr(play, 'post_tasks', post_tasks)

    tasks = []
    tasks.append(Task())
    tasks.append(Task())
    setattr(play, 'tasks', tasks)

    tasks = play.get_tasks()
    assert len(tasks) == 8

# Generated at 2022-06-23 06:33:39.276384
# Unit test for method copy of class Play
def test_Play_copy():
    pass

# Generated at 2022-06-23 06:33:51.105225
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from itertools import tee
    import yaml

    # Loads a play from file named "test"
    # SOURCE: https://github.com/ansible/ansible/blob/devel/test/unit/play/test_play.py
    def load_play_from_file(path, variable_manager, loader, inventory):
        '''Loads a play from a playbook file.'''
        play = None
        ds = None


# Generated at 2022-06-23 06:34:02.366566
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()