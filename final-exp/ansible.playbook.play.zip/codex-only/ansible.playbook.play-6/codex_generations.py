

# Generated at 2022-06-23 06:24:08.241782
# Unit test for method serialize of class Play
def test_Play_serialize():
    import json
    data = {'private_key_file': None, 'connection': 'smart', 'remote_user': 'vagrant', 'gather_facts': 'no', 'name': '', 'become': False, 'become_method': 'sudo', 'become_user': None, 'forks': 5, 'roles': [], 'vars_files': [], 'tags': [], 'vars_prompt': []}
    p = Play.load(data)
    p.tasks = []
    p.handlers = []

# Generated at 2022-06-23 06:24:17.404889
# Unit test for method get_name of class Play
def test_Play_get_name():
    """ Unit test for class: Play, method: get_name """

    def test(play, expected):
        actual = play.get_name()
        assert actual == expected

    play = Play()
    play.name = 'Playname'
    test(play, 'Playname')

    play = Play()
    play.hosts = 'hostname'
    test(play, 'hostname')

    play = Play()
    play.hosts = ['host1', 'host2']
    test(play, 'host1,host2')

    play = Play()
    test(play, '')


# Generated at 2022-06-23 06:24:22.283509
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    result = play.preprocess_data({'hosts': 'localhost'})
    assert result is not None

# Generated at 2022-06-23 06:24:32.432892
# Unit test for method copy of class Play
def test_Play_copy():
    # Initialize the test Play
    p = Play()
    # Set the needed fields
    p.vars_files = ['/tmp/test_file', '/tmp/test_file2']
    # Copy it to a new Play
    new_p= p.copy()
    assert(new_p._ds == p._ds) # The _ds private attributes must be equal
    assert(new_p._included_path == p._included_path) # The _included_path private attributes must be equal
    assert(new_p._action_groups == p._action_groups) # The _action_groups private attributes must be equal
    assert(new_p._group_actions == p._group_actions) # The _group_actions private attributes must be equal
    assert(new_p.__dict__ == p.__dict__) # The attributes must

# Generated at 2022-06-23 06:24:43.993971
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    Play_obj = Play()
    

# Generated at 2022-06-23 06:24:51.923439
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []
    role = RoleInclude(name="role")
    role.compile(play=play)
    play.roles.append(role)
    assert play.compile_roles_handlers() == []
    role.register_hook(None, "handler1", "handler", "task1")
    role.register_hook(None, "handler2", "handler", "task1")
    handlers = play.compile_roles_handlers()
    assert len(handlers) == 2
    assert handlers[0].name == "handler1"
    assert handlers[1].name == "handler2"
    assert not handlers[0]._parent
    assert not handlers[1]._parent


# Generated at 2022-06-23 06:24:54.208500
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'foo'
    assert p.get_name() == 'foo'


# Generated at 2022-06-23 06:25:05.571032
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = 'file1'
    assert play.get_vars_files() == ['file1']
    play.vars_files = ['file1', 'file2']
    assert play.get_vars_files() == ['file1', 'file2']
    play.vars_files = []
    assert play.get_vars_files() == []
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = [None]
    assert play.get_vars_files() == []


# Generated at 2022-06-23 06:25:08.658141
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    data = {"name": "test_play", "hosts": "all"}
    p = Play()
    p.deserialize(data)
    assert not p.get_roles()


# Generated at 2022-06-23 06:25:15.342882
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    p = Play()
    b = Block()
    t = Task()
    b.block.append(t)
    p.pre_tasks = [b]
    p.tasks = [b]
    p.post_tasks = [b]
    tl = p.get_tasks()
    assert isinstance(tl, list)
    assert len(tl) == 3

# Generated at 2022-06-23 06:25:24.170361
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
       Assert the correct value for get_vars_files
    '''
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    assert play.vars_files is None

    play.vars_files = "/home/user/test"
    assert play.get_vars_files() == [play.vars_files]
    assert play.vars_files == "/home/user/test"

    play.vars_files = ["/home/user/test", "/home/user/test2"]
    assert play.get_vars_files() == play.vars_files
    assert play.vars_files == ["/home/user/test", "/home/user/test2"]



# Generated at 2022-06-23 06:25:24.995102
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    #TODO
    pass

# Generated at 2022-06-23 06:25:28.207226
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    new_ds = p.preprocess_data(ds={'hosts': 'all','roles': ['common','ntp','sudo']})
    assert isinstance(new_ds, dict)


# Generated at 2022-06-23 06:25:32.778983
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    """
    Test for the Play get_vars method.
    """
    play = Play()
    play.vars = {}
    assert play.get_vars() == play.vars


# Generated at 2022-06-23 06:25:36.657104
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = dict(foo="bar")
    assert play.get_vars() == dict(foo="bar")

# Generated at 2022-06-23 06:25:40.234956
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    Play_obj = Play()

    Play_obj._load_tasks('tasks', [{}])
    Play_obj._load_pre_tasks('pre_tasks', [{}])
    Play_obj._load_post_tasks('post_tasks', [{}])

    assert True == isinstance(Play_obj.get_tasks(), list)

# Generated at 2022-06-23 06:25:44.379725
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    #play = Play(playbook=notNone, name=notNone, vars_files=notNone)
    #expect = []
    #assert play.get_vars_files() == expect
    logger.warn('There is no interface for testing method get_vars_files of class Play')
    assert True

# Generated at 2022-06-23 06:25:55.704070
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    task = TaskInclude()
    context = PlayContext()

# Generated at 2022-06-23 06:26:01.992138
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    _self = Play()
    _self.get_name = MagicMock(name='get_name')
    _self.get_name.return_value = "__repr___return"

    # call the method
    assert _self.__repr__() == "__repr___return"
    # all assertions passed


# Generated at 2022-06-23 06:26:03.159855
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [1,2,3]
    assert p.get_tasks() == [1,2,3]

# Generated at 2022-06-23 06:26:15.893034
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test the case where ds is a "dict"
    try:
        Play().preprocess_data({})
    except AnsibleAssertionError as e:
        assert str(e) == "while preprocessing data ({}), ds should be a dict but was a <class 'dict'>"

    # Test the case where ds key "user" does not exist
    data = {
        'hosts': [],
    }
    assert Play().preprocess_data(data) == {
        'hosts': [],
    }

    # Test the case where ds key "user" exists and ds key "remote_user" does not exist
    data = {
        'hosts': [],
        'user': "ansible"
    }

# Generated at 2022-06-23 06:26:21.859732
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert hasattr(p, 'name')
    assert hasattr(p, 'hosts')
    assert hasattr(p, 'vars')
    assert hasattr(p, 'roles')
    assert hasattr(p, 'tasks')
    assert hasattr(p, 'tags')
    assert hasattr(p, 'gather_facts')
    assert hasattr(p, 'any_errors_fatal')

# Generated at 2022-06-23 06:26:34.068651
# Unit test for method copy of class Play

# Generated at 2022-06-23 06:26:43.961861
# Unit test for method compile of class Play
def test_Play_compile():
    """
    Compiles and returns the task list for this play, compiled from the
    roles (which are themselves compiled recursively) and/or the list of
    tasks specified in the play.
    """
    test_data = load_fixture('Play_compile')

    test_data['task_list'] = Task.load(test_data['task_list'], play=test_data['play'],
                                       variable_manager=test_data['variable_manager'], loader=test_data['loader'])

    test_data['play']._compile_roles = MagicMock()
    test_data['play']._compile_roles.return_value = test_data['role_block_list']
    test_data['play'].compile()

    assert test_data['play'].pre_tasks == test

# Generated at 2022-06-23 06:26:47.848963
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    # test with a list of tasks
    task1 = Task()
    task1.name = "task1"
    task2 = Task()
    task2.name = "task2"
    p.tasks = [task1, task2]
    assert p.compile() == [task1, task2]
    # test with a list of roles
    p.roles = [role_one, role_two]
    assert p.compile() == [task1, task2, task_one_one, task_one_two, task_two_one, task_two_two]

# Generated at 2022-06-23 06:26:57.715675
# Unit test for method load of class Play
def test_Play_load():
    args = dict(
        connection='smart',
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        vault_password=None,
        verbosity=1,
        start_at_task=None,
    )
    context.CLIARGS = AttributeDict(args)

    data = dict(
        name='test_play',
        hosts=['all'],
        gather_facts='no'
    )

    variable_manager = VariableManager()
    loader = DataLoader()
    p = Play.load(data, variable_manager=variable_manager, loader=loader)
    assert p.name == 'test_play'
    assert p.hosts == 'all'
    assert p.gather_facts == 'no'

# Generated at 2022-06-23 06:27:04.415007
# Unit test for method __repr__ of class Play

# Generated at 2022-06-23 06:27:15.800618
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    p = Play()

# Generated at 2022-06-23 06:27:26.126092
# Unit test for method copy of class Play
def test_Play_copy():
    # Initialize a play of class Play
    play = Play()
    play.name = 'my_play'

    # Copy the play
    play_copy = play.copy()
    assert play.name == play_copy.name
    assert play._included_conditional == play_copy._included_conditional
    assert play._included_path == play_copy._included_path
    assert play._action_groups == play_copy._action_groups
    assert play._group_actions == play_copy._group_actions

    # Verify ROLE_CACHE is a copy
    assert play.ROLE_CACHE != play_copy.ROLE_CACHE



# Generated at 2022-06-23 06:27:28.082383
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {}
    p = Play()
    p.deserialize(data=data)

# Generated at 2022-06-23 06:27:34.504941
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    hosts = 'localhost,remote'
    tasks = [
        dict(action=dict(module='shell', args='ls'), register='shell_out'),
        dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]

    play_src =  dict(
            name = "Ansible Play",
            hosts = hosts,
            gather_facts = 'no',
            tasks = tasks
        )

    play = Play().load(play_src, variable_manager=VariableManager(), loader=DataLoader())

    handlers = play.get_handlers()

    assert handlers == []


# Generated at 2022-06-23 06:27:43.716286
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play._included_path = 'test_included_path'
    play._action_groups = {'test_key': 'test_value'}
    play._action_groups = {'test_key': 'test_value'}

    role = Role()
    role.name = 'test_role_name'
    role.defaults = {'test_key': 'test_value'}
    role.vars = {'test_key': 'test_value'}
    role.tasks = [
        {
            'test_key1': 'test_value1',
            'test_key2': 'test_value2',
        },
        {
            'test_key1': 'test_value1',
            'test_key2': 'test_value2',
        },
    ]


# Generated at 2022-06-23 06:27:54.027903
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name is ''
    assert p.hosts == 'all'
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.tags == set(['all'])
    assert p.skip_tags == set()
    assert p.gather_facts is True
    assert p.vars == dict()
    assert p.vars_prompt == list()
    assert p.vars_files == list()
    assert p.connection == 'smart'
    assert p.port is 0
    assert p.remote_addr is None
    assert p.transport == 'smart'
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.sudo is False
    assert p.sudo_user == C.DEFAULT_SUDO_USER

# Generated at 2022-06-23 06:28:00.148372
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p1 = Play()
    p1._tasks = [1,2,3]
    p1._post_tasks = [4,5,6]
    p1._pre_tasks = [7,8,9]
    assert p1.get_tasks() == [7,8,9,1,2,3,4,5,6]

# Generated at 2022-06-23 06:28:04.733577
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.handlers = [{'a': {'b': 1}}, {'c': 2}, {'d': 3, 'e': 4}]
    print(play.compile_roles_handlers())
    play.roles = [Role(), Role(), Role()]
    print(play.compile_roles_handlers())


# Generated at 2022-06-23 06:28:14.438172
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    my_play = Play()
    my_play.vars_files = 'myhost.yml'
    assert my_play.get_vars_files() == ['myhost.yml']
    my_play.vars_files = None
    assert my_play.get_vars_files() == []
    my_play.vars_files = ['myhost.yml', 'myhost2.yml']
    assert my_play.get_vars_files() == ['myhost.yml', 'myhost2.yml']

# Generated at 2022-06-23 06:28:18.753701
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {"key0": "value0", "key1": "value1", "key2": "value2"}
    assert play.get_vars() == {"key0": "value0", "key1": "value1", "key2": "value2"}

# Generated at 2022-06-23 06:28:27.930004
# Unit test for method compile of class Play
def test_Play_compile():
    ds = {'hosts': 'localhost', 'tasks': [{'action': {'__ansible_argspec': {'kwargs': {}, 'args': ['foo']}, '__ansible_module__': 'debug'}, '__ansible_argspec': {'kwargs': {}, 'args': ['msg']}}], 'vars': {'a': 'b'}}
    p = Play()
    p.load_data(ds, variable_manager=VariableManager(), loader=DataLoader())

# Generated at 2022-06-23 06:28:33.280876
# Unit test for method compile of class Play
def test_Play_compile():
    data = {
        u'name': u'localhost',
        u'hosts': [u'localhost'],
        u'tasks': [],
        u'vars': {u'host': u'localhost'},
        u'roles': []
    }
    play = Play()
    play.deserialize(data)
    play.compile()

# Generated at 2022-06-23 06:28:33.781103
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-23 06:28:38.220964
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = (1,2)
    play.tasks = (3,4)
    play.post_tasks = (5,6)
    r1 = play.get_tasks()


# Generated at 2022-06-23 06:28:47.796816
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    Unit test for method ``get_vars_files`` of class :py:class:`Play`
    :param self: An instance of the test case
    :type self: testtools.testcase.TestCase
    '''

# Generated at 2022-06-23 06:28:53.791872
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    my_play = Play()
    my_play.ROLE_CACHE = {'role1': 'role1'}
    my_play.roles = [{'role1.tasks': [{'some_task': 'some_task'}]}]
    assert my_play.compile_roles_handlers() == [{'some_task': 'some_task'}]

# Generated at 2022-06-23 06:29:03.964136
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = 'tmp_vars'
    assert isinstance(p.get_vars_files(), list)
    p.vars_files = None
    assert isinstance(p.get_vars_files(), list)
    p.vars_files = []
    assert isinstance(p.get_vars_files(), list)
    p.vars_files = [1]
    assert isinstance(p.get_vars_files(), list)
    p.vars_files = [1,2,3,4]
    assert isinstance(p.get_vars_files(), list)


# Generated at 2022-06-23 06:29:06.594713
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.handlers = [{'testhandlers': 'handlers'}]
    play.get_handlers()
    assert True


# Generated at 2022-06-23 06:29:13.162116
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() == ''
    p.name = 'test_name'
    assert p.get_name() == 'test_name'
    p.hosts = 'test_host'
    assert p.get_name() == 'test_name'
    p.name = ''
    assert p.get_name() == 'test_host'
    p.hosts = ['host1','host2']
    assert p.get_name() == 'host1,host2'

# Generated at 2022-06-23 06:29:19.835263
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.get_name=MagicMock(return_value='test')
    assert play.__repr__() == 'test'
    play.get_name=MagicMock(side_effect=Exception('Bang!'))
    try:
        play.__repr__()
    except Exception as exception:
        assert str(exception) == "Bang!"


# Generated at 2022-06-23 06:29:22.054483
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert repr(play) == 'Play:None'


# Generated at 2022-06-23 06:29:26.512516
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    vars = dict(key = dict(one = 1))
    assert play.get_vars() == dict()
    play.vars = vars
    assert play.get_vars() == vars


# Generated at 2022-06-23 06:29:36.702895
# Unit test for method serialize of class Play
def test_Play_serialize():
    '''
    Unit test for method serialize of class Play
    '''
    test_obj = Play()
    test_obj.name = "test"
    test_obj.hosts = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20']
    test_obj.gather_facts = True
    test_obj.task_ignore_errors = False
    test_obj.max_fail_percentage = 30
    test_obj.serial = 0
    test_obj.any_errors_fatal = False
    test_obj.force_handlers = True

# Generated at 2022-06-23 06:29:45.140155
# Unit test for method copy of class Play
def test_Play_copy():
    assert Play().copy()

    # TODO
    #p = Play()
    #assert p._included_conditional == None
    #print(p.copy())
    #print(p._included_conditional)
    #print(p._included_path)
    #print(p._action_groups)
    #print(p._group_actions)

    #assert p._included_conditional == None
    #assert p._included_path == None
    #assert p._action_groups == {}
    #assert p._group_actions == {}

test_Play_copy()

# for test

# Generated at 2022-06-23 06:29:55.927063
# Unit test for constructor of class Play
def test_Play():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    p = Play()
    p.load({}, variable_manager, loader)

    assert isinstance(p, Play)
    assert isinstance(p.name, string_types)
    assert isinstance(p.hosts, string_types)
    assert isinstance(p.remote_user, string_types)
    assert isinstance(p.become, bool)
    assert isinstance(p.become_method, string_types)
    assert isinstance(p.vars, dict)
    assert isinstance(p.vars_prompt, list)
    assert isinstance(p.vars_files, list)

# Generated at 2022-06-23 06:29:56.690081
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    pass

# Generated at 2022-06-23 06:30:03.239230
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play.load(dict(
        hosts=['127.0.0.1'],
        tasks=[
            dict(action=dict(module='assert', args=dict(that=['2', 2])))
        ]
    ), variable_manager=variable_manager, loader=loader)
    task_list = play.get_tasks()
    assert len(task_list) == 1
    assert len(task_list[0]) == 1
    assert isinstance(task_list[0][0], Task)
    assert task_list[0][0].args['that'][0] == '2'
    assert task_list[0][0].args['that'][1] == 2

# Generated at 2022-06-23 06:30:15.198907
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.vars = dict(a=1, b=2, c=3)
    play.tasks = [dict(name='Test task 1'), dict(name='Test task 2'), dict(name='Test task 3')]
    play.post_tasks = [dict(name='Test post task 1'), dict(name='Test post task 2')]
    play.pre_tasks = [dict(name='Test pre task 1'), dict(name='Test pre task 2')]
    play.hosts = 'hosts.txt'
    play.name = 'Test Play'
    play.roles = [Role().load(dict(name='Test role 1')), Role().load(dict(name='Test role 2'))]
    play._included_path = 'Play.yml'
    play.tags = ['test']

# Generated at 2022-06-23 06:30:19.647785
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = "TestName"
    assert p.get_name() == "TestName"

    p.name = None
    p.hosts = "TestHosts"
    assert p.get_name() == "TestHosts"


# Generated at 2022-06-23 06:30:32.243370
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-23 06:30:36.006977
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    myclass = Play()
    myclass.roles = []
    myclass.roles.append("boo")
    myclass.roles.append("bar")
    assert myclass.get_roles() == ["boo", "bar"]

# Generated at 2022-06-23 06:30:47.408048
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    '''
    Unit test for method get_vars of class Play
    '''

    #
    # Currently get_vars()' only purpose is to copy the dict in self.vars.
    #
    # I will expand this to cover the pre_tasks/post_tasks/tasks/roles/handlers
    # as well, since this will be necessary for Ansible 2.x's "hostvars"
    # concept.
    #
    # --duglin@redhat.com
    #
    #
    # Set up test variables
    #
    mock_play_vars = dict(
        key1='value1',
        key2='value2',
    )

# Generated at 2022-06-23 06:30:54.648455
# Unit test for method get_name of class Play
def test_Play_get_name():
    # test default behavior
    play = Play()
    play.name = None
    play.hosts = 'all'
    play.get_name()
    assert play.name == 'all'
    # test default play name value (empty string)
    play = Play()
    play.name = None
    play.hosts = None
    play.get_name()
    assert play.name == ''


# Generated at 2022-06-23 06:31:01.434829
# Unit test for constructor of class Play
def test_Play():
    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[],
    )

    db = Play().load(data=play_ds)
    assert db._attribute_errors == []
    assert db.get_name() == 'Ansible Play'
    assert db.hosts == 'localhost'
    assert db.gather_facts == 'no'
    assert db._ds == play_ds
    assert play_ds['name'] == "Ansible Play"

# Generated at 2022-06-23 06:31:05.534558
# Unit test for method compile of class Play
def test_Play_compile():
    # Test compile
    # Assume that it is a list of objects
    assert_equal(play._compile_roles(), ['test'])


# Generated at 2022-06-23 06:31:08.531275
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    from ansiblelint import RuleMatch
    import re
    p = Play()
    assert isinstance(p.get_vars(), dict)

# Generated at 2022-06-23 06:31:17.836758
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = { 'remote_user':'test_remote_user' }
    p = Play()
    assert p.preprocess_data(ds) == { 'remote_user':'test_remote_user' }
    ds = { 'user':'test_remote_user' }
    p = Play()
    preprocessed_ds = p.preprocess_data(ds)
    assert preprocessed_ds.get('user',None) is None
    assert preprocessed_ds.get('remote_user',None) == 'test_remote_user'
    ds = { 'user':'test_remote_user', 'remote_user': 'test_remote_user_remote' }
    p = Play()
    with pytest.raises(AnsibleParserError):
        p.preprocess_data(ds)

#

# Generated at 2022-06-23 06:31:19.978498
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    assert p.get_handlers() == []


# Generated at 2022-06-23 06:31:29.272167
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Create an empty Play() to pass to the method.
    p = Play()

    # Make sure the method returns an empty list if vars_files is unset.
    assert p.get_vars_files() == [], "Expected empty list when vars_files is unset."

    # Test that a string is treated as a single-item list.
    p.vars_files = 'test.yml'
    assert p.get_vars_files() == ['test.yml'], "Expected list of single string."

    # Test that a list returns the list unchanged.
    p.vars_files = ['test.yml', 'test2.yml']
    assert p.get_vars_files() == ['test.yml', 'test2.yml'], "Expected list to be returned unmodified."



# Generated at 2022-06-23 06:31:29.867317
# Unit test for constructor of class Play
def test_Play():
    pass

# Generated at 2022-06-23 06:31:39.559419
# Unit test for constructor of class Play
def test_Play():
    # variable_manager:
    variable_manager = VariableManager()

    # a dict for hosts
    hosts = dict()

    # test for class Play constructor
    play = Play(
        hosts = hosts,
        variable_manager = variable_manager,
    )

    # check if play is an instance of Play
    assert isinstance(play, Play), "the play should be an instance of Play"

    # check the hosts of play
    assert play.hosts == hosts, "the hosts should be %s" % repr(hosts)

    # check the variable_manager
    assert play.variable_manager == variable_manager, "the variable_manager of play should be %s" % repr(variable_manager)

    # check the name of play
    assert play.name != None, "the name of play should not be None"


# Generated at 2022-06-23 06:31:47.089468
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() == ''
    p.name = 'test play'
    assert p.get_name() == 'test play'
    p.name = None
    p.hosts = ['host1', 'host2', 'host3']
    assert p.get_name() == 'host1,host2,host3'
    p.hosts = 'host1,host2,host3'
    assert p.get_name() == 'host1,host2,host3'
    p.hosts = []
    assert p.get_name() == ','


# Generated at 2022-06-23 06:31:58.454709
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = AnsiblePlay()

    # TEST: empty handlers
    ret = p.get_handlers()
    assert ret == []

    # TEST: single handler
    p.Handlers = [{"a": "1"}]
    ret = p.get_handlers()
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert isinstance(ret[0], dict)
    assert ret[0]['a'] == "1"

    # TEST: multiple handlers
    p.Handlers = [{"a": "1"}, {"b": "2"}]
    ret = p.get_handlers()
    assert isinstance(ret, list)
    assert len(ret) == 2
    assert isinstance(ret[0], dict)
    assert ret[0]['a'] == "1"

# Generated at 2022-06-23 06:32:06.999207
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    module_name = build_file_path('get_vars_files', __file__)
    return_value = ["./v1.yml", "./v2.yml"]
    spec_values = {'vars_files': return_value}
    result = run_command(module_name, [{}], [spec_values])
    assert result['failed'] == False
    assert result['rc'] == 0
    assert result['changed'] == False
    assert result['stdout'] == return_value
    assert result['warnings'] == []



# Generated at 2022-06-23 06:32:19.264629
# Unit test for constructor of class Play
def test_Play():

    p_play = Play()
    assert isinstance(p_play, object)
    assert hasattr(p_play, '_attributes')
    assert hasattr(p_play, '_ds')
    assert hasattr(p_play, '_ds_delayed')
    assert hasattr(p_play, 'LU')
    assert hasattr(p_play, 'ROLE_CACHE')
    assert hasattr(p_play, 'ROLE_CACHE')
    assert hasattr(p_play, 'ROLE_CACHE')
    assert hasattr(p_play, '_loader')
    assert hasattr(p_play, '_variable_manager')
    assert hasattr(p_play, '_basedir')
    assert hasattr(p_play, '_vars')

# Generated at 2022-06-23 06:32:26.628740
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Verify that the data structure user in the constructor is not modified
    d = {'hosts': 'localhost', 'user': "test_user", 'tasks':[{'name': 'test', 'action': {'module': 'fail', 'args': {'msg': 'test message'}}}]}
    p = Play()
    assert p.preprocess_data(d) == d

    # Verify that the data structure user in the constructor is not modified
    d = {'hosts': 'localhost', 'tasks':[{'name': 'test', 'action': {'module': 'fail', 'args': {'msg': 'test message'}}}]}
    p = Play()
    assert p.preprocess_data(d) == d



# Generated at 2022-06-23 06:32:27.865847
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-23 06:32:31.626002
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    print()

    # Test setup

    # ################
    # Execute test

    pl = Play()
    pl.name = 'TestPlay'
    assert str(pl) == 'TestPlay'


# Generated at 2022-06-23 06:32:35.033910
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test_play_name'
    assert p.get_name() == 'test_play_name'


# Generated at 2022-06-23 06:32:47.059693
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible.template import Templar

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.block import Task

    inventory = """
    [my-group]
    host1
    host2

    [my-group:vars]
    ansible_password=password
    """
    p1 = Play()
    p1.name = "test"
    h1 = Host("host1")
    h2 = Host("host2")
    g1 = Group("my-group")
    g1.add_host(h1)
    g1.add_host(h2)
    g

# Generated at 2022-06-23 06:32:47.690352
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass

# Generated at 2022-06-23 06:32:50.740578
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    """
    Unit test that checks, if get_vars works
    """
    play = Play()
    play.vars = {"a": "c", "b": "d"}
    assert play.get_vars() == {"a": "c", "b": "d"}

# Generated at 2022-06-23 06:32:51.331319
# Unit test for method compile of class Play
def test_Play_compile():
    pass

# Generated at 2022-06-23 06:32:56.188363
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    '''
    get_vars()
    '''
    p = Play()
    assert p.get_vars() == {}

    p.vars = dict(a=1)
    assert p.get_vars() == dict(a=1)


# Generated at 2022-06-23 06:33:00.615206
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = {}
    p = Play()
    p.preprocess_data(ds)
    p = Play()
    p.preprocess_data(ds)
    p = Play()
    p.preprocess_data(ds)

# Generated at 2022-06-23 06:33:04.276372
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    handlers = [{"name":"test"}]
    p.handlers = handlers
    result = p.get_handlers()
    assert result == [{"name":"test"}]


# Generated at 2022-06-23 06:33:15.922683
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = dict(
                connection='local',
                gather_facts='no',
                hosts='localhost',
                max_fail_percentage=0.0,
                name=None,
                no_log='False',
                priority='100',
                roles=[],
                serial=0,
                tags=None,
                tasks=[],
                vars_files=None,
                vars_prompt=None,
                force_handlers='no',
                strategy=C.DEFAULT_STRATEGY,
                included_path='/etc/ansible/roles/myrole/tasks/main.yml',
                action_groups={'create-device': ['create-device']},
                group_actions={'create-device': ['create-device']},
                vars={}
                )

    p = Play()
    p

# Generated at 2022-06-23 06:33:19.507121
# Unit test for method load of class Play
def test_Play_load():
    play = Play()
    setattr(play, 'hosts', 'localhost')
    setattr(play, 'roles', [])
    assert play.get_name() == 'localhost'


# Generated at 2022-06-23 06:33:34.186164
# Unit test for method compile of class Play
def test_Play_compile():
    host_list = ["TEST_HOST"]
    loader = DictDataLoader(dict())
    variable_manager = VariableManager()
    play_source =  dict(
            name = "Ansible Play",
            hosts = host_list,
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    play.compile()


# Generated at 2022-06-23 06:33:45.478176
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-23 06:33:46.161069
# Unit test for constructor of class Play
def test_Play():
    pass

# Generated at 2022-06-23 06:33:51.149351
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # TODO: This unit test currently fails for reasons unknown. It works "in practice",
    #       but does not seem to work in isolation.
    # play = Play()
    # assert_that("This unit test currently fails for reasons unknown")
    pass

# Generated at 2022-06-23 06:34:02.477765
# Unit test for method compile of class Play
def test_Play_compile():
    import unittest
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.module_utils.six import PY3, b

    class TestPlay(unittest.TestCase):
        def setUp(self):
            self.play = Play()

        def tearDown(self):
            pass

        def test_compile_default(self):
            """Testing Play - compile, defaults"""

            self.play.vars = dict()
            self.play.hosts = ["host1", "host2", "host3"]
            self.play.vars_prompt = dict()
            self.play.tasks = []