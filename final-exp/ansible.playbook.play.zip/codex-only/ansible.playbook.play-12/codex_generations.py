

# Generated at 2022-06-23 06:24:08.001616
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    class ArgSpec(object):
        def __init__(self):
            self.args = []
    class Options(object):
        def __init__(self):
            self.tags = []
            self.skip_tags = []
            self.args = []

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # initialize needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    display = Display()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])
    variable_manager.set_inventory(inventory)

    context.CLIARGS = Options()

# Generated at 2022-06-23 06:24:20.881895
# Unit test for method compile of class Play
def test_Play_compile():
    yaml_file = open("test_yaml/plays/valid_playbook.yml","r")
    data = yaml.load(yaml_file)
    yaml_file.close()
    data = data['plays'][0]
    a = Play()
    a._load_vars(None, data['vars'])
    a._load_vars_prompt(None, data['vars_prompt'])
    a._load_vars_files(None,data['vars_files'])
    a._load_roles(None,data['roles'])
    a._load_tasks(None,data['tasks'])
    a._load_handlers(None,data['handlers'])
    a._load_pre_tasks(None,data['pre_tasks'])


# Generated at 2022-06-23 06:24:21.788938
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert True

# Generated at 2022-06-23 06:24:28.523221
# Unit test for constructor of class Play
def test_Play():
    # Define test data for instantiation of class Play
    p = Play()
    assert p.play_hosts == {}
    assert p.playbook == None
    assert p.get_name() == ""
    assert p.pseudo_host == None
    assert p.ROLE_CACHE == {}
    assert p._variables == {}
    assert p._included_path == None
    assert p._action_groups == {}
    assert p._group_actions == {}



# Generated at 2022-06-23 06:24:38.873507
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.hosts = ['localhost']
    assert play.get_name() == 'test_play'
    play.name = ''
    assert play.get_name() == 'localhost'
    play.hosts = ['localhost', '127.0.0.1']
    assert play.get_name() == 'localhost,127.0.0.1'
    play.name = 'test_play'
    assert play.get_name() == 'test_play'



# Generated at 2022-06-23 06:24:45.954167
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # create a play to test get_vars_files
    play = Play()

    # test when vars_files is None
    play.vars_files = None
    assert play.get_vars_files() == []

    # test when vars_files is a list
    play.vars_files = ['1', '2']
    assert play.get_vars_files() == ['1', '2']

    # test when vars_files is a string (also test the case without fail)
    play.vars_files = '3'
    assert play.get_vars_files() == ['3']

# Generated at 2022-06-23 06:24:51.330218
# Unit test for method load of class Play
def test_Play_load():
    p = Play.load(dict(name='test', hosts=['foo'], tasks=[]))
    assert p.name == 'test'
    assert p.hosts == ['foo']

# Generated at 2022-06-23 06:25:03.367495
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # test empty list
    print("Testing Play:get_roles()")
    play = Play()
    play.roles = []
    assert play.get_roles() == []
    # test roles in roles
    role = MockRole()
    role.roles = [MockRole()]
    play.roles = [role]
    assert play.get_roles() is not role.roles
    assert play.get_roles()[0].roles[0] == role.roles[0]
    print("Test success\n")

test_Play_get_roles()


# Generated at 2022-06-23 06:25:04.330895
# Unit test for method load of class Play
def test_Play_load():
  pass


# Generated at 2022-06-23 06:25:16.277035
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    """
    This unit test checks that the compile_roles_handlers method 
    that is part of the Play class
    """

    # Test compile_roles_handlers with the playbook obtained from test_Play_load

    ## test_Play_load.yml
    """
    ---
    - name: Test play
      hosts: all
      vars:
        var1: val1
      user: test
      serial: 1
      gather_facts: no
    """

    ## test_Play_load.yml converted to json

# Generated at 2022-06-23 06:25:21.470682
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    """
    test of method _load_handlers of class Play
    """
    loader = DataLoader()
    variable_manager = VariableManager()
    p = Play().load(dict(name='foo', hosts='all', gather_facts='no'), variable_manager=variable_manager, loader=loader)
    p._load_handlers(attr='foobar', ds=['foobar'])
    assert p.get_handlers() == []



# Generated at 2022-06-23 06:25:25.492415
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    roles = []
    r = Role()
    r.name = 'test'
    roles.append(r)
    setattr(p, 'roles', roles)
    assert p.get_roles()[0].name == 'test'

# Generated at 2022-06-23 06:25:26.944313
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    assert Play.get_vars() == Play.get_vars()

# Generated at 2022-06-23 06:25:32.274788
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    err = None
    play_obj = Play()

    play_obj.vars = {'test_var': 'test_value'}
    assert play_obj.get_vars() == {'test_var': 'test_value'}



# Generated at 2022-06-23 06:25:32.992861
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-23 06:25:40.036183
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() == ''
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p = Play()
    p.hosts = ['host1','host2','host3']
    assert p.get_name() == 'host1,host2,host3'
    

# Generated at 2022-06-23 06:25:43.916119
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Setup test
    play = Play()
    play.tasks = ['task1', 'task2']

    # Perform the test
    actual = play.get_tasks()

    # Verify the result
    assert actual == ['task1', 'task2']


# Generated at 2022-06-23 06:25:49.767687
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    data = p.serialize()
    assert data.get('roles') == []
    assert data.get('included_path') is None
    assert data.get('action_groups') == {}
    assert data.get('group_actions') == {}


# Generated at 2022-06-23 06:25:51.226131
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    assert True



# Generated at 2022-06-23 06:25:54.645773
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    role = Role()
    play.roles.append(role)
    assert play.get_roles()[0] == role

# Generated at 2022-06-23 06:26:00.029164
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_name = "temp"
    variable_manager = "variable_manager"
    loader = "loader"
    inventory = "inventory"
    play = Play(name=play_name, variable_manager=variable_manager, loader=loader, inventory=inventory)
    play.vars_files = []
    assert play.get_vars_files() == []
    play.vars_files = "vars_files"
    assert play.get_vars_files() == ["vars_files"]



# Generated at 2022-06-23 06:26:01.356109
# Unit test for method get_roles of class Play
def test_Play_get_roles():
	pass

# Generated at 2022-06-23 06:26:02.338162
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-23 06:26:05.824548
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    assert p.get_handlers() == [], "Expected value: [], Actual value: %s" % p.get_handlers()

# Generated at 2022-06-23 06:26:09.172888
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # get_name() is mocked
    instance = Play()
    exp_res = instance.get_name()
    res = instance.__repr__()
    assert res == exp_res


# Generated at 2022-06-23 06:26:12.645094
# Unit test for method compile of class Play
def test_Play_compile():
    set_runner()
    p = Play()
    p.get_tasks()
    p.compile()

# Generated at 2022-06-23 06:26:23.150111
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from units.mock.v2_4 import MockV2Module
    from ansible.vars import VariableManager
    ds = {'hosts':['all'],
          'user': 'xyz',
          'tasks':[{'action': { 'module': 'shell', 'args': 'dontcare'}},],
          'roles':['xyz']}
    loader = DataLoader()
    play = Play.load(ds, None, loader=loader)
    assert isinstance(play.tasks[0], Task)
    assert isinstance(play.roles[0], Role)
    assert play.remote_user == 'xyz'
    assert play.user is None
    assert play.hosts == ['all']

# Generated at 2022-06-23 06:26:34.860992
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    hosts = 'all'
    gather_facts = 'no'
    user = 'john'
    vars = {'var1': 'value1'}

    p = Play()
    p.set_loader(DataLoader())
    p.set_variable_manager(VariableManager())

    # test attribute roles
    roles_1 = [{'name': 'db'}, {'name': 'web'}]
    p.load({'hosts': hosts, 'user': user, 'gather_facts': gather_facts, 'roles': roles_1}, variable_manager=p._variable_manager, loader=p._loader)
    roles = p.get_roles()
    assert len(roles) == 2

    # test attribute vars
    vars_1 = {'var1': 'value1'}

# Generated at 2022-06-23 06:26:38.185369
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.handlers = []
    assert play.get_handlers() == []

    play = Play()
    play.handlers = [1,2,3]
    assert play.get_handlers() == [1,2,3]


# Generated at 2022-06-23 06:26:46.380237
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from collections import namedtuple
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.plugins.loader import connection_loader, module_loader
    Play = Play()
    Play.task = Task()
    Play.task.context = PlayContext()
    Play.task.loader = DataLoader()
    Play.task.variable_manager = VariableManager()
    Play.plugins = namedtuple('_', ('connection_loader', 'module_loader'))(connection_loader, module_loader)

# Generated at 2022-06-23 06:26:54.314188
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ansible_obj = Play_global()
    ansible_obj._ds = dict(user='test_user', remote_user='test_remote_user')
    try:
        assert 'user' not in ansible_obj.preprocess_data(ansible_obj._ds)
    except Exception:
        pass
    assert 'remote_user' in ansible_obj.preprocess_data(ansible_obj._ds)

    ansible_obj._ds = dict(user='test_user')
    try:
        assert 'user' not in ansible_obj.preprocess_data(ansible_obj._ds)
    except Exception:
        pass
    assert 'remote_user' in ansible_obj.preprocess_data(ansible_obj._ds)


# Generated at 2022-06-23 06:26:56.285946
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert p.__repr__() == p.get_name()

# Generated at 2022-06-23 06:27:06.772512
# Unit test for constructor of class Play
def test_Play():
    from ansible.playbook.role_include import IncludeRole
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import add_all_plugin_dirs
    import os

    add_all_plugin_dirs()

    hosts = ['127.0.0.1']
    user = 'joe'
    remote_user = 'fred'
    connection = 'smart'
    vars = {'var1': 'value1', 'var2': 'value2'}
    pre_tasks = [{'name': 'do this first'}]
    tasks = [{'name': 'do this'}]
    post_tasks = [{'name': 'do this last'}]
    handlers = [{'name': 'handle this'}]

# Generated at 2022-06-23 06:27:09.858718
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    role1 = Role()
    role2 = Role()
    role1.handlers = ['handler1']
    play.roles = [role1, role2]

    # verify resultant handlers list is the list of union of handlers
    # from all the roles i.e. it removes duplicates
    assert play.compile_roles_handlers() == ['handler1']

# Generated at 2022-06-23 06:27:16.255136
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    """
    Test for method __repr__ of class Play
    """
    print("test: Play:__repr__")
    #
    # Setup a simple play
    #
    class MockPlay(Play):
        def __init__(self, name):
            self.name = name

    play = MockPlay("test")
    #
    # Check that play.name is returned
    #
    assert play.__repr__() == "test"

# Generated at 2022-06-23 06:27:28.227906
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    p = Play()
    pc = PlayContext()
    templar = Templar(loader=None, variables={'foo': 'foo_value'})
    v = VariableManager()
    v.set_variable_memory_usage()

    # Neither self.vars_files nor self.vars is set
    assert p.get_vars_files() == []

    # Set self.vars_files without vars_file definitions and without vars
    p.vars_files = []
    assert p.get_vars_files() == []

    # Set self.vars_files with a vars

# Generated at 2022-06-23 06:27:30.185529
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play.load({'hosts': 'hosts'})
    assert play.__repr__() == 'hosts'

# Generated at 2022-06-23 06:27:34.193556
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({})
    r = p.ROLE_CACHE
    assert r == {}
    i = p._included_conditional
    assert i is None
    i = p._included_path
    assert i is None
    a = p._action_groups
    assert a == {}
    g = p._group_actions
    assert g == {}


# Generated at 2022-06-23 06:27:43.621520
# Unit test for method copy of class Play
def test_Play_copy():
    # Initialize test variables
    ds = dict(
        name=dict(
            default='test_default_name',
            type='str'
        )
    )
    p = Play()
    p._load_data(ds, 'fake_loader', 'fake_variable_manager')
    # Test
    result = p.copy()
    # Verify
    assert result.name == p.name


    # Initialize test variables
    ds = dict(
        name=dict(
            default='test_default_name',
            type='str'
        )
    )
    p = Play()
    p._load_data(ds, 'fake_loader', 'fake_variable_manager')
    result = p.copy()
    # Test
    assert result._roles == p._roles


    # Initialize test variables


# Generated at 2022-06-23 06:27:44.367868
# Unit test for method compile of class Play
def test_Play_compile():
    pass

# Generated at 2022-06-23 06:27:54.353941
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # Create a new class instance
    play = Play()
    # Get the value of the vars attribute
    result = play.get_vars()
    # Check the vars attribute is empty
    assert result == {}, 'The vars attribute is not empty'

    # Modify the vars attribute
    play.vars = {}
    # Get the value of the vars attribute
    result = play.get_vars()
    # Check the vars attribute is empty
    assert result == {}, 'The vars attribute is not empty'

    # Modify the vars attribute
    play.vars = {'name': 'test'}
    # Get the value of the vars attribute
    result = play.get_vars()
    # Check the vars attribute is not empty

# Generated at 2022-06-23 06:28:05.239271
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p1 = Play()
    p1.vars_files = "vars_files"
    assert p1.get_vars_files() == ['vars_files']
    
    p2 = Play()
    p2.vars_files = None
    assert p2.get_vars_files() == []
    
    p3 = Play()
    p3.vars_files = []
    assert p3.get_vars_files() == []

# Generated at 2022-06-23 06:28:18.119129
# Unit test for constructor of class Play
def test_Play():
    # Test without passing any argument.
    play = Play()
    assert play.deprecations == dict()
    assert play.handlers == []
    assert play.post_tasks == []
    assert play.pre_tasks == []
    assert play.roles == []
    assert play.tasks == []
    assert play.vars_files is None
    assert play.vars_prompt == []
    assert play.hosts is None
    assert play.remote_user is None
    assert play.tags == []
    assert play.gather_facts is False
    assert play.gather_subset == []
    assert play.any_errors_fatal is False
    assert play.max_fail_percentage == 0.0
    assert play.force_handlers is False
    assert play.serial is None

# Generated at 2022-06-23 06:28:20.789121
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert play.__repr__() == '_play_name'


# Generated at 2022-06-23 06:28:23.263838
# Unit test for method compile of class Play
def test_Play_compile():
  data = {}
  play = Play()
  play.load(data)
  assert play.compile() == block_list

# Generated at 2022-06-23 06:28:33.655307
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p.compile_order_setting = {'a': 2, 'b': 3, 'f': 0}
    p.name = 'clone_test'
    p.default_vars = {'a': 2, 'b': 3, 'f': 0}
    p.vars = {'a': 2, 'b': 3, 'f': 0}
    p.max_fail_percentage = 100
    p.deprecated_message = 'Test Play'
    p.deprecated_expiration = '2018-01-01'
    p.tags = ['test', 'clone']
    #p.notify = ['test', 'clone']
    p.no_log = True
    p.roles = [Role]
    p.default_vars = 'test'

# Generated at 2022-06-23 06:28:44.133637
# Unit test for method compile of class Play
def test_Play_compile():
    import json

    task_list = [{
            'name': 'print var',
            'debug': 'var={{ test_var }}'
        },
        {
            'name': 'print var',
            'debug': 'var={{ test_var }}'
        }
    ]

    block = Block.load(
        data={'tasks': task_list},
        play=Play(),
        variable_manager=VariableManager(),
        loader=DictDataLoader()
    )

    for task in block.block:
        task.implicit = True


# Generated at 2022-06-23 06:28:45.651917
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    print(play.compile())


# Generated at 2022-06-23 06:28:56.459430
# Unit test for method __repr__ of class Play

# Generated at 2022-06-23 06:28:58.785041
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.handlers = []
    assert play.get_handlers() == []


# Generated at 2022-06-23 06:29:07.634665
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    assert p.get_roles() == []
    p = Play().load(dict(
        gather_facts="yes",
        hosts=["local"],
        roles=[{'role': 'example', 'name': 'example'}]
    ), variable_manager=VariableManager(), loader=DataLoader())
    assert len(p.get_roles()) == 1
    assert p.get_roles()[0].role == 'example'
    assert p.get_roles()[0].name == 'example'
    # check if get_roles returns a copy, not the reference
    assert p._roles is not p.get_roles()


# Generated at 2022-06-23 06:29:15.977033
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    block1 = Block()
    block1.block = [task1, task2]
    block2 = Block()
    block2.block = [task3, task4]
    play.pre_tasks= [block1]
    play.tasks = [block2]
    play.post_tasks = []
    assert play.get_tasks() == [task1, task2, task3, task4]


# Generated at 2022-06-23 06:29:18.005357
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Create and initialize a new Play object
    p = Play()
    assert p.get_handlers() == p.handlers


# Generated at 2022-06-23 06:29:23.198928
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {'a': 'a', 'b': 'b'}
    assert play.get_vars() == {'a': 'a', 'b': 'b'}

    play.vars = None
    assert play.get_vars() == {}

# Generated at 2022-06-23 06:29:32.454713
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {"vars1": "value1", "vars2": "value2"}
    assert p.get_vars() == {"vars1": "value1", "vars2": "value2"}
    p.vars = {"vars1": "value1"}
    assert p.get_vars() == {"vars1": "value1"}
    p.vars = {"vars2": "value2"}
    assert p.get_vars() == {"vars2": "value2"}


# Generated at 2022-06-23 06:29:35.485118
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p is not None


# Generated at 2022-06-23 06:29:46.204738
# Unit test for method copy of class Play
def test_Play_copy():
    '''
    test class Play
    '''
    def myf():
        ''' local function for test
        '''
        new_obj = my_obj.copy()

        assert new_obj._loader is my_obj._loader, \
            "the function Play.copy make a shallow copy instead of a deep copy."
        assert new_obj._variable_manager is my_obj._variable_manager, \
            "the function Play.copy make a shallow copy instead of a deep copy."
        assert new_obj.ROLE_CACHE is not my_obj.ROLE_CACHE, \
            "the function Play.copy make a shallow copy instead of a deep copy."

# Generated at 2022-06-23 06:29:52.038976
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    obj = Play()

    # Attempt to call the method and assert that an exception was raised
    try:
        obj.compile_roles_handlers()
    except NotImplementedError:
        pass
    else:
        assert False, "An exception should have been raised"



# Generated at 2022-06-23 06:29:54.394466
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    result = play.serialize()
    assert result is not None


# Generated at 2022-06-23 06:29:57.399379
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    play.tasks = ['task1', 'task2']
    assert play.compile() == ['task1', 'task2']


# Generated at 2022-06-23 06:30:09.592419
# Unit test for method serialize of class Play
def test_Play_serialize():

  from ansible.parsing.dataloader import DataLoader
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.playbook.play_context import PlayContext
  from ansible.playbook.play import Play


  loader = DataLoader()
  variable_manager = VariableManager()
  inventory = InventoryManager(loader=loader, sources='localhost')
  inventory.parse_inventory()

  play_context = PlayContext(play=Play())
  play_context.network_os = 'ios'
  play_context.become = True
  play_context.become_method = 'enable'
  play_context.become_user = 'test_user'
  play_context.remote_addr = '192.0.2.0'

# Generated at 2022-06-23 06:30:20.627672
# Unit test for method compile of class Play
def test_Play_compile():
    def compile_mock(self):
        return [self.pre_tasks, self._compile_roles(), self.tasks, self.post_tasks]
    p = Play()
    p.compile = types.MethodType(compile_mock,p)
    p.pre_tasks = ['1']
    p.tasks = ['2']
    p.post_tasks = ['3']
    result = p.compile()
    assert result[0] == p.pre_tasks
    assert result[1] == p._compile_roles()
    assert result[2] == p.tasks
    assert result[3] == p.post_tasks

# Generated at 2022-06-23 06:30:32.769440
# Unit test for method copy of class Play
def test_Play_copy():
    p2 = Play()
    p1 = Play()
    p1.hosts = 'host1'
    p1.name = 'play'
    p1.roles = [p2]
    p2.name = 'role'
    p2.tasks = [Task()]

    p3 = p1.copy()
    assert p3.hosts == 'host1'
    assert p3.name == 'play'
    assert len(p3.roles) == 1
    assert p3.roles[0].name == 'role'
    assert len(p3.roles[0].tasks) == 1

# Only the 'hosts' are required (and must contain something)
Play.REQUIRED_FIELDS = ('hosts',)

# Register this class with the plugin loader so it can be loaded


# Generated at 2022-06-23 06:30:42.435227
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    import ansible.playbook.handler
    import ansible.playbook.task

    x = Play()
    handlers = []
    for i in range(5):
        handlers.append(ansible.playbook.handler.Handler())
    result = x.get_handlers()
    assert len(result) == 0
    tasks = []
    for i in range(5):
        tasks.append(ansible.playbook.task.Task())
    result = x.get_tasks()
    assert len(result) == 0
    #assert not ('Play.get_handlers()' in result)
    #assert not ('Play.get_tasks()' in result)


# Generated at 2022-06-23 06:30:49.919210
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    '''
    The method get_roles() is supposed to return the roles.
    '''
    # Initialise a new Play object
    p = Play()

    # Initialise a new Role object
    r = Role()

    # Set the attribute roles of p to [r]
    setattr(p, 'roles', [r])

    # Get the roles from p
    roles = p.get_roles()

    # Get the first element from roles
    first_element = roles[0]

    # Verify that roles is a list
    assert(isinstance(roles, list))
    # Verify that first_element is an instance from class Role
    assert(isinstance(first_element, Role))



# Generated at 2022-06-23 06:30:51.374725
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    assert True

# Generated at 2022-06-23 06:31:01.109008
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    import ansible.compat.tests.mock
    import ansible.compat.tests.module_loader

    # Test attributes: play 
    mock_play = ansible.compat.tests.mock.MagicMock()
    # Test attributes: name 
    mock_name = ansible.compat.tests.mock.MagicMock()
    # Test attributes: connection 
    mock_connection = ansible.compat.tests.mock.MagicMock()

    test_instance = Play()
#     def get_roles(self):
#         return self.roles[:]
    test_instance.roles = mock_connection
    assert test_instance.get_roles() == mock_connection



# Generated at 2022-06-23 06:31:14.726020
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    Task._default_action = 'nothing'
    Task._default_notify = []
    Task._default_delegate_to = 'localhost'
    Task._default_notify_type = 'default'
    Task._default_notify_flags = []
    Task._default_wait_for = []
    Task._default_when = []
    Task._default_listen = []
    Task

# Generated at 2022-06-23 06:31:18.926534
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p=Play()
    assert p.get_name() == p.__repr__()
    # Return type of function test_Play___repr__ is <type 'NoneType'>


# Generated at 2022-06-23 06:31:19.878592
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-23 06:31:29.188930
# Unit test for constructor of class Play
def test_Play():
    pass
#        # Create a new Play
#        new_play = Play()
#
#        # Verify that Play is of the correct type
#        assert isinstance(new_play, Play)
#
#        # Verify that Play contains an empty list for 'tasks'
#        assert isinstance(new_play.tasks, list)
#        assert len(new_play.tasks) == 0
#
#        # Create a second Play, with kwargs
#        new_play2 = Play(serial=0,
#                         max_fail_percentage=20.0,
#                         remote_user='user',
#                         strategy='linear',
#                         name='test_play',
#                         force_handlers=True)
#
#        # Verify that Play is of the correct type
#        assert isinstance(new_play2,

# Generated at 2022-06-23 06:31:38.922345
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.constants import DEFAULT_HANDLER_NAME

    pb = Play()

    # block 0
    block_0 = Block()
    block_0.name = DEFAULT_HANDLER_NAME
    task_0 = Task()
    task_0.action = 'debug'
    task_0.set_loader(DictDataLoader({}))
    task_0.args = {u'msg': u'handler_0'}
    block_0.block = [task_0]

    # role a
    role_a = Role()
    role_a.name = "role a"


# Generated at 2022-06-23 06:31:43.200833
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # create a play and check if it returns the list of handlers
    play = Play()
    play._ds = {'handlers': [], 'tasks': []}
    assert play.get_handlers() == []
    return True



# Generated at 2022-06-23 06:31:46.748512
# Unit test for method get_name of class Play
def test_Play_get_name():
    p=Play()
    p.name='test'
    assert p.name==p.get_name()


# Generated at 2022-06-23 06:31:58.317316
# Unit test for method serialize of class Play
def test_Play_serialize():

    # Construct a dummy class for class Play
    class DummyPlay(object):
        def __init__( self, args, kwargs ):
            self.args = args
            self.kwargs = kwargs
        def serialize( self ):
            return { 'args':self.args, 'kwargs':self.kwargs }

    # Construct a dummy class for class FieldAttribute
    class DummyFieldAttribute(object):
        def __init__( self, args, kwargs ):
            self.args = args
            self.kwargs = kwargs
        def serialize( self ):
            return { 'args':self.args, 'kwargs':self.kwargs }

    # Construct a dummy class for class Base

# Generated at 2022-06-23 06:32:09.034776
# Unit test for method deserialize of class Play

# Generated at 2022-06-23 06:32:20.200052
# Unit test for constructor of class Play
def test_Play():
    play = Play.load(dict(
        name="test",
        hosts=["localhost"],
        vars_prompt=[dict(name='vars_prompt_value', prompt='vars_prompt', private=True)],
        vars_files=[dict(name='vars_prompt_value', prompt='vars_prompt', private=True)],
        gather_facts=False,
        tasks=[]
    ))

    assert len(play.hosts) == 1
    assert play.hosts[0] == "localhost"
    assert play.gather_facts is False
    assert len(play.vars_prompt) == 1
    assert play.vars_prompt[0]['name'] == 'vars_prompt_value'

# Generated at 2022-06-23 06:32:29.110044
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()

    play.roles = [Role(name='role1'), Role(name='role2')]
    play.tasks = [Task()]

    result = play.compile()

    assert len(result) == 2  # compiled from roles (each 2 blocks) + 1 implicit flush block

    for b in result[:len(result)-1]:
        assert len(b) == 1  # each role is one block

    assert len(result[len(result)-1]) == 1 # implicit flush block also one task

    assert type(result[len(result)-1][0]) == HandlerTask

# Generated at 2022-06-23 06:32:29.813592
# Unit test for method compile of class Play
def test_Play_compile():
    pass

# Generated at 2022-06-23 06:32:34.807841
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = "test_Play___repr__"
    assert play.__repr__() == "test_Play___repr__"
    play = Play()
    play.hosts = "test_Play___repr__"
    assert play.__repr__() == "test_Play___repr__"
# Unit tests for method get_name of class Play

# Generated at 2022-06-23 06:32:44.838229
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    play = Play()
    play.name = "test"
    assert play.get_name() == "test"
    play.hosts = "localhost"
    play.name = ""
    assert play.get_name() == "localhost"
    play.hosts = ["localhost", "127.0.0.1"]
    play.name = ""
    assert play.get_name() == "localhost,127.0.0.1"
    play.hosts = None
    play.name = ""
    assert play.get_name() == ""

# Generated at 2022-06-23 06:32:47.881749
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    assert_raises(AnsibleError, Play().deserialize, {'hosts': {'127.0.0.1'}})


# Generated at 2022-06-23 06:32:50.349930
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    play.roles = []
    expected_result = []
    actual_result = play.get_roles()
    assert actual_result == expected_result


# Generated at 2022-06-23 06:33:02.797901
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    import copy

    playbook = dict(
        hosts = 'all',
        pre_tasks = [dict(action = 'action1', name = 'task1')],
        post_tasks = [dict(action = 'action2', name = 'task2')],
        roles = [],
    )

    play = Play()
    assert not hasattr(play, 'pre_tasks')
    assert not hasattr(play, 'post_tasks')
    play.load_data(copy.deepcopy(playbook))
    assert hasattr(play, 'pre_tasks')
    assert hasattr(play, 'post_tasks')
    assert len(play.pre_tasks) == 1
    assert len(play.post_tasks) == 1
    assert play.pre_tasks[0].action == 'action1'
   

# Generated at 2022-06-23 06:33:10.526873
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = {'name': 'existing_play', 'gather_facts': 'no', 'hosts': 'all', 'roles': [{'name': 'role1', 'vars': {}, 'playbooks': [], 'tasks': [], 'handlers': [], 'meta': '', 'default_vars': {}}], 'included_path': '', 'action_groups': {}, 'group_actions': {}}
    play = Play()
    play.deserialize(data)
    assert play.serialize() == data


# Generated at 2022-06-23 06:33:17.724025
# Unit test for method serialize of class Play
def test_Play_serialize():
    my_play = Play()
    my_play.hosts = "hosts"
    my_play.name = "name_Play"
    my_play.remote_user = "remote_user"
    my_play.connection = "connection"
    my_play.vars_prompt = "vars_prompt"
    my_play.become = "become"
    my_play.become_method = "become_method"
    my_play.become_user = "become_user"
    my_play.gather_facts = "gather_facts"
    my_play.tags = "tags"
    my_play.any_errors_fatal = "any_errors_fatal"
    my_play.serial = "serial"
    my_play.poll = "poll"
    my

# Generated at 2022-06-23 06:33:20.585713
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.name = 'test_Play'

    assert str(p) == 'test_Play'

# Generated at 2022-06-23 06:33:28.226984
# Unit test for method load of class Play
def test_Play_load():
    '''
    Unit test to check the load method of class Play
    '''
    my_play = Play()
    my_play.load("Hello World")
    assert(my_play.get_name() == 'Hello World')

# Generated at 2022-06-23 06:33:28.949269
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    pass

# Generated at 2022-06-23 06:33:29.857941
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    assert True

# Generated at 2022-06-23 06:33:30.599468
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    Play()

# Generated at 2022-06-23 06:33:31.805672
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert play.__repr__() == play.get_name()


# Generated at 2022-06-23 06:33:41.084922
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p
    assert p._play_hosts == set()
    assert p._plays == []
    assert p._dependency_map == {}
    assert p.name == ""
    assert p._included_conditional == None
    assert p._included_path == None
    assert p.ROLE_CACHE == {}
    assert p.only_tags == ('all',)
    assert p.skip_tags == ()
    assert p._action_groups == {}
    assert p._group_actions == {}


# Generated at 2022-06-23 06:33:53.009849
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # 
    class MockRole(object):
        # 
        @classmethod
        def get_handler_blocks(cls, play):
            return []
    MockRole.tasks = []
    MockRole.handlers = []
    MockRole.ROLE_NAME = 'TestRole'
    MockRole.TASK_ATTRIBUTE_OVERRIDES = {}
    MockRole.DEFAULT_HANDLER_MAPPING = {}
    root = create_temp_folder('test-Play-compile-roles-handlers')
    play = Play().load(dict(
        name="Play name",
        hosts=["all"],
        roles=[]
    ), variable_manager=VariableManager(), loader=DictDataLoader({}))
    # 
    

# Generated at 2022-06-23 06:33:54.638284
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # test_Play_compile_roles_handlers()
    assert True

# Generated at 2022-06-23 06:33:59.838287
# Unit test for method compile of class Play
def test_Play_compile():
    a = Play()
    a.__dict__['_tasks'] = [1,2,3,4]
    a.__dict__['_handlers'] = [4,3,2,1]
    
    assert a.compile()[0][0] == [1,2,3,4]
    assert a.compile()[-1][-1] == [4,3,2,1]