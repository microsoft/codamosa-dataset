

# Generated at 2022-06-23 06:23:59.163770
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    checkme = Play()
    checkme.deserialize({})



# Generated at 2022-06-23 06:24:04.958403
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    new_play = play.copy()
    assert isinstance(new_play, Play)
    assert play.ROLE_CACHE == new_play.ROLE_CACHE
    assert play._included_conditional == new_play._included_conditional
    assert play._included_path == new_play._included_path
    assert play._action_groups == new_play._action_groups
    assert play._group_actions == new_play._group_actions



# Generated at 2022-06-23 06:24:17.473168
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    ''' 
    test the method get_tasks of class Play
    '''


# Generated at 2022-06-23 06:24:24.091397
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()

    handlers_list = [Block(), Block(), Block()]

    play.handlers = handlers_list

    assert play.get_handlers() == handlers_list, "Play.get_handlers() failed"


# Generated at 2022-06-23 06:24:38.484578
# Unit test for constructor of class Play
def test_Play():
    loader = DictDataLoader({
        'playbook.yml': """
        - hosts: all
          gather_facts: true
          tasks:
          - name: ping
            ping:

        - hosts: all
          gather_facts: true
          vars_files:
          - group_vars/group1.yml
          - group_vars/group2.yml
          tasks:
          - name: ping
            ping:
        """,

        'group_vars/group1.yml': """
        ---
        var1: value1
        var2: value2
        var3: value3
        """,

        'group_vars/group2.yml': """
        ---
        var1: value1
        var2: value2
        var3: value3
        """
    })
   

# Generated at 2022-06-23 06:24:46.942273
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    results = []
    p = Play()

# Generated at 2022-06-23 06:24:59.100108
# Unit test for method get_vars of class Play
def test_Play_get_vars():

    # Setup playbook and host defined fact vars (will be combined into self.vars)
    playbook = ''
    host_vars = {}

    # Create new Play() object and initialize attributes.
    play = Play()
    play._ds = {'hosts': 'localhost', 'name': 'test-play'}
    play._loader = DataLoader()
    play.variable_manager = VariableManager()
    play.variable_manager._fact_cache = host_vars
    play.variable_manager.set_playbook_basedir(os.path.dirname(playbook))
    play.vars = {'key': 'value'}
    play.vars_prompt = {'prompt_var': {'name': 'prompt_var', 'prompt': 'Enter a value:'}}

    # Invoke get_vars and check

# Generated at 2022-06-23 06:25:00.121517
# Unit test for constructor of class Play
def test_Play():
    play = Play()


# Generated at 2022-06-23 06:25:09.023512
# Unit test for method get_name of class Play
def test_Play_get_name():
    print("*** Start Unit Test for Play.get_name() ***")
    host_type = "host"
    host_name = "host_name"
    play_name = "play_name"

    test_Play = Play()
    test_Play.host_type = host_type

    # Test for an existing name
    test_Play.name = play_name
    if test_Play.get_name() != play_name:
        assert False, "Play.get_name(): fail to get name for an existing name"

    # Test for a non-existing name
    test_Play.hosts = host_name
    test_Play.name = None
    if test_Play.get_name() != host_name:
        assert False, "Play.get_name(): fail to get name for a non-existing name"


# Generated at 2022-06-23 06:25:15.330502
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    
    # Test no roles in play
    ret = play.compile_roles_handlers()
    
    assert ret == []

    # Test roles in play
    play._roles = [Role(name="role1"), Role(name="role2")]

    role1 = play._roles[0]
    role2 = play._roles[1]

    role1._handler_blocks = [ Task(action="handler1", name="handler1", play=play) ]
    role2._handler_blocks = [ Task(action="handler2", name="handler2", play=play), Task(action="handler3", name="handler3", play=play) ]

    ret = play.compile_roles_handlers()


# Generated at 2022-06-23 06:25:26.626579
# Unit test for method deserialize of class Play
def test_Play_deserialize():
	play = Play()

# Generated at 2022-06-23 06:25:37.993336
# Unit test for method compile of class Play

# Generated at 2022-06-23 06:25:42.118019
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    new_me = play.copy()
    new_me.hosts = 'hostname'
    assert new_me.hosts == 'hostname'
    assert play.hosts != 'hostname'



# Generated at 2022-06-23 06:25:53.884974
# Unit test for method serialize of class Play

# Generated at 2022-06-23 06:25:55.085460
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Do not remove this function, it is used in the tests
    return

# Generated at 2022-06-23 06:26:02.143023
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # test preprocess_data to convert 'user' to 'remote_user'
    ds = {'foo': 'bar', 'user': 'joe', 'tasks': [{'name': 'test'}]}
    data2 = Play().preprocess_data(ds)
    assert data2 == {'foo': 'bar', 'remote_user': 'joe', 'tasks': [{'name': 'test'}]}
    # test with preprocess_data to convert 'hosts' shortcut to 'hosts'
    ds = 'all'
    data2 = Play().preprocess_data(ds)
    assert data2 == {'hosts': 'all'}

    # test preprocess_data to convert 'hosts' shortcut to 'hosts'
    ds = ['foo', 'bar', 'baz']

# Generated at 2022-06-23 06:26:04.050009
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    obj = Play()
    assert repr(obj) == 'None'


# Generated at 2022-06-23 06:26:14.932025
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print("Test of get_vars_files")
    p = Play()
    p.vars_files = ["toto.yaml", "titi.yaml"]
    file_list = p.get_vars_files()
    assert(file_list == ["toto.yaml", "titi.yaml"])
    p.vars_files = None
    file_list = p.get_vars_files()
    assert(file_list == [])
    p.vars_files = "toto.yaml"
    file_list = p.get_vars_files()
    assert(file_list == [p.vars_files])

# Generated at 2022-06-23 06:26:20.254811
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # Init mock
    var_manager = MagicMock()

    # Prepare test data
    play1 = Play.load(dict(vars=dict(x=42)), variable_manager=var_manager)

    # Test method
    result = play1.get_vars()
    assert result == {'x': 42}



# Generated at 2022-06-23 06:26:23.442350
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    #from ... import Play
    #play = Play()
    #return play.get_handlers()

    pass  # nothing to test here



# Generated at 2022-06-23 06:26:26.441766
# Unit test for method get_name of class Play
def test_Play_get_name():
    play=Play()
    assert play.get_name()==''

    play.name='play_name'
    assert play.get_name()=='play_name'

# Generated at 2022-06-23 06:26:37.684883
# Unit test for method copy of class Play
def test_Play_copy():
    # Set the role cache to a known value
    role_cache = {
        'role1': Role.load(data='role1'),
        'role2': Role.load(data='role2'),
    }
    play = Play()
    play.ROLE_CACHE = role_cache
    # Set all the extra fields so they're present in the copy
    play._included_conditional = 'conditional'
    play._included_path = '/path/to/playbook.yml'
    play._action_groups = {
        'group1': [
            {'host1': 'action1'},
            {'host2': 'action2'},
        ],
        'group2': [
            {'host3': 'action3'},
        ],
    }

# Generated at 2022-06-23 06:26:45.113362
# Unit test for method load of class Play
def test_Play_load():
    # Test with vars
    play = Play()
    play.load(vars='{"var1": 1, "var2": true, "var3": "Hello"}')
    assert play.vars == {u'var1': 1, u'var2': True, u'var3': u'Hello'}
    # Test with name and vars
    play.load(name="test", vars='{"var1": 1, "var2": true, "var3": "Hello"}')
    assert play.name == u'test'
    assert play.vars == {u'var1': 1, u'var2': True, u'var3': u'Hello'}

# Generated at 2022-06-23 06:26:50.183458
# Unit test for method copy of class Play
def test_Play_copy():
    assert True

    instance = Play()
    instance.ROLE_CACHE = {'a': 'aa', 'b': 'bb'}
    instance._included_conditional = 'conditional'
    instance._included_path = 'included_path'
    instance._action_groups = {'a', 'b'}
    instance._group_actions = {'b', 'a'}

    new_instance = instance.copy()

    assert new_instance.ROLE_CACHE == {'a': 'aa', 'b': 'bb'}
    assert new_instance._included_conditional == 'conditional'
    assert new_instance._included_path == 'included_path'
    assert new_instance._action_groups == {'a', 'b'}

# Generated at 2022-06-23 06:26:54.330603
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    test_play = Play.load(dict(name=['Test play'], hosts=['localhost'], gather_facts="no"), variable_manager=None, loader=None)
    assert test_play.get_vars() == {'gather_facts': 'no', 'name': 'Test play'}


# Generated at 2022-06-23 06:27:05.900113
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    
    # Test 1.
    play.pre_tasks = []
    play.tasks = [{'include': u'test_role/main.yml'}]
    play.post_tasks = []
    
    results_1 = [{'include': u'test_role/main.yml'}]
    
    assert play.get_tasks() == results_1, "Test 1 failed"
    
    # Test 2.
    play.pre_tasks = []
    play.tasks = []
    play.post_tasks = []
    
    results_2 = []
    
    assert play.get_tasks() == results_2, "Test 2 failed"
    
    # Test 3.

# Generated at 2022-06-23 06:27:07.863392
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    l = []
    for task in p.get_tasks():
        l.append(task)
    print(l)

# Generated at 2022-06-23 06:27:13.420805
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    #Test for User to Remote User
    doc="""
    - name: test
      hosts: all
      user: some_user
    """
    p = Play()
    data = Play.load(doc, None, None, None)

    #Test for ensure_local to local_action
    doc1 = """
    - name: test
      hosts: all
      tasks:
      - name: test
        ensure_local:
        - some_user
      vars_prompt:
        - name: some
          prompt: yes
    """
    p = Play()
    data = Play.load(doc1, None, None, None)
    assert data._ds['tasks'][0]['local_action'][0] == 'some_user'

# Generated at 2022-06-23 06:27:17.608587
# Unit test for method compile of class Play
def test_Play_compile():

    # Play_compile takes 0 positional arguments but 1 was given
    # Play_compile takes 0 positional arguments but 1 was given
    assert False == pytest.Test_Play_compile(0)

# Generated at 2022-06-23 06:27:21.665443
# Unit test for method load of class Play
def test_Play_load():
    # Load module: ansible/modules/system/service
    # Load module: ansible/modules/system/ping
    # Load module: ansible/modules/system/setup
    pass

# Generated at 2022-06-23 06:27:31.866911
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test that the task list returned by get_tasks() is correct
    # for a Play instance

    # Create an empty Play object
    p = Play()

    # Create a simple block with two tasks

# Generated at 2022-06-23 06:27:38.274525
# Unit test for method deserialize of class Play

# Generated at 2022-06-23 06:27:42.484345
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {'blah': 5}
    assert isinstance(p.get_vars(), dict)
    assert 'blah' in p.get_vars()

# Generated at 2022-06-23 06:27:53.476747
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # instance is Play
    ######################################################
    data = dict()
    data['hosts'] = ['192.168.0.1']
    data['vars'] = dict()
    data['tasks'] = []
    data['user'] = 'myuser'
    data['vars_prompt'] = dict()
    data['name'] = ''
    data['remote_user'] = 'myuser'
    data['roles'] = dict()
    data['handlers'] = []

    # test missing argument data
    ######################################################
    with pytest.raises(AnsibleAssertionError) as excinfo:
        Play.preprocess_data(None)

# Generated at 2022-06-23 06:27:56.942043
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {'a':1}
    assert play.get_vars() == {'a': 1}


# Generated at 2022-06-23 06:28:01.631560
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # simple test of method get_vars of class Play
    play = Play()
    play.vars = dict(a='b')

    assert play.get_vars() == dict(a='b')
    assert play.get_vars() is not play.vars



# Generated at 2022-06-23 06:28:14.641903
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # set up
    data = {}
    p = Play()
    p.post_validate_data(data=data)

    assert data == {}, '''Should be empty'''

    # test
    data['user'] = 'jack'
    p.post_validate_data(data=data)

    assert data['remote_user'] == 'jack', '''Should contain remote_user with the same value as user'''

    # test
    data['user'] = 'jack'
    data['remote_user'] = 'jill'
    p.post_validate_data(data=data)

    assert data['user'] is None and data['remote_user'] == 'jill', '''Should ignore user'''


# Generated at 2022-06-23 06:28:27.951008
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.parsing.dataloader import DataLoader

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play


# Generated at 2022-06-23 06:28:34.690440
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_obj = Play()
    test_name = 'test_Play_deserialize'
    print("TEST {}()".format(test_name))

    test_obj.deserialize({"hosts": "localhost"})
    assert test_obj._hosts == "localhost"

    print("OK {}".format(test_name))

if __name__ == "__main__":
    test_Play_deserialize()

# Generated at 2022-06-23 06:28:45.713950
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # list of non-task objects, this should return an empty list
    assert Play().get_tasks() == []
    # list of non-task objects, this should return an empty list
    assert Play().get_tasks() == []
    # list of tasks, this should return the tasks
    tasks = [True, False, "task1", "task2"]
    assert Play(tasks=tasks).get_tasks() == tasks
    # list of tasks, this should return the tasks
    pre_tasks = [False, "task1", "task2"]
    tasks = [True, False, "task3", "task4"]
    post_tasks = [False, "task1", "task2"]
    assert Play(pre_tasks=pre_tasks, tasks=tasks, post_tasks=post_tasks).get_

# Generated at 2022-06-23 06:28:56.460018
# Unit test for method load of class Play
def test_Play_load():
    # Check Play.load() with simple "ok" tasks.
    # Plays are loadable from file or dict-type obj
    expected = ['asdf', 'xyz']
    d1 = {'hosts': 'localhost:2222', 'tasks': [
        {'name': 'asdf', 'action': 'command', 'args': {'_raw_params': 'ls'}},
        {'name': 'xyz', 'action': 'command', 'args': {'_raw_params': 'ls -l'}}
    ]}

    # Test with dict obj
    play1 = Play.load(d1)
    assert play1.get_name() == 'localhost:2222'
    assert play1.hosts == 'localhost:2222'
    assert play1.tasks[0].action == 'command'
    assert play

# Generated at 2022-06-23 06:29:02.725992
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play1 = Play()
    play2 = Play()
    play3 = Play()
    play4 = Play()
    play5 = Play()
    play6 = Play()

    play1.vars_files = [{'vars_file':'test'}, {'vars_file':'test2'}]
    play2.vars_files = {'vars_file':'test'}
    play3.vars_files = 'test'
    play4.vars_files = [{'vars_file':'test'}]
    play5.vars_files = None
    play6.vars_files = []

    assert play1.get_vars_files() == [{'vars_file':'test'}, {'vars_file':'test2'}]
    assert play2

# Generated at 2022-06-23 06:29:04.020224
# Unit test for method load of class Play
def test_Play_load():
    # Not working.
    pass

# Generated at 2022-06-23 06:29:06.164584
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    ds = {}
    result = p.preprocess_data(ds)
    assert isinstance(result, dict)

# Generated at 2022-06-23 06:29:15.036947
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    test_Play_get_handlers.my_host = dict(name = 'my_host')
    test_Play_get_handlers.my_host2 = dict(name = 'my_host2')
    test_Play_get_handlers.my_hosts = [test_Play_get_handlers.my_host['name'], test_Play_get_handlers.my_host2['name']]
    test_Play_get_handlers.my_play = Play()
    test_Play_get_handlers.my_play.name = 'test_play'
    test_Play_get_handlers.my_play.hosts = test_Play_get_handlers.my_hosts
    test_Play_get_handlers.my_play.roles = []

# Generated at 2022-06-23 06:29:17.927605
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    assert Play().preprocess_data(None) == {}
    assert Play().preprocess_data({'some': 'data'}) == {'some': 'data'}

# Generated at 2022-06-23 06:29:19.972290
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    returns nothing
    '''
    pass

# Generated at 2022-06-23 06:29:26.367708
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.set_loader(DictDataLoader({}))
    handlers_bck = play.handlers
    play.handlers = [{"name": "test"}]
    assert play.get_handlers() == [{"name": "test"}]
    if handlers_bck:
        play.handlers = handlers_bck



# Generated at 2022-06-23 06:29:36.592147
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import ansible.constants as C
    import ansible.utils.vars as vars_m
    import copy

    # Construct the params to be passed to the Play module
    name = 'test'
    hosts = None
    try:
        hosts = vars_m.ansible_var__['inventory_hostname']
    except KeyError:
        hosts = vars_m.ansible_var__['inventory_hostname'] = 'hosts'

    roles = []
    for i in range(0, 3):
        r = Role()
        r.name = 'role%d' % i
       

# Generated at 2022-06-23 06:29:40.651442
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play._handlers = 'mock_handlers'  # private attr needs setter
    handlers = play.get_handlers()
    assert handlers == 'mock_handlers'

# Generated at 2022-06-23 06:29:41.481654
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-23 06:29:56.967940
# Unit test for method compile of class Play
def test_Play_compile():
    variable_manager = VariableManager()
    loader = DataLoader()
    play_ds = dict(
        name="Ansible Play",
        hosts="all",
        gather_facts="no",
        tasks=[
            dict(action=dict(module="shell", args="ls")),
            dict(action=dict(module="debug", args=dict(msg="{{_username}}")))
        ]
    )
    play = Play().load(play_ds, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 06:30:02.512833
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    o = dict(host='example.com', user='me')
    n = play.preprocess_data(o)
    assert n == dict(host='example.com', remote_user='me')

    o = dict(host='example.com', user='me', remote_user='you')
    with pytest.raises(AnsibleParserError, match="both 'user' and 'remote_user' are set for this play"):
        play.preprocess_data(o)


# Generated at 2022-06-23 06:30:03.180293
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-23 06:30:03.842698
# Unit test for method load of class Play
def test_Play_load():
    assert True

# Generated at 2022-06-23 06:30:15.808029
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible import errors
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    import tempfile
    import os.path
    import shutil


    #
    # Test setup
    #

    class TestRoleDef(RoleDefinition):
        def _load_role_data(self):
            role_vars = self.role_data.get('vars', {})
            if role_vars is not None:
                role_vars = {}
            role_vars['pre_tasks'] = list()
            role_vars['post_tasks'] = list()
            role_vars['tasks'] = list()
            role_vars['handlers'] = list()

            # Add just 1 of each task type.

# Generated at 2022-06-23 06:30:20.257002
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # Create Play instance with test data
    p = Play()
    p._ds = {'vars': {'x': 1, 'y': 2, 'z': 3}}
    # Test method
    v = p.get_vars()
    assert v == {'x': 1, 'y': 2, 'z': 3}
    # Verify that it's a copy
    v['x'] = 10
    assert p.get_vars() == {'x': 1, 'y': 2, 'z': 3}


# Generated at 2022-06-23 06:30:24.085767
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    """Play: get_handlers"""
    play = Play()
    play.get_handlers()


# Generated at 2022-06-23 06:30:25.781567
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    assert p.get_vars() == {}


# Generated at 2022-06-23 06:30:29.520917
# Unit test for method serialize of class Play
def test_Play_serialize():
    play1 = Play()
    play1.name = "test"
    play1.hosts = "all"
    play1.remote_user = "renwu"

    ret = play1.serialize()
    print(ret)


# Generated at 2022-06-23 06:30:39.461992
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play_ds = {
        'hosts': 'localhost',
        'vars': {
            'var1': 'val1',
            'var2': 'val2',
            'var3': 'val3',
        },
    }

    variable_manager = InventoryVariableManager()
    loader = DataLoader()
    play_obj = Play().load(play_ds, variable_manager=variable_manager, loader=loader)

    vars = play_obj.get_vars()

    assert isinstance(vars, dict)
    assert vars == {
        'var1': 'val1',
        'var2': 'val2',
        'var3': 'val3',
    }



# Generated at 2022-06-23 06:30:47.213945
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from collections import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    play = Play()
    loader = DataLoader()
    play.loader = loader
    play.vars_prompt = None
    play.vars_files = None
    play.default_vars = False
    play.connection = 'smart'
    play.gather_facts = 'yes'
    play.max_fail_percentage = None
    play.accelerate = None
    play.no_log = False
    play._no_log_task_fields = set()
    play.hosts = None
    play.name = ''
    play.tags = ['all']
    play.tasks = []
    play.tasks_include = []
    play.post_

# Generated at 2022-06-23 06:30:57.417500
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # list.append method is called in the get_roles method in Play class
    # So the list of roles is empty when the method is called
    play = Play()
    assert play.get_roles() == []
    role = Role()
    role.name = 'test_role'
    play.roles.append(role)
    assert play.get_roles() == [role]
    # create another role with the same name
    role2 = Role()
    role2.name = 'test_role'
    play.roles.append(role2)
    assert play.get_roles() == [role2]


# Generated at 2022-06-23 06:31:10.606006
# Unit test for method get_handlers of class Play

# Generated at 2022-06-23 06:31:16.099994
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play._ds = {
        'handlers': [
            'main.yml'
        ],
        'hosts': 'localhost',
        'name': 'Play',
        'pre_tasks': [],
        'post_tasks': [],
        'tasks': [
            {
                'Ping': {
                    'action': 'ping'
                }
            }
        ],
        'user': 'root'
    }


# Generated at 2022-06-23 06:31:19.010521
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = dict(host='localhost',port=22)
    assert play.get_vars() == dict(host='localhost', port=22)



# Generated at 2022-06-23 06:31:28.826607
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # test_Play_deserialize() {
    #   play = AnsiblePlay()
    #   data = {'roles': [{'name': 'role'}], 'name': 'play'}
    #   play.deserialize(data)
    #   assert len(play.get_roles()) == 1
    #   assert play.name == 'play'
    # }
    play = AnsiblePlay()
    data = {'roles': [{'name': 'role'}], 'name': 'play'}
    play.deserialize(data)
    assert len(play.get_roles()) == 1
    assert play.name == 'play'



# Generated at 2022-06-23 06:31:31.495961
# Unit test for method compile of class Play
def test_Play_compile():
  play = Play()
  play.name = 'test'
  play.hosts = 'localhost'
  play.roles = [Role()]
  play.tasks = [Block()]
  assert play.compile()

# Generated at 2022-06-23 06:31:40.812055
# Unit test for method load of class Play
def test_Play_load():
    import __main__
    import sys
    import ansible.playbook

    # Create an instance of class Play to test
    p = Play()

    # Check if the test configuration is correct
    if not hasattr(__main__, 'ansible_module_my_test'):
        raise AssertionError("ansible_module_my_test not found in __main__")
    if not hasattr(ansible.playbook, 'CLI'):
        raise AssertionError("CLI not found in ansible.playbook")

    # Create an instance of class CLI to test
    ansible.playbook.CLI(['-k'])
    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create the necessary Ansible objects to initialize the class Play

# Generated at 2022-06-23 06:31:41.611119
# Unit test for method copy of class Play
def test_Play_copy():
    pass

# Generated at 2022-06-23 06:31:49.812635
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = {'hosts': 'all',
            'name': 'Test play',
            'tasks': [{'debug': {'msg': 'test'}}],
            'vars': {'test_var': 'test_value'},
            'roles': [{'name': 'test1',
                       'vars': {'role_var': 'test_value'}
                      },
                      {'name': 'test2',
                       'vars': {'role_var': 'test_value'}
                      }
                     ]
            }
    p = Play()
    p.load_data(data)
    serialized_data = p.serialize()
    assert 'roles' in serialized_data
    assert len(serialized_data['roles']) == 2

# Generated at 2022-06-23 06:31:55.682132
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    data = {'hosts': '127.0.0.1', 'connection': 'local', 'name': 'play1'}
    play.deserialize(data)
    assert play.vars == {}
    assert play.hosts == '127.0.0.1'
    assert play.name == 'play1'
    assert play.connection == 'local'

# Generated at 2022-06-23 06:32:00.816853
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
        play = Play()
        play.tasks = [
            {
                'name': 'Show version',
                'command': '/usr/bin/showversion'
            },
            {
                'name': 'Show uptime',
                'command': '/usr/bin/showuptime'
            }
        ]
        assert play.get_tasks() == [
            [
                {
                    'name': 'Show version',
                    'command': '/usr/bin/showversion'
                },
                {
                    'name': 'Show uptime',
                    'command': '/usr/bin/showuptime'
                }
            ]
        ]

if __name__ == '__main__':
    pytest.main(['-v', __file__])


# Generated at 2022-06-23 06:32:10.192898
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    set_module_args({
        'hosts': 'localhost',
        'name': 'test_name',
        'connection': 'local',
    })

    # Mock the actual module.
    # Load tasks.yml for testing.
    tasks = [
        {'action': {'module': 'debug', 'msg': 'Hello World'}},
        {'action': {'module': 'copy', 'src': 'test/copy/src', 'dest': 'test/copy/dest'}}
    ]

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = tasks
    )

    play = Play().load(play_source, variable_manager=None, loader=None)
    tasks = play.get_tasks()

# Generated at 2022-06-23 06:32:14.832801
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    play.roles = [1, 2, 3]
    assert play.get_roles() == play.roles


# Generated at 2022-06-23 06:32:16.536667
# Unit test for method compile of class Play
def test_Play_compile():
    # False Positive expected as the method compile of class Play is tested in another test
    assert True


# Generated at 2022-06-23 06:32:17.877781
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p is not None

# Generated at 2022-06-23 06:32:20.137684
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = 'The name of a play'
    assert play.__repr__() == 'The name of a play'

# Generated at 2022-06-23 06:32:21.772702
# Unit test for method copy of class Play
def test_Play_copy():
    cls = Play()
    assert isinstance(cls.copy(), Play)

# Generated at 2022-06-23 06:32:23.243924
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass



# Generated at 2022-06-23 06:32:30.079780
# Unit test for method get_roles of class Play
def test_Play_get_roles():

	
	# Instantiate a Play object
	play = Play()
	# checked by assert
	play.__roles__ = [ {'role': 'rolename'}, {'role': 'rolename'} ]
		
	assert play.get_roles() == [ {'role': 'rolename'}, {'role': 'rolename'} ]
	
	# Check the raise condition
	# checked by assert
	play.__roles__ = None
	try:
		play.get_roles()
	except:
		assert True

	# Instantiate a Role object 
	role = Role()
	role.serialize()
	# checked by assert
	role.__handlers__ = [ ]
	
	assert role.get_handler_blocks() == []
	
	# Check the raise condition
	# checked

# Generated at 2022-06-23 06:32:43.238292
# Unit test for method compile of class Play
def test_Play_compile():
    '''
    Unit test for method compile of class Play
    '''

    #####################################################################
    #
    #                PREPARE
    #
    #####################################################################

    # Create an instance of the Play class
    play = Play()

    # Create an instance of the RoleInclude class
    role = RoleInclude()

    # Create an instance of the Block class
    block = Block()

    # Create an instance of the Handler class
    handler = Handler()

    # Add the RoleInclude instance to the roles list of Play instance
    play.roles.append(role)

    # Add the Block instance to the pre_tasks list of Play instance
    play.pre_tasks.append(block)

    # Add the Block instance to the tasks list of Play instance
    play.tasks.append(block)

    # Add the Block instance

# Generated at 2022-06-23 06:32:46.133965
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # Create the object
    p = Play()

    # Check the vars are an empty dict
    assert p.get_vars() == {}


# Generated at 2022-06-23 06:32:49.505349
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    assert Play().get_vars_files() == []
    assert Play(vars_files=[1,2]).get_vars_files() == [1,2]
    assert Play(vars_files=1).get_vars_files() == [1]


# Generated at 2022-06-23 06:32:51.319956
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    compare_result = p.get_roles()
    assert compare_result == None


# Generated at 2022-06-23 06:32:52.926879
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers() == []

# Generated at 2022-06-23 06:32:54.588428
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = 'test.yml'
    assert p.get_vars_files() == ['test.yml']


# Generated at 2022-06-23 06:33:04.603548
# Unit test for method serialize of class Play
def test_Play_serialize():
	play = Play()
	play._ds = {}
	play._ds['roles'] = ['role1', 'role2', 'role3']
	play.ROLE_CACHE = {'role1' : 'role_cache1', 'role2' : 'role_cache2'}
	play._action_groups = {'action_group1' : 'ag1', 'action_group2' : 'ag2'}
	play._group_actions = {'group_action1' : 'ga1', 'group_action2' : 'ga2'}
	play.serialize()



# Generated at 2022-06-23 06:33:08.272746
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    play.roles = [ "role1", "role2" ]
    result = play.get_roles()
    assert result == [ "role1", "role2" ]

# Generated at 2022-06-23 06:33:11.765280
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # TODO: this test is not very good
    play = Play()
    play.vars = {'key': 'value'}
    result = play.get_vars()
    assert result == {'key': 'value'}

# Generated at 2022-06-23 06:33:17.469947
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    player = Play()
    roles = [
        Role(name='role-1'),
        Role(name='role-2'),
        Role(name='role-3')
    ]
    player.roles = roles
    assert player.get_roles() is not roles
    assert player.get_roles() == roles


# Generated at 2022-06-23 06:33:34.250963
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.scoped import ScopedVars
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager

    fake_loader = DictDataLoader({})
    fake_variable_manager = VariableManager(loader=fake_loader)

    fake_inventory = InventoryManager(loader=fake_loader, sources=["localhost"])
    fake_inventory.subset("my_subset")
    fake_inventory.subscriptions.add("my_subset", "localhost")

# Generated at 2022-06-23 06:33:45.532509
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    vars_data_1 = {'var1': 'value1'}
    vars_data_2 = {'var2': 'value2'}
    vars_data_3 = {'var3': 'value3'}
    play = Play()
    play.vars = vars_data_2
    play._ds = {'vars': '', 'vars_files': ''}
    if play.get_vars() != {'var2': 'value2'}:
        raise AssertionError()
    play._ds['vars'] = vars_data_1
    if play.get_vars() != vars_data_1:
        raise AssertionError()
    play._ds['vars_files'] = vars_data_3

# Generated at 2022-06-23 06:33:50.369216
# Unit test for method compile of class Play
def test_Play_compile():
    name = 'test_Play_compile'
    def test():
        result = Play()
        result.compile()
    if hasattr(Play, 'compile'):
        return test
    else:
        return pytest.skip(name)


# Generated at 2022-06-23 06:34:01.027167
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.loader import VarsModule
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.varmodules = {'vars': VarsModule}
    play = Play.load(dict(hosts=dict(hostvars=dict(key="value")), vars=dict(key="value"), vars_files=dict(key="value")), variable_manager)
    data = play.serialize()
    assert data == dict(vars=dict(key="value"), vars_files=dict(key="value"))
    assert isinstance(data['vars'], dict)
    assert isinstance(data['vars_files'], dict)