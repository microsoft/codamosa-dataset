

# Generated at 2022-06-23 06:24:08.208690
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert isinstance(play, Play)
    assert play.name is None
    assert play.hosts is None
    assert play.remote_user is None
    assert play.connection is C.DEFAULT_TRANSPORT
    assert play.port == C.DEFAULT_REMOTE_PORT
    assert play.gather_facts is True
    assert play.sudo is False
    assert play.sudo_user is None
    assert play.become is False
    assert play.become_method is 'sudo'
    assert play.become_user is None
    assert play.vars_prompt is None
    assert play.vars_files is None
    assert play.vars_from_files is None
    assert play.vars_from_inventory_sources is None
    assert play.tags == []

# Generated at 2022-06-23 06:24:18.344954
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    host_list = [u'm1', u'm2']
    play = Play()
    ds = dict(
        name=u'TestPlaybook1',
        hosts=host_list,
        gather_facts=u'no',
        become=False,
        become_user=u'',
        become_method=u'',
        vars=dict(
            some_var=u"value1",
            other_var=u"value2"
        )
    )
    res = play.load(ds)
    vars = play.get_vars()
    assert vars.get(u'some_var') == u'value1'
    assert vars.get(u'other_var') == u'value2'



# Generated at 2022-06-23 06:24:21.679368
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # TODO: Implement this test
    return True

# Generated at 2022-06-23 06:24:28.479759
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play._ds = {
        'user': 'root',
        'hosts': 'localhost',
        'tasks': [{'name': 'install something', 'apt': 'name=something state=present'}]
    }
    play.preprocess_data(play._ds)
    assert 'user' not in play._ds
    assert 'root' in play._ds['remote_user']
    assert len(play._ds) == 3


# Generated at 2022-06-23 06:24:37.945221
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    playbook = AnsiblePlaybook()
    data = {}
    data['user'] = 'remote_user'
    play = playbook.load(data, variable_manager=None, loader=None).get_plays()[0]
    # Expected result
    result = Play()
    result.post_validate = Mock(return_value=None)
    # Actual result
    play.post_validate = Mock(return_value=None)
    actual = play.preprocess_data(data)
    # The results does not match
    assert actual == result.preprocess_data(data), actual

# Generated at 2022-06-23 06:24:45.410060
# Unit test for method serialize of class Play
def test_Play_serialize():
    play1 = Play()
    play1.name = "Master Play"
    play2 = Play()
    play2.name = "Slavery Play"
    play1.hosts = play2.hosts = 'all'
    play1.vars = play2.vars = { 'foo': 'bar' }
    play1.roles = [play2]
    deserialized = play1.serialize()
    print("Serialized data: ", deserialized)
    play3 = Play()
    play3.deserialize(deserialized)
    print("Deserialized data: ", play3.serialize())


# Generated at 2022-06-23 06:24:58.341790
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    role_1 = Role()
    role_1.handlers = [{'name': 'role_1_handler_1'}, {'name': 'role_1_handler_2'}, {'name': 'role_1_handler_3'}]
    role_2 = Role()
    role_2.handlers = [{'name': 'role_2_handler_1'}, {'name': 'role_2_handler_2'}, {'name': 'role_2_handler_3'}]
    play = Play()
    play.roles = [role_1, role_2]

    handlers = play.compile_roles_handlers()
    assert isinstance(handlers, list)

# Generated at 2022-06-23 06:25:01.987220
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.tasks = ["1","2"]
    play.post_tasks = ["3","4"]
    play.pre_tasks = ["5","6"]
    res = play.get_tasks()
    assert res == ["1","2","3","4","5","6"]

# Generated at 2022-06-23 06:25:10.805011
# Unit test for method compile of class Play
def test_Play_compile():
    """
    Tests for the Play.compile() method
    """
    from ansible.utils.sentinel import Sentinel
    from ansible.playbook.block import Task
    from ansible.playbook.role import TaskInclude
    from ansible.playbook.block import Block

    # create some 'blocks' to add to the Play
    block0 = Block()
    block1 = Block()
    block2 = Block()
    block3 = Block()
    block4 = Block()
    block5 = Block()
    block6 = Block()

    # add tasks to the blocks
    block0.block = [Task()]
    block1.block = [Task()]
    block2.block = [Task()]
    block3.block = [Task()]
    block4.block = [Task()]

# Generated at 2022-06-23 06:25:11.494937
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert True

# Generated at 2022-06-23 06:25:14.028168
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    #test data
    ds = {
        'user': "test_user"
    }
    #test
    p = Play()
    ds_new = p.preprocess_data(ds)
    #check
    assert ds_new == {'remote_user': 'test_user'}


# Generated at 2022-06-23 06:25:18.026699
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.name = 'test_name'
    assert p.__repr__() == 'test_name'


# Generated at 2022-06-23 06:25:28.320787
# Unit test for method copy of class Play
def test_Play_copy():
    my_vars = dict(a=dict(b=2))
    p = Play.load(dict(
        name='test',
        hosts='testhost',
        user='fake_user',
        vars=my_vars,
        roles=[
            dict(name='fake_role', tasks=[
                dict(action=dict(module='shell', args='echo hi')),
            ]),
        ],
    ))
    p_copy = p.copy()
    assert p_copy.name == 'test'
    assert p_copy.hosts == 'testhost'
    assert p_copy.user == 'fake_user'
    assert p_copy.vars == my_vars
    assert len(p_copy.roles) == 1
    assert len(p_copy.roles[0].tasks) == 1


# Generated at 2022-06-23 06:25:36.215356
# Unit test for method compile of class Play
def test_Play_compile():
    # Create a list of items to use in the test
    item_list = [
        {"a": 1},
        {"a": 2},
        {"a": 3}
    ]
    for item in item_list:
        # Create a test object
        test_object = Play()
        # Get the result of method compile
        result = test_object.compile()
        # Compute the expectation
        # Currently there are no assertions. This can change as the code is modified.
        test_object = Play()
        test_object.compile()


# Generated at 2022-06-23 06:25:37.343221
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-23 06:25:39.168827
# Unit test for method load of class Play
def test_Play_load():
    # TODO: Implement test_Play_load
    pass


# Generated at 2022-06-23 06:25:42.275732
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = 'test-repr'
    assert play.__repr__() == 'test-repr'



# Generated at 2022-06-23 06:25:52.032309
# Unit test for method get_roles of class Play
def test_Play_get_roles():

    # Test variables
    play_content = {"name": "Example Play","hosts": "example_host","roles": [{"role": "role1"},{"role": "role2"},{"role": "role3"}],"vars": {"var1": "var1_value"}}
    var_manager = VariableManager()
    loader = DataLoader()
    p = Play.load(data=play_content, variable_manager=var_manager, loader=loader)
    new_p = p.copy()

    # Test conditions
    if not new_p.get_roles():
        raise Exception()

    # Test actions
    # Test assertions



# Generated at 2022-06-23 06:25:59.063369
# Unit test for method __repr__ of class Play
def test_Play___repr__():
	play = Play()
	play.name = 'TEST'
	play.gather_facts = True
	play.handlers = ['handlers']
	play.tasks = ['tasks']
	play.roles = ['roles']
	play.tags = ['tags']
	play.post_tasks = ['post_tasks']
	play.pre_tasks = ['pre_tasks']
	play.strategy = 'strategy'
	assert play.__repr__() == 'TEST'


# Generated at 2022-06-23 06:26:12.696640
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.playbook.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleAssertionError
    from ansible.errors import AnsibleParserError

    # Test normal preprocess_data method.
    play = Play.load(dict(hosts='localhost', vars={"a": "b"}))
    assert play.get_vars() == {"a": "b"}

    # Test preprocess_data method that raises AnsibleAssertionError exception.
    play = Play.load(dict(hosts='localhost'))
    data = None

# Generated at 2022-06-23 06:26:13.309872
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    assert 0


# Generated at 2022-06-23 06:26:23.589766
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    # Arrange
    fake_vars_file = 'fake_file'
    p = Play()
    # Act
    p.vars_files = fake_vars_file
    # Assert
    vars_files1 = p.get_vars_files()
    assert vars_files1 != []
    assert vars_files1[0] == fake_vars_file
    # Arrange
    fake_vars_file = 'fake_file'
    p = Play()
    # Act
    p.vars_files = [fake_vars_file]
    # Assert
    vars_files2 = p.get_vars_files()
    assert vars_files2 != []
    assert vars_files2[0] == fake_vars_file


# Generated at 2022-06-23 06:26:34.860822
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test Play._preprocess_data() with no 'user' in ds
    # ds has no 'user' key
    ds = {'hosts': 'all'}
    p = Play()

    # test return value
    actual = p._preprocess_data(ds)
    expected = ds
    assert actual == expected

    # Test Play._preprocess_data() with 'user' in ds
    # ds has 'user' key
    ds = {'hosts': 'all', 'user': 'root'}
    p = Play()

    # test return value
    actual = p._preprocess_data(ds)
    expected = {'hosts': 'all', 'remote_user': 'root'}
    assert actual == expected


# Generated at 2022-06-23 06:26:41.972523
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p._role_names is None
    assert p.ROLE_CACHE is None
    assert p._included_conditional is None
    assert p.get_roles() is None
    assert p._included_path is None
    assert p.get_vars() is None
    assert p.get_vars_files() is None
    assert p._action_groups is None
    assert p._group_actions is None
    assert p.get_handlers() is None
    assert p.get_tasks() is None


# Generated at 2022-06-23 06:26:48.309007
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    role_content001 = """\
---
- shell: my command
"""
    role_content002 = """\
---
- shell: my command
"""
    role_content003 = """\
- role: role001
"""
    role_content004 = """\
---
- role: role002
"""
#
# Test all combinations of setting 'roles' vs. 'tasks':
# See also test_Play_get_roles()
#
    def check_tasks(play, n_powers_of_two, n_tasks_expected):
        assert isinstance(play, Play)
        tasks = play.get_tasks()
        n_tasks = len(tasks)

# Generated at 2022-06-23 06:26:52.505160
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.roles.append(Role())
    p.tasks.append(Task())
    p.post_tasks.append(Task())
    p.pre_tasks.append(Task())
    result = p.compile()
    assert result == []

# Generated at 2022-06-23 06:26:54.214880
# Unit test for method load of class Play
def test_Play_load():
    pass



# Generated at 2022-06-23 06:27:04.098526
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    play = Play()

    data = {
       'roles': [],
       'included_path': None,
       'action_groups': {},
       'group_actions': {},
       'tags': [],
       'always_run': False,
       'block': [],
       'any_errors_fatal': False,
       'connection': 'local',
       'gather_facts': 'smart',
       'hosts': [],
       'roles': [],
       'serial': []
    }

    play.deserialize(data)
    assert play._included_path == None
    assert play._action_groups == {}
    assert play._group_actions == {}
    assert play.roles == []


# Generated at 2022-06-23 06:27:06.707577
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    pl = Play()
    pl.handlers = [{"test":"test1"}]
    assert pl.get_handlers() == [{"test": "test1"}]



# Generated at 2022-06-23 06:27:17.853720
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {"vars_prompt": [{"name": "host", "prompt": "host", "private": "no"}], "hosts": "all", "vars_files": [], "name": "Test Play"}
    expected_outcome = {"vars_prompt": [{"name": "host", "prompt": "host", "private": "no"}], "hosts": "all", "vars_files": [], "name": "Test Play"}
    play = Play()
    play.deserialize(data)
    if play.get_vars_files() != expected_outcome['vars_files']:
        return False
    if play.get_name() != expected_outcome['name']:
        return False

# Generated at 2022-06-23 06:27:28.497826
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict value
    ds = {'hosts': 'localhost', 'user': 'root', 'serial': 5}
    
    result = Play.preprocess_data(ds)
    assert result['hosts'] == 'localhost'
    assert result['user'] == 'root'
    assert 'user' not in result
    assert result['remote_user'] == 'root'
    assert result['serial'] == 5
    # Test with a non-dict value
    ds = []
    with pytest.raises(AnsibleAssertionError) as excinfo:
        Play.preprocess_data(ds)
    assert 'while preprocessing data' in to_native(excinfo.value)

# Generated at 2022-06-23 06:27:30.118113
# Unit test for method compile of class Play
def test_Play_compile():
    role1 = Role()
    role1.compile()

    play = Play()
    play.compile()

# Generated at 2022-06-23 06:27:32.901214
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
	pass


# Generated at 2022-06-23 06:27:42.805439
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    collection_loader = Mock()
    collection_loader._collections = []
    collection_loader._all_collections = {}

    loader = Mock()
    loader.load_from_file = Mock()

    play = Play()
    play.playbook = Mock()

    play.vars = Mock()
    play.vars.copy = Mock()
    play.vars.copy.return_value = {}
    play.vars_files = []

    task = Mock()
    task.serialize.return_value = {}
    task.copy.return_value = task

    role = Mock()
    role.get_handler_blocks.return_value = task
    role.from_include = False

    role1 = Mock()
    role1.get_handler_blocks.return_value = task
    role1.from_include = False



# Generated at 2022-06-23 06:27:53.689724
# Unit test for method compile of class Play
def test_Play_compile():
    # Test when attribute pre_tasks is not empty
    play1 = Play()
    play1_pre_tasks = ['Task1', 'Task2']
    setattr(play1, 'pre_tasks', play1_pre_tasks)
    # Test when attribute roles is not empty
    play1_roles = ['role1', 'role2']
    setattr(play1, 'roles', play1_roles)
    # Test when attribute tasks is not empty
    play1_tasks = ['Task3', 'Task4']
    setattr(play1, 'tasks', play1_tasks)
    # Test when attribute post_tasks is not empty
    play1_post_tasks = ['Task5', 'Task6']

# Generated at 2022-06-23 06:28:02.699433
# Unit test for method load of class Play
def test_Play_load():
    # Altered to pass for new class hierarchy
    data = '''
    - name: "Test Play"
      hosts:
        - instance1
      roles:
        - test-role1
    '''
    p = Play().load(data, variable_manager=MockVariableManager(), loader=MockLoader())
    assert p.get_name() == "Test Play"
    assert p.hosts == ['instance1']
    assert len(p.roles) == 1
    assert p.roles[0].get_name() == 'test-role1'

# Generated at 2022-06-23 06:28:16.804636
# Unit test for method copy of class Play
def test_Play_copy():
    pb_data = dict(
        name="minimal",
        hosts="all",
        gather_facts="no",
        pre_tasks=[{"name": "setup"}],
        tasks=[{"name": "test"}],
        roles=[],
        post_tasks=[],
        handlers=[],
        vars_prompt=[],
        vars_files=[],
        vars={'A': 'a'},
        gather_facts="no"
    )
    p = Play.load(pb_data, loader=DictDataLoader())
    p_copy = p.copy()
    assert p.roles == p_copy.roles
    #__dict__ is not exact same, but they are still the same.
    del p_copy.__dict__['_variable_manager']

# Generated at 2022-06-23 06:28:22.453031
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = "test.yml"
    assert play.get_vars_files() == ['test.yml']
    play.vars_files = ['test1.yml', 'test2.yml']
    assert play.get_vars_files() == ['test1.yml', 'test2.yml']



# Generated at 2022-06-23 06:28:32.667971
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    import ansible
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError  
    from ansible.config.manager import ConfigManager
    from ansible.plugins.loader import plugin_loader
    from ansible.playbook.block import Block
    import os

    config_manager = ConfigManager(os.getcwd())
    loader = DataLoader()
    results_callback = ResultsCollectorToFile()
    inventory = InventoryManager(loader=loader, sources=os.getcwd())
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:28:34.810649
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    a = Play()
    assert a.get_handlers() == []
    assert True

# Generated at 2022-06-23 06:28:44.382800
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    task_blocks = []
    task_block_1 = Block()
    task_block_1.block = ['task1', 'task2']
    task_blocks.append(task_block_1)
    task_block_2 = Block()
    task_block_2.block = ['task3', 'task4']
    task_blocks.append(task_block_2)
    task_block_3 = Block()
    task_block_3.block = ['task5']
    task_blocks.append(task_block_3)
    setattr(play, 'tasks', task_blocks)
    print(play.get_tasks())



# Generated at 2022-06-23 06:28:51.309048
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    Test result of method get_tasks of class Play
    '''
    play = Play()
    play.pre_tasks = ['pre_task']
    play.post_tasks = ['post_task']
    play.tasks = ['task']
    assert play.get_tasks() == ['pre_task', 'task', 'post_task']
    play = Play()
    play.pre_tasks = [['pre_task']]
    play.post_tasks = [['post_task']]
    play.tasks = [['task']]
    assert play.get_tasks() == ['pre_task', 'task', 'post_task']
    play = Play()
    play.pre_tasks = [['pre_task'], ['pre_task_1']]
    play.post_t

# Generated at 2022-06-23 06:28:57.044217
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    data = {'name': 'testPlay', 'hosts': 'testHosts', 'remote_user': 'testUser', 'tasks': [{'meta': 'testMeta'}], 'strategy': 'testStrategy'}
    variable_manager = VariableManager()
    loader = DataLoader()
    p = Play()
    p = p.load_data(data, variable_manager=variable_manager, loader=loader)
    # TODO: can't think of a good way to test this
    assert(True)


# Generated at 2022-06-23 06:28:57.838060
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-23 06:29:03.807094
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    Test for method get_tasks of Play class
    '''
    play = Play()
    task = Task()
    task.action = "include_vars"
    task.args = {"yaml": "{{ play_dir }}/../main.yml"}
    task.block = []
    task.implicit = False
    task.rescue = []
    task.always = []
    task.register = None

# Generated at 2022-06-23 06:29:05.339159
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # [{'name': 'role1'}, {'name': 'role2'}]
    # return [Role('role1'), Role('role2')]
    pass


# Generated at 2022-06-23 06:29:14.276075
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    class AnsiblePlay(unittest.TestCase):
        def test_Play_get_roles_one(self):
            host_list = [
                '172.31.102.12',
                '172.31.102.13',
                '172.31.102.14'
            ]
            vars = dict()
            play = Play.load(data=None, variable_manager=None,
                             loader=None, vars=vars)
            play.hosts = host_list
            play.get_roles()

    unittest.main()

if __name__ == '__main__':
    test_Play_get_roles()

# Generated at 2022-06-23 06:29:22.090660
# Unit test for method load of class Play
def test_Play_load():
    yaml = """
- hosts: localhost
  remote_user: root
  tasks:
  - name: This is a task
    ping:
"""

    play = Play.load(
        data=yaml,
        variable_manager=None,
        loader=None
    )

    assert play is not None
    assert play.get_name() == 'localhost'
    assert len(play.tasks) == 1

    task = play.tasks[0]
    assert task.action == 'ping'
    assert task.name == 'This is a task'


# Generated at 2022-06-23 06:29:34.049089
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create play with empty pre_tasks, post_tasks and tasks
    # and try to get_tasks
    play1 = Play()
    play1.pre_tasks = []
    play1.tasks = []
    play1.post_tasks = []
    assert play1.get_tasks() == []

    # Create play with pre_tasks, post_tasks and tasks
    # and try to get_tasks
    play2 = Play()
    play2.pre_tasks = [Task()]
    play2.tasks = [Task()]
    play2.post_tasks = [Task()]
    assert len(play2.get_tasks()) == 3

    # Create play with pre_tasks, post_tasks and tasks
    # and try to get_tasks

# Generated at 2022-06-23 06:29:45.028986
# Unit test for method get_name of class Play

# Generated at 2022-06-23 06:29:46.733049
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # FIXME: add tests
    p = Play()
    p.test()



# Generated at 2022-06-23 06:29:55.290734
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.get_name() == ''
    assert play.roles == []
    assert play.handlers == []
    assert play.tasks == []

    play.set_loader(MockDataLoader())
    play.set_variable_manager(MockVariableManager())
    play.load({'hosts': 'all'})

    assert play.get_name() == 'all'
    assert play.roles == []
    assert play.handlers == []
    assert play.tasks == []
    assert play.vars == {}
    assert play.vars_prompt == []
    assert play.vars_files == []

# Generated at 2022-06-23 06:29:56.478091
# Unit test for constructor of class Play
def test_Play():
    assert Play()


# Generated at 2022-06-23 06:30:04.427289
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.tasks = [
        {
            'block': [
                'action1',
                {
                    'name': 'action2',
                    'tag': 'tag1'
                }
            ],
            'rescue': [
                {
                    'name': 'action3',
                    'tags': [
                        'tag2',
                        'tag3'
                    ]
                }
            ],
            'always': [
                {
                    'name': 'action4',
                    'loop': {
                        'my_list': [
                            'a',
                            'b',
                            'c'
                        ]
                    }
                }
            ]
        }
    ]

    result = play.serialize()

# Generated at 2022-06-23 06:30:06.350811
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass



# Generated at 2022-06-23 06:30:08.019800
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    assert play.serialize() is not None

# Generated at 2022-06-23 06:30:15.637448
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    assert p.get_roles() == []
    r1 = Role()
    r2 = Role()
    r3 = Role()
    p.roles.append(r1)
    p.roles.append(r2)
    p.roles.append(r3)
    assert p.get_roles() == [r1,r2,r3]



# Generated at 2022-06-23 06:30:21.472310
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # @TODO: get_handlers() should return a clone
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    p = Play()
    p.handlers = [Task(name='foo')]
    assert p.get_handlers() == [Task(name='foo')]

    assert p.handlers[0] is p.get_handlers()[0]

    assert p.get_handlers()[0] is not p.handlers[0].copy()

    p.handlers += [Block(name='foo')]
    assert p.get_handlers() == [Task(name='foo'), Block(name='foo')]
    assert p.handlers[0] is p.get_handlers()[0]

# Generated at 2022-06-23 06:30:32.884428
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.playbook import Play as _testclass
    from ansible.playbook import PlayContext as _testclass2
    from ansible.playbook import Playbook as _testclass3
    from ansible.playbook.included_file import IncludedFile as _testclass4
    from ansible.playbook.task_include import TaskInclude as _testclass5
    from ansible.playbook.block import Block as _testclass6
    from ansible.playbook.task import Task as _testclass7
    from ansible.playbook.handler import Handler as _testclass8
    instance2 = _testclass2()
    roles = []
    for role in getattr(instance2, 'roles'):
        r = Role()
        roles.append(r.deserialize(role))

# Generated at 2022-06-23 06:30:42.131841
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    vars_files = []
    play.vars_files = vars_files
    assert vars_files == play.get_vars_files()
    vars_files = 'a_var_file'
    play.vars_files = vars_files
    assert [vars_files] == play.get_vars_files()
    vars_files = ['another_var_file']
    play.vars_files = vars_files
    assert vars_files == play.get_vars_files()


# Generated at 2022-06-23 06:30:46.042306
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    data = {'hosts': 'host1'}
    res = play.preprocess_data(data)
    assert data['remote_user'] == play.user

# Generated at 2022-06-23 06:30:58.485676
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Case 1:
    ds = {'hosts': 'localhost', 'vars': {'name1': '{{name1}}'}, 'user': 'root', 'tasks': [{}]}
    p = Play()
    preprocess_handler = getattr(p, '_preprocess_data', None)
    if preprocess_handler:
        preprocess_handler(ds)
    assert ds == {'hosts': 'localhost', 'vars': {'name1': '{{name1}}'}, 'remote_user': 'root', 'tasks': [{}]}

    # Case 2:
    ds = {'hosts': 'localhost', 'vars': {'name1': '{{name1}}'}, 'remote_user': 'root', 'tasks': [{}]}
    p = Play()
    preprocess

# Generated at 2022-06-23 06:31:05.059322
# Unit test for method serialize of class Play
def test_Play_serialize():
    """
    Unit test for method serialize of class Play
    """
    play = Play()
    data = play.serialize()
    assert data == {}
    assert play._included_path is None
    assert play._action_groups == {}
    assert play._group_actions == {}
    assert data.get('roles') == []


# Generated at 2022-06-23 06:31:07.378086
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.  deserialize(p.  serialize())

# Generated at 2022-06-23 06:31:09.797471
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = 'test_play'
    assert str(play) == 'test_play'


# Generated at 2022-06-23 06:31:13.690539
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = [{"one": 1}, {"two": 2}]
    v = p.get_vars_files()
    assert v == p.vars_files


# Generated at 2022-06-23 06:31:17.718291
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.get_name = MagicMock(return_value='test_Play')
    result = repr(play)
    assert result == 'test_Play'

# Generated at 2022-06-23 06:31:29.185063
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'name'
    play.hosts = 'localhost'
    play.vars = {'test_vars': 'test_value'}
    play.vars_prompt = ['test_prompt']
    play.vars_files = ['test_variables']
    play.handlers = ['test_handlers']
    play.pre_tasks = ['test_pre_tasks']
    play.post_tasks = ['test_post_tasks']
    play.tasks = ['test_tasks']
    play.serial = ['test_serial']
    play.strategy = 'test_strategy'
    play.roles = [Role().load(data={'name': 'test_role_name'})]
    play.tags = ['test_tags']
    play

# Generated at 2022-06-23 06:31:32.745029
# Unit test for method get_name of class Play
def test_Play_get_name():
    # play = Play()  # create a new instance of the class Play
    # play.name = name  # set a value for attribute name
    # play.get_name() # should return a the value of play.name
    pass


# Generated at 2022-06-23 06:31:39.787639
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.tasks = ['task1', 'task2']
    p.roles = ['role1', 'role2']
    p._compile_roles = Mock()
    p._compile_roles.return_value = ['role1_task1', 'role1_task2', 'role2_task1', 'role2_task2']
    result = p.compile()
    assert result == ['task1', 'task2', 'role1_task1', 'role1_task2', 'role2_task1', 'role2_task2']

# Generated at 2022-06-23 06:31:49.074487
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    import collections
    import types
    # This class definition is for usage testing purposes only,
    # it will be replaced with the real class when tested.
    class PlayTestBase(Base):
        _valid_attrs = frozenset(('name', 'vars', 'roles'))
        _valid_attribute_values = {'name': set(('MyPlay',))}
        # default values for one or more attributes
        name = ''
        vars = collections.OrderedDict()
        roles = []

     # This class definition is for testing purposes only,
    # it will be replaced with the real class when tested.
    class BaseTestBase(object):
        @staticmethod
        def __getattr__(name):
            return None
        @staticmethod
        def get():
            return {}

# Generated at 2022-06-23 06:31:55.003429
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
	# Initialize task_blocks
	task_blocks = Block()
	
	# add tasks to task_blocks
	
	
	# Initialize block_list
	block_list = [task_blocks]
	
	# Initialize play
	play = Play()
		
	# Check return value
	assert play.get_tasks() == block_list



# Generated at 2022-06-23 06:32:01.270859
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    test_data = {
        'name': 'test play',
        'user': 'root'
    }
    myplay = Play()
    assert myplay.preprocess_data(test_data) == {'name': 'test play', 'remote_user': 'root'}

TestAnsibleCore.add_method_to_test(test_Play_preprocess_data)

# Generated at 2022-06-23 06:32:10.494302
# Unit test for method copy of class Play
def test_Play_copy():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.settings = {
        'force_handlers': True,
        'max_fail_percentage': 1,
        'serial': 10,
        'strategy': 'Free',
        'order': 'order'
    }
    play = Play()
    play.vars = {'key1': 'value1'}
    play.vars_prompts = None
    play.vars_files = None
    play.connection = 'local'
    play.gather_facts = 'no'
    play.name = 'test'

# Generated at 2022-06-23 06:32:16.731930
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    mock_loader_obj = MagicMock()
    mock_vm_obj = MagicMock()
    expected_handlers = []
    mock_play_obj = Play(loader=mock_loader_obj, variable_manager=mock_vm_obj, handlers=expected_handlers)
    actual_handlers = mock_play_obj.get_handlers()
    assert actual_handlers is expected_handlers



# Generated at 2022-06-23 06:32:18.637388
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Unit test for method compile_roles_handlers of class Play
    '''
    pass

# Generated at 2022-06-23 06:32:21.196230
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    #This is just a sample, this needs a unit test that makes sense
    #assertEqual(expected, Play.get_handlers())
    assert False # TODO: implement your test here


# Generated at 2022-06-23 06:32:22.421889
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    y = Play()
    assert y.get_vars()



# Generated at 2022-06-23 06:32:29.707577
# Unit test for method load of class Play
def test_Play_load():
    user_name = "user"
    host = "localhost"
    # Set variables for test case
    _data = dict(
        name="play-name",
        gather_facts=True,
        hosts="localhost",
        vars={},
        roles={},
        tasks=[]
    )
    _user_vars = dict(user_name=user_name)
    _host_vars = dict(host_name=host)
    # Function to be tested
    def _test(test_case):
        # Test Play.load
        _test_case = test_case
        # Create instance of VariableManager to store variables
        play_vardir = mock.MagicMock(spec=VariableManager)
        # Create instance of AnsibleLoader to load variables
        ansibleloader = mock.MagicMock(spec=AnsibleLoader)

# Generated at 2022-06-23 06:32:33.306551
# Unit test for method load of class Play
def test_Play_load():
    """
    Test if the method load is working as expected
    """
    play = Play()
    play.load({"hosts": "127.0.0.1", "roles": [{"role": "some_name"}]})



# Generated at 2022-06-23 06:32:38.604913
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.hosts = [
                    'host1',
                    'host2',
                 ]
    EXPECTED_NAME = 'host1,host2'
    act_name = play.get_name()

    assert act_name == EXPECTED_NAME



# Generated at 2022-06-23 06:32:49.459715
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p and p._ds  # ensure there is a datastructure to work with

    # _load_roles() pre-validates, so no need to re-check here
    p._load_roles(None, 'blah')
    assert p.roles == []

    # return the set() of tasks to run
    assert isinstance(p.compile(), list)
    assert isinstance(p.compile_roles_handlers(), list)

    # get_vars() => dict
    assert isinstance(p.get_vars(), dict)

    # get_vars_files() => list
    assert isinstance(p.get_vars_files(), list)

    # get_handlers() => list
    assert isinstance(p.get_handlers(), list)

    # get_ro

# Generated at 2022-06-23 06:33:01.338658
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test_name"
    assert play.get_name() == play.name
    play.name = None
    play.hosts = "test_hosts"
    assert play.get_name() == play.hosts
    play.hosts = None
    assert play.get_name() == play.name
    play.name = "test_name"
    assert play.get_name() == play.name
    play.hosts = "test_hosts"
    assert play.get_name() == play.name
    play.only_tags = "test_only_tags"
    assert play.get_name() == play.only_tags
    play.only_tags = None
    play.skip_tags = "test_skip_tags"
    assert play.get_name() == play

# Generated at 2022-06-23 06:33:12.759236
# Unit test for method serialize of class Play
def test_Play_serialize():
    from collections import namedtuple
    from ansible import constants as C
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.vault import VaultLib

    # case 1:
    # test if serialize method of class Play is working properly.
    # this test case is executed when variable C.DEFAULT_VAULT_ID_MATCH (
    # ansible.constants) is false.

    assert C.DEFAULT_VAULT_ID_MATCH == False

    # creating object of class Play.
    p = Play()

    # creating namedtuple object.
    class Obj:
        def __init__(self):
            self.value = 'ansible'
    obj = Obj()

    # creating namedtuple object.

# Generated at 2022-06-23 06:33:28.720473
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    vars_manager = VariableManager()
    loader.set_basedir('/etc/ansible/roles/role1')

    obj = Play()
    setattr(obj, '_ds', dict(name='Play 1', hosts='all', pre_tasks=[], roles=[], tasks=[], post_tasks=[]))
    data =  obj.serialize()
    obj.deserialize(data)

    # Test for serialize method of class Role
    assert hasattr(obj, '_ds')
    assert hasattr(obj, '_variable_manager')
    assert hasattr(obj, '_loader')
    assert hasattr(obj, '_name')
    assert hasattr(obj, '_role_name')

# Generated at 2022-06-23 06:33:35.061367
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
	# Declare a instance of class Play
	p = Play()
	# unit test for get_vars_files method
	assert p.get_vars_files() == []
	p.vars_files = "value"
	assert p.get_vars_files() == ["value"]
test_Play_get_vars_files()

# Generated at 2022-06-23 06:33:36.178832
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    my_play = Play()
    my_play.deserialize({})

# Generated at 2022-06-23 06:33:43.926182
# Unit test for constructor of class Play
def test_Play():

    # test constructor of role class
    play = Play()
    assert play._ds is None
    assert play._variable_manager is None
    assert play._loader is None
    assert play.roles is not None
    assert play.handlers is not None
    assert play.tasks is not None
    assert play.name is None
    assert play.hosts is None
    assert play.vars is None
    assert not play.any_errors_fatal



# Generated at 2022-06-23 06:33:46.192351
# Unit test for method get_name of class Play
def test_Play_get_name():
    """
    Test case for function get_name of class Play. This function tests functionalities of get_name function of Play class.
    """
    pl = Play()
    assert pl.get_name() == ','


# Generated at 2022-06-23 06:33:52.780269
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from pprint import pprint
    from collections import namedtuple
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_usable

    # Display debug output when running this unit test
    context.CLIARGS = namedtuple('CLIARGS', ['explain', 'verbosity'])
    context.CLIARGS.verbosity = 4

    # When testing methods of this Ansible class, which use the
    # following methods of the Ansible class, then replace those
    # imported modules with mock modules.

# Generated at 2022-06-23 06:33:56.593408
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.gather_facts is None
    assert isinstance(p.hosts, list)
    assert p.hosts == []
    assert isinstance(p.roles, list)
    assert p.roles == []


# Generated at 2022-06-23 06:34:02.420239
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    pre_tasks = []
    tasks = []
    post_tasks = []
    handlers = []
    roles = ['role1', 'role2']
    play = Play('name', hosts=[], pre_tasks=pre_tasks, tasks=tasks, post_tasks=post_tasks, handlers=handlers, roles=roles)
    assert play.get_roles() == ['role1', 'role2']
