

# Generated at 2022-06-23 06:23:59.160895
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    assert Play().get_roles() == Play()._roles

# Generated at 2022-06-23 06:24:08.271344
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['127.0.0.1'])
    variable_manager.set_inventory(inventory)
    play_source = dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

# Generated at 2022-06-23 06:24:18.872352
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = {'name': 'testPlay',
            'hosts': 'localhost',
            'pre_tasks': [{'name': 'pre task'}],
            'tasks': [{'name': 'first task'},
                      {'name': 'second task'}],
            'post_tasks': [{'name': 'post task'}],
            'handlers': [{'name': 'test handler'}]
            }
    play = Play.load(data, variable_manager=VariableManager(), loader=DataLoader())
    play.compile()
    assert(play.get_name() == 'testPlay')

# Generated at 2022-06-23 06:24:30.053887
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # set-up
    # set-up ends
    ansible_play = Play()
    ansible_play.vars_files = "vars-files.yml"
    assert_equals(["vars-files.yml"], ansible_play.get_vars_files())

    ansible_play.vars_files = ["vars-files.yml", "tempfile.yml"]
    assert_equals(["vars-files.yml", "tempfile.yml"], ansible_play.get_vars_files())

    ansible_play.vars_files = None
    assert_equals([], ansible_play.get_vars_files())



# Generated at 2022-06-23 06:24:37.250108
# Unit test for method deserialize of class Play

# Generated at 2022-06-23 06:24:46.265339
# Unit test for method copy of class Play
def test_Play_copy():
    test_Play = Play()
    test_Play.ROLE_CACHE = {"test_Role_name": "test_Role"}
    test_Play._included_conditional = "test_included_conditional"
    test_Play._included_path = "test_included_path"
    test_Play._action_groups = {"test_group_name": "test_task"}
    test_Play._group_actions = {"test_task_name": "test_group"}
    copy_Play = test_Play.copy()
    assert copy_Play.ROLE_CACHE == {"test_Role_name": "test_Role"}, "test copy of ROLE_CACHE failed"

# Generated at 2022-06-23 06:24:55.328928
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    global pathname
    import doctest
    import sys
    import os.path
    parent_dir = os.path.dirname(pathname)
    sys.path.append(parent_dir)
    doctest.testmod()
    # demo code
    p = Play()
    p.get_roles()
if __name__ == '__main__':
    pathname = os.path.dirname(sys.argv[0])
    test_Play_get_roles()

# Generated at 2022-06-23 06:25:05.102385
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert len(play.ROLE_CACHE) == 0
    assert len(play.roles) == 0
    assert play.name == ''
    assert play.hosts == ''
    assert len(play.tasks) == 0
    assert len(play.pre_tasks) == 0
    assert len(play.post_tasks) == 0
    assert len(play.handlers) == 0
    assert play.serial == []
    assert play.vars == {}
    assert play.default_vars == {}
    assert play.vars_files == []
    assert play.vars_prompt == []
    assert play.tags == [ 'all' ]
    assert play.gather_facts == 'smart'

    # with_items test
    play = Play()

# Generated at 2022-06-23 06:25:16.526560
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test that the 'user' and 'remote_user' are set correctly
    # using a default (None) user

    play = Play()
    data = Mock(spec_set=dict)
    play.preprocess_data(data)
    data.assert_has_calls([call['user']])

    # Test that the 'user' and 'remote_user' are set correctly
    # using an empty string value

    play = Play()
    data = Mock(spec_set=dict)

    data.__getitem__ = Mock(return_value='')
    data.__contains__ = Mock(return_value=True)

    play.preprocess_data(data)
    data.__contains__.assert_has_calls([call('user')])

# Generated at 2022-06-23 06:25:27.256673
# Unit test for method get_tasks of class Play

# Generated at 2022-06-23 06:25:36.516264
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [object()]
    i = -1
    def side_effect(*args):
        nonlocal i
        i += 1
        return [object()]

    dummy = MagicMock()
    dummy.get_handler_blocks = MagicMock(side_effect=side_effect)

    play.roles[0] = dummy
    play.compile_roles_handlers()
    assert i == 0

    dummy.from_include = True

    play.compile_roles_handlers()
    assert i == 0
# END Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-23 06:25:46.318914
# Unit test for constructor of class Play
def test_Play():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory import Inventory

    my_vars = dict(a='1', b=2)
    my_variable_manager = VariableManager()
    my_variable_manager.extra_vars = my_vars
    my_loader = DataLoader()
    my_inventory = Inventory(loader=my_loader, variable_manager=my_variable_manager, host_list='localhost')
    my_play = Play()
    my_play.name = 'test_play'
    my_play.hosts = 'localhost'
    my_play.connection = 'local'
    my_play.vars = dict(a='2', c=3)
    my_play.v

# Generated at 2022-06-23 06:25:52.583567
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    test_play = Play()
    test_play._roles = [
       (1,2),
       (3,4),
    ]
    test_play._valid_attrs = ['roles']
    test_play._loaded_attrs = ['roles']
    assert test_play.get_roles() == [
       (1,2),
       (3,4),
    ]


# Generated at 2022-06-23 06:25:56.541634
# Unit test for method load of class Play
def test_Play_load():
    p = Play()
    assert p.load(ds=dict(hosts="hosts", gather_facts="no"))
    assert p.gather_facts is False
    assert p.hosts == "hosts"

# Generated at 2022-06-23 06:26:09.370314
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible import context
    from ansible.utils.vars import combine_vars
    import ast
    import json

    context._init_global_context(cli_args={"vault_password":"ansible"})
    variable_manager = VariableManager()
    loader, inventory, variable_manager = CLIRunner._load_inventory_and_vars(None, None, None, None, context.CLIARGS, False)
    play_context = PlayContext(loader=loader, variable_manager=variable_manager, defaults=dict(inventory=inventory))
    play_context.prompt = lambda c, p: c
    play_context

# Generated at 2022-06-23 06:26:14.502305
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {'a': 1, 'b': 2}
    if p.get_vars() != {'a': 1, 'b': 2}:
        raise RuntimeError('Could not get vars from Play')

# Generated at 2022-06-23 06:26:15.456207
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert Play().get_name() == ','

# Generated at 2022-06-23 06:26:17.264280
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    assert 'vars_files' in load_yaml(Play.load)



# Generated at 2022-06-23 06:26:19.047689
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    pl=Play()
    assert pl.get_roles() == []

# Generated at 2022-06-23 06:26:21.330755
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.compile()

# Unit test of method preprocess_data of class Play

# Generated at 2022-06-23 06:26:34.021691
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name is None
    assert play.hosts == ['']
    assert play.remote_user == ''
    assert play.connection == 'smart'
    assert play.gather_facts == 'no'
    assert play.gather_facts_tags == ['always']
    assert play.volatile_facts == ['ansible_local']
    assert play.delegate_to_hosts is None
    assert play.delegate_to_hosts_all is False
    assert play.serial == []
    assert play.any_errors_fatal is False
    assert play.max_fail_percentage == 0
    assert play.roles == []
    assert play.tags == ''
    assert play.skip_tags == ''
    assert play.tasks == []
    assert play.handlers == []
   

# Generated at 2022-06-23 06:26:35.371442
# Unit test for method copy of class Play
def test_Play_copy():
    pass


# Generated at 2022-06-23 06:26:44.401845
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    hostvars = {'testhostname': '1234'}
    test_host_names = ['testhostname']
    test_vars = {'test_var': 'test_value'}
    test_variable_manager = VariableManager(loader=None, inventory=Inventory(loader=None, host_list=test_host_names),
        host_vars=hostvars, group_vars=None)
    test_loader = MockLoader()
    test_play = Play()
    test_play._variable_manager = test_variable_manager
    test_play._loader = test_loader
    test_play.vars = test_vars
    test_play.get_vars() == {}

test_play = Play()
test_play.get_vars()


# Generated at 2022-06-23 06:26:44.835715
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-23 06:26:57.578185
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    """
    Test the deserialize method of the Play class
    """
    data = {
        "__ansible_vault": None,
        "__ansible_template": None,
        "__ansible_diff": None,
        "name": "foo.yml",
        "_included_path": None,
        "_action_groups": {},
        "_group_actions": {},
        "roles": [],
        "remote_user": "john",
        "connection": "ssh",
        "gather_facts": True,
        "roles": [],
        "vars": {},
        "vars_prompt": [],
        "vars_files": [],
        "tasks": [],
        "hosts": "all",
        "errors": []
    }
    p = Play

# Generated at 2022-06-23 06:26:59.799857
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert play.__repr__()

# Generated at 2022-06-23 06:27:08.452956
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.name = 'test'
    assert p.serialize() == {'name': 'test', 'vars': {}, 'hosts': 'all', 'roles': [], 'tasks': []}
    p.hosts = 'localhost'
    assert p.serialize() == {'name': 'test', 'vars': {}, 'hosts': 'localhost', 'roles': [], 'tasks': []}
    p.roles = ['test_role']
    p.tasks = ['test_task']
    assert p.serialize() == {'name': 'test', 'vars': {}, 'hosts': 'localhost', 'roles': ['test_role'], 'tasks': ['test_task']}

# Generated at 2022-06-23 06:27:11.649806
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Tests serialization of a role
    data = {
        'name': 'test_play',
        'hosts': 'localhost'
    }

    play = Play()
    play.load(data)

    serialized_data = play.serialize()

    assert data['name'] == serialized_data['name']
    assert data['hosts'] == serialized_data['hosts']

# Generated at 2022-06-23 06:27:19.983038
# Unit test for constructor of class Play
def test_Play():
    test_Play = Play()
    assert test_Play is not None

import sys
import unittest
from ansible.playbook.tests import empty_playbook, playbook_path
from ansible.module_utils.common.collections import ImmutableDict
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.template import Templar



# Generated at 2022-06-23 06:27:28.272692
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():

    # Construct a mock Play object and get its handlers
    Play = Play()
    Play.handlers = [Block(), Block()]

    expected_handlers = [Block(), Block()]
    actual_handlers = Play.get_handlers()

    # Compare lengths of the handlers
    def assert_handlers_lengths_equal(expected_handlers, actual_handlers):
        return len(actual_handlers) == len(expected_handlers)

    assert(assert_handlers_lengths_equal(expected_handlers, actual_handlers))


# Generated at 2022-06-23 06:27:35.773878
# Unit test for method load of class Play
def test_Play_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    # Arrange
    data = {'hosts': 'localhost', 'vars': {'foo': 'bar'}, 'tasks': [{'debug': {'msg': 'hello world'}}]}
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Act
    play = Play.load(data, variable_manager, loader)

    # Assert
    assert isinstance(play, Play)
    assert play.hosts == 'localhost'
    assert play.vars == {'foo': 'bar'}

# Generated at 2022-06-23 06:27:36.640970
# Unit test for constructor of class Play
def test_Play():
    assert Play()

# Generated at 2022-06-23 06:27:40.711100
# Unit test for method get_name of class Play
def test_Play_get_name():
    host_list = []
    play_instance_0 = Play()
    play_instance_0.name = None
    play_instance_0.hosts = host_list
    assert play_instance_0.get_name() == ''
    assert play_instance_0.name == ''

# Generated at 2022-06-23 06:27:51.002181
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    assert play.serialize() == {'handlers': [], 'max_fail_percentage': None, 'name': '', 'serial': [], 'roles': [], 'status': '', 'timeout': None, 'vars': {}, 'hosts': None, 'pre_tasks': [], 'post_tasks': [], 'force_handlers': False, 'tags': [], 'strategy': 'linear', 'any_errors_fatal': False, 'included_path': None, 'action_groups': {}, 'group_actions': {}, 'action': 'meta', 'meta': 'noop', 'tasks': [], 'order': None}

# Generated at 2022-06-23 06:27:54.771617
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    vars_dict = play.get_vars()

    assert(isinstance(vars_dict, dict))
    assert(len(vars_dict) == 0)


# Generated at 2022-06-23 06:28:03.798402
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    def mock_Role_load(a):
        return 'x'
    my_Role = Role()
    my_Role.load = mock_Role_load
    my_variable_manager = 'y'
    my_loader = 'z'
    my_play = Play.load(dict(
        name = 'a',
        hosts = ['b'],
        roles = [{'role': 'c'}]),
        variable_manager = my_variable_manager,
        loader = my_loader)
    my_play.Role = my_Role
    assert my_play.get_roles() == ['x']

# Generated at 2022-06-23 06:28:08.169394
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # method to test __repr__ of Play class
    Play = Play()
    Play.name = "Play Name"
    assert Play.__repr__() == "Play Name"

# Generated at 2022-06-23 06:28:19.566103
# Unit test for method copy of class Play
def test_Play_copy():
    host = Host('127.0.0.1')
    task = Task()
    role = Role()
    play = Play()

    new_role = play.roles
    new_role.append(role)
    new_task = play.tasks
    new_task.append(task)
    new_host = play.hosts
    new_host.append(host)
    play.ROLE_CACHE = {'myRole':role}
    play._included_conditional = 'my conditional'
    play._included_path = '/path/to/my/play'
    play._action_groups = {'myGroup':['myAction']}
    play._group_actions = {'myAction':['myGroup']}

    new_play = play.copy()

# Generated at 2022-06-23 06:28:22.855801
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data({'roles': ['role1', 'role2']})
    assert play.roles == ['role1', 'role2']


# Generated at 2022-06-23 06:28:33.380446
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert(p.name == '')
    assert(p.hosts == '')
    assert(p.connection == 'smart')
    assert(p.port == 0)
    assert(p.gather_facts == True)
    assert(p.max_fail_percentage == 0)
    assert(p.remote_user == C.DEFAULT_REMOTE_USER)
    assert(p.vars == {})
    assert(p.vars_files == None)
    assert(p.vars_prompt == [])
    assert(p.sudo == False)
    assert(p.sudo_user == C.DEFAULT_SUDO_USER)
    assert(p.transport == 'smart')
    assert(p.serial == [])
    assert(p.roles == [])
   

# Generated at 2022-06-23 06:28:36.073723
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    # Serialize serializes the value of a object into a basic object.
    play.serialize()


# Generated at 2022-06-23 06:28:44.216007
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    data = {'foo': 'bar'}
    # First, run the method against data that we control
    rval = play.preprocess_data(data)
    # We don't expect any changes to be made
    assert rval == data
    # Now run the method against data where a deprecation will happen
    data = {'user': 'foo'}
    rval = play.preprocess_data(data)
    # We expect the method to properly turn user into remote_user
    assert rval == {'remote_user': 'foo'}

# Generated at 2022-06-23 06:28:55.556397
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # test with role_handlers = []
    # For example:
    #  roles:
    #    - {role: my_role}
    #  my_role/tasks/main.yml:
    #    - name: Echo hello
    #      debug:
    #        msg: "Hello"
    #  my_role/handlers/main.yml:
    #    - name: test handler
    #      debug:
    #        msg: "my test handler"
    role_handlers = []
    play = Play()
    assert play.compile_roles_handlers() == role_handlers
    # test with handlers = []
    # For example:
    #  roles:
    #    - {role: my_role}
    #  my_role/tasks/main.yml:
   

# Generated at 2022-06-23 06:28:57.061534
# Unit test for method compile of class Play
def test_Play_compile():
    m = Play()
    m.compile()

# Generated at 2022-06-23 06:29:03.137646
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    p = Play()
    ds = get_play_data()
    p.load_data(ds)
    ds = p.serialize()
    p2 = Play.load(ds)
    assert p2.tasks[1].name == 'debug'
    assert p2.handlers[0].name == 'debug'
    assert p2.roles[0].name == 'common'

# Generated at 2022-06-23 06:29:12.659954
# Unit test for method serialize of class Play
def test_Play_serialize():
    test_data_1 = {
        "name": "local",
        "hosts": "all",
        "tasks": {
            "a": "b"
        }
    }
    test_data_2 = {
        "name": "local",
        "hosts": "all",
        "pre_tasks": [
            {
                "name": "a"
            }
        ],
        "post_tasks": [
            {
                "a": "b"
            }
        ]
    }

    ds = Play(1, 2).deserialize(test_data_1)
    assert ds.serialize() == test_data_1

    ds = Play(1, 2).deserialize(test_data_2)
    assert ds.serialize() == test_data_2

# Generated at 2022-06-23 06:29:18.604225
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test play'
    assert p.get_name() == 'test play'

    p = Play()
    p.name = None
    assert p.get_name() == ''

    p = Play()
    p.name = None
    p.hosts = 'all'
    assert p.get_name() == 'all'

    p = Play()
    p.name = None
    p.hosts = ['alice', 'bob']
    assert p.get_name() == 'alice,bob'

    p = Play()
    p.name = None
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-23 06:29:21.292545
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    attr = 'vars'
    ds_type = dict
    check_method_of_class(Play, 'get_vars', attr, ds_type)

# Generated at 2022-06-23 06:29:25.089853
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    pb = Play()
    pb.handlers = [1,2,3]
    assert pb.get_handlers() == [1,2,3]

# Generated at 2022-06-23 06:29:29.083706
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # 1. Create an object of class Play
    play_obj = Play()
    # 2. Call method get_roles for the object play_obj
    result = play_obj.get_roles()
    # 3. Execute assertion - result should be an empty list
    assert result == []
     

# Generated at 2022-06-23 06:29:32.773118
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({'tasks': [{'name': 'test'}]})
    assert p.name == 'test'
    assert p.tasks[0].get_name() == 'test'


# Generated at 2022-06-23 06:29:42.232082
# Unit test for method load of class Play
def test_Play_load():
    # Testing example from http://docs.ansible.com/playbooks.html
    text = """
    - name: a playbook to configure some Cisco routers
      hosts: all
      connection: local
      gather_facts: no
      tasks:
         - name: ensure ntp is configured
           ios_config:
             lines:
              - ntp broadcast
              - ntp server 192.0.2.1
    """
    data = Play.load(yaml.load(text), variable_manager=VariableManager(), loader=DataLoader())
    assert data is not None


# Generated at 2022-06-23 06:29:43.673743
# Unit test for method copy of class Play
def test_Play_copy():
    '''
    Test copy.
    '''
    pass


# Generated at 2022-06-23 06:29:54.243789
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    variables = {'foo': 'bar'}
    obj = Play()
    
    # check if key 'included_path' exists in obj._ds
    obj._ds['included_path'] = None
    
    # check if key 'action_groups' exists in obj._ds
    obj._ds['action_groups'] = {}
    
    # check if key 'group_actions' exists in obj._ds
    obj._ds['group_actions'] = {}
    
    #check if key 'roles' exists in obj._ds
    obj._ds['roles'] = []
    obj._ds['roles'].append({'foo': 'bar'})
    
    
    
    obj.deserialize(obj._ds)
    # if obj._included_path and obj._included_conditional are both None, this should return

# Generated at 2022-06-23 06:30:02.513096
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p_ds = {u'name': u'apache', u'hosts': u'all', u'become': True, u'become_user': u'root', u'become_method': u'sudo', u'connection': u'ssh', u'vars': {u'group_name': u'apache'}, u'tasks': [{u'debug': {u'msg': u'{{ group_name }}'}}], u'roles': [{u'name': u'common', u'defaults': {u'group_name': u'common'}}]}
    p.deserialize(p_ds)
    assert p.hosts == 'all'


# Generated at 2022-06-23 06:30:09.059486
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Test data
    data = {
        'roles': [{'role': 'test_role'}],
        'handlers': [{'name': 'test_handler'}]
    }

    # Test
    play = Play()
    play.load(data, variable_manager=VariableManager())

    assert play.handlers == [{'name': 'test_handler'}]



# Generated at 2022-06-23 06:30:13.410247
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {'item': 'example'}
    assert play.get_vars() == {'item': 'example'}

# Generated at 2022-06-23 06:30:19.654023
# Unit test for method copy of class Play
def test_Play_copy():
    assertequal(Play().copy(), Play(), 's1')
    assertequal(Play(dict(a=1)).copy(), Play(dict(a=1)), 's2')
    try:
        Play(dict(a=1)).copy().a = 2
    except:
        expect_noerror('')
    assertequal(Play(dict(a=1)).copy().a, 1, 's3')
    assertequal(Play(dict(a=1)).copy().copy() != Play(dict(a=1)).copy(), False, 's4')

# Generated at 2022-06-23 06:30:32.284752
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    a_play = Play()

# Generated at 2022-06-23 06:30:44.634439
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = {
        u"name": u"test",
        u"hosts": u"127.0.0.1",
        u"gather_facts": u"no",
        u"tasks": [
            {
                u"name": u"dummy",
                u"action": u"setup"
            }
        ]
    }

    play = Play.load(data=data, loader=DictDataLoader())
    serialized = play.serialize()

    assert isinstance(serialized, dict) is True
    assert 'roles' in serialized
    assert 'action_groups' in serialized
    assert 'group_actions' in serialized
    assert 'included_path' in serialized

    assert isinstance(serialized['roles'], list)

# Generated at 2022-06-23 06:30:50.933863
# Unit test for constructor of class Play
def test_Play():
    fake_variable_manager = DictData(dict())
    fake_loader = DictData(dict())

    fake_loader.path_exists.return_value = True
    fake_loader.file_exists.return_value = True
    fake_loader.get_basedir.return_value = '/home/username/ansible/module'
    fake_loader.path_exists.return_value = True

    fake_play = Play()

    assert fake_play._variable_manager is None
    assert fake_play._loader is None
    assert fake_play.name is None
    assert fake_play.hosts == ["all"]
    assert fake_play.gather_facts is True
    assert fake_play.vars == {}
    assert fake_play.vars_files == []
    assert fake_play.vars_prom

# Generated at 2022-06-23 06:30:55.021284
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    ds = AnsibleMapping()
    p = Play()
    assert isinstance(p.preprocess_data(ds), AnsibleMapping)



# Generated at 2022-06-23 06:31:02.668686
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    roles = []
    for i in range(0, 2):
        r = Role()
        roles.append(r)
    p.roles = roles
    p._action_groups = {
        'a': [],
        'b': []
    }
    p._group_actions = {
        'a': 'b'
    }
    data = p.serialize()
    assert data['roles'] == [{}, {}]
    assert data['action_groups'] == {'a': [], 'b': []}
    assert data['group_actions'] == {'a': 'b'}


# Generated at 2022-06-23 06:31:10.507673
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    def preprocess_data(ds, expected_ds):
        p = Play()
        data = p.preprocess_data(ds)
        assert data == expected_ds

    ds = {'hosts': 'localhost'}
    expected_ds = ds.copy()
    preprocess_data(ds, expected_ds)
    # replace 'hosts' with 'remote_user'
    ds = {'user': 'localhost'}
    expected_ds = {'remote_user': 'localhost'}
    preprocess_data(ds, expected_ds)
    # raise error if 'user' and 'remote_user' are both present
    ds = {'user': 'localhost', 'remote_user': 'localhost'}

# Generated at 2022-06-23 06:31:12.825897
# Unit test for constructor of class Play
def test_Play():
    play_obj = Play()
    assert play_obj is not None

# Generated at 2022-06-23 06:31:15.984722
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]

# Generated at 2022-06-23 06:31:26.830506
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Set the variable manager and loaders to be used for testing
    variable_manager = VariableManager()
    loader = DataLoader()

    # Check if an empty list is returned if variable vars_files is None
    play_vars_files = Play()
    play_vars_files._variable_manager = variable_manager
    play_vars_files._loader = loader
    assert play_vars_files.get_vars_files() == []

    # Check if a list with one element is returned if variable vars_files is a string
    play_vars_files = Play(vars_files="test.yml")
    play_vars_files._variable_manager = variable_manager
    play_vars_files._loader = loader

# Generated at 2022-06-23 06:31:29.931419
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test for method get_name of class Play
    # Fails if test_Play_get_name does not raise exception
    # play = Play()
    # play.get_name()
    pass

# Generated at 2022-06-23 06:31:39.597772
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name is None
    assert p.hosts is None
    assert p.remote_user is None
    assert p.connection is None
    assert p.port is 22
    assert p.gather_facts is True
    assert p.vars is None
    assert p.vars_files is None
    assert p.vars_prompt is None
    assert p.tags == ['all']
    assert p.any_errors_fatal is False
    assert p.max_fail_percentage is None
    assert p.roles is None
    assert p.handlers is None
    assert p.blocks is None
    assert p.post_tasks is None
    assert p.pre_tasks is None
    assert p.task_include is None
    assert p.notify is None

# Generated at 2022-06-23 06:31:40.566876
# Unit test for method copy of class Play
def test_Play_copy():
    # TODO: Implement this test
    pass

# Generated at 2022-06-23 06:31:47.741732
# Unit test for method compile of class Play
def test_Play_compile():
    # Unit test code:
    play1 = Play()
    play1.ansible_version = "2.8"
    play1.compile()

    # Print play1.roles
    print(play1.roles)

    # Print play1.compile()
    print(play1.compile())

    # Print play1.get_tasks()
    print(play1.get_tasks())

    play2 = Play()
    play2.compile()
    play2.get_tasks()

    # Print play2.serialize()
    print(play2.serialize())


# Generated at 2022-06-23 06:31:50.469838
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
        p =  Play()
        with pytest.raises(AnsibleAssertionError):
            p.preprocess_data(1)



# Generated at 2022-06-23 06:31:58.454559
# Unit test for constructor of class Play
def test_Play():
    play_source = dict(
        name="Test play",
        hosts="foo",
        roles="bar",
        tasks="baz"
    )

    play_instance = Play()
    play_instance.load_data(play_source)

    assert play_instance.get_name() == "Test play"
    assert play_instance.get_vars() == dict()
    assert play_instance.get_vars_files() == list()
    assert play_instance.get_handlers() == list()
    assert play_instance.get_roles() == list()

# Generated at 2022-06-23 06:32:07.667587
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_Play_get_name'
    assert play.get_name() == 'test_Play_get_name'
    play.name = None
    play.hosts = ['127.0.0.1']
    assert play.get_name() == '127.0.0.1'
    play.hosts = '127.0.0.1'
    assert play.get_name() == '127.0.0.1'
    play.hosts = '127.0.0.2'
    assert play.get_name() == '127.0.0.2'

# Generated at 2022-06-23 06:32:09.550532
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    """Unit test for method get_handlers of class Play."""
    instance = Play()
    result = instance.get_handlers()
    assert result == None

# Generated at 2022-06-23 06:32:15.899855
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    fake_loader = object()
    play = Play(loader=fake_loader)
    role = Role()
    handler = Handler()
    handler.register = "notified"
    handler.task = "meta"
    handler.args = {"flush_handlers": {}}
    role.handlers.append(handler)
    play.roles.append(role)
    assert play.compile_roles_handlers()[0] == handler

# Generated at 2022-06-23 06:32:18.716381
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play_1 = Play()
    play_1.roles = [Role()]
    assert play_1.get_roles() == play_1.roles


# Generated at 2022-06-23 06:32:21.016249
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    myplay = Play()
    myrole = Role()
    myplay.roles = [myrole]
    myplay.compile_roles_handlers()
    assert True

# Generated at 2022-06-23 06:32:30.720097
# Unit test for method serialize of class Play
def test_Play_serialize():
    var_manager = VariableManager()
    loader = DataLoader()
    play = Play()
    play._variable_manager = var_manager
    play._loader = loader
    play._ds = {'name': 'test'}
    play._loader._task_cache = {}
    play._included_path = ''
    play._action_groups = {}
    play._group_actions = {}
    assert play.serialize() == {'name': 'test', 'vars': {}, 'roles': [], 'included_path': '', 'action_groups': {}, 'group_actions': {}}


# Generated at 2022-06-23 06:32:43.841895
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [1, 2, 3]
    assert p.get_tasks() == [1, 2, 3]
    p.pre_tasks = [4, 5]
    p.post_tasks = [6, 7]
    assert p.get_tasks() == [4, 5, 1, 2, 3, 6, 7]
    p.pre_tasks = [4, 5]
    p.post_tasks = [6, 7]
    b = Block()
    b.block = [8, 9]
    p.tasks = [1, 2, b]
    assert p.get_tasks() == [4, 5, 1, 2, 8, 9, 6, 7]
    b.rescue = [10, 11]
    assert p.get_tasks

# Generated at 2022-06-23 06:32:53.184792
# Unit test for method copy of class Play
def test_Play_copy():
    from ansiblelint.rules import RulesCollection
    from ansiblelint.runner import Runner
    from ansiblelint import AnsibleLintRule
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars

    original = Play()
    original.vars = dict()
    # Issue 2909
    original.vault_password_file = AnsibleVaultEncryptedUnicode(
        None, b'/home/user/.vault_pass.txt')
    original.name = 'p1'
    original.tasks = [dict()]
    original.handlers = [dict()]
    original.roles = [
        Role(),
        Role(),
    ]

    copy = original.copy()

    assert original.vars

# Generated at 2022-06-23 06:32:55.232125
# Unit test for method load of class Play
def test_Play_load():
    play = Play()
    play.load()




# Generated at 2022-06-23 06:32:59.136216
# Unit test for method load of class Play
def test_Play_load():
    playbook_name = 'sample_playbook.yml'
    pb = Play.load(playbook_name)
    assert isinstance(pb, Play)

# Generated at 2022-06-23 06:33:06.366244
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.hosts is not None
    assert p.hosts == 'all'
    assert p.name == ''

    p = Play.load(dict(hosts='localhost'))
    assert p.hosts is not None
    assert p.hosts == 'localhost'
    assert p.name == 'localhost'


# *********************************************************************************
# *********************************************************************************

# *********************************************************************************
# *********************************************************************************

# Generated at 2022-06-23 06:33:15.736814
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-23 06:33:31.844355
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """
    This test verifies that the compile_roles_handlers method of the Play
    class produces a flat list of Block objects.
    """
    def mock_role(play, tasks=False, handlers=False):
        role = MagicMock()
        role.get_handler_blocks = MagicMock(return_value=handlers)
        role.get_tasks = MagicMock(return_value=tasks)
        return role
    p = Play()
    p._loader = DictDataLoader({
        "foo.yml": "key=value",
        "roles/foo/tasks/main.yml": "fake",
        "roles/bar/tasks/main.yml": "fake",
        "roles/baz/tasks/main.yml": "fake",
    })
    p

# Generated at 2022-06-23 06:33:37.922478
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))
    variable_manager.set_loader(loader)

    play_data = dict(
        name='test',
        hosts='localhost',
        gatherers=['gather_facts'],
        roles=[{'name':'role1', 'tasks':[{'name':'task1', 'tags':['tag1']}]}]
    )

    play = Play.load(play_data, variable_manager=variable_manager)

    assert play.get_handlers() == list()


# Generated at 2022-06-23 06:33:50.177010
# Unit test for method copy of class Play
def test_Play_copy():
    # Initializes a new instance of a Play
    play = Play()
    # Gets the copy of the play
    play_copy = play.copy()
    # Verifies that the ROLE_CACHE attribute of the play equals to the ROLE_CACHE attribute of the play_copy
    assert play.ROLE_CACHE == play_copy.ROLE_CACHE
    # Verifies that the _included_conditional attribute of the play is equal to the _included_conditional attribute of play_copy
    assert play._included_conditional == play_copy._included_conditional
    # Verifies that the _included_path attribute of the play is equal to the _included_path attribute of play_copy
    assert play._included_path == play_copy._included_path
    # Verifies that the _action_

# Generated at 2022-06-23 06:33:51.578422
# Unit test for method copy of class Play
def test_Play_copy():
    a = Play()
    b=a.copy()
    assert(a is not b)

# Generated at 2022-06-23 06:33:57.860345
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    roles1 = [Role(), Role()]
    play.roles = roles1
    roles2 = play.get_roles()
    # test get_roles returns a copy of roles
    assert set(roles1) == set(roles2)
    assert roles1 is not roles2
    # Can idempotently get roles
    assert play.get_roles() == play.get_roles()
