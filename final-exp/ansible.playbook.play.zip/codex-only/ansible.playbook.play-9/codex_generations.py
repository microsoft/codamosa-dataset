

# Generated at 2022-06-23 06:24:08.036915
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    play.ROLE_CACHE = {'a': 1}
    play._included_conditional = "a"
    play._included_path = "b"
    play._action_groups = {'c': 1}
    play._group_actions = {'d': 1}

    play_copy = play.copy()

    assert play.ROLE_CACHE == play_copy.ROLE_CACHE
    assert play._included_conditional == play_copy._included_conditional
    assert play._included_path == play_copy._included_path
    assert play._action_groups == play_copy._action_groups
    assert play._group_actions == play_copy._group_actions


# Generated at 2022-06-23 06:24:20.877435
# Unit test for method copy of class Play
def test_Play_copy():
    a_play = Play()
    a_play.ROLE_CACHE = {'role1':None, 'role2':None}
    a_play._included_conditional = 'a'
    a_play._included_path = 'b'
    a_play._action_groups = {'a':None, 'b':None}
    a_play._group_actions = {'a':None, 'b':None}
    new_play = a_play.copy()
    assert a_play.ROLE_CACHE == new_play.ROLE_CACHE
    assert a_play._included_conditional == new_play._included_conditional
    assert a_play._included_path == new_play._included_path
    assert a_play._action_groups == new_play._action_

# Generated at 2022-06-23 06:24:32.940794
# Unit test for method copy of class Play
def test_Play_copy():
    p1 = Play()
    p1._included_conditional = 'test'
    p1._included_path = 'path'
    p1._action_groups = {'a': 'group'}
    p1._group_actions = {'a': 'action'}
    p1.ROLE_CACHE = {'a': 1}
    p2 = p1.copy()
    assert p1._included_conditional == p2._included_conditional
    assert p1._included_path == p2._included_path
    assert p1._action_groups == p2._action_groups
    assert p1._group_actions == p2._group_actions
    assert p1.ROLE_CACHE == p2.ROLE_CACHE

# Generated at 2022-06-23 06:24:37.188503
# Unit test for constructor of class Play
def test_Play():
    '''
    >>> p = Play()
    >>> p.name == ''
    True
    >>> p.hosts == []
    True
    >>> p.vars == {}
    True
    '''


# Generated at 2022-06-23 06:24:42.089494
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [1, 2, 3]
    p.pre_tasks = [4, 5, 6]
    p.post_tasks = [7, 8, 9]
    assert p.get_tasks() == [4, 5, 6, 1, 2, 3, 7, 8, 9]
# unit test for method copy of class Play

# Generated at 2022-06-23 06:24:48.812289
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name == ''
    assert p.hosts == 'all'
    assert p.connection == 'smart'
    assert p.user == ''
    assert p.port == 0
    assert p.timeout == 10
    assert p.vars == getattr(p, '_Play__vars')
    assert p.vars_files == []
    assert isinstance(p.vars_prompt, list)
    assert p.vars_prompt == []
    assert p.handlers == []
    assert p.rsync_path == ''
    assert p.roles == []
    assert p.tasks == []
    assert p.gather_facts == 'yes'
    assert p.remote_user == ''
    assert p.remote_pass == ''
    assert p.sudo == 'no'


# Generated at 2022-06-23 06:24:59.783627
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role


# Generated at 2022-06-23 06:25:01.038867
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass # get_vars_files() has no implementation code yet



# Generated at 2022-06-23 06:25:04.168473
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    assert isinstance(p.get_roles(), list)
    p.roles = [1,2,3]
    assert p.get_roles() == [1,2,3]


# Generated at 2022-06-23 06:25:11.956154
# Unit test for method get_name of class Play
def test_Play_get_name():
    hosts1 = ['192.168.0.1']
    hosts2 = ['192.168.0.1', '192.168.0.2']

# Generated at 2022-06-23 06:25:14.400339
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p is not None


# Generated at 2022-06-23 06:25:18.811127
# Unit test for method get_name of class Play
def test_Play_get_name():
    pl = Play()
    if not isinstance(pl.get_name(), six.string_types):
        raise AssertionError()
    pl.name = 'test'
    if not isinstance(pl.get_name(), six.string_types):
        raise AssertionError()

# Generated at 2022-06-23 06:25:23.332559
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = ['pre_task']
    p.tasks = ['task']
    p.post_tasks = ['post_task']
    assert ['pre_task', 'task', 'post_task'] == p.get_tasks()


# Generated at 2022-06-23 06:25:32.785592
# Unit test for method load of class Play
def test_Play_load():
    # Test empty input
    data = {}
    play = Play.load(data)
    assert isinstance(play, Play)
    assert play.get_name() == ''

    # Test sequence input
    data = {'hosts': ['localhost'], 'vars': {'var1': 'val1'}, 'tasks': [{'action': {'module': 'ping'}}]}
    play = Play.load(data)
    assert play.get_name() == 'localhost'
    assert play.vars == {'var1': 'val1'}
    assert len(play.tasks) == 1
    task = play.tasks[0]
    assert isinstance(task, Task)
    assert task.action['module'] == 'ping'

    # Test string input

# Generated at 2022-06-23 06:25:38.440998
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {'key':'value'}
    valid_return_value = play.get_vars()
    assert type(valid_return_value) == dict
    assert valid_return_value == play.vars


# Generated at 2022-06-23 06:25:43.473774
# Unit test for method copy of class Play
def test_Play_copy():
    new_me = Play()
    new_me_obj = copy(new_me)
    assert new_me_obj == new_me
    assert new_me_obj is not new_me
    assert isinstance(new_me_obj, Play)
    assert new_me_obj.__dict__ == new_me.__dict__

# Generated at 2022-06-23 06:25:54.968870
# Unit test for method deserialize of class Play

# Generated at 2022-06-23 06:25:56.956608
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    c = p.copy()
    print (c.ROLE_CACHE)
test_Play_copy()


# Generated at 2022-06-23 06:25:57.705956
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass

# Generated at 2022-06-23 06:26:10.751234
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.name = 'test_play'
    p.tasks = [
        {'action': {'module': 'copy', 'args': 'src=a dest=b'}},
        {'action': {'module': 'copy', 'args': 'src=a dest=b'}}
    ]
    p.compile()
    assert "action" in p.tasks[0].keys()
    assert "compiled from '<unicode string>'" in p.tasks[0].keys()
    assert "action" in p.tasks[1].keys()
    assert "compiled from '<unicode string>'" in p.tasks[1].keys()
    assert "action" not in p.tasks[2].keys()
    assert "meta" in p.tasks[2].keys()


# Generated at 2022-06-23 06:26:14.511267
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Dummy method for testing purpose
    test = True
    if test:
        print("Test: test_Play_compile_roles_handlers -- TODO")
        return

    pass


# Generated at 2022-06-23 06:26:19.983890
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():

    # test Play.get_handlers()
    play = Play()
    handlers = play.get_handlers()
    assert 'list' == type(handlers).__name__
    assert [] == handlers
    # end of test


if __name__ == '__main__':
    test_Play_get_handlers()

# Generated at 2022-06-23 06:26:24.574652
# Unit test for method compile of class Play
def test_Play_compile():
    # setup test object
    play = Play()
    # test name parameter gets to the method
    play.compile()
# setup test object
play = Play()

# unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-23 06:26:27.041814
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.name = 'test name'

    assert p.__repr__() == 'test name'


# Generated at 2022-06-23 06:26:28.846113
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # TODO
    pass


# Generated at 2022-06-23 06:26:33.793369
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert play.get_name() == ''
    play = Play(hosts='hosts')
    assert play.get_name() == 'hosts'
    play = Play(hosts=['host1', 'host2'])
    assert play.get_name() == 'host1,host2'


# Generated at 2022-06-23 06:26:43.644333
# Unit test for method load of class Play
def test_Play_load():

    # ansible/playbook/__init__.py:37
    # Declare a test Play
    test_play = Play()

    # ansible/playbook/__init__.py:44
    # Declare a test dict
    test_dict = dict()

    # ansible/playbook/__init__.py:49
    # Declare a test variable_manager
    test_variable_manager = None

    # ansible/playbook/__init__.py:50
    # Declare a test loader
    test_loader = None

    # ansible/playbook/__init__.py:51
    # Declare a test vars
    test_vars = None

    return test_play.load(test_dict, test_variable_manager, test_loader, test_vars)

# Generated at 2022-06-23 06:26:46.116315
# Unit test for method load of class Play
def test_Play_load():
    '''
    Unit test class Play.load
    '''
    args = {}
    p = Play()

    # Test the case where the vars argument is []
    vars = []
    result = p.load(args, vars=vars)


# Generated at 2022-06-23 06:26:50.094154
# Unit test for method load of class Play
def test_Play_load():
    data = dict(hosts='localhost')
    play = Play.load(data)
    assert play.hosts == ['localhost']


# Generated at 2022-06-23 06:27:00.467894
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Tests if the function Play.get_handlers() is working
    # Play: Instance of the class 'Play'
    Play = Play()
    # expected: The expected result of the function Play.get_handlers()
    expected = []
    assert Play.get_handlers() == expected, "The get_handlers() method of Play() is not working"

    # Tests if the function Play.get_handlers() is working
    # Play: Instance of the class 'Play'
    Play = Play()
    # handlers1: The handlers passed to the constructor of the class 'Play'
    handlers1 = [{'name': 'task1'}, {'name': 'task2'}]
    # expected: The expected result of the function Play.get_handlers()

# Generated at 2022-06-23 06:27:06.583744
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    ######################################################################
    #
    # unit test for method get_roles of class Play
    #
    ######################################################################
    play = Play()
    play.roles = []
    assert play.roles is not None
    assert play.get_roles() == []
    role = Role()
    role.name = "test_role"
    play.roles.append(role)
    assert play.get_roles() == [role]

# Generated at 2022-06-23 06:27:11.898090
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # test_data
    play = Play()
    play.vars = {'foo': 'bar'}
    # test_get_vars
    #test_vars = play.get_vars()
    assert play.vars == play.get_vars()


# Generated at 2022-06-23 06:27:20.980999
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # test1
    p = Play()
    ds = p.preprocess_data(dict)
    assert ds is not None
    assert isinstance(ds, dict)

    # test2
    p = Play()
    ds = p.preprocess_data(None)
    assert ds is not None
    assert isinstance(ds, dict)

    # test3
    p = Play()
    ds = p.preprocess_data(int)
    assert ds is None

# Generated at 2022-06-23 06:27:28.713591
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test"
    assert play.get_name() == "test"
    play.name = None
    play.hosts = "test"
    assert play.get_name() == "test"
    play.hosts = "host-01"
    assert play.get_name() == "host-01"
    play.hosts = [ "host-01", "host-02" ]
    assert play.get_name() == "host-01,host-02"


# Generated at 2022-06-23 06:27:36.086800
# Unit test for method copy of class Play
def test_Play_copy():
    from ansible.playbook.base import PlaybookBase
    from ansible.vars.manager import VariableManager
    from ansible.vars import Variable
    from ansible.parsing.dataloader import DataLoader

    # Instantiate mock objects
    variable_manager_instance = Mock(spec=VariableManager)
    loader_instance = Mock(spec=DataLoader)
    variable_manager_instance.get_vars.return_value = dict()
    loader_instance.get_basedir.return_value = "/PATH/TO/"
    vars_dict = dict()
    vars_dict["var1"] = Variable("var1")
    vars_dict["var2"] = Variable("var2")
    vars_dict["var3"] = Variable("var3")
    variable_manager_instance.get_vars.return_

# Generated at 2022-06-23 06:27:43.057677
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    block_list = _test_Play_compile_roles_handlers()
    if (len(block_list) == 2) and (len(block_list[0].block) == 1) and (block_list[0].block[0].action == 'meta') and (block_list[0].block[0].args == 'flush_handlers') and (len(block_list[1].block) == 1) and (block_list[1].block[0].action == 'meta') and (block_list[1].block[0].args == 'flush_handlers'):
        return True
    return False

# Generated at 2022-06-23 06:27:51.796643
# Unit test for method load of class Play
def test_Play_load():
    '''
    This test makes sure that the plugin Play() is capable of loading a yaml file
    into the Play class. The yaml is a dict containing the play meta data.
    '''
    yaml_data = {'name': 'test_playload-playbook1', 'hosts': 'test_playload-all'}
    plugin_test = Play()
    plugin_test.load(yaml_data)
    # test if the name is loaded correctly
    assert plugin_test.name == yaml_data['name']
    # test if the hosts are loaded correctly
    assert plugin_test.hosts == yaml_data['hosts']
    # test if the class has set its ds to the yaml_data
    assert plugin_test._ds == yaml_data



# Generated at 2022-06-23 06:27:55.745635
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p    = mock.Mock()
    Play = Play()
    Play.get_roles = get_roles(p)
    assert_equals(Play.get_roles(),p.roles)

# Generated at 2022-06-23 06:28:05.855615
# Unit test for constructor of class Play
def test_Play():
    class TestPlay(Play):
        _base_class = Play
        _base_attributes = Play._base_attributes

    class TestData:
        def __init__(self, data):
            self.data = data

        def get(self, key, default=None):
            return self.data.get(key, default)

    test_play = TestPlay()
    test_data = TestData({})
    test_play.vars = test_data

    assert test_play.vars == {}, "Fail: Play constructor is not working properly, 1st test"

    test_data = TestData({'gather_facts': True})
    test_play.vars = test_data
    assert test_play.vars == {'gather_facts': True}, "Fail: Play constructor is not working properly, 2nd test"



# Generated at 2022-06-23 06:28:18.376827
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Creation of a Play instance with args
    p = Play()

    p.get_terminal_width = lambda: 80  # jinja2.utils.terminal_width()
    # Creation of a Play instance with kwargs
    role = p.load(dict(
        name="test.yml",
        hosts=["all"],
        gather_facts="no",
        vars=dict(a=1, b=2, c="string"),
        roles=[],
    ))

    result = role.serialize()

# Generated at 2022-06-23 06:28:29.218605
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Unit test for method compile_roles_handlers of class Play
    '''
    # Compiles and returns the handler list for this play, compiled from the
    # roles (which are themselves compiled recursively).
    try:
        data = dict(
            name="test_role", # Valid
        )
        play = Play()
        play.vars = dict()
        play.hosts = ""

        play.deserialize(data)
        play.compile_roles_handlers()
    except Exception as e:
        print(e)
        logger.debug("[TEST] Method compile_roles_handlers of class Play threw an exception")
        raise


# Generated at 2022-06-23 06:28:41.509072
# Unit test for method serialize of class Play
def test_Play_serialize():
    c = Play()
    s = c.serialize()
    assert c.vars == None
    assert c.hosts == 'all'
    assert c.name == ''
    assert c.connection == 'smart'
    assert c.max_fail_percentage == None
    assert c.serial == None
    assert c.strategy == 'linear'
    assert c.remote_user == C.DEFAULT_REMOTE_USER
    assert c.remote_port == C.DEFAULT_REMOTE_PORT
    assert c.sudo == False
    assert c.sudo_user == C.DEFAULT_SUDO_USER
    assert c.sudo_pass == False
    assert c.sudo_exe == None
    assert c.sudo_flags == None
    assert c.tags == set()
    assert c.gather_facts == True
   

# Generated at 2022-06-23 06:28:53.158453
# Unit test for method get_name of class Play
def test_Play_get_name():
    my_object = Play()
    my_object.vars = dict()
    my_object._variable_manager = dict()
    my_object.DS = 'ok'
    my_object.only_tags = set(context.CLIARGS.get('tags', [])) or frozenset(('all',))
    my_object.skip_tags = set(context.CLIARGS.get('skip_tags', []))
    my_object.ROLE_CACHE = dict()
    my_object._included_conditional = None
    my_object._included_path = None
    my_object._removed_hosts = []
    my_object._action_groups = dict()
    my_object._group_actions = dict()
    my_object.post_validate_data()
    my_object.host

# Generated at 2022-06-23 06:29:05.319386
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    import yaml
    yaml_text = '''
                 - name: copy local file to remote server
                   copy:
                     src: /etc/hosts
                     dest: /tmp/hosts
                     owner: root
                     group: root
                     mode: "u=rw,g=r,o=r"
                 '''
    data = yaml.safe_load(yaml_text)
    p = Play()
    result = p.preprocess_data(data)
    assert type(result) == list
    assert result[0] == {'name': 'copy local file to remote server', 'copy': {'dest': '/tmp/hosts', 'src': '/etc/hosts', 'group': 'root', 'owner': 'root', 'mode': 'u=rw,g=r,o=r'}}

# Generated at 2022-06-23 06:29:07.551603
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create a test Play object
    play = Play()
    # Assert the equality of property 'name' of play object
    assert play.name == ''

# Generated at 2022-06-23 06:29:13.833610
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()
    test_play.ROLE_CACHE = {}
    test_play.roles = []
    test_play.role = {}

    print("Test 1: Empty role")
    result = test_play.compile_roles_handlers()
    print("result: " + str(result))
    assert isinstance(result, list) == True
    assert len(result) == 0
    print("\n")

    print("Test 2: Multiple roles")
    test_play1 = Play()
    test_play1.ROLE_CACHE = {}
    test_play1.roles = []
    test_play1.role = {}

    role_include_obj2 = RoleInclude()
    role_include_obj2.role_name = "test-role"
    role_include_

# Generated at 2022-06-23 06:29:19.640463
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'hello'

    assert play.name == play.get_name()

    play.name = None
    play.hosts = 'localhost'
    assert play.hosts == play.get_name()

    play.hosts = ['localhost']
    assert play.hosts == play.get_name()


# Generated at 2022-06-23 06:29:24.354876
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Mock class Task
    play = Play()
    play1 = Play()
    play2 = Play()
    # Mock func get_tasks
    tasklist = [play, play1, play2]
    assert play.get_tasks() == tasklist

# Generated at 2022-06-23 06:29:33.795249
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    ds = {'user': 'test_user'}
    assert p.preprocess_data(ds) == {'remote_user': 'test_user'}

    ds = {'remote_user': 'test_user'}
    assert p.preprocess_data(ds) == {'remote_user': 'test_user'}

    ds = {'user': 'test_user', 'remote_user': 'test_remote_user'}
    with pytest.raises(AnsibleParserError):
        p.preprocess_data(ds)

    ds = None
    assert p.preprocess_data(ds) == {}


# Generated at 2022-06-23 06:29:40.414731
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    po = PlaybookExecutor(playbooks=['/etc/ansible/Test_case/test.yml'], inventory=inventory, variable_manager=variable_manager, loader=loader, passwords={})
    play = po._get_play_from_playbook()[0]
    assert play.get_handlers() == [], 'There are no handlers in the play'


# Generated at 2022-06-23 06:29:56.356633
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play_data = dict(
        name='some.yml',
        roles=dict(
            cli_args=dict(
                roles=dict(
                    foo=dict(
                        name='foo',
                        tasks=dict(
                            main=dict(
                                block=dict(
                                    tasks=[
                                        dict(action=dict(module='shell', args='echo bar')),
                                    ]
                                )
                            )
                        )
                    )
                )
            )
        )
    )

    from units.mock.loader import DictDataLoader
    from units.mock.vars_plugin import VarsModule
    from units.mock.sys_path import MockSysPathPlugin
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import Task

# Generated at 2022-06-23 06:30:04.371891
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.module_utils.six import string_types
    # Run module patching
    if not string_types:
        string_types = (str,)
    
    modules_to_patch = ('ansible.module_utils.basic.basic',)
    patches = {}
    for modulename in modules_to_patch:
        patches[modulename] = True
    StageMock.patch(patches)
    import ansible.module_utils.basic as basic
    
    


# Generated at 2022-06-23 06:30:07.258750
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
  play = Play()
  assert(play.get_handlers() == [])


# Generated at 2022-06-23 06:30:15.481454
# Unit test for method copy of class Play
def test_Play_copy():
    source = Play()
    source.ROLE_CACHE = {}
    source._action_groups = {}
    source._group_actions = {}
    source._included_conditional = True
    source._included_path = '/home/aoeu'
    play = source.copy()
    assert play.ROLE_CACHE == source.ROLE_CACHE
    assert play._action_groups == source._action_groups
    assert play._group_actions == source._group_actions
    assert play._included_path == source._included_path


# Generated at 2022-06-23 06:30:18.762421
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = [1,2,3]
    assert p.get_handlers() == p.handlers


# Generated at 2022-06-23 06:30:31.609110
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    # Set attribute ROLE_CACHE
    play.ROLE_CACHE = {
        'key_1': "value_1",
        'key_2': "value_2",
    }
    # Set attribute _included_conditional
    play._included_conditional = {
        'key_1': "value_1",
        'key_2': "value_2",
    }
    # Set attribute _included_path
    play._included_path = {
        'key_1': "value_1",
        'key_2': "value_2",
    }
    # Set attribute _action_groups
    play._action_groups = {
        'key_1': "value_1",
        'key_2': "value_2",
    }
    #

# Generated at 2022-06-23 06:30:35.220837
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.load_data({'user': 'a'})

    # noinspection PyTypeChecker
    play.preprocess_data({'user': 'a'})



# Generated at 2022-06-23 06:30:38.876314
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = {}
    ds['user'] = 'ansible'
    Play().preprocess_data(ds)
    assert 'user' not in ds
    assert ds['remote_user'] == 'ansible'

# Generated at 2022-06-23 06:30:40.725068
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play_instance = Play()
    assert play_instance.get_roles() == []



# Generated at 2022-06-23 06:30:45.549594
# Unit test for method __repr__ of class Play
def test_Play___repr__():

    # Arrange
    p = Play()
    p.name = 'test'
    # Act
    res = p.__repr__()
    # Assert
    assert res == 'test'


# Generated at 2022-06-23 06:30:58.095889
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.vars import VariableManager, HostVars
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader

    add_all_plugin_dirs()
    # 1. Setup test objects
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.host_vars = HostVars(loader=loader, variable_manager=variable_manager)
    play = Play()
    play.name = 'Test'
    play.hosts = '127.0.0.1'
    play.become = False
    play.become_user = None
    play._variable_manager = variable_manager
    play._loader = loader
    play.vars = dict(var1='value', var2='value2')


# Generated at 2022-06-23 06:30:59.941096
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    '''
    get_roles()
    '''
    pass


# Generated at 2022-06-23 06:31:01.164675
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    Play.compile_roles_handlers()

# Generated at 2022-06-23 06:31:14.727611
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    # 두개의 task와 한개의 handler를 포함하는 play 생성
    # play를 생성하는 과정이 좀 까다로움.
    play.tasks = [
        Task.load(dict(action="shell : pwd", name="pwd"), play=play),
        Task.load(dict(action="shell : pwd", name="pwd"), play=play)
    ]
    play.handlers = [
        Handler.load(dict(action="shell : pwd", name="pwd"), play=play)
    ]
    # Play에서 handler

# Generated at 2022-06-23 06:31:20.032036
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    ''' Update: copy method is added to class Play
        so testing on get_handlers of class play is not needed anymore
        Because we do testing on methods of class PlayImpl,
        so it has no relation with methods of class Play.
    '''
    pass


# Generated at 2022-06-23 06:31:27.371856
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()

# Generated at 2022-06-23 06:31:29.623305
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play._data = {'hosts':'localhost'}
    assert repr(play) == play.get_name()

# Generated at 2022-06-23 06:31:35.941743
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.hosts == 'all'
    assert play.get_name() == ''
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'group1'
    assert play.get_name() == 'group1'
    play.hosts = ['group1', 'group2']
    assert play.get_name() == 'group1,group2'


# Generated at 2022-06-23 06:31:45.479772
# Unit test for method get_name of class Play
def test_Play_get_name():
    Play.ROLE_CACHE = {}
    Play._included_conditional = None
    Play._included_path = None
    Play._removed_hosts = []
    Play.only_tags = set(context.CLIARGS.get('tags', [])) or frozenset(('all',))
    Play.skip_tags = set(context.CLIARGS.get('skip_tags', []))
    Play._action_groups = {}
    Play._group_actions = {}

    p = Play()
    p.name = "Test-Play-Name"
    assert p.get_name() == "Test-Play-Name"

# Generated at 2022-06-23 06:31:57.083924
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Input data.
    ds1 = {
        'hosts': 'all',
        'user': 'vagrant',
        'remote_user': 'vagrant',
        'serial': [],
        'gather_facts': 'no',
        'vars_prompt': [],
        'tasks': [],
        'tasks_filters': '',
        'post_tasks': [],
        'handlers': [],
        'vars': {},
        'vars_files': [],
        'any_errors_fatal': 'no',
        'roles': []
    }

# Generated at 2022-06-23 06:32:03.975894
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    # Need to set "block" as "block" is not set by default
    play.block = []
    # Need to set "handlers" as "handlers" is not set by default
    play.handlers = []
    play.vars = dict(test_Play_serialize_vars)
    play.vars_prompt = []
    # Need to set "post_tasks" as "post_tasks" is not set by default
    play.post_tasks = []
    play.included_path = None
    play.max_fail_percentage = None
    play.hosts = 'hosts'
    # Need to set "pre_tasks" as "pre_tasks" is not set by default
    play.pre_tasks = []
    play.tasks = []
   

# Generated at 2022-06-23 06:32:07.130792
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    print('Test Play.__repr__')
    test_play = Play()
    assert test_play.__repr__() == test_play.get_name(), 'Test Failed'



# Generated at 2022-06-23 06:32:10.570683
# Unit test for method compile of class Play
def test_Play_compile():
    # default play object
    p = Play()
    # setup test data
    p.tasks = [{"action": {"__ansible_module__": "shell", "__ansible_arguments__": "command=ls /a path=/path"},
                "name": "gather facts", "register": "fact"}]
    
    # run test
    p.compile()

# Generated at 2022-06-23 06:32:21.978375
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    '''
    Unit test for method get_handlers of class Play
    '''
    test_context = {}
    playbook_path = 'test/unit/fixtures/playbook.yml'
    playbook = Playbook.load(playbook_path, variable_manager=VariableManager(), loader=DataLoader())
    test_context['play'] = playbook.get_plays_by_name('test_play')[0]
    test_play = test_context['play']
    assert len(test_play.get_handlers()) == 2
    original_handlers = test_play.get_handlers()[:]
    original_handlers[0].action = 'debug'
    assert len(test_play.get_handlers()) == 2
    assert len(test_play.get_handlers()) == 2
test_Play_get_hand

# Generated at 2022-06-23 06:32:27.101851
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    # Test that get_roles method works
    p = Play()
    r1 = Role()
    r2 = Role()
    p.roles = [r1, r2]
    assert p.get_roles() == [r1, r2]


# Generated at 2022-06-23 06:32:36.372757
# Unit test for method deserialize of class Play

# Generated at 2022-06-23 06:32:37.752627
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass


# Generated at 2022-06-23 06:32:41.377567
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert p.__repr__() == ''
    p.name = 'Test'
    assert p.__repr__() == p.get_name()

# Generated at 2022-06-23 06:32:42.558360
# Unit test for method load of class Play
def test_Play_load():
    pass



# Generated at 2022-06-23 06:32:52.424393
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import ansible.playbook.block
    import ansible.playbook.role
    global T_Block
    T_Block = ansible.playbook.block.Block
    global T_Role
    T_Role = ansible.playbook.role.Role
    import ansible.playbook.play
    global T_Play
    T_Play = ansible.playbook.play.Play
    import ansible.playbook.task
    global T_Task
    T_Task = ansible.playbook.task.Task
    import ansible.utils.unsafe_proxy
    global T_unsafe_proxy
    T_unsafe_proxy = ansible.utils.unsafe_proxy.AnsibleUnsafeText
    import ansible.utils.unsafe_proxy
    global T_unsafe_proxy

# Generated at 2022-06-23 06:32:55.459315
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = "test"
    assert(str(play) == play.get_name())


# Generated at 2022-06-23 06:33:08.361439
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    assert Play().preprocess_data(dict()) == dict()
    assert Play().preprocess_data("string") is "string"
    assert Play().preprocess_data(1) == 1
    assert Play().preprocess_data(list()) == list()
    assert Play().preprocess_data(set()) == set()
    assert Play().preprocess_data(None) is None
    assert Play().preprocess_data(False) is False
    assert Play().preprocess_data(True) is True
    assert Play().preprocess_data(dict(user="bob")) == dict(remote_user="bob")
    assert Play().preprocess_data(dict(ansible_user="bob")) == dict(ansible_user="bob")
    assert Play().preprocess_data(dict(ansible_user="bob", user="jim"))

# Generated at 2022-06-23 06:33:12.129795
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    mock = mocker.Mocker()
    play = Play()
    mock_vars = mock.mock()
    play.vars = mock_vars
    expect(mock_vars.copy())
    play.get_vars()


# Generated at 2022-06-23 06:33:13.508886
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-23 06:33:24.865277
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.q_vars_files = [
        {
            "var_file": "host_vars/hostA.yml"
        },
        {
            "var_file": "host_vars/hostB.yml"
        }
    ]
    print(play.q_vars_files)
    print(play.get_vars())
    print(play.get_vars_files())

if __name__ == "__main__":
    test_Play_get_vars_files()

# Generated at 2022-06-23 06:33:32.636148
# Unit test for method compile of class Play
def test_Play_compile():
    pp = Play()
    pp.tasks = [{'action': dict(module='copy', args=dict(src='/tmp/x', dest='/tmp/y'))}]
    r = pp.compile()
    assert r == [
        {
            'action': dict(
                module='copy',
                args=dict(src='/tmp/x', dest='/tmp/y'),
            ),
        },
    ]



# Generated at 2022-06-23 06:33:44.795227
# Unit test for method preprocess_data of class Play

# Generated at 2022-06-23 06:33:52.354904
# Unit test for method serialize of class Play
def test_Play_serialize():
    #
    # These are from examples in the ansible YAML documentation
    # https://docs.ansible.com/ansible/2.0/reference_appendices/YAMLSyntax.html
    #
    # The first is a simple dictionary
    dict_data = {
        'Names': ['Karl', 'Anne', 'Martin', 'Steven'],
        'Ages': [26, 24, 51, 42]
    }
    #
    # The next three are variations of a list of data
    #
    list_data = [
        {'Name': 'Karl', 'Age': 26},
        {'Name': 'Anne', 'Age': 24},
        {'Name': 'Martin', 'Age': 51},
        {'Name': 'Steven', 'Age': 42}
    ]


# Generated at 2022-06-23 06:34:03.565985
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible import constants
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager, loader_objects=[])
    test_class = Play()