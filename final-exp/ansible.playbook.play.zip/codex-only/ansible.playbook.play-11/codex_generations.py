

# Generated at 2022-06-23 06:24:02.044966
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
	pass
	# Get the list of tasks in this Play
		# Return a list of tasks assigned to this play
	# end
# end

	# Unit test for method preprocess_data of class Play

# Generated at 2022-06-23 06:24:02.799093
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-23 06:24:04.463100
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert play.__repr__() == play.get_name()


# Generated at 2022-06-23 06:24:07.932971
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Test using constructor syntax
    p = Play('test_name', {}, [], [], [], [], [], "")
    assert p.get_handlers() == []
    # Test using object syntax
    p.handlers = ['test']
    assert p.get_handlers() == ['test']


# Generated at 2022-06-23 06:24:20.877138
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play1 = Play('test_name', '127.0.0.1', [], [], 1)
    role1 = Role('role1', [], [], '127.0.0.1', [], [], [], [], [], [], [], [], [], [], [], [])
    role2 = Role('role2', [], [], '127.0.0.1', [], [], [], [], [], [], [], [], [], [], [], [])
    role3 = Role('role3', [], [], '127.0.0.1', [], [], [], [], [], [], [], [], [], [], [], [])
    # Get a task list from play1, which contains 3 roles and no handlers.
    task_list1 = play1.compile_ro

# Generated at 2022-06-23 06:24:31.693494
# Unit test for method serialize of class Play
def test_Play_serialize():
    test_Play = Play()
    test_Play.hosts = 'hosts_test'
    test_Play.name = 'name_test'

    test_roles = []
    test_roles.append({
        'name': 'name_test',
        '_role_path': '_role_path_test'
    })
    test_Play.roles = test_roles
    test_Play._included_path = '_included_path_test'
    test_Play._action_groups = '_action_groups_test'
    test_Play._group_actions = '_group_actions_test'

    new_test_Play = test_Play.copy()
    new_test_Play.ROLE_CACHE = test_Play.ROLE_CACHE.copy()
    new_test_Play

# Generated at 2022-06-23 06:24:38.001279
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    """
    Test __repr__
    """
    a = Play()
    a.name = "test_play"
    assert "test_play" == a.__repr__()
    a.name = ""
    a.hosts = "test_host"
    assert "test_host" == a.__repr__()


# Generated at 2022-06-23 06:24:42.133627
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # Arrange
    mock_self = MagicMock()
    mock_self.vars = {}

    # Act
    actual = Play.get_vars(mock_self)

    # Assert
    assert actual == mock_self.vars.copy()

# Generated at 2022-06-23 06:24:44.837233
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = dict(foo='bar')
    assert play.get_vars() == dict(foo='bar')


# Generated at 2022-06-23 06:24:48.270525
# Unit test for method load of class Play
def test_Play_load():
    data = {}
    variable_manager = VariableManager()
    loader = None
    vars = None
    p = Play.load(data, variable_manager, loader, vars)
    assert type(p) is Play

# Generated at 2022-06-23 06:24:51.273198
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    Play_obj = Play()
    Play_obj.vars = {}
    assert Play_obj.get_vars() == {}

# Generated at 2022-06-23 06:25:01.320366
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Unit test for method get_handlers of class Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.executor.task_result import TaskResult
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    # Test Data

# Generated at 2022-06-23 06:25:10.162027
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-23 06:25:12.642142
# Unit test for constructor of class Play
def test_Play():
    assert not isinstance(Play(), Role)
    assert isinstance(Play(), Base)


# Generated at 2022-06-23 06:25:25.862990
# Unit test for method copy of class Play
def test_Play_copy():
    a_play = Play()
    assert a_play
    a_play.ROLE_CACHE = {}
    a_play._included_conditional = 'blabla'
    a_play._included_path = 'blabla'
    a_play._action_groups = {1: 2}
    a_play._group_actions = {1: 2}
    assert a_play.copy()
    assert a_play.copy().ROLE_CACHE == {}
    assert a_play.copy()._included_conditional == 'blabla'
    assert a_play.copy()._included_path == 'blabla'
    assert a_play.copy()._action_groups == {1: 2}
    assert a_play.copy()._group_actions == {1: 2}



# Generated at 2022-06-23 06:25:33.247048
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._load_roles = MagicMock(return_value = [MagicMock(spec=Role, from_include=False), MagicMock(spec=Role, from_include=False)])
    p.roles[0].get_handler_blocks = MagicMock(return_value = ['handler1', 'handler2'])
    p.roles[1].get_handler_blocks = MagicMock(return_value = ['handler3', 'handler4'])
    handler_blocks = p.compile_roles_handlers()
    assert handler_blocks == ['handler1', 'handler2', 'handler3', 'handler4']

# Generated at 2022-06-23 06:25:37.915123
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    global TEST_PLAY
    roletest = Role()
    TEST_PLAY.roles = [roletest]
    playrole = TEST_PLAY.get_roles()
    return playrole[0] == roletest

# Generated at 2022-06-23 06:25:42.415226
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_Play_obj = Play()
    test_Play_obj.deserialize({"roles": [], "included_path": None, "action_groups": {}, "group_actions": {}})
    assert isinstance(test_Play_obj, Play)



# Generated at 2022-06-23 06:25:54.125067
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize(data={'name': 'test', 'hosts': ['test1', 'test2'], 'roles': [
        {
            'name': 'test',
            'hosts': ['test1', 'test2']
        }
    ], 'action_groups': {'test': [{'name': 'test'}]}, 'group_actions': {'test': [{'name': 'test'}]}})
    assert len(play.roles) == 1
    assert isinstance(play.roles[0], Role)
    assert play.roles[0].name == 'test'
    assert play.roles[0].hosts == ['test1', 'test2']
    assert play.name == 'test'

# Generated at 2022-06-23 06:26:00.140810
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    """
    Test get_roles of class Play
    """
    import builtins

# Generated at 2022-06-23 06:26:13.594608
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play1 = Play()
    # play1.pre_tasks = ['a', 'b', 'c', 'd']
    # play1.tasks = ['e', 'f', 'g', 'h']
    # play1.post_tasks = ['i', 'j', 'k', 'l']
    # assert play1.get_tasks() == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l']
    play1.pre_tasks = [Block()]
    play1.pre_tasks[0].block = ['a', 'b']
    play1.pre_tasks[0].rescue = ['c']
    play1.pre_tasks[0].always = ['d']

# Generated at 2022-06-23 06:26:23.915879
# Unit test for method serialize of class Play
def test_Play_serialize():
    '''
    Unit test for method serialize of class Play
    '''
    #    p = Play()
    #    for role in p.get_roles():
    #        roles.append(role.serialize())
    #        data['roles'] = roles
    #        data['included_path'] = self._included_path
    #        data['action_groups'] = self._action_groups
    #        data['group_actions'] = self._group_actions
    #        return data

    #    super(Play, self).deserialize(data)
    #    self._included_path = data.get('included_path', None)
    #    self._action_groups = data.get('action_groups', {})
    #    self._group_actions = data.get('group_actions', {})


# Generated at 2022-06-23 06:26:35.499381
# Unit test for method copy of class Play
def test_Play_copy():
    my_play = Play()
    my_play.ROLE_CACHE = {'key1': 'value1'}
    my_play._included_conditional = 'my_play._included_conditional'
    my_play._included_path = 'my_play._included_path'
    my_play._action_groups = {'key1': 'value1'}
    my_play._group_actions = {'key1': 'value1'}
    my_copy = my_play.copy()
    assert compare_json(my_copy.ROLE_CACHE , my_play.ROLE_CACHE)
    assert compare_json(my_copy._included_conditional , my_play._included_conditional)

# Generated at 2022-06-23 06:26:45.240859
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create play
    play = Play()
    play.ROLE_CACHE = {}
    play._included_conditional = None
    play._included_path = None
    play._removed_hosts = []

    # Create task
    task = Task()
    task.action = "test_action"

    block = Block()
    block.block = [task]
    block.rescue = None
    block.always = None
    block.name = None
    block.parent_block = None

    role = Role()
    role.from_include = False
    role.tasks_pattern = '';
    role.handlers_pattern = '';
    role.default_tasks_pattern = '';
    role.default_handlers_pattern = '';
    role.ROLE_CACHE = {}
   

# Generated at 2022-06-23 06:26:51.746632
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    # sets roles to [{}, {}]
    play.roles = [{}, {}]
    # expects roles to be [{}, {}]
    assert_true(play.get_roles() == [{}, {}])


# Generated at 2022-06-23 06:26:58.068700
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    ds = {'hosts': 'c'}
    # Run function __repr__ of class Play with parameters: ds
    my_play = Play.load(ds)
    result = my_play.__repr__()
    #__repr__ should return a string
    assert isinstance(result, str)

# Generated at 2022-06-23 06:27:07.678973
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test="""
- hosts: localhost
  vars:
    - minion_id: test
  roles:
    - test

  pre_tasks:
    - name: test
      test:
        key: value
        index: 0
  tasks:
    - name: test
      test:
        key: value
        index: 1
  post_tasks:
    - name: test
      test:
        key: value
        index: 2
  handlers:
     - name: test
       test:
         key: value
         index: 3
"""
    play=Play().load(data=yaml.load(test))
    data=[each.serialize() for each in play.get_tasks()]
    assert data[0]["task_args"]["index"]=="0"

# Generated at 2022-06-23 06:27:18.458578
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    #Setting filepath attribute to a non-existing path to avoid overwriting an actual file
    play.vars_prompt.append({'name':'test_variable1','prompt':'What is the test_variable1 value?','private':True,'default':''})
    play.vars_prompt.append({'name':'test_variable2','prompt':'What is the test_variable2 value?','private':False,'default':''})

    data = play.serialize()
    data = json.dumps(data)
    deserialized_play = Play()
    deserialized_play.deserialize(json.loads(data))
    assert deserialized_play.vars_prompt[0]['name'] == 'test_variable1'
    assert deserialized_play.vars_

# Generated at 2022-06-23 06:27:24.481471
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play.load(play_data1)
    assert hasattr(play, 'get_tasks')
    tasks = play.get_tasks()
    assert isinstance(tasks, list)
    assert len(tasks) == 3
    assert tasks[0].action == 'shell'
    assert tasks[1].action == 'shell'


# Generated at 2022-06-23 06:27:26.028591
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.get_vars()

# Generated at 2022-06-23 06:27:34.550079
# Unit test for method serialize of class Play
def test_Play_serialize():
    # In
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:27:36.556128
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.hosts = "localhost"
    assert play.get_name() == "localhost"

# Generated at 2022-06-23 06:27:42.500814
# Unit test for constructor of class Play
def test_Play():
    # no args
    p = Play()
    assert p.vars is None
    assert p.roles is None
    assert isinstance(p._roles, list)
    assert p.handlers is None
    assert isinstance(p._handlers, list)
    assert isinstance(p.tasks, list)
    assert isinstance(p.pre_tasks, list)
    assert isinstance(p.post_tasks, list)
    assert p.hosts is None


# Generated at 2022-06-23 06:27:50.867909
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # type: () -> None
    # Tests the method get_handlers of the class Play using a fake handler
    # and a real handler
    p = Play.load(dict(
        name='fake handler',
        hosts=['localhost']
    ))

    assert len(p.handlers) == 0

    p = Play.load(dict(
        name='fake handler',
        hosts=['localhost'],
        tasks=[dict(meta='fake handler')]
    ))

    assert len(p.handlers) == 1



# Generated at 2022-06-23 06:28:03.180478
# Unit test for constructor of class Play
def test_Play():

    # Test with Minimal arguments
    p = Play()
    assert p.name == ''
    assert p.hosts == ''
    assert p.tasks == []
    assert p.pre_tasks == []
    assert p.post_tasks == []
    assert p.roles == []
    assert p.handlers == []
    assert p.tags == frozenset(('all',))
    assert p.skip_tags == frozenset(())
    assert p.vars == {}
    assert p.vars_files == []
    assert p.vars_prompt == []
    assert p.any_errors_fatal == True
    assert p.force_handlers == False
    assert p.max_fail_percentage == 0
    assert p.serial == []
    assert p.strategy == 'linear'

# Generated at 2022-06-23 06:28:04.130259
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-23 06:28:17.448550
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Dummy Play() object for testing
    yaml = ("- block:\n"
            "    - debug: var=not_me\n"
            "  handlers:\n"
            "    - debug: var=msg\n"
            "    - debug: var=msg1\n"
            "  rescue:\n"
            "    - debug: var=msg2\n"
            "  always:\n"
            "    - debug: var=msg3\n"
            "  meta: end_play")

    play_obj = Play().load(yaml, variable_manager=VariableManager(), loader=DataLoader()) # type: Play
    # Add dummy role
    role = Role()
    dummy_blk = Block()
    dummy_blk.block = [Task()]

# Generated at 2022-06-23 06:28:19.789554
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    a = Play()
    assert a.get_roles==[]

# Generated at 2022-06-23 06:28:21.650205
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data({'hosts': None})
    assert play.hosts == 'all'
    
    

# Generated at 2022-06-23 06:28:31.698297
# Unit test for method compile of class Play
def test_Play_compile():
    '''
    Unit test for method compile of class Play
    '''
    play = Play()
    roles = [Role(name='role1', loader=None, variable_manager=None, use_handlers=False), Role(name='role2', loader=None, variable_manager=None, use_handlers=False)]
    play.roles = roles
    play.tasks = [{'test': 'task1'}, {'test': 'task2'}]
    compiled = play.compile()
    assert compiled == [{'test': 'task1'}, {'test': 'task2'}, {'test': 'task1'}, {'test': 'task2'}]


# Generated at 2022-06-23 06:28:43.753781
# Unit test for method copy of class Play
def test_Play_copy():
    import copy

    play = Play()
    new_play = play.copy()
    assert new_play is not play
    assert new_play.ROLE_CACHE == play.ROLE_CACHE
    assert new_play._included_conditional == play._included_conditional
    assert new_play._included_path == play._included_path
    assert new_play._action_groups == play._action_groups
    assert new_play._group_actions == play._group_actions
    
    play.ROLE_CACHE = {'a':'b'}
    new_play = play.copy()
    assert new_play is not play
    assert new_play.ROLE_CACHE != play.ROLE_CACHE

# Generated at 2022-06-23 06:28:49.500941
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.hosts = '127.0.0.1'
    play._name = 'test_Play_get_name'
    assert play.get_name() == 'test_Play_get_name'
    play._name = None
    assert play.get_name() == '127.0.0.1'

    play.hosts = ['127.0.0.1', '127.0.0.2']
    assert play.get_name() == '127.0.0.1,127.0.0.2'

# Generated at 2022-06-23 06:28:50.920108
# Unit test for constructor of class Play
def test_Play():
    assert Play().__class__.__name__ == 'Play'

# Generated at 2022-06-23 06:28:58.803161
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    hosts = 'localhost'
    vars = {'var_name': 'var_value'}
    tasks = [{'local_action': 'win_ping'}]
    ds = dict(
        name='Ansible Play',
        hosts=hosts,
        gather_facts='no',
        vars=vars,
        tasks=tasks
    )

    p = Play().load(ds, variable_manager=VariableManager(), loader=DataLoader())
    p.preprocess_data()
    blocks = p.compile()

    # Check that Blocks are transformed into single Task list
    assert len(blocks) == 5
    assert any([isinstance(block, Block) for block in blocks])
    assert not any([isinstance(task, Block) for block in blocks for task in block])

    task_list = p.get_

# Generated at 2022-06-23 06:29:09.138360
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=DataLoader()))
    play_ds1 = dict(
        name="Ansible Play 1",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{user_name}}'))),
            dict(action=dict(module='debug', args=dict(msg='{{user_home}}')))
        ],
        vars=dict(
            user_home='/home/{{user_name}}',
            user_name='admin'
        ),
    )
    # create play
    play1 = Play().load(data=play_ds1, variable_manager=variable_manager, loader=None)
    assert play1.get

# Generated at 2022-06-23 06:29:17.133137
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    # Create one role
    role = Role()
    role.set_loader(Mock())
    play.set_loader(Mock())
    play.set_variable_manager(Mock())
    role_list = []
    role_list.append(role)
    # Set required fields for play
    play._ds = {}
    play._ds['name'] = 'testplay'
    play._ds['hosts'] = 'testhost'
    play._ds['roles'] = role_list
    play._ds['vars'] = []
    play._ds['vars_files'] = []
    play._ds['handlers'] = []
    play._ds['post_tasks'] = []

    # Execute constructor
    play.__init__()

    # Assert the play

# Generated at 2022-06-23 06:29:27.700459
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    # Test cases with Expected Results

# Generated at 2022-06-23 06:29:36.629902
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()
    play.load({'name': 'foo', 'hosts': 'localhost', 'gather_facts': 'no'}, variable_manager=variable_manager, loader=loader)
    assert play.get_roles() == []
    play.load({'name': 'foo', 'hosts': 'localhost', 'gather_facts': 'no', 'roles': [{'role': 'example'}]}, variable_manager=variable_manager, loader=loader)
    assert len(play.get_roles()) == 1
    assert play.get_roles()[0].get_name() == 'example'



# Generated at 2022-06-23 06:29:42.143325
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play._included_path = '/etc/ansible/roles/my_role'
    data = play.serialize()

    new_play = Play()
    new_play.deserialize(data)

    assert new_play._included_path == '/etc/ansible/roles/my_role'

# Generated at 2022-06-23 06:29:45.000847
# Unit test for method compile of class Play
def test_Play_compile():
    """
    Unit test for method compile of class Play
    """
    # Check the calling of the method
    p = Play()
    assert len(p.compile()) == 0



# Generated at 2022-06-23 06:29:50.620028
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-23 06:29:52.241279
# Unit test for method get_name of class Play
def test_Play_get_name():
    name = Play().get_name()
    assert not name


# Generated at 2022-06-23 06:29:59.448367
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    playbook = Playbook()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.options_vars = {}
    variable_manager.extra_vars = {}
    variable_manager.options_vars['basedir'] = os.path.abspath(os.getcwd())

    playbook.set_loader(loader)
    playbook.set_variable_manager(variable_manager)

    playbook.load(playbooks_path + '/test_playbook.yml')
    play = playbook.get_plays()[0]
    assert play.get_vars_files() == [playbooks_path + "/patch.yml"]

# Generated at 2022-06-23 06:30:02.013983
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    print(play.get_tasks())


# Generated at 2022-06-23 06:30:13.385113
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    yaml_data = """---
    hosts: localhost
    vars:
      var1: 1
      var2: 2
    pre_tasks:
      - vars:
          var1: 1
          var2: 2
        name: test name
    roles:
      - role1
    tasks:
      - name: test name
        vars:
          var1: 3
          var2: 4
    """
    play = Play.load(yaml_data, loader=loader)
    assert play.hosts == ['localhost'], "hosts should be localhost"
    assert play.vars == {'var1': 1, 'var2': 2}, "vars should be var1: 1, var2: 2"

# Generated at 2022-06-23 06:30:23.666850
# Unit test for method load of class Play
def test_Play_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    ds = [
        '- include_role: role=test_role1'
    ]

    ds = parse_yaml(ds)
    ds = preprocess_data(ds)
    loader = DataLoader()

    loader.set_basedir('/tmp')
    variable_manager = VariableManager()

    # test 'name' not set
    play = Play()
    play.load_data(ds, variable_manager=variable_manager, loader=loader)
    assert play.name == ','.join(play.hosts)

    # test 'name' set
    ds['name'] = 'test play'
    play = Play()

# Generated at 2022-06-23 06:30:28.962121
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()
    test_role = Role()
    test_play.roles = [test_role]
    assert test_play.compile_roles_handlers() == []
    test_role.handlers = [1]
    assert test_play.compile_roles_handlers() == [1]


# Generated at 2022-06-23 06:30:30.726985
# Unit test for method serialize of class Play
def test_Play_serialize():
    # given

    pass
# unit tests end
# unit_test:end
# unit_test:end

# Generated at 2022-06-23 06:30:37.680875
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = AnsiblePlay()
    task1 = AnsibleTask()
    task2 = AnsibleTask()
    task3 = AnsibleTask()
    block1 = AnsibleBlock()
    block1.add_task(task1)
    block1.add_task(task2)
    block1.rescue.add_task(task3)
    play.add_task(block1)
    assert len(play.get_tasks()) == 3

# Generated at 2022-06-23 06:30:46.157315
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    _loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=_loader, variable_manager=variable_manager, host_list='localhost'))


    # Empty vars files
    play_ds = {}
    play_ds['name'] = 'Test play get_vars_files'
    play_ds['hosts'] = 'localhost'
    play = Play().load(play_ds, variable_manager=variable_manager, loader=_loader)
    assert play.get_vars_files() == [], \
        'get_vars_files should return list with [] when vars is None'

    # Single vars file
    play_ds = {}
    play_ds['name'] = 'Test play get_vars_files'

# Generated at 2022-06-23 06:30:57.783474
# Unit test for method serialize of class Play
def test_Play_serialize():
    '''
    test Play class serialize method
    '''
    # Set data
    data = {
        'name': 'test',
        'connection': 'my_connection',
        'vars': {
            'key1': 'val1',
            'key2': 'val2',
        },
        'hosts': 'test_host',
        'tasks': ['my_task'],
        'roles': [],
    }
    # Create object
    play = Play.load(data = data, variable_manager = None, loader = None, vars = None)

    # Serialize object
    serialized = play.serialize()

    # Asserts
    assert serialized == data
    assert serialized is not data



# Generated at 2022-06-23 06:31:01.876756
# Unit test for constructor of class Play
def test_Play():
    play = {'name': 'test-play'}
    p1 = Play()
    p1._load_data(play)
    p2 = Play(play)
    assert p1 is not p2
    assert p1.get_name() == p2.get_name() == play.get('name')


# Generated at 2022-06-23 06:31:12.425332
# Unit test for method copy of class Play
def test_Play_copy():
    x = Play()
    x._included_conditional = 'something'
    x._included_path = 'something'
    x._action_groups = {}
    x._group_actions = {}

    new_me = x.copy()
    assert new_me.ROLE_CACHE == x.ROLE_CACHE
    assert new_me._included_conditional == x._included_conditional
    assert new_me._included_path == x._included_path
    assert new_me._action_groups == x._action_groups
    assert new_me._group_actions == x._group_actions


# Generated at 2022-06-23 06:31:15.776819
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_obj = Play()
    ds = dict(x='x')
    result = play_obj.preprocess_data(ds)
    expected = ds
    assert result == expected


# Generated at 2022-06-23 06:31:26.011790
# Unit test for method get_vars of class Play

# Generated at 2022-06-23 06:31:28.324312
# Unit test for method load of class Play
def test_Play_load():
    p = Play()
    p.load()


# Generated at 2022-06-23 06:31:38.265169
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/etc/ansible/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    pc = PlayContext()

# Generated at 2022-06-23 06:31:44.799257
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # parser = create_parser()
    # args = parser.parse_args(['file.yml'])
    # inventory = create_inventory(parser, args)
    # loader, inventory, variable_manager = create_loader(inventory)
    # play = Play.load(args.yml, variable_manager=variable_manager, loader=loader)
    # handlers = play.compile_roles_handlers()
    pass

# Generated at 2022-06-23 06:31:56.861168
# Unit test for method get_roles of class Play

# Generated at 2022-06-23 06:32:03.839006
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [Task()]
    play.tasks = [Task()]
    play.post_tasks = [Task()]
    play.post_tasks.append(Block())
    fake_block = Block()
    fake_block.rescue = [Task()]
    fake_block.always = [Task()]
    play.post_tasks.append(fake_block)
    play.post_tasks.append(Task())
    tasklist = play.get_tasks()
    assert len(tasklist) == 9
    assert isinstance(tasklist[0], Task)
    assert isinstance(tasklist[1], Task)
    assert isinstance(tasklist[2], Task)
    assert isinstance(tasklist[3], Task)

# Generated at 2022-06-23 06:32:05.886395
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert not p.tasks
    assert not p.handlers
    assert not p.roles

# Generated at 2022-06-23 06:32:08.716609
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # TODO
    pass

# Generated at 2022-06-23 06:32:14.930913
# Unit test for method get_name of class Play
def test_Play_get_name():
  play = Play()
  play.hosts = 'hosts'
  assert play.get_name() == 'hosts'
  play.name = 'name'
  assert play.get_name() == 'name'
  play.name = None
  play.hosts = ['host1', 'host2']
  assert play.get_name() == 'host1,host2'
# hosting-play unit test for method validate_hosts of class Play

# Generated at 2022-06-23 06:32:20.689573
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.handlers = [Handler(), Handler()]
    result = play.get_handlers()
    assert isinstance(result, list)
    assert len(result) == 2
    assert all(isinstance(item, Handler) for item in result)
    assert result[0] is not result[1]
    assert result[0] is not play.handlers[0]
    assert result[1] is not play.handlers[1]

# Generated at 2022-06-23 06:32:28.147052
# Unit test for method compile of class Play
def test_Play_compile():
    # Create a simple Play
    play = {"name": "myPlay", "hosts": "localhost", "gather_facts": "no", "tasks": [{"name": "taskName", "debug": "msg='{{ msg }}'"}]}
    play_object = Play.load(play)
    play_object.validate()
    # Assert that the Play has been correctly compiled
    assert play_object.compile() == [play_object.tasks]


# Generated at 2022-06-23 06:32:33.887847
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [inventory_tasks]
    p.tasks = [inventory_tasks]
    p.post_tasks = [inventory_tasks]
    ansible_tasks = p.get_tasks()
    assert isinstance(ansible_tasks, list)
    for task in ansible_tasks:
        assert isinstance(task, list)

# Generated at 2022-06-23 06:32:38.660792
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    """Play.__repr__()

    Test the return of Play.__repr__()
    """
    myPlay = Play()
    assert myPlay.__repr__() == myPlay.get_name()
# Integration test for method get_name of class Play

# Generated at 2022-06-23 06:32:41.376761
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    '''
    Unit test for method get_handlers of class Play
    '''
    pass # nothing to do for this method


# Generated at 2022-06-23 06:32:42.407568
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-23 06:32:45.374211
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play_obj=Play.load()
    if play_obj.handlers:
        return play_obj.handlers[:]
    else:
        return []


# Generated at 2022-06-23 06:32:48.522376
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ['var_file1', 'var_file2']
    assert p.get_vars_files() == ['var_file1', 'var_file2']

# Generated at 2022-06-23 06:32:49.726227
# Unit test for method load of class Play
def test_Play_load():
    # There is no public method Play.load
    pass

# Generated at 2022-06-23 06:32:51.819954
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    p._load_roles(None, [{"role": "x"}])
    assert len(p.get_roles()) == 1


# Generated at 2022-06-23 06:32:55.231587
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars['var_name'] = 'value'
    assert play.get_vars() == {'var_name': 'value'}



# Generated at 2022-06-23 06:33:05.915069
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # Testing default value of first parameter
    playbook_hosts = set()
    playbook_hosts.add("localhost")
    playbook_hosts.add("127.0.0.1")
    playbook_hosts.add("8.8.8.8")
    playbook_hosts.add("8.8.4.4")
    p = Play(hosts=playbook_hosts)

    assert p.__repr__() == 'localhost,127.0.0.1,8.8.8.8,8.8.4.4'

    p = Play()

    assert p.__repr__() == ''

# Generated at 2022-06-23 06:33:10.588831
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    p.load_data(dict(user='test_user', hosts='test_host'))
    assert p.remote_user == 'test_user'
    assert 'hosts' in p._ds
    assert 'user' in p._ds
    

# Generated at 2022-06-23 06:33:12.448950
# Unit test for method get_name of class Play
def test_Play_get_name():
   play = Play()
   try:
      assert play.get_name()
   except:
      return 1
   return 0


# Generated at 2022-06-23 06:33:13.377912
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert None != None


# Generated at 2022-06-23 06:33:17.224908
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p1 = Play()
    p1.handlers = ["h1", "h2", "h3"]
    assert p1.get_handlers() == ["h1", "h2", "h3"]


# Generated at 2022-06-23 06:33:18.484627
# Unit test for method serialize of class Play
def test_Play_serialize():
    assert True

# Generated at 2022-06-23 06:33:24.350641
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize([1, 2, 3])
    return play._ds == [1, 2, 3]


# Generated at 2022-06-23 06:33:38.459837
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.tasks = []
    play.tasks[:] = [{'name': 'Task1'}, {'name': 'Task2'}]
    play.deprecated_roles = []
    play.deprecated_roles[:] = [{'name': 'Role1'}, {'name': 'Role2'}]
    play.name = 'Play'
    play.hosts = 'localhost'
    play.defaults_path = 'defaults.yml'
    play.vars_path = 'vars.yml'
    play.roles = []
    play.roles[:] = [Role(), Role()]
    data = play.serialize()
    assert data['tasks'] == [{'name': 'Task1'}, {'name': 'Task2'}]
   

# Generated at 2022-06-23 06:33:50.566556
# Unit test for method serialize of class Play
def test_Play_serialize():
    # test dict serialization of nullable fields (should still be serialized as None)
    p = Play()
    p.connection = None
    p.remote_user = None
    p.roles = None
    p.until = None
    p.retries = None
    p.any_errors_fatal = None
    p.delay = None
    p.when = None
    p.tags = None
    p.become = None
    p.become_user = None
    p.become_method = None
    
    # test dict serialization of empty list fields
    p.post_tasks = []
    p.pre_tasks = []
    p.tasks = []
    p.vars_prompt = []
    p.hosts = []
    p.vars_files = []

# Generated at 2022-06-23 06:34:01.808881
# Unit test for method load of class Play