

# Generated at 2022-06-23 06:24:08.141422
# Unit test for method load of class Play
def test_Play_load():
    mock_data = {'name': 'test_play', 'hosts': 'some_host', 'connection': 'some_connection'}
    mock_variable_manager = Mock()

    mock_loader = Mock()

    mock_vars = Mock()

    result = Play.load(data=mock_data, variable_manager=mock_variable_manager, loader=mock_loader, vars=mock_vars)
    assert result is not None
    assert isinstance(result, Play)
    assert result._ds == mock_data
    assert result.name == 'test_play'
    assert result.hosts == 'some_host'
    assert result.connection == 'some_connection'
    assert result._included_path == None
    assert result.ROLE_CACHE == {}
    assert result._included_conditional

# Generated at 2022-06-23 06:24:17.043736
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    obj = Play()
    assert isinstance(obj, Play)
    obj.deserialize(data={'roles': [], 'included_path': "/path1", 'action_groups': {}, 'group_actions': {}})
    assert_equals(obj._included_path, "/path1")
    assert_equals(obj._action_groups, {})
    assert_equals(obj._group_actions, {})
    assert_equals(obj.roles, [])
    assert_equals(obj.ROLE_CACHE, {})



# Generated at 2022-06-23 06:24:24.080538
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    x_Play = Play()
    # Assigning values to variables in class Play.
    x_Play.roles = [Role()]
    # Unit test for method get_roles of class Play.
    assert x_Play.get_roles() == [Role()]



# Generated at 2022-06-23 06:24:25.577887
# Unit test for method load of class Play
def test_Play_load():
    foo = Play()
    assert isinstance(foo, Play)


# Generated at 2022-06-23 06:24:32.456011
# Unit test for constructor of class Play
def test_Play():
    # Constructor AnsiblePlay
    p = Play()

    # Constructor AnsiblePlay
    p = Play(
        {
            'name': 'test',
            'hosts': '127.0.0.1',
            'vars': {'username': 'testUser'},
        },
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-23 06:24:34.297513
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize("event_handler: \"{{ some_var }}\"\nhosts: all\nname: blah blah blah")


# Generated at 2022-06-23 06:24:41.776132
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p_copy = p.copy()
    assert p_copy._included_conditional == None
    assert p_copy._included_path == None
    assert p_copy._action_groups == {}
    assert p_copy._group_actions == {}
    assert p_copy.roles == []
    p_copy.roles = [1, 2, 3]
    assert p_copy.roles == [1, 2, 3]



# Generated at 2022-06-23 06:24:51.019171
# Unit test for constructor of class Play
def test_Play():

    # Initializing play instance with integer
    try:
        play = Play(1)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    # Initializing play instance with string
    try:
        play = Play("playbook.yml")
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    # Initializing play instance with list
    try:
        play = Play([])
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    # Initializing play instance with dictionary
    try:
        play = Play({})
        play = Play(dict(hosts=[]))
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    # Initializing play instance with valid data

# Generated at 2022-06-23 06:25:01.204513
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    def get_block_line_num(block):
        return block[0].LINENO

    # FIXME(kdub): This test is not great, as it is tightly coupled to the
    # order that tasks are returned from a role, which is not guaranteed.
    # The tests for RoleInclude._load_tasks should be expanded to include
    # verifying that order is preserved by the loader, and then this test
    # can be simplified to only check that the handlers are returned in the
    # correct order.


# Generated at 2022-06-23 06:25:02.823306
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert repr(p) == p.get_name()


# Generated at 2022-06-23 06:25:04.200566
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.hosts is None


# Generated at 2022-06-23 06:25:16.277169
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = '/etc/ansible/hosts'
    assert len(p.get_vars_files()) == 1
    assert p.get_vars_files()[0] == '/etc/ansible/hosts'
    p = Play()
    p.vars_files = []
    assert len(p.get_vars_files()) == 0
    p = Play()
    p.vars_files = None
    assert len(p.get_vars_files()) == 0
    p = Play()
    p.vars_files = ['/etc/ansible/group_vars/all.yml', '/etc/ansible/group_vars/project.yml']
    assert len(p.get_vars_files()) == 2
    assert p.get_

# Generated at 2022-06-23 06:25:24.344048
# Unit test for method compile of class Play

# Generated at 2022-06-23 06:25:35.092915
# Unit test for method serialize of class Play
def test_Play_serialize():
    import sys
    p = Play()
    d = p.serialize()

# Generated at 2022-06-23 06:25:42.852422
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play.load({
        'name': 'foo',
        'hosts': 'all',
        'roles': [
            {'name': 'bar', 'handlers': [{'name': 'baz', 'listen': 'me', 'tasks': []}]}
        ]
    })
    results = play.compile_roles_handlers()
    assert len(results) == 1
    assert results[0].name == 'baz'


# Generated at 2022-06-23 06:25:46.138004
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = ''
    if p.get_name() != '':
        raise Exception("failed test for Play._get_name()")


# Generated at 2022-06-23 06:25:56.406225
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import ansible
    import ansible.playbook
    import ansible.template
    data = {}

    data['remote_user'] = 'test'
    data['remote_port'] = 5555
    data['roles'] = []
    data['name'] = 'test'
    data['included_path'] = '/tmp/test'
    data['action_groups'] = {'test': {'hosts': [], 'roles': [], 'tasks': []}}
    data['group_actions'] = {'test': {'hosts': [], 'roles': [], 'tasks': []}}

    print("*** data in deserialize ***")
    print(data)
    print("*** data in deserialize ***")

    play = ansible.playbook.Play()
    play.deserialize(data)
   

# Generated at 2022-06-23 06:26:09.273086
# Unit test for constructor of class Play
def test_Play():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode

    pb = Play()
    assert pb.name == ''
    assert pb.connection == 'smart'
    assert pb.hosts is None
    assert pb.remote_user is None
    assert pb.vars == dict()
    assert pb.vars_files == []
    assert pb.vars_prompt == []
    assert pb.tags == []
    assert pb.roles == []
    assert pb.tasks == []
    assert pb.handlers == []
    assert pb

# Generated at 2022-06-23 06:26:12.310546
# Unit test for method get_name of class Play
def test_Play_get_name():
    Play.__init__
    x = Play()
    x._get_name()


# Generated at 2022-06-23 06:26:14.046442
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {'test_key': 'test_value'}
    expected_result = {'test_key': 'test_value'}
    assert play.get_vars() == expected_result

# Generated at 2022-06-23 06:26:23.748524
# Unit test for method copy of class Play
def test_Play_copy():
    play1 = Play()
    play2 = play1.copy()
    assert play1.ROLE_CACHE == play2.ROLE_CACHE

    play1._included_conditional = 'test'
    play1._included_path = 'test'
    play1._action_groups = {'test':'test'}
    play1._group_actions = {'test':'test'}
    play3 = play1.copy()
    assert play1._included_conditional == play3._included_conditional
    assert play1._included_path == play3._included_path
    assert play1._action_groups == play3._action_groups
    assert play1._group_actions == play3._group_actions


# Generated at 2022-06-23 06:26:29.120110
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = {
        'name': 'foo',
        'connection': 'ssh',
        'hosts': 'all',
        'gather_facts': True,
        'remote_user': 'root',
        'vars': {'foo': 'bar'},
        'vars_files': ['vars1.yml', 'vars1.yml'],
        'any_errors_fatal': False,
        'max_fail_percentage': 5.0,
        'force_handlers': True,
        'serial': [1, 1, 2],
        'strategy': 'linear',
        'roles': ['role1', 'role2'],
        'handlers': ['all'],
        'tasks': [{
            'include': 'all'
        }]
    }

# Generated at 2022-06-23 06:26:41.753049
# Unit test for method copy of class Play
def test_Play_copy():
  play = Play()
  play_copy = play.copy()
  assert play.ROLE_CACHE == play_copy.ROLE_CACHE
  assert play._included_conditional == play_copy._included_conditional
  assert play._included_path == play_copy._included_path
  assert play._action_groups == play_copy._action_groups
  assert play._group_actions == play_copy._group_actions

    # =================================================================================


# Generated at 2022-06-23 06:26:48.960005
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    #Test the Play class' get_tasks method
    #test 1
    pl = Play()
    pl.pre_tasks = ["pre_task1", "pre_task2"]
    pl.post_tasks = ["post_task1", "post_task2"]
    pl.tasks = ["task1", "task2"]
    assert pl.get_tasks() == ["pre_task1","pre_task2","task1","task2","post_task1","post_task2"]
    #test 2
    pl2 = Play()
    pl2.pre_tasks = ["pre_task1"]
    pl2.post_tasks = ["post_task1"]
    pl2.tasks = ["task1"]

# Generated at 2022-06-23 06:26:49.498508
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-23 06:27:00.063368
# Unit test for method serialize of class Play
def test_Play_serialize():
    # play_ds defines the data structure that is used to create a Play object
    play_ds = dict(
        name='my play',
        hosts='webservers',
        vars=dict(
            count=5,
            body='hello world'
        ),
        pre_tasks=dict(
            name='some task',
            yum='some yum command'
        ),
        roles=dict(
            include='some role'
        )
    )

    # Create a Play object from the play_ds data structure
    p = Play.load(play_ds)
    p.post_validate()

    # Serialize the Play object
    serialized = p.serialize()

    # Deserialize the serialized Play object
    d = Play()
    d.deserialize(serialized)

    # assert that the

# Generated at 2022-06-23 06:27:08.857938
# Unit test for method compile of class Play
def test_Play_compile():
    name = "test"
    hosts = "127.0.0.1"
    connection = "local"
    gather_facts = True
    user = 'root'
    play_source = "playbook.yaml"
    r_task = Task(name=name, action='null')
    role = Role(name=name, play_source=play_source)
    role.tasks.append(r_task)
    roles_ = []
    roles_.append(role)
    task = Task(name=name, action='null')
    tasks = []
    tasks.append(task)

# Generated at 2022-06-23 06:27:18.786022
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Same code for role and play:
    #test_Role_deserialize
    
    test_data = dict()
    
    # First block of code
    # Initializing data structure
    test_data['data'] = dict()
    test_data['data']['variable_manager'] = dict()
    test_data['data']['variable_manager']['_inventory'] = dict()
    test_data['data']['variable_manager']['_inventory']['_variables'] = dict()
    test_data['data']['variable_manager']['_inventory']['_variables']['HOST_VAR1'] = "val1"

# Generated at 2022-06-23 06:27:29.929349
# Unit test for method load of class Play
def test_Play_load():
    # Create mock vars
    vars = {}
    # Create mock loader
    loader = mock.create_autospec(Loader)
    # Create mock variable_manager
    variable_manager = mock.create_autospec(VariableManager)
    # Create mock ds to be passed to load_data
    ds = {}

    # Create mock Play object
    mock_play = mock.create_autospec(Play())
    mock_play.__dict__ = {
        'ROLE_CACHE': {},
        '_included_conditional': None,
        '_included_path': None,
        '_action_groups': {},
        '_group_actions': {},
    }

    # Mock load_data and return itself
    mock_play.load_data.return_value = mock_play

    #

# Generated at 2022-06-23 06:27:36.578743
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    playbook = Playbook()
    play = Play()
    play.name = ''
    playbook.set_plays([play])

    assert repr(play) == play.get_name()

    play.name = 'p1'
    assert repr(play) == play.get_name()


# Generated at 2022-06-23 06:27:43.766823
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['test']
    assert play.vars_files == ['test']
    assert play.get_vars_files() == ['test']

    play.vars_files =  'test'
    assert play.vars_files == 'test'
    assert play.get_vars_files() == ['test']

# Generated at 2022-06-23 06:27:46.388589
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    play.roles = [ Role() ]
    assert play.get_roles() == [ Role() ]


# Generated at 2022-06-23 06:27:50.358809
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Setup
    play = Play()
    play.handlers = [{'name': 'foobar', 'action': 'none'}]
    # Execute
    result = play.get_handlers()
    # Verify
    assert result == play.handlers

# Generated at 2022-06-23 06:27:55.430958
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_obj = Play()
    data = dict(
        name="A test play",
        hosts="localhost",
        roles=[]
    )
    play_obj.deserialize(data=data)


# Load test for method _load_vars_prompt of class Play

# Generated at 2022-06-23 06:28:00.913558
# Unit test for constructor of class Play
def test_Play():

    # test the default mode, which is to validate the keys
    p = Play()
    # p.post_validate()

    # assert that p.name is an empty string
    assert (p.name == '')

    # assert that p.hosts is an empty string
    assert (p.hosts == None)

    # for each key in p.__dict__, make sure that it is one of the keys in the _valid_attrs set
    for key in p.__dict__:
        assert (key in _valid_attrs)

    # test the constructor when told to validate the keys
    p = Play(validate_keys=True)
    # p.post_validate()

    # assert that p.name is an empty string
    assert (p.name == '')

    # assert that p.hosts is an empty string


# Generated at 2022-06-23 06:28:04.642129
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = "test play name"
    assert play.__repr__() == play.name, "Play: __repr__ method doesn't work"


# Generated at 2022-06-23 06:28:17.806895
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    try:
        # test if it raises error with expected message when ds is not dict
        ds = ''
        p.preprocess_data(ds)
        assert False
    except AssertionError as e:
        assert e.args[0] == 'while preprocessing data (), ds should be a dict but was a <class \'str\'>'
    p = Play()

# Generated at 2022-06-23 06:28:20.486352
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # Initialize a Play object
    p = Play()

    # TODO: Add more tests


# Generated at 2022-06-23 06:28:31.533790
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    """
    Method ``get_vars`` of class ``Play``
    """
    #######################################################
    # Test for method `get_vars` of class `Play`
    #######################################################
    # Create a Play object
    p = Play()
    # get_vars() should return a dict
    if not isinstance(p.get_vars(), dict):
        fail("get_vars() should return a dict")
    # get_vars() should return a clone of vars
    if ref(p.get_vars()) == ref(p.vars):
        fail("get_vars() should return a clone of vars")
    #######################################################
    exit_json(changed=False, msg="OK")


# Generated at 2022-06-23 06:28:35.019569
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    my_play = Play()
    # todo: Test method get_handlers of class Play
    assert False, "Test method Play.get_handlers() not implemented"



# Generated at 2022-06-23 06:28:45.329326
# Unit test for constructor of class Play
def test_Play():
    '''
    ---
    name: test play
    hosts: localhost
    pre_tasks:
    - debug: msg="hi"
    roles:
    - name: test
      tasks:
      - debug: var=a
      handlers:
      - debug: msg="handler"
    tasks:
    - debug: msg="step1"
    - include: more-tasks.yml
    - debug: msg="step2"
    post_tasks:
    - debug: msg="step3"
    handlers:
    - debug: msg="handler"
    '''

    loader = DictDataLoader({
        "more-tasks.yml": """
        tasks:
        - debug: msg="step4"
        - debug: msg="step5"
        """,
    })

    pb = Play.load

# Generated at 2022-06-23 06:28:52.808436
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''
    Test method get_name of class Play
    '''
    # pass
    play = Play()
    play.name = 'test play'
    assert play.get_name() == 'test play'
    play.name = None
    play.hosts = 'test host'
    assert play.get_name() == 'test host'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-23 06:28:55.180147
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    pass

# Unit tests for method preprocess_data of class Play

# Generated at 2022-06-23 06:28:59.172959
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.hosts == "all"
    assert p.roles == []
    assert p.tasks == []
    assert p.handlers == []
    assert p.vars == {}



# Generated at 2022-06-23 06:29:09.370821
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [{"role_1": {"handlers": [], "tasks": []}},
               {"role_2": {"handlers": [{"name": "handler_2", "tasks": []}], "tasks": []}},
               {"role_3": {"handlers": [], "tasks": []}}]

    # assert p.compile_roles_handlers() == [
    #     {'role_2': {'handlers': [{'name': 'handler_2', 'tasks': []}], 'tasks': [], 'vars': {}, 'files': []}}
    #     ]

    assert p.compile_roles_handlers() == [
        ({"name": "handler_2", "tasks": []})
    ]

# Generated at 2022-06-23 06:29:12.818319
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = '{{playbook_dir}}/vars_files.yml'
    assert play.get_vars_files() == ['{{playbook_dir}}/vars_files.yml']


# Generated at 2022-06-23 06:29:17.630227
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    data = dict(
        foo='foo',
        bar='bar',
        roles=[1,2,3]
    )
    p.deserialize(data)
    assert p.bar == 'bar'
    assert p.roles == [1,2,3]
    assert p.foo == 'foo'



# Generated at 2022-06-23 06:29:20.701960
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    result = play.get_roles()
    assert result is not None
    assert result == []

# Generated at 2022-06-23 06:29:22.419224
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    assert play.get_vars() == dict()

# Generated at 2022-06-23 06:29:34.257132
# Unit test for method compile of class Play
def test_Play_compile():
    loader = DictDataLoader({
        "inventory": {
            "hosts": ["host1", "host2"],
            "vars": {"some_var": 10}
        }
    })
    variable_manager = VariableManager(loader=loader)

    # Handle ansible.cfg
    class AnsibleConfig(object):
        def __init__(self, defaults=None):
            self.bin_ansible_callbacks = False
            self.new_style_tags = None
            self.defaults = defaults or dict()
            self.ansible_callback_whitelist = list()


# Generated at 2022-06-23 06:29:35.934236
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    assert Play().get_roles() == []


# Generated at 2022-06-23 06:29:38.967368
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    args = {}
    p = Play()
    args['name'] = 'test'
    return p.__repr__() == 'test'

# Generated at 2022-06-23 06:29:42.527774
# Unit test for method copy of class Play
def test_Play_copy():
    play_ = Play()
    play_.ROLE_CACHE = {u'_default': {}}
    assert play_.copy().ROLE_CACHE == play_.ROLE_CACHE
    assert play_.copy()._included_conditional == play_._included_conditional
    assert play_.copy()._included_path == play_._included_path
    assert play_.copy()._action_groups == play_._action_groups
    assert play_.copy()._group_actions == play_._group_actions

# Generated at 2022-06-23 06:29:43.956185
# Unit test for method load of class Play
def test_Play_load():
    P = Play()
    P.load( {})
    # assert load is called
    assert True


# Generated at 2022-06-23 06:29:55.194496
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    '''
    Unit test for method get_handler of class Play
    '''

    global LOGGER
    LOGGER = logging.getLogger(__name__)
    LOGGER.setLevel(logging.INFO)
    LOGGER.addHandler(logging.StreamHandler())
    LOGGER.propagate = False

    play = Play()
    role = Role()
    role.compile(play=play)

    for handler in role.get_handler_blocks():
        for t in handler.block:
            play.handlers.append(t)

    results = play.get_handlers()
    assert results == play.handlers[:]


# Generated at 2022-06-23 06:29:58.239847
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    """
  # Unit test for method get_vars of class Play
 """
    play = Play()
    _vars = play.get_vars()
    assert _vars == {}


# Generated at 2022-06-23 06:30:05.475352
# Unit test for method compile of class Play
def test_Play_compile():
    z = Play()
    z._ds = { 'name': 'Test' } 
    z._validated_data = { 
        'name': 'Test', 
        'tasks': [], 
        'post_tasks': [], 
        'roles': [], 
        'pre_tasks': [] 
    }
    z._handlers = []
    z.ROLE_CACHE = {}  
    z._included_conditional = None
    z._included_path = None
    z._action_groups = {}
    z._group_actions = {}
    z.only_tags = set(context.CLIARGS.get('tags', [])) or frozenset(('all',))
    z.skip_tags = set(context.CLIARGS.get('skip_tags', []))

# Generated at 2022-06-23 06:30:17.122817
# Unit test for constructor of class Play
def test_Play():
    play_dict = dict(
        name="Ansible Play",
        hosts="all",
        gather_facts="yes"
    )
    play = Play.load(play_dict)
    assert play.get_name() == play_dict.get("name")
    assert play.hosts == play_dict.get("hosts")
    assert play.vars == dict()
    assert play.roles == list()
    assert play.tasks == list()
    assert play.handlers == list()
    assert play.post_tasks == list()
    assert play.pre_tasks == list()
    assert play.connection == 'smart'

    # test constructor with explicit args
    play_dict2 = dict(
        name="Ansible Play 2",
        hosts="all",
        gather_facts="no"
    )


# Generated at 2022-06-23 06:30:17.908250
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-23 06:30:22.737928
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    with pytest.raises(AnsibleAssertionError) as ansible_error:
        play.get_name()
    assert ansible_error.type == AnsibleAssertionError
    assert ansible_error.value.args[0] == ('while preprocessing data (%s), ds should be a dict but was a %s' % (ds, type(ds)))


# Generated at 2022-06-23 06:30:27.921286
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    Play = play.Play(name='test_Play_compile_roles_handlers',
                     variable_manager=variable_manager.VariableManager(),
                     loader=loader.DataLoader(), host_list=['localhost'],
                     roles=[])

    assert Play.compile_roles_handlers() == []


# Generated at 2022-06-23 06:30:31.650599
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # unit test for Play.get_vars()
    assert Play().get_vars() == dict()
    assert Play(vars=dict(a=0, b=2)).get_vars() == dict(a=0, b=2)


# Generated at 2022-06-23 06:30:35.267969
# Unit test for method get_vars of class Play
def test_Play_get_vars():

    # Parsing Play
    play = Play()
    # Getting vars
    variables = play.get_vars()

    # Testing variables
    assert isinstance(variables, dict) == True


# Generated at 2022-06-23 06:30:38.922015
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    vars = {'greeting': 'hello', 'topic': 'world'}
    myPlay = Play()
    myPlay.vars = vars
    assert myPlay.get_vars() == vars


# Generated at 2022-06-23 06:30:49.052578
# Unit test for constructor of class Play
def test_Play():
    '''
    >>> test_Play()
    '''

    # we first load a playbook via a playbook collection, which is not the
    # usual way a playbook would be loaded, but it ensures we go through
    # the same code paths
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.plugin_docs import read_docstub

    def get_host_groups(hostnames, hostvars, groupvars, groups):
        '''Returns a dictionary mapping hostnames to their group memberships'''

        results = {}
        for hostname in hostnames:
            group_map = []
            for group in groups:
                members = groups[group]['hosts']

# Generated at 2022-06-23 06:30:54.648137
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    ansible_play = Play()
    test_role1 = Role()
    test_role2 = Role()
    ansible_play.roles = [test_role1, test_role2]
    assert ansible_play.get_roles() == [test_role1, test_role2]


# Generated at 2022-06-23 06:31:02.119225
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # test to check execution of get_roles method of class Play
    play = Play()
    role1 = Role()
    role1.name = "role1"
    role2 = Role()
    role2.name = "role2"
    play.roles = [role1, role2]
    result = play.get_roles()
    assert result is not None
    assert result == [role1, role2]
    assert result[0].name == "role1"
    assert result[1].name == "role2"

if __name__ == "__main__":
    test_Play_get_roles()

# Generated at 2022-06-23 06:31:03.460058
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-23 06:31:04.596335
# Unit test for constructor of class Play
def test_Play():
    pass

# Generated at 2022-06-23 06:31:16.058557
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.parsing import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()


# Generated at 2022-06-23 06:31:21.251088
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    mock_play = Play()
    mock_play.vars = {'_ansible_selinux_special_fs': None}
    assert mock_play.get_vars() == {'_ansible_selinux_special_fs': None}


# Generated at 2022-06-23 06:31:27.302256
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    loader = DictDataLoader(dict(
        default=dict(
            vars_files=[
                'a.yml',
                'b.yml'
            ]
        )
    ))
    variable_manager = VariableManager(loader=loader, inventory=PlaybookInventory(loader=loader))
    play = Play().load({}, variable_manager=variable_manager, loader=loader, use_deprecated_get_vars=True)
    assert ['a.yml', 'b.yml'] == play.get_vars_files()

# Generated at 2022-06-23 06:31:31.525333
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create a test Play p
    p = Play()

    # Check that method preprocess_data works as expected
    assert p.preprocess_data({'remote_user': 'testuser'}) == {'remote_user': 'testuser'}

    p.preprocess_data({'user': 'testuser'})
    assert p.remote_user == 'testuser'


# Generated at 2022-06-23 06:31:40.840657
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    """
    Test Play.deserialize method
    """
    p = Play()

# Generated at 2022-06-23 06:31:46.381320
# Unit test for method compile of class Play
def test_Play_compile():
    data = """
    - include_role:
        name: include_role
    - role: include_role
    - import_role:
        name: import_role
    - include_role:
        name: include_role
    - role: include_role
    """
    p = Play()
    p.load_data(data)
    p.compile_roles_handlers()
    assert p.compile() == 5


# Generated at 2022-06-23 06:31:48.023891
# Unit test for method load of class Play
def test_Play_load():
    pass



# Generated at 2022-06-23 06:31:55.529277
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # GIVEN: An object of type Play
    p = Play()
    p.handlers = [{'listen': 'always', 'name': 'handler1'}]
    # WHEN: method get_handlers() is called on the object
    result = p.get_handlers()
    # THEN: the returned value is equal to list of handlers of the play
    expected = [{'listen': 'always', 'name': 'handler1'}]
    assert result == expected



# Generated at 2022-06-23 06:32:01.521801
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.get_name = MagicMock(return_value='Fake Name of Play')
    assert isinstance(p.__repr__(), string_types)
    assert isinstance(p.__repr__(), binary_type)
    assert p.__repr__() == p.get_name.return_value


# Generated at 2022-06-23 06:32:10.607574
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    data = play.serialize()
    assert data['name'] == None
    assert data['hosts'] == None
    assert data['connection'] == 'smart'
    assert data['become'] == False
    assert data['become_method'] == C.DEFAULT_BECOME_METHOD
    assert data['become_user'] == C.DEFAULT_BECOME_USER
    assert data['check'] == False
    assert data['gather_facts'] == 'smart'
    assert data['gather_subset'] == None
    assert data['environment'] == None
    assert data['no_log'] == None
    assert data['remote_user'] == None
    assert data['port'] == None
    assert data['sudo'] == None
    assert data['sudo_user'] == None

# Generated at 2022-06-23 06:32:15.116704
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.hosts = 'host_1'
    play._ds = {'hosts':'host_1'}
    play.preprocess_data(play._ds)
    assert isinstance(play._ds['hosts'], text_type)
    return play


# Generated at 2022-06-23 06:32:18.508986
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Method that would be called by the test
    p = Play()
    r = Role()
    p.roles.append(r)
    roles = p.get_roles()
    assert roles[0] == r


# Generated at 2022-06-23 06:32:25.022075
# Unit test for method load of class Play
def test_Play_load():
    data =  dict(
        name='test-play',
        hosts='all',
        gather_facts='no',
        remote_user='root',
        roles=[],
        tasks = []
    )
    p = Play.load(data)
    assert p.get_name() == 'test-play'
    assert p.hosts  == 'all'
    assert p.gather_facts  == 'no'
    assert p.remote_user == 'root'
    assert len(p.roles) == 0



# Generated at 2022-06-23 06:32:31.021437
# Unit test for method load of class Play
def test_Play_load():
    fake_loader = DictDataLoader({})
    fake_variable_manager = VariableManager()

    play = Play.load(dict(
        hosts='localhost',
        vars=dict(
            a=0
        ),
        pre_tasks=list(dict(
            action='debug',
            msg='hello'
        )),
        roles=list(dict(
            role='test1'
        )),
        tasks=list(dict(
            action='debug',
            msg='hello'
        )),
        post_tasks=list(dict(
            action='debug',
            msg='hello'
        ))
    ), variable_manager=fake_variable_manager, loader=fake_loader)

    assert isinstance(play, Play)
    assert isinstance(play.vars, dict)
    assert 'a' in play

# Generated at 2022-06-23 06:32:32.525564
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-23 06:32:44.943957
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    role1 = Role()
    role1.vars = {'var1': 'value1'}
    role2 = Role()
    role2.vars = {'var2': 'value2'}

    roles = [role1, role2]
    
    play = Play()
    play.vars = {'var3': 'value3'}
    play.vars_files = ['/tmp/vars_file1.yaml', '/tmp/vars_file2.yaml']
    play.roles = roles

    vars_expected = {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}
    assert(play.vars == vars_expected)

# Generated at 2022-06-23 06:32:51.670861
# Unit test for method copy of class Play
def test_Play_copy():
    import datetime
    from ansiblelint.runner import Runner

    filename = "playbook.yaml"
    runner = Runner([], [], [], True, '/doesnotexist', None)

    play = None
    with open(filename, "r") as f:
        try:
            play = Play.load(f.read(), variable_manager=runner.variable_manager, loader=runner._loader)
        except AnsibleParserError as e:
            print(e)
            sys.exit(1)

    assert play.copy().serialize() == play.serialize()


# Generated at 2022-06-23 06:32:52.263874
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-23 06:32:54.186743
# Unit test for method load of class Play
def test_Play_load():
    play = Play()
    assert play.load({}) != None


# Generated at 2022-06-23 06:32:55.298741
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  pass

# Generated at 2022-06-23 06:33:02.274787
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    '''
    Unit test for Play._get_handlers()
    '''
    play = Play()
    # Check for correct returns for no handlers
    assert play.get_handlers() == play.handlers,\
    "Play._get_handlers() returned incorrect value"
    # Check for correct return when there are handlers
    play.handlers = ['a', 'b']
    assert play.get_handlers() == play.handlers,\
    "Play._get_handlers() returned incorrect value when there were handlers"

# Generated at 2022-06-23 06:33:09.092268
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p2 = p.copy()
    assert p.ROLE_CACHE == p2.ROLE_CACHE
    assert p._included_conditional == p2._included_conditional
    assert p._included_path == p2._included_path
    assert p._action_groups == p2._action_groups
    assert p._group_actions == p2._group_actions


# Generated at 2022-06-23 06:33:12.957536
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Create a play with one handler
    play = Play()
    play.handlers = [{'name': 'abc', 'action': 'abc'}]
    # Get handlers from the play.
    handlers = play.get_handlers()
    # Verify that the handler count is one
    assert len(handlers) == 1


# Generated at 2022-06-23 06:33:20.587964
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    from collections import MutableMapping
    data = dict(
        vars = dict(
            a = "b"
        )
    )
    play = Play()
    play._variable_manager = Mock()
    play.load_data(data, variable_manager=play._variable_manager)
    result = play.get_vars()
    assert isinstance(result, MutableMapping)
    assert result == {'a': 'b'}

# Generated at 2022-06-23 06:33:21.195341
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    pass



# Generated at 2022-06-23 06:33:29.168154
# Unit test for method compile of class Play
def test_Play_compile():
    # Create instance of class Play with value for its attribute
    # _roles but with None value for attributes _play_hosts and _ds
    # (line 135)
    play = ansible_play.Play()
    # Create an object of class dict called dict1
    dict1 = dict()
    # Create an object of class dict called dict2
    dict2 = dict()
    # Add to dict1 the key-value pair ('roles', [])
    dict1['roles'] = []
    # Add to dict2 the key-value pair ('roles', [])
    dict2['roles'] = []
    # Call method load_data() of play with arguments dict1 and dict2
    play.load_data(dict1, dict2)
    # Assert value of variable play_hosts
    assert play.play_hosts == []

# Generated at 2022-06-23 06:33:42.684338
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.playbook.play_context import PlayContext
    from collections import namedtuple
    from ansible import constants as C
    Options = namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = Options(connection='smart', module_path=['/to/mymodules'], forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)
    loader, inventory, variable_manager = C.DEFAULT_LOADER, C.DEFAULT_INVENTORY, C.DEFAULT_INVENTORY
    ansible_connection = 'local'
    context._init_global_context(options)

# Generated at 2022-06-23 06:33:54.073102
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    ds_1 = {}
    ds_1_res = play_1.preprocess_data(ds_1)
    assert isinstance(ds_1_res, dict)
    assert ds_1_res == {}
    ds_2 = {'user': 'root'}
    ds_2_res = play_1.preprocess_data(ds_2)
    assert ds_2_res == {'remote_user': 'root'}
    try:
        ds_3 = {'user': 'root', 'remote_user': 'root'}
        play_1.preprocess_data(ds_3)
    except AssertionError as e:
        assert e.args[0] == "A malformed block was encountered while loading tasks: %s" % to_native

# Generated at 2022-06-23 06:33:58.060557
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    """ test_Play___repr__() - Verify Play.__repr__() returns the name of the Play"""

    # set up test objects
    p = Play()
    p.hosts = 'hosts'
    p.name = 'name'

    # test
    assert p.__repr__() == 'name'
