

# Generated at 2022-06-23 06:24:04.422530
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    assert play.get_vars_files() == []

    play.vars_files = 'abc'
    assert play.get_vars_files() == ['abc']

    play.vars_files = ['abc', 'xyz']
    assert play.get_vars_files() == ['abc', 'xyz']

# Generated at 2022-06-23 06:24:17.160377
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-23 06:24:28.525336
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = load_fixture('play', "play.yml")
    assert play.name == 'Foo'
    assert play.hosts == 'all'
    assert play.user == 'root'

    serialized = play.serialize()
    new_play = Play()

    assert new_play.get_vars() == {}
    new_play.deserialize(serialized)
    assert new_play.name == 'Foo'
    assert new_play.hosts == 'all'
    assert new_play.user == 'root'
    assert new_play.get_vars() == play.get_vars()


# Generated at 2022-06-23 06:24:32.110472
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.handlers = [1,2]
    p.roles = [3]
    assert p.compile_roles_handlers() == [1,2] or p.compile_roles_handlers() == [2,1]

# Generated at 2022-06-23 06:24:34.001720
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert repr(play) == ''


# Generated at 2022-06-23 06:24:41.591202
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    my_play = Play()
    my_play.roles = [Role(name="role1"), Role(name="role2")]
    for role in my_play.roles:
        role.handlers = [{"handler1": {"block": [{"debug": {"msg": "debug1"}}]}}]
    print(my_play.compile_roles_handlers())


if __name__ == "__main__":
    test_Play_compile_roles_handlers()

# Generated at 2022-06-23 06:24:45.418230
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({'name': 'test', 'hosts': ['test_host']})
    assert p.name == 'test'
    assert p.hosts == ['test_host']


# Generated at 2022-06-23 06:24:58.341849
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks[:] = [1, 2, 3, 4]
    p.post_tasks[:] = [5, 6, 7]
    assert p.get_tasks() == [1, 2, 3, 4, 5, 6, 7]

    p = Play()
    p.tasks[:] = [1, 2, 3, 4]
    p.pre_tasks[:] = [0]
    p.post_tasks[:] = [5, 6, 7]
    assert p.get_tasks() == [0, 1, 2, 3, 4, 5, 6, 7]

    p = Play()
    p.tasks[:] = [1, 2, 3, 4]
    p.pre_tasks[:] = [0]
    p.post_tasks[:]

# Generated at 2022-06-23 06:25:06.015369
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    '''
    Tests the get_vars method of the Play class
    '''
    # Create an instance of the Play class
    p = Play()

    # Create a dictionary
    d = {
        'a': 'b',
        'c': 'd',
    }

    # Set the vars attribute of the play instance to the
    # above dictionary
    p.vars = d.copy()

    # Assert that the vars returned by the get_vars
    # method are the same as that of the dictionary
    assert p.get_vars() == d.copy()

# Generated at 2022-06-23 06:25:17.190719
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    tasks = [
        Task.load(dict(action=dict(module='module_1'))),
        Task.load(dict(action=dict(module='module_2'))),
    ]


# Generated at 2022-06-23 06:25:19.618838
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p._handlers = ['handlers']
    assert p.get_handlers() == ['handlers']

# Generated at 2022-06-23 06:25:28.894785
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    """
    Tests the get_vars_files method of the Play class.
    """
    # Test a None vars_files attribute
    p = Play()
    p.vars_files = None

    assert(p.get_vars_files() == [])

    # Test a not None attribute value, with a single string
    p.vars_files = "file.yml"
    assert(p.get_vars_files() == ["file.yml"])

    # Test a not None attribute value with a list
    p.vars_files = ["file.yml", "file2.yml"]
    assert(p.get_vars_files() == ["file.yml", "file2.yml"])


# Generated at 2022-06-23 06:25:39.107057
# Unit test for constructor of class Play
def test_Play():
    import unittest

    class TestPlay(unittest.TestCase):
        def test_init(self):
            play = Play()
            self.assertEqual(play.name, '')
            self.assertEqual(play.hosts, '')
            self.assertEqual(play.remote_user, 'root')
            self.assertEqual(play.connection, 'smart')
            self.assertEqual(play.port, None)
            self.assertEqual(play.gather_facts, False)
            self.assertEqual(play._variable_manager, None)
            self.assertEqual(play.vars, {})
            self.assertEqual(play.vars_prompt, [])
            self.assertEqual(play.vars_files, [])
            self.assertEqual

# Generated at 2022-06-23 06:25:41.267517
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert play.__repr__() == play.get_name()

# Generated at 2022-06-23 06:25:43.338922
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    print("Test Play get_vars")
    Play()


# Generated at 2022-06-23 06:25:48.641482
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    """Unit test for method __repr__ of class Play"""
    play = Play()
    output = repr(play)
    assert  output == play.get_name(), "output = %s, expected 0 = %s" % (output, play.get_name())


# Generated at 2022-06-23 06:25:57.336930
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-23 06:26:03.186977
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.get_roles()
    data = p.serialize()
    assert data['roles'] == []
    assert data.get('included_path', None) == None
    assert data['action_groups'] == {}
    assert data['group_actions'] == {}


# Generated at 2022-06-23 06:26:03.660260
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass



# Generated at 2022-06-23 06:26:06.975411
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = 'test'
    result = play.get_vars_files()
    assert isinstance(result, list)


# Generated at 2022-06-23 06:26:19.529883
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    role1 = {"include_tasks": "tasks/main.yml", "name": "role1"}
    role2 = {"include_tasks": "tasks/main.yml", "name": "role2"}
    role3 = {"include_tasks": "tasks/main.yml", "name": "role3"}
    role4 = {"include_tasks": "tasks/main.yml", "name": "role4"}
    roles = [role1, role2, role3, role4]
    task_data = {"foo_task": {"include_tasks": "tasks/foo.yml", "block": {"tasks": [{"meta": "flush_handlers"}]}}}
    options = {}
    variable_manager = MagicMock()
    loader = MagicMock()

# Generated at 2022-06-23 06:26:22.636630
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    pb = Play()
    assert pb.get_handlers() == []

# Generated at 2022-06-23 06:26:34.425238
# Unit test for method copy of class Play
def test_Play_copy():
    pass

    # self.ROLE_CACHE = self.ROLE_CACHE.copy()
    # self._included_conditional = self._included_conditional
    # self._included_path = self._included_path
    # self._action_groups = self._action_groups
    # self._group_actions = self._group_actions
    # return new_me

# def __setstate__(self, d):
#     ''' Enable pickle to work with object hierarchy '''
#     self.__dict__ = d
#     self.ROLE_CACHE = {}
#     self.only_tags = set(context.CLIARGS.get('tags', [])) or frozenset(('all',))
#     self.skip_tags = set(context.CLIARGS.get('skip

# Generated at 2022-06-23 06:26:44.287043
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # python2.6 compat
    from io import BytesIO

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    data = dict(
        name='test_play',
        hosts=['localhost'],
        gather_facts='no',
        roles=[dict(name='test_role1'), dict(name='test_role2')]
    )

    # Use AnsibleLoader to parse the data as YAML
    data = AnsibleLoader(BytesIO(b'---\n' + to_bytes(yaml.dump(data, default_flow_style=False))), variable_manager=VariableManager()).get_single_data()

    # Cast data

# Generated at 2022-06-23 06:26:45.518760
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize(play.serialize())
    print('Passed test for deserialize of class Play')

# Generated at 2022-06-23 06:26:57.622223
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test Play.compile_roles_handlers
    p = Play()
    assert p.compile_roles_handlers() == []

    # Add a bunch of roles, none of them with handlers
    roles = []
    for i in range(10):
        r = Role()
        r.name = "role-%s" % i
        roles.append(r)
        p.roles.append(r)
    assert p.compile_roles_handlers() == []

    # Add some handlers
    for i in range(10):
        handlers = []
        for j in range(10):
            b = Block(parent_block=p, play=p)
            b.block = [ Handler() for k in range(10) ]
            handlers.append(b)
        roles[i].handlers = handlers


# Generated at 2022-06-23 06:26:59.585458
# Unit test for method compile of class Play
def test_Play_compile():
    """
    Play:compile - the function of Play.compile
    """
    pass


# Generated at 2022-06-23 06:27:03.242462
# Unit test for method load of class Play
def test_Play_load():
    ds = {}
    variable_manager = None
    loader = None
    vars = None

    p = Play.load(ds, variable_manager, loader, vars)
    assert p
    assert isinstance(p, Play)


# Generated at 2022-06-23 06:27:04.515723
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-23 06:27:16.037557
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create a Play object
    Play_obj = Play()
    # Initialize a dict to be used as data structure
    data = {}
    data['name'] = 'Test play name'
    data['hosts'] = ['localhost']
    data['user'] = 'remote_user'
    data['roles'] = []
    data['tasks'] = []
    data['vars_prompt'] = []
    data['vars_files'] = []
    data['handlers'] = []
    data['tags'] = []
    data['gather_facts'] = 'no'
    data['pre_tasks'] = []
    data['post_tasks'] = []
    data['any_errors_fatal'] = False
    data['max_fail_percentage'] = 25
    data['force_handlers'] = False
   

# Generated at 2022-06-23 06:27:22.772317
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pts = Play()
    assert pts.get_tasks() == []
    pts.pre_tasks = [1, 2, 3]
    pts.tasks = [4, 5, 6]
    pts.post_tasks = [7, 8, 9]
    assert pts.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 06:27:23.960188
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    pass
    

# Generated at 2022-06-23 06:27:33.208634
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # data
    data = dict(
            name='test',
            hosts="all",
            gather_facts='no',
            roles=[
                dict(
                     name='role1',
                 ),
                dict(
                    name='role2'
                )
            ]
        )

    # initialize objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost,')
    variable_manager.set_inventory(inventory)
    play = Play.load(data, variable_manager=variable_manager, loader=loader)
    play.pre_validate(inventory)
    play.post_validate(inventory)

    # get the result
    result = play.compile_roles_handlers()

    assert result == []


#

# Generated at 2022-06-23 06:27:41.520253
# Unit test for method serialize of class Play
def test_Play_serialize():
    attrs = dict(
      name = "TEST PLAY",
      hosts = "all",
      roles = ["TEST ROLE"],
    )
    c = Play(attrs)
    serial = c.serialize()
    assert isinstance(serial, dict)
    assert serial["name"] == "TEST PLAY"
    assert serial["hosts"] == "all"
    assert serial["roles"] == ["TEST ROLE"]
    assert serial["tasks"] == None
    assert serial["included_path"] == None
    assert serial["action_groups"] == {}
    assert serial["group_actions"] == {}

# Generated at 2022-06-23 06:27:50.048905
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    playbook = Play()
    playbook._ds = {
        "roles": [
            {
                "role": "common"
            }
        ]
    }
    playbook._validate_roles(attr="roles", name="roles", value=playbook._ds['roles'])
    roles = playbook.get_roles()
    assert roles == playbook.roles
    assert roles[0].__class__.__name__ == "Role"
    assert roles[0].get_name() == "common"


# Generated at 2022-06-23 06:28:02.836868
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # Testing data structure:
    #
    # data_structure_1 = {
    #     "user": "mohit"
    # }
    #
    # data_structure_2 = {
    #     "user": "mohit",
    #     "remote_user": "ansible"
    # }
    #
    # data_structure_3 = {
    #     "user": None
    # }
    #
    # data_structure_4 = {
    #     "user": []
    # }

    # Initializing variables required for testing
    p = Play()
    data_structure_1 = {
        "user": "mohit"
    }

# Generated at 2022-06-23 06:28:11.284313
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # just initialize new instance
    play = Play()
    assert play.get_tasks() == []
    # set pre_tasks
    play.pre_tasks = ["a", "b", "c"]
    # get_tasks should now return list of pre_tasks + tasks + post_tasks
    assert play.get_tasks() == play.pre_tasks + play.tasks + play.post_tasks


# Generated at 2022-06-23 06:28:12.003171
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-23 06:28:21.851023
# Unit test for method deserialize of class Play

# Generated at 2022-06-23 06:28:25.153115
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._load_included_file = MagicMock(return_value='')
    p._load_roles = MagicMock(return_value='')
    assert p.compile_roles_handlers() == []
#Unit test for method compile of class Play

# Generated at 2022-06-23 06:28:37.478678
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play().load(dict(
        name = 'test',
        hosts = 'all',
        gather_facts = 'no',
        pre_tasks = [],
        roles = [],
        tasks = [],
        post_tasks = [],
        handlers = [],
        vars = dict(
            foo = 'bar'
        )
    ), variable_manager=VariableManager(), loader=DictDataLoader())

    from copy import deepcopy
    c = deepcopy(play)
    assert play.get_name() == c.get_name()
    assert play.get_vars() == c.get_vars()
    assert play.get_vars_files() == c.get_vars_files()
    assert play.get_handlers() == c.get_handlers()
    assert play.get_

# Generated at 2022-06-23 06:28:47.268216
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {
        'name': 'test play',
        'roles': [
            {
                'file_name': 'Dummy',
                'name': 'dummy role',
                'default_vars': {
                    'test_var': 'test value'
                }
            }
        ],
        'variables': {
            'test_var': 'test value'
        }
    }

    play = Play()

    play.deserialize(data)

    assert play.get_name() == 'test play'
    assert play.vars == {
        'test_var': 'test value'
    }
    assert len(play.roles) == 1
    assert play.roles[0].get_name() == 'dummy role'

# Generated at 2022-06-23 06:28:57.351666
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.name = "test_play"
    play.hosts = "local"
    play.tasks = """
    - name: This is a task
      ping:
    """

    # Create a dummy role that simpyl returns a single handler and a list of handlers
    class FakeRole(object):
        def __init__(self):
            self.name = "fake_role"
            self.handlers = [
                Handler.load(handler_uuid="a_handler", ds={'name': 'a_handler'}, play=play),
                Handler.load(handler_uuid="another_handler", ds={'name': 'another_handler'}, play=play),
            ]


# Generated at 2022-06-23 06:28:58.635870
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    data = dict()
    play.deserialize(data)


# Generated at 2022-06-23 06:29:01.192157
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = "play_test"
    assert play.__repr__() == "play_test"

# Generated at 2022-06-23 06:29:02.103758
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-23 06:29:05.764003
# Unit test for method load of class Play
def test_Play_load():
    p = Play()
    p.load({'name': "test play"})
    assert p.get_name() == "test play"
    assert p.name == "test play"
    assert p.post_validate()


# Generated at 2022-06-23 06:29:16.590252
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.deserialize({'hosts': u'hosts', 'name': u'test_play', 'remote_user': u'root', 'roles': [{'default_vars': {}, 'name': u'role1'}, {'default_vars': {}, 'name': u'role2'}], 'vars': {}, 'vars_files': []})
    assert play.serialize() == {'hosts': u'hosts', 'name': u'test_play', 'remote_user': u'root', 'roles': [{'default_vars': {}, 'name': u'role1'}, {'default_vars': {}, 'name': u'role2'}], 'vars': {}, 'vars_files': []}


# Generated at 2022-06-23 06:29:26.798785
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    register_filter(AnsibleCoreTest)
    fake_loader = DictDataLoader({
        "foo": "",
        "bar": "",
    })
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list=[])
    t = Play()
    t._loader = fake_loader
    t._variable_manager = VariableManager()
    t._variable_manager.set_inventory(fake_inventory)
    t.vars = {}
    t.vars["foo"] = "bar"
    t._ds = dict(
        name="test",
        hosts="all",
        gather_facts="no",
        roles=[],
        tasks=[],
        handlers=["foo", "bar"],
    )
    t.post_validate()
    t._finalize_data()
   

# Generated at 2022-06-23 06:29:29.894671
# Unit test for method __repr__ of class Play
def test_Play___repr__():
  p = Play()
  assert isinstance(p, Play)
  assert p.__repr__() == 'None'

  p.name = 'test'
  assert p.__repr__() == 'test'



# Generated at 2022-06-23 06:29:33.794917
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    blocks = [Block(block=[]), Block([])]
    tasks = [Task(), Task(), Task()]
    p.tasks = blocks + tasks
    assert p.get_tasks() == list(chain.from_iterable(blocks)) + tasks



# Generated at 2022-06-23 06:29:38.936444
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    play.tasks = [{'action': {'module': 'test_module', 'args': 'args'}}]
    play.post_tasks = [{'action': {'module': 'test_module_2', 'args': 'args'}}]
    play.pre_tasks = [{'action': {'module': 'test_module_3', 'args': 'args'}}]
    play.handlers = [{'action': {'module': 'test_module_4', 'args': 'args'}}]
    play.roles = [{'action': {'module': 'test_module_5', 'args': 'args'}}]
    expected = [{'action': {'module': 'test_module_5', 'args': 'args'}}]
    assert play.get_roles

# Generated at 2022-06-23 06:29:44.283084
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    # Load a test yml file with simple 2 tasks
    p._load_data(get_data_file_path("playbook_get_tasks.yml"))
    # Load the tasks
    assert len(p.get_tasks()) == 2

p = Play()
p._load_data(get_data_file_path("playbook_get_tasks.yml"))


# Generated at 2022-06-23 06:29:57.088646
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # test_Play_preprocess_data constructor
    test_Play_preprocess_data_instance = Play()

# Generated at 2022-06-23 06:30:04.827327
# Unit test for method copy of class Play
def test_Play_copy():
    play1 = Play()
    play2 = play1.copy()
    play1.roles = 'roles'
    play1._included_conditional = 'included_conditional'
    play1._included_path = 'included_path'
    play1._action_groups = 'action_groups'
    play1._group_actions = 'group_actions'
    play1.ROLE_CACHE = 'ROLE_CACHE'
    assert play1.roles == 'roles'
    assert play1._included_conditional == 'included_conditional'
    assert play1._included_path == 'included_path'
    assert play1._action_groups == 'action_groups'
    assert play1._group_actions == 'group_actions'
    assert play1.ROLE_C

# Generated at 2022-06-23 06:30:16.403038
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    test_play_data = {
        'tasks': ['tasks', 'tasks/playbook'],
        'vars_files': 'vars_files',
        'vars': {'test_var': 'test_var_value'}
    }
    test_play_data_list = {
        'tasks': ['tasks', 'tasks/playbook'],
        'vars_files': ['vars_files', 'vars_files/playbook'],
        'vars': {'test_var': 'test_var_value'}
    }

# Generated at 2022-06-23 06:30:19.464342
# Unit test for method load of class Play
def test_Play_load():
    p = Play()
    assert p.load_data(dict(hosts="abc", vars=dict(ansible_user="abc")))



# Generated at 2022-06-23 06:30:32.118652
# Unit test for method serialize of class Play

# Generated at 2022-06-23 06:30:39.729785
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = dict()
    data['name'] = 'test'

    data['handlers'] = [dict()]
    data['hosts'] = 'host1'
    data['tasks'] = [dict()]
    data['vars'] = dict()
    data['vars_prompt'] = dict()
    data['roles'] = [dict()]
    data['included_path'] = 'test'
    data['action_groups'] = dict()
    data['group_actions'] = dict()

    p = Play()
    p.deserialize(data)


# Generated at 2022-06-23 06:30:42.525405
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    new_me = p.copy()
    assert isinstance(new_me, Play) is True, 'Expect to be True'
#Unit test for method deserialize of class Play

# Generated at 2022-06-23 06:30:50.322845
# Unit test for method copy of class Play
def test_Play_copy():
    pass

    # TODO: More tests please.

    #pass
    #p = Play()
    #p.ROLE_CACHE = {}
    #p._included_conditional = None
    #p._included_path = None
    #p._action_groups = {}
    #p._group_actions = {}
    #new_me = p.copy()
    #assert isinstance(new_me, Play)
    ##assert new_me.ROLE_CACHE == {} # TODO: Check this.
    #assert new_me._included_conditional is None
    #assert new_me._included_path is None
    #assert 0 # TODO: Check this.
    #assert new_me._group_actions == {}


# Generated at 2022-06-23 06:30:54.378274
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create the instance
    p = Play()
    p.name = 'test_name'

    # Test get_name of class Play
    name = p.get_name()
    assert name == 'test_name'

# Generated at 2022-06-23 06:31:00.235083
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    playobj = Play()
    data = dict(
        name='test',
        connection='smart',
        hosts=['hello', 'world'],
    )
    playobj.deserialize(data)
    assert playobj.name == 'test'
    assert playobj.connection == 'smart'
    assert playobj.hosts == ['hello', 'world']
    assert isinstance(playobj._role_dependencies, set)


# Generated at 2022-06-23 06:31:04.474696
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    p.roles = [Role()]
    assert p.get_roles()[0].__class__.__name__ == 'Role'


# Generated at 2022-06-23 06:31:16.002470
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {'remote_user': 'alice', 'roles': [{'name': 'example', 'defaults': {'var': {'some_key': 'some_value'}}, 'tasks': ['task1', 'task2']}], 'hosts': 'hosts.example.org', 'playbook': 'example.yml', 'gather_facts': 'no', 'name': 'test_Play_deserialize', 'roles_path': '/path/to/roles', 'action_groups': {}, 'group_actions': {}}

# Generated at 2022-06-23 06:31:26.831205
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-23 06:31:36.755209
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.vars = {'a':3}
    p.name = 'test play'
    p.hosts = 'all'
    p.remote_user = 'root'
    p.any_errors_fatal = True
    p.become = True
    p.become_user = 'wheel'
    p.tags = ['a', 'b']
    p.roles = []
    p.roles.append(Role())
    p.roles.append(Role())
    p.tasks = []
    t = Task()
    t.name = 'test task 1'
    p.tasks.append(t)
    t = Task()
    t.name = 'test task 2'
    p.tasks.append(t)
    p.pre_tasks = []
   

# Generated at 2022-06-23 06:31:42.005639
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_data = dict(
        name="Ansible Play",
        hosts="all",
        gather_facts="no",
        roles=[]
    )

    play = Play.load(play_data)

    play.compile_roles_handlers()


# Generated at 2022-06-23 06:31:54.898498
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.vars = {"key1": "value1"}
    play.handlers = {"key2": "value2"}
    play.tags = {"key3": "value3"}
    play.no_log = {"key4": "value4"}
    play.hosts = {"key5": "value5"}
    play.roles = {"key6": "value6"}
    play.post_tasks = {"key7": "value7"}
    play.tasks = {"key8": "value8"}
    play.pre_tasks = {"key9": "value9"}
    play.when = {"key10": "value10"}
    data = play.serialize()
    print(data)
    new_play = Play()
    new_play.deserialize(data)

# Generated at 2022-06-23 06:32:00.636870
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    r1 = Role()
    r2 = Role()
    b1 = Block('meta', 'flush_handlers')
    b2 = Block('meta', 'flush_handlers')
    r1.compiled_tasks = set([b1])
    r2.compiled_tasks = set([b2])
    play.roles = [r1, r2]
    assert play.compile_roles_handlers() == [b1, b2]


# Generated at 2022-06-23 06:32:05.429153
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play._validate_hosts = lambda: True
    play.load(dict(
        name='the_play',
        hosts=['localhost'],
        gather_facts=False,
        tasks=[]
    ))

    assert repr(play) == 'the_play'


# Generated at 2022-06-23 06:32:09.015813
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    assert play.get_roles() == []

# Generated at 2022-06-23 06:32:14.200051
# Unit test for method get_name of class Play
def test_Play_get_name():
    def mocked_load_data(self, data, variable_manager=None, loader=None):
        self._attributes = {}
        self.hosts = 'host1'
        return self

    with patch.object(Play, 'load_data', mocked_load_data):
        p = Play()
        assert p.get_name() == 'host1'



# Generated at 2022-06-23 06:32:24.557072
# Unit test for method serialize of class Play

# Generated at 2022-06-23 06:32:35.893596
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_data = {'hosts': 'localhost', 'tasks': [{'local_action': {'module': 'shell', 'args': 'echo TEST > /tmp/test1.txt'}},
                                                 {'local_action': {'module': 'shell', 'args': 'echo TEST > /tmp/test2.txt'}},
                                                 {'local_action': {'module': 'shell', 'args': 'echo TEST > /tmp/test3.txt'}}]}

    play = Play.load(play_data, variable_manager=None)
    play.ROLE_CACHE = {}
    play._included_conditional = None
    play._included_path = None
    play._action_groups = {}
    play._group_actions = {}

    data = play.compile_roles_handlers

# Generated at 2022-06-23 06:32:40.194605
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = ['test']
    assert play.get_vars_files() == ['test']


# Generated at 2022-06-23 06:32:48.956967
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    unit test for `compile_roles_handlers` method of class Play
    '''
    # Check for `isinstance(self, Play)`
    play = Play()
    assert isinstance(play, Play)
    # Check for `isinstance(self.roles, list)`
    assert isinstance(play.roles, list)
    assert not play.roles

    # Check error message
    msg = "lack the attribute `get_handler_blocks`"
    pre_msg = "`self.roles`"
    with pytest.raises(AttributeError, match=r".*{0}.*{1}".format(pre_msg, msg)):
        play.compile_roles_handlers()

    # Check `self.roles` is not empty, else return `block_list`

# Generated at 2022-06-23 06:32:53.925668
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    my_play = Play()
    my_task = Task()
    my_play.roles.append(Role())
    my_play.roles.append(Role())
    role_list = my_play.get_roles()
    assert len(role_list) == 2
    assert role_list[1].__class__.__name__ == 'Role'
    assert role_list[0].__class__.__name__ == 'Role'


# Generated at 2022-06-23 06:33:07.412911
# Unit test for method copy of class Play
def test_Play_copy():
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode

    p = Play()
    p.ROLE_CACHE = {}
    p._included_conditional = 'test'
    p._included_path = 'test2'
    p._action_groups = {'key': 'value'}
    p._group_actions = {'key': 'value'}
    p.name = 'test3'
    p.remote_user = 'test4'
    p.sudo = 'test5'
    p.sudo_user = 'test6'
    p.become = 'test7'
    p.become_method = 'test8'
    p.become_user = 'test9'
    p.connection = 'test10'
   

# Generated at 2022-06-23 06:33:08.437078
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # TODO
    pass

# Generated at 2022-06-23 06:33:20.190441
# Unit test for method get_name of class Play
def test_Play_get_name():
    my_playbook = Playbook()
    my_play = Play()
    my_play.name="test_play"
    my_playbook._entries.append(my_play)
    my_play_too = Play()
    my_play_too.hosts="host1"
    my_playbook._entries.append(my_play_too)
    print(my_playbook.get_entries())
    assert my_playbook.get_entry_type('test_play') == 'play'
    assert my_playbook.get_entry_type('host1') is None
    assert my_playbook.get_names()==['test_play', 'host1']
    assert my_play.get_name() == 'test_play'
    assert my_play_too.get_name() == 'host1'

# Generated at 2022-06-23 06:33:26.415985
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    # Test to make sure that there are no failure cases
    assert play.get_name() is not None


# Generated at 2022-06-23 06:33:37.736058
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
 
    data = dict(
        name = 'a',
        hosts = ['localhost'], # ansible_connection
        remote_user = 'user', # ansible_user
        gather_facts = 'no'
    )
 
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
 
    play = Play.load(data, variable_manager=variable_manager, loader=loader)
    play.compile_roles_handlers()
    pass

test_Play_compile_roles_handlers()

# Generated at 2022-06-23 06:33:49.845861
# Unit test for constructor of class Play
def test_Play():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    p = Play().load({}, variable_manager=VariableManager(), loader=DataLoader())

    # constructor
    assert p._loader == DataLoader()
    assert p._variable_manager == VariableManager()
    assert p._included_path == None
    assert p._included_conditional == None
    assert p._removed_hosts == []
    assert p._action_groups == {}
    assert p._group_actions == {}
    assert p.ROLE_CACHE == {}
    assert p.only_tags == frozenset(('all',))
    assert p.skip_tags == set()
    assert p.name == ''
    assert p.hosts == ''

# Generated at 2022-06-23 06:33:55.290209
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._validate_custom_paths = MagicMock(return_value=True)
    p.vars = dict()
    p._ds = dict()
    p._action_groups = dict()
    p._group_actions = dict()
    p.post_validate = MagicMock(return_value=None)
    p.compile_roles_handlers()



# Generated at 2022-06-23 06:34:05.317314
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import mock
    # Mock attributes:
    #     always
    #     block
    #     from_include
    #     handlers
    #     hosts
    #     ignore_errors
    #     implicit
    #     loop
    #     name
    #     post_tasks
    #     pre_tasks
    #     rescue
    #     serial
    #     tasks
    #     tags
    #     when
    
    
    # Create an instance of a generic play object
    play_obj = Play()
    
    # Create a mock Block object
    block_obj = mock.create_autospec(
        Block
    )

    # Set attributes of the mock Block object
    block_obj.rescue = [
        block_obj,
        block_obj,
        block_obj
    ]
    block_obj.always