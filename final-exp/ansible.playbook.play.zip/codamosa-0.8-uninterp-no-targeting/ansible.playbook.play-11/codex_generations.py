

# Generated at 2022-06-21 00:42:57.189320
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.vars = {
        'var1': 'val1',
        'var2': 'val2',
        'var3': 'val3'
    }
    play.roles = [
        Role(name='Role1', play=play),
        Role(name='Role2', play=play),
        Role(name='Role3', play=play)
    ]

    data = play.serialize()
    new_play = Play()
    new_play.deserialize(data)

    assert play.vars == new_play.vars
    assert play.roles[0].name == new_play.roles[0].name
    assert play.roles[1].name == new_play.roles[1].name

# Generated at 2022-06-21 00:42:59.966910
# Unit test for constructor of class Play
def test_Play():
    '''
    Play constructor unit test
    '''
    p = Play()


# Generated at 2022-06-21 00:43:09.222207
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    pl = Play()

# Generated at 2022-06-21 00:43:17.350462
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    tasks = []
    play.pre_tasks = [Block({"task": Task(task_ds={"name": "task1"})}), Block({"task": Task(task_ds={"name": "task2"})})]
    play.tasks = [Block({"task": Task(task_ds={"name": "task3"})}), Block({"task": Task(task_ds={"name": "task4"})})]
    play.post_tasks = [Block({"task": Task(task_ds={"name": "task5"})}), Block({"task": Task(task_ds={"name": "task6"})})]
    tasks = play.get_tasks()
    assert len(tasks) == 6
    assert tasks[0].get_name() == "task1"
    assert tasks

# Generated at 2022-06-21 00:43:21.219966
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {'key': 'value'}
    assert p.get_vars() == {'key': 'value'}


# Generated at 2022-06-21 00:43:22.769297
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass # nothing to test

# Generated at 2022-06-21 00:43:33.335284
# Unit test for constructor of class Play
def test_Play():

    # For testing, disable lookups and vars plugin loading, because
    # it makes it hard to test class attributes.
    context.CLIARGS = ImmutableDict(connection='local', module_path=None, forks=10, become=False,
                                 become_method=None, become_user=None, check=False, diff=False,
                                 verbosity=3)

    # An empty play, consisting of just required parameters
    play = Play()
    assert play.connection == 'local'
    assert play.hosts == 'all'
    assert play.name == ''
    assert play.become == False
    assert play.become_user == None
    assert play.become_method == None
    assert play._ds == dict()

    # A play with all of the parameters

# Generated at 2022-06-21 00:43:35.513386
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    Play_instance = Play()
    assert Play_instance.get_roles is None
    assert Play_instance.get_roles() == []

# Generated at 2022-06-21 00:43:40.755832
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test play"
    assert play.name == play.get_name()
    play.name = None
    play.hosts = "test_host"
    assert play.hosts == play.get_name()

# Generated at 2022-06-21 00:43:45.427583
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    obj = Play()
    result = obj.get_handlers()
    assert result is not None, 'Return type is: ' + str(type(result)) + '. Expected: handler list.'



# Generated at 2022-06-21 00:43:56.621963
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = fake_handlers

    result = p.get_handlers()

    assert result == fake_handlers

# Generated at 2022-06-21 00:44:06.812035
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Setup
    play = Play()

    # Test 1
    ds = None
    try:
        play.preprocess_data(ds)
    except AnsibleAssertionError as e:
        assert str(e) == 'while preprocessing data (None), ds should be a dict but was a <class \'NoneType\'>', 'Raised error message does not match'
    except Exception as e:
        assert False, 'Raised error message does not match'
    else:
        assert False, 'AnsibleAssertionError not raised'

    # Test 2
    ds = {}
    res = play.preprocess_data(ds)
    assert res == {}, 'Return value of preprocess_data method of Play class does not match'

    # Test 3
    ds = {'user': 'John'}

# Generated at 2022-06-21 00:44:10.882385
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Create an instance of Play
    p = Play()

    # Get the JSON representation of the instance
    data = p.serialize()
    
    # Deserialize the instance
    p.deserialize(data)

    # Test if the deserialization is successful
    assert(isinstance(p, Play))

# Generated at 2022-06-21 00:44:11.839024
# Unit test for method load of class Play
def test_Play_load():
    assert True

# Generated at 2022-06-21 00:44:14.141633
# Unit test for method copy of class Play
def test_Play_copy():
    # Note that how to test returns value is already unit tested by test_Base.copy
    # TODO: implement this test
    pass

# Generated at 2022-06-21 00:44:23.448809
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    p_get_roles = lambda :p.get_roles()
    assert(p_get_roles() == [])
    p.roles = ['role1', 'role2']
    assert(p_get_roles() == ['role1', 'role2'])
    p.roles = []
    assert(p_get_roles() == [])

# Generated at 2022-06-21 00:44:36.569307
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from ansible.parsing import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.constants import DEFAULT_SUDO_USER, DEFAULT_REMOTE_USER
    from ansible.constants import DEFAULT_SUBSET
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    import ansible.constants as C
    import json

    # Create a basic inventory for testing
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set

# Generated at 2022-06-21 00:44:44.431053
# Unit test for method get_name of class Play
def test_Play_get_name():
    play1 = Play()

    play1.hosts = "hosts-value"
    assert play1.get_name == "hosts-value"

    play2 = Play()

    play2.hosts = ['hosts-value', 'hosts-value']
    assert play2.get_name == "hosts-value,hosts-value"


# Generated at 2022-06-21 00:44:46.891004
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert repr(play) == play.get_name()

# Generated at 2022-06-21 00:44:57.792554
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    '''
    As there is no direct access to get_vars method, it has to be called through init method
    '''
    '''
    As there is no direct access to vars.copy(), it has to be called through get_vars method
    '''
    '''
    As there is no direct access to vars, it has to be called through get_vars method
    '''
    '''
    As there is no direct access to vars, it has to be called through get_vars method
    '''

# Generated at 2022-06-21 00:45:10.667302
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'SOME NAME'
    expected_output = 'SOME NAME'
    assert (p.get_name() == expected_output)

    p.name = None
    p.hosts = 'HOST'
    expected_output = 'HOST'
    assert (p.get_name() == expected_output)

    p.hosts = ['HOST1', 'HOST2']
    expected_output = 'HOST1,HOST2'
    assert (p.get_name() == expected_output)


# Generated at 2022-06-21 00:45:25.150701
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''test_Play_get_tasks is a unit test for method get_tasks of class Play'''
    import copy
    data = copy.deepcopy(DATA_PL)
    data["serial"] = 0
    data["strategy"] = "free"    
    data["connection"] = "local"
    data["max_fail_percentage"] = 0
    p = Play()
    p.load_data(data=data)
    p.ROLE_CACHE = {}
    p._included_conditional = None
    p._included_path = None
    p._removed_hosts = []
    p.only_tags = set(context.CLIARGS['tags']) or frozenset(('all',))
    p.skip_tags = set(context.CLIARGS['skip_tags'])

# Generated at 2022-06-21 00:45:34.935318
# Unit test for method serialize of class Play
def test_Play_serialize():
    test_play = Play()
    test_play.name = "test_play"
    # test_play.vars = {'test': 'test_value'}
    test_play.vars_files = [{'test': 'test_vars_files'}]
    # test_play.hosts = "localhost"
    # test_play.connection = "ssh"
    # test_play.user = "root"
    # test_play.gather_facts = True
    test_play.tasks = [{"action": {"module": "debug", "args": {"msg": "test_msg"}}}]

# Generated at 2022-06-21 00:45:44.385678
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert callable(p.compile_roles_handlers)

    # ------
    # 1. Roles is empty
    p.roles = []

    assert p.compile_roles_handlers() == []
    # ------
    # 2. Role.from_include is True
    r1 = mock.MagicMock()
    r1.from_include = True
    r2 = mock.MagicMock()
    r2.from_include = False
    p.roles = [r1, r2]

    assert list(map(lambda x: x.from_include, p.compile_roles_handlers())) == [False]
    # ------
    # 3. Role.from_include is False
    r2.from_include = True
    r3 = mock.MagicMock

# Generated at 2022-06-21 00:45:49.031839
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    test_Play = Play()
    test_data = {'user': 'naveen'}
    test_Play.preprocess_data(test_data)



# Generated at 2022-06-21 00:45:57.488837
# Unit test for constructor of class Play
def test_Play():
    # Tests empty constructor.
    play = Play()
    assert play is not None
    assert play.vars is None
    assert play.hosts is None
    assert play.name is None
    assert play.connection is None
    assert play.priority is None
    assert play.gather_facts is None
    assert play.remote_user is None
    assert play.tags is None
    assert play.any_errors_fatal is None
    assert play.become is None
    assert play.become_user is None
    assert play.become_method is None
    assert play.delegate_to is None
    assert play._handlers is None
    assert play._pre_tasks is None
    assert play._post_tasks is None
    assert play._tasks is None
    assert play.force_handlers is None

# Generated at 2022-06-21 00:46:08.387697
# Unit test for method compile of class Play
def test_Play_compile():
    # Test function 1
    # Tests that a flush meta task is appended to the end of each block
    # and of the pre, main and post tasks, and that these calls are done
    # in the right order
    # Note: flush_handlers is not the same as flush_tasks
    p = Play()
    p._load_tasks(None, [
        {'name': 'foo'}
    ])
    p._load_handlers(None, [
        {'name': 'bar'}
    ])
    p.pre_tasks = [
        {'name': 'prefoo'}
    ]
    p.post_tasks = [
        {'name': 'postbar'}
    ]
    p._compile_roles()
    p.compile()


# Generated at 2022-06-21 00:46:13.523191
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.parsing.dataloader import DataLoader

    play_data = {
        'name': 'test_play',
        'hosts': 'localhost',
        'roles': ['role1', 'role2']
    }

    play = Play.load(play_data, variable_manager=VariableManager(), loader=DataLoader())
    serialize_data = play.serialize()

    assert serialize_data['name'] == 'test_play'
    assert serialize_data['hosts'] == 'localhost'
    assert serialize_data['roles'] == [{}, {}]

    assert serialize_data['included_path'] == None
    assert serialize_data['action_groups'] == {}
    assert serialize_data['group_actions'] == {}


# Generated at 2022-06-21 00:46:19.275001
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    pl_hosts = 'testhosts'
    play.hosts = pl_hosts
    a = play.get_name()
    b = pl_hosts
    assert(a == b)


# Generated at 2022-06-21 00:46:22.773572
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p._ds = {'name': 'Test Play'}
    assert p.__repr__() == 'Test Play'


# Generated at 2022-06-21 00:46:39.363517
# Unit test for method compile of class Play
def test_Play_compile():
    # create fake play
    test_play = Play()

    # set attributes
    test_play.pre_tasks = {
        'first pre_task' : 'value',
        'second pre_task' : 'value',
    }
    test_play.post_tasks = {
        'first post_task' : 'value',
        'second post_task' : 'value',
    }
    test_play.tasks = {
        'first task' : 'value',
        'second task' : 'value',
    }

    # compile
    # test_play.compile()
    # check result
    assert test_play.compile() == ['first pre_task', 'second pre_task', 'first task', 'second task', 'first post_task', 'second post_task']



# Generated at 2022-06-21 00:46:40.505619
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-21 00:46:49.225657
# Unit test for method get_roles of class Play

# Generated at 2022-06-21 00:46:59.653031
# Unit test for constructor of class Play

# Generated at 2022-06-21 00:47:00.383061
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass


# Generated at 2022-06-21 00:47:02.575773
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    assert play.get_handlers() is not None


# Generated at 2022-06-21 00:47:03.376428
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-21 00:47:09.864731
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.vars == dict()
    assert play.tasks == []
    assert play.handlers == []
    assert play.roles == []
    assert play.post_tasks == []
    assert play.pre_tasks == []
    assert play.name == ''


# Generated at 2022-06-21 00:47:20.350151
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.callback.default import CallbackModule
    import pprint

    # Create play
    play = Play()

    # Test __repr__
    assert play.__repr__() == 'None'

    # Load callback
    callback = CallbackModule()

    # Load inventory
    loader = DataLoader()

# Generated at 2022-06-21 00:47:24.762973
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    obj = Play()
    obj.roles = ['B1', 'B2']
    assert obj.get_roles() == ['B1', 'B2']


# Generated at 2022-06-21 00:47:34.827165
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()

    block_list = []

    assert play.compile_roles_handlers() == block_list

# Generated at 2022-06-21 00:47:40.451559
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    # __repr__ is used (amongst other places) in the python debugger via pdb.
    # assert(repr(play) == "Play({'name': ''})")
    assert(repr(play) == "Play()")
    play.name = 'playname'
    assert(repr(play) == "playname")


# Generated at 2022-06-21 00:47:46.307288
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    '''
    Unit test for method __repr__ of class Play
    '''
    play_mock = Play()
    play_mock.name = "test name"
    assert play_mock.__repr__() == "test name"


# Generated at 2022-06-21 00:47:48.366529
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    result = Play().__repr__()
    assert result is None


# Generated at 2022-06-21 00:47:49.074611
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    return True

# Generated at 2022-06-21 00:48:02.703971
# Unit test for method copy of class Play
def test_Play_copy():
    import copy
    import tempfile

    # Setup a play object
    data = {}
    data['hosts'] = 'all'
    data['name'] = 'Ansible Play'
    data['variables'] = {}
    data['roles'] = []
    data['included_path'] = 'path'
    data['action_groups'] = {}
    data['group_actions'] = {}
    vars = MagicMock()
    vars.copy.return_value = {}
    p = Play()
    p.vars = vars
    p.load_data(data, variable_manager=MagicMock(), loader=MagicMock())

    # Verify that 'p' and 'p_copy' are equal
    p_copy = p.copy()
    assert p == p_copy, "Failed to copy play object"


# Generated at 2022-06-21 00:48:13.995940
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.name = 'default'
    p.hosts = 'all'
    p.remote_user = 'root'
    p.sudo = True
    p.connection = 'local'
    p.become = True
    p.become_user = 'admin'
    p.vars = dict(
        username='admin',
        password='12345'
    )
    p.port = '22'
    p.serial = 10
    p.extra_vars = dict(
        foo=1,
        bar=2
    )
    p.roles = [
        Role(
            get_data_loader(),
            variable_manager=VariableManager()
        )
    ]
    p.tasks = [
        {'name': 'do something'}
    ]
    p.post

# Generated at 2022-06-21 00:48:18.931194
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    play._loader = 'test'
    play.tasks = [{'meta': 'flush_handlers'}]
    assert play.compile() == play.tasks


# Generated at 2022-06-21 00:48:26.985425
# Unit test for method serialize of class Play
def test_Play_serialize():
    hostfile = tempfile.NamedTemporaryFile()
    hostfile.write(b'[localhost]\nlocalhost ansible_connection=local\n')
    hostfile.flush()
    
    iterator = PlayIterator([], None, None)
    
    loader = DataLoader()
    inventory = Inventory(loader = loader, variable_manager = VariableManager(), host_list = hostfile.name)


# Generated at 2022-06-21 00:48:34.129843
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_module = AnsibleModule(argument_spec=dict(
        roles=dict(type='list'),
        included_path=dict(type='str'),
        action_groups=dict(type='dict', default={}),
    ))
    play_arguments = play_module.params
    play_instance = Play.load(play_arguments)
    play_instance.deserialize(play_instance.serialize())


# ===========================================
# Module execution.
#

# Generated at 2022-06-21 00:49:00.193070
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from collections import namedtuple
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    MockedHandler = namedtuple("MockedHandler", ["block"])
    MockedTask = namedtuple("MockedTask", ["block"])

    play = Play()
    role = Role()

    role1 = Role()
    role1.name = "role1"
    task1 = MockedTask(block=Block(
        name='name1',
        role=role1,
        tasks=[MockedTask(block=None), MockedTask(block=None)]
    ))

# Generated at 2022-06-21 00:49:06.619220
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    x = Play()
    assert not x.get_vars_files()
    assert ['./test'] == Play.load({'vars_files' : './test'}).get_vars_files()
    assert ['./test1', './test2'] == \
           Play.load({'vars_files' : ['./test1', './test2']}).get_vars_files()


# Generated at 2022-06-21 00:49:07.648691
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    assert p.compile() == []

# Generated at 2022-06-21 00:49:13.550243
# Unit test for method get_name of class Play
def test_Play_get_name():
    # DUT
    dut = Play()
    # Test
    for case in get_cases('Play_get_name'):
        log.debug('testing if %s equals to %s', dut.get_name(), case.expected_result)
        assert dut.get_name() == case.expected_result

# Generated at 2022-06-21 00:49:20.050340
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # vars should be copy of vars
    p = Play()
    p.vars = {"a":"b"}
    r = p.get_vars()
    assert(r == {"a":"b"})
    r["a"] = "c"
    assert(p.vars == {"a":"b"})
    assert(r == {"a":"c"})

# Generated at 2022-06-21 00:49:26.356765
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Mock member variables of class Play
    play = Play()
    play.tasks = [1,2,3]
    play.pre_tasks = [4,5,6]
    play.post_tasks = [7,8,9]

    # Test get_tasks
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 00:49:32.164779
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ["vars.yml"]
    assert(p.get_vars_files() == ["vars.yml"])

    p2 = Play()
    p2.vars_files = None
    assert(p2.get_vars_files() == [])

    p3 = Play()
    p3.vars_files = []
    assert(p3.get_vars_files() == [])

# Generated at 2022-06-21 00:49:45.241156
# Unit test for method compile of class Play
def test_Play_compile():
    # Test fixture for method compile of class Play
    host_patterns = 'all'
    play_basedir = '/home/vagrant/ansible'
    ds = {'name': 'test_play', 'hosts': host_patterns, 'gather_facts': 'no', 'connection': 'local',
        'tasks': [{'name': 'test_task', 'action': 'test_action'}]}
    loader = DataLoader()
    variable_manager = VariableManager()
    p = Play()
    p.load_data(ds, loader=loader, variable_manager=variable_manager, play_basedir=play_basedir)

    # Unit test
    ret = p.compile()

    # Verify

# Generated at 2022-06-21 00:49:55.725135
# Unit test for method compile of class Play
def test_Play_compile():
    # Test execution if Play._compile_roles() raises an exception
    set_module_args(dict(
        roles='[{"name": "foo", "src": "foo/bar.tar.gz"}]',
    ))
    from ansible.playbook.play import Play
    from ansible.plugins.loader import roles_loader
    import ansible.errors as errors
    from collections import namedtuple
    MockLoaderResults = namedtuple('MockLoaderResults', ['result', 'paths'])
    def my_load_roles(paths):
        raise errors.AnsibleParserError("AnsibleParserError")
    monkeypatch.setattr('ansible.plugins.loader.roles_loader._load_roles', my_load_roles)

# Generated at 2022-06-21 00:49:59.401841
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = dict(hosts="hostname",
                vars=dict(name="test",
                          value=1))
    yaml_test_string = yaml.dump(data)
    assert Play.load(data=yaml_test_string)

Play()

# https://raw.githubusercontent.com/ansible/ansible/v2.9.7/lib/ansible/playbook/block.py

# Generated at 2022-06-21 00:50:45.557263
# Unit test for constructor of class Play
def test_Play():
    p = Play()

    assert p.name is None
    assert p.hosts == ''
    assert p.gather_facts == C.DEFAULT_GATHER_FACTS
    assert p.any_errors_fatal is False
    assert p.max_fail_percentage == 0
    assert p.serial == []
    assert p.handlers == []
    assert p.roles == []
    assert p.tags == []
    assert p.skip_tags == []
    assert p.tasks is None
    assert p.connection == 'network_cli'
    assert p.vars is None
    assert p.vars_prompt is None
    assert p.vars_files is None
    assert p.connections is None
    assert p.transport == 'smart'
    assert p._variable_manager is None

# Generated at 2022-06-21 00:50:54.672780
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    new_play = play.copy()
    assert play.ROLE_CACHE == new_play.ROLE_CACHE
    assert play._included_conditional == new_play._included_conditional
    assert play._included_path == new_play._included_path
    assert play._action_groups == new_play._action_groups
    assert play._group_actions == new_play._group_actions


# Test the copy method of class Play
test_Play_copy()


# Generated at 2022-06-21 00:50:58.267244
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_Play_name'
    assert play.get_name() == 'test_Play_get_name'

    play2 = Play()
    play2.hosts = 'test_hosts'
    assert play2.get_name() == 'test_hosts'



# Generated at 2022-06-21 00:51:10.266964
# Unit test for method load of class Play

# Generated at 2022-06-21 00:51:20.419258
# Unit test for constructor of class Play
def test_Play():
    yaml_data = '''
 - hosts: localhost
   roles: [ role1 ]
   tasks:
     - debug: msg='here'
     - debug: msg='there'
'''

# Generated at 2022-06-21 00:51:27.568989
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = set()
    assert play.compile_roles_handlers() == []
    play.roles = [mock.Mock()]
    assert play.compile_roles_handlers() == []
    play.roles[0].from_include = False
    assert play.compile_roles_handlers() == []

# Generated at 2022-06-21 00:51:36.047807
# Unit test for method serialize of class Play
def test_Play_serialize():
    host = 'localhost'
    new_play = Play.load(dict(name="test_play", hosts=host, gather_facts='no',
                              tasks=dict(action=dict(module="shell",
                                                     args=dict(cmd="whoami")))))
    new_play.serialize()
    assert new_play.serialize()['__ansible_playbook_python__']['version'] == 2


# Generated at 2022-06-21 00:51:38.781715
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.handlers = [{'name': 'test'}]
    assert play.get_handlers() == [{'name': 'test'}]


# Generated at 2022-06-21 00:51:40.976230
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    assert play.vars_files == []

# Generated at 2022-06-21 00:51:43.734733
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pl = Play()
    assert pl.get_vars() == dict()