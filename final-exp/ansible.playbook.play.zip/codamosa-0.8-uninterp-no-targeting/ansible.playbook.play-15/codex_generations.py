

# Generated at 2022-06-21 00:43:13.542836
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play._ds['hosts']='a'
    assert play.get_name() == 'a'

    play._ds['hosts']=['a']
    assert play.get_name() == 'a'

    play._ds['name']='a'
    assert play.get_name() == 'a'

    play._ds['name']=None
    assert play.get_name() == 'a'


# Generated at 2022-06-21 00:43:19.758891
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['/path/to/file1', '/path/to/file2']
    assert play.get_vars_files() == ['/path/to/file1', '/path/to/file2']

# Generated at 2022-06-21 00:43:23.082580
# Unit test for method __repr__ of class Play
def test_Play___repr__():

    play = Play()
    play.name = 'bob'
    assert str(play) == 'bob'

# Generated at 2022-06-21 00:43:25.889459
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    mock_data = dict()
    play = Play()
    play.deserialize(mock_data)


# Generated at 2022-06-21 00:43:34.276228
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    p.roles = ['role1', 'role2', 'role3']
    assert p.get_roles() == ['role1', 'role2', 'role3']

    assert p.roles == ['role1', 'role2', 'role3']
    p.get_roles()
    assert p.roles == ['role1', 'role2', 'role3']



# Generated at 2022-06-21 00:43:37.245024
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    _me = Play()
    _me.get_name = MagicMock(return_value='test_Play')
    assert _me.__repr__() == 'test_Play'



# Generated at 2022-06-21 00:43:46.810572
# Unit test for method load of class Play
def test_Play_load():
    attr = {}
    ds = {}

    play = Play()

    # --------------- test when ds is None
    try:
        ds = None
        play.load_roles(attr, ds)
        assert False
    except AssertionError:
        pass

    # --------------- test when ds is not dict or list
    try:
        ds = 45
        play.load_roles(attr, ds)
        assert False
    except AssertionError:
        pass

    # --------------- test when ds is dict
    try:
        ds = {"name": "test", "roles": "role"}
        play.load_roles(attr, ds)
        assert False
    except AnsibleParserError:
        pass

    # --------------- test when ds is list

# Generated at 2022-06-21 00:43:53.608249
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    for class_name in ('Play',):
        for method_name in ('__repr__',):
            m = getattr(globals()[class_name](), method_name)
            assert m is not None
            assert m()


# ====== Unit test for class RoleInclude ======


# Generated at 2022-06-21 00:44:01.190858
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    Unit test for method get_vars_files of class Play
    '''
    play = Play()
    play._ds = {}
    play._ds['vars_files'] = 'vars.dat'
    assert play.get_vars_files() == ['vars.dat']
    play1 = Play()
    play1._ds = {}
    play1._ds['vars_files'] = ['vars.dat']
    assert play1.get_vars_files() == ['vars.dat']

# Generated at 2022-06-21 00:44:11.381623
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = dict(
        hosts   = 'all',
        vars    = dict(
            http_port = 80,
            max_clients = 200
        ),
        tasks   = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami')),
        ],
        handlers = [
            dict(action=dict(module='debug', args=dict(msg='{{http_port}} is the {{inventory_hostname}} port')))
        ]
    )

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory'))

# Generated at 2022-06-21 00:44:23.908952
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    unit_test_data = dict(
        user='root'
    )

    p = Play()
    new_data = p.preprocess_data(unit_test_data)

    assert new_data == dict(remote_user='root')

# Generated at 2022-06-21 00:44:25.587421
# Unit test for method serialize of class Play
def test_Play_serialize():
    '''
    serialize(self)
    '''

    pass

# Generated at 2022-06-21 00:44:26.420153
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
  pass

# Generated at 2022-06-21 00:44:30.422002
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    result = repr(p)
    expected = p.get_name()
    assert result == expected

# Generated at 2022-06-21 00:44:36.611290
# Unit test for constructor of class Play
def test_Play():
    play_ds = {}
    play_ds['name'] = 'ping all hosts'
    play_ds['hosts'] = 'all'
    play_ds['gather_facts'] = 'no'
    _play = Play.load(play_ds)
    assert isinstance(_play, Play)

# Generated at 2022-06-21 00:44:41.458453
# Unit test for method copy of class Play
def test_Play_copy():
    myobj = Play()
    assert myobj.copy() is not None, 'unit test failed'
    # assert myobj.copy().__eq__() is not None, 'unit test failed'


# Generated at 2022-06-21 00:44:42.409477
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-21 00:44:46.456974
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    p.roles = [1, 2, 3]
    assert p.get_roles() == [1, 2, 3]

# Generated at 2022-06-21 00:44:48.153892
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    pass



# Generated at 2022-06-21 00:44:49.197886
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    pass

# Generated at 2022-06-21 00:45:09.174407
# Unit test for method serialize of class Play
def test_Play_serialize():
    my_play = Play()
    my_play.start()
    my_play.name = "Local"
    my_play.connection = "ssh"
    my_play.remote_user = "root"
    my_play.become = False
    my_play.become_method = None
    my_play.become_user = None
    my_play.vars = {'var_one': 1, 'var_two': 'foo'}
    my_play.vars_files = ["/path/to/file.yml", "/path/to/otherfile.yml"]

# Generated at 2022-06-21 00:45:22.939008
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    import ansible.playbook.play_context
    import ansible.playbook.play_iterator
    x = Play()
    x._ds = dict() # ds is not a dict? this is the default in __init__
    data = {'data': 'data'}
    try:
        x.preprocess_data(data)
        assert False, 'AnsibleAssertionError not raised'
    except AnsibleAssertionError:
        pass
    # The value of user is replaced with remote_user if both are set.
    # You need to set user and remote_user to test this block.
    #data = {'user': 'user', 'remote_user': 'remote_user'}
    #x.preprocess_data(data)
    #assert not data['user']
    #assert data['remote_user']


# Generated at 2022-06-21 00:45:31.306995
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    class Dummy_Play(object):
        def __init__(self, handlers=None, **kwargs):
            self.handlers = handlers or dict()

        def get_handlers(self):
            ''' return handlers of the Play '''
            return self.handlers

    dummy_handlers = [1,2]
    dummy_play = Dummy_Play(handlers=dummy_handlers)
    assert dummy_play.get_handlers() == dummy_handlers


# Generated at 2022-06-21 00:45:35.505186
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = {'roles': 1}
    play.preprocess_data(ds)

# Generated at 2022-06-21 00:45:41.530461
# Unit test for method get_name of class Play
def test_Play_get_name():
    a = Play()
    assert a.get_name() == ''

    a.name = "test_name"
    assert a.get_name() == "test_name"

    a.name = None
    a.hosts = ['a','b','c','d','e']
    assert a.get_name() == 'a,b,c,d,e'


# Generated at 2022-06-21 00:45:43.302592
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.serialize()



# Generated at 2022-06-21 00:45:55.020764
# Unit test for method copy of class Play
def test_Play_copy():
    class MockVariableManager(object):
        def __init__(self):
            pass
        def hostvars(self, play):
            return {}

    class MockLoader(object):
        def get_basedir(self):
            return 'basedir'
        def load_from_file(p, d):
            return {}
        def get_collection_list(self):
            return []

    variable_manager = MockVariableManager()
    loader = MockLoader()
    test_play = Play.load({}, variable_manager, loader)
    test_play.tasks = [1]
    test_play.pre_tasks = [1]
    test_play.post_tasks = [1]
    test_play.handlers = [1]
    test_play.ROLE_CACHE = {1: 1}
    test

# Generated at 2022-06-21 00:46:05.842063
# Unit test for method copy of class Play
def test_Play_copy():
    playbook = Playbook()
    play = Play()
    play.tasks = get_data_files('./test/data/tasks/valid_tasks_mixed_with_invalid.yml')
    play.handlers = get_data_files('./test/data/handlers/valid_handlers.yml')
    play.pre_tasks = get_data_files('./test/data/tasks/valid_tasks_mixed_with_invalid.yml')
    play.post_tasks = get_data_files('./test/data/tasks/valid_tasks_mixed_with_invalid.yml')
    play.vars_prompt = get_data_files('./test/data/vars_prompt/valid_vars_prompt.yml')

# Generated at 2022-06-21 00:46:06.798879
# Unit test for method load of class Play
def test_Play_load():
    pass



# Generated at 2022-06-21 00:46:15.042634
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test for get_vars method
    # Test for Play.get_vars_files() method
    
    play = Play()
    play.vars_files = ['a']


# Generated at 2022-06-21 00:46:29.110552
# Unit test for method load of class Play
def test_Play_load():
    p = Play()
    p.load_data()

# Test for method get_name of class Play

# Generated at 2022-06-21 00:46:32.555706
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Arrange
    play = Play()
    # Act
    ret = play.compile_roles_handlers()
    # Assert
    assert ret == []

# Generated at 2022-06-21 00:46:38.819399
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Setup
    p = Play()
    p.roles = ['a', 'b']
    expected = ['a', 'b']
    # Exercise
    actual = p.get_roles()
    # Verify
    print(actual)
    assert expected == actual



# Generated at 2022-06-21 00:46:48.670109
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.vars = {
        'var2': 1,
        'var1': 2
    }
    p.hosts = "testhost"
    p.roles = [
        {
            'name': 'role1'
        },
        {
            'name': 'role2'
        }
    ]

# Generated at 2022-06-21 00:46:59.422461
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play._ds = dict(
        name="TEST",
        hosts=["all"],
        gather_facts="no",
        connection="network_cli",
        roles=["var_push", "snmp_output"]
    )
    play.vars = dict(
        ansible_ssh_client="network_cli",
        ansible_connection="network_cli",
        ansible_network_os="ios",
        ansible_user="evacom",
        ansible_password="evacom",
        ansible_become_password="evacom",
        ansible_become="yes",
    )
    play._variable_manager = VariableManager()
    play._loader = DataLoader()
    play.post_validate(play._ds, play._variable_manager)

    assert True == play

# Generated at 2022-06-21 00:46:59.897510
# Unit test for method compile of class Play
def test_Play_compile():
    pass

# Generated at 2022-06-21 00:47:12.146080
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    inventory = Inventory(loader=None, variable_manager=None, host_list='tests/inventory/hosts')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()
    play = Play.load(dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        vars=dict(
            a='hello',
            b='world'
        ),
    ), variable_manager=variable_manager, loader=loader)
    assert len(play.get_vars()) == 2
    assert play.get_vars()['a'] == 'hello'
    assert play.get_vars()['b'] == 'world'



# Generated at 2022-06-21 00:47:22.047578
# Unit test for method copy of class Play

# Generated at 2022-06-21 00:47:23.526148
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-21 00:47:25.541513
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert isinstance(play, Play)

# Generated at 2022-06-21 00:47:46.583289
# Unit test for method deserialize of class Play

# Generated at 2022-06-21 00:47:53.077995
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p_copy = p.copy()
    assert type(p) == type(p_copy)
    assert p_copy.ROLE_CACHE == p.ROLE_CACHE
    assert p_copy._included_conditional == p._included_conditional
    assert p_copy._included_path == p._included_path
    assert p_copy._action_groups == p._action_groups
    assert p_copy._group_actions == p._group_actions


# Generated at 2022-06-21 00:47:55.914170
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert p.__repr__() == p.get_name()



# Generated at 2022-06-21 00:47:57.110506
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p1 = Play()
    roles = p1.get_roles()
    assert len(roles) == 0

# Generated at 2022-06-21 00:48:02.621119
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert p.get_vars_files() == []

    p.vars_files = ''
    assert p.get_vars_files() == ['']

    p.vars_files = ['test1', 'test2']
    assert p.get_vars_files() == ['test1', 'test2']



# Generated at 2022-06-21 00:48:11.157977
# Unit test for method copy of class Play
def test_Play_copy():
    # Run the method
    try:
        r = Play.copy()
    # Check for None
    except:
        assert False, "The Play.copy method is not returning the expected result."
    # Check for the correct data type
    if not isinstance(r, type(None)):
        assert False, "The Play.copy method is not returning the expected result."
    # Check for the correct result
    if r is not None:
        assert False, "The Play.copy method is not returning the expected result."

# Generated at 2022-06-21 00:48:21.466968
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = '/path/to/file'
    assert p.get_vars_files() == ['/path/to/file']
    p.vars_files = ['/path/to/file1', '/path/to/file2']
    assert p.get_vars_files() == ['/path/to/file1', '/path/to/file2']


# Generated at 2022-06-21 00:48:26.636344
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = super(Play, play).__init__()
    play = Play()
    play.get_handlers()
    print(play.get_handlers())
    return True

# Generated at 2022-06-21 00:48:35.770632
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # This test runs a static test (no dynamic data).
    # Therefore we are ignoring it in the coverage report.
    tasks = []
    tasks.append({"test_task":{"test_key":"test_value"}})
    tasks.append({"test_task":{"test_key":"test_value"}})

    data = {"name":"test_name", "hosts":"test_hosts", "tasks":tasks}

    play = Play()
    play.load_data(data)
    assert play.get_tasks() == [{'test_task': {'test_key': 'test_value'}}, {'test_task': {'test_key': 'test_value'}}]


# Generated at 2022-06-21 00:48:41.323882
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    """
    Test for `get_vars` method of class `Play`

        - Runs when no vars are set
        - Runs when only default vars are set
        - Runs when vars are set

    """

    # Runs when no vars are set
    p1 = Play()
    assert p1.get_vars() == {}

    # Runs when only default vars are set
    p2 = Play()
    p2.vars = {}
    assert p2.get_vars() == {}

    # Runs when vars are set
    p3 = Play()
    p3.vars = 'test'
    assert p3.get_vars() == 'test'

# Generated at 2022-06-21 00:49:07.448856
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = [{}, {}, {}, {}, {}]
    assert p.get_handlers()[0] is p.handlers[0]
    assert p.get_handlers()[2] is p.handlers[2]
    assert p.get_handlers()[4] is p.handlers[4]
    assert p.get_handlers()[1] is p.handlers[1]

    p.handlers = [{}, {}, {}, {}, {}]
    assert p.get_handlers()[0] is p.handlers[0]
    assert p.get_handlers()[2] is p.handlers[2]
    assert p.get_handlers()[4] is p.handlers[4]

# Generated at 2022-06-21 00:49:09.081153
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []

# Generated at 2022-06-21 00:49:17.104545
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name == ''
    assert p.hosts == ''
    assert p.connection == 'smart'
    assert p.port == 0
    assert p.remote_user == ''
    assert p.roles == []
    assert p.tags == frozenset([])
    assert p.get_roles() == []
    assert p.get_vars() == {}
    assert p.get_vars_files() == []

# Generated at 2022-06-21 00:49:27.861018
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    for data in [
        dict(
            action_groups = dict(
                install = dict(
                    install = dict(
                        install = dict(
                            install = "install_what"
                        )
                    )
                )
            )
        ),
        dict(
            action_groups = dict(
                install = [
                    dict(
                        install = dict(
                            install = dict(
                                install = "install_what"
                            )
                        )
                    )
                ]
            )
        ),
    ]:
        for x in Play(data).compile_roles_handlers():
            y = x[0]
            for z in y:
                print("y: ", y)

    pass

# Generated at 2022-06-21 00:49:31.154273
# Unit test for method compile of class Play
def test_Play_compile():
    # Setup test env
    play = Play()
    play._load_roles = MagicMock()

    # test
    play.compile()

    # Assert
    assert play._load_roles.call_count == 1



# Generated at 2022-06-21 00:49:37.549952
# Unit test for method load of class Play
def test_Play_load():
    # Arguments for unit test
    data = {}
    variable_manager = {}
    loader = {}
    vars = {}

    # Play.load()
    Play.load(data=data, variable_manager=variable_manager, loader=loader, vars=vars)


# Generated at 2022-06-21 00:49:43.329653
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    '''
    Unit test for method deserialize of class Play

    '''

    print('')
    print('Test for method deserialize of class Play:')
    print('TODO')
    print('')
    print('we need a good way to populate a test data structure')


# unit test for method copy of class Play

# Generated at 2022-06-21 00:49:46.356793
# Unit test for constructor of class Play
def test_Play():
    p = Play().load(dict(
        name="foobar",
        hosts="all",
        roles=[1,2]
    ))
    assert p.name == "foobar"
    assert p.hosts == "all"
    assert p.roles == [1,2]


# Generated at 2022-06-21 00:49:49.547810
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p._ds = {'hosts': 'host1:host2'}

    assert p.__repr__() == 'host1:host2'
    assert repr(p) == 'host1:host2'

# Generated at 2022-06-21 00:50:01.123085
# Unit test for method serialize of class Play
def test_Play_serialize():
    variable_manager = VariableManager()
    loader = DataLoader()
    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='setup', args=dict()), register='shell_out'),
               dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))]
    )
    play = Play.load(data=play_ds, variable_manager=variable_manager, loader=loader)
    serialized_play = play.serialize()
    assert serialized_play.get('name') == play_ds['name']


# Generated at 2022-06-21 00:50:24.011954
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class FakePlay(Play):
        
        _pre_tasks = FieldAttribute(isa='list', default=list)
        _tasks = FieldAttribute(isa='list', default=list)
        _post_tasks = FieldAttribute(isa='list', default=list)

        
        def __init__(self):
            self._pre_tasks = []
            self._tasks = []
            self._post_tasks = []


    play = FakePlay()
    tasks = play.get_tasks()
    assert tasks == []

    task = Mock()
    task.serialize.return_value = 'test'

    play._pre_tasks = [task]
    play._tasks = [task]
    play._post_tasks = [task]

    tasks = play.get_tasks()

# Generated at 2022-06-21 00:50:31.233628
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.set_loader(DictDataLoader({}))
    play._ds = dict(
        name='test_Play___repr__',
        hosts='localhost',
    )

    assert play.__repr__() == 'test_Play___repr__'

# Generated at 2022-06-21 00:50:32.815744
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    pass


# Generated at 2022-06-21 00:50:45.696266
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Verify behavior of preprocess_data
    # when invoked with a non-dict argument
    play = Play()
    non_dict_test_value = list()
    dummy_variable_manager = object()
    dummy_loader = object()
    try:
        play.load_data(non_dict_test_value, variable_manager=dummy_variable_manager, loader=dummy_loader)
    except Exception as exc:
        assert(isinstance(exc, AnsibleAssertionError))
    else:
        raise Exception("preprocess_data() method did not raise expected exception when "
                        "invoked with a non-dict argument.")
        
    # Verify behavior of preprocess_data
    # when 'user' key is present
    data = dict()
    data['user'] = 'jdoe'

# Generated at 2022-06-21 00:50:51.283569
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert(p.get_vars_files() == [])
    #Test with a vars_files value
    p = Play()
    setattr(p, "vars_files", ["file1", "file2"])
    assert(p.get_vars_files() == ["file1", "file2"])
    #Test with a vars_file value
    p = Play()
    setattr(p, "vars_files", "file1")
    assert(p.get_vars_files() == ["file1"])


# Generated at 2022-06-21 00:50:53.998093
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert play.get_name() == play.__repr__()


# Generated at 2022-06-21 00:50:56.070245
# Unit test for method __repr__ of class Play
def test_Play___repr__():
  # arrange
  play = Play()

  # act

  # assert
  assert repr(play) == play.get_name()


# Generated at 2022-06-21 00:51:09.406683
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Create an empty playbook (no extra vars), then check that the function
    # get_vars_files returns a list containing an empty dict in it
    from collections import namedtuple
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.playbook import PlayBook
    from ansible.playbook_include.task import TaskInclude
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.playbook_executor import PlaybookExecutor

    fakesettings = namedtuple(
        'FakeSettings',
        'extra_vars'
    )
    FakeSettings = fakesettings(
        extra_vars={}
    )
    context._init_global_context(FakeSettings)

   

# Generated at 2022-06-21 00:51:17.492085
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from ansible.playbook import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block


    p = Play()
    p.handlers = [
        Handler.load({
            "name": "test1",
            "listen": "test",
            "tasks": [
                {"name": "a"}
            ]
        }, loader=None, play=p)
    ]

# Generated at 2022-06-21 00:51:25.466866
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class MockPlay(Play):
        pass
    
    play = MockPlay()
    play.pre_tasks = [1]
    play.tasks = [2,3]
    play.post_tasks = [4,5]
    result = play.get_tasks()
    assert result == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 00:52:16.758454
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p = Play()
    p.name = None
    p.hosts = 'all'
    assert p.get_name() == 'all'
    p = Play()
    p.name = None
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-21 00:52:17.654026
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-21 00:52:30.029779
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Arrange
    role_1_name = "test_role_1"
    role_2_name = "test_role_2"
    play = Play()

    handler_1 = Task()
    handler_1.name = "test_handler_1"
    handler_2 = Task()
    handler_2.name = "test_handler_2"

    role_1 = Role()
    role_1.name = role_1_name
    role_2 = Role()
    role_2.name = role_2_name

    role_1.handlers = [handler_1]
    role_2.handlers = [handler_2]

    play.roles = [role_1, role_2]

    # Act
    handlers = play.compile_roles_handlers()

    # Assert

# Generated at 2022-06-21 00:52:39.567588
# Unit test for method serialize of class Play
def test_Play_serialize():
    try:
        if context.CLIARGS['syntax'] is True:
            ansible.module_utils.basic.AnsibleExitJson(skipped=True)
    except KeyError:
        pass

    import copy
    import os
    import pathlib

    from units.mock.paths import Paths

    from ansible.module_utils import six
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.six import string_types

    p = Play()

# Generated at 2022-06-21 00:52:42.239820
# Unit test for method load of class Play
def test_Play_load():
    raise NotImplementedError(u'Test not implemented for method Play.load')
