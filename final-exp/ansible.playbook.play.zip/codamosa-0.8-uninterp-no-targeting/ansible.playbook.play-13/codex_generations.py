

# Generated at 2022-06-21 00:43:17.707396
# Unit test for method serialize of class Play
def test_Play_serialize():
  play = Play()
  play.vars = {u'var_3': u'helloword', u'var_2': u'helloword', u'var_1': u'helloword'}
  play.hosts = [u'host_1', u'host_2', u'host_2']
  play.name = u'helloword'
  play.roles = [Role(), Role()]

# Generated at 2022-06-21 00:43:26.662234
# Unit test for constructor of class Play
def test_Play():
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()

    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {'bam': 'baz'}

    p = Play().load({
        'name': 'test play',
        'hosts': 'slaves',
        'vars': {'a': '1', 'b': '2'}
    }, variable_manager=variable_manager, loader=DummyLoader())

    assert p.name == 'test play'
    assert p.hosts == 'slaves'
    assert combine_vars(p.get_vars(), variable_manager.get_vars()) == dict(a='1', b='2', foo='bar', bam='baz')

# Unit

# Generated at 2022-06-21 00:43:39.302956
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({'hosts': 'hosts', 'user': 'user', 'connection': 'connection', 'name': 'name', 'become': 'become', 'become_user': 'become_user', 'become_method': 'become_method', 'become_flags': 'become_flags', 'remote_user': 'remote_user', 'roles': ['role1', 'role2'], 'included_path': 'included_path', 'action_groups': 'action_groups', 'group_actions': 'group_actions'})
    assert p.hosts == 'hosts'
    assert p.connection == 'connection'
    assert p.name == 'name'
    assert p.become == 'become'
    assert p.become_user == 'become_user'

# Generated at 2022-06-21 00:43:50.243677
# Unit test for method deserialize of class Play

# Generated at 2022-06-21 00:43:51.680382
# Unit test for method get_name of class Play
def test_Play_get_name():
    name_test = Play()
    result = name_test.get_name()
    assert result == ''

# Generated at 2022-06-21 00:44:00.163701
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''
    Play: Play.get_name()
    Network Engineer's toolkit
    '''
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'localhost'
    assert p.get_name() == 'localhost'
    p.hosts = []
    assert p.get_name() == ''
    p.hosts = None
    assert p.get_name() == ''

# Generated at 2022-06-21 00:44:08.018323
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p.hosts = ["127.0.0.1"]
    p.pre_tasks = [{"include": "test.yml"}]
    p.roles = [{
        "name": "test role"
        }]
    p.post_tasks = [{"shell": "the command"}]
    p._included_conditional = True
    p._included_path = "test.yml"
    p._action_groups = {"test ag": []}
    p._group_actions = {"test": ["test ag"]}
    p.ROLE_CACHE = {"test role": {"name": "test role"}}
    p_copy = p.copy()
    assert p_copy._included_conditional == p._included_conditional
    assert p_copy._included

# Generated at 2022-06-21 00:44:10.607289
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    role = Role()
    play.roles.append(role)
    assert play.get_roles() == [role]



# Generated at 2022-06-21 00:44:14.305175
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    data = {
        'hosts': 'localhost',
        'vars_files': 'file.yml',
    }
    p = Play()
    p.load_data(data=data)
    assert p.get_vars_files() == ['file.yml']

# Generated at 2022-06-21 00:44:23.676515
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    """
    Test get_vars of class Play
    """
    # vars is initialized as {} in class Play
    # __init__ of Play is called before this test
    # test default value
    assert Play().get_vars() == {}

    # test get_vars
    a = Play()
    a.vars = {1:1, 2:2}
    assert a.get_vars() == {1:1, 2:2}


# Generated at 2022-06-21 00:44:36.950546
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # create an instance of the class and test it's repr attribute
    play = Play()
    assert repr(play) == play.get_name()


# Generated at 2022-06-21 00:44:47.650468
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    playbook_data = dict(
        name="Test Playbook",
        hosts="localhost",
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World!'))),
        ],
        user="root",
    )

    Play = Play()
    Play.preprocess_data(data=playbook_data)

    assert playbook_data.get('user') == None, 'Test Playbook user is not None'
    assert playbook_data.get('remote_user') == 'root', 'Test Playbook remote_user is not None'

# Generated at 2022-06-21 00:45:00.663077
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Build a new Play
    play1 = Play()
    # Test get_vars_files without initialization of the attribute vars_files
    assert play1.get_vars_files() == []
    # Build another Play
    play2 = Play()
    # Test get_vars_files after initialization of the attribute vars_files with a list of 2 elements
    play2.vars_files = ["vars_file1.yml","vars_file2.yml"]
    assert play2.get_vars_files() == play2.vars_files
    # Build another Play
    play3 = Play()
    # Test get_vars_files after initialization of the attribute vars_files with a string
    play3.vars_files = "vars_file.yml"
    assert play3.get_vars

# Generated at 2022-06-21 00:45:01.850826
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass

# Generated at 2022-06-21 00:45:05.469533
# Unit test for method serialize of class Play
def test_Play_serialize():
    a = Play()
    bb = a.serialize()
    b = Play()
    b.deserialize(bb)


# Generated at 2022-06-21 00:45:10.050742
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    vars_files_list = ["vars1", "vars2"]
    play.vars_files = vars_files_list
    assert play.get_vars_files() == vars_files_list
    play.vars_files = "vars"
    assert play.get_vars_files() == ["vars"]

# Generated at 2022-06-21 00:45:18.576083
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['file1']
    assert play.get_vars_files() == ['file1']
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'file1'
    assert play.get_vars_files() == ['file1']


# Generated at 2022-06-21 00:45:32.185706
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    block_one = Block(
        task_include=TaskInclude(),
        tasks=[Task()],
        rescue=[Task()],
        always=[Task()]
    )
    block_two = Block(
        task_include=TaskInclude(),
        tasks=[Task()],
        rescue=[Task()],
        always=[Task()]
    )

    play = Play(
        pre_tasks=[Task()],
        tasks=[block_one],
        post_tasks=[Task()]
    )
    play.post_validate(play._ds, play)

    assert len(play.get_tasks())

# Generated at 2022-06-21 00:45:36.737623
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name is None
    assert p.hosts is None
    assert p.remote_user is None
    assert p.connection is None
    assert p.port is None
    assert p.gather_facts is None
    assert p.any_errors_fatal is False
    assert p.max_fail_percentage is None
    assert p.serial is None
    assert p.tags is None
    assert p.skip_tags is None
    assert p.check is False

# Generated at 2022-06-21 00:45:44.785478
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    from ansible.playbook.role.include import RoleInclude
    role1 = RoleInclude.load(dict(), play=None)
    role2 = RoleInclude.load(dict(), play=None)
    play = Play()
    play.roles.append(Role.load(role1, play))
    play.roles.append(Role.load(role2, play))
    roles = play.get_roles()
    print("roles=%s" % str(roles))
    assert len(roles) == 2
    assert roles[0] != roles[1]
    assert roles[0] == roles[0]
    assert not (roles[0] != roles[0])


# Generated at 2022-06-21 00:46:01.391396
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    _f = {
        'vars': {'aa': 'bb'},
        'roles': [{'name': '1', 'uuid': '2'}, {'name': '2', 'uuid': '2'}, ]
    }
    _p = Play
    _p.deserialize(_f)



# Generated at 2022-06-21 00:46:02.312343
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-21 00:46:05.691339
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    play.__init__()
    result = play.compile()
    assert isinstance(result, list)


# Generated at 2022-06-21 00:46:09.578844
# Unit test for method load of class Play
def test_Play_load():
    # Test with empty args
    v = Play.load()
    assert isinstance(v, Play), "Play.load() did not return an instance of Play"

    # Test with valid args
    v = Play.load(data={}, variable_manager=None, loader=None, vars={})
    assert isinstance(v, Play), "Play.load() did not return an instance of Play"

# Generated at 2022-06-21 00:46:18.704267
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    host_list = ["host1", "host2"]
    play_source =  dict(
                name = "Ansible Play",
                hosts = host_list,
                gather_facts = 'no',
                tasks = [
                    dict(action=dict(module="shell", args="ls"), register="shell_out"),
                    dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}"))),
                    dict(action=dict(module="command", args="yum update", warn=False))
                 ]
            )

    p = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    print("play_object: ", p)
    print("play_object role_cache: ", p.ROLE_CACHE)

# Generated at 2022-06-21 00:46:20.080294
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.compile()


# Generated at 2022-06-21 00:46:24.186470
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    assert play.get_vars() == {}

    play.vars = {'a': 'b'}
    assert play.get_vars() == {'a': 'b'}


# Generated at 2022-06-21 00:46:26.400041
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    assert type(p.get_vars()) == dict


# Generated at 2022-06-21 00:46:35.847381
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_cases = [
        {
            'name': 'simple play',
            'play': dict(hosts='host1'),
            'expected': 'host1'
        },
        {
            'name': 'play with multiple hosts',
            'play': dict(hosts=['host1', 'host2', 'host3']),
            'expected': 'host1,host2,host3'
        },
        {
            'name': 'play with no hosts',
            'play': dict(),
            'expected': ''
        }
    ]
    for test_case in test_cases:
        assert Play.load(test_case['play']).get_name() == test_case['expected']



# Generated at 2022-06-21 00:46:38.011093
# Unit test for method load of class Play
def test_Play_load():
    pass


# Generated at 2022-06-21 00:47:01.452726
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    p = Play()
    # test if the tasks was returned
    with pytest.raises(AnsibleError) as excinfo:
        p.get_tasks()
    assert 'Did not find any tasks' in to_native(excinfo.value)

    p = Play()
    t = Task()
    t.action = 'test'
    t.args = {'name': 'test_task'}
    p.tasks = [t]

    assert p.get_tasks() == [t]

# Generated at 2022-06-21 00:47:15.266525
# Unit test for constructor of class Play
def test_Play():
    p = Play()

    assert p.hosts is None
    assert p.name is None
    assert p.connection == 'smart'
    assert p.port is None
    assert p.remote_user is None
    assert p.timeout is 10
    assert p.remote_pass is None
    assert p.sudo is None
    assert p.sudo_user is None
    assert p.become is False
    assert p.become_method is None
    assert p.become_user is None
    assert p.become_pass is None
    assert p.tags == frozenset(['all'])
    assert p.skip_tags == frozenset()
    assert p.check is False
    assert p.gather_facts is 'smart'
    assert p.any_errors_fatal == False
    assert p.roles == []

# Generated at 2022-06-21 00:47:25.281283
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p.ROLE_CACHE = {'a':1}
    p._included_conditional = 'a'
    p._included_path = 'b'
    p._action_groups = {'c':1}
    p._group_actions = {'d':1}
    #Test
    p1 = p.copy()
    #Assert
    assert p1.ROLE_CACHE == {'a':1}
    assert p1._included_conditional == 'a'
    assert p1._included_path == 'b'
    assert p1._action_groups == {'c':1}
    assert p1._group_actions == {'d':1}

# Generated at 2022-06-21 00:47:31.749389
# Unit test for method compile of class Play
def test_Play_compile():
    from ansiblelint import RulesCollection
    from ansiblelint.runner import Runner

    rulesdir = 'lib/ansiblelint/rules'
    # set our rules directories
    rules = RulesCollection()
    rules.extend(os.path.realpath(os.path.join(os.getcwd(), rulesdir, path))
                 for path in os.listdir(rulesdir))

    # get rules matching a tag
    tag = 'action-instead-of-module'
    taggedRules = [rule for rule in rules if rule.id in tag]

    # run the rules with target Play
    path = 'test/integration/targets/plays/main_test_play.yml'
    runner = Runner(taggedRules, [path], [], [], [])
    runner.run()

# Generated at 2022-06-21 00:47:41.187723
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    data_set = Play()
    data_set.handlers[:] = [
        {
            'name': 'fake_handler',
            'actions': [
                {'name': 'get_role_package_version', 'args': {'roles': ['fake_role'], 'variable': 'fake_version'}}
            ]
        }
    ]
    result = data_set.get_handlers()
    assert result == [
        {
            'name': 'fake_handler',
            'actions': [
                {'name': 'get_role_package_version', 'args': {'roles': ['fake_role'], 'variable': 'fake_version'}}
            ]
        }
    ]


# Generated at 2022-06-21 00:47:53.181043
# Unit test for method load of class Play
def test_Play_load():
    run_in_console = getattr(__main__, '__file__', sys.argv[0]) == sys.argv[0]
    #
    # Play.load
    #

# Generated at 2022-06-21 00:48:04.450014
# Unit test for method copy of class Play
def test_Play_copy():
    p=Play()
    p.hosts="hosts"
    p.name="name"
    p.gather_facts=True
    p.any_errors_fatal=True
    p.roles=[{}]
    p.force_handlers=True
    p.max_fail_percentage=15
    p.serial=['serial']
    p.strategy='strategy'
    p.order='order'
    p.tasks=[{}]
    p.handlers=[{}]
    p.pre_tasks=[{}]
    p.post_tasks=[{}]
    p.ROLE_CACHE={"test":{'test':'test'}}
    p._included_conditional={"test":"test"}
    p._included_path="included_path"

# Generated at 2022-06-21 00:48:09.368969
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    a = Play()
    value = a.get_roles()
    assert_equal(value, [], msg='Returned unexpected value from method get_roles of class Play')


# Generated at 2022-06-21 00:48:21.505779
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pl = Play()
    pl._ds = {'vars_files': [1, 2, 3]}
    assert pl.get_vars_files() == [1, 2, 3]
    pl._ds = {'vars_files': []}
    assert pl.get_vars_files() == []
    pl._ds = {'vars_files': None}
    assert pl.get_vars_files() == []
    pl._ds = {'vars_files': 1}
    assert pl.get_vars_files() == [1]
    pl._ds = {'vars_files': []}

# Generated at 2022-06-21 00:48:34.684916
# Unit test for method get_name of class Play
def test_Play_get_name():

    ############################################################################################
    #
    #   1.
    #   Test case: test field "hosts" with value "hosts=W01-cloud-infra-prod-db01.w01.wml.three.co.uk"
    #   Expected result:
    #   - get_name() should return "W01-cloud-infra-prod-db01.w01.wml.three.co.uk"
    #
    ############################################################################################

    # 1.

    play = Play()
    play.hosts = "W01-cloud-infra-prod-db01.w01.wml.three.co.uk"
    result = play.get_name()

# Generated at 2022-06-21 00:48:55.585267
# Unit test for method copy of class Play
def test_Play_copy():
    new_me = Play()._copy()
    assert new_me is not None

# Generated at 2022-06-21 00:49:06.631275
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    t = Play()
    assert t.get_tasks() == []
    t = Play()
    t.tasks = [fake_loader.get_plugin_loader('action').get('ping'),fake_loader.get_plugin_loader('action').get('ping') ]
    assert t.get_tasks() == [fake_loader.get_plugin_loader('action').get('ping'),fake_loader.get_plugin_loader('action').get('ping')]
    t = Play()
    t.handlers = [fake_loader.get_plugin_loader('action').get('ping'),fake_loader.get_plugin_loader('action').get('ping') ]
    assert t.get_tasks() == []
    t = Play()

# Generated at 2022-06-21 00:49:13.056720
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = {'name': 'testplay', 'hosts': ['testhost'], 'tasks': []}
    play = Play.load(data)
    actual = play.serialize()
    expected = {'name': 'testplay', 'hosts': ['testhost'], 'tasks': [], 'roles': []}
    assert actual == expected, 'serialized structure does not match'



# Generated at 2022-06-21 00:49:25.569799
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Create the object, passing in params and their types
    import unittest
    import os
    import sys
    import tempfile
    import yaml
    from io import StringIO
    import shutil
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    import ansible.constants as C
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    import ansible.playbook.play_context as pc
    import ansible.playbook.task_include as task_include
    import ansible.playbook.block as block
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.template import Templar

# Generated at 2022-06-21 00:49:29.442094
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.name = 'myplay'
    assert repr(p) == 'myplay'
    p = Play()
    p.hosts = ['host1', 'host2']
    assert repr(p) == 'host1,host2'


# Generated at 2022-06-21 00:49:36.823536
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.post_tasks = []
    p.pre_tasks = []
    p.tasks = []
    assert p.get_tasks() == []
    assert isinstance(p.get_tasks(), list)

    b = Block()
    b.block = [None]
    b.always = [None]
    b.rescue = [None]
    p = Play()
    p.post_tasks = []
    p.pre_tasks = []
    p.tasks = [b]
    assert p.get_tasks() == [[None, None, None]]
    assert isinstance(p.get_tasks(), list)

    b1 = Block()
    b1.block = [None]
    b1.always = [None]

# Generated at 2022-06-21 00:49:47.219763
# Unit test for method compile of class Play
def test_Play_compile():
    # This test verifies that the compile method of class Play works properly
    import pytest

    Play_test_input = dict(
        name='test_Play_compile',
        hosts='h1',
        roles=list(),
        tasks=list(),
        handlers=list(),
        pre_tasks=list(),
        post_tasks=list()
    )

    test_Play = Play()
    test_Play.load_data(Play_test_input, loader=DictDataLoader())

    # Verify that the compile method of class Play returns an empty list when the play has no tasks and no roles
    assert test_Play.compile() == list()

    # Verify that the compile method of class Play returns the list of tasks in the play when the play has tasks but no roles

# Generated at 2022-06-21 00:49:52.845183
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # get_handlers() returns a copy of handlers attribute
    # Create play object with handlers
    handlers = ['handler1', 'handler2']
    play = Play()
    play.handlers = handlers
    # get_handlers() returns a copy of handlers attribute
    assert play.get_handlers() == handlers
    assert play.get_handlers() is not handlers


# Generated at 2022-06-21 00:50:04.454889
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Variables
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory.py')

    ds = dict(
        name='fake play',
        hosts=['fake_group'],
        gather_facts='no',
        pre_tasks=dict(
            name='fake task'
        ),
        roles=[]
    )

    play = Play.load(ds, variable_manager=variable_manager, loader=loader)
    play.post_validate(inventory)
    play.compile()

    # Expected value
    expected_value = []

    # Actual value
    actual_value = play.get_handlers()

    # Assertion
    assert actual_value == expected_value

# Unit test

# Generated at 2022-06-21 00:50:13.705581
# Unit test for method serialize of class Play
def test_Play_serialize():
    print('''TEST: Play.serialize''')
    play = Play()
    source = {'roles': [{'file_name': 'test', 'vars': {'test_var': 'test_value'}}]}
    play.deserialize(source)
    data = play.serialize()
    roles = data.get('roles', [])
    assert roles[0].get('vars').get('test_var') == 'test_value'
    assert roles[0].get('file_name') == 'test'


# Generated at 2022-06-21 00:50:45.103568
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_dict = dict(
        name="Play",
        hosts="host1",
        remote_user="user",
        become=False,
        become_method="sudo",
        become_user="su",
        gather_facts="no",
        vars_prompt=list(
            dict(
                name="host",
                prompt="host",
                default="host"
            )
        ),
        vars_files=list(
            "file1",
            "file2"
        )
    )
    play = Play.load(play_dict)
    result = play.preprocess_data(play._ds)


# Generated at 2022-06-21 00:50:45.672875
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    pass

# Generated at 2022-06-21 00:50:53.602338
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    data = {
        'tasks': [],
        'roles': None,
        'role_search_path': None
    }
    play.deserialize(data)
    assert play.roles is None
    assert play.role_search_path is None
    assert play.tasks == []



# Generated at 2022-06-21 00:50:54.233999
# Unit test for constructor of class Play
def test_Play():
    pass



# Generated at 2022-06-21 00:51:01.819428
# Unit test for method deserialize of class Play

# Generated at 2022-06-21 00:51:07.853658
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    dict = __main__.dict
    dict['user'] = 'myuser'
    dict2 = {'user' : 'myuser'}
    try:
        p = Play()
        assert p.preprocess_data(dict) == dict2
    except AttributeError as e:
        assert False, 'Play.preprocess_data method failed'

# Generated at 2022-06-21 00:51:19.599850
# Unit test for method load of class Play
def test_Play_load():
    # Define variables used in test_Play_load func
    hosts = 'node1'
    options = '-c local -m shell -a "ls"'
    roles = 'Compile'

    # create a var for the test method
    play_obj = Play()

    # create a var for the test method
    hosts_var = play_obj._validate_hosts(hosts, 0, hosts)

    # create a var for the test method
    options_var = play_obj._validate_options(options, 0, options)

    # create a var for the test method
    roles_var = play_obj._validate_roles(roles, 0, roles)

    # Compare the values
    assert hosts_var == hosts_var
    assert options_var == options_var
    assert roles_var == roles_var


#

# Generated at 2022-06-21 00:51:29.119536
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    data = {'name': 'test_name_string', 'hosts': 'test_hosts_string', 'vars': {}, 'tasks': [{'name': 'test_task_name_string'}], 'handlers': [{'name': 'test_handlers_name_string'}]}
    test_object = Play.load(data, variable_manager=None, loader=None)
    test_handlers = test_object.get_handlers()
    assert test_handlers[0]['name'] == 'test_handlers_name_string'


# Generated at 2022-06-21 00:51:32.099239
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Testing method get_handlers of class Play
    # Unit test for method get_handlers of class Play
    pass


# Generated at 2022-06-21 00:51:41.250218
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    '''
    使用 pytest 测试，可以进行单元测试, 会导致vim 报错 。。。
    :return:
    '''
    # "id": 30,
    #   "type": "play",
    #   "name": "default",
    #   "tags": [
    #     "all"
    #   ],
    #   "hosts": null,
    #   "roles": [],
    #   "vars": {},
    #   "role_include": [],
    #   "play_include": null
    # },
    play = Play()
    play.vars = {'test_var':'test_var_value'}

# Generated at 2022-06-21 00:52:05.101196
# Unit test for method load of class Play
def test_Play_load():
    # Setup vars
    data = ""

    # Invoke method
    results = Play.load(data)
    # Check results
    assert results is not None

# Generated at 2022-06-21 00:52:15.225068
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    play = Play()
    play.pre_tasks = [Block.load(data={'meta': 'flush_handlers'},play=play, variable_manager=play._variable_manager, loader=play._loader)]
    play.tasks = [Task.load(data={'name': 'test'},play=play, variable_manager=play._variable_manager, loader=play._loader)]
    play.post_tasks = [Block.load(data={'meta': 'flush_handlers'},play=play, variable_manager=play._variable_manager, loader=play._loader)]

# Generated at 2022-06-21 00:52:19.841881
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    testvar = Play()
    data = {'data': { }, 'groups': { }, 'included_path': None, 'action_groups': { }, 'group_actions': { }}
    assert testvar.deserialize(data)

# Generated at 2022-06-21 00:52:30.871592
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    play.hosts = "hosts"
    play.connection = "connection"
    play.vars = {"a": 2}
    play.vars_prompt = []
    play.vars_files = ['/etc/ansible/host_vars/hostname']
    play.roles = []
    play.pre_tasks = []
    play.post_tasks = []
    play.tasks = []
    play.handlers = []
    play.registered_variables = {"b": 1}
    play.block = []
    play.strategy = "strategy"
    play.serial = "serial"
    play.max_fail_percentage = "max_fail_percentage"
    play.sudo = "sudo"
    play.sudo_user = "sudo_user"


# Generated at 2022-06-21 00:52:39.784753
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansiblelint.rules.NoHostKeyCheckingRule import NoHostKeyCheckingRule
    from ansiblelint.rules.BecomeUserEqualsUserRule import BecomeUserEqualsUserRule
    from ansiblelint.rules.BecomeUserEqualsRootRule import BecomeUserEqualsRootRule
    from ansiblelint.rules.BecomeUserNotSpecifiedRule import BecomeUserNotSpecifiedRule
    from ansiblelint.rules.BecomeUserEqualsRootOrGid0 import BecomeUserEqualsRootOrGid0
    from ansiblelint.rules.RunAsRootWithoutBecomeRule import RunAsRootWithoutBecomeRule
    from ansiblelint.rules.BecomeUserNoPasswordRule import BecomeUserNoPasswordRule
    from ansiblelint.rules.BecomeUserFalseRule import BecomeUserFalseRule