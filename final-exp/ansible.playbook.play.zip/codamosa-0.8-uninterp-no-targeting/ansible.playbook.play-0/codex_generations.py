

# Generated at 2022-06-21 00:43:09.318544
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Create an inventory with just one host
    hosts = ["new_host_for_serialize"]
    groups = []
    inventory = ansible.inventory.Inventory(hosts, groups)

    # Create a Play with a task
    play = Play()
    play.name = "Serialize Test Play"
    play.hosts = hosts
    # Create a task and add it to the play
    new_task = Task()
    new_task.action = "shell"
    new_task.args["_raw_params"] = "echo 'hello world' > /tmp/serialize_test"
    play.tasks = [new_task]

    # Create a Playbook
    playbook = Playbook()
    playbook.inventory = inventory
    playbook.plays = [play]

    # Save the data in a valid yaml file

# Generated at 2022-06-21 00:43:20.034840
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    p = Play()
    p.name = 'test_Play_get_tasks'

# Generated at 2022-06-21 00:43:22.145009
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # TODO: Implement this test
    pass

# Generated at 2022-06-21 00:43:27.608568
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play({
        'hosts': 'all',
        'roles': [
            'role1',
            'role2'
        ]
    })
    role1 = Role({'name': 'role1'})
    role2 = Role({'name': 'role2'})
    assert play.get_roles() == [role1, role2]



# Generated at 2022-06-21 00:43:34.046602
# Unit test for method load of class Play
def test_Play_load():
    # Test with a simple dict
    data = {
        'name': 'test_Play_load',
    }
    play = Play.load(data, variable_manager=None, loader=None, vars=None)
    assert play.name == 'test_Play_load'


# Generated at 2022-06-21 00:43:41.414084
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # given
    p = Play()
    p.handlers = ['test', 'test2']

    # when
    r = p.get_handlers()

    # then
    assert r is not None
    assert r is not p.handlers
    assert p.handlers == ['test', 'test2']
    assert r == ['test', 'test2']


# Generated at 2022-06-21 00:43:51.713081
# Unit test for method deserialize of class Play

# Generated at 2022-06-21 00:43:56.260813
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [{"foo":"bar"}]
    p.tasks = [{"foo":"bar"}]
    p.post_tasks = [{"foo":"bar"}]
    assert set(p.get_tasks()) == set([{"foo":"bar"},{"foo":"bar"},{"foo":"bar"}])
    p.post_tasks = [{"foo":"baz"}]
    assert set(p.get_tasks()) == set([{"foo":"bar"},{"foo":"bar"},{"foo":"baz"}])

# Generated at 2022-06-21 00:44:03.277892
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = """
    - hosts: 127.0.0.1
      connection: local
      tasks:
      - ping:
    """
    play = Play.load(data, variable_manager=VariableManager(), loader=None)
    serialized_data = play.serialize()
    assert 'roles' in serialized_data
    assert 'action_groups' in serialized_data
    assert 'group_actions' in serialized_data
    assert 'included_path' in serialized_data



# Generated at 2022-06-21 00:44:04.872445
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() == ""


# Generated at 2022-06-21 00:44:30.472606
# Unit test for method load of class Play
def test_Play_load():
    print('Testing method load of class Play')
    #self, data, variable_manager=None, loader=None, vars=None):
    local_loader = DataLoader()
    p1 = Play()
    p2 = Play()
    p3 = Play()
    p4 = Play()
    p5 = Play()
    p6 = Play()
    p7 = Play()
    p8 = Play()
    p9 = Play()
    p10 = Play()
    p11 = Play()
    p12 = Play()
    p13 = Play()
    p14 = Play()

    assert p1.load(data = 'tasks:', loader = local_loader) == p2.load(data = 'tasks:', loader = local_loader)

# Generated at 2022-06-21 00:44:35.605735
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test cases to make sure the method correctly returns the 
    # name of the play.
    def test_get_name_valid_positive(self):
        self.name = "Test Play"
        assertEqual(self.get_name(), "Test Play")
        
    def test_get_name_valid_negative(self):
        self.name = "Test Play"
        assertNotEqual(self.get_name(), "Test Play123")
        
    

# Generated at 2022-06-21 00:44:42.902900
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.conditional import Conditional
    from pprint import pprint
    results = []

    # Create the basic objects
    
    loader = DataLoader()
    variablemanager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variablemanager, host_list='')
    variablemanager.set_inventory(inventory)


    # Create the conditional object
    conditional = Conditional(loader=loader, variable_manager=variablemanager)

    # Create

# Generated at 2022-06-21 00:44:48.964913
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    task = Task()
    task.name = "test1"
    task2 = Task()
    task2.name = "test2"
    tasks = []
    tasks.append(task)
    tasks.append(task2)
    play = Play()
    play.tasks = tasks 
    actual = play.get_tasks()
    expected = tasks
    assert actual == expected

# Generated at 2022-06-21 00:44:50.067370
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-21 00:44:54.833429
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_obj = Play()
    play_obj.hosts = "test_host"
    play_obj.name = None
    play_obj.get_name() == "test_host"


# Generated at 2022-06-21 00:45:04.089691
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.vars = {}
    # Condition: vars is a dict
    # Assertion: AssertionError is not raised
    play.vars = {}
    # Condition: vars is not a dict
    # Assertion: AssertionError is raised
    play.vars = None
    # Condition: vars is not a dict
    # Assertion: AssertionError is raised
    play.vars = []
    # Condition: vars is not a dict
    # Assertion: AssertionError is raised
    play.vars = ''
    # Condition: vars is not a dict
    # Assertion: AssertionError is raised
    play.vars = 0
    # Condition: vars is not a dict
    # Assertion: AssertionError is raised
   

# Generated at 2022-06-21 00:45:12.447934
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_files = ["/etc/ansible/vars_files/vars_main.yml", "/etc/ansible/vars_files/vars_mysql.yml", "/etc/ansible/vars_files/vars_apache.yml"]
    vars_files2 = "/etc/ansible/vars_files/vars_main.yml"

    play1 = Play()
    play2 = Play()
    play3 = Play()

    play1.vars_files = vars_files
    play2.vars_files = vars_files2
    play3.vars_files = None

    print("Test 1: ", play1.get_vars_files() == vars_files)

# Generated at 2022-06-21 00:45:12.880566
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass

# Generated at 2022-06-21 00:45:13.989930
# Unit test for method compile of class Play
def test_Play_compile():
    raise NotImplementedError('test_Play_compile not implemented')

# Generated at 2022-06-21 00:45:29.373088
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Note: most of the test is in the field 'tasks'
    pass


# Generated at 2022-06-21 00:45:33.625807
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    print(p.get_roles())
    assert p.get_roles() == []



# Generated at 2022-06-21 00:45:41.327432
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {"a" : {"b" : 1}}
    res = p.get_vars()
    assert res == {"a" : {"b" : 1}}
    p.vars = {"a" : {"b": 1, "c":1}}
    res = p.get_vars()
    assert res == {"a" : {"b": 1, "c":1}}


# Generated at 2022-06-21 00:45:53.819821
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [[
        {'action': {'__ansible_module__': 'setup', 'module': 'setup'}},
        {'action': {'__ansible_module__': 'command', 'module': 'command', 'args': 'echo 1'}},
        {'action': {'__ansible_module__': 'shell', 'module': 'shell', 'args': 'echo 1'}},
    ]]
    p.handlers = [[{'action': {'__ansible_module__': 'service', 'module': 'service', 'name': 'sshd', 'state': 'restarted'}}]]
    p.post_tasks = [[{'action': {'__ansible_module__': 'debug', 'module': 'debug', 'msg': 'Play completed'}}]]

    tasks

# Generated at 2022-06-21 00:45:56.581861
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    assert isinstance(p.get_vars(), dict)


# Generated at 2022-06-21 00:46:06.701822
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):

        def v2_runner_on_ok(self, result, **kwargs):
            print("%s" % result)

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources="localhost")
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:46:17.617733
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # [{"name": "vars_files", "is_sequence": false}]
    play = Play()
    play.vars_files = "./playbooks/vars.yml"
    assert play.get_vars_files() == ["./playbooks/vars.yml"]
    play.vars_files = "./playbooks/vars.yml"
    assert play.get_vars_files() == ["./playbooks/vars.yml"]
    play.vars_files = ["host_vars/hostname1.yml", "host_vars/hostname2.yml"]
    assert play.get_vars_files() == ["host_vars/hostname1.yml", "host_vars/hostname2.yml"]


# Generated at 2022-06-21 00:46:27.537947
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    playbook_data = {
        'roles': [{'name': 'fake-role-name'}],
        'hosts': 'all',
    }
    p = Play.load(data=playbook_data, variable_manager=None, loader=None)
    p._load_roles(None, p.roles)
    assert p._compile_roles() == []
    assert p.compile_roles_handlers() == []
    assert p.handlers == []
    rep_p = p.copy()
    assert rep_p.roles == p.roles
    assert p.get_vars() == {}
    assert p.get_tasks() == []

# Generated at 2022-06-21 00:46:33.980837
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Create a Play object.
    p = Play()
    
    # Get roles of the play.
    roles = p.get_roles()
    
    # Test.
    assert(type(roles) == list) #Returns list of role objects.
    assert(type(roles[0]) == Role) #The list contains role objects.
    assert(len(roles) > 0) #The list contains some roles.

# Generated at 2022-06-21 00:46:46.706169
# Unit test for method copy of class Play
def test_Play_copy():
    test_string = "hi"
    test_dict = {"hi":"hello"}
    test_list = [1,2,3]
    test_bool = True
    test_int = 8
    test_sequence = (1,2,3)
    from copy import copy
    from copy import deepcopy
    from collections import Sequence
    from collections import MutableSequence
    from collections import Mapping
    from collections import MutableMapping
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 00:47:02.870720
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    '''
    Tests for method get_handlers of class Play
    '''
    pass

# Generated at 2022-06-21 00:47:16.146776
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.hosts = 'hosts'
    p.vars = {'var': 'value'}
    p.vars_prompt = [{'name': 'var_prompt'}]
    p.vars_files = ['vars_files']
    p.name = 'name'
    p.remote_user = 'user'
    p.connection = 'connection'
    p.gather_facts = 'facts'
    p.serial = 'serial'
    p.tags = 'tags'
    p.skip_tags = 'skip_tags'
    p.included_path = 'included_path'
    p.action_groups = {'action_groups': 'val'}
    p.group_actions = {'group_actions': 'val'}

# Generated at 2022-06-21 00:47:25.584560
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''
    Play: get_name method
    '''
    mock_play = Mock(spec=Play)

    # Test 1
    # Setup test
    mock_play.name = 'test_name'
    # Test
    result = mock_play.get_name()
    # Validate test
    assert result == 'test_name'

    # Test 2
    # Setup test
    mock_play.name = None
    mock_play.hosts = ['test']
    # Test
    result = mock_play.get_name()
    # Validate test
    assert result == ','.join(mock_play.hosts)

    # Test 3
    # Setup test
    mock_play.name = None
    mock_play.hosts = None
    # Test
    result = mock_play.get_name()


# Generated at 2022-06-21 00:47:29.001285
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = dict(a=1, b=2)
    assert play.get_vars() == dict(a=1, b=2)



# Generated at 2022-06-21 00:47:32.143466
# Unit test for method load of class Play
def test_Play_load():
    # TODO: implement unit tests for Play.load
    pass


# Generated at 2022-06-21 00:47:33.600598
# Unit test for method load of class Play
def test_Play_load():
    pass


# Generated at 2022-06-21 00:47:42.165945
# Unit test for method load of class Play
def test_Play_load():
    """
    This tests the loading of the Play class
    """
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    pl = Play()
    assert isinstance(pl, AnsibleBaseYAMLObject)
    assert isinstance(pl, Play)
    pl = Play.load(None)
    assert isinstance(pl, AnsibleBaseYAMLObject)
    assert isinstance(pl, Play)
    pl = Play.load({})
    assert isinstance(pl, AnsibleBaseYAMLObject)
    assert isinstance(pl, Play)
    pl = Play.load({'hosts': 'testhosts'})
    assert isinstance(pl, AnsibleBaseYAMLObject)
    assert isinstance(pl, Play)

# Generated at 2022-06-21 00:47:45.202985
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert_equal(play.__repr__(), play.get_name())


# Generated at 2022-06-21 00:47:54.592931
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible import constants, errors
    from ansible.collections import defaultdict
    from ansible.executor.playbook_iterator import PlaybookIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.plugins import filter_loader, lookup_loader, module_loader, test
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    from ansible_collections.my.my_test_collection.plugins.module_utils import my_module

# Generated at 2022-06-21 00:47:57.169715
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play=Play()
    assert play.__repr__()==play.get_name()


# Generated at 2022-06-21 00:48:17.436829
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {'a':1, 'b':2}
    ret = play.get_vars()
    assert ret['a'] == 1
    assert ret['b'] == 2


# Generated at 2022-06-21 00:48:20.413658
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    assert not Play().__repr__()
    assert Play().__repr__() == Play().get_name()



# Generated at 2022-06-21 00:48:24.752841
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    args = {}
    p = Play()
    p._load_data(args)
    assert p.__repr__() == p.get_name()

# Generated at 2022-06-21 00:48:26.943529
# Unit test for method load of class Play
def test_Play_load():
    """
    Unit test of method load of class Play
    """
    pass

# Generated at 2022-06-21 00:48:30.027034
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = []
    assert p.get_handlers() == []


# Generated at 2022-06-21 00:48:38.051919
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()

    p.pre_tasks = [
        {'name': 't2.1'},
        {'name': 't2.2'},
        {'name': 't2.3'},
    ]
    p.tasks = [
        {'name': 't1.1'},
        {'name': 't1.2'},
        {'name': 't1.3'},
    ]
    p.post_tasks = [
        {'name': 't3.1'},
        {'name': 't3.2'},
        {'name': 't3.3'},
    ]


# Generated at 2022-06-21 00:48:40.823101
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    attr = {}
    ret = Play().deserialize(attr)
    assert ret is None


# Generated at 2022-06-21 00:48:48.142410
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = []
    assert p.compile_roles_handlers() == []
    assert p.compile_roles_handlers() == []

    r1 = Role()
    r1.name = 'r1'
    r2 = Role()
    r2.name = 'r2'
    p.roles = [r1,r2]
    assert p.compile_roles_handlers() == []
    assert p.compile_roles_handlers() == []

    p.handlers = []
    assert p.compile_roles_handlers() == []
    assert p.compile_roles_handlers() == []

    handler1 = Handler()
    handler2 = Handler()
    p.handlers = [handler1, handler2]
    assert p

# Generated at 2022-06-21 00:48:48.665305
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    pass

# Generated at 2022-06-21 00:48:49.621499
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    assert True

# Generated at 2022-06-21 00:49:24.699873
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    ####################################
    #### Create empty instance of Play

    p = Play()


    ####################################
    #### Test cases for multiple values
    p.vars_files = '/path/to/file1'
    assert p.get_vars_files() == ['/path/to/file1']

    p.vars_files = ['/path/to/file1', '/path/to/file2']
    assert p.get_vars_files() == ['/path/to/file1', '/path/to/file2']


    ####################################
    #### Test cases for empty values
    
    # Test case "vars_files" is None
    p.vars_files = None
    assert p.get_vars_files() == []


    ####################################
    #### Test case for wrong type


# Generated at 2022-06-21 00:49:30.482767
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    #setup
    p = Play()
    p.vars = {}
    p.roles = [Mock(Role())]
    r = p.roles[0]
    r.get_handler_blocks.return_value = ['baz']
    assert p.compile_roles_handlers() == ['baz']
    #tests
    r.get_handler_blocks.assert_called_with(play=p)


# Generated at 2022-06-21 00:49:38.300761
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5]
    play.post_tasks = [6, 7, 8]
    expected_tasks = [1, 2, 3, 4, 5, 6, 7, 8]

    assert play.get_tasks() == expected_tasks


# Generated at 2022-06-21 00:49:45.207809
# Unit test for method serialize of class Play
def test_Play_serialize():
    test_Play_obj = Play()
    test_serialize_obj = test_Play_obj.serialize()
    print(test_serialize_obj)
    assert test_serialize_obj == {'post_tasks': [], 'pre_tasks': [], 'tasks': [], 'roles': [], 'hosts': 'all', 'action': 'meta', 'name': 'all', 'included_path': None, 'action_groups': {}, 'group_actions': {}}


# Generated at 2022-06-21 00:49:45.742598
# Unit test for method get_vars of class Play
def test_Play_get_vars():
  pass

# Generated at 2022-06-21 00:49:48.338958
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    name = play.get_name()
    assert name is None


# Generated at 2022-06-21 00:49:54.599014
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    assert play.get_roles() == []

    play = Play()
    play.roles = ['role1']
    assert play.get_roles() == ['role1']

    play = Play()
    play.roles = ['role1', 'role2']
    assert play.get_roles() == ['role1', 'role2']


# Generated at 2022-06-21 00:49:57.160028
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # TODO: remove this test code, included only to avoid triggering test-coverage error
    pass

# Generated at 2022-06-21 00:50:02.095132
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # It's an error to call a method that takes parameters when its called
    # Play.get_roles() should raise an error
    try:
        Play().get_roles()
    except TypeError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-21 00:50:09.568348
# Unit test for method copy of class Play
def test_Play_copy():
    test_data = {"name": "test_data_name", "hosts": "test_data_hosts"}
    dict_to_object(data=test_data, obj=Play())
    assert Play().copy().name == "test_data_name"
    assert Play().copy().hosts == "test_data_hosts"



# Generated at 2022-06-21 00:50:40.527282
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.utils.unsafe_proxy import wrap_var
    play = Play()
    data = {}

    try:
        play.deserialize(data)
    except:
        pass
    assert not hasattr(play, '_included_path')
    assert data == {}


# Generated at 2022-06-21 00:50:42.914398
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'somename'
    assert p.get_name() == 'somename'


# Generated at 2022-06-21 00:50:45.406337
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play1 = Play()
    play1.deserialize({'name': 'my_play', 'roles': [{}, {}]})
    assert play1.name == 'my_play'



# Generated at 2022-06-21 00:50:55.525254
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    global loader
    # Init variables
    if 'loader' not in globals():
        loader = DataLoader()
    play_vars_files = temp_play_vars_files
    # Get the method configuration
    get_vars_files_config = Play_get_vars_files_config()
    # Init class
    Play = Play()
    Play.init()
    # Execute method
    get_vars_files_config.execute(Play)
    # Check assertion
    assert(isinstance(Play.get_vars_files(), list))
    # Clean temporary variables
    del play_vars_files
# Configuration class for method get_vars_files of class Play

# Generated at 2022-06-21 00:51:03.607633
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() == ''
    assert p.name == ''

    p.name = 'foo'
    assert p.get_name() == 'foo'
    assert p.name == 'foo'
    assert p.get_name() == 'foo'
    assert p.name == 'foo'


# Generated at 2022-06-21 00:51:09.262645
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play1 = Play()
    assert not play1._handlers

    # test using sequence
    play1._handlers = [1]
    assert play1._handlers == [1]
    assert play1.get_handlers() == [1]

    # test using string
    play1._handlers = "1"
    assert play1._handlers == "1"
    assert play1.get_handlers() == "1"



# Generated at 2022-06-21 00:51:16.642123
# Unit test for method get_name of class Play
def test_Play_get_name():
    """
    Check if names are set correct
    >>> a = Play()
    >>> a.name = 'TEST'
    >>> a.get_name()
    'TEST'
    >>> b = Play()
    >>> b.get_name()
    ''
    >>> c = Play()
    >>> c.hosts='localhost'
    >>> c.get_name()
    'localhost'
    >>> d = Play()
    >>> d.hosts=['localhost']
    >>> d.get_name()
    'localhost'
    >>> e = Play()
    >>> e.hosts=['localhost', 'example.com']
    >>> e.get_name()
    'localhost,example.com'
    """

# Generated at 2022-06-21 00:51:19.243771
# Unit test for constructor of class Play
def test_Play():
    play_instance = Play()
    assert play_instance is not None

# Generated at 2022-06-21 00:51:21.942098
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    exit_msg = '''
[DEPRECATION WARNING]: The Play class deserialize method is deprecated.
This method will be removed in version 2.9.  Use 'load' method instead
'''
    play = Play()
    play.deserialize({'roles':[]})
    assert isinstance(play, Play)


# Generated at 2022-06-21 00:51:33.222260
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing import DataLoader
    from ansible.inventory.manager import InventoryManager


    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='tests/unit/inventory')


# Generated at 2022-06-21 00:52:04.362405
# Unit test for method compile of class Play

# Generated at 2022-06-21 00:52:15.042286
# Unit test for method copy of class Play
def test_Play_copy():
    class Test_cls_1():
        def __init__(self):
            pass
    t_obj_1 = Test_cls_1()
    t_dict_2 = {u'bar': 1, u'foo': u'Foo', u'baz': u'qux'}
    pobj = Play()
    pobj.vars = t_dict_2
    pobj.hosts = t_obj_1
    pobj._load_included_file = t_obj_1
    pobj.yaml_line = 5
    pobj._ds = t_dict_2
    pobj.gather_facts = u'yes'
    pobj.hosts_pattern = u'all'
    pobj.deprecated = t_dict_2
    pobj.tags = u'all'
    p

# Generated at 2022-06-21 00:52:15.665395
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass

# Generated at 2022-06-21 00:52:17.635360
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass
    # TEST CODE GOES HERE



# Generated at 2022-06-21 00:52:28.310177
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    data = dict(
        name = "get_vars_files",
        hosts = "localhost",
        vars_files = ["/usr/local", "/usr/local/bin"],
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello Ansible!')))
        ]
    )
    play = Play.load(data)
    os.chdir("/")
    vars_files = play.get_vars_files()
    assert isinstance(vars_files,list)
    assert os.path.isfile(vars_files[1])


# Generated at 2022-06-21 00:52:34.881065
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {'var1': 'value1', 'var2': 'value2'}
    assert play.get_vars() == {'var1': 'value1', 'var2': 'value2'}
    assert play.get_vars() != {'var1': 'value1'}


# Generated at 2022-06-21 00:52:36.597577
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    assert Play.get_vars_files == Play().get_vars_files


# Generated at 2022-06-21 00:52:40.157504
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play_obj = Play()
    assert play_obj.get_vars()