

# Generated at 2022-06-21 00:43:13.866016
# Unit test for method serialize of class Play
def test_Play_serialize():
    t = Play()
    t._ds = {
        'name': 'my_play',
        'roles': [
            {
                'name': 'my_role',
                'role_params': {
                    'hosts': 'all',
                    'roles': [
                        {
                            'name': 'my_include',
                            'include_params': {
                                'hosts': 'all'
                            }
                        }
                    ]
                }
            }
        ]
    }
    t._variable_manager = MagicMock()
    t._loader = MagicMock()
    t.ROLE_CACHE = {}

    data = t.serialize()

# Generated at 2022-06-21 00:43:24.792162
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    role1 = Role()
    role1_name = "role1_name"
    role1.name = role1_name
    role2 = Role()
    role2_name = "role2_name"
    role2.name = role2_name
    roles_list = [role1, role2]
    play.roles = roles_list
    assert play.get_roles() == roles_list


# Generated at 2022-06-21 00:43:26.193835
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play is not None

# Generated at 2022-06-21 00:43:30.036731
# Unit test for method copy of class Play
def test_Play_copy():
    my_play = play_grammar._get_play_instance()
    my_play.name = "my name"
    my_play_cpy = my_play.copy()
    assert my_play.name == my_play_cpy.name



# Generated at 2022-06-21 00:43:42.865268
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    
    Options = namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'listhosts', 'listtasks', 'listtags', 'syntax','diff','removed_hosts'])

# Generated at 2022-06-21 00:43:45.021057
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    obj = Play()
    ans = repr(obj)


# Generated at 2022-06-21 00:43:54.500452
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    TaskBlock = namedtuple('TaskBlock', ['block'])
    play.pre_tasks = [TaskBlock(block=[1, 2])]
    play.tasks = [TaskBlock(block=[3, 4])]
    play.post_tasks = [TaskBlock(block=[5, 6])]

    assert play.get_tasks() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-21 00:43:56.669849
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.vars == {}, "Can not create an instance of Play"

# Generated at 2022-06-21 00:44:06.833982
# Unit test for method compile of class Play
def test_Play_compile():
    # This unit test for the method compile of class Play is intended to
    # check the correct implementation of the role compilation step,
    # returning a flat list of tasks with the lowest level dependencies
    # first. For example, if a role R has a dependency D1, which also
    # has a dependency D2, the tasks from D2 are merged first, followed
    # by D1, and lastly by the tasks from the parent role R last.
    # This is done for all roles in the Play.
    test_play = Play()
    test_play.roles = []
    test_play.post_tasks = []
    test_play.post_tasks = []
    test_play.tasks = [
        {
            'name': 'hostname',
            'hostname': 'test'
        }]
    returned_data = test_

# Generated at 2022-06-21 00:44:12.295182
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # Test to ensure that 'get_vars' functions properly when the 'self.vars' is set to a dictionary.
    play_obj = Play()
    play_obj.vars = {'test_key': 'test_value'}
    assert isinstance(play_obj.get_vars(), dict)
    assert play_obj.get_vars() == {'test_key': 'test_value'}


# Generated at 2022-06-21 00:44:28.164846
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    name = 'myplay'
    hosts = ['127.0.0.1']
    handlers = []
    roles = []
    tasks = []
    pre_tasks = []
    post_tasks = []
    play = Play(name=name, hosts=hosts, handlers=handlers, roles=roles, tasks=tasks, pre_tasks=pre_tasks, post_tasks=post_tasks)
    handler_list = play.get_handlers()
    assert len(handler_list) == 0
    assert handler_list == play.handlers


# Generated at 2022-06-21 00:44:40.208351
# Unit test for method copy of class Play
def test_Play_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.debug import ActionModule as DebugActionModule
    from ansible.inventory.host import Host

    action_loader._add_directory(DATA_PATH + '/action_plugins')

    p = Play().load(dict(
        name='test play',
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action='debug', msg='Hello world!')
        ]
    ), variable_manager=VariableManager(), loader=DataLoader())
    p._tasks = [[Task().load(dict(action='debug', msg='Hello world!'), variable_manager=VariableManager(), loader=DataLoader())]]
    p.vars.update

# Generated at 2022-06-21 00:44:46.928641
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.manager import VariableManager
    
    play_ds = [{
        u'hosts': u'testhost',
        u'vars': {u'var1': u'value1'},
        u'vars_files': u'value3',
        u'vars_prompt': u'value4',
    }]

    play = Play.load(play_ds, variable_manager=VariableManager(), loader=None)
    
    result = play.get_vars_files()

    assert result == u'value3'

    new_vars = play.get_vars()


# Generated at 2022-06-21 00:44:51.537909
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    '''
    Unit test for method __repr__ of class Play
    '''
    print('In method: __repr__')
    # TODO: Write unit test



# Generated at 2022-06-21 00:44:58.679815
# Unit test for method copy of class Play
def test_Play_copy():
    play=Play()
    play.roles=['roles']
    new_me=play.copy()
    assert new_me._included_path==play._included_path
    assert new_me.roles==play.roles
    assert new_me._action_groups==play._action_groups
    assert new_me._group_actions==play._group_actions


# Generated at 2022-06-21 00:45:07.475396
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    """ Validates the behavior of the
    :py:meth:`ansible.parsing.dataloader.DataLoader.get_roles` method of
    :py:class:`ansible.parsing.dataloader.DataLoader`
    """
    p = Play()
    r = Role()
    setattr(p, 'roles', [r])
    assert p.get_roles() == [r]


# Generated at 2022-06-21 00:45:19.841969
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
   p=Play()
   assert p.get_vars_files() == []
   # get_vars_files can accept vars_files that is None, list, or dict
   p.vars_files=None
   assert p.get_vars_files() == []
   p.vars_files=['./hosts.yml']
   assert p.get_vars_files() == ['./hosts.yml']
   p.vars_files={'host':'./host.yml'}
   assert p.get_vars_files() == {'host':'./host.yml'}


# Generated at 2022-06-21 00:45:32.721703
# Unit test for method compile of class Play
def test_Play_compile():
    # Pass
    p = Play()
    p._hosts = '127.0.0.1'
    p._name = 'test_play'
    p._vars = {'test_k': 'test_v'}
    p._roles = []
    p._handlers = ['handler1']
    p._pre_tasks = ['pre_task1']
    p._post_tasks = ['post_task1']
    p._tasks = ['task1']
    p._tags = set()
    p._max_fail_percentage = 2
    p._serial = [1, 2, 3]
    p._strategy = 'free'
    p._order = 'explicit'
    p._force_handlers = False
    block_list = p._compile_roles()

# Generated at 2022-06-21 00:45:33.534422
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    Play();

# Generated at 2022-06-21 00:45:44.462577
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    def dummy_role(name):
        return Role(name=name,
                    handler_list=[],
                    task_list=[])

    class DummyPlay(Play):
        def copy(self):
            # Play.copy() may not return a Play-type object,
            # so we need to override it.
            p = DummyPlay()
            p.load_data(self.serialize())
            return p


    play = DummyPlay()

    # Test for no roles given
    assert play.compile_roles_handlers() == []

    # Test for a single role
    play.roles = [dummy_role('foo')]
    assert play.compile_roles_handlers() == []

    # Test for multiple roles
    play.roles.append(dummy_role('bar'))

# Generated at 2022-06-21 00:46:07.535060
# Unit test for method compile of class Play
def test_Play_compile():
    ## Tests the method compile of the class Play
    # Tests the case when there are no tasks or roles in the in the play
    p = Play()
    p.tasks = []
    p.roles = []
    assert p.compile() == [Block({'meta': 'flush_handlers'}, play=p).block]
    # Tests the case when there are only the pre tasks in the play
    p = Play()
    p.tasks = []
    p.roles = []
    p.pre_tasks = [Task({'name': 'this is a pre task'}, play=p)]
    assert p.compile() == [Block({'meta': 'flush_handlers'}, play=p).block, p.pre_tasks[0]]
    # Tests the case when there are only post tasks in the play

# Generated at 2022-06-21 00:46:17.972579
# Unit test for method get_vars of class Play

# Generated at 2022-06-21 00:46:19.407381
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert p.__repr__() is not None


# Generated at 2022-06-21 00:46:24.286055
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._load_roles = MagicMock()
    r = Role()
    p.roles = [r]
    assert p.compile_roles_handlers() == [r.get_handler_blocks()]
    assert p._load_roles.called == False


# Generated at 2022-06-21 00:46:33.553876
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    host_vars = {
        "host_name": {
            "var_name": "var_value",
        }
    }
    play = Play()
    play.vars = {
        "var_name": "var_value_override",
        "var_name2": "var_value2"
    }

    vars = play.get_vars()

    assert vars["var_name"] == "var_value_override"
    assert vars["var_name2"] == "var_value2"


# Generated at 2022-06-21 00:46:35.053282
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass


# Generated at 2022-06-21 00:46:39.352545
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    obj = Play()
    assert not obj.get_tasks()
    assert not obj.get_roles()
	
	

# Generated at 2022-06-21 00:46:51.760792
# Unit test for method load of class Play
def test_Play_load():
    play_data = {}
    variable_manager = VariableManager()
    loader = None
    vars = None
    test_Play = Play.load(play_data, variable_manager, loader, vars)
    assert test_Play
    assert test_Play.__class__.__name__ == 'Play'
    assert test_Play.hosts == 'all'
    assert test_Play.name == 'all'
    assert test_Play.vars == {}
    assert test_Play.vars_files == []
    assert test_Play.vars_prompt == []
    assert test_Play.include_role == {}
    assert test_Play.include_tasks == {}
    assert test_Play.tags == frozenset(('all',))
    assert test_Play.pre_tasks == []
    assert test_Play.post

# Generated at 2022-06-21 00:47:00.731090
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    assert play_1.get_name() == '', 'Should be an empty string'
    play_2 = Play()
    play_2.name = None
    play_2.hosts = '10.0.0.100'
    assert play_2.get_name() == '10.0.0.100'
    play_3 = Play()
    play_3.name = None
    play_3.hosts = None
    assert play_3.get_name() == '', 'Should be an empty string'
    play_4 = Play()
    play_4.name = None
    play_4.hosts = ['10.0.0.100', '10.0.0.101']

# Generated at 2022-06-21 00:47:04.118048
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = [1, 2, 'a']
    assert p.get_handlers() == [1, 2, 'a']


# Generated at 2022-06-21 00:47:26.793992
# Unit test for constructor of class Play
def test_Play():
    play = Play.load(dict(
        name='test',
        hosts='all',
        roles=['roleA'],
    ), variable_manager=VariableManager(), loader=DictDataLoader())
    assert play.get_name() == 'test'
    assert play.hosts == 'all'
    assert len(play.roles) == 1
    assert play.roles[0].get_name() == 'roleA'

# Generated at 2022-06-21 00:47:36.357152
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Initializing method variables
    playbook = dict(
                    {
                        'hosts': 'all',
                        'vars': {},
                        'tasks': [
                            {
                                'name': 'setup',
                                'ansible_facts': {
                                    'key': 'value',
                                    'nested': {
                                        'inner': 'value'
                                    }
                                },
                                'setup': {},
                                'action': {},
                                'register': 'setup_result'
                            }
                        ]
                    })

    variable_manager = VariableManager()
   

# Generated at 2022-06-21 00:47:42.933298
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test get_name of class Play
    myPlay = Play()
    myPlay.name = 'Admin'
    assert myPlay.get_name() == 'Admin'
    myPlay.name = None
    myPlay.hosts = '127.0.0.1'
    assert myPlay.get_name() == '127.0.0.1'
    myPlay.hosts = None
    assert myPlay.get_name() == ''


# Generated at 2022-06-21 00:47:53.903433
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.errors import AnsibleParserError
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'test'
    assert p.get_vars_files() == ['test']
    p.vars_files = ['test', 'test2']
    assert p.get_vars_files() == ['test', 'test2']


# Generated at 2022-06-21 00:47:58.527006
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    monkeypatch.setattr(Play, "get_roles", lambda self: [])
    p = Play()

    # Test with a call without parameter
    assert p.get_roles() == []

    monkeypatch.undo()

# Generated at 2022-06-21 00:48:07.917501
# Unit test for method copy of class Play
def test_Play_copy():
    ansible_play = Play()
    ansible_play.ROLE_CACHE = {'1':'1'}
    ansible_play._included_conditional = '1'
    ansible_play._included_path = '1'
    ansible_play._action_groups = '1'
    ansible_play._group_actions = '1'
    # Test copy method
    ansible_play1 = ansible_play.copy()
    assert ansible_play1.ROLE_CACHE == {'1':'1'}
    assert ansible_play1._included_conditional == '1'
    assert ansible_play1._included_path == '1'
    assert ansible_play1._action_groups == '1'

# Generated at 2022-06-21 00:48:16.389422
# Unit test for method serialize of class Play
def test_Play_serialize():
    # setup
    class GroupRule:
        pass

    p = Play()
    p._included_path = os.path.join('whatever', 'play.yml')
    p._included_conditional = GroupRule()
    class RoleRules:
        def serialize(self):
            return {'serialized': True}
    p.roles = [RoleRules()]
    p._action_groups = {'group': []}
    p._group_actions = {'group': []}

    # test
    data = p.serialize()

    # assert
    assert str(type(data['roles'][0])) == "<class 'dict'>"
    assert data['roles'][0]['serialized'] == True

# Generated at 2022-06-21 00:48:18.062282
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    r = p.copy()
    assert isinstance(r, Play)
    # FIXME: implement


# Generated at 2022-06-21 00:48:19.711927
# Unit test for method load of class Play
def test_Play_load():
    Play.load()



# Generated at 2022-06-21 00:48:27.241193
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    block1 = Block(play=play)
    block2 = Block(play=play)
    block3 = Block(play=play)

    block1.block = ['b1t1','b1t2','b1t3']
    block2.block = ['b2t1','b2t2','b2t3']
    block3.block = ['b3t1','b3t2','b3t3']

    play.pre_tasks = [block1, 'p1', 'p2', 'p3']
    play.tasks = [block2, 't1', 't2', 't3']
    play.post_tasks = [block3, 'po1', 'po2', 'po3']


# Generated at 2022-06-21 00:48:59.104986
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    myplay = Play()
    assert myplay.get_roles() == []

# Generated at 2022-06-21 00:49:10.793014
# Unit test for method load of class Play

# Generated at 2022-06-21 00:49:13.008117
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    assert play.preprocess_data == Play.preprocess_data

# Generated at 2022-06-21 00:49:14.494127
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    testPlay_compile_roles_handlers = Play()
    testPlay_compile_roles_handlers.compile_roles_handlers()

# Generated at 2022-06-21 00:49:17.749037
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.handlers = 'handlers'
    assert play.get_handlers() == 'handlers'


# Generated at 2022-06-21 00:49:29.263243
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Test with a simple play
    p = Play().load(dict(
        name='simple-play',
        hosts=['127.0.0.1'],
        gather_facts='no',
        connection='local',
        tasks=[
            dict(action=dict(module='shell', args='ls -al'),
                 async_val=42,
                 poll=0,
                 register='out_ls',
                ),
            dict(action=dict(module='shell', args='uptime'),
                 async_val=43,
                 poll=0,
                ),
        ]
    ), variable_manager=VariableManager())
    data = p.serialize()
    assert 'hosts' in data
    assert data['hosts'] == ['127.0.0.1']
    assert 'gather_facts' in data

# Generated at 2022-06-21 00:49:36.721212
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.vars import get_default_vars_plugin_mock

    loader = DictDataLoader({
        "playbook.yml": """
        - hosts: all
          tasks:
            - name: Test variable files
              debug:
                var: combined_vars
          vars:
            var: "value"
          vars_files:
            - test1.yml
            - test2.yml
        """,
        "test1.yml": """
        var1: "value1"
        """,
        "test2.yml": """
        var2: "value2"
        """
    })

    # The vars plugin manager add

# Generated at 2022-06-21 00:49:38.379233
# Unit test for method compile of class Play
def test_Play_compile():
    assert True
    

# Generated at 2022-06-21 00:49:44.048400
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files()== []
    play.vars_files = 'abc'
    assert play.get_vars_files()== ['abc']
    play.vars_files = ['abc', 'def']
    assert play.get_vars_files()== ['abc', 'def']

# Generated at 2022-06-21 00:49:45.471246
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-21 00:50:48.812775
# Unit test for constructor of class Play
def test_Play():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 00:50:54.450681
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Play test Play
    play = Play()
    original_data = {}
    preprocessed_data = play.preprocess_data(original_data)
    assert 'user' not in preprocessed_data
    assert preprocessed_data['remote_user'] == original_data['user']
    assert 'user' not in original_data


# Generated at 2022-06-21 00:50:56.087811
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    env = Environment()
    play = Play()
    play.preprocess_data("ds")


# Generated at 2022-06-21 00:51:00.429273
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'My_first_play'
    assert play.get_name() == play.name

# Generated at 2022-06-21 00:51:04.596281
# Unit test for method load of class Play
def test_Play_load():
    # Initialize test data
    data = dict()

    try:
        # Run test scenario
        Play.load(data)
    except Exception:
        pass

# Generated at 2022-06-21 00:51:06.010552
# Unit test for method load of class Play
def test_Play_load():
    raise NotImplementedError()

# Generated at 2022-06-21 00:51:13.411263
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    data = {}
    data['name'] = 'unit_test'
    data['hosts'] = 'localhost'
    data['vars'] = {'var1': 1}
    play = Play()
    play.load(data, variable_manager=None, loader=None)
    assert play.get_roles() == []

# Generated at 2022-06-21 00:51:17.879362
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {'var1': 'var1', 'var2': 'var2'}
    assert play.get_vars() == {'var1': 'var1', 'var2': 'var2'}

# Generated at 2022-06-21 00:51:30.333653
# Unit test for constructor of class Play
def test_Play():
    loader = DataLoader()

    # Test constructor of class Play
    pb = Play()

    # Test constructor of class Play with parameters
    loader = DataLoader()
    pb = Play.load(dict(
        name="Install stuff",
        hosts="localhost",
        gather_facts="no",
        roles=["role1", "role2"],
        tasks=[dict(action=dict(module="apt", args=dict(name="ntp"))),
               dict(action=dict(module="service", args=dict(name="ntp", state="started")))],
    ), loader=loader)

    assert pb.name == "Install stuff"
    assert pb.hosts == "localhost"
    assert pb.gather_facts == False
    assert len(pb.roles) == 2

# Generated at 2022-06-21 00:51:39.629408
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
        test Play.compile_roles_handlers()
    '''
    from ansiblelint.runner import Runner
    from ansiblelint.utils import ANSIBLE_ROLE_DIR

    # create a Play from the test file
    runner = Runner(
        playbook='./test/playbooks/test-role-handler.yml',
        rulesdir='./test/rules',
        tags=[],
        exclude_paths=[],
        verbosity=1,
    )

    results = []

    # run the lint
    runner.run()

    # check the output
    results = runner.run()
    assert len(results) == 1
    assert results[0]['code_desc'] == 'Role handler'

