

# Generated at 2022-06-21 00:43:16.041372
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Initialization of mock objects
    m_Block = Mock(name="mock of Block")
    m_Block.configure_mock(block=[])
    m_play = Mock(name="mock of Play")
    m_play.configure_mock(pre_tasks=[], tasks=[], post_tasks=[])
    m_play.get_tasks.return_value = []
    #
    play = Play()
    play.pre_tasks = [m_Block]
    play.tasks = [m_Block]
    play.post_tasks = [m_Block]
    #
    list_result = play.get_tasks()
    #
    # Assertion
    assert list_result == [[], [], []]

# Generated at 2022-06-21 00:43:28.698790
# Unit test for method load of class Play
def test_Play_load():
    mock_role_data_1 = dict(
        name='role1',
        dependencies=[
            dict(role='role2', when='ansible_os_family != "RedHat"'),
            dict(role='role3', when="ansible_os_family == 'RedHat'")
        ],
        tasks=[{'name': 'role1 task1'}, {'name': 'role1 task2'}]
    )
    mock_role_data_2 = dict(
        name='role2',
        dependencies=[
            dict(role='role3')
        ],
        tasks=[{'name': 'role2 task1'}, {'name': 'role2 task2'}]
    )

# Generated at 2022-06-21 00:43:35.842143
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = 'play1'
    assert repr(play) == 'play1'
    play.name = None
    play.hosts = 'host'
    assert repr(play) == 'host'
    play.hosts = ['host', 'host1']
    assert repr(play) == 'host,host1'

# test for method load of class Play

# Generated at 2022-06-21 00:43:48.953489
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert (p.get_name() == ',')

    p.name = "repr_test"
    assert (p.__repr__() == "repr_test")

    p.name = None
    p.hosts = '127.0.0.1'
    assert (p.__repr__() == p.get_name())

    p.hosts = ['127.0.0.1', 'localhost']
    assert (p.__repr__() == p.get_name())

Play._load_roles = Play._load_roles.__get__(Play(), Play)
Play._load_vars_prompt = Play._load_vars_prompt.__get__(Play(), Play)

# Generated at 2022-06-21 00:43:58.078494
# Unit test for method compile of class Play
def test_Play_compile():

    # The type of `data` is dict
    data = {}
    # The type of `variable_manager` is VariableManager
    variable_manager = {}
    # The type of `loader` is DataLoader
    loader = {}
    # The type of `vars` is dict
    vars = {}

    # The type of `play` is Play
    play = Play.load(data, variable_manager, loader, vars)

    # test function compile
    block_list = play.compile()


# Generated at 2022-06-21 00:44:04.236734
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.compile()

    assert play.get_handlers() is not None

    play = Play()
    play.compile()

    assert play.get_handlers() is not None

    play = Play()
    play.compile()

    assert play.get_handlers() is not None

# Generated at 2022-06-21 00:44:14.141859
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Create a new Play object and set required attribute for the test
    p = Play()
    p.hosts = None

    # Define data for deserialize

# Generated at 2022-06-21 00:44:16.697843
# Unit test for method copy of class Play
def test_Play_copy():
    foo = Play()
    # TODO: may be add some asserts here
    foo.copy()


# Generated at 2022-06-21 00:44:24.870726
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play.load(dict(
        name='myplay',
        hosts=["host1", "host2"],
        roles=["role1", "role2"],
        tasks=[{"action":"ping"}, {"action":"ping2"}]
    ),
    variable_manager=VariableManager(),
    loader=DataLoader())
 
    assert play.get_handlers() != None


# Generated at 2022-06-21 00:44:32.090997
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Without any role
    data = {
        'name' : 'test_play',
        'hosts' : 'localhost',
        'vars' : {
            'a_var' : 'value'
        }
    }

    play = Play()
    play.deserialize(data)
    assert play.name == 'test_play'
    assert play.hosts == 'localhost'
    assert play.vars['a_var'] == 'value'
    assert play.roles == []

    # With a role

# Generated at 2022-06-21 00:45:00.446938
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from unittest import mock
    import yaml

    # Create a fake tasklist
    tasklist = """
    - name: do foo
      foo: bar

    - name: do bar
      bar: baz
    """

    # Create a fake Play
    play = yaml.safe_load(tasklist)

    # Create a Play
    p = Play()
    p.load(play, variable_manager=None, loader=None)
    p.ROLE_CACHE = {}
    p._included_conditional = None
    p._included_path = None
    p._action_groups = {}
    p._group_actions = {}

    # Test the get_tasks method

# Generated at 2022-06-21 00:45:06.660763
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = {'hosts': 'localhost', 'user': 'johnd'}
    d = Play().preprocess_data(ds)
    assert d['remote_user'] == 'johnd'
    assert ds != d
    assert 'user' not in d

# Generated at 2022-06-21 00:45:11.630528
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # Setup the test object
    # test_obj = Play()
    test_obj = Play()
    test_obj.get_name = MagicMock(return_value = 'test_name')

    # get the repr for the test_obj
    test_repr = repr(test_obj)

    # assert that test_repr is equal to expected repr
    expected_repr = 'test_name'
    assert test_repr == expected_repr

    # return the test_obj
    return test_obj


# Generated at 2022-06-21 00:45:23.920502
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test data
    p = Play()
    p.roles = [RoleInclude("role1"), RoleInclude("role2")]
    # create a role handler
    t = Handler()
    t.name = "handler1"
    # generate a handler block
    b = Block()
    b.block = [t]
    # generate a list of handler blocks
    hb = [b, b]
    # inject the list into the role1
    p.roles[0]._handlers = hb
    # inject the list into the role2
    p.roles[1]._handlers = hb
    # change the role2 name
    p.roles[1].name = "changed_name"
    
    # Test execution
    result = p.compile_roles_handlers()
    
    # Test

# Generated at 2022-06-21 00:45:26.920017
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    """Test the method get_roles of class Play.
    """
    play = Play()
    role = Role()
    play.roles = [role]
    assert play.get_roles() == [role]


# Generated at 2022-06-21 00:45:31.064966
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_data = dict(
        hosts=['localhost'],
    )
    play = Play()
    play.load_data(play_data, variable_manager=None, loader=None)
    assert(play.get_name() == 'localhost')


# Generated at 2022-06-21 00:45:35.276842
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    result = Play().get_tasks()
    assert result is not None
    assert type(result) is list
    assert len(result) == 0



# Generated at 2022-06-21 00:45:44.902042
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    hosts = [host for host in 'host1,host2'.split(',')]
    vars = {}
    vars_prompt = []
    play = Play()
    assert isinstance(play, Play), "Play class needs to return Play"
    assert is_sequence(hosts), "hosts needs to be a sequence"
    assert isinstance(vars, dict), "vars needs to be a dict"
    assert isinstance(vars_prompt, list), "vars_prompt needs to be a list"
    assert play.__repr__() is not None, "Play class needs to have __repr__"
    assert play.get_name() is not None, "Play class needs to have get_name"
    assert play.get_vars() is not None, "Play class needs to have get_vars"
   

# Generated at 2022-06-21 00:45:55.764014
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_obj = Play()
    test_obj._parent = mock.Mock()
    test_obj._parent._set_vars = mock.Mock()
    test_obj._ds['vars_files'] = None
    test_obj._ds['vars_files'] = None
    assert test_obj.get_vars_files() == []
    assert test_obj.get_vars_files() == []
    test_obj._ds['vars_files'] = 'vars_files'
    test_obj._ds['vars_files'] = 'vars_files'
    assert test_obj.get_vars_files() == ['vars_files']
    assert test_obj.get_vars_files() == ['vars_files']

# Generated at 2022-06-21 00:46:04.380860
# Unit test for method copy of class Play
def test_Play_copy():
    p1 = Play()
    p1.ROLE_CACHE = {'Role1': 1, 'Role2': 2}
    p2 = p1.copy()
    assert p1 == p2
    assert p1.ROLE_CACHE == p2.ROLE_CACHE
    assert p1._included_conditional == p2._included_conditional
    assert p1._included_path == p2._included_path
    assert p1._action_groups == p2._action_groups
    assert p1._group_actions == p2._group_actions



# Generated at 2022-06-21 00:46:27.449675
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Unit test to verify various conditions of the get method
    import os
    import sys

    my_var = 'my_var'
    my_value = 'my_value'
    my_list = ['item1', 'item2']

    p = Play()

    # Verify vars_file is None
    assert p.get_vars_files() == []

    # Verify vars_file is not a list does not raise error
    p.vars_files = 5
    assert p.get_vars_files() == [5]

    # Verify vars_file is a list
    p.vars_files = my_list
    assert p.get_vars_files() == my_list

# Generated at 2022-06-21 00:46:28.900003
# Unit test for method compile of class Play
def test_Play_compile():
    assert True == True

# Generated at 2022-06-21 00:46:29.865613
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass

# Generated at 2022-06-21 00:46:33.594787
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # GIVEN:
    play = Play()
    play.vars = dict()
    
    # WHEN:
    result = play.get_tasks()

    # THEN:
    assert result == list()



# Generated at 2022-06-21 00:46:43.897615
# Unit test for method copy of class Play
def test_Play_copy():
    play1 = Play().load(dict(name='test'))
    play2 = play1.copy()
    assert play1.get_name() == play2.get_name()
    assert play1.vars == play2.vars
    assert play1._included_path == play2._included_path
    assert play1._action_groups == play2._action_groups
    assert play1._group_actions == play2._group_actions
    assert play1.ROLE_CACHE == play2.ROLE_CACHE



# Generated at 2022-06-21 00:46:57.273248
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.vars_files is None
    assert p.roles is None
    assert p.tasks is None
    assert p.handlers is None
    assert p.name is None
    assert p.vars == {}
    assert p.hosts == ''
    assert p.tags == []
    assert p.gather_facts == C.DEFAULT_GATHER_FACTS
    assert p.port == C.DEFAULT_REMOTE_PORT
    assert p.any_errors_fatal is False
    assert p.force_handlers is False
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.serial == 1
    assert p.max_fail_percentage == 0
    assert p.strategy == C.DEFAULT_STRATEGY
    assert p.connection

# Generated at 2022-06-21 00:46:59.510077
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # vars
    p = Play()
    d = dict()
    p.vars = d
    assert p.get_vars() == d


# Generated at 2022-06-21 00:47:06.082622
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
   play = Play()
   play.tasks = [{'block': []}, {'block': []}]
   play.post_tasks = [{'block': []}]
   play.pre_tasks = [{'block': []}]

# Generated at 2022-06-21 00:47:17.380595
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # init pb/play
    print("pb")
    pb = Playbook()
    pb.set_loader(DictDataLoader({}))
    pb.set_variable_manager(VariableManager())
    print("play")
    play = Play()
    play.set_loader(DictDataLoader({}))
    play.set_variable_manager(VariableManager())
    print("mock")
    mock_task = MockTask()
    mock_task.set_loader(DictDataLoader({}))
    mock_task.set_variable_manager(VariableManager())
    print("pre_tasks")
    play.set_loader(DictDataLoader({}))
    play.set_variable_manager(VariableManager())
    play.tasks = [mock_task]
    play.pre_tasks = []

# Generated at 2022-06-21 00:47:19.304702
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert play.__repr__() == play.get_name()

# Generated at 2022-06-21 00:48:05.893873
# Unit test for method copy of class Play
def test_Play_copy():
    '''
    Test that method copy of class Play actually copies the object and
    not just returns a reference to the original object
    '''
    # Create an instance of Play() with fields being set
    #in order to fully exercise __init__
    my_vars = dict()
    my_vars['var1'] = 'test_var'
    play_test = Play(my_vars, 'test_play')
    play_test.name = 'Test Play'

    # Create a copy of play_test
    copy_play_test = play_test.copy()

    # Note id(object) returns the internal id of the object
    # These are equal if object is assigned from object
    # e.g. a=b
    assert id(play_test) == id(copy_play_test)

    # Now change something in copy_

# Generated at 2022-06-21 00:48:15.318866
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from pprint import pprint
    from units.module_utils.basic import AnsibleModule

    play = Play()
    play.set_loader(AnsibleModule._load_params)
    play.set_variable_manager(AnsibleModule._load_params)
    play.load(dict(
        name="test",
        hosts=["all"],
        gather_facts="no",
        vars={},
        handlers=[
            dict(
                include_role=dict(
                    name="test-2"
                ),
                import_role=dict(
                    name="test-1"
                )
            )
        ]
    ))

    print('Play.get_handlers()')
    pprint(play.get_handlers())
    print('Play.get_handlers()')

# Generated at 2022-06-21 00:48:18.270512
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert repr(p) == p.get_name()


# Generated at 2022-06-21 00:48:19.145319
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-21 00:48:21.346092
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play_repr = play.__repr__()
    assert play_repr == play.get_name()

# Generated at 2022-06-21 00:48:34.589721
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.parsing import vault
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # create the objects to test
    pm = Play()
    ds = dict(
        name='testing',
        hosts='all',
        connection='local',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='echo hi'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )
    pm.deserialize(ds)

    # create the data loader and inventory
    loader = DataLoader()

# Generated at 2022-06-21 00:48:43.212469
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    global_vars = {}
    p = Play()
    p.deserialize(global_vars)

    # check that variables that should be set after deserialization are defined
    assert "ROLE_CACHE" in global_vars
    assert "action_groups" in global_vars
    assert "group_actions" in global_vars
    assert "included_path" in global_vars
    assert "roles" in global_vars

    return p


# Generated at 2022-06-21 00:48:45.357976
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    assert p.compile() is not None

# Generated at 2022-06-21 00:48:48.781432
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # print('Testing Play.preprocess_data()')
    play = Play()
    play.preprocess_data(None)


# Generated at 2022-06-21 00:48:52.814556
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = [1, 2, 3]
    assert p.get_vars_files() == [1, 2, 3]

# Generated at 2022-06-21 00:49:16.016258
# Unit test for constructor of class Play
def test_Play():
    data = """ - test1
               - test2
            """
    block = """ - test3
                - test4
             """

    p = Play()
    p.load(load_data(data), variable_manager=None, loader=None, vars=None)

    assert p.name, 'test1,test2'
    assert p.hosts, 'test1'

    assert len(p.tasks), 1
    assert p.tasks[0], block

# Generated at 2022-06-21 00:49:27.763241
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play(dict(name='test_play_name'))
    assert p.name == 'test_play_name'
    assert p.get_name() == 'test_play_name'
    assert p.tasks == []
    assert p.get_tasks() == []
    p.pre_tasks = [ dict(name = 'pre_task_1'), dict(name = 'pre_task_2') ]
    p.tasks = [ dict(name = 'task_1'), dict(name = 'task_2') ]
    p.post_tasks = [ dict(name = 'post_task_1'), dict(name = 'post_task_2') ]

# Generated at 2022-06-21 00:49:29.576564
# Unit test for method copy of class Play
def test_Play_copy():
    if not Play.copy:
        raise Exception('Incorrect copy')
test_Play_copy()

# Generated at 2022-06-21 00:49:33.495489
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    mock = MagicMock()
    mock.get_roles.return_value = [1,2]

    obj = Play()
    obj.roles = mock

    a = obj.get_roles()
    assert a == [1,2]
    mock.get_roles.assert_called_once()


# Generated at 2022-06-21 00:49:42.860516
# Unit test for method copy of class Play
def test_Play_copy():
    test_obj = get_Play()
    new_obj = test_obj.copy()
    assert new_obj.ROLE_CACHE == test_obj.ROLE_CACHE
    assert new_obj._included_conditional == test_obj._included_conditional
    assert new_obj._included_path == test_obj._included_path
    assert new_obj._action_groups == test_obj._action_groups
    assert new_obj._group_actions == test_obj._group_actions


# Generated at 2022-06-21 00:49:45.470576
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    assert play.preprocess_data("") == ''


# Generated at 2022-06-21 00:49:55.254834
# Unit test for constructor of class Play
def test_Play():
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.vars.defaults import DEFAULT_HANDLER_NAME
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.vars import combine_vars

    pm = Play.load(dict(name="Test Play"), variable_manager=VariableManager())

    assert isinstance(pm, AttributeResolver)
    assert isinstance(pm, Taggable)
    assert hasattr(pm, "name")
    assert hasattr(pm, "hosts")
    assert hasattr(pm, "handlers")
    assert hasattr(pm, "tasks")
    assert hasattr(pm, "role_names")

# Generated at 2022-06-21 00:50:01.589848
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import collections

    # Instantiate object, don't need valid data for all attributes
    p = Play()

    # _connection
    assert p._connection is None
    data_in = 'smart'
    p.deserialize({'_connection': data_in})
    assert p._connection == data_in
    p.deserialize({})
    assert p._connection == data_in

    # _delegate_to
    data_in = 'all'
    p.deserialize({'_delegate_to': data_in})
    assert p._delegate_to == data_in
    p.deserialize({})
    assert p._delegate_to == data_in

    # _description
    data_in = 'Play description'
    p.deserialize({'_description': data_in})
    assert p._description

# Generated at 2022-06-21 00:50:13.631156
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_play = copy.deepcopy(play_ds)
    play = Play.load(test_play)
    test_results = []
    test_results.append(test_play['tasks'][0])
    test_results.append(test_play['tasks'][1])
    test_results.append(test_play['tasks'][2])
    test_results.append(test_play['tasks'][3])
    test_results.append(test_play['tasks'][4])
    test_results.append(test_play['tasks'][5])
    assert play.get_tasks() == test_results

# Generated at 2022-06-21 00:50:19.932610
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    b = {}
    b['hosts'] = 'host'
    b['name'] = 'test_play'
    b['vars_files'] = 'play_var_file'
    b['vars'] = 'play_var'
    b['roles'] = 'play_role'
    p = Play()
    p.load(b, None, None)
    assert p.get_vars_files() == ['play_var_file']


# Generated at 2022-06-21 00:50:48.048331
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Invalid play object
    invalid_play = None
    result = Play.compile_roles_handlers(invalid_play)
    assert result == None

    # Valid play object having roles
    play = Play()
    role = Role.load(RoleInclude(), play=play)
    play.roles.append(role)
    result = Play.compile_roles_handlers(play)
    assert result == [role]

    # Valid play object not having roles
    play = Play()
    result = Play.compile_roles_handlers(play)
    assert result == []


# Generated at 2022-06-21 00:50:55.123866
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    try:
        # Test calling an empty Play class
        Play_obj = Play()
        assert Play_obj.get_roles() == []
    except AssertionError as e:
        print('Assertionerror: ', e)
        raise AssertionError

if __name__ == "__main__":
    test_Play_get_roles()

# Generated at 2022-06-21 00:51:08.862638
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block

    play_name = 'test_play'
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    cle = Play()

    # We create a play with different stuff

# Generated at 2022-06-21 00:51:15.797209
# Unit test for method copy of class Play
def test_Play_copy():
    loader = DictDataLoader({
        "example_playbook.yml": """
---
- hosts: all
  tasks:
   - name: ping
     ping:
""",
    })
    inventory = Inventory(loader=loader, host_list=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    p = Play.load('example_playbook.yml', variable_manager=variable_manager, loader=loader)
    p_copy = p.copy()
    assert p_copy._play_hosts == p._play_hosts
    assert p_copy._play_name == p._play_name



# Generated at 2022-06-21 00:51:17.991780
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    if play.get_name() != play.__repr__():
        raise AssertionError("(%s) != (%s)" % (play.get_name(), play.__repr__()))


# Generated at 2022-06-21 00:51:30.332862
# Unit test for method load of class Play
def test_Play_load():
    from ansible.errors import AnsibleParserError

    # Load the test data from data/unit_tests/ansible_play.yaml
    data = load_fixture('ansible_play.yaml')

    # Initialize a Play object
    p = Play()

    # Test the load method using the test data
    expected = Play()
    load_data(expected, data)
    actual = Play.load(data)
    assert expected == actual

    # Execute a negative test (missing name) with an assertion statement.
    del(data['name'])
    # with pytest.raises(AnsibleParserError):
    #     p.load_data(data)

    # Execute a negative test (missing hosts) with an assertion statement.
    data = load_fixture('ansible_play.yaml')

# Generated at 2022-06-21 00:51:34.456674
# Unit test for method get_name of class Play
def test_Play_get_name():
    name = None
    p = Play()
    p.name = name
    p.hosts = 'hosts'
    assert p.get_name() == 'hosts'
    p.hosts = []
    assert p.get_name() == ''

# Generated at 2022-06-21 00:51:37.974779
# Unit test for method compile of class Play
def test_Play_compile():
    ds = {}
    p = Play()
    result = p.compile(ds)
    assert result == None

# Generated at 2022-06-21 00:51:50.496973
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.blocks import Block
    from ansible.playbook.handler import Handler

    data = {'name': 'test', 'hosts': 'test_hosts','roles': ['test_role']}
    
    new_play = Play()
    new_play.load_data(data)
    
    handler1 = Handler()
    handler1.action = 'debug'

    handler2 = Handler()
    handler2.action = 'debug'

    task1 = Task()
    task1.action = 'debug'
    
    
    task2 = Task()
    task2.action = 'debug'
    
    task3 = Task()
    task3.action = 'debug'


# Generated at 2022-06-21 00:51:52.499964
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    from ansible.playbook import Play


    play = Play()
    play.vars = {'k1': 'v1'}

    assert play.get_vars() == {'k1': 'v1'}

# Generated at 2022-06-21 00:52:18.918792
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_file_list = ["vars.yml", "vars.yml"]
    play = Play()
    # set attribute vars_files in play with a list
    play.vars_files = vars_file_list
    # get attribute vars_files from play
    result_vars_files = play.get_vars_files()
    assert result_vars_files == vars_file_list
    # set attribute vars_files in play with a string
    play.vars_files = "vars.yml"
    # get attribute vars_files from play
    result_vars_files = play.get_vars_files()
    assert result_vars_files == ["vars.yml"]
    # set attribute vars_files in play with None
    play.vars_files

# Generated at 2022-06-21 00:52:25.117685
# Unit test for constructor of class Play
def test_Play():
    '''
    >>> Play.load({})
    <ansible.playbook.play.Play object at 0x20c4b01d0>
    '''

if __name__ == '__main__':

    # Test the class constructor
    p = test_Play()

# Generated at 2022-06-21 00:52:31.350080
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    test_object = Play()
    test_object._ds = {'hosts': 'localhost', 'tasks': [], 'vars': {}, 'pre_tasks': [], 'post_tasks': [], 'roles': [], 'handlers': []}
    result = test_object.preprocess_data(test_object._ds)
    assert result == {'hosts': 'localhost', 'tasks': [], 'vars': {}, 'remote_user': 'root', 'pre_tasks': [], 'post_tasks': [], 'roles': [], 'handlers': []}


# Generated at 2022-06-21 00:52:34.147381
# Unit test for method get_name of class Play
def test_Play_get_name():
    a = Play()
    a._ds = {'hosts': '192.168.0.1'}
    assert a.get_name() == '192.168.0.1'



# Generated at 2022-06-21 00:52:39.904774
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.manager import InventoryManager
    from ansible.context import context


# Generated at 2022-06-21 00:52:42.049227
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.name = 'name of the play'
    actual_result = p.__repr__()
    expected_result = 'name of the play'
    assert actual_result == expected_result
    
    