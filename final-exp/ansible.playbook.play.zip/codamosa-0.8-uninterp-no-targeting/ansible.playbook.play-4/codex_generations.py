

# Generated at 2022-06-21 00:43:01.304945
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play

# Generated at 2022-06-21 00:43:03.268353
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = []
    assert p.get_handlers() == []


# Generated at 2022-06-21 00:43:14.995576
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pl = Play()
    pl.deserialize({'name': None, 'hosts': ['all'], 'tasks': [{'meta': 'flush_handlers', '__ansible_index__': 0}, {'meta': 'flush_handlers', '__ansible_index__': 0}, {'meta': 'flush_handlers', '__ansible_index__': 0}, {'meta': 'flush_handlers', '__ansible_index__': 0}], 'handlers': [], 'roles': [], 'included_path': None, 'action_groups': {}, 'group_actions': {}})
    pass

# Generated at 2022-06-21 00:43:16.097401
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert True



# Generated at 2022-06-21 00:43:28.167326
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize(
        {
            'action_groups': {},
            'hosts': '',
            'roles': [
                {
                    'name': '',
                    'role_path': '',
                    'tasks': [],
                    'vars': {},
                    'default_vars': {},
                    '_role_path': '',
                    '_file_name': '',
                    '_name': '',
                    '_parent': None,
                    '_role': None,
                    '_loader': None,
                    '_variable_manager': None,
                    '_init_ok': True
                }
            ],
            'group_actions': {},
            'included_path': None
        }
    )

# Generated at 2022-06-21 00:43:40.437914
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.reserved import Reserved
    from ansible.vars.clean import strip_internal_keys
    from ansible.vars.manager import load_extra_vars, load_options_vars, load_command_line_snippet
    from ansible.vars.insert_vars import prepend_play_context

    # Issue#36110
    # Play.preprocess_data removes some of the keys and values from self._ds.
    # In this test case, we will check the self._ds object after calling Play

# Generated at 2022-06-21 00:43:43.530943
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    assert p.get_handlers() == []
    

# Generated at 2022-06-21 00:43:47.549755
# Unit test for method load of class Play
def test_Play_load():
    '''
    Test for method for load
    '''
    dat = parser.load_from_file(playbook_path_data)
    play = Play.load(dat)
    aeq(play.__dict__.get('_ds'), dat)

# Generated at 2022-06-21 00:43:55.181103
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    ####
    # Test cases for Play.get_tasks()
    ####

    play_data = dict(
        name="Ansible Play 0",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )
    play = Play().load(data=play_data, variable_manager=VariableManager(), loader=None)
    assert len(play.get_tasks()) == 3
    assert play.get_tasks()[0].action == 'shell'
    assert play.get_tasks()[1].action == 'debug'

# Generated at 2022-06-21 00:43:57.435953
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    result = isinstance(Play.deserialize(''), AnsibleBaseYAMLObject)
    assert result == True


# Generated at 2022-06-21 00:44:07.336658
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.name = 'test'
    assert str(p) == 'test'


# Generated at 2022-06-21 00:44:11.380728
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    test_object = Play()
    test_object.deserialize(dict(handlers=[{'name': 'all', 'loop': '', 'with_sequence': 'start=0 end=10'}]))
    assert isinstance(test_object.get_handlers(), list)


# Generated at 2022-06-21 00:44:20.190523
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test 1
    # Testing the case of tasks being None
    play = Play()

    setattr(play, 'pre_tasks', None)
    setattr(play, 'tasks', None)
    setattr(play, 'post_tasks', None)

    assert play.get_tasks() == []

    # Test 2
    # Testing the case of tasks having length
    play = Play()

    setattr(play, 'pre_tasks', [])
    setattr(play, 'tasks', [])
    setattr(play, 'post_tasks', [])

    assert play.get_tasks() == []

    # Test 3
    # Testing the case of tasks having length
    play = Play()

    block = Block(play=play)
    setattr(block, 'block', [])

# Generated at 2022-06-21 00:44:26.224355
# Unit test for method compile of class Play
def test_Play_compile():
    # test_Play_compile.links_1
    play_obj = Play()
    context.CLIARGS = ImmutableDict(connection='smart', module_path=None, forks=5, become=None, become_method=None, become_user=None, check=False, diff=False, verbosity=5)
    play_obj.vars_files = None
    play_obj.handlers = None

# Generated at 2022-06-21 00:44:33.550747
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    p.roles = [{'role1':'1'}, {'role2':'2'}]
    # expected result: [{'role1':'1'}, {'role2':'2'}]
    print(p.get_roles())


# Generated at 2022-06-21 00:44:42.179287
# Unit test for constructor of class Play
def test_Play():
    def _WalkVars(attributes, obj):
        for k, v in attributes.items():
            if isinstance(v, type):
                yield k, getattr(obj, k)
            else:
                for k1, v1 in _WalkVars(v, getattr(obj, k)):
                    yield k1, v1

    _play = Play()

    # Check if each attribute has a value
    for k, v in _WalkVars(Play._load_attributes, _play):
        if isinstance(v, (binary_type, text_type)):
            assert isinstance(v, (binary_type, text_type))
        elif isinstance(v, (int, float)):
            assert isinstance(v, (int, float))
        elif isinstance(v, set):
            assert isinstance

# Generated at 2022-06-21 00:44:43.065057
# Unit test for constructor of class Play
def test_Play():
    pass



# Generated at 2022-06-21 00:44:48.428301
# Unit test for method serialize of class Play
def test_Play_serialize():
    '''
    Play._validate_strategy test
    '''
    A = Play()
    x = type(A)
    try:
        assert issubclass(x, Play), "Play is not a subclass of Play"
    except:
        print("Play is not a subclass of Play")
    B = Play()
    B.serialize()

# Generated at 2022-06-21 00:44:55.384454
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    def test(self):
        if self.vars_files is None:
            assert True
        elif not isinstance(self.vars_files, list):
            assert True
        return self.vars_files
    a = Play()
    assert a.get_vars_files() == test(a)

# Generated at 2022-06-21 00:45:03.597762
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # test setup
    from ansiblelint.rules.TasksNotIncludedInAnyPlayRule import TasksNotIncludedInAnyPlayRule
    rule = TasksNotIncludedInAnyPlayRule()
    filename = 'testResources/ansible-smell/playBeforeTask.yml'
    print (filename)

    # run test
    play = Play.load(filename, loader=yaml_dumper, variable_manager=variable_manager)
    result = play.get_tasks()
    task = result[0]
    action = task.action

    # test assertions
    assert isinstance(play.__class__, Play)
    assert isinstance(task, IncludeTask)
    assert action == 'include_tasks'


# Generated at 2022-06-21 00:45:23.765968
# Unit test for method serialize of class Play
def test_Play_serialize():
    '''
    Unit test for method serialize of class Play
    '''

    test_play_args = dict(name='TestPlay', variable_manager=None, loader=None)
    test_data = {
        'tasks': [
            {"debug": {"msg": "will remove this"}},
            {"name": "Test Task", "debug": {"msg": "will keep this"}}
        ]
    }

    # test with data
    test_play = Play.load(data=test_data, **test_play_args)
    test_play_serialized = test_play.serialize()

    # test without data
    no_data_play = Play(**test_play_args)
    no_data_play_serialized = no_data_play.serialize()

    assert test_play_serialized == no_data

# Generated at 2022-06-21 00:45:29.434703
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Testing the default initialisation
    play = Play()

    roles = play.get_roles()
    assert type(roles) == list
    assert len(roles) == 0

    # Testing after a role has been added
    role = Role()
    role.get_name = MagicMock(return_value="my_role")

    play.roles = [role]
    assert len(play.get_roles()) == 1
    assert play.get_roles()[0] == role



# Generated at 2022-06-21 00:45:43.089025
# Unit test for method load of class Play
def test_Play_load():
    play = Play.load({'hosts': 'localhost', 'tasks': [{'name': 'task1', 'action': {'module': 'debug', 'args': {'msg': 'OK'}}},
                                                      {'block': {'tasks': [{'name': 'task2', 'action': {'module': 'debug', 'args': {'msg': 'OK'}}}],
                                                       'rescue': [{'name': 'task3', 'action': {'module': 'debug', 'args': {'msg': 'OK'}}}]}}]})
    assert play.name == 'localhost'
    assert len(play.tasks) == 3
    assert play.tasks[0].name == 'task1'
    assert play.tasks[1].name == 'task2'

# Generated at 2022-06-21 00:45:50.237443
# Unit test for method get_name of class Play
def test_Play_get_name():
    dict = {'hosts': 'all', 'gather_facts': 'no', 'tasks': [{'debug': {'msg': 'Hello world'}}]}
    p = Play.load(dict)
    assert (p.get_name() == dict['hosts'])
# Unit Test for method get_vars of class Play

# Generated at 2022-06-21 00:45:52.313323
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p._ROLE_CACHE is {}

# Generated at 2022-06-21 00:46:00.861857
# Unit test for method load of class Play
def test_Play_load():
    test_Play = Play()
    test_loader = DataLoader()
    test_variable_manager = VariableManager()
    test_Play_data = {}
    test_Play_load = test_Play.load(test_data=test_Play_data, variable_manager=test_variable_manager, loader=test_loader)
    assert test_Play_load.__class__.__name__ == 'Play'

# Generated at 2022-06-21 00:46:14.972066
# Unit test for method get_tasks of class Play

# Generated at 2022-06-21 00:46:27.422801
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p._execute_handlers = True
    p._execute_tasks    = True
    p._handler_cleaned  = True
    p._handler_task     = None
    p._included_conditional = True
    p._included_path = '/test'
    p.ROLE_CACHE = {'1234': True}
    p.action = 'test'
    p.always = []
    p.any_errors_fatal = False
    p.become_user = 'test'
    p.block = []
    p.block_errors_fatal = False
    p.deprecated = False
    p.deprecated_msg = None
    p.description = 'test'
    p.done = []
    p._ds = {'roles': True}
    p.failed

# Generated at 2022-06-21 00:46:34.242327
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'asd123'
    assert p.get_name() == 'asd123'

    p.name = None
    assert p.get_name() == ''

    p.hosts = ['local']
    assert p.get_name() == 'local'

    p.hosts = ['local', 'remote']
    assert p.get_name() == 'local,remote'


# Generated at 2022-06-21 00:46:38.092681
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()

    assert isinstance(p.get_roles(), list), 'Wrong type returned by get_roles() method'

# Generated at 2022-06-21 00:47:01.581542
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_play = Play.load(yaml.safe_load("""
    - hosts: all
      gather_facts: no
      tasks:
        - debug:
            msg: task1
        - block:
            - debug:
                msg: task2
            - debug:
                msg: task3
        - block:
            - debug:
                msg: task4
              rescue:
                - debug:
                    msg: task5
                - debug:
                    msg: task6
              always:
                - debug:
                    msg: task7
        - debug:
            msg: task8
    """))
    test_Play_get_task_res = test_play.get_tasks()
    assert [str(task) == 'task1' for task in test_Play_get_task_res[0]]

# Generated at 2022-06-21 00:47:04.908305
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    v = dict(vars1="1")
    play =  Play()
    play.vars = v
    assert play.get_vars() == v

# Generated at 2022-06-21 00:47:10.242963
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.handlers = [{'test': lambda: 42}]
    
    assert len(play.get_handlers()) == 1
    assert play.get_handlers()[0]['test']() == 42


# Generated at 2022-06-21 00:47:20.396978
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play._ds is None
    assert play.vars is None
    assert play.vars_files is None
    assert play.name is None
    assert play.description is None
    assert play.hosts is None
    assert play.remote_user is None
    assert play.become is None
    assert play.become_method is None
    assert play.become_user is None
    assert play.force_handlers is False
    assert play.max_fail_percentage is None
    assert play.serial is None
    assert play.strategy is C.DEFAULT_STRATEGY
    assert play.roles is None
    assert play.handlers is None
    assert play.pre_tasks is None
    assert play.post_tasks is None
    assert play.tasks is None

# Generated at 2022-06-21 00:47:21.749123
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass

# Generated at 2022-06-21 00:47:25.293516
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    assert Play().preprocess_data("") == {}
    data = {'user': 'root', 'name': 'test'}
    assert Play().preprocess_data(data) == {'remote_user': 'root', 'name': 'test'}

# Generated at 2022-06-21 00:47:28.519184
# Unit test for method deserialize of class Play
def test_Play_deserialize():
   print("CREATING Play")
   play = Play()
   print("CREATING data")
   data = {"name": "Apollo", "hosts": ["localhost"], "connection": "local", "remote_user": "root", "port": "22"}
   print("DESERIALZE Play")
   print(play.deserialize(data))

# Generated at 2022-06-21 00:47:35.816721
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = 'toto'
    assert play.get_vars_files() == ['toto']
    del play.vars_files
    assert play.get_vars_files() == []
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = []
    assert play.get_vars_files() == []
    play.vars_files = ['a', 'b']
    assert play.get_vars_files() == ['a', 'b']


# Generated at 2022-06-21 00:47:43.216598
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play.load(dict(name='Test Play',
                       hosts='all',
                       gather_facts='no',
                       roles=[],
                       tasks=[dict(action=dict(module='debug', args=dict(msg='Hello World')))],
                       handlers=[]))
    assert isinstance(p.get_handlers(), HandlerBaseList)
    p.handlers = [Handler()]
    assert isinstance(p.get_handlers(), HandlerBaseList)
    assert isinstance(p.get_handlers()[0], Handler)



# Generated at 2022-06-21 00:47:48.969794
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    import copy
    import unittest
    p = Play()
    p.vars = {'a': 'b'}
    assert p.get_vars() == {'a': 'b'}
    assert p.get_vars() is not p.vars

# Generated at 2022-06-21 00:48:07.101394
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p

# Generated at 2022-06-21 00:48:15.938620
# Unit test for method compile of class Play
def test_Play_compile():
    """ Test the Play.compile() method """

    # Create test Play
    play = Play()

    # Create test data structure
    my_play_ds = dict(
        name='Ansible Play Test',
        hosts=dict(
            all=dict(
                vars=dict(
                    key1='value1',
                    key2='value2',
                ),
            ),
        ),
        roles=[
            dict(
                role='role1',
            ),
            dict(
                role='role2',
            ),
        ],
        tasks=dict(
            task1=dict(
                module='ping',
            ),
            task2=dict(
                module='ping',
            ),
        ),
    )

    # Load the test data structure into the Play

# Generated at 2022-06-21 00:48:24.906515
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {
        'vars': {},
        'roles': [{
            'name': 'role-name',
            'file': 'path/to/role.yml',
            'defaults': {},
            'vars': {},
            'tasks': [],
        }]
    }
    p = Play()
    p.deserialize(data)

    assert p.roles[0].name == 'role-name'
    assert p.roles[0].file == 'path/to/role.yml'


# Generated at 2022-06-21 00:48:25.582702
# Unit test for method load of class Play
def test_Play_load():
    pass



# Generated at 2022-06-21 00:48:27.174804
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass


# Generated at 2022-06-21 00:48:30.265530
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    result = play.__repr__()
    assert result == ''

# Generated at 2022-06-21 00:48:37.415160
# Unit test for constructor of class Play

# Generated at 2022-06-21 00:48:46.689955
# Unit test for constructor of class Play
def test_Play():

    yaml_data = dedent('''
    ---
    - name: Test Play
      hosts: all
      remote_user: root
      gather_facts: yes
      roles:
        - role1
        - role2
      tasks:
        - name: debug var
          debug:
            msg: "{{ var }}"
        - name: debug var in verbose
          debug:
            var: "{{ var }}"
        - name: autogenerated task from a dictionary
          fail:
            msg: "This task was generated from a dictionary"
    ''')

    ds = yaml.safe_load(yaml_data)
    p = Play().load(ds[0], variable_manager=VariableManager(), loader=DataLoader())
    assert p.name == "Test Play", p.name

# Generated at 2022-06-21 00:48:50.364531
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    print( p.get_name())


# =============================================================================
# Ansible PlayContext
# =============================================================================


# Generated at 2022-06-21 00:48:57.698940
# Unit test for method copy of class Play
def test_Play_copy():
    p1 = Play()
    p2 = p1.copy()
    assert p1._included_conditional == p2._included_conditional
    assert p1._included_path == p2._included_path
    assert p1._action_groups == p2._action_groups
    assert p1._group_actions == p2._group_actions
    assert p1.ROLE_CACHE == p2.ROLE_CACHE


# Generated at 2022-06-21 00:49:31.656013
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Check that play is created properly
    play = Play()
    assert play.get_roles() == [] 

# Generated at 2022-06-21 00:49:45.045800
# Unit test for method compile of class Play
def test_Play_compile():
    '''
    This tests a playbook with a task, two roles and another task.
    '''
    test_play_datastructure = '''
    ---
    - hosts: localhost
      strategy: free
      serial: 1
      pre_tasks:
        - debug:
            var: random
      roles:
        - role_1
        - role_2
      tasks:
        - debug:
            var: foo
        - debug:
            var: bar
      handlers:
        - name: restart nginx
          service:
            name: nginx
            state: restarted
      post_tasks:
        - debug:
            var: baz
      vars_prompt:
        - name: foo
          prompt: "What is foo?"
          private: no
    '''
    test_play = Play()


# Generated at 2022-06-21 00:49:54.599088
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    han = Handler()
    han.name = 'test_handler'
    han.action = 'test_action'
    t1, t2 = Task(), Task()
    t1.name, t2.name = 'test_task1', 'test_task2'
    blk = Block(tasks=[t1,], rescue=[t2,], always=[han,])
    play = Play()
    play.tasks = [t1, t2, blk,]
    tasks = play.get_tasks()
    assert t1 in tasks
    assert t2 in tasks
    assert han in tasks
    assert blk not in tasks


# Generated at 2022-06-21 00:49:57.021118
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.play import Play
    p = Play()
    p.pre_tasks = []
    p.tasks = []
    p.post_tasks = []
    assert p.get_tasks() == []



# Generated at 2022-06-21 00:50:05.363261
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ['1','2','3']
    expected = ['1','2','3']
    actual = p.get_vars_files()
    assert expected == actual, 'Expected: %s, Actual: %s' % (expected, actual)

    p.vars_files = '4'
    expected = ['4']
    actual = p.get_vars_files()
    assert expected == actual, 'Expected: %s, Actual: %s' % (expected, actual)
    print('Test get_vars_files PASS!')

if __name__ == "__main__":
    test_Play_get_vars_files()

# Generated at 2022-06-21 00:50:11.810631
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    test_Play = get_test_instance(Play)
    test_vars = test_Play.get_vars()

# Generated at 2022-06-21 00:50:13.866480
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert repr(p) == p.get_name()

# Generated at 2022-06-21 00:50:15.734317
# Unit test for method load of class Play
def test_Play_load():
    # Verify that Play class loads the datastructure into the proper attributes
    pass

# Generated at 2022-06-21 00:50:24.735744
# Unit test for method load of class Play
def test_Play_load():
    play = Play.load(data=dict())

# Generated at 2022-06-21 00:50:34.546649
# Unit test for method load of class Play
def test_Play_load():
    _data = {}
    _variable_manager = {}
    _loader = {}
    _vars = {}
    obj = Play()
    #_data = {}
    #_variable_manager = {}
    #_loader = {}
    #_vars = {}
    try:
        assert obj.load(_data, _variable_manager, _loader, _vars) == None
        assert obj.load_data(_data, _variable_manager, _loader) == None
    except Exception as e:
        print('exception raised!\n{}'.format(e))
    finally:
        print('test_Play_load finished')

test_Play_load()

# Generated at 2022-06-21 00:51:19.222241
# Unit test for method compile of class Play

# Generated at 2022-06-21 00:51:24.130176
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = '127.0.0.1'
    assert play.get_vars_files() == ['127.0.0.1']
    play.vars_files = ['127.0.0.1', '172.0.0.1']
    assert play.get_vars_files() == ['127.0.0.1', '172.0.0.1']


# Generated at 2022-06-21 00:51:35.088195
# Unit test for method load of class Play
def test_Play_load():
    '''
    Play.load() should compile a single Play
    '''

    mock_loader = MagicMock()
    mock_loader.load_from_file.side_effect = lambda x, y, z: x
    data = {
        'name': 'test',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'debug': {'msg': 'This is a task'}},
            {'meta': {'end_play': True}}
        ]
    }

    play = Play.load(data=data, loader=mock_loader)
    assert play

    # serialize the play to ensure it doesn't alter the data from the playbook
    # which could cause issues later in the execution (see issue #10557)
    play.serialize()


# Generated at 2022-06-21 00:51:40.281298
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
   p = Play()
   ods = dict()
   ds = p.preprocess_data(ods)
   assert ds == ods
   ods = dict(user='test')
   ds = p.preprocess_data(ods)
   assert ds == dict(remote_user='test')
   with pytest.raises(AnsibleAssertionError) as e_info:
      p.preprocess_data(3)


# Generated at 2022-06-21 00:51:41.193016
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass



# Generated at 2022-06-21 00:51:51.705979
# Unit test for method serialize of class Play
def test_Play_serialize():
    my_path = os.path.join(UNIT_TEST_PATH, 'test_files/test_playbook.yml' )
    pb = Playbook.load(my_path)
    pb.validate()

    assert isinstance(pb, Playbook)

    play = pb.get_plays()[0]
    data = play.serialize()
    assert isinstance(data, dict)


# Generated at 2022-06-21 00:51:52.612606
# Unit test for constructor of class Play
def test_Play():
    assert Play()

# Generated at 2022-06-21 00:52:00.031132
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    x = p.get_vars_files()
    assert x == []

    p = Play()
    p.vars_files = ['/etc/foo']
    x = p.get_vars_files()
    assert x == ['/etc/foo']

    p = Play()
    p.vars_files = '/etc/foo'
    x = p.get_vars_files()
    assert x == ['/etc/foo']

# Generated at 2022-06-21 00:52:10.993281
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = dict(
        name='my-playbook',
        hosts=['localhost'],
        tasks=[
            dict(
                shell='/bin/true',
            ),
        ],
    )
    play = Play()
    play.load_data(data)
    preprocess_data = play.preprocess_data(data)
    assert preprocess_data == dict(
        name='my-playbook',
        hosts=['localhost'],
        tasks=[
            dict(
                name='shell',
                raw_shell=None,
                shell='/bin/true',
            ),
        ],
    )


# Generated at 2022-06-21 00:52:18.861871
# Unit test for method get_name of class Play
def test_Play_get_name():
    # This test will fail if either code or error is not expected.
    # The expected result is a string: a list of hosts in this play

    # This test aims to test if input is empty list, set, or None.
    # Expected result: empty string
    p1 = Play()
    p1.hosts = None
    assert p1.get_name() == ''

    # This test aims to test if input is a list.
    # Expected result: string of list of hosts in this play
    p2 = Play()
    p2.hosts = [1, 2, 3]
    assert p2.get_name() == '1,2,3'
    p2.hosts = ['a', 'b', 'c']
    assert p2.get_name() == 'a,b,c'

    # This test aims to