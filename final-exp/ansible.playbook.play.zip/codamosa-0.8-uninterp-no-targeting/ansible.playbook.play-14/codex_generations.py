

# Generated at 2022-06-21 00:43:06.504090
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Configure Mock for Play.load()
    ds = {}
    variable_manager = {}
    loader = {}
    # Setup test results
    expected_result = Play()

    # Test function call with all parameters
    result = Play.load(ds, variable_manager=variable_manager, loader=loader)

    assert result == expected_result
    # Test function call without loader parameter
    result = Play.load(ds, variable_manager=variable_manager)

    assert result == expected_result


# Generated at 2022-06-21 00:43:09.318823
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    assert p.compile() == []


# Generated at 2022-06-21 00:43:12.425484
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    # ValueError: max_fail_percentage is not a float value and is not alphanumeric
    assert None == play.__repr__()

# Generated at 2022-06-21 00:43:17.171387
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Setup
    play = Play()

    # Case 1: No data included
    assert play.get_vars_files() == []

    # Case 2: Only one value included
    play.vars_files = 'testString'
    assert play.get_vars_files() == ['testString']

    # Case 3: Data included as list
    play.vars_files = ['testString', 'testString2']
    assert play.get_vars_files() == ['testString', 'testString2']




# Generated at 2022-06-21 00:43:25.623723
# Unit test for method compile of class Play
def test_Play_compile():
    # for python2 compat
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import AnsibleTemplate
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class FakeVariableManager:
        def __init__(self):
            self.vars = dict()
            self.extra_vars = dict()
            self.extra_vars.update({"inventory_hostname": AnsibleUnsafeText("foo")})


# Generated at 2022-06-21 00:43:38.572567
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p.name = 'test_Play_copy'
    p.remote_user = 'root'
    p.hosts = 'all' # or any other inventory or host
    p.serial = '1'
    p.connection = "ssh"
    p.gather_facts = True
    p.vars = {'var1': 'value1'}
    p.max_fail_percentage = 0
    p.tags = ['test1', 'test2']
    p.handlers = ['notify_all']
    p.tasks = ['copy_dir']

    p_copy = p.copy()
    assert p_copy is not p
    assert p_copy.name == p.name
    assert p_copy.remote_user == p.remote_user

# Generated at 2022-06-21 00:43:50.405018
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = "test-Play"
    play.connection = "test-connection"
    play.port = "test-port"
    play.remote_user = "test-remote_user"
    play.user = "test-user"
    play.become = "test-become"
    play.become_method = "test-become_method"
    play.become_user = "test-become_user"
    play.become_pass = "test-become_pass"
    play.become_exe = "test-become_exe"
    play.vars_files = "test-vars_files"
    play.vars_prompt = "test-vars_prompt"
    play.vars_pass = "test-vars_pass"


# Generated at 2022-06-21 00:44:01.862625
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    # Test a malformed play - ds should always be a dict
    with pytest.raises(AnsibleAssertionError):
        # ds should always be a dict (line 291)
        play.preprocess_data('foo')
    # Test if 'user' exists in ds
    ds = {'user': 'user'}
    ds = play.preprocess_data(ds)
    assert ds == {'remote_user': 'user'}
    # Test if 'user' doesn't exist in ds
    ds = {'foo': 'foo'}
    ds = play.preprocess_data(ds)
    assert 'remote_user' not in ds



# Generated at 2022-06-21 00:44:11.971341
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['test/ansible/playbooks/inventory'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:44:12.982455
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    pass



# Generated at 2022-06-21 00:44:25.064736
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
        test_data = dict(type='play', name='test name', hosts=['localhost'],
                         pre_tasks=[dict(type='task', name='pre task')],
                         tasks=[dict(type='task', name='task')],
                         post_tasks=[dict(type='task', name='post task')],
                         roles=['test role'])
        p = Play()
        p.load_data(test_data)
        assert len(p.get_tasks()) == 3



# Generated at 2022-06-21 00:44:26.990481
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    assert play.get_roles() == []
    assert isinstance(play, Play)


# Generated at 2022-06-21 00:44:30.879740
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import json
    play = Play()
    play.deserialize(json.loads(play.serialize()))

# Generated at 2022-06-21 00:44:40.080315
# Unit test for method serialize of class Play
def test_Play_serialize():
    p1 = Play()
    p1._load_data({'hosts': ['host1', 'host2', 'host3'],
                   'name': 'play1',
                   'gather_facts': 'yes',
                   'user': 'user1',
                   'vars': {'var1': 'val1', 'var2': 'val2'},
                   'roles': [{'name': 'role1'}, {'name': 'role2'}]})
    p1.deserialize(p1.serialize())

    p2 = Play()
    p2.deserialize(p1.serialize())
    assert p1 == p2


# Generated at 2022-06-21 00:44:41.331063
# Unit test for constructor of class Play
def test_Play():

    p = Play()
    p.ROLE_CACHE = {}
    p.BOOLEAN_GROUP = {}

# Generated at 2022-06-21 00:44:51.216405
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Check if method accepts only 'dict' as argument
    assert_raises(AnsibleAssertionError, Play().preprocess_data, 'ciao')
    assert_raises(AnsibleAssertionError, Play().preprocess_data, 123)
    # Check "user" key deprecation
    ds = dict(name='Playbook', user='test')
    expected = dict(name='Playbook', remote_user='test')
    eq_(expected, Play().preprocess_data(ds))
    # Check if 'hosts' attribute is empty
    ds = dict(hosts=[])
    assert_raises(AnsibleParserError, Play().preprocess_data, ds)
    # Check if 'hosts' has a None value in the list of strings

# Generated at 2022-06-21 00:44:57.132624
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert p.get_vars_files() == []
    p.vars_files = ['a.yml', 'b.yml']
    assert sorted(p.get_vars_files()) == ['a.yml', 'b.yml']

# Generated at 2022-06-21 00:45:10.051206
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    assert isinstance(play.get_vars_files(), list)
    assert len(play.get_vars_files()) == 0

    play.vars_files = None
    assert isinstance(play.get_vars_files(), list)
    assert len(play.get_vars_files()) == 0

    play.vars_files = 'sample_file.txt'
    assert isinstance(play.get_vars_files(), list)
    assert len(play.get_vars_files()) > 0
    assert play.get_vars_files()[0] == 'sample_file.txt'

    play.vars_files = ['sample_file.txt']
    assert isinstance(play.get_vars_files(), list)

# Generated at 2022-06-21 00:45:21.099814
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    name = 'test_role'
    role_args = {
        'name': name,
        'path': '/tmp/test_role',
        'src': 'tmp/test_role',
        'role': 'tmp/test_role',
        'collections': ['my_collection']
    }
    role = Role.load(role_args, play=None)
    roles = [role]

    # run test function
    p = Play()
    setattr(p, 'roles', roles)

    res = p.get_roles()

    assert name == res[0].name

# Generated at 2022-06-21 00:45:22.225751
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-21 00:45:43.659231
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = dict(
        name='myplay',
        connection='smart',
        remote_user=None,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        any_errors_fatal=False,
        diff=False,
        gather_facts='no',
        handlers=[],
        max_fail_percentage=None,
        serial='0',
        strategy='linear',
        no_log=False,
        when=None,
        vars_files=[],
        vars_prompt=[],
        force_handlers=False,
        tags=set([]),
        roles=[],
        environment={},
        pre_tasks=['task'],
        post_tasks=['task'],
        tasks=['task'],
    )


# Generated at 2022-06-21 00:45:47.230856
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert repr(p) == p.get_name()


# Generated at 2022-06-21 00:45:49.228907
# Unit test for method load of class Play
def test_Play_load():
    pass # TODO: Implement test_Play_load


# Generated at 2022-06-21 00:45:57.615793
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    args = {}
    p = Play().load(dict(name='1234', hosts=['host'], gather_facts='no'), variable_manager=VariableManager())
    #assert type(p.get_vars_files() is list)
    p.vars_files = '1234'
    assert type(p.get_vars_files() == list)
    p.vars_files = None
    assert type(p.get_vars_files() == list)
    assert(p.get_vars_files() == [])
    p.vars_files = ['1234']
    assert(p.get_vars_files() == ['1234'])
    p.vars_files = ['1234','5678']
    assert(p.get_vars_files() == ['1234','5678'])

# Generated at 2022-06-21 00:46:07.179151
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_obj = Play()
    play_obj._ds = [1,2,3]
    play_obj._iterator = None
    play_obj._variable_manager = "variable_manager"
    play_obj._loader = "loader"
    play_obj.name = "name"
    play_obj.hosts = "hosts"
    play_obj.hosts_pattern = "hosts_pattern"
    play_obj.remote_user = "remote_user"
    play_obj.connection = "connection"
    play_obj.port = "port"
    play_obj.any_errors_fatal = "any_errors_fatal"
    play_obj.serial = "serial"
    play_obj.transport = "transport"
    play_obj.become = "become"

# Generated at 2022-06-21 00:46:09.314471
# Unit test for constructor of class Play
def test_Play():
    pass

# Generated at 2022-06-21 00:46:11.837646
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # Play implements this correctly
    assert True


# Generated at 2022-06-21 00:46:16.778470
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {'var1':1,'var2':2}
    assert p.get_vars() == {'var1':1,'var2':2}

# Generated at 2022-06-21 00:46:28.027790
# Unit test for constructor of class Play
def test_Play():
    def test_constructor_with_no_args():
        p = Play()
        assert p._ds is None
        assert p.vars is None
        assert p.handlers is None
        assert p.meta is None
        assert p.name is None
        assert p.tags is None
        assert p.tasks is None
        assert p.hosts is None
        assert p.roles is None

        assert p._default_vars is None
        assert p._handlers is None
        assert p._meta is None
        assert p._name is None
        assert p._tags is None
        assert p._tasks is None
        assert p._hosts is None
        assert p._roles is None

        assert p._action_groups is None
        assert p._group_actions is None
        assert p._included_conditional is None

# Generated at 2022-06-21 00:46:38.011080
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test 1
    # description: Test if the method returns an empty list if the vars_files value is None
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    # Test 2
    # description: Test if the method returns a list if the vars_files value is a list
    play = Play()
    play.vars_files = ['a', 'b']
    assert play.get_vars_files() == ['a', 'b']
    # Test 3
    # description: Test if the method returns a list if the vars_files value is not a list
    play = Play()
    play.vars_files = 'a'
    assert play.get_vars_files() == ['a']


# Generated at 2022-06-21 00:46:58.550538
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible.playbook import PlayBook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    playbook = PlayBook.load("""
     - hosts: localhost
       tasks:
         - name: some task
           ping:
         - name: task 2
           debug:
             var: hostvars['localhost']
         - name: new host
           add_host:
               name: fakehost1
               ansible_host: 1.1.1.1
        """, variable_manager=VariableManager(), loader=DictDataLoader())

    play = playbook.get_plays()[0]

    variable_manager = VariableManager()

    variable_manager.extra_vars = {'hostvars': {'localhost': {'who': 'fred'}}}
    variable_manager

# Generated at 2022-06-21 00:47:10.170955
# Unit test for method copy of class Play
def test_Play_copy():

    class Play():

        def __init__(self):
            self.ROLE_CACHE = {'a': 'b'}
            self._included_conditional = True
            self._included_path = 'path'
            self._action_groups = {'a': True}
            self._group_actions = {'b': True}

        def copy(self):

            new_me = super(Play, self).copy()
            new_me.ROLE_CACHE = self.ROLE_CACHE.copy()
            new_me._included_conditional = self._included_conditional
            new_me._included_path = self._included_path
            new_me._action_groups = self._action_groups
            new_me._group_actions = self._group_actions
            return new_

# Generated at 2022-06-21 00:47:14.383305
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    playbook = Playbook()
    play = Play()
    playbook["test_Play___repr__"] = play
    assert repr(play) == "test_Play___repr__"


# Generated at 2022-06-21 00:47:24.525347
# Unit test for method load of class Play

# Generated at 2022-06-21 00:47:27.725727
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = 'test_Play'
    assert play.__repr__() == 'test_Play'


# Generated at 2022-06-21 00:47:40.901181
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    play = Play()
    play.tasks = [{'action': {'__ansible_module__': 'copy', 'dest': '.', 'content': 'ABCDEF', 'src': 'known_hosts'}},
                  {'action': {'__ansible_module__': 'template', 'dest': '/etc/foo.conf'}}]
    play.pre_tasks = [{'action': {'__ansible_module__': 'ping', 'foo': 'bar'}},
                      {'action': {'__ansible_module__': 'setup', 'filter': 'ansible_date_time'}}]

# Generated at 2022-06-21 00:47:41.930849
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    Play()


# Generated at 2022-06-21 00:47:52.970849
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.vars = {
        "ansible_connection": "winrm",
        "ansible_winrm_server_cert_validation": "ignore"
    }
    p.name = "Play 1"
    ds = [
        {
            'name': 'Install / start WinRM',
            'win_winrm': {
                'force': True,
                'state': 'started',
                'transport': 'ssl',
                'port': 5986
            }
        },
        {
            'name': 't2'
        }
    ]
    p._load_tasks(1, ds)
    #print(p.get_tasks())
    assert p.get_tasks() != []

# Generated at 2022-06-21 00:48:04.098144
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = dict(
        name='test_Play_preprocess_data',
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='whoami'))
        ]
    )

    play_ctx = Play().load_data(data)
    play_ctx.validate()
    assert play_ctx.vars == dict()
    assert play_ctx.name == 'test_Play_preprocess_data'
    assert play_ctx.hosts == 'all'
    assert play_ctx.gather_facts == 'no'
    assert play_ctx.tasks[0].module_name == 'shell'
    assert play_ctx.tasks[0].args == 'whoami'


# Generated at 2022-06-21 00:48:14.534244
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import __main__

    setattr(__main__, '__file__', '/home/NoThisIsNotMyHome/ansible/lib/ansible/playbook/play.py')

    setattr(__main__, '__builtins__', __builtins__)

# Generated at 2022-06-21 00:48:37.007533
# Unit test for method deserialize of class Play

# Generated at 2022-06-21 00:48:46.533543
# Unit test for method copy of class Play
def test_Play_copy():
    play1 = Play()
    play1._included_conditional = 'conditional'
    play1._included_path = 'path'
    play1._action_groups = {'key': 'value'}
    play1._group_actions = {'key': 'value'}
    play1.ROLE_CACHE = {'key': 'value'}
    play2 = play1.copy()
    assert play2._included_conditional == 'conditional'
    assert play2._included_path == 'path'
    assert play2._action_groups == {'key': 'value'}
    assert play2._group_actions == {'key': 'value'}
    assert play2.ROLE_CACHE == {'key': 'value'}
    assert play1._included_conditional == play2

# Generated at 2022-06-21 00:48:50.993901
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.tasks = [{'test':'test'}]
    assert play.get_tasks() == play.tasks


# Generated at 2022-06-21 00:49:01.164892
# Unit test for method load of class Play
def test_Play_load():
    data = {
        'hosts': [
            'localhost'
        ],
        'vars': {'name': 'test'},
        'tasks': [
            {
                'debug': {
                    'msg': '{{name}}'
                }
            }
        ]
    }

    results = Play.load(data, variable_manager=None)
    assert results._ds['hosts'] == ['localhost']
    assert results._ds['vars']['name'] == 'test'
    assert results._ds['tasks'][0]['debug']['msg'] == '{{name}}'

    data = {'name': 'test_play', 'tasks': ['task_a', 'task_b']}
    results = Play.load(data, variable_manager=None)

# Generated at 2022-06-21 00:49:02.691057
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass


# Generated at 2022-06-21 00:49:03.578724
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    assert False

# Generated at 2022-06-21 00:49:12.851314
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    vars = dict(ansible_connection=dict(type="ssh",user="root",password="password",host="10.60.2.1"))
    tasks = [{"hosts": "all","gather_facts": "no", "name": "Test-1","connection": "local","tasks": [{"action": {"module": "os_server","name": "test_server1"},"when": "item == 'create'"},{"action": {"module": "os_server","name": "test_server1"},"when": "item=='delete'"}]}]
    data = dict(hosts="10.60.2.1",user="root",become=None,vars=vars,tasks=tasks)
    new_play = play.deserialize(data)

# Generated at 2022-06-21 00:49:19.026191
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    class Dummy(object):
        pass

    def get_roles_from_Play(p):
        return p.get_roles()

    test_roles = [Dummy(), Dummy()]
    p = Play(dict())
    p.roles = test_roles

    assert get_roles_from_Play(p) == test_roles

# Generated at 2022-06-21 00:49:30.344265
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.ROLE_CACHE = {'cache1': 'cache1', 'cache2': 'cache2'}
    play._included_conditional = 'include_conditional'
    play._included_path = 'include_path'
    play._action_groups = {'group1': 'group1', 'group2': 'group2'}
    play._group_actions = {'action1': 'action1', 'action2': 'action2'}
    role1 = Play()
    role2 = Play()
    roles = [role1, role2]
    play.roles = roles
    data = play.serialize()
    assert data['roles'][0] == role1
    assert data['roles'][1] == role2

# Generated at 2022-06-21 00:49:39.687183
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({'roles': [], 'included_path': "./test/test.yaml", 'action_groups': {}, 'group_actions': {}})
    assert p._included_path == "./test/test.yaml"
    assert len(p._action_groups) == 0
    assert len(p._group_actions) == 0
    assert len(p.get_roles()) == 0


# Generated at 2022-06-21 00:50:05.182408
# Unit test for method compile of class Play
def test_Play_compile():
    from ansible.parsing import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import include_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.errors import AnsibleError
    from ansible.utils.listify import listify_lookup_plugin_terms


# Generated at 2022-06-21 00:50:09.936228
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    """
    Test for Play method: deserialize
    """
    p = Play()
    assert p.deserialize(None) is None

    assert  p.deserialize('string') is None

# Generated at 2022-06-21 00:50:20.320294
# Unit test for method deserialize of class Play

# Generated at 2022-06-21 00:50:34.058823
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import json
    play = Play()
    data = {
        "name": "test",
        "id": 1,
        "description": "test",
        "hosts": "all",
        "remote_user": "root",
        "become": True,
        "become_user": "root",
        "vars": {},
        "roles": [],
        "tasks": []
    }
    play.deserialize(data)
    assert play.name == 'test'
    assert play.hosts == 'all'
    assert play.remote_user == 'root'
    assert play.become == True
    assert play.become_user == 'root'
    assert play.id == 1
    assert play.description == 'test'
    assert play.vars == {}
    assert play.ro

# Generated at 2022-06-21 00:50:41.345511
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    #Verify the deserialize method
    assert 0 == len(p.roles)
    p.deserialize({'my_data_dict': {'key1': 'val1', 'key2': 'val2'}})
    assert not  hasattr(p, 'my_data_dict')

# Generated at 2022-06-21 00:50:42.762058
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert p == p.get_name()


# Generated at 2022-06-21 00:50:55.711392
# Unit test for method load of class Play
def test_Play_load():
    def load_data(play, ds):
        role = Role()
        role.load_data(ds, play=play)
        return role


# Generated at 2022-06-21 00:51:03.028647
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''
    Unit test for method get_name of class Play
    '''
    my_play = Play().load(dict(name='test name', type='play'), variable_manager=None, loader=None)
    name = my_play.get_name()
    assert name == 'test name'


# Generated at 2022-06-21 00:51:05.875885
# Unit test for method compile of class Play
def test_Play_compile():
  data = {'hosts': 'localhost'}
  play = Play().load(data, variable_manager=None, loader=None)
  # TODO: uncomment
  # assert play is not None
  # assert play.compile() is not None
  

# Generated at 2022-06-21 00:51:19.181895
# Unit test for constructor of class Play
def test_Play():
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()

# Generated at 2022-06-21 00:51:38.685722
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p.load_data({'name' : 'test_Play_copy', 
                 'hosts' : 'localhost', 
                 'gather_facts' : 'no', 
                 'tasks' : [{'name': 'test_Play_copy', 
                             'debug': 'msg="test copy"'}]})
    new_me = p.copy()
    assert p.name == new_me.name, 'name attr are not equal'
    assert p._ds['gather_facts'] == new_me._ds['gather_facts'], 'gather_facts attr are not equal'
    new_me_tasks = new_me.get_tasks()
    assert isinstance(new_me_tasks, list), 'tasks is not a list'

# Generated at 2022-06-21 00:51:47.590517
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    _name = 'play_name'
    play.name = _name
    assert play.get_name() == _name

    play.name = None
    _hosts = ['host1', 'host2', 'host3']
    play.hosts = _hosts
    assert play.get_name() == ','.join(_hosts)

    play.hosts = None
    assert play.get_name() == ''

# Generated at 2022-06-21 00:52:00.546541
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()

    # Set up a play and some blocks
    play_name = 'my play'
    p.name = play_name

    pre_block = Block(parent_block=p)
    task1 = Task()
    task1.name = 'Task 1'
    task2 = Task()
    task2.name = 'Task 2'
    pre_block.block = [task1, task2]
    p.pre_tasks = [pre_block]

    block1 = Block(parent_block=p)
    block1.name = 'my block'
    task3 = Task()
    task3.name = 'Task 3'
    task4 = Task()
    task4.name = 'Task 4'
    block1.block = [task3, task4]
    p.tasks = [block1]



# Generated at 2022-06-21 00:52:02.206537
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-21 00:52:13.967902
# Unit test for method copy of class Play
def test_Play_copy():
    p1 = Play()
    p1_copy = p1.copy()
    assert hasattr(p1_copy, 'ROLE_CACHE')
    assert isinstance(p1_copy.ROLE_CACHE, dict)
    assert hasattr(p1_copy, '_included_conditional')
    assert hasattr(p1_copy, '_included_path')
    assert hasattr(p1_copy, '_action_groups')
    assert isinstance(p1_copy._action_groups, dict)
    assert hasattr(p1_copy, '_group_actions')
    assert isinstance(p1_copy._group_actions, dict)
    assert hasattr(p1_copy, '_ds')
    assert isinstance(p1_copy._ds, dict)

# Generated at 2022-06-21 00:52:27.428089
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.name = 'my_play'
    p.vars = {'key': 'value'}
    p.vars_prompt = [{'name': 'key1', 'prompt': 'prompt1'}]
    vars_files = [{'name': 'file1', 'file': 'file1.yml'}]
    p.vars_files = vars_files
    role1 = Role()
    role1.vars = {'role_var': 'value1'}
    role1.get_name = lambda: 'role1'
    role2 = Role()
    role2.vars = {'role_var': 'value2'}
    role2.get_name = lambda: 'role2'
    p.roles = [role1, role2]


# Generated at 2022-06-21 00:52:35.015164
# Unit test for method load of class Play
def test_Play_load():
    from ansible import context
    import ansible.parsing.yaml.objects

    temp_load = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.load

    ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.load = lambda self: "encrypted string"


# Generated at 2022-06-21 00:52:35.963799
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    check_preprocess_data_results(Play.preprocess_data)


# Generated at 2022-06-21 00:52:40.369691
# Unit test for method serialize of class Play
def test_Play_serialize():
    #the method serialize is a static method, we can create an empty object for test
    p = Play()
    p.serialize()
