

# Generated at 2022-06-21 00:43:14.179292
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import ansible.constants as C
    p1 = Play()

    if os.path.exists('/etc/test_test1') or os.path.exists('/etc/test2'):
        try:
            shutil.rmtree('/etc/test_test1')
            shutil.rmtree('/etc/test2')
        except:
            pass
    else:
        os.mkdir('/etc/test_test1')
        os.mkdir('/etc/test2')

    r1 = Role()
    r1.name = 'my_role1'

    f1 = Task()
    f1.action = 'shell'
    f1.args = 'ls -l /etc/'
    f1.name = 'my_task1'

# Generated at 2022-06-21 00:43:18.301317
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    """test_Play_get_roles"""
    play = Play()
    play.get_roles()


# Generated at 2022-06-21 00:43:22.091397
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'roles': [{'name': 'some_role', 'tasks': [{'action': {'module': 'setup'}, 'register': 'setup_result'}]}]})
    assert play.roles[0].tasks[0].module == 'setup'


# Generated at 2022-06-21 00:43:30.653349
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['./test/test_vars_file1.yml', './test/test_vars_file2.yml']
    assert play.get_vars_files() == ['./test/test_vars_file1.yml', './test/test_vars_file2.yml']
    play.vars_files = './test/test_vars_file1.yml'
    assert play.get_vars_files() == ['./test/test_vars_file1.yml']

# Generated at 2022-06-21 00:43:34.557343
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p._handlers = [{"hello": "world"}]
    assert p.get_handlers() == [{"hello": "world"}]
    # Make sure we are returning the copy, not the original
    assert p.get_handlers() != p._handlers


# Generated at 2022-06-21 00:43:38.186946
# Unit test for constructor of class Play
def test_Play():
    play_ds = dict(name="Test Play", hosts='localhost', tasks=[])
    play = Play(play_ds)
    assert play.name == "Test Play"
    assert play.hosts == 'localhost'
    assert isinstance(play.tasks, list)


# Generated at 2022-06-21 00:43:40.916654
# Unit test for method __repr__ of class Play
def test_Play___repr__():

    # Call method and check result
    # Just calls get_name()
    pass

# Generated at 2022-06-21 00:43:44.302521
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    handler = task.Handler()
    play.handlers.append(handler)
    # The method returns all the handlers in the Play (a copy)
    assert play.get_handlers() == play.handlers
    assert play.get_handlers() is not play.handlers


# Generated at 2022-06-21 00:43:47.245123
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play1 = Play()
    role = Role()
    play1.roles = [role]
    result = play1.compile_roles_handlers()
    assert result == []

# Generated at 2022-06-21 00:43:55.611378
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    playbook = YAML().load(dedent("""
        - hosts: all
          tasks:
          - name: test
            debug:
              msg: "test"
        """))
    
    # Play.__init__()
    Play_instance = Play()
    
    # Play.preprocess_data(self, ds)
    Play_instance.preprocess_data(playbook)
    

# Generated at 2022-06-21 00:44:10.561466
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    try:
        p = Play()
        name = p.get_name()
        assert name == ''
    except Exception as e:
        print("EXCEPTION!!!!", e)


# Generated at 2022-06-21 00:44:11.589831
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    assert True == True



# Generated at 2022-06-21 00:44:25.240943
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.playbook.play_context import PlayContext
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    fake_loader = DictDataLoader({
        "t.yml": """
        - name: test
        """,
        "n.yml": """
        ---
        - name:  test
        """,
        "v.yml": """
        ---
        - hosts: all
          vars:
            host: "6"
        - hosts: all
          vars:
            host: "8"
        """
    })
    fake_inventory = InventoryManager(loader=fake_loader, sources='localhost,')

# Generated at 2022-06-21 00:44:38.948056
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    class AnsiblePlayTest(unittest.TestCase):
        def test_Play_compile_roles_handlers(self):
            # Testing that the compile_roles_handlers of the Play class compiles roles handlers.
            # First we get the path of the playbook to load.
            role_playbook = os.path.join(os.path.dirname(__file__), 'test_data/test_playbook_role.yml')
            # Getting the playbook data and creating the Play instance.
            data = open(role_playbook, 'rb').read()
            play = Play.load(data)
            # Calling the method compile_roles_handlers of the Play instance.
            role_handlers = play.compile_roles_handlers()
            # Testing the result of the compile_roles_handlers method.

# Generated at 2022-06-21 00:44:48.769901
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # datastructure used by the test_Play_preprocess_data
    data = {'user': 'root', 'sudo': True}

    # initialize the play object
    p = Play()
    # preprocess the data
    p.preprocess_data(data)

    # compare the value of 'user' key
    assert(data['user'] == 'root')
    # compare the value of 'sudo' key
    assert(data['sudo'] == True)
    # compare the value of 'remote_user' key
    assert(data.get('remote_user') == 'root')


# Generated at 2022-06-21 00:45:01.014144
# Unit test for method copy of class Play
def test_Play_copy():
    obj1 = Play()
    obj1.ROLE_CACHE = {"ROLE_CACHE": "value"}
    obj1.hosts = "hosts"
    obj1.name = "name"
    obj1.gather_facts = "gather_facts"
    obj1.vars_prompt = "vars_prompt"
    obj1.vars_files = "vars_files"
    obj1._included_conditional = "_included_conditional"
    obj1.vars = "vars"
    obj1.roles = "roles"
    obj1.tasks = "tasks"
    obj1._included_path = "_included_path"
    obj1.post_tasks = "post_tasks"

# Generated at 2022-06-21 00:45:03.525580
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    test_play = Play()
    test_play.roles = [3,4]
    result = test_play.get_roles()
    assert result == [3,4]
    return True


# Generated at 2022-06-21 00:45:08.638669
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Attempting to create an instance of Play
    # Play should have a name of 'test_Play_get_name'

    # Create an instance of Play
    test_play = Play()
    test_play.name = 'test_Play_get_name'

    assert test_play.get_name() == 'test_Play_get_name'
    assert test_play.name == 'test_Play_get_name'



# Generated at 2022-06-21 00:45:20.594565
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Check to see whether the method get_roles works with an empty play.
    host_list = "localhost,jetbrains.com"
    play_source =  dict(
            name = "Ansible Play",
            hosts = host_list,
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=dict()))
            ]
        )
    p = Play().load(play_source, variable_manager=None, loader=None)
    assert isinstance(p.get_roles(), list)
    assert len(p.get_roles()) == 0 

# Generated at 2022-06-21 00:45:24.017794
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play=Play()
    assert True # TODO: implement your test here


# Generated at 2022-06-21 00:45:39.801239
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    """
        This function is to test the function get_handlers of class Play.
        The purpose of this function is to get its handlers.
        Return:
            Return the handlers of the play.
    """
    assert Play()


# Generated at 2022-06-21 00:45:52.923832
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    task_1 = Task()
    task_2 = Task()
    play.tasks.append(task_1)
    play.tasks.append(task_2)
    assert play.get_tasks() == [task_1, task_2]
    
    rescue = Block()
    rescue.rescue.append(task_1)
    play.tasks.append(rescue)
    assert play.get_tasks() == [task_1, task_2, task_1]
    
    always = Block()
    always.always.append(task_2)
    play.tasks.append(always)
    assert play.get_tasks() == [task_1, task_2, task_1, task_2]

# Generated at 2022-06-21 00:46:01.078177
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    rd1 = RoleDefinition()    
    p = Play()
    p.roles = [Role(role_definition=rd1)]
    p.get_roles()



# Generated at 2022-06-21 00:46:08.280129
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = {'name': 'My Play', 'user': 'root', 'hosts': 'all'}
    p = Play.load(data)
    assert p._ds == {'name': 'My Play', 'remote_user': 'root', 'hosts': 'all'}

# Generated at 2022-06-21 00:46:18.262754
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Set up mock
    for i in range(1):
        with patch('ansible.parsing.dataloader.DataLoader') as mock_DataLoader:
            mock_DataLoader_instance = mock_DataLoader.return_value

            with patch('ansible.vars.manager.VariableManager') as mock_VariableManager:
                mock_VariableManager_instance = mock_VariableManager.return_value

                with patch('ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode') as mock_AnsibleVaultEncryptedUnicode:
                    mock_AnsibleVaultEncryptedUnicode_instance = mock_AnsibleVaultEncryptedUnicode.return_value


# Generated at 2022-06-21 00:46:20.214870
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 1
    play.hosts = ['a']
    assert play.get_name() == 'a'

# Generated at 2022-06-21 00:46:33.393073
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # prepare the test
    playbook_path = os.path.join('lib', 'ansible', 'playbooks')
    folder_name = os.path.join(playbook_path, 'z_playbook_for_unit_test')
    file_name = os.path.join(folder_name, 'playbook_for_unit_test.yaml')

    # test
    # manually create a Play object and set vars_files to be None
    pb_object = Play()
    vfs = pb_object.get_vars_files()
    assert isinstance(vfs, list)
    assert len(vfs) == 0

    # manually create a Play object and set vars_files to be a string
    pb_object = Play()
    pb_object.vars_files = file_name
    vfs

# Generated at 2022-06-21 00:46:46.481168
# Unit test for method serialize of class Play
def test_Play_serialize():
    '''
    unit test for serialize method in class Play
    '''
    play = Play()
    play.vars = {'var1':'test1'}

    play.tasks = [
        dict(action=dict(module='test_module1')),
        dict(action=dict(module='test_module2')),
        dict(action=dict(module='test_module3')),
        dict(action=dict(module='test_module4')),
        dict(action=dict(module='test_module5')),
    ]


# Generated at 2022-06-21 00:46:58.297322
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p is not None
    assert p.name == ''
    assert p.remote_user == 'root'
    assert p.connection == 'smart'
    assert p.port == 22
    assert p.gather_facts == True
    assert p.max_fail_percentage == None
    assert p.serial == None
    assert p.strategy == 'linear'
    assert p.sudo == False
    assert p.sudo_user == ''
    assert p.sudo_pass == False
    assert p.transport == None
    assert p.tags == frozenset([])
    assert p.any_tags_match is None
    assert p.skip_tags == frozenset([])
    assert p.force_handlers == False
    assert p.delegate_to == None
    assert p.tasks == []

# Generated at 2022-06-21 00:47:00.074332
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    test_Play = Play()
    assert Play.__repr__(test_Play) == test_Play.get_name()


# Generated at 2022-06-21 00:47:29.726560
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    #Test copy() method
    assert play.copy() is not None
    roles = []
    #Test get_roles() method
    assert len(play.get_roles()) == len(roles)
    #Test serialize() method
    assert play.serialize() is not None
    #Test get_vars_files() method
    assert play.get_vars_files() is not None
    #Test get_handlers() method
    assert play.get_handlers() is not None
    #Test get_tasks() method
    assert play.get_tasks() is not None
    #Test get_vars() method
    assert play.get_vars() is not None


# Generated at 2022-06-21 00:47:38.270004
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # initialize a new object of class Play
    play = Play()
    play.vars_files = ["path1", "path2"]
    vars_files = play.get_vars_files()
    assert vars_files == ["path1", "path2"]

    play.vars_files = "path"
    vars_files = play.get_vars_files()
    assert vars_files == ["path"]


# Generated at 2022-06-21 00:47:46.793428
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.parsing.dataloader import DataLoader

    # Make sure the test_data directory is on the Ansible module search path
    paths = os.path.join(DATA_PATH, 'parsing', 'playbooks')
    loader = DataLoader()
    loader.set_basedir(paths)

    # load a play
    play = Play.load(loader=loader, variable_manager=VariableManager(), use_handlers=True, play_ds=[{'name': 'Test play', 'hosts': 'all'}])

    # create a role
    role_ds = loader.load_from_file(os.path.join(paths, 'handlers', 'handlers_play.yaml'))

# Generated at 2022-06-21 00:47:52.839693
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.name = 'test'
    p.hosts = 'webservers'
    p.vars = {}
    p._ds = {}
    p.roles = ['role1', 'role2']
    p._included_path = '/etc/ansible/test'
    p._action_groups = {}
    p._group_actions = {}

    ps = p.serialize()

    assert ps == {'roles': ['role1', 'role2'],
      'included_path': '/etc/ansible/test',
      'name': 'test',
      'hosts': 'webservers',
      'vars': {},
      'action_groups': {},
      'group_actions': {},
      '_ds': {}}


# Generated at 2022-06-21 00:48:04.292142
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader


    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = Options(connection='smart', module_path=['/to/mymodules'], forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)

    loader = DataLoader()  # Takes care of finding and reading yaml, json and ini files

    variable_manager = VariableManager()  # Stores variables available to Ansible tasks
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=options)
    variable_manager.options_vars = load

# Generated at 2022-06-21 00:48:06.641371
# Unit test for method copy of class Play
def test_Play_copy():
    pass

    # FIXME: Add unit test for method copy of class Play
    # FIXME: Add unit test for method copy of class Play
    # FIXME: Add unit test for method copy of class Play



# Generated at 2022-06-21 00:48:15.721913
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # verify that the 'user' key is deprecated, and that uses of it
    # are transformed into 'remote_user'

    play = Play()

    # legacy style v1 playbook
    ds = dict(
        name='test',
        hosts='localhost',
        user='root',
        tasks=[{'name': 'foo', 'action': 'bar'}]
    )
    ds = play.preprocess_data(ds)
    assert not 'user' in ds
    assert 'remote_user' in ds
    assert ds['remote_user'] == 'root'

    # playbook with invalid user entry
    ds = dict(
        name='test',
        hosts='localhost',
        tasks=[{'name': 'foo', 'action': 'bar'}]
    )
    ds['user'] = None

# Generated at 2022-06-21 00:48:25.503343
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Load data
    ds = {'name': 'play_name', 'hosts':'all', 'roles':[]}

    # Create a Play
    p = Play.load(
        ds,
        variable_manager=variable_manager,
        loader=loader
    )

    # Create blocks
    b = Block.load(
        ds=None,
        play=p,
        variable_manager=variable_manager,
        loader=loader
    )

    # Create a task
    t = Task.load(
        data={'name': 'task_name'},
        play=p,
        block=b,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=variable_manager,
        loader=loader
    )

    # Create a task2

# Generated at 2022-06-21 00:48:33.680200
# Unit test for method load of class Play
def test_Play_load():
    # Set up mock objects
    loader_manager = mock.Mock()
    variable_manager = mock.Mock()
    vars = mock.Mock()
    ds = {}
    # Set return values of mocked methods
    vars.copy.return_value = {}
    # Create instance of object to test
    play = Play()
    # Test
    play.load(data=ds, variable_manager=variable_manager, loader=loader_manager, vars=vars)



# Generated at 2022-06-21 00:48:41.532611
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.parsing.mod_args import ModuleArgsParser

    # create 1 play
    data = dict(
        name='test_play',
        hosts='localhost',
        tasks=[],
    )
    play = Play.load(data, loader=DictDataLoader())
    # test get_name
    assert play.get_name() == play.name


# Generated at 2022-06-21 00:49:16.501458
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    def _run_module(conn, module_name, module_args, tmp=None, task_vars=None,
                    inject=None, complex_args=None, **kwargs):
        arg_strings_CLEANED = str(module_args)
        arg_strings_CLEANED = arg_strings_CLEANED.replace("\\", "/")
        arg_strings_CLEANED = arg_strings_CLEANED.replace("//", "/")

# Generated at 2022-06-21 00:49:22.947382
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_data = {'roles': [], 'tasks': [], 'name': 'test', 'vars_files': [], 'handlers': [], 'vars': {}, 'pre_tasks': [], 'action_groups': {}}
    p = Play()
    try:
        p.deserialize(test_data)
    except:
        assert False, "deserialize fails for valid data"


# Generated at 2022-06-21 00:49:33.300041
# Unit test for method deserialize of class Play

# Generated at 2022-06-21 00:49:38.051398
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'first_play'
    assert play.get_name() == 'first_play'

    play.name = None
    play.hosts = ['localhost', ]
    assert play.get_name() == 'localhost'

    play.name = None
    play.hosts = ['127.0.0.1', 'localhost']
    assert play.get_name() == '127.0.0.1,localhost'


# Generated at 2022-06-21 00:49:39.609213
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    assert 1+1 == 2

# Generated at 2022-06-21 00:49:48.846986
# Unit test for constructor of class Play
def test_Play():
    from ansible.playbook.block import Block
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    # Initialize Variables
    play_ds = dict(
        name='Test Play',
        hosts='all',
        remote_user='test_user',
        connection='test_connection',
        gather_facts='no',
        become='false',
        become_method='test_become_method',
        become_user='test_become_user',
        serial='test_serial',
        max_fail_percentage='test_max_fail_percentage',
        strategy='test_strategy',
        vars=[],
        roles=[]
    )

    variable_manager = VariableManager()

# Generated at 2022-06-21 00:49:56.897077
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    task1 = Task()
    task1.name = "foo"
    task1.action = 'lineinfile'
    task1.args = {'dest': '/etc/foo', 'regexp': 'alpha', 'line': 'beta'}
    task2 = Task()
    task2.name = "foo"
    task2.action = 'lineinfile'
    task2.args = {'dest': '/etc/foo', 'regexp': 'alpha', 'line': 'beta'}
    task3 = Task()
    task3.name = "foo"
    task3.action = 'lineinfile'
    task3.args = {'dest': '/etc/foo', 'regexp': 'alpha', 'line': 'beta'}
    play=Play()
    play.name="test_play"

# Generated at 2022-06-21 00:50:00.360325
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    result = p.get_handlers()
    assert result == []
    assert type(result) == list


# Generated at 2022-06-21 00:50:05.481001
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    p.get_name()
    if p.__repr__() == p.get_name():
        print("test_Play___repr__ success")
    else:
        print("test_Play___repr__ failed")

# Generated at 2022-06-21 00:50:10.305185
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()
    test_play.roles = []
    block_list = test_play.compile_roles_handlers()
    assert_equal(block_list, [])

# Generated at 2022-06-21 00:51:09.116965
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    host, port = doctest_namespace['inventory_manager'].get_host_details('test_all')
    connection = Connection(host)
    play._variable_manager.set_host_variable(connection, 'ansible_connection', 'local')
    play._variable_manager.set_host_variable(connection, 'ansible_python_interpreter', 'python')
    play._variable_manager.set_host_variable(connection, 'ansible_inventory_sources', ['localhost,'])
    play._variable_manager.extra_vars = {'ansible_python_interpreter': 'python', 'ansible_connection': 'local'}
    import json

# Generated at 2022-06-21 00:51:11.837816
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    instance = Play()
    assert isinstance(instance.get_roles(), list)

# Generated at 2022-06-21 00:51:21.017035
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Unit test for method compile_roles_handlers of class Play
    '''
    # Dummy Role
    class DummyRole(Role):
        def __init__(self):
            super(DummyRole, self).__init__()
            self.name = "DummyRole"
            self.handlers = ['DummyHandler']


    test_play = Play()
    test_play.handlers = []

    # Test with the case of no roles
    assert test_play.compile_roles_handlers() == test_play.handlers

    # Test with the case of one role with handlers
    test_play.roles.append(DummyRole())

    expected_handlers = copy.deepcopy(test_play.handlers)

# Generated at 2022-06-21 00:51:21.940368
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-21 00:51:23.802829
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.compile_roles_handlers()
    pass



# Generated at 2022-06-21 00:51:33.260208
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():

    # Create play object
    p = Play()

    # Create a list of dictionaries to add to the handler list
    ds = [{'task1': 'task one'}, {'tags': ['test']}, {'name': 'test', 'task': 'test'}]

    # Set the handlers field of the play object to a list of dictionaries
    p.handlers = ds

    # Print out the field handlers, run the get_handlers method, and print the first returned handler
    print("Printing the field handlers: " + str(p.handlers))
    h = p.get_handlers()
    print("Printing the first handler: " + str(h[0]))


# Generated at 2022-06-21 00:51:34.658375
# Unit test for constructor of class Play
def test_Play():
    play = Play()

    assert play is not None
    assert isinstance(play, Play)

# Generated at 2022-06-21 00:51:42.295814
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()

    p.roles = [Role()]
    p.roles[0]._role_path = '/test/testing'

    p._included_path = '/test/test'
    p._action_groups = {'test': ('test', 'test', 'test')}
    p._group_actions = {'test': 'test'}

    assert p.vars == {}
    assert p._ds == {}
    assert p.vars_files is None
    assert p.roles[0]._role_path == '/test/testing'
    assert p._included_path == '/test/test'
    assert p._action_groups == {'test': ('test', 'test', 'test')}
    assert p._group_actions == {'test': 'test'}

    data = p.serialize()

# Generated at 2022-06-21 00:51:45.366340
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    assert p.preprocess_data({}) == {}


# Generated at 2022-06-21 00:51:49.182682
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data={"type":"Play","name":"test_play","hosts":"all"}
    p=Play()
    p.deserialize(data)
    expected_result="test_play"
    assert p.get_name()==expected_result


# Generated at 2022-06-21 00:52:42.019968
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # Setup
    play = Play()

    # Exercise
    repr = play.__repr__()

    # Verify
    assert repr == ''

    # Cleanup - none necessary

