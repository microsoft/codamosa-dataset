

# Generated at 2022-06-21 00:43:01.266331
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

    # Method get_handlers of class Play
    # Minimal example
    #_______________________________________________________________________
    # Set up the test environment
    p = Play()
    p.handlers = [Handler()]
    # Perform the test
    result = p.get_handlers()
    # Check the expected result
    assert isinstance(result, list)
    assert isinstance(result[0], Handler)

    #

# Generated at 2022-06-21 00:43:10.017142
# Unit test for constructor of class Play
def test_Play():
    # verify default constructor of class Play
    play = Play()
    assert play.name == ''
    assert play.hosts is None
    assert play.connection == 'smart'
    assert play.remote_user == 'root'
    assert play.max_fail_percentage == 0
    assert play.remote_port == 22
    assert play.vars == {}
    assert play.vars_prompt == []
    assert play.vars_files == []
    assert play.tags == []
    assert play.roles == []
    assert play.handlers == []
    assert play.tasks == []
    assert play.default_vars == []
    assert play.vault_password == ''
    assert play.transport == C.DEFAULT_TRANSPORT

    # verify remap constructor of class Play

# Generated at 2022-06-21 00:43:17.752024
# Unit test for method serialize of class Play
def test_Play_serialize():
    my_var = dict(
        a=1,
        b=2,
        c=3,
    )
    my_roles = list(
        dict(
            name="role%d" % i,
            hosts="host%d" % i,
            tasks=['task%d' % i]
        )
        for i in range(1, 3)
    )
    my_play = dict(
        name="my_play",
        hosts="some_host",
        vars=my_var,
        roles=my_roles,
    )

    play = Play.load(my_play)
    serialized = play.serialize()

    assert_equal(set(serialized['vars']), set(my_var))
    assert_equal(len(serialized['roles']), 2)
   

# Generated at 2022-06-21 00:43:18.431231
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-21 00:43:28.037821
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    _loader = DictDataLoader({
        "multi.yml": """
        - name: test 1
          hosts: all
          gather_facts: no
          tasks: [ test1 ]
          handlers:
              - test handler 1
              - test handler 2
          pre_tasks: [ test pre task 1 ]
          post_tasks: [ test post task 1 ]
        """,
        "single.yml": """
        - name: test 2
          hosts: all
          gather_facts: no
          tasks:
              - test task 1
              - test task 2
          handlers: [ test handler ]
        """,
    })

    # Test method with multiple handlers

# Generated at 2022-06-21 00:43:40.189659
# Unit test for constructor of class Play
def test_Play():
    play_one = Play()
    assert play_one._ds is None
    #assert play_one.connection is None
    assert not play_one.become
    assert not play_one.become_method
    assert play_one.become_user == ''
    assert not play_one.become_ask_pass
    assert not play_one.delegate_to
    assert not play_one.environment
    assert not play_one.hosts
    assert not play_one.max_fail_percentage
    assert not play_one.name
    assert not play_one.no_log
    assert not play_one.only_tags
    assert not play_one.other_tags
    assert not play_one.remote_user
    assert not play_one.roles
    assert not play_one.serial
    assert not play

# Generated at 2022-06-21 00:43:51.259248
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    #Create a mock ansible playbook, as an instance of class Play.
    #Insert mock roles in the list of roles from the playbook
    #Setup the pre-task and post-task values to be empty, there are no tasks
    #Insert mock handlers in the list of handlers from the playbook
    play = Play()
    play.roles = [MockRole(), MockRole()]
    play.pre_tasks = []
    play.post_tasks = []
    play.handlers = [MockHandler(), MockHandler()]
    play.tasks = []
    #Check that the method compile_roles_handlers returns the expected
    #result, which is a list 3 mock handlers.
    assert play.compile_roles_handlers() == [MockHandler(), MockHandler(), MockHandler()]


# Generated at 2022-06-21 00:44:03.318783
# Unit test for method compile of class Play
def test_Play_compile():
    m = Mock()
    m.roles.return_value = [1,2,3]
    m.pre_tasks.return_value = [4,5,6]
    m._compile_roles.return_value = [7,8,9]
    m.tasks.return_value = [10,11,12]
    m.post_tasks.return_value = [13,14,15]
    assert m.compile() == [4,5,6, 1,2,3, 7,8,9, 10,11,12, 13,14,15]
    m.roles.assert_called_with()
    m.pre_tasks.assert_called_with()
    assert m._compile_roles.call_count == 1
    m.tasks.assert_called_with()

# Generated at 2022-06-21 00:44:13.199484
# Unit test for method compile of class Play
def test_Play_compile():
    def get_play(play_dict):

        def get_block_dict(block_dict):
            if not isinstance(block_dict, dict):
               return {}
            if 'tasks' in block_dict.keys():
                for ele in block_dict['tasks']:
                    if not isinstance(ele, Task):
                        block_dict['tasks'] = [Task.load(ele)]
            return block_dict

        if 'pre_tasks' in play_dict.keys():
            play_dict['pre_tasks'] = [Block.load(get_block_dict(block_dict), Task()) for block_dict in play_dict['pre_tasks']]

# Generated at 2022-06-21 00:44:19.464604
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Arrange
    p = Play(loader =DictDataLoader({}), variable_manager=VariableManager())

    ds = {'hosts': 'hosts'}
    # Act
    p.preprocess_data(ds)
    # Assert
    assert(ds == {'hosts': 'hosts'})



# Generated at 2022-06-21 00:44:42.102346
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.get_name_result = 'test'

    result = repr(play)

    assert result == 'test'


# Generated at 2022-06-21 00:44:50.631616
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    assert p.compile() == []

    # Test with a basic Play
    p = Play()
    p.tasks = [1, 2]
    assert p.compile() == [1, 2]

    # Test with a basic Play with handlers
    p = Play()
    p.tasks = [1]
    p.handlers = [2]
    assert p.compile() == [1, 2]

    # Test with a basic Play with roles
    p = Play()
    p.roles = [1, 2]
    p.handlers = [3]
    assert p.compile() == [1, 2, 3]


# Generated at 2022-06-21 00:44:54.912664
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.name = '1'
    p.tasks = 't'
    assert p.get_tasks() is 't'

# Generated at 2022-06-21 00:45:07.894066
# Unit test for method get_name of class Play
def test_Play_get_name():
    """
    Tests get_name() in class Play"""
    # Given the following inputs
    obj = Play()


    # When the following methods are invoked
    obj.get_name()


    # Then the following assertions hold
    assert obj.name == ""

    # Case 2
    # Given the following inputs
    obj = Play()
    obj.name = "name"


    # When the following methods are invoked
    obj.get_name()


    # Then the following assertions hold
    assert obj.name == "name"

    # Case 3
    # Given the following inputs
    obj = Play()
    obj.hosts = ["host1", "host2"]


    # When the following methods are invoked
    obj.get_name()


    # Then the following assertions hold
    assert obj.name == "host1,host2"

# Generated at 2022-06-21 00:45:19.056153
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pl=Play()
    data=pl.serialize()
    pl1=Play()
    pl1.deserialize(data)
    assert pl1._ds==pl._ds
    assert pl1.ROLE_CACHE==pl.ROLE_CACHE
    assert pl1._included_conditional==pl._included_conditional
    assert pl1._included_path==pl._included_path
    assert pl1._action_groups==pl._action_groups
    assert pl1._group_actions==pl._group_actions


# Generated at 2022-06-21 00:45:32.448949
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = {
		"user": "foo",
		"hosts": "localhost",
		"name": "install mongodb",
		"tasks": [
			{
				"name": "install on debian/ubuntu systems",
				"apt": "name=mongodb state=present",
				"when": "ansible_os_family == 'Debian"
			},
			{
				"name": "install on Centos/RHEL systems",
				"yum": "name=mongodb state=present",
				"when": "ansible_os_family == 'RedHat"
			}
		]
	}
    result = play.preprocess_data

# Generated at 2022-06-21 00:45:41.774300
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

    data = {
        "name": "toto",
        "id": "123456"
    }
    play.deserialize(data)

    assert play.name == "toto"
    assert play.playbook_id == "123456"
    assert play.connection == "ssh"
    assert play.user == "root"
    assert play.port == 22
    assert play.remote_user == "root"
    assert play.transport == "smart"
    assert play.no_log == False

# Generated at 2022-06-21 00:45:46.728762
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    ds = {'user': 'root'}
    ans = {'remote_user': 'root'}
    p.preprocess_data(ds)
    assert ds == ans

# Generated at 2022-06-21 00:45:49.291279
# Unit test for method load of class Play
def test_Play_load():
  #Create an instance of Play
  p = Play()
  p.load()


# Generated at 2022-06-21 00:45:51.132758
# Unit test for method get_vars of class Play
def test_Play_get_vars():
  play = Play()
  play.vars = None
  assert play.get_vars() == {}


# Generated at 2022-06-21 00:46:04.313285
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    assert play is not None


# Generated at 2022-06-21 00:46:06.998222
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    assert p.get_vars() is not None



# Generated at 2022-06-21 00:46:10.886246
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    """ verify that Play.deserialize is working"""
    p = Play()
    p.deserialize({'strategy':'strategy', 'name':'name', 'default_vars':{}})
    assert p._attributes == ['strategy', 'name', 'default_vars']
    assert 'strategy' == getattr(p, 'strategy')
    assert 'name' == getattr(p, 'name')
    assert {} == getattr(p, 'default_vars')

# Generated at 2022-06-21 00:46:13.261309
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    _ = Play()
    _.deserialize(None)



# Generated at 2022-06-21 00:46:16.205029
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()

    # TODO: test cases
    # play.get_handlers()


# Generated at 2022-06-21 00:46:26.944642
# Unit test for method copy of class Play
def test_Play_copy():
    new_me = Play().copy()
    assert not new_me.ROLE_CACHE, "New Play.ROLE_CACHE is not empty"
    assert not hasattr(new_me, '_included_conditional'), \
        "New Play._included_conditional is not empty"
    assert not hasattr(new_me, '_included_path'), \
        "New Play._included_path is not empty"
    assert not hasattr(new_me, '_action_groups'), \
        "New Play._action_groups is not empty"
    assert not hasattr(new_me, '_group_actions'), \
        "New Play._group_actions is not empty"


# Generated at 2022-06-21 00:46:33.942888
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # create a Play object
    play = Play()

    # check default value of attribute vars_files of generated object
    assert play.vars_files == None

    # set attribute vars_files with the following value
    play.vars_files = 'FileName'

    # validate that the method does not return None
    assert play.get_vars_files() != None
# Unit tests for method get_roles of class Play

# Generated at 2022-06-21 00:46:38.011014
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    result = play.compile_roles_handlers()
    assert result is not None



# Generated at 2022-06-21 00:46:46.148518
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    # Test a play with no roles
    no_roles_play = Play()
    assert no_roles_play.get_roles() == []

    # Test a play with one role and one non-Role
    role = Role()
    one_role_play = Play(roles=[role, 'test'])
    assert one_role_play.get_roles() == [role]


# Generated at 2022-06-21 00:46:51.336054
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    play.roles = [{"data1":"data1"},{"data2":"data2"}]
    assert play.get_roles() == [{"data1":"data1"},{"data2":"data2"}]

# Generated at 2022-06-21 00:47:14.179331
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {'a': 'b'}
    assert p.get_vars() == {'a': 'b'}


# Generated at 2022-06-21 00:47:14.818218
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-21 00:47:25.281055
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = [
        {
            'name': 'restart-tomcat',
            'listen': ['app-stopped'],
            'tags': ['always']
        },
        {
            'name': 'start-tomcat',
            'listen': ['app-started'],
            'tags': ['always']
        }
    ]
    assert (p.get_handlers() == [
        {
            'name': 'restart-tomcat',
            'listen': ['app-stopped'],
            'tags': ['always']
        },
        {
            'name': 'start-tomcat',
            'listen': ['app-started'],
            'tags': ['always']
        }
    ])


# Generated at 2022-06-21 00:47:26.216926
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert True

# Generated at 2022-06-21 00:47:27.103679
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
  pass

# Generated at 2022-06-21 00:47:37.282294
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    try:
        reload(Task())
    except NameError:
        try:
            from ansible.playbook.task import Task
        except ImportError as e:
            print("failed=True msg='{0}'".format(e))
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.utils.display import Display
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-21 00:47:44.021714
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    class Test(unittest.TestCase):
        def test(self):
            play = Play()
            ds_user = dict(
                foo='bar',
                user='chuck',
            )
            ds = play.preprocess_data(ds=ds_user)
            self.assertDictEqual(
                d1=ds,
                d2=dict(
                    foo='bar',
                    remote_user='chuck',
                ),
            )
    unittest.TextTestRunner(verbosity=2).run(testsuite())


# Generated at 2022-06-21 00:47:52.747125
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p._included_conditional = 'something'
    p._included_path = 'something'
    p._action_groups = 'something'
    p._group_actions = 'something'

    c = p.copy()
    assert c.ROLE_CACHE == p.ROLE_CACHE
    assert c._included_conditional == p._included_conditional
    assert c._included_path == p._included_path
    assert c._action_groups == p._action_groups
    assert c._group_actions == p._group_actions



# Generated at 2022-06-21 00:47:57.181647
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play._handlers = ['x','y','z']
    play.get_handlers()
    assert play.handlers == ['x','y','z']

# Generated at 2022-06-21 00:48:09.472235
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # Create a mock object to test
    p = Play()

    # Create a mock datastructure to test with
    ds = {}

    # The datastructure to be used when testing Play._preprocess_tasks
    # Create a mock dictionary to use

# Generated at 2022-06-21 00:48:44.893699
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    obj = Play()
    obj._included_path = None
    obj._action_groups = {}
    obj._group_actions = {}

# Generated at 2022-06-21 00:48:57.434467
# Unit test for method load of class Play
def test_Play_load():
    data = dict(
        name="load",
        connection="smart",
        hosts=['localhost', 'otherhost'],
        gather_facts='no',
        vars_prompt=[],
        vars_files=['file1', 'file2'],
        roles=[dict(name='rolename', tasks=dict(task='taskname'))],
        tasks=[dict(action='setup')],
        handlers=[dict(name='all', tasks=dict(task='handler'))],
    )

    play = Play().load(data)
    assert play.name == data['name']
    assert play.connection == data['connection']
    assert play.hosts == data['hosts']
    assert play.gather_facts == data['gather_facts']
    assert play.vars_prompt == data['vars_prompt']

# Generated at 2022-06-21 00:49:08.525792
# Unit test for method load of class Play
def test_Play_load():
    # For example purposes only, this test is almost useless
    # Proper code will be provided as we go along
    # Note that running this test could take a LONG time...
    # But it should eventually pass
    inventory = Inventory(loader=None, variable_manager=None, host_list='ansible/test_inventories/inventory_file')

# Generated at 2022-06-21 00:49:14.488617
# Unit test for method compile of class Play
def test_Play_compile():
    # Create a test instance for class Play
    test_instance = Play()
    assert isinstance(test_instance, Play)
    
    # Try to call method compile of Play
    try:
        test_instance.compile()
    except AnsibleError as e:
        assert isinstance(e, AnsibleError)
    except:
        raise

# Generated at 2022-06-21 00:49:27.019072
# Unit test for constructor of class Play
def test_Play():
    my_dict = dict(
        name='testPlay',
        hosts='testHosts',
        gather_facts='True',
        tasks=[dict(action='setup', register='output_setup')],
        handlers=[dict(name='restartTheThing', action='service name=thething restart')],
        roles=[dict(name='testRole')]
    )
    my_play = Play.load(data=my_dict)
    assert my_play.name == 'testPlay'
    assert my_play.hosts == 'testHosts'
    assert my_play.gather_facts == 'True'
    assert my_play.tasks == [dict(action='setup', register='output_setup')]

# Generated at 2022-06-21 00:49:35.436548
# Unit test for method copy of class Play
def test_Play_copy():
    _play = Play()
    _play.ROLE_CACHE = {'1':'', '2':''}
    _play._included_conditional = 'included_conditional'
    _play._included_path = 'included_path'
    _play._action_groups = 'action_groups'
    _play._group_actions = 'group_actions'

    new_me = _play.copy()
    assert _play.ROLE_CACHE == new_me.ROLE_CACHE
    assert _play._included_conditional == new_me._included_conditional
    assert _play._included_path == new_me._included_path
    assert _play._action_groups == new_me._action_groups
    assert _play._group_actions == new_me._group_actions

# Generated at 2022-06-21 00:49:40.289903
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({'name': 'New Play', 'hosts': 'localhost'})
    assert p.name == 'New Play' and p.hosts == 'localhost'


# Generated at 2022-06-21 00:49:43.064733
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.handlers = ['roles', 'blocks']
    assert play.get_handlers() == ['roles', 'blocks']



# Generated at 2022-06-21 00:49:54.598138
# Unit test for method copy of class Play
def test_Play_copy():
    data = {
        'name': 'test play.py',
        'hosts': 'host1,host2,host3',
        'user': 'test_user',
        'gather_facts': 'no',
        'tasks': [
            {'name': 'task1'},
            {'name': 'task2', 'with_items': 'fake_item'}
        ]
    }
    p = Play()
    p.load_data(data)


# Generated at 2022-06-21 00:49:59.162165
# Unit test for method serialize of class Play
def test_Play_serialize():
    import json
    b = dict(
        name="testname",
        gather_facts="smart",
        hosts="all",
        tasks=[
            dict(action=dict(module="shell", args="some args"))
        ],
        handlers=[
            dict(
                name="testhandler",
                raw="yum install something",
                notify=['some other handler'])
        ])
    a = Play.load(b, variable_manager=None, loader=None)
    print(json.dumps(a.serialize()))
    assert True



# Generated at 2022-06-21 00:50:34.789451
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize(
        {
            "tasks": [],
            "roles": [
                {
                    "tasks": [],
                    "role_path": "/root/.ansible/libraries/roles/TestRole_Deserialize",
                    "name": "TestRole_Deserialize",
                    "include_role": {},
                    "tags": [],
                    "vars": {"test": "foo"},
                    "handlers": [],
                    "defaults": {"test": "bar"}
                }
            ],
            "id": 1,
            "vars": {"var1": "foo"},
            "hosts": "all",
            "name": "example"
        }
    )

# Generated at 2022-06-21 00:50:43.274300
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    p = Play()
    assert isinstance(p.get_roles, types.MethodType)

    # check that get_roles returns a list of Role objects
    assert isinstance(p.get_roles(), list)
    assert all(isinstance(r, Role) for r in p.get_roles())

    # check that get_roles returns a copy of self.roles
    assert p.get_roles() is not p.get_roles()


# Generated at 2022-06-21 00:50:45.494139
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = {'hosts': 'some_host'}
    p = Play()
    assert p.preprocess_data('some_host') == ds


# Generated at 2022-06-21 00:50:47.045287
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass # Not implemented


# Generated at 2022-06-21 00:50:54.489338
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
  play = Play()
  data_set = {
    'hosts': ['myhost'],
    'user': 'myusername'}
  result = play.preprocess_data(data_set)
  expected = {
    'hosts': ['myhost'],
    'remote_user': 'myusername'}
  # BEGIN ASSERTS
  assert(isinstance(result, dict))
  assert(expected == result)


# Generated at 2022-06-21 00:50:58.130791
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # Set up test objects
    p = Play()
    p.name = 'play_name'

    ###
    # Test

    # run __repr__()
    expected_result = p.get_name()
    actual_result = p.__repr__()
    assert expected_result == actual_result



# Generated at 2022-06-21 00:51:02.498417
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    if not isinstance(p, Play):
        raise AssertionError("test_Play failed to create an instance of class Play")


# Generated at 2022-06-21 00:51:10.339009
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from io import StringIO
    p = Play()
    p._ds = dict(
        name = 'test_play',
        hosts = ['host1'],
        user = 'test_user',
        roles = [dict(name='test_role')],
        tasks=[]
    )
    p.preprocess_data()
    assert p._ds['remote_user'] == 'test_user'
    assert p._ds['user'] is None
    assert p._ds['tasks'] == []
    assert p._ds['roles'] == [dict(name='test_role')]


# Generated at 2022-06-21 00:51:18.154653
# Unit test for method copy of class Play
def test_Play_copy():
    import mock
    import copy
    play = Play()
    play.ROLE_CACHE = {'1': '11'}
    play._included_conditional = 'included_conditional'
    play._included_path = 'included_path'
    play._action_groups = {'1': '11'}
    play._group_actions = {'1': '11'}
    play1 = play.copy()
    assert play.ROLE_CACHE == play1.ROLE_CACHE
    play1.ROLE_CACHE['1'] = '12'
    assert play.ROLE_CACHE != play1.ROLE_CACHE
    assert play._included_conditional == play1._included_conditional
    assert play._included_path == play1._included

# Generated at 2022-06-21 00:51:28.965668
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # Preprocess data to convert a role 
    # with deprecated 'user' field to 'remote_user' field
    ds = { 'name': 'test_play', 'remote_user': 'test_remote_user' }
    play = Play()
    assert ds == play.preprocess_data(ds)

    ds = { 'name': 'test_play', 'user': 'test_remote_user' }
    assert ds == play.preprocess_data(ds)
    assert 'remote_user' in ds
    assert 'user' not in ds
    assert ds['remote_user'] == 'test_remote_user'


# Generated at 2022-06-21 00:52:03.395010
# Unit test for method load of class Play
def test_Play_load():
    # This test case is the Play load method testing, load a json file
    # which is a valid playbook, and use load method to convert the json file
    # to Play object.
    load_path = os.path.join(os.path.dirname(__file__), "./load/playbooks/test_play_load_valid.json")
    load_file = open(load_path, "r")
    load_json = json.load(load_file)
    loaded_play = Play.load(load_json)
    assert isinstance(loaded_play, Play)
    assert loaded_play.name == "A simple playbook"
    assert loaded_play.hosts == "all"
    assert loaded_play.remote_user == "root"
    assert loaded_play.become

# Generated at 2022-06-21 00:52:14.550001
# Unit test for method copy of class Play
def test_Play_copy():
    p = Play()
    p._included_conditional = 'add'
    p._included_path = '/tmp'
    p._action_groups = {'key': 'value'}
    p._group_actions = {'key1': 'value1'}
    p.ROLE_CACHE = {'role1': 'role1'}
    p.only_tags = 'all'
    p.skip_tags = 'none'
    my_class = Play()
    my_class.name = 'name1'
    p.load_data(my_class)
    new_me = p.copy()
    # shallow copy
    assert id(p.ROLE_CACHE) == id(new_me.ROLE_CACHE)

# Generated at 2022-06-21 00:52:19.260679
# Unit test for method load of class Play
def test_Play_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    p = Play()
    ds = DataLoader()
    variable_manager = VariableManager()
    p.load(ds, variable_manager)

# Generated at 2022-06-21 00:52:26.549450
# Unit test for method serialize of class Play
def test_Play_serialize():
    # set up object to serialize
    yaml_data = load_fixture_file("serialized_play.data")
    obj = Play()
    obj.deserialize(yaml_data)

    # serialize to yaml
    data = obj.serialize()

    # see what we get
    assert data == yaml_data


# Generated at 2022-06-21 00:52:38.304215
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    # play object of class Play is created
    # test for case when handlers is not present in the play object
    assert play.get_handlers() == []
    # test for case when handlers is present in the play object
    # but it is not of type list
    play.handlers = "xyz"
    assert play.get_handlers() == []
    # test for case when handlers is present in the play object
    # it is of type list and has one element
    play1 = Play()
    play1.handlers = ["xyz"]
    assert play1.get_handlers() == ["xyz"]
    # test for case when handlers is present in the play object
    # it is of type list and has multiple element
    play2 = Play()
    play2.handlers = ["xyz", "abc"]
