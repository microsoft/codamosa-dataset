

# Generated at 2022-06-21 00:43:09.205187
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Setup
    play = Play()
    # Exercise
    play.preprocess_data(ds=None)
    # Verify
    assert False, "TODO: Implement me"

# Generated at 2022-06-21 00:43:19.957927
# Unit test for method copy of class Play
def test_Play_copy():
    '''
    Test the method copy of class Play
    '''
    # Test to create a role.
    role = Role()
    assert(role) is not None
    # Test to set a variable name and variable value.
    data = {'name': 'role', 'value': 'Role Creation Test'}
    # Test to set the variable.
    setattr(role, 'name', 'role')
    setattr(role, 'value', 'Role Creation Test')
    # Test to create a Play.
    play = Play()
    assert(play) is not None
    # Test to set the variable in the Play.
    setattr(play, 'roles', [role])
    assert(play.roles) is not None
    assert(play.roles) == [role]
    # Test to copy the Play.
    new_me

# Generated at 2022-06-21 00:43:25.844649
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # obj = Play()
    # tasklist = obj.get_tasks()
    # assert len(tasklist) > 0 and len(tasklist[0]) > 0
    # for task in tasklist[0]:
    #     assert(callable(task))
    assert True



# Generated at 2022-06-21 00:43:39.303432
# Unit test for method get_vars of class Play

# Generated at 2022-06-21 00:43:50.842197
# Unit test for method get_tasks of class Play

# Generated at 2022-06-21 00:44:02.845496
# Unit test for method copy of class Play
def test_Play_copy():
    """
    make sure that none of the variables are lost when the object is copied
    """
    def create_Play_object():
        """
        Factory method for creating Play objects
        """
        play_obj = Play()
        play_obj.ROLE_CACHE = {'key1':1,'key2':2}
        play_obj._included_conditional = 'incl_conditional'
        play_obj._included_path = 'included_path'
        play_obj._action_groups = {'action1':1,'action2':2}
        play_obj._group_actions = {'action1':1,'action2':2}

        return play_obj

    play_obj_1 = create_Play_object()
    play_obj_2 = play_obj_1.copy()

    assert play_obj

# Generated at 2022-06-21 00:44:12.901273
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    assert play.get_vars_files() == []
    play.vars_files = None
    assert play.get_vars_files() == []

    # list
    play.vars_files = ['a','b','c']
    assert play.get_vars_files() == ['a','b','c']
    play.vars_files = 0
    assert play.get_vars_files() == ['a','b','c']

    # string
    play.vars_files = 'string'
    assert play.get_vars_files() == ['a','b','c']
    play.vars_files = False
    assert play.get_vars_files() == ['a','b','c']

    play.vars_files = ['a','b','c']
    assert play

# Generated at 2022-06-21 00:44:15.316171
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Init Play
    play = Play()
    # Verify get_roles of Play
    assert play.get_roles() == []

# Generated at 2022-06-21 00:44:23.449010
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

    p = Play()
    p.ROLE_CACHE = {
        'foo': Role(),
        'bar': Role()
    }

    ri1 = RoleInclude()
    ri1.role = 'foo'

    ri2 = RoleInclude()
    ri2.role = 'bar'

    p.roles = [ri1, ri2]

    task1 = Task()
    task2 = Task()

    block = Block()

# Generated at 2022-06-21 00:44:24.870770
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-21 00:44:32.786687
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-21 00:44:36.393808
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = { 'hello': 'world' }
    assert play.get_vars() == { 'hello': 'world' }

# Generated at 2022-06-21 00:44:40.435178
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = dict(a=1)
    assert p.get_vars() == dict(a=1)



# Generated at 2022-06-21 00:44:44.275526
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    play.load_data(dict(
            name = 'test play',
            handlers = [
                dict(
                    name = 'test handler',
                    action = dict(
                        module = 'test module'
                        )
                    )
                ]
            ))
    result = play.get_handlers()
    assert len(result) == 1
    assert result[0].name == 'test handler'


# Generated at 2022-06-21 00:44:53.453840
# Unit test for constructor of class Play
def test_Play():
    # Constructor of class Play should throw an exception if the hosts parameter
    # is not a string or a list
    invalid_hosts = {}
    try:
        Play(hosts=invalid_hosts)
        raise AssertionError("Failed to throw an exception for Play(hosts=%s)" % invalid_hosts)
    except AnsibleParserError:
        pass

    valid_hosts = ['localhost']
    Play(hosts=valid_hosts)  # This should work

    # Constructor of class Play should throw an exception if the name attribute
    # is not a string
    invalid_name = {}

# Generated at 2022-06-21 00:44:56.528458
# Unit test for method get_name of class Play
def test_Play_get_name():

    # Test the get_name method for class Play
    def helper(hosts):
        # Create a Play object with the given hosts
        play = Play()
        play.hosts = hosts

        # Check if the Play.get_name method returns the correct value
        assert play.get_name() == hosts or ''

    helper([])
    helper([1, 2, 3])
    helper(['a', 'b', 'c'])


# Generated at 2022-06-21 00:44:59.617727
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.set_loader(Mock())
    assert hasattr(play, '__repr__')

# Generated at 2022-06-21 00:45:08.372641
# Unit test for method get_name of class Play
def test_Play_get_name():
    playbook = AnsiblePlaybook()
    playbook.set_playbook_basedir('/path/to/playbook')
    playbook._load_data('/path/to/playbook/site.yml',
                        "{}")
    play = playbook.get_plays()[0]
    assert play.get_name() == 'localhost'
    play._ds['name'] = 'test'
    assert play.get_name() == 'test'


# Generated at 2022-06-21 00:45:22.459462
# Unit test for constructor of class Play
def test_Play():
    # Ensure we can take a block of data and create a Play object
    play = Play.load(dict(
        name = 'test play',
        hosts = 'webservers',
        gather_facts = 'no',
        roles = ['common', 'web'],
        tasks = [
            dict(action=dict(module='shell', args='/usr/bin/uptime')),
        ]
    ), variable_manager=None, loader=None)

    assert play
    assert play.name == 'test play'
    assert play.hosts == 'webservers'
    assert 'common' in play.roles
    assert 'web' in play.roles
    assert len(play.tasks) == 1
    assert play.tasks[0].action['module'] == 'shell'

# Generated at 2022-06-21 00:45:30.525919
# Unit test for method get_name of class Play
def test_Play_get_name():
    """
    Test `Play.get_name` method
    """
    play_1 = Play()
    with pytest.raises(Exception):
        play_1.get_name()

    play_1.name = 'play_name'
    play_1_name = play_1.get_name()
    assert play_1_name == 'play_name'


    play_2 = Play()
    play_2.hosts = ['host1', 'host2']
    play_2_name = play_2.get_name()
    assert play_2_name == 'host1,host2'

    play_3 = Play()
    play_3.hosts = 'host3'
    play_3_name = play_3.get_name()
    assert play_3_name == 'host3'

    play

# Generated at 2022-06-21 00:45:40.491681
# Unit test for constructor of class Play
def test_Play():
    # call the constructor of the class object and assert that it should return an instance of the class
    play_object = Play()
    assert isinstance(play_object, Play)

# Generated at 2022-06-21 00:45:43.492551
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'


# Generated at 2022-06-21 00:45:48.768833
# Unit test for method __repr__ of class Play
def test_Play___repr__():
  """ test __repr__ of class Play """
  if SKIP_TESTS:
    return

  # Pass
  p = Play()
  assert repr(p) == p.get_name()


# Generated at 2022-06-21 00:45:50.421626
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    assert play.get_handlers() == []


# Generated at 2022-06-21 00:46:03.820448
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.deprecated_vars == []
    assert p.handlers == []
    assert p.hosts == ''
    assert p.hosts_pattern == []
    assert p.remote_user == 'root'
    assert p.roles == []
    assert p.tasks == []
    assert p.vars == {}
    assert p.tags == []
    assert p.transport == 'smart'
    assert p.any_vars_on_host == []
    assert p.vars_prompt == []
    assert p._included_path == None
    assert p._action_groups == {}
    assert p._group_actions == {}
    assert p.ROLE_CACHE == {}


# Generated at 2022-06-21 00:46:06.409579
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = {}
    assert play.get_vars() == {}

# Generated at 2022-06-21 00:46:17.493734
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # testing for empty roles
    Play._roles = list()
    assert Play.get_roles() == []
    # testing with a regular role
    role = Role()
    role.name = "testrole"
    role.tags = ["test", "tags"]
    role.default_vars = {"name": "test"}
    role.tasks = [{"name": "test", "action": "test"}]
    role.dependencies = ["test", "dependencies"]
    role.handlers = [{"name": "test", "action": "test"}]
    Play._roles = [role]
    roles = Play.get_roles()

# Generated at 2022-06-21 00:46:17.982853
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass

# Generated at 2022-06-21 00:46:27.878738
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    ds = AnsibleLoader(loader=loader, variable_manager=variable_manager).load_from_file('test/units/parsing/yaml/test_play.yml')

    play = Play()
    new_ds = play.preprocess_data(ds)
    assert play.get_name() == u''
    assert new_ds == {u'hosts': u'all'} or {u'hosts': u'', u'name': u''}


# Generated at 2022-06-21 00:46:31.283472
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'unit test'
    play.hosts = 'all'
    play.serialize()


# Generated at 2022-06-21 00:47:14.541037
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    data = {
        'roles': [
            'alpha',
        ],
        'name': 'foo',
        'hosts': 'bar',
        'vars': {'test': 'test'},
        'vars_files': [],
        'handlers': [
            {'name': 'test'},
        ],
        'tasks': [
            {'name': 'test'},
            {'name': 'test'},
        ],
    }

    playlist = Play.load(data, loader=DictDataLoader({}))
    assert len(playlist.get_handlers()) == 1
    assert not playlist.get_handlers()[0].implicit

# Generated at 2022-06-21 00:47:18.950164
# Unit test for method load of class Play
def test_Play_load():
    task_ds = {"name": "fail"}
    tasks = [Task.load(task_ds)]
    play_ds = {"hosts": "all", "tasks": tasks}
    play = Play()

    assert play.load_data(play_ds) == tasks

# Generated at 2022-06-21 00:47:23.253592
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    b = Play()
    print(b.__repr__())
if __name__ == '__main__':
    test_Play___repr__()


# Generated at 2022-06-21 00:47:34.201283
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # This test case checks the following scenario
    #     1- Create two roles, test_role1 and test_role2
    #     2- Attach handlers to test_role1
    #     3- Compile handlers for test_role to ensure no error occurs
    #     4- Compile handlers for test_role2 to ensure no error occurs
    test_play = Play()
    test_play.vars = dict()
    test_play.roles = []
    cache_loader = DataLoader()
    inventory = InventoryManager(loader=cache_loader)
    variable_manager = VariableManager(loader=cache_loader, inventory=inventory)
    test_play._variable_manager = variable_manager

    role_name = 'test_role1'

# Generated at 2022-06-21 00:47:44.236094
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = dict(
        name='foo',
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup'),
                 register='setup_facts'),
            dict(action=dict(module='debug', args=dict(msg='{{setup_facts.ansible_env.HOME}}')))
        ]
    )

    myplay = Play.load(data)
    myplay.deserialize(myplay.serialize())


# Generated at 2022-06-21 00:47:51.096935
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test Play.get_name() method
    # 
    # 
    # Setup: Create a Play object
    # 
    # 
    # Return Value Test: Return the name of the Play object
    #      Asserts that the name of the Play object is equal to the name that was stored, which
    #      is the same as the name of the file from which the Play was created, if a name was
    #      not explicitly specified
    #
    return p

    # Test: Load a play from a simple yaml file
    # 
    # 
    # Setup: Create a Play object that reads in a simple play file with a
    #      single task
    # 
    # 
    # Return Value Test: Return a list with the tasks from the Play object
    #      Asserts that the list contains a single task
    #

# Generated at 2022-06-21 00:48:03.446505
# Unit test for method compile of class Play
def test_Play_compile():
    fake_host = FakeHost('fakehost', [FakeTask('dummy')])
    fake_host.set_vars({})
    fake_host.groups = ['fake']
    fake_host.groups_list = [
        ['fake'],
    ]
    fake_host.groups_dict = {
        'fake': {
            'name': 'fake',
            'hosts': ['fakehost'],
            'vars': {}
        }
    }

    fake_play = Play()
    fake_play.vars = {}
    fake_play.name = 'test'

# Generated at 2022-06-21 00:48:09.369083
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    test_play = Play()
    test_play_dict = {"name": "test_Play"}
    test_play.load_data(test_play_dict)
    assert test_play.__repr__() == test_play.get_name()


# Generated at 2022-06-21 00:48:22.980668
# Unit test for method serialize of class Play

# Generated at 2022-06-21 00:48:26.709402
# Unit test for method get_name of class Play
def test_Play_get_name():
      play = Play()
      play.name = "test_name"
      assert play.get_name() == play.name


# Generated at 2022-06-21 00:48:43.173954
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    with PyTest(globals()):
        # Arrange
        play = Play()
        play.vars = {}
        play.roles = [Role()]
        # Act
        result = play.get_roles()
        # Assert
        t.eq([Role()], result)


# Generated at 2022-06-21 00:48:47.094330
# Unit test for method get_name of class Play
def test_Play_get_name():
    x=Play()
    print(x.get_name())
    print(x._ds)
    print(x.preprocess_data(x._ds))

# Generated at 2022-06-21 00:48:48.785397
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # TODO
    assert True


# Generated at 2022-06-21 00:48:52.133932
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create a test play for testing
    play = Play()

    # Create a dictionary with the user key
    data = {'user': 'someuser'}

    # Call the method
    play.preprocess_data(data)
    # A key value of remote_user should be present and be equal to 'someuser'
    assert data.get('remote_user') == 'someuser'


# Generated at 2022-06-21 00:49:02.691146
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
            'test.yml': """
            - hosts: localhost
              tasks:
                - debug: msg="test"
              handlers:
                - name: test handler
                  debug: msg="test"
              """})

    play = Play.load(dict(name='test'), variable_manager=None, loader=loader)
    assert(len(play.get_handlers()) == 1)


# Generated at 2022-06-21 00:49:06.086399
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()

# Generated at 2022-06-21 00:49:07.914989
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Arguments for method test
    play = Play()
    data = None
    play.deserialize(data)

# Generated at 2022-06-21 00:49:20.831972
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    hostvars = {}
    play = Play()
    role = Role()
    role_data = {'role_name': 'test_role', 'file_name': 'test_role'}
    role.deserialize(role_data)
    data = {}
    data['roles'] = [role_data]
    data['action_groups'] = {}
    data['group_actions'] = {}
    play.deserialize(data)
    assert play._included_path == None
    assert play._action_groups == {}
    assert play._group_actions == {}
    assert play.roles[0]._role_name == 'test_role'
    assert play.roles[0]._file_name == 'test_role'
    assert play.roles[0]._collections_paths == []

# Unit

# Generated at 2022-06-21 00:49:27.565808
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    raw_data = {'name': 'test_play', 'hosts': 'all'}
    p = Play()
    p.load_data(raw_data)
    p.compile_roles_handlers()

    raw_data = {'name': 'test_play', 'hosts': 'all'}
    p = Play()
    p._ds = raw_data
    p.compile_roles_handlers()



# Generated at 2022-06-21 00:49:34.788502
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    vars = {'test_variable': 'test value'}
    def _get_vars(value=None):
        return vars

    data = dict(
        name='foo',
        hosts='all',
        vars='test_variable',
        tasks=[dict(action=dict(module='print', args='{{ test_variable }}'))]
    )
    p = Play()
    p.get_variable_manager = _get_vars
    p._loader = DictDataLoader({})
    ds = p.preprocess_data(data)
    assert ds.get('vars') == vars.get('test_variable')


# Generated at 2022-06-21 00:49:54.733738
# Unit test for method load of class Play
def test_Play_load():
    global loader, variable_manager, playbook
    ds = {"name": "play1", "hosts": "host1", "tasks": [{"name": "task1", "action": {"module": "echo", "args": {"msg": "hi"}}}]}
    play = Play.load(ds=ds, variable_manager=variable_manager, loader=loader)
    assert play.name == "play1"
    assert play.hosts == "host1"
    assert play.tasks == [{"name": "task1", "action": {"module": "echo", "args": {"msg": "hi"}}}]

# Generated at 2022-06-21 00:50:00.981833
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print("test_Play_get_tasks")
    myplay = Play()
    myplay.deserialize({"handlers": {"handlers": [
        {"include": {"name": "handlers", "roles": "Role1"}}]}})
    myplay.roles = [Role(name="Role1")]
    myplay.roles[0].deserialize({"handlers": {"handlers": [{"include": {"name": "handlers", "roles": "Role2"}}]}})
    myplay.roles[0].roles = [Role(name="Role2")]

# Generated at 2022-06-21 00:50:03.367440
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # FIXME: This method used in Ansible-runner's code and is not used in Ansible's code.
    #        This method should be removed after ensuring Ansible-runner does not need it.
    pass

# Generated at 2022-06-21 00:50:16.527398
# Unit test for method load of class Play
def test_Play_load():
    _load = Play.load
    _Play_load = Play.load
    @staticmethod
    def load(data, variable_manager=None, loader=None, vars=None):
        return _load(data, variable_manager=variable_manager, loader=loader, vars=vars)
    Play.load = load
    _load = Play._load
    _Play__load = Play._load

    def _load(self, attr, ds):
        if attr == 'tasks':
            return self.tasks
        return _load(self, attr, ds)
    Play._load = _load
    result = Play.load("""- action: shell /bin/foo
- action: shell /bin/bar
""",
                       loader=DictDataLoader({}))

    # Asserts for body of method load

# Generated at 2022-06-21 00:50:23.538108
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play1 = Play()

    # Case 1: input is empty dict
    ds = dict()
    ret = play1.preprocess_data(ds)
    assert (ret == ds)

    # Case 2: input is dict which does not contain key 'user'
    ds = {'name': 'test play 1', 'hosts': 'localhost'}
    ret = play1.preprocess_data(ds)
    assert (ret == ds)

    # Case 3: input is dict which contains key 'user' and value is not None
    ds = {'name': 'test play 1', 'hosts': 'localhost', 'user': 'test user'}
    ret = play1.preprocess_data(ds)
    assert (ret['remote_user'] == ds['user'])
    assert ('user' not in ret)


# Generated at 2022-06-21 00:50:24.735825
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    p.preprocess_data({})

# Generated at 2022-06-21 00:50:33.727060
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import Include
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.plugins.loader import connection_loader

    to_text = lambda x: x

# Generated at 2022-06-21 00:50:45.951527
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.plugins.callback import CallbackBase

    def get_first_play(playbook_path):
        loader = DataLoader()
        inventory = InventoryManager(loader=loader, sources='')
        variable_manager = VariableManager(loader=loader, inventory=inventory)
        pb = Playbook.load(playbook_path, variable_manager=variable_manager, loader=loader)
        return pb.get_plays()[0]


# Generated at 2022-06-21 00:50:56.502353
# Unit test for method load of class Play
def test_Play_load():
    args = MagicMock()
    args.module_path = None
    args.module_paths = []
    args.tree = None
    args.roles_path = []
    #args.connection = None
    #args.new_vault_password_file = None
    #args.vault_password_files = None
    #args.remote_user = None
    #args.private_key_file = None
    #args.verbosity = 0
    #args.check = False
    #args.syntax = None
    #args.start_at_task = []
    #args.force_handlers = False
    #args.step = False
    #args.diff = False
    #args.tags = []
    #args.skip_tags = []
    #args.limit = []
    #args.inventory =

# Generated at 2022-06-21 00:51:05.851683
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Desired Variables
    desired_vars_files = []

    # Set up an instance of Play
    p = Play()

    # Try to get the variable
    actual_vars_files = p.get_vars_files()

    # Check the variable
    assert actual_vars_files == desired_vars_files

test_Play_get_vars_files()



# Generated at 2022-06-21 00:51:29.663977
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """Unit tests for compile_roles_handlers method of Play.
    """
    # TODO: Add tests for Play.compile_roles_handlers
    raise AnsibleError("compile_roles_handlers tests not implemented.")

# Generated at 2022-06-21 00:51:39.251627
# Unit test for method __repr__ of class Play

# Generated at 2022-06-21 00:51:50.233510
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    d = {'name': 'test', 
         'hosts': 'localhost', 
         'roles': [{'name': 'test'}, {'name': 'test3'}]
        }
    p.deserialize(d)

    assert p.name == 'test'
    assert p.hosts == 'localhost'
    assert p.roles[0].name == 'test'
    assert p.roles[1].name == 'test3'
    assert p.serialize()['roles'][0]['name'] == 'test'
    assert p.serialize()['roles'][1]['name'] == 'test3'


# Generated at 2022-06-21 00:52:01.425879
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.context import CLIContext
    context._init_global_context(CLIContext('.', '.'))
    p = Play()
    p.name = 'test_name'
    assert(p.get_name() == 'test_name')
    p.name = None
    p.hosts = 'test_host'
    assert(p.get_name() == 'test_host')
    p.hosts = None
    assert(p.get_name() == '')
    p.hosts = ['test_host1', 'test_host2', 'test_host3']
    assert(p.get_name() == 'test_host1,test_host2,test_host3')

# Generated at 2022-06-21 00:52:07.675832
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # data to use to initialize play
    data = {}
    # initialize a new instance of Play
    test_Play = Play()
    test_Play.vars = {}
    # test the method get_vars of Play
    result = test_Play.get_vars()
    # compare results
    assert result == {}

# Generated at 2022-06-21 00:52:17.708777
# Unit test for method serialize of class Play
def test_Play_serialize():

    # creates a play instance
    p = Play()

    data = p.serialize()
    assert data == {
        'name': '',
        'hosts': u'all',
        'gather_facts': 'smart',
        'tasks': [],
        'roles': [],
        'vars': {},
        'vars_files': [],
        'vars_prompt': [],
        'handlers': [],
        'block': [],
        'post_tasks': [],
        'pre_tasks': [],
        'included_path': None,
        'action_groups': {},
        'group_actions': {}
    }


# Generated at 2022-06-21 00:52:22.569722
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Precondition
    from .block import Block
    from .task import Task
    from .module_utils import module_docs as docs

    # Given
    p = Play()
    p.tasks = [Task.load({"action": {"module": "meta", "args": {"_raw_params": "flush_handlers"}}, "_line": 3}), Task.load({"action": {"module": "meta", "args": {"_raw_params": "flush_handlers"}}, "_line": 4}), Task.load({"action": {"module": "meta", "args": {"_raw_params": "flush_handlers"}}, "_line": 5})]

# Generated at 2022-06-21 00:52:31.771997
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import ansible.parsing.yaml.objects
    plugin = ansible.plugins.callback.CallbackModule()
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager(loader=None)
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    
    test_obj = {'hosts': ['host2'], 'name': 'testing'}
    
    
    
    
    p = Play()
    p.deserialize(test_obj)
    assert p.hosts == ['host2']
    assert p.name == 'testing'
    assert not p.ROLE_C

# Generated at 2022-06-21 00:52:36.232092
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    # instance to test on
    play = Play()
    play.name = 'new play'

    # test execution
    repr_result = repr(play)

    # assertions
    assert repr_result == 'new play'


# Generated at 2022-06-21 00:52:48.727760
# Unit test for constructor of class Play
def test_Play():

    play = Play()
    assert play.name is None
    assert play.hosts is None
    assert play.roles is None
    assert play.roles is None
    assert play.vars is None
    assert play.vars_prompt is None
    assert play.vars_files is None
    assert play.vars_files[0] is None
    assert play.tasks is None
    assert play.post_tasks is None
    assert play.handlers is None
    assert play.serial is None
    assert play.max_fail_percentage is None
    assert play.ignore_errors is None
    assert play.tags is None
    assert play.skip_tags is None
    assert play.blocks is None
    assert play.deprecated is None
    assert play.deprecate_inventory is None
    assert play.connection