

# Generated at 2022-06-21 00:43:00.398494
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass


# Generated at 2022-06-21 00:43:00.851944
# Unit test for method deserialize of class Play
def test_Play_deserialize():
  pass

# Generated at 2022-06-21 00:43:13.825594
# Unit test for method load of class Play
def test_Play_load():
    loader = DictDataLoader(dict())
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager._use_fact_cache = True
    variable_manager.add_cache(variable_manager._fact_cache)
    variable_manager._options = DC()
    variable_manager._options.tags = set(('test_tags',))
    variable_manager._extra_vars = dict()
    variable_manager.set_inventory(MockInventory(hosts_list=("127.0.0.1",)))
    variable_manager._vars_cache = dict()
    variable_manager._extra_vars = {}


# Generated at 2022-06-21 00:43:19.908143
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_obj = Play()
    assert play_obj._included_conditional is None
    assert not play_obj._included_path
    assert play_obj._action_groups is {}
    assert play_obj._group_actions is {}


# Generated at 2022-06-21 00:43:21.365235
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.compile()

# Generated at 2022-06-21 00:43:32.694455
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.callback import default
    # Create loader object
    loader = DataLoader()

    # Create a test Inventory object
    inv = Inventory(loader, [])

    # Create a test Play object
    play = Play()

    # Create TQM object
    tqm = TaskQueueManager(
        inventory=inv,
        variable_manager=play.get_variable_manager(),
        loader=loader,
        options=None,
        passwords={},
        stdout_callback=default.CallbackModule(),
    )

    # Creating a new test Play/Role
    test_play = Play()

# Generated at 2022-06-21 00:43:37.383825
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert p.__repr__() is p.get_name()
    p = Play()
    for x in range(10):
        p.roles = []
        p.roles.append(Role())
        assert p.__repr__() is p.get_name()

# Generated at 2022-06-21 00:43:41.487692
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    play.roles = []
    play._load_roles('test', [])
    assert play.get_roles() == []

# Generated at 2022-06-21 00:43:50.880017
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = {}
    _field_names = {}
    _fields = {}
    _tmp = None
    instance = Play()
    obj = super(Play, instance).serialize()
    data.update(obj)
    roles = []
    for role in instance.get_roles():
        _tmp = role.serialize()
        roles.append(_tmp)
    data['roles'] = roles
    data['included_path'] = instance._included_path
    data['action_groups'] = instance._action_groups
    data['group_actions'] = instance._group_actions

    assert data == {}
    assert _field_names == {}
    assert _fields == {}
    assert _tmp is None



# Generated at 2022-06-21 00:43:55.965227
# Unit test for constructor of class Play
def test_Play():
    assert Play().get_name() == ''
    assert Play(name='test').get_name() == 'test'
    assert Play(hosts='127.0.0.1').get_name() == '127.0.0.1'
    assert Play(hosts=['127.0.0.1']).get_name() == '127.0.0.1'
    assert Play(hosts='127.0.0.1', name='test').get_name() == 'test'
    assert Play(hosts=['127.0.0.1'], name='test').get_name() == 'test'

# Generated at 2022-06-21 00:44:13.496446
# Unit test for method copy of class Play
def test_Play_copy():
    variables = dict(
        foo="bar"
    )
    my_play = Play()
    my_play.ROLE_CACHE = variables.copy()
    my_play._included_conditional = "foo"
    my_play._included_path = variables.copy()
    my_play._action_groups = variables.copy()
    my_play._group_actions = variables.copy()
    my_new_play = my_play.copy()
    assert my_new_play.ROLE_CACHE == my_play.ROLE_CACHE
    assert my_new_play._included_conditional == my_play._included_conditional
    assert my_new_play._included_path == my_play._included_path
    assert my_new_play._action_groups == my_play

# Generated at 2022-06-21 00:44:20.435670
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.hosts == 'all'
    assert p.name == 'all'
    assert p.vars is None
    assert p.serial is 1
    assert p.strategy == 'linear'
    assert p.roles == []
    assert p.handlers == []
    assert p.tasks == []
    assert p.tags == ''

# Generated at 2022-06-21 00:44:30.193403
# Unit test for method load of class Play
def test_Play_load():
    # First, we instantiate a new Play object
    p = Play()
    # We set the attributes that are needed for the load method
    # as described in the documentation
    p._loader = None
    p._variable_manager = None
    # We call the load method with the following parameters
    # as described in the documentation
    assert p.load({"hosts": "localhost"}, variable_manager=None, loader=None) == p
    # We check that the values that the method returns are correct
    # using the assert_equal method
    assert_equal(p.hosts, "localhost")
    assert_equal(p.handlers, [])
    assert_equal(p.roles, [])
    assert_equal(p.tasks, [])
    assert_equal(p.vars, {})

# Generated at 2022-06-21 00:44:40.929450
# Unit test for method compile of class Play
def test_Play_compile():
    # set up some objects from scratch
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=context.CLIARGS)
    variable_manager.options_vars = load_options_vars(loader=None, options=context.CLIARGS)
    variable_manager.set_inventory(inventory=Inventory(loader=None, variable_manager=variable_manager, host_list=C.DEFAULT_HOST_LIST))
    loader = DataLoader()
    playbook = Playbook()
    test_playbook = playbook._load_playbook_data('tests/test_playbook.yml', variable_manager=variable_manager, loader=loader)
    play = test_playbook[0]
    # assert the first task of the play is "ping"
   

# Generated at 2022-06-21 00:44:44.278946
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    """Unit test for method __repr__ of class Play"""

    assert Play()._repr__() == 'Play()'

# Generated at 2022-06-21 00:44:50.161897
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test Play preprocess data without user keyword
    data = dict(hosts=['host1', 'host2'], name='Test Play', tasks=[dict(action=dict(module='test_module', args=dict(test='test arg')))])
    play = Play.load(data)
    assert play.hosts == ['host1', 'host2']

    # Test Play preprocess data with user keyword
    data = dict(hosts=['host1', 'host2'], name='Test Play', user='root', tasks=[dict(action=dict(module='test_module', args=dict(test='test arg')))])
    play = Play.load(data)
    assert play.remote_user == 'root'

    # Test Play preprocess data with user and remote_user keyword

# Generated at 2022-06-21 00:44:53.116532
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    assert isinstance(play.get_roles(), list)

# Generated at 2022-06-21 00:45:03.189615
# Unit test for method serialize of class Play
def test_Play_serialize():
  play1 = Play()

# Generated at 2022-06-21 00:45:07.066216
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {
        'name': 'play_name',
        'id': 'play_id',
    }
    obj = Play()
    obj.deserialize(data)
    assert obj.name == 'play_name'
    assert obj.id == 'play_id'


# Generated at 2022-06-21 00:45:13.041015
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    new_play = play.copy()
    assert new_play == play

    # TODO: Test more in-depth with different variables

    new_play.vars = {'ansible_playbook_python': '/usr/bin/python'}
    play.vars = {'ansible_playbook_python': '/usr/local/bin/python'}
    new_play.hosts = []
    new_play.hosts.append('localhost')
    play.hosts = ['localhost', '127.0.0.1']

    # TODO: Add more test cases here
    # These lines should fail because the copy is a deep copy but that's not
    # happening here
    # assert new_play.vars == play.vars
    # assert new_play.hosts == play.hosts




# Generated at 2022-06-21 00:45:30.644985
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    loader_mock = MagicMock()
    role_mock = MagicMock()
    role_mock.get_handler_blocks.return_value = "handler_blocks"
    play_obj = Play()
    play_obj.roles = [role_mock, role_mock, role_mock]
    role_mock.get_handler_blocks.assert_not_called()
    assert play_obj.compile_roles_handlers() == ["handler_blocks"] * 3


# Generated at 2022-06-21 00:45:39.632273
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    import ansible.playbook.play
    import ansible.playbook.role
    p = ansible.playbook.play.Play()
    r = ansible.playbook.role.Role()
    p.roles = [r]
    r2 = p.get_roles()
    assert r2 == [r]
    assert p.get_roles()[0] is r

# Generated at 2022-06-21 00:45:42.573661
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    assert "Play" in p.__repr__()


# Generated at 2022-06-21 00:45:54.591998
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Basic test for class method "deserialize" of class "Play"
    play = Play()
    assert play is not None
    data = {
        'roles': [],
        'included_path': None,
        'action_groups': {},
        'group_actions': {},
        '_name': 'some_name',
        '_handlers': [],
        '_tasks': [],
        '_block': [],
        '_default_vars': {},
        '_vars_prompt': [],
        '_vars_files': [],
        '_roles': [],
        '_dependent_collections': [],
        '_dependent_items': None
    }
    play.deserialize(data)

# Generated at 2022-06-21 00:46:05.666739
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    Unit test for method get_tasks of class Play
    '''
    config = [{
        'name': 'test_Play_get_tasks',
        'connection': 'local',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [{
            'name': 'test_Play_get_tasks1',
            'assert': {
                'that': 1 == 1,
            }
        }, {
            'name': 'test_Play_get_tasks2',
            'assert': {
                'that': 1 == 1,
            }
        }]
    }]
    obj = Play().load(config, variable_manager=None, loader=None)
    tasks = obj.get_tasks()
    assert len(tasks) == 2


# Generated at 2022-06-21 00:46:17.188238
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Setup
    p = Play()
    p.vars_files = []

    # Assertion 1:
    assert p.get_vars_files() == []

    # Setup
    p.vars_files = ['/etc/ansible/test.yml']

    # Assertion 2:
    # Note: the potential difference between Python 2 and Python 3
    # is irrelevant since this code is meant to be run on Python 2
    assert p.get_vars_files() == ['/etc/ansible/test.yml']

    # Setup
    p.vars_files = '/etc/ansible/test1.yml'

    # Assertion 3:
    # Note: the potential difference between Python 2 and Python 3
    # is irrelevant since this code is meant to be run on Python 2
    assert p.get_

# Generated at 2022-06-21 00:46:28.170778
# Unit test for method serialize of class Play

# Generated at 2022-06-21 00:46:32.385446
# Unit test for method copy of class Play
def test_Play_copy():
    """Test copy of class Play"""
    obj = Play()
    copy1 = obj.copy()
    copy2 = obj.copy()
    assert copy1 == copy2
    assert copy1 is not copy2



# Generated at 2022-06-21 00:46:35.051746
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {}
    assert p.get_vars() == {}



# Generated at 2022-06-21 00:46:45.206377
# Unit test for method load of class Play
def test_Play_load():
    play = Play.load(test_data.testdata.get('Play.load'))
    assert play.name == 'test'
    assert play.hosts == 'localhost'
    assert play.connection == 'local'
    assert not play.become
    assert not play.become_user
    assert play.roles[0].name == 'base_install'
    assert play.roles[0].get_default_vars(play=play)['test'] == True
    assert play.tasks[0].action == 'shell'
    assert not play.tasks[0].register

# Generated at 2022-06-21 00:47:02.957326
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # test creation of object Play
    play = Play()
    # test creation of object Host
    host = Host()
    assert(host.name == None)
    assert(host.host_name == None)
    assert(host.port == None)
    assert(host.vars == {})
    assert(host.groups == [])
    assert(host.has_vars({'key': 'value'}) == False)
    # test get_host of class Play
    return_value = play.get_host(host.name)
    assert(return_value == host.name)
    # test check_vars of class Play
    play.get_variables(loader=None, variables=None)
    # test get_variables of class Play

# Generated at 2022-06-21 00:47:16.176282
# Unit test for method load of class Play
def test_Play_load():
    # Data model
    data = {
        'name': 'test_play',
        'hosts': 'localhost',
        'connection': 'local',
        'any_errors_fatal': False,
        'serial': 1,
        'roles': [
            {
                'name': 'common',
                'tasks': [{
                    'name': 'first_common_task',
                    'action': {'module': 'shell', 'args': 'echo "hello"'},
                }],
                'vars': {
                    'var_a': 'A',
                    'var_b': 'B',
                    'var_c': 'C',
                },
            },
        ],
    }

    # Initialize
    play = Play.load(data)
    assert play.get_name() == 'test_play'
   

# Generated at 2022-06-21 00:47:23.526206
# Unit test for method copy of class Play
def test_Play_copy():
    print("Play test")
    new_me = super(Play, self).copy()
    new_me.ROLE_CACHE = self.ROLE_CACHE.copy()
    new_me._included_conditional = self._included_conditional
    new_me._included_path = self._included_path
    new_me._action_groups = self._action_groups
    new_me._group_actions = self._group_actions
    return new_me

# Generated at 2022-06-21 00:47:30.827677
# Unit test for method get_name of class Play

# Generated at 2022-06-21 00:47:33.296545
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    result = p.preprocess_data('test')
    assert result == 'test'

# Generated at 2022-06-21 00:47:34.689738
# Unit test for constructor of class Play
def test_Play():
    assert Play()


# Generated at 2022-06-21 00:47:40.185591
# Unit test for method compile of class Play
def test_Play_compile():
    a = Play()
    a.pre_tasks = ['pre_tasks']
    a.tasks = ['tasks']
    a.post_tasks = ['post_tasks']
    a.roles = ['roles']
    b = a.compile()
    expected_output = ['pre_tasks', 'tasks', 'post_tasks']
    assert b == expected_output


# Generated at 2022-06-21 00:47:47.744745
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play.load(dict(
        hosts='localhost',
        tasks=[
            dict(
                block=[dict(action=dict(module='customModule'))],
                rescue=[dict(action=dict(module='customModule'))],
                always=[dict(action=dict(module='customModule'))]
            )
        ]
    ))


# Generated at 2022-06-21 00:47:55.403930
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansiblelint.rules.AnsibleLintRule import AnsibleLintRule
    from ansiblelint.rules.FileModeShouldBeUppercaseRule import FileModeShouldBeUppercaseRule
    from ansiblelint.rules.DebugStatementsRule import DebugStatementsRule
    from ansiblelint.rules.MainHasUnownedPrivFileOrDir import MainHasUnownedPrivFileOrDir
    from ansiblelint.rules.UserHasUnownedPrivFileOrDir import UserHasUnownedPrivFileOrDir
    from ansiblelint.rules.PackageInstalledNotLatestRule import PackageInstalledNotLatestRule
    from ansiblelint.rules.PackageInstalledWithVersionRule import PackageInstalledWithVersionRule
    from ansiblelint.rules.TaskHasNoNameRule import TaskHasNoNameRule

# Generated at 2022-06-21 00:47:57.803467
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play_instance = Play()
    assert isinstance(play_instance.get_handlers(), list)


# Generated at 2022-06-21 00:48:23.551944
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test_play'
    assert p.get_name() == 'test_play'

# Generated at 2022-06-21 00:48:34.038576
# Unit test for constructor of class Play
def test_Play():
    p1 = Play()
    p2 = Play(name="test")
    p2.load(dict(hosts=[1, 2, 3]))
    p3 = Play().load(dict(hosts=[1, 2, 3]))
    assert p1 is not None
    assert p2 is not None
    assert p3 is not None
    assert p1.name is None
    assert p2.name == "test"
    assert p3.name is None
    assert len(p1.hosts) == 0
    assert len(p2.hosts) == 3
    assert len(p3.hosts) == 3


# Generated at 2022-06-21 00:48:43.903985
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    user = dict()
    user['name'] = 'test'
    user['password'] = 'test'

    # Prepare a test data set with user and remote_user
    data = {'name': 'LAMP setup', 'user': '{{ username }}'}
    p = Play()
    data = p.preprocess_data(data)

    # Check if data contains remote_user
    assert 'remote_user' in data
    # Check if data does not contain user
    assert 'user' not in data
    # Check if data is a dictionary
    assert isinstance(data, dict)
    
    

# Generated at 2022-06-21 00:48:56.727261
# Unit test for constructor of class Play
def test_Play():
    """
    Test constructor of class Play
    """

    play = Play()

    # Validating the type of the '_roles' attribute
    assert isinstance(play._roles, list), "The '_roles' attribute should be a list, but it is: %s" % type(play._roles)

    # Validating the type of the '_handlers' attribute
    assert isinstance(play._handlers, list), "The '_handlers' attribute should be a list, but it is: %s" % type(play._handlers)

    # Validating the type of the '_pre_tasks' attribute
    assert isinstance(play._pre_tasks, list), "The '_pre_tasks' attribute should be a list, but it is: %s" % type(play._pre_tasks)

    # Validating

# Generated at 2022-06-21 00:49:07.534846
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    """
    Unit test for method get_roles of class Play
    """
    ################################################################################
    # Unit test for method get_roles of class Play
    
    # Create test object
    play_obj = Play()
    
    # Get value of object when object has no data for key 'roles'.
    # Should return empty list
    assert play_obj.get_roles() == []
    
    # Create test object
    play_obj = Play()
    # Add roles to the object.
    role_obj_1 = Role()
    role_obj_1.name = "role"
    role_obj_2 = Role()
    role_obj_2.name = "role1"
    play_obj.roles.append(role_obj_1)

# Generated at 2022-06-21 00:49:11.010112
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    data = {'name': 'test', 'hosts': 'testhosts'}
    play.load_data(data)
    serialize = play.serialize()
    assert data == serialize

# Generated at 2022-06-21 00:49:22.993949
# Unit test for method load of class Play

# Generated at 2022-06-21 00:49:33.375995
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()

# Generated at 2022-06-21 00:49:39.314359
# Unit test for method load of class Play
def test_Play_load():
    from ansible.playbook.play import load
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleAssertionError
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleParserError
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

# Generated at 2022-06-21 00:49:42.514316
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    # set up test Play
    p = Play()
    p.handlers = ['handlers']
    assert p.handlers == p.get_handlers()


# Generated at 2022-06-21 00:50:06.852367
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    __repr__ = getattr(Play, '__repr__', None)
    assert __repr__ is not None



# Generated at 2022-06-21 00:50:12.056695
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    '''
    Unit test for method get_handlers of class Play
    '''
    play = Play()
    play.handlers = 'handlers'
    assert play.get_handlers() == 'handlers'


# Generated at 2022-06-21 00:50:16.199408
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {"host": "172.26.7.11"}
    assert p.get_vars() == p.vars.copy()


# Generated at 2022-06-21 00:50:23.537555
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # https://github.com/ansible/ansible-modules-core/issues/4454
    play = Play()
    data = {
        'hosts': 'all',
        'vars': {'roles': 'common'},
        'tasks': [
            {'include_role': {
                'name': 'some_role',
                'user': 'joe',
                'vars': {
                    'localhost': {'a': 1}
                },
            }},
            {'action': 'break'},
        ],
    }
    play.preprocess_data(data)
    assert data['tasks'][0]['include_role']['vars']['local'] == {'a': 1}

# Generated at 2022-06-21 00:50:35.049713
# Unit test for method compile of class Play
def test_Play_compile():
    #  #
    #  Play.compile()
    #  #

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager


    my_host = Host('localhost')
    my_host.set_variable('ansible_connection', 'local')
    my_host.set_variable('ansible_python_interpreter', sys.executable)
    my_host.set_variable('ansible_shell_executable', '/bin/sh')


    group = Group('my_group')
    group.add

# Generated at 2022-06-21 00:50:36.445059
# Unit test for method get_roles of class Play
def test_Play_get_roles():
      play = Play()
      play.roles = []
      assert play.get_roles() == []

# Generated at 2022-06-21 00:50:44.909080
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    role = Role()
    role1 = Role()
    role2 = Role()
    handler = Handler()
    play.roles = [role, role1, role2]
    role.get_handler_blocks = MagicMock(return_value=handler)
    role1.get_handler_blocks = MagicMock(return_value=handler)
    role2.get_handler_blocks = MagicMock(return_value=handler)
    result = play.compile_roles_handlers()
    assert result == [handler, handler, handler]


# Generated at 2022-06-21 00:50:51.323223
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Test set up
    p = Play()
    role1 = Role()
    role2 = Role()
    role3 = Role()
    p.roles = [role1, role2]
    # Test execution
    result = p.get_roles()
    # Test verification
    assert result == [role1, role2], "Wrong result returned. Expected: [role1, role2], received: %s" % result
    # Test result handling
    assert result == [role1, role2], "Wrong handling of result. Expected: [role1, role2], received: %s" % result
    # Test teardown
    # N/A


# Generated at 2022-06-21 00:50:55.124274
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    play = Play()
    assert play.get_roles() == []
    roles = [ Role() ]
    play.roles = roles
    assert play.get_roles() == roles


# Generated at 2022-06-21 00:51:08.890206
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    self = Play()
    assert self.compile_roles_handlers() == []
    self.roles = [MockRole(from_include=False), MockRole(), MockRole(from_include=False)]
    self.roles[0].get_handler_blocks = MockRoleGetHandlerBlocks([[1, 2], [3]])
    self.roles[2].get_handler_blocks = MockRoleGetHandlerBlocks([[4, 5], [6]])
    assert self.compile_roles_handlers() == [1, 2, 3, 4, 5, 6]
    self.roles = [MockRole(), MockRole(from_include=False)]
    self.roles[1].get_handler_blocks = MockRoleGetHandlerBlocks([[4, 5], [6]])
    assert self.compile_ro

# Generated at 2022-06-21 00:52:04.390544
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.utils import template
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    # a template can be used to generate a config file
    # import jinja2
    #
    # jinja_env = jinja2.Environment()
    #
    # jinja_env.loader = jinja2.FileSystemLoader(searchpath="/Users/xiao/Documents/A2-master")
    #
    # template = jinja_env.get_template('/home/xiao/Documents/A2-master/test.playbook.yml')
    #
    # print(template.render(host=['127.0.0.1']))

    pc = PlayContext

# Generated at 2022-06-21 00:52:05.272910
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    play.compile()


# Generated at 2022-06-21 00:52:07.601210
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = 'test'
    assert repr(play) == 'test'

# Generated at 2022-06-21 00:52:10.804528
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    assert play.get_vars() == {}


play = Play()
play.get_vars()

# Generated at 2022-06-21 00:52:12.759017
# Unit test for method serialize of class Play
def test_Play_serialize():
    my_play = Play()


# Unit tests for method deserialize of class Play

# Generated at 2022-06-21 00:52:20.021277
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Play.tasks is the list of tasks for this play.  This is a list of Block objects.
    # The Block objects are not added to the task list.

    # This object will be used to return the results of the test
    result = {}

    # The list of tasks
    task_list = []

    # Initialize the Play object
    play = Play()
    play.tasks = task_list

    # The expected result
    expected_result = copy.deepcopy(task_list)

    # The actual result
    actual_result = play.get_tasks()

    if actual_result == expected_result:
        result['rc'] = 0
    else:
        result['rc'] = 1

# Generated at 2022-06-21 00:52:28.588791
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    ds = {'hosts': 'all', 'user': 'root'}
    if p.preprocess_data(ds) != {'hosts': 'all', 'remote_user': 'root'}:
        raise Exception('test_Play_preprocess_data failed')
    ds = {'hosts': 'all'}
    if p.preprocess_data(ds) != ds:
        raise Exception('test_Play_preprocess_data failed')
test_Play_preprocess_data()

# Generated at 2022-06-21 00:52:39.066873
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    role = RoleInclude()
    
    role.name = "role1"
    role.play = Play()