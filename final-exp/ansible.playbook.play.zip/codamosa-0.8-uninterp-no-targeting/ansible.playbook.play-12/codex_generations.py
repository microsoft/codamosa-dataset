

# Generated at 2022-06-21 00:43:03.777040
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_obj = Play()
    play_obj.block_start = datetime(1970,1,1)
    play_obj.tasks = [{'foo': 'hello world'}]
    assert(play_obj.get_tasks() == [{'foo': 'hello world'}])



# Generated at 2022-06-21 00:43:05.861378
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    assert True


# Generated at 2022-06-21 00:43:09.317986
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert isinstance(play.__repr__(), str)


# Generated at 2022-06-21 00:43:16.173109
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ['myfile']
    assert p.get_vars_files() == ['myfile'], "get_vars_files() failed to retrieve a single file."
    p.vars_files = ['myfile1','myfile2']
    assert p.get_vars_files() == ['myfile1','myfile2'], "get_vars_files() failed to retrieve multiple files."
    p.vars_files = None
    assert p.get_vars_files() == [], "get_vars_files() failed to retrieve an empty list."


# Generated at 2022-06-21 00:43:17.683788
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
 
    pass

# Generated at 2022-06-21 00:43:22.550505
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    
    # Create a Play object
    play = Play()
    play.vars = dict(foo=1)
    
    # Expect the same type but with different ID
    assert isinstance(play.get_vars(), dict)
    assert play.get_vars() != play.vars
    
    # Test that the dict has been copied
    assert play.get_vars() == dict(foo=1)
    

# Generated at 2022-06-21 00:43:33.230218
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.vars = {
        'a': 'b'
    }
    p.tasks = [
        {
            'include': 'vars7.yaml'
        }
    ]
    p.vars_files = [
        'vars2.yaml',
        {
            'include': 'vars3.yaml',
            'foo': 'bar'
        }
    ]
    p.roles = [
        'common',
        {
            'name': 'common2',
            'foo': 'bar'
        }
    ]
    p.handlers = [
        'common',
        {
            'include': 'common3',
            'foo': 'bar'
        }
    ]
    p.name = 'myplay'

# Generated at 2022-06-21 00:43:35.443668
# Unit test for method load of class Play
def test_Play_load():
    # Just initialize
    play = Play()
    assert play._included_conditional is None

# Generated at 2022-06-21 00:43:43.457027
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    
    play = Play()
    
    assert play.get_vars_files() == []
    
    play.vars_files = 'a'
    assert play.get_vars_files() == ['a']
    
    play.vars_files = ['b']
    assert play.get_vars_files() == ['b']
    
    return True


# Generated at 2022-06-21 00:43:45.740588
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    assert repr(play) == play.get_name()


# Generated at 2022-06-21 00:44:06.687861
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''Unit test for method get_vars_files of class Play.'''
    p = Play()
    assert p.get_vars_files() == []
    p.__dict__['vars_files'] = None
    assert p.get_vars_files() == []
    p.__dict__['vars_files'] = 'string'
    assert p.get_vars_files() == ['string']
    p.__dict__['vars_files'] = ['string', 'string']
    assert p.get_vars_files() == ['string', 'string']
    p.__dict__['vars_files'] = ['string']
    assert p.get_vars_files() == ['string']

# Generated at 2022-06-21 00:44:15.673047
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    obj = Play(loader=None, variable_manager=None, use_handlers=False, task_include=None)
    obj.vars_files = None
    assert obj.get_vars_files() == []
    obj.vars_files = []
    assert obj.get_vars_files() == []
    obj.vars_files = [u'/tmp/foo_3/vars']
    assert obj.get_vars_files() == [u'/tmp/foo_3/vars']
    obj.vars_files = [u'/tmp/foo_4/vars']
    assert obj.get_vars_files() == [u'/tmp/foo_4/vars']



# Generated at 2022-06-21 00:44:28.259708
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
  # Initialize the Play class object 
  # NOTE: for now, we are not using the real test data file as input as the
  # whole data structure is not getting parsed properly from yaml to python
  # which is breaking the tests
  #p = Play.load(create_valid_data_dict())
  p = Play()
  # Test 1
  expected_result = []
  actual_result = p.get_vars_files()
  assert actual_result == expected_result
  # Test 2
  p.vars_files = '/path/to/file'
  expected_result = ['/path/to/file']
  actual_result = p.get_vars_files()
  assert actual_result == expected_result
  # Test 3

# Generated at 2022-06-21 00:44:40.239140
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name="user input test",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='command', args=dict(cmd='echo hi'))),
        ]
    )
    # Test that a dict is not changed if it does not have a 'user' key
    user_play_source = play_source.copy()
    assert not user_

# Generated at 2022-06-21 00:44:43.274801
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    #play = Play()
    #play.get_vars()
    pass

# Generated at 2022-06-21 00:44:50.153591
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'Test Play'
    
    # Test for name
    assert_equal(play.get_name(), 'Test Play')
    
    # Test for host
    play.hosts = 'hostA'
    assert_equal(play.get_name(), 'hostA')
    
    # Test for hosts
    play.hosts = ['hostA', 'hostB', 'hostC']
    assert_equal(play.get_name(), 'hostA,hostB,hostC')


# Generated at 2022-06-21 00:45:01.949980
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # test with an empty dictionary
    ds = {}
    p = Play()
    result = p.preprocess_data(ds)
    assert result == ds

    # test with a dictionary with 'user' key
    ds = {'user': 'jack', 'hosts' : 'all'}
    p = Play()
    result = p.preprocess_data(ds)
    assert result == {'hosts': 'all', 'remote_user': 'jack'}

    # test with a dictionary with 'remote_user' key
    ds = {'remote_user': 'jack', 'hosts' : 'all'}
    p = Play()
    result = p.preprocess_data(ds)
    assert result == {'hosts': 'all', 'remote_user': 'jack'}

    # test with a dictionary with

# Generated at 2022-06-21 00:45:09.951445
# Unit test for constructor of class Play
def test_Play():
    def test(obj, result):
        assert obj._ds == result
        assert obj.tasks is result['tasks']
        assert obj.handlers is result['handlers']
        assert obj.roles is result['roles']
        assert obj.vars is result['vars']
        assert obj.vars_files is result['vars_files']
        assert obj.tags is result['tags']
        assert obj.hosts is result['hosts']
        assert obj.name is result['name']
        assert obj.gather_facts is result['gather_facts']
        assert obj.remote_user is result['remote_user']
        assert obj.sudo is result['sudo']
        assert obj.sudo_user is result['sudo_user']
        assert obj.become is result['become']
        assert obj.become_

# Generated at 2022-06-21 00:45:19.657743
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
  play = Play()
  play.vars_files=["/home/ansible/vars_files/sample_var"]
  assert play.get_vars_files() == ['/home/ansible/vars_files/sample_var']
  play.vars_files=None
  assert play.get_vars_files() == []
  play.vars_files="test_string"
  assert play.get_vars_files() == ['test_string']

# Generated at 2022-06-21 00:45:32.683408
# Unit test for method compile of class Play

# Generated at 2022-06-21 00:45:51.951447
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    pl = Play()
    pl.name = 'A play'
    assert pl.__repr__() == 'A play'
    pl2 = Play()
    pl2.hosts = ['host1']
    assert pl2.__repr__() == 'host1'
    pl3 = Play()
    pl3.hosts = ['host1', 'host2']
    assert pl3.__repr__() == 'host1,host2'


# Generated at 2022-06-21 00:45:57.084514
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    test_play = Play()
    test_play.vars = dict(test_var='test_var')
    assert test_play.get_vars() == dict(test_var='test_var')


# Generated at 2022-06-21 00:46:06.927418
# Unit test for method compile of class Play
def test_Play_compile():
    import ansible.constants as ansible_constants
    import ansible.plugins.loader as ansible_plugins_loader
    import ansible.vars.hostvars as ansible_vars_hostvars
    import ansible.vars.manager as ansible_vars_manager
    
    ansible_constants.DEFAULT_HASH_BEHAVIOUR = "md5"
    ansible_constants.DEFAULT_KEEP_REMOTE_FILES = 0
    ansible_constants.DEFAULT_PRIVATE_ROLE_VARS = 1
    ansible_constants.DEFAULT_REMOTE_TMP = "/tmp"
    ansible_constants.DEFAULT_SUDO = True
    ansible_constants.DEFAULT_SUDO_EXE = "/usr/bin/sudo"


# Generated at 2022-06-21 00:46:09.609855
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    self = Play()
    self.roles = [Role()]
    assert 1 == len(self.get_roles())

# Generated at 2022-06-21 00:46:14.229989
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    my_play = Play()
    my_play.get_name = MagicMock(return_value='my_play')
    assert my_play.__repr__() == 'my_play'
    my_play.get_name.assert_called_once_with()



# Generated at 2022-06-21 00:46:27.023009
# Unit test for method copy of class Play
def test_Play_copy():
  play = Play()
  play.ROLE_CACHE = {'key1':'value'} # This is a dict
  play._included_conditional = 'condition'
  play._included_path = 'path'
  play._action_groups = {'key1':'value'} # This is a dict
  play._group_actions = {'key2':'value'} # This is a dict
  assert play.ROLE_CACHE == {'key1':'value'}
  assert play._included_conditional == 'condition'
  assert play._included_path == 'path'
  assert play._action_groups == {'key1':'value'}
  assert play._group_actions == {'key2':'value'}
  new_play = play.copy()
  assert new_play

# Generated at 2022-06-21 00:46:36.744752
# Unit test for method compile of class Play
def test_Play_compile():
    # Create an instance of Play
    data = {'name': 'heartbeat', 'connection': 'local', 'hosts': '1.1.1.1', 'roles': []}
    play = Play()

    # Test block_list empty
    result = play.compile()
    assert result == [], "Incorrect result: should be [], not {}".format(result)

    # Test role empty
    setattr(play, 'roles', [])
    result = play.compile()
    assert result == [], "Incorrect result: should be [], not {}".format(result)

    # Test role not empty
    r = Role()
    setattr(play, 'roles', [r])
    result = play.compile()

# Generated at 2022-06-21 00:46:41.586044
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    import ansible.playbook.play
    obj = ansible.playbook.play.Play()
    obj.get_name = Mock(return_value=sentinel.name)
    repr(obj) == sentinel.name

# Generated at 2022-06-21 00:46:48.154829
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p_dict = {
        'hosts': 'all',
        'roles': [
            {
                'tasks': [
                    {
                        'debug': {
                            'msg': '{{test}}'
                        }
                    }
                ]
            }
        ]
    }
    p = Play()
    p.deserialize(p_dict)
    assert p.hosts == 'all'
    assert p.roles[0].tasks[0].name == 'debug'
    assert 'test' in p.roles[0].tasks[0].args


# Generated at 2022-06-21 00:46:50.901721
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = ""
    assert play.get_name() == ""


# Generated at 2022-06-21 00:47:04.832327
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    p = Play()
    name = p.get_name()
    assert p.__repr__() == name


# Generated at 2022-06-21 00:47:10.169453
# Unit test for method copy of class Play
def test_Play_copy():
    my_play = Play()
    my_play.name = 'Test'
    loaded = my_play.copy()
    assert loaded.name == my_play.name
    assert loaded.ROLE_CACHE == my_play.ROLE_CACHE

# Generated at 2022-06-21 00:47:18.235978
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Set its attribute pre_tasks
    play.pre_tasks = [task1, task2]
    # Set its attribute tasks
    play.tasks = [task3, task4]
    # Set its attribute post_tasks
    play.post_tasks = [task5, task6]
    # Check if the method get_tasks returns a concatenation of the three attributes given above
    assert play.get_tasks() == [task1, task2, task3, task4, task5, task6]
    

# Generated at 2022-06-21 00:47:26.794128
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    mock_play = unittest.mock.MagicMock()
    test_obj = Play()
    test_obj._compile_roles = unittest.mock.MagicMock(return_value=['compiled_roles'])
    actual_result = test_obj.compile_roles_handlers()
    assert actual_result == [], 'Expected different result'



# Generated at 2022-06-21 00:47:28.292273
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert hasattr(play, 'name')
    assert isinstance(play, Play)

# Generated at 2022-06-21 00:47:32.178889
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p.hosts = 'localhost'
    try:
        p.compile()
    except Exception as e:
        print(e)
    if len(p.compile())>0:
        print(p.compile())
        print('Play.compile() -> %s'%p.compile())
        raise AssertionError('The Play.compile() method is not error-free')
    else:
        print('The Play.compile() method is working')


# Generated at 2022-06-21 00:47:38.217657
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    my_play = Play()
    my_play.vars_files = 'test'
    assert my_play.get_vars_files() == ['test']
    my_play.vars_files = ['test', 'test2']
    assert my_play.get_vars_files() == ['test', 'test2']
    my_play.vars_files = None
    assert my_play.get_vars_files() == []


# Generated at 2022-06-21 00:47:46.763827
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p._initialize_data_structures()

    p.deserialize({
        'name': 'Test Play',
        'hosts': {
            'raw_name': 'localhost',
            'name': 'localhost',
            'pattern': 'localhost',
            'raw_addresses': ['127.0.0.1'],
            'hash_name': 'localhost'
        },
        'roles': [
            {
                'name': 'test-role',
                'path': '/etc/ansible/roles/test'
            },
            {
                'name': 'test-role-2',
                'path': 'test_role_2'
            }
        ],
        'included_path': '/etc/ansible/playbooks/playbook.yml'
    })

#

# Generated at 2022-06-21 00:47:51.967379
# Unit test for method compile of class Play
def test_Play_compile():
  up = {}
  up['gather_facts'] = 'no'
  up['hosts'] = 'all'
  p = Play.load(up, variable_manager=None, loader=None, vars=None)
  assert p.gather_facts == 'no'
  assert p.hosts == 'all'
  assert p.compile() == []
  

# Generated at 2022-06-21 00:48:01.389809
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

    data = {}
    data['name'] = 'localhost'
    data['hosts'] = 'localhost'
    data['roles'] = []
    data['included_path'] = 'playbooks/play.yml'
    data['action_groups'] = {}
    data['group_actions'] = {}

    play.deserialize(data)

    assert play._included_path == 'playbooks/play.yml'
    assert play._action_groups == {}
    assert play._group_actions == {}
    assert play.roles == []


# Generated at 2022-06-21 00:48:25.961008
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.get_handlers()



# Generated at 2022-06-21 00:48:30.851915
# Unit test for constructor of class Play
def test_Play():
    play_ds = {
        'name': 'test'
    }
    play = Play.load(play_ds)
    assert play._ds == play_ds
    assert play.name == 'test'

# Generated at 2022-06-21 00:48:34.408403
# Unit test for method get_name of class Play
def test_Play_get_name():
    """
    Test for method "get_name" of class Play
    """
    Play().get_name()


# Generated at 2022-06-21 00:48:40.854209
# Unit test for method serialize of class Play

# Generated at 2022-06-21 00:48:55.191102
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = "vars_files"
    result = play.get_vars_files()
    assert result == ['vars_files']
    play.vars_files = None
    result = play.get_vars_files()
    assert result == []
    play.vars_files = [
        '/path/to/file1.yaml',
        '/path/to/file2.yaml',
        '/path/to/file3.yaml',
    ]
    result = play.get_vars_files()
    assert result == [
        '/path/to/file1.yaml',
        '/path/to/file2.yaml',
        '/path/to/file3.yaml',
    ]


# Generated at 2022-06-21 00:49:00.690803
# Unit test for method get_roles of class Play
def test_Play_get_roles():
     # Test code
     a = Play()
     a._roles = ['a list', 'of', 'strings']
     assert a.get_roles() == ['a list', 'of', 'strings']


# Generated at 2022-06-21 00:49:02.808408
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    assert Play().__repr__() == Play().__str__()


# Generated at 2022-06-21 00:49:09.343841
# Unit test for method get_vars of class Play
def test_Play_get_vars():
  '''
  Unit test for method get_vars of class Play
  '''
  # Create an instance of class Play without arguments
  play = Play()
  # Get attribute vars from the instance of class Play
  play.vars = dict()
  # Assert that the instance of class Play returns the correct get_vars
  assert play.get_vars() == dict()

# Generated at 2022-06-21 00:49:23.705651
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class MockPlay():
        def __init__(self):
            self.roles = []
            self.vars_prompt = []
            self.handlers = []
            self.vars = []
            self.pre_tasks = []
            self.post_tasks = []
            self.tasks = []
            
        def get_roles(self):
            return self.roles 

        def get_vars(self):
            return self.vars

        def get_vars_files(self):
            return self.vars_files

        def get_handlers(self):
            return self.handlers

        def get_tasks(self):
            return self.pre_tasks + self.tasks + self.post_tasks
    
    play = Play()
    assert play.get_t

# Generated at 2022-06-21 00:49:26.001912
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    p = Play()
    p.handlers = [
        dict(name='fake task')
    ]
    assert p.get_handlers()[0]['name'] == 'fake task'

# Generated at 2022-06-21 00:49:53.832526
# Unit test for method load of class Play
def test_Play_load():
    # test load method of class Play
    test_play = Play.load(data={'name': 'test_play', 'hosts': []})
    assert len(test_play.roles) == 0
    assert isinstance(test_play, Play)
    assert test_play.name == 'test_play'
    test_play = Play.load(data={'name': 'test_play', 'hosts': 'all'})
    assert test_play.name == 'test_play'



# Generated at 2022-06-21 00:50:04.928087
# Unit test for constructor of class Play
def test_Play():
    play1 = Play()
    assert play1 is not None

    from ansible.playbook.block import Block
    from ansible.playbook.role import RoleInclude

    ds = dict(
        name="test play",
        hosts="testhost",
        gather_facts=False,
        remote_user="testuser",
        pre_tasks=[],
        roles=[
            RoleInclude.load(dict(
                name="testrole",
            )),
        ],
        tasks=[],
    )
    play2 = Play.load(ds)
    assert play2.name == "test play"
    assert play2.hosts == ["testhost"]
    assert play2.remote_user == "testuser"
    assert play2.gather_facts is False

# Generated at 2022-06-21 00:50:10.319843
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    fake_play_data = dict(
        hosts='all',
    )
    preprocessed_data = p.preprocess_data(fake_play_data)
    assert preprocessed_data is not None

# Generated at 2022-06-21 00:50:19.048678
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['./vars_files/1.yml','./vars_files/2.yml']
    vars_files = play.get_vars_files()
    # vars_files is a list
    assert isinstance(vars_files, list)
    # the length of vars_files is 2
    assert len(vars_files) == 2
    # vars_files is ['./vars_files/1.yml','./vars_files/2.yml']
    assert vars_files == ['./vars_files/1.yml','./vars_files/2.yml']


# Generated at 2022-06-21 00:50:20.848226
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert Play().get_name() == ''


# Generated at 2022-06-21 00:50:34.181803
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )


# Generated at 2022-06-21 00:50:44.870720
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    new_Play = Play()
    new_Play._tasks = None
    new_Play._handlers = None
    new_Play._tasks = None
    new_Play.ROLE_CACHE = None
    new_Play._included_conditional = None
    new_Play._included_path = None
    new_Play._removed_hosts = None
    new_Play.only_tags = None
    new_Play.skip_tags = None
    new_Play._action_groups = None
    new_Play._group_actions = None
    new_str = str(new_Play)
    assert type(new_str) == str


# Generated at 2022-06-21 00:50:48.340775
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = "Test"
    assert play.__repr__() == "Test"


# Generated at 2022-06-21 00:50:55.468507
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_Play = Play()
    test_Play.pre_tasks = ["task_1", "task_2"]
    test_Play.tasks = ["task_3", "task_4"]
    test_Play.post_tasks = ["task_5", "task_6"]
    expected_output = ["task_1", "task_2", "task_3", "task_4", "task_5", "task_6"]
    assert(test_Play.get_tasks() == expected_output)

# Generated at 2022-06-21 00:51:09.117479
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import ansible.playbook.play_context
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.template
    import ansible.vars.manager
    import ansible.vars.hostvars
    import ansible.vars.hostvars
    import ansible.vars.hostvars
    import ansible.vars.hostvars
    import ansible.vars.hostvars
    import ansible.vars.hostvars
    import ansible.vars.vars
    import ansible.vars.unsafe_proxy
    import ansible.vars.unsafe_proxy
    # Instantiation
    play_context = ansible.playbook.play_context.Play

# Generated at 2022-06-21 00:51:33.587930
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass #TODO: implement your test here


# Generated at 2022-06-21 00:51:36.089295
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    # Test with roles being None
    my_play = Play()
    my_play.roles = None
    assert my_play.get_roles() == []


# Generated at 2022-06-21 00:51:43.022444
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Load a test Play
    data = {
        'name': 'Test Playbook',
        'hosts': 'all',
        'roles': [
            {'role': 'r1'},
            {'role': 'r2', 'tasks': [{'debug': 'msg=foo'}]}
        ],
        'tasks': [{'debug': 'msg=bar'}]
    }
    play = Play().load(data, variable_manager=VariableManager(), loader=DataLoader())

    # This play has no handlers, so no handlers are returned
    assert play.compile_roles_handlers() == []

    # Add a handler to r1, then r2

# Generated at 2022-06-21 00:51:49.451726
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() == '', 'Name should be an empty string'
    p.name = 'test_play'
    assert p.get_name() == 'test_play', 'Name should be test_play'
    p.name = None
    p.hosts = 'test_host'
    assert p.get_name() == 'test_host', 'Name should be "test_host"'
    p.hosts = ['test_host']
    assert p.get_name() == 'test_host', 'Name should be "test_host"'

# Generated at 2022-06-21 00:51:53.747976
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    p = Play()
    p.vars = {'a': 'b'}
    assert p.get_vars() == {'a': 'b'}

# Generated at 2022-06-21 00:51:55.791400
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # TODO: write unit test for method get_vars
    assert False

# Generated at 2022-06-21 00:52:04.364032
# Unit test for method compile of class Play
def test_Play_compile():
    play = Play()
    
    
    play.tasks = ''
    play.roles = play.roles
    play.roles = ''
    play.roles = play._compile_roles()
    
    
    
    
    
    
    



# Generated at 2022-06-21 00:52:05.673095
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    logger.info(play)
    logger.info(play)
#test_Play_deserialize()



# Generated at 2022-06-21 00:52:11.728698
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    '''
    Unit test function, should not be called directly
    '''
    print("testing function get_handlers of class Play")
    play = Play()
    assert play.get_handlers() == [], "Play.get_handlers() returns wrong output"
    play.handlers = ['test-block']
    assert play.get_handlers() == ['test-block'], "Play.get_handlers() returns wrong output"

# Generated at 2022-06-21 00:52:12.594339
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    pass

# Generated at 2022-06-21 00:52:48.579452
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # This import is needed for the test_loader to successfully run
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars

    # Create our Play
    p = Play()
    # Create the Play's PlayContext, loading settings from the CLI
    p.context = PlayContext()

    # Create our array of roles to load
    roles = []
    # Create our array of handlers to return
    h = []

    # Generate a Temporary Directory, to hold our test roles
    td = tempfile.TemporaryDirectory()
    # Create the path to our roles, so we can load them
    role_path = '%s/roles' % td.name

    # Create our 'test' role