

# Generated at 2022-06-21 00:43:07.300761
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    # test if the fields in the class is initialized correctly
    assert play._ds is None
    assert play._included_path is None
    assert play._removed_hosts == []
    assert play.ROLE_CACHE == {}
    assert play.only_tags == set(('all',))
    assert play.skip_tags == set()
    assert play._action_groups == {}
    assert play._group_actions == {}


# Generated at 2022-06-21 00:43:14.179131
# Unit test for method __repr__ of class Play
def test_Play___repr__():

    host = loader.load_from_file('test/units/tags/play.yml')[1]['hosts']
    obj = Play()
    obj._ds = host
    obj.post_validate(obj._ds, None)
    obj.preprocess_data(obj._ds)
    obj.preprocess_data(host)
    obj.post_validate(host, None)
    obj.deserialize(host)
    obj.copy()
    obj.load(host, None, None, None)
    assert isinstance(obj.__repr__(), str)

# Generated at 2022-06-21 00:43:19.467001
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = {'user': 'root'}
    play = Play()
    assert 'user' in play.preprocess_data(data)
    assert 'remote_user' in play.preprocess_data(data)

# Generated at 2022-06-21 00:43:31.252234
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # Arguments used for instantiating an object of class Play
    args={}
    args['become'] = None
    args['become_method'] = None
    args['become_user'] = None
    args['check'] = None
    args['connection'] = None
    args['diff'] = None
    args['directory'] = None
    args['environment'] = {}
    args['hosts'] = None
    args['name'] = None
    args['no_log'] = None
    args['remote_user'] = None
    args['roles'] = []
    args['serial'] = []
    args['tags'] = []
    args['tasks'] = []
    args['transport'] = None
    args['vars'] = {}
    args['vars_files'] = []

# Generated at 2022-06-21 00:43:32.835691
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    assert play.get_handlers() == []

# Generated at 2022-06-21 00:43:46.310130
# Unit test for constructor of class Play
def test_Play():
    """
    This is just a basic test to ensure that objects created by the class
    Play will have all the required fields and methods and that these won't
    change without us noticing.
    """
    play_obj = Play()
    assert hasattr(play_obj, 'vars')
    assert hasattr(play_obj, 'vars_files')
    assert hasattr(play_obj, 'vars_prompt')
    assert hasattr(play_obj, 'vars_files_prompt')
    assert hasattr(play_obj, 'tags')
    assert hasattr(play_obj, 'when')
    assert hasattr(play_obj, 'notify')
    assert hasattr(play_obj, 'handlers')
    assert hasattr(play_obj, 'pre_tasks')

# Generated at 2022-06-21 00:43:55.181412
# Unit test for method compile of class Play
def test_Play_compile():
    """
    Unit test function for method compile of class Play
    """
    data = {'name': 'play1', 'hosts': 'all', 'tasks': [{'name': 'task1', 'debug': 'var=foo'}]}
    p = Play.load(data=data, variable_manager=None, loader=None)
    t = p.compile()
    assert len(t) == 1

# Generated at 2022-06-21 00:43:55.899551
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    assert True


# Generated at 2022-06-21 00:43:57.343611
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert True

# Generated at 2022-06-21 00:44:04.041476
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    """
    Test method get_roles of class Play
    """

    play = Play()
    play._load_roles("roles",[])
    assert play.get_roles() == []
    play._load_roles("roles",["one","two"])
    assert play.get_roles() == [u'one', u'two']


# Generated at 2022-06-21 00:44:14.706466
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p._compile_roles()

# Generated at 2022-06-21 00:44:18.133845
# Unit test for method __repr__ of class Play
def test_Play___repr__():
    play = Play()
    play.name = 'testPlayName'
    assert play.__repr__() == 'testPlayName'



# Generated at 2022-06-21 00:44:29.287488
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from collections import namedtuple
    import unittest
    import re
    import os.path
    class FakeRole(object):
        def __init__(name, tasks=None, handlers=None):
            self.name = name
            self.tasks = tasks or []
            self.handlers = handlers or []
        def __repr__(self):
            return repr(self.name)

    # check that the tasks of a role are executed in the right order
    x = Play()
    Tasks = namedtuple('Tasks', 'name handlers')

    role1 = FakeRole('role1')
    role1.tasks = [Tasks('task1', []), Tasks('task2', []), Tasks('task3', [])]
    role1.handlers = ['handler1', 'handler2', 'handler3']
   

# Generated at 2022-06-21 00:44:40.332079
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    """Test get_vars method from class Play"""
    from ansible.playbook.play_context import PlayContext
    play_obj = Play.load(dict(
        name='test-get-vars',
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='shell', args='ls'))]
    ))
    context_obj = PlayContext(play_obj)
    play_obj._variable_manager = VariableManager()
    play_obj._variable_manager.set_nonpersistent_facts(manageable_dict({'nonsense': 'nonsense_value'}))
    play_obj.vars = dict(key='value')
    assert play_obj.get_vars() == dict(key='value')

# Generated at 2022-06-21 00:44:50.956698
# Unit test for method get_name of class Play
def test_Play_get_name():

    # Create a new Play object
    p = Play()

    # Verify that method get_name returns a value that is not None
    assert p.get_name() is not None, "Error: Play.get_name: Play object 'p' has method get_name() that returns None"

    # Print results of verification
    print("Verification: Play.get_name: Play object 'p' has method get_name() that returns a value that is not None")

    # Verify that method get_name returns a string
    assert isinstance(p.get_name(), str), "Error: Play.get_name: Play object 'p' has method get_name() that does not return a string"

    # Print results of verification
    print("Verification: Play.get_name: Play object 'p' has method get_name() that returns a string")


# Run

# Generated at 2022-06-21 00:45:02.306423
# Unit test for method serialize of class Play

# Generated at 2022-06-21 00:45:06.427035
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''Test definition of Play instance method preprocess_daata
    '''
    # Test: load the module
    mod = load_module(Play)
    Play.load = lambda x, y, z : x
    # Test: expected attribute return value
    assert mod.preprocess_data('data') == 'data'



# Generated at 2022-06-21 00:45:12.687740
# Unit test for method deserialize of class Play

# Generated at 2022-06-21 00:45:23.156914
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    import pytest
    from ansiblelint import AnsibleLintRule
    from ansiblelint.rules.TestPlaybookHasHostsRule import TestPlaybookHasHostsRule
    filename = 'test/static_analysis_distribution_test/test_get_vars_function.yml'
    runner = Runner(filename, [], [], [], True, None)
    play = runner.get_plays()[0]
    vars = play.get_vars()
    assert vars == {'var1': 'string', 'var2': ['item1', 'item2'], 'var3': True, 'var4': {'key1': 'value1'}}


# Generated at 2022-06-21 00:45:32.003485
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._ds = [{
        'hosts': 'all',
        'roles': [
            {'role': 'Common_conf_Defaults'},
            {'role': 'Common_conf_Defaults'}
        ]
    }]
    p._load_vars(attr='vars', ds=[])
    p._load_roles(attr='roles', ds=p._ds[0]['roles'])
    ret = p.compile_roles_handlers()
    assert ret == []


# Generated at 2022-06-21 00:45:53.541912
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    # Create an instance of Play
    data = {}
    data['name'] = "Test Play"
    data['hosts'] = "localhost"
    data['vars_files'] = "test_vars"
    play = Play.load(data, loader=None)
    assert(play is not None)

    # Test with empty
    play.vars_files = None
    assert(play.get_vars_files() == [])
    # Test with string
    play.vars_files = "test_vars"
    assert(play.get_vars_files() == ["test_vars"])
    # Test with list
    play.vars_files = ["test_vars"]
    assert(play.get_vars_files() == ["test_vars"])


# Generated at 2022-06-21 00:46:05.242956
# Unit test for constructor of class Play

# Generated at 2022-06-21 00:46:16.983722
# Unit test for method compile of class Play
def test_Play_compile():
    args = dict(
        name='Test Play',
        hosts=['localhost'],
        remote_user='root',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play_source = dict(
        name=args['name'],
        hosts=args['hosts'],
        gather_facts='no',
        tasks=args['tasks']
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    play.post_validate(templar=Templar(variables=VariableManager()))
    task_blocks = play.compile()
    assert task_

# Generated at 2022-06-21 00:46:22.053329
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    # Create instance of class Play
    p = Play()
    # Check if the return value of method get_vars of Play is correct
    assert p.get_vars() == p.vars.copy()



# Generated at 2022-06-21 00:46:27.650212
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    d = {'user': 'a'}
    new_d = p.preprocess_data(d)
    assert new_d['remote_user'] == 'a'
    assert 'user' not in new_d


# Generated at 2022-06-21 00:46:33.062073
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2]
    play.tasks = [3, 4]
    play.post_tasks = [5, 6]
    tasks = play.get_tasks()
    assert tasks == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-21 00:46:46.353925
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object, which can then be used to instantiate a PlayContext
    play_ds = dict(
        name = "Ansible Play",
        gather_facts = 'no',
        hosts = 'webservers',
        roles = ['common', 'web', 'database'],
    )
    play_src = AnsibleFile(path=dict(path='test_play.yml', type='file'), data=play_ds)
    play_obj = Play.load(data=play_ds, variable_manager=None, loader=None, vars=None)
    play_obj.vars = {}
    play_obj.post_validate(templar=None)

    # Create a PlayContext, which is a copy of the object attributes
    play_context = PlayContext(play=play_obj)

    blocks = play

# Generated at 2022-06-21 00:46:58.213795
# Unit test for constructor of class Play
def test_Play():
    play_ds = dict(
        hosts='localhost',
        remote_user='remote_user',
        gather_facts='gather_facts',
        tasks='tasks',
        name='name',
        tags='tags',
        ignore_errors='ignore_errors',
        force_handlers='force_handlers',
        max_fail_percentage='max_fail_percentage',
        strategy='push',
    )
    play = Play.load(play_ds)
    assert play.hosts == 'localhost'
    assert play.remote_user == 'remote_user'
    assert play.gather_facts == 'gather_facts'
    assert play.tasks == 'tasks'
    assert play.name == 'name'
    assert play.tags == 'tags'
    assert play.ignore_errors == 'ignore_errors'

# Generated at 2022-06-21 00:47:02.337420
# Unit test for method get_name of class Play
def test_Play_get_name():
    play1 = Play()
    play2 = Play()
    play3 = Play()
    play4 = Play()

    play1.name = 'all'
    play2.hosts = 'all'
    play4.hosts = ['all']

    assert play1.get_name() == 'all'
    assert play1.get_name() == 'all'
    assert play1.get_name() == 'all'
    assert play1.get_name() == 'all'


# Generated at 2022-06-21 00:47:15.828348
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from collections import UserDict
    from unittest.mock import Mock, patch, MagicMock

    task_ds = '''
- meta: flush_handlers
  handlers:
    - name: test
      tags: foo
'''

# Generated at 2022-06-21 00:47:34.981536
# Unit test for constructor of class Play
def test_Play():
    # Test Ansible data for play
    data = dict(
        name="Ansible Play Test",
        hosts="localhost",
        user="root",
        tasks=[
            dict(action=dict(module="shell", args="id"), register="shell_out"),
            dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}")))
        ]
    )

    # Create play object from data
    play = Play.load(data=data)
    # Check the name of play and host
    assert play.name == 'Ansible Play Test'
    assert play.hosts == 'localhost'
    assert isinstance(play.tasks, list)
    assert len(play.tasks) == 2

    # Create play object from data

# Generated at 2022-06-21 00:47:41.563961
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    hosts = 'localhost'
    roles = [{'name': 'dummyrole', 'include_tasks': ['test_debug.yml']}]
    vars_files = ['vars1.yml', 'vars2.yml']

    p = Play().load({
        'hosts' : hosts,
        'roles' : roles,
        'vars_files' : vars_files,
    }, variable_manager=VariableManager(), loader=DictDataLoader())

    assert [role.name for role in p.get_roles()] == [role['name'] for role in roles]


# Generated at 2022-06-21 00:47:46.884265
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data({"hosts": ["localhost"], "user": "root"})
    print(play._ds)


if __name__ == '__main__':
    test_Play_preprocess_data()

# Generated at 2022-06-21 00:47:49.913139
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    from ansibleplaybook.play import Play
    play = Play()
    actual = play.get_handlers()
    answer = []
    assert actual == answer

# Generated at 2022-06-21 00:48:03.064627
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    mocker.patch('ansible.playbook.play_context.PlayContext')
    mocker.patch('ansible.playbook.play_context.CLIARGS')
    mocker.patch('ansible.playbook.play.TaskQueueManager')
    mocker.patch('ansible.playbook.play_context.PlayContext.set_task_and_variable_override')
    mocker.patch('ansible.playbook.play_context.PlayContext._set_defaults')
    mocker.patch('ansible.playbook.play_context.PlayContext._set_parent_vars')
    mocker.patch('ansible.playbook.play_context.PlayContext._set_action_and_task_vars')
    mocker.patch('ansible.playbook.play.Play')

# Generated at 2022-06-21 00:48:14.139525
# Unit test for method copy of class Play
def test_Play_copy():
    import sys
    import os
    import tempfile
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.parsing.vault.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping as DictMixin, MutableSequence as ListMixin
    from ansible.module_utils.parsing.convert_bool import boolean
    import ansible.module_utils.urls
    import ansible.module_utils.facts.virtual.base

# Generated at 2022-06-21 00:48:21.431286
# Unit test for constructor of class Play
def test_Play():

    # Construct an instance of the Play class with its important attributes
    play_ds = dict(
        name='A play',
        hosts='all',
        gather_facts='no',
        tasks=[{'action': {'module': 'setup'}}]
    )
    p = Play()
    assert type(p) == Play

    # Validate the dataclass's contructor
    p.load_data(data=play_ds)
    assert p.name == 'A play'
    assert p.hosts == 'all'
    assert p.gather_facts == 'no'
    assert len(p.tasks) == 1
    assert p.tasks[0].action['module'] == 'setup'

# Generated at 2022-06-21 00:48:32.114555
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test 1
    play = Play()
    host1 = "test1"
    host2 = "test2"
    host3 = "test3"
    play.hosts = host1
    assert play.get_name() == "test1"

    # Test 2
    play.hosts = [host1, host2, host3]
    assert play.get_name() == "test1,test2,test3"
    play.name = "name"
    assert play.get_name() == "name"



# Generated at 2022-06-21 00:48:39.150134
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    for play in _get_testdata():
        _assert_equal(
            play.get_handlers(),
            play._ds.get('handlers', []),
            msg="Failed when getting handlers for following Play:\n" + pprint.pformat(play._ds, width=144)
        )


# Generated at 2022-06-21 00:48:45.365454
# Unit test for method get_name of class Play
def test_Play_get_name():
    try:
        # Create a Play instance.
        test_obj = Play()
        test_obj.name = '127.0.0.1'
        # Get the value of get_name function under test.
        result = test_obj.get_name()
        # Assert equal.
        assert result == '127.0.0.1', "Play get_name(). Result equals '127.0.0.1' (expected)."

    except AssertionError as e:
        print(e)
        raise AssertionError(e)


# Generated at 2022-06-21 00:49:01.706742
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    # Set initial values for private attributes
    play._handlers = ['handler1']
    play._roles = []
    # Execute method under test
    play._compile_roles()
    res = play.get_handlers()
    assert res == ['handler1']


# Generated at 2022-06-21 00:49:12.958527
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create data as yaml
    data = '''
    ---
    - hosts: all
      tasks:
      - shell: echo "hello"
      handlers:
      - copy: src=copy.py dest=/copy.py
    '''
    def create_play_obj(self):
        return Play.load(data, variable_manager=variable_manager, loader=loader)

    # create object for Play class
    play_obj = create_play_obj(Play())

    # create object for Host class
    host = Host(name="test_host")

    # create object for Runner class
    runner = Runner(host=host, play=play_obj)

    # create object for ActionBase class

# Generated at 2022-06-21 00:49:16.942815
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    play = Play()
    play.vars = dict(foo='bar')
    get_vars = play.get_vars()
    assert get_vars['foo'] == 'bar'



# Generated at 2022-06-21 00:49:18.527270
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p is not None
    return

# Generated at 2022-06-21 00:49:19.229707
# Unit test for method load of class Play
def test_Play_load():
    pass

# Generated at 2022-06-21 00:49:23.704746
# Unit test for method get_vars of class Play
def test_Play_get_vars():
    from ansible.playbook.play import play
    from ansible.playbook.task import task

    ## test_method_get_vars_1
    # test_case: Return copy of variables
    play_obj = play.Play()
    play_obj.vars = {'a': 1, 'b': 2}
    play_obj.get_vars() == {'a': 1, 'b': 2}



# Generated at 2022-06-21 00:49:25.555726
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    actual = play.copy()
    assert actual == play
    # TODO: Add tests for class Play


# Generated at 2022-06-21 00:49:34.574348
# Unit test for method copy of class Play
def test_Play_copy():
    from ansible.playbook import Playbook

    playbook = Playbook()
    play = Play()
    play.vars = {'hostname': 'host1'}
    play.vars_files = ['/etc/hosts']
    play.remote_user = 'testuser'
    play.sudo_user = 'root'
    play.connection = 'local'
    play.become = False
    play.become_method = 'sudo'
    play.check_mode = False
    play.name = 'play1'
    play.hosts = ['host1', 'host2']
    play.tags = ['t1', 't2']
    play.skip_tags = ['t3', 't4']
    play.any_errors_fatal = False
    play.serial = 3
    play.max_fail_

# Generated at 2022-06-21 00:49:46.032229
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
 
    p = Play()
    p.pre_tasks = [Task()]
    p.tasks = [Task()]
    p.post_tasks = [Task()]
    block = Block()
    block.block = [Task()]
    block.rescue = [Task()]
    block.always = [Task()]
    p.pre_tasks.append(block)
    p.tasks.append(block)
    p.post_tasks.append(block)
    #print("p.pre_tasks = %s" % p.pre_tasks)
    #print("p.tasks = %s" % p.tasks)
    #

# Generated at 2022-06-21 00:49:56.824406
# Unit test for method copy of class Play
def test_Play_copy():
    play = Play()
    play.ROLE_CACHE = {"cache_key" : "cache_value"}
    play._included_conditional = self._included_conditional
    play._included_path = self._included_path
    play._action_groups = self._action_groups
    play._group_actions = self._group_actions

    new_play = play.copy()

    assert new_play.ROLE_CACHE == play.ROLE_CACHE
    assert new_play._included_conditional == play._included_conditional
    assert new_play._included_path == play._included_path
    assert new_play._action_groups == play._action_groups
    assert new_play._group_actions == play._group_actions

# Generated at 2022-06-21 00:50:24.262741
# Unit test for method load of class Play
def test_Play_load():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook

    play = Play()
    hosts = ['host1.example.com', 'host2.example.com', 'host3.example.com']
    variable_manager = VariableManager()
    variable_manager.set_inventory(hosts)
    loader = DataLoader()
    variable_manager.set_loader(loader)
    play.vars = variable_manager
    play_context = PlayContext()
    play_context.opts = {'verbosity': 0}
    play_context.password = 'secret'
    play_context.conf_file = ''
    play_context.remote_addr = None
    playbook

# Generated at 2022-06-21 00:50:30.007361
# Unit test for method __repr__ of class Play
def test_Play___repr__():
  test_obj = Play()
  # Test with integer parameter
  expected__repr__ = '<Play>'
  new__repr__ = test_obj.__repr__()
  assert new__repr__ == expected__repr__


# Generated at 2022-06-21 00:50:39.309588
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    '''
    Test get_vars_files() method of Play class.
    '''
    data = {
        "name": "play 1",
        "hosts": "127.0.0.1",
        "connection": "local",
        "vars_files": "foo.yaml"
    }

    try:
        p = Play()
        p.load_data(data)
    except AnsibleParserError as e:
        raise AssertionError("test_Play_get_vars_files raised AnsibleParserError unexpectedly!")

    results = p.get_vars_files()
    if not isinstance(results, list):
        raise AssertionError("test_Play_get_vars_files: Play.get_vars_files() did not return a list!")

# Generated at 2022-06-21 00:50:43.167113
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    task_list = []
    play = Play()

    play.post_tasks = task_list
    assert play.get_tasks() == task_list

    play.pre_tasks = task_list
    assert play.get_tasks() == task_list

    play.tasks = task_list
    assert play.get_tasks() == task_list


# Generated at 2022-06-21 00:50:55.525747
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    foo_play = Play().deserialize({"connection": "local",
                                   "hosts": "localhost",
                                   "name": "Foo",
                                   "roles": [
                                       {
                                           "handlers": [
                                               {"include": "foo.yml",
                                                "name": "Bar"}
                                           ],
                                           "meta": {"hosts": "localhost",
                                                    "role_name": "Baz"},
                                           "tasks": []
                                       }
                                   ],
                                   "vars": {},
                                   "vars_files": []
                                   }
                                  )
    assert foo_play.compile_roles_handlers()[0].name == "Bar"
    


# Generated at 2022-06-21 00:51:09.117888
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    task5 = Task()

    block1 = Block()
    block1.block = [task1]
    block1.rescue = [task2]
    block1.always = [task3]

    block2 = Block()
    block2.block = [task4]
    block2.rescue = [task5]
    block2.always = []

    data = {'hosts': 'localhost', 'roles': [], 'tasks': [block1, block2]}
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()
    loader = DataLoader()
    play = Play.load(data, variable_manager=variable_manager, loader=loader)
    assert play.get

# Generated at 2022-06-21 00:51:10.304402
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    my_Play = Play()
    my_Play.deserialize({})

# Generated at 2022-06-21 00:51:17.517488
# Unit test for method get_handlers of class Play
def test_Play_get_handlers():
    play = Play()
    setattr(play, 'handlers', [])

    handlerList = play.get_handlers()
    assert handlerList == []

    handler = Handler(task=Task())
    handler.task.set_loader(play._loader)
    setattr(play, 'handlers', [handler])
    handlerList = play.get_handlers()
    assert handlerList == [handler]


# Generated at 2022-06-21 00:51:21.108261
# Unit test for method compile of class Play
def test_Play_compile():
    p = Play()
    p._load_tasks = MagicMock()
    p._load_pre_tasks = MagicMock()
    p._load_post_tasks = MagicMock()
    p._compile_roles = MagicMock()
    p._compile_roles.return_value = [1, 2, 3]

    assert p.compile() == [1, 2, 3]


# Generated at 2022-06-21 00:51:29.688932
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Imports
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.vars.manager import VariableManager
    # Empty case
    p = Play()
    p.preprocess_data(None)
    # String case
    p = Play()
    p.preprocess_data(AnsibleUnicode(''))
    # Sequence with one element case
    p = Play()
    p.preprocess_data(AnsibleSequence([]))
    # Sequence with two elements case
    p = Play()
    p.preprocess_data(AnsibleSequence(['', '']))
    # Regular case
    p = Play()
    p._variable_manager = VariableManager()
    p._

# Generated at 2022-06-21 00:51:55.278739
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    d = {
        'hosts': ['master.example.com'],
        'user': 'root'
    }
    play = Play()
    play.preprocess_data(d)
    assert d['remote_user'] == 'root'


# Generated at 2022-06-21 00:51:59.526257
# Unit test for method load of class Play
def test_Play_load():
    # Initialize the class with some valid data
    p = Play.load(data={
        "connection": "local",
    })
    assert isinstance(p, Play)

    # Ensure that the correct attributes are populated
    assert p.connection == "local"



# Generated at 2022-06-21 00:52:12.539442
# Unit test for method copy of class Play
def test_Play_copy():

    # Arrange
    new_me = Play()
    my_play_obj = Play()
    new_me.ROLE_CACHE = my_play_obj
    new_me._included_conditional = my_play_obj
    new_me._included_path = my_play_obj
    new_me._action_groups = my_play_obj
    new_me._group_actions = my_play_obj

    # Act
    test_obj = new_me.copy()

    # Assert
    assert test_obj.ROLE_CACHE == my_play_obj
    assert test_obj._included_conditional == my_play_obj
    assert test_obj._included_path == my_play_obj
    assert test_obj._action_groups == my_play_obj
    assert test_

# Generated at 2022-06-21 00:52:19.687811
# Unit test for method load of class Play
def test_Play_load():
    from ansible.playbook.play import load
    from ansible.cli.arguments import options as cli_args
    import ansible.constants as C
    from ansible.context import cli, context

    # initialize context for unit tests
    context._init_global_context(cli_args=cli_args)

    context.CLIARGS = {}

    test1 = dict()
    test1['hosts'] = dict()
    test1['hosts']['localhost'] = dict()
    test1['hosts']['localhost']['connection'] = 'local'
    test1['hosts']['localhost']['ansible_user'] = 'test'
    test1['hosts']['localhost']['ansible_password'] = 'pass'

    test2 = dict()

# Generated at 2022-06-21 00:52:25.757943
# Unit test for method get_name of class Play
def test_Play_get_name():
    host = "test"
    play = Play()
    play.name = None
    play.hosts = host
    assert play.get_name() == host
    play.name = "test_name"
    assert play.get_name() == play.name


# Generated at 2022-06-21 00:52:29.650723
# Unit test for method get_roles of class Play
def test_Play_get_roles():
    
    # Initialization
    pl = Play()
    pl.roles = [{'role1': 'role1'},{'role2': 'role2'}]
    
    # Execute the function tested
    result = pl.get_roles()
    
    # Check the result
    assert result == pl.roles[:]


# Generated at 2022-06-21 00:52:39.438103
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.role

    play = ansible.playbook.play.Play()
    r = ansible.playbook.role.Role()
    r.tasks = []
    r.tasks.append(ansible.playbook.block.Block([], b_type='role'))

    r._handler_blocks = []
    ansible.playbook.block.Block([], b_type='role')
    h = ansible.playbook.block.Block([], b_type='role')
    r._handler_blocks.append(h)

    play.roles = []
    play.roles.append(r)
    block = play.compile_roles_handlers()


# Generated at 2022-06-21 00:52:45.020867
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    mock_ds = {'user': 'foo'}
    mock_play = Play()
    return_val = mock_play.preprocess_data(mock_ds)
    assert return_val == {'remote_user': 'foo'}
