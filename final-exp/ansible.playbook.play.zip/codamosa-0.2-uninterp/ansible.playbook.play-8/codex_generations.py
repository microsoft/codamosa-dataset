

# Generated at 2022-06-17 07:36:08.899595
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with vars_files is None
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []

    # Test with vars_files is not None and is not a list
    play = Play()
    play.vars_files = 'vars_files'
    assert play.get_vars_files() == ['vars_files']

    # Test with vars_files is not None and is a list
    play = Play()
    play.vars_files = ['vars_files']
    assert play.get_vars_files() == ['vars_files']


# Generated at 2022-06-17 07:36:17.491704
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test 1
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test 2
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test 3
    play = Play()

# Generated at 2022-06-17 07:36:27.621000
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.vars = {'var1': 'val1', 'var2': 'val2'}
    play.vars_prompt = [{'name': 'var1', 'prompt': 'prompt1', 'default': 'default1', 'private': False, 'confirm': False, 'encrypt': 'md5', 'salt_size': 10, 'salt': 'salt1', 'unsafe': False}, {'name': 'var2', 'prompt': 'prompt2', 'default': 'default2', 'private': True, 'confirm': True, 'encrypt': 'sha512', 'salt_size': 20, 'salt': 'salt2', 'unsafe': True}]

# Generated at 2022-06-17 07:36:39.808550
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a new Play object
    p = Play()
    # Create a new Role object
    r = Role()
    # Create a new Handler object
    h = Handler()
    # Create a new Block object
    b = Block()
    # Create a new Task object
    t = Task()
    # Create a new Task object
    t2 = Task()
    # Create a new Task object
    t3 = Task()
    # Create a new Task object
    t4 = Task()
    # Create a new Task object
    t5 = Task()
    # Create a new Task object
    t6 = Task()
    # Create a new Task object
    t7 = Task()
    # Create a new Task object
    t8 = Task()
    # Create a new Task object
    t9 = Task()
    # Create a new Task object
   

# Generated at 2022-06-17 07:36:48.908547
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    p = Play()

    # Create a Block object
    b = Block()

    # Create a Task object
    t = Task()

    # Add the Task object to the Block object
    b.block = [t]

    # Add the Block object to the Play object
    p.pre_tasks = [b]
    p.tasks = [b]
    p.post_tasks = [b]

    # Call the method get_tasks of the Play object
    tasklist = p.get_tasks()

    # Assert that the method get_tasks returns a list of Task objects
    assert isinstance(tasklist, list)
    assert isinstance(tasklist[0], Task)
    assert isinstance(tasklist[1], Task)
    assert isinstance(tasklist[2], Task)
   

# Generated at 2022-06-17 07:36:54.010959
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'roles': [{'name': 'test_role', 'tasks': [{'name': 'test_task'}]}]})
    assert play.roles[0].name == 'test_role'
    assert play.roles[0].tasks[0].name == 'test_task'


# Generated at 2022-06-17 07:37:01.530670
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:37:04.786792
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'roles': [{'name': 'test'}]})
    assert play.roles[0].name == 'test'


# Generated at 2022-06-17 07:37:08.325774
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = {'user': 'root'}
    play.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds


# Generated at 2022-06-17 07:37:14.669210
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    assert play.compile_roles_handlers() == []

    # Test with roles
    play = Play()
    role = Role()
    role.name = 'role_name'
    role.handlers = [Handler(), Handler()]
    play.roles = [role]
    assert play.compile_roles_handlers() == role.handlers

    # Test with roles from include_role
    play = Play()
    role = Role()
    role.name = 'role_name'
    role.handlers = [Handler(), Handler()]
    role.from_include = True
    play.roles = [role]
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-17 07:37:30.464442
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 07:37:39.223153
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    assert play.compile_roles_handlers() == []

    # Test with roles
    play = Play()
    play.roles = [Role(), Role()]
    assert play.compile_roles_handlers() == []

    # Test with roles and handlers
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].handlers = [Handler(), Handler()]
    play.roles[1].handlers = [Handler(), Handler()]
    assert len(play.compile_roles_handlers()) == 4
    assert isinstance(play.compile_roles_handlers()[0], Handler)
    assert isinstance(play.compile_roles_handlers()[1], Handler)
    assert isinstance

# Generated at 2022-06-17 07:37:48.357037
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a valid data structure
    data = {'hosts': 'localhost', 'user': 'root', 'tasks': [{'name': 'test', 'debug': {'msg': 'test'}}]}
    p = Play()
    p.preprocess_data(data)
    assert data['remote_user'] == 'root'
    assert 'user' not in data

    # Test with an invalid data structure
    data = {'hosts': 'localhost', 'user': 'root', 'tasks': [{'name': 'test', 'debug': {'msg': 'test'}}]}
    p = Play()
    with pytest.raises(AnsibleAssertionError):
        p.preprocess_data(None)


# Generated at 2022-06-17 07:37:52.459793
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # TODO: implement test
    pass


# Generated at 2022-06-17 07:37:58.395537
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'localhost'
    assert p.get_name() == 'localhost'
    p.hosts = ['localhost', '127.0.0.1']
    assert p.get_name() == 'localhost,127.0.0.1'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:38:02.671439
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 07:38:06.450410
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    play.roles[1].get_handler_blocks = lambda: [4, 5, 6]
    assert play.compile_roles_handlers() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-17 07:38:09.281119
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test_name"
    assert play.get_name() == "test_name"


# Generated at 2022-06-17 07:38:22.116185
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test case 1:
    #   vars_files is None
    #   Expected result:
    #   return []
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []

    # Test case 2:
    #   vars_files is not None and is not a list
    #   Expected result:
    #   return [self.vars_files]
    play = Play()
    play.vars_files = 'vars_files'
    assert play.get_vars_files() == ['vars_files']

    # Test case 3:
    #   vars_files is not None and is a list
    #   Expected result:
    #   return self.vars_files
    play = Play()
    play.vars_files

# Generated at 2022-06-17 07:38:28.972232
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:38:47.265626
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with vars_files is None
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    # Test with vars_files is a list
    p = Play()
    p.vars_files = ['./test_file1', './test_file2']
    assert p.get_vars_files() == ['./test_file1', './test_file2']
    # Test with vars_files is a string
    p = Play()
    p.vars_files = './test_file'
    assert p.get_vars_files() == ['./test_file']


# Generated at 2022-06-17 07:38:54.101406
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Create a Block object
    b1 = Block()
    # Create a Task object
    t1 = Task()
    # Create a Block object
    b2 = Block()
    # Create a Task object
    t2 = Task()
    # Create a Block object
    b3 = Block()
    # Create a Task object
    t3 = Task()
    # Create a Block object
    b4 = Block()
    # Create a Task object
    t4 = Task()
    # Create a Block object
    b5 = Block()
    # Create a Task object
   

# Generated at 2022-06-17 07:39:01.179395
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:39:10.930866
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Block object
    block1 = Block()
    # Create a Task object
    task1 = Task()
    # Create a Block object
    block2 = Block()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Task object
    task4 = Task()
    # Create a Block object
    block5 = Block()
    # Create a Task object
    task5 = Task()
    # Create a Block object
    block6 = Block()
    # Create a Task object

# Generated at 2022-06-17 07:39:14.709461
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2]
    play.tasks = [3, 4]
    play.post_tasks = [5, 6]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-17 07:39:26.686714
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test 1
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    # Test 2
    play = Play()
    play.hosts = 'test'
    assert play.get_name() == 'test'
    # Test 3
    play = Play()
    play.hosts = ['test1', 'test2']
    assert play.get_name() == 'test1,test2'
    # Test 4
    play = Play()
    assert play.get_name() == ''


# Generated at 2022-06-17 07:39:32.573957
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:39:37.399279
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:39:47.467244
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with no tasks
    play = Play()
    assert play.get_tasks() == []

    # Test with tasks
    play = Play()
    play.tasks = [Task()]
    assert play.get_tasks() == [Task()]

    # Test with tasks and pre_tasks
    play = Play()
    play.tasks = [Task()]
    play.pre_tasks = [Task()]
    assert play.get_tasks() == [Task(), Task()]

    # Test with tasks and post_tasks
    play = Play()
    play.tasks = [Task()]
    play.post_tasks = [Task()]
    assert play.get_tasks() == [Task(), Task()]

    # Test with tasks and pre_tasks and post_tasks
    play = Play

# Generated at 2022-06-17 07:39:55.319845
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:40:29.397445
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block2 = Block()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Task object
    task4 = Task()
    # Create a Block object
    block5 = Block()
    # Create a Task object
    task5 = Task()
    # Create a Block object
    block6 = Block()
    # Create a Task object
   

# Generated at 2022-06-17 07:40:40.473467
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a RoleInclude object
    role_include = RoleInclude()
    # Create a RoleInclude object
    role_include1 = RoleInclude()
    # Create a RoleInclude object
    role_include2 = RoleInclude()
    # Create a RoleInclude object
    role_include3 = RoleInclude()
    # Create a RoleInclude object
    role_include4 = RoleInclude()
    # Create a RoleInclude object
    role_include5 = RoleInclude()
    # Create a RoleInclude object

# Generated at 2022-06-17 07:40:49.439924
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block2 = Block()
    # Create a Handler object
    handler2 = Handler()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Handler object
    handler3 = Handler()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Handler object
    handler4 = Handler()
    # Create a Task object
    task4 = Task()
    # Create a Block object
   

# Generated at 2022-06-17 07:40:55.390088
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a play
    play = Play()
    # create a role
    role = Role()
    # create a block
    block = Block()
    # create a handler
    handler = Handler()
    # add the handler to the block
    block.block.append(handler)
    # add the block to the role
    role.handlers.append(block)
    # add the role to the play
    play.roles.append(role)
    # compile the roles handlers
    play.compile_roles_handlers()
    # assert that the handler is in the handlers list
    assert handler in play.handlers


# Generated at 2022-06-17 07:41:04.540945
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = "test.yml"
    assert play.get_vars_files() == ["test.yml"]
    play.vars_files = ["test.yml", "test2.yml"]
    assert play.get_vars_files() == ["test.yml", "test2.yml"]


# Generated at 2022-06-17 07:41:08.629566
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    assert play.compile_roles_handlers() == [1, 2, 3]


# Generated at 2022-06-17 07:41:20.880863
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name is None
    assert play.hosts is None
    assert play.remote_user is None
    assert play.connection is None
    assert play.port is None
    assert play.gather_facts is None
    assert play.vars is None
    assert play.vars_files is None
    assert play.vars_prompt is None
    assert play.tags is None
    assert play.skip_tags is None
    assert play.any_errors_fatal is None
    assert play.handlers is None
    assert play.tasks is None
    assert play.roles is None
    assert play.post_tasks is None
    assert play.pre_tasks is None
    assert play.notify is None
    assert play.listen is None
    assert play.max_fail_percent

# Generated at 2022-06-17 07:41:26.451937
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test Play.get_tasks()
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Task object
    task1 = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
    task10 = Task()
    # Create a Task object
    task

# Generated at 2022-06-17 07:41:31.503279
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:41:35.812405
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2]
    play.tasks = [3, 4]
    play.post_tasks = [5, 6]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-17 07:42:24.178951
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:42:30.096002
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'test'
    assert p.get_vars_files() == ['test']
    p.vars_files = ['test1', 'test2']
    assert p.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:42:43.788532
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()

    # Create a Role object
    r = Role()

    # Create a Block object
    b = Block()

    # Create a Handler object
    h = Handler()

    # Create a Task object
    t = Task()

    # Create a list of blocks
    block_list = []

    # Create a list of handlers
    handler_list = []

    # Create a list of tasks
    task_list = []

    # Append the Block object to the list of blocks
    block_list.append(b)

    # Append the Handler object to the list of handlers
    handler_list.append(h)

    # Append the Task object to the list of tasks
    task_list.append(t)

    # Set the list of blocks to the Block object
    b.block = block_list

# Generated at 2022-06-17 07:42:49.177871
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'test'
    assert p.get_vars_files() == ['test']
    p.vars_files = ['test1', 'test2']
    assert p.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:42:56.894370
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.hosts == 'all'
    assert play.name == ''
    assert play.vars == {}
    assert play.vars_files == []
    assert play.roles == []
    assert play.tasks == []
    assert play.handlers == []
    assert play.pre_tasks == []
    assert play.post_tasks == []
    assert play.tags == frozenset(['all'])
    assert play.skip_tags == frozenset()
    assert play.only_tags == frozenset(['all'])
    assert play.force_handlers == False
    assert play.max_fail_percentage == 0
    assert play.serial == []
    assert play.strategy == 'linear'
    assert play.order == 'implicit'
    assert play.vars

# Generated at 2022-06-17 07:43:02.508038
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = ['test']
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:43:13.634261
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    assert play.compile_roles_handlers() == []

    # Test with a role with no handlers
    role = Role()
    role.name = 'test_role'
    play.roles = [role]
    assert play.compile_roles_handlers() == []

    # Test with a role with handlers
    handler = Handler()
    handler.name = 'test_handler'
    role.handlers = [handler]
    assert play.compile_roles_handlers() == [handler]

    # Test with a role with handlers and a role with no handlers
    role2 = Role()
    role2.name = 'test_role2'
    play.roles = [role, role2]

# Generated at 2022-06-17 07:43:28.378829
# Unit test for method get_tasks of class Play

# Generated at 2022-06-17 07:43:33.270353
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_host'
    assert play.get_name() == 'test_host'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:43:39.387395
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:45:05.185407
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    p = Play()
    assert p.compile_roles_handlers() == []

    # Test with a single role
    p = Play()
    r = Role()
    p.roles.append(r)
    assert p.compile_roles_handlers() == []

    # Test with a single role with a single handler
    p = Play()
    r = Role()
    h = Handler()
    r.handlers.append(h)
    p.roles.append(r)
    assert p.compile_roles_handlers() == [h]

    # Test with a single role with a single handler and a single task
    p = Play()
    r = Role()
    h = Handler()
    t = Task()
    r.handlers.append(h)
    r

# Generated at 2022-06-17 07:45:11.165897
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    p = Play()
    p.roles = []
    assert p.compile_roles_handlers() == []

    # Test with roles
    p = Play()
    p.roles = [Role(), Role()]
    assert p.compile_roles_handlers() == []

    # Test with roles with handlers
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].handlers = [Handler(), Handler()]
    p.roles[1].handlers = [Handler(), Handler()]
    assert len(p.compile_roles_handlers()) == 4


# Generated at 2022-06-17 07:45:23.295687
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with empty play
    play = Play()
    assert play.get_tasks() == []

    # Test with play with tasks
    play = Play()
    play.tasks = [1, 2, 3]
    assert play.get_tasks() == [1, 2, 3]

    # Test with play with tasks and blocks
    play = Play()
    play.tasks = [1, 2, 3]
    play.pre_tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [4, 5, 6, 1, 2, 3, 7, 8, 9]

    # Test with play with tasks and blocks with tasks and blocks
    play = Play()
    play.tasks = [1, 2, 3]
    play

# Generated at 2022-06-17 07:45:26.687868
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test"
    assert play.get_name() == "test"


# Generated at 2022-06-17 07:45:34.928523
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    assert play.compile_roles_handlers() == []

    # Test with roles
    play = Play()
    play.roles = [Role(), Role()]
    assert play.compile_roles_handlers() == []

    # Test with roles and handlers
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].handlers = [Handler(), Handler()]
    play.roles[1].handlers = [Handler(), Handler()]
    assert play.compile_roles_handlers() == [Handler(), Handler(), Handler(), Handler()]


# Generated at 2022-06-17 07:45:42.796847
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]
