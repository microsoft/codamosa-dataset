

# Generated at 2022-06-17 07:36:11.324412
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = {'user': 'root'}
    play.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds


# Generated at 2022-06-17 07:36:21.812183
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Rescue object
    rescue = Rescue()
    # Create a Always object
    always = Always()
    # Add the Task object to the Block object
    block.block.append(task)
    # Add the Rescue object to the Block object
    block.rescue.append(rescue)
    # Add the Always object to the Block object
    block.always.append(always)
    # Add the Block object to the Play object
    play.pre_tasks.append(block)
    # Add the Block object to the Play object
    play.tasks.append(block)
    # Add the Block object to the Play object
    play.post_tasks.append(block)

# Generated at 2022-06-17 07:36:26.709032
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test_play'
    assert p.get_name() == 'test_play'
    p.name = None
    p.hosts = 'test_host'
    assert p.get_name() == 'test_host'
    p.hosts = ['test_host1', 'test_host2']
    assert p.get_name() == 'test_host1,test_host2'


# Generated at 2022-06-17 07:36:37.240796
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create a Play object
    p = Play()
    # Set the name attribute of the Play object
    p.name = 'test'
    # Assert that the name attribute of the Play object is 'test'
    assert p.get_name() == 'test'
    # Set the name attribute of the Play object to None
    p.name = None
    # Set the hosts attribute of the Play object
    p.hosts = 'test'
    # Assert that the name attribute of the Play object is 'test'
    assert p.get_name() == 'test'
    # Set the hosts attribute of the Play object to None
    p.hosts = None
    # Assert that the name attribute of the Play object is ''
    assert p.get_name() == ''


# Generated at 2022-06-17 07:36:51.163246
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block1 = Block()
    # Create a Handler object
    handler1 = Handler()
    # Create a Task object
    task1 = Task()
    # Create a Block object
    block2 = Block()
    # Create a Handler object
    handler2 = Handler()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Handler object
    handler3 = Handler()
    # Create a Task object
    task3 = Task()
    # Create a Block object
   

# Generated at 2022-06-17 07:37:04.454611
# Unit test for constructor of class Play
def test_Play():
    # Test with no arguments
    p = Play()
    assert p.hosts == 'all'
    assert p.name == ''
    assert p.roles == []
    assert p.tasks == []
    assert p.handlers == []
    assert p.vars == {}
    assert p.vars_prompt == []
    assert p.vars_files == []
    assert p.tags == frozenset(['all'])
    assert p.skip_tags == frozenset()
    assert p.connection == 'smart'
    assert p.gather_facts == 'smart'
    assert p.serial == 1
    assert p.max_fail_percentage == 0
    assert p.any_errors_fatal is False
    assert p.force_handlers is False
    assert p.remote_user == C.DEFAULT

# Generated at 2022-06-17 07:37:12.461384
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'test_hosts'
    play.connection = 'test_connection'
    play.remote_user = 'test_remote_user'
    play.become = 'test_become'
    play.become_user = 'test_become_user'
    play.become_method = 'test_become_method'
    play.become_flags = 'test_become_flags'
    play.gather_facts = 'test_gather_facts'
    play.vars_prompt = 'test_vars_prompt'
    play.vars_files = 'test_vars_files'
    play.vars = 'test_vars'
    play.tags = 'test_tags'
    play

# Generated at 2022-06-17 07:37:20.161325
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = ['test1', 'test2']
    assert play.get_name() == 'test1,test2'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:37:26.761666
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:37:32.231667
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'roles': [{'_role_name': 'test_role'}]})
    assert play.roles[0]._role_name == 'test_role'


# Generated at 2022-06-17 07:37:41.933462
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:37:51.301571
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with valid data
    play = Play()
    ds = {'user': 'test_user'}
    play.preprocess_data(ds)
    assert ds['remote_user'] == 'test_user'
    assert 'user' not in ds

    # Test with invalid data
    play = Play()
    ds = {'user': 'test_user', 'remote_user': 'test_user'}
    try:
        play.preprocess_data(ds)
    except AnsibleParserError as e:
        assert 'both \'user\' and \'remote_user\' are set for this play' in to_native(e)

    # Test with invalid data
    play = Play()
    ds = {'user': None}

# Generated at 2022-06-17 07:37:55.984677
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_host'
    assert play.get_name() == 'test_host'
    play.hosts = ['test_host1', 'test_host2']
    assert play.get_name() == 'test_host1,test_host2'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:38:06.771480
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Create a Block object
    b1 = Block()
    # Create a Handler object
    h1 = Handler()
    # Create a Task object
    t1 = Task()
    # Create a Block object
    b2 = Block()
    # Create a Handler object
    h2 = Handler()
    # Create a Task object
    t2 = Task()
    # Create a Block object
    b3 = Block()
    # Create a Handler object
    h3 = Handler()
    # Create a Task object
    t3 = Task()
    # Create a Block object
   

# Generated at 2022-06-17 07:38:19.841963
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.vars = {'var1': 'value1'}
    play.name = 'test_play'
    play.hosts = 'all'
    play.connection = 'local'
    play.gather_facts = 'no'
    play.roles = [Role(), Role()]
    play.roles[0].name = 'role1'
    play.roles[1].name = 'role2'
    play.roles[0].tasks = [Task(), Task()]
    play.roles[1].tasks = [Task(), Task()]
    play.roles[0].tasks[0].name = 'task1'
    play.roles[0].tasks[1].name = 'task2'

# Generated at 2022-06-17 07:38:25.136790
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:38:34.026016
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block2 = Block()
    # Create a Handler object
    handler2 = Handler()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Handler object
    handler3 = Handler()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Handler object
    handler4 = Handler()
    # Create a Task object
    task4 = Task()
    # Create a Block object
   

# Generated at 2022-06-17 07:38:40.466466
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[1, 2])
    play.roles[1].get_handler_blocks = MagicMock(return_value=[3, 4])
    assert play.compile_roles_handlers() == [1, 2, 3, 4]
    assert play.roles[0].get_handler_blocks.call_count == 1
    assert play.roles[1].get_handler_blocks.call_count == 1


# Generated at 2022-06-17 07:38:46.029354
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:38:50.376221
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:39:02.848023
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:39:08.095502
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:39:12.969478
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_hosts'
    assert play.get_name() == 'test_hosts'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:39:22.439748
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a new Play object
    p = Play()
    # Create a new Role object
    r = Role()
    # Create a new Block object
    b = Block()
    # Create a new Handler object
    h = Handler()
    # Create a new Task object
    t = Task()
    # Create a new Block object
    b2 = Block()
    # Create a new Task object
    t2 = Task()
    # Create a new Block object
    b3 = Block()
    # Create a new Task object
    t3 = Task()
    # Create a new Block object
    b4 = Block()
    # Create a new Task object
    t4 = Task()
    # Create a new Block object
    b5 = Block()
    # Create a new Task object
    t5 = Task()
    # Create a new Block object
   

# Generated at 2022-06-17 07:39:28.338998
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:39:35.213532
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:39:42.226740
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = "test_play"
    play.hosts = "test_hosts"
    play.connection = "test_connection"
    play.user = "test_user"
    play.remote_user = "test_remote_user"
    play.become = True
    play.become_method = "test_become_method"
    play.become_user = "test_become_user"
    play.vars = {"test_var": "test_value"}
    play.vars_files = ["test_vars_files"]

# Generated at 2022-06-17 07:39:48.563016
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:39:55.203880
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:40:01.425955
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:40:29.535354
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a play object
    play = Play()
    # Create a role object
    role = Role()
    # Create a handler object
    handler = Handler()
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a block list
    block_list = []
    # Add the handler to the block
    block.block = [handler]
    # Add the block to the role
    role.handlers = [block]
    # Add the role to the play
    play.roles = [role]
    # Add the task to the play
    play.tasks = [task]
    # Add the task to the block
    block.block = [task]
    # Add the block to the play
    play.handlers = [block]
    # Add the block to the block

# Generated at 2022-06-17 07:40:35.485703
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1, 2, 3]
    p.tasks = [4, 5, 6]
    p.post_tasks = [7, 8, 9]
    assert p.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-17 07:40:46.065931
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'test_hosts'
    play.remote_user = 'test_remote_user'
    play.connection = 'test_connection'
    play.port = 'test_port'
    play.gather_facts = 'test_gather_facts'
    play.vars = 'test_vars'
    play.vars_files = 'test_vars_files'
    play.vars_prompt = 'test_vars_prompt'
    play.tags = 'test_tags'
    play.skip_tags = 'test_skip_tags'
    play.any_errors_fatal = 'test_any_errors_fatal'

# Generated at 2022-06-17 07:40:53.491344
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:40:59.891972
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with pre_tasks, tasks and post_tasks
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test with tasks only
    play = Play()
    play.tasks = [4, 5, 6]
    assert play.get_tasks() == [4, 5, 6]

    # Test with pre_tasks and post_tasks only
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.post_tasks = [7, 8, 9]
    assert play

# Generated at 2022-06-17 07:41:06.502800
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:41:14.107610
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1, 2, 3]
    p.tasks = [4, 5, 6]
    p.post_tasks = [7, 8, 9]
    assert p.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    p.pre_tasks = [1, 2, 3]
    p.tasks = [4, 5, 6]
    p.post_tasks = [7, 8, 9]
    assert p.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    p.pre_tasks = [1, 2, 3]
    p.tasks = [4, 5, 6]

# Generated at 2022-06-17 07:41:21.969274
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1, 2]
    p.tasks = [3, 4]
    p.post_tasks = [5, 6]
    assert p.get_tasks() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-17 07:41:28.572482
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Task object
    task1 = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
   

# Generated at 2022-06-17 07:41:38.402777
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    p = Play()
    assert p.compile_roles_handlers() == []

    # Test with a role with no handlers
    p = Play()
    r = Role()
    p.roles = [r]
    assert p.compile_roles_handlers() == []

    # Test with a role with handlers
    p = Play()
    r = Role()
    r.handlers = [Handler()]
    p.roles = [r]
    assert p.compile_roles_handlers() == r.handlers

    # Test with a role with handlers and a role with no handlers
    p = Play()
    r1 = Role()
    r1.handlers = [Handler()]
    r2 = Role()
    p.roles = [r1, r2]


# Generated at 2022-06-17 07:42:18.977708
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Add the Handler object to the Block object
    b.block = [h]
    # Add the Block object to the Role object
    r.handlers = [b]
    # Add the Role object to the Play object
    p.roles = [r]
    # Call the method compile_roles_handlers of the Play object
    result = p.compile_roles_handlers()
    # Check the result
    assert result == [b]


# Generated at 2022-06-17 07:42:22.960156
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'


# Generated at 2022-06-17 07:42:28.975871
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with a play with no tasks
    p = Play()
    assert p.get_tasks() == []

    # Test with a play with tasks
    p = Play()
    p.tasks = [Task()]
    assert p.get_tasks() == [Task()]


# Generated at 2022-06-17 07:42:32.820139
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:42:42.592278
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a play
    play = Play()
    # create a role
    role = Role()
    # create a block
    block = Block()
    # create a handler
    handler = Handler()
    # add the handler to the block
    block.block = [handler]
    # add the block to the role
    role.handlers = [block]
    # add the role to the play
    play.roles = [role]
    # compile the roles handlers
    handlers = play.compile_roles_handlers()
    # assert that the handler is in the handlers
    assert handler in handlers


# Generated at 2022-06-17 07:42:47.792456
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test_play'
    assert p.get_name() == 'test_play'
    p.name = None
    p.hosts = 'test_host'
    assert p.get_name() == 'test_host'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:42:53.860132
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test_play"
    assert play.get_name() == "test_play"
    play.name = None
    play.hosts = "test_host"
    assert play.get_name() == "test_host"
    play.hosts = None
    assert play.get_name() == ""


# Generated at 2022-06-17 07:43:02.906390
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Set the handler of the Block object
    b.handler = h
    # Set the block of the Role object
    r.block = b
    # Set the tasks of the Role object
    r.tasks = t
    # Set the roles of the Play object
    p.roles = r
    # Call the method compile_roles_handlers of the Play object
    p.compile_roles_handlers()


# Generated at 2022-06-17 07:43:13.872948
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name == ''
    assert p.hosts == ''
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.connection == C.DEFAULT_TRANSPORT
    assert p.port == C.DEFAULT_REMOTE_PORT
    assert p.gather_facts == C.DEFAULT_GATHER_FACTS
    assert p.vars == {}
    assert p.vars_prompt == []
    assert p.vars_files == []
    assert p.tags == []
    assert p.skip_tags == []
    assert p.handlers == []
    assert p.tasks == []
    assert p.pre_tasks == []
    assert p.post_tasks == []
    assert p.roles == []
    assert p.role_

# Generated at 2022-06-17 07:43:21.901034
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:43:51.545239
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].handlers = [Handler(), Handler()]
    play.roles[1].handlers = [Handler()]
    assert len(play.compile_roles_handlers()) == 3


# Generated at 2022-06-17 07:43:56.305094
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:44:02.592205
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test get_tasks method of class Play
    # Create a Play object
    p = Play()
    # Create a Block object
    b = Block()
    # Create a Task object
    t = Task()
    # Create a list of tasks
    tasks = [t]
    # Assign the list of tasks to the Block object
    b.block = tasks
    # Assign the Block object to the Play object
    p.tasks = b
    # Assert that the list of tasks is returned by the get_tasks method
    assert p.get_tasks() == tasks


# Generated at 2022-06-17 07:44:09.897397
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    p = Play()
    assert p.compile_roles_handlers() == []

    # Test with roles
    p = Play()
    r = Role()
    r.handlers = [Handler()]
    p.roles = [r]
    assert p.compile_roles_handlers() == r.handlers

    # Test with roles from include_role
    p = Play()
    r = Role()
    r.handlers = [Handler()]
    p.roles = [r]
    r.from_include = True
    assert p.compile_roles_handlers() == []


# Generated at 2022-06-17 07:44:15.799010
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()

    # Create a Role object
    r = Role()

    # Create a Block object
    b = Block()

    # Create a Handler object
    h = Handler()

    # Create a Task object
    t = Task()

    # Create a list of roles
    roles = [r]

    # Create a list of blocks
    blocks = [b]

    # Create a list of handlers
    handlers = [h]

    # Create a list of tasks
    tasks = [t]

    # Set the roles of the Play object
    p.roles = roles

    # Set the blocks of the Role object
    r.blocks = blocks

    # Set the handlers of the Block object
    b.handlers = handlers

    # Set the tasks of the Block object
    b.tasks = tasks

    # Set

# Generated at 2022-06-17 07:44:17.242858
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-17 07:44:23.021669
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create a Play object
    p = Play()
    # Set the name of the Play
    p.name = "test_play"
    # Check if the name of the Play is returned
    assert p.get_name() == "test_play"


# Generated at 2022-06-17 07:44:28.901478
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:44:37.880291
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    assert play.compile_roles_handlers() == []

    # Test with one role
    play = Play()
    role = Role()
    role.name = 'test_role'
    role.handlers = [Handler()]
    play.roles = [role]
    assert play.compile_roles_handlers() == role.handlers

    # Test with two roles
    play = Play()
    role1 = Role()
    role1.name = 'test_role1'
    role1.handlers = [Handler()]
    role2 = Role()
    role2.name = 'test_role2'
    role2.handlers = [Handler()]
    play.roles = [role1, role2]
    assert play.compile_roles

# Generated at 2022-06-17 07:44:43.188573
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:45:33.077181
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].handlers = [Handler(), Handler()]
    play.roles[1].handlers = [Handler(), Handler()]
    play.roles[0].from_include = True
    play.roles[1].from_include = False
    assert play.compile_roles_handlers() == play.roles[1].handlers



# Generated at 2022-06-17 07:45:39.829548
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with vars_files is None
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    # Test with vars_files is not a list
    p = Play()
    p.vars_files = 'a'
    assert p.get_vars_files() == ['a']
    # Test with vars_files is a list
    p = Play()
    p.vars_files = ['a', 'b']
    assert p.get_vars_files() == ['a', 'b']


# Generated at 2022-06-17 07:45:42.977648
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create a Play object
    p = Play()
    # Set the name attribute of the Play object
    p.name = "test_play"
    # Assert that the name of the Play object is equal to the name attribute
    assert p.get_name() == "test_play"
