

# Generated at 2022-06-17 07:36:09.337959
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[])
    assert play.compile_roles_handlers() == []
    play.roles[0].get_handler_blocks.assert_called_once_with(play=play)


# Generated at 2022-06-17 07:36:19.587016
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Create a Block object
    b1 = Block()
    # Create a Handler object
    h1 = Handler()
    # Create a Task object
    t1 = Task()
    # Add the Handler object to the Block object
    b.block.append(h)
    # Add the Task object to the Block object
    b.block.append(t)
    # Add the Block object to the Role object
    r.block.append(b)
    # Add the Handler object to the Block object
    b1.block.append(h1)
    # Add the Task object

# Generated at 2022-06-17 07:36:29.178785
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Handler object
    handler = Handler()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Task object
    task1 = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
   

# Generated at 2022-06-17 07:36:40.602936
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    assert play.get_tasks() == []
    play.pre_tasks = [1]
    play.tasks = [2]
    play.post_tasks = [3]
    assert play.get_tasks() == [1, 2, 3]
    play.pre_tasks = [1, 2]
    play.tasks = [3, 4]
    play.post_tasks = [5, 6]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6]
    play.pre_tasks = [1, 2]
    play.tasks = [3, 4]
    play.post_tasks = [5, 6]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6]
   

# Generated at 2022-06-17 07:36:45.118615
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data(None)
    play.preprocess_data(dict())
    play.preprocess_data(dict(user='root'))
    play.preprocess_data(dict(user='root', remote_user='root'))
    try:
        play.preprocess_data(dict(user='root', remote_user='root'))
        assert False
    except AnsibleParserError:
        pass
    try:
        play.preprocess_data(dict(user=None))
        assert False
    except AnsibleParserError:
        pass
    try:
        play.preprocess_data(dict(user=1))
        assert False
    except AnsibleParserError:
        pass


# Generated at 2022-06-17 07:36:51.937896
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({"name": "test", "hosts": "localhost", "roles": [{"name": "test", "tasks": [{"name": "test", "action": "test"}]}]})
    assert play.name == "test"
    assert play.hosts == "localhost"
    assert play.roles[0].name == "test"
    assert play.roles[0].tasks[0].name == "test"
    assert play.roles[0].tasks[0].action == "test"


# Generated at 2022-06-17 07:36:59.275664
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'roles': [{'name': 'test_role', 'tasks': [{'name': 'test_task'}]}]})
    assert play.roles[0].name == 'test_role'
    assert play.roles[0].tasks[0].name == 'test_task'


# Generated at 2022-06-17 07:37:07.986460
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Set the handler attribute of the Block object
    block.handler = handler
    # Set the handlers attribute of the Role object
    role.handlers = [block]
    # Set the roles attribute of the Play object
    play.roles = [role]
    # Call the method compile_roles_handlers of the Play object
    play.compile_roles_handlers()


# Generated at 2022-06-17 07:37:19.331598
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name == ''
    assert p.hosts == ''
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.connection == C.DEFAULT_TRANSPORT
    assert p.port == C.DEFAULT_REMOTE_PORT
    assert p.gather_facts == C.DEFAULT_GATHER_FACTS
    assert p.vars == dict()
    assert p.vars_prompt == dict()
    assert p.vars_files == list()
    assert p.tags == list()
    assert p.skip_tags == list()
    assert p.handlers == list()
    assert p.tasks == list()
    assert p.roles == list()
    assert p.post_tasks == list()
    assert p.pre_tasks

# Generated at 2022-06-17 07:37:31.264977
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test'
    play.hosts = 'test'
    play.remote_user = 'test'
    play.connection = 'test'
    play.port = 'test'
    play.gather_facts = 'test'
    play.any_errors_fatal = 'test'
    play.serial = 'test'
    play.max_fail_percentage = 'test'
    play.become = 'test'
    play.become_method = 'test'
    play.become_user = 'test'
    play.check = 'test'
    play.diff = 'test'
    play.tags = 'test'
    play.skip_tags = 'test'
    play.start_at_task = 'test'
    play.force_handlers = 'test'

# Generated at 2022-06-17 07:37:50.148412
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict
    ds = dict(
        hosts='localhost',
        user='root',
        tasks=[
            dict(action=dict(module='shell', args='ls'))
        ]
    )
    p = Play()
    p.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds
    assert ds['tasks'][0]['action']['module'] == 'shell'
    assert ds['tasks'][0]['action']['args'] == 'ls'

    # Test with a list
    ds = [
        dict(action=dict(module='shell', args='ls'))
    ]
    p = Play()
    p.preprocess_data(ds)

# Generated at 2022-06-17 07:37:54.424734
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Create a Play object
    play = Play()
    # Create a variable for the vars_files attribute
    vars_files = []
    # Set the vars_files attribute of the Play object
    play.vars_files = vars_files
    # Call the get_vars_files method of the Play object
    result = play.get_vars_files()
    # Check if the result is equal to the expected result
    assert result == vars_files


# Generated at 2022-06-17 07:38:01.039205
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict
    ds = {'user': 'root'}
    p = Play()
    p.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds

    # Test with a non-dict
    ds = 'root'
    p = Play()
    with pytest.raises(AnsibleAssertionError):
        p.preprocess_data(ds)


# Generated at 2022-06-17 07:38:06.968392
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:38:20.050177
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict
    ds = {'hosts': 'localhost', 'user': 'root'}
    p = Play()
    assert p.preprocess_data(ds) == {'hosts': 'localhost', 'remote_user': 'root'}
    # Test with a list
    ds = ['localhost', 'root']
    p = Play()
    assert p.preprocess_data(ds) == ['localhost', 'root']
    # Test with a string
    ds = 'localhost'
    p = Play()
    assert p.preprocess_data(ds) == 'localhost'
    # Test with a None
    ds = None
    p = Play()
    assert p.preprocess_data(ds) == None
    # Test with a int
    ds = 1
    p = Play()

# Generated at 2022-06-17 07:38:28.495456
# Unit test for constructor of class Play

# Generated at 2022-06-17 07:38:35.103809
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:38:39.172019
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:38:40.569514
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers() == []


# Generated at 2022-06-17 07:38:46.757263
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:38:55.869607
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:39:02.784584
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'test'
    assert p.get_vars_files() == ['test']
    p.vars_files = ['test1', 'test2']
    assert p.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:39:11.966642
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    assert p.get_tasks() == []
    p.tasks = [1, 2, 3]
    assert p.get_tasks() == [1, 2, 3]
    p.pre_tasks = [4, 5, 6]
    assert p.get_tasks() == [4, 5, 6, 1, 2, 3]
    p.post_tasks = [7, 8, 9]
    assert p.get_tasks() == [4, 5, 6, 1, 2, 3, 7, 8, 9]
    p.tasks = [Block(block=[1, 2, 3], rescue=[4, 5, 6], always=[7, 8, 9])]

# Generated at 2022-06-17 07:39:16.351864
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:39:19.301947
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].handlers = [Handler(), Handler()]
    p.roles[1].handlers = [Handler(), Handler()]
    assert len(p.compile_roles_handlers()) == 4


# Generated at 2022-06-17 07:39:30.931280
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict
    ds = {'hosts': 'localhost', 'user': 'root'}
    p = Play()
    p.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds
    # Test with a list
    ds = ['localhost', 'root']
    p = Play()
    p.preprocess_data(ds)
    assert ds[1] == 'root'
    assert len(ds) == 2
    # Test with a string
    ds = 'localhost'
    p = Play()
    p.preprocess_data(ds)
    assert ds == 'localhost'
    # Test with a number
    ds = 42
    p = Play()
    p.preprocess_data(ds)
    assert ds

# Generated at 2022-06-17 07:39:37.484341
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:39:42.248273
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a play
    play = Play()
    # create a role
    role = Role()
    # create a handler
    handler = Handler()
    # create a block
    block = Block()
    # add the handler to the block
    block.block = [handler]
    # add the block to the role
    role.handlers = [block]
    # add the role to the play
    play.roles = [role]
    # call the method compile_roles_handlers
    result = play.compile_roles_handlers()
    # check the result
    assert result == [block]


# Generated at 2022-06-17 07:39:48.204034
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.tasks = [1,2,3]
    play.pre_tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:39:55.845354
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:40:16.584260
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'vars_files'
    assert play.get_vars_files() == ['vars_files']
    play.vars_files = ['vars_files_1', 'vars_files_2']
    assert play.get_vars_files() == ['vars_files_1', 'vars_files_2']


# Generated at 2022-06-17 07:40:20.858332
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_Play_get_name'
    assert play.get_name() == 'test_Play_get_name'


# Generated at 2022-06-17 07:40:29.606386
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'all'
    play.vars = {'var1': 'value1'}
    play.vars_files = ['/path/to/vars_file']
    play.roles = [Role(), Role()]
    play.tasks = [Task(), Task()]
    play.handlers = [Handler(), Handler()]
    play.pre_tasks = [Task(), Task()]
    play.post_tasks = [Task(), Task()]
    play._included_path = '/path/to/included_path'
    play._action_groups = {'group1': ['action1', 'action2']}

# Generated at 2022-06-17 07:40:33.797900
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_Play = Play()
    test_Play.pre_tasks = [1,2,3]
    test_Play.tasks = [4,5,6]
    test_Play.post_tasks = [7,8,9]
    assert test_Play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:40:40.687100
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].get_handler_blocks = lambda: [1, 2]
    p.roles[1].get_handler_blocks = lambda: [3, 4]
    assert p.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:40:46.411211
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = None
    assert p.get_name() == ''
    p.hosts = ['test1', 'test2']
    assert p.get_name() == 'test1,test2'


# Generated at 2022-06-17 07:40:53.750132
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    assert play.compile_roles_handlers() == []

    # Test with roles
    play = Play()
    play.roles = [Role()]
    assert play.compile_roles_handlers() == []
    play.roles = [Role(), Role()]
    assert play.compile_roles_handlers() == []
    play.roles = [Role(), Role(), Role()]
    assert play.compile_roles_handlers() == []

    # Test with roles and handlers
    play = Play()
    play.roles = [Role()]
    play.roles[0].handlers = [Handler()]
    assert play.compile_roles_handlers() == [Handler()]

# Generated at 2022-06-17 07:41:01.767381
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:41:12.529311
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name is None
    assert play.hosts is None
    assert play.remote_user is None
    assert play.connection is None
    assert play.port is None
    assert play.become is None
    assert play.become_method is None
    assert play.become_user is None
    assert play.become_flags is None
    assert play.vars is None
    assert play.vars_prompt is None
    assert play.vars_files is None
    assert play.tags is None
    assert play.skip_tags is None
    assert play.handlers is None
    assert play.tasks is None
    assert play.roles is None
    assert play.post_tasks is None
    assert play.pre_tasks is None
    assert play.any_errors_f

# Generated at 2022-06-17 07:41:23.526439
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict
    ds = {'hosts': 'all', 'user': 'root'}
    p = Play()
    p.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds

    # Test with a list
    ds = ['hosts', 'all', 'user', 'root']
    p = Play()
    p.preprocess_data(ds)
    assert ds[2] == 'remote_user'
    assert ds[3] == 'root'
    assert 'user' not in ds

    # Test with a string
    ds = 'hosts: all\nuser: root'
    p = Play()
    p.preprocess_data(ds)

# Generated at 2022-06-17 07:41:40.822827
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:41:45.207312
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    ds = {'user': 'root', 'hosts': 'localhost'}
    ds = p.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds


# Generated at 2022-06-17 07:41:49.294002
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    p = Play()
    assert p.compile_roles_handlers() == []

    # Test with roles
    p = Play()
    p.roles = [Role(), Role()]
    assert p.compile_roles_handlers() == []


# Generated at 2022-06-17 07:41:55.118854
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    p = Play()
    assert p.compile_roles_handlers() == []

    # Test with roles
    p = Play()
    p.roles = [Role(), Role()]
    assert p.compile_roles_handlers() == []


# Generated at 2022-06-17 07:42:00.801109
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test_name'
    assert p.get_name() == 'test_name'
    p.name = None
    p.hosts = 'test_hosts'
    assert p.get_name() == 'test_hosts'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:42:12.288911
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'all'
    play.roles = [Role(), Role()]
    play.roles[0].name = 'test_role_0'
    play.roles[1].name = 'test_role_1'
    play.roles[0].tasks = [Task(), Task()]
    play.roles[1].tasks = [Task(), Task()]
    play.roles[0].tasks[0].name = 'test_task_0_0'
    play.roles[0].tasks[1].name = 'test_task_0_1'
    play.roles[1].tasks[0].name = 'test_task_1_0'

# Generated at 2022-06-17 07:42:18.802606
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:42:27.630275
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'file1'
    assert play.get_vars_files() == ['file1']
    play.vars_files = ['file1', 'file2']
    assert play.get_vars_files() == ['file1', 'file2']


# Generated at 2022-06-17 07:42:35.431219
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with pre_tasks, tasks and post_tasks
    p = Play()
    p.pre_tasks = [1, 2]
    p.tasks = [3, 4]
    p.post_tasks = [5, 6]
    assert p.get_tasks() == [1, 2, 3, 4, 5, 6]

    # Test with tasks only
    p = Play()
    p.tasks = [3, 4]
    assert p.get_tasks() == [3, 4]

    # Test with pre_tasks and post_tasks only
    p = Play()
    p.pre_tasks = [1, 2]
    p.post_tasks = [5, 6]
    assert p.get_tasks() == [1, 2, 5, 6]

    # Test

# Generated at 2022-06-17 07:42:38.337971
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-17 07:43:07.652852
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [Task()]
    play.tasks = [Task()]
    play.post_tasks = [Task()]
    assert len(play.get_tasks()) == 3


# Generated at 2022-06-17 07:43:14.404942
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = None
    assert p.get_name() == ''
    p.hosts = ['test1', 'test2']
    assert p.get_name() == 'test1,test2'


# Generated at 2022-06-17 07:43:23.047870
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[])
    assert play.compile_roles_handlers() == []
    play.roles[0].get_handler_blocks.assert_called_once_with(play=play)


# Generated at 2022-06-17 07:43:30.277039
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_hosts'
    assert play.get_name() == 'test_hosts'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:43:38.378474
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with pre_tasks, tasks, and post_tasks
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test with pre_tasks, tasks, and post_tasks, but with blocks
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    play.pre_tasks = [Block(block=[1, 2, 3])]

# Generated at 2022-06-17 07:43:48.199093
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'test_hosts'
    play.roles = ['test_roles']
    play._included_path = 'test_included_path'
    play._action_groups = 'test_action_groups'
    play._group_actions = 'test_group_actions'
    data = play.serialize()
    assert data['name'] == 'test_play'
    assert data['hosts'] == 'test_hosts'
    assert data['roles'] == ['test_roles']
    assert data['included_path'] == 'test_included_path'
    assert data['action_groups'] == 'test_action_groups'
    assert data['group_actions'] == 'test_group_actions'

# Unit test

# Generated at 2022-06-17 07:43:59.549374
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test 1
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].get_handler_blocks = lambda: [1,2,3]
    p.roles[1].get_handler_blocks = lambda: [4,5,6]
    assert p.compile_roles_handlers() == [1,2,3,4,5,6]
    # Test 2
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].get_handler_blocks = lambda: [1,2,3]
    p.roles[1].get_handler_blocks = lambda: [4,5,6]
    p.roles[0].from_include = True
    assert p.compile_roles_handlers()

# Generated at 2022-06-17 07:44:07.318081
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name is None
    assert play.hosts == 'all'
    assert play.remote_user == C.DEFAULT_REMOTE_USER
    assert play.connection == C.DEFAULT_TRANSPORT
    assert play.port == C.DEFAULT_REMOTE_PORT
    assert play.gather_facts == C.DEFAULT_GATHER_FACTS
    assert play.vars == {}
    assert play.vars_prompt == []
    assert play.vars_files == []
    assert play.tags == frozenset(['all'])
    assert play.skip_tags == frozenset([])
    assert play.any_errors_fatal is False
    assert play.handlers == []
    assert play.tasks == []
    assert play.roles == []

# Generated at 2022-06-17 07:44:11.577706
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:44:16.469113
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:45:18.828708
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    p.roles[1].get_handler_blocks = lambda: [4, 5, 6]
    assert p.compile_roles_handlers() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-17 07:45:25.766716
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:45:30.774513
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:45:37.413082
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_name'
    assert play.get_name() == 'test_name'
    play.name = None
    play.hosts = 'test_hosts'
    assert play.get_name() == 'test_hosts'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:45:44.850074
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'test_hosts'
    play.remote_user = 'test_remote_user'
    play.connection = 'test_connection'
    play.port = 'test_port'
    play.gather_facts = 'test_gather_facts'
    play.vars_prompt = 'test_vars_prompt'
    play.vars_files = 'test_vars_files'
    play.vars_prompt = 'test_vars_prompt'
    play.vars_files = 'test_vars_files'
    play.tags = 'test_tags'
    play.skip_tags = 'test_skip_tags'