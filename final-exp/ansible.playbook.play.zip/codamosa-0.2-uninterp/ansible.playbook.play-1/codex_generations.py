

# Generated at 2022-06-17 07:36:02.819606
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:36:09.599253
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'test'
    assert p.get_vars_files() == ['test']
    p.vars_files = ['test1', 'test2']
    assert p.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:36:14.203520
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:36:19.112900
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:36:27.730825
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Task object
    task1 = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
    task10 = Task()
    # Create a Task object
    task11 = Task()
    # Create a Task object

# Generated at 2022-06-17 07:36:36.984800
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'name': 'test_play', 'hosts': 'test_hosts', 'roles': [{'name': 'test_role', 'tasks': [{'name': 'test_task', 'action': 'test_action'}]}]})
    assert play.name == 'test_play'
    assert play.hosts == 'test_hosts'
    assert play.roles[0].name == 'test_role'
    assert play.roles[0].tasks[0].name == 'test_task'
    assert play.roles[0].tasks[0].action == 'test_action'


# Generated at 2022-06-17 07:36:48.487968
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[])
    play.roles[1].get_handler_blocks = MagicMock(return_value=[])
    assert play.compile_roles_handlers() == []
    play.roles[0].get_handler_blocks.assert_called_once_with(play=play)
    play.roles[1].get_handler_blocks.assert_called_once_with(play=play)


# Generated at 2022-06-17 07:36:54.328356
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_host'
    assert play.get_name() == 'test_host'
    play.hosts = ['test_host1', 'test_host2']
    assert play.get_name() == 'test_host1,test_host2'


# Generated at 2022-06-17 07:37:07.024830
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with empty list
    play = Play()
    play.pre_tasks = []
    play.tasks = []
    play.post_tasks = []
    assert play.get_tasks() == []

    # Test with non-empty list
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test with non-empty list
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]

# Generated at 2022-06-17 07:37:17.399722
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    play.roles = []
    assert play.compile_roles_handlers() == []

    # Test with roles
    play = Play()
    play.roles = [Role(), Role()]
    assert play.compile_roles_handlers() == []

    # Test with roles
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].handlers = [Handler(), Handler()]
    play.roles[1].handlers = [Handler(), Handler()]
    assert play.compile_roles_handlers() == [Handler(), Handler(), Handler(), Handler()]


# Generated at 2022-06-17 07:37:34.587144
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test'
    play.hosts = 'test'
    play.roles = ['test']
    play._included_path = 'test'
    play._action_groups = 'test'
    play._group_actions = 'test'
    data = play.serialize()
    assert data['name'] == 'test'
    assert data['hosts'] == 'test'
    assert data['roles'] == ['test']
    assert data['included_path'] == 'test'
    assert data['action_groups'] == 'test'
    assert data['group_actions'] == 'test'

# Generated at 2022-06-17 07:37:48.443319
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    play.roles = []
    assert play.compile_roles_handlers() == []

    # Test with one role
    play = Play()
    role = Role()
    role.handlers = [Handler()]
    play.roles = [role]
    assert play.compile_roles_handlers() == role.handlers

    # Test with two roles
    play = Play()
    role1 = Role()
    role1.handlers = [Handler()]
    role2 = Role()
    role2.handlers = [Handler()]
    play.roles = [role1, role2]
    assert play.compile_roles_handlers() == role1.handlers + role2.handlers


# Generated at 2022-06-17 07:37:51.365018
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    assert play.compile_roles_handlers() == [1, 2]

# Generated at 2022-06-17 07:37:58.051479
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    play.roles[1].get_handler_blocks = lambda: [4, 5, 6]
    play.roles[2].get_handler_blocks = lambda: [7, 8, 9]
    assert play.compile_roles_handlers() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:38:01.715125
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:38:12.073616
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with vars_files is None
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []

    # Test with vars_files is a list
    play = Play()
    play.vars_files = ['/path/to/file1', '/path/to/file2']
    assert play.get_vars_files() == ['/path/to/file1', '/path/to/file2']

    # Test with vars_files is a string
    play = Play()
    play.vars_files = '/path/to/file'
    assert play.get_vars_files() == ['/path/to/file']


# Generated at 2022-06-17 07:38:18.115609
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2]
    play.tasks = [3,4]
    play.post_tasks = [5,6]
    assert play.get_tasks() == [1,2,3,4,5,6]

# Generated at 2022-06-17 07:38:23.615252
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:38:32.805467
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.vars = dict(a=1, b=2)
    play.vars_prompt = dict(c=3, d=4)
    play.hosts = 'all'
    play.name = 'test_play'
    play.connection = 'local'
    play.remote_user = 'root'
    play.gather_facts = True
    play.serial = 2
    play.max_fail_percentage = 50
    play.any_errors_fatal = True
    play.roles = [Role(), Role()]
    play.tasks = [Task(), Task()]
    play.handlers = [Handler(), Handler()]
    play.tags = ['tag1', 'tag2']
    play.skip_tags = ['tag3', 'tag4']
    play.notify

# Generated at 2022-06-17 07:38:39.812803
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    p.roles[1].get_handler_blocks = lambda: [4, 5, 6]
    assert p.compile_roles_handlers() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-17 07:39:06.051088
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test Play.get_tasks()
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Rescue object
    rescue = Rescue()
    # Create a Always object
    always = Always()
    # Add the Task object to the Block object
    block.block = [task]
    # Add the Rescue object to the Block object
    block.rescue = [rescue]
    # Add the Always object to the Block object
    block.always = [always]
    # Add the Block object to the Play object
    play.tasks = [block]
    # Get the tasks of the Play object
    tasks = play.get_tasks()
    # Check if the tasks are correct

# Generated at 2022-06-17 07:39:13.486678
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_host'
    assert play.get_name() == 'test_host'
    play.hosts = ['test_host1', 'test_host2']
    assert play.get_name() == 'test_host1,test_host2'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:39:22.398027
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1,2,3]
    p.tasks = [4,5,6]
    p.post_tasks = [7,8,9]
    assert p.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:39:26.942370
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create a Play object
    p = Play()
    # Create a dict object
    ds = dict()
    # Call method preprocess_data of class Play
    p.preprocess_data(ds)


# Generated at 2022-06-17 07:39:29.806090
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = {'user': 'root'}
    play.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds


# Generated at 2022-06-17 07:39:38.537266
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with vars_files as None
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []

    # Test with vars_files as a string
    p = Play()
    p.vars_files = 'test_vars_files'
    assert p.get_vars_files() == ['test_vars_files']

    # Test with vars_files as a list
    p = Play()
    p.vars_files = ['test_vars_files']
    assert p.get_vars_files() == ['test_vars_files']


# Generated at 2022-06-17 07:39:46.352768
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:39:52.640121
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:40:00.787610
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:40:05.789747
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'vars_files'
    assert p.get_vars_files() == ['vars_files']
    p.vars_files = ['vars_files']
    assert p.get_vars_files() == ['vars_files']


# Generated at 2022-06-17 07:40:31.756130
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Task object
    task1 = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
   

# Generated at 2022-06-17 07:40:40.634882
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:40:49.439616
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block2 = Block()
    # Create a Handler object
    handler2 = Handler()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Handler object
    handler3 = Handler()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Handler object
    handler4 = Handler()
    # Create a Task object
    task4 = Task()
    # Create a Block object
   

# Generated at 2022-06-17 07:40:55.757714
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test_name'
    assert p.get_name() == 'test_name'
    p.name = None
    p.hosts = 'test_hosts'
    assert p.get_name() == 'test_hosts'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:41:03.038660
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:41:08.542128
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:41:15.624321
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:41:27.769519
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'test_hosts'
    play.connection = 'test_connection'
    play.port = 'test_port'
    play.remote_user = 'test_remote_user'
    play.vars = {'test_key': 'test_value'}
    play.vars_files = 'test_vars_files'
    play.vars_prompt = 'test_vars_prompt'
    play.tags = ['test_tag']
    play.gather_facts = 'test_gather_facts'
    play.gather_subset = ['test_gather_subset']
    play.roles = ['test_role']
    play.tasks = ['test_task']

# Generated at 2022-06-17 07:41:32.401561
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:41:42.185125
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict
    ds = {'hosts': 'localhost', 'user': 'root'}
    p = Play()
    new_ds = p.preprocess_data(ds)
    assert new_ds == {'hosts': 'localhost', 'remote_user': 'root'}
    # Test with a list
    ds = ['localhost']
    p = Play()
    new_ds = p.preprocess_data(ds)
    assert new_ds == ['localhost']
    # Test with a string
    ds = 'localhost'
    p = Play()
    new_ds = p.preprocess_data(ds)
    assert new_ds == 'localhost'
    # Test with a None
    ds = None
    p = Play()
    new_ds = p.preprocess_data(ds)
   

# Generated at 2022-06-17 07:41:58.182304
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # TODO: Implement test
    pass

# Generated at 2022-06-17 07:42:02.775107
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2]
    play.tasks = [3,4]
    play.post_tasks = [5,6]
    assert play.get_tasks() == [1,2,3,4,5,6]


# Generated at 2022-06-17 07:42:13.810911
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test 1:
    #   - pre_tasks: [task1, task2]
    #   - tasks: [task3, task4]
    #   - post_tasks: [task5, task6]
    #   - handlers: [handler1, handler2]
    #   - roles: [role1, role2]
    #   - expected: [task1, task2, task3, task4, task5, task6]
    play = Play()
    play.pre_tasks = [Task(), Task()]
    play.tasks = [Task(), Task()]
    play.post_tasks = [Task(), Task()]
    play.handlers = [Handler(), Handler()]
    play.roles = [Role(), Role()]
    assert play.get_tasks() == play.pre_tasks

# Generated at 2022-06-17 07:42:19.685087
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:42:25.336109
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = {'user': 'root'}
    play.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds


# Generated at 2022-06-17 07:42:34.244579
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.name = 'test_play'
    p.hosts = 'test_hosts'
    p.remote_user = 'test_remote_user'
    p.connection = 'test_connection'
    p.port = 'test_port'
    p.gather_facts = 'test_gather_facts'
    p.vars_prompt = 'test_vars_prompt'
    p.vars_files = 'test_vars_files'
    p.vars_prompt = 'test_vars_prompt'
    p.vars_files = 'test_vars_files'
    p.vars = 'test_vars'
    p.tags = 'test_tags'
    p.skip_tags = 'test_skip_tags'
    p.any

# Generated at 2022-06-17 07:42:40.116505
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1,2,3]
    p.tasks = [4,5,6]
    p.post_tasks = [7,8,9]
    assert p.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:42:48.870399
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'localhost'
    assert p.get_name() == 'localhost'
    p.hosts = ['localhost', '127.0.0.1']
    assert p.get_name() == 'localhost,127.0.0.1'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:42:54.334889
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:43:06.872487
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block1 = Block()
    # Create a Task object
    task1 = Task()
    # Create a Block object
    block2 = Block()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Task object
    task4 = Task()
    # Create a Block object
    block5 = Block()
    # Create a Task object
   

# Generated at 2022-06-17 07:43:21.977615
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_name'
    assert play.get_name() == 'test_name'


# Generated at 2022-06-17 07:43:27.345947
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    assert play.compile_roles_handlers() == [1, 2, 3]


# Generated at 2022-06-17 07:43:32.158880
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[])
    assert play.compile_roles_handlers() == []
    play.roles[0].get_handler_blocks.assert_called_once_with(play=play)


# Generated at 2022-06-17 07:43:40.419221
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test.yml'
    assert play.get_vars_files() == ['test.yml']
    play.vars_files = ['test1.yml', 'test2.yml']
    assert play.get_vars_files() == ['test1.yml', 'test2.yml']


# Generated at 2022-06-17 07:43:45.046845
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2]
    play.tasks = [3,4]
    play.post_tasks = [5,6]
    assert play.get_tasks() == [1,2,3,4,5,6]


# Generated at 2022-06-17 07:43:48.822561
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    play.roles[1].get_handler_blocks = lambda: [4, 5, 6]
    play.roles[2].get_handler_blocks = lambda: [7, 8, 9]
    assert play.compile_roles_handlers() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:43:59.121499
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Task object
    task1 = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
   

# Generated at 2022-06-17 07:44:02.992940
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    data = dict(
        name="test",
        hosts="all",
        user="root",
        tasks=[
            dict(action=dict(module="shell", args="echo hello"))
        ]
    )
    play.preprocess_data(data)
    assert data['remote_user'] == "root"
    assert 'user' not in data


# Generated at 2022-06-17 07:44:11.538135
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'all'
    play.roles = [Role(), Role()]
    play.roles[0].name = 'test_role_1'
    play.roles[1].name = 'test_role_2'
    play.roles[0].tasks = [Task(), Task()]
    play.roles[1].tasks = [Task(), Task()]
    play.roles[0].tasks[0].name = 'test_task_1'
    play.roles[0].tasks[1].name = 'test_task_2'
    play.roles[1].tasks[0].name = 'test_task_3'

# Generated at 2022-06-17 07:44:16.426866
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = ['test1', 'test2']
    assert p.get_name() == 'test1,test2'


# Generated at 2022-06-17 07:44:35.150898
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:44:41.956734
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_hosts'
    assert play.get_name() == 'test_hosts'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:44:54.557998
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test'
    play.hosts = 'all'
    play.tasks = [{'name': 'test'}]
    play.roles = [Role({'name': 'test'})]
    play._included_path = 'test'
    play._action_groups = {'test': 'test'}
    play._group_actions = {'test': 'test'}
    data = play.serialize()
    assert data['name'] == 'test'
    assert data['hosts'] == 'all'
    assert data['tasks'] == [{'name': 'test'}]
    assert data['roles'] == [{'name': 'test'}]
    assert data['included_path'] == 'test'

# Generated at 2022-06-17 07:45:04.879857
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Task object
    task1 = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
    task10 = Task()
    # Create a Task object
    task11 = Task()
    # Create a Task object

# Generated at 2022-06-17 07:45:08.791111
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1,2,3]
    p.tasks = [4,5,6]
    p.post_tasks = [7,8,9]
    assert p.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:45:18.828549
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['/path/to/file1', '/path/to/file2']
    assert play.get_vars_files() == ['/path/to/file1', '/path/to/file2']
    play.vars_files = '/path/to/file1'
    assert play.get_vars_files() == ['/path/to/file1']
    play.vars_files = None
    assert play.get_vars_files() == []


# Generated at 2022-06-17 07:45:24.618664
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = "test"
    assert play.get_vars_files() == ["test"]
    play.vars_files = ["test1", "test2"]
    assert play.get_vars_files() == ["test1", "test2"]
    play.vars_files = None
    assert play.get_vars_files() == []


# Generated at 2022-06-17 07:45:27.759622
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-17 07:45:32.839917
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = "test"
    assert play.get_vars_files() == ["test"]
    play.vars_files = ["test1", "test2"]
    assert play.get_vars_files() == ["test1", "test2"]


# Generated at 2022-06-17 07:45:41.714327
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
    task10 = Task()
    # Create a Task object
   