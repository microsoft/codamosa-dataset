

# Generated at 2022-06-17 07:36:11.401761
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'roles': [{'name': 'role1', 'tasks': [{'name': 'task1'}]}]})
    assert play.roles[0].name == 'role1'
    assert play.roles[0].tasks[0].name == 'task1'


# Generated at 2022-06-17 07:36:22.020022
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-17 07:36:28.901445
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with data structure containing 'user'
    ds = {'user': 'root'}
    p = Play()
    assert p.preprocess_data(ds) == {'remote_user': 'root'}

    # Test with data structure not containing 'user'
    ds = {'remote_user': 'root'}
    p = Play()
    assert p.preprocess_data(ds) == {'remote_user': 'root'}


# Generated at 2022-06-17 07:36:35.617715
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.vars = dict(a=1, b=2)
    play.vars_files = ['/tmp/a', '/tmp/b']
    play.hosts = 'all'
    play.name = 'test'
    play.connection = 'local'
    play.remote_user = 'root'
    play.sudo = True
    play.sudo_user = 'root'
    play.become = True
    play.become_method = 'sudo'
    play.become_user = 'root'
    play.tags = ['a', 'b']
    play.gather_facts = True
    play.any_errors_fatal = True
    play.max_fail_percentage = 50
    play.serial = 2
    play.strategy = 'linear'
    play.trans

# Generated at 2022-06-17 07:36:46.300028
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-17 07:36:52.629959
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1,2,3]
    p.tasks = [4,5,6]
    p.post_tasks = [7,8,9]
    assert p.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:37:06.121548
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Create a list of tasks
    t_list = [t]
    # Create a list of handlers
    h_list = [h]
    # Create a list of blocks
    b_list = [b]
    # Set the handlers of the block
    b.block = h_list
    # Set the tasks of the block
    b.rescue = t_list
    # Set the tasks of the block
    b.always = t_list
    # Set the handlers of the role
    r.handlers = b_list
    # Set the handlers of the role


# Generated at 2022-06-17 07:37:18.411294
# Unit test for constructor of class Play
def test_Play():
    # Test with empty datastructure
    p = Play()
    assert p.name is None
    assert p.hosts is None
    assert p.remote_user is None
    assert p.connection is None
    assert p.port is None
    assert p.gather_facts is None
    assert p.vars_prompt is None
    assert p.vars_files is None
    assert p.vars is None
    assert p.tags is None
    assert p.skip_tags is None
    assert p.any_errors_fatal is None
    assert p.roles is None
    assert p.handlers is None
    assert p.tasks is None
    assert p.pre_tasks is None
    assert p.post_tasks is None
    assert p.force_handlers is None
    assert p.max_fail

# Generated at 2022-06-17 07:37:21.285758
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'roles': [{'name': 'test', 'tasks': [{'name': 'test'}]}]})
    assert play.roles[0].name == 'test'
    assert play.roles[0].tasks[0].name == 'test'


# Generated at 2022-06-17 07:37:26.535328
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
    task10 = Task()
    # Create a Task object
   

# Generated at 2022-06-17 07:37:40.856438
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'


# Generated at 2022-06-17 07:37:50.485247
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
    task10 = Task()
    # Create a Task object
    task11 = Task()
    # Create a Task object
    task12 = Task()
    # Create a Task object

# Generated at 2022-06-17 07:37:57.450814
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name == ''
    assert p.hosts == ''
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.connection == C.DEFAULT_TRANSPORT
    assert p.port == C.DEFAULT_REMOTE_PORT
    assert p.gather_facts == C.DEFAULT_GATHER_FACTS
    assert p.vars == {}
    assert p.vars_prompt == []
    assert p.vars_files == []
    assert p.tags == frozenset(['all'])
    assert p.skip_tags == frozenset([])
    assert p.handlers == []
    assert p.tasks == []
    assert p.post_tasks == []
    assert p.pre_tasks == []

# Generated at 2022-06-17 07:38:01.150026
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:38:07.842809
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block1 = Block()
    # Create a Task object
    task1 = Task()
    # Create a Block object
    block2 = Block()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Task object
    task4 = Task()
    # Create a Block object
    block5 = Block()
    # Create a Task object
   

# Generated at 2022-06-17 07:38:11.244509
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'vars_files'
    assert p.get_vars_files() == ['vars_files']
    p.vars_files = ['vars_files']
    assert p.get_vars_files() == ['vars_files']


# Generated at 2022-06-17 07:38:22.698586
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # create a Play object
    play = Play()
    # create a Block object
    block = Block()
    # create a Task object
    task = Task()
    # create a list of tasks
    tasks = [task]
    # set the value of the attribute tasks of the object play
    play.tasks = tasks
    # set the value of the attribute block of the object block
    block.block = tasks
    # set the value of the attribute pre_tasks of the object play
    play.pre_tasks = [block]
    # set the value of the attribute post_tasks of the object play
    play.post_tasks = [block]
    # get the value of the attribute tasks of the object play
    tasks = play.get_tasks()
    # test if the value of the attribute tasks of the object play is equal to the list

# Generated at 2022-06-17 07:38:26.411196
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    assert play.compile_roles_handlers() == []

    # Test with roles
    play = Play()
    play.roles = [Role()]
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-17 07:38:34.243303
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:38:42.742452
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name is None
    assert play.hosts == 'all'
    assert play.remote_user == C.DEFAULT_REMOTE_USER
    assert play.connection == C.DEFAULT_TRANSPORT
    assert play.port == C.DEFAULT_REMOTE_PORT
    assert play.gather_facts == C.DEFAULT_GATHER_FACTS
    assert play.vars == {}
    assert play.vars_prompt == []
    assert play.vars_files == []
    assert play.tags == frozenset(['all'])
    assert play.skip_tags == frozenset()
    assert play.any_errors_fatal is False
    assert play.roles == []
    assert play.handlers == []
    assert play.tasks == []
    assert play

# Generated at 2022-06-17 07:38:57.519852
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:39:06.784662
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with vars_files as None
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []

    # Test with vars_files as a string
    p = Play()
    p.vars_files = 'test'
    assert p.get_vars_files() == ['test']

    # Test with vars_files as a list
    p = Play()
    p.vars_files = ['test1', 'test2']
    assert p.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:39:16.314252
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'all'
    play.roles = [Role(), Role()]
    play.tasks = [Task(), Task()]
    play.post_tasks = [Task(), Task()]
    play.pre_tasks = [Task(), Task()]
    play.handlers = [Handler(), Handler()]
    play.vars = {'test_var': 'test_value'}
    play.vars_files = ['/path/to/file']
    play.vars_prompt = [{'name': 'test_var_prompt', 'prompt': 'test_prompt'}]
    play.tags = ['test_tag']
    play.any_errors_fatal = True
    play.max_fail_percentage

# Generated at 2022-06-17 07:39:21.935229
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:39:27.026548
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    data = {'user': 'root'}
    play.preprocess_data(data)
    assert data['remote_user'] == 'root'
    assert 'user' not in data


# Generated at 2022-06-17 07:39:30.623580
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:39:39.896945
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict
    ds = {'hosts': 'localhost', 'user': 'test', 'tasks': [{'name': 'test'}]}
    p = Play()
    assert p.preprocess_data(ds) == {'hosts': 'localhost', 'remote_user': 'test', 'tasks': [{'name': 'test'}]}

    # Test with a list
    ds = [{'hosts': 'localhost', 'user': 'test', 'tasks': [{'name': 'test'}]}]
    p = Play()
    assert p.preprocess_data(ds) == [{'hosts': 'localhost', 'remote_user': 'test', 'tasks': [{'name': 'test'}]}]


# Generated at 2022-06-17 07:39:52.974295
# Unit test for method preprocess_data of class Play

# Generated at 2022-06-17 07:39:58.062801
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:40:05.502361
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Create a Task object
    t2 = Task()
    # Create a Task object
    t3 = Task()
    # Create a Task object
    t4 = Task()
    # Create a Task object
    t5 = Task()
    # Create a Task object
    t6 = Task()
    # Create a Task object
    t7 = Task()
    # Create a Task object
    t8 = Task()
    # Create a Task object
    t9 = Task()
    # Create a Task object
    t10 = Task()
    # Create a Task object
   

# Generated at 2022-06-17 07:40:21.171929
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:40:27.164909
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name is None
    assert play.hosts is None
    assert play.remote_user is None
    assert play.connection is None
    assert play.port is None
    assert play.gather_facts is None
    assert play.vars is None
    assert play.vars_files is None
    assert play.vars_prompt is None
    assert play.tags is None
    assert play.skip_tags is None
    assert play.handlers is None
    assert play.tasks is None
    assert play.roles is None
    assert play.post_tasks is None
    assert play.pre_tasks is None
    assert play.notify is None
    assert play.listen is None
    assert play.any_errors_fatal is None

# Generated at 2022-06-17 07:40:32.312078
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:40:45.230388
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with pre_tasks, tasks and post_tasks
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test with pre_tasks, tasks and post_tasks
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test

# Generated at 2022-06-17 07:40:49.304333
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:40:55.355102
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:41:08.757362
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.loop import Loop
    from ansible.playbook.task.block import Block as TaskBlock
    from ansible.playbook.task.include import Include
    from ansible.playbook.task.meta import Meta
    from ansible.playbook.task.when import When
    from ansible.playbook.task.import_role import ImportRole


# Generated at 2022-06-17 07:41:19.586352
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a list of tasks
    tasks = [task]
    # Set the tasks attribute of the Block object
    block.block = tasks
    # Create a list of blocks
    blocks = [block]
    # Set the pre_tasks, tasks and post_tasks attributes of the Play object
    play.pre_tasks = blocks
    play.tasks = blocks
    play.post_tasks = blocks
    # Call the get_tasks method of the Play object
    play.get_tasks()


# Generated at 2022-06-17 07:41:25.909362
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1]
    play.tasks = [2]
    play.post_tasks = [3]
    assert play.get_tasks() == [1, 2, 3]


# Generated at 2022-06-17 07:41:36.890611
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with empty roles
    p = Play()
    p.roles = []
    assert p.compile_roles_handlers() == []

    # Test with roles with no handlers
    p = Play()
    p.roles = [Role(), Role()]
    assert p.compile_roles_handlers() == []

    # Test with roles with handlers
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].handlers = [Handler(), Handler()]
    p.roles[1].handlers = [Handler(), Handler()]
    assert p.compile_roles_handlers() == p.roles[0].handlers + p.roles[1].handlers

    # Test with roles with handlers and from_include
    p = Play()

# Generated at 2022-06-17 07:41:54.963137
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = "test"
    assert play.get_vars_files() == ["test"]
    play.vars_files = ["test1", "test2"]
    assert play.get_vars_files() == ["test1", "test2"]


# Generated at 2022-06-17 07:42:01.032078
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    play.roles[1].get_handler_blocks = lambda: [4, 5, 6]
    assert play.compile_roles_handlers() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-17 07:42:07.331263
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = "test"
    assert p.get_vars_files() == ["test"]
    p.vars_files = ["test1", "test2"]
    assert p.get_vars_files() == ["test1", "test2"]


# Generated at 2022-06-17 07:42:16.842218
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [
        Role(name='role1', handlers=['handler1', 'handler2']),
        Role(name='role2', handlers=['handler3', 'handler4']),
        Role(name='role3', handlers=['handler5', 'handler6']),
    ]
    handlers = play.compile_roles_handlers()
    assert handlers == ['handler1', 'handler2', 'handler3', 'handler4', 'handler5', 'handler6']


# Generated at 2022-06-17 07:42:23.411808
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block2 = Block()
    # Create a Handler object
    handler2 = Handler()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Handler object
    handler3 = Handler()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Handler object
    handler4 = Handler()
    # Create a Task object
    task4 = Task()
    # Create a Block object
   

# Generated at 2022-06-17 07:42:33.790679
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'test_host'
    play.vars = {'test_var': 'test_value'}
    play.vars_files = 'test_vars_files'
    play.vars_prompt = 'test_vars_prompt'
    play.tags = 'test_tags'
    play.gather_facts = 'test_gather_facts'
    play.any_errors_fatal = 'test_any_errors_fatal'
    play.force_handlers = 'test_force_handlers'
    play.max_fail_percentage = 'test_max_fail_percentage'
    play.serial = 'test_serial'
    play.strategy = 'test_strategy'
    play.order

# Generated at 2022-06-17 07:42:39.023831
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    assert play.compile_roles_handlers() == [1, 2]


# Generated at 2022-06-17 07:42:46.983383
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].handlers = [Handler(), Handler()]
    p.roles[1].handlers = [Handler(), Handler()]
    assert len(p.compile_roles_handlers()) == 4

# Generated at 2022-06-17 07:42:53.751336
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_host'
    assert play.get_name() == 'test_host'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:43:03.946152
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[1, 2, 3])
    play.roles[1].get_handler_blocks = MagicMock(return_value=[4, 5, 6])
    assert play.compile_roles_handlers() == [1, 2, 3, 4, 5, 6]
    play.roles[0].get_handler_blocks.assert_called_once_with(play=play)
    play.roles[1].get_handler_blocks.assert_called_once_with(play=play)


# Generated at 2022-06-17 07:43:26.275961
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:43:31.068101
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = "test_play"
    assert p.get_name() == "test_play"
    p.name = None
    p.hosts = "test_host"
    assert p.get_name() == "test_host"
    p.hosts = None
    assert p.get_name() == ""


# Generated at 2022-06-17 07:43:35.762472
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:43:45.996973
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name is None
    assert p.hosts == 'all'
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.connection == C.DEFAULT_TRANSPORT
    assert p.port == C.DEFAULT_REMOTE_PORT
    assert p.gather_facts is True
    assert p.vars == dict()
    assert p.vars_prompt == list()
    assert p.vars_files == list()
    assert p.tags == list()
    assert p.skip_tags == list()
    assert p.handlers == list()
    assert p.tasks == list()
    assert p.roles == list()
    assert p.post_tasks == list()
    assert p.pre_tasks == list()

# Generated at 2022-06-17 07:43:50.181262
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:43:56.941212
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:44:03.314691
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with empty vars_files
    p = Play()
    p.vars_files = []
    assert p.get_vars_files() == []

    # Test with vars_files as a list
    p = Play()
    p.vars_files = ['/path/to/file1', '/path/to/file2']
    assert p.get_vars_files() == ['/path/to/file1', '/path/to/file2']

    # Test with vars_files as a string
    p = Play()
    p.vars_files = '/path/to/file'
    assert p.get_vars_files() == ['/path/to/file']

# Generated at 2022-06-17 07:44:07.044890
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:44:11.934898
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:44:14.475188
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    p = Play()
    assert p.compile_roles_handlers() == []

    # Test with roles
    p = Play()
    p.roles = [Role(), Role()]
    assert p.compile_roles_handlers() == []


# Generated at 2022-06-17 07:44:51.312916
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[])
    assert play.compile_roles_handlers() == []
    play.roles[0].get_handler_blocks.assert_called_once_with(play=play)


# Generated at 2022-06-17 07:44:55.724524
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:45:00.573945
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['/path/to/vars_file1', '/path/to/vars_file2']
    assert play.get_vars_files() == ['/path/to/vars_file1', '/path/to/vars_file2']


# Generated at 2022-06-17 07:45:04.797337
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 07:45:07.721454
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2, 3]
    assert play.compile_roles_handlers() == [1, 2, 3]


# Generated at 2022-06-17 07:45:22.467269
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block1 = Block()
    # Create a Handler object
    handler1 = Handler()
    # Create a Task object
    task1 = Task()
    # Create a Block object
    block2 = Block()
    # Create a Handler object
    handler2 = Handler()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Handler object
    handler3 = Handler()
    # Create a Task object
    task3 = Task()
    # Create a Block object
   

# Generated at 2022-06-17 07:45:28.017671
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'test'
    assert p.get_vars_files() == ['test']
    p.vars_files = ['test1', 'test2']
    assert p.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:45:30.961646
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[])
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-17 07:45:41.559716
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a play object
    play = Play()
    # Create a role object
    role = Role()
    # Create a handler object
    handler = Handler()
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a list of handlers
    handlers = [handler]
    # Create a list of blocks
    blocks = [block]
    # Create a list of tasks
    tasks = [task]
    # Set the handlers of the role object
    role.set_handlers(handlers)
    # Set the blocks of the role object
    role.set_blocks(blocks)
    # Set the tasks of the role object
    role.set_tasks(tasks)
    # Create a list of roles
    roles = [role]
    # Set the roles of the play object
