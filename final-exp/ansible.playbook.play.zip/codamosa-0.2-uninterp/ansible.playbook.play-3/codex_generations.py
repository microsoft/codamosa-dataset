

# Generated at 2022-06-17 07:36:12.075775
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [Role(), Role()]
    p.roles[0].handlers = [Handler()]
    p.roles[1].handlers = [Handler()]
    assert len(p.compile_roles_handlers()) == 2


# Generated at 2022-06-17 07:36:18.026264
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:36:21.775033
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data({'user': 'test'})
    assert play.remote_user == 'test'
    assert 'user' not in play._ds


# Generated at 2022-06-17 07:36:27.026475
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1,2,3]
    p.tasks = [4,5,6]
    p.post_tasks = [7,8,9]
    assert p.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:36:34.402548
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a dict
    ds = {'hosts': 'localhost', 'user': 'root'}
    p = Play()
    p.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds

    # Test with a list
    ds = ['localhost', 'root']
    p = Play()
    p.preprocess_data(ds)
    assert ds[1] == 'root'
    assert len(ds) == 2

    # Test with a string
    ds = 'localhost'
    p = Play()
    p.preprocess_data(ds)
    assert ds == 'localhost'


# Generated at 2022-06-17 07:36:37.834939
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({"hosts": "all", "name": "test_play", "roles": [{"name": "test_role"}]})
    assert play.name == "test_play"
    assert play.hosts == "all"
    assert play.roles[0].name == "test_role"


# Generated at 2022-06-17 07:36:51.202277
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with a valid data structure
    ds = {'hosts': 'localhost', 'user': 'root', 'tasks': [{'name': 'test'}]}
    p = Play()
    p.preprocess_data(ds)
    assert ds['remote_user'] == 'root'
    assert 'user' not in ds

    # Test with an invalid data structure
    ds = {'hosts': 'localhost', 'user': 'root', 'tasks': [{'name': 'test'}], 'remote_user': 'root'}
    p = Play()
    try:
        p.preprocess_data(ds)
    except AnsibleParserError as e:
        assert 'both' in to_text(e)
        assert 'user' in to_text(e)

# Generated at 2022-06-17 07:36:58.835676
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = MagicMock(return_value=[1, 2, 3])
    play.roles[1].get_handler_blocks = MagicMock(return_value=[4, 5, 6])
    assert play.compile_roles_handlers() == [1, 2, 3, 4, 5, 6]
    play.roles[0].get_handler_blocks.assert_called_once_with(play=play)
    play.roles[1].get_handler_blocks.assert_called_once_with(play=play)


# Generated at 2022-06-17 07:37:04.181584
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:37:08.877580
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:37:25.527445
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:37:28.427310
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'


# Generated at 2022-06-17 07:37:34.244664
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:37:48.368135
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Create a list of blocks
    block_list = []
    # Append the Block object to the list of blocks
    block_list.append(b)
    # Set the block attribute of the Role object to the list of blocks
    r.block = block_list
    # Create a list of roles
    role_list = []
    # Append the Role object to the list of roles
    role_list.append(r)
    # Set the roles attribute of the Play object to the list of roles
    p.roles = role_list
    # Create a list of handlers

# Generated at 2022-06-17 07:37:55.331015
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Block object
    b = Block()
    # Create a Handler object
    h = Handler()
    # Create a Task object
    t = Task()
    # Create a Block object
    b1 = Block()
    # Create a Task object
    t1 = Task()
    # Create a Task object
    t2 = Task()
    # Create a Task object
    t3 = Task()
    # Create a Task object
    t4 = Task()
    # Create a Task object
    t5 = Task()
    # Create a Task object
    t6 = Task()
    # Create a Task object
    t7 = Task()
    # Create a Task object
    t8 = Task()
    # Create a Task object
   

# Generated at 2022-06-17 07:37:59.944320
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.tasks = [1,2,3]
    play.pre_tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [4,5,6,1,2,3,7,8,9]


# Generated at 2022-06-17 07:38:11.153229
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()

    # Create a Block object
    block = Block()

    # Create a Task object
    task = Task()

    # Set the block attribute of the Play object
    play.block = [block]

    # Set the block attribute of the Block object
    block.block = [task]

    # Call the get_tasks method of the Play object
    tasklist = play.get_tasks()

    # Assert that the tasklist is a list
    assert isinstance(tasklist, list)

    # Assert that the tasklist contains the task
    assert task in tasklist


# Generated at 2022-06-17 07:38:19.589563
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test_vars_files'
    assert play.get_vars_files() == ['test_vars_files']
    play.vars_files = ['test_vars_files1', 'test_vars_files2']
    assert play.get_vars_files() == ['test_vars_files1', 'test_vars_files2']


# Generated at 2022-06-17 07:38:24.154003
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:38:27.441184
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ['/path/to/file1', '/path/to/file2']
    assert p.get_vars_files() == ['/path/to/file1', '/path/to/file2']


# Generated at 2022-06-17 07:38:40.396053
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test for empty vars_files
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    # Test for single vars_files
    p.vars_files = "test.yml"
    assert p.get_vars_files() == ["test.yml"]
    # Test for multiple vars_files
    p.vars_files = ["test1.yml", "test2.yml"]
    assert p.get_vars_files() == ["test1.yml", "test2.yml"]


# Generated at 2022-06-17 07:38:50.321576
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    p = Play()
    # Create a Role object
    r = Role()
    # Create a Handler object
    h = Handler()
    # Create a Block object
    b = Block()
    # Create a Task object
    t = Task()
    # Create a RoleInclude object
    ri = RoleInclude()
    # Create a RoleDependency object
    rd = RoleDependency()
    # Create a RoleRequirement object
    rr = RoleRequirement()
    # Create a RoleDepSpec object
    rds = RoleDepSpec()
    # Create a RoleRequirementSpec object
    rrs = RoleRequirementSpec()
    # Create a RoleSpec object
    rs = RoleSpec()
    # Create a RoleSpecTerm object
    rst = RoleSpecTerm()
    # Create a RoleSpecParser

# Generated at 2022-06-17 07:39:03.286371
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.hosts = 'test_hosts'
    play.connection = 'test_connection'
    play.remote_user = 'test_remote_user'
    play.become = True
    play.become_method = 'test_become_method'
    play.become_user = 'test_become_user'
    play.vars = {'test_key': 'test_value'}

# Generated at 2022-06-17 07:39:08.433347
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:39:14.398148
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a list of tasks
    tasks = [task, task]
    # Set the tasks of the Block object
    block.block = tasks
    # Set the tasks of the Play object
    play.tasks = [block]
    # Get the tasks of the Play object
    result = play.get_tasks()
    # Check if the result is correct
    assert result == tasks


# Generated at 2022-06-17 07:39:16.066179
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'


# Generated at 2022-06-17 07:39:23.065488
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2]
    play.tasks = [3, 4]
    play.post_tasks = [5, 6]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-17 07:39:28.869096
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(), Role()]
    play.roles[0].get_handler_blocks = lambda: [1, 2]
    play.roles[1].get_handler_blocks = lambda: [3, 4]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-17 07:39:37.336467
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''

# Generated at 2022-06-17 07:39:47.466321
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a Block object
    block_1 = Block()
    # Create a Handler object
    handler_1 = Handler()
    # Create a Task object
    task_1 = Task()
    # Create a Block object
    block_2 = Block()
    # Create a Handler object
    handler_2 = Handler()
    # Create a Task object
    task_2 = Task()
    # Create a Block object
    block_3 = Block()
    # Create a Handler object
    handler_3 = Handler()
    # Create a Task object
    task_3 = Task()

# Generated at 2022-06-17 07:40:07.700024
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']

# Generated at 2022-06-17 07:40:15.844687
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = ['test']
    assert p.get_name() == 'test'
    p.hosts = []
    assert p.get_name() == ''
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:40:21.434037
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.deserialize({'roles': [{'name': 'test_role'}]})
    assert play.serialize() == {'roles': [{'name': 'test_role'}]}


# Generated at 2022-06-17 07:40:29.705525
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    p = Play()
    assert p.compile_roles_handlers() == []

    # Test with roles
    p = Play()
    p.roles = [Role(), Role()]
    assert p.compile_roles_handlers() == []
    p.roles[0].handlers = [Handler(), Handler()]
    assert p.compile_roles_handlers() == [Handler(), Handler()]
    p.roles[1].handlers = [Handler(), Handler()]
    assert p.compile_roles_handlers() == [Handler(), Handler(), Handler(), Handler()]
    p.roles[1].handlers = []
    assert p.compile_roles_handlers() == [Handler(), Handler()]
    p.roles[0].handlers = []


# Generated at 2022-06-17 07:40:33.113694
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2]
    play.tasks = [3,4]
    play.post_tasks = [5,6]
    assert play.get_tasks() == [1,2,3,4,5,6]


# Generated at 2022-06-17 07:40:39.913385
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    play.roles = []
    assert play.compile_roles_handlers() == []

    # Test with roles
    play = Play()
    play.roles = [Role(), Role()]
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-17 07:40:46.183941
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Add the Task object to the Block object
    block.block = [task]
    # Add the Block object to the Play object
    play.tasks = [block]
    # Call the method get_tasks of the Play object
    result = play.get_tasks()
    # Check the result
    assert result == [task]


# Generated at 2022-06-17 07:40:54.414007
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:41:02.540034
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [1,2,3]
    p.pre_tasks = [4,5,6]
    p.post_tasks = [7,8,9]
    assert p.get_tasks() == [4,5,6,1,2,3,7,8,9]

# Generated at 2022-06-17 07:41:08.142879
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_hosts'
    assert play.get_name() == 'test_hosts'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:41:23.223448
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create a Play object
    p = Play()
    # Set the name attribute of the Play object
    p.name = 'test'
    # Assert that the get_name method returns the name of the Play object
    assert p.get_name() == 'test'


# Generated at 2022-06-17 07:41:31.107237
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:41:35.765541
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:41:40.994420
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:41:46.566324
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    p = Play()
    # Create a Block object
    b = Block()
    # Create a Task object
    t = Task()
    # Add the Task object to the Block object
    b.block = [t]
    # Add the Block object to the Play object
    p.pre_tasks = [b]
    # Call the method get_tasks of the Play object
    tasklist = p.get_tasks()
    # Check the result
    assert tasklist == [t]


# Generated at 2022-06-17 07:41:49.720272
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:41:56.099123
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:42:07.628025
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name is None
    assert p.hosts is None
    assert p.remote_user is None
    assert p.connection is None
    assert p.port is None
    assert p.gather_facts is None
    assert p.vars is None
    assert p.vars_files is None
    assert p.vars_prompt is None
    assert p.tags is None
    assert p.skip_tags is None
    assert p.handlers is None
    assert p.tasks is None
    assert p.roles is None
    assert p.post_tasks is None
    assert p.pre_tasks is None
    assert p.notify is None
    assert p.listen is None
    assert p.max_fail_percentage is None
    assert p.serial is None
   

# Generated at 2022-06-17 07:42:15.533927
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:42:25.342317
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'vars_files'
    assert play.get_vars_files() == ['vars_files']
    play.vars_files = ['vars_files']
    assert play.get_vars_files() == ['vars_files']


# Generated at 2022-06-17 07:42:50.483157
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a Block object
    block = Block()
    # Create a Handler object
    handler = Handler()
    # Create a Task object
    task = Task()
    # Create a RoleInclude object
    role_include = RoleInclude()
    # Create a RoleDependency object
    role_dependency = RoleDependency()
    # Create a RoleRequirement object
    role_requirement = RoleRequirement()
    # Create a RoleMeta object
    role_meta = RoleMeta()
    # Create a RoleDefaults object
    role_defaults = RoleDefaults()
    # Create a Role object
    role1 = Role()
    # Create a Block object
    block1 = Block()
    # Create a Handler object
   

# Generated at 2022-06-17 07:43:02.399435
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Task object
    task1 = Task()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
    task10 = Task()
    # Create a Task object
    task11 = Task()
    # Create a Task object

# Generated at 2022-06-17 07:43:12.530734
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test with no name
    p = Play()
    assert p.get_name() == ''

    # Test with name
    p = Play(name='test')
    assert p.get_name() == 'test'

    # Test with name and hosts
    p = Play(name='test', hosts='localhost')
    assert p.get_name() == 'test'

    # Test with name and hosts
    p = Play(name='test', hosts=['localhost'])
    assert p.get_name() == 'test'

    # Test with name and hosts
    p = Play(name='test', hosts=['localhost', '127.0.0.1'])
    assert p.get_name() == 'test'

    # Test with name and hosts
    p = Play(hosts='localhost')

# Generated at 2022-06-17 07:43:21.886439
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = None
    play.hosts = 'test_host'
    assert play.get_name() == 'test_host'
    play.hosts = ['test_host1', 'test_host2']
    assert play.get_name() == 'test_host1,test_host2'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:43:29.071113
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = ['test1', 'test2']
    assert p.get_name() == 'test1,test2'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:43:34.146539
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:43:39.195502
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test'
    assert p.get_name() == 'test'
    p.name = None
    p.hosts = 'test'
    assert p.get_name() == 'test'
    p.hosts = None
    assert p.get_name() == ''


# Generated at 2022-06-17 07:43:45.352034
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-17 07:43:49.367253
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'
    play.name = None
    play.hosts = 'test'
    assert play.get_name() == 'test'
    play.hosts = None
    assert play.get_name() == ''


# Generated at 2022-06-17 07:43:57.016640
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:44:12.957539
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2]
    play.tasks = [3,4]
    play.post_tasks = [5,6]
    assert play.get_tasks() == [1,2,3,4,5,6]


# Generated at 2022-06-17 07:44:17.695150
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:44:28.999032
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name is None
    assert play.hosts is None
    assert play.remote_user is None
    assert play.connection is None
    assert play.port is None
    assert play.vars is None
    assert play.vars_prompt is None
    assert play.vars_files is None
    assert play.tags is None
    assert play.skip_tags is None
    assert play.handlers is None
    assert play.tasks is None
    assert play.roles is None
    assert play.default_vars is None
    assert play.force_handlers is None
    assert play.max_fail_percentage is None
    assert play.serial is None
    assert play.strategy is None
    assert play.order is None
    assert play.any_errors_fatal is None


# Generated at 2022-06-17 07:44:34.479908
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-17 07:44:41.067051
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create a new Play object
    p = Play()
    # Set the name attribute of the Play object
    p.name = "test_play"
    # Assert that the name of the Play object is "test_play"
    assert p.get_name() == "test_play"


# Generated at 2022-06-17 07:44:45.547049
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'


# Generated at 2022-06-17 07:44:56.458907
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.vars = dict()
    play.vars_prompt = list()
    play.vars_files = list()
    play.handlers = list()
    play.roles = list()
    play.post_tasks = list()
    play.pre_tasks = list()
    play.tasks = list()
    play.tags = list()
    play.hosts = list()
    play.name = None
    play.connection = 'smart'
    play.remote_user = None
    play.sudo = False
    play.sudo_user = None
    play.become = False
    play.become_method = None
    play.become_user = None
    play.check_mode = False
    play.gather_facts = 'smart'
    play.any_

# Generated at 2022-06-17 07:45:03.166216
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play = Play()
    # Create a list of tasks
    tasks = [Task(), Task()]
    # Set the tasks attribute of the Play object
    play.tasks = tasks
    # Assert that the tasks attribute of the Play object is equal to the list of tasks
    assert play.tasks == tasks
    # Assert that the method get_tasks of the Play object returns the list of tasks
    assert play.get_tasks() == tasks


# Generated at 2022-06-17 07:45:07.556590
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'test'
    assert p.get_vars_files() == ['test']
    p.vars_files = ['test1', 'test2']
    assert p.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-17 07:45:22.467104
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with no roles
    play = Play()
    assert play.compile_roles_handlers() == []

    # Test with one role
    play = Play()
    play.roles = [Role()]
    assert play.compile_roles_handlers() == []

    # Test with one role with handlers
    play = Play()
    role = Role()
    role.handlers = [Handler()]
    play.roles = [role]
    assert play.compile_roles_handlers() == role.handlers

    # Test with two roles with handlers
    play = Play()
    role1 = Role()
    role1.handlers = [Handler()]
    role2 = Role()
    role2.handlers = [Handler()]
    play.roles = [role1, role2]

# Generated at 2022-06-17 07:45:42.396389
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ['/path/to/file1', '/path/to/file2']
    assert p.get_vars_files() == ['/path/to/file1', '/path/to/file2']
