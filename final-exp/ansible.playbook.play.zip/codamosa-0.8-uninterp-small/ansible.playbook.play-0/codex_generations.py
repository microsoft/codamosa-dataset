

# Generated at 2022-06-25 05:24:33.388527
# Unit test for constructor of class Play
def test_Play():
    print('<=== Test case 0 ==>')
    test_case_0()

if __name__ == '__main__':
    test_Play()

# Generated at 2022-06-25 05:24:44.030390
# Unit test for method get_name of class Play
def test_Play_get_name():
    print('')
    print('###############################################################################')
    print('Test Play method get_name')
    print('###############################################################################')
    if True:
        print('Test 1 : Calling get_name method with play containing valid "hosts" parameter')
        print('-----------------------------------------------------------------------------')
        try:
            play_1 = Play()
            play_1.hosts = 'myhosts'
            name = play_1.get_name()
            if name == 'myhosts':
                print('Test result: PASS')
            else:
                print('Test result: FAIL')
        except Exception as e:
            print('Test result: FAIL')
            print(e)
    if True:
        print('Test 2 : Calling get_name method with play containing invalid "hosts" parameter')
        print('-----------------------------------------------------------------------------')


# Generated at 2022-06-25 05:24:45.157984
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds_0 = {}
    play_0.preprocess_data(ds_0)



# Generated at 2022-06-25 05:24:53.605240
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    list_0 = play_0.get_vars_files()
    assert list_0 == []

    play_0.vars_files = []
    list_0 = play_0.get_vars_files()
    assert list_0 == []

    play_0.vars_files = None
    list_0 = play_0.get_vars_files()
    assert list_0 == []

    play_0.vars_files = "filename"
    list_0 = play_0.get_vars_files()
    assert list_0 == ["filename"]

    play_0.vars_files = ["filename", "another_filename"]
    list_0 = play_0.get_vars_files()
    assert list_0 == ["filename", "another_filename"]



# Generated at 2022-06-25 05:24:58.904874
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds = dict()
    result = play_0.preprocess_data(ds)
    assert type(result) == dict



# Generated at 2022-06-25 05:25:01.577395
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    # test cases
    if (play_0.get_name() == ''):
        pass
    else:
        raise Exception('Failed to reproduce expected behavior')


# Generated at 2022-06-25 05:25:13.053342
# Unit test for method preprocess_data of class Play

# Generated at 2022-06-25 05:25:18.217455
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = 'test_file'
    assert play.get_vars_files() == ['test_file']

    play = Play()
    play.vars_files = ['test_file_0', 'test_file_1']
    assert play.get_vars_files() == ['test_file_0', 'test_file_1']

    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []


# Generated at 2022-06-25 05:25:25.181178
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    class_name = "Ansible Playbook Play"
    try:
        play_0.preprocess_data({"hosts": "localhost", "roles": {}, "tasks": []})
    except Exception as exc:
        assert False, 'test_Play_preprocess_data for {class_name} raised exception "{error!s}"'.format(class_name=class_name, error=exc)
    else:
        assert True


# Generated at 2022-06-25 05:25:35.618859
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    # test with empty roles
    assert play_1.compile_roles_handlers() == []
    # test with roles with no handlers
    test_role_1 = Role()
    test_role_2 = Role()
    play_1.roles.append(test_role_1)
    play_1.roles.append(test_role_2)
    assert play_1.compile_roles_handlers() == []

    # test with roles with handlers
    test_block_1 = Block()
    test_block_2 = Block()
    handler_1 = Handler()
    handler_2 = Handler()
    test_block_1.rescue.append(handler_1)
    test_block_2.always.append(handler_2)
    test_role_3 = Role

# Generated at 2022-06-25 05:25:57.903781
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_1 = Play()
    play_0.ROLE_CACHE={}
    play_1.ROLE_CACHE={}
    play_1.ROLE_CACHE={}
    play_0.get_roles=MagicMock()
    play_0.get_roles.return_value=[play_0]
    play_0.get_handler_blocks=MagicMock()
    play_0.get_handler_blocks.return_value=[""]
    result = play_0.compile_roles_handlers()
    play_0.get_roles.assert_called_once_with()
    play_0.get_handler_blocks.assert_called_once_with(play=play_0)


test_cases_test_Play_compile

# Generated at 2022-06-25 05:26:06.115404
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])

# Generated at 2022-06-25 05:26:06.697184
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()


# Generated at 2022-06-25 05:26:09.496257
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test case 0
    # Testing a concrete case of Play instantiation
    print("Testing case 0:")
    print(" Instantiate a Play object using a concrete case")

    play_0 = Play()
    play_0.name = "cisco"
    play_0.hosts = "all"
    print(play_0.get_name())


# Generated at 2022-06-25 05:26:11.240581
# Unit test for method get_name of class Play
def test_Play_get_name():

    play_obj = Play()
    play_obj.name = "ping"
    assert play_obj.get_name() == "ping"


# Generated at 2022-06-25 05:26:12.874218
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    res = play_0.compile_roles_handlers()
    assert res == []


# Generated at 2022-06-25 05:26:15.888977
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_get_tasks_0 = Play()
    test_case_0()
    test_case_1()
    test_case_2()

    tasks_0 = play_get_tasks_0.get_tasks()
    assert tasks_0 == []


# Generated at 2022-06-25 05:26:23.377587
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    data_1 = dict(hosts='myhost.example.com', user='username', tasks=[dict(action=dict(module='shell', args='/bin/echo hello'))])
    data_1_result = dict(hosts='myhost.example.com', remote_user='username', tasks=[dict(action=dict(module='shell', args='/bin/echo hello'))])
    play_1._ds = data_1
    play_1.preprocess_data(data_1)
    assert play_1._ds == data_1
    play_1.preprocess_data(data_1)
    assert play_1._ds == data_1_result


# Generated at 2022-06-25 05:26:30.282768
# Unit test for method get_name of class Play
def test_Play_get_name():

    # Setup
    play_0 = Play()
    get_name_str = ''

    # Exercise
    try:
        get_name_str = play_0.get_name()
    except:
        assert False
        return

    # Verify
    assert get_name_str == ''

    return


# Generated at 2022-06-25 05:26:38.773767
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.deserialize(data={'tasks': [{'hosts': {'_host': '127.0.0.1', '_raw_params': '127.0.0.1', '_raw_name': '127.0.0.1'}, 'vars': {}, 'action': 'shell', 'args': {'_raw_params': 'whoami', '_raw_name': 'whoami'}}]})

# Generated at 2022-06-25 05:26:55.839866
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.roles = [Role(), Role()]
    play_0.roles[0].handlers = [Handler(), Handler(), Handler()]
    play_0.roles[1].handlers = [Handler(), Handler()]
    actual = play_0.compile_roles_handlers()
    expected = [Handler(), Handler(), Handler(), Handler(), Handler()]
    assert(actual == expected) 


# Generated at 2022-06-25 05:27:00.693443
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='/dev/null')

    play_source =  dict(
        name = "Ansible Play 0"
        )

    play_DS = play_source
    play_DS = Play.load(play_DS, variable_manager, loader, play_DS.get('vars'))
    play_DS = Play.load(play_DS, variable_manager, loader)

   

# Generated at 2022-06-25 05:27:07.985980
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    print("Test: get_vars_files()")
    print("type(play_0) = ", type(play_0))
    print("play_0.vars_files = ", play_0.vars_files)
    print("play_0.get_vars_files() = ", play_0.get_vars_files())


# Generated at 2022-06-25 05:27:11.769790
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    block = Block()
    task = Task()
    block.block = [task]
    play.pre_tasks = [block]
    play.tasks = [block]
    play.post_tasks = [block]

    assert play.get_tasks() == [task, task, task]


# Generated at 2022-06-25 05:27:23.061008
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_1 = Play()
    play_0.roles.extend([
        play_1._ROLE_DATA_SKELETON(
            name='role1',
            tasks=[
                # Set of tasks from this role
                {
                    'block': [],
                }
            ]
        )
    ])
    play_1.roles.extend([
        play_1._ROLE_DATA_SKELETON(
            name='role2',
            tasks=[
                # Set of tasks from this role
                {
                    'block': [],
                }
            ]
        )
    ])

    handlers = play_0.compile_roles_handlers()

# Generated at 2022-06-25 05:27:28.846126
# Unit test for method serialize of class Play
def test_Play_serialize():
    print("Begin Testing")
    play_1 = Play()
    play_1.post_validate(templar=None)
    print(play_1.serialize())
    print("Done Testing")


# Generated at 2022-06-25 05:27:35.152153
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''
    Test the method Play.get_name of class Play
    '''

    print('Method get_name of class Play :')

    play_0 = Play()
    print(play_0.get_name())

    play_0.name = 'name'
    play_0.hosts = 'localhost,'
    print(play_0.get_name())

    play_0.name = 'name'
    play_0.hosts = 'localhost,127.0.0.1'
    print(play_0.get_name())

    play_0.name = 'name'
    play_0.hosts = None
    print(play_0.get_name())


# Generated at 2022-06-25 05:27:39.781542
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p_handlers = []
    if len(p.roles) > 0:
        for r in p.roles:
            if r.from_include:
                continue
            p_handlers.extend(r.get_handler_blocks(play=p))
    assert p_handlers == p.compile_roles_handlers()


# Generated at 2022-06-25 05:27:49.278075
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print("\n===== test_get_vars_files ===========")
    play_0 = Play()
    #play_1 = Play()
    #play_1.vars_files = []
    #play_2 = Play()
    #play_2.vars_files = "D:\Pass\Playbook\test-get_vars_files.yml"
    #print("\nTesting play_0:\n")
    #print(play_0.get_vars_files())
    #print("\nTesting play_1:\n")
    #print(play_1.get_vars_files())
    #print("\nTesting play_2:\n")
    #print(play_2.get_vars_files())



# Generated at 2022-06-25 05:27:57.686567
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_2 = Play()
    play_3 = Play()
    play_3.name = 'play_3'
    if play_1.get_name() != 'play_1' or play_2.get_name() != 'play_2' or play_3.get_name() != 'play_3':
        raise AnsibleAssertionError(
            'Failed to get the play name, play_1.get_name() is ' + play_1.get_name() + ', play_2.get_name() is ' + play_2.get_name() + ' and play_3.get_name() is ' + play_3.get_name())


# Generated at 2022-06-25 05:28:38.825147
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data_0 = play_0.serialize()
    play_0.deserialize(data_0)
    # task 9 assertions
    assert("name" in data_0)
    assert("name" not in play_0)

    # task 10 assertions
    assert("tags" in data_0)
    assert("tags" not in play_0)

    # task 11 assertions
    assert("when" in data_0)
    assert("when" not in play_0)

    # task 12 assertions
    assert("hosts" in data_0)
    assert("hosts" not in play_0)

    # task 13 assertions
    assert("roles" in data_0)
    assert("roles" not in play_0)

    # task 15 assertions

# Generated at 2022-06-25 05:28:48.806663
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.name = 'test_play_name'
    play_1.hosts = 'test_play_hosts'
    play_1.remote_user = 'test_play_remote_user'
    play_1.connection = 'test_play_connection'
    play_1.any_errors_fatal = True
    play_1.max_fail_percentage = 42
    play_1.gather_facts = 'test_play_gather_facts'
    play_1.serial = 42
    play_1.vars_files = 'test_play_vars_files'
    play_1.vars_prompt = 'test_play_vars_prompt'
    play_1.vars = 'test_play_vars'
    play_1.tags

# Generated at 2022-06-25 05:28:57.702623
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.tasks.append("t1")
    play_1.post_tasks.append("t2")
    play_1.pre_tasks.append("t3")
    play_1.handler_blocks.append("h1")

    result = play_1.get_tasks()
    assert_equals(result, ["t3", "t1", "t2"])



# Generated at 2022-06-25 05:28:59.259005
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    assert "hosts" in play_1.serialize()


# Generated at 2022-06-25 05:29:03.091121
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = ['test/test_get_vars_files/expected_value']
    expected_value = [os.path.abspath('test/test_get_vars_files/expected_value')]
    actual_value = play_0.get_vars_files()
    assert actual_value == expected_value


# Generated at 2022-06-25 05:29:09.306496
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = get_test_play(test_case_0)
    name = play_0.get_name()
    print(name)


# Generated at 2022-06-25 05:29:14.105445
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    logger.info("=======================================================")
    logger.info("testing Play deserialize method")
    logger.info("=======================================================")
    play = Play()
    play.deserialize(play_0_data)
    logger.info(play)
    logger.info("equals play_0_data: %s" % play.__dict__ == play_0_data)
    assert play.__dict__ == play_0_data


# Generated at 2022-06-25 05:29:20.283084
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    block_list = []
    create_role_1 = Role()
    create_role_2 = Role()
    create_block_1 = Block()
    create_block_2 = Block()
    create_role_1.blocks = [create_block_1]
    create_role_2.blocks = [create_block_2]
    play_1.roles = [create_role_1, create_role_2]
    block_list.extend(create_role_1.blocks)
    block_list.extend(create_role_2.blocks)
    # Check value of method compile_roles_handlers
    assert play_1.compile_roles_handlers() == block_list


# Generated at 2022-06-25 05:29:26.538141
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = dict(
        name="test play",
        hosts=["localhost"],
        gather_facts=True,
        gather_subset=[],
        roles=[dict(
            name="test role",
            tags=["role tag"],
            remote_user="test user",
            become=True,
            become_method="sudo",
            become_user="root",
            become_ask_pass=True)],
        tasks=[dict(
            name="test task",
            action=dict(
                module="foo",
                args=dict(),
                k1='v1'),
            async_val=5,
            poll=5)])


# Generated at 2022-06-25 05:29:33.517093
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.pre_tasks = [ Task() ]
    play_1.tasks = [ Block(block= [ Task() ]) ]
    play_1.post_tasks = [ Task() ]
    assert( len(play_1.get_tasks()) == 5 )


# Generated at 2022-06-25 05:30:02.587529
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print("\nTest case 0: Play()")
    print("\nTesting Play.get_tasks()")
    play_0 = Play()
    print(play_0.get_tasks())    

if __name__ == '__main__':
    print('\nTest #0: Play')
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping

    test_case_0()
    test_Play_get_tasks()

# Generated at 2022-06-25 05:30:07.165161
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = "play_name"
    assert play_1.get_name() == 'play_name'

    play_2 = Play()
    play_2.hosts = ["all"]
    assert play_2.get_name() == 'all'

    play_3 = Play()
    play_3.hosts = ["local"]
    assert play_3.get_name() == 'local'


# Generated at 2022-06-25 05:30:08.517155
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    assert play_0.compile_roles_handlers() is None


# Generated at 2022-06-25 05:30:14.823630
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    try:
        play_0.get_tasks()
    except InvalidVariableError:
        print('InvalidVariableError raised')
    except Exception as e:
        print(str(e))


test_case_0()
test_Play_get_tasks()

# Generated at 2022-06-25 05:30:17.959283
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.vars_files = [
        {
            "path": "./common.yaml",
            "name": "vars_files"
        }
    ]
    play_0.serialize()



# Generated at 2022-06-25 05:30:20.588292
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    handler_list = play_0._compile_roles()

    # Test no blocks are missing
    assert len(handler_list) > 0

    # Test no blocks are missing
    for block in handler_list:
        print(block)



# Generated at 2022-06-25 05:30:31.472007
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    d = dict(
        connection = dict(
            param = dict(
                one = 1,
                two = 2,
            ),
        ),
        name = 'myplay',
        gather_facts = 'smart',
        inventory = dict(
            hostnames = ['brown', 'blue'],
        ),
        hosts = ['red'],
        remote_user = 'jupiter',
        pre_tasks = 'mypretasks',
        post_tasks = 'myposttasks',
        roles = dict(
            role_name = dict(
                role_params = dict(
                    role_one_param = 'role_one_param',
                ),
            ),
        ),
        tasks = 'mytasks',
        handlers = 'myhandlers',
    )

    play_0.deserial

# Generated at 2022-06-25 05:30:34.581069
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks = list()
    tasks = play_0.get_tasks()
    assert tasks == list()


# Generated at 2022-06-25 05:30:41.633367
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # testing case 0
    play_0 = Play()
    play_0.pre_tasks = []
    play_0.tasks = []
    play_0.post_tasks = []
    assert play_0.get_tasks() == []

    # testing case 1
    play_1 = Play()
    play_1.pre_tasks = []
    play_1.tasks = []
    play_1.post_tasks = []
    assert play_1.get_tasks() == []

    # testing case 2
    play_2 = Play()
    play_2.pre_tasks = None
    play_2.tasks = None
    play_2.post_tasks = None
    assert play_2.get_tasks() == []

    # testing case 3
    play_3 = Play()

# Generated at 2022-06-25 05:30:51.086933
# Unit test for method serialize of class Play

# Generated at 2022-06-25 05:31:36.346534
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    # Testing the importation of a dictionary
    play_1.__dict__ = {'name': 'simple_play', 'hosts': 'all', 'vars': {}, 'vars_files': [], 'roles': []}
    assert play_1.serialize() == {
        'name': u'simple_play',
        'included_path': None,
        'action_groups': {},
        'group_actions': {},
        'roles': []
    }
    print("Test unit for 'serialize' done")


# Generated at 2022-06-25 05:31:46.898833
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play with one role and one handler
    play = Play()
    play.name = "Test Play"
    role = Role()
    role.name = "Test Role"
    
    handler = Handler()
    handler.name = "Test Handler"
    handler.task = Task()
    
    role.tasks = [handler.task]
    role.handlers = [handler]
    play.roles = [role]
    
    # Call method under test
    handlers = play.compile_roles_handlers()
    
    assert len(handlers) == 1
    assert handlers[0].name == handler.name


# Generated at 2022-06-25 05:31:51.007235
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-25 05:31:56.179548
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()

    ds = None
    try:
        play_0.preprocess_data(ds)
    except (AnsibleAssertionError):
        pass
    else:
        # should have raised Exception
        raise Exception('Expected Exception')


# Generated at 2022-06-25 05:32:03.792300
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks = [play_0.copy()]
    play_1 = Play()
    play_1.roles = [play_0]
    play_2 = Play()
    play_2.tasks = [play_1]
    res = play_2.get_tasks()
    assert res[0].tasks == [play_0]

test_case_0()
test_Play_get_tasks()

# Generated at 2022-06-25 05:32:14.280624
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasklist = play_0.get_tasks()

    assert len(tasklist) == 6
    assert isinstance(tasklist[0], Block)
    assert isinstance(tasklist[1], Block)
    assert isinstance(tasklist[2], Block)
    assert isinstance(tasklist[3], Block)
    assert isinstance(tasklist[4], Block)
    assert isinstance(tasklist[5], Block)

    assert len(tasklist[0].block) == 1
    assert len(tasklist[1].block) == 1
    assert len(tasklist[2].block) == 1
    assert len(tasklist[3].block) == 1
    assert len(tasklist[4].block) == 1
    assert len(tasklist[5].block) == 1


# Generated at 2022-06-25 05:32:18.969681
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Instantiating an object of type Play
    play_0 = Play()
    # Calling the method get_name of play_0
    # <class 'ansible.parsing.yaml.objects.AnsibleUnicode'>
    assert_equal(isinstance(play_0.get_name(), unicode), True)


# Generated at 2022-06-25 05:32:22.777334
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()

    # create a fake list of blocks
    handler_block_list = [Block(), Block(), Block()]

    # Call compile_roles_handlers
    play.roles.append(lambda: handler_block_list)

    # compare with reference
    assert(play.compile_roles_handlers() == handler_block_list)


# Generated at 2022-06-25 05:32:31.083782
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_2 = Play()
    Play_compile_roles_handlers_result_1 = play_1.compile_roles_handlers()
    Play_compile_roles_handlers_result_2 = play_2.compile_roles_handlers()
    assert(Play_compile_roles_handlers_result_1 == [])
    assert(Play_compile_roles_handlers_result_2 == [])



# Generated at 2022-06-25 05:32:32.000655
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()


# Generated at 2022-06-25 05:33:41.622199
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    try:
        play_0.get_name()
    except Exception as exc:
        errors_collected.append(str(exc))


# Generated at 2022-06-25 05:33:47.066649
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Set up the ansible.playbook.play.Play object
    play_0 = Play()
    play_0.ROLE_CACHE = {}
    play_0.ROLE_CACHE['roles'] = {}
    play_0.ROLE_CACHE['roles']['path'] = {}
    play_0.ROLE_CACHE['roles']['path']['/etc/ansible/roles'] = True
    play_0.ROLE_CACHE['roles']['path']['/etc/ansible/roles'] = True

    # Set up the ansible.playbook.role.RoleInclude object
    role_include_0 = RoleInclude()
    role_include_0.name = 'roles/role.yml'
    role_include_0.role

# Generated at 2022-06-25 05:33:53.027375
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_1 = Play()
    play_1._load_data({'name': 'some_play'})
    play_2 = Play()
    play_2._load_data({'hosts': 'some_hosts'})

    assert play_0.get_name() == ''
    assert play_1.get_name() == 'some_play'
    assert play_2.get_name() == 'some_hosts'


# Generated at 2022-06-25 05:33:56.226806
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()

    # Verify that we obtain the correct name
    assert play_0.get_name() == None


# Generated at 2022-06-25 05:34:03.394371
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    play_0 = Play()
    # The basic test case
    result = play_0.compile_roles_handlers()
    assert len(result) == 0

    # The test case with single role in the play
    play_1 = Play()
    role_include_0 = RoleInclude()
    handler_block_0 = Block()
    block_task_0 = BlockTask()
    handler_0 = Handler()
    role_include_0.name = 'role_include_0'
    role_include_0._role = role_include_0.name
    role_include_0.play = play_1
    role_0 = Role()
    role_0.name = 'role_0'
    role_0.play = play_1
    role_0.tasks = []