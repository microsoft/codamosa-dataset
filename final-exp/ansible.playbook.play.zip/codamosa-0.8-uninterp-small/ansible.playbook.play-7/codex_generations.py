

# Generated at 2022-06-25 05:24:45.421726
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    vars_files_0 = play_0.get_vars_files()
    assert vars_files_0 == []


# Generated at 2022-06-25 05:24:47.603278
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    for play_data in PLAY_DATA_LIST:
        play_1 = Play()
        play_1.deserialize(play_data)

# Generated at 2022-06-25 05:24:55.419309
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_d = Play()
    play_d.deserialize({
        '_ordered_tasks':[{
            '_uuid':uuid4()
        }],
        'roles':[{
            'role_file':'origin_role_file'
        }]
    })
    assert(play_d.roles[0].role_file == 'origin_role_file')

# Generated at 2022-06-25 05:24:57.852758
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Need to be included
    try:
        pass
    except Exception as e:
            print(e)
    else:
        print('No exception')


# Generated at 2022-06-25 05:24:59.195315
# Unit test for method serialize of class Play
def test_Play_serialize():
   # test_case_0
   play_0 = Play()
   play_0.serialize()


# Generated at 2022-06-25 05:25:04.147207
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    results = play_0.compile_roles_handlers()
    assert results == []


# Generated at 2022-06-25 05:25:16.182209
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    play_ds = {
        'name': 'test',
        'hosts': 'all',
        'roles': [
            { 'name': 'role_without_meta',
            },
        ],
        'tasks': [
            {'local_action': {'module': 'debug', 'msg': 'debug message'}},
            {'include': 'role_without_meta/tasks/main.yml'},
            {'local_action': {'module': 'debug', 'msg': 'debug task 2'}},
            {'include': 'role_without_meta/tasks/main.yml'},
            {'local_action': {'module': 'debug', 'msg': 'debug task 3'}}
        ]
    }

# Generated at 2022-06-25 05:25:18.129174
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    try:
        play_0.preprocess_data(ds=None)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:25:24.522111
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data_deserialize={'hosts': 'all', 'name': 'test_play', 'defaults': {'gather_facts': 'yes'}, 'vars': {'var1': 1}, 'tasks': []}
    play = Play()
    play.deserialize(data_deserialize)
    assert play.hosts is 'all'


# Generated at 2022-06-25 05:25:29.903185
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    if play_0.get_name() == "":
        print('test_Play_get_name ok')
    else:
        print('test_Play_get_name NG')


# Generated at 2022-06-25 05:25:43.284999
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    result = play_0.get_tasks()

# Generated at 2022-06-25 05:25:45.424308
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''
    play.name = 'test_play'
    assert play.get_name() == 'test_play'

# Generated at 2022-06-25 05:25:51.255060
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_Play_get_tasks_obj = Play()
    assert test_Play_get_tasks_obj.get_tasks() == [], """test_Play_get_tasks: Assertion failed on assert test_Play_get_tasks_obj.get_tasks() == []"""


# Generated at 2022-06-25 05:25:53.878915
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data = dict(
        name='test', # String. Name of the playbook
        hosts='all', # Host pattern to apply playbook to
        gather_facts='yes', # Gather facts from the playbook
        remote_user='root', # User to execute play with
        tasks=[] # List of tasks to execute
    )
    play_0.deserialize(data)


# Generated at 2022-06-25 05:25:57.213956
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "test1"
    result = play_0.get_name()
    assert result == "test1"


# Generated at 2022-06-25 05:26:02.173457
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_obj = Play()

    play_obj2 = Play()
    play_obj2.deserialize(play_obj.serialize())



# Generated at 2022-06-25 05:26:08.427236
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks.append('play_0_tasks_0')
    play_0.tasks.append('play_0_tasks_1')
    play_0.tasks.append('play_0_tasks_2')
    tasks_0 = play_0.get_tasks()
    assert(tasks_0 == ['play_0_tasks_0', 'play_0_tasks_1', 'play_0_tasks_2'])


# Generated at 2022-06-25 05:26:14.236914
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    ds_1 = {u'hosts': [u'all'], u'tasks': [{u'name': u'uname is Linux', u'assert': {u'fail_msg': u'Linux is not in the OS name {{ ansible_os_family }}', u'check': u'Linux in ansible_os_family', u'success_msg': u'OS is Linux'}}]}
    # provided argument 'ds' of type 'dict' (i.e. {u'hosts': [u'all'], u'tasks': [{u'name': u'uname is Linux', u'assert': {u'fail_msg': u'Linux is not in the OS name {{ ansible_os_family }}', u'check': u'Linux in ansible_os_family', u'success_msg

# Generated at 2022-06-25 05:26:19.275422
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    vars_files_0 = play_0.get_vars_files()
    assert vars_files_0 == []


# Generated at 2022-06-25 05:26:20.746842
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    name_0 = play_0.get_name()


# Generated at 2022-06-25 05:26:35.728435
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = "Ansible Playbook"
    assert play_1.name == "Ansible Playbook"
    assert play_1.get_name() == "Ansible Playbook"


# Generated at 2022-06-25 05:26:38.523923
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    assert play_1.compile_roles_handlers() is None

if __name__ == '__main__':
    test_case_0()
    test_Play_compile_roles_handlers()
    print('Test Play done successfully')

# Generated at 2022-06-25 05:26:40.215093
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create Play object
    play_1 = Play()

    # Execute compile_roles_handlers()
    play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:26:43.410453
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_object = Play()
    play_object.roles = [1,2,3]
    x = play_object.compile_roles_handlers()
    assert type(x) == list
    assert len(x) == 0


# Generated at 2022-06-25 05:26:53.669464
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # test: empty role list
    play_1 = Play()
    play_1.roles = []
    assert(play_1.compile_roles_handlers() == [])

    # test: non empty role list
    play_2 = Play()
    play_2.roles = [Role()]
    assert(play_2.compile_roles_handlers() == [])

    # test: non empty role list with handlers
    play_3 = Play()
    play_4 = Role()
    play_4.handlers = [Handler()]
    play_3.roles = [play_4]
    assert(play_3.compile_roles_handlers() == [])

if __name__ == "__main__":
    test_case_0()
    test_Play_compile_ro

# Generated at 2022-06-25 05:27:02.962413
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()

    assert play_1.preprocess_data(None) == None
    assert play_1.preprocess_data('') == ''
    assert play_1.preprocess_data('abc') == 'abc'
    assert play_1.preprocess_data(['abc', 1, 'def']) == ['abc', 1, 'def']
    assert play_1.preprocess_data({'a':'b', 1:'c'}) == {'a':'b', 1:'c'}
    assert play_1.preprocess_data(['a', 'b', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-25 05:27:04.516456
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.get_vars_files() == []


# Generated at 2022-06-25 05:27:10.623303
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play1 = Play()
    play1.vars_files = None
    assert play1.get_vars_files() == []

    play2 = Play()
    play2.vars_files = "test.yml"
    assert play2.get_vars_files() == ["test.yml"]

    play3 = Play()
    play3.vars_files = ["test1.yml", "test2.yml"]
    assert play3.get_vars_files() == ["test1.yml", "test2.yml"]

# Generated at 2022-06-25 05:27:11.961841
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    dict_0 = play_0.serialize()


# Generated at 2022-06-25 05:27:18.347682
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    print("testing Play.compile_roles_handlers()")
    play_1 = Play()
    play_2 = Play()
    assert play_1.compile_roles_handlers() == play_2.compile_roles_handlers()


# Generated at 2022-06-25 05:27:33.020017
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()

    # Test with proper value
    #play_0.vars_files = 'hello'
    #expected_value = play_0.get_vars_files()
    #print(expected_value)
    #assert expected_value == 'hello'
    pass


# Generated at 2022-06-25 05:27:40.397290
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    # This test assumes that the return value on an uninitialized Play object
    # is an empty string
    assert play_0.get_name() == ''
    play_0.name = 'test'
    # This test assumes that the name property is returned
    assert play_0.get_name() == 'test'
    play_0.hosts = 'test'
    # This test assumes that the hosts property is returned
    assert play_0.get_name() == 'test'


# Generated at 2022-06-25 05:27:49.890183
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()

# Generated at 2022-06-25 05:27:54.891792
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

    play_1.tasks = [Task()]
    play_1.pre_tasks = [Task()]
    play_1.post_tasks = [Task()]

    assert play_1.get_tasks() == play_1.pre_tasks + play_1.tasks + play_1.post_tasks


# Generated at 2022-06-25 05:28:03.699762
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # Create a play
    play = Play()

    # Create some dictionaries with bad/good data to test the method
    dict_1 = "string"
    dict_2 = 10
    dict_3 = [1,2,3,4,5]
    dict_4 = {'key':'value'}

    # Test with good data
    try:
        play.preprocess_data(dict_4)
    except Exception as e:
        # Fail
        assert False

    # Test with bad data
    try:
        play.preprocess_data(dict_3)
        # Fail
        assert False
    except:
        pass

    try:
        play.preprocess_data(dict_2)
        # Fail
        assert False
    except:
        pass


# Generated at 2022-06-25 05:28:05.309883
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasklist = play_0.get_tasks()
    assert(tasklist is not None)



# Generated at 2022-06-25 05:28:12.625116
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()

# Generated at 2022-06-25 05:28:17.797507
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    temp_ans = play_0.get_name()
    print("Play.get_name() returns:")
    print(temp_ans)


# Generated at 2022-06-25 05:28:25.786806
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    test on Play class
    '''

    play_0 = Play()
    play_0._ds = {'name': 'test_play', 'hosts': '127.0.0.1', 'tasks': [{'name': 'task_0'}, {'name': 'task-1'}]}
    play_0.post_validate(play_0._ds, play_0)
    play_0.load_data(play_0._ds)
    play_0.ROLE_CACHE = {'role_name':'test_role'}
    play_0._included_conditional = 'test_condition'
    play_0._included_path = 'test_path'
    play_0._action_groups = {'test_action':'test_action'}
    play_0

# Generated at 2022-06-25 05:28:35.094756
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Declare play
    play_1 = Play()

    # Declare role
    role_0 = Role()
    role_0.name = 'test_name'
    role_0.default_vars = {"test_key": "test_value"}
    role_0.tasks = [{'meta': 'flush_handlers'}]
    role_0.handlers = [{'meta': 'flush_handlers'}]

    # Add role to play
    play_1.roles.append(role_0)

    assert(play_1.compile_roles_handlers() == [{'meta': 'flush_handlers'}])


# Generated at 2022-06-25 05:28:54.213608
# Unit test for method serialize of class Play
def test_Play_serialize():
    print("Testing serialize() in class Play")
    pass_0 = None
    try:
        play_0 = Play()
        pass_0 = True
        print("Passed: Play()")
    except Exception as error_0:
        print(error_0)
        pass_0 = False
        print("Failed: Play()")
    pass_1 = None
    try:
        result_1 = play_0.serialize()
        pass_1 = True
        print("Passed: play_0.serialize()")
    except Exception as error_1:
        print(error_1)
        pass_1 = False
        print("Failed: play_0.serialize()")
    if pass_0 and pass_1:
        print("Passed: All tests for serialize()")

# Generated at 2022-06-25 05:29:04.366922
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

# Generated at 2022-06-25 05:29:05.582909
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    print(play_0.get_name())


# Generated at 2022-06-25 05:29:11.946103
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # No errors when loading data with user
    play_1 = Play()
    play_1.load_data({"user": "user_1"})
    assert play_1.remote_user == "user_1"

    # Error when loading data with user and remote_user
    try:
        play_2 = Play()
        play_2.load_data({"user": "user_1", "remote_user": "user_2"})
        assert False, "Should raise"
    except AnsibleParserError as exception:
        assert 'both \'user\' and \'remote_user\' are set' in exception.message

    # Error when loading data with no user

# Generated at 2022-06-25 05:29:17.473456
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    try:
        play_0.preprocess_data("play_0")
    except AnsibleAssertionError:
        pass
    else:
        assert False, "AnsibleAssertionError not raised"


# Generated at 2022-06-25 05:29:20.582514
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    try:
        play_1 = Play()
        assert type(play_1.get_vars_files()) is list
        print("test_Play_get_vars_files: OK\n")
    except:
        print("test_Play_get_vars_files: FAILED\n")


# Generated at 2022-06-25 05:29:26.772752
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Create test instance of class Play and verify that all default
    # attribute values are as expected
    play_1 = Play()
    print('\nPlay class instance created with values:')
    print('  name             = {0}'.format(play_1.get_name()))
    print('  strategy         = {0}'.format(play_1.strategy))
    print('  remote_user      = {0}'.format(play_1.remote_user))
    print('  become           = {0}'.format(play_1.become))
    print('  become_method    = {0}'.format(play_1.become_method))
    print('  become_user      = {0}'.format(play_1.become_user))

# Generated at 2022-06-25 05:29:34.509279
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [Role(name='test_role', tasks='test_tasks')]
    assert play.compile_roles_handlers() == []
    play.roles[0]._handlers = [Handler(name='test_task', _play=play)]
    assert play.compile_roles_handlers() == [play.roles[0]._handlers[0]]

# Generated at 2022-06-25 05:29:43.333983
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
  # Test data for get_vars_files
  play_1 = Play()
  play_1.vars_files = None
  # Expected result for test case 1
  expected_result_1 = []
  # Check result for test case 1
  assert expected_result_1 == play_1.get_vars_files()
  # Test data for get_vars_files
  play_2 = Play()
  play_2.vars_files = '/etc/ansible/playbook.yaml'
  # Expected result for test case 2
  expected_result_2 = ['/etc/ansible/playbook.yaml']
  # Check result for test case 2
  assert expected_result_2 == play_2.get_vars_files()
  # Test data for get_vars_files
  play_3

# Generated at 2022-06-25 05:29:45.604209
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    with pytest.raises(AnsibleAssertionError):
        play_0.preprocess_data(None)


# Generated at 2022-06-25 05:29:59.918591
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_1 = Play()
    play_1.serialize()


# Generated at 2022-06-25 05:30:03.536273
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    result_0 = play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:30:09.229920
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    first_vars_files_list = ['ansible.cfg', 'playbooks/ansible.cfg']

    play_0 = Play()
    play_0.vars_files = first_vars_files_list

    empty_list = []
    not_list = 'ansible.cfg'

    ###
    assert play_0.get_vars_files() == first_vars_files_list
    assert Play().get_vars_files() == empty_list
    assert Play(vars_files=not_list).get_vars_files() == empty_list


# Generated at 2022-06-25 05:30:15.387837
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_1 = Play(vars_files='test_vars_files')
    play_2 = Play(vars_files=['vars_files_0', 'vars_files_1'])

    assert play_0.get_vars_files() == []
    assert play_1.get_vars_files() == ['test_vars_files']
    assert play_2.get_vars_files() == ['vars_files_0', 'vars_files_1']


# Generated at 2022-06-25 05:30:22.366771
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = None
    get_vars_files_0 = play_0.get_vars_files()
    assert get_vars_files_0 == []
    play_0.vars_files = None
    get_vars_files_1 = play_0.get_vars_files()
    assert get_vars_files_1 == []
    play_0.vars_files = None
    get_vars_files_2 = play_0.get_vars_files()
    assert get_vars_files_2 == []
    play_0.vars_files = None
    get_vars_files_3 = play_0.get_vars_files()
    assert get_vars_files_3 == []
    play_

# Generated at 2022-06-25 05:30:23.678904
# Unit test for method get_name of class Play
def test_Play_get_name():
    play1 = Play()
    play1.name = 'name'
    assert play1.get_name() == 'name'


# Generated at 2022-06-25 05:30:32.401282
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    # set up basic vars
    play_data = dict(
        name = 'test',
        connection = 'local',
        hosts = 'all',
        gather_facts = True,
        roles = [],
        tasks = [],
    )
    play_data['roles'].append({
        'role': 'test',
    })
    play_data['roles'].append({
        'name': 'test',
        'role': 'test',
        'internal': True,
        'tags': ['a', 'b'],
    })
    play_data['roles'].append({
        'name': 'test',
        'role': 'test',
        'internal': True,
        'vars': {
            'a': 'a',
            'b': 'b',
        },
    })

    #

# Generated at 2022-06-25 05:30:35.508281
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasks_0 = play_0.get_tasks()

    # Matcher to evaluate that the returned list is not empty
    assert len(tasks_0) != 0


# Generated at 2022-06-25 05:30:38.115891
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    test_result = play_0.compile_roles_handlers()
    assert test_result == []


# Generated at 2022-06-25 05:30:39.103066
# Unit test for constructor of class Play
def test_Play():
    test_case_0()



# Generated at 2022-06-25 05:30:58.384264
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_tasks_vars

    # test input data
    # collects tasks from the play into tasklist
    # checks "ok" and "changed" for all the tasks
    # verifies the output of remote_addr and remote_user for all the tasks

# Generated at 2022-06-25 05:30:59.703038
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()

# Generated at 2022-06-25 05:31:03.024715
# Unit test for constructor of class Play
def test_Play():
    try:
        test_case_0()
        print("Successfully executed test case: %s" % "Play")
    except Exception as exp:
        print("Exception caught while executing test case : %s" % "Play")
        print("Reason for exception : %s" % exp.message)
        print("Stack trace for exception : %s" % exp.message)
        raise

# Generated at 2022-06-25 05:31:13.555820
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    #try:
        # Create a Play instance
        play_0 = Play()

        # Create a YAML string
        yaml_str = """
        ---
        handlers: []
        post_tasks: []
        pre_tasks: []
        roles: []
        tasks:
          - ping: {}
        vars: {}
        vars_files: []
        """

        # Create a YAML object
        yaml_obj = yaml.safe_load(yaml_str)

        # Call method deserialize
        play_0.deserialize(yaml_obj)

        # AssertionError raised
    #except AssertionError as e:
        #print(e)
        #pass

# Generated at 2022-06-25 05:31:20.474816
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'dummy_name'
    assert play_1.get_name() == 'dummy_name'

    play_2 = Play()
    play_2.hosts = ['dummy_host']
    assert play_2.get_name() == ','.join(play_2.hosts)


# Generated at 2022-06-25 05:31:23.520401
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.post_validate(play_ds=[], var_options={})
    play_0.serialize()


# Generated at 2022-06-25 05:31:24.448213
# Unit test for constructor of class Play
def test_Play():
    play_0 = Play()


# Generated at 2022-06-25 05:31:26.529668
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    return_value = play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:31:33.830020
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'a test play'
    assert play_1.get_name() == 'a test play'

    play_2 = Play()
    play_2.hosts = 'somehosts'
    assert play_2.get_name() == 'somehosts'

    play_3 = Play()
    play_3.hosts = ['a', 'b']
    assert play_3.get_name() == 'a,b'


# Generated at 2022-06-25 05:31:35.838332
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    assert play_1.get_name() == ''
    

# Generated at 2022-06-25 05:31:59.069628
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create the play object
    play_1 = Play()
    # Create the tasks, pre_tasks and post_tasks objects and assign them to play_1
    task_1 = Task()
    task_2 = Task()
    task_3 = Task()
    pre_task_1 = Task()
    pre_task_2 = Task()
    pre_task_3 = Task()
    post_task_1 = Task()
    post_task_2 = Task()
    post_task_3 = Task()
    play_1.tasks = [task_1, task_2, task_3]
    play_1.pre_tasks = [pre_task_1, pre_task_2, pre_task_3]

# Generated at 2022-06-25 05:32:03.792538
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    with pytest.raises(AssertionError, match=r' *Invalid role declaration'):
        block_list_1 = play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:32:12.907110
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    testcases = [
        {
            'play'           : Play(),
            'expected-exit'  : None,
            'expected-value' : None,
        },
    ]

    for testcase in testcases:
        testname = testcase.get('testname', None)
        expected_exit = testcase.get('expected-exit', None)
        expected_value = testcase.get('expected-value', None)
        play = testcase.get('play', None)

        value = None
        try:
            # Invoke the method with the testcase's arguments
            value = play.compile_roles_handlers()
        except Exception as exception:
            if expected_exit == "exception":
                pass
            else:
                raise
        else:
            if expected_exit == "exception":
                assert False

# Generated at 2022-06-25 05:32:22.298801
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.handler
    import ansible.vars.manager
    import ansible.template

    run_cnt = 0
    def my_compile(self, play):
        assert self.name == u'role_name_0'
        assert isinstance(self, ansible.playbook.role.Role)
        assert self.tasks[0].name == u'name_0'
        assert self.tasks[0].action == u'shell'
        assert self.tasks[0].loop == []
        assert self.handlers[0].name == u'name_1'
        assert self.handlers[0].action == u'shell'
       

# Generated at 2022-06-25 05:32:26.405435
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'name': 'test_play'})
    assert play.name == 'test_play'


# Generated at 2022-06-25 05:32:28.798181
# Unit test for constructor of class Play
def test_Play():
    play_0 = Play()
    assert play_0.current_user == 'root'


# Generated at 2022-06-25 05:32:30.330918
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = ''
    assert play_0.get_name() == ''


# Generated at 2022-06-25 05:32:37.090865
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    # Create an instance of Play to test
    play_0 = Play()

    # set a value for vars_files so that it is not None
    play_0.vars_files = []

    # get the result of method get_vars_files()
    result = play_0.get_vars_files()

    # check if the value returned is a list
    assert isinstance(result, list)


# Generated at 2022-06-25 05:32:41.269676
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    
    play = Play()

    play.vars_files = '../../../test/test_vars_files.yml'
    vars_files = play.get_vars_files()
    print(vars_files)


# Generated at 2022-06-25 05:32:46.564075
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_1 = Play()
    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    task_3 = Task()
    task_4 = Task()
    task_5 = Task()
    task_6 = Task()
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()
    play_2 = Play()
    task_7 = Task()
    task_8 = Task()
    task_9 = Task()
    play_3 = Play()
    task_10 = Task()
    task_11 = Task()
    task_12 = Task()
    play_4 = Play()
    task_13 = Task()
    task_14 = Task()

# Generated at 2022-06-25 05:33:04.378595
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Setup
    play = Play()
    play.vars_files = "/etc/ansible/facts.d"

    # Exercise
    actual_result = play.get_vars_files()

    # Verify
    assert actual_result == ['/etc/ansible/facts.d']

# Generated at 2022-06-25 05:33:12.996641
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'test'
    assert play_1.get_name() == 'test', \
        "Play method get_name returns wrong value"
    play_2 = Play()
    play_2.name = 'test'
    del play_2.name
    play_2.hosts = '127.0.0.1'
    assert play_2.get_name() == '127.0.0.1', \
        "Play method get_name returns wrong value"
    play_3 = Play()
    play_3.name = 'test'
    del play_3.name
    play_3.hosts = ['127.0.0.1']

# Generated at 2022-06-25 05:33:16.596389
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    play_0.deserialize({'roles': 'roles'})



# Generated at 2022-06-25 05:33:19.874148
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'test_play'
    name = play_1.get_name()
    assert name == play_1.name


# Generated at 2022-06-25 05:33:25.489055
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    setattr(play_0, 'vars_files', {})
    assert play_0.get_vars_files() == [{}]


# Generated at 2022-06-25 05:33:29.993607
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()

    result_1 = play_1.compile_roles_handlers()
    assert result_1==[]


# Generated at 2022-06-25 05:33:38.445842
# Unit test for method serialize of class Play
def test_Play_serialize():
    # test case 1
    play_1 = Play()
    play_1.post_validate()
    data = play_1.serialize()
    play_1.deserialize(data)
    assert play_1.serialize() == data

    # test case 2
    play_2 = Play()
    play_2.vars = dict()
    play_2.post_validate()
    data = play_2.serialize()
    play_2.deserialize(data)
    assert play_2.serialize() == data

    # test case 3
    play_3 = Play()
    play_3.remote_user = 'user'
    play_3.post_validate()
    data = play_3.serialize()
    play_3.deserialize(data)
    assert play_3.serial

# Generated at 2022-06-25 05:33:39.642134
# Unit test for constructor of class Play
def test_Play():
    play_0 = Play()


# Generated at 2022-06-25 05:33:43.434805
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a new play with one handler in it.
    handler_0 = Handler()
    handler_0.action = "shell"
    handler_0.args = dict()
    handler_0.args['_raw_params'] = "echo 'hello world'"
    play_0 = Play(handlers=[handler_0])
    # invoke compile_roles_handlers
    play_0.compile_roles_handlers()
    # TODO: Check results


# Generated at 2022-06-25 05:33:52.147801
# Unit test for method serialize of class Play
def test_Play_serialize():
    vars = dict()
    vars['foo'] = 'bar'
    vars['baz'] = 42
    variable_manager = VariableManager()
    variable_manager.extra_vars = vars

    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'vars': vars,
    }, variable_manager=variable_manager, loader=DataLoader())

    play_data = play.serialize()
    assert play_data['name'] == 'test'
    assert play_data['hosts'] == 'localhost'
    assert play_data['gather_facts'] == 'no'
    assert play_data['vars'] == vars
