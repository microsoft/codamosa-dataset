

# Generated at 2022-06-25 05:24:33.667574
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0._tasks = [Task(), Task(), Task()]
    play_0._pre_tasks = [Task(), Task(), Task()]
    play_0._post_tasks = [Task(), Task(), Task()]
    play_0.hosts = '192.168.1.1'
    x = play_0.get_tasks()
    assert x[0].action == 'set_fact'
    assert x[1].action == 'debug'
    assert x[2].action == 'fail'
    assert x[3].action == 'set_fact'
    assert x[4].action == 'debug'
    assert x[5].action == 'fail'
    assert x[6].action == 'set_fact'
    assert x[7].action == 'debug'
    assert x

# Generated at 2022-06-25 05:24:37.153551
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    register_loader_types()
    data = dict(
        name='A play',
        hosts='all',
        user='a_user',
    )
    play_0 = Play.load(data)


# Generated at 2022-06-25 05:24:41.085347
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    '''
    Improper deserialize call without data
    '''
    play_1 = Play()
    try:
        play_1.deserialize(None)
    except AnsibleError as e:
        assert True


# Generated at 2022-06-25 05:24:49.757001
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    # Only works if there is a play.yml in the module path
    try:
        p = Play.load('play.yml')
    except AnsibleFileNotFound:
        # Cannot run test
        return
    data = p.serialize()
    new_p = Play()
    new_p.deserialize(data)
    assert new_p.vars == p.vars
    assert new_p.tags == p.tags
    assert new_p.name == p.name
    assert new_p.become == p.become
    assert new_p.become_user == p.become_user
    assert new_p.serial == p.serial
    assert new_p.strategy == p.strategy
    assert new_p.max_fail_percentage == p.max_fail_percentage


# Generated at 2022-06-25 05:24:52.190399
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Create an instance of Play
    play_1 = Play()
    # Read the contents of the var files
    vars_files = play_1.get_vars_files()
    # Assert that the contents are empty
    assert len(vars_files) == 0


# Generated at 2022-06-25 05:24:54.117225
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    assert play_0.get_tasks() == []


# Generated at 2022-06-25 05:25:03.126681
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    role_1 = Role()
    role_2 = Role()
    role_3 = Role()
    handler_1 = Handler()
    handler_2 = Handler()
    handler_3 = Handler()
    play_1.roles = [role_1, role_2, role_3]
    role_1._block = [handler_1]
    role_2._block = [handler_2]
    role_3._block = [handler_3]
    play_1.compile_roles_handlers()

# Generated at 2022-06-25 05:25:15.494041
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.roles = [{'name': 'test_role'}]
    play_0.roles[0].handlers = [{'name': 'ok', 'blockname': task_0}]
    play_0.roles[0].handlers[0]['block'] = [{'name': 'ok', 'tasks': [task_0]}]
    play_0.roles[0].tasks = [{'name': 'ok', 'blockname': task_0}]
    play_0.roles[0].tasks[0]['block'] = [{'name': 'ok', 'tasks': [task_0]}]
    play_0.roles[0].tasks[0]['when'] = {'1': '1'}
    blocks = play

# Generated at 2022-06-25 05:25:19.580420
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    # Use list from method get_roles of class Play
    roles_0 = play_0.get_roles()
    for role in roles_0:
        # Use method get_handler_blocks of class Role
        role.get_handler_blocks()
    # Use method compile_roles_handlers of class Play
    play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:25:26.407936
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.vault import VaultLib

    # test case 1
    play_1 = Play()
    play_1.preprocess_data(dict(vars=dict(v1=1, v2=2, v3=3)))
    assert play_1.vars == dict(v1=1, v2=2, v3=3)

    # test case 2
    play_2 = Play()
    play_2.preprocess_data(dict(vars=dict(v1=1, v2=2, v3=3, ansible_vault=dict(key_1=1, key_2=2, key_3=3))))

# Generated at 2022-06-25 05:25:41.895295
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_case_0()

##############################################################################

# Tests

# Generated at 2022-06-25 05:25:45.039873
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    play_0.preprocess_data({})
    play_0.preprocess_data('not a dict')
    play_0.preprocess_data({'hosts': 'localhost', 'roles': ['foo']})


# Generated at 2022-06-25 05:25:46.637382
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()

    data = dict()
    play_0.preprocess_data(data)


# Generated at 2022-06-25 05:25:47.801358
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert test_case_0() is None


# Generated at 2022-06-25 05:25:58.146555
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play1 = Play()
    roles1 = [
        {'name': 'role_1'},
        {'name': 'role_2'},
        {'name': 'role_3'},
        {'name': 'role_4'},
        {'name': 'role_5'},
    ]

    play1.roles = Play._load_roles(play1, 'roles', roles1)
    play1.roles[0].get_handler_blocks = MagicMock(return_value=['handler1'])
    play1.roles[1].get_handler_blocks = MagicMock(return_value=['handler2'])
    play1.roles[2].get_handler_blocks = MagicMock(return_value=['handler3'])
    play1.roles[3].get_

# Generated at 2022-06-25 05:26:03.896876
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # Ensure that a task in a Role has handlers associated with it,
    # and that they are not implicitly run.
    role = Role()
    role.tasks = [
        Task.load(
            data={'name': 'task 1', 'handlers': [{'name': 'handler 1', 'debug': {'msg': 'handler 1'}}]},
            play=Play(),
            variable_manager=VariableManager(),
            loader=DataLoader(),
        )
    ]

    play = Play()
    play.roles = [role]
    for handler in play.compile_roles_handlers():
        assert len(handler.notified_by()) == 0


# Generated at 2022-06-25 05:26:07.185981
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    #This may raise an exception
    try:
        play_0 = Play()
        play_0.get_vars_files()
    except Exception:
        assert False, "Failure in get_vars_files"



# Generated at 2022-06-25 05:26:08.771297
# Unit test for constructor of class Play
def test_Play():
    print("Constructor test for class Play")
    print("----------------------------------------------------------------------")
    test_case_0()
    print("")


# Generated at 2022-06-25 05:26:19.179873
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    #
    # Test preprocessing of play and vars blocks
    #
    def do_play_preprocessing(play_ds, variable_manager=None, loader=None):
        play_ds = preprocess_data(play_ds, variable_manager=variable_manager, loader=loader)
        play_ds = Play.preprocess_data(play_ds)
        return play_ds

    #
    # Test vars block
    #
    # The user can provide a vars block in YAML as a dictionary or a list.
    # To make life easier for the user, this should be converted to a list
    # as we don't want to have to keep updating code for both list and
    # dictionary. The conversion should be done in a way which doesn't
    # break the user's existing playbook.
    #
    # This should result in the

# Generated at 2022-06-25 05:26:24.854526
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    n = p.get_name()
    assert isinstance(n, text_type), "Returned value is not text_type"


# Generated at 2022-06-25 05:26:41.877807
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "play_0"
    assert play.get_name() == "play_0"


# Generated at 2022-06-25 05:26:44.147121
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    play_0.preprocess_data(ds=None)
    assert u'tasks' not in play_0.vars
    assert u'hosts' not in play_0.vars


# Generated at 2022-06-25 05:26:50.361900
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_1 = Play()
    play_2 = Play()
    play_3 = Play()
    play_4 = Play()
    play_5 = Play()
    play_6 = Play()
    play_7 = Play()
    play_8 = Play()
    play_9 = Play()
    play_10 = Play()
    pre_tasks_1 = [Block(block=[Task()]), Block(block=[Task()])]
    play_1.pre_tasks = pre_tasks_1
    tasks_2 = [Block(block=[Task()]), Block(block=[Task()])]
    play_2.tasks = tasks_2
    post_tasks_3 = [Block(block=[Task()]), Block(block=[Task()])]

# Generated at 2022-06-25 05:26:53.744329
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasks = play_0.get_tasks()
    assert tasks == []
    print("Task tests are passed")


# Generated at 2022-06-25 05:26:55.226033
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = []
    play_1._compile_roles()


# Generated at 2022-06-25 05:27:00.162975
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_1 = Play()
    play_1.roles = ['role_1', 'role_2']
    block_list_0 = play_1.compile_roles_handlers()
    play_2 = Play({'roles': ['role_0']})
    block_list_1 = play_2.compile_roles_handlers()
    play_3 = Play({'roles': ['role_0']})
    block_list_2 = play_3.compile_roles_handlers()
    play_4 = Play({'roles': ['role_0']})
    block_list_3 = play_4.compile_roles_handlers()
    assert block_list_0 == ['role_1', 'role_2']
    assert block_list_1

# Generated at 2022-06-25 05:27:07.754144
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()

# Generated at 2022-06-25 05:27:09.490361
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_1 = play_0.serialize()


# Generated at 2022-06-25 05:27:10.362744
# Unit test for constructor of class Play
def test_Play():
    test_case_0()


# Generated at 2022-06-25 05:27:16.355125
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create a data structure representing a play YAML
    # document with very special names
    play_data_dict = {
        'play original': {
            'hosts': 'localhost',
            'tasks': [
                {'meta': 'flush_handlers'},
                {'user': 'foo', 'local_action': 'shell touch foo'},
                {'user': 'bar', 'local_action': 'shell touch bar'},
                {'user': 'baz', 'local_action': 'shell touch baz'},
            ],
            'handlers': [
                {'user': 'baz', 'local_action': 'shell ls'},
            ]
        }
    }
    play_data = StringIO(yaml.dump(play_data_dict, default_flow_style=False))
    # Make sure

# Generated at 2022-06-25 05:27:36.279257
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    try:
        #   Input data is a list
        #   expected to throw exception because input is not dict
        play_0 = Play()
        play_0.preprocess_data([])
        assert False and "Exception not thrown"
    except AssertionError as e:
        assert str(e) == 'while preprocessing data ([]), ds should be a dict but was a <class \'list\'>'
    except Exception as e:
        assert False and "Incorrect exception thrown"
    try:
        #   Input data has key user and not remote_user
        #   expected to add remote_user to data and delete user
        play_0 = Play()
        data_0 = dict()
        play_0.preprocess_data(data_0)
    except Exception as e:
        assert False and "Incorrect exception thrown"
   

# Generated at 2022-06-25 05:27:42.034178
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play object
    play_1 = Play()
    # Invoke the method get_tasks
    tasks = play_1.get_tasks()
    # Get the length of the list 'tasks'
    tasks_len = len(tasks)
    # Compare tasks_len with the expected output
    assert tasks_len == 0, "Expected output is 0 but got {}".format(tasks_len)

if __name__ == '__main__':
    test_Play_get_tasks()

# Generated at 2022-06-25 05:27:47.518110
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    host_list = ['192.168.0.1', '192.168.0.2']
    block_0 = Block()
    block_0.name = 'do_foo'
    block_0.block = 'some tasks'
    block_1 = Block()
    block_1.name = 'do_bar'
    block_1.block = 'some other tasks'
    play_0 = Play()
    play_0.name = 'foo'
    play_0.hosts = host_list
    play_0.tasks = [block_0, block_1]
    play_0.handlers = [block_1, block_0]
    play_0.roles = [block_0, block_1]

# Generated at 2022-06-25 05:27:49.589615
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data = {}
    play_0.deserialize(data)


# Generated at 2022-06-25 05:27:53.198508
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    test_str = play_0.deserialize({'remote_user': 'test_remote_user'})
    assert play_0.remote_user == 'test_remote_user'



# Generated at 2022-06-25 05:27:57.310923
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test case #0
    play_0 = Play()
    assert(play_0.vars_files is None)
    vars_files_0 = play_0.get_vars_files()
    assert(vars_files_0 == [])
    assert(play_0.vars_files is None)


# Generated at 2022-06-25 05:28:05.659147
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_1 = Play()
    play_2 = Play()
    play_3 = Play()
    play_4 = Play()
    play_5 = Play()
    play_6 = Play()
    play_7 = Play()
    play_8 = Play()

    play_8.name = None
    play_0.hosts = 'hosts'
    play_1.hosts = 'hosts'
    play_2.hosts = 'hosts'
    play_3.hosts = 'hosts'
    play_4.hosts = 'hosts'
    play_5.hosts = 'hosts'
    play_6.hosts = 'hosts'
    play_7.hosts = 'hosts'
    play_8.hosts = 'hosts'

   

# Generated at 2022-06-25 05:28:06.616554
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-25 05:28:10.880273
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert Play().get_name() == ''


# Generated at 2022-06-25 05:28:16.887067
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    ds_1 = dict()
    result_1 = play_1.preprocess_data(ds_1)
    assert(isinstance(result_1, dict))


# Generated at 2022-06-25 05:28:49.092664
# Unit test for method get_name of class Play
def test_Play_get_name():
    hostlist_0 = [ '192.168.101.100', '192.168.101.101' ]
    play_0 = Play(hosts=hostlist_0)
    name_0 = play_0.get_name()
    assert name_0 == '192.168.101.100,192.168.101.101'


# Generated at 2022-06-25 05:28:54.356502
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = ['pre_tasks', 'pre_tasks', 'pre_tasks']
    play_0.tasks = ['tasks', 'tasks', 'tasks']
    play_0.post_tasks = ['post_tasks', 'post_tasks', 'post_tasks']

    task_list_0 = play_0.get_tasks()
    assert task_list_0 == ['pre_tasks', 'pre_tasks', 'pre_tasks', 'tasks', 'tasks', 'tasks', 'post_tasks', 'post_tasks', 'post_tasks']
    

# Generated at 2022-06-25 05:29:04.618182
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_1.preprocess_data({'one': 1, 'two': 'two', 'three': {'mykey': 'myval'}, 'four': ['one', 'two', 'three']})
    assert play_1.one == 1
    assert play_1.two == 'two'
    assert play_1.three['mykey'] == 'myval'
    assert play_1.four == ['one', 'two', 'three']

    play_2 = Play()
    play_2.preprocess_data({'user': 'foo'})
    assert play_2.user is None
    assert play_2.remote_user == 'foo'

    play_3 = Play()
    play_3.preprocess_data({'user': 'foo', 'remote_user': 'bar'})

# Generated at 2022-06-25 05:29:06.007217
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test-play'
    assert play.get_name() == 'test-play'


# Generated at 2022-06-25 05:29:09.260818
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass


# Generated at 2022-06-25 05:29:12.421229
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # create a copy of the test Play()
    newPlay = test_case_0()

    # Play should contain no roles
    # len(roles) = 0
    # test against expected value
    assert newPlay.compile_roles_handlers() == []


# Generated at 2022-06-25 05:29:18.276260
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    try:
        play_0 = Play()
        assert play_0
    except Exception as e:
        print()
        raise
    try:
        play_0.get_tasks()
    except Exception as e:
        print()
        raise
    else:
        print('%s success' % test_Play_get_tasks.__name__)


# Generated at 2022-06-25 05:29:20.037023
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_1.preprocess_data({
        'hosts': 'localhost',
        'user': 'root'
    })


# Generated at 2022-06-25 05:29:22.027332
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    block_list = play_0.compile_roles_handlers()
    assert(isinstance(block_list, list))


# Generated at 2022-06-25 05:29:26.907124
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.tasks.append(Task())
    play_1.post_tasks.append(Task())
    play_1.pre_tasks.append(Task())
    assert len(play_1.get_tasks()) == 3


# Generated at 2022-06-25 05:29:59.628564
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "PLAY_0"
    assert play_0.get_name() == "PLAY_0"


# Generated at 2022-06-25 05:30:10.478800
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
	play_1 = Play()
	assert play_1.get_vars_files() == []

	play_2 = Play()
	play_2.vars_files = None
	assert play_2.get_vars_files() == []
	
	play_3 = Play()
	play_3.vars_files = ["ansible/playbooks/roles/common/vars/main.yml"]
	assert isinstance(play_3.get_vars_files(), list)
	assert play_3.get_vars_files() == ["ansible/playbooks/roles/common/vars/main.yml"]
	
	#TODO: Create a test case when the vars_files is a list that contains multiple files

#print(vars(play_1))
#print(vars(

# Generated at 2022-06-25 05:30:13.742667
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'testPlay_1'
    if play_1.get_name() != 'testPlay_1':
        print("Test case for method get_name of class Play Failed")


# Generated at 2022-06-25 05:30:14.638838
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()


# Generated at 2022-06-25 05:30:16.157341
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()

    tasks_0 = play_0.get_tasks()


# Generated at 2022-06-25 05:30:19.267891
# Unit test for method get_name of class Play
def test_Play_get_name():
    pytest.skip("TODO")
    # Test for "return the name of the Play", in test case 0
    res = play_0.get_name()
    if 'AnsibleException' in res or 'AnsibleUndefinedVariable' in res:
        pytest.fail("Should not fail")


# Generated at 2022-06-25 05:30:20.793720
# Unit test for method get_name of class Play
def test_Play_get_name():

    # Setup
    play_0 = Play()

    # Testing
    assert play_0.get_name() == ""


# Generated at 2022-06-25 05:30:27.411545
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "play_0_name"
    assert play_0.get_name() == "play_0_name"
    hosts_0 = ["host_a", "host_b"]
    play_0.hosts = hosts_0
    assert play_0.get_name() == "host_a,host_b"


# Generated at 2022-06-25 05:30:31.892535
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create basic play to test compile_roles_handlers
    play_0 = Play()
    play_0.name = 'test_play_0'
    play_0.hosts = ['test_host_0']
    play_0.roles = [
        {
            'name': 'test_role_0',
            'handlers': {
                'handler_block_0': {
                    'test_task_0': {}
                },
            }
        },
        {
            'name': 'test_role_1',
            'handlers': {
                'handler_block_0': {
                    'test_task_0': {}
                },
            }
        },
    ]

    # get handlers
    blocks = play_0.compile_roles_handlers()

    assert len(blocks) == 2

# Generated at 2022-06-25 05:30:40.575949
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # Set-up
    # Create a Play object and use it to create a role with handlers
    play_1 = Play()
    role_1 = Role()
    # Create a Handler object that the Role will contain
    handler_1 = Handler()
    # Create a Task object that the Role will contain
    task_1 = Task()
    task_1.name = "task 1"
    task_1.set_loader(DictDataLoader({}))
    task_1._role = role_1
    handler_1.task = task_1

    # Run and check
    role_1.handlers = []
    role_1.handlers.append(handler_1)
    play_1.roles.append(role_1)
    handlers = play_1.compile_roles_handlers()

# Generated at 2022-06-25 05:31:17.959855
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()

    # Example data on the format of data


# Generated at 2022-06-25 05:31:27.352950
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    print("Test Play: deserialize")
    play_0 = Play()
    play_0.deserialize(
        {
            'connection' : 'local',
            'name' : 'Test Play',
            'hosts' : 'localhost',
            'gather_facts' : 'no',
            'vars' : {
                'ansible_connection' : 'local'
            },
            'tasks' : [
                {
                    'include_role' : {
                        'name' : 'pancake'
                    }
                }
            ]
        }
    )


# Generated at 2022-06-25 05:31:38.780068
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_obj = Play()
    role_obj1 = Role()
    role_obj2 = Role()
    role_obj3 = Role()
    role_obj4 = Role()
    role_obj5 = Role()
    role_obj1.set_handler_blocks([role_obj2, role_obj3])
    role_obj1.set_handler_blocks([role_obj4, role_obj5])
    play_obj.roles.append(role_obj1)
    result_obj = play_obj.compile_roles_handlers()
    assert result_obj == [role_obj2, role_obj3, role_obj4, role_obj5], "test_Play_compile_roles_handlers failed"
    print("test_Play_compile_roles_handlers passed")


# Unit test

# Generated at 2022-06-25 05:31:45.580061
# Unit test for method get_name of class Play
def test_Play_get_name():
    try:
        play = Play()
    except:
        print("Failed! Play can't be initialized!")
        exit(1)
    play.hosts = 'hosts'
    if play.get_name() != 'hosts':
        print("Failed! Name is not correct!")
        exit(1)


# Generated at 2022-06-25 05:31:48.802966
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create fixture
    play_0 = Play()
    # Exercise
    result = play_0.compile_roles_handlers()
    # Verify
    if result is None:
        raise AssertionError('Play.compile_roles_handlers returned None')


# Generated at 2022-06-25 05:31:51.192427
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-25 05:31:59.937711
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Play obj created for test_case_0
    # dummy data from include_role module
    play_0 = Play()
    play_0._ds = {'hosts': 'localhost', 'name': 'test_case_0', 'roles': [{'include_role': {'name': 'foo', 'tasks_from': 'main'}}], 'tasks': [], 'vars': {}}
    play_0._loader = DataLoader()
    play_0._variable_manager = VariableManager()
    _results = play_0._load_roles(attr=None, ds=play_0._ds.get('roles', []))
    play_0.roles = _results
    assert play_0.compile_roles_handlers() == []


# Generated at 2022-06-25 05:32:10.875209
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    for line in open("compile_roles_handlers_test_data.txt", 'r'):
        play_name, role_name, role_path, handler_name, handler_path, expected_result = line.split("|")
        play_0 = Play()
        play_0.name = play_name

        r = Role()
        r.name = role_name
        r.ROLE_PATH = role_path
        r.handlers = {'name': handler_name, 'path': handler_path}

        play_0.roles.append(r)

        play_0.compile_roles_handlers()
        assert play_0.roles[0].handlers['name'] == expected_result

# Generated at 2022-06-25 05:32:12.319063
# Unit test for constructor of class Play
def test_Play():
    play_0 = Play().__init__()
# print("Play(): ", test_Play())


# Generated at 2022-06-25 05:32:22.872118
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    collection_0 = Mock()
    collection_0.get_file_vars.return_value = 'get_file_vars'
    play_1.collections = [collection_0]
    play_vars_1 = dict()
    play_vars_1['vars'] = set()
    play_1._variable_manager = VariableManager()
    play_1._variable_manager._extra_vars = play_vars_1
    play_1._loader = DataLoader()

# Generated at 2022-06-25 05:33:06.903465
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    play_1 = Play()
    play_1.vars = dict(foo = 'bar')
    task_0 = Task()
    play_1.tasks = [task_0]
    task_1 = Task()
    play_1.pre_tasks = [task_1]
    task_2 = Task()
    play_1.post_tasks = [task_2]
    task_3 = Task()
    play_1.handlers = [task_3]

    assert play_1.get_vars() == dict(foo = 'bar')
    assert play_1.get_handlers() == [task_3]
    assert play_1.get_tasks() == [task_1, task_0, task_2]


# Generated at 2022-06-25 05:33:15.056346
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # data for test case
    play_1 = Play()
    play_1.pre_tasks = "pre_tasks"
    play_1.tasks = "tasks"
    play_1.post_tasks = "post_tasks"
    play_1_exp_tasklist = ['pre_tasks', 'tasks', 'post_tasks']

    # invoke operation under test w/ data from test case
    play_1_act_tasklist = play_1.get_tasks()

    # check results

# Generated at 2022-06-25 05:33:19.287984
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Test with non dict value for data
    play_1 = Play()
    try:
        play_1.deserialize("")
    except (AssertionError, AnsibleAssertionError, AssertionError) as e:
        print("Exception Raised :" + str(e))


# Generated at 2022-06-25 05:33:27.185625
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_handler_block_0 = DummyTask()
    test_handler_block_1 = DummyTask()
    test_handler_block_2 = DummyTask()
    test_handler_block_3 = DummyTask()
    test_handler_block_4 = DummyTask()
    test_handler_block_5 = DummyTask()
    test_handler_block_6 = DummyTask()
    test_handler_block_7 = DummyTask()
    test_handler_block_8 = DummyTask()
    test_handler_block_9 = DummyTask()
    test_handler_block_10 = DummyTask()
    test_handler_block_11 = DummyTask()
    test_handler_block_12 = DummyTask()
    test_handler_block_13 = DummyTask()
    test_

# Generated at 2022-06-25 05:33:31.924395
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Create a test variable
    play_0 = Play()
    # Create an empty variable
    data_0 = {}

    # Set the data to the variable
    data_0 = play_0.serialize()

    # Assert that the data is not empty
    assert data_0 != {}


# Generated at 2022-06-25 05:33:36.137472
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = [{'name': 'task_0'}]
    play_0.tasks = [{'name': 'task_1'}]
    play_0.post_tasks = [{'name': 'task_2'}]
    play_0.get_tasks()


# Generated at 2022-06-25 05:33:45.384950
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-25 05:33:47.178419
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.get_vars_files() == []


# Generated at 2022-06-25 05:33:57.512557
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:34:04.387247
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()

    task_handler_0 = Handler()
    task_handler_1 = Handler()
    task_handler_2 = Handler()
    task_handler_3 = Handler()

    play_0.handlers = [ task_handler_0, task_handler_1, task_handler_2 ]

    task_role_0 = Role()
    task_role_1 = Role()
    task_role_2 = Role()

    task_role_0.handlers = [ task_handler_0, task_handler_1 ]
    task_role_1.handlers = [ task_handler_2, task_handler_3 ]

    play_0.roles = [ task_role_0, task_role_1, task_role_2 ]

    task_block_1 = Block()