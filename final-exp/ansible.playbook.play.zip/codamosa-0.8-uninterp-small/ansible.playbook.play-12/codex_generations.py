

# Generated at 2022-06-25 05:24:13.227744
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'foo'
    assert p.get_name() == 'foo'
    del p.name
    p.hosts = 'bar'
    assert p.get_name() == 'bar'
    del p.hosts
    assert p.get_name() == ''


# Generated at 2022-06-25 05:24:14.500382
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    assert play_1.compile_roles_handlers() is None


# Generated at 2022-06-25 05:24:18.027185
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print("Testing Play.get_vars_files()")

    # Test case 0
    play_0 = Play()
    play_0.vars_files = []

    expected_0 = play_0.vars_files
    actual_0 = play_0.get_vars_files()
    if actual_0 != expected_0:
        raise AssertionError("%s != %s" % (actual_0, expected_0))


# Generated at 2022-06-25 05:24:23.095257
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()

    play_1.name = "play_1"
    play_1._DS = dict(name="play_1")
    assert play_1.get_name() == "play_1"
    assert play_1.name == "play_1"

    play_2 = Play()
    play_2.hosts = ["host_1"]
    assert play_2.get_name() == "host_1"
    assert play_2.name == "host_1"

    play_3 = Play()
    play_3.hosts = ["host_1", "host_2"]
    assert play_3.get_name() == "host_1,host_2"
    assert play_3.name == "host_1,host_2"


# Generated at 2022-06-25 05:24:27.673063
# Unit test for method serialize of class Play
def test_Play_serialize():
    with open('./unit_test_cases/test_data/test_Play_serialize.json', 'r') as fd:
        data = json.load(fd)
    play_0 = Play.load(data['data'])
    new_data = play_0.serialize()

    assert new_data == data['expected_result']


# Generated at 2022-06-25 05:24:29.725735
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    tasks_1 = play_1.get_tasks()
    assert tasks_1 == [], tasks_1


# Generated at 2022-06-25 05:24:30.942335
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.get_name() == ''


# Generated at 2022-06-25 05:24:42.020856
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # initialize required objects
    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager)

    # sample datastructure

# Generated at 2022-06-25 05:24:43.470205
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    # assert play_1.get_name() == ''
    play_1.name = 'test_name'
    assert play_1.get_name() == 'test_name'


# Generated at 2022-06-25 05:24:46.732396
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    handler_list = []
    handler_list.append(Handler(name='test_handler', play=p))
    p.handlers = handler_list
    assert p.compile_roles_handlers() == handler_list

# Generated at 2022-06-25 05:24:57.856997
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # play_0 = Play()
    # play_0.get_tasks()
    pass


# Generated at 2022-06-25 05:25:05.747298
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()

# Generated at 2022-06-25 05:25:06.418252
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_case_0()


# Generated at 2022-06-25 05:25:16.781481
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()

    test_play._load_handlers(None, [{'handlers': [{'listen': 'failures'}]}])
    test_play._load_roles(None, [{'roles': [{'role': 'test'}]}])

    handler_list = test_play.compile_roles_handlers()

    # Check that handler list has expected structure
    assert isinstance(handler_list, list)
    assert isinstance(handler_list[0],  Handler)
    assert isinstance(handler_list[0].block, list)
    assert isinstance(handler_list[0].block[0], Task)
    assert handler_list[0].block[0].action == 'meta'

# Generated at 2022-06-25 05:25:18.690607
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()

    # Test normal operation
    play_0.name = "ALICE"
    assert play_0.get_name() == "ALICE"


# Generated at 2022-06-25 05:25:23.489838
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Generate test data
    data = {'user': 'root'}
    # Generate expected results
    expected_results = {'remote_user': 'root'}
    # Create instance of class Play
    play_1 = Play()
    # Preprocess test data
    preprocessed_test_data = play_1.preprocess_data(data)
    # Compare actual results with expected results
    assert expected_results == preprocessed_test_data
    # Test for alternate key name
    data['remote_user'] = 'root'
    # Compare actual results with expected results
    assert expected_results == preprocessed_test_data


# Generated at 2022-06-25 05:25:32.833584
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.tasks = [
        {'include_tasks': 'test.yml'},
        {'block': [
            {'include_role': {'name': 'test'}},
            {'import_tasks': 'test.yml'},
            {'include_tasks': 'test.yml'},
        ]}
    ]
    play.post_tasks = [{'debug': {'msg': 'post_tasks'}}]
    play.pre_tasks = [{'debug': {'msg': 'pre_tasks'}}]
    tasks = play.get_tasks()
    assert isinstance(tasks, list)


# Generated at 2022-06-25 05:25:42.465356
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.vars_files is None
    assert play_0.get_vars_files() == []
    play_0.vars_files = None
    assert play_0.get_vars_files() == []
    play_0.serialize()
    play_0.deserialize({'vars_files': ['filename1', 'filename2'],
                        'some_key': 'some_value'})
    assert play_0.get_vars_files() == ['filename1', 'filename2']


# Generated at 2022-06-25 05:25:43.374572
# Unit test for constructor of class Play
def test_Play():
    test_case_0()


# Generated at 2022-06-25 05:25:47.916661
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    file_1 = '/etc/some_file'
    file_2 = '/etc/some_second_file'
    vars_files = [file_1, file_2]

    play_2 = Play()
    play_2.vars_files = vars_files
    assert play_2.get_vars_files() == vars_files
    play_2.vars_files = file_1
    assert play_2.get_vars_files() == [file_1]


# Generated at 2022-06-25 05:25:57.440978
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    play_serialize = play_1.serialize()
    assert '__ansible_version__' in play_serialize.keys()
    assert '__ansible_module__' in play_serialize.keys()
    assert '__ansible_parsed' in play_serialize.keys()


# Generated at 2022-06-25 05:25:59.373157
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    data_0 = {}
    result = play_1.preprocess_data(ds=data_0)
    assert result == {}


# Generated at 2022-06-25 05:26:07.762495
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    task_1_0 = dict(action='action_0_0', name='name_0_0_0', tags='')
    task_1_1 = dict(action='action_0_1', name='name_0_1_0', tags='tag_1_0')
    task_1_2 = dict(action='action_0_2', name='name_0_2_0', tags='tag_1_0')
    task_1_3 = dict(action='action_0_3', name='name_0_3_0', tags='')
    task_1_4 = dict(action='action_0_4', name='name_0_4_0', tags='')

# Generated at 2022-06-25 05:26:12.322426
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    name = play_0.get_name()
    assert name == ''

# Generated at 2022-06-25 05:26:17.393725
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    curdir = os.path.dirname(os.path.abspath(__file__))

    # Check the deserialize method when given a serialized Play and a
    # Playbook.
    play = Play.load(loader.load_from_file(curdir +
        '/../../test/sanity/serialize/serialize_data/play_serialize_0.yml'))
    result = play.serialize()

    play_0 = Play.load(loader.load_from_file(curdir +
        '/../../test/sanity/serialize/serialize_data/play_serialize_1.yml'))
    play_0.deserialize(result)
    assert play_0.serialize() == result

    # Check the deserialize method when given a serialized Play and Role.
   

# Generated at 2022-06-25 05:26:19.795390
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'play_name'

    assert play_1.get_name() == play_1.name


# Generated at 2022-06-25 05:26:25.753633
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'test_play_1'
    assert play_1.get_name() == 'test_play_1'
    play_2 = Play()
    play_2.hosts = 'localhost'
    assert play_2.get_name() == 'localhost'
    play_3 = Play()
    play_3.hosts = ['host1', 'host2']
    assert play_3.get_name() == 'host1,host2'
    play_4 = Play()
    assert play_4.get_name() == ''


# Generated at 2022-06-25 05:26:28.564524
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    # Test for failure on self.name = None;
    try:
        play_0.get_name()
    except AnsibleParserError:
        pass
    play_0.name = 'play_0.name'
    assert play_0.get_name() == 'play_0.name'


# Generated at 2022-06-25 05:26:35.417976
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    res = play_0.compile_roles_handlers()
    assert(res == [])

    play_1 = Play()
    play_1.roles = [Role()]
    res = play_1.compile_roles_handlers()
    assert(res == [])


# Generated at 2022-06-25 05:26:40.667670
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    play_0.preprocess_data(ds=None)
    play_0._included_path = 'path'


# Generated at 2022-06-25 05:26:57.802483
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Initialize an object of class Play
    play = Play()
    # Initialize two objects of class Role
    role1 = Role()
    role2 = Role()
    # Set the handlers attribute of the two objects of class Role to {'role1': ['t1.yaml'], 'role2': ['t2.yaml']}
    role1.handlers = {'role1': ['t1.yaml']}
    role2.handlers = {'role2': ['t2.yaml']}
    # Set the role attribute of the object of class Play to [role1, role2]
    play.roles = [role1, role2]
    # Invoke the compile_roles_handlers method of the object of class Play
    play.compile_roles_handlers()
    # Assert that the handlers attribute of

# Generated at 2022-06-25 05:27:00.515769
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.serialize()


# Generated at 2022-06-25 05:27:05.130013
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.pre_tasks = [Task()]
    play_1.post_tasks = [Task()]
    play_1.tasks = [Task()]
    assert len(play_1.get_tasks()) == 3
    play_2 = Play()
    play_2.pre_tasks = [Block()]
    play_2.post_tasks = [Block()]
    play_2.tasks = [Block()]
    assert len(play_2.get_tasks()) == 9

# Unit tests for method _load_tasks of class Play

# Generated at 2022-06-25 05:27:13.155711
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    print('{:-^100}'.format(' Unit test for method preprocess_data of class Play '))

    def verify_tasks_data(tasks_ds, play_obj):
        try:
            play_obj.tasks = play_obj._load_tasks('tasks', tasks_ds)
        except AnsibleParserError as e:
            print('\nFor tasks: %s' % tasks_ds)
            print('AnsibleParserError: %s\n' % to_native(e))

    play_0 = Play()

# Generated at 2022-06-25 05:27:21.938359
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    play_1 = Play()
    play_2 = Play()
    play_3 = Play()
    play_4 = Play()


# Generated at 2022-06-25 05:27:24.004701
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    data = {}
    data = play_1.deserialize(data)
    assert data == {}


# Generated at 2022-06-25 05:27:27.387789
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()


# Generated at 2022-06-25 05:27:34.313157
# Unit test for method preprocess_data of class Play

# Generated at 2022-06-25 05:27:39.326837
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-25 05:27:48.752696
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    global play_0
    play_0.pre_tasks = [{'name':'taskA'}, {'name':'taskB'}]
    play_0.tasks = [{'name':'taskC'}, {'name':'taskD'}]
    play_0.post_tasks = [{'name':'taskE'}, {'name':'taskF'}]
    play_0.compile()

    tasklist = play_0.get_tasks()
    assert(tasklist[1].task_name == 'taskB')
    assert(tasklist[2].task_name == 'taskC')
    assert(tasklist[5].task_name == 'taskF')

#if __name__ == "__main__":
#    import sys
#    sys.exit(0)

# Generated at 2022-06-25 05:28:16.587394
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    # Test for case 0
    block_list_0 = play_0.compile_roles_handlers()

    # Test for case 1
    disp_0 = Display()
    data_0 = dict()
    data_0["some_key"] = "test_value"
    disp_0.display(data_0, "*")
    play_1 = Play()
    block_list_1 = play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:28:25.700189
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Instantiate Play object
    play = Play()

    # Instantiate Role object, and set the role name
    role = Role()
    role.name = 'TestRole'

    # Instantiate Block object, and append a task
    block = Block()
    block.block = ['TestTask']

    # Instantiate Handler object, and append a task
    handler = Handler()
    handler.block = ['TestHandler']

    # Set the when value of the handler to a list
    handler.when = ['test_when']

    # Append the handler to the tasks of the role
    role.handlers.append(handler)

    # Append the block to the tasks of the role
    role.tasks.append(block)

    # Test the function of the method
    assert play.compile_roles_handlers() == [handler]

# Generated at 2022-06-25 05:28:32.788590
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_1 = Play()

    play_0.hosts = 'hosts list'
    play_1.hosts = None

    play_0_name = play_0.get_name()
    play_1_name = play_1.get_name()

    assert(play_0_name == 'hosts list')
    assert(play_1_name == '')


# Generated at 2022-06-25 05:28:42.475910
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1, block_1, block_2, task_1, task_2, task_3, task_4, task_5, task_6 = Play(), Block(), Block(), Task(), Task(), Task(), Task(), Task(), Task()
    play_1.tasks = [block_1, block_2]
    block_1.block = [task_1, task_2, task_3]
    block_2.block = [task_4, task_5, task_6]
    play_1.pre_tasks = [task_3, task_4]
    play_1.post_tasks = [task_1, task_2]

# Generated at 2022-06-25 05:28:44.946241
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    vars_file_0 = play_0.get_vars_files()


# Generated at 2022-06-25 05:28:46.650193
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    assert play_1.get_name() == ''


# Generated at 2022-06-25 05:28:47.728568
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_obj = Play()
    assert play_obj.compile_roles_handlers() is not None


# Generated at 2022-06-25 05:28:52.322238
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_1 = Play()

# Generated at 2022-06-25 05:28:56.295839
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """
    Test for method get_tasks of class Play
    """
    play_0 = Play()
    assert len(play_0.get_tasks()) == 0



# Generated at 2022-06-25 05:29:04.012194
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    # Test case 0
    play_0 = Play()
    play_0.pre_tasks = [{'raw': 'meta', 'module': 'meta', 'keywords': []}]
    play_0.tasks = [{'raw': 'service', 'state': 'started', 'service': 'sshd'}, {'raw': 'meta', 'module': 'meta', 'keywords': []}]
    play_0.post_tasks = [{'raw': 'meta', 'module': 'meta', 'keywords': []}]

    assert len(play_0.get_tasks()) == 5
    assert len(play_0.get_tasks()[0]) == 1

    # Test case 1
    play_1 = Play()

# Generated at 2022-06-25 05:29:24.973501
# Unit test for constructor of class Play
def test_Play():
    test_case_0()


# Generated at 2022-06-25 05:29:29.398512
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

    # Check that Task objects in Play.pre_tasks are returned by the method
    block_0 = Block()
    block_0.block = [Task()]
    play_1.pre_tasks = [block_0]
    assert play_1.get_tasks() == [block_0.block[0]]

    # Check that Task objects in Play.tasks are returned by the method
    block_1 = Block()
    block_1.block = [Task()]
    play_1.tasks = [block_1]
    assert play_1.get_tasks() == [block_0.block[0], block_1.block[0]]

    # Check that Task objects in Play.post_tasks are returned by the method
    block_2 = Block()
    block_2.block

# Generated at 2022-06-25 05:29:38.251452
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from . import Play
    play_0 = Play()
    play_1 = AnsibleBaseYAMLObject.serialize(play_0)
    play_2 = Play.serialize(play_0)
    
    assert play_1 == play_2
    # Possible here that assert play_1 == play_2 is not helpful. Try ansible.utils.unsafe_proxy.AnsibleUnsafeText and  pyyaml.nodes.ScalarNode
    #assert play_1 == play_2

# Generated at 2022-06-25 05:29:43.877683
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    print("Inside test_Play_compile_roles_handlers()")
    name = 'test_Play_compile_roles_handlers'
    print(name)
    # Input data

# Generated at 2022-06-25 05:29:45.978453
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    result = play_1.compile_roles_handlers()
    assert result is None


# Generated at 2022-06-25 05:29:48.004127
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    output = play_0.serialize()
    assert hasattr(output, '__iter__')


# Generated at 2022-06-25 05:29:49.579162
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    assert isinstance(play_0.get_tasks(), list)


# Generated at 2022-06-25 05:30:00.758898
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    role = Role()
    role.name = 'test_role_1'
    handler_1 = Handler()
    handler_2 = Handler()
    handler_1.name = 'debug.test_handler_1'
    handler_2.name = 'debug.test_handler_2'
    role.handlers = [handler_1, handler_2]
    play.roles = [role]
    handler_list = play.compile_roles_handlers()
    assert len(handler_list) == 2
    assert handler_list[0].name == 'debug.test_handler_1'
    assert handler_list[1].name == 'debug.test_handler_2'



# Generated at 2022-06-25 05:30:04.222028
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1_tasks = play_1.get_tasks()
    # The obj play_1_tasks should be a list
    assert isinstance(play_1_tasks, list)


# Generated at 2022-06-25 05:30:09.141916
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    result = play_0.compile_roles_handlers()
    assert result == [], 'Returned unexpected result: Returned unexpected result: %s' % result


# Generated at 2022-06-25 05:30:51.985540
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    result = play_1.get_vars_files()
    assert result == []

    play_1.vars_files = ['./vars_files/group_vars/group1.yml']
    result = play_1.get_vars_files()
    assert result == ['./vars_files/group_vars/group1.yml']

    play_1.vars_files = None
    result = play_1.get_vars_files()
    assert result == []


# Generated at 2022-06-25 05:30:56.980414
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """Test Play::get_tasks"""

    # Setup

    play_1 = Play()
    block_1 = Block()
    task_1 = dict()
    play_1.tasks = [block_1]

    # Exercise
    tasklist = play_1.get_tasks()

    # Verify
    assert tasklist == [block_1.block + block_1.rescue + block_1.always]


# Generated at 2022-06-25 05:31:05.300931
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    p1_roles_1 = Mock()
    p1_roles_1.get_handler_blocks = MagicMock(return_value=[1,2])
    p1_roles_2 = Mock()
    p1_roles_2.get_handler_blocks = MagicMock(return_value=[3,4])
    play_1.roles = [p1_roles_1, p1_roles_2]
    result = play_1.compile_roles_handlers()
    assert result == [1, 2, 3, 4]


# Generated at 2022-06-25 05:31:15.006722
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    # Test case when ds is not a dict
    try:
        play_1.preprocess_data('ds')
        assert False
    except AnsibleAssertionError:
        assert True
    # Test case when ds is a dict and there is no user in ds
    ds_1 = {'hosts': '127.0.0.1', 'become': True}
    try:
        play_1.preprocess_data(ds_1)
        assert True
    except AnsibleParserError:
        assert False
    # Test case when ds is a dict and user is in ds but remote_user is not
    ds_2 = {'hosts': '127.0.0.1', 'become': True, 'user': 'root'}

# Generated at 2022-06-25 05:31:18.569885
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = 'test'
    assert play_0.get_name() == 'test'


# Generated at 2022-06-25 05:31:26.294051
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0._included_path = "7Ww"
    play_0._action_groups = {}
    play_0._group_actions = {}
    play_0.get_name()
    play_0.get_vars()
    play_0.get_vars_files()
    play_0.get_handlers()
    play_0.get_roles()
    play_0.get_tasks()
    play_0.serialize()


# Generated at 2022-06-25 05:31:37.835874
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()

    roles_1 = []
    role_1 = Role()
    role_1.name = "role1"
    role_1.get_handler_blocks = Mock()
    role_1.get_handler_blocks.return_value = []
    roles_1.append(role_1)
    role_2 = Role()
    role_2.name = "role2"
    role_2.get_handler_blocks = Mock()
    role_2.get_handler_blocks.return_value = []
    roles_1.append(role_2)
    play_1.roles = roles_1

    handler_list = play_1.compile_roles_handlers()
    assert handler_list == []


# Generated at 2022-06-25 05:31:49.382790
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Check 1
    play_1 = Play()
    play_1.pre_tasks = []
    play_1.tasks = []
    play_1.post_tasks = []
    assert play_1.get_tasks() == [], "method get_tasks of class Play did not return the expected result. Expected: []. \n Actual: %s\n" % str(play_1.get_tasks())
    # Check 2
    play_2 = Play()
    play_2.pre_tasks = [None]
    play_2.tasks = [None]
    play_2.post_tasks = [None]

# Generated at 2022-06-25 05:31:54.574164
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    vars_files_0 = play_0.get_vars_files()
    assert vars_files_0 == [], "Expected [], but got: %s" % vars_files_0


# Generated at 2022-06-25 05:31:56.048849
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    result = play_0.compile_roles_handlers()
    assert(result == [])


# Generated at 2022-06-25 05:32:37.567868
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    global play_0
    play_0 = Play()
    print('method get_vars_files of class Play:')
    play_0.get_vars_files()


# Generated at 2022-06-25 05:32:40.029134
# Unit test for constructor of class Play
def test_Play():
    print('Test case 0: Run constructor')
    test_case_0()

# Generated at 2022-06-25 05:32:45.991761
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0._tasks = []
    play_0._post_tasks = []
    play_0._pre_tasks = []
    tasklist = play_0.get_tasks()



# Generated at 2022-06-25 05:32:52.029457
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print("\n=========== Start test for test_Play_get_vars_files===========")
    if not globals()["json_data"]:
        print("None input, skip test.")
        print("=========== End test for test_Play_get_vars_files ===========")
        return
    play = Play()
    play.deserialize(json_data)
    print("The vars_files of play is %s" % play.get_vars_files())
    print("=========== End test for test_Play_get_vars_files ===========")


# Generated at 2022-06-25 05:32:53.116241
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-25 05:32:59.302749
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    print(repr(play_0))
    # play_0.register_loader_option()
    play_0.blocks = [{'tasks': [{'block': [{'block': ('block', 'block')}]}, {'block': ('block', 'bloc')}]}]
    play_0._included_path = 'test_Play_included_path'
    play_0._variable_manager = 'test_Play_variable_manager'
    play_0._loader = 'test_Play_loader'
    play_0.conditional = 'test_Play_conditional'
    play_0.post_validate = 'test_Play_post_validate'
    play_0.handler_loader = 'test_Play_handler_loader'
    # play_0.vars

# Generated at 2022-06-25 05:33:09.167615
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = None
    play_1 = Play()
    play_1.vars_files = []
    play_2 = Play()
    play_2.vars_files = ''
    play_3 = Play()
    play_3.vars_files = 'test/functional/'
    play_4 = Play()
    play_4.vars_files = ['', '']
    play_5 = Play()
    play_5.vars_files = ['test/functional/', '']
    play_6 = Play()
    play_6.vars_files = ['test/functional/', 'test/functional/']
    play_7 = Play()
    play_7.vars_files = ['test/functional/']
    play_8 = Play()


# Generated at 2022-06-25 05:33:11.178714
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    var_files = play_0.get_vars_files()
    assert type(var_files) == list


# Generated at 2022-06-25 05:33:12.570794
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_case_0()

if __name__ == "__main__":
    test_Play_get_name()

# Generated at 2022-06-25 05:33:21.740753
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_1 = Play()
    play_2 = Play()
    play_3 = Play()
    play_4 = Play()
    play_5 = Play()
    play_6 = Play()
    play_7 = Play()
    play_8 = Play()
    play_9 = Play()
    play_10 = Play()
    play_11 = Play()
    play_12 = Play()
    play_13 = Play()
    play_14 = Play()
    play_15 = Play()

    play_0.vars_files = []
    play_1.vars_files = 0
    play_2.vars_files = Variable('foo')
    play_3.vars_files = "foo"
    play_4.vars_files = '/tmp/foo'
    play