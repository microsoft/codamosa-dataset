

# Generated at 2022-06-25 05:24:22.617608
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    vars = {'hosts': 'localhost'}
    play_1 = Play()
    play_1.name = 'play_1'
    play_1.vars = vars
    play_2 = Play()
    play_2.name = 'play_2'
    play_2.vars = vars

    play_1.vars = vars.copy()
    play_1.vars['user'] = 's0s'
    # Case 1: Should replace key 'user' with 'remote_user'
    play_1.preprocess_data(play_1.vars)
    assert play_1.vars.get('user', None) == None
    assert play_1.vars.get('remote_user') == 's0s'

    # Case 2: Should not raise an error since the key '

# Generated at 2022-06-25 05:24:25.177130
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()

    assert play_0.get_tasks() == []

# Testing of the local_action method with no args

# Generated at 2022-06-25 05:24:33.750339
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    dict = dict()
    dict['hosts'] = 'all'
    dict['connection'] = 'smart'
    dict['gather_facts'] = 'yes'
    dict['name'] = 'test_Play_deserialize'
    dict['deprecated'] = dict()
    dict['deprecated']['forks'] = 1
    dict['deprecated']['action'] = 'Setup'
    dict['deprecated']['module_args'] = dict()
    dict['deprecated']['module_args']['fact_path'] = '/etc/ansible/facts.d'
    dict['deprecated']['module_args']['filter'] = '*'
    dict['deprecated']['module_name'] = 'setup'

    play_0.deserialize(dict)



# Generated at 2022-06-25 05:24:44.373022
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data({})
    play.preprocess_data([])
    play.preprocess_data({'tasks': [], 'pre_tasks': [], 'post_tasks': [], 'handlers': []})
    play.preprocess_data({'tasks': None, 'pre_tasks': None, 'post_tasks': None, 'handlers': None})
    play.preprocess_data({'tasks': (), 'pre_tasks': (), 'post_tasks': (), 'handlers': ()})
    play.preprocess_data({'tasks': [], 'post_tasks': [], 'pre_tasks': [], 'handlers': []})

# Generated at 2022-06-25 05:24:48.471499
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    try:
        play_0.get_name()
    except:
        return False

    play_1 = Play()
    play_1._ds = {'name': 'test1'}
    try:
        play_1.get_name()
    except:
        return False

    return True


# Generated at 2022-06-25 05:24:58.205627
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()

    ds = """
    - name: Test play
      hosts: all
      vars:
        http_port: 80
        max_clients: 200
      roles:
        - role1
      tasks:
        - name: task1
          debug:
            msg: this is task1
        - name: task2
          debug:
            msg: this is task2
    """
    new_ds = play_0.preprocess_data(ds)
    print(new_ds)

if __name__ == "__main__":
    test_case_0()
    test_Play_preprocess_data()

# Generated at 2022-06-25 05:25:05.964163
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_raw_0 = dict()
    play_raw_0['roles'] = list()
    play_raw_0['roles'].append(dict(role_raw_00))
    play_raw_1 = dict()
    play_raw_1['roles'] = list()
    play_raw_1['roles'].append(dict(role_raw_00))
    play_raw_1['roles'].append(dict(role_raw_01))
    play_0 = Play()
    play_1 = Play()    
    play_0.deserialize(play_raw_0)
    print("%s" % play_0.roles[0].get_name())
    play_1.deserialize(play_raw_1)

# Generated at 2022-06-25 05:25:11.327377
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    play_1 = Play()
    #this attribute is set to a function, which can't be serialized
    play_1.vars_prompt = lambda: None
    #this attribute is set to a function, which can't be serialized
    play_1.ROLE_CACHE = {}
    play_1.included_path = None
    play_1.action_groups = {}
    play_1.group_actions = {}
    data = play_1.serialize()
    play_2 = Play()
    play_2.deserialize(data)

    assert play_1.vars == play_2.vars, 'Attribute vars mismatch'
    assert play_1.name == play_2.name, 'Attribute name mismatch'

# Generated at 2022-06-25 05:25:16.344520
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data_0 = {}
    data_1 = {}

    play_0 = Play()
    data_0 = play_0.preprocess_data(data=data_1)
    assert data_0 == {}


# Generated at 2022-06-25 05:25:21.497869
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create play object
    play = Play()

    # Initialize variables
    data = dict()

    # Call method to test
    try:
        play.preprocess_data(data)
        assert False
    except AnsibleAssertionError as e:
        # Check if exception is expected
        assert str(e) == 'while preprocessing data ({}), ds should be a dict but was a <class \'NoneType\'>'.format(data)



# Generated at 2022-06-25 05:25:35.287239
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_instance = Play()
    play_instance.tasks = [Task(), ]
    tasks_list = play_instance.get_tasks()
    assert( isinstance(tasks_list, list) )
    assert( isinstance(tasks_list[0], Task) )


# Generated at 2022-06-25 05:25:39.308427
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    if play_0.__class__.__name__ != 'Play':
        raise AssertionError("Attribute class type is not: {}" .format(play_0.__class__.__name__))

    if play_0.__class__.__name__ not in ('Play'):
        raise AssertionError("Expected: {}, got: {}" .format('Play', play_0.__class__.__name__))


# Generated at 2022-06-25 05:25:40.898011
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    var_files = play_0.get_vars_files()



# Generated at 2022-06-25 05:25:42.804852
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_case_0()

if __name__ == '__main__':
    test_Play_get_vars_files()

# Generated at 2022-06-25 05:25:51.403521
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    test_play = Play.load(dict(
        name = "Test Play 0",
        hosts = "all",
        gather_facts = False,

        roles = [
            # dummy role to test play_compile_roles_handlers
            dict(
                name = "Test_role",
                tasks = [
                    dict(
                        name = "echo host_ip",
                        debug = dict(
                            msg = "{{ host_ip }}"
                        )
                    )
                ],
                handlers = [
                    dict(
                        name = "always handler",
                        debug = dict(
                            msg = "always handler executed"
                        )
                    )
                ]
            )
        ]
    ))

    handlersList = test_play.compile_roles_handlers()

    #test Play.compile_roles_handlers

# Generated at 2022-06-25 05:25:52.021893
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-25 05:25:57.321307
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()

    if play_0.serialize() is not None:
        print("Test Play serialize Passed")
    else:
        print("Test Play serialize Failed")


# Generated at 2022-06-25 05:26:02.490514
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data = dict()
    data['name'] = 'test'
    play_0.deserialize(data)


# Generated at 2022-06-25 05:26:08.120591
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    global play_0
    play_0 = Play()

    with pytest.raises(AnsibleAssertionError):
        play_0.preprocess_data({'my_file': 'sample_file.yaml'})

    with pytest.raises(AnsibleAssertionError):
        play_0.preprocess_data(['a', 'b', 'c'])

    assert play_0.preprocess_data({'hosts':'test', 'become_user':'root'}) == {'hosts':'test', 'become_user':'root'}
    assert play_0.preprocess_data({'user':'test', 'become':'root'}) == {'remote_user':'test', 'become':'root'}


# Generated at 2022-06-25 05:26:12.069770
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    play_1.serialize()


# Generated at 2022-06-25 05:26:35.689062
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    # when 'vars_files' is None, play_0.get_vars_files() should return []
    var_0 = play_0.get_vars_files()
    assert(var_0 == [])
    play_0.vars_files = []
    # when 'vars_files' is [], play_0.get_vars_files() should return []
    var_0 = play_0.get_vars_files()
    assert(var_0 == [])
    play_0.vars_files = ''
    # when 'vars_files' is '', play_0.get_vars_files() should return ['']
    var_0 = play_0.get_vars_files()
    assert(var_0 == [''])
    play

# Generated at 2022-06-25 05:26:41.968587
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Setup
    play_0 = Play()
    play_0._ds['name'] = 'test_play'
    play_0._ds['hosts'] = 'localhost'
    play_0._ds['roles'] = [{'role': 'test_role_0'}, {'role': 'test_role_1'}]
    role_0 = RoleInclude()
    role_0._data_struct = {'role': 'test_role_0'}
    role_0._role_name = 'test_role_0'
    role_0._play = play_0
    role_1 = RoleInclude()
    role_1._data_struct = {'role': 'test_role_1'}
    role_1._role_name = 'test_role_1'
    role_1._play = play_

# Generated at 2022-06-25 05:26:49.616885
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0._tasks = []
    play_0._pre_tasks = []
    play_0._post_tasks = []
    tasklist = play_0.get_tasks()
    assert True


# Generated at 2022-06-25 05:26:56.333308
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # we create a fake play with a role to test that role handlers are sorted correctly
    p = Play()

    # create a fake role, with a handler
    r = Role()
    r._role_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'roles', 'test_role')
    r.load_data(os.path.join(r._role_path, 'meta', 'main.yml'))

    # add the role to the play
    p.roles.append(r)

    # store the compiled handlers in a list.
    # we will check the order later
    handlers = []
    for h in p.compile_roles_handlers():
        handlers.append(h)

    # the compiled handlers should be in the same order
    # as

# Generated at 2022-06-25 05:26:58.090932
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test case setup
    play_0 = Play()
    # Test case execution
    test_case_0()
    test_case_1()
    test_case_2()
    # Test case verification


# Generated at 2022-06-25 05:27:03.840880
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_ds = dict(
        vars_files = [
            'vars_file0',
            'vars_file1'
        ]
    )
    play = Play()
    play.load_data(play_ds)
    assert play.get_vars_files() == ['vars_file0', 'vars_file1']


# Generated at 2022-06-25 05:27:12.244544
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.tasks = [{'task': {'task_1': {'action': 'debug'}}}, {'meta': 'flush_handlers'}]
    play_1.handlers = [{'handler': {'handler_1': {'action': 'debug'}}}, {'meta': 'flush_handlers'}]
    play_1.post_tasks = [{'task': {'task_2': {'action': 'debug'}}}]
    play_1.pre_tasks = [{'task': {'task_0': {'action': 'debug'}}}]

# Generated at 2022-06-25 05:27:18.485260
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    play_1 = Play()
    play_1.pre_tasks = [ Task(name='task_a'), Task(name='task_b'), Task(name='task_c') ]
    play_1.tasks = [ Task(name='task_d'), Task(name='task_e'), Task(name='task_f') ]
    play_1.post_tasks = [ Task(name='task_g'), Task(name='task_h'), Task(name='task_i') ]

    # get_tasks should return an array with all elements of pre_tasks
    # and tasks and post_tasks
    tasks = play_1.get_tasks()

    assert len(tasks) == 9
    assert tasks[0].name == 'task_a'
    assert tasks[1].name == 'task_b'

# Generated at 2022-06-25 05:27:28.847961
# Unit test for method serialize of class Play
def test_Play_serialize():
	# Test Play.serialize using data from test case 0
	play_0 = Play()
	result_0 = play_0.serialize()
	
	# Expected result:
	expected_result_0 = {}
	expected_result_0['hosts'] = []
	expected_result_0['name'] = ''
	expected_result_0['vars'] = {}
	expected_result_0['vars_prompt'] = []
	expected_result_0['vars_files'] = []
	expected_result_0['roles'] = []
	expected_result_0['included_path'] = None
	expected_result_0['action_groups'] = {}
	expected_result_0['group_actions'] = {}
	
	assert result_0 == expected_result_0, "Test Case 0 Failed !"

# Generated at 2022-06-25 05:27:31.465211
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()

    # This test should pass, so we don't check the return value
    play_1.get_vars_files()

    # This test should pass, so we don't check the return value
    play_1.get_vars_files()


# Generated at 2022-06-25 05:27:40.564504
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    assert(play_1.get_tasks() == [])


# Generated at 2022-06-25 05:27:50.108646
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_case_0()
    play_1 = Play()
    roles_1 = [{"tasks": [{"action": "include_role", "args": {"name": "test_role", "tasks_from": "main"}}], "vars": {"role_var1": "role_var1_value", "role_var2": {"role_var2_key1": "role_var2_key1_value", "role_var2_key2": "role_var2_key2_value"}}}]
    variable_manager_1 = ansible_vars_1 = None
    loader_1 = ansible_vars_2 = None
    setattr(play_1, 'roles', roles_1)

# Generated at 2022-06-25 05:27:51.969270
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    
    #Test in case of successful compilation
    play_1.roles = [Role(), Role()]
    assert len(play_1.compile_roles_handlers()) == 4


# Generated at 2022-06-25 05:28:00.700384
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    #play = Play()
    print("get_vars_files")
    test_case = "test"
    play_0 = Play()
    expected1 = True
    try:
        play_0.get_vars_files()
        expected2 = True
    except:
        expected2 = False
    assert (expected1 == expected2)
    print("--- get_roles ---")
    expected1 = True
    try:
        play_0.get_roles()
        expected2 = True
    except:
        expected2 = False
    assert (expected1 == expected2)
    print("--- get_vars ---")
    expected1 = True
    try:
        play_0.get_vars()
        expected2 = True
    except:
        expected2 = False
    assert (expected1 == expected2)

# Generated at 2022-06-25 05:28:06.125705
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test_play"
    assert play.get_name() == "test_play"
    play.name = None
    assert play.get_name() == ""


# Generated at 2022-06-25 05:28:12.330024
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.set_loader(DictDataLoader({}))
    play.vars_files = ['/path/to/file', '/path/to/other/file']
    assert play.get_vars_files() == play.vars_files


# Generated at 2022-06-25 05:28:18.064915
# Unit test for method get_name of class Play
def test_Play_get_name():
    data = dict(
        name='somePlay', hosts='localhost',
    )
    play = Play.load(data=data, variable_manager=VariableManager(), loader=None)
    assert play.get_name() == 'somePlay'


# Generated at 2022-06-25 05:28:19.646874
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.get_vars_files().__eq__([])


# Generated at 2022-06-25 05:28:22.600911
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_1 = Play()
    res = play_0.serialize()
    assert res == {}
    res = play_1.serialize()
    assert res == {}


# Generated at 2022-06-25 05:28:26.982103
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    block_list = play_0.compile_roles_handlers()
    assert block_list == []


# Generated at 2022-06-25 05:28:59.111453
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_1.preprocess_data({'user': 'test', 'foo': 'bar'})
    assert play_1.get_ds().get('remote_user') == 'test'
    assert play_1.get_ds().get('user') == None
    assert play_1.get_ds().get('foo') == 'bar'


# Generated at 2022-06-25 05:29:00.514470
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    assert play_0.compile_roles_handlers() == []


# Generated at 2022-06-25 05:29:03.147553
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0_result = play_0.compile_roles_handlers()
    assert True


# Generated at 2022-06-25 05:29:14.872289
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()

    task_list = play_0.get_tasks()
    assert task_list is None, "Line: {0}".format(inspect.stack()[0][2])


if __name__ == '__main__':
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    cur_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(cur_dir, "test_play.yml")

# Generated at 2022-06-25 05:29:22.535162
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_1 = Play()
    play_1.name = 'myplay'
    play_2 = Play()
    play_2.hosts = 'myhosts'

    # test get_name
    play_0.get_name()
    play_1.get_name()
    play_2.get_name()

    play_3 = Play()
    play_4 = Play()
    play_4.name = 'myplay'
    play_5 = Play()
    play_5.hosts = 'myhosts'

    # test without input, return empty string
    assert play_0.get_name() == ''

    # test with input, return name
    assert play_1.get_name() == 'myplay'

# Generated at 2022-06-25 05:29:28.202276
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.vars = dict()
    play_0.vars_files = []
    play_0.role_vars = dict()
    play_0.playbook_dir = 'playbook_dir'
    play_0.roles_path = 'roles_path'
    play_0.boolean = True
    play_0.hosts = 'hosts'
    play_0.remote_user = 'remote_user'
    play_0.name = 'name'
    play_0.force_handlers = True
    play_0.max_fail_percentage = 0.5
    play_0.serial = 0
    play_0.strategy = 'strategy'
    play_0.no_log = True
    play_0.check_mode = True


# Generated at 2022-06-25 05:29:37.709642
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    def get_vars_files(self):
        return self.vars_files

    play_1 = Play()
    play_1._ds['vars_files'] = 'tests\data\playbook_vars_files.yaml'
    expected_get_vars_files = [play_1.vars_files]
    actual_get_vars_files = get_vars_files(play_1)

    try:
        assert expected_get_vars_files == actual_get_vars_files
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 05:29:38.513138
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 05:29:43.101687
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # create an instance of class Play
    play_0 = Play.load(data=dict(
                        gather_facts='no',
                        hosts='all',
                        vars_files=['../vars/all.yml']
    ))
    assert play_0.get_vars_files() == ['../vars/all.yml']

# Generated at 2022-06-25 05:29:45.760247
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()

    #print build_list_of_roles(play_1.get_roles())
    #print play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:30:11.621541
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,',)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostname = 'localhost'

# Generated at 2022-06-25 05:30:20.026156
# Unit test for method serialize of class Play
def test_Play_serialize():
    expected = {'gather_facts': True,
                'name': '',
                'vars': {},
                'vars_files': [],
                'vars_prompt': None,
                'connection': 'smart',
                'max_fail_percentage': None,
                'serial': [],
                'strategy': 'linear',
                'tags': [],
                'tasks': [],
                'handlers': [],
                'pre_tasks': [],
                'post_tasks': [],
                'hosts': '',
                'roles': [],
                'included_path': None,
                'action_groups': {},
                'group_actions': {}}
    play_0 = Play()
    obj = play_0.serialize()
    assert obj == expected

#

# Generated at 2022-06-25 05:30:27.667947
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    play_1.vars_files = []
    assert play_1.get_vars_files() == []
    play_1.vars_files = 'abc'
    assert play_1.get_vars_files() == ['abc']
    play_1.vars_files = ['abc']
    assert play_1.get_vars_files() == ['abc']


# Generated at 2022-06-25 05:30:34.884477
# Unit test for method get_name of class Play
def test_Play_get_name():
    have_passed = True

    play_0 = Play()
    play_0.name = "test_Play_get_name_0"
    expected_result = "test_Play_get_name_0"
    actual_result = play_0.get_name()
    if expected_result != actual_result:
        have_passed = False
        print('Test 0 of 1 in test_Play_get_name() failed:')
        print('Expected:')
        print(expected_result)
        print('But was:')
        print(actual_result)

    if have_passed:
        print('All tests in test_Play_get_name() passed')
    else:
        print('*** A test in test_Play_get_name() failed ***')


# Generated at 2022-06-25 05:30:36.961275
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    vars_files = play_1.get_vars_files()
    assert vars_files == []


# Generated at 2022-06-25 05:30:46.845728
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = [
        Task(action=dict(module='setup'), name='setup'),
    ]
    play_0.tasks = [
        Task(action=dict(module='debug', var1='value1'), name='debug 1'),
        Task(action=dict(module='command', args="/bin/true"), name='command 1')
    ]
    play_0.post_tasks = [
        Task(action=dict(module='debug', var1='value2'), name='debug 2'),
        Task(action=dict(module='command', args="/bin/false"), name='command 2')
    ]

# Generated at 2022-06-25 05:30:52.967825
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    # Test deserialize with play_data_0 as data
    play_0 = Play.deserialize(play_data_0)

    assert play_0.hosts is None
    assert play_0.name == ''
    assert play_0.tasks is None
    assert play_0.vars is None
    assert play_0.roles is None
    assert play_0.handlers is None



# Generated at 2022-06-25 05:31:00.414624
# Unit test for method serialize of class Play
def test_Play_serialize():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    if six.PY3:
        builtin_open = 'builtins.open'
    else:
        builtin_open = '__builtin__.open'
    source = 'string'
    line_no = 100
    column = 200
    AnsibleBaseYAMLObject.add_to_class('__slots__', ('source', 'line_no', 'column'))
    AnsibleBaseYAMLObject.add_to_class('source', source)
    AnsibleBaseYAMLObject.add_to_class('line_no', line_no)
    AnsibleBaseYAMLObject.add_to_

# Generated at 2022-06-25 05:31:07.509896
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    Unit test for method Play.get_vars_files
    '''
    play_0 = Play()
    var_files = play_0.get_vars_files()
    assert var_files == []

    play_1 = Play()
    play_1.vars_files = None
    var_files = play_1.get_vars_files()
    assert var_files == []

    play_2 = Play()
    play_2.vars_files = "path/to/vars_file"
    var_files = play_2.get_vars_files()
    assert var_files == ["path/to/vars_file"]

    play_3 = Play()

# Generated at 2022-06-25 05:31:12.146291
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play() # Default constructor parameters
    assert play_1.get_name() == ''


# Generated at 2022-06-25 05:31:59.007593
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    test_play = Play()
    test_play._ds = {'block': ['1']}

    test_play.preprocess_data(test_play._ds)


# Generated at 2022-06-25 05:32:04.915512
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    # play_0._compile_roles is not called at this time
    play_0._compile_roles_handlers()
    play_0._compile_roles()
    play_0._compile_roles_handlers()


# Generated at 2022-06-25 05:32:08.988646
# Unit test for method serialize of class Play
def test_Play_serialize():
    # test raise exception if wrong arguments are passed
    # test return the serialized dict
    pass


# Generated at 2022-06-25 05:32:10.849228
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.get_name() == ""


# Generated at 2022-06-25 05:32:17.261420
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_2 = Play()
    play_1.ds = play_2.ds = dict({
        'name': 'test play_0',
        'user': 'root',
        'hosts': 'localhost',
        'vars': dict(),
        'tasks': list()
    })
    play_1.preprocess_data(play_1.ds)
    assert 'user' not in play_1.ds
    assert 'remote_user' in play_1.ds


# Generated at 2022-06-25 05:32:19.288501
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play.load(filename=config_data.get('playbooks')[0], variable_manager=variable_manager)
    p.serialize()


# Generated at 2022-06-25 05:32:21.114016
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    result = play_0.compile_roles_handlers()
    assert result == []


# Generated at 2022-06-25 05:32:26.931331
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # verify given data is not None
    assert test_case_0() is not None

    play_0 = Play()
    task_list = play_0.get_tasks()
    #verify task_list is of type list
    assert isinstance(task_list, list)

# Generated at 2022-06-25 05:32:36.873671
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # Test data for preprocess_data
    play_1 = Play()
    ds_1 = {
        'hosts':
            '{{ inventory_dir }}/{{ env }}/hosts',
        'user':
            '{{ remote_user }}',
        'vars': {
            'foo':
                '{{ env }}.foo'
        },
        'vars_files': [
            '/etc/ansible/foo.yml',
            '/etc/ansible/bar.yml'
        ],
        'include_vars': {
            'file':
                '{{ inventory_dir }}/{{ env }}/host_vars/{{ inventory_hostname }}'
        },
        'remote_user':
            'superuser'
    }

    # Expected value

# Generated at 2022-06-25 05:32:40.196085
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    assert play_1.get_name() == ''
