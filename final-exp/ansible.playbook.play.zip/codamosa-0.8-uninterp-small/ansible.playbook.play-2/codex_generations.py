

# Generated at 2022-06-25 05:24:22.697614
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({})


# Generated at 2022-06-25 05:24:26.301094
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()

    play_0.roles.append(Role())
    expected_result = []
    result = play_0.compile_roles_handlers()
    assert result == expected_result


# Generated at 2022-06-25 05:24:36.032372
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    fl_yml_0 = '''
    - shell: ls
    '''
    task_0 = Task()
    task_0.load_data(fl_yml_0)

    fl_yml_1 = '''
    - name: sssssssss
      shell: ls
    '''
    task_1 = Task()
    task_1.load_data(fl_yml_1)

    hosts = [
              'test_host_0',
              'test_host_1'
            ]
    play_0 = Play()
    play_0.hosts = hosts
    play_0.tasks = [
                      task_0,
                      task_1
                   ]
    play_0.pre_tasks = play_0.post_tasks = []
    res = play_0.get_

# Generated at 2022-06-25 05:24:38.421666
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    #print(repr(play_0.compile_roles_handlers()))


# Generated at 2022-06-25 05:24:47.912057
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = [Role()]
    result = play_1.compile_roles_handlers()
    assert result == []
    play_2 = Play()
    play_2.roles = [Role()]
    role = play_2.roles[0]
    role.handler_blocks = []
    result = play_2.compile_roles_handlers()
    assert result == []
    play_3 = Play()
    play_3.roles = [Role()]
    role = play_3.roles[0]
    role.handler_blocks = [Block()]
    result = play_3.compile_roles_handlers()
    assert result == [Block()]


# Generated at 2022-06-25 05:24:50.119270
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pl = Play()
    pl.tasks = ['ls', 'tac']
    assert pl.get_tasks() == ['ls', 'tac']



# Generated at 2022-06-25 05:24:54.531822
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.hosts = '1'
    assert play_0.get_name() == '1'


# Generated at 2022-06-25 05:24:59.205355
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
        play_1 = Play()
        block_list = play_1.compile_roles_handlers()
        assert block_list == []



# Generated at 2022-06-25 05:25:07.876619
# Unit test for method serialize of class Play
def test_Play_serialize():

    # the result is dictionary
    result = Play.load(dict(hosts='all', 
        roles=['whatever'], 
        vars=dict(a=1), 
        tasks=[dict(name='test', shell='ls /tmp')])).serialize()

    expected_result = dict(vars=dict(a=1), 
        hosts='all', 
        roles=dict(name='whatever'), 
        tasks=dict(name='test', shell='ls /tmp'))

    assert result == expected_result, 'Expected: %s, but got: %s' % (expected_result, result)

# Generated at 2022-06-25 05:25:18.479065
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "Test"
    assert play_0.get_name() == "Test"
    play_0.name = ""
    play_0.roles = [Role() for i in range(3)]
    for i in range(3):
        play_0.roles[i].name = "Role" + str(i)
    play_0._roles = [play_0.roles[0], play_0.roles[1]]
    assert play_0.get_name() == "Role0,Role1"
    play_0.name = ""
    play_0.hosts = ["Hosts0", "Hosts1", "Hosts2"]
    play_0._hosts = play_0.hosts[:2]
    assert play_0.get_

# Generated at 2022-06-25 05:25:30.192904
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    play_1.deserialize({'hosts': 'hosts', 'name': 'My_Play_Name'})
    if (play_1.name != 'My_Play_Name'):
        raise Exception('play_1.name = {0}, expected My_Play_Name'.format(play_1.name))
    if type(play_1.vars) is not dict:
        raise Exception('type(play_1.vars) = {0}, expected dict'.format(type(play_1.vars)))
    if type(play_1.vars_file) is not list:
        raise Exception('type(play_1.vars_file) = {0}, expected list'.format(type(play_1.vars_file)))

# Generated at 2022-06-25 05:25:31.352186
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'test'
    assert play_1.get_name() == 'test'


# Generated at 2022-06-25 05:25:32.328625
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()

    assert play_0.get_tasks() == []


# Generated at 2022-06-25 05:25:43.977910
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data_0 = {}
    data_0['vars'] = {}
    data_0['vars']['vars_file'] = ['test_0']
    data_0['vars']['user'] = 'user_1'
    data_0['vars']['max_fail_percentage'] = 'max_fail_percentage_2'
    data_0['vars']['include_vars'] = ['test_3']
    data_0['vars']['vars_prompt'] = []
    data_0['vars']['vars_prompt'].append({})
    data_0['vars']['vars_prompt'][0]['name'] = 'name_4'

# Generated at 2022-06-25 05:25:46.788420
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds = {}
    play_0.preprocess_data(ds)
    ds = {}
    play_0.preprocess_data(ds)
    ds = {}
    play_0.preprocess_data(ds)


# Generated at 2022-06-25 05:25:50.840061
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    
    # play_0 = Play()
    # play_0._load_roles()
    pass
    # TODO: implement test


# Generated at 2022-06-25 05:25:58.463922
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    play_0 = Play()
    playbook_play_0 = Play()
    playbook_play_0.vars_files = [
        'group_vars/app1.yml',
        'group_vars/app2.yml'
    ]
    # Test when vars_files is a list
    assert playbook_play_0.get_vars_files() == ['group_vars/app1.yml', 'group_vars/app2.yml']

    playbook_play_0.vars_files = 'group_vars/all.yml'
    # Test when vars_files is not a list
    assert playbook_play_0.get_vars_files() == ['group_vars/all.yml']

# Generated at 2022-06-25 05:26:02.896780
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    play_0.deserialize(None)
    play_0.deserialize(dict())
    play_0.deserialize({'name': 'test'})


# Generated at 2022-06-25 05:26:10.787119
# Unit test for method get_name of class Play
def test_Play_get_name():
    example_0 = Play()
    example_1 = Play()
    example_1.name = "A string"
    example_2 = Play()
    example_2.hosts = "A string"
    example_3 = Play()
    example_3.name = "A string"
    example_3.hosts = "A string"
    expected_0 = ""
    expected_1 = "A string"
    expected_2 = "A string"
    expected_3 = "A string"
    obtained_0 = example_0.get_name()
    obtained_1 = example_1.get_name()
    obtained_2 = example_2.get_name()
    obtained_3 = example_3.get_name()
    assert obtained_0 == expected_0
    assert obtained_1 == expected_1
    assert obtained_

# Generated at 2022-06-25 05:26:11.578287
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass


# Generated at 2022-06-25 05:26:20.753300
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.name == '', "Checking if play.name is correctly set."
    play.name = 'p0'
    assert play.get_name() == 'p0', "Checking if get_name() is correctly returning name of the play."


# Generated at 2022-06-25 05:26:25.023751
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = [
        ("<1>", "<2>"),
        ("<3>", "<4>")
    ]
    result = play_1.compile_roles_handlers()
    assert result[0] == "<3>" and result[1] == "<1>" and result[2] == "<4>" and result[3] == "<2>"


# Generated at 2022-06-25 05:26:31.151555
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Set up of unit test
    def test_tasks():
        tasks = []
        for task in play_0.get_tasks():
            tasks.append(task)
        return tasks
    # Execute test
    play_0.tasks = 'test'
    tasks = test_tasks()
    # Assertions
    assert [tasks] == [['test']]

# Generated at 2022-06-25 05:26:36.853912
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    playbook = Play()
    ansible_playbook_cli = context.CLIARGS
    if 'vars_files' in ansible_playbook_cli:
        playbook.vars_files = ansible_playbook_cli['vars_files']
    assert playbook.vars_files == ansible_playbook_cli['vars_files']


# Generated at 2022-06-25 05:26:46.592492
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_data_1 = {
        'hosts': 'localhost',
        'user': 'root',
        'vars': {
        'var2': 2
        },
        'tasks': [
        {
            'name': 'test',
            'debug': 'msg="{{ var1 }} || {{ var2 }}"'
        }
        ],
        'roles': [
        'test'
        ]
    }

# Generated at 2022-06-25 05:26:54.253086
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    Test to verify if a given datastructure can be used to load a
    new Play.
    '''

    # Test Case 1:
    play_1 = Play()
    play_1.name = 'Play 1'
    play_1.hosts = 'testhost1'
    play_1.vars = dict(value1=1)

    tasks_1 = [ dict(action=dict(module='debug', args=dict(msg='Hello from Play 1'))) ]

    play_1.tasks = tasks_1

    # Test Case 2:
    play_2 = Play()
    play_2.name = 'Play 2'
    play_2.hosts = 'testhost2'
    play_2.vars = dict(value1=1)


# Generated at 2022-06-25 05:27:04.114807
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-25 05:27:12.454891
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    play_1.set_loader(DictDataLoader({}))
    play_1.set_variable_manager(VariableManager())

# Generated at 2022-06-25 05:27:17.606000
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    # Desired behavior
    '''
    If the vars_files is None, then return an empty list:
    If the vars_files is a list, then return the vars_files
    If the vars_files is not a list, then convert it to a list and return it
    '''

    # Variables
    test_cases = [
        None,
        [],
        ['vars_files_1'],
        ['vars_files_1', 'vars_files_2'],
        ['vars_files_1', 'vars_files_2', 'vars_files_3'],
        'vars_files_1',
        'vars_files_1,vars_files_2,vars_files_3'
    ]

    # Test

# Generated at 2022-06-25 05:27:19.007403
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    play_0.deserialize(None)


# Generated at 2022-06-25 05:27:27.145821
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = "test-play-name"
    failure_message = "Failed to return the correct name"
    assert_equal(play_1.get_name(), "test-play-name", failure_message)



# Generated at 2022-06-25 05:27:30.736637
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Initializing variables
    play_0 = Play()
    data = {}
    # This is just to check the running of test cases.
    test_Play_copy(play_0)
    # Execute method deserialize
    play_0.deserialize(data)
    # Check instance of class Play
    assert isinstance(play_0, Play)


# Generated at 2022-06-25 05:27:35.406798
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # For this test we will create a play, add some tasks,
    # and then call get_tasks.  We will then compare the tasks
    # to the ones we added to the play to ensure that the tasks
    # are returned.
    task1 = Task()
    task2 = Task()
    task3 = Task()

    task_list = []
    task_list.append(task1)
    task_list.append(task2)
    task_list.append(task3)

    role = Role()
    role.tasks = task_list

    play = Play()
    play.tasks = task_list

    assert play.get_tasks() == [task1, task2, task3]


# Generated at 2022-06-25 05:27:41.079949
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    assert play.serialize() is not None
    assert play.serialize() == dict()
    assert play.serialize() == {}

    # Define all attributes:
    play.name = "play"
    play.hosts = "hosts"
    play.remote_user = "remote_user"
    play.connection = "connection"
    play.port = "port"
    play.gather_facts = "gather_facts"
    play.vars_prompt = "vars_prompt"
    play.vars_prompt_except = "vars_prompt_except"
    play.any_errors_fatal = "any_errors_fatal"
    play.serial = "serial"
    play.transport = "transport"
    play.tags = "tags"
   

# Generated at 2022-06-25 05:27:45.704722
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_files = [{
        "vars_files": [
            "/home/ansible/vars_files/project/vars.yml"
        ]
    }]
    play = Play()
    play._ds = vars_files
    assert play.get_vars_files() == vars_files[0].get('vars_files')


# Generated at 2022-06-25 05:27:55.583730
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-25 05:28:04.230656
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    unittest.TestCase.maxDiff = None
    play_1 = Play()
    play_1.hosts = "host_0"
    play_1.name = "test_name_2"
    play_1._loader = DataLoader()
    play_1._variable_manager = VariableManager()
    data_1 = {
        'include_role': {
            'name': "role_name_0",
            'metadata': {
                'dependencies': [
                    {
                        'role': "role_name_1",
                        'scenario': "scenario_4"
                    }
                ]
            }
        }
    }
    RoleInclude_1 = RoleInclude()
    RoleInclude_1.load_data(data=data_1)

# Generated at 2022-06-25 05:28:05.624596
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    assert play_0.preprocess_data(play_0._ds) == play_0._ds


# Generated at 2022-06-25 05:28:10.326616
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Constructor test
    test_case_0()
    # Instantiate a dict object
    dict1 = dict()
    dict2 = dict()

    play_0 = Play()
    play_0.deserialize(dict1)

    # Deserialize the play
    play_0.deserialize(dict2)
    # Check if the returned play is valid
    assert isinstance(play_0.deserialize(dict2), Play)



# Generated at 2022-06-25 05:28:13.313003
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2]
    play.tasks = [3, 4]
    play.post_tasks = [5, 6]
    play.handlers = [7, 8]

    assert play.get_tasks() == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-25 05:28:27.184786
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.get_name() == ''


# Generated at 2022-06-25 05:28:33.034858
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds = (1)
    try:
        play_0.preprocess_data(ds)
    except AssertionError:
        pass
    except Exception as e:
        assert False, "unexpected exception occurred: " + str(e)


# Generated at 2022-06-25 05:28:43.158569
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:28:51.896285
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    tasks = [
        {'name': 'gather facts', 'action': 'setup'},
        {'name': 'create a file', 'action': 'copy', 'dest': "/tmp/test"},
        {'name': 'create a directory', 'action': 'file', 'dest': "/tmp/dir/", 'state': 'directory'},
        {'name': 'remove a file', 'action': 'file', 'state': 'absent', 'dest': "/tmp/test"},
        {'name': 'remove a directory', 'action': 'file', 'state': 'absent', 'dest': "/tmp/dir/"},
    ]

    # create a play_0 object
    play_0 = Play()
    play_0.vars = {'ansible_default_remote_user': 'user'}

# Generated at 2022-06-25 05:28:58.433373
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    assert play_0.compile_roles_handlers() == []

    play_1 = Play()
    play_1.roles = [Role()]
    role_1 = play_1.roles[0]
    role_1.get_handler_blocks = lambda **kwargs: []
    assert play_1.compile_roles_handlers() == []


# Generated at 2022-06-25 05:29:07.831564
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = list()
    expected_0 = list()
    actual_0 = play_0.get_vars_files()
    assert expected_0 == actual_0

    play_1 = Play()
    play_1.vars_files = {}
    expected_1 = [{}]
    actual_1 = play_1.get_vars_files()
    assert expected_1 == actual_1

    play_2 = Play()
    play_2.vars_files = list()
    expected_2 = list()
    actual_2 = play_2.get_vars_files()
    assert expected_2 == actual_2



# Generated at 2022-06-25 05:29:09.105058
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds = {}
    assert play_0.preprocess_data(ds) == ds


# Generated at 2022-06-25 05:29:15.146721
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.add_block(Block.load(
        data={'block': [
            {'meta': 'flush_handlers'},
            {'debug': 'msg=foo'}
        ]},
        play=play,
        variable_manager=None,
        loader=None
    ))
    play.blocks.append("bar")
    play.blocks.append("baz")
    assert play.get_tasks() == [[{'meta': 'flush_handlers'}], {'debug': 'msg=foo'}, 'bar', 'baz'], play.get_tasks()


# Generated at 2022-06-25 05:29:25.567400
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    def test_gen_ds():
        play_1 = Play()

# Generated at 2022-06-25 05:29:26.454492
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_Play()



# Generated at 2022-06-25 05:29:45.557688
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1=Play()
    play_1.removed_hosts=["127.0.0.1"]
    play_1.hosts=["127.0.0.1"]
    play_1.roles=[RoleInclude()]
    play_1._loader=Mock()
    play_1._loader.get_basedir.return_value='/tmp'
    #
    res=play_1.compile_roles_handlers()
    #test conditions
    assert len(res)==0
    assert res==[]


# Generated at 2022-06-25 05:29:53.369701
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    p = Play()
    p.tasks = []
    p.roles = []
    p.pre_tasks = []
    p.post_tasks = []

    p.roles.append(Role())
    p.roles.append(Role())

    assert isinstance(p.compile_roles_handlers(), list)
    assert p.compile_roles_handlers() == []

    for role in p.roles:
        role.handler_blocks = [Task()]

    assert isinstance(p.compile_roles_handlers(), list)
    assert len(p.compile_roles_handlers()) == 2
    assert all(isinstance(x, Task) for x in p.compile_roles_handlers())

    for role in p.roles:
        role.handler_

# Generated at 2022-06-25 05:29:58.116159
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    block_list_0 = play_0.compile_roles_handlers()
    print(block_list_0)


# Generated at 2022-06-25 05:30:01.575873
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    """ test_Play_deserialize """
    play_1 = Play()
    play_1.deserialize({'name': 'play_1', 'hosts': 'localhost'})


# Generated at 2022-06-25 05:30:09.260472
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-25 05:30:14.830902
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.serialize()

Play.register_attribute(name='hosts', field_class=FieldAttribute)
Play.register_attribute(name='name', field_class=FieldAttribute)
Play.register_attribute(name='connection', field_class=HostAttribute)
Play.register_attribute(name='gather_facts', field_class=HostAttribute)
Play.register_attribute(name='no_log', field_class=HostAttribute)


# Generated at 2022-06-25 05:30:21.950710
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_ = Play()
    play_._tasks = [
        {'name': 'task_1', 'action': 'debug'},
        {'name': 'task_2', 'action': 'debug'},
        {'name': 'task_3', 'action': 'debug'},
    ]


# Generated at 2022-06-25 05:30:24.695931
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Tests the Play.get_tasks() method.
    play_s = Play()
    play_s.get_tasks()


# Generated at 2022-06-25 05:30:26.768300
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test 0
    play_0 = Play()
    assert play_0.compile_roles_handlers == []


# Generated at 2022-06-25 05:30:34.554054
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()

# Generated at 2022-06-25 05:30:50.876695
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = test_case_0()
    assert play_0.get_name() == '', "Unit Test Failed: Play_get_name()"

# Generated at 2022-06-25 05:30:57.933467
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    if p.get_vars_files() is not []:
        raise Exception('Play.get_vars_files() should return an empty list by default')
    p.vars_files = None
    if p.get_vars_files() is not []:
        raise Exception('Play.get_vars_files() should return an empty list if vars_files is set to None')
    p.vars_files = '/path/to/vars.yml'
    if p.get_vars_files() != ['/path/to/vars.yml']:
        raise Exception('Play.get_vars_files() should return a list with one element if vars_files is set to a string')

# Generated at 2022-06-25 05:31:04.554399
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data = {'name': 'test_Play_deserialize_name',
            'hosts': 'test_Play_deserialize_hosts',
            'vars': {'key_0': 'value_0'},
            'roles': [{'name': 'test_Play_deserialize_Roles_name',
                       'tasks': [{'action': 'test_Play_deserialize_Tasks_action',
                                  'name': 'test_Play_deserialize_Tasks_name'}]}]}
    data['roles'][0]['tasks'][0]['action'] = {'key_0': 'value_0'}

# Generated at 2022-06-25 05:31:05.703961
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    print(play_0.compile_roles_handlers())


# Generated at 2022-06-25 05:31:06.927660
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.serialize()


# Generated at 2022-06-25 05:31:12.428003
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Uncomment to start debugging
    #import pdb; pdb.set_trace()

    # Setup
    play = Play()

    # Test function call
    Test = play.compile_roles_handlers()

    # Test assertions
    #assert eq_test
    eq_(Test, play.compile_roles_handlers())

test_Play_compile_roles_handlers()

# Generated at 2022-06-25 05:31:19.110250
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    play_0.deserialize({'include': 'foo.yml', 'vars_files': [], 'roles': [], 'included_path': 'foo.yml'})


# Generated at 2022-06-25 05:31:29.754083
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    task_1 = Task(name='a', action='role')
    task_2 = Task(name='b', action='role')
    task_3 = Task(name='c', action='role')
    task_4 = Task(name='d', action='role')
    task_5 = Task(name='e', action='role')
    play_1.tasks = [task_1, task_2, task_3, task_4, task_5]
    out = play_1.get_tasks()
    assert len(play_1.tasks) == 5
    assert play_1.tasks[0] == task_1
    assert play_1.tasks[1] == task_2
    assert play_1.tasks[2] == task_3

# Generated at 2022-06-25 05:31:34.487595
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    play_2 = Play()
    serialized_play = play_1.serialize()
    assert play_1 == play_2
    play_2.deserialize(serialized_play)
    assert play_1 == play_2


# Generated at 2022-06-25 05:31:47.064467
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with no conditions
    play_1 = Play()
    ds_1= { 'hosts' : 'localhost' }
    loaded_1 = play_1.preprocess_data(ds_1)
    assert loaded_1 is not None
    assert isinstance(loaded_1, dict)
    assert loaded_1 == ds_1

    # Test with 'user' key in place
    play_2 = Play()
    ds_2= { 'hosts' : 'localhost', 'user' : 'remoteuser' }
    loaded_2 = play_2.preprocess_data(ds_2)
    assert loaded_2 is not None
    assert isinstance(loaded_2, dict)
    assert loaded_2['user'] == ds_2['user']
    assert loaded_2['remote_user'] == ds_2

# Generated at 2022-06-25 05:32:11.132759
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    assert(Play.preprocess_data(Play(), {}) == {})
    assert(Play.preprocess_data(Play(), {'hosts': 'test_hosts'}) == {'hosts': 'test_hosts'})
    assert(Play.preprocess_data(Play(), {'hosts': 'test_hosts', 'user': 'test_user'}) == {'remote_user': 'test_user', 'hosts': 'test_hosts'})
    assert(Play.preprocess_data(Play(), {'hosts': 'test_hosts', 'user': 'test_user'}) == {'remote_user': 'test_user', 'hosts': 'test_hosts'})

# Generated at 2022-06-25 05:32:15.840243
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.compile_roles_handlers()


# Generated at 2022-06-25 05:32:19.040857
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = 'some name'
    assert play_0.get_name() == 'some name'
    play_0.name = None
    play_0.hosts = 'some host'
    assert play_0.get_name() == 'some host'


# Generated at 2022-06-25 05:32:28.964413
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    role_0 = Role()
    role_1 = Role()
    role_2 = Role()
    role_3 = Role()
    role_4 = Role()
    role_5 = Role()
    role_6 = Role()
    role_7 = Role()
    role_8 = Role()
    role_9 = Role()

    role_0.name = "R0"
    role_1.name = "R1"
    role_2.name = "R2"
    role_3.name = "R3"
    role_4.name = "R4"
    role_5.name = "R5"
    role_6.name = "R6"
    role_7.name = "R7"
    role_8.name = "R8"
    role_9.name = "R9"

# Generated at 2022-06-25 05:32:38.579775
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()

    def get_task_data(task):
        return task.serialize()


# Generated at 2022-06-25 05:32:41.118815
# Unit test for constructor of class Play
def test_Play():
    try:
        test_case_0()
    except Exception as e:
        print('Failed to execute test case 0 for Play: %s' % str(e))

# Test for private functions in Play.py

# Generated at 2022-06-25 05:32:49.263988
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    play_0 = Play()
    play_1 = Play()
    play_2 = Play()

    vars_files_1 = [
        '{{ playbook_dir }}/../vars/main.yml',
        {'role': 'test', 'name': 'test'},
    ]
    play_1.vars_files = vars_files_1

    assert play_0.get_vars_files() == []
    assert play_1.get_vars_files() == vars_files_1
    assert play_2.get_vars_files() == []


# Generated at 2022-06-25 05:32:56.924404
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import yaml

# Generated at 2022-06-25 05:32:59.226718
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # test_case_0()
    # play_0 = Play()
    assert type(Play._get_vars_files(play_0)) == list


# Generated at 2022-06-25 05:33:01.136709
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    set_class(Play.__name__)
    test_case_0()


# Generated at 2022-06-25 05:33:23.573884
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    vars_files_0 = play_0.get_vars_files()
    if play_0.get_vars_files() is None:
        print("vars_files_0 is None")
    elif not isinstance(play_0.get_vars_files(), list):
        print("vars_files_0 is not instance of list")
    elif play_0.vars_files is None:
        print("play_0.vars_files is None")
    elif not isinstance(play_0.vars_files, list):
        print("play_0.vars_files is not instance of list")
    elif play_0.vars_files is []:
        print("play_0.vars_files is []")

# Generated at 2022-06-25 05:33:27.280187
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1._load_roles = lambda a,b: [0]
    role = Role()
    role.get_handler_blocks = lambda: [1]
    play_1.roles = [role]
    assert play_1.compile_roles_handlers() == [1]

# Generated at 2022-06-25 05:33:33.736911
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # test_case_0()
    play_1 = Play()
    play_1.vars_files = 111
    assert play_1.get_vars_files() == [111]
    play_2 = Play()
    play_2.vars_files = []
    assert play_2.get_vars_files() == []
    play_4 = Play()
    assert play_4.get_vars_files() == []


# Generated at 2022-06-25 05:33:38.952669
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    data = play_0.serialize()
    assert data['name'] == '', 'Wrong'
    assert data['hosts'] == 'all', 'Wrong'
    assert data['roles'] == [], 'Wrong'
    assert data['included_path'] is None, 'Wrong'
    assert data['action_groups'] == {}, 'Wrong'
    assert data['group_actions'] == {}, 'Wrong'
    assert data['remote_user'] == 'root', 'Wrong'


# Generated at 2022-06-25 05:33:42.010113
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Testing for name
    play_1 = Play()
    play_1.name = 'Play one'
    assert (play_1.get_name()==play_1.name)
    # Testing for hosts
    play_1.hosts = 'hosts'
    assert (play_1.get_name()==play_1.hosts)


# Generated at 2022-06-25 05:33:47.349412
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create play_0
    play_0 = Play()
    play_0.hosts = ''

    play_0_preprocess_data_ds = {'hosts': '', 'user': ''}
    play_0_preprocess_data_result = play_0.preprocess_data(play_0_preprocess_data_ds)
    assert play_0_preprocess_data_result['hosts'] == ''
    assert play_0_preprocess_data_result['remote_user'] == ''

    # Create play_1
    play_1 = Play()
    play_1.hosts = ''

    play_1_preprocess_data_ds = {'hosts': '', 'user': '', 'new_key': 'new_value'}

# Generated at 2022-06-25 05:33:53.260152
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()

    play.vars_files = []
    assert play.get_vars_files() == []

    play.vars_files = 'vars_files'
    assert play.get_vars_files() == ['vars_files']

    play.vars_files = ['vars_files1', 'vars_files2']
    assert play.get_vars_files() == ['vars_files1', 'vars_files2']

# Generated at 2022-06-25 05:34:02.180262
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.mod_args import TaskLoader

    task_loader = TaskLoader()
    task_loader.loader = DictDataLoader({
        'playbooks/playbook/tasks/main.yaml': '''
        - debug:
            var: x

        - debug:
            var: y
        ''',
        'playbooks/playbook/tasks/handlers.yaml': '''
        - debug:
            var: z

        - debug:
            var: a
        '''
    })

    play_a = Play().load_data({'tasks': [{'include': 'playbooks/playbook/tasks/main.yaml'}], 'handlers': [{'include': 'playbooks/playbook/tasks/handlers.yaml'}]}, loader=task_loader)