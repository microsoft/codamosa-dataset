

# Generated at 2022-06-25 05:24:33.364198
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    roles_0 = []
    role_0 = Role()
    role_0.name = 'foo'
    role_0.role_path = 'foo/path'
    roles_0.append(role_0)
    data_0 = {'roles': roles_0, 'action_groups': {}}
    play_0.deserialize(data_0)
    assert play_0.roles[0].name == 'foo'
    assert play_0.roles[0].role_path == 'foo/path'
    data_0['roles'][0]['role_path'] += '/new'
    assert play_0.roles[0].role_path == 'foo/path'


# Generated at 2022-06-25 05:24:44.030066
# Unit test for method serialize of class Play
def test_Play_serialize():
    import sys
    import os
    import tempfile
    tempdir = tempfile.gettempdir()
    tempdir = '.'
    my_file = os.path.join(tempdir,'test_Play_class_serialize.yaml')
    my_str = '''
- hosts: localhost
  name: test_Play_serialize
  gather_facts: no
  tasks:
    - name: test_Play_serialize
      debug:
        msg: 'test_Play_serialize'
  pre_tasks: []
  post_tasks: []
  handlers: []
'''
    print(my_str)
    write_file(my_file, my_str)
    my_dict = read_yaml_file(my_file)
    #my_dict = dict()
    #my_dict['

# Generated at 2022-06-25 05:24:52.602200
# Unit test for method get_name of class Play

# Generated at 2022-06-25 05:25:04.098542
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0._force_handlers = True
    play_0._strategy = 'free'
    play_0._max_fail_percentage = 1
    play_0.connection = 'network_cli'
    play_0.remote_user = 'vagrant'
    play_0._variable_manager = None
    play_0.hosts = 'dut_0'
    play_0.port = 22
    play_0.timeout = 5
    play_0.gio_timeout = 60
    play_0.become = True
    play_0.become_method = 'enable'
    play_0.become_user = 'cisco'
    play_0.check = False
    play_0.name = 'ping'

# Generated at 2022-06-25 05:25:16.182911
# Unit test for method get_name of class Play
def test_Play_get_name():

    from ansible.inventory import Inventory

    # Create an instance of class Play
    play_0 = Play()

    # Create and assign an instance of class Inventory
    inventory = Inventory("hosts", "hosts", "hosts", "hosts")
    play_0.inventory = inventory

    # Assign a value to attribute name
    play_0.name = "Test Play"

    # Create an instance of class Play
    play_1 = Play()

    # Create and assign an instance of class Inventory
    inventory = Inventory("hosts", "hosts", "hosts", "hosts")
    play_1.inventory = inventory

    # Assign a value to attribute name
    play_1.name = ""

    # Create an instance of class Play
    play_2 = Play()

    # Create and assign an instance of class Inventory

# Generated at 2022-06-25 05:25:20.595400
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    try:
        # Test case 0
        test_case_0()
        # Lets say a test succeeds
        msg = "\nTest case 0 passed"
    except Exception as e:
        # If it fails, it should throw an error 
        msg = "\nTest case 0 failed with Exception %s" %e
    finally:
        print(msg)
Play.get_tasks = test_Play_get_tasks
# run the test.
Play.get_tasks()

#Unit test for method copy of class Play

# Generated at 2022-06-25 05:25:23.554737
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == '', 'Failed to retrieve name of Play'

# Test the load() method

# Generated at 2022-06-25 05:25:29.035688
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    data = play_1.serialize()
    play_2 = Play()
    play_2.deserialize(data)
    assert play_1.serialize() == play_2.serialize()


# Generated at 2022-06-25 05:25:32.035159
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    role_0 = Role()
    role_0.name = 'foo'
    role_1 = Role()
    role_1.name = 'bar'
    play_1.roles.extend([role_0, role_1])
    play_1.serialize()

# Generated at 2022-06-25 05:25:43.094068
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pl = Play()
    t1 = Task()
    t2 = Task()
    t3 = Task()
    b1 = Block()
    b1.block = [t1, t2]
    b2 = Block()
    b2.block = [t3]
    pl.pre_tasks = [b1]
    pl.tasks = [b2]
    pl.post_tasks = [b2]
    tasks = pl.get_tasks()
    assert len(tasks) == 5
    assert tasks[0] == t1
    assert tasks[1] == t2
    assert tasks[2] == t3
    assert tasks[3] == t3
    assert tasks[4] == t3
    print('play ok')


# Generated at 2022-06-25 05:25:59.112584
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play.load(dict(name='testing', hosts='all'), variable_manager=variable_manager, loader=loader)
    assert play_1.get_name() == 'testing'

    play_2 = Play.load(dict(hosts='all'), variable_manager=variable_manager, loader=loader)
    assert play_2.get_name() == 'all'


# Generated at 2022-06-25 05:26:07.504576
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data_0 = {"roles": [{"role": "a"}, 0, {"role": "b"}, {"role": "c"}], "hosts": "hosts", "tasks": 'tasks', "vars_files": 'vars_files', "post_tasks": 'post_tasks', "handlers": 'handlers', "pre_tasks": 'pre_tasks', "vars_prompt": 'vars_prompt', "name": "name", "vars": 'vars'}
    play_0 = Play()
    play_0.ROLE_CACHE = {}
    play_0._included_conditional = None
    play_0._included_path = None
    play_0._removed_hosts = []
    data_1 = play_0.preprocess_data(data_0)

# Generated at 2022-06-25 05:26:15.854065
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_1.preprocess_data({'name': 'play_1', 'hosts': 'some_hosts', 'user': 'jerry', 'vars': {}})
    assert play_1.name == 'play_1'
    assert 'user' not in play_1._ds
    assert 'remote_user' in play_1._ds
    assert play_1.remote_user == 'jerry'
    #TODO: Add test for 'hosts'


# Generated at 2022-06-25 05:26:24.654825
# Unit test for method preprocess_data of class Play

# Generated at 2022-06-25 05:26:30.759262
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    with pytest.raises(AnsibleAssertionError) as excinfo:
        play_1.preprocess_data(1)
    assert 'ds should be a dict' in to_native(excinfo.value)

    play_2 = Play()
    play_2.preprocess_data({})


# Generated at 2022-06-25 05:26:32.797780
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    result = play_0.get_tasks()
    assert result == []



# Generated at 2022-06-25 05:26:36.002005
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "Play"
    try:
        assert play_0.get_name() == "Play"
    except Exception as err:
        print("Test get_name of class Play fail")
        raise err


# Generated at 2022-06-25 05:26:36.896063
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()



# Generated at 2022-06-25 05:26:46.072188
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.handlers = [
        {'listen': 'first', 'name': 'first'},
        {'listen': 'second', 'name': 'second'},
        {'listen': 'third', 'name': 'third'},
        {'name': 'fourth'}
    ]
    compiled_handlers = play.compile_roles_handlers()
    assert len(compiled_handlers) == 4
    assert compiled_handlers[0]['name'] == 'first'
    assert compiled_handlers[1]['name'] == 'second'
    assert compiled_handlers[2]['name'] == 'third'
    assert compiled_handlers[3]['name'] == 'fourth'



# Generated at 2022-06-25 05:26:49.654090
# Unit test for constructor of class Play
def test_Play():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        assert False



# Generated at 2022-06-25 05:27:02.080821
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    if play_0.get_vars_files() is not None:
        print('Failed')
        exit(1)


# Generated at 2022-06-25 05:27:09.100413
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [('role/tests/role_1', 'role/tests/role_1', 'role_1', {}), ('role/tests/role_2', 'role/tests/role_2', 'role_2', {})]
    play.roles[0]._handlers = ['test_1', 'test_2']
    play.roles[1]._handlers = ['test_3', 'test_4']
    assert play.compile_roles_handlers() == ['test_1', 'test_2', 'test_3', 'test_4']

# Generated at 2022-06-25 05:27:15.812225
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    play_1.vars_files = ['/examples/playbooks/vars/redis/ansible_redis_vars.yml']
    result_1 = play_1.get_vars_files()
    expected_1 = ['/examples/playbooks/vars/redis/ansible_redis_vars.yml']
    if result_1 == expected_1:
        correct_1 = True
    else:
        correct_1 = False
        print("Test case 1 failed")
        print("Expected " + str(expected_1))
        print("Received " + str(result_1))

    play_2 = Play()
    play_2.vars_files = None
    result_2 = play_2.get_vars_files()
    expected

# Generated at 2022-06-25 05:27:20.347085
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = None
    play_0.get_vars_files()
    play_0.vars_files = 'vars_files'
    play_0.get_vars_files()
    play_0.vars_files = ['vars_files']
    play_0.get_vars_files()


# Generated at 2022-06-25 05:27:25.222914
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = [[['task_0']]]
    play_0.tasks = [[['task_1']]]
    play_0.post_tasks = [[['task_2']]]
    task_list = []
    for task in play_0.get_tasks():
        task_list.append(task)
    assert task_list == [[['task_0']], [['task_1']], [['task_2']]]


# Generated at 2022-06-25 05:27:29.378855
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    # Assigning value to attribute vars_files of object play_1.
    play_1.vars_files = list()

    # Invoking method get_vars_files on object play_1.
    result_1 = play_1.get_vars_files()

    # Evaluating truth value of result_1.
    assert result_1 == [], print_vars_files_1


# Generated at 2022-06-25 05:27:31.849212
# Unit test for method get_name of class Play
def test_Play_get_name():
    print('Testing method get_name...')
    play_0 = Play()
    name_0 = play_0.get_name()
    assert name_0 == ''
    print('method get_name works as expected.')


# Generated at 2022-06-25 05:27:41.949657
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a test Play and two test Roles
    play_0 = Play()
    role_0 = Role()
    role_1 = Role()

    # Create a test handler
    handler = Handler()

    # attach roles_0 and role_1 to the Play
    play_0.roles.extend([ role_0, role_1 ])

    # Attach the handler to role_0
    role_0.handlers.extend([ handler ])

    # compile the handlers attached to Play's roles
    # the result should be a list of length 1 containing the handler
    assert(play_0.compile_roles_handlers() == [ handler ])


# Generated at 2022-06-25 05:27:45.262400
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create a Play object
    play = Play()

    # Check a None result, if a name doesn't exist
    if play.get_name() != None:
        sys.exit("Play.get_name() error")


# Generated at 2022-06-25 05:27:55.154201
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play = Play.load(dict(
        name='some_play',
        hosts=['localhost', 'some_remote_server'],
        vars=dict(
            var1='foo',
            var2='bar',
        ),
        vars_prompt=dict(
            var3='hello',
        ),
        tasks=['some_task', 'some_other_task'],
    ))

    assert play is not None
    assert play.name == 'some_play'
    assert play.hosts == ['localhost', 'some_remote_server']
    assert play.vars == dict(
        var1='foo',
        var2='bar',
    )
    assert play.vars_prompt == dict(
        var3='hello',
    )
    assert len(play.tasks)

# Generated at 2022-06-25 05:28:06.195953
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:28:11.319143
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    setattr(play_0, '_tasks', [])
    assert play_0.get_tasks() == []



# Generated at 2022-06-25 05:28:15.457350
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    obj = Play()
    print(obj.deserialize())


# Generated at 2022-06-25 05:28:22.774571
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_files = ['/path/to/vars_file1.yml', '/path/to/vars_file2.yml']
    play_0 = Play()
    play_0.vars_files = vars_files
    assert play_0.get_vars_files() == vars_files
    vars_files = '/path/to/vars_file1.yml'
    play_0.vars_files = vars_files
    assert play_0.get_vars_files() == [vars_files]
    vars_files = None
    play_0.vars_files = vars_files
    assert play_0.get_vars_files() == []


# Generated at 2022-06-25 05:28:30.354156
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Tests if the get_name method produces the expected result
    obj = Play()
    obj.name = None
    obj.hosts = "localhost"
    obj2 = Play()
    obj2.name = "play_0"
    obj2.hosts = ["localhost", "localhost"]
    # Case where call method get_name of class Play
    assert obj.get_name() == 'localhost'
    # Case where call method get_name of class Play
    assert obj2.get_name() == 'play_0'


# Generated at 2022-06-25 05:28:34.532722
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    try:
        # test that method get_vars_files of class Play raises exception
        # AttributeError if Play object has no attribute 'vars_files'
        play_1 = Play()
        play_1.get_vars_files()
    except AttributeError:
        pass
    else:
        print('test_Play_get_vars_files failed')


# Generated at 2022-06-25 05:28:45.176712
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Unit test for serialize method of class Play
    # Test Play.serialize()
    play_1 = Play()

    # Test serialize
    # serialize() should return a list of attributes
    # Get serialized output
    data = play_1.serialize()

    # Check data is dictionary
    if not isinstance(data, dict):
        raise AssertionError("'data' is not an instance of dictionary")
    # Check number of attributes
    if not len(data) == 13:
        raise AssertionError("Play serialize() should return 13 attributes")

    # Check all attributes in 'data'

# Generated at 2022-06-25 05:28:52.657133
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    assert play_1.serialize() == dict(gather_facts='smart', any_errors_fatal=True, max_fail_percentage=None, force_handlers=False, serial=None, remote_user='root', ignore_errors=False, roles=[], handlers=[], pre_tasks=[], post_tasks=[], vars_files=None, tasks=[], strategy='linear', name='', connection='smart', gather_subset=[], variables=dict(), environment=dict(), become=False, become_user=None, become_method=None, block=None, block_rescue=None, block_always=None, vars_prompt=None, order='linear', included_path=None, action_groups={}, group_actions={})


# Generated at 2022-06-25 05:28:55.733375
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    assert play.get_tasks() == []


# Generated at 2022-06-25 05:28:57.139106
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.serialize()



# Generated at 2022-06-25 05:29:07.502353
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-25 05:29:10.456653
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.vars_files == []
    assert play_0.get_vars_files() == []
    play_1 = Play()
    play_0.vars_files = 'test/vars_files'
    assert play_1.get_vars_files() == ['test/vars_files']


# Generated at 2022-06-25 05:29:21.487436
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Instantiate an empty instance
    play_0 = Play()

    # Invoke method
    result = play_0.compile_roles_handlers()

    # Check result
    assert result == []


# Generated at 2022-06-25 05:29:23.338534
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds = {}
    play_0.preprocess_data(ds)
    assert ds == ds

# Generated at 2022-06-25 05:29:26.199494
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "play0"
    assert play_0.get_name() == "play0"


# Generated at 2022-06-25 05:29:26.942496
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass


# Generated at 2022-06-25 05:29:35.997418
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    test_objects = [
        Play(),
    ]

    def test_body(test_obj, test_data):
        test_result = test_obj.preprocess_data(test_data)
        #
        # Write test assertions here
        #

    test_data = [
        None,
        'test_value_1',
        'test_value_2',
    ]
    for test_obj in test_objects:
        for test_d in test_data:
            test_body(test_obj, test_d)


# Generated at 2022-06-25 05:29:43.613562
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # create a play without handlers and without vars
    ds = dict(hosts='myhost',
              pre_tasks=[],
              roles=[],
              tasks=[],
              post_tasks=[])
    play = Play(ds)

    # validate that the play has no handlers and no vars
    assert play.handlers == []
    assert play.vars == {}
    assert play.default_vars == {}

    # add a handler and a var
    ds = dict(hosts='myhost',
              pre_tasks=[],
              roles=[],
              tasks=[],
              post_tasks=[],
              handlers=['a_handler'],
              vars=dict(a_var='abc'))

    play = Play(ds)
    # ensure that both handlers and vars are loaded

# Generated at 2022-06-25 05:29:49.079238
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    task0_1 = dicto(task='task0')
    task1_1 = dicto(task='task1')
    play_1.pre_tasks = [task0_1]
    play_1.tasks = [task1_1]
    play_1.post_tasks = []
    try:
        assert play_1.get_tasks() == [task0_1, task1_1]
    except AssertionError as e:
        print('AssertionError: %s' % e)


# Generated at 2022-06-25 05:30:01.243910
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play.load({'name': 'test-play',
        'hosts': 'localhost',
        'roles': [{
            'name': 'role1',
            'block': [{
                'meta': 'flush_handlers',
                'block': [{
                    'name': 'handler1',
                    'listen': 'success',
                    'block': [{
                        'meta': 'always',
                        'block': [{
                            'meta': 'always_run'
                        }]
                    }]
                }]
            }]
        }]
    }, variable_manager=VariableManager(), loader=DictDataLoader())

    handlers = play.compile_roles_handlers()
    assert len(handlers) == 1, handlers
    assert handlers[0].block[0].name == 'handler1'


# Generated at 2022-06-25 05:30:13.465681
# Unit test for method get_name of class Play
def test_Play_get_name():

    # Test that an exception is raised when play is not loaded
    with pytest.raises(AnsibleAssertionError):
        test_case_0().get_name()


# Generated at 2022-06-25 05:30:21.811670
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = 'test_play'

    _all_hosts = 'allhosts'
    play_1.hosts = _all_hosts
    assert play_1.get_name() == 'test_play'

    _host_list = ['host_one', 'host_two']
    play_1.hosts = _host_list
    assert play_1.get_name() == 'host_one,host_two'

    play_1.hosts = 'host'
    assert play_1.get_name() == 'host'

    play_1.name = None
    assert play_1.get_name() == 'host'

    play_1.hosts = None
    assert play_1.get_name() == ''


# Generated at 2022-06-25 05:30:31.584969
# Unit test for method get_tasks of class Play

# Generated at 2022-06-25 05:30:36.468095
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.post_tasks = [Task(), Task()]
    play_0.pre_tasks = [Task()]
    play_0.tasks = [Task()]
    tasklist = play_0.get_tasks()
    assert(len(tasklist)==4)


# Generated at 2022-06-25 05:30:38.759737
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_2 = Play()
    play_2.name = 'play_0'
    assert play_2.get_name() == 'play_0'


# Generated at 2022-06-25 05:30:44.951046
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.handlers = []
    p.roles = []
    p.tasks = [{"meta": {"end_play": {}}}, {"meta": {"flush_handlers": {}}}]
    p.pre_tasks = []
    p.post_tasks = []
    assert p.get_tasks() == [{"meta": {"end_play": {}}}, {"meta": {"flush_handlers": {}}}]



# Generated at 2022-06-25 05:30:53.302122
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = ['pre_tasks_list']
    play_0.post_tasks = ['post_tasks_list']
    play_0.tasks = ['tasks_list']

    result = play_0.get_tasks()
    assert isinstance(result, list)
    assert result == ['pre_tasks_list', 'tasks_list', 'post_tasks_list']


# Generated at 2022-06-25 05:30:55.179254
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    assert play_0.compile_roles_handlers() == []


# Generated at 2022-06-25 05:30:56.992437
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = ['/tmp/foo', '/tmp/bar']
    play_0.get_vars_files()


# Generated at 2022-06-25 05:30:59.017281
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    name_0 = play_0.get_name()
    print("\nname_0",name_0)


# Generated at 2022-06-25 05:31:21.204179
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()



# Generated at 2022-06-25 05:31:25.805669
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    temp_data = {}
    temp_roles = []
    temp_role = Role()
    temp_roles.append(temp_role)
    temp_data['roles'] = temp_roles
    play_0.deserialize(temp_data)


# Generated at 2022-06-25 05:31:27.481358
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_1.preprocess_data({})


# Generated at 2022-06-25 05:31:38.868838
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    class AnsibleMock(Ansible):

        def __init__(self):
            self.ROLE_CACHE = {}

    # Fake some data for the role
    role_name = 'test role'
    handlers = ['test handler']
    data = {'name': role_name, 'handlers': handlers}
    my_role = Role.load(data)
    play_0 = Play()
    play_0.ROLE_CACHE[role_name] = my_role

    # Call the compile_roles_handlers method of the play
    blocks = play_0.compile_roles_handlers()

    # Make sure the block is of the correct type
    assert isinstance(blocks[0], Block)
    # Make sure the handler is of the correct type

# Generated at 2022-06-25 05:31:45.740889
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    try:
        play_get_vars_files = Play()
        assert play_get_vars_files.get_vars_files() == []
    except AssertionError as e:
        raise AssertionError(e)
    except Exception as e:
        raise AssertionError(repr(e))


# Generated at 2022-06-25 05:31:47.657077
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = ''
    play_0.hosts = 'localhost'
    var_0 = play_0.get_name()
    assert var_0 == 'localhost'


# Generated at 2022-06-25 05:31:51.081220
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    var = play_0.get_vars_files()


# Generated at 2022-06-25 05:32:00.135272
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    # Test for case 0
    play_0 = Play()
    play_0.pre_tasks = [
        Block(
            block=[
                Task(
                    name='Test Task 0',
                    tasks=[]
                ),
                Task(
                    name='Test Task 1',
                    tasks=[]
                )
            ],
            rescue=[
                Task(
                    name='Test Task 2',
                    tasks=[]
                ),
                Task(
                    name='Test Task 3',
                    tasks=[]
                )
            ],
            always=[
                Task(
                    name='Test Task 4',
                    tasks=[]
                ),
                Task(
                    name='Test Task 5',
                    tasks=[]
                )
            ]
        )
    ]

# Generated at 2022-06-25 05:32:10.397394
# Unit test for method get_name of class Play
def test_Play_get_name():
    code0 = '''
    check = True
    play_0 = Play()
    '''
    exec(code0)
    check = play_0.get_name()
    res = ''
    success = False

    if check is not None:
        if check == res:
            success = True

    if success:
        with open('tests/results/Play_get_name.txt', 'a') as file:
            file.write('### get_name() ###\n')
            file.write('Success\n')
            file.write('==========================\n')
            file.write('\n')



# Generated at 2022-06-25 05:32:21.800271
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    json_data = u'''
{
    "roles": [
        {
            "tasks": [
                {
                    "ignore_errors": false,
                    "local_action": {
                        "module": "shell",
                        "args": "echo \"hello world\""
                    },
                    "register": "out"
                }
            ],
            "hosts": [
                "localhost"
            ],
            "name": "role-0"
        }
    ],
    "hosts": [
        "localhost"
    ]
}'''
    play_0 = Play.load(from_json(json_data), variable_manager=VariableManager())
    ret = play_0.get_tasks()
    assert ret is not None


# Generated at 2022-06-25 05:32:46.710321
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    local_tags = frozenset()
    block_list = play_0.compile_roles_handlers()
    assert block_list == []


# Generated at 2022-06-25 05:32:54.557527
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()

# Generated at 2022-06-25 05:33:03.254264
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    #Test: play get task in no task environment
    assert(play.get_tasks() == [])

    #Test: add a task in task environment
    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    play.tasks = [task_0]
    assert(play.get_tasks() == [task_0])
    play.pre_tasks = [task_1]
    play.post_tasks = [task_2]
    assert(play.get_tasks() == [task_1, task_0, task_2])
    play.tasks.append(task_1)
    play.tasks.append(task_2)

# Generated at 2022-06-25 05:33:05.364971
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # instantiate
    play_1 = Play()

    # test
    play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:33:10.792978
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.tasks = ["tasks_1", "tasks_2", "tasks_3"]
    play_1.pre_tasks = ["pre_task_1", "pre_task_2", "pre_task_3"]
    play_1.post_tasks = ["post_task_1", "post_task_2", "post_task_3"]
    assert len(play_1.get_tasks()) == 9

# Generated at 2022-06-25 05:33:15.407973
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    play = Play()
    play.roles = [Role()]
    play.roles[0]._handlers = []
    play.roles[0]._handlers.append(Block(parent_block=play.roles[0]))
    play.roles[0]._handlers[0]._handlers = [Handler()]

    handlers = play.compile_roles_handlers()
    assert handlers == [Handler()]

# Generated at 2022-06-25 05:33:22.547862
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.pre_tasks = ['pre_task_1', 'pre_task_2']
    play_1.tasks = ['task_1', 'task_2']
    play_1.post_tasks = ['post_task_1', 'post_task_2']

    assert play_1.get_tasks() == ['pre_task_1', 'pre_task_2', 'task_1', 'task_2', 'post_task_1', 'post_task_2']


# Generated at 2022-06-25 05:33:29.042811
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    # base test: no pre_tasks, no tasks, no post_tasks
    play_1 = Play()
    tasks_1 = play_1.get_tasks()
    assert tasks_1 == []

    # test with pre_tasks only
    pre_tasks = Task.load(dict(action=dict(module='debug', args=dict(msg='pre task1'))), play=play_1)
    play_2 = Play()
    play_2.pre_tasks.append(pre_tasks)
    tasks_2 = play_2.get_tasks()
    assert tasks_2 == [pre_tasks]

    # test with tasks only
    tasks = Task.load(dict(action=dict(module='debug', args=dict(msg='play task 1'))), play=play_1)
    play

# Generated at 2022-06-25 05:33:31.154469
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from collections import Mapping
    play_1 = Play()
    play_1.preprocess_data(None)
    assert(True)


# Generated at 2022-06-25 05:33:34.652786
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()

    expected_hosts = 'localhost'
    play_0.hosts = expected_hosts
    actual_name = play_0.get_name(
    )

    assert actual_name == expected_hosts
