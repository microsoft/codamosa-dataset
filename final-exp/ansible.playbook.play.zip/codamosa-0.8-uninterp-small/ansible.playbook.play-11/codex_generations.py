

# Generated at 2022-06-25 05:24:20.773191
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    play_0.deserialize('data')


# Generated at 2022-06-25 05:24:27.997078
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data = {'vars': {'inventory_hostname': 'sample_host'}, 'roles': [{'role': {'name': 'my_role', 'include_role': {'name': 'include_this_role'}, 'tasks': []}}]}
    play_0.deserialize(data)
    assert play_0.vars['inventory_hostname'] == 'sample_host'
    assert play_0.roles[0].role.name == 'my_role'
    assert play_0.roles[0].role.include_role.name == 'include_this_role'


# Generated at 2022-06-25 05:24:36.913668
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Code here will be used to test function get_tasks() of class Play
    # By initializing a Play object:
    play_1 = play_0
    play_1.pre_tasks = list()
    play_1.tasks = list()
    play_1.post_tasks = list()
    play_1.pre_tasks = [1, 2, 3]
    play_1.tasks = [4, 5, 6]
    play_1.post_tasks = [7, 8, 9]
    play_1.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-25 05:24:46.942217
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:24:59.103186
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    #VARS_PROMPT = FieldAttribute(isa='list')
    play_0 = Play()
    # Load property vars_prompt with the field attribute
    play_0.vars_prompt = Play.vars_prompt
    play_0.vars_prompt._load_type_vals(['test_handler'])
    Play.vars_prompt = play_0.vars_prompt

    play_0.hosts = ['test_host']
    print("play_0.hosts: ", play_0.hosts)

    # Override method compile_roles_handlers with mock

# Generated at 2022-06-25 05:25:04.197818
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Tests for class Play for method get_tasks
    play_1 = Play()
    task_1 = play_1._tasks = Task()
    task_1 = play_1._pre_tasks = Task()
    task_1 = play_1._post_tasks = Task()
    test_1 = play_1.get_tasks()
    assert test_1 ==[], 'Expected: [], but returned: %s' % test_1


# Generated at 2022-06-25 05:25:09.145056
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # unit test for method get_tasks() of class Play
    play_0 = Play()
    tasks_0 = play_0.get_tasks()


# Generated at 2022-06-25 05:25:19.327881
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Simple test case
    play_0 = Play()
    data = {"roles": [{"handlers": [{"block": [], "always": [],
                                     "rescue": [], "name": "TestHandler"}], "name": "Test-Role",
                      "vars": {"test_var": "Test value"}, "tasks": [], "tags": ["test"]}], "name": "Test play"}
    play_0.deserialize(data)
    assert (play_0.get_name() == "Test play")
    roles =  play_0.get_roles()
    assert (len(roles) == 1)
    assert (roles[0].get_name() == "Test-Role")
    assert (roles[0].get_handler('TestHandler').get_name() == "TestHandler")
   

# Generated at 2022-06-25 05:25:20.757396
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_case_0()
    test_Play_get_vars_files_0()


# Generated at 2022-06-25 05:25:25.126090
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_2 = Play()
    play_2_compile_roles_handlers_var_1 = play_2.compile_roles_handlers()
    assert play_2_compile_roles_handlers_var_1 is not None
    assert len(play_2_compile_roles_handlers_var_1) == 0


# Generated at 2022-06-25 05:25:39.229882
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    #Test 0: create a play, instantiate a Role and add it to the
    #        play.roles list.
    #        Then create a task, a handler and add them to the
    #        Role tasks and handlers lists, respectively.
    #        Note: The task and handler are added to the role,
    #        not to the play. This is done because a Role is
    #        a collection of tasks and handlers and they
    #        should not be populated with tasks and handlers
    #        from the Play
    play_0 = Play()
    role_0 = Role()
    play_0.roles.append(role_0)
    task_0 = Task()
    handler_0 = Handler()
    role_0.tasks.append(task_0)
    role_0.handlers.append(handler_0)
    #

# Generated at 2022-06-25 05:25:43.456465
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    """
    Checks that the method preprocess_data of class Play
    returns an object of type dict if the input is of type dict.
    """

    play = Play()
    input = {'hosts':'all'}

    try:
        output = play.preprocess_data(input)
    except:
        output = None

    assert isinstance(output, dict)


# Generated at 2022-06-25 05:25:44.439404
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = []
    p._compile_roles()


# Generated at 2022-06-25 05:25:48.455313
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.set_loader('test_loader')
    play_0._ds = {'test_ds': 'test_ds'}
    obj = play_0.serialize()
    assert('test_loader' == obj['loader'])
    assert(play_0._ds == obj['_ds'])


# Generated at 2022-06-25 05:25:58.525757
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create test objects
    play_1 = Play()
    play_2 = Play()
    play_3 = Play()

    # Test get_name function
    play_1.name = "TEST_CASE_1"
    play_2.hosts = "TEST_CASE_2"
    play_3.hosts = "TEST_CASE_3"
    play_3.name = "TEST_CASE_3"

    # Check all test cases
    assert play_1.get_name() == "TEST_CASE_1"
    assert play_2.get_name() == "TEST_CASE_2"
    assert play_3.get_name() == "TEST_CASE_3"

    # Check function with no parameters

# Generated at 2022-06-25 05:26:06.827550
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test: Call of method get_tasks with no arguments
    # Test: Return data is not None
    play_1 = Play()
    list_1 = play_1.get_tasks()
    assert(list_1 != None)
    # Test: Return data is an instance of list
    assert(isinstance(list_1, list))
    # Test: Return value is equal to property tasks
    assert(list_1 == play_1.tasks)


# Generated at 2022-06-25 05:26:14.278519
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    # Test case 'var_files not None'
    play_1.vars_files = {1: 2, 3: 4}
    assert play_1.get_vars_files() == [{1: 2, 3: 4}]

    # Test case 'var_files is None'
    play_2 = Play()
    play_2.vars_files = None
    assert play_2.get_vars_files() == []

# Generated at 2022-06-25 05:26:22.637241
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert isinstance(play_0.get_name(), str)
    play_1 = Play()
    assert isinstance(play_1.get_name(), str)
    play_2 = Play()
    assert isinstance(play_2.get_name(), str)
    play_3 = Play()
    assert isinstance(play_3.get_name(), str)
    play_4 = Play()
    assert isinstance(play_4.get_name(), str)
    play_5 = Play()
    assert isinstance(play_5.get_name(), str)
    play_6 = Play()
    assert isinstance(play_6.get_name(), str)
    play_7 = Play()
    assert isinstance(play_7.get_name(), str)
    play_8 = Play()

# Generated at 2022-06-25 05:26:24.337640
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = []
    block_list = play.compile_roles_handlers()
    if block_list != []:
        raise AssertionError


# Generated at 2022-06-25 05:26:28.720508
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name='Play Name Test'
    assert(play_1.get_name() == 'Play Name Test')


# Generated at 2022-06-25 05:26:41.488758
# Unit test for method serialize of class Play
def test_Play_serialize():
    """Play.serialize"""
    play_0 = Play()

# Generated at 2022-06-25 05:26:43.724664
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks = [Task(), Task(), Task(), Task(), Task()]
    play_0.pre_tasks = [Block()]
    play_0.post_tasks = [Block()]
    play_0.get_tasks()


# Generated at 2022-06-25 05:26:45.524763
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_1 = Play()
    play_1.name = play_0.serialize()['name']
    play_1.name = play_0.serialize()['name']


# Generated at 2022-06-25 05:26:50.515406
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    # Verify the AnsibleAssertionError is raised for incorrect play data
    try:
        ds_0 = []
        play_0.preprocess_data(ds_0)
    except AnsibleAssertionError as e:
        assert(e)
    # Verify the AnsibleParserError is raised for a malformed block
    try:
        ds_1 = {'tasks': [{'_raw_params': 'invalid'}]}
        play_0.preprocess_data(ds_1)
    except AnsibleParserError as e:
        assert(e)


# Generated at 2022-06-25 05:26:54.371508
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test using a real Play class
    play_1 = Play()
    play_1.roles.append(Role())
    play_1.compile_roles_handlers()
    

# Generated at 2022-06-25 05:26:57.965023
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    task_0 = Play.get_tasks()


# Generated at 2022-06-25 05:27:01.359941
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'name'
    assert play.get_name() == play.name


# Generated at 2022-06-25 05:27:10.249658
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    """Exercise preprocess_data for legacy play data structure"""
    data = {
        'user': 'root',
        'hosts': 'all',
        'vars': {},
        'tasks': [],
        'roles': [
            {
                'user': 'jdoe',
                'name': 'rolename',
                'vars': {},
                'tasks': [],
            }
        ]
    }
    play = Play()
    play.preprocess_data(data)

    assert play._attributes['remote_user'] == 'root'
    assert play.roles[0]._attributes['remote_user'] == 'jdoe'

    # Check that preprocess_vars is called for the play, the role and the tasks
    assert play.vars == {}
    assert play.ro

# Generated at 2022-06-25 05:27:16.619467
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [
        Task(name="echo", action=dict(module="debug", args=dict(msg="pre_tasks_msg_1")), register="pre_tasks_reg_1"),
        Task(name="echo", action=dict(module="debug", args=dict(msg="pre_tasks_msg_2")), register="pre_tasks_reg_2"),
        # TaskList(name="dummy_tasklist")
    ]

# Generated at 2022-06-25 05:27:23.585962
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a fake play object
    play = Play()

    # add in a fake role to test the method
    fake_role = Role()
    fake_role.handlers = [{'listen': 'first'}, {'handler': 'listen'}, {'listen': 'second'}]
    play.roles.append(fake_role)

    # compile the fake role handlers
    role_handler_blocks = play.compile_roles_handlers()

    # test that all the handlers were compiled correctly
    assert len(role_handler_blocks) == 3
    assert {'listen': 'first'} in role_handler_blocks
    assert {'handler': 'listen'} in role_handler_blocks
    assert {'listen': 'second'} in role_handler_blocks

    # test that the compiled handlers are in

# Generated at 2022-06-25 05:27:30.784431
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.serialize()


# Generated at 2022-06-25 05:27:37.963527
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create a new instance of class Play
    play_0 = Play()
    # Get attribute name from instance play_0
    name = play_0.name
    # Call method get_name with parameter name from instance play_0
    # and store the result in the variable result_get_name
    result_get_name = play_0.get_name(name)


# Generated at 2022-06-25 05:27:42.571978
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_1 = play_0.serialize()
    assert play_1 == {'_name': '', '_tasks': [], '_roles': [], '_post_tasks': [], '_handlers': [],
        '_pre_tasks': [], '_vars': {}, '_vars_files': []}


# Generated at 2022-06-25 05:27:48.036566
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    basedir = os.path.dirname(__file__)

    play = Play()
    play.load(
        play_source=dict(
            name="test",
            hosts=['all']),
        variable_manager=VariableManager(),
        loader=DictDataLoader({}))
    play.roles = [
        RoleInclude.load(
            dict(
                name=role_name,
                tasks_from=os.path.join(basedir, 'test_data'))
        )
        for role_name in ('test_role1', 'test_role2')
    ]

# Generated at 2022-06-25 05:27:55.411607
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.roles = [None]
    play_0_copy = play_0.copy()
    play_0_copy.roles[0].from_include = False
    play_0_copy.roles[0].get_handler_blocks = types.MethodType(lambda self, play: [None], play_0_copy.roles[0])
    block_list = play_0_copy.compile_roles_handlers()
    assert len(block_list) == 1
    assert block_list[0] is None


# Generated at 2022-06-25 05:28:03.845171
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    # Play play_1 instantiation
    play_1 = Play()

    # Task task_1 instantiation, setting attribute 'name' to 'test1'
    task_1 = Task()
    task_1.name = 'test1'

    # Task task_2 instantiation, setting attribute 'name' to 'test2'
    task_2 = Task()
    task_2.name = 'test2'

    # Play play_1_2 instantiation
    play_1_2 = Play()

    # Task task_2_2 instantiation, setting attribute 'name' to 'test2_2'
    task_2_2 = Task()
    task_2_2.name = 'test2_2'

    # Task task_3_2 instantiation, setting attribute 'name' to 'test3_2'

# Generated at 2022-06-25 05:28:07.250527
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    if len(play_1.roles) > 0:
        for r in play_1.roles:
            if r.from_include:
                continue
            block_list.extend(r.get_handler_blocks(play=play_1))
    return block_list

# Generated at 2022-06-25 05:28:12.281443
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_1.preprocess_data(ds={'hosts': 'all', 'user': 'root'})
    play_1.preprocess_data(ds={'hosts': 'all', 'remote_user': 'root'})
    play_1.preprocess_data(ds={'hosts': 'all', 'notuser': 'root'})
    play_1.preprocess_data(ds={'hosts': 'all', 'remote_user': 'root', 'user': 'root'})


# Generated at 2022-06-25 05:28:18.629134
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = [1, 2, 3, 4]
    # Method compile_roles_handlers should return the list of handler blocks
    assert play_1.compile_roles_handlers() == [4, 3, 1, 2]


# Generated at 2022-06-25 05:28:21.043964
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    # invoke method get_tasks of class Play
    play_0.get_tasks()


# Generated at 2022-06-25 05:28:32.458410
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    vars_files_0 = play_0.get_vars_files()
    assert isinstance(vars_files_0, list), 'get_vars_files() of Play must return a list.'


# Generated at 2022-06-25 05:28:36.928618
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    assert play_1.compile_roles_handlers() == []


# Generated at 2022-06-25 05:28:41.809227
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    assert(len(play_0.get_tasks()) == 0)
    play_0.tasks = [Task(), Task(), Task()]
    assert(len(play_0.get_tasks()) == 3)


# Generated at 2022-06-25 05:28:51.048389
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.playbook.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    play_1 = Play()
    play_1.vars = {'a': '1', 'b': '2'}
    play_1.vars_files = ['a.yml', 'b.yml']
    assert play_1.get_vars_files() == ['a.yml', 'b.yml']
    play_1.vars_files = ['a.yml']
    assert play_1.get_vars_files() == ['a.yml']
    play_1.vars_files = [{'a.yml', 'b.yml'}]
    assert play_1.get_vars

# Generated at 2022-06-25 05:29:01.278045
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-25 05:29:03.426429
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    print(play_1.serialize())


# Generated at 2022-06-25 05:29:07.779083
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_1 = Play()

    # test case 1
    play_1.vars_files = 'config.yml'
    #print(play_1.get_vars_files())

    # test case 2
    play_2 = Play()
    play_2.vars_files = ['config.yml']
    #print(play_2.get_vars_files())


# Generated at 2022-06-25 05:29:14.635279
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "test_name"
    assert play_0.get_name() == "test_name"
    assert play_0.name == "test_name"

    play_1 = Play()
    play_1.hosts = "test_hosts"
    assert play_1.get_name() == "test_hosts"
    assert play_1.name == "test_hosts"

    play_2 = Play()
    assert play_2.get_name() == ''
    assert play_2.name == ''


# Generated at 2022-06-25 05:29:20.993348
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create play
    play = Play()

    # Create roles to add as attribute of play
    # Role 1
    r1 = Role()
    r1.name = 'r1'

    # Role 2
    r2 = Role()
    r2.name = 'r2'

    # Role 3
    r3 = Role()
    r3.name = 'r3'

    # Create role_includes to add as attribute of play
    # Role include 1
    ri1 = RoleInclude()
    ri1.role = r1

    # Role include 2
    ri2 = RoleInclude()
    ri2.role = r2

    # Role include 3
    ri3 = RoleInclude()
    ri3.role = r3

    # Create handlers to add as attribute of r1
    # Handler 1


# Generated at 2022-06-25 05:29:24.043008
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    for task in play_0.pre_tasks + play_0.tasks + play_0.post_tasks:
        if isinstance(task, Block):
            tasklist.append(task.block + task.rescue + task.always)
        else:
            tasklist.append(task)

# Generated at 2022-06-25 05:29:45.519391
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # play_0 will have a list of value(s) in it's vars_files attribute.
    play_0 = Play()
    # play_1 will have a single value in it's vars_files attribute.
    play_1 = Play()
    # play_2 will have no value in it's vars_files attribute.
    play_2 = Play()
    # copy the attributes of play_2 to play_1
    play_1.__dict__.update(play_2.__dict__)
    # copy the attributes of play_1 to play_0
    play_0.__dict__.update(play_1.__dict__)
    # generate the expected results of the method get_vars_files of the class Play when called with the
    # arguments : play_0, play_1, play_2
    # method get

# Generated at 2022-06-25 05:29:53.076923
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    vars_manager = MockVariableManager()
    loader = DictDataLoader(dict(vars_manager._fact_cache))
    play_roles_data = dict(
        name="Test Play",
        hosts="all",
        remote_user="root",
        roles=[
            dict(
                name="role_0"
            ),
            dict(
                name="role_1"
            ),
            dict(
                name="role_2"
            )
        ]
    )

    # test
    play_roles = Play.load(play_roles_data, variable_manager=vars_manager, loader=loader)
    assert play_roles
    result = play_roles.compile_roles_handlers()
    assert result



# Generated at 2022-06-25 05:29:54.125678
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass


# Generated at 2022-06-25 05:29:59.826424
# Unit test for method serialize of class Play

# Generated at 2022-06-25 05:30:04.344229
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()

    role1 = Role()
    role1.name = "role1"
    role1.handlers = [{"include_role": "role2", "tasks": None, "tags": []}]
    role2 = Role()
    role2.name = "role2"
    role2.tag = ["tag1", "tag2"]
    role3 = Role()
    role3.name = "role3"
    play.roles = [role1, role2, role3]
    block_list = play.compile_roles_handlers()

    assert len(block_list) == 1
    assert block_list[0].tags == [u"tag1", u"tag2"]
    assert block_list[0].name == u"role2"



# Generated at 2022-06-25 05:30:08.070638
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    result = play_0.get_tasks()
    assert result == []


# Generated at 2022-06-25 05:30:10.565642
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    var_files_1 = play_0.get_vars_files()


# Generated at 2022-06-25 05:30:18.507503
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks = [
        Block(
            block=[
                Task.load({'action': {'__ansible_module__': 'setup'}})
            ]
        )
    ]

    tasks = play_0.get_tasks()
    if len(tasks) != 1:
        raise AssertionError("Expected len(play_0.get_tasks()) == 1, got %d" % len(tasks))


# Generated at 2022-06-25 05:30:24.376105
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_1 = Play()
    role_2 = Role()
    role_2.name = "foo"
    role_2.serialize = lambda: {'name': 'foo'}
    role_2.deserialize = lambda x: x
    role_2.load = lambda x, play: x
    setattr(play_1, 'roles', [role_2])
    setattr(play_1, '_included_path', "/Users/charlesmartin/ansible/ansible/lib/ansible/playbook/play_include.yml")
    setattr(play_1, '_action_groups', {})
    setattr(play_1, '_group_actions', {})
    setattr(play_1, '_ds', {})
    serialize_0

# Generated at 2022-06-25 05:30:32.948787
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = [
        Module("shell", {"_raw_params": "echo", "_uses_shell": True}),
        Module("shell", {"_raw_params": "echo", "_uses_shell": True}),
        Module("shell", {"_raw_params": "echo", "_uses_shell": True}),
        Module("shell", {"_raw_params": "echo", "_uses_shell": True}),
        Module("shell", {"_raw_params": "echo", "_uses_shell": True})
    ]

# Generated at 2022-06-25 05:30:55.678880
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    play_1 = Play()
    play_1.pre_tasks = [{"block": [{"local_action": {"module": "debug",
                                                     "args": {"msg": "In pre_tasks"}}},
                                   {"local_action": {"module": "debug",
                                                     "args": {"msg": "In pre_tasks"}}},
                                   {"local_action": {"module": "debug",
                                                     "args": {"msg": "In pre_tasks"}}}]}]

# Generated at 2022-06-25 05:31:03.226450
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Parameter: Path to file if vars_files is defined in the Play
    play_0 = Play()
    play_0.vars_files = "/home/foo/bar"

    expected_0 = ["/home/foo/bar"]
    actual_0 = play_0.get_vars_files()

    assert expected_0 == actual_0

# Generated at 2022-06-25 05:31:14.269401
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """
    #
    # Method called by Play.compile
    #
    # This is called twice by Play.compile.  The first time is
    # to compile handlers defined in the play and the second time
    # is to compile handlers defined in the roles.
    # The handlers from the roles are prepended to the handlers
    # from the play.
    #
    # Arguments:
    #   attr - Not used
    #   ds   - Not used
    #
    # Returns:
    #   A list of Block objects
    #
    """
    play_1 = Play()
    play_1._variable_manager = VariableManager()
    play_1._loader = DataLoader()
    play_1._tqm = TaskQueueManager()
    play_1.hosts = ['host_0']
    play_1

# Generated at 2022-06-25 05:31:17.343574
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()

# Generated at 2022-06-25 05:31:25.541472
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.hosts = ['localhost']
    assert play_1.get_name() == 'localhost'
    play_1.name = 'test'
    assert play_1.get_name() == 'test'
    play_1.hosts = ['localhost', '127.0.0.1']
    assert play_1.get_name() == 'localhost,127.0.0.1'


# Generated at 2022-06-25 05:31:29.233540
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()

    # case 1 - default case
    assert play.get_name() == None

    # case 2 - with name is not none
    play.name = "abc"
    assert play.get_name() == "abc"


# Generated at 2022-06-25 05:31:41.440402
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    host1 = Hosts([])
    host1.name = 'localhost'
    host1.port = 22
    host1.interpreter = '/bin/bash'
    host1.extravars = {'ansible_user': 'vagrant', 'ansible_password': 'vagrant', 'ansible_port': '22'}
    host1.ansible_connection = 'local'
    host1.vars = {'ansible_connection': 'local'}

    host2 = Hosts([])
    host2.name = 'host2'
    host2.port = 22
    host2.interpreter = '/bin/bash'
    host2.extravars = {'ansible_user': 'vagrant', 'ansible_password': 'vagrant', 'ansible_port': '22'}

# Generated at 2022-06-25 05:31:52.978012
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-25 05:31:58.850015
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    play_1.vars = {'k_0': 'v_0'}
    play_1.hosts = 'localhost'
    play_1.name = 'Play_0'
    play_1.port = 20
    play_1.roles = ['role_0']
    play_1.connection = 'ssh'
    play_1._variable_manager = 'VariableManager_0'
    play_1._loader = 'Loader_0'
    play_1._included_path = 'included_path_0'
    play_1._action_groups = {'k_0': 'v_0'}
    play_1._group_actions = {'k_0': 'v_0'}
    play_1.gather_facts = True
    play_1.max_

# Generated at 2022-06-25 05:32:05.733798
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    variables_1 = dict()
    variables_1['hosts'] = 'test_host'
    play_1 = Play()
    play_1.vars_files = ['test_path']
    #import pdb; pdb.set_trace()
    result = play_1.get_vars_files()
    assert result == ["test_path"]


# Generated at 2022-06-25 05:32:38.605995
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """Test get_tasks method of class Play"""
    import pudb; pu.db
    yaml_file = "../../../../../lib/galaxy/importer/content/sample_playbook.yml"
    with open(yaml_file) as f:
        play_dict = yaml.load(f)
    play = Play.load(play_dict, variable_manager=None, loader=None)
    play.deserialize(play.serialize())
    play.get_tasks()

if __name__ == "__main__":
    test_case_0()
    test_Play_get_tasks()
    print("Done")

# Generated at 2022-06-25 05:32:42.012737
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    try:
        play_1 = Play()
        result_1 = play_1.compile_roles_handlers()
        assert result_1 == [], "compile_roles_handlers returned %s, expected %s" % (result_1, [])
    except Exception as e:
        raise e


# Generated at 2022-06-25 05:32:47.220626
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    role_1 = Role()
    role_2 = Role()
    role_3 = Role()

    play_1.roles.append(role_1)
    play_1.roles.append(role_2)
    play_1.roles.append(role_3)

    # Check on empty
    assert play_1.compile_roles_handlers() == []

    handler_1 = Handler()
    handler_2 = Handler()
    handler_3 = Handler()

    role_1.handlers.append(handler_1)
    role_1.handlers.append(handler_2)

    role_2.handlers.append(handler_3)

    assert play_1.compile_roles_handlers() == [handler_1, handler_2, handler_3]

# Generated at 2022-06-25 05:32:49.766020
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # init test vars
    play_0 = Play()
    def test_task_0():
        pass
    def test_task_1():
        pass
    play_0.tasks = [test_task_0, test_task_1]
    res = play_0.get_tasks()
    exp = [test_task_0, test_task_1]
    assert res == exp


# Generated at 2022-06-25 05:32:52.280102
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    json_result = play_0.serialize()
    assert isinstance(json_result, dict)


# Generated at 2022-06-25 05:32:56.119503
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.name is None
    play_0.name = "TestPlayName"
    assert play_0.get_name() == "TestPlayName"
    play_0.name = None
    play_0.hosts = '127.0.0.1'
    assert play_0.get_name() == '127.0.0.1'


# Generated at 2022-06-25 05:32:59.273918
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    print(Fore.YELLOW+"Test for compile_roles_handlers for Play")
    test_case_0()
    play_0 = Play()
    result_0 = play_0.compile_roles_handlers()
    assert_equals(result_0, [])
    print(Fore.GREEN+"Test for compile_roles_handlers for Play passed")


# Generated at 2022-06-25 05:33:03.937240
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    Play_0 = Play()
    Play_0._variable_manager = MagicMock()
    Play_0._loader = MagicMock()
    Play_0.vars_files = ['test_value_0']
    return_value_0 = Play_0.get_vars_files()
    assert return_value_0 == ['test_value_0']

# Generated at 2022-06-25 05:33:10.829108
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    play_1.vars_files = None
    assert play_1.get_vars_files() == []

    play_2 = Play()
    play_2.vars_files = '/dev/null'
    assert play_2.get_vars_files() == ['/dev/null']

    play_3 = Play()
    play_3.vars_files = ['/dev/null1', '/dev/null2']
    assert play_3.get_vars_files() == ['/dev/null1', '/dev/null2']


# Generated at 2022-06-25 05:33:15.228642
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_case_0()
    inst = Play()
    assert inst.get_tasks() == [], 'Method failed to return correct value'


# Generated at 2022-06-25 05:33:44.499985
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Create a new Play object
    play_0 = Play()

    # Create a variable for the variable_manager object
    variable_manager_0 = play_0.variable_manager

    # Access the variable "vars_files" in the variable_manager object
    result = variable_manager_0.vars_files

    # Assert "result" is false
    assert not result


# Generated at 2022-06-25 05:33:45.385220
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass


# Generated at 2022-06-25 05:33:47.991660
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1._load_roles(None, [{'role': 'tasks/main.yml'}])


# Generated at 2022-06-25 05:33:50.914778
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = list()
    assert isinstance(play_0.get_vars_files(), list)


# Generated at 2022-06-25 05:33:52.005154
# Unit test for constructor of class Play
def test_Play():
    play_0 = Play()

# Test for load method of class Play

# Generated at 2022-06-25 05:33:55.955233
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_cases = [
        (test_case_0, ""),
    ]

    for t in test_cases:
        yield play_get_name_run, t[0], t[1]


# Generated at 2022-06-25 05:33:59.868194
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

    # Verify that the second task in play_1.tasks is an instance of Task
    assert isinstance(play_1.tasks[1], Task)

    assert isinstance(play_1.get_tasks()[0], Task)

    for item in play_1.get_tasks():
        assert isinstance(item, Task)
