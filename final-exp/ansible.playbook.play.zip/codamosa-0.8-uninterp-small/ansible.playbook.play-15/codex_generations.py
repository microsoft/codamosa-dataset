

# Generated at 2022-06-25 05:24:29.049916
# Unit test for method load of class Play
def test_Play_load():
    play_1 = Play()
    play_1.load(data={'foo': 'bar'}, variable_manager={}, loader={})


# Generated at 2022-06-25 05:24:30.488527
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.get_vars_files() == []


# Generated at 2022-06-25 05:24:33.723434
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    play_2 = play_1.deserialize({})
    assert play_1 == play_2, "Objects play_1 and play_2 do not match"


# Generated at 2022-06-25 05:24:42.966153
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_case = [
      {
        'in': None,
        'out': [],
      },
      {
        'in': {u'vars_files': 'f1'},
        'out': ['f1'],
      },
      {
        'in': {u'vars_files': ['f1', 'f2']},
        'out': ['f1', 'f2'],
      },
    ]
    for case in test_case:
        p = Play()
        p._ds = case['in']
        taskfiles = p.get_vars_files()
        assert taskfiles == case['out']


# Generated at 2022-06-25 05:24:51.563794
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()

# Generated at 2022-06-25 05:24:53.052208
# Unit test for method load of class Play
def test_Play_load():
    # Constructs a test Play object.
    play_1 = Play(name='foo')


# Generated at 2022-06-25 05:24:59.383150
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create a Play object
    play_0 = Play()

    # Create a list to be used as a test parameter
    test_ds = []

    # The following line should not throw an error.
    play_0.preprocess_data(ds=test_ds)


# Generated at 2022-06-25 05:25:02.607785
# Unit test for method load of class Play
def test_Play_load():
    play_0 = Play.load(data)
    ansible_play_0 = Play()
    assert play_0.name == ansible_play_0.name
    assert play_0.hosts == ansible_play_0.hosts
    assert play_0.vars_files == ansible_play_0.vars_files
    assert play_0.tasks == ansible_play_0.tasks
    assert play_0.handlers == ansible_play_0.handlers
    assert play_0.roles == ansible_play_0.roles


# Generated at 2022-06-25 05:25:10.486289
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''
    play.name = 'test_name'
    assert play.get_name() == 'test_name'
    play.hosts = 'test_hosts'
    assert play.get_name() == 'test_hosts'
    play.name = None
    assert play.get_name() == 'test_hosts'


# Generated at 2022-06-25 05:25:11.890929
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()

    assert type(play).get_tasks() == list



# Generated at 2022-06-25 05:25:24.761736
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = []
    assert play_0.get_vars_files() == []
    play_0.vars_files = 'test/files/test_Play.vars_files'
    assert play_0.get_vars_files() == ['test/files/test_Play.vars_files']
    play_0.vars_files = ['a', 'b', 'c']
    assert play_0.get_vars_files() == ['a', 'b', 'c']


# Generated at 2022-06-25 05:25:35.164499
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # In order to test the preprocess_data method, we will set a MockPlay object with a basic ds
    # and then we will test if the method returns the expected value when called
    play_1 = MockPlay()
    play_1.preprocess_data({'any_key': 'any_value'})
    assert play_1.ds == {'any_key': 'any_value'}

    play_2 = MockPlay()
    play_2.preprocess_data({'any_key': 'any_value', 'user': 'test_user'})
    assert play_2.ds == {'any_key': 'any_value', 'remote_user': 'test_user'}

    play_3 = MockPlay()

# Generated at 2022-06-25 05:25:42.502282
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from test.unit.parsing.loader import load_from_file
    play_0 = load_from_file('test/unit/parsing/fixtures/roles_extends/play_0.yaml')
    play_0._validate_attrs({'hosts': {}})
    #
    # The use of the 'user' key in the Play YAML datastructure was
    # deprecated. This test ensures that it's properly replaced with
    # 'remote_user'.
    assert 'user' in play_0._ds
    play_0.preprocess_data(play_0._ds)
    assert 'user' not in play_0._ds
    assert 'remote_user' in play_0._ds


# Generated at 2022-06-25 05:25:45.216022
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    try:
        # Setup data
        play_0 = Play()

        # Test method
        test_result = play_0.compile_roles_handlers()

        # Verify results
        assert test_result == []
    except Exception as e:
        print("Exception caught in test_Play_compile_roles_handlers()")
        print("Exception: " + str(e))
        raise


# Generated at 2022-06-25 05:25:51.201822
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.tasks = [{}, {}]
    play_1.pre_tasks = [{}, {}]
    play_1.post_tasks = [{}, {}]

    tasklist = play_1.get_tasks()
    assert len(tasklist) == 6


# Generated at 2022-06-25 05:25:59.130558
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # data from an existing playbook
    ds = {
        'name': 'Setup a master/slave Redis with Sentinel servers',
        'hosts': 'redis-servers',
        'gather_facts': 'no',
        'roles': [
            'common',
            'redis_sentinel_master',
            'redis_sentinel_slaves',
        ],
    }

    # initialise the play
    play = Play()
    # initialise the default data values
    play.set_loader(DataLoader())
    play.set_variable_manager(VariableManager())

    # preprocess the data
    play.preprocess_data(ds)

    # the user field should have been renamed to remote_user
    assert 'user' not in ds
    assert 'remote_user' in ds

    # the name

# Generated at 2022-06-25 05:26:09.228743
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    Test preprocess_data of Play class

    Play's preprocess_data method, when called with a dict of data, should preprocess the data.
    The data, though not a simple dictionary, should always be a dictionary, or else,
    an exception should be thrown.
    The preprocessed data has to be returned.
    '''

    # create a dict of data
    data = dict({'hosts': 'all'})

    # create a new object of Play class
    play_0 = Play()

    # play_0.preprocess_data should return the data dict
    assert play_0.preprocess_data(data) == data

    # the data has to be a dict
    with pytest.raises(AssertionError):
        data = ('a', 'b', 'c')
        play_0.preprocess_

# Generated at 2022-06-25 05:26:15.616072
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play._roles = []

    a = Handler()
    b = Handler()
    c = Handler()
    d = Handler()

    play.handlers.append(a)
    play.handlers.append(b)

    play._roles.append(Role())
    play._roles[0]._handlers = [c]

    play._roles.append(Role())
    play._roles[1]._handlers = [d]

    handlers = play.compile_roles_handlers()

    assert len(handlers) == 4
    for handler in handlers:
        assert isinstance(handler, Handler)


# Generated at 2022-06-25 05:26:22.795170
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print("Testing get_tasks...")
    play_0 = Play()
    task_1 = Task()
    block_2 = Block()
    block_2.block = [task_1]
    play_0.pre_tasks = [task_1]
    play_0.post_tasks = [task_1]
    play_0.tasks = [block_2]
    tasklist = play_0.get_tasks()
    print("The length of tasklist is " + str(len(tasklist)))
    for task in tasklist:
        print(task)
        print("The name of task is " + str(task.name))



# Generated at 2022-06-25 05:26:26.817331
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds_0 = {'hosts': 'Test'}
    play_0 = Play()
    try:
        play_0.preprocess_data(ds_0)
        assert False
    except Exception as e:
        assert str(e) == "while preprocessing data ({'hosts': 'Test'}), ds should be a dict but was a <class 'dict'>"


# Generated at 2022-06-25 05:26:39.790656
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    if not play_0.get_tasks():
        return False


# Generated at 2022-06-25 05:26:41.542001
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()

    assert isinstance(play_1.get_vars_files(), list)


# Generated at 2022-06-25 05:26:42.547844
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    assert play.get_tasks() == []


# Generated at 2022-06-25 05:26:53.624123
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks = [{"connection": "smart", "name": "test task", "action": {"__ansible_arguments__": [{"value": "ls"}], "__ansible_module__": "shell"}}]
    play_0.vars = {"test": "hello"}
    play_0.hosts = "localhost"
    play_0.post_tasks = [{"connection": "smart", "name": "test task2", "action": {"__ansible_arguments__": [{"value": "echo hello"}], "__ansible_module__": "shell"}}]

# Generated at 2022-06-25 05:27:03.900657
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p
    assert p.hosts == 'all'
    assert not p.gather_facts
    assert not p.connection
    assert not p.vars
    assert not p.vars_files
    assert not p.vars_prompt
    assert not p.vars_files_prompt
    assert not p.handlers
    assert not p.tasks
    assert not p.roles
    assert not p.dep_chain
    assert p.name == ''
    assert p.serial == 100
    assert p.max_fail_percentage == 0
    assert not p.ROLE_CACHE
    assert not p._included_conditional
    assert not p._included_path
    assert not p._removed_hosts
    assert not p._action_groups
    assert not p

# Generated at 2022-06-25 05:27:12.171473
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Play-0
    # Play-0.1
    play_0_1 = Play()
    play_0_1.deserialize({'serial': 1, 'hosts': 'localhost', 'name': 'tasks', 'roles': [], 'vars': {}, 'tasks': [], 'handlers': []})
    assert play_0_1.serial == 1
    assert play_0_1.hosts == 'localhost'
    assert play_0_1.name == 'tasks'
    assert play_0_1.roles == []
    assert play_0_1.vars == {}
    assert play_0_1.tasks == []
    assert play_0_1.handlers == []

    play_0_2 = Play()

# Generated at 2022-06-25 05:27:18.416688
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_1 = Play()
    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    block_0 = Block()
    block_1 = Block()

    block_0.block = [task_1]
    block_0.rescue = [task_2]
    block_0.always = [task_0]

    block_1.block = [task_0]
    block_1.rescue = [task_1]
    block_1.always = [task_2]

    play_0.tasks = [task_0, task_1, task_2]
    play_0.pre_tasks = [task_0, task_1, task_2]

# Generated at 2022-06-25 05:27:26.259803
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Class instance creation
    play_0 = Play()
    # Test method serialize of class Play
    play_serialize = play_0.serialize()
    if (not (isinstance(play_serialize, dict))):
        print("Failed test_Play_serialize: Method serialize of class Play returned: %s. Expected: %s" % (type(play_serialize), dict))
        return -1
    print("test_Play_serialize passed!")
    return 0


# Generated at 2022-06-25 05:27:32.462950
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play.load(dict(
        name="test_play",
        hosts=["host1", "host2"],
        roles=[
            dict(
                name="test_role",
                handlers=[
                    "handler_task_1",
                    "handler_task_2"
                ]
            )
        ]
    ))


# Generated at 2022-06-25 05:27:35.882549
# Unit test for method serialize of class Play
def test_Play_serialize():
    # todo: add test for serializing a Play object
    pass


# Generated at 2022-06-25 05:27:53.380607
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # Test case 0
    play = Play()
    ds = {"name": "test data","hosts": "group1", "user": "user1"}
    play.preprocess_data(ds)
    assert play.remote_user == "user1" and play.hosts == "group1"
    assert play.name == "test data"

    # Test case 1
    ds = {"name": "test data","hosts": "group1", "user": "user1", "tasks": []}
    play.preprocess_data(ds)
    assert play.remote_user == "user1" and play.hosts == "group1"
    assert play.name == "test data"


# Generated at 2022-06-25 05:27:55.766911
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    vars_files = play_0.get_vars_files()
    assert isinstance(vars_files, list)


# Generated at 2022-06-25 05:28:04.124897
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    play_1 = Play()
    play_2 = Play()

    try:
        play_0.preprocess_data('foobar')
    except AnsibleAssertionError:
        pass
    else:
        assert False

    data_0 = { 'user': 'foobar' }
    ds_0 = play_1.preprocess_data(data_0)
    assert ds_0.get('remote_user', None) == 'foobar'
    assert 'user' not in ds_0

    ds_1 = play_2.preprocess_data(data_0)
    assert ds_1.get('remote_user', None) == 'foobar'
    assert 'user' not in ds_1



# Generated at 2022-06-25 05:28:11.011986
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test case where there are no roles and no handlers
    # Expect to get back []
    play_0_compile_roles_handlers = Play().compile_roles_handlers()
    assert play_0_compile_roles_handlers == []
    # Test case where there is one role and no handlers
    # Expect to get back [Handler(<ansible.playbook.handler.Handler object at 0x10b5a5c50>)]
    play_1_compile_roles_handlers = Play(roles=[Role()]).compile_roles_handlers()
    assert play_1_compile_roles_handlers == [Handler(handler.Handler())]
    # Test case where there is one role and one handler
    # Expect to get back [Handler(<ansible.playbook.handler.Handler object

# Generated at 2022-06-25 05:28:21.895587
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test Play name
    play_2 = Play()
    play_2.name = 'test_play'
    assert play_2.get_name() == 'test_play'
    # Test Play name with host list
    play_3 = Play()
    play_3.hosts = 'test_host'
    assert play_3.get_name() == 'test_host'
    play_4 = Play()
    play_4.hosts = ['test_host1', 'test_host2']
    assert play_4.get_name() == 'test_host1,test_host2'
    play_5 = Play()
    play_5.hosts = []
    assert play_5.get_name() == ''

# Unit test to make sure the Play object can handle roles

# Generated at 2022-06-25 05:28:28.009146
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Load play
    ds = load_data_file(path=get_data_file_path(DATA_PATH + "playbook.yml"))[0]
    play = Play.load(ds, variable_manager=VariableManager(), loader=DictDataLoader())
    play.vars_files = [
        { 'role': 'common', 'vars_files': '{{ playbook_dir }}/../../roles/common/vars/main.yml' },
        { 'name': '{{ playbook_dir }}/../../roles/common/vars/name.yml' }
    ]

    vars_files = play.get_vars_files()

# Generated at 2022-06-25 05:28:33.524929
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Test with default Play object
    play_default = Play()
    play_default_ds = {
        'hosts': '',
        'name': '',
        'no_log': False,
        'roles': [],
        'tags': []
    }
    assert play_default.serialize() == play_default_ds

    # Test with custom Play object
    play_custom = Play()
    play_custom.name = 'test_play_name'
    play_custom.hosts = 'test_play_hosts'
    play_custom_ds = {
        'hosts': play_custom.hosts,
        'name': play_custom.name,
        'no_log': False,
        'roles': [],
        'tags': []
    }

# Generated at 2022-06-25 05:28:42.519931
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    assert play_1.get_vars_files() == []
    play_2 = Play()
    play_2.vars_files = None
    assert play_2.get_vars_files() == []
    play_3 = Play()
    play_3.vars_files = ['var_file1.yml', 'var_file2.yml', 'var_file3.yml']
    assert play_3.get_vars_files() == ['var_file1.yml', 'var_file2.yml', 'var_file3.yml']
    play_4 = Play()
    play_4.vars_files = 'var_file1.yml'
    assert play_4.get_vars_files() == ['var_file1.yml']

# Generated at 2022-06-25 05:28:52.849906
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test cases
    play_0 = Play()
    play_0.hosts = 'localhost'
    play_0.name = 'Test Play'
    play_0.roles = []
    # Test case 1
    block_list = play_0.compile_roles_handlers()
    assert block_list == [], "Failed test case 1 in test_Play_compile_roles_handlers"

    # Test case 2
    role_0 = Role()
    role_0.default_vars = {}
    role_0.vars = {}
    role_0.block = []
    role_0.always = []
    role_0.rescue = []
    role_0.meta = []
    role_0.hosts = 'localhost'

# Generated at 2022-06-25 05:29:00.138665
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    for tc in test_cases:
        obj = Play()
        obj.pre_tasks = tc[0]
        obj.tasks = tc[1]
        obj.post_tasks = tc[2]

        task_list = obj.get_tasks()
        assert tc[3] == task_list


# Method: get_vars
#  Tests obj.get_vars() with several different values of obj.vars.
#  Confirms dict returned is a deep copy of obj.vars.

# Generated at 2022-06-25 05:29:09.764320
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_case_0()



# Generated at 2022-06-25 05:29:12.880649
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = []
    assert play.compile_roles_handlers() == []
    play.roles = [Role()]
    assert isinstance(play.compile_roles_handlers(), list)


# Generated at 2022-06-25 05:29:17.519824
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Creation of mock object
    play_0 = Play()
    # Test with no var_files
    assert play_0.get_vars_files() == []
    # Test with only one var file
    var_file = {}
    play_0.vars_files = var_file
    assert play_0.get_vars_files() == [var_file]
    # Test with several var files
    var_files = []
    play_0.vars_files = var_files
    assert play_0.get_vars_files() == []


# Generated at 2022-06-25 05:29:20.196820
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    block = Block()
    task = Task()
    block.block = [task]
    role = Role()
    role.handlers = [block]
    play.roles = [role]
    assert play.compile_roles_handlers()[0] == block


# Generated at 2022-06-25 05:29:23.357620
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_cases = [
        # play_0.get_tasks()
        test_case_0
    ]
    for test_case_i in test_cases:
        test_case_i()

# Generated at 2022-06-25 05:29:29.228853
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = list()
    roles = list()
    role = Role()
    role.compile_handlers = list()
    roles.append(role)
    play_1.roles = roles
    test_compile_roles_handlers = play_1.compile_roles_handlers()
    assert test_compile_roles_handlers == role.compile_handlers

test_case_0()
test_Play_compile_roles_handlers()

# Generated at 2022-06-25 05:29:40.415162
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:29:41.507909
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_case_0()

# Generated at 2022-06-25 05:29:51.434577
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    # the test data was taken from a playbook
    # the data structure has been modified to include
    # the bare minimum fields so that the method can be
    # tested.
    data_structure = {
        'hosts': 'all',
        'connection': 'local',
        'vars': {
            'test_var': 'test_val'
            },
        'tasks': [
            {
                'name': 'test_task',
                'setup': 'test_result',
                'ignore_errors': 'yes'
                }
            ]
        }

# Generated at 2022-06-25 05:30:03.509625
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # Step 1: Create an instance of class Play
    play_1 = Play()

    # Step 2: Create an instance of class Role
    role_1 = Role()

    # Step 3: Create an instance of class RoleInclude
    role_include_1 = RoleInclude()

    # Step 4: Set the attributes of role_include_1
    role_include_1.name = "myrole"
    role_include_1.play = play_1
    role_include_1.role = role_1
    role_include_1.task_includes = ['main.yml']
    role_include_1.handlers = ['notify.yml']

    # Step 5: Update the attribute role of play_1
    play_1.roles = [role_1]

    # Step 6: Call the method compile_roles_hand

# Generated at 2022-06-25 05:30:24.822633
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    name = 'test_name'
    setattr(play, 'name', name)
    assert play.get_name() == name


# Generated at 2022-06-25 05:30:31.584883
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0._load_roles = Mock(return_value = [])
    with patch.object(Play, 'get_roles', return_value = []):
        play_0.compile_roles_handlers()

    play_0 = Play()
    play_1 = Play()
    mock_load_roles = Mock()
    mock_get_handler_blocks = Mock()
    with patch.object(Play, 'get_roles', return_value = [play_1]):
        play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:30:36.756450
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_1 = Play()
    play_2 = Play()
    try:
        play_0.compile_roles_handlers()
        play_1.compile_roles_handlers()
        play_2.compile_roles_handlers()
    except:
        traceback.print_exc()



# Generated at 2022-06-25 05:30:41.490829
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.name is None
    assert play._ds is None
    assert play.hosts == 'all'
    assert play.hosts_pattern is None
    assert repr(play) == ''
    assert not play.force_handlers
    assert play.max_fail_percentage == 0
    assert play.serial == []
    assert play.strategy == 'linear'
    assert play.tags == frozenset(('all',))
    assert play.skip_tags == set([])
    assert play.only_tags == set([])


# Generated at 2022-06-25 05:30:46.307756
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "play_0"
    play_0.hosts = "hosts_0"

    assert play_0.get_name() == "play_0"


# Generated at 2022-06-25 05:30:48.749253
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Initialization
    play_0 = Play()
    # Execution
    result_0 = play_0.get_tasks()
    # Verification
    assert(result_0 == [])



# Generated at 2022-06-25 05:30:56.733936
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import unittest
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    class Test_0(unittest.TestCase):
        def test_0(self):
            play_0 = Play()
            play_0.tasks = [
                Task(),
                Task(),
                Task(),
            ]
            play_0.post_tasks = [
                Task(),
                Task(),
                Task(),
            ]
            play_0.pre_tasks = [
                Task(),
                Task(),
                Task(),
            ]
            self.assertEqual(play_0.get_tasks(), [Task(), Task(), Task(), Task(), Task(), Task(), Task(), Task(), Task()])

        def test_1(self):
            play_0 = Play()

# Generated at 2022-06-25 05:30:59.154898
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a test Play instance
    play_0 = Play()

    # Retrieve tasks from the Play
    play_0_tasks = play_0.get_tasks()

    # Check that the first task is Block
    assert(isinstance(play_0_tasks[0], Block))


# Generated at 2022-06-25 05:31:02.258038
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    ds_0 = dict()
    ds_0['roles'] = []
    ds_0['hosts'] = 'magic'
    ds_0['tasks'] = []
    play_0 = Play()
    play_0.load_data(ds_0)
    play_0.get_tasks()


# Generated at 2022-06-25 05:31:07.986704
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    assert play_1.get_vars_files() == []
    play_1.vars_files = []
    assert play_1.get_vars_files() == []
    play_1.vars_files = ''
    assert play_1.get_vars_files() == []
    play_2 = Play()
    play_2.vars_files = ''
    assert play_2.get_vars_files() == []
    play_2.vars_files = []
    assert play_2.get_vars_files() == []
    play_3 = Play()
    play_3.vars_files = '/etc/ansible'
    assert play_3.get_vars_files() == ['/etc/ansible']
    play_4 = Play()


# Generated at 2022-06-25 05:31:28.335515
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play.load("---\n- hosts: localhost")
    play_0.deserialize({})
    


# Generated at 2022-06-25 05:31:40.391706
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    tasks = []
    t1 = Task()
    t1.set_loader(DictDataLoader({}))
    t1._ds = dict(action='a1')
    t1.action = 'a1'
    t1._parent = play
    t1.validate()
    tasks.append(t1)
    b1 = Block()
    b1._ds = dict(block=tasks)
    b1.block = tasks
    b1.rescue = []
    b1.always = []
    b1._parent = play
    b1.validate()
    tasks.append(b1)
    play.tasks = tasks
    play.pre_tasks = []
    play.post_tasks = []
    play.name = ''

# Generated at 2022-06-25 05:31:42.734784
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    if not isinstance(play_0.get_vars_files(), list):
        raise AssertionError()


# Generated at 2022-06-25 05:31:47.339016
# Unit test for method get_name of class Play
def test_Play_get_name():
    # creating test data
    play_1 = Play()
    # assigning attribute play_1.name
    play_1.name = 'test'
    # calling test method
    assert play_1.get_name() == 'test'


# Generated at 2022-06-25 05:31:57.613043
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = "test_play_1"

    assert play_1.get_name() == "test_play_1"

    play_2 = Play()
    play_2.hosts = "host_1,host_2"

    assert play_2.get_name() == "host_1,host_2"

    play_3 = Play()
    play_3.hosts = []

    assert play_3.get_name() == ""

    play_4 = Play()
    assert play_4.get_name() == ""


# Generated at 2022-06-25 05:32:09.794762
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a fake play
    play = Play()
    play.roles = []
    # create a fake role
    role = Role()
    role.handlers = []
    role_handler_1 = Handler()
    role_handler_2 = Handler()
    role.handlers.append(role_handler_1)
    role.handlers.append(role_handler_2)
    play.roles.append(role)
    # create another fake role
    role2 = Role()
    role2.handlers = []
    role_handler_3 = Handler()
    role2.handlers.append(role_handler_3)
    play.roles.append(role2)
    # create a play handler
    play_handler = Handler()
    play.handlers.append(play_handler)
    # compile roles and handlers


# Generated at 2022-06-25 05:32:21.175211
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:32:30.839781
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # play_0 = Play()
    # play_0.vars_files = None
    # assert play_0.get_vars_files() == []
    # play_0.vars_files = '/path/to/file.yml'
    # assert play_0.get_vars_files() == ['/path/to/file.yml']
    play_1 = Play()
    play_1.vars_files = ['/path/to/file.yml', '/path/to/file2.yml']
    assert play_1.get_vars_files() == ['/path/to/file.yml', '/path/to/file2.yml']

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:32:31.968999
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()

# Generated at 2022-06-25 05:32:36.473465
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pl = Play()
    assert pl.compile_roles_handlers() == ([])


# Generated at 2022-06-25 05:33:14.875215
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    #print(play_0.compile_roles_handlers())
    print(play_0)




# Generated at 2022-06-25 05:33:24.294289
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    # tasks:
    #   - name: "task0"
    #     shell: "echo hello"
    #   - name: "task1"
    #     shell: "echo world"
    data = dict(
        name = "a play",
        hosts = "all",
        gather_facts = "no",
        tasks = [
            dict(name="task0", shell="echo hello"),
            dict(name="task1", shell="echo world")
        ]
    )

    play_0 = Play.load(data)
    play_1 = copy.deepcopy(play_0)

    tasks_0 = play_0.get_tasks()
    tasks_1 = play_1.get_tasks()


# Generated at 2022-06-25 05:33:35.959849
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.hosts = "hosts_0"
    play_1.name = "name_0"
    play_1.vars = dict()
    play_1.vars_prompt = dict()
    play_1.vars_files = list()
    play_1.tags = list()
    play_1.roles = list()
    play_1.tasks = list()
    play_1.handlers = list()
    play_1.collections = list()
    play_1.pre_tasks = list()
    play_1.post_tasks = list()
    assert isinstance(play_1.compile_roles_handlers(), list)


# Generated at 2022-06-25 05:33:37.065318
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_1.preprocess_data({})


# Generated at 2022-06-25 05:33:43.436154
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import datetime 
    
    # Default test
    play_0 = Play()
    tasks = play_0.get_tasks()
    assert tasks is not None
    
    # Create play with tasks
    tasks_0 = [1, 2, 3]
    play_1 = Play(tasks=tasks_0)
    tasks = play_1.get_tasks()
    assert tasks == tasks_0
    
    # Create play with pre-tasks and post-tasks
    tasks_0 = [1, 2, 3]
    tasks_1 = [3, 4, 5]
    tasks_2 = [6, 7, 8]
    play_2 = Play(pre_tasks=tasks_0, post_tasks=tasks_1)
    tasks = play_2.get_tasks()

# Generated at 2022-06-25 05:33:52.909429
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.utils.addresses import parse_address
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class TestCallback(CallbackBase):
        pass

    class PlayBook:
        def __init__(self):
            self.hostvars = {}

    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()
    play_book = PlayBook()
    play_book.tasks = []
    play_book.handlers = []
    play_book.default_vars = {}
    play_book.roles = []
    play_book.inventory = Mock()
    play_book.inventory.groups_

# Generated at 2022-06-25 05:34:01.867691
# Unit test for method get_vars_files of class Play