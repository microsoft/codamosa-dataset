

# Generated at 2022-06-25 05:24:27.201145
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = {
        'hosts': 'hostname',
        'user': 'test'
    }
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()
    assert isinstance(play.preprocess_data(data), dict)


# Generated at 2022-06-25 05:24:37.526351
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    # AssertionError raised?
    play_1 = Play()
    # AssertionError raised?
    play_2 = Play()
    # AssertionError raised?
    play_3 = Play()
    # AssertionError raised?
    play_4 = Play()
    # AssertionError raised?
    play_5 = Play()
    # AssertionError raised?
    play_6 = Play()
    # AssertionError raised?
    play_7 = Play()
    # AssertionError raised?
    play_8 = Play()
    # AssertionError raised?
    play_9 = Play()
    # AssertionError raised?
    play_10 = Play()
    # AssertionError raised?
    play_11 = Play()
    # Assert

# Generated at 2022-06-25 05:24:47.481163
# Unit test for constructor of class Play

# Generated at 2022-06-25 05:24:55.380259
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()

    play_serialize_expected = {'name': ''}
    play_serialized_actual = play_0.serialize()

    assert play_serialize_expected == play_serialized_actual, \
        "Error serializing a Play object. Expected {}, but received {}.".format(
            play_serialize_expected,
            play_serialized_actual,
        )


# Generated at 2022-06-25 05:25:02.967845
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    block_1 = Block()
    block_2 = Block()
    role_1 = Role()
    role_1.set_handlers([block_1])
    role_2 = Role()
    role_2.set_handlers([block_2])
    play_1.set_roles([role_1, role_2])
    ret = play_1.compile_roles_handlers()
    assert ret == [block_1, block_2]


# Generated at 2022-06-25 05:25:11.630491
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.post_tasks = ['task_1', 'task_2']
    play_1.tasks = ['task_3', 'task_4']
    play_1.pre_tasks = ['task_5', 'task_6']
    assert play_1.get_tasks() == ['task_5', 'task_6', 'task_3', 'task_4', 'task_1', 'task_2']



# Generated at 2022-06-25 05:25:19.211011
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    data = {
        'hosts': '127.0.0.1',
        'roles': [
            {
                'role': {
                    'name': 'fake_name',
                    'path': 'fake_path'
                }
            }
        ]
    }

    play_1.deserialize(data)
    assert isinstance(play_1.roles[0], Role)


# Generated at 2022-06-25 05:25:26.116082
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Load up play with some roles, pre_tasks and handlers
    fake_loader = DictDataLoader(dict(
        host_vars={},
        group_vars={},
        all_vars={},
        injection_vars=[],
    ))

# Generated at 2022-06-25 05:25:36.667903
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Test case 0
    play_0 = Play()
    data_0 = {u'hosts': 'hosts value', u'connection': 'local', u'roles': [], u'action_groups': {}, u'group_actions': {}, u'included_path': None, u'name': 'name value', u'defer_facts': False, u'vars': {u'var1': [u'var1', u'val1']}, u'vars_files': [u'file1', u'file2']}
    play_0.deserialize(data_0)
    assert type(play_0) == Play
    assert play_0._ds == data_0
    assert play_0._included_path == None
    assert type(play_0._action_groups) == dict
    assert play_0._

# Generated at 2022-06-25 05:25:40.363818
# Unit test for method get_name of class Play
def test_Play_get_name():
    try:
        play_1 = Play()
        result = play_1.get_name()
        assert result == ''
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:25:55.260751
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Testing: Returns a flat list of Handlers that have been
    # compiled from the roles

    # No handlers.
    play_1 = Play()
    assert play_1.compile_roles_handlers() == []

    # Single handler
    play_2 = Play()
    handler_0 = Handler()
    play_2.handlers.append(handler_0)
    assert play_2.compile_roles_handlers() == [handler_0]


# Generated at 2022-06-25 05:26:02.578221
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a block containing a single flush handlers meta
    # task, so we can be sure to run handlers at certain points
    # of the playbook execution
    flush_block = Block.load(
        data={'meta': 'flush_handlers'},
        play=play_0,
        variable_manager=self._variable_manager,
        loader=self._loader
    )

    for task in flush_block.block:
        task.implicit = True

    block_list = []

    block_list.extend(self.pre_tasks)
    block_list.append(flush_block)
    block_list.extend(self._compile_roles())
    block_list.extend(self.tasks)
    block_list.append(flush_block)

# Generated at 2022-06-25 05:26:10.585968
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.hosts = 'localhost'
    name = play_0.get_name()
    assert name == 'localhost'

    play_0 = Play()
    play_0.hosts = ['localhost']
    name = play_0.get_name()
    assert name == 'localhost'

    play_0 = Play()
    play_0.name = 'localhost'
    name = play_0.get_name()
    assert name == 'localhost'



# Generated at 2022-06-25 05:26:17.420310
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a block list
    block_list = []

    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))))
    roles_path = os.path.join(base_dir, 'test','unit','data','playbook','roles','basic')
    ds = {"role_name": "basic", "role_path": roles_path}

    # Create a valid role object
    r = Role()

    # Load roles object with data
    r.load_data(ds, variable_manager=None, loader=None)

    # Create a play object
    p = Play()

    # Add roles to play
    p

# Generated at 2022-06-25 05:26:18.295213
# Unit test for method serialize of class Play
def test_Play_serialize():
    test_case_0()


# Generated at 2022-06-25 05:26:20.378211
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.get_name() == ""
    play_1 = Play()
    assert play_1.get_name() == ""


# Generated at 2022-06-25 05:26:26.518428
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_obj = Play()
    assert play_obj.serialize().keys() == {'action_groups', '_post_validation_errors', '_ds', 'vars', 'group_actions', 'name', 'connection', 'hosts', '_validation_errors', 'roles', 'remote_user', 'become', '_included_path', 'vars_files', 'handlers', '_loader', 'tags', 'strategy', 'block', 'tasks', 'pre_tasks', 'post_tasks', 'tasks_parameters', '_prepared_blocks', '_serial', '_variable_manager'}


# Generated at 2022-06-25 05:26:29.773352
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    assert play_0.compile_roles_handlers() is not None


# Generated at 2022-06-25 05:26:38.369288
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    serialize_Play = play_0.serialize()
    exp_serialize_Play = {'any_errors_fatal': None, 'attributes': {'hosts': None}, 'become': True, 'collect_facts': 'Smart', 'connection': 'smart', 'delegate_to': None, 'environment': [], 'gather_facts': True, 'handlers': [], 'included_vars': {}, 'include_tasks': None, 'include_vars': None, 'name': '', 'no_log': False, 'post_tasks': [], 'pre_tasks': [], 'roles': [], 'serial': 1, 'tags': [], 'tasks': [], 'vars': {}, 'vars_prompt': []}

# Generated at 2022-06-25 05:26:44.600739
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    """

    """
    play_0 = Play()
    play_0.vars_files = []
    # Test method return value with argument []
    assert play_0.get_vars_files() == []
    # Test method return value with argument None
    assert play_0.get_vars_files() == []
    play_0.vars_files = None
    # Test method return value with argument None
    assert play_0.get_vars_files() == []


# Generated at 2022-06-25 05:26:58.268967
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # set up test case
    Testcase.testcase_0()
    role1_0 = Testcase.role1_0()
    role1_0.get_handler_blocks = MagicMock(return_value=[])
    role2_0 = Testcase.role2_0()
    role2_0.get_handler_blocks = MagicMock(return_value=[])
    play_0.roles = [role1_0, role2_0]

    # call operation
    result = play_0.compile_roles_handlers()

    # assert result
    assert result == [], 'Expected call_args: %s. Actual call_args: %s' % ([], result)
    role1_0.get_handler_blocks.assert_called_once_with(play=play_0)
    role2_

# Generated at 2022-06-25 05:27:00.561132
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_case_0()


# Generated at 2022-06-25 05:27:10.900807
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    new_play = Play()
    new_play_handlers = [
        "test handler 1",
        "test handler 2",
        "test handler 3",
        "test handler 4"
    ]

    new_play.handlers = new_play_handlers
    new_play_compiled_roles_handlers = new_play.compile_roles_handlers()

    if (new_play_compiled_roles_handlers == new_play_handlers):
        return True

    print("ERROR - Play.compile_roles_handlers:")
    print("     Expected handlers =", new_play_handlers)
    print("     Actual   handlers =", new_play_compiled_roles_handlers)


# Generated at 2022-06-25 05:27:12.086091
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    print(play_0.serialize())


# Generated at 2022-06-25 05:27:13.323538
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    result = play.compile_roles_handlers()
    assert result == []

# Generated at 2022-06-25 05:27:19.017847
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    if play.vars_files is not None:
        # test for get_vars_files method
        assert play.get_vars_files() == []
    else:
        # test for get_vars_files method
        assert play.get_vars_files() == []


# Generated at 2022-06-25 05:27:25.180068
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Play object for test, data is dummy value.
    play_obj = Play()

    # Setting the data to test as follows:
    # roles_list = []
    play_obj.roles = []
    #  roles_list.append(role_0)
    #  roles_list.append(role_1)

    # Test function returns the following value.
    expected_compile_roles_handlers_return_value = []
    # Calling the function to test with above data.
    compile_roles_handlers_return_value = play_obj.compile_roles_handlers()

    # Testing the return value of the above method.
    assert expected_compile_roles_handlers_return_value == compile_roles_handlers_return_value


# Generated at 2022-06-25 05:27:25.951248
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass


# Generated at 2022-06-25 05:27:29.359292
# Unit test for constructor of class Play
def test_Play():
    try:
        play = Play()
    except Exception as e:
        print("Exception caught in test_Play()")
        print(str(e))
        exit(1)
    else:
        print("Play() call worked")


# Generated at 2022-06-25 05:27:30.970237
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    ans = play_1.get_vars_files()
    assert ans == []


# Generated at 2022-06-25 05:27:41.484594
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    if False:  # (play_1.get_name() == "play"):
        print("get_name() of Play returned: play")
        print("Expected: play")

if __name__ == '__main__':
    test_Play_get_name()

# Generated at 2022-06-25 05:27:51.106132
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # Play object
    play = Play()

    # Mock role object
    role = MagicMock()

    # Role objects in a list
    role_list = [role]

    # Mock handler block object
    block = MagicMock()

    # Assign the list of roles to the play
    play.roles = role_list

    # Assigning a return value to the mock function get_handler_blocks
    role.get_handler_blocks.return_value = [block]

    # Assigning a return value to the mock function copy
    block.copy.return_value = block
    
    # Call the function under test
    block_list = play.compile_roles_handlers()

    # Check for test result
    assert block_list == [block]


# Generated at 2022-06-25 05:27:59.965336
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.name = 'test_play'
    play_1.hosts = ['test_host']
    # play_1.tasks
    # play_1.post_tasks
    play_1.vars = dict(a=1, b=2, c='d')
    play_1.handlers = [1, 2]
    play_1.roles = [1, 2]
    play_1.vars_prompt = [1, 2]
    play_1.defaults = dict(a=1, b=2, c='d')
    play_1.meta = dict(a=1, b=2, c='d')
    play_1.tags = []
    # play_1.pre_tasks
    play_1.serial = 1
    play

# Generated at 2022-06-25 05:28:02.440807
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test_Play_get_name"
    assert play.name == play.get_name()
    play = Play()
    play.hosts = "test_Play_get_name"
    assert play.hosts == play.get_name()


# Generated at 2022-06-25 05:28:04.025664
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    res = play_0.get_name()
    assert res == ''


# Generated at 2022-06-25 05:28:07.914287
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()

    play.tasks = [1,2,3]
    play.pre_tasks = [4,5,6]
    play.post_tasks = [7,8,9]

    tasklist = play.get_tasks()

    assert tasklist == [4,5,6,1,2,3,7,8,9]

# Generated at 2022-06-25 05:28:09.737759
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    handlers_0 = play_1.compile_roles_handlers()



# Generated at 2022-06-25 05:28:11.065058
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    play_0.preprocess_data(ds=None)


# Generated at 2022-06-25 05:28:18.246642
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play.load(dict(hosts='localhost', name='play1'))
    assert play_1.get_name() == 'play1'
    play_2 = Play.load(dict(hosts='localhost', name=2))
    assert play_2.get_name() == '2'



# Generated at 2022-06-25 05:28:22.367137
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    play_1._ds = OrderedDict()
    play_1._ds['play'] = {
        'hosts': 'all'
    }
    play_1.preprocess_data(play_1._ds)
    assert play_1.hosts == 'all'


# Generated at 2022-06-25 05:28:31.670987
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    str_0 = play_0.get_name()
    assert str_0


# Generated at 2022-06-25 05:28:35.093518
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_0 = Play()
    play_0.load_data({})
    play_0.tasks = [play_1]
    assert play_0.compile_roles_handlers() == play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:28:39.257043
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.tasks = [
        {'name' : 'test task 1'},
        {'name' : 'test task 2'},
        {'name' : 'test task 3'}
    ]
    assert play_1.get_tasks() == play_1.tasks


# Generated at 2022-06-25 05:28:41.598555
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    block_list_1 = play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:28:45.629230
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play.load(dict(
        name='test',
        hosts='all',
        roles=['foo', 'bar', 'baz']
    ))
    result = p.compile_roles_handlers()
    assert result == []


# Generated at 2022-06-25 05:28:49.946911
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-25 05:28:57.545473
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    test_0 = play_1.get_vars_files()
    test_1 = play_1.vars_files
    play_1.vars_files = 123
    test_2 = play_1.get_vars_files()
    assert test_0 == test_1 and test_2 == test_1
    assert test_0 != test_2



# Generated at 2022-06-25 05:29:00.541074
# Unit test for method serialize of class Play
def test_Play_serialize():
    try:
        Play().serialize()
    except NotImplementedError as nie:
        assert nie.args[0] == "Play is an abstract class that does not implement serialize"
        print("Unit test for Play's serialize method passed")


# Generated at 2022-06-25 05:29:01.609942
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()



# Generated at 2022-06-25 05:29:06.960133
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    assert isinstance(play_1.compile_roles_handlers(), list)


# Generated at 2022-06-25 05:29:14.967765
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    result = play_0.get_vars_files()


# Generated at 2022-06-25 05:29:17.755490
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    print('play_0.name: %s' % play_0.name)
    print('play_0.get_name: %s' % play_0.get_name())


# Generated at 2022-06-25 05:29:22.124403
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()

    play_0.pre_tasks = 'pre_tasks'
    play_0.tasks = 'tasks'
    play_0.post_tasks = 'post_tasks'
    tasklist = play_0.get_tasks()

    if tasklist != ['pre_tasks', 'tasks', 'post_tasks']:
        raise AssertionError("Failed to get_tasks of Play")



# Generated at 2022-06-25 05:29:23.866412
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    (tasks, ) = play_0.get_tasks()
    assert(isinstance(tasks, Play))


# Generated at 2022-06-25 05:29:29.138562
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = [
        {
            'name': 'role1',
            'handlers': [
                'handler1',
                'handler2'
            ]
        },
        {
            'name': 'role2',
            'handlers': [
                'handler3',
                'handler4'
            ]
        }
    ]

# Generated at 2022-06-25 05:29:36.962911
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    test_passed = True
    try:
        play_obj = Play.load(dict(hosts='localhost', roles='rolename'), variable_manager=None, loader=None)
        play_obj.preprocess_data(play_obj._ds)
    except AnsibleParserError as e:
        assert e.message == 'Role dependency rolename has circular dependencies'
    else:
        test_passed = False
    finally:
        assert test_passed, 'Test failed to raise AnsibleParserError'


# Generated at 2022-06-25 05:29:38.562962
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.get_vars_files() == []



# Generated at 2022-06-25 05:29:47.504228
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variables=vars_manager, hosts="127.0.0.1")
    vars_manager.set_inventory(inventory)

# Generated at 2022-06-25 05:29:49.376153
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()

    # play_0._preprocess_data()
    #
    # assert play_0._ds == {}



# Generated at 2022-06-25 05:30:01.531612
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test case with import_role
    play_1 = Play()
    test_role_1 = Role()
    test_role_1.from_include = False
    play_1.roles.append(test_role_1)
    role_block_1 = Block()
    role_block_1.block.append(Task())
    test_role_1.handler_blocks.append(role_block_1)
    result_1 = play_1.compile_roles_handlers()

    assert result_1 != None
    assert isinstance(result_1, list)
    assert len(result_1) == 1
    assert isinstance(result_1[0], Block)
    assert result_1[0].block
    assert isinstance(result_1[0].block[0], Task)

    # Test case with include

# Generated at 2022-06-25 05:30:17.266347
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    handler_list = play_0.compile_roles_handlers()

    # check if handler_list is a list
    assert handler_list == []


# Generated at 2022-06-25 05:30:23.737270
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.roles = []
    play_0.post_tasks = []
    play_0.pre_tasks = []
    play_0.tasks = []
    play_0._included_conditional = None
    play_0._included_path = None
    play_0.ROLE_CACHE = {}
    play_0.only_tags = set(['all'])
    play_0.skip_tags = set()
    play_0._action_groups = {}
    play_0._group_actions = {}
    assert play_0.get_tasks() == []

    play_1 = Play()
    play_1.roles = []
    play_1.post_tasks = []
    play_1.pre_tasks = []
    un

# Generated at 2022-06-25 05:30:32.460329
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-25 05:30:40.796846
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = [ { 'name': 'set locale', 'action': 'set_fact', 'args': { 'ansible_locale_configured': True } }, { 'name': 'install python', 'action': 'apt', 'args': { 'name': 'python {deb_state}' } }, { 'name': 'install python', 'action': 'apt', 'args': { 'name': 'python: {deb_state}' } } ]

# Generated at 2022-06-25 05:30:42.579300
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with empty list
    play_0 = Play()
    assert play_0.get_vars_files() == []



# Generated at 2022-06-25 05:30:49.891785
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [Task() for _ in range(3)]
    play.tasks = [Task() for _ in range(3)]
    play.post_tasks = [Task() for _ in range(3)]
    all_tasks = play.get_tasks()
    assert len(all_tasks) == 9, 'Play.get_tasks() should return 9 tasks'
    assert all(isinstance(t, Task) for t in all_tasks), 'All tasks should be instances of Task'


# Generated at 2022-06-25 05:30:55.179083
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_compile_roles_handlers = Play()
    assert play_compile_roles_handlers.compile_roles_handlers() is not None


# Generated at 2022-06-25 05:30:56.377781
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert isinstance(play.compile_roles_handlers(), list)


# Generated at 2022-06-25 05:31:03.081917
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = None
    play_0.get_vars_files()
    print('Play.get_vars_files() is passed!')

if __name__ == '__main__':
    test_case_0()
    test_Play_get_vars_files()

# Generated at 2022-06-25 05:31:14.118003
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()

# Generated at 2022-06-25 05:31:46.776755
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "testPlay"
    test_out = play_0.get_name()

    assert(test_out == "testPlay")


# Generated at 2022-06-25 05:31:51.007037
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-25 05:31:59.038899
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    play_1.vars_files = []
    assert_equals(play_1.get_vars_files(), [])

    play_2 = Play()
    play_2.vars_files = 'test_string'
    assert_equals(play_2.get_vars_files(), ['test_string'])

    play_3 = Play()
    play_3.vars_files = ['test_string', 'test_string2']
    assert_equals(play_3.get_vars_files(), ['test_string', 'test_string2'])


# Generated at 2022-06-25 05:32:11.069127
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_data = {
        'name': 'test',
        'hosts': 'localhost',
        'connection': 'local',
        'gather_facts': 'no',
        'roles': [
            {
                'role': 'role1',
                'handlers': [
                    {
                        'name': 'handler_role1_1'
                    },
                    {
                        'name': 'handler_role1_2'
                    }
                ]
            },
            {
                'role': 'role2',
                'handlers': [
                    {
                        'name': 'handler_role2_1'
                    },
                    {
                        'name': 'handler_role2_2'
                    }
                ]
            }
        ]
    }

    play = Play()

# Generated at 2022-06-25 05:32:20.307924
# Unit test for method get_tasks of class Play

# Generated at 2022-06-25 05:32:31.160318
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.name = "Test_play"
    play_0.pre_tasks = [{"pre_task_1": "pre_task_1"}, {"pre_task_2": "pre_task_2"}]
    play_0.tasks = [{"task_1": "task_1"}, {"task_2": "task_2"}]
    play_0.post_tasks = [{"post_task_1": "post_task_1"}, {"post_task_2": "post_task_2"}]


# Generated at 2022-06-25 05:32:36.150520
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = 'test_case_0'
    assert play_0.get_name() == play_0.name


# Generated at 2022-06-25 05:32:42.172016
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

# Generated at 2022-06-25 05:32:45.486702
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()

    play.vars_files = None
    assert play.get_vars_files() == []

    play.vars_files = ''
    assert play.get_vars_files() == ['']

    play.vars_files = []
    assert play.get_vars_files() == []

    play.vars_files = ['']
    assert play.get_vars_files() == ['']


# Generated at 2022-06-25 05:32:53.401240
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Load handler data and create dependent objects
    handler_data = load_data_file(os.path.join(DATA_PATH, "handlers", "handler_ok.yml"))
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()

    # Create handler and assign to block, which is needed for compilation
    handler = Handler.load(handler_data, play, variable_manager=variable_manager, loader=loader)
    block = Block(block=handler)

    # Create list of blocks and compile handlers
    block_list = [block, block]
    actual_output = Play().compile_roles_handlers(block_list)

    # Since the name of the handler is the same we should see a warning
    # Assert that the output is a list
    assert isinstance(actual_output, list)



# Generated at 2022-06-25 05:33:35.845608
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    logger.info("Testing Play.compile_roles_handlers")
    test_Play = Play()
    test_Play._compile_roles_handlers()


# Generated at 2022-06-25 05:33:38.103076
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    try:
        play_0 = Play()
        play_0.preprocess_data(None)
    except AssertionError:
        return
    print('test_Play_preprocess_data failed')


# Generated at 2022-06-25 05:33:42.434926
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    play_0 = Play()
    ret_0 = play_0.compile_roles_handlers()
    if ret_0 is not None:
        raise ValueError("play_0.compile_roles_handlers() returns '%s', expected: '%s'" % (ret_0, None))

# Generated at 2022-06-25 05:33:43.813310
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.get_tasks()


# Generated at 2022-06-25 05:33:53.194322
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # NOTE: This test assumes that the Play class has the following tasks
    #       - pre_tasks
    #       - tasks
    #       - post_tasks
    # Also, this test is not testing the Block class's defintion.
    # Also, this test is assuming that the tasks are executed in the following
    # order.
    # - pre_tasks
    # - tasks
    # - post_tasks
    # TODO: Refactor this test to not assume the tasks order.
    play_0 = Play()
    pre_tasks = play_0.pre_tasks
    tasks = play_0.tasks
    post_tasks = play_0.post_tasks

    # Check that all three lists are empty

# Generated at 2022-06-25 05:33:56.403320
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    result = play_0.get_tasks()
    assert result == None


# Generated at 2022-06-25 05:34:01.097844
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_case = Play()
    test_case.pre_tasks = [1,2,3]
    test_case.tasks = [4]
    test_case.post_tasks = [5,6,7]

    try:
        assert test_case.get_tasks() == [1,2,3,4,5,6,7]
    except AssertionError:
        raise AssertionError('test_Play_get_tasks failed')
