

# Generated at 2022-06-25 05:24:27.445159
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.hosts = "host"
    play.handlers = [{"name": "test", "tags":["test"]}]
    # Test for no roles
    res = play.compile_roles_handlers()
    assert res == play.handlers
    # Test for with roles
    roles = [{"name": "role0", "tasks": [{"name": "task", "tags":["test1"]}], "handlers": [{"name": "test", "tags":["test2"]}]}]
    play.roles = roles
    res = play.compile_roles_handlers()
    assert res == play.handlers

# Generated at 2022-06-25 05:24:35.149420
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play instance with no roles
    play_1 = Play()

    # Test the compile_roles_handlers method with a play instance having no roles
    assert play_1.compile_roles_handlers() == []

    # Create a Role instance
    role_1 = Role()

    # Create a Play instance with one role
    play_2 = Play()
    play_2._roles = [role_1]

    # Test the compile_roles_handlers method with a play instance having one role
    assert play_2.compile_roles_handlers() == []


# Generated at 2022-06-25 05:24:37.296253
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    assert play_0.preprocess_data({}) is not None


# Generated at 2022-06-25 05:24:40.454015
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    # Check the method returns a list of tasks
    assert isinstance(play_0.get_tasks(), list)


# Generated at 2022-06-25 05:24:42.208527
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    task_2 = play_0.get_tasks()


# Generated at 2022-06-25 05:24:44.146372
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    if play_1.get_vars_files() == []:
        print("The method get_vars_files of class Play works!")
    else:
        print("Error! get_vars_files of class Play doesn't work!")


# Generated at 2022-06-25 05:24:52.725307
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Compiles and returns the handler list for this play, compiled from the
    roles (which are themselves compiled recursively) and/or the list of
    tasks specified in the play.
    '''

    # Create a new Play
    play_1 = Play()

    # Create a new Role
    role_1 = Role()

    # Create a new Block
    block_1 = Block()

    # Add the Block to the Role
    role_1.add(block_1)

    # Create a new Handler
    handler_arg = Munch()
    handler_1 = Handler(handler_arg, loader=play_1._loader, play=play_1)

    # Add the Handler to the Block
    block_1.add(handler_1)

    # Add the Role to the Play

# Generated at 2022-06-25 05:25:04.198277
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible import constants as C
    from ansible.utils.unsafe_proxy import wrap_var

    target_play_name = "123"
    fake_name = wrap_var(target_play_name)
    test_subject_play_obj = play_factory(name=fake_name)

    actual_play_name = test_subject_play_obj.get_name()
    assert actual_play_name == target_play_name

    target_play_name = "456"
    fake_hosts = wrap_var(target_play_name)
    test_subject_play_obj.hosts = fake_hosts
    test_subject_play_obj.name = None # Clear name assigned by play_factory
    actual_play_name = test_subject_play_obj.get_name()
    assert actual_play

# Generated at 2022-06-25 05:25:14.906202
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansiblelint.runner import Runner
    from ansiblelint import RulesCollection
    from ansiblelint.utils import assertIn

    runner = Runner(RulesCollection(), '/tmp/dummy', [], [], [])
    play_test = Play()
    try:
        play_test.preprocess_data(['test', 'test1'])
        assert(0==1)
    except AnsibleAssertionError:
        pass

    try:
        play_test.preprocess_data({'test': 'test1', 'test2': 'test2'})
    except AssertionError:
        assert(0==1)

# Generated at 2022-06-25 05:25:16.818610
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    expected_result = []
    assert play_0.compile_roles_handlers() == expected_result


# Generated at 2022-06-25 05:25:23.678701
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_case_0()


# Generated at 2022-06-25 05:25:29.199685
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    with pytest.raises(AnsibleParserError) as e:
        p.compile_roles_handlers()
    assert 'conflict' in to_native(e.value)



# Generated at 2022-06-25 05:25:34.045308
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds = {}
    play_0.preprocess_data(ds)


# Generated at 2022-06-25 05:25:45.832714
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()

# Generated at 2022-06-25 05:25:48.703434
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    assert [] == play_0.compile_roles_handlers(), 'return value should be []'
    return


# Generated at 2022-06-25 05:25:50.851263
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    play_0.deserialize({"name": "a_name"})
    assert play_0.name == "a_name", "Expected value 'a_name' for attribute 'name' but got {0}".format(play_0.name)


# Generated at 2022-06-25 05:25:58.944229
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()

# Generated at 2022-06-25 05:26:01.988251
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test1: An empty play
    pass
    # TODO: Add test cases


# Generated at 2022-06-25 05:26:05.298068
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    task = Task()
    play.add_task(task)
    task_list = play.get_tasks()
    assert task in task_list


# Generated at 2022-06-25 05:26:08.329952
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.load({'name':'dummyplay', 'connection': 'local'})
    serialized = play.serialize()
    assert serialized['name'] == 'dummyplay'
    assert serialized['connection'] == 'local'



# Generated at 2022-06-25 05:26:18.295394
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = ["vars_files"]
    vars_files = play_0.get_vars_files()
    assert vars_files == ["vars_files"]


# Generated at 2022-06-25 05:26:19.952607
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test case 1
    play = Play()
    assert play.get_name() == ""


# Generated at 2022-06-25 05:26:27.378749
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

    t1 = Task()
    t2 = Task()
    t3 = Task()
    t4 = Task()
    t5 = Task()
    t6 = Task()
    t7 = Task()
    t8 = Task()
    t9 = Task()
    t10 = Task()
    t11 = Task()
    t12 = Task()
    t13 = Task()

    play_1.tasks.append(t1)
    play_1.tasks.append(t2)
    play_1.tasks.append(t3)
    play_1.tasks.append(t4)
    play_1.tasks.append(t5)
    play_1.tasks.append(t6)
    play_1.tasks.append(t7)
    play

# Generated at 2022-06-25 05:26:34.395870
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansiblelint import RulesCollection
    from ansiblelint.rules.AnsibleBestPractices import AnsibleBestPractices

    rules_collection = RulesCollection()
    rules_collection.register(AnsibleBestPractices())

    runner = Runner(
        rules=rules_collection,
        runner_data={
            'is_playbook': True
        },
    )

    play_0 = Play()

    runner.run(play_0, play_0.copy())

# Generated at 2022-06-25 05:26:41.186668
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_compile_roles_handlers = Play()
    # Add a block containing a single flush handlers meta task, so we can be sure to run handlers at certain points of the playbook execution
    flush_block = Block.load(data={'meta': 'flush_handlers'}, play=play_compile_roles_handlers, variable_manager=None, loader=None)
    for task in flush_block.block:
        task.implicit = True
    # create a role 'fake_role_0' to test
    fake_role_0 = Role()
    fake_role_0.dependencies = list()
    fake_role_0.default_vars = dict()
    fake_role_0.name = "fake_role_0"
    fake_role_0.tasks_filename = None

# Generated at 2022-06-25 05:26:44.056582
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Play object init
    play_0 = Play()

    # test compile_roles_handlers
    print('\n************* test compile_roles_handlers ****************')
    play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:26:45.500189
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_case = Play()
    name = test_case.get_name()
    assert(isinstance(name, string_types))


# Generated at 2022-06-25 05:26:46.871383
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasklist = play_0.get_tasks()
    assert tasklist == []

# Generated at 2022-06-25 05:26:50.865110
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    '''
    This is a unit test for deserialize method of class Play.
    '''
    play_0 = Play()
    data = {'roles': [], 'included_path': None, 'action_groups': {}, 'group_actions': {}}
    play_0.deserialize(data)


# Generated at 2022-06-25 05:26:57.523913
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

    t0 = Block()
    t1 = Block()
    p0 = Block()
    p1 = Block()
    p2 = Block()
    p3 = Block()
    play_1.pre_tasks = [p0, p1, p2, p3]
    play_1.tasks = [t0, t1]

    assert(play_1.get_tasks() == [p0, p1, p2, p3, t0, t1])


# Generated at 2022-06-25 05:27:14.761568
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()


# Generated at 2022-06-25 05:27:21.430699
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    file_to_read = open('/home/dev/Ansible/2.4/test/units/lib/ansible/playbook/test_data/test_playbook.yaml')
    play_md = yaml.load(file_to_read)
    file_to_read.close()
    play_md = play_md['plays'][0]
    play = Play()
    play.deserialize(data = play_md)

if __name__ == '__main__':
    test_Play_deserialize()

# Generated at 2022-06-25 05:27:25.094688
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play.load(dict(hosts='all', name='warriors'))
    assert play_1.get_name() == 'warriors'


# Generated at 2022-06-25 05:27:32.482374
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = [ Task() ]
    play_0.tasks = [ Task() ]
    play_0.post_tasks = [ Task() ]
    block_0 = Block()
    task_0 = Task()
    block_0.block = [ task_0 ]
    assert play_0.pre_tasks[0] == task_0
    assert play_0.tasks[0] == task_0
    assert play_0.post_tasks[0] == task_0
    assert block_0.block[0] == task_0


# Generated at 2022-06-25 05:27:38.579119
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    play_1 = Play.load(dict(hosts='all', gather_facts='no', pre_tasks=[dict(shell='/bin/foo'), dict(debug=dict(msg='{{shell_output.stdout}}'))]), variable_manager=VariableManager(), loader=loader)
    connector = object()

# Generated at 2022-06-25 05:27:41.907314
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    assert play_0.get_tasks() == []
    return


test_cases = [test_case_0]
if __name__ == '__main__':
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-25 05:27:51.559330
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    play_1.vars_files = ['test_data/test_playbook.yml']
    assert play_1.get_vars_files() == ['test_data/test_playbook.yml']

    play_2 = Play()
    play_2.vars_files = None
    assert play_2.get_vars_files() == []

    play_3 = Play()
    play_3.vars_files = ['test_data/test_playbook.yml', 'test_data/test_playbook2.yml']
    assert play_3.get_vars_files() == ['test_data/test_playbook.yml', 'test_data/test_playbook2.yml']


# Generated at 2022-06-25 05:28:01.586240
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({'hosts': [u'localhost'],
                   'tasks': [],
                   'roles': [
                       {'tasks': [],
                        'default_vars': {},
                        'handlers': [
                            {'tasks': [],
                             'default_vars': {},
                             'name': 'main',
                             'dynamic_blocks': []}],
                        'name': 'test',
                        'dynamic_blocks': []}],
                   'name': u'localhost',
                   'action_groups': {'all': ['test']},
                   'group_actions': {'test': ['all']},
                   'included_path': None})

if __name__ == "__main__":
    test_Play_deserialize()

# Generated at 2022-06-25 05:28:11.642252
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    inventory = InventoryManager(loader, sources=['./test_data/hosts'])
    variable_manager = VariableManager(loader, inventory)
    play = Play()
    play.load("./test_data/test_yaml/test_Play_deserialize.yaml", variable_manager, loader)
    play.vars = {}

# Generated at 2022-06-25 05:28:19.389188
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_get_vars_files = Play()
    play_get_vars_files.vars_files = ['./ansible/test/integration/targets/host_vars_files']
    assert play_get_vars_files.get_vars_files() == ['./ansible/test/integration/targets/host_vars_files']


# Generated at 2022-06-25 05:28:37.071301
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    assert play_1.compile_roles_handlers() == []

    with pytest.raises(Exception) as execinfo:
        play_1.compile_roles_handlers("a")

    # if this test fails then it's because unsupported argument(s) are passed
    # to Play.compile.
    assert str(execinfo.value) == 'unsupported argument(s) passed to Play.compile: a'

    with pytest.raises(Exception) as execinfo:
        play_1.compile(a="a")

    # if this test fails then it's because unsupported argument(s) are passed
    # to Play.compile.
    assert str(execinfo.value) == 'unsupported argument(s) passed to Play.compile: a'


# Generated at 2022-06-25 05:28:48.254856
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test 1. Strings as hosts
    play_0 = Play()
    play_0.name = ''
    play_0.hosts = 'localhost'
    name = play_0.get_name()
    assert name == 'localhost'
    assert isinstance(name, binary_type)

    # Test 2. List as hosts
    play_1 = Play()
    play_1.name = ''
    play_1.hosts = ['localhost']
    name = play_1.get_name()
    assert name == 'localhost'
    assert isinstance(name, binary_type)

    # Test 3. Empty string as hosts
    play_2 = Play()
    play_2.name = ''
    play_2.hosts = ''
    name = play_2.get_name()
    assert name == ''

# Generated at 2022-06-25 05:28:52.229466
# Unit test for method serialize of class Play
def test_Play_serialize():

    play_0 = Play()
    # Verify this calling this method does not raise an exception.  This verifies
    # we have no missing data in the 'play_0' object.
    serialized_data = play_0.serialize()


if __name__ == "__main__":
    # Test case for play.py
    test_Play_serialize()

# Generated at 2022-06-25 05:29:02.052759
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test case data
    play_1 = Play()
    play_1_ds = [
        {'name': 'test_play_1'},
        'test_play_1',
        None
    ]
    play_1_ds_expected_results = [
        {'name': 'test_play_1'},
        {'name': 'test_play_1'},
        {'name': None}
    ]
    play_2 = Play()
    play_2_ds = [
        {'user': 'jsmith'},
        'jsmith',
        None
    ]
    play_2_ds_expected_results = [
        {'remote_user': 'jsmith'},
        {'remote_user': 'jsmith'},
        {'remote_user': None}
    ]
    play_

# Generated at 2022-06-25 05:29:04.471250
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Data
    play = Play()
    task = Task()
    play.tasks.append(task)

    # Execute
    result = play.get_tasks()

    # Assert
    assert True


# Generated at 2022-06-25 05:29:09.429245
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    # Test get_name is a function
    assert callable(getattr(play_0, "get_name", None))


# Generated at 2022-06-25 05:29:11.660483
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    try:
        play_0.get_name()
    except:
        print("Exception while calling Play.get_name()")


# Generated at 2022-06-25 05:29:16.058255
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasklist = play_0.get_tasks()


# Generated at 2022-06-25 05:29:19.693951
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_1 = Play()
    play_2 = Play()

    block_list_0 = []

    block_list_0 = play_0.compile_roles_handlers()
    block_list_0 = play_1.compile_roles_handlers()
    block_list_0 = play_2.compile_roles_handlers()


# Generated at 2022-06-25 05:29:25.677539
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    play_1.vars_files = None
    assert play_1.get_vars_files() == []

    play_2 = Play()
    play_2.vars_files = 'test'
    assert play_2.get_vars_files() == ['test']

    play_3 = Play()
    play_3.vars_files = ['test1', 'test2']
    assert play_3.get_vars_files() == ['test1', 'test2']


# Generated at 2022-06-25 05:29:43.245358
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    result_for_method_compile_roles_handlers = play_0.compile_roles_handlers()
    print(result_for_method_compile_roles_handlers)


# Generated at 2022-06-25 05:29:50.291512
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = {'name': 'test', 'hosts': '127.0.0.1', 'user': 'foo'}

    try:
        play.preprocess_data(ds)
        assert False
    except AnsibleAssertionError:
        assert True

    ds = {'name': 'test', 'hosts': '127.0.0.1', 'tasks': [], 'user': 'foo'}

    try:
        play.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        assert True

    ds = {'name': 'test', 'hosts': '127.0.0.1', 'tasks': [], 'remote_user': 'foo'}


# Generated at 2022-06-25 05:29:55.410719
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Test case for method compile_roles_handlers of class Play

    Defines a minimal Play object and calls compile_roles_handlers
    '''

    # Minimal definition of a role:
    role_1 = {'handlers': []}
    role_2 = {'handlers': []}
    roles = [role_1, role_2]
    test_case_0_Play = Play(name='test_case_0_Play', roles=roles)

    handlers_list = test_case_0_Play.compile_roles_handlers()

    assert handlers_list == [[], []]


# Generated at 2022-06-25 05:30:01.958425
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    if play.name != None:
        raise AssertionError("Initial value for Play.name is not 'None'.")

    play.name = "test_name"
    if play.get_name() != "test_name":
        raise AssertionError("Expected value for Play.name is 'test_name'.")


# Generated at 2022-06-25 05:30:05.103149
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = None
    play_0.tasks = None
    play_0.post_tasks = None
    tasklist = play_0.get_tasks()
    assert tasklist is not None


# Generated at 2022-06-25 05:30:08.506699
# Unit test for method get_name of class Play
def test_Play_get_name():
    # (1) create an instance of Play
    play_0 = Play()

    # (2) Invoke method get_name of class Play
    play_0_name = play_0.get_name()
    # play_0_name should be None
    assert(play_0_name is None)
    return play_0


# Generated at 2022-06-25 05:30:12.064317
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """
    Test that the method get_tasks of class Play return the right value

    :return: Nothing
    """

    # create a task with play
    play_1 = Play()
    # define a task
    task_1 = Play()
    task_1.name = 'test1'
    # append two task to the play
    play_1.tasks.append(task_1)

    assert(play_1.get_tasks()[0] == task_1)


# Generated at 2022-06-25 05:30:20.190232
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play.load(dict(
        name='Play',
        hosts=dict(
            all=dict(
                vars=dict(
                    ansible_python_interpreter='/usr/bin/python'
                )
            )
        ),
        remote_user='root',
        gather_facts='no',
        roles=dict(
            role0=dict(
                name='role0'
            )
        ),
        tasks=dict(
            task0=dict(
                name='task0'
            )
        )
    ))

# Generated at 2022-06-25 05:30:31.431128
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    play :
        - hosts:
            - localhost
        - vars:
            - test_var: "test_var"
        - tasks:
            - debug:
                msg: "test_var={{ test_var }}"
        - handlers:
            - debug:
                msg: "new_var={{ test_var }}"
    '''

# Generated at 2022-06-25 05:30:35.367538
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    result = play_1.serialize()
    assert result is not None
    assert result['collections'] == []
    assert result['hosts'] == 'all'
    assert result['name'] == ''
    assert result['serial'] == 1
    assert result['tasks'] == []
    assert result['vars'] == {}
    assert result['roles'] == []
    assert result['included_path'] == None


# Generated at 2022-06-25 05:30:56.824657
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = None
    play_1.hosts = 'all'
    play_1_1 = play_1.get_name()
    assert play_1_1 == 'all'
    play_2 = Play()
    play_2.name = 'test'
    play_2.hosts = 'all'
    play_2_1 = play_2.get_name()
    assert play_2_1 == 'test'
    play_3 = Play()
    play_3.name = 'test'
    play_3.hosts = None
    play_3_1 = play_3.get_name()
    assert play_3_1 == 'test'


# Generated at 2022-06-25 05:30:57.789348
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.serialize()


# Generated at 2022-06-25 05:31:04.445336
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create an empty Play object (Play())
    play_0 = Play()

    # create an empty Role object
    role_0 = Role()

    # set role_0 name
    role_0.name = 'TestRole'

    # set role_0 _role_path
    role_0._role_path = '/home/aik/ansible/test/roles/TestRole'

    # set role_0 handlers to a list of Handlers
    role_0.handlers = [ Handler(task=Task(action=Action(module_name='shell', module_args='echo handler task'))) ]

    # add role_0 to role list of play_0
    play_0.roles.append(role_0)

    # retrieve Handler objects from role of play
    res = play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:31:11.915955
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.ROLE_CACHE = {'a': 1}
    play_0.roles = [1]
    block_list = []
    play_0.handlers = [1]
    c = play_0.compile_roles_handlers()
    print(c)
    assert c
    print('test_Play_compile_roles_handlers: %s' % c)


# Generated at 2022-06-25 05:31:18.339054
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_case_0()
    test_play = Play()
    test_play.vars_files = None
    return_value_0 = test_play.get_vars_files()
    assert return_value_0 == []

    test_case_0()
    test_play = Play()
    test_play.vars_files = 'abc.yml'
    return_value_1 = test_play.get_vars_files()
    assert return_value_1 == ['abc.yml']

    test_case_0()
    test_play = Play()
    test_play.vars_files = ['def.yml', 'ghi.yml']
    return_value_2 = test_play.get_vars_files()

# Generated at 2022-06-25 05:31:20.737258
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass


# Generated at 2022-06-25 05:31:30.622036
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # test default values
    play = Play()
    ans = []
    result = play.compile_roles_handlers()
    assert result == ans, "Play.compile_roles_handlers result should be []"

    # test with roles
    play = Play()
    roles_list = RoleInclude.load({
        'name': 'role1',
        'hosts': 'hosts',
        'handlers': {
            'main': [
                {'listen': 'restart'},
                {'name': 'restart'},
            ]
        }
    })

    play.roles = [Role.load(roles_list, play=play)]
    result = play.compile_roles_handlers()

# Generated at 2022-06-25 05:31:37.309833
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test case 0
    # Description: Test Case 0 Description
    # Pre-conditions:
    #    Check: None
    # Post-conditions:
    #    Assert: None
    play_0 = Play()
    tasklist_0 = play_0.get_tasks()
    assert isinstance(tasklist_0, list)


# Generated at 2022-06-25 05:31:39.992624
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

    # Test with valid data
    assert isinstance(play_1.get_tasks(), list)



# Generated at 2022-06-25 05:31:45.697042
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()

    assigned_value_0 = play_0.get_tasks()

    assert assigned_value_0 == [], "Expected\n%s\ngot\n%s" % (repr([]), repr(assigned_value_0))



# Generated at 2022-06-25 05:32:22.620671
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test role should have 3 handlers, 1st and 3rd should be marked as private
    roles_0 = []

    # Create Role and associate it with Play
    role_0 = Role()
    role_0.name = u'foocompile_roles_handlers'
    role_0._parent = play_0
    roles_0.append(role_0)
    handler_block_0 = Block()
    handler_0 = Handler()
    handler_0.name = u'foohandler0'
    handler_block_0.block.append(handler_0)
    handler_1 = Handler()
    handler_1.name = u'foohandler1'
    handler_block_0.block.append(handler_1)
    handler_block_0._private = True
    handler_2 = Handler()
   

# Generated at 2022-06-25 05:32:26.930751
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.compile_roles_handlers()

if __name__ == "__main__":
    test_case_0()
    test_Play_compile_roles_handlers()

# Generated at 2022-06-25 05:32:32.345340
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    block_1 = Block()
    play_1.pre_tasks = [play_1.get_tasks()[0], block_1]
    play_1.tasks = [play_1.get_tasks()[0], block_1]
    play_1.post_tasks = [play_1.get_tasks()[0], block_1]
    assert play_1.get_tasks() is not None


# Generated at 2022-06-25 05:32:40.932926
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    # Test exception block
    try:
        play_1.preprocess_data("test_Play_preprocess_data")
    except AnsibleAssertionError as e:
        print("expected error: {}".format(e))
    else:
        print("Expected error not raised")
    # Test successful pass block
    play_2 = Play()
    play_2.preprocess_data({"name": "test_Play_preprocess_data", "hosts": "test_host", "user": "test_user"})
    play_2.preprocess_data({"name": "test_Play_preprocess_data", "hosts": "test_host", "remote_user": "test_remote_user"})


# Generated at 2022-06-25 05:32:41.774280
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_Play_compile_roles_handlers_0()


# Generated at 2022-06-25 05:32:50.821588
# Unit test for constructor of class Play
def test_Play():

    play_0 = Play()
    play_1 = Play()
    assert play_0.get_name() is None
    assert play_0.hosts is None
    assert play_0.collection is None
    assert play_0.name is None
    assert play_0.connection is None
    assert play_0.delegate_to is None
    assert play_0.gather_facts is None
    assert play_0.remote_user is None
    assert play_0.any_errors_fatal is None
    assert play_0.become is None
    assert play_0.become_method is None
    assert play_0.become_user is None
    assert play_0.diff is None
    assert play_0.ignore_errors is None
    assert play_0.environment is None
    assert play_0.no

# Generated at 2022-06-25 05:32:53.601187
# Unit test for method get_name of class Play
def test_Play_get_name():
    try:
        play_0 = Play()
    except Exception as e:
        print('FAILURE: ', e)
        return False
    return True


# Generated at 2022-06-25 05:32:59.681627
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    db = play_1.serialize()
    assert db == {'roles': [], 'included_path': None, 'action_groups': {}, 'group_actions': {}, 'vars': {}}
    db['roles'] = [{'vars': {}, 'tasks': [], 'handlers': [], 'name': None, 'defaults': {}, 'meta': {}, 'dependencies': [], 'post_tasks': [], 'pre_tasks': [], 'private': False, 'vars_prompt': [], 'tags': [], 'collections': []}]
    play_1.deserialize(db)

# Generated at 2022-06-25 05:33:09.338625
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    task_2 = Task()
    task_3 = Task()
    task_4 = Task()
    block_5 = Block()
    block_6 = Block()
    block_6.block.append(Task())
    block_6.block.append(Task())
    block_6.rescue.append(Task())
    block_6.always.append(Task())
    block_7 = Block()
    task_8 = Task()
    task_9 = Task()
    task_10 = Task()
    block_11 = Block()
    block_12 = Block()
    block_12.block.append(Task())
    block_12.block.append(Task())
    block_12.rescue.append(Task())
    block_12.always.append(Task())

# Generated at 2022-06-25 05:33:11.540457
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    result = play.compile_roles_handlers()
    expected_result = []
    assert result == expected_result


# Generated at 2022-06-25 05:33:44.236965
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    roles = [Role(), Role()]
    play_0.roles = roles

    # compile_roles_handlers
    block_list = compile_roles_handlers(roles)
    print("block_list= %s" % block_list)


# Generated at 2022-06-25 05:33:45.774806
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    assert isinstance(play_0.get_tasks(), list)


# Generated at 2022-06-25 05:33:51.096992
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    play_1 = Play()
    play_1.vars_files = None
    assert play_1.get_vars_files() == []

    play_2 = Play()
    play_2.vars_files = ['vars_file1.yaml']
    assert play_2.get_vars_files() == ['vars_file1.yaml']


# Generated at 2022-06-25 05:33:52.213113
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    assert [] == play.get_tasks()


# Generated at 2022-06-25 05:33:59.797937
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    # First test
    play_1.vars_files = None
    assert play_1.get_vars_files() == []
    # Second test
    play_1.vars_files = AnsibleFile()
    assert play_1.get_vars_files()[0] == play_1.vars_files
    # Third test
    play_1.vars_files = [AnsibleFile(), AnsibleFile(), AnsibleFile()]
    assert play_1.get_vars_files() == play_1.vars_files

