

# Generated at 2022-06-25 05:24:31.341177
# Unit test for method get_name of class Play
def test_Play_get_name():

    # Declaration of the object 'play_0'
    play_0 = Play()

    # Get the name of the object 'play_0'
    play_0_name = play_0.get_name()

    # Assertion
    assert play_0_name == '', "(0, '', '', '', '', '', '', '') != (0, '', '', '', '', '', '', '')"


# Generated at 2022-06-25 05:24:42.152472
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    target = lambda: True

    play_1 = Play()
    role_1 = Role()
    role_2 = Role()
    role_3 = Role()
    role_1.name = 'role_1'
    role_2.name = 'role_2'
    role_3.name = 'role_3'
    play_1.roles = [role_1, role_2, role_3]

    role_1.handlers = [target]
    role_2.handlers = [target, target]
    role_3.handlers = [target]

    result_1 = play_1.compile_roles_handlers()

    assert len(result_1) == 6, "The number of items in result_1 is wrong"
    assert result_1[0] is target

# Generated at 2022-06-25 05:24:43.812955
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    assert play_0.deserialize({})


# Generated at 2022-06-25 05:24:47.683413
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    print("Unit test for method deserialize of class Play")
    # Setup

    play_0 = Play()
    # Test

    try:
        play_0.deserialize({})
        # Check
    except Exception as e:
        print("Failed to deserialize Play, debug this line!")


# Generated at 2022-06-25 05:24:48.980506
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-25 05:24:52.787588
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # TODO
    pass

# Generated at 2022-06-25 05:25:04.264386
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_tasks1 = Play()
    play_2 = Play()
    play_2.tasks.append("task1")
    play_2.tasks.append("task2")
    play_2.tasks.append("task3")
    play_2.pre_tasks.append("pre_task1")
    play_2.pre_tasks.append("pre_task2")
    play_2.pre_tasks.append("pre_task3")
    play_2.post_tasks.append("post_task1")
    play_2.post_tasks.append("post_task2")
    play_2.post_tasks.append("post_task3")
    list_tasks = play_2.get_tasks()
    # Injecting fault: changing list_tasks by adding a

# Generated at 2022-06-25 05:25:08.890656
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    ret_val_0 = play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:25:20.196818
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.tasks = [{'action': {'__ansible_module__': 'ping', '__ansible_arguments__': {}}}, {'action': {'__ansible_module__': 'shell', '__ansible_arguments__': {}}}]
    play_1.pre_tasks = [{'action': {'__ansible_module__': 'shell', '__ansible_arguments__': {}}}]
    play_1.post_tasks = [{'action': {'__ansible_module__': 'shell', '__ansible_arguments__': {}}}, {'action': {'__ansible_module__': 'copy', '__ansible_arguments__': {}}}]

# Generated at 2022-06-25 05:25:21.384575
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    #  TODO
    assert False


# Generated at 2022-06-25 05:25:42.383481
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a block containing a single flush handlers meta
    # task, so we can be sure to run handlers at certain points
    # of the playbook execution
    flush_block = Block.load(
        data={'meta': 'flush_handlers'},
        play=Play(),
        variable_manager=VariableManager(),
        loader=None
    )

    for task in flush_block.block:
        task.implicit = True

    block_list = []

    block_list.append(flush_block)
    block_list.extend(Play()._compile_roles())
    block_list.append(flush_block)

    assert block_list

# Generated at 2022-06-25 05:25:49.109070
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()

# Generated at 2022-06-25 05:25:56.188793
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create a new Play
    play = Play()

    ds = {'hosts': 'all', 'tasks': [{'debug': {'msg': '{{ lookup(''vars'', ''inventory_hostname'') }}'}}]}

    # Call method
    try:
        result = play.preprocess_data(ds)
    except AnsibleAssertionError as e:
        display.warning("Got unexpected AnsibleAssertionError exception: {0}".format(str(e)))


# Generated at 2022-06-25 05:26:03.727838
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data_value = '{"hosts": [["host_1"], ["host_1"]], "post_tasks": [{"meta": "flush_handlers"}], "pre_tasks": [], "serial": [["0"]], "tasks": [{"block": [{"meta": "flush_handlers"}], "rescue": [], "always": []}]}'
    data = json.loads(data_value)
    play_0.deserialize(data)

# Generated at 2022-06-25 05:26:11.426255
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    print("Test Play.deserialize")

    # check for empty input
    if play_0.deserialize():
        print("FAIL: Play.deserialize should return None when input is empty")

    # check for None input
    if play_0.deserialize(None):
        print("FAIL: Play.deserialize should return None when input is None")

    # check for error when input is not dict
    if play_0.deserialize(1):
        print("FAIL: Play.deserialize should return None when input is not dict")

    # check for error when input is list
    if play_0.deserialize([]):
        print("FAIL: Play.deserialize should return None when input is list")

    # check for attributes set without error

# Generated at 2022-06-25 05:26:13.532094
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds = {u'hosts': u'localhost', u'name': u'testing'}
    play_0.preprocess_data(ds)


# Generated at 2022-06-25 05:26:18.349274
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []



# Generated at 2022-06-25 05:26:23.005832
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.vars_files = ['vars_files', 'vars_files']

    actual_result = play_0.get_vars_files()
    expected_result = [play_0.vars_files]
    assert(expected_result == actual_result)

    play_1 = Play()
    play_1.vars_files = 'vars_files'

    actual_result = play_1.get_vars_files()
    expected_result = [play_1.vars_files]
    assert(expected_result == actual_result)

    play_2 = Play()
    play_2.vars_files = None

    actual_result = play_2.get_vars_files()
    expected_result = []

# Generated at 2022-06-25 05:26:27.234434
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1_tasks = play_1.get_tasks()
    expected_play_1_tasks = []
    assert play_1_tasks == expected_play_1_tasks
    play_2 = Play()
    play_2.pre_tasks = [Task()]
    play_2.tasks = [Task()]
    play_2.post_tasks = [Task()]
    play_2_tasks = play_2.get_tasks()
    expected_play_2_tasks = [Task(), Task(), Task(), Task()]
    assert play_2_tasks == expected_play_2_tasks


# Generated at 2022-06-25 05:26:37.413698
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.playbook.role.include
    import ansible.plugins.loader
    _ = ansible.plugins.loader

    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.task
    _ = ansible.playbook.task

    import ansible.playbook.role.meta
    import ansible.playbook.role.tasks
    import ansible.playbook.role.vars
    import ansible.playbook.role.defaults
    _ = ansible.playbook.role.vars


# Generated at 2022-06-25 05:26:55.067657
# Unit test for method preprocess_data of class Play

# Generated at 2022-06-25 05:26:56.524615
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    if play_0.get_name() != '':
        raise AssertionError()


# Generated at 2022-06-25 05:27:01.283671
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # set up the Play object
    play = Play()
    play.handlers = [Block(), Block()]
    play_roles = [Role(), Role()]
    play_roles[0].handlers = [Block(), Block()]
    play_roles[1].handlers = [Block(), Block()]
    play.roles = play_roles

    # test that the expected number of blocks is returned
    assert len(play.compile_roles_handlers()) == 6


# Generated at 2022-06-25 05:27:03.912839
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds_0 = dict()
    play_0 = Play()
    rtn = play_0.preprocess_data(ds=ds_0)
    assert(rtn)


# Generated at 2022-06-25 05:27:11.037388
# Unit test for method get_name of class Play

# Generated at 2022-06-25 05:27:12.221964
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    print(play_0.get_tasks)


# Generated at 2022-06-25 05:27:18.920330
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks = [{'name': 'dummy'}]
    play_0.post_tasks = [{'name': 'dummy'}]
    play_0.pre_tasks = [{'name': 'dummy'}]
    play_0.get_tasks()


# Generated at 2022-06-25 05:27:25.668392
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test data
    play_1 = Test_Play()
    play_1.tasks = []
    play_1.post_tasks = []
    play_1.pre_tasks = []
    play_1.vars_files = []
    play_1.hosts = 'all'
    play_1.name = 'test'
    play_1.roles = []
    play_1.connection = 'smart'
    play_1.user = 'root'
    play_1.become = 'yes'
    play_1.become_method = 'sudo'
    play_1.tags = []
    play_1.handlers = []
    # Test call
    # Test assertion
    play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:27:27.032825
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    var_0 = play_0.get_tasks()


# Generated at 2022-06-25 05:27:29.538041
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_files = [u"vars_files"]
    play = Play()
    play.vars_files = vars_files
    assert play.get_vars_files() == [u"vars_files"]


# Generated at 2022-06-25 05:27:49.801790
# Unit test for method serialize of class Play
def test_Play_serialize():
    import copy

    # Test error case
    p = Play()
    data = p.serialize()
    assert data == {
        '_priority': 0,
        'name': '',
        'hosts': '',
        'roles': [],
        'included_path': None,
        'action_groups': {},
        'group_actions': {},
    }

    # Test success case

# Generated at 2022-06-25 05:27:53.380939
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    try:
        play_0 = Play()
        ds_0 = {'user': 'root'}
        play_0.preprocess_data(ds_0)
    except:
        print('Exception thrown')


# Generated at 2022-06-25 05:28:02.659945
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Create test objects
    play = Play()

    # Create data
    data = {
        "name": "My Play",
        "connection": "ssh",
        "hosts": "localhost",
        "gather_facts": True,
        "roles": [
            {
                "role": "apache"
            },
            {
                "role": "mysql"
            }
        ]
    }

    # Run tests
    play.deserialize(data)
    assert play.name == "My Play"
    assert play.connection == "ssh"
    assert play.hosts == "localhost"
    assert play.gather_facts
    assert play.roles[0].name == "apache"
    assert play.roles[1].name == "mysql"


# Generated at 2022-06-25 05:28:06.652195
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.get_tasks()

if __name__ == '__main__':
    # test_case_0()
    test_Play_get_tasks()

# Generated at 2022-06-25 05:28:15.971400
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    play_1.deserialize({})
    play_2 = Play()
    play_2.deserialize({})

    play_3 = Play()
    play_3.deserialize({})
    #play_3.deserialize(None)

    play_4 = Play()
    play_4.deserialize(play_1)
    play_5 = Play()
    play_5.deserialize(play_1)

    play_6 = Play()
    play_6.deserialize(play_2)
    play_7 = Play()
    play_7.deserialize(play_2)

    return play_0, play_1, play_2, play_3, play_4, play_5, play_6, play_7


# Generated at 2022-06-25 05:28:25.668838
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    def play_preprocess_data_0():
        play_0 = Play()
        play_0._ds = {'user': 'alex'}
        play_0.preprocess_data(play_0._ds)
        assert play_0._ds == {'remote_user': 'alex'}

    def play_preprocess_data_1():

        # Test exception thrown by play_preprocess_data_0
        try:
            play_preprocess_data_0()
        except:
            pass
        else:
            pytest.fail("DID NOT RAISE")

    play_preprocess_data_1()

    # Test exception thrown by play_preprocess_data
    try:
        Play().preprocess_data('some_string')
    except:
        pass

# Generated at 2022-06-25 05:28:35.953636
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    Unit test for method get_tasks of class Play
    '''
    play_0 = Play()
    task_0 = dict(action=dict(args=dict(), module='ping'))
    task_1 = dict(action=dict(args=dict(), module='command'), args=dict(cmd='uptime'))
    task_2 = dict(action=dict(args=dict(), module='ping'))
    task_3 = dict(action=dict(args=dict(), module='command'), args=dict(cmd='ping'))
    play_0.tasks = [task_0, task_1]
    play_0.pre_tasks = [task_2]
    play_0.post_tasks = [task_3]

# Generated at 2022-06-25 05:28:47.220882
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_1 = Play()
    data = {}
    data['hosts'] = 'all'
    data['roles'] = [{'_role_name': 'common', 'tasks': [{'debug': {'msg': 'Hello world'}}], '_role_path': '/etc/ansible/roles/common'}]
    play_1.deserialize(data)
    assert play_1.hosts == 'all'
    assert play_1.roles[0].role_name == 'common'
    assert play_1.roles[0].tasks[0].action == 'debug'
    assert play_1.roles[0].tasks[0].args.get('msg') == 'Hello world'

# Generated at 2022-06-25 05:28:48.930945
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasks_0 = play_0.get_tasks()


# Generated at 2022-06-25 05:29:00.037843
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # If self.vars_files is None then return an empty list
    play_1 = Play()
    play_1.vars_files = None
    result_1 = play_1.get_vars_files()
    assert result_1 == []
    # If self.vars_files is not a list then return a list with one element
    play_1.vars_files = {}
    result_1 = play_1.get_vars_files()
    assert result_1 == [{}]
    # If self.vars_files is a list then return self.vars_files
    play_1.vars_files = ['file']
    result_1 = play_1.get_vars_files()
    assert result_1 == ['file']


# Generated at 2022-06-25 05:29:12.587199
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    name_0 = play_0.get_name( )
    assert name_0 == ''


# Generated at 2022-06-25 05:29:16.749891
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_obj = Play()
    play_obj.roles = []
    out = play_obj.compile_roles_handlers()
    assert out == []


# Generated at 2022-06-25 05:29:23.623963
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_vars_files_1 = Play(vars_files=None)
    assert play_vars_files_1.get_vars_files() == []
    play_vars_files_2 = Play(vars_files=[])
    assert play_vars_files_2.get_vars_files() == []
    play_vars_files_3 = Play(vars_files='abc.yml')
    assert play_vars_files_3.get_vars_files() == ['abc.yml']
    play_vars_files_4 = Play(vars_files=['abc.yml', 'xyz.yml'])
    assert play_vars_files_4.get_vars_files() == ['abc.yml', 'xyz.yml']

# Unit test

# Generated at 2022-06-25 05:29:27.007066
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    dict_0 = dict({'connection': 'smart',
                   'hosts': ['localhost'],
                   'roles': ['common'],
                   'tasks': [{'name': 'role'},
                             {'name': 'tasks'}]})

    play_0 = Play()
    Play._get_tasks(play_0, dict_0)


# Generated at 2022-06-25 05:29:38.750383
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = ["role_0"]
    play_1.roles[0].handlers = Block([])
    play_1_expected = []
    play_1_expected[0:0] = play_1.roles[0].handlers
    play_1_actual = play_1.compile_roles_handlers()
    if len(play_1_expected) != len(play_1_actual):
        print("FAILED - test_Play_compile_roles_handlers: Unexpected number of handlers in list returned by compile_roles_handlers()")
        print("Expected: " + str(play_1_expected) + ", actual: " + str(play_1_actual))
        return False

# Generated at 2022-06-25 05:29:39.862733
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    play_0.preprocess_data("hosts")

# Generated at 2022-06-25 05:29:42.189960
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    if len(play_1.get_tasks()) != 0:
        return False
    return True


# Generated at 2022-06-25 05:29:44.464564
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    serialize_1 = play_1.serialize()


# Generated at 2022-06-25 05:29:52.805573
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    play_1 = Play()
    block_list_1 = play_1.compile_roles_handlers()
    assert isinstance(block_list_1, list)
    assert block_list_1 == []

    play_2 = Play()
    r_2a = Role()
    r_2a.vars = {'role_var': 'role_value'}
    r_2a.tasks = [
        {'action': {'__ansible_module__': 'debug',
                    'msg': "'role_var={{role_var}}'"}}]

# Generated at 2022-06-25 05:29:53.832284
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_case_0()


# Generated at 2022-06-25 05:30:07.548682
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    assert play_1.compile_roles_handlers() == []


# Generated at 2022-06-25 05:30:16.796962
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    play_1 = Play()


# Generated at 2022-06-25 05:30:19.824210
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.get_name() == ''
    play_1 = Play()
    play_1.get_name() == ''


# Generated at 2022-06-25 05:30:26.989717
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1._pre_tasks = ['task_1', 'task_2']
    play_1._tasks = ['task_3', 'task_4']
    play_1._post_tasks = ['task_5', 'task_6']

    assert len(play_1.get_tasks()) == 6


# Generated at 2022-06-25 05:30:31.346429
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Create an instance of a Play class.
    play_1 = Play()
    # Test field vars_files
    assert play_1.get_vars_files() == []
    # Create an instance of a Play class.
    play_2 = Play()
    # Test field vars_files
    assert play_2.get_vars_files() == []


# Generated at 2022-06-25 05:30:37.137280
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks.append(Block())
    play_0.pre_tasks.append(Block())
    play_0.post_tasks.append(Block())
    actual = play_0.get_tasks()
    expected = [play_0.pre_tasks[0], play_0.tasks[0], play_0.post_tasks[0]]
    assert expected == actual


# Generated at 2022-06-25 05:30:39.035038
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    all_tasks = play_0.get_tasks()
    assert len(all_tasks) == 0


# Generated at 2022-06-25 05:30:42.187483
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Instantiate an object of class Play
    play_2 = Play()
    # Test the return value of the method compile_roles_handlers and if it is a list
    assert isinstance(play_2.compile_roles_handlers(),list)


# Generated at 2022-06-25 05:30:51.460176
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.set_loader(DictDataLoader({}))
    play_1.ROLE_CACHE = None
    play_1.post_validate()

    # Testing the  first branch of the method
    try:
        data = dict(
            name = "Include 'webservers'",
            hosts = "webservers",
            include_role = dict(name = "apache")
        )
        include_role = load_list_of_roles(data, play_1, loader = DictDataLoader({}))
        play_1.roles = include_role
        play_1.compile_roles_handlers()
        assert True
    except AssertionError:
        assert False

    # Testing the  second branch of the method

# Generated at 2022-06-25 05:30:55.695519
# Unit test for method get_name of class Play
def test_Play_get_name():

    # test_case_1
    play_1 = Play()
    play_1.name = 'test1'
    assert play_1.get_name() == 'test1'

    # test_case_2
    play_2 = Play()
    play_2.hosts = 'test2'
    assert play_2.get_name() == 'test2'



# Generated at 2022-06-25 05:31:08.851948
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    play_0 = Play()
    play_0.preprocess_data("Play data")



# Generated at 2022-06-25 05:31:17.240645
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    play_1.vars_files = None
    assert play_1.get_vars_files() == []

    play_2 = Play()
    play_2.vars_files = []
    assert play_2.get_vars_files() == []

    play_3 = Play()
    play_3.vars_files = "a.yml"
    assert play_3.get_vars_files() == ['a.yml']

    play_4 = Play()
    play_4.vars_files = ["b.yml", "c.yml"]
    assert play_4.get_vars_files() == ['b.yml', 'c.yml']


# Generated at 2022-06-25 05:31:23.370863
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_case_0()
    play_1 = Play()
    play_1.name = 'test_name'
    result_1 = play_1.get_name()
    assert result_1 == 'test_name'


# Generated at 2022-06-25 05:31:27.877685
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    play_1 = Play()
    play_1.roles = []
    assert play_1.compile_roles_handlers() == []

    play_2 = Play()
    play_2.roles = [1, 2, 3]
    assert play_2.compile_roles_handlers() == [1, 2, 3]


# Generated at 2022-06-25 05:31:30.374070
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    block_list_1 = play_0.compile_roles_handlers()
    print(block_list_1)


# Generated at 2022-06-25 05:31:33.984757
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    for i in range(10):
        assert play_0.compile_roles_handlers() == []


# Generated at 2022-06-25 05:31:46.570010
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    ds = dict()
    try:
        play_1.preprocess_data(ds)
    except AnsibleAssertionError as e:
        # ['while preprocessing data %s, ds should be a dict but was a %s']
        assert(e.args[0] == 'while preprocessing data %s, ds should be a dict but was a %s' and e.args[1] == ds and e.args[2] == type(ds))
    play_2 = Play()
    ds = ""

# Generated at 2022-06-25 05:31:48.071069
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    assert_equal(play_0.get_tasks(), [])


# Generated at 2022-06-25 05:31:59.159911
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create play object
    play_1 = Play()
    # Verify that the method returns an empty list
    assert play_1.compile_roles_handlers() == []
    # Create a RoleInclude object
    ri = RoleInclude()
    # Add the RoleInclude object to the play
    play_1.roles.append(ri)
    # Assert that the method returns an empty list
    assert play_1.compile_roles_handlers() == []
    # Create a Block object
    block_1 = Block()
    # Create a Block object
    block_2 = Block()
    # Add the blocks to the play
    play_1.handlers.append(block_1)
    play_1.handlers.append(block_2)
    # Verify that the method returns the blocks
    assert play_

# Generated at 2022-06-25 05:32:09.849055
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_1.name = "play_1"
    assert play_1.get_name() == "play_1"
    del play_1.name
    play_1.hosts = "host1"
    assert play_1.get_name() == "host1"
    play_1.hosts = None
    assert play_1.get_name() == ""
    play_1.hosts = ["host1"]
    assert play_1.get_name() == "host1"
    play_1.hosts = ["host1", "host2"]
    assert play_1.get_name() == "host1,host2"

# Generated at 2022-06-25 05:32:33.040483
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play1 = Play()
    play1.roles = [{'name': 'test', 'tasks': []}]
    assert play1.compile_roles_handlers() == []



# Generated at 2022-06-25 05:32:42.113784
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = [Role()]
    play_1.roles[0]._handlers = [Block()]
    play_1.roles[0]._handlers[0].block = [Task()]
    play_1.roles[0]._handlers[0].block[0].name = 't1'
    play_1.roles[0]._handlers[0].name = 'b1'

    play_1.roles[0]._handlers.append(Block())
    play_1.roles[0]._handlers[1].block = [Task()]
    play_1.roles[0]._handlers[1].block[0].name = 't2'
    play_1.roles[0]._handlers[1].name

# Generated at 2022-06-25 05:32:44.272859
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    Test case for  get_vars_files of class Play
        Test for a variable files list of length 0
    '''
    assert Play().get_vars_files() == [], 'Test vars_files of 0 failed'


# Generated at 2022-06-25 05:32:49.882120
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # create blocks, tasks, and push them into play
    play = Play()

    play.tasks = [
        {
            'name': 'test',
            'action': 'test'
        },
        {
            'name': 'test2',
            'action': 'test2'
        }
    ]

    task_list = play.get_tasks()

    assert len(task_list) == 2 and task_list[0].action == 'test' and task_list[1].action == 'test2'


# Generated at 2022-06-25 05:32:52.280449
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    assert isinstance(play_0.compile_roles_handlers(), list)


# Generated at 2022-06-25 05:32:58.028353
# Unit test for method get_name of class Play
def test_Play_get_name():

    play_0 = Play()
    assert play_0.get_name() == ''

    play_0 = Play()
    play_0 = Play()
    play_0 = Play()

    play_0 = Play()
    play_0 = Play()
    play_0 = Play()

    play_0 = Play()
    play_0 = Play()
    play_0 = Play()
    play_0.get_name()

    play_0 = Play()
    play_0 = Play()
    play_0 = Play()
    play_0.get_name()
    play_0.get_name()
    play_0.get_name()


# Generated at 2022-06-25 05:32:59.350983
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.get_name() == ''


# Generated at 2022-06-25 05:33:02.587258
# Unit test for constructor of class Play
def test_Play():
    try:
        test_case_0()
    except Exception as e:
        raise Exception(e)

# Test the constructor
if __name__ == "__main__":
    test_Play()

# Generated at 2022-06-25 05:33:10.934855
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()

    # boundary test:
    #   vars_files is None
    assert play.get_vars_files() == []
    # boundary test:
    #   vars_files is not None and not a list
    play.vars_files = 'test'
    assert play.get_vars_files() == [play.vars_files]
    # boundary test:
    #   vars_files is a list
    play.vars_files = ['test1', 'test2']
    assert play.get_vars_files() == play.vars_files

if __name__ == "__main__":
    test_case_0()
    test_Play_get_vars_files()

# Generated at 2022-06-25 05:33:20.719085
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # _load_roles() should set _roles to a list
    play_1 = Play()
    play_1._load_roles(None, None)
    assert isinstance(play_1._roles, list)

    # _load_roles() should call function load_list_of_roles
    play_2 = Play()
    mock_ds = []
    mock_variable_manager = mock.MagicMock()
    mock_loader = mock.MagicMock()
    with mock.patch('ansible.playbook.play.load_list_of_roles', return_value=[]):
        play_2._load_roles(None, mock_ds)