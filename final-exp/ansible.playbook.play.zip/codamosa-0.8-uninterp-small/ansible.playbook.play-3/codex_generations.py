

# Generated at 2022-06-25 05:24:19.775589
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from collections import OrderedDict
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    new_play = Play()
    new_play.compile_roles_handlers()
    assert new_play is not None
    new_play_2 = Play()
    h1 = Handler.load(data={'name': 'Handler 3', 'listen': 'Handler 3'}, play=new_play_2, variable_manager=None, loader=None)
    h2 = Handler.load(data={'name': 'Handler 4', 'listen': 'Handler 4'}, play=new_play_2, variable_manager=None, loader=None)
    h1.block.append(Block.load(data={'block': [], 'rescue': [], 'always': []}))
    h

# Generated at 2022-06-25 05:24:22.423897
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    a_play = Play()
    a_play.handlers = ['handlers_list']
    result = a_play.compile_roles_handlers()
    assert len(result) == 1
    assert result[0] == 'handlers_list'


# Generated at 2022-06-25 05:24:32.220585
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from collections import OrderedDict
    data_dict = dict(
        name = 'test',
        hosts = 'all',
        user = 'test',
        roles =
        [
            'test_role'
        ]
    )
    data_dict_ordered = OrderedDict(
        name = 'test',
        hosts = 'all',
        user = 'test',
        roles =
        [
            'test_role'
        ]
    )
    play = Play()
    play.preprocess_data(data_dict)
    print(play._ds)
    print(play._ds_validated)
    play.preprocess_data(data_dict_ordered)
    print(play._ds)
    print(play._ds_validated)
    print(play._attributes)


# Generated at 2022-06-25 05:24:42.924323
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print('Test: Play_get_tasks')
    play_1 = Play()
    play_1.hosts = 'hosts'
    play_1.roles = 'roles'
    play_1.tasks = ['task_0', 'task_1', 'task_2']
    play_1.handlers = 'handlers'
    play_1.defaults = 'defaults'
    play_1.vars_prompt = 'vars_prompt'
    play_1.vars_files = 'vars_files'
    play_1.name = 'name'
    play_1.vars = ['var_0', 'var_1']
    play_1.remote_user = 'remote_user'
    play_1.serial = 'serial'
    play_1.tags = 'tags'

# Generated at 2022-06-25 05:24:51.531422
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''
    Unit test for method get_name of class Play
    '''

    # Check that the method returns the correct value
    # when the name of play is set
    play_0 = Play()
    play_0.name = 'Test Play 0'
    assert play_0.get_name() == 'Test Play 0'

    # Check that the method returns the correct value
    # when the name of play is not set and the hosts variable
    # is a list (sequence)
    play_1 = Play()
    play_1.hosts = ['host_1', 'host_2']
    assert play_1.get_name() == 'host_1,host_2'

    # Check that the method returns the correct value
    # when the name of play is not set and the hosts variable
    # is a string

# Generated at 2022-06-25 05:24:52.723049
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    play_1.serialize()


# Generated at 2022-06-25 05:25:00.455981
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Case 1:
    # play_data has a top-level "user" option
    play_data = dict(
        name = "test play",
        hosts = "all",
        user = "root",
        tasks = [],
    )

    play_0 = Play()
    play_0.preprocess_data(play_data)
    assert(play_0.get_name() == "test play")
    assert(play_0.remote_user == "root")

    # Case 2:
    # play_data has a top-level "user" option and a top-level "remote_user" option
    play_data = dict(
        name = "test play",
        hosts = "all",
        user = "root",
        remote_user = "user",
        tasks = [],
    )


# Generated at 2022-06-25 05:25:02.426185
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    mock_play = Play()
    return_value = mock_play.get_tasks()
    assert len(return_value) == 0


# Generated at 2022-06-25 05:25:04.138852
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    tasks_1 = play_1.get_tasks()
    assert tasks_1 == []


# Generated at 2022-06-25 05:25:08.592822
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasks_0 = play_0.get_tasks()


# Generated at 2022-06-25 05:25:21.662142
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_payload = {
        'tasks':[
            {'task1':{'a':1}},
            {'task2': {'b':2}}
        ]
    }

    play_1 = Play().load(data=test_payload, variable_manager=variable_manager, loader=loader)
    assert len(play_1.tasks) ==2
    for task in play_1.tasks:
        assert isinstance(task, Task)
    assert isinstance(play_1.get_tasks(), list)
    assert len(play_1.get_tasks())== 4
    assert isinstance(play_1.get_tasks()[0], Task)
    assert isinstance(play_1.get_tasks()[1], Task)

# Generated at 2022-06-25 05:25:31.229436
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print('Test function get_vars_files of class Play')
    a_vars_files = [
    {
        'foo': 'bar',
        'baz': 123
    },
    {
        'spam': 'eggs'
    }
    ]
    play_1 = Play()
    assert play_1.get_vars_files() == []
    play_1.vars_files = a_vars_files
    assert play_1.get_vars_files() == a_vars_files


# Generated at 2022-06-25 05:25:39.204350
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:25:45.914118
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.roles = [{'block': []}, {'block': []}]
    play_0.roles[0].get_handler_blocks = lambda self: play_0.roles[0]['block']
    play_0.roles[1].get_handler_blocks = lambda self: play_0.roles[1]['block']
    play_0.roles[0]['block'] = [{'name': 'test0'}, {'name': 'test1'}]
    play_0.roles[1]['block'] = [{'name': 'test2'}, {'name': 'test3'}]
    play_0.compile_roles_handlers()



# Generated at 2022-06-25 05:25:51.244096
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.pre_tasks = list()
    play_0.tasks = list()
    play_0.post_tasks = list()
    play_0.get_tasks()


# Generated at 2022-06-25 05:25:54.060721
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    block_list_0 = play_1.compile_roles_handlers()
    assert(block_list_0 == [])

    pass

# Generated at 2022-06-25 05:25:54.971708
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass


# Generated at 2022-06-25 05:25:57.830625
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data_0 = {}
    play_0.deserialize(data_0)
    assert(play_0.serialize() == play_0.deserialize(data=data_0).serialize())


# Generated at 2022-06-25 05:26:03.377739
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasklist = play_0.get_tasks()
    print("Printing tasklist")
    for task in tasklist:
        print("    " + str(task))

    #assert(result == expected)


# Generated at 2022-06-25 05:26:07.900411
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    data = '{"name": "test", "description": "this is a test", "connection": "local", "vars": {}, "vars_prompt": [], "vars_files": [], "meta": {}, "roles": [], "included_path": None}'
    play_0.deserialize(data)

# Generated at 2022-06-25 05:26:21.408822
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # run the method
    play_0 = Play.load(dict(tasks=[dict(action=dict(module='setup'), register='setup_facts')]))
    play_0.compile()
    play_1 = Play.load(dict(
        tasks=[
            dict(action=dict(module='setup'), register='setup_facts'),
            dict(include_role=dict(name='common'))
        ]
    ))
    play_1.compile()


# Generated at 2022-06-25 05:26:28.353262
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    print('')
    print('Test: Play.deserialize')
    # Test using var "removed_hosts"
    print('    Test: Play.deserialize using var "removed_hosts"')
    play = Play()
    data = {}
    data['removed_hosts'] = None
    play.deserialize(data)
    print('        Pass: Play.deserialize using var "removed_hosts"')
    # Test using var "tasks"
    print('    Test: Play.deserialize using var "tasks"')
    play = Play()
    data = {}
    data['tasks'] = []
    play.deserialize(data)
    print('        Pass: Play.deserialize using var "tasks"')
    # Test using var "roles"

# Generated at 2022-06-25 05:26:29.008727
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()


# Generated at 2022-06-25 05:26:37.982157
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:26:46.550949
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """
    Test that play a.yml contains:
    1. 2 handlers
    2. 2 simple tasks
    3. 1 role with 2 handlers
    """

    test_file_path = os.path.join(os.path.dirname(__file__), "../test_data/test_Play_compile_roles_handlers")
    test_file = "a.yml"
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=[os.path.join(test_file_path, "hosts")])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = os.path.join(test_file_path, test_file)
    p = Play.load(play_source, variable_manager=variable_manager, loader=loader)
    p.comp

# Generated at 2022-06-25 05:26:48.517517
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    data = play_0.serialize()
    pass


# Generated at 2022-06-25 05:26:53.417425
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test data
    data = {
        'name': 'test_play_preprocess_data',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'user': 'root'
    }
    play = Play() 
    processed_data = play.preprocess_data(data)
    assert not isinstance(processed_data, dict)
    assert 'remote_user' not in processed_data
    assert isinstance(processed_data, dict)
    assert 'user' not in processed_data


# Generated at 2022-06-25 05:26:54.188552
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()



# Generated at 2022-06-25 05:27:03.207177
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    t1 = Task()
    t2 = Task()
    t3 = Task()
    t4 = Task()

    play_1 = Play()
    play_1.pre_tasks = [t1]
    play_1.tasks = [t2]
    play_1.post_tasks = [t3]

    task_list = play_1.get_tasks()
    assert task_list.index(t1) < task_list.index(t2) < task_list.index(t3) is True, "failed test 1"

if __name__ == "__main__":
    test_case_0()
    test_Play_get_tasks()

# Generated at 2022-06-25 05:27:12.087628
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """
    Test the compile_roles_handlers method of Play
    """
    # create a test Play
    play_content = """
    - hosts: all
      roles:
        - nginx
        - mysql
      gather_facts: yes
      tasks:
      - name: task-1
        shell: echo 'Hello World!'
      handlers:
      - name: handler-1
        shell: touch /tmp/handler-1
      - name: handler-2
        shell: touch /tmp/handler-2
      """
    # load test Play
    play = Play.load(play_content, None, None)
    # compile roles
    block_list = play.compile_roles_handlers()
    # test the length of handler list
    assert len(block_list) == 2
    # test the name and block list


# Generated at 2022-06-25 05:27:33.584819
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    print("\n___________________________________________________\nRunning test_Play_deserialize\n")

    play_deserialize = Play()

    # Assign data
    dict = dict()
    dict['name'] = 'Install Tomcat'

    # deserialize by passing 'dict'
    play_deserialize.deserialize(dict)

    # check whether the deserialized data is same
    assert play_deserialize.name == dict['name']

    # remove 'dict'
    dict.clear()

    # set new data in dict
    dict['name'] = 'Install Apache'
    dict['free-form_tags'] = ['server', 'webserver']

    # Deserialize by passing 'dict'
    play_deserialize.deserialize(dict)

    # check whether the deserialized data is same
    assert play

# Generated at 2022-06-25 05:27:43.437466
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create an instance of a Play
    # Play has one attribute: _handlers, an empty list
    play = Play()
    # Compile the handler blocks of all roles in play.
    # play.roles is an empty list
    # Expect empty list to be returned
    assert play.compile_roles_handlers() == []

    play_1 = Play()
    role_1 = Role()
    role_1.handlers = [Block(play=play_1, role=role_1)]
    role_1.get_handler_blocks(play=play_1)
    play_1.roles = [role_1]

    assert play_1.compile_roles_handlers() == [role_1.handlers[0]]
    play_2 = Play()
    role_2 = Role()
    role_2

# Generated at 2022-06-25 05:27:50.190500
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play1 = Play()
    ds1 = dict(hosts='localhost')
    play1.load(ds1)
    assert play1['hosts'] == 'localhost'
    ds2 = dict(hosts=['localhost', '127.0.0.1'])
    play2 = Play()
    play2.load(ds2)
    assert play2['hosts'] == ['localhost', '127.0.0.1']
    ds3 = dict(hosts='localhost', remote_user='test')
    play3 = Play()
    play3.load(ds3)
    assert play3['hosts'] == 'localhost'
    assert play3['remote_user'] == 'test'
    ds4 = dict(user='test')
    play4 = Play()
    play4.load(ds4)
   

# Generated at 2022-06-25 05:27:57.015187
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    # Test case where vars_files is None
    assert play_0.get_vars_files() == []

    # Test case where vars_files is a list
    play_2 = Play()
    play_2.vars_files = []
    assert play_2.get_vars_files() == []

    # Test case where vars_files is a string
    play_1 = Play()
    play_1.vars_files = "string"
    assert play_1.get_vars_files() == ["string"]


# Generated at 2022-06-25 05:28:01.301213
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()

    play_0.name = u'test_play_name'
    rc = play_0.get_name()
    assert rc == u'test_play_name'


# Generated at 2022-06-25 05:28:09.032210
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    assert play.get_vars_files() == []

    play = Play(vars_files='vars_files_attr')
    assert play.get_vars_files() == ['vars_files_attr']

    play = Play(vars_files=['vars_files_attr1', 'vars_files_attr2'])
    assert play.get_vars_files() == ['vars_files_attr1', 'vars_files_attr2']

# Generated at 2022-06-25 05:28:14.141030
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Setup
    play = Play()
    role1 = Role()
    role1.handlers = [
        {'name': 'Test Handler 1'}
    ]
    role2 = Role()
    role2.handlers = [
        {'name': 'Test Handler 2'}
    ]
    play.roles = [role1, role2]

    # Test
    results = play.compile_roles_handlers()

    # Verify
    assert len(results) == 2
    assert results[0].name == 'Test Handler 1'
    assert results[1].name == 'Test Handler 2'

# Generated at 2022-06-25 05:28:22.593534
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create a fake play
    role1 = create_fake_role('role1')
    role2 = create_fake_role('role2')
    fake_play = Play()
    fake_play.roles = [role1, role2]
    # create a fake handler
    fake_handler = create_fake_handler()
    # set the handlers of each role accordingly
    role1.get_handler_blocks.return_value = [fake_handler]
    role2.get_handler_blocks.return_value = [fake_handler]
    # compile roles
    fake_play.compile_roles_handlers()
    # assert the handlers of the play are the same as the handlers of the fake play
    assert fake_play.handlers == fake_play.compile_roles_handlers()


# Generated at 2022-06-25 05:28:24.886966
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    var_files = '/path/to/vars_files'
    play_0.vars_files = var_files
    assert play_0.get_vars_files() == [var_files]


# Generated at 2022-06-25 05:28:30.022227
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:28:44.001273
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    play_0 = Play()
    data_0 = dict()
    play_0.preprocess_data(data_0)


# Generated at 2022-06-25 05:28:50.006474
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    play = Play()
    play.deserialize({"name": "test", "hosts": "all"})


# Generated at 2022-06-25 05:29:00.333529
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    play = Play()
    play.deserialize({
        'name': 'foo',
        'playbook_uuid': 'uuid_1',
        'roles': [{
            'name': 'role1',
            'tasks': [{
                'name': 'task1'
            }]
        }],
        '_action_groups': {
            'login': {
                'hosts': ['localhost'],
                'vars': {'h': 'h'},
                'tasks': []
            }
        },
        '_group_actions': {
            'all': ['login']
        }
    })

    assert play.name == 'foo'
    assert play.playbook_uuid == 'uuid_1'
    assert play.roles[0].name == 'role1'

# Generated at 2022-06-25 05:29:02.261878
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    if play_0.get_vars_files() != []:
        print('Expected: %s' % [])
        print('But got: %s' % play_0.get_vars_files())


# Generated at 2022-06-25 05:29:13.286821
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    play_2 = Play()
    play_2.vars_files = None
    result = play_2.get_vars_files()
    assert result == []

    play_3 = Play()
    play_3.vars_files = 'file0'
    result = play_3.get_vars_files()
    assert result == ['file0']

    play_4 = Play()
    play_4.vars_files = ['file1', 'file2']
    result = play_4.get_vars_files()
    assert result == ['file1', 'file2']


# Generated at 2022-06-25 05:29:14.261749
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    task_list = play_0.get_tasks()


# Generated at 2022-06-25 05:29:19.061209
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    yaml_0 = """debug:
  msg: 'hi'
hosts:
  - localhost
tasks:
  - debug:
      msg: 'running debug'
  - name: 'debug 2'
    debug:
      msg: 'running debug 2'
"""

    play_0 = Play.load(datastructure_load(yaml_0))

    tasks_0 = play_0.get_tasks()

    assert len(tasks_0) == 2, "Expected 2 elements but we have " + str(len(tasks_0))



# Generated at 2022-06-25 05:29:28.148790
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import ansible.plugins.action.normal as normal
    import jinja2

    C.DEFAULT_HANDLER_TASK_NAME = 'meta'
    C.HOST_KEY_CHECKING = False

    play_0 = Play()
    play_0._variable_manager = VariableManager()
    play_0._loader = jinja2.DictLoader({})
    play_0._tqm = None
    play_0.role_names = []
    play_0.handlers = []

    r

# Generated at 2022-06-25 05:29:37.391624
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    vars_files_0 = play_0.get_vars_files()
    assert play_0.__class__.__name__ == 'Play', "play_0.__class__.__name__ is not Play"
    assert vars_files_0.__class__.__name__ == 'list', "vars_files_0.__class__.__name__ is not list"
    assert len(vars_files_0) == 0, "len(vars_files_0) is not 0"


# Generated at 2022-06-25 05:29:46.910222
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    handlers = play_0.compile_roles_handlers()
    assert len(handlers) == 0

    test_role = Role()

    test_task = Task()
    test_task.name = 'test_task'
    test_task.action = 'test'

    test_handler = Handler()
    test_handler.name = 'test_handler'
    test_handler.task_action = 'test'

    test_block = Block()
    test_block.block = [test_task]

    test_role.handlers = [test_handler]
    test_role.tasks = [test_block]

    play_0.roles = [test_role]

    assert len(play_0.roles) == 1

    handlers = play_0.compile_roles_

# Generated at 2022-06-25 05:30:15.005165
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from collections import namedtuple
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.errors import AnsibleError

    # Create an instance of a Play named 'test'
    # including a single role named 'role-0'
    # which has a single handler named 'handler-0'
    Play_0 = Play()
    Play_0.name = 'test'
    Role_0 = Role()
    Role_0.name = 'role-0'
    Handler_0 = Handler(name = 'handler-0')
    Role_0.handlers = [Handler_0]
    Play_0.roles = [Role_0]

# Generated at 2022-06-25 05:30:18.356408
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1._load_roles = MagicMock(return_value = [Role.load(RoleInclude.load({'role': 'test'}, play=play_1))])
    play_1.compile_roles_handlers()


# Generated at 2022-06-25 05:30:20.928592
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.fake_load()
    play_0.name = 'name'
    output = play_0.get_name()
    if output != 'name':
        raise Exception('Play.get_name() should return "name"')


# Generated at 2022-06-25 05:30:30.174250
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.get_vars_files() == []

    play_1 = Play()
    play_1.vars_files = None
    assert play_1.get_vars_files() == []

    play_2 = Play()
    play_2.vars_files = ['/tmp/a', '/tmp/b']
    assert play_2.get_vars_files() == ['/tmp/a', '/tmp/b']

    play_3 = Play()
    play_3.vars_files = '/tmp/c'
    assert play_3.get_vars_files() == ['/tmp/c']


# Generated at 2022-06-25 05:30:32.003914
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.get_vars_files() == []


# Generated at 2022-06-25 05:30:34.035350
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert Play.get_tasks() is None

# Generated at 2022-06-25 05:30:37.888383
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()

    name_0 = play_0.get_name()
    assert name_0 == ''

    play_0.name = 'foobar'

    name_1 = play_0.get_name()
    assert name_1 == 'foobar'


# Generated at 2022-06-25 05:30:45.729249
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    setattr(play_0, "vars_files", None)
    assert play_0.get_vars_files() == []
    setattr(play_0, "vars_files", "Test string")
    assert play_0.get_vars_files() == ["Test string"]
    obj_0 = Play()
    setattr(obj_0, "vars_files", ["Test string", "Test string"])
    assert obj_0.get_vars_files() == ["Test string", "Test string"]


# Generated at 2022-06-25 05:30:51.317533
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    data = play_0.serialize()
    assert_equal(data['name'], '')
    assert_equal(data['hosts'], 'all')


# Generated at 2022-06-25 05:30:58.924114
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    ds = dict(a=1, b=2)
    play_1 = Play()
    actual = play_1.preprocess_data(ds)
    expected = dict(a=1, b=2)
    assert actual == expected
    assert not play_1._ds
    assert play_1._ds is None

    ds = [1, 2]
    play_2 = Play()
    # If assertion fails, this function will raise exception.
    play_2.preprocess_data(ds)

    ds = 1
    play_3 = Play()
    # If assertion fails, this function will raise exception.
    play_3.preprocess_data(ds)


# Generated at 2022-06-25 05:31:24.236017
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    serialized_datastructure = play_0.serialize()

    # Compare the serialized datastructure with the expected

# Generated at 2022-06-25 05:31:28.973847
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    play_1.roles = [Role(),]

    relative_path = 'plugins/action/__init__.py'
    real_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), relative_path)
    play_1.roles[0]._role_path = os.path.dirname(real_path)

    ansible_playbook_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')
    playbook_path = os.path.join(ansible_playbook_path, 'test')
    play_1.roles[0].name = 'test'
    play_1.roles[0]._role_name = 'test'

# Generated at 2022-06-25 05:31:38.482108
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.vars = {'test': 'success'}
    play_1 = play_0.copy()

    r = Role._load_role({'name': 'test'}, play=play_0)
    play_0.roles.append(r)

    play_1.deserialize(play_0.serialize())

    assert play_0._validate_attributes() == play_1._validate_attributes() and play_0.roles[0]._validate_attributes() == play_1.roles[0]._validate_attributes()


# Generated at 2022-06-25 05:31:49.926514
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = load_play(dict(
        name=u'play_0',
        hosts=u'host_0',
    ))
    assert play_0.get_name() == u'play_0'

    play_0 = load_play(dict(
        hosts=u'host_0',
    ))
    assert play_0.get_name() == u'host_0'

    play_0 = load_play(dict(
        hosts=[u'host_0'],
    ))
    assert play_0.get_name() == u'host_0'

    play_0 = load_play(dict(
        hosts=['host_0', 'host_1'],
    ))
    assert play_0.get_name() == u'host_0,host_1'

    play_0 = load_

# Generated at 2022-06-25 05:31:53.927161
# Unit test for method get_name of class Play
def test_Play_get_name():
    ansible_play_0 = Play()

    ansible_play_0.name = None
    ansible_play_0.hosts = "hosts"

    assert ansible_play_0.get_name() == "hosts"

# Generated at 2022-06-25 05:31:55.447927
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    name = play_1.get_name()
    assert name == play_1.name


# Generated at 2022-06-25 05:31:57.298898
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Setup
    play_1 = Play()
    # Exercise
    x = play_1.serialize()
    # Verify
    assert(x == "")
    # Cleanup - none necessary


# Generated at 2022-06-25 05:32:09.002108
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.vars = {}
    play_0.vars_prompt = []
    play_0.hosts = "all"
    play_0.name = "Test Play"
    play_0.connection = "smart"
    play_0.port = 22
    play_0.gather_facts = True
    play_0.roles = []
    play_0.vars_files = []
    play_0.tags = set()
    play_0.deprecate_tags = set()
    play_0.handlers = [
        {
            "name": "restart apache",
            "action": {
                "module": "service",
                "name": "apache2",
                "state": "restarted"
            }
        }
    ]
   

# Generated at 2022-06-25 05:32:20.818999
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # play_1 has only pre_tasks, tasks and post_tasks, so no roles and handlers
    # expected result: empty list
    play_1 = Play()
    result = play_1.compile_roles_handlers()
    assert len(result) == 0, "Play_compile_roles_handlers failed: play_1 should only have pre_tasks, tasks and post_tasks, so expected empty list"

    # play_2 has roles but no handlers
    # expected result: empty list
    filename = 'test-case-2.yaml'
    play_2 = Play.load(get_fixture_path(filename), variable_manager=VariableManager(), loader=DataLoader())
    result = play_2.compile_roles_handlers()

# Generated at 2022-06-25 05:32:30.839169
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    assert_equal(play_1.get_tasks(), [])
    play_2 = Play()
    assert_equal(play_2.get_tasks(), [])
    play_3 = Play()
    assert_equal(play_3.get_tasks(), [])
    play_4 = Play()
    assert_equal(play_4.get_tasks(), [])
    play_5 = Play()
    assert_equal(play_5.get_tasks(), [])
    play_6 = Play()
    assert_equal(play_6.get_tasks(), [])
    play_7 = Play()
    assert_equal(play_7.get_tasks(), [])
    play_8 = Play()
    assert_equal(play_8.get_tasks(), [])

# Generated at 2022-06-25 05:32:47.756923
# Unit test for method serialize of class Play
def test_Play_serialize():
    test_case_0()


# Generated at 2022-06-25 05:32:54.402340
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play.load(dict(name = 'does not matter',
                            hosts = 'abc',
                            tasks = [
                                dict(action = 'run command'),
                                dict(action = 'reboot')
                            ]))
    assert len(play_1.get_tasks()) == 2
    assert play_1.get_tasks()[0].action == 'run command'
    assert play_1.get_tasks()[1].action == 'reboot'


# Generated at 2022-06-25 05:32:59.415396
# Unit test for method get_name of class Play
def test_Play_get_name():

    play_0 = Play()
    play_0_hosts_0 = 'M[=v`Y#}Gcw4?abZ@x{-JF8E.W!@F<=g9Ih>Et8'
    play_0.hosts = play_0_hosts_0
    play_0_name_0 = play_0.get_name()

    assert (play_0_name_0 == play_0_hosts_0)


# Generated at 2022-06-25 05:33:00.974748
# Unit test for method serialize of class Play
def test_Play_serialize():
    test_case_0()


# Generated at 2022-06-25 05:33:10.061321
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """
    Test if the returned value is the right list of handlers
    """
    play_0 = Play()
    handler_0 = Handler()
    handler_1 = Handler()
    handler_2 = Handler()
    play_0.handlers.append(handler_0)
    play_0.handlers.append(handler_1)
    play_0.handlers.append(handler_2)
    role_0 = Role()
    role_0.handlers.append(handler_0)
    role_0.handlers.append(handler_1)
    role_0.handlers.append(handler_2)
    play_0.roles.append(role_0)
    assert play_0.compile_roles_handlers() == (handler_0, handler_1, handler_2)
    

# Generated at 2022-06-25 05:33:12.585407
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play_1 = Play(name = "test_play_1")
    assert(play.get_name() == '')
    assert(play_1.get_name() == "test_play_1")

# Generated at 2022-06-25 05:33:13.956126
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.get_name() == ''

# Generated at 2022-06-25 05:33:22.548138
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.pre_tasks = [Task()]
    play_1.tasks = [Task()]
    play_1.post_tasks = [Task()]
    assert isinstance(play_1.get_tasks(), list)
    assert len(play_1.get_tasks()) == 4
    assert isinstance(play_1.get_tasks()[0], Task)
    assert isinstance(play_1.get_tasks()[1], Task)
    assert isinstance(play_1.get_tasks()[2], Task)
    assert isinstance(play_1.get_tasks()[3], Task)


# Generated at 2022-06-25 05:33:29.068995
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.vars = VariableManager()

    # empty roles
    assert play_0.compile_roles_handlers() == []

    # empty blocks
    play_0.roles = [Role()]
    assert play_0.compile_roles_handlers() == []

    # nested blocks
    play_0.roles = [Role({'handlers': [Block({'block': [
        Handler(), Task()]})]})]

    assert len(play_0.compile_roles_handlers()) == 1
    assert isinstance(play_0.compile_roles_handlers()[0], Handler)

    # more nested blocks

# Generated at 2022-06-25 05:33:37.828601
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0.name = ''
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play_0.hosts = 'localhost'
    play

# Generated at 2022-06-25 05:34:03.336987
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create and populate a bunch of Blocks
    block_10 = Block()
    block_10.block = [task_10, task_20, task_30]
    block_10.rescue = [task_40, task_50, task_60]
    block_10.always = [task_70, task_80, task_90]
    block_10._include_rescue = False
    block_10._include_always = False
    block_20 = Block()
    block_20.block = [task_100, task_200, task_300]
    block_20.rescue = [task_400, task_500, task_600]
    block_20.always = [task_700, task_800, task_900]
    block_20._include_rescue = False
    block_20._include_always = False