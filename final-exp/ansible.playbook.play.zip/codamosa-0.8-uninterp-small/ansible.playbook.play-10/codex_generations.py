

# Generated at 2022-06-25 05:24:22.574947
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds_0 = {}
    play_0.preprocess_data(ds_0)


# Generated at 2022-06-25 05:24:30.203765
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    test_play = Play()
    test_play_data_preprocessed = test_play.preprocess_data({
        'hosts': 'all',
        'become': 'foo',
        'hosts': 'bar',
        'roles': [
            dict(role='test_role'),
        ],
    })
    assert test_play_data_preprocessed['hosts'] == 'bar'
    assert test_play_data_preprocessed['become'] == 'foo'
    assert test_play_data_preprocessed['roles'][0]['role'] == 'test_role'



# Generated at 2022-06-25 05:24:33.060535
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test class instantiation
    play_0 = Play()
    # Test get_vars_files method
    play_0.get_vars_files()


# Generated at 2022-06-25 05:24:37.296057
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    global test_case_0
    play_0 = test_case_0()
    assert play_0.compile_roles_handlers() is None

if __name__ == "__main__":
    test_Play_compile_roles_handlers()

# Generated at 2022-06-25 05:24:38.325391
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_case_0()


# Generated at 2022-06-25 05:24:48.136499
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    cwd = os.getcwd()

# Generated at 2022-06-25 05:24:59.277867
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()

# Generated at 2022-06-25 05:25:06.657133
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test 0
    play_0 = Play()
    assert play_0.get_name() == ""

    # Test 1
    play_1 = Play()
    play_1.name = "abc"
    assert play_1.get_name() == "abc"

    # Test 2
    play_2 = Play()
    play_2.hosts = "abc"
    assert play_2.get_name() == "abc"

    # Test 3
    play_3 = Play()
    play_3.hosts = "abc"
    play_3.name = "def"
    assert play_3.get_name() == "def"

    # Test 4
    play_4 = Play()
    play_4.hosts = []
    assert play_4.get_name() == ""

    # Test 5
    play

# Generated at 2022-06-25 05:25:11.889213
# Unit test for method load of class Play
def test_Play_load():
    import sys, os
    my_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
    my_file= os.path.join(my_dir, "test_data/test_data_1.yaml")
    with open(my_file, "r") as stream:
        my_yml_data = yaml.load(stream)
    p = Play.load(my_yml_data)
    assert p.name == 'Install and run Apache'
    assert p.remote_user == 'root'
    assert isinstance(p.roles, list)
    assert isinstance(p.tasks, list)
    assert isinstance(p.handlers, list)
    assert isinstance(p.pre_tasks, list)

# Generated at 2022-06-25 05:25:18.848268
# Unit test for method load of class Play
def test_Play_load():
    play_0 = Play()
    ds = dict()
    variable_manager = VariableManager()
    loader = DataLoader()
    vars = dict()
    hasattr(Play, 'load')
    play_1 = play_0.load(
        data=ds, variable_manager=variable_manager, loader=loader, vars=vars)
    assert play_1


# Generated at 2022-06-25 05:25:29.614469
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    print("Test Play deserialize")
    play_0 = Play()
    play_0.deserialize(dict())



# Generated at 2022-06-25 05:25:33.582441
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_6 = Play()
    play_6.deserialize({})


# Generated at 2022-06-25 05:25:45.347566
# Unit test for method get_name of class Play
def test_Play_get_name():

    # Case 0: Empty Play
    play_0 = Play()
    assert play_0.get_name() == ''

    # Case 1: Play with hosts
    play_ds_1 = dict(
        name='Test Play',
        hosts='all',
        gather_facts='yes'
    )
    play_1 = Play.load(play_ds_1, variable_manager=None, loader=None)
    assert play_1.get_name() == 'all'

    # Case 2: Play with host list
    play_ds_2 = dict(
        name='Test Play',
        hosts=['a','b','c','d','e','f','g','h','i'],
        gather_facts='yes'
    )

# Generated at 2022-06-25 05:25:48.788268
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()

    get_vars_files_mock = MagicMock(return_value = [play_0.vars_files])
    play_0.get_vars_files = get_vars_files_mock
    assert play_0.get_vars_files() == play_0.vars_files
    get_vars_files_mock.assert_called_once_with()


# Generated at 2022-06-25 05:25:53.684103
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()

# Generated at 2022-06-25 05:25:56.607195
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    # Execute the deserialize method
    play_0.deserialize(data="test")



# Generated at 2022-06-25 05:26:02.424693
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    assert play_0.get_tasks() == []
    print('Test successful. get_tasks function returns expected output')


# Generated at 2022-06-25 05:26:05.655982
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_0 = Play()
    ds = dict(playbook=play_0, loader=None)
    assert 'playbook' in ds, "playbook not found in ds"
    assert 'loader' not in ds, "loader found in ds"
    try:
        play_0.preprocess_data(ds)
    except:
        assert False, "'loader' of type NoneType not allowed in ds"



# Generated at 2022-06-25 05:26:11.441057
# Unit test for method serialize of class Play
def test_Play_serialize():
    # Assert that serialize() produces a dict
    play_0 = Play()
    result_0 = play_0.serialize()
    assert isinstance(result_0, dict)
    # Assert that serialize() produces the correct values
    # source dict: 1
    play_1 = Play()

# Generated at 2022-06-25 05:26:12.243922
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_case_0()


# Generated at 2022-06-25 05:26:24.593095
# Unit test for method serialize of class Play
def test_Play_serialize():
        play_serialize = Play()
        # play.serialize() returns data, a dict containing all needed information of the play
        data = play_serialize.serialize()
        # deserialize the dict to a new play
        play_deserialize = Play()
        play_deserialize.deserialize(data)

        # check if the two plays are the same
        play_serialize_obj = play_serialize.__dict__
        play_deserialize_obj = play_deserialize.__dict__
        assert (play_serialize_obj == play_deserialize_obj)


# Generated at 2022-06-25 05:26:26.765121
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # TODO: implement test and update expected results
    play_0 = Play()
    results = play_0.compile_roles_handlers()
    assert(results == [])


# Generated at 2022-06-25 05:26:30.671106
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    block_list_0 = play_0.compile_roles_handlers()
    assert(isinstance(block_list_0, list))


# Generated at 2022-06-25 05:26:39.014901
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    Test the get_tasks method of the Play class
    '''
    import sys
    import inspect
    import ansible.playbook.play

    play = Play()
    play.tasks = [
        {'action': {'__ansible_actions': 'ping'}},
        {'action': {'__ansible_actions': 'debug'}},
    ]

    play.pre_tasks = [
        {'action': {'__ansible_actions': 'ping'}},
    ]

    play.post_tasks = [
        {'action': {'__ansible_actions': 'ping'}},
    ]


# Generated at 2022-06-25 05:26:46.035179
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    if not play_1.get_name() == '':
        raise AssertionError("Test was unsuccessful: test_Play_get_name()")

    play_1.name = "test"
    if not play_1.get_name() == "test":
        raise AssertionError("Test was unsuccessful: test_Play_get_name()")

    play_2 = Play()
    play_2.hosts = "test"
    if not play_2.get_name() == "test":
        raise AssertionError("Test was unsuccessful: test_Play_get_name()")

    play_3 = Play()
    play_3.hosts = ["test1", "test2"]
    if not play_3.get_name() == "test1,test2":
        raise Assertion

# Generated at 2022-06-25 05:26:50.289840
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.tasks = [Task(), Task()]
    play_0.pre_tasks = [Task(), Task()]
    play_0.post_tasks = [Task(), Task()]
    play_0.get_tasks()

# Generated at 2022-06-25 05:26:54.883758
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {'any_errors_fatal': True, 'become': False, 'become_method': '', 'become_user': '', 'connection': '', 'delegate_to': '', 'delegate_facts': True,
     'gather_facts': True, 'hosts': 'all', 'ignore_errors': False, 'name': '', 'no_log': False, 'poll': 0, 'port': '', 'post_tasks': [],
      'pre_tasks': [], 'roles': ['role2', 'role1', 'role0'], 'serial': 10, 'tasks': []}
    play = Play()
    play.deserialize(data)
    assert (play._any_errors_fatal == True)
    assert (play._become == False)

# Generated at 2022-06-25 05:27:00.414282
# Unit test for method deserialize of class Play

# Generated at 2022-06-25 05:27:09.375073
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # This test case will test the correct path
    play_0 = Play()

    data_0 = {}
    data_0['vars'] = {'key_0': 'value_0'}
    data_0['name'] = 'value_1'
    data_0['remote_user'] = 'value_2'
    data_0['gather_facts'] = 'value_3'
    data_0['sudo'] = 'value_4'
    data_0['sudo_user'] = 'value_5'
    data_0['delegate_to'] = 'value_6'
    data_0['tags'] = 'value_7'
    data_0['run_once'] = 'value_8'
    data_0['hosts'] = 'value_9'

# Generated at 2022-06-25 05:27:11.439135
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_1 = Play()
    ds = {}
    result = play_1.preprocess_data(ds)
    assert(ds == result)


# Generated at 2022-06-25 05:27:19.007373
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    assert play_1.get_tasks() == [], "This assertion is expected to fail"



# Generated at 2022-06-25 05:27:25.981422
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import copy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_manager = MagicMock()
    inventory = MagicMock()
    inventory.hosts = set()
    inventory.filter_hosts = MagicMock(return_value=set())


# Generated at 2022-06-25 05:27:31.683682
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    actual = play.preprocess_data({
    'name': 'Play',
    'user': 'ansible-user',
    'gather_facts': False,
    'hosts': 'all',
    'tasks': [{
        'name': 'Ping',
        'action': 'ping'
    }]
    })
    expected = {
    'name': 'Play',
    'gather_facts': False,
    'remote_user': 'ansible-user',
    'hosts': 'all',
    'tasks': [{
        'name': 'Ping',
        'action': 'ping'
    }]
    }
    assert actual == expected


# Generated at 2022-06-25 05:27:39.286999
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_data_0 = {
        'remote_user': 'root',
        'name': 'common',
        'user': 'root'
    }
    test_Play = Play()
    test_Play.preprocess_data(play_data_0)
    assert test_Play._ds['remote_user'] == 'root'
    assert 'user' not in test_Play._ds


# Generated at 2022-06-25 05:27:47.268438
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    value_2 = play_1.compile_roles_handlers()
    assert value_2 == []
    play_1.roles.append(Role(name="alexander"))
    value_2 = play_1.compile_roles_handlers()
    assert value_2 == []
    play_1.roles.append(Role(name="juliette"))
    value_2 = play_1.compile_roles_handlers()
    assert value_2 == []
    play_1.roles = []
    value_2 = play_1.compile_roles_handlers()
    assert value_2 == []


# Generated at 2022-06-25 05:27:54.760255
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_obj = Play()
    play_obj.tasks = ['test_code_0', 'test_code_1']
    play_obj.pre_tasks = ['test_code_0', 'test_code_1']
    play_obj.post_tasks = ['test_code_0', 'test_code_1']
    assert play_obj.get_tasks() == ['test_code_0', 'test_code_1', 'test_code_0', 'test_code_1', 'test_code_0', 'test_code_1']


# Generated at 2022-06-25 05:28:00.928299
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    # Testing for exceptions
    play_0.vars_files = 'test_file'
    print(play_0.get_vars_files())
    # Testing for exceptions
    play_0.vars_files = None
    print(play_0.get_vars_files())
    play_0.vars_files = []
    print(play_0.get_vars_files())

if __name__ == '__main__':
    test_case_0()
    test_Play_get_vars_files()

# Generated at 2022-06-25 05:28:02.976244
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-25 05:28:10.452917
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    import sys
    orig_stdout = sys.stdout

    # Redirect stdout
    sys.stdout = StringIO()

    # Create play with 'user' in datastructure
    ds = dict(user='foo', hosts=['localhost'], gather_facts='no')
    play_0 = Play()
    try:
        play_0.preprocess_data(ds)
    except:
        assert 0, 'Unexpected exception!'

    sys.stdout = orig_stdout


# Generated at 2022-06-25 05:28:13.890146
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # setup
    play_0 = Play()

    # expected
    res_play_compile_roles_handlers = []

    # actual
    act_play_compile_roles_handlers = play_0.compile_roles_handlers()

    # assertion
    assert act_play_compile_roles_handlers == res_play_compile_roles_handlers, ''


# Generated at 2022-06-25 05:28:30.183085
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    def mock_block_serialize(self):
        return self

    Block.serialize = mock_block_serialize

    p = Play()

    p._pre_tasks = [
        Block(
            block=[
                Task(),
                Task()
            ],
            rescue=[
                Task(),
                Task()
            ],
            always=[
                Task(),
                Task()
            ]
        )
    ]

    p._post_tasks = [
        Task(),
        Task()
    ]

    p._tasks = [
        Task(),
        Task()
    ]

    tasks = p.get_tasks()

    assert len(tasks) == 10

    for i in range(3):
        assert isinstance(tasks[i], list)
        assert len(tasks[i]) == 2


# Generated at 2022-06-25 05:28:38.921363
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    play_0 = Play()
    play_0.blocks = []
    play_0.roles = []
    play_0.current_block = None
    play_0.name = None
    play_0.hosts = None
    play_0.hosts_pattern = None
    play_0.vars = {}
    play_0.vars_files = []
    play_0.vars_prompt = []
    play_0.vars_files_prompt = []
    play_0.playbook_dir = None
    play_0.tasks = []
    play_0.handlers = []
    play_0.notified_handlers = []
    play_0.tags = []
    play_0.always_run = False
    play_0.default_vars = False
    play_

# Generated at 2022-06-25 05:28:40.925115
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    assert play_0.get_name() == ''



# Generated at 2022-06-25 05:28:43.714529
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = Play()
    play_2 = Play()
    utils.run_test("Play", "get_name", play_1, play_2)
    return 0


# Generated at 2022-06-25 05:28:50.481276
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    # Deserialize data from file
    from ansiblelint.tests.data.rules.rule_726_use_blockinfile_module_instead_of_lineinfile import TestCaseData
    play_1 = Play.load(TestCaseData.play_data, variable_manager=None, loader=None)
    result = play_1.serialize()
    # Serialize data to file
    import json
    with open('data.json', 'w') as outfile:
        json.dump(result, outfile, indent=4, sort_keys=True)

# Generated at 2022-06-25 05:28:52.657120
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_0 = Play()
    play_0.roles = [Role(),Role()]
    print(play_0.serialize())
    print(play_0.__dict__)
    assert(play_0.vars == {})

# Generated at 2022-06-25 05:28:56.188939
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    tasks_0 = p.get_tasks()
    assert tasks_0 == []

# Generated at 2022-06-25 05:28:57.963748
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    assert play_0.get_vars_files() == []


# Generated at 2022-06-25 05:29:05.142316
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.vars = {'Test': 'Variable1'}
    serialized_play = play.serialize()
    if play.vars != serialized_play.get('vars'):
        raise Exception('Serialization of vars FAIL')

    if play.hosts != serialized_play.get('hosts'):
        raise Exception('Serialization of hosts FAIL')

    if play.name != serialized_play.get('name'):
        raise Exception('Serialization of name FAIL')

    if play.connection != serialized_play.get('connection'):
        raise Exception('Serialization of connection FAIL')

    if play.gather_facts != serialized_play.get('gather_facts'):
        raise Exception('Serialization of gather_facts FAIL')


# Generated at 2022-06-25 05:29:09.346575
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    tasks = play_0.get_tasks()
    assert tasks

# Test runner

# Generated at 2022-06-25 05:29:18.842368
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.hosts = "localhost"
    play_0.name = "test_play"
    play_1 = Play()
    play_1.hosts = "test_host"
    play_1.name = "test"
    play_2 = Play()
    play_2.hosts = "test"
    play_2.name = "test_play"


# Generated at 2022-06-25 05:29:24.168675
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    assert play_1.get_tasks() == []

    play_2 = Play(tasks=[Task(name='task_1'), Block(block=[Task(name='task_2')])])
    play_2_tasks = play_2.get_tasks()
    assert len(play_2_tasks) == 3
    assert play_2_tasks[0].name == 'task_1'
    assert play_2_tasks[1].name == 'task_2'
    assert play_2_tasks[2].name == 'task_2'


# Generated at 2022-06-25 05:29:28.616386
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a new Play
    play_1 = Play()
    # Add a new Block to 'pre_tasks' attribute of play_1
    play_1.pre_tasks.append(Block())
    # Add a new Line to 'block' attribute of play_1.pre_tasks[0]
    play_1.pre_tasks[0].block.append(Line())
    # Add a new Block to 'tasks' attribute of play_1
    play_1.tasks.append(Block())
    # Add a new Line to 'block' attribute of play_1.tasks[0]
    play_1.tasks[0].block.append(Line())
    # Add a new Block to 'post_tasks' attribute of play_1
    play_1.post_tasks.append(Block())
    # Add a

# Generated at 2022-06-25 05:29:30.063094
# Unit test for constructor of class Play
def test_Play():
    test_case_0()

# Generated at 2022-06-25 05:29:38.448603
# Unit test for method get_name of class Play
def test_Play_get_name():
    playbook_path = os.path.join(fixture_path, 'ansible_playbook.yml')
    playbook_path = os.path.realpath(playbook_path)
    loader = DataLoader()
    variable_manager = VariableManager()
    pb = Playbook.load(playbook_path, variable_manager=variable_manager, loader=loader)
    play_0 = pb.get_plays()[0]
    play_0_name = play_0.get_name()
    assert play_0_name == 'this is the name'


# Generated at 2022-06-25 05:29:45.830115
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create an instance of class Play
    play = Play()

    # Create empty list
    hosts = []

    # Set name as attribute of Play
    play.name = "Test"

    # Check if value of get_name is same as name
    assert play.get_name() == "Test", "get_name() should return name when name is assigned"

    # Set hosts as attribute of Play
    play.hosts = hosts

    # Check if value of get_name is same as name
    assert play.get_name() == "", "get_name() should return empty string when hosts is empty list"



# Generated at 2022-06-25 05:29:48.466922
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_1 = get_sample_play_1()
    name_1 = play_1.get_name()
    assert name_1 == "This is a test play 1"


# Generated at 2022-06-25 05:29:55.261134
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_1 = Play()
    result_1 = play_1.compile_roles_handlers()
    assert result_1 == []
    play_2 = Play()
    role_2 = Role()
    play_2.roles.append(role_2)
    result_2 = play_2.compile_roles_handlers()
    assert result_2 == []
    play_3 = Play()
    role_3 = Role()
    role_3.handlers = Handler()
    play_3.roles.append(role_3)
    result_3 = play_3.compile_roles_handlers()
    assert result_3 == [role_3.handlers]
    play_4 = Play()
    role_4 = Role()
    role_4.handlers = Handler()
    role_

# Generated at 2022-06-25 05:29:59.224983
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_0 = Play()
    play_0._load_roles(None, None)
    play_0.compile_roles_handlers()


# Generated at 2022-06-25 05:30:10.456175
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_vars_files = Play()
    # vars_files not set
    # play_vars_files.vars_files is None
    ansible_assert(not play_vars_files.get_vars_files(), 'n/a', "test_Play_get_vars_files_0")

    # vars_files is a string
    play_vars_files.vars_files = 'ansible.cfg'
    ansible_assert(play_vars_files.get_vars_files(), ['ansible.cfg'], "test_Play_get_vars_files_1")

    # vars_files is a list
    play_vars_files.vars_files = ['ansible.cfg', 'hosts']

# Generated at 2022-06-25 05:30:24.738114
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_0 = Play()
    assert play_0.deserialize(data = {'version': '2.8'}) == None


# Generated at 2022-06-25 05:30:26.808042
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "my test play"
    assert play.get_name() == "my test play"


# Generated at 2022-06-25 05:30:29.579992
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    for vars_files in [None, [], ['var1', 'var2'], 'var']:
        play = Play()
        play.vars_files = vars_files
        assert play.get_vars_files() == vars_files
    # TODO: Test against the error case when vars_files is not a list or a string
    # TODO: Test case where vars_files is a list of strings


# Generated at 2022-06-25 05:30:32.805890
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Setup test
    play_0 = Play()

    # Invoke method
    result = play_0.compile_roles_handlers()

    # Assert
    assert result is not None
    assert isinstance(result, list)


# Generated at 2022-06-25 05:30:34.924906
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    test_Play_deserialize_0()

# Test for method deserialize of class Play

# Generated at 2022-06-25 05:30:38.188890
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "unitTest0"
    assert play.get_name() == "unitTest0"
    play.name = "unitTest1"
    assert play.get_name() == "unitTest1"


# Generated at 2022-06-25 05:30:39.750682
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    try:
        play_0 = Play()
    except Exception:
        raise Exception


# Generated at 2022-06-25 05:30:47.327662
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    ass = AnsibleModule({"hosts": ["host1", "host2"], "vars": {"var1": "value1", "var2": "value2"}})
    play.AddTask(ass)
    tasks = play.get_tasks()
    assert(len(tasks) == 1)
    assert(isinstance(tasks[0], AnsibleModule))

if __name__ == "__main__":
    test_case_0()
    test_Play_get_tasks()

# Generated at 2022-06-25 05:30:55.616429
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_0 = Play()
    play_0.deserialize({'vars_files': [], 'name': 'name_1'})
    assert play_0.get_vars_files() == []
    play_0.deserialize({'vars_files': 'vars_files_0', 'name': 'name_1'})
    assert play_0.get_vars_files() == ['vars_files_0']
    play_0.deserialize({'vars_files': ['vars_files_0', 'vars_files_1'], 'name': 'name_1'})
    assert play_0.get_vars_files() == ['vars_files_0', 'vars_files_1']


# Generated at 2022-06-25 05:31:06.441733
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_1 = Play()
    play_1.hosts = 'host1'
    play_1.name = 'play1'

    task_1 = Task()
    task_1._role_name = 'role1'
    task_1._role_path = 'path1'
    task_1.action = 'action1'
    task_1.name = 'task1'

    role_1 = Role()
    role_1.name = 'role1'
    role_1._role_path = 'path1'
    role_1._role_name = 'role1'
    role_1.tasks = [task_1]

    play_1.roles = [role_1]

    data = play_1.serialize()

# Generated at 2022-06-25 05:31:30.548952
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class Task:
        def __init__(self, implicit=True):
            self.implicit = implicit
    class Block_1:
        def __init__(self, tasks):
            self.block = tasks
            self.rescue = []
            self.always = []
    class Block_2:
        def __init__(self, tasks):
            self.block = []
            self.rescue = tasks
            self.always = []
    class Block_3:
        def __init__(self, tasks):
            self.block = []
            self.rescue = []
            self.always = tasks
    class Block_4:
        def __init__(self, tasks):
            self.block = tasks
            self.rescue = tasks
            self.always = tasks

# Generated at 2022-06-25 05:31:32.743923
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    print(play)


# Generated at 2022-06-25 05:31:40.345147
# Unit test for method get_name of class Play
def test_Play_get_name():

    play_Collection = Play()
    play_Collection.set_loader(DataLoader())
    play_Collection.set_variable_manager(VariableManager())

    # import a file from the tests/test_collections/collection_examples/example_playbooks/
    name = 'test_playbook_check_mode.yaml'
    play, included_files = play_Collection.load(name)

    assert play.get_name() == 'test_playbook_check_mode'

# Generated at 2022-06-25 05:31:41.964324
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    assert (play_0.get_vars_files()) == ([])


# Generated at 2022-06-25 05:31:50.104695
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    role = Role()
    role2 = Role()
    block = Block()
    handler = Handler()
    handler2 = Handler()
    handler.name = 'h1'
    handler2.name = 'h2'
    block.block = [handler]
    role.handlers = [block]
    role2.handlers = [handler2]
    play.roles = [role, role2]
    assert play.compile_roles_handlers() == [handler, handler2], \
        "Expected handler list of [handler, handler2]"


# Generated at 2022-06-25 05:31:54.180451
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []

test_case_0()

#assert play_0.compile_roles_handlers() == []
#check_for_undefined_attributes(play_0)

# Generated at 2022-06-25 05:32:00.530688
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_1 = Play()
    play_1.pre_tasks = [{'name': 'pre_task'}]
    play_1.tasks = [{'name': 'task'}]
    play_1.post_tasks = [{'name': 'post_task'}]
    play_1.compile()

    assert play_1.get_tasks() == [{'name': 'pre_task'}, {'name': 'flush_handlers'}, {'name': 'task'}, {'name': 'flush_handlers'}, {'name': 'post_task'}, {'name': 'flush_handlers'}]

if __name__ == '__main__':
    test_case_0()
    test_Play_get_tasks()

# Generated at 2022-06-25 05:32:08.414778
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # The Play constructor creates callables
    play_0 = Play()

    # Test case 0
    try:
        result = play_0.compile_roles_handlers()
        print ("Unit test for method compile_roles_handlers of class Play")
        print ("Test case 0: Passed!\n")
        print ("result: %s\n" % result)

    except AssertionError as e:
        print ("AssertionError: %s\n" % e)


# Generated at 2022-06-25 05:32:17.984841
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play_0 = Play()
    test_play_0.ROLE_CACHE = {
        'baz': [
            Role(),
            Role(),
        ],
        'foo': [
            Role(),
        ],
        'bar': [
            Role(),
            Role(),
            Role(),
        ],
    }
    expected = [
        [],
        [],
        [
            Handler(),
            Handler(),
            Handler(),
            Handler(),
            Handler(),
            Handler(),
            Handler(),
            Handler(),
            Handler(),
            Handler(),
        ],
        [
            Handler(),
            Handler(),
            Handler(),
            Handler(),
        ],
        [],
        [
            Handler(),
        ],
    ]

# Generated at 2022-06-25 05:32:23.936938
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_1 = Play()
    assert play_1.get_vars_files() == []

    play_2 = Play()
    play_2._vars_files = 'vars_files'
    assert play_2.get_vars_files() == ['vars_files']

    play_3 = Play()
    play_3._vars_files = ['vars_files0', 'vars_files1']
    assert play_3.get_vars_files() == ['vars_files0', 'vars_files1']


# Generated at 2022-06-25 05:32:47.391040
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Check if a user can call the method get_task on an object of class Play.
    # AnsibleMock() is used to mock the Anisble class.
    # AnsibleMock is used to mock a class method as well in tese case calling
    # the is_playbook_task_include function.
    with mock.patch('ansible.playbook.play.Ansible.is_playbook_task_include', AnsibleMock(return_value=True)):
        # Create an object of class Play.
        play_1 = Play()
        play_1.load_data([{}])
        play_1.vars_prompt = None
        play_1.handlers = [Task()]
        play_1.tasks = [Task()]
        # Test the method get_tasks of the class Play.


# Generated at 2022-06-25 05:32:51.125167
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # A fixture that creates a 'Play' object by calling its constructor
    play_0 = Play()
    # Get the return value of method 'get_tasks'
    ret_val = play_0.get_tasks()
    # Test for equality of type
    assert(type(ret_val) == type([]))
    # Test for equality of value
    assert(ret_val == [])


# Generated at 2022-06-25 05:32:58.383463
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create Play object for test
    play_1 = Play()
    # Create a list of roles and a list of handlers
    role_list = [Role(), Role()]
    handler_list = [Block(), Block()]
    # Create a list of block lists for each handler
    block_list_list = [Handler(), Handler()]
    # Set the block list for each role
    role_list[0].handler_blocks = block_list_list[0]
    role_list[1].handler_blocks = block_list_list[1]
    # Create a list of handlers which is the concatenation of the two block lists
    expected_handlers = block_list_list[0].block + block_list_list[1].block
    # Set the roles to be tested
    play_1.roles = role_list
    # Get handlers

# Generated at 2022-06-25 05:33:07.850465
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # 1. Create a Play object
    a_play = Play()
    # 1.1. Create a role and a role include object
    a_role_name = 'test_role_0'
    a_role_include_name = 'test_role_include_0'
    a_role = Role()
    a_role.name = a_role_name
    a_role_include = RoleInclude()
    a_role_include.name = a_role_include_name
    # 1.2. Create a Handler object
    a_handler_name = 'test_handler_0'
    a_handler = Handler()
    a_handler.name = a_handler_name
    # 1.3. Add the Handler object to the Handler list
    a_role.handlers = [a_handler]

# Generated at 2022-06-25 05:33:10.372378
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_0 = Play()
    play_0.vars = dict()
    play_0.vars["init_vars"] = ""
    play_0.get_tasks()


# Generated at 2022-06-25 05:33:19.393753
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "namefield value"
    assert play_0.get_name() == "namefield value"
    play_1 = Play()
    play_1.name = "namefield value"
    assert play_1.get_name() == "namefield value"
    play_2 = Play()
    play_2.name = "namefield value"
    assert play_2.get_name() == "namefield value"
    play_3 = Play()
    play_3.name = "namefield value"
    assert play_3.get_name() == "namefield value"
    play_4 = Play()
    play_4.name = "namefield value"
    assert play_4.get_name() == "namefield value"
    play_5 = Play()
   

# Generated at 2022-06-25 05:33:22.849848
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    Unit test for method get_tasks of class Play
    '''
    play_0 = Play()

    assert isinstance(play_0, Play)
    assert isinstance(play_0.get_tasks(), list)



# Generated at 2022-06-25 05:33:25.380902
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader

    p = Play.load(dict(
        name="test",
        hosts=["foo"],
        gather_facts="no"
    ), variable_manager=None, loader=DictDataLoader())

    assert p.get_name() == "test"


# Generated at 2022-06-25 05:33:29.685729
# Unit test for method get_name of class Play
def test_Play_get_name():
    play_0 = Play()
    play_0.name = "test"
    assert("test" == play_0.get_name())


# Generated at 2022-06-25 05:33:37.446865
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print('Test Play get_vars_files()')
    play_0 = Play()
    assert play_0.get_vars_files() == []
    # Check random cases
    for _i in range(0, 16):
        try:
            play_1 = Play()
            play_1.vars_files = dict()
            play_1.get_vars_files()
            assert False
        except AssertionError:
            pass

    play_2 = Play()
    play_2.vars_files = [random.random() for _ in range(3)]
    assert play_2.get_vars_files() == play_2.vars_files


# Generated at 2022-06-25 05:33:57.685136
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_get_tasks = Play()
    play_get_tasks.pre_tasks = []
    play_get_tasks.tasks = []
    play_get_tasks.post_tasks = []


# Generated at 2022-06-25 05:34:04.550444
# Unit test for method compile_roles_handlers of class Play