

# Generated at 2022-06-11 10:18:27.825119
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data={'roles': 'self._included_conditional', '_included_path': 'self._included_path'}
    assert False


# Generated at 2022-06-11 10:18:33.836173
# Unit test for method serialize of class Play
def test_Play_serialize():
    host_list = ['192.168.1.1','192.168.1.2']
    host_list_str = ','.join(host_list)
    #正常操作
    play = Play()
    play.load({
        'name': 'test',
        'hosts': host_list,
        'connection': 'local',
        'gather_facts': 'no',
        'roles': ['test_role']
    })
    #正常操作
    data = play.serialize()
    assert(data['name'] == 'test')
    assert(data['hosts'] == host_list)
    assert(data['connection'] == 'local')
    assert(data['gather_facts'] == 'no')

# Generated at 2022-06-11 10:18:34.531552
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:18:40.600343
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name == ''
    assert len(p.tags) == 0
    assert len(p.roles) == 0
    assert len(p.get_tasks()) == 0
    assert len(p.handlers) == 0
    assert not p._included_conditional
    assert p._included_path == None



# Generated at 2022-06-11 10:18:50.716500
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = dict(
        name="test_play",
        hosts="test_hosts",
        tasks=[
            dict(action="test_action"),
            dict(block=dict(
                tasks=[
                    dict(action="test_action"),
                    dict(action="test_action")],
                rescue=[
                    dict(action="test_action"),
                    dict(action="test_action")],
                always=[
                    dict(action="test_action"),
                    dict(action="test_action")]
            ))
        ]
    )

    play = Play.load(data=data)
    tasks = play.get_tasks()
    assert(len(tasks) == 6)


# Generated at 2022-06-11 10:18:51.369492
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:18:54.644863
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.playbook.play import Play
    vars_files = []
    assert Play.get_vars_files(vars_files) == []


# Generated at 2022-06-11 10:18:57.677833
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    print("---------------test_Play_preprocess_data-------------")
    play = Play()
    play.preprocess_data("Test")

# Generated at 2022-06-11 10:19:10.426668
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Here we test this method by calling it with a set of basic parameters, and checking the returned value.

    # Instantiate some objects
    task_ds = {'debug': 'msg={{playbook_dir}}'}
    task_handler_ds = [{'tasks': [task_ds]}]
    task_role_ds = {'name': 'role1', 'handlers': task_handler_ds}
    task_play_ds = {'name': 'play1', 'roles': [task_role_ds]}
    task_variable_manager = VariableManager()
    task_loader = DataLoader()
    task_play = Play.load(task_play_ds, variable_manager=task_variable_manager, loader=task_loader)
    task_output = task_play.compile_roles_handlers()

    # Now

# Generated at 2022-06-11 10:19:20.138499
# Unit test for constructor of class Play
def test_Play():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='shell', args='ls'))]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    serialized_data = play.serialize()
    play = Play()
    play.deserialize(serialized_data)
    assert play.name == "Ansible Play"

# Generated at 2022-06-11 10:19:31.261428
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
	# setup
	p = Play()
	p.roles = []
	assert p.compile_roles_handlers() == []
	# teardown
	del p


# Generated at 2022-06-11 10:19:42.306558
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play is not None
    assert play._ds is None
    assert play.name is None
    assert play.hosts is None
    assert play.remote_user is None
    assert play.connection is None
    assert play.port is None
    assert play.gather_facts is None
    assert play.vars == dict()
    assert play.vars_files is None
    assert play.vars_prompt is None
    assert play.vars_files_prompt is None
    assert play.vars_files_complex is False
    assert play.tags == list()
    assert play.filters is None
    assert play.run_once is False
    assert play.roles == list()
    assert play.handlers == list()
    assert play.tasks == list()
    assert play.pre_

# Generated at 2022-06-11 10:19:43.432732
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass


# Generated at 2022-06-11 10:19:50.109655
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a new play, and set basic play attributes.
    test_object = Play()
    test_object.ROLE_CACHE = {
        'test_role': {
            'handlers/main': ['test handler'],
            'meta/main': ['test handler']
        }
    }
    test_object.roles = ['test_role']
    # Create expected result for unit test
    expected_result = ['test handler', 'test handler']
    # call method from test object
    real_result = test_object.compile_roles_handlers()
    # Check that the result is as expected
    assert real_result == expected_result

# Generated at 2022-06-11 10:19:50.747064
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:19:53.031461
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert Play().get_name() == ''
    assert Play().get_name() == ''
    assert Play().get_name() == ''



# Generated at 2022-06-11 10:19:58.279568
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'name': 'test'})
    play.deserialize({'hosts': ['test']})
    play.deserialize({'hosts': ['test'], 'name': 'test'})
    play.deserialize({'hosts': ['test'], 'name': 'test', 'roles': []})

# Generated at 2022-06-11 10:20:10.374125
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    """
    This method is used to test preprocess_data() of class Play.

    This test case ensures that if user key is present, remote_user is set to 
    user values and user is deleted from the data structure to rename user to 
    remote_user.

    Return:
      test_pass: True if test case passed, False otherwise
    """
    ds = dict(
        user='root',
        remote_user='root',
        ansible_user='root',
        become='yes',
        become_user='root',
        become_method='sudo',
        become_flags='-H',
    )

    p = Play()
    p.preprocess_data(ds)

    test_pass = True
    if ds.get('user') is not None:
        test_pass = False


# Generated at 2022-06-11 10:20:18.558173
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # data['roles'] = []
    # dump_path = "/tmp/play.txt"
    # data = pickle.load(open(dump_path, "rb"))

    dump_path = "/tmp/play.txt"
    data = pickle.load(open(dump_path, "rb"))

    # data['roles'] = None
    # data['roles'] = []
    # data['roles'] = [{'name': "test_role"}]

    # data['hosts'] = None
    # data['hosts'] = 123
    # data['hosts'] = "test_host"
    # data['hosts'] = ["test_host1", "test_host2"]

    # data['connection'] = None
    # data['connection'] = 1234
    # data['connection'] = "test_connection

# Generated at 2022-06-11 10:20:29.212565
# Unit test for constructor of class Play
def test_Play():
    # Invalid argument to constructor
    try:
        Play(hosts=None)
        raise AssertionError("Invalid argument to constructor of class Play was not identified")
    except AnsibleAssertionError:
        pass

    # Constructor is called without argument
    play = Play()
    assert (play.hosts == C.DEFAULT_HOST_LIST), \
    "Constructor of class Play is called without argument but the default value of argument 'hosts' is not set"

    # Constructor is called with valid argument
    play = Play(hosts="all")
    assert (play.hosts == "all"), \
    "Constructor of class Play is called with valid argument but the value of argument 'hosts' is not set"

# Generated at 2022-06-11 10:20:37.023544
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    assert False

# Generated at 2022-06-11 10:20:48.247680
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    import copy
    import pytest

    from ansiblelint.rules import RulesCollection
    from ansiblelint.runner import Runner
    from ansiblelint.version import __version__

    play = {
        'name': 'testplay',
        'hosts': 'localhost',
        'user': 'usertest',
        'connection': 'local'
    }

    test_rule_collections = [
        RulesCollection.create_from_directory(
            os.path.join('test', 'rules'))]

    ansible_lint_runner = Runner(
        play,
        test_rule_collections,
        {},
        [],
        [],
        [],
        False)

    success, result = ansible_lint_runner.run()
    assert success


# Generated at 2022-06-11 10:20:59.985425
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    Unit test for method preprocess_data of class Play
    '''

    # Execute the task with the test arguments
    proc = Popen([sys.executable, '-m', 'ansible.playbook.play', 'preprocess_data'], stdout=PIPE, stderr=PIPE)
    stdout, stderr = proc.communicate()

    # Ensure no error occurred
    assert(proc.returncode == 0)
    assert(len(stderr) == 0)

    # Check the expected stdout

# Generated at 2022-06-11 10:21:05.150111
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = "file1.yml"
    assert p.get_vars_files() == ["file1.yml"]
    p.vars_files = ["file2.yml"]
    assert p.get_vars_files() == ["file2.yml"]
    p.vars_files = []
    assert p.get_vars_files() == []


# Generated at 2022-06-11 10:21:16.293937
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible import context
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    options = context.CLIARGS
    options = PlaybookCLI.read_cli_data(options, shell=False)
    options.connection = 'local'
    options.become = False
    options.become_method = 'sudo'
    options.become_user = None
    options.become_ask_pass = False
    passwords = {}

# Generated at 2022-06-11 10:21:28.754665
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    testplay = Play.load(
        dict(vars_files=["my.yml", "my_other.yml"]), 
        variable_manager=VariableManager(),
        loader=DataLoader()
    )
    result = testplay.get_vars_files()
    assert type(result) is list, "get_vars_files() should return a list"
    assert len(result) == 2, "get_vars_files() should return a list of length 2"
    assert result[0] == "my.yml", "get_vars_files() should return the expected string"
    assert result[1] == "my_other.yml", "get_vars_files() should return the expected string"


# Generated at 2022-06-11 10:21:36.088343
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    v = ansible.parsing.dataloader.DataLoader()
    pm = ansible.playbook.Playbook()
    pm._loader = v
    variable_manager = ansible.vars.manager.VariableManager()
    PM = ansible.playbook.Play(
        data='{ "hosts": "test", "vars_files": "test.yml" }',
        variable_manager=variable_manager,
        loader=v
    )
    assert PM.get_vars_files() == ['test.yml']
    PM = ansible.playbook.Play(
        data='{ "hosts": "test", "vars_files": ["test.yml", "test2.yml"] }',
        variable_manager=variable_manager,
        loader=v
    )
    assert PM.get

# Generated at 2022-06-11 10:21:46.998977
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    # Initialization
    play_context = PlayContext()
    play = Play()

# Generated at 2022-06-11 10:21:47.640946
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass

# Generated at 2022-06-11 10:21:59.315683
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # AnsiblePlay object
    play = Play()
    # AnsiblePlay, AnsibleRole objects
    r = Role()
    r.name = 'test-role'
    r.role_path = 'some_path'
    play.roles = [r]
    # AnsiblePlay, AnsibleRole, AnsibleTask objects
    task = Handler()
    task.name = 'test-task'
    task.tags = ['tag']
    task.when = 'tag in play_tags'
    task.notify = 'test-role'
    task.meta = {'flush_handlers': True}
    handler_list = [task]
    r._handlers = handler_list
    # Unit test
    assert play.compile_roles_handlers() == handler_list


# Generated at 2022-06-11 10:22:24.787242
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    with pytest.raises(AnsibleInternalError) as excinfo:
        p.get_vars_files()
    assert 'This should not happen' in to_native(excinfo.value)

# Generated at 2022-06-11 10:22:34.822222
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    p = Play()
    p.roles = [
        {
            'name': 'r1',
            'vars': {'x': "{{ y }}"},
            'tasks': [{'name': 't1', 'y': "{{ z }}"}, {'name': 't2'}],
            'handlers': [{'name': 'h1'}, {'name': 'h2'}]
        },
        {
            'name': 'r2',
            'tasks': [{'name': 't3'}, {'name': 't4'}],
            'handlers': [{'name': 'h3'}]
        }
    ]

    t1 = Task()
    t1.name = 't1'
    t1.vars = {'y': "{{ z }}"}


# Generated at 2022-06-11 10:22:45.460046
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    print("*****Test for method compile_roles_handlers of class Play*****")
    #
    #set_module_args(dict(
    #    name='foo',
    #    state='bar'
    #))
    #
    #from ansible.module_utils.basic import AnsibleModule
    ##
    #module = AnsibleModule(
    #    argument_spec=dict(
    #        name=dict(required=True, type='str'),
    #        state=dict(default='present', type='str',
    #                   choices=['present', 'absent', 'latest']),
    #        force=dict(default=False, type='bool'),
    #        provider=dict(required=True, type='dict', options=dict(
    #            name=dict(required=True, type='str'),
    #           

# Generated at 2022-06-11 10:22:54.521321
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    def test_1():
        p = Play()
        p.vars_files = None
        assert p.get_vars_files() == []
    test_1()

    def test_2():
        p = Play()
        p.vars_files = 'abc.yml'
        assert p.get_vars_files() == ['abc.yml']
    test_2()

    def test_3():
        p = Play()
        p.vars_files = ['abc.yml', 'def.yml']
        assert p.get_vars_files() == ['abc.yml', 'def.yml']
    test_3()


# Generated at 2022-06-11 10:23:06.040359
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play1 = Play()
    play1.vars_files = [{'file': 'foo'}, {'file': 'bar'}]
    assert(play1.get_vars_files() == [{'file': 'foo'}, {'file': 'bar'}])

    play2 = Play()
    play2.vars_files = [{'file': 'foo'}]
    assert(play2.get_vars_files() == [{'file': 'foo'}])

    play3 = Play()
    play3.vars_files = [{'file': 'foo'}, 'bar']
    assert(play3.get_vars_files() == [{'file': 'foo'}, 'bar'])

    play4 = Play()
    play4.vars_files = 'foo'

# Generated at 2022-06-11 10:23:06.827013
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass

# Generated at 2022-06-11 10:23:14.340175
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [Role(), Role()]
    assert p.compile_roles_handlers() == []
    p.roles[0].handlers = [Handler()]
    p.roles[1].handlers = [Handler()]
    assert p.compile_roles_handlers() == [Handler(), Handler()]

'''
test_Play_compile_roles_handlers()
'''


# Generated at 2022-06-11 10:23:24.325666
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    data = [
    {"include":"foo"}
    ]
    role = {
        'name': 'foo',
        'tasks': [
            {'include': 'foo', 'block': [{'include': 'bar'}], 'rescue': [{'include': 'no_bar'}]},
        ],
        'handlers': [
            {'include': 'foo', 'block': [{'include': 'bar'}], 'rescue': [{'include': 'no_bar'}]},
        ],
    }
    role2 = {
        'name': 'no_bar',
        'handlers': [
            {'include': 'foo'},
        ],
    }

# Generated at 2022-06-11 10:23:28.411908
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = 'test.yml'
    assert play.get_vars_files() == ['test.yml']
    play.vars_files = None
    assert play.get_vars_files() == []

# Generated at 2022-06-11 10:23:41.500497
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class Play_get_tasks_no_tasks():
        def get_tasks(self):
            return []
    
    class Play_get_tasks_with_tasks():
        def get_tasks(self):
            return [1, 2, 3]
    
    class Play_get_tasks_with_tasks_and_blocks():
        def get_tasks(self):
            return [1, 2, 3, [4, 5, 6]]
    
    class Play_get_tasks_with_tasks_and_blocks_and_nones():
        def get_tasks(self):
            return [1, 2, 3, [4, 5, 6], None, [None, None]]
    

# Generated at 2022-06-11 10:23:55.044602
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Initialize test data
    play = Play()
    play.vars_files = 'vars_files'
    # Execute method under test
    result = play.get_vars_files()
    # Verify expected results
    assert result == ['vars_files']

# Generated at 2022-06-11 10:23:59.100340
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()

    #Testing with None
    assert play.get_vars_files() == []

    #Testing with empty list
    play.vars_files = []
    assert play.get_vars_files() == []

    #Testing with list of values
    play.vars_files = ["./vars.yml", "./vars.yaml"]
    assert play.get_vars_files() == ["./vars.yml", "./vars.yaml"]

    #Testing with single value
    play.vars_files = "./vars.yml"
    assert play.get_vars_files() == ["./vars.yml"]


# Generated at 2022-06-11 10:24:02.639828
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Unit test for method compile_roles_handlers of class Play
    '''
    play = Play()
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-11 10:24:08.940476
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = {'hosts': '127.0.0.1','remote_user': 'root'}
    result = play.preprocess_data(ds)
    assert result is not None
    ds = {'hosts': '127.0.0.1','user': 'root'}
    result = play.preprocess_data(ds)
    assert result is not None


# Generated at 2022-06-11 10:24:19.475748
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create new role-block with role
    role_block1 = RoleBlock()
    role1 = Role()
    role1.name = 'role1'
    role1.from_include = False
    role1.default_vars = dict()
    role1.default_vars['role1_var'] = 'role1_var_value'
    role1.tasks = [{'name': 'role1_task1'}, {'name': 'role1_task2'}, {'name': 'role1_task3'}]

# Generated at 2022-06-11 10:24:20.172364
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    assert True

# Generated at 2022-06-11 10:24:21.545017
# Unit test for method serialize of class Play
def test_Play_serialize():
    Play.test_serialize()

# Generated at 2022-06-11 10:24:32.647714
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    def test_roles_load(self):
        return [
            {
                'name': 'role1',
                'tasks': [
                    {
                        'name': 'task1',
                        'listen': 'handler1'
                    },
                    {
                        'name': 'task2',
                        'listen': 'handler2'
                    }
                ],
                'handlers': {
                    'list': [
                        'handler1',
                        'handler2'
                    ]
                }
            }
        ]
    Play.roles = [MagicMock(spec=Role)]
    Play.roles[0].get_handler_blocks = MagicMock(side_effect=test_roles_load)
    Play.get_roles = MagicMock(return_value=Play.roles)
    Play.get_ro

# Generated at 2022-06-11 10:24:33.323577
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:24:36.560520
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    a = Play()
    a.roles.append({"from_include": False, "include_tasks": []})
    a.roles.append({"from_include": False, "include_tasks": []})

    result = a._compile_roles_handlers
    assert result == [[], []]


# Generated at 2022-06-11 10:24:52.548129
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    assert True

# Generated at 2022-06-11 10:25:01.266306
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible import constants as C

    p = Play()
    data = dict(
        name='test play',
        hosts=['localhost'],
        roles=[[1,2,3],[4,5,6]],
        gather_facts='no',
        pre_tasks=[[7,8,9],[10,11,12]],
        post_tasks=[[13,14,15],[16,17,18]],
        tasks=[[19,20,21],[22,23,24]],
        handlers=[[25,26,27],[28,29,30]],
        vars=[31,32,33],
        remote_user=C.DEFAULT_REMOTE_USER,
        tx_fact_cache=True,
    )
    p.deserialize(data)

# Generated at 2022-06-11 10:25:11.033657
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['vars_files 1']
    assert play.get_vars_files() == ['vars_files 1']
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'vars_files 2'
    assert play.get_vars_files() == ['vars_files 2']
    play.vars_files = ['vars_files 3']
    assert play.get_vars_files() == ['vars_files 3']


# Generated at 2022-06-11 10:25:13.684207
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play._role_handlers = {}
    play.compile_roles_handlers()

# Generated at 2022-06-11 10:25:25.493660
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task

    p = Play(
        name = 'test_play',
        hosts = 'all',
    )
    p.vars = dict()

# Generated at 2022-06-11 10:25:27.257610
# Unit test for method serialize of class Play
def test_Play_serialize():
    '''Unit test for method serialize of class Play'''
    # TODO
    pass

# Generated at 2022-06-11 10:25:38.836059
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    # default functionality
    p = Play.load(dict(vars_files=["./playbooks/vars/main.yml"]))
    assert (p.get_vars_files() == ["./playbooks/vars/main.yml"])

    # vars_files can be list or only one value
    p = Play.load(dict(vars_files="./playbooks/vars/main.yml"))
    assert (p.get_vars_files() == ["./playbooks/vars/main.yml"])

    # vars_files can be None
    p = Play.load(dict())
    assert (p.get_vars_files() == [])


# Generated at 2022-06-11 10:25:49.164177
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.name = 'test_play'
    p.hosts = 'localhost'
    p.tasks = [
        {'action': {'module': 'debug', 'msg': 'step1'}},
        {'action': {'module': 'debug', 'msg': 'step2'}},
    ]
    p.handlers = [
        {'action': {'module': 'debug', 'msg': 'step3'}},
        {'action': {'module': 'debug', 'msg': 'step4'}},
    ]

# Generated at 2022-06-11 10:25:59.119457
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # AnsibleAssertionError: while preprocessing data (None), ds should be a dict but was a <class 'NoneType'>
    try:
        Play().preprocess_data(None)
    except AnsibleAssertionError as e:
        print(e)
    try:
        Play().preprocess_data('data')
    except AnsibleAssertionError as e:
        print(e)

    ds = {'hosts': ['1.1.1.1'], 'user': 'myuser', 'tasks': [{'name': 'ping', 'ping': 'pong'}]}
    p = Play()
    p.preprocess_data(ds)
    print(p.hosts)
    print(p.remote_user)



# Generated at 2022-06-11 10:26:11.367400
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    """
    Test get_vars_files() method of class Play
    """
    _loader, _inventory, _variable_manager = (
        "loader", "inventory", "variable_manager"
    )
    data = {
        "hosts": "test_hosts",
        "name": "test_name",
        "vars": {
            "key1": "value1",
            "key2": "value2"
        },
        "vars_files": [
            "/path/vars_files1",
            "/path/vars_files2"
        ]
    }

    play = Play()
    play._loader = _loader
    play._inventory = _inventory
    play._variable_manager = _variable_manager
    play.vars = data["vars"]

    ret = play.get_vars

# Generated at 2022-06-11 10:26:52.687968
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """
    Test get_tasks method of class Play
    """
    tasks = [
        {"tasks": {"method": "get", "url": "/api/v1/mock/5c5c5de5d5f5"}},
        {"tasks": [{"method": "get", "url": "/api/v1/mock/5c5c5de5d5f5"}]},
        {"tasks": [{"host": "127.0.0.1", "method": "get", "url": "/api/v1/mock/5c5c5de5d5f5"}]},
        [{"host": "127.0.0.1", "method": "get", "url": "/api/v1/mock/5c5c5de5d5f5"}]
    ]

   

# Generated at 2022-06-11 10:27:03.689309
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    assert p.get_tasks() == []
    p.vars_files = []
    assert p.get_vars_files() == []
    assert p.get_roles() == []
    assert p.get_handlers() == []

# Generated at 2022-06-11 10:27:04.675928
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    a=Play()
    

# Generated at 2022-06-11 10:27:12.037585
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    obj = Play()
    obj.vars_files = ['./vars_files_1.yml','vars_files_2.yml']
    assert ['./vars_files_1.yml','vars_files_2.yml'] == obj.get_vars_files()

    obj.vars_files = 'vars_files.yml'
    assert ['vars_files.yml'] == obj.get_vars_files()

    obj.vars_files = None
    assert [] == obj.get_vars_files()

    obj.vars_files = [u'个人借款.csv']
    assert [u'个人借款.csv'] == obj.get_vars_files()


# Generated at 2022-06-11 10:27:21.450356
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p1 = Play()
    assert p1.get_tasks() == []
    p2 = Play()
    p2.tasks = [1]
    assert p2.get_tasks() == [1]
    p3 = Play()
    p3.tasks = [1]
    p3.post_tasks = [2]
    p3.pre_tasks = [3]
    assert p3.get_tasks() == [1, 2, 3]
    p4 = Play()
    p4.tasks = [1]
    p4.post_tasks = [2]
    p4.pre_tasks = [3]
    p4.handlers = [4]
    p4.roles = [5]

# Generated at 2022-06-11 10:27:26.967695
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = 'test.yml'
    assert play.get_vars_files() == ['test.yml']
    play.vars_files = ['test', 'test2']
    assert play.get_vars_files() == ['test', 'test2']



# Generated at 2022-06-11 10:27:36.743196
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    def mock_load(ds, play=None, use_handlers=False, variable_manager=None, loader=None):
        return ds
    # Set up the class to be used in the test
    p = Play()
    p.compile_roles_handlers = Play.compile_roles_handlers.__get__(p)
    p.load_list_of_blocks_with_role_handlers = mock_load
    p.roles = []
    # Now we test it.
    assert p.compile_roles_handlers() == []
    p.roles = [{"get_handler_blocks": lambda: [1, 2, 3]}]
    assert p.compile_roles_handlers() == [1, 2, 3]

# Generated at 2022-06-11 10:27:41.674443
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    with pytest.raises(AnsibleAssertionError) as e:
        play.preprocess_data('ds')
    assert to_native(e.value) == "while preprocessing data (ds), ds should be a dict but was a <class 'str'>"
    play.preprocess_data({'hosts': 'hosts_value'})
    

# Generated at 2022-06-11 10:27:46.682192
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # We build a play with a list of tasks
    # We get the tasks using the get_tasks method
    # We expect to get back the same list of tasks
    play = Play()
    play.tasks = [Task(), Task()]
    tasks = play.get_tasks()
    assert tasks == play.tasks



# Generated at 2022-06-11 10:27:52.752849
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    hosts = 'localhost'
    tasks = [dict(action=dict(module='debug', args=dict(msg='Hello world!')))]
    test_play_1 = Play().load(dict(hosts=hosts, tasks=tasks, name='test_play'))
    assert test_play_1.get_tasks() == [{"action": {"module": "debug", "args": {"msg": "Hello world!"}}}]

