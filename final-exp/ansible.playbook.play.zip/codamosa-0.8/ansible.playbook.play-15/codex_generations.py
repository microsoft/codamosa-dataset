

# Generated at 2022-06-11 10:18:23.813365
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # TODO: implement
    pass


# Generated at 2022-06-11 10:18:29.883297
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import json
    import sys
    import os
    import tempfile

    # Create the temporary file, which will be removed automatically
    test_file, temp_filename = tempfile.mkstemp()
    with open(temp_filename, 'w') as f:
        json.dump(data_from_file, f)

    p = Play.load(data_from_file, variable_manager=DataLoader().set_basedir('/tmp'))
    play_serialized = p.serialize()
    p2 = Play()
    p2.deserialize(play_serialized)
    assert p.serialize() == p2.serialize()
    test_file_2, temp_filename_2 = tempfile.mkstemp()

# Generated at 2022-06-11 10:18:31.244310
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_compile_roles_handlers(Play)


# Generated at 2022-06-11 10:18:44.153382
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-11 10:18:47.591983
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({
        'roles': [
            {
                'name': 'test-role'
            }
        ]
    })
    assert play.roles[0].name == 'test-role'


# Generated at 2022-06-11 10:18:54.250635
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # test with pre_tasks, tasks and post_tasks
    play = Play.load({'name': 'test', 'hosts': 'all', 'gather_facts': 'no',
                      'pre_tasks': [{'name': 'test1', 'shell': 'echo 1'}, {'name': 'test2', 'shell': 'echo 2'}],
                      'tasks': [{'name': 'test3', 'shell': 'echo 3'}, {'name': 'test4', 'shell': 'echo 4'}],
                      'post_tasks': [{'name': 'test1', 'shell': 'echo 5'}, {'name': 'test2', 'shell': 'echo 6'}]})
    got_tasks = play.get_tasks()

# Generated at 2022-06-11 10:19:05.676476
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({
        'roles': [
            {'name': 'other_role', 'defaults': {'_another_var': 'value'}}
        ]
    })
    assert len(p.roles) == 1
    assert p.roles[0].name == 'other_role'
    assert p.roles[0].defaults == {'_another_var': 'value'}

    assert p.vars == {}
    assert p.handlers == []
    assert p.roles == [Role.load({'name': 'other_role', 'defaults': {'_another_var': 'value'}})]
    assert p.tasks == []



# Generated at 2022-06-11 10:19:06.580345
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass # nothing to test

# Generated at 2022-06-11 10:19:09.071441
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({'roles': []})

# Generated at 2022-06-11 10:19:18.120273
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    #pre_tasks = Task({'name': 'play task1'}), Task({'name': 'play task2'})
    #post_tasks = Task({'name': 'play task3'}), Task({'name': 'play task4'})
    #tasks = Task({'name': 'play task5'}), Task({'name': 'play task6'})

    #play = Play({'name': play_name, 'hosts': 'localhost', 'pre_tasks': pre_tasks, 'post_tasks': post_tasks, 'tasks': tasks})
    #print(play.get_tasks())
    assert True


# Generated at 2022-06-11 10:19:31.663251
# Unit test for method get_name of class Play
def test_Play_get_name():
    Play.get_name()

# Generated at 2022-06-11 10:19:37.384393
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = {'hosts': 'localhost', 'user': 'root', 'gather_facts': 'no'}
    play = Play()
    play.preprocess_data(data)
    assert play._ds['hosts'] == 'localhost'
    assert play._ds['gather_facts'] == 'no'
    assert play._ds['remote_user'] == 'root'
    assert 'user' not in play._ds

# Generated at 2022-06-11 10:19:47.845203
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    m = Play()
    data = dict(hosts='127.0.0.1')
    assert m.preprocess_data(data) == {'hosts': '127.0.0.1', 'name': ''}
    data = dict(hosts=['127.0.0.1', '127.0.0.2', '127.0.0.3'])
    assert m.preprocess_data(data) == {'hosts': ['127.0.0.1', '127.0.0.2', '127.0.0.3'], 'name': '127.0.0.1,127.0.0.2,127.0.0.3'}
    data = dict(hosts='127.0.0.1,127.0.0.2,127.0.0.3')

# Generated at 2022-06-11 10:19:57.725124
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    p._ds = {'user': 'root', 'remote_user': 'admin'}

    try:
        p.preprocess_data(p._ds)
    except:
        assert False, '''AnsbleParserError should not be thrown from method preprocess_data of class Play if both 'user' and 'remote_user' are set'''

    # this should never happen, but error out with a helpful message
    # to the user if it does...
    p._ds = {'user': 'root', 'remote_user': 'admin'}
    p.preprocess_data(p._ds)
    assert p._ds == {'remote_user': 'root'}, '''AnsbleParserError is not thrown from method preprocess_data of class Play if both 'user' and 'remote_user' are set'''

# Generated at 2022-06-11 10:20:09.680500
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from collections import Counter

    # Create and configure a Play object
    play = Play()
    play._variable_manager = MockVariableManager()
    play._loader = MockDataLoader()
    play.vars = dict()
    play.vars_files = []
    play.handlers = []

    # Create some Task objects and add them to the Play object
    tasks = [
        Task(action='a', args=dict()),
        Task(action='b', args=dict()),
        Task(action='b', args=dict()),
        Task(action='c', args=dict())
    ]
    play.tasks = tasks

    # Call the method under test
    tasks = play.get_tasks()

    # Compute the expected result

# Generated at 2022-06-11 10:20:17.373001
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # arrange
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    handler = Handler(
        name = "test_handler",
        tasks = [
            {"test": "task"},
        ]
    )
    role = mock.Mock()
    role.get_handler_blocks.return_value = Block.load(
        data={"handlers": [handler]},
        play=None,
        variable_manager=None,
        loader=None
    ).block
    play = Play()
    play.roles[:] = [role]

    # act
    result = play.compile_roles_handlers()

    # assert
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], Handler)
    assert result

# Generated at 2022-06-11 10:20:28.973281
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    
    _data = {
        "name": "test_play",
        "hosts": "all",
        "tasks": [
            {
                "name": "shell",
                "shell": "echo \"hello\""
            }
        ]
    }
    
    _test_set = [
        {"data":_data, "expected": 1 },
        {"data":{}, "expected": 0 },
        {"data":None, "expected": 0 },
    ]

    _variable_manager = VariableManager()
    _loader = DataLoader()
    
    
    for _case in _test_set:
        _play = Play()
        _play.load_data(_case["data"], variable_manager=_variable_manager, loader=_loader)
        _tasklist = _play.get_tasks()
        assert len

# Generated at 2022-06-11 10:20:39.340404
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    import os
    import unittest

    class TestPlay(unittest.TestCase):

        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.inventory = InventoryManager(loader=self.loader, sources=[])

            # Create 1 host + 1 group with that host in it
            self.inventory.add_group('test_group')
            self.inventory.add_host(Host(name='test_host'))
            self.inventory.get_

# Generated at 2022-06-11 10:20:50.985829
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert not play.compile_roles_handlers()
    role1 = Role()
    role1.from_include = False
    role1.task_blocks = []
    role1.handler_blocks = [{'handlers': [{'name': 't1'}, {'name': 't2'}]}]
    play.roles = [role1]
    assert play.compile_roles_handlers() == role1.handler_blocks
    role2 = Role()
    role2.from_include = False
    role2.task_blocks = []
    role2.handler_blocks = [{'handlers': [{'name': 't3'}, {'name': 't4'}]}]
    play.roles.append(role2)
    assert play.compile_ro

# Generated at 2022-06-11 10:20:53.590735
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a test Play
    play = Play()
    play.pre_tasks = ["pre1", "pre2"]
    play.post_tasks = ["post1", "post2"]
    play.tasks = ["task1", "task2"]
    result = play.get_tasks()
    # Assertions
    assert result == ["pre1", "pre2", "task1", "task2", "post1", "post2"]


# Generated at 2022-06-11 10:21:17.079355
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    inventory = InventoryManager(loader=loader, sources="localhost")
    play_context = PlayContext()
    p = Play()
    res = p.preprocess_data({"hosts": 'localhost', "tasks": [{"action": {"module": "ping", "args": ''}}]})
    assert res == {'hosts': 'localhost', 'tasks': [{'action': {'module': 'ping', 'args': ''}}]}

# Generated at 2022-06-11 10:21:28.570927
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    # 1. test_Play
    p.pre_tasks = [1, 2, 3, 4]
    p.tasks = []
    p.post_tasks = [5, 6, 7, 8]
    assert p.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8]

    # 2. test_Block
    p.pre_tasks = [Block(block=[1, 2, 3], rescue=[4, 5], always=[6, 7])]
    p.post_tasks = []
    assert p.get_tasks() == [[1, 2, 3, 4, 5, 6, 7]]

# Generated at 2022-06-11 10:21:30.986731
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    print(play.get_name())


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 10:21:41.019375
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    my_play = Play()
    files1 = ['test', 'test2']
    my_play.vars_files = files1
    assert_equal(my_play.get_vars_files(),files1)
    files2 = ['test3']
    my_play.vars_files = files2
    assert_equal(my_play.get_vars_files(),files2)
    assert_equal(my_play.get_vars_files(),my_play.vars_files)
    files3 = ['test3', 'test4']
    my_play.vars_files = files3
    assert_equal(my_play.get_vars_files(),files3)
    assert_not_equal(my_play.get_vars_files(),files2)

# Generated at 2022-06-11 10:21:53.728123
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    scenario = AnsiblePlay()
    scenario.roles = [AnsibleRole(scenario=scenario, name="test_role1", handlers=[]),
                      AnsibleRole(scenario=scenario, name="test_role2", handlers=[])]

    play = Play()
    play.roles = [AnsibleRole(scenario=scenario, name="test_role1", handlers=[]),
                  AnsibleRole(scenario=scenario, name="test_role2", handlers=[])]

    expected_result = [AnsibleHandler(), AnsibleHandler()]
    result = play.compile_roles_handlers()

    print("\nExpected result:")
    pprint.pprint(expected_result)
    print("\nResult:")
    pprint.pprint(result)

    assert result == expected

# Generated at 2022-06-11 10:22:01.313203
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    hosts = "localhost"
    tasks = [
        {
            'name': 'print var files',
            'debug': 'msg={{play.get_vars_files()}}'
        }
    ]
    vars_files = ['/tmp/foo.yml', '/tmp/bar.yml']
    play_src = dict(
        name="Ansible Play 1",
        hosts=hosts,
        gather_facts='no',
        vars_files=vars_files,
        tasks=tasks
    )
    play = Play().load(
        play_src,
        variable_manager=variable_manager,
        loader=loader
    )
    assert play.get_vars_files() == vars_files

# Generated at 2022-06-11 10:22:06.151373
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2]
    play.tasks = [3,4]
    play.post_tasks = [5,6]

    assert play.get_tasks() == [1,2,3,4,5,6]

# Generated at 2022-06-11 10:22:13.489365
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    myplay = Play()
    myplay.vars_files = None
    assert myplay.get_vars_files() == []
    myplay.vars_files = 'file1.yml'
    assert myplay.get_vars_files() == ['file1.yml']
    myplay.vars_files = ['file2.yml','file3.yml']
    assert myplay.get_vars_files() == ['file2.yml','file3.yml']


# Generated at 2022-06-11 10:22:15.776126
# Unit test for constructor of class Play
def test_Play():
    # test if constructor can be called
    p = Play()


if __name__ == '__main__':
    test_Play()

# Generated at 2022-06-11 10:22:17.530693
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pytest.skip("TODO: Implement test for Play.get_vars_files()")



# Generated at 2022-06-11 10:22:28.308703
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    result = play.compile_roles_handlers()
    assert len(result) == 0


# Generated at 2022-06-11 10:22:32.217870
# Unit test for method get_name of class Play
def test_Play_get_name():
    string1 = "nive"
    assert Play.load(name = string1).get_name() == string1

    list1 = ["nive", "mayar"]
    assert Play.load(hosts = list1).get_name() == "nive,mayar"

# Generated at 2022-06-11 10:22:36.660617
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()

    p.pre_tasks = [1,2]
    p.tasks = [3,4]
    p.post_tasks = [5,6]

    assert p.get_tasks() == [1,2,3,4,5,6]


# Generated at 2022-06-11 10:22:42.242098
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    #set up
    p = Play()
    p.pre_tasks = []
    p.tasks = []
    p.post_tasks = []
    p.handlers = []

    #test
    r = p.get_tasks()
    assert r == [], "get_tasks failed"
    print('test_Play_get_tasks: Success')


# Generated at 2022-06-11 10:22:52.953322
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    register_loader()
    load_collection_vars_files()

    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.action.normal import ActionModule as NormalActionModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule

    import ansible.constants as C
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    C.DEFAULT_DEBUG_MSG = False
   

# Generated at 2022-06-11 10:23:04.480803
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    shell, play = create_play_by_name("basic")
    # This is a test of the deserialization of Roles.
    shell.register_vars(play.get_vars())
    tasks = play.get_tasks()
    assert(len(tasks)) == 5
    for task in tasks:
        if task[0] == "/home/ansible/ansible-pull/roles/role_a/tasks/main.yml:1":
            assert(task[1]) == "echo hello a"
        if task[0] == "/home/ansible/ansible-pull/roles/role_b/tasks/main.yml:1":
            assert(task[1]) == "echo hello b"

# Generated at 2022-06-11 10:23:16.175812
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test scenario:
    # Play.vars_files is None
    # Expect: get_vars_files return []
    play = Play()
    assert play.get_vars_files() == []

    # Test scenario:
    # Play.vars_files is not instance of list
    # Expect: get_vars_files return [Play.vars_files]
    play = Play()
    play.vars_files = "A string"
    assert play.get_vars_files() == [play.vars_files]

    # Test scenario:
    # Play.vars_files is instance of list
    # Expect: get_vars_files return Play.vars_files
    play = Play()
    play.vars_files = ["A string", "Another string"]
    assert play.get_vars_

# Generated at 2022-06-11 10:23:23.423367
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    m = Play()
    m.get_roles = lambda: [1,2]
    m.roles = [
        Mock(),
        Mock()
    ]
    m.roles[0].from_include = False
    m.roles[0].get_handler_blocks = Mock(return_value = [3])
    m.roles[1].from_include = True
    m.roles[1].get_handler_blocks = Mock(return_value = [4,5])

    assert m.compile_roles_handlers() == [3]


# Generated at 2022-06-11 10:23:24.584717
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass



# Generated at 2022-06-11 10:23:32.686599
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = []
    # Create 2 roles
    for i in range(2):
        # Create Role with a name based on counter
        role = Role()
        # Create name of the role based on counter
        name = "foo" + str(i)
        role.name = name
        # Add the role to list
        play.roles.append(role)
    blocks = play.compile_roles_handlers()
    # Assert that we have the same number of role
    assert len(blocks) == len(play.roles)

# Generated at 2022-06-11 10:23:47.447210
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() == ''
    p.name = 'name'
    assert p.get_name() == 'name'
    p.hosts = 'host1,host2,host3'
    assert p.get_name() == 'host1,host2,host3'
    p.hosts = ['host1', 'host2', 'host3']
    assert p.get_name() == 'host1,host2,host3'


# Generated at 2022-06-11 10:23:54.233766
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_play = Play()
    assert test_play.get_vars_files() == []
    test_play.vars_files = None
    assert test_play.get_vars_files() == []
    test_play.vars_files = 1
    assert test_play.get_vars_files() == [1]
    test_play.vars_files = [2]
    assert test_play.get_vars_files() == [2]


# Generated at 2022-06-11 10:23:57.451478
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # test 1: two values
    ds = {'user': 'admin', 'remote_user': 'Ansible'}

    p = Play()
    p.preprocess_data(ds)
    assert ds == {'remote_user': 'Ansible'}

    # test 2: single value
    ds = {'user': 'admin'}

    p = Play()
    p.preprocess_data(ds)
    assert ds == {'remote_user': 'admin'}


# Generated at 2022-06-11 10:24:04.762798
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p._ds = {'hosts': '', 'tasks': [{'meta': 'flush_handlers'}], 'pre_tasks': [{'name': 'Add free space', 'df': '{{ ansible_mounts }}'}]}
    p._load_data()

    assert p.get_tasks() == [[{'name': 'Add free space', 'df': '{{ ansible_mounts }}'}]]


# Generated at 2022-06-11 10:24:15.134024
# Unit test for constructor of class Play
def test_Play():
    play_ds1 = dict(
        name = "test play",
        hosts = "all",
        gather_facts = "no",
        roles = ["web", "db"],
        remote_user = "root",
        gather_facts = "yes",
        connection = "local",
        tags = ["a", "b", "c"],
        tasks = []
    )
    p = Play()
    p.load(play_ds1, variable_manager=None, loader=None)
    assert dict([(k, v) for (k, v) in iteritems(p._ds) if '_' not in k]) == play_ds1
    vars_prompt = dict(name="hello", prompt="world")
    p.vars_prompt = vars_prompt

# Generated at 2022-06-11 10:24:26.999123
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.module_utils.common.collections import ImmutableDict
    
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.tasks.meta import MetaTask
    
    
    
    
#     p = Play()
#     p.vars = ImmutableDict({"ansible_version": "2.8.0-rc1", "ansible_os_family": "RedHat"})
#     p.variable_manager = VariableManager()
#     p.variable_manager._fact_cache = {"ansible_version": "2.8.0-rc1", "ansible_os_family": "RedHat", "ansible_facts": {"ansible_version": "2.8.0-rc1", "ansible_os_family": "RedHat"}}
#    

# Generated at 2022-06-11 10:24:35.811626
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    tasks = [{'name': 'first task'}, {'name': 'second task'}]
    handler = [{'name': 'first handler', 'listen': 'first task'}]
    p = Play()
    p.load({'tasks': tasks,
            'handlers': handler}, variable_manager=None, loader=None)

    tasklist = p.get_tasks()

    assert len(tasklist) == 3
    assert isinstance(tasklist[0], Task)
    assert isinstance(tasklist[1], Task)
    assert isinstance(tasklist[2], Task)
    assert tasklist[0].name == 'first task'
    assert tasklist[1].name == 'second task'
    assert tasklist[2].name == 'first handler'



# Generated at 2022-06-11 10:24:39.975114
# Unit test for method get_vars_files of class Play

# Generated at 2022-06-11 10:24:44.926229
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    Unit test for method get_tasks of class Play
    '''
    print("Testing method get_tasks of class Play")
    x = Play()
    x.pre_tasks = None
    x.tasks = None
    x.post_tasks = None
    assert x.get_tasks()==[]

# Generated at 2022-06-11 10:24:56.591513
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []

    play.vars_files = "test.yml"
    assert play.get_vars_files() == [play.vars_files]

    play.vars_files = ["test.yml", "test.yaml"]
    assert play.get_vars_files() == play.vars_files

    # test with vars
    play = Play()
    play.vars = {}
    play.vars_files = None
    play.vars["test"] = [1, 2, 3]
    assert play.get_vars_files() == []

    play.vars_files = "test.yml"

# Generated at 2022-06-11 10:25:18.269390
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    def test_func():
        import os
        import sys
        import unittest
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.module_utils.common._collections_compat import MutableMapping
        from ansible.playbook.play_context import PlayContext
        from ansible.playbook.play import Play
        import yaml
        loader = DataLoader()
        variable_manager = VariableManager()
        inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-11 10:25:18.898894
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    assert True

# Generated at 2022-06-11 10:25:28.362571
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.module_utils._text import to_text
    from ansible.parsing.utils.addresses import parse_address
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    import os

    options = namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = options(connection='local', module_path='/path/to/mymodules', forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)


# Generated at 2022-06-11 10:25:32.774062
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  print("Test the method compile_roles_handlers of class Play")
  data = {}
  data['block'] = 1
  data['block'] = 2
  print(data['block'])
  print("End of Tests")

# Generated at 2022-06-11 10:25:45.364763
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test with tasks of type list
    play1 = Play.load(dict(name="test_task_name",
                           hosts="hostname1",
                           tasks=["task1", "task2"]))
    assert play1.get_tasks() == ["task1", "task2"]

    # Test with tasks of type Block
    task_block = Block.load(data=dict(block=["task1", "task2"],
                                      rescue=["task3", "task4"],
                                      always=["task5", "task6"]),
                            play=play1)
    play2 = Play.load(dict(name="test_task_name",
                           hosts="hostname1",
                           tasks=task_block))

# Generated at 2022-06-11 10:25:50.958178
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play_inst = Play()
    assert not play_inst.get_vars_files()
    play_inst.vars_files = 'test-get-vars-file'
    assert play_inst.get_vars_files() == ['test-get-vars-file']
    play_inst.vars_files = ['test-get-vars-file']
    assert play_inst.get_vars_files() == ['test-get-vars-file']



# Generated at 2022-06-11 10:26:01.881302
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.original_basedir = '.'
    # play.vars = {}
    # play.vars_files = []
    # play.roles = []
    # play.handlers = []
    # play.tasks = []
    # play.pre_tasks = []
    # play.post_tasks = []
    # play.any_errors_fatal = None
    # play.force_handlers = None
    # play.name = ''
    # play.connection = ''
    # play.hosts = ''
    # play.max_tries = 0
    # play.gather_facts = ''
    # play.remote_user = ''
    play.become = False
    play.become_user = ''
    play.become_method = ''
    play.verb

# Generated at 2022-06-11 10:26:07.317300
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print("")
    print("Functon: test_Play_get_tasks")
    # Check that the tasks list is correct
    #print("result from get_tasks: %s" % Play._load_tasks())
    print("")
    print(Play._load_tasks)


# Generated at 2022-06-11 10:26:09.825748
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    print(json.dumps(p.get_tasks()))


# Generated at 2022-06-11 10:26:14.180742
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Tests the behaviour of Play.get_name
    #   Args:
    #       None
    #   Returns:
    #       None
    #   Raises:
    #       None

    # Arrange
    play = Play()
    # Act
    expected_result = play.get_name()
    # Assert
    assert expected_result == None


# Generated at 2022-06-11 10:26:44.363856
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    
    # Test 1
    # pre_tasks, tasks, and post_tasks all empty
    play = Play()
    play.pre_tasks = []
    play.tasks = []
    play.post_tasks = []
    assert play.get_tasks() == []

    # Test 2
    # pre_tasks and tasks are Task, post_tasks empty
    play = Play()
    task1 = Task()
    task2 = Task()
    play.pre_tasks = [task1]
    play.tasks = [task2]
    play.post_tasks = []
    assert play.get_tasks() == [task1, task2]

    # Test 3
    # pre_tasks

# Generated at 2022-06-11 10:26:46.639704
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    assert isinstance(play.get_tasks(), list)
#endunit



# Generated at 2022-06-11 10:26:49.051137
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
        # setup
        p = Play()
        value = None

        #test
        value = p.get_tasks()

        #assert
        assert value == None
         

# Generated at 2022-06-11 10:26:56.685951
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """ test get_tasks of class Play"""
    play = Play()
    play.tasks = [ dict(name="test_task_A"), dict(name="test_task_B") ]
    play.pre_tasks = [ dict(name="test_task_C"), dict(name="test_task_D") ]
    with pytest.raises(Error) as excinfo:
        play.get_tasks()
    assert "AnsibleObjectException" in str(excinfo.value)




#
#==============================================================================
#

# Generated at 2022-06-11 10:27:02.622242
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = 'test_vars_files'
    assert play.get_vars_files() == ['test_vars_files']
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = ['test_vars_files']
    assert play.get_vars_files() == ['test_vars_files']

# Generated at 2022-06-11 10:27:03.601011
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    raise NotImplementedError



# Generated at 2022-06-11 10:27:11.003818
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._ds = { 'tasks': [
            {'include_vars': {'name': './vars_to_include.yml'}},
            {'include_vars': {'name': './vars_to_include.yml'}},
            {'include_vars': {'name': './vars_to_include.yml'}}
        ],
        'roles': [
            {'include': '../roles/include1'},
            {'include': '../roles/include2'}
        ]
    }

    if not isinstance(p, Play):
        raise Exception("Class is not Play")

    assert p != None
    assert p._ds != None

# Generated at 2022-06-11 10:27:20.263691
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play.load(dict(vars_files=[]), variable_manager=VariableManager(), loader=DataLoader())
    assert p.get_vars_files() == []
    p = Play.load(dict(vars_files='vars'), variable_manager=VariableManager(), loader=DataLoader())
    assert p.get_vars_files() == ['vars']
    p = Play.load(dict(vars_files='vars'), variable_manager=VariableManager(), loader=DataLoader())
    assert p.get_vars_files() == ['vars']
    p = Play.load(dict(vars_files=['vars1', 'vars2']), variable_manager=VariableManager(), loader=DataLoader())
    assert p.get_vars_files() == ['vars1', 'vars2']

# Generated at 2022-06-11 10:27:28.007687
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """Unit test for method get_tasks of class Play
    
    Arguments:
    - `self`:
    """

    with open('/Users/shiqing/work/github/ansible-playbook/test/test_play_get_tasks.yml', 'r') as f:

        play = Play.load(f.read(), variable_manager=VariableManager(), loader=DataLoader())

        print(play.get_tasks())
        # print(play.get_tasks()[0])
        # print(play.get_tasks()[0].implicit)

# test_Play_get_tasks()


# Generated at 2022-06-11 10:27:37.747365
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # test standard play with no roles imported
    roles = []
    play = Play()
    play.roles = roles
    result = play.compile_roles_handlers()
    assert not result, "Play role compiler failed to return an empty list for no roles"
    # test roles with no handlers
    roles = [(Role()), (Role())]
    play = Play()
    play.roles = roles
    result = play.compile_roles_handlers()
    assert not result, "Play role compiler failed to return an empty list for roles with no handlers"
    # test roles with handlers
    handlers = [Handler(), Handler()]
    roles = [(Role()), (Role(handlers=handlers))]
    play = Play()
    play.roles = roles
    result = play.compile_roles_handlers()
