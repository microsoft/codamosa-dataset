

# Generated at 2022-06-11 10:18:43.673813
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = ['role']
    assert play.compile_roles_handlers() == []

# Generated at 2022-06-11 10:18:46.098505
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play();
    assert play.compile_roles_handlers() == None


# Generated at 2022-06-11 10:18:53.442581
# Unit test for method deserialize of class Play
def test_Play_deserialize(): 
    play = Play() 

# Generated at 2022-06-11 10:19:04.697897
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    assert play.serialize() == dict(
        name=None,
        hosts=None,
        remote_user=C.DEFAULT_REMOTE_USER,
        become=False,
        become_method=None,
        become_user=None,
        check_mode=False,
        gather_facts='smart',
        tags=[],
        skip_tags=[],
        vars={},
        vars_files=[],
        roles=[],
        tasks=[],
        handlers=[],
        post_tasks=[],
        pre_tasks=[],
        included_path=None,
        action_groups={},
        group_actions={}
    )

# Generated at 2022-06-11 10:19:16.605440
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    test_data1 = {
        'tasks': ['task1', 'task2'],
        'roles': ['role1', 'role2'],
        'handlers': ['handler1', 'handler2'],
        'vars': {
            'var1': 'value1',
            'var2': 'value2'
        },
        'vars_files': ['file1', 'file2'],
        'hosts': 'hosts',
        'name': 'play_name',
        'user': 'me',
    }


# Generated at 2022-06-11 10:19:22.998375
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansibledocgen.play import Play


# Generated at 2022-06-11 10:19:35.671744
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()

# Generated at 2022-06-11 10:19:36.398425
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:19:44.947942
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data={"hosts":"hosts", "roles": [{"hosts":"hosts","tasks": [{"name":"task1"}, {"name":"task2"}]}]}
    play=Play.load(data, variable_manager=None, loader=None, vars=None)
    tasklist=play.get_tasks()
    assert tasklist[0] == {'name': 'task1'}, 'Unexpected outcome'
    assert tasklist[1] == {'name': 'task2'}, 'Unexpected outcome'
    assert len(tasklist) == 2, 'Unexpected outcome'


# Generated at 2022-06-11 10:19:51.099774
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansiblelint import RulesCollection
    from ansiblelint.runner import Runner
    from ansiblelint.rules.PlayHasName import PlayHasName

    # Create a test playbook that does not use the play keyword
    yml = '---\n' + '- hosts: localhost\n'

    # Create the rules collection and add the rule
    rules = RulesCollection()
    rules.register(PlayHasName())

    # Run it against our test playbook
    runner = Runner(rules, yml, [], [], [])
    runner.run()

    assert len(runner.failed_rules) == 1

# Generated at 2022-06-11 10:20:08.058546
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_files = ['/etc/ansible/group_vars/all.yaml', '/etc/ansible/group_vars/web.yaml']
    p = Play()
    p.vars_files = vars_files
    assert p.get_vars_files() == vars_files

play_instance = Play()

# Generated at 2022-06-11 10:20:16.311767
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    def test_case(description, input, expected):
        assert input == expected, "%s - input: %s - expected: %s" % (description, input, expected)

    play_obj = Play()


# Generated at 2022-06-11 10:20:20.474567
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    Play_instance = Play()
    Play_instance.vars_files = ['/etc/ansible/hosts']
    result = Play_instance.get_vars_files()
    assert result == ['/etc/ansible/hosts']


# Generated at 2022-06-11 10:20:22.308087
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    print("Unit test for method compile_roles_handlers of class Play")


# Generated at 2022-06-11 10:20:33.122223
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    new_play = Play()

# Generated at 2022-06-11 10:20:35.310527
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # test with valid inputs
    assert isinstance(block_list, list)



# Generated at 2022-06-11 10:20:42.393168
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # test empty user
    data = {
        'user': None,
        'hosts': 'localhost'
    }
    play = Play()
    play.preprocess_data(data)
    assert 'remote_user' not in data
    assert data['user'] is None

    # test empty string as user
    data = {
        'user': '',
        'hosts': 'localhost'
    }
    play = Play()
    play.preprocess_data(data)
    assert 'remote_user' not in data
    assert data['user'] == ''



# Generated at 2022-06-11 10:20:54.624475
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    assert 'user' in p.preprocess_data({'user': 'fuga'})
    assert 'user' not in p.preprocess_data({'user': 'fuga'})
    assert 'remote_user' in p.preprocess_data({'user': 'fuga'})

    assert 'user' in p.preprocess_data({'user': 'fuga', 'remote_user': 'hoge'})
    assert 'user' not in p.preprocess_data({'user': 'fuga', 'remote_user': 'hoge'})
    assert 'remote_user' in p.preprocess_data({'user': 'fuga', 'remote_user': 'hoge'})

test_Play_preprocess_data()

# Generated at 2022-06-11 10:20:56.649881
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.compile_roles_handlers()


# Generated at 2022-06-11 10:21:04.977909
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    hosts=["localhost"]
    roles=["nginx"]
    t = Play()
    t._load_included_file()
    t._role_compile(roles)
    t._load_included_file()
    t._compile_roles()
    t._load_included_file()
    t.compile_roles_handlers()
# Testing
if __name__ == '__main__':
    hosts=["localhost"]
    roles=["nginx"]
    test_Play_compile_roles_handlers()
 
# /usr/lib/python3.6/site-packages/ansible/playbook/role/definition.py
# import os
# import os.path
# import json
# import yaml

# from ansible import constants as C
# from ansible.errors import Ans

# Generated at 2022-06-11 10:21:29.202736
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    """
    Test the deserialize method of the class Play.
    """
    context.CLIARGS = ImmutableDict(tags={}, listtags=False, listtasks=False, listhosts=False, syntax=False, connection=None,
                                    module_path=None, forks=5, remote_user=None, private_key_file=None, ssh_common_args=None,
                                    ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None, become=None,
                                    become_method=None, become_user=None, verbosity=False, check=False, diff=False)

# Generated at 2022-06-11 10:21:36.311192
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()

# Generated at 2022-06-11 10:21:37.012542
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:21:37.701440
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-11 10:21:42.873748
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # This test should do nothing if there is no roles
    Play = Play()
    Play.roles = []
    Play.compile_roles_handlers()

    # This test should do nothing if there is no roles
    Play = Play()
    Play.roles = [Role()]
    assert Play.compile_roles_handlers() == []

# Generated at 2022-06-11 10:21:51.274008
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = {'tasks':[{'name': 'test'}, {'name': 'test2'}] }
    play = Play()
    play.load(data, variable_manager=None, loader=None)
    tasks = play.get_tasks()
    assert len(tasks) == 2
    assert tasks[0].name == 'test'
    assert tasks[1].name == 'test2'

from ansible.playbook.helpers import load_list_of_blocks, load_list_of_roles

# Generated at 2022-06-11 10:21:57.990273
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    fake_play = Play()
    fake_play.pre_tasks = [['sleep', '1']]
    fake_play.tasks = [['sleep', '1']]
    fake_play.post_tasks = [['sleep', '1']]
    fake_tasks = [['sleep', '1'], ['sleep', '1'], ['sleep', '1']]
    assert fake_play.get_tasks() == fake_tasks



# Generated at 2022-06-11 10:22:02.288818
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.vars = {
        'hosts': ['host1', 'host2']
    }
    data = p.serialize()
    new_p = Play().deserialize(data)
    assert new_p.vars == p.vars

# Generated at 2022-06-11 10:22:13.779040
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    print("Test Play_compile_roles_handlers")

    hosts = 'all'
    gather_facts = 'no'
    vars_prompt = None
    play_source =  dict(
        name = "Ansible Play",
        hosts = hosts,
        gather_facts = gather_facts,
        vars_prompt = vars_prompt,
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    assert play.hosts == hosts
    assert play.gather_facts == gather_facts
    assert play.vars_prompt == vars_prompt
    print("Test Play_compile_roles_handlers - Test if the the returned value is a list")
    handler_list = play.compile_roles_handlers()
   

# Generated at 2022-06-11 10:22:16.816375
# Unit test for method get_name of class Play
def test_Play_get_name():
    new_play = Play()
    fake_name = "test_name"
    new_play.name = fake_name
    assert new_play.get_name() == fake_name


# Generated at 2022-06-11 10:22:38.388418
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play1 = Play()

    # Define type of the method get_tasks  to be tested
    # play1:Play, return: list
    play1_test = play1.get_tasks()

    # For the following 2 tests no assert is needed
    # "test 1"
    play1_test_1 = play1_test

    # "test 2"
    play1_test_2 = play1_test

    # Define expected output
    # play1:Play, return: list
    play1_expected = []

    # "test 1"
    play1_expected_1 = []

    # "test 2"
    play1_expected_2 = []

    # Compare expected output with actual output for test 1
    assert play1_expected_1 == play1_test_1

    # Compare expected output with actual output for

# Generated at 2022-06-11 10:22:49.201692
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.playbook.base import Play
    from ansible.playbook.play import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = DataLoader()
    p = Play().load(dict(hosts=dict(host1=dict()), name="test play"))

# Generated at 2022-06-11 10:23:00.267222
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    
    class MockRole(object):
        def __init__(self, name):
            self.name = name

    class MockHandler(object):
        def __init__(self, name):
            self.name = name

    class MockPlay(object):
        def __init__(self, name):
            self.name = name

    roles = []
    roles.append(MockRole("rolename1"))
    roles.append(MockRole("rolename2"))

    handlers = []
    handlers.append(MockHandler("handler-name"))

    play = MockPlay("playname")
    setattr(play, "roles", roles)
    setattr(play, "handlers", handlers)

    def get_handler_blocks(self, play):
        if self.name == "rolename1":
            return handlers
        el

# Generated at 2022-06-11 10:23:11.965175
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import ansible.playbook.role.definition as role_definition
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import ansible.playbook.task_include as task_include

    name = "test_name"
    private_data = "test_private_data"

    handler = task.Task()
    handler.name = name
    handler.private_data = private_data

    block_task = block.Block()
    block_task.block = [handler]

    handler_list = [block_task]

    handler_definition = role_definition.HandlerDefinition()
    handler_definition.block = handler_list

    handler_definition_list = [handler_definition]
    role = role_definition.RoleDefinition()
    role.handlers = handler_definition_list

    role_

# Generated at 2022-06-11 10:23:22.389225
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = {}
    data['playbook_dir'] = os.path.dirname(os.path.realpath('__file__'))
    data['host_list'] = C.DEFAULT_HOST_LIST
    data['private_key_file'] = ''
    data['password'] = None
    data['connection'] = 'ssh'
    data['vault_password'] = None
    data['forks'] = C.DEFAULT_FORKS
    data['become'] = False
    data['become_method'] = 'sudo'
    data['become_user'] = 'root'
    data['check'] = False
    data['listhosts'] = True
    data['listtasks'] = True
    data['listtags'] = True
    data['syntax'] = True
    data['module_path'] = None


# Generated at 2022-06-11 10:23:28.264062
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()

    play.name = 'name'
    assert play.get_name() == 'name'

    play.hosts = 'hosts'
    assert play.get_name() == 'hosts'

    play.name = None
    play.hosts = ['host1', 'host2']
    assert play.get_name() == 'host1,host2'



# Generated at 2022-06-11 10:23:31.682002
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # init
    play = Play()
    play.tasks = [1, 2, 3, 4]
    # excute
    assert play.get_tasks() == [1, 2, 3, 4]

# Generated at 2022-06-11 10:23:44.292529
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_object = Play()
    loaded_json = load_fixture('Play_deserialize.json')
    play_object.deserialize(loaded_json)
    assert play_object.name == ''
    assert not hasattr(play_object, 'gather_facts')
    assert play_object.connection == 'smart'
    assert play_object.vars_prompt == []
    assert play_object.vars_files == []
    assert play_object.vars_persist == {"hostvars": "hostvars.yml", "vars": "vars.yml"}
    assert play_object.vars == {'var1': 'value1', 'var2': 'value2'}
    assert play_object.hosts == {}
    assert not play_object.any_errors_fatal

# Generated at 2022-06-11 10:23:51.732707
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    data = dict(
        name='arbitrary',
        hosts='arbitrary',
        become='True',
        become_user='arbitrary',
        gather_facts='True',
        vars_files=[
            '/path/1',
            '/path/2'
        ]
    )
    expected = ['/path/1', '/path/2']
    test_play = Play()
    test_play.load_data(data)
    assert test_play.get_vars_files() == expected

# Generated at 2022-06-11 10:23:56.349908
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    role1 = Role()
    role2 = Role()
    role3 = Role()
    play.roles = [role1, role2, role3]
    play.sort_roles_into_backup_list()
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-11 10:24:15.720109
# Unit test for method get_name of class Play
def test_Play_get_name():
    playbook = Play()
    playbook.name = None

    # Case 1: Playbook has a name set
    test_name = "Test Playbook"
    playbook.name = test_name
    assert playbook.get_name() == test_name

    # Case 2: Playbook does not have a name set but does have a host restriction
    playbook.name = None
    playbook.hosts = "localhost"
    assert playbook.get_name() == "localhost"

    # Case 3: Playbook does not have a name set and does not have a host restriction
    playbook.hosts = None
    assert playbook.get_name() == ""


# Generated at 2022-06-11 10:24:27.788722
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Build a mock role
    role_data = {}
    role_data.update({'name' : 'mock-role', 'handlers' : ['main.yml']})
    role_data.update({'name' : 'mock-role', 'path' : os.path.dirname(__file__)})

    # Build a mock role include
    role_include_data = {}
    role_include_data.update({'role' : 'mock-role'})

    # Build a mock play
    play_data = {}
    play_data.update({'hosts' : '127.0.0.1'})
    play_data.update({'roles' : [RoleInclude.load(role_include_data)]})

    # Create the play
    play = Play.load(play_data)

   

# Generated at 2022-06-11 10:24:35.240564
# Unit test for method get_name of class Play
def test_Play_get_name():
    a = Play()
    assert a.get_name() == "", "Expected empty string"
    b = Play()
    b.name = "name"
    assert b.get_name() == "name", "Expected 'name'"
    c = Play()
    c.hosts = "localhost"
    assert c.get_name() == "localhost", "Expected 'localhost'"
    d = Play()
    d.hosts = ["localhost", "127.0.0.1"]
    assert d.get_name() == "localhost,127.0.0.1", "Expected 'localhost,127.0.0.1'"


# Generated at 2022-06-11 10:24:38.492232
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """
    Dump of the test data for method compile_roles_handlers of class Play

    ## --- Start data --- ##
    ## --- End data --- ##
    """
    pass

# Generated at 2022-06-11 10:24:49.996972
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    play = Play()
    role1 = RoleDefinition()
    role2 = RoleDefinition()

    play.roles.append(role1)
    play.roles.append(role2)

    t1 = Task()
    t2 = Task()

    block1 = Block()

# Generated at 2022-06-11 10:25:00.056207
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    assert p.get_tasks() == []
    p.tasks = [
        {'action': 'do something'},
        {'action': 'do something else'},
    ]
    assert p.get_tasks() == [{'action': 'do something'}, {'action': 'do something else'}]
    p.pre_tasks = [
        {'action': 'pre do something'},
        {'action': 'pre do something else'},
    ]
    p.post_tasks = [
        {'action': 'post do something'},
        {'action': 'post do something else'},
    ]

# Generated at 2022-06-11 10:25:13.142949
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import os
    import sys
    import json
    import yaml
    import unittest
    import mock


# Generated at 2022-06-11 10:25:23.286043
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Does this work for None values?
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    # Does this work for list values?
    p.vars_files = ['/ansible/test/vars/file.yml']
    assert p.get_vars_files() == ['/ansible/test/vars/file.yml']
    # Does this work for string values?
    p.vars_files = '/ansible/test/vars/file.yml'
    assert p.get_vars_files() == ['/ansible/test/vars/file.yml']

# Generated at 2022-06-11 10:25:30.417199
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play.load(
        dict(
            name='test',
            hosts='hosts',
            roles=[dict(role='role1', tags=['tag1']),
                   dict(role='role3', tags=['tag3'])],
            tasks=[dict(action='action1', tags=['tag1']),
                   dict(action='action3', tags=['tag3'])],
        ),
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader(),
    )
    assert play.get_name() == 'test'

# Generated at 2022-06-11 10:25:31.290912
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert 0 == 1

# Generated at 2022-06-11 10:25:47.840768
# Unit test for method get_name of class Play
def test_Play_get_name():
    with pytest.raises(AnsibleAssertionError):
        Play().get_name()

    play = Play()
    play._variable_manager = MagicMock()
    play._loader = MagicMock()
    play.vars = {}

    play.name = "my_play"
    assert play.get_name() == play.name

    play.name = None
    play.hosts = "all"
    assert play.get_name() == "all"

# Generated at 2022-06-11 10:25:53.280063
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'file1'
    assert p.get_vars_files() == ['file1']
    p.vars_files = ['file1', 'file2']
    print(p.get_vars_files())
    assert p.get_vars_files() == ['file1', 'file2']

# Generated at 2022-06-11 10:25:58.523998
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    runner = CliRunner()
    result = runner.invoke(cli.main)
    assert result.exit_code == 0
    assert '--version' in result.output
    help_result = runner.invoke(cli.main, ['--help'])
    assert help_result.exit_code == 0
    assert 'Show this message and exit.' in help_result.output

# Generated at 2022-06-11 10:26:05.976229
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create instance of play
    play = Play()
    play.roles = [{'role': 'role1'}, {'role': 'role2'}]
    play.roles[0] = Role.load(play.roles[0], play=play)
    play.roles[1] = Role.load(play.roles[1], play=play)
    #Try to compile handlers
    play.compile_roles_handlers()


# Generated at 2022-06-11 10:26:14.775298
# Unit test for method serialize of class Play
def test_Play_serialize():
    print("Unit test for method serialize of class Play")

    try:
        #play = Play.load(data={"name": "test", "hosts": ["localhost"]}, variable_manager=None, loader=None)
        play = Play()
        play.name = "test"
        play.hosts = ["localhost"]
        d = play.serialize()
        print("d: ", d)
        assert d['name'] == 'test'
        assert d['hosts'] == ['localhost']
        assert 'tasks' not in d
        assert 'roles' not in d
    except SystemExit:
        print("Error")
        return

    print("Test pass")


# Generated at 2022-06-11 10:26:15.926872
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    assert play.get_tasks() == []


# Generated at 2022-06-11 10:26:24.428492
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.errors import AnsibleAssertionError
    from ansible.module_utils.six import text_type
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestPlayGetName(unittest.TestCase):
        def test_get_name(self):
            play = Play()
            self.assertEqual(play.get_name(), '')

            play.name = 'test'
            self.assertEqual(play.get_name(), 'test')

            play.name = text_type('test')
            self.assertEqual(play.get_name(), 'test')

            play.name = u'test'
            self.assertEqual(play.get_name(), 'test')


# Generated at 2022-06-11 10:26:32.167189
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    roles = [
        Role(),
        Role(),
        Role(),
    ]

    play = Play()
    play.roles = roles

    handlers = play.compile_roles_handlers()

    assert len(handlers) == 3
    assert id(handlers[0]) == id(roles[0].handlers)
    assert id(handlers[1]) == id(roles[1].handlers)
    assert id(handlers[2]) == id(roles[2].handlers)


# Generated at 2022-06-11 10:26:33.717026
# Unit test for constructor of class Play
def test_Play():
  p=Play()
  p._load_roles(None, None)


# Generated at 2022-06-11 10:26:43.648731
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    def test_1():
        # Testing normal case
        #
        # Empty Play object
        play = Play()
        # set all attributes to some empty list
        play.pre_tasks = []
        play.tasks = []
        play.post_tasks = []
        # set valid default values for all attributes

# Generated at 2022-06-11 10:27:15.756331
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play.load(dict(
        name = "test_play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(
                name = "role1",
                handlers = [
                    dict(
                        name = "Handler one",
                        tags = ["one"],
                        listen = "handler_one",
                    ),
                    dict(
                        name = "Handler two",
                        tags = ["two"],
                        listen = "handler_two",
                    ),
                ]
            ),
            dict(
                name = "role2",
                handlers = []
            ),
        ]))


# Generated at 2022-06-11 10:27:25.454613
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    data = dict()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    inventory.clear_pattern_cache()
    variable_manager.set_inventory(inventory)
    variable_manager.set_run_once(False)
    variable_manager.set_fail_on_missing(False)
    variable_manager.set_automation_evidence(True)

    variable_manager.set_extra_vars({'hostvars': {}})
    variable_manager.set_options({})
    variable_manager.set_options({'_ansible_syslog_facility': 'LOG_USER'})
    variable_manager.set_options({'_ansible_debug': False})

# Generated at 2022-06-11 10:27:31.446218
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pl = {'vars_files':'test_default'}
    p = Play.load(pl)
    assert p.get_vars_files() == ['test_default']
    pl = {'vars_files':['test_default_1', 'test_default_2']}
    p = Play.load(pl)
    assert p.get_vars_files() == ['test_default_1', 'test_default_2']


# Generated at 2022-06-11 10:27:40.790357
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    ds = {}
    ds.update({
        'name': 'test_play',
        'connection': 'test_connection',
        'hosts': ['test_hosts_1'],
        'user': 'test_user',
        'gather_facts': 'test_gather_facts',
        'vars': 'test_gather_facts',
        'vars_files': 'test_vars_files',
        'tags': 'test_tags',
        'roles': [{
            '_parent': 'test_parent',
            '_role_path': 'test_role_path',
            'name': 'test_role_name'
        }]
    })
    p = Play()
    p.deserialize(ds)
    assert ds == p.serialize()


# Generated at 2022-06-11 10:27:42.938489
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = []
    print(p.compile_roles_handlers())


# Generated at 2022-06-11 10:27:53.709115
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import os
    import re
    import itertools
    import pytest

    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play as Play2
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.vars import VariableManager
    from ansible.plugins.loader import action_loader

    # check if the imported modules are available in Ansible 2.9
    if not AnsibleSequence:
        return

# Generated at 2022-06-11 10:28:02.703231
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    Get the variable files of a play
    '''

    # Create an instance Play
    play = Play()
    play.vars_files = ['/path/to/file1', '/path/to/file2']
    assert play.get_vars_files() == ['/path/to/file1', '/path/to/file2']

    # Create an instance Play
    play = Play()
    play.vars_files = '/path/to/file1'
    assert play.get_vars_files() == ['/path/to/file1']

    # Create an instance Play
    play = Play()
    play.vars_files = []
    assert play.get_vars_files() == []


# Generated at 2022-06-11 10:28:10.135024
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print("")
    print("---Unit test---")
    play = Play.load({})
    # Possibility 1: self.vars_files is None
    play.vars_files = None
    exp_result = []
    act_result = play.get_vars_files()
    if act_result == exp_result:
        print("OK: Possibility 1")
    else:
        print("FAIL: Possibility 1")
    # Possibility 2: self.vars_files is list
    play.vars_files = ['test1', 'test2', 'test3']
    exp_result = ['test1', 'test2', 'test3']
    act_result = play.get_vars_files()
    if act_result == exp_result:
        print("OK: Possibility 2")