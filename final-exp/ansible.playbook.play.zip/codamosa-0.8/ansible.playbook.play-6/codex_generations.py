

# Generated at 2022-06-11 10:18:30.969884
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play = play.serialize()
    assert play.get('roles',None) == None
    assert play.get('included_path',None) == None
    assert play.get('action_groups',None) == None
    assert play.get('group_actions',None) == None


# Generated at 2022-06-11 10:18:43.845938
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = []
    role = Role()
    role.tasks = []
    tasks = Block()
    tasks.block = []
    tasks.block.append(Block())
    tasks.block.append(Block())
    tasks.block.append(Block())
    tasks.rescue = [Block()]
    tasks.always = [Block()]
    role.tasks.append(Task())
    role.tasks.append(Task())
    role.tasks.append(tasks)
    role.tasks.append(Block())
    role.handlers = [Handler()]
    role.handlers.append(Block())
    role.handlers.append(Block())
    p.roles.append(role)


# Generated at 2022-06-11 10:18:45.723136
# Unit test for method get_name of class Play
def test_Play_get_name():
    Play.get_name()

# Generated at 2022-06-11 10:18:49.814422
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-11 10:18:56.357133
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'foobar'
    assert p.get_name() == 'foobar'
    p.name = None
    p.hosts = 'localhost'
    assert p.get_name() == 'localhost'
    p.hosts = ['host1', 'host2']
    assert p.get_name() == 'host1,host2'


# Generated at 2022-06-11 10:19:09.196975
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import types
    import json
    import tempfile
    import os.path
    import os
    import itertools

    # Original Code
    # -*- coding: utf-8 -*-
    from __future__ import (absolute_import, division, print_function)
    __metaclass__ = type
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_text
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common._collections_compat import Mapping
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.parsing.convert_bool import boolean
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.six import iter

# Generated at 2022-06-11 10:19:19.450737
# Unit test for constructor of class Play
def test_Play():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_ds = dict(
        vars=dict(
            var1='value1',
            var2=2,
            var3=True,
            var4=[1, 2, 3]
        ),
        hosts='implicit localhost',
        pre_tasks=['hello', 'world'],
        roles=['webservers', 'database']
    )

    loader = DataLoader()
    variable_manager = VariableManager()

    p = Play()
    p.load(data=play_ds, variable_manager=variable_manager, loader=loader)

    # Print the internal representation of the play.
    pprint(dict(p.serialize()))

    # Print the current state of the Play

# Generated at 2022-06-11 10:19:30.489699
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # initialization
    play = Play()
    data = {}
    play.deserialize(data)
    role_data = data.get('roles', [])
    roles = []
    for role in role_data:
        r = Role()
        r.deserialize(role)
        roles.append(r)

    setattr(play, 'roles', roles)
    del data['roles']
    # verification
    assert('roles' in data) == False
    # tear down
    play.ROLE_CACHE.clear()
    del play

# Generated at 2022-06-11 10:19:38.530920
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    # Unit test for method get_tasks of class Play

    # setup test object with mock data
    play = Play()
    # play.roles = mock_roles
    play.post_tasks = mock_task_blocks
    play.tasks = mock_task_blocks
    play.pre_tasks = mock_task_blocks

    # expected result
    expected_result = [task for task in mock_tasks for i in range(3)]

    # perform action on test object
    result = play.get_tasks()

    # verify test result
    assert result == expected_result


# Generated at 2022-06-11 10:19:48.745799
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()
    test_play.ROLE_CACHE = {}
    test_play._included_conditional = None
    test_play._included_path = None
    test_play._removed_hosts = []
    test_play.ROLE_CACHE = {}

    test_play.only_tags = set(context.CLIARGS.get('tags', [])) or frozenset(('all',))
    test_play.skip_tags = set(context.CLIARGS.get('skip_tags', []))

    test_play._action_groups = {}
    test_play._group_actions = {}


    test_play.name = 'foobar'
    test_play.vars = {}
    test_play.roles = []
    test_role = Role()
   

# Generated at 2022-06-11 10:20:01.929852
# Unit test for method serialize of class Play
def test_Play_serialize():
    component = Play()
    test_var = component.serialize()
    # Test loading yaml
    with open("test/unit/parser/data/ansible/play.yml", 'r') as stream:
        data = yaml.load(stream)
    assert test_var == data


# Generated at 2022-06-11 10:20:13.514035
# Unit test for method deserialize of class Play

# Generated at 2022-06-11 10:20:19.454504
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data1 = {'roles':[{'role_name': 'test_role', 'role_path': 'test_role_path'},{'role_name': 'test_role1', 'role_path': 'test_role_path1'},]}
    new_me = Play().deserialize(data1)
    print(new_me.roles[0].role_name)
    print(new_me.roles[1].role_name)


# Generated at 2022-06-11 10:20:23.950865
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = {"tasks":[{"name":"task2","action":{"__ansible_module__":"copy","__ansible_arguments__":["src=/etc/hosts dest=/tmp/hosts"]}}]}
    vars = {}
    p = Play()
    p.preprocess_data(data)
    


# Generated at 2022-06-11 10:20:29.495611
# Unit test for method get_name of class Play
def test_Play_get_name():
    # First prepare for test
    class Play(anx.Play):
        def get_name(self):
            return self.name
    
    # Begin testing
    test_object = Play()
    assert (test_object.get_name()) == ''
    test_object.name = 'test'
    assert (test_object.get_name()) == 'test'

# Generated at 2022-06-11 10:20:39.842183
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    data = dict()
    data['name'] = "test_play"
    data['description'] = "Unit Test Play"
    data['hosts'] = "localhost"
    data['strategy'] = "free"


# Generated at 2022-06-11 10:20:43.385499
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pl = Play()
    pl.vars_files = []
    assert pl.get_vars_files() == []
    pl.vars_files = '/path/to/file'
    assert pl.get_vars_files() == ['/path/to/file']
    pl.vars_files = ['/path/to/file1', '/path/to/file2', '/path/to/file3']
    assert pl.get_vars_files() == ['/path/to/file1', '/path/to/file2', '/path/to/file3']


# Generated at 2022-06-11 10:20:47.248796
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['f1', 'f2']

    assert play.get_vars_files() == ['f1', 'f2']

# Generated at 2022-06-11 10:20:48.350416
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass # no need for test



# Generated at 2022-06-11 10:21:00.027521
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    host = Host('localhost')
    play = Play('SOME_HOST')
    play._variable_manager = VariableManager()
    play._loader = DataLoader()
    play.set_loader(play._loader)
    play._iterator = TaskIterator(play._tqm,play.hosts,play,play.callbacks,play.get_transport_for_host(host),play.ROLE_CACHE,play.play_basedir,play.playbook_basedir,play._iterator_loader_cache,)
    play.set_variable_manager(play._variable_manager)
    play.set_variable_manager(play._variable_manager)
    play.post_validate(templar=None,validate_templated=True)
    result = play.compile_roles_handlers()
    assert_equal

# Generated at 2022-06-11 10:21:20.715697
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert Play.load(dict(
        hosts=['group1', 'group2', 'host1', 'host2'],
        roles=[]
    )).get_name() == 'group1,group2,host1,host2'

    assert Play.load(dict(
        hosts='group1:group2:group3',
        roles=[]
    )).get_name() == 'group1:group2:group3'

    assert Play.load(dict(
        roles=[]
    )).get_name() == ''

    assert Play.load(dict(
        hosts=['group1', 'group2', 'host1', 'host2'],
        gather_facts=False,
        roles=[]
    )).get_name() == 'group1,group2,host1,host2'


# Generated at 2022-06-11 10:21:30.235173
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p1 = Play()
    p1.vars_files = "test_vars_files"
    assert type(p1.get_vars_files()) is list
    assert p1.get_vars_files() == ["test_vars_files"]
    p2 = Play()
    p2.vars_files = ["test_vars_files1", "test_vars_files2"]
    assert type(p2.get_vars_files()) is list
    assert p2.get_vars_files() == ["test_vars_files1", "test_vars_files2"]

# Generated at 2022-06-11 10:21:32.534603
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  play = Play()
  assert play.compile_roles_handlers() == []
  #assert isinstance(play.compile_roles_handlers(), list)


# Generated at 2022-06-11 10:21:42.828791
# Unit test for method preprocess_data of class Play

# Generated at 2022-06-11 10:21:54.957535
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play.load(dict(name="test_play",
                          hosts=["localhost"],
                          remote_user="root",
                          roles=[dict(role="test_role")],
                          tasks=[dict(name="test_task")]),
                     variable_manager=VariableManager(), loader=DictDataLoader())
    assert play.serialize() == dict(name="test_play",
                                    hosts="localhost",
                                    remote_user="root",
                                    roles=[dict(role="test_role")],
                                    tasks=[dict(name="test_task")],
                                    handler_tasks=[],
                                    variables={},
                                    tasks_for_handler=[],
                                    included_path=None)

# ===========================================

# Generated at 2022-06-11 10:21:59.547666
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    parser = PlaybookParser.get()
    loader = DataLoader()
    yaml_obj = PlaybookParser.load_yaml_data(loader.load_from_file('yaml/play.yaml'), '', '', '')
    p.load_data(yaml_obj, parser, loader)
    assert isinstance(p.get_name(), str)



# Generated at 2022-06-11 10:22:08.199681
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Load play object with pre-defined roles
    # get_handler_blocks() and compile_roles_handlers() should return same data
    play = Play()
    play._load_included_file('./test/helpers/roles_definition.yml')

    handlers_from_get = []
    for r in play.roles:
        handlers_from_get.extend(r.get_handler_blocks(play=play))

    handlers_from_compile = play.compile_roles_handlers()

    assert(handlers_from_get == handlers_from_compile)


# Generated at 2022-06-11 10:22:16.188529
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'jkakfa'
    assert play.get_name() == 'jkakfa'
    play.name = None
    play.hosts = 'abc'
    assert play.get_name() == 'abc'
    play.hosts = None
    assert play.get_name() == ''
    play.hosts = []
    assert play.get_name() == ''
    play.hosts = ['abc', 'bcd']
    assert play.get_name() == 'abc,bcd'
# Test for class Play

# Generated at 2022-06-11 10:22:21.034425
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    #init
    ds=[]
    play=Play()
    play._pre_tasks=ds
    play._tasks=ds
    play._post_tasks=ds
    assert play.get_tasks()==[]
    assert play.get_tasks()==ds

# Generated at 2022-06-11 10:22:31.024789
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.playbook.task import Task
    import ansible.utils.unsafe_proxy as unsafe_proxy
    p = Play()
    ds={'foobar': 'baz'}
    result=p.preprocess_data(ds)
    assert (result == {'foobar': 'baz'})
    ds={'user': 'baz'}
    result=p.preprocess_data(ds)
    assert (result == {'remote_user': 'baz'})

    ds={'user': 'baz'}
    ds['user'] = unsafe_proxy.UnsafeText('baz')
    result=p.preprocess_data(ds)
    assert (result == {'remote_user': unsafe_proxy.UnsafeText('baz')})


# Generated at 2022-06-11 10:22:41.516841
# Unit test for method get_name of class Play
def test_Play_get_name():
    host = 'some_value'
    play = Play()
    play.name = name
    assert play.get_name() == name


# Generated at 2022-06-11 10:22:49.010333
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = []
    assert p.compile_roles_handlers() == []
    p.roles = [Role({},
                    {},
                    {'handlers': ['a', 'b']}),
              Role({},
                   {},
                   {'handlers': ['c']})]
    result = [dict(name='a', handlers=['a', 'b']),
              dict(name='c', handlers=['c'])]
    assert p.compile_roles_handlers() == result

# Generated at 2022-06-11 10:22:52.448857
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    role = Role()
    role_list = [role]
    play.roles = role_list
    assert play.compile_roles_handlers() == [], 'TODO'

# Generated at 2022-06-11 10:23:03.780822
# Unit test for constructor of class Play
def test_Play():

    # test without any data
    p = Play()
    assert p.name == ''
    assert not p.hosts
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert not p.roles
    assert not p.tasks
    assert p.max_fail_percentage == C.MAX_FAIL_PERCENTAGE
    assert not p.any_errors_fatal
    assert p.force_handlers == False
    assert p.serial == 1
    assert p.vars_prompt == []
    assert not p.default_vars
    assert not p.extra_vars
    assert not p.vars_files

    # test constructor with data dictionary

# Generated at 2022-06-11 10:23:12.394982
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    try:
        assert isinstance(p.get_tasks(), list)
    except AssertionError:
        print("AssertionError raised while testing get_tasks of class Play")
    p.pre_tasks = [
        {
            'foo': 'bar',
            'bar': 'baz'
        }
    ]
    try:
        assert isinstance(p.get_tasks(), list)
    except AssertionError:
        print("AssertionError raised while testing get_tasks of class Play")


# Generated at 2022-06-11 10:23:18.751004
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play(vars_files='/path/to/file')
    assert p.get_vars_files() == ['/path/to/file']

    p = Play(vars_files=[])
    assert p.get_vars_files() == []

    p = Play(vars_files=['/path/to/file'])
    assert p.get_vars_files() == ['/path/to/file']


# Generated at 2022-06-11 10:23:29.132432
# Unit test for method get_name of class Play
def test_Play_get_name():

    ####################################################################
    # Test for Play.get_name
    ####################################################################
    from ansible.playbook.play import Play
    from ansible import context
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from six import PY3, string_types
    from __builtin__ import isinstance
    from ansible.parsing.dataloader import DataLoader

    if PY3:
        unicode = str

    # Definition of 'invalid_input'
    input_para1 = (False, 'False')
    input_para2 = (False, 'True')
    input_para3 = (2, 3)
    input_para4 = ('localhost', '127.0.0.1')

# Generated at 2022-06-11 10:23:30.278772
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass
 

# Generated at 2022-06-11 10:23:43.189489
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    yaml_text = '''\
        ---
        - hosts: localhost
          gather_facts: no
          tasks:
            - import_tasks: test_handler_include.yml
          handlers:
            - import_tasks: test_handler_include.yml
        '''
    playbook = Playbook.load(
        yaml_text,
        variable_manager=variable_manager,
        loader=loader
    )

    play = Play().load(
        playbook[0],
        variable_manager=variable_manager,
        loader=loader
    )
    play._variable_manager = variable_manager
    play.post_validate([play])

    play

# Generated at 2022-06-11 10:23:54.095287
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    def test(s):
        return s.replace(" ", "TEST")

    ########################################################################################
    ## These tests assume that the test_Play_preprocess_data method is run before running any of the other tests
    ## in this class.  This is done to make sure that the custom test user module is used by the Play class during
    ## these tests rather than the user module in the Ansible modules directory.
    ##
    ## This is important because the Play class uses the modules directory to find modules to run in order
    ## to do preprocessing.  The list of Ansible modules directories is added to sys.path.  So far, this list is
    ## always added at the beginning of sys.path, so it will be used for modules found using the import statement
   

# Generated at 2022-06-11 10:24:13.152771
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-11 10:24:24.402373
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager,host_list=['127.0.0.1']))
    p = Play()
    p.vars = {'hosts': 'localhost', 'remote_user': 'root', 'gather_facts': 'no'}
    p.variable_manager = variable_manager
    data = p.vars.copy()
    p.load_data(data, variable_manager=variable_manager)
    assert p.get_tasks() == []
    data = {'name': 'check kdump status', 'check_kdump': 'kdumpctl status', 'register': 'kdump_status'}
    t = Task()

# Generated at 2022-06-11 10:24:27.316416
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p, 'Play is empty'
    assert p.name == '', 'Play name is not empty'


# Generated at 2022-06-11 10:24:31.679344
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ['/path/to/file1', '/path/to/file2']

    expected = ['/path/to/file1', '/path/to/file2']
    result = p.get_vars_files()
    assert result == expected


# Generated at 2022-06-11 10:24:40.562751
# Unit test for method get_name of class Play
def test_Play_get_name():
    host1 = 'host1'
    host2 = 'host2'
    hosts = [host1, host2]
    # Case 1:Set name
    name = 'play_name'
    play1 = Play()
    play1.name = name
    # Case 1: Expect return name
    assert name == play1.get_name()
    # Case 2: Set hosts
    play2 = Play()
    play2.hosts = hosts
    # Case 2: Expect return hosts
    assert ','.join(hosts) == play2.get_name()
    # Case 3: Set hosts and name
    play3 = Play()
    play3.hosts = hosts
    play3.name = name
    # Case 3: Expect return name
    assert name == play3.get_name()


# Generated at 2022-06-11 10:24:52.714226
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.playbook.play_context import PlayContext

    # Test with empty Play()
    p = Play()
    data = p.serialize()
    assert isinstance(data, dict), "Play.serialize return type"

# Generated at 2022-06-11 10:24:55.086627
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    result = Play().preprocess_data({"hosts": "123"})
    assert isinstance(result, dict)

# Generated at 2022-06-11 10:25:00.388626
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    my_play = Play()
    my_play.vars_files = None
    assert my_play.get_vars_files(), []
    my_play.vars_files = [1, 2]
    assert my_play.get_vars_files(), [1, 2]
    my_play.vars_files = [1, 2]
    result = my_play.get_vars_files()
    assert [1, 2] == result

# Generated at 2022-06-11 10:25:08.839042
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[
            "common/ntp",
            "common/osupdate"
        ])

    play = Play().load(data=play_ds, variable_manager=VariableManager(), loader=DataLoader())

    roles = RoleInclude.load()
    block_list = play.compile_roles_handlers()


    assert True==True

# Generated at 2022-06-11 10:25:21.099449
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    host = 'localhost'
    block = Block()

    play = Play()
    tasks = [
        Task(action='test', args={'msg': 'test handler'})
    ]
    block.block = tasks
    task = Task(action='test', args={'msg': 'test handler'})

    hander_list = []
    hander_list.append(Handler(task=task, when=[host]))
    hander_list.append(Handler(task=block, when=[host]))

    role = RoleDefinition(name='test', handlers=hander_list)
    play.roles = [role]

   

# Generated at 2022-06-11 10:25:38.128110
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    assert False

# Generated at 2022-06-11 10:25:42.568220
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_obj = Play()
    # check 1
    if isinstance(play_obj.serialize(), dict) is False:
        raise AssertionError("play_obj.serialize() not returning proper dictionary object")


# Generated at 2022-06-11 10:25:47.191511
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_obj = Play()
    task = ({"test_key":"test_value"},)
    play_obj.pre_tasks = []
    play_obj.tasks = [task]
    play_obj.post_tasks = []
    expected_result = [task]
    actual_result = play_obj.get_tasks()
    assert actual_result == expected_result

# Generated at 2022-06-11 10:25:48.576474
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
  # TODO: Implement unit tests
  pass

# Generated at 2022-06-11 10:25:51.681821
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    play_context = PlayContext()
    play=Play()
    play.tasks = [TaskInclude()]
    tasks = play_context.get_tasks()
    assert tasks

# Generated at 2022-06-11 10:26:02.695900
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import tempfile
    import collections
    import operator
    import sys
    import shutil
    import os
    import io
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.strategy
    import ansible.executor.task_result
    import ansible.plugins.callback
    import ansible.plugins.connection

    from ansible.plugins.loader import get_all_plugin_loaders, PluginLoader
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-11 10:26:03.359065
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass # TODO

# Generated at 2022-06-11 10:26:14.636039
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    fake_loader = DictDataLoader({'tasks': {
        'test.yml': """
        - name: play_tasks
          block:
            - name: task1
          handlers:
            - name: play_handlers
              block:
                - name: handler1
        """}})
    fake_variable_manager = VariableManager()


# Generated at 2022-06-11 10:26:20.688430
# Unit test for method get_name of class Play
def test_Play_get_name():
    v = Play()
    assert v.get_name() == '', 'Play.get_name must return empty string in case of empty play'
    v = Play({'hosts': 'all', 'name': 'test'})
    assert v.get_name() == 'test', 'Play.get_name must return the name of the play'
    v = Play({'hosts': ['host1', 'host2'], 'name': 'test'})
    assert v.get_name() == 'host1,host2', 'Play.get_name must return the name of the play'

# Generated at 2022-06-11 10:26:22.689932
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = \
        "Test_Task"
    assert play.get_name() == "Test_Task"

# Generated at 2022-06-11 10:26:48.316903
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_Play=Play()
    test_Play.pre_tasks=[1,2,3]
    test_Play.tasks=[4,5,6]
    test_Play.post_tasks=[7,8,9]
    tasks = [1,2,3,4,5,6,7,8,9]
    assert tasks == test_Play.get_tasks()
    
    

# Generated at 2022-06-11 10:26:57.447901
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert([]) == play.get_vars_files()

    play.vars_files = 'vars/vars_files.yml'
    assert(['vars/vars_files.yml']) == play.get_vars_files()

    play.vars_files = ['vars/vars_files-1.yml', 'vars/vars_files-2.yml']
    assert(['vars/vars_files-1.yml', 'vars/vars_files-2.yml']) == play.get_vars_files()


# Generated at 2022-06-11 10:27:00.535601
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile



# Generated at 2022-06-11 10:27:05.057030
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []

    p.vars_files = 1
    assert p.get_vars_files() == [1]

    p.vars_files = [1, 2]
    assert p.get_vars_files() == [1, 2]


# Generated at 2022-06-11 10:27:12.239611
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [
        {'name': 'task1'},
        {'name': 'task2', 'rescue': [{'name': 'task3'}]}
    ]
    play.tasks = [
        {'name': 'task4'},
        {'name': 'task5', 'rescue': [{'name': 'task6'}]}
    ]
    play.post_tasks = [
        {'name': 'task7'},
        {'name': 'task8', 'rescue': [{'name': 'task9'}]}
    ]
    test_list = play.get_tasks()
    assert len(test_list) == 9
    assert len(test_list[0]) == 1

# Generated at 2022-06-11 10:27:21.627764
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """Test compile_roles_handlers"""

    import copy
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.play_context import PlayContext

    mock_loader = DictDataLoader({})

    mock_variable_manager = MagicMock()
    mock_variable_manager.__contains__ = MagicMock(return_value = True)
    mock_variable_manager.get_vars = MagicMock(return_value=dict(
        main_role_var="main",
        other_role_var="main"
    ))
    mock_variable_manager.extra_vars = MagicMock(return_value=dict(
        main_extra_role_var="main",
        other_extra_role_var="main"
    ))

    mock_play_context = Play

# Generated at 2022-06-11 10:27:24.894238
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [1]
    p.tasks = [2]
    p.post_tasks = [3]
    assert p.get_tasks() == [1, 2, 3]


# Generated at 2022-06-11 10:27:27.055781
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test play'
    assert play.get_name() == 'test play'


# Generated at 2022-06-11 10:27:36.828575
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    Test that Play.get_tasks() - the tasks in the Play are correctly processed.
    Returns a list of tasks, where the Block has been expanded into a list of tasks.
    '''
    class TestPlay(Play):
        def __init__(self, tasklist):
            super(TestPlay, self).__init__()
            self.pre_tasks = []
            self.post_tasks = []
            self.tasks = tasklist

    #
    # Test that a block returns a list of tasks
    #
    block = Block()
    block.block = [Mock(is_handler=False)]
    play = TestPlay([block])
    assert(play.get_tasks() == [[Mock(is_handler=False)]])

    #
    # Test that an list of a task and a block

# Generated at 2022-06-11 10:27:44.339248
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():


    # If roles are present, returns a flat list of Blocks compiled from roles.
    # If roles are empty, returns an empty list.
    #
    # Unit test cases
    #
    # Case 1:
    #
    # Input: roles = [Role(), Role()]
    #
    # Expected results:
    #
    # Play().compile_roles_handlers() = [Block, Block]


    # Case 2:
    #
    # Input: roles = []
    #
    # Expected results:
    #
    # Play().compile_roles_handlers() = []

    pass

