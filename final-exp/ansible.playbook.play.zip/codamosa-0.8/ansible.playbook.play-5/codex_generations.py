

# Generated at 2022-06-11 10:18:28.799639
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    obj = AnsibleBaseYAMLObject()
    obj.data = {'hosts': 'all'}
    vars_manager = VariableManager()
    loader = DataLoader()
    p = Play.load(obj.data, variable_manager=vars_manager, loader=loader)
    assert p.hosts == 'all'
    assert p.vars == {}
    assert p.roles == []
    assert p.name == 'all'

    # Test with roles
    obj2 = AnsibleBaseYAMLObject()

# Generated at 2022-06-11 10:18:31.524381
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test"
    assert play.get_name() == "test"


# Generated at 2022-06-11 10:18:32.933114
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
	my_play = Play()
	my_play.roles = ['roles']
	my_play.compile_roles_handlers()

# Generated at 2022-06-11 10:18:45.211991
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    provider = dict(
        name="azure",
        subscription_id="00000000-0000-0000-0000-000000000000",
        client_id="00000000-0000-0000-0000-000000000000",
        secret="00000000-0000-0000-0000-000000000000",
        tenant="00000000-0000-0000-0000-000000000000",
        ad_user="username@domain.com",
        ad_password="password",
        cloud_environment="AZUREPUBLICCLOUD"
    )
    testPlay = Play()
    testPlay.hosts = ['host']
    testPlay.roles = [Role({"name":"testRole", "provider":provider}, testPlay, None)]

# Generated at 2022-06-11 10:18:52.950548
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    ################################################################################
    #  TEST Play.compile_roles_handlers()
    ################################################################################

    # --------------------------------------------------------------
    #  Create test role fixtures
    # --------------------------------------------------------------

    # Create test role fixtures
    role_name = "role_name"
    role_path = "/path/to/role"

    ## Create a test role
    role = Role()
    role.get_name.return_value = role_name
    role.get_path.return_value = role_path

    # Create test role
    role1 = Role()
    role1.get_name.return_value = role_name
    role1.get_path.return_value = role_path

    role.get_handler_blocks.return_value = [role1]

    ## Create a test handler
    handler_

# Generated at 2022-06-11 10:19:06.011133
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pb = Play()
    # Create a block containing a single flush handlers meta
    # task, so we can be sure to run handlers at certain points
    # of the playbook execution
    flush_block = Block.load(
        data={'meta': 'flush_handlers'},
        play=pb,
        variable_manager=None,
        loader=None
    )
    for task in flush_block.block:
        task.implicit = True

    block_list = []
    block_list.extend(pb.pre_tasks)
    block_list.append(flush_block)
    block_list.extend(pb._compile_roles())
    block_list.extend(pb.tasks)
    block_list.append(flush_block)

# Generated at 2022-06-11 10:19:17.618251
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # set up objects
    p = Play()
    # set up mocks
    # set up test data

# Generated at 2022-06-11 10:19:22.840548
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    myplay = Play()
    ds = {'user': 'fungible'}
    res = myplay.preprocess_data(ds)
    assert res['remote_user'] == 'fungible'

# Generated at 2022-06-11 10:19:35.512503
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    class TestPlayPreprocessData:
        def test_result(self, monkeypatch, mocker):
            monkeypatch.setattr(Play, '__init__', lambda self: None)
            mocker.patch.object(Play, '_validate_blocks')
            mocker.patch.object(Play, '_load_included_file')
            mocker.patch.object(Play, '_create_blocks')
            mocker.patch.object(Play, '_post_validate')
            mocker.patch.object(Play, 'load_data', return_value='load_data')
            mocker.patch.object(Play, 'post_validate')
            play = Play()
            assert play.preprocess_data('ds') == 'load_data'

# Generated at 2022-06-11 10:19:46.258007
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''Unit test for Play.get_name'''
    def test_Play_get_name_001():
        '''Test Play.get_name when name is specified'''
        p = Play()
        p.name = 'test'
        assert p.get_name() == p.name
    test_Play_get_name_001()
    def test_Play_get_name_002():
        '''Test Play.get_name when name is not specified'''
        p = Play()
        p.hosts = None
        assert p.get_name() == ''
    test_Play_get_name_002()
    def test_Play_get_name_003():
        '''Test Play.get_name when name is not specified and hosts is a string'''
        p = Play()

# Generated at 2022-06-11 10:20:08.058002
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager.extra_vars = dict()
    variable_manager._options = Mock()

    variable_manager._options.connection = 'local'
    variable_manager._options.module_path = None
    variable_manager._options.forks = 5
    variable_manager._options.remote_user = 'username'
    variable_manager._options.private_key_file = None
    variable_manager._options.ssh_common_args = None
    variable_manager._options.ssh_extra_args = None
    variable_manager._options.sftp_extra_args = None
    variable_manager._options.scp_extra_args = None
    variable_manager._options.become = False

# Generated at 2022-06-11 10:20:17.078667
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """
    Class: Play
    Method: compile_roles_handlers
    """
    # Test 1 - default case
    play_attributes = {
        "name": "my play",
        "hosts": "all",
        "user": "bob",
    }
    p = Play().load(play_attributes, variable_manager=None, loader=None)
    #self.assertFalse(hasattr(p, "handler"), "None")
    # Test 2 - default case
    play_attributes = {
        "name": "my play",
        "hosts": "all",
        "user": "bob",
        "roles": [
            "role1"
        ]
    }
    p = Play().load(play_attributes, variable_manager=None, loader=None)

    p.RO

# Generated at 2022-06-11 10:20:27.681169
# Unit test for constructor of class Play
def test_Play():
    # Constructor for the class Play
    p = Play()

    # test that the default values are set correctly
    assert p.vars is None
    assert p.hosts is None
    assert p.remote_user is None
    assert p.become is None
    assert p.become_method is None
    assert p.become_user is None
    assert p.connection is None
    assert p.any_errors_fatal is None
    assert p.serial is None
    assert p.async_val is None
    assert p.poll is None
    assert p.timeout is None
    assert p.max_fail_percentage is None
    assert p.environment is None
    assert p.basedir is None



# Generated at 2022-06-11 10:20:36.499960
# Unit test for method get_name of class Play
def test_Play_get_name():
  # basic test
  play = Play()
  play.name = "test"
  assert play.get_name() == "test"
  # test with play having no specified name but hosts specified
  play = Play()
  play.hosts = ["test-hosts"]
  assert play.get_name() == "test-hosts"
  # host should be set even if it's set to ""
  play = Play()
  play.hosts = [""]
  assert play.get_name() == ""
  # tests with play having no specified name and no hosts specified
  play = Play()
  assert play.get_name() == ""
test_Play_get_name()


# Generated at 2022-06-11 10:20:47.694487
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansiblelint.rules.WhenIsNotSufficientRule import WhenIsNotSufficientRule
    when_not_present_rule = WhenIsNotSufficientRule()
    play = Play()
    play.get_tasks()[0].set_loader(DictDataLoader({'test/test.yml': """
    - hosts: localhost
      tasks:
      - block:
        - shell: echo I run
          when: not present
        rescue:
        - shell: echo I run
          when: present
        always:
        - shell: echo I run
          when: always
    """}))
    for block in play.get_tasks():
        for task in block.block:
            when_not_present_rule.matchtask(task)
    serialized_play = play.serialize()
    assert serialized_play

# Generated at 2022-06-11 10:20:59.563391
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    m_data = dict(name='test_play', 
                  max_fail_percentage=5.5, 
                  serial=['a', 'b', 'c'], 
                  strategy='test_strategy', 
                  slots=5, 
                  gather_facts='no', 
                  ds='test_ds', 
                  _ds='test__ds', 
                  _AnsibleContainer__ds='test__AnsibleContainer__ds', 
                  _ansible_version='test_ansible_version', 
                  _ansible_no_log='test_ansible_no_log', 
                  _ansible_self_gs='test_ansible_self_gs', 
                  _ansible_self_ds='test_ansible_self_ds')
    p = Play()

# Generated at 2022-06-11 10:21:09.107734
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    context = PlayContext()

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    base_dir = os.path.dirname(os.path.dirname(__file__))
    callback = PlaybookExecutor(playbooks=[base_dir + '/test/base/test_playbook.yml'],
                                inventory=inventory,
                                variable_manager=variable_manager,
                                loader=loader,
                                options=None,
                                passwords={})

# Generated at 2022-06-11 10:21:21.910647
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    global_vars = dict(
        ansible_connection='smart',
        ansible_ssh_private_key_file='./test/integration/default_private_key',
        ansible_ssh_common_args='-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null',
        ansible_ssh_user='test_ssh_user',
        ansible_sudo_pass='test_ssh_pwd',
        ansible_become_method='sudo',
        ansible_become_exe='test_become_exe',
        ansible_ssh_host='test_connection_hostname',
        ansible_ssh_port='test_connection_port'
    )
    loader = DataLoader()

# Generated at 2022-06-11 10:21:26.377078
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test to verify the method compile_roles_handlers of class Play.
    p = Play()
    assert p._compile_roles_handlers() == [], "_compile_roles_handlers() failed to return expected result"


# Generated at 2022-06-11 10:21:35.041241
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include_role import TaskIncludeRole
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 10:21:55.696041
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Init
    data = {}
    # Call
    play_obj = Play()
    play_obj.deserialize(data)
    # Assert

    # Init
    data = {'something': True}
    # Call
    play_obj = Play()
    play_obj.deserialize(data)
    # Assert

    # Init
    data = {'roles': []}
    # Call
    play_obj = Play()
    play_obj.deserialize(data)
    # Assert

    # Init
    data = {'roles': [{}, {}]}
    # Call
    play_obj = Play()
    play_obj.deserialize(data)
    # Assert



# Generated at 2022-06-11 10:22:01.422516
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test with vars_files=None
    p = Play()
    assert p.get_vars_files() == []
    # Test with vars_files=<string>
    p2 = Play()
    p2.vars_files = 'test'
    assert p2.get_vars_files() == ['test']
    # Test with vars_files=<list>
    p3 = Play()
    p3.vars_files = ['test1', 'test2']
    assert p3.get_vars_files() == ['test1', 'test2']



# Generated at 2022-06-11 10:22:10.480842
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Test Play.compile_roles_handlers.

    :return:
        A boolean indicating pass or fail.
    '''
    p = Play()
    p.handlers = []
    p.roles = [[
        {},
        {
            'import_playbook': 'foo.yml'
        },
        {
            'handlers': []
        }
    ]]

    result = p.compile_roles_handlers()
    if result != p.roles[0][2]['handlers']:
        return False

    return True

# Generated at 2022-06-11 10:22:14.807344
# Unit test for method get_name of class Play
def test_Play_get_name():
    try:

        # Test for Play.get_name(self)

        """
        Return the name of the Play object, which is derived from the list of hosts.
        """

        # Test for return of Play.get_name(self)
        pass
    except:
        pass


# Generated at 2022-06-11 10:22:19.457579
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
	args = dict(
		vars_files=BASE_VARS_FILES
	)
	play = Play.load(args, None)
	play_vars_files = play.get_vars_files()
	assert play_vars_files == BASE_VARS_FILES


# Generated at 2022-06-11 10:22:29.617326
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers() == []
    roles = [
        Role.load({'name': 'a'}),
        Role.load({'name': 'b'}),
    ]
    p = Play()
    p.set_roles(roles)
    assert p.compile_roles_handlers() == []
    roles = [
        Role.load({'name': 'a', 'handlers': [{'handler1': {'name': 'handler1'}}]}),
        Role.load({'name': 'b', 'handlers': [Block(
            [{'handler2': {'name': 'handler2'}}, {'handler3': {'name': 'handler3'}}]
        )]}),
    ]
    p = Play()

# Generated at 2022-06-11 10:22:40.006210
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_utils'))


# Generated at 2022-06-11 10:22:47.175949
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    task = Task()
    task.block = 'block'
    task.rescue = 'rescue'
    task.always = 'always'
    play = Play()
    play.pre_tasks = task
    play.tasks = task
    play.post_tasks = task
    tasks = play.get_tasks()
    assert len(tasks) == 3
    for t in tasks:
        assert t == 'block'
        assert t == 'rescue'
        assert t == 'always'

# Generated at 2022-06-11 10:22:58.105257
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    playbook_loader = PlaybookFileLoader(loader=DataLoader())
    playbook_path = playbook_loader._find_path('playbook_example.yml')
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=context.CLIARGS)
    variable_manager.options_vars = load_options_vars(context.CLIARGS)
    variable_manager.set_inventory(Inventory(loader=None, variable_manager=variable_manager, host_list='hosts_test'))
    playbooks = [playbook_path for playbook_path in playbook_loader.find_all_playbooks([playbook_path])]
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list='hosts_test')
    p

# Generated at 2022-06-11 10:23:02.059538
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    a = Play()
    assert isinstance(a.get_vars_files(), list)
    a.vars_files = ['vf']
    assert isinstance(a.get_vars_files(), list)


# Generated at 2022-06-11 10:23:14.135941
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_obj = Play()
    assert play_obj.compile_roles_handlers() == [], "Compiling roles Handlers failed"

# Generated at 2022-06-11 10:23:16.271292
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  # Branch coverage:
  #   True:  line 23
  #   False: lines 8, 22, 25
  return 1

# Generated at 2022-06-11 10:23:26.532829
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import json
    import pprint
    # Import base class module
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    # Load JSON data into class
    play_data = dict()
    play_data['name'] = 'configure-apache-servers'
    play_data['hosts'] = 'webservers'
    play_data['user'] = 'deploy'
    play_data['connection'] = 'local'
    play_data['gather_facts'] = 'no'
    play_data['vars'] = dict()
    play_data['vars']['ansible_connection'] = 'local'
    play_data['vars_files'] = list()

# Generated at 2022-06-11 10:23:29.240719
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [1,2,3]
    assert p.get_tasks() == [1,2,3]


# Generated at 2022-06-11 10:23:42.290295
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    a = set()
    playbook_data = dict(
        hosts='localhost',
        vars_files=['test/ansible/test_vars_files/test0', 'test/ansible/test_vars_files/test1', 'test/ansible/test_vars_files/test2'],
    )

    p = Play().load(playbook_data, variable_manager=VariableManager(), loader=DataLoader())
    b = p.get_vars_files()
    for i in b:
        a.add(i)
    assert a == {'test/ansible/test_vars_files/test0', 'test/ansible/test_vars_files/test1', 'test/ansible/test_vars_files/test2'}, 'bad Play.get_vars_files()'

# Generated at 2022-06-11 10:23:53.105565
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [({"task_name":"test_1","task_id":1,"action":"test_action_1","action_args":{"key1":"val1","key2":"val2"},"start_at":0})]
    p.pre_tasks = [({"task_name":"test_2","task_id":2,"action":"test_action_2","action_args":{"key1":"val1","key2":"val2"},"start_at":0})]
    p.post_tasks = [({"task_name":"test_3","task_id":3,"action":"test_action_3","action_args":{"key1":"val1","key2":"val2"},"start_at":0})]
    tasks = p.get_tasks()
    assert(len(tasks) == 3)

# Generated at 2022-06-11 10:24:04.837421
# Unit test for method preprocess_data of class Play

# Generated at 2022-06-11 10:24:15.123743
# Unit test for method get_vars_files of class Play

# Generated at 2022-06-11 10:24:16.163831
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    Play()


# Generated at 2022-06-11 10:24:28.107134
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    host_list = [
        'test_host_0',
        'test_host_1',
        'test_host_2'
    ]
    # FIXME: mock this function
    variables = get_vars(loader=None, play=None, host=None, task=None)
    play_source = dict(
        name="Ansible Play",
        hosts='webservers',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='/usr/bin/ls')),
            dict(action=dict(module='debug', args=dict(msg='Hello World')))
        ]
    )
    play = Play().load(
        play_source,
        variable_manager=VariableManager(),
        loader=DataLoader()
    )
    play._hosts = host

# Generated at 2022-06-11 10:24:52.605474
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.role.definition import RoleDefinition

    my_play = Play()
    role_definition = RoleDefinition()
    role_definition.roles = ['test_role']
    my_play.ROLE_CACHE = {'test_role': role_definition}
    result = my_play.compile_roles_handlers()
    assert result == []
# test get_vars_files

# Generated at 2022-06-11 10:25:01.318779
# Unit test for method get_tasks of class Play

# Generated at 2022-06-11 10:25:10.597232
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''
    get_name() return the name of the Play
    '''
    playbook = Playbook()
    assert playbook.get_name() is None

    playbook = Playbook(loader=DictDataLoader({
        "/foo/bar/file.yml": """
- hosts: 192.168.0.1
  tasks:
        - name: foo
          ping: """,
    }))
    playbook.load("/foo/bar/file.yml")
    assert playbook.get_name() == "192.168.0.1"

# Generated at 2022-06-11 10:25:18.837176
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [{'debug': 'msg1'}]
    play.tasks = [{'debug': 'msg2'}]
    play.post_tasks = [{'debug': 'msg3'}]
    result_tasks = play.get_tasks()
    expect_tasks = [{'debug': 'msg1'}, {'debug': 'msg2'}, {'debug': 'msg3'}]
    assert result_tasks == expect_tasks

# Generated at 2022-06-11 10:25:23.810472
# Unit test for constructor of class Play
def test_Play():
    # just one of the multiple constructor tests
    play_ds = dict(
        name='play1',
        vars=dict(x=1),
        hosts=['all'],
        gather_facts=False,
        tasks=dict(
            name='task1',
            action=dict(module='shell', args='uptime')
        ),
        post_tasks=dict(
            name='task2',
            action=dict(module='shell', args='date')
        ),
        handlers=[
            dict(
                name='handler1',
                action='debug',
                args=dict(msg='action1.handler1')
            ),
            dict(
                name='handler2',
                action=dict(module='shell', args='tzdata')
            ),
        ]
    )


# Generated at 2022-06-11 10:25:24.469444
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert False, "Test not implemented"

# Generated at 2022-06-11 10:25:30.812399
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    dummy_runner = type('', (object,), dict(get_name='dummy_runner'))
    dummy_play = type('', (object,), dict(get_name='dummy_play', runner=dummy_runner))
    dummy_tqm = type('', (object,), dict(get_name='dummy_tqm', host_list=[]))
    dummy_play_context = type('', (object,), dict(CLIARGS=dict(force_handlers=False)))
    p = Play()
    # Test exception if no block_list argument is given
    with pytest.raises(TypeError):
        p.run_handlers(dummy_tqm, dummy_play_context)
    # Test exception if block_list argument is given the wrong datatype

# Generated at 2022-06-11 10:25:44.113615
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # create a play
    play = Play()
    # set vars_files to None
    play.vars_files = None
    # assert that play.get_vars_files returns an empty list
    assert play.get_vars_files() == []
    # set vars_files to a string
    play.vars_files = '/path/to/file'
    # assert that play.get_vars_files returns a list
    assert isinstance(play.get_vars_files(), list)
    # set vars_files to a list
    play.vars_files = ['/path/to/file1', '/path/to/file2']
    # assert that play.get_vars_files returns a list
    assert isinstance(play.get_vars_files(), list)

# Generated at 2022-06-11 10:25:52.294024
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create an instance of a Play object with an attribute name of play
    play = Play()
    # create an instance of a Role object with an attribute name of role
    role = Role()
    # create a list object with an attribute name of roles which contains role
    play.roles=[role]
    # create a list object with an attribute name of handlers which contains role
    role.handlers=[role]
    # create a role object with an attribute name of role
    role=Role()
    # create a list object with an attribute name of roles which contains role
    play.roles=[role]
    # create an instance of a Task object with an attribute name of task
    task=Task()
    # create a list object with an attribute name of tasks which contains task
    role.tasks=[task]
    # create an instance of a Block object with an attribute name of

# Generated at 2022-06-11 10:25:54.603058
# Unit test for method serialize of class Play
def test_Play_serialize():

    def setUp(self):
        pass
    def tearDown(self):
        pass

    def test_serialize(self):
        pass

# Generated at 2022-06-11 10:26:18.891978
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    # TODO: Fix the test_get_tasks.

    # pre_tasks=[Task(name='Pre task')],
    # tasks=[Task(name='Task')],
    # post_tasks=[Task(name='Post task')],

    pass

# Generated at 2022-06-11 10:26:20.481181
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert isinstance(p.compile_roles_handlers(), list)


# Generated at 2022-06-11 10:26:29.338898
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-11 10:26:31.113946
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    tasks = p.get_tasks()
    assert tasks == []


# Generated at 2022-06-11 10:26:39.661324
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    
    # Create Instance of Play
    p = Play()
    
    # Create module
    m = AnsibleModule()
    
    # Create a task and append it to the list of tasks
    for i in range(0, 10):
        task = Task(module_name="ping", module_args={"data": "ping"}, name="ping-"+str(i), async_val=1, poll=0, ignore_errors=False, delegate_to="", register="", when="", loop_control="", loop_with="", until="")
        p.tasks.append(task)

    task_list = p.get_tasks()

    assert len(task_list) == 10, p.name
    
    
    
    
    


# Generated at 2022-06-11 10:26:49.977819
# Unit test for method get_vars_files of class Play

# Generated at 2022-06-11 10:26:56.686330
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()
    test_play.load_data({'roles': [
        {'role': 'test_role', 'include_tasks': 'test_include.yml', 'handlers': ['test_handler.yml']}
    ]})
    compiled_handlers = test_play.compile_roles_handlers()
    assert compiled_handlers[0].name == 'test_handler'
    # TODO: other checks


# Generated at 2022-06-11 10:26:59.766238
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    test get_vars_files method of Play class
    '''
    p = Play()
    p.get_vars_files()


# Generated at 2022-06-11 10:27:01.494506
# Unit test for method serialize of class Play
def test_Play_serialize():
    # test serialize of Play class
    play = Play()
    play.serialize()

# Generated at 2022-06-11 10:27:02.868314
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.compile_roles_handlers()

# Generated at 2022-06-11 10:27:28.473618
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    record_property("hostname", socket.gethostname())
    record_property("ansible_version", __version__)
    record_property("ansible_python_version", sys.version)
    record_property("ansible_playbook_python_version", sys.version)

    main()


# Generated at 2022-06-11 10:27:38.146380
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._load_roles = lambda: [1,2,3]
    p.roles = []
    p.collections = []
    assert p.compile_roles_handlers() == []
    p._load_roles = lambda: [
        Role(task_blocks={'tasks': [{
            'name': 'echo hello1',
            'block': [{'name': 'echo hello1'}],
            'rescue': [],
            'always': []
        }]})
    ]
    p.roles = []

# Generated at 2022-06-11 10:27:43.810280
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Check that get_tasks returns the correct number of tasks
    # Setup
    play = Play()

    play._pre_tasks = ['task1', 'task2', 'task3']
    play._tasks = ['task4', 'task5', 'task6']
    play._post_tasks = ['task7', 'task8', 'task9']

    # Exercise
    # Verify
    assert len(play.get_tasks()) == 9


# Generated at 2022-06-11 10:27:49.993404
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.tasks = [[1,2,3],[4,5],6]
    play.pre_tasks = [[7,8,9]]
    play.post_tasks = [10]
    expected = [1,2,3,4,5,6,7,8,9,10]
    assert expected == play.get_tasks()


# Generated at 2022-06-11 10:28:00.055199
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_file_1 = "/file/path/to/playbook/playbook-vars.yml"
    vars_file_2 = "/file/path/to/playbook/playbook-vars.yaml"
    vars_file_3 = "/file/path/to/playbook/playbook-vars.json"
    vars_file_4 = "/file/path/to/playbook/playbook-vars.yml"
    vars_file_5 = "/file/path/to/playbook/playbook-vars.yaml"
    vars_file_6 = "/file/path/to/playbook/playbook-vars.json"

    # get_vars_files() for a Play for which vars_files is None
    p = Play()
    p.vars_

# Generated at 2022-06-11 10:28:00.629741
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-11 10:28:08.339102
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    data = p.preprocess_data({'user': 'root'})
    assert data['remote_user'] == 'root'
    assert not 'user' in data
    data = p.preprocess_data({'hosts': 'host'})
    assert data['hosts'] == 'host'
    data = p.preprocess_data({'hosts': ['host1', 'host2']})
    assert data['hosts'] == ['host1', 'host2']
    with pytest.raises(AnsibleAssertionError):
        data = p.preprocess_data('')
    with pytest.raises(AnsibleAssertionError):
        data = p.preprocess_data(0)
