

# Generated at 2022-06-11 10:18:33.765278
# Unit test for method get_name of class Play
def test_Play_get_name():

    # Unit test for method get_name of class Play with no args
    playbook = Play()
    assert playbook.get_name() == ""

    # Unit test for method get_name of class Play with host pattern
    playbook = Play()
    playbook._ds = dict(hosts="1.1.1.1")
    assert playbook.get_name() == "1.1.1.1"

    # Unit test for method get_name of class Play with multiple args
    playbook = Play()
    playbook._ds = dict(hosts=["1.1.1.1","2.2.2.2"])
    assert playbook.get_name() == "1.1.1.1,2.2.2.2"


# Generated at 2022-06-11 10:18:45.849422
# Unit test for method serialize of class Play
def test_Play_serialize():
    import copy
    play = Play()
    play.vars={'k1':'v1'}
    play.name='play'
    play.hosts='play'
    play.roles=None
    play.tasks=[]
    play._action_groups={}
    play._group_actions={}
    data = play.serialize()
    # Verify if serialize stores the same value or not
    assert play.vars == data['vars']
    assert play.name == data['name']
    assert play.hosts == data['hosts']
    assert play.roles == data['roles']
    assert play.tasks == data['tasks']
    assert play._action_groups == data['action_groups']
    assert play._group_actions == data['group_actions']
    # Change value of variables in

# Generated at 2022-06-11 10:18:50.810313
# Unit test for method get_name of class Play
def test_Play_get_name():
    """
    Play.get_name()
    """

    # setup test data
    play_ds = dict(
        name="test_get_name",
        hosts="test",
        connection="test"
    )
    play = Play()
    play.load(play_ds, variable_manager=None)

    # test
    result = play.get_name()

    # assert result
    assert result == "test_get_name"



# Generated at 2022-06-11 10:19:03.595380
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    loader = DictDataLoader({
        "hello_world.yml": """
---
- hosts: all
  connection: local
  tasks:
    - yum:
        name: foobar
        state: present
      vars:
        pkgname: foobar
        state: present
""",
        "hello_world_role/defaults/main.yml": """
---
foo: bar
""",
        "hello_world_role/tasks/main.yml": """
---
- debug: msg="hello world"
"""
    })

    inventory = InventoryManager(loader=loader, sources="localhost,")

    # Test with a list passed in
    p = Play()
    p.vars_files = ["hello_world_role/defaults/main.yml"]
    p.vars_files = p

# Generated at 2022-06-11 10:19:14.956442
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    my_play = Play(
        name='test_play',
        hosts='all',
        gather_facts='no',
        vars_files='./tests/unit/module_utils/ansible_test_vars.yml',
        roles=[
            RoleInclude(
                name='test_role_1',
            ),
            RoleInclude(
                name='test_role_2',
            ),
            RoleInclude(
                name='test_role_3',
            ),
        ]
    )

    result = my_play.compile_roles_handlers()
    assert result == ['test_role_1_handler block', 'test_role_2_handler block', 'test_role_3_handler block']


# Generated at 2022-06-11 10:19:29.643117
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    
    p = Play()
    p.vars = dict()
    p.vars['hosts'] = ['host1', 'host2']
    p.connection = 'local'
    p.name = 'play'
    p.play_hosts = set(['host1', 'host2'])
    p.serial = 1
    p.vars_prompt = dict()
    p.variable_manager = VariableManager()
    p.handler_block = []
    p.handlers = []
    p.post_tasks = []
    p.pre

# Generated at 2022-06-11 10:19:40.669366
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize(get_json())
    assert play.included_path == "/etc/ansible/roles/role_a"
    assert play.vars == get_json().get('vars')
    assert play.name == "myplay"
    assert play.tags == get_json().get('tags')
    assert play.hosts == "all"
    assert play.connection == "smart"
    assert play.max_fail_percentage == 88
    assert play.remote_user == "DonJohnson"
    assert play.become == True
    assert play.become_user == "DonJohnson"
    assert play.become_method == "sudo"
    assert play.boostrap_host == "127.0.0.1"
    assert play.boostrap_port == 22

# Generated at 2022-06-11 10:19:46.533179
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.name = 'test'
    play.tasks = [{"name": "Test play"}]
    play.pre_tasks = [{"name": "Test pre_tasks"}]
    play.post_tasks = [{"name": "Test post_tasks"}]
    play.handler_tasks = [{"name": "Test handlers"}]
    assert isinstance(play.get_tasks()[0], Task)

# Generated at 2022-06-11 10:19:53.712119
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    test_ds = [{'post_tasks': [{'include_tasks': '{{ path }}{{ host }}actions.yml'}, {'debug': 'msg={{ host }}'}], 'vars_prompt': [{'name': 'path', 'prompt': 'The path of the vpn client config file', 'private': True}]}]
    # set the context
    obj_handle = Play()
    retval = obj_handle.preprocess_data(test_ds)
    # assert the return code
    assert retval is not None, "Preprocess data failed."
    # return the results
    return retval



# Generated at 2022-06-11 10:20:05.301250
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._load_roles = MagicMock()

    roles = [MagicMock(), MagicMock(), MagicMock()]
    p._load_roles.return_value = roles

    roles[0].get_handler_blocks.return_value = []
    roles[1].get_handler_blocks.return_value = ['qwerty']
    roles[2].get_handler_blocks.return_value = ['ytrewq']

    assert p.compile_roles_handlers() == ['ytrewq', 'qwerty']

    p._load_roles.assert_called_once_with('roles', [])
    assert roles[0].get_handler_blocks.call_count == 1
    roles[0].get_handler_blocks.assert_called_once_with(play=p)


# Generated at 2022-06-11 10:20:13.695431
# Unit test for method deserialize of class Play
def test_Play_deserialize():
  pass

# unit test for method load of class Play

# Generated at 2022-06-11 10:20:23.952722
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import types
    import yaml

    class Play:
        def __init__(self):
            self.pre_tasks = [PlayTask([PlayTask([PlayTask(), PlayTask()])]), PlayTask()]
            self.post_tasks = [PlayTask([PlayTask([PlayTask(), PlayTask()])]), PlayTask()]
            self.tasks = [PlayTask([PlayTask([PlayTask(), PlayTask()])]), PlayTask()]
            self.handlers = [PlayTask([PlayTask([PlayTask(), PlayTask()])]), PlayTask()]
            self.roles = []

    class PlayTask:
        def __init__(self, task=None):
            self.task = task
            self.block = []
            self.rescue = []
            self.always = []

    p = Play()

# Generated at 2022-06-11 10:20:34.794491
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    #=============================
    # Use case 1: Test the function get_vars_files() for a single file
    #=============================
    # Precondition
    # Create a play
    p = Play()
    # p.vars_files is None
    p.vars_files = None
    # Tests
    # Call the function get_vars_files()
    res = p.get_vars_files()
    # Check that res == []
    assert res == [], "test_Play_get_vars_files() test case 1 fails\n" \
                      "p.vars_files is None and get_vars_files() returned " + str(res) + "\n"

    #=============================
    # Use case 2: Test the function get_vars_files() with vars_files as a list
    #

# Generated at 2022-06-11 10:20:35.471126
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:20:38.956198
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # test data
    data = {"hosts": "localhost"}

    # test object
    p = Play()

    # test call
    result = p.preprocess_data(data)

    # test assertions
    assert result == {"hosts": "localhost"}

# Generated at 2022-06-11 10:20:50.493529
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    # preprocess_data(self, ds)
    # play.preprocess_data()
    print("\nTest Play.preprocess_data():\n")
    assert play.preprocess_data(dict(hosts='hosts', vars=dict(vars = 'vars'), roles=dict(roles='roles'), tasks=dict(tasks='tasks'))) == dict(hosts='hosts', vars=dict(vars = 'vars'), roles=dict(roles='roles'), tasks=dict(tasks='tasks')), "Test1 is failed!"
    print("Test1 is passed!")
    # assert play.preprocess_data(dict(hosts='hosts', vars='vars', roles='roles', user='user', tasks='tasks')) == dict(hosts

# Generated at 2022-06-11 10:20:54.190913
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    """ test method deserialize of class Play """
    play_ds = Play()
    play_ds.deserialize({"hosts": []})
    assert play_ds.hosts == []

# Generated at 2022-06-11 10:20:56.598771
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Step 1
    x = Play()
    # Step 2

    assert isinstance(x.deserialize({}), bool)


# Generated at 2022-06-11 10:20:59.388856
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test preprocess_data method
    # Test 1
    play = Play()
    ds = "Test"
    assert play.preprocess_data(ds) is None


# Generated at 2022-06-11 10:21:08.850470
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test the Play function get_name with the following values:
    #    self.name='test_name'
    #    self.hosts='test_hosts'
    play_test1 = Play()
    play_test1.name = 'test_name'
    play_test1.hosts = 'test_hosts'
    assert play_test1.get_name() == 'test_name'

    # Test the Play function get_name with the following values:
    #    self.name=None
    #    self.hosts='test_hosts'
    play_test2 = Play()
    play_test2.name = None
    play_test2.hosts = 'test_hosts'
    assert play_test2.get_name() == 'test_hosts'

    # Test the Play function get_name

# Generated at 2022-06-11 10:21:29.075046
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_data = {'name': 'test_play_tagging_hosts', 'hosts': 'hosts',
     'roles': [{'name': 'test_role', 'tasks':
                                           [{'tags': ['t1', 't2'],
                                             'name': 'test_task',
                                             'register': 'test_task_register',
                                             'meta': {'args': {'key1': 'value1', 'key2': 'value2'}},
                                             'task': {'name': {'module': 'test_module', 'args': {'key': 'value'}}}}], 'meta': {}, 'vars': {}, 'handlers': []}],
     'vars': {}, 'handlers': []}
    play = Play()
    play.deserial

# Generated at 2022-06-11 10:21:32.761119
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """ Unit test for method get_tasks of class Play """
    play = Play()
    play.pre_tasks = [True]
    play.tasks = [False]
    play.post_tasks = [True]
    assert play.get_tasks() == [True, False, True]


# Generated at 2022-06-11 10:21:35.403946
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = ['task1', 'task2']
    tasks = p.get_tasks()
    assert len(tasks) < 1


# Generated at 2022-06-11 10:21:44.625088
# Unit test for method serialize of class Play
def test_Play_serialize():
    v = None
    p = Play()
    p.vars = {'k': 'v'}
    p.vars_prompt = 'prompt'
    p.vars_files = ['a', 'b']

    serialized = p.serialize()
    assert 'vars' in serialized
    assert 'vars_prompt' in serialized
    assert 'vars_files' in serialized
    assert 'roles' not in serialized
    assert 'included_path' not in serialized

    with pytest.raises(AssertionError):
        Play.load(data=serialized, variable_manager=v, loader=v)


# Generated at 2022-06-11 10:21:56.993352
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    record_property("hostname", "localhost")
    obj = Play()
    data = {}
    obj.deserialize(data)
    record_property("hostname", "localhost")
    assert 'id' in data
    record_property("hostname", "localhost")
    assert 'hidden' in data
    record_property("hostname", "localhost")
    assert 'name' in data
    record_property("hostname", "localhost")
    assert 'description' in data
    record_property("hostname", "localhost")
    assert 'tags' in data
    record_property("hostname", "localhost")
    assert 'remote_user' in data
    record_property("hostname", "localhost")
    assert 'connection' in data
    record_property("hostname", "localhost")
    assert 'gather_facts' in data
   

# Generated at 2022-06-11 10:22:07.512246
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    hostlist = ['foo.example.com', 'bar.example.com', 'baz.example.com', 'qux.example.com']
    (inventory, loader, variable_manager) = AnsibleTest.build_inventory(hostlist)
    
    # We have to specify a variable manager to prevent
    # a NPE when we call the copy() method of the play
    variable_manager.set_host_variable('foo.example.com', 'ansible_python_interpreter', '/foo/bar/python')
    variable_manager.set_host_variable('bar.example.com', 'ansible_python_interpreter', '/foo/bar/python')
    variable_manager.set_host_variable('baz.example.com', 'ansible_python_interpreter', '/foo/bar/python')

# Generated at 2022-06-11 10:22:18.425544
# Unit test for method deserialize of class Play
def test_Play_deserialize():

  # mock of an initialized 'data' variable, which is passed to the method under test
  data = {'tasks': {}, 'roles': [], 'included_path': '/path/to/file', 'action_groups': {'group_2': {'default': {'a_task': 'task1_path'}}, 'group_1': {'default': {'a_task': 'task1_path'}}}, 'group_actions': {'group_2': {'default': {'a_task': 'task1_path'}}, 'group_1': {'default': {'a_task': 'task1_path'}}}}

  # mock of the return value for ROLE_CACHE.copy()
  copy_return = {}

  # mock of class Play

# Generated at 2022-06-11 10:22:28.774730
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play1 = Play().load({}, variable_manager=VariableManager(), loader=DataLoader())
    #test 1
    #play1 = play().load({ 'tasks': [ { 'action': { '__ansible_module__': 'command', u'chdir': u'$HOME', '__ansible_arguments__': { 'warn': True }, u'creates': [ u'$HOME/output.txt' ], u'executable': None, u'removes': [], u'__ansible_no_log__': False, u'__ansible_verbose_always__': False, u'__ansible_module__': 'command', u'command': u'/bin/false' }, u'name': u'/bin/false' }, { 'action': { '__ansible_module__': 'command', u'chdir': u'$HOME',

# Generated at 2022-06-11 10:22:39.132138
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    yaml = '''---
- hosts: all
  gather_facts: true
  vars:
    var1: 1
    var2: 2
  vars_files:
   - file.yml
  pre_tasks:
    - name: pre_task
      debug: msg="Pre tasks"
  roles:
    - devopscafe.roles.role1
  tasks:
    - name: task_1
      debug: msg="Task 1"
  post_tasks:
    - name: post_task
      debug: msg="Post tasks"
  handlers:
    - name: handler_1
      debug: msg=Handler 1
'''
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-11 10:22:49.905277
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test case 1
    p = Play()
    p._pre_tasks = [
        'a',
        'b',
        'c'
    ]

    p._tasks = [
        'd',
        'e',
        'f'
    ]

    p._post_tasks = [
        'g',
        'h',
        'i'
    ]

    assert p.get_tasks() == [
        'a',
        'b',
        'c',
        'd',
        'e',
        'f',
        'g',
        'h',
        'i'
    ]

    # Test case 2
    p = Play()
    p._pre_tasks = [
        'a',
        'b',
        'c'
    ]

    p._tasks

# Generated at 2022-06-11 10:23:09.405848
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    name = play.get_name()
    assert name == "", "Assertion error"
    hosts = ["1.1.1.1", "2.2.2.2"]
    play.hosts = hosts
    play.name = None
    name = play.get_name()
    assert name == "1.1.1.12.2.2.2"


# Generated at 2022-06-11 10:23:19.031343
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play.load(dict(
        name='play',
        hosts='all',
        tasks=[
            dict(action='command', args=dict(cmd='/bin/true')),
        ],
    ), variable_manager=VariableManager(), loader=DataLoader())
    data = play.serialize()
    play.deserialize(data)
    assert play.name == u'play'
    assert play.hosts == 'all'
    assert len(play.get_tasks()) == 1
    assert play.get_tasks()[0].action == 'command'
    assert play.get_tasks()[0].args == dict(cmd='/bin/true')


# Generated at 2022-06-11 10:23:29.498497
# Unit test for method get_name of class Play
def test_Play_get_name():
    import os
    import tempfile
    import json

    _config_manager, pe = setup_patch_for_class(
        class_to_patch=Play,
        module_to_patch=os.path.basename(__file__),
        class_name='Play'
    )

    temp_dir = tempfile.mkdtemp('ansible_module_%s' % 'Play')
    data = dict([('scenario', 'test_scenario')])

    play_data = dict(
        hosts='localhost',
        pre_tasks=[],
        post_tasks=[],
        tasks=[],
        handlers=[],
        roles=[],
        vars=[],
        vars_prompt=[],
        vars_files=[],
        name='test_play'
    )


# Generated at 2022-06-11 10:23:32.961391
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
      ds = {'hosts': 'all', 'roles': [], 'tasks': [], 'vars': {}}
      play = Play()
      play.preprocess_data(ds)

# Generated at 2022-06-11 10:23:45.012832
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a fake Play object
    p = Play()

    # Create fake Role object with fake handler blocks
    r = Role()
    r.role_name = "fake_role"
    p.roles = [r]

    # Create fake handler block
    fake_handler = Block()
    fake_handler.block = [{'fake_handler': 'fake_task'}]
    r.handlers = [fake_handler] # Add fake handler block to fake role

    # Get list of handler blocks, to compare to the expected one
    handler_blocks = p.compile_roles_handlers()

    # Assert that 'fake_handler' is a handler block in the returned handler_blocks
    assert handler_blocks[0].block[0]['fake_handler'] == 'fake_task'


# Generated at 2022-06-11 10:23:45.771939
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert True

# Generated at 2022-06-11 10:23:55.005374
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_handler = 'name: test handler\nnotify:\n- test\n'
    test_role = '- role: handler_test\n'
    test_meta = '---\n- name: test play\nhosts: localhost\nroles:\n%s' % test_role
    try:
        p = Play().load(data=test_meta, variable_manager=VariableManager(), loader=DictDataLoader())
        handlers = p.compile_roles_handlers()
        assert handlers
        for h in handlers:
            assert h.serialize() == test_handler
    except Exception as e:
        raise(e)



# Generated at 2022-06-11 10:23:57.128075
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.name = "test_play" 
    play.hosts = "localhost.localdomain"
    play.roles = [{"role": "test_role"}]

    if len(play._compile_roles()) != 0:
        raise AssertionError


# Generated at 2022-06-11 10:24:07.637209
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({
        'name': 'test play',
        'hosts': 'localhost',
        'roles': [{
            'name': 'test role',
            'hosts': 'localhost',
            'tasks': [x.serialize() for x in get_test_tasks()],
        }],
    })
    assert p.get_name() == 'test play'
    assert p.hosts == 'localhost'
    assert p.name == 'test play'
    assert len(p.roles) == 1
    assert p.roles[0].name == 'test role'
    assert len(p.roles[0].tasks) == 3


# Generated at 2022-06-11 10:24:18.065040
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from collections import namedtuple
    p = Play()
    p._variable_manager = namedtuple('VariableManager', 'extra_vars hostvars')
    t = Task()
    t.block = [t]
    t.role = RoleDefinition()
    p.tasks = [t]
    b = Block()
    b.block = [t]
    b.rescue = [t]
    b.always = [t]
    p.pre_tasks = [b]
    p.post_tasks

# Generated at 2022-06-11 10:24:52.761017
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data({'user': 'x', 'remote_user': 'y'})
    assert(play.remote_user == 'y')
    assert(not hasattr(play, 'user'))
    play.preprocess_data({'user': 'x'})
    assert(play.remote_user == 'x')
    assert(not hasattr(play, 'user'))


# Generated at 2022-06-11 10:24:58.014557
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p._ds = "test"
    p.vars_files = "test"
    assert p.get_vars_files() == ["test"]
    p.vars_files = ["test"]
    assert p.get_vars_files() == ["test"]
    p.vars_files = None
    assert p.get_vars_files() == []

# Generated at 2022-06-11 10:25:11.240465
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    config = ConfigParser.ConfigParser()
    config.read('ansible.cfg')
    # initialize needed objects
    playbook = Playbook.load('test_playbook.yml', variable_manager=VariableManager(), loader=DataLoader())
    play = playbook.get_plays()[0]
    play._loader = DataLoader(config.get('defaults', 'roles_path'))

    # get the result of method
    results = play.compile_roles_handlers()
    print("*** Method: compile_roles_handlers of class Play *************")
    print("*** expect the result to be:")
    print("*** [{'name': 'failures', 'listen': 'failure', 'block': [{'include': 'failure_handlers.yml'}]}]")

# Generated at 2022-06-11 10:25:19.962552
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # """
    # Test injecting vars into the play data structure
    # """
    ds = {
        'roles': [],
        'vars': {
            'key1': 'value1',
            'key2': 'value2'
        }
    }
    p = Play()
    p.preprocess_data(ds)
    assert ds == {
        'roles': [],
        'vars': {
            'key1': 'value1',
            'key2': 'value2'
        }
    }



# Generated at 2022-06-11 10:25:28.902368
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Tests get_tasks method
    play_ = Play()
    play_.set_loader(DictDataLoader({}))
    play_.set_variable_manager(VariableManager())
    play_.set_variable_manager(VariableManager())
    play_.set_variable_manager(VariableManager())
    play_.tasks = []
    
    play_.vars = dict()
    play_.vars_prompt = []
    play_.handlers = []
    play_.roles = []
    play_.post_tasks = []
    play_.pre_tasks = []
    play_.default_vars = dict()
    
    play_.set_loader(DictDataLoader({}))
    play_.set_variable_manager(VariableManager())
    play_.set_variable_manager(VariableManager())

# Generated at 2022-06-11 10:25:30.717189
# Unit test for method get_name of class Play
def test_Play_get_name():
    result = Play().get_name()
    assert result


# Generated at 2022-06-11 10:25:33.909762
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    expected_obj= Play()
    actual_obj= Play()
    assert expected_obj.get_tasks() == actual_obj.get_tasks()
    
    

# Generated at 2022-06-11 10:25:34.559662
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    assert True

# Generated at 2022-06-11 10:25:36.156130
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass

# Generated at 2022-06-11 10:25:42.868984
# Unit test for method get_name of class Play
def test_Play_get_name():
    pl = Play()
    pl.name = "somename"
    assert pl.get_name() == "somename"
    pl.hosts = ['host1', 'host2']
    assert pl.get_name() == "host1,host2"
    pl.name = None
    assert pl.get_name() == "host1,host2"


# Generated at 2022-06-11 10:27:18.534561
# Unit test for method get_name of class Play
def test_Play_get_name():
    import pytest
    from collections import defaultdict
    from units_play import Play
    play = Play()
    assert play._ds == {}
    play._ds = {'hosts': 'test_host',
                'tasks': [{'action': {'module': 'command', 'arguments': {'_raw_params': 'ls', '_uses_shell': False}, 'index': 0},
                           'name': 'test_name'}]}
    assert play.get_name() == 'test_host'
    play._ds = {'hosts': 'test_host',
                'tasks': [{'action': {'module': 'command', 'arguments': {'_raw_params': 'ls', '_uses_shell': False}, 'index': 0},
                           'name': 'test_name'}]}

# Generated at 2022-06-11 10:27:22.864403
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    theplay = Play()
    theplay.pre_tasks = ['first']
    theplay.post_tasks = ['fifth']
    theplay.tasks = ['second', 'third', 'fourth']
    result = theplay.get_tasks()
    expected = ['first', 'second', 'third', 'fourth', 'fifth']
    assert expected == result

# Generated at 2022-06-11 10:27:28.346812
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Test data
    a = Play()
    a.load({"name": "test",
            "hosts": "local",
            "tasks": [{"debug": "msg=bar"}],
            "handlers": [{"debug": "msg=bar"}]})
    test_list = a.get_tasks()
    assert len(test_list) > 0, "test_list should not be empty"



# Generated at 2022-06-11 10:27:30.148846
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'play_name'
    assert p.get_name() == 'play_name'
    p.name = None
    p.hosts = 'hosts_name'
    assert p.get_name() == 'hosts_name'


# Generated at 2022-06-11 10:27:31.163930
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass


# Generated at 2022-06-11 10:27:40.550275
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # assert the method returns an empty set (not None)
    # if the list of variables files is None
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []

    # assert the method returns a list of one variable file
    # if the list of variable files contains only one variable file
    play = Play()
    vars_files = "./my_variable_file.yaml" # a string to represent a variable file
    play.vars_files = vars_files
    assert play.get_vars_files() == [vars_files]

    # assert the method returns a list of variable files
    # if the list of variable files contains many variables files
    play = Play()

# Generated at 2022-06-11 10:27:51.282114
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play1 = Play()
    play1.pre_tasks = [Block(), Block()]
    play1.tasks = [Block(), Block()]
    play1.post_tasks = [Block(), Block()]
    for task in play1.pre_tasks + play1.tasks + play1.post_tasks:
        task.block = [Task(), Task()]
        task.rescue = [Block(), Block()]
        task.always = [Block(), Block()]

# Generated at 2022-06-11 10:27:57.001175
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [{'block': [{'debug': 'msg=foo'}]}, {'debug': 'msg=bar'}]

    tasks = p.get_tasks()
    assert len(tasks) == 2
    assert len(tasks[0]) == 1
    assert tasks[0][0].action == 'debug'
    assert tasks[1].action == 'debug'



# Generated at 2022-06-11 10:28:04.280288
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Default testcase
    pt = Play()
    pt.vars_files = None
    assert pt.get_vars_files() == []

    # vars_files is string
    pt = Play()
    pt.vars_files = 'a.yml'
    assert pt.get_vars_files() == ['a.yml']

    # vars_files is list
    pt = Play()
    pt.vars_files = ['a.yml', 'b.yml']
    assert pt.get_vars_files() == ['a.yml', 'b.yml']

