

# Generated at 2022-06-11 10:18:23.200592
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    assert p.get_name() ==  ''
    p.name = 'name'
    assert p.get_name() == 'name'
    p.name = None
    p.hosts = 'localhost'
    assert p.get_name() == 'localhost'
    p.hosts = ['localhost', '127.0.0.1']
    assert p.get_name() == 'localhost,127.0.0.1'



# Generated at 2022-06-11 10:18:27.544156
# Unit test for method deserialize of class Play
def test_Play_deserialize():
  # unit-test belongs here
  # more info on how to use unittest
  # https://docs.python.org/2/library/unittest.html
  import pprint
  test_data = {"_ds": {"roles": [{"role": "credentials"}], "gather_facts": "smart", "vars": {"domain": "test.local", "daemon_user":"testuser"}, "serial": ["all"]}, "_deprecated_messages": [], "_handlers": [], "_pre_tasks": [], "_post_tasks": [], "_tasks": []}
  o = Play()
  o.deserialize(test_data)
  pprint.pprint(o.roles)


# Generated at 2022-06-11 10:18:33.590848
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansiblelint import Runner, RulesCollection
    from ansiblelint.rules.MetaMainHasRole import MetaMainHasRole
    from ansiblelint.rules.MetaMainHasTask import MetaMainHasTask
    from ansiblelint.rules.MetaMainIncludesImportTask import MetaMainIncludesImportTask
    from ansiblelint.rules.MetaMainIncludesImportRole import MetaMainIncludesImportRole
    from ansiblelint.rules.TaskHasName import TaskHasName

    rulesdir = 'test/hacking/rules'
    good_playbook = 'test/hacking/meta-main/meta-main-good.yml'
    runner = Runner(rulesdir, [], [], [], [])
    rules = RulesCollection.create_from_directory(rulesdir)
    rule = MetaMainHasTask(runner)

# Generated at 2022-06-11 10:18:45.669817
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # setup
    r1 = Role()
    r1.name = "test_role_1"
    r2 = Role()
    r2.name = "test_role_2"
    role_list = [r1, r2]
    handlers = [Handler.load(dict(
        name="test_handler_1",
        tasks=[dict(name="test_task_1", action=dict(module="dummy"))]
        ), play=None),
        Handler.load(dict(
            name="test_handler_2",
            tasks=[dict(name="test_task_2", action=dict(module="dummy"))]
        ), play=None)
    ]
    r1.handlers = handlers
    r2.handlers = handlers
    # test
    p = Play()
    p.roles = role_

# Generated at 2022-06-11 10:18:51.661968
# Unit test for method get_name of class Play
def test_Play_get_name():
    play1 = Play.load(dict(name='test play1'), variable_manager=variable_manager, loader=loader)
    assert play1.get_name() == 'test play1'

    play2 = Play.load(dict(hosts='test host'), variable_manager=variable_manager, loader=loader)
    assert play2.get_name() == 'test host'

    play3 = Play.load(dict(hosts=['test host', 'abc']), variable_manager=variable_manager, loader=loader)
    assert play3.get_name() == 'test host,abc'



# Generated at 2022-06-11 10:19:04.697231
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    #Test with ds = None (should return nothing)
    data = None
    new_object = Play()
    new_object.deserialize(data)
    assert new_object.roles == []

    #Test with ds = {} (should return nothing)
    data = {}
    new_object = Play()
    new_object.deserialize(data)
    assert new_object.roles == []

    #Test with ds = {'roles': None} (should return nothing)
    data = {'roles': None}
    new_object = Play()
    new_object.deserialize(data)
    assert new_object.roles == []

    #Test with ds = {'roles': []} (should return nothing)
    data = {'roles': []}
    new_object = Play

# Generated at 2022-06-11 10:19:15.873996
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
        if not os.path.isdir("test_data"):
            raise AnsibleError("test_data is missing.  It is needed for unit tests.")
        os.chdir("test_data")
        if not os.path.isdir("test_play"):
            raise AnsibleError("test_play is missing.  It is needed for unit tests.")

        p = Play.load("test_play/playbooks/test_play.yml", variable_manager=None, loader=None)
        print("\n\n\n\n")
        print("test_Play_compile_roles_handlers")
        print("\n\n\n\n")
        p.compile_roles_handlers()


# Generated at 2022-06-11 10:19:18.244946
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "foobar"
    result = play.get_name()
    assert result == "foobar"


# Generated at 2022-06-11 10:19:25.443217
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Create Play object
    play = Play()
    play.deserialize({
        "name": "test",
        "removed_hosts": [],
        "vars_files": "abc.yml"
    })
    assert play.get_vars_files() == ['abc.yml']


# Generated at 2022-06-11 10:19:30.838085
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test_play'
    assert play.get_name() == 'test_play'
    play.name = 'test2_play'
    assert play.get_name() == 'test2_play'


# Generated at 2022-06-11 10:19:49.070986
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-11 10:19:59.457192
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers() == []

    r1 = Role()
    r1.name= 'test'
    r1.path= '/test'
    p.roles.append(r1)
    assert p.compile_roles_handlers() == []

    b1 = Block()
    b1.only_if = 'test'
    h1 = Handler()
    h1.name = 'test'

    b1.block = [h1]
    r1.handlers.append(b1)
    result = p.compile_roles_handlers()
    assert isinstance(result[0], Block)
    assert isinstance(result[0].block[0], Handler)
    assert result[0].block[0].name == 'test'

# Unit

# Generated at 2022-06-11 10:20:09.727246
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    #
    # Ensure that get_tasks returns a list of tasks.

    # Create an instance of Play without any attributes set since the method
    # we are testing is not dependant upon these.
    play_instance = Play()
    pre_tasks = study_Block()
    tasks = study_Block()
    post_tasks = study_Block()
    play_instance.pre_tasks = pre_tasks
    play_instance.tasks = tasks
    play_instance.post_tasks = post_tasks
    result = play_instance.get_tasks()
    expected = pre_tasks + tasks + post_tasks
    assert result == expected

# Generated at 2022-06-11 10:20:17.968940
# Unit test for method deserialize of class Play

# Generated at 2022-06-11 10:20:29.496299
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Since the actual test scenario is bit complicated, we will test the result
    # of get_tasks method against a certain value that we want to see.
    data = {
        'name': 'test play',
        'hosts': ['127.0.0.1'],
        'vars': {},
        'roles': [],
        'pre_tasks': [
            {
                'meta': 'flush_handlers'
            }
        ],
        'tasks': [
            [
                {'debug': {'msg': 'this is task 1'}},
                {'debug': {'msg': 'this is task 2'}}
            ]
        ],
        'post_tasks': [
            {
                'meta': 'flush_handlers'
            }
        ]
    }

# Generated at 2022-06-11 10:20:39.842355
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    get_loader = lambda : DictDataLoader({
        "test_playbook.yaml": dedent(
            """
            - hosts: localhost
              gather_facts: false
              tasks:
                - name: task 1
                  debug:
                    msg: task 1
                - name: task 2
                  debug:
                    msg: task 2
                - name: task 3
                  debug:
                    msg: task 3
            """
        )
    })
    pb_data = load_data_from_file('test_playbook.yaml', get_loader)
    # The playbook to test contains only one play, so we will just test that one
    p = Play()
    p.deserialize(pb_data[0])
    # Get tasks
    tasklist = p.get_tasks()
    # Verify number of tasks
   

# Generated at 2022-06-11 10:20:44.354737
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Dummy Role definition
    def fake_Role():
        class FakeRole(Role):
            def __init__(s):
                s.get_handler_blocks = mock.MagicMock(return_value=[])
        return FakeRole()

    # Create play
    p = Play()
    p.roles = [fake_Role() for _ in range(5)]
    compiled_handlers = p.compile_roles_handlers()
    assert p.roles[0].get_handler_blocks.called
    assert p.roles[1].get_handler_blocks.called
    assert p.roles[2].get_handler_blocks.called
    assert p.roles[3].get_handler_blocks.called
    assert p.roles[4].get_handler_blocks.called

# Generated at 2022-06-11 10:20:49.181985
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    assert p.get_tasks() == []

    p = Play.load(dict(tasks=[dict(meta="flush_handlers")]))
    assert p.get_tasks() == [[dict(meta="flush_handlers")]]

# Generated at 2022-06-11 10:21:00.696252
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play_obj = Play()
    data = {
            'action_groups': {'group': ['action']},
            'group_actions': {'action': ['group1', 'group2']},
            'roles': [{'_role_params': {}, '_search_paths': ['roles'], 'name': 'roles_name'}],
            'name': 'play_name'
            }
    play_obj.deserialize(data)

    assert(play_obj._action_groups == {'group': ['action']})
    assert(play_obj._group_actions == {'action': ['group1', 'group2']})
    assert(play_obj._name == 'play_name')
    assert(play_obj.get_roles()[0].name == 'roles_name')


# Unit

# Generated at 2022-06-11 10:21:06.434153
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    ds = {'a': 'b', 'b': 'c'}

    # tests the scenario when ds passed in is a dict
    result = Play.preprocess_data(None, ds)
    assert result == ds
    assert isinstance(result, dict)

    # tests the scenario when ds passed in is a null
    result = Play.preprocess_data(None, None)
    assert result == {}
    assert isinstance(result, dict)


# Generated at 2022-06-11 10:21:27.648648
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansiblelint import RulesCollection, Runner
    from ansiblelint.rules.UseShellInsteadOfCommandRule import UseShellInsteadOfCommandRule
    from ansiblelint.runner import Runner

    rulesdir = 'test/'

    # Tests Play.get_name
    collection = RulesCollection()
    collection.register(UseShellInsteadOfCommandRule())
    runner = Runner(collection, 'test/playbook.yml', ['--exclude', 'test/roles/nosharedir'], ['test/'], [])
    runner.run()
    success = True
    for play in runner.plays:
        if play.get_name() != 'PLAY [all]':
            success = False
    assert success

    # Tests Play.get_name
    collection = RulesCollection()
    collection.register(UseShellInsteadOfCommandRule())


# Generated at 2022-06-11 10:21:28.891356
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass


# Generated at 2022-06-11 10:21:38.688991
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test case data
    roles = ['foo']
    for role in roles:
        role = Role.load(role)
    play = Play()
    play.roles = roles

    # We need to mock role object of the role class
    mocked_role_obj = create_autospec(Role)
    mocked_role_obj.get_handler_blocks.return_value = True

    # We also need to mock play object of the play class
    mocked_play_obj = create_autospec(Play)
    mocked_play_obj.roles = [mocked_role_obj]

    # Mock play.compile_roles_handlers()

# Generated at 2022-06-11 10:21:50.722396
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.hosts = 'hosts'
    play.name = 'name'
    play.connection = 'connection'
    play.gather_facts = 'gather_facts'
    play.vars_files = 'vars_files'
    play.vars_prompt = 'vars_prompt'
    play.vars = 'vars'
    play.some_attr = 'some_attr'
    play.port = 'port'
    play.remote_user = 'remote_user'
    play.remote_pass = 'remote_pass'
    play.sudo = 'sudo'
    play.sudo_user = 'sudo_user'
    play.transport = 'transport'
    play.tags = 'tags'
    play.skip_tags = 'skip_tags'

# Generated at 2022-06-11 10:21:54.235974
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name= 'ansible'
    assert play.get_name() == 'ansible', "play is not initialized correctly"


# Generated at 2022-06-11 10:22:01.877258
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars
    pb = Play()
    v = {
        'gather_facts': True
    }
    t = Task()
    t.preprocess_data(v)
    data = {
        'hosts': '127.0.0.1',
        'gather_facts': True
    }
    pb.preprocess_data(data)
    assert t.action == 'setup'
    assert t.gather_facts == True
    assert pb.gather_facts == True

    v = {
        'gather_facts': False
    }
    t.preprocess_data(v)
    assert t.action == 'setup'


# Generated at 2022-06-11 10:22:13.393495
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    t1 = Task()
    t2 = Task()
    t1.set_loader({})
    t2.set_loader({})
    t1.set_variable_manager({})
    t2.set_variable_manager({})
    p.tasks = [t1, t2]
    assert p.get_tasks() == [t1, t2]

    tb = Block()
    t1 = Task()
    t2 = Task()
    t1.set_loader({})
    t2.set_loader({})
    t1.set_variable_manager({})
    t2.set_variable_manager({})
    tb.block = [t1, t2]
    tb.rescue = []
    tb.always = []

# Generated at 2022-06-11 10:22:24.259920
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    import mock
    import os
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.path import unfrackpath
    import ansible.constants as C
    import sys

    #TODO: Finish this unittest
    ds = {'hosts': 'localhost', 'vars': {}}
    def _unfrackpath(path, follow=True):
        path = unfrackpath(path, follow)

# Generated at 2022-06-11 10:22:34.217286
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    ds = dict(name='test', hosts='all', remote_user='ansible', user='ansible')
    new_ds = p.preprocess_data(ds)
    assert new_ds is not ds
    assert 'remote_user' in new_ds
    assert 'user' not in new_ds
    assert new_ds['remote_user'] == 'ansible'

    ds = dict(name='test', hosts='all', remote_user='ansible', user='ansible')
    new_ds = p.preprocess_data(ds)
    assert new_ds is not ds
    assert 'remote_user' in new_ds
    assert 'user' not in new_ds
    assert new_ds['remote_user'] == 'ansible'

TestPlay = Play()

# Generated at 2022-06-11 10:22:37.093659
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Play.preprocess_data(ds) ==> ds
    assert Play()
    # Base.preprocess_data(ds) ==> ds
    assert Base()

# Generated at 2022-06-11 10:22:53.287408
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert [] == p.get_vars_files()
    p.vars_files = '/path/to/file'
    assert ['/path/to/file'] == p.get_vars_files()
    p.vars_files = ['/path/to/file1', '/path/to/file2', '/path/to/file3']
    assert ['/path/to/file1', '/path/to/file2', '/path/to/file3'] == p.get_vars_files()
    p.vars_files = None
    assert [] == p.get_vars_files()


# Generated at 2022-06-11 10:23:04.865950
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    global role_1_name, role_1_handlers, role_1_meta_main, role_1_meta_main_action, \
    role_1_tasks, role_1_meta_file, role_1_meta_main_name

    global role_2_name, role_2_tasks, role_2_meta_main, role_2_meta_main_name

    role_1_name = 'role_1'
    role_1_handlers = {'handlers': [],
                       'meta_file': 'meta/main.yml',
                       'meta_main_action': {},
                       'meta_main_name': 'main',
                       'meta_main': {},
                       'tasks': []}


# Generated at 2022-06-11 10:23:08.700444
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    with pytest.raises(TypeError) as e:
        Play.get_vars_files()
    assert str(e.value) == "get_vars_files() missing 1 required positional argument: 'self'"


# Generated at 2022-06-11 10:23:14.860996
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Init
    p = Play()
    p.pre_tasks = [1]
    p.tasks = [2]
    p.post_tasks = [3]
    # Run
    tasklist = p.get_tasks()
    # Assert
    assert isinstance(tasklist, list)
    assert len(tasklist) == 3


# Generated at 2022-06-11 10:23:24.877919
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    def impl(ds):
        p = Play()
        p.preprocess_data(ds)

    # Check that preprocess_data correctly changes a 'user' key
    # to a 'remote_user' key
    ds1 = {'user': 'root'}
    expected1 = {'remote_user': 'root'}
    impl(ds1)
    assert (ds1 == expected1)

    # Check that preprocess_data fails if 'user' and 'remote_user' are both
    # specified
    ds2 = {'user': 'root', 'remote_user': 'bob'}
    with pytest.raises(AnsibleParserError) as ei:
        impl(ds2)
    e = ei.value
    # Make sure the exception message is correct

# Generated at 2022-06-11 10:23:37.228860
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    task = Task()
    task1 = Task()
    task3 = Task()
    task5 = Task()
    task7 = Task()
    task9 = Task()
    task11 = Task()

    task.block = []
    task.rescue = []
    task.always = []
    task_list = [task]
    task_list1 = [task1]
    task_list3 = [task3]
    task_list5 = [task5]
    task_list11 = [task11]

    block1 = Block()
    block3 = Block()
    block5 = Block()
    block7 = Block()
    block9 = Block()
    block11 = Block()

    block1.block = task_list1
    block1.rescue = []
    block1.always = []

# Generated at 2022-06-11 10:23:37.999022
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-11 10:23:46.617079
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    fake_ds_list = [{'name': 'first_fake_name', 'tasks': [{'name': 'fake_task', 'action': 'fake_action'}]}]
    fake_role_list = [Role.load(role_data=fake_ds_list)]
    play = Play.load(data={'hosts': 'localhost', 'roles': fake_role_list}, variable_manager=None, loader=None, vars=None)
    res = play.compile_roles_handlers()
    assert res[0].name == 'first_fake_name'

# Generated at 2022-06-11 10:23:57.784368
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    set_module_args({
        "name": "test_Play_compile_roles_handlers",
        "roles": [
            {
                "role": "test1",
                "tags": ["taga"]
            },
            {
                "role": "test2"
            }
        ]
    })
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-11 10:24:06.646732
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    P = Play(name='test_play')
    # missing user key
    ds = {'hosts': 'localhost'}
    expected = {'hosts': 'localhost', 'remote_user': 'root'}
    assert expected == P.preprocess_data(ds)
    # present user key
    ds = {'hosts': 'localhost', 'user': 'test_user', 'remote_user': 'root'}
    expected = {'hosts': 'localhost', 'remote_user': 'root'}
    assert expected == P.preprocess_data(ds)



# Generated at 2022-06-11 10:24:25.322722
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import os
    from collections import namedtuple
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    Options = namedtuple('Options',
                         ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check',
                          'diff'])
    options = Options(connection='local', module_path=['/to/mymodules'], forks=10, become=None, become_method=None,
                      become_user=None, check=False, diff=False)
    loader = DataLoader() # Takes care of finding and reading yaml, json and ini files

# Generated at 2022-06-11 10:24:30.959437
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    files = [u'/etc/ansible/group_vars/all.yml', u'/etc/ansible/group_vars/proxy.yml']
    assert play.get_vars_files() == []
    play._ds = {u'vars_files': files}
    assert play.get_vars_files() == files


# Generated at 2022-06-11 10:24:39.538505
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.remote_user == 'default_remote_user'
    assert p.connection == C.DEFAULT_TRANSPORT
    assert p.connection == 'default_connection'
    assert p.become is False
    assert p.become is not True
    assert p.become_user == C.DEFAULT_BECOME_USER
    assert p.become_user == 'default_become_user'
    assert p.become_method == C.DEFAULT_BECOME_METHOD
    assert p.become_method == 'default_become_method'
    assert p.sudo is False
    assert p.sudo is not True
    assert p.sudo_user == C.DEFAULT_SUDO_USER


# Generated at 2022-06-11 10:24:41.488994
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    a = Play()
    for task in a.get_tasks():
        print(task)


# Generated at 2022-06-11 10:24:48.849811
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = dict()
    data['name'] = 'test'
    data['id'] = 'play1'
    data['vars'] = dict()
    data['remote_user'] = 'test'
    data['hosts'] = 'server'
    data['roles'] = []
    data['included_path'] = '/etc/ansible/test'
    data['action_groups'] = dict()
    data['group_actions'] = dict()
    play = Play.load(data)
    play.serialize()

# Generated at 2022-06-11 10:24:51.768387
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # preprocess_data return data_structure when data is valid
    assert True



# Generated at 2022-06-11 10:24:56.827856
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    ds = dict(
        name='test_play',
        hosts='localhost',
        become='True',
        become_user='root',
        roles=None,
        vars=dict(
            a=1
        )
    )
    play.load_data(ds)
    print(play.serialize())


# Generated at 2022-06-11 10:25:10.212799
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.plugins.callback import CallbackBase, callbacks
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess

    class ResultCallback(CallbackBase):
        def __init__(self):
            self.host_ok = {}
            self.host_unreachable = {}
            self.host_failed = {}

        def v2_runner_on_unreachable(self, result):
            host = result._host.get_name()
            self.host_unreach

# Generated at 2022-06-11 10:25:22.367921
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # We don't have a Bunch object so just create one
    bunch = type('Bunch', (object,), {})

    # Create an instance of Play
    play = Play()

    # Create ds
    ds = [
        bunch(
            handlers=[],
            name='role1',
            file_args={},
            vars=None,
            role=None,
            parent_role=None,
            from_include=False
        )
    ]

    # Add roles to play
    play._roles = ds

    # We should now have two roles
    assert len(play.roles) == 1

    # Check that the expected call is being made

# Generated at 2022-06-11 10:25:24.564251
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []

# Generated at 2022-06-11 10:25:44.740240
# Unit test for method get_name of class Play
def test_Play_get_name():
    class TestAnsibleModule(object):
        def __init__(self, argument_spec=dict(), bypass_checks=False, no_log=False, check_invalid_arguments=True, mutually_exclusive=None, required_together=None, required_one_of=None, add_file_common_args=False, supports_check_mode=False):
            pass
    module = TestAnsibleModule()
    play = Play()
    play._loader = DictDataLoader({})
    play.ROLE_CACHE = {}
    play._included_conditional = None
    play._included_path = None
    play._removed_hosts = []
    play.only_tags = set(context.CLIARGS.get('tags', [])) or frozenset(('all',))
    play.skip_tags

# Generated at 2022-06-11 10:25:50.200672
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play.load(
        data={'name': 'test', 'hosts': 'all'},
        variable_manager=VariableManager(),
        loader=None,
    )
    ds = p.serialize()
    assert 'name' in ds
    assert ds['name'] == 'test'

    assert 'hosts' in ds
    assert ds['hosts'] == 'all'

    assert ds['included_path'] is None



# Generated at 2022-06-11 10:25:54.195923
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play._ds = {'hosts': 'localhost', 'name': 'test', 'roles': ['test']}
    play.preprocess_data(play._ds)
    assert play.hosts != 'localhost', "Value of attribute hosts should not be 'localhost'"


# Generated at 2022-06-11 10:25:59.314605
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    ds = dict(name="test")
    ds1 = play.preprocess_data(ds)

    play2 = Play()
    ds2 = {}
    ds3 = play2.preprocess_data(ds2)

    assert ds1 is not None
    assert ds3 is not None

# Generated at 2022-06-11 10:26:11.525106
# Unit test for method get_name of class Play
def test_Play_get_name():
    import sys
    import collections
    import itertools
    import copy
    import ansible.parsing.yaml.objects
    import ansible.template
    import ansible.cli
    import ansible.cli.arguments
    import ansible.utils.display
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    import ansible.constants as C
    import ansible.errors
    import ansible.playbook.block
    import ansible.playbook.helpers
    import ansible.playbook.included_file
    import ansible.playbook.role
    import ansible.playbook.role.requirement
    import ansible.playbook.taggable
    import ansible.playbook.task
    import ansible.playbook.role.task
    import ansible

# Generated at 2022-06-11 10:26:18.854148
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    Play_obj = Play()
    Play_obj.roles = [{"ROLE_obj": "ROLE_obj"}, {"ROLE_obj": "ROLE_obj"}]
    Play_obj._group_actions = {"_group": [{"action_str": "action_str"}]}
    ret_val = Play_obj.compile_roles_handlers()
    if ret_val:
        print("PASSED: Got {} as ret_val from the method compile_roles_handlers of class Play.\n".format(ret_val))
    else:
        print("FAILED: No value returned from the method compile_roles_handlers of class Play.\n")


# Generated at 2022-06-11 10:26:27.577711
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    tasks1 = [
    {'name':'t1.1'},
    {'name':'t1.2'},
    {'name':'t1.3'},
    {'name':'t1.4'},
    {'name':'t1.5'}
    ]
    tasks2 = [
    {'name':'t2.1'},
    {'name':'t2.2'},
    {'name':'t2.3'},
    {'name':'t2.4'},
    {'name':'t2.5'}
    ]

# Generated at 2022-06-11 10:26:33.902369
# Unit test for method serialize of class Play
def test_Play_serialize():

    fake_vars_files = ['C:\\Ansible\\Projects\\test_1/test_2/test_3/test_4.yml', 'C:\\Ansible\\Projects\\test_1/test_2/test_3/test_5.yml']

    play = Play()
    play.vars_files = fake_vars_files

    serialize_data = play.serialize()

    assert "vars_files" in serialize_data
    assert serialize_data["vars_files"] == fake_vars_files


# Generated at 2022-06-11 10:26:35.975100
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
# Tests the methods get_tasks.
#
# :returns: None
# :rtype: None
    pass




# Generated at 2022-06-11 10:26:46.215367
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible import constants as C

    from units.mock.path import mock_unfrackpath_noop, mock_unfrackpath_success
    from units.mock.loader import DictDataLoader

    mock_loader = DictDataLoader({
        u'live-hosts-group': u'''
---
- hosts: localhost
  become: false
  tasks:
  - debug: var=hostvars[inventory_hostname]
        '''
    })

    test_play_ds = {
        u'name': u'Ansible Play',
        u'hosts': u'localhost',
        u'connection': u'local',
        u'tasks': [
            {u'include': u'live-hosts-group'},
        ]
    }


# Generated at 2022-06-11 10:27:05.663182
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pl = Play()
    pl.vars_files = [{"vars_file": "file"}]
    assert pl.get_vars_files() == [{'vars_file': 'file'}]


# Generated at 2022-06-11 10:27:12.519958
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Instantiate a play object
    p = Play()
    # Creating a block object
    block = Block()
    # Creating List of Tasks without Meta tasks
    t1 = Task()
    t1.action = 'shell'
    t1.args = {'_raw_params': 'ls -l'}
    t2 = Task()
    t2.action = 'shell'
    t2.args = {'_raw_params': 'whoami'}
    t3 = Task()
    t3.action = 'shell'
    t3.args = {'_raw_params': 'pwd'}
    
    # Adding tasks to block
    block.block = [t1, t2, t3]
    # Creating a Task object with Meta Task
    t = Task()
    t.action = 'meta'
    t

# Generated at 2022-06-11 10:27:21.891875
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.name = 'test_play'
    play.vars_files = ['test/file']
    play.vars_prompt=['test/prompt']
    play.vars=['test/vars']
    play.tags=['test/tags']
    play.handlers=['test/handlers']
    play.hosts=['test/hosts']
    play.max_fail_percentage=['test/max_fail_percentage']
    play.serial=['test/serial']
    play.strategy=['test/strategy']
    play.order=['test/order']
    play.roles=['test/roles']
    play.tasks=['test/tasks']
    play.pre_tasks=['test/pre_tasks']

# Generated at 2022-06-11 10:27:31.705651
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    fail = False
    hostname = 'dummyhost'
    port = '22'
    username = 'dummyuser'
    password = 'dummyuser'
    # set up a connection to the host
    connection = Connection(host=hostname, port=port, user=username, password=password)

    # Add variables for test playbook
    variable_manager= VariableManager()
    variable_manager.extra_vars={'ansible_ssh_user': username, 'ansible_ssh_pass': password, 'ansible_ssh_host': hostname, 'ansible_ssh_port': port}
    loader = DataLoader()
    options = Options()
    options.connection = 'local'
    options.module_path = 'C:/Python27/lib/site-packages/ansible/modules'
    options.connection_plugins = 'local'

# Generated at 2022-06-11 10:27:34.523212
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = []
    p.post_tasks = []
    p.tasks = [1]
    assert p.get_tasks() == [1]


# Generated at 2022-06-11 10:27:41.278654
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
   play_obj = Play()
   play_obj.vars_files = "Sample_var_file"
   assert play_obj.get_vars_files() == ["Sample_var_file"]
   play_obj.vars_files = ["Sample_var_file_1","Sample_var_file_2"]
   assert play_obj.get_vars_files() == ["Sample_var_file_1","Sample_var_file_2"]
   play_obj.vars_files = None
   assert play_obj.get_vars_files() == []

# Generated at 2022-06-11 10:27:49.187517
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    task5 = Task()
    task6 = Task()
    task7 = Task()

    play = Play()

    play._pre_tasks = [task1, task2]
    play._tasks = [task3]
    play._post_tasks = [task4, task5, task6]

    play.handlers = [task7]

    assert play.get_tasks() == [task1, task2, task3, task4, task5, task6]

# Generated at 2022-06-11 10:27:51.978993
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test with an incorrect instantiation
    my_play = Play()
    assert my_play.compile_roles_handlers() is None


# Generated at 2022-06-11 10:28:01.674778
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()

    # If there are no roles, return empty list
    assert p.compile_roles_handlers() == []

    # If there is one role, return a list of handlers from that role
    role = Role()
    block = Block()
    task = Task()

    task.name = ''
    block.block = [task]
    block.rescue = []
    block.always = []

    role.handlers = [block]
    p.roles = [role]

    assert p.compile_roles_handlers() == [block]

    # If there are two roles, return a list of handlers from both roles
    role_1 = Role()
    block_1 = Block()
    task_1 = Task()

    task_1.name = ''

# Generated at 2022-06-11 10:28:07.636275
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []
    play.roles = [Role()]
    reset_loader()
    role = play.roles[0]
    role = {"role": "foo",
            "tasks": [{"name": "hello foo"}, {"include": {"role": "bar"}}],
            "handlers": [{"name": "hello foo handler"},
                         {"include": {"role": "blah"}}]}
    role.get_handler_blocks(play=play)