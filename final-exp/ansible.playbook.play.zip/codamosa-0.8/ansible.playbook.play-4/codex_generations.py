

# Generated at 2022-06-11 10:18:42.541301
# Unit test for method deserialize of class Play

# Generated at 2022-06-11 10:18:49.772368
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create a Play class object
    p = Play()
    # Set the values of its attribute pre_tasks
    p.pre_tasks = ["pre1", "pre2"]
    # Set the values of its attribute tasks
    p.tasks = ["t1", "t2"]
    # Set the values of its attribute post_tasks
    p.post_tasks = ["post1", "post2"]
    assert p.get_tasks() == ["pre1", "pre2", "t1", "t2", "post1", "post2"]


# Generated at 2022-06-11 10:18:56.803998
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''Play.get_vars_files()'''
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'foo'
    assert p.get_vars_files() == ['foo']
    p.vars_files = ['foo', 'bar']
    assert p.get_vars_files() == ['foo', 'bar']

# Generated at 2022-06-11 10:19:09.584572
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_ds = [{
        u'name': u'all',
        u'hosts': u'all',
        u'gather_facts': u'no',
        u'tasks': [{
            u'name': u'Gather Facts',
            u'action': {
                u'module': u'set_fact',
                u'args': {
                    u'ansible_facts': {
                        u'disk_sda_size': u'50G'
                    }
            }
        },
    }]}
    ]
    play = Play()
    play.load(data=play_ds, variable_manager=VariableManager(), loader=DataLoader())
    tasks = play.get_tasks()
    assert len(tasks) == 1
    assert tasks[0].get_name() == u'Gather Facts'

# Generated at 2022-06-11 10:19:10.768073
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pass


# Generated at 2022-06-11 10:19:18.369587
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['/etc/ansible/file1', '/etc/ansible/file2']

    assert play.get_vars_files() == ['/etc/ansible/file1', '/etc/ansible/file2']

    play.vars_files = '/etc/ansible/file1'
    assert play.get_vars_files() == ['/etc/ansible/file1']

    play.vars_files = None
    assert play.get_vars_files() == []


# Generated at 2022-06-11 10:19:32.605489
# Unit test for constructor of class Play
def test_Play():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop, mock_unfrackpath_fails
    from units.mock.vars import MockVarsModule

    test_loader = DictDataLoader({
        "/path/to/main.yml": """
        - name: Play 1
          hosts: localhost
          gather_facts: no
          serial: 1
        """,
        "/path/to/other.yml": """
        - name: Play 2
          hosts: all
          gather_facts: no
        """
    })
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(host_list=['host1', 'host2']))

# Generated at 2022-06-11 10:19:35.922957
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['vars.yaml', 'playbook.yaml']
    assert play.get_vars_files() == play.vars_files

# Generated at 2022-06-11 10:19:39.883016
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Build test object
    p = Play()
    p.roles = None
    # Test method
    flat_handlers = p.compile_roles_handlers()
    # Assertions
    assert flat_handlers == []
    assert p.roles is None

# Generated at 2022-06-11 10:19:42.103008
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = []
    play.compile_roles_handlers()

# Generated at 2022-06-11 10:20:02.359280
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create an instance of Play
    play1 = Play()

    # Create a datastructure for preprocess
    play1_datastructure = {'hosts': 'all', 'roles': [{'role': 'test_role'}]}
    # Create an instance of AnsibleParserError
    ansible_paser_error = AnsibleParserError()

    # Unit test for preprocess user from a datastructure
    if 'user' in play1_datastructure:
        if 'remote_user' in play1_datastructure:
            # Raise an AnsibleParserError
            raise ansible_paser_error
        else:
            play1_datastructure.update({'remote_user': play1_datastructure['user']})
            del play1_datastructure['user']

# Generated at 2022-06-11 10:20:05.674802
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'


# Generated at 2022-06-11 10:20:12.354213
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ["/tmp/vars_file"]
    assert play.get_vars_files() == ['/tmp/vars_file']

    play = Play()
    play.vars_files = ["/tmp/vars_file1", "/tmp/vars_file2"]
    assert play.get_vars_files() == ['/tmp/vars_file1', '/tmp/vars_file2']


# Generated at 2022-06-11 10:20:19.355094
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import json
    import os
    import pytest
    # I moved the list out of the block, and then into the block,
    # because this is how Ansible currently processes
    # the datastructure.
    # That is, the pre-tasks are in a list,
    # then the tasks are in a list.
    #
    # I also moved the 'tasks' key to the top level.
    # This allows me to use @pytest.fixture(scope='class')
    # to do the entire test.
    # Ansible would probably move this to the top-level
    # as well.
    #
    # I added the 'handlers' key and list,
    # which is what Ansible does.
    # The handlers' list is apparently not listed in any documentation
    # I have found,
    # so this has to

# Generated at 2022-06-11 10:20:28.449298
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    loader = DictDataLoader({})
    variable_manager = VariableManager()

    hosts = ["localhost"]
    roles = [Role({'name':"test"})]

    p = Play({'name':"test",'hosts':hosts, 'roles':roles})

    assert len(p.compile_roles_handlers()) == 0

    roles = [Role({'name':"test", "handlers":{'listen':"test is running"}})]

    p = Play({'name':"test",'hosts':hosts, 'roles':roles})

    assert len(p.compile_roles_handlers()) == 1

# Generated at 2022-06-11 10:20:29.864309
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    print(play.get_name())

# Generated at 2022-06-11 10:20:40.202332
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible import constants as C


# Generated at 2022-06-11 10:20:41.147709
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass


# Generated at 2022-06-11 10:20:47.037071
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()

    play.pre_tasks = [1, 2, 3]
    play.post_tasks = [4, 5, 6]
    play.tasks = [7, 8, 9]

    assert play.get_tasks() == [1, 2, 3, 7, 8, 9, 4, 5, 6]


# Generated at 2022-06-11 10:20:53.066978
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    """
    Test that compile_roles_handlers returns an empty list if there are no roles and returns
    a list of handlers when there are roles

    """
    play = Play()
    assert play.compile_roles_handlers() == []
    play.roles = [Role()]
    assert isinstance(play.compile_roles_handlers(), list)



# Generated at 2022-06-11 10:21:09.748409
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    t1 = Block()
    t2 = Task()
    t3 = Task()
    t3.action = 'copy'
    
    p.pre_tasks.append(t1)
    p.tasks.append(t2)
    p.post_tasks.append(t3)
    
    assert p.get_tasks() == [t1.block + t1.rescue + t1.always, t2, t3]

 

# Generated at 2022-06-11 10:21:12.620366
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.hosts = ['all']
    assert p.get_name() == "all"


# Generated at 2022-06-11 10:21:14.710823
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass
    #play_obj = Play()
    #play_obj.get_tasks()
    #assert True

# Generated at 2022-06-11 10:21:26.163363
# Unit test for method get_name of class Play
def test_Play_get_name():
    # testing method get_name of class Play
    hosts = "127.0.0.1"
    ds = dict(hosts=hosts, name="name_1")
    p = Play()
    p.load_data(data=ds)
    assert p.get_name() == "name_1"
    ds = dict(hosts=hosts, name="")
    p.load_data(data=ds)
    assert p.get_name() == ""
    ds = dict(hosts=hosts)
    p.load_data(data=ds)
    assert p.get_name() == "127.0.0.1"



# Generated at 2022-06-11 10:21:27.884747
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    p = Play()

    ds = {'test1': 'test1', 'test2': 'test2'}

    p._ds=ds

    p.preprocess_data(ds)

    assert p._ds == ds


# Generated at 2022-06-11 10:21:37.357715
# Unit test for constructor of class Play
def test_Play():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    p = Play()
    assert p.name is None
    assert p.hosts == 'all'
    assert len(p.vars) == 0
    assert p.vars_prompt == []
    assert len(p.vars_files) == 0
    assert p.remote_user is None
    assert p.connection is None
    assert len(p.port) == 0
    assert p.gather_facts is True
    assert p.delegate_to is None
    assert isinstance(p.delegate_facts, set)

# Generated at 2022-06-11 10:21:41.710346
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    playbook_vars_files = [ "./testPlay/testPlay.yml", "./testPlay/testVars_Play.json"]
    p = Play()
    p.vars_files = playbook_vars_files
    assert playbook_vars_files == p.get_vars_files()

testPlay()

# Generated at 2022-06-11 10:21:44.781220
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_play = Play()
    test_play.name = "test play"
    assert test_play.get_name() == "test play"



# Generated at 2022-06-11 10:21:57.121804
# Unit test for method get_name of class Play
def test_Play_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block

    playbook = Playbook()
    play = Play.load("""
    - hosts: server1
      tasks:
        - debug: msg="hello world"
    """, variable_manager=playbook._variable_manager, loader=playbook._loader)
    play.post_validate(playbook)
    assert play.get_name() == 'server1'

    play = Play.load("""
    - hosts: server1
      vars_files:
       - path/to/file.yml
      tasks:
        - debug: msg="hello world"
    """, variable_manager=playbook._variable_manager, loader=playbook._loader)
    play.post_valid

# Generated at 2022-06-11 10:21:59.398872
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Create an instance of class Play
    # play_ = Play()
    # play_.load(data, variable_manager=None, loader=None)
    play_.get_tasks()

# Generated at 2022-06-11 10:22:10.688390
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    _play = Play()
    assert _play.deserialize({}) is None

# Generated at 2022-06-11 10:22:21.629573
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import json
    play = Play()
    data = {'roles': [{'vars': {'rvar': 'rvalue'}, 'name': 'role', 'path': '/path/to/roles','tasks':[{'action':{'__ansible_module__':'someModule', 'someArg':'someValue'}}]}], 'vars': {'pvar': 'pvalue'}, 'name': 'play', 'hosts': 'localhost', 'tasks': [{'action': {'__ansible_module__': 'someModule', 'someArg': 'someValue'}}]}
    play.deserialize(data)
    assert play.vars['pvar'] == 'pvalue'
    assert play.roles[0].vars['rvar'] == 'rvalue'

# Generated at 2022-06-11 10:22:23.132653
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = {}
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()
    result = play.load_data(data, variable_manager, loader)
    assert result
    assert play.get_tasks() == []

# Generated at 2022-06-11 10:22:26.616919
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    assert Play.load(dict(user='bob')).get_ds().get('remote_user') == 'bob'
    assert Play.load(dict(remote_user='bob')).get_ds().get('remote_user') == 'bob'



# Generated at 2022-06-11 10:22:30.259110
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = 'vars_file'
    assert p.get_vars_files() == ['vars_file']
    p.vars_files = ['vars_file1', 'vars_file2']
    assert p.get_vars_files() == ['vars_file1', 'vars_file2']

# Generated at 2022-06-11 10:22:34.464338
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    result = p.compile_roles_handlers()
    expected = []
    assert result == expected

    p.roles = [Role()]
    result = p.compile_roles_handlers()
    expected = []
    assert result == expected

# Generated at 2022-06-11 10:22:38.434825
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    _variable_manager=None
    _loader=None
    _tqm=None
    test_instance = Play('', [], _loader, _variable_manager, _tqm)
    assert test_instance.get_vars_files() == []
    

# Generated at 2022-06-11 10:22:49.248358
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handlers.task_handler import TaskHandler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block

    p = Play()
    p.hosts = 'hosts'
    p.name = 'name'
    p.connection = 'connection'
    p.port = 'port'
    p.remote_user = 'remote_user'
    p.become = 'become'
    p.become_method = 'become_method'
    p.become_user = 'become_user'
    p.vars_prompt = 'vars_prompt'

# Generated at 2022-06-11 10:23:00.267987
# Unit test for method serialize of class Play
def test_Play_serialize():
    playbook = Playbook()
    inventory = Inventory()
    variable_manager = VariableManager()
    loader = DataLoader()

    blocks = [{"action": {"__ansible_module__": "command", "__ansible_arguments__": "ls"}}, {"action": {"__ansible_module__": "command", "__ansible_arguments__": "pwd"}}]
    pre_tasks = [{"action": {"__ansible_module__": "command", "__ansible_arguments__": "ls"}}]
    post_tasks = [{"action": {"__ansible_module__": "command", "__ansible_arguments__": "pwd"}}]


# Generated at 2022-06-11 10:23:09.461942
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    class Parser():
        def __init__(self):
            self.args = {}
            self.members = []
    parser = Parser()

    class Role():
        def __init__(self):
            self.name = 'test role'
            self.from_include = False
        def compile(self, play=None):
            return [1, 2]
        def get_handler_blocks(self, play=None):
            return [3]
    role = Role()

    play = Play()
    play._ds = parser
    play.roles = [role]
    assert play.compile_roles_handlers() == [3]

# Generated at 2022-06-11 10:23:21.924051
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_Play_vars_files = Play()
    test_Play_vars_files.vars_files = 'test_Play_vars_files'
    assert test_Play_vars_files.get_vars_files() == 'test_Play_vars_files'



# Generated at 2022-06-11 10:23:24.740966
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Setup
    p = Play()
    # Exercise
    result = p.compile_roles_handlers()
    # Verify
    assert result == []



# Generated at 2022-06-11 10:23:37.001151
# Unit test for method get_name of class Play
def test_Play_get_name():
    import copy
    # Initializing a class object
    p = Play()
    # setter name
    name = 'name'
    p.name = name
    # initializing hosts
    hosts = 'all'
    new_hosts = [hosts]
    p.hosts = hosts
    hosts = new_hosts
    expected_result = hosts[0]
    # getter name
    result = p.get_name()
    # setter hosts
    hosts_new = copy.deepcopy(hosts)
    p.hosts = hosts_new
    expected_result = hosts_new[0]
    # getter hosts
    result = p.get_name()
    # setter name
    name = 'new_name'
    p.name = name
    expected_result = name
    # getter name
    result

# Generated at 2022-06-11 10:23:48.590181
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    #
    # Unit test for method get_vars_files() in class Play
    #
    _play_name = 'play_1'
    _play_hosts = ['host1']
    _play_vars_files = "test_vars_files"

    # create a Play class object
    _play_instance = Play()
    _play_instance.name = _play_name
    _play_instance.hosts = _play_hosts
    _play_instance.vars_files = _play_vars_files

    # Unit test:
    # If vars_files is None, should return an empty list
    _play_instance.vars_files = None
    assert _play_instance.get_vars_files() == []

    # Unit test:
    # If vars_files is a list, should

# Generated at 2022-06-11 10:23:57.852119
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play1 = Play()
    # No vars_files is None
    assert play1.get_vars_files() == []
    play1.vars_files = 'test.yml'
    # vars_files is 'test.yml'
    assert play1.get_vars_files() == ['test.yml']
    play1.vars_files = ['test1.yml', 'test2.yml']
    # vars_files is ['test1.yml', 'test2.yml']
    assert play1.get_vars_files() == ['test1.yml', 'test2.yml']

# Generated at 2022-06-11 10:24:07.772689
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    set_ansible_lib(__file__)
    play = Play.load(dict(
        name='test',
        hosts='localhost',
        vars=dict(
            foo='bar'
        ),
        roles=[
            dict(
                name='test_role',
                handlers=[
                    dict(
                        name='test_handler',
                        action=dict(
                            module='debug'
                        )
                    )
                ]
            )
        ]
    ))
    result = play.compile_roles_handlers()
    assert_equal(len(result), 1)
    assert_equal(result[0].get_name(), 'test_handler')


# Generated at 2022-06-11 10:24:18.272842
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-11 10:24:29.928034
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import os
    import sys
    import unittest

    from collections import namedtuple
    from units.compat import mock

    import ansible
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import plugin_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.utils.path import unfrackpath


# Generated at 2022-06-11 10:24:31.678300
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    result = play.get_name()
    assert result == ''


# Generated at 2022-06-11 10:24:33.697333
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Call method compile_roles_handlers of class Play
    play = Play()
    play.compile_roles_handlers()


# Generated at 2022-06-11 10:25:02.055436
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    def fake_get_handler_blocks(self):
        return [Block(parent_block=self)]

    p = Play()
    p.roles = [Role(parent_block=p)]
    p.roles[0].get_handler_blocks = fake_get_handler_blocks
    p.roles.append(Role(parent_block=p))
    p.roles[1].get_handler_blocks = fake_get_handler_blocks
    result = p.compile_roles_handlers()
    assert len(result) == 4
    assert result[0].parent_block == p
    assert result[1].parent_block == p.roles[0]
    assert result[2].parent_block == p
    assert result[3].parent_block == p.roles[1]
    assert result[0].parent

# Generated at 2022-06-11 10:25:14.788448
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-11 10:25:26.227205
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    """
    test_Play_preprocess_data
    """
    play = Play()


# Generated at 2022-06-11 10:25:27.099449
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass



# Generated at 2022-06-11 10:25:27.661036
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass

# Generated at 2022-06-11 10:25:40.937768
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    class Play_compile_roles_handlers_helper():
        class MockRole():
            def __init__(self):
                self.name = 'Mock_Role_1'
                self.handlers_list = ['Mock_Handler_1', 'Mock_Handler_2']
            def get_handler_blocks(self, play):
                return self.handlers_list
    class MockPlay():
        def __init__(self):
            self.roles = []
            self.role1 = Play_compile_roles_handlers_helper.MockRole()
            self.role2 = Play_compile_roles_handlers_helper.MockRole()
            self.role2.name = 'Mock_Role_2'
            self.roles.append(self.role1)
            self

# Generated at 2022-06-11 10:25:50.522000
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.include.role import IncludeRole
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars
    import pytest
    import json
    import re
    from ansible_collections.stino.plugins.module_utils import core


# Generated at 2022-06-11 10:25:57.269175
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Test with non-dictionary type datasource
    with pytest.raises(AnsibleAssertionError):
        Play().preprocess_data(None)
    # Test with dictionary type datasource
    assert Play().preprocess_data({}).get('remote_user') is None
    assert Play().preprocess_data({'user': None}).get('remote_user') is None
    assert Play().preprocess_data({'user': 'foo'}).get('remote_user') == 'foo'


# Generated at 2022-06-11 10:25:57.996322
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:26:01.092524
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play(loader=None, variable_manager=None)
    test = p.compile_roles_handlers()
    assert test == []

# Generated at 2022-06-11 10:27:01.536906
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # test instantiation
    myplay = Play(name='test_Play_compile_roles_handlers_name')

    # test empty logic
    actual = myplay.compile_roles_handlers()
    assert actual == []

    # test non-empty logic
    myplay.roles = [
        Role(name='role1', tasks=[
            Task(name='task1')
        ]),
        Role(name='role2', tasks=[
            Task(name='task2')
        ]),
        Role(name='role3', tasks=[])
    ]
    actual = myplay.compile_roles_handlers()
    assert actual == []

    # test non-empty logic
    role1 = Role(name='role1', handlers=[
        Task(name='task1')
    ])
    role2 = Role

# Generated at 2022-06-11 10:27:10.179580
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.load(dict(
        name='play1',
        hosts=["localhost"],
        remote_user="admin",
        gather_facts=False,
        pre_tasks=[{'debug': {'msg': 'pre task'}}],
        roles=[{'role': 'role1', 'tasks': [{'debug': {'msg': 'role1'}}]}],
        tasks=[{'debug': {'msg': 'play task'}}],
        post_tasks=[{'debug': {'msg': 'post task'}}],
        vars_files=[{'debug': {'msg': 'var file'}}],
        handlers=[{'meta': 'flush_handlers'}]
    ))
    serial_data = play.serialize()

    # deserialize the data

# Generated at 2022-06-11 10:27:14.277469
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.playbook.play_context import PlayContext
    play = Play()
    play.hosts = 'test_hosts'
    play.name = 'test_name'
    play.vars = dict(fruit = 'apple')
    play.vars_prompt = dict()
    play.vars_files = []
    play.conne

# Generated at 2022-06-11 10:27:15.978515
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers()==[]


# Generated at 2022-06-11 10:27:17.025137
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass #TODO


# Generated at 2022-06-11 10:27:26.521966
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    _play = Play()
    assert _play.get_tasks() == []
    _play.pre_tasks = ['first']
    # pre_tasks was already a list. So it is not converted to a nested list.
    assert _play.get_tasks() == ['first']
    setattr(_play, 'post_tasks', ['second'])
    # post_tasks was converted to a nested list by its _load_post_tasks method.
    # get_tasks method converts the nested list back to a flat list.
    assert _play.get_tasks() == ['first']
    _play._post_tasks = [['second']]
    assert _play.get_tasks() == ['first', 'second']
    setattr(_play, 'tasks', [])
    # tasks was already a list. So

# Generated at 2022-06-11 10:27:36.300928
# Unit test for method serialize of class Play
def test_Play_serialize():
    v = AnsibleVault('asd')
    p = Play()
    p.vars = {'x': '1', 'y': '2'}
    p.vars_prompt=[{'name':'x','prompt':'x','default':'1'},{'name':'y','prompt':'y','default':'2'}]
    p.name = 'unit test'
    p.connection = 'local'
    p.remote_user = 'root'
    p.sudo = 'yes'
    p.sudo_user = 'asd'
    p.sudo_pass = v
    p.tags = ['x', 'y']
    p.gather_facts = 'no'
    r1 = Role()
    r1.name = 'role 1'
    r2 = Role()
    r

# Generated at 2022-06-11 10:27:40.114107
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    role = Role()
    role.get_handler_blocks = Mock(return_value=[])
    role.from_include = False
    play.roles = [role]
    handlers = play.compile_roles_handlers()
    assert handlers == []



# Generated at 2022-06-11 10:27:42.200792
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = {}
    new_ds = Play.preprocess_data(ds)
    assert new_ds is ds


# Generated at 2022-06-11 10:27:46.456537
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.tasks = [{'block': [0]}, {'block': [1, 2]}]
    play._compile_roles = lambda: play.tasks
    assert play.compile_roles_handlers() == play.tasks