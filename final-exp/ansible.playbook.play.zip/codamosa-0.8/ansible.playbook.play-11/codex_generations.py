

# Generated at 2022-06-11 10:18:25.576365
# Unit test for method get_name of class Play
def test_Play_get_name():
    temp_play = Play()
    temp_play.name = 'first_play'
    assert 'first_play' == temp_play.get_name()
    temp_play.name = None
    assert '' == temp_play.get_name()
    temp_play.name = 'second_play'
    assert 'second_play' == temp_play.get_name()


# Generated at 2022-06-11 10:18:31.232506
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    expectedResult1 = {'user': 'root'}
    expectedResult2 = {'remote_user': 'root'}
    p = Play()
    test_data = {'hosts': 'localhost', 'user': 'root'}
    actualResult = p.preprocess_data(test_data)
    assert actualResult == expectedResult2, "Actual: %s, Expected: %s" % (actualResult, expectedResult2)
    test_data = {'hosts': 'localhost', 'remote_user': 'root'}
    actualResult = p.preprocess_data(test_data)
    assert actualResult == expectedResult2, "Actual: %s, Expected: %s" % (actualResult, expectedResult2)

# Generated at 2022-06-11 10:18:33.954665
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    obj = Play()
    obj.compile_roles_handlers()


# Generated at 2022-06-11 10:18:39.114663
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import os
    from . import __file__ as playbook_file

    path = os.path.dirname(playbook_file)

# Generated at 2022-06-11 10:18:49.935488
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import unittest
    import os
    import sys
    import random
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    file_path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-11 10:18:56.415533
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert p.get_vars_files() == []
    p.vars_files = '/var/foo'
    assert p.get_vars_files() == ['/var/foo']
    p.vars_files = ['/var/foo', '/var/bar']
    assert p.get_vars_files() == ['/var/foo', '/var/bar']


# Generated at 2022-06-11 10:19:09.252515
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    pl = Play()
    ds = ['ok']
    assert pl.preprocess_data(ds) == ['ok']
    ds = {'hosts': '127.0.0.1'}
    assert pl.preprocess_data(ds) == {'hosts': '127.0.0.1'}
    ds = {'hosts': '127.0.0.1', 'user': 'root'}
    assert pl.preprocess_data(ds) == {'hosts': '127.0.0.1', 'remote_user': 'root'}
    ds = ['ok', {'user': 'root'}]
    assert pl.preprocess_data(ds) == ['ok', {'remote_user': 'root'}]

# Generated at 2022-06-11 10:19:19.483333
# Unit test for method get_name of class Play
def test_Play_get_name():
    #
    # Test valid case
    #    
    play = Play()
    name = play.get_name()
    #
    # Test that assert_equal() is being used
    #
    try:
        assert_equal(name, "")
    except AssertionError as e:
        print("AssertionError: %s" % e)
    #
    # Test valid case
    #    
    play = Play()
    play.hosts = ["host0", "host1"]
    name = play.get_name()
    #
    # Test that assert_equal() is being used
    #
    try:
        assert_equal(name, "host0,host1")
    except AssertionError as e:
        print("AssertionError: %s" % e)
    #
    # Test valid

# Generated at 2022-06-11 10:19:33.322533
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    key = 'tasks'

# Generated at 2022-06-11 10:19:44.543281
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansiblelint import Runner
    from ansiblelint.rules import AnsibleLintRule

    class MyRunner(Runner):
        def __init__(self, rules, opts):
            self.hosts = dict(inventory={'testhost': dict(name='testhost'),
                                        'testhost2': dict(name='testhost2')})

    class MyRule(AnsibleLintRule):
        id = '999'
        shortdesc = 'My Runner'
        description = '''
        My runner.
        '''
        tags = ['play']

        def match(self, file, text):
            return True

    class MyRule2(AnsibleLintRule):
        id = '1000'
        shortdesc = 'My Runner 2'
        description = '''
        My runner 2.
        '''
       

# Generated at 2022-06-11 10:19:58.923724
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''
    play.name = 'test'
    assert play.get_name() == 'test'
    play.hosts = ['host1', 'host2']
    name = ','.join(play.hosts)
    assert play.get_name() == name


# Generated at 2022-06-11 10:19:59.627737
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-11 10:20:11.553845
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    host = Host('localhost')

    p1 = Play()
    p1.has_tasks = True
    p1.tasks = [
        Task.load(dict(action='copy', copy='copy 1'), play=p1),
        Task.load(dict(action='ruby', ruby='ruby 1'), play=p1),
    ]

    p2 = Play()
    p2.has_tasks = True
    p2.tasks = [
        Task.load(dict(action='copy', copy='copy 2'), play=p2),
        Task.load(dict(action='ruby', ruby='ruby 2'), play=p2),
    ]

    p3 = Play()
    p3.has_tasks = True

# Generated at 2022-06-11 10:20:13.767517
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = "test_play"
    assert p.get_name() == "test_play"

    p.name = None
    assert p.get_name() == ""


# Generated at 2022-06-11 10:20:15.302243
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    '''
    Unit test for method deserialize of class Play
    ''' 
    pass

# Generated at 2022-06-11 10:20:26.148167
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    class TestClass(object):
        def __init__(self, test_case, vars_files):
            self.test_case = test_case
            self.vars_files = vars_files
        def get_vars_files(self):
            return self.vars_files
    # 1.
    test_case = TestClass(None, None)
    play = Play()
    play.test_case = test_case
    get_vars_files_value = play.get_vars_files()
    test_case.test_case.assertEqual(get_vars_files_value, [])
    # 2.
    test_case = TestClass(None, "String")
    play = Play()
    play.test_case = test_case

# Generated at 2022-06-11 10:20:36.860518
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Arrange
    # Create an instance of Play()
    p = Play()
    # Set some attributes
    p.roles = [
        {
            'name': 'role1'
        },
        {
            'name': 'role2'
        }
    ]
    # Create a mock of the Role() class
    mock_role_class = MagicMock()
    # Combine the mock of the Role class and the Play() class
    p.roles[0] = mock_role_class()
    p.roles[1] = mock_role_class()
    # Create a mock of the Role.get_handler_blocks() method
    mock_handler_blocks = MagicMock()
    # Arrange - set return value for the get_handler_blocks() call

# Generated at 2022-06-11 10:20:48.087289
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-11 10:20:55.444565
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # create a play
    play = Play()
    # test that empty play.tasks returns an empty list
    assert play.get_tasks() == []
    # create a task and add it to the play
    task = Task()
    play.tasks.append(task)
    # test that play.get_tasks returns a list with the only task
    assert play.get_tasks() == [task]



# Generated at 2022-06-11 10:21:04.345587
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print("test_Play_get_vars_files")
    test_object = Play()
    print(f"#1: test_object.vars_files = {test_object.vars_files}")
    # Test new_Play_get_vars_files_1
    assert test_object.get_vars_files() == []

    # Test new_Play_get_vars_files_2
    test_object.vars_files = ["./test1.yml"]
    assert test_object.get_vars_files() == ["./test1.yml"]

    # Test new_Play_get_vars_files_3
    test_object.vars_files = "./test2.yml"

# Generated at 2022-06-11 10:21:24.298306
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    role_handlers = '''
    - name: Test handler
      debug: msg="Handler_unit_test"

    - name: Handler test2
      debug: msg="Test handler2"
    '''

    role_handlers_file = os.path.join(tempfile.gettempdir(), 'role_handlers_file')
    with open(role_handlers_file, 'w') as f:
        f.write(role_handlers)

    pb_data = dict(
        roles=[
            dict(
                name='test_play_role',
                handlers=role_handlers_file
            )
        ]
    )

    p = Play()
    p.load(pb_data)
    p.post_validate()
    results = p.compile_roles_handlers()

# Generated at 2022-06-11 10:21:29.470214
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.vars = dict()
    play._ds = dict()
    play._ds['hosts'] = ["192.168.1.1",
                          "192.168.1.2"]
    assert play.get_name() == "192.168.1.1,192.168.1.2"


# Generated at 2022-06-11 10:21:31.760856
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play= Play()
    data={}
    play.deserialize(data)
    # Checks if Play is instance of Play
    assert isinstance(play,Play)


# Generated at 2022-06-11 10:21:34.201620
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Arrange
    play = Play()
    # Act
    res = play.get_name()
    # Assert
    assert res == ''


# Generated at 2022-06-11 10:21:44.982097
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
  # this test should be run from the unit_tests directory
  from ansible.parsing import vault
  from ansible.playbook import Playbook
  from ansible.executor.task_queue_manager import TaskQueueManager
  import ansible.constants as C
  import ansible.utils
  import os
  import shutil
  import tempfile
  import unittest

  # CONSTANTS
  ARCHIVE_DIR = "../archive/test_Play_get_tasks"

  class PlaybookTestCase(unittest.TestCase):
    # import pdb; pdb.set_trace()  # XXX BREAKPOINT
    def setUp(self):
      self.test_dir = tempfile.mkdtemp(prefix="test_Play_get_tasks-tmp-")

      self.test_playbook

# Generated at 2022-06-11 10:21:50.026505
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {"name": "foobar", "hosts": "foo"}
    play = Play()
    play.deserialize(data)
    assert play.name == "foobar"
    assert str(play.hosts) == 'foo'


# Generated at 2022-06-11 10:21:53.868488
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  p = Play()
  p.roles = [Role(),Role(),Role()]
  p.compile_roles_handlers()
  assert True # TODO: implement your test here


# Generated at 2022-06-11 10:21:57.287547
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'_ds': {'hosts': 'all', 'name': 'test'}})
    assert play.hosts == 'all'
    assert play.name == 'test'


# Generated at 2022-06-11 10:21:58.174688
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({})

# Generated at 2022-06-11 10:22:03.738886
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = [
        mock.Mock(get_handler_blocks=mock.Mock(return_value=[1, 2])),
        mock.Mock(get_handler_blocks=mock.Mock(return_value=[3, 4]))
    ]
    assert play.compile_roles_handlers() == [1, 2, 3, 4]


# Generated at 2022-06-11 10:22:13.501274
# Unit test for method get_name of class Play
def test_Play_get_name():
    Play = Play()
    Play.name = 'test'
    # Assert name is set properly
    assert Play.get_name() == 'test'


# Generated at 2022-06-11 10:22:24.352277
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    _loader = DictDataLoader({
        u'file.yml': """
            ---
            - hosts: all
              tasks:
              - name: test
                ping:
                tags: test
              roles:
              - role: test
                tags: test
        """
    })
    _variable_manager = VariableManager()

    play = Play.load(
        data=dict(),
        variable_manager=_variable_manager,
        loader=_loader
    )

    data = play.serialize()

    new_play = Play.load(
        data=dict(),
        variable_manager=_variable_manager,
        loader=_loader
    )

    new_play.deserialize(data)

    # The new Play's (de)serializer will use a DictDataLoader, which returns the
    # playbook file as bytes

# Generated at 2022-06-11 10:22:26.032583
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({"roles": []})
    assert(p._roles == [])

# Generated at 2022-06-11 10:22:31.637833
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # this test is used to ensure _add_task_to_action_group is called on each task
    # and that get_tasks returns data in proper format
    def _add_task_to_action_group(self, group, task):
        group.append(task)
    Play.add_task_to_action_group = MethodType(_add_task_to_action_group, None, Play)
    # prepare data structure before calling get_tasks() on a Play object
    host = Host('localhost')
    task = Task(name='hello', hosts=[host], tasks=[])
    task1 = Task(name='hello', hosts=[host], tasks=[], rescue=[])
    task2 = Task(name='hello', hosts=[host], tasks=[], always=[])

# Generated at 2022-06-11 10:22:42.195189
# Unit test for method deserialize of class Play
def test_Play_deserialize():

    # ##############
    # Create setup #
    # ##############


    # ############
    # Create test #
    # ############

    # Execute action
    play = Play()
    play.deserialize({'hosts': 'localhost', 'roles': []})
    # Validate results
    assert play._included_path == None
    assert play._included_conditional == None
    assert play._action_groups == {}
    assert play._group_actions == {}
    assert play.roles == []
    assert play.tasks == []
    assert play.handlers == []
    assert play.vars == {}
    assert play.vars_files == []
    assert play.pre_tasks == []
    assert play.post_tasks == []
    assert play.tags == []
   

# Generated at 2022-06-11 10:22:46.349097
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    data = dict(
        name = 'bar',
        hosts = 'all',
        handler = dict(tasks=['foo'])
    )
    pp = Play()
    pp._load_data(data)
    pp.compile_roles_handlers()

# Generated at 2022-06-11 10:22:53.142736
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = []
    assert play.get_vars_files() == []

    play = Play()
    play.vars_files = 'sdfsdf'
    assert play.get_vars_files() == ['sdfsdf']

    play = Play()
    play.vars_files = ['sdfsdf', 'sdffsdf']
    assert play.get_vars_files() == ['sdfsdf', 'sdffsdf']



# Generated at 2022-06-11 10:23:04.694879
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # setup
    test_play = Play()
    test_play_tasks = [MagicMock(), MagicMock(), MagicMock()]
    test_play.pre_tasks = MagicMock()
    test_play.tasks = test_play_tasks
    test_play.post_tasks = MagicMock()

    # exercise
    returned_tasks = test_play.get_tasks()

    # verify
    assert len(returned_tasks) == 6
    assert test_play.pre_tasks[0] == returned_tasks[0]
    assert test_play_tasks[0] == returned_tasks[1]
    assert test_play_tasks[1] == returned_tasks[2]
    assert test_play_tasks[2] == returned_tasks[3]


# Generated at 2022-06-11 10:23:07.239397
# Unit test for method get_name of class Play
def test_Play_get_name():
    test_play = Play()
    test_play.name = 'Test_name'
    assert test_play.get_name() == test_play.name

# Generated at 2022-06-11 10:23:18.656454
# Unit test for method deserialize of class Play

# Generated at 2022-06-11 10:23:28.713680
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = 'get_vars_files'
    assert play.get_vars_files() == ['get_vars_files']


# Generated at 2022-06-11 10:23:41.814771
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = []
    # Testing with no roles added
    block_list = play.compile_roles_handlers()
    assert not block_list

    # Testing with one role added
    role1 = Role('test1')
    role1.handlers = []
    play.roles.append(role1)
    block_list = play.compile_roles_handlers()
    assert not block_list

    # Testing with another role added
    role2 = Role('test2')
    role2.handlers = []
    play.roles.append(role2)
    block_list = play.compile_roles_handlers()
    assert not block_list

    # Testing with a role having one handler task
    role1.handlers.append(Task())
    play.ro

# Generated at 2022-06-11 10:23:44.002159
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    # testing return value of get_name
    assert play.get_name() == ''


# Generated at 2022-06-11 10:23:50.980418
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = Task()
    p.tasks = Task()
    p.post_tasks = Task()
    tasklist = []
    for task in p.pre_tasks + p.tasks + p.post_tasks:
        tasklist.append(task)
    assert len(p.get_tasks()) > 0
    assert len(p.get_tasks()) == len(tasklist)



# Generated at 2022-06-11 10:23:55.132055
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert(play.__class__.__name__ == 'Play')
    assert(play.get_name() == 'play')
    assert(play.name == '')
    assert(play.max_fail_percentage == 0)
    assert(play.ROLE_CACHE is not None)

# Generated at 2022-06-11 10:23:56.349084
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = "foo"
    assert p.get_name() == "foo"

# Generated at 2022-06-11 10:24:08.228440
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a Play object, with a single role
    p = Play()
    r = Role()
    p.roles.append(r)
    # Set some handlers for the role/play
    r.handlers = [
        Handler.load({'name': "handler1", 'listen': "test1"}),
        Handler.load({'name': "handler2", 'listen': "test2"}),
        Handler.load({'name': "handler3", 'listen': "test3"})
    ]
    p.handlers = [
        Handler.load({'name': "handler4", 'listen': "test4"}),
        Handler.load({'name': "handler5", 'listen': "test5"}),
        Handler.load({'name': "handler6", 'listen': "test6"})
    ]

# Generated at 2022-06-11 10:24:08.953156
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-11 10:24:19.475667
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # python3 -m pytest tests/test_utils.py
    test_data = [
            "tests/data_debug/compile_roles_handlers.yml"
    ]
    test_vars = [
            "tests/data_debug/compile_vars.yml"
    ]
    test_var = [
            "tests/data_debug/compile_var.yml"
    ]
    #print("Info: test_Play_compile_roles_handlers")
    #print(yaml.dump(test_data))
    for t in test_data:
        with open(t, "rb") as f:
            res = yaml.load(f)
        assert res is not None
        p = Play()
        p.deserialize(res)
        #print(yaml

# Generated at 2022-06-11 10:24:31.055679
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.handlers = []
    play.roles = [Playbook()]
    play.roles[0]._handlers = [Block()]
    play.roles[0]._handlers[0].block = [Handler()]
    play.roles[0]._handlers[0].block[0].notify = []
    play.roles[0]._handlers[0].block[0].rescue = []
    play.roles[0]._handlers[0].block[0].always = []
    play.roles[0]._handlers[0].block[0].listen = []
    play.roles[0]._handlers[0].block[0].tags = [None]

# Generated at 2022-06-11 10:24:55.406005
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    inp = {
        "_tasks": [
            {
                "_uri": "task1.yml",
                "vars": {}
            },
            {
                "_uri": "block1.yml",
                "_block": [
                    {
                        "_uri": "task2.yml",
                        "vars": {}
                    }
                ]
            },
            {
                "_uri": "block2.yml",
                "_block": [
                    {
                        "_uri": "task3.yml",
                        "vars": {}
                    }
                ]
            }
        ]
    }
    p = Play()
    p.load_data(inp)

# Generated at 2022-06-11 10:24:57.841672
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = './test/test.yml'
    assert p.get_vars_files() == ['./test/test.yml']

# Generated at 2022-06-11 10:25:04.000743
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Setting up test variables
    play = Play()
    play.name = ""
    play.hosts = ""

    def check_Play_get_name():
        # This function is supposed to check whther the value returned from get_name is equal to hosts
        return play.get_name() == play.hosts

    assert check_Play_get_name()


# Generated at 2022-06-11 10:25:17.614136
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    # The following custom connection class is needed to avoid the "self.connection"
    # attribute being set to None during the setup of the Play objects.

# Generated at 2022-06-11 10:25:27.573866
# Unit test for method serialize of class Play
def test_Play_serialize():
    d = {'name': 'test', 'hosts': 'localhost', 'gather_facts': 'no', 'remote_user': 'root'}
    p = Play()
    p.vars = {'var1': 'val1'}
    p.vars_files = 'testvarfiles'
    p.vars_prompt = {'name': 'var2', 'prompt': 'var2prompt', 'default': 'defaultvar2'}
    p.connection = 'local'
    p.max_fail_percentage = 50
    p.serial = 5
    p.strategy = 'linear'
    p.tags = 'tag1, tag2'
    p.skip_tags = 'skip1, skip2'
    p.su = 'suuser'
    p.su_user = 'suuser'
   

# Generated at 2022-06-11 10:25:37.215559
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    prep = [MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock()]
    tasks = [MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock()]
    postp = [MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock()]

    play = Play()
    play.pre_tasks = prep
    play.tasks = tasks
    play.post_tasks = postp

    result = play.get_tasks()

    assert prep + tasks + postp == result


# Generated at 2022-06-11 10:25:48.153085
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {'hosts': 'localhost', 'roles': [{'name': 'role1'}, {'name': 'role2'}], '_action_groups': {}, '_group_actions': {'group1': [{'action': 'user', 'args': {'name': 'bob'}}], 'all': [{'action': 'user', 'args': {'name': 'alice'}}]}}
    play = Play()
    play.deserialize(data)
    assert play.roles[0].name == 'role1'
    assert play.roles[0].from_include == False
    assert play.roles[1].name == 'role2'
    assert play.roles[1].from_include == False
    assert play._action_groups == {}

# Generated at 2022-06-11 10:25:57.882747
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    yaml_data = """
- name: This is a Play
  hosts: localhost
  pre_tasks:
    - name: pre task 1
      debug: msg=pre task 1
  roles:
    - role1
  tasks:
    - name: task 1
      debug: msg=task 1
    - name: task 2
      debug: msg=task 2
      run_once: true
    - name: task 3
      debug: msg=task 3
  post_tasks:
    - name: post task 1
      debug: msg=post task 1
    - name: post task 2
      debug: msg=post task 2
"""

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load(yaml_data, variable_manager=variable_manager, loader=loader)
    play.comp

# Generated at 2022-06-11 10:26:00.252953
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  play = Play()
  assert play.compile_roles_handlers() == []

# Generated at 2022-06-11 10:26:08.393304
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    my_play = Play()
    my_play.vars_files = "test_vars_files"
    assert(my_play.get_vars_files() == ["test_vars_files"])
    my_play.vars_files = ["test_vars_files_1", "test_vars_files_2"]
    assert(my_play.get_vars_files() == ["test_vars_files_1", "test_vars_files_2"])


# Generated at 2022-06-11 10:26:32.490234
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    # save the current context, and reset it to run test case
    orig_context = context
    context.CLIARGS = AttributeDict()

# Generated at 2022-06-11 10:26:36.259287
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p=Play()
    p.handlers=[{u'meta': u'flush_handlers'}]
    p.roles=[{u'name': u'test'}]
    assert p.compile_roles_handlers() == [{u'meta': u'flush_handlers'}]

# Generated at 2022-06-11 10:26:37.212535
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    skip = 'test not implemented for the Play method'

# Generated at 2022-06-11 10:26:38.805262
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.get_name()


# Generated at 2022-06-11 10:26:49.050825
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert(p.get_vars_files() == [])

    # Test 1:
    p.vars_files = None
    assert(p.get_vars_files() == [])

    # Test 2:
    p.vars_files = 'varfile'
    assert(p.get_vars_files() == ['varfile'])

    # Test 3:
    p.vars_files = ['vf1', 'vf2', 'vf3']
    assert(p.get_vars_files(), ['vf1', 'vf2', 'vf3'])

    # Test 4:
    p.vars_files = 'varfile1'
    assert(p.get_vars_files() == ['varfile1'])



# Generated at 2022-06-11 10:27:00.367399
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    task5 = Task()
    task6 = Task()
    p.pre_tasks.append(task1)
    p.pre_tasks.append(task2)
    p.tasks.append(task3)
    p.tasks.append(task4)
    p.post_tasks.append(task5)
    p.post_tasks.append(task6)
    
    ##  For each of pre_tasks, tasks and post_tasks, 
    ##  the tasks are appended to tasklist one by one.
    ##  Then each tasklist is appended to tasklist_all
    ##  So tasklist_all is [task1, task2, task

# Generated at 2022-06-11 10:27:09.329877
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    def testfunc(self):
        # build the block list for the play based on compiled roles,
        # the roles list, and the tasks list
        block_list = self._compile_roles()
        block_list.extend(self.tasks)
        return self.compile_roles_handlers()

    module_name='ansible.playbook.play'
    method_name='Play._compile_roles_handlers'
    patched_method = '%s.%s' % (module_name, method_name)
    with patch(patched_method, Mock(side_effect=testfunc)):
        # run the code to be tested
        p = Play()
        p.compile_roles_handlers()
        # assertions
        for h in p.handlers:
            h.reset_notified

# Generated at 2022-06-11 10:27:11.348635
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test_name'
    assert p.get_name() == 'test_name'


# Generated at 2022-06-11 10:27:17.392340
# Unit test for method serialize of class Play
def test_Play_serialize():
    from pprint import pprint
    play = Play()
    play.load(dict(
        name = 'test play',
        remote_user = 'test remote_user'
    ))
    pprint(play._serialize_data())
    assert play.serialize() == dict(
        name = 'test play',
        remote_user = 'test remote_user',
        included_path = None,
        action_groups = dict(),
        group_actions = dict(),
        roles = []
    )

# Generated at 2022-06-11 10:27:18.043579
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-11 10:27:44.723550
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-11 10:27:55.568608
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    config_path = os.getcwd() + '/ansible.cfg'
    print(config_path)
    #config_path = os.path.expanduser(config_path)
    c = AnsibleConfig(config_path)
    c.parse()
    c.base_config_args()

    # test run
    # from ansible.executor.task_queue_manager import TaskQueueManager
    # from ansible import context
    # context.CLIARGS = ImmutableDict(connection='local', module_path=None, forks=10, become=None,
    #                      become_method=None, become_user=None, check=False, diff=False, remote_user=None,
    #                      private_key_file=None,
    #                      module_path_force=True, become_ask_pass=None

# Generated at 2022-06-11 10:28:05.006574
# Unit test for method get_tasks of class Play