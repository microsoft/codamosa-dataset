

# Generated at 2022-06-11 10:18:31.713848
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    cls = Play()
    args = {}
    cls.preprocess_data(args)

    assert args == {}

    ################
    args = {'user': 'bad', 'remote_user': 'good'}
    with pytest.raises(AnsibleParserError) as excinfo:
        cls.preprocess_data(args)
    assert str(excinfo.value) == "both 'user' and 'remote_user' are set for this play. The use of 'user' is deprecated, and should be removed"
    assert args == {'user': 'bad', 'remote_user': 'good'}

    ################
    args = {'user': 'bad'}
    cls.preprocess_data(args)
    assert args == {'remote_user': 'bad'}


# Unit test

# Generated at 2022-06-11 10:18:35.041873
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p._pre_tasks = [ 'pre1', 'pre2' ]
    p._tasks = [ 'task1', 'task2' ]
    p._post_tasks = [ 'post1', 'post2' ]
    tasks = p.get_tasks()
    assert tasks == [ 'pre1', 'pre2', 'task1', 'task2', 'post1', 'post2' ]


# Generated at 2022-06-11 10:18:47.016337
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Arrange
    p = Play()
    p.roles=[]
    p.vars={}
    p.collections=[]
    # Act
    res = p.compile_roles_handlers()
    # Assert
    expected = []
    assert res == expected
    # Arrange
    p = Play()
    p.roles=None
    p.vars={}
    p.collections=None
    # Act
    res = p.compile_roles_handlers()
    # Assert
    expected = []
    assert res == expected
    # Arrange
    p = Play()
    p.roles=['some roles']
    p.vars={}
    p.collections=[]
    # Act
    res = p.compile_roles_handlers()
    #

# Generated at 2022-06-11 10:18:50.316647
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Init object, set vars_files to None
    play = Play()
    play.vars_files = None
    # Call method get_vars_files
    play.get_vars_files()
    # Check result
    assert play.vars_files == []

# Generated at 2022-06-11 10:19:00.060061
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    a = Play()
    a.deserialize({'hosts': ['foo', 'bar'], 'roles': [{'foo': 'bar'}, {'bar': 'baz'}], 'action_groups': {'bar': 'baz'}, 'group_actions': {'bar': 'baz'}})
    assert a.hosts == ['foo', 'bar']
    assert a.roles[0].foo == 'bar'
    assert a.roles[1].bar == 'baz'
    assert a._included_path == None
    assert a._included_conditional == None


# Generated at 2022-06-11 10:19:00.928375
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-11 10:19:02.120490
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass



# Generated at 2022-06-11 10:19:10.768302
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # TEST data
    data = [{'name': 'role1', 'id': 'role-1', 'version': '1.1.1'},
            {'name': 'role2', 'id': 'role-2', 'version': '1.1.1'}]

    # TEST code
    # create a Play object
    p = Play()
    # execute method compile_roles_handlers of class Play
    result = p.compile_roles_handlers()
    # Assertion
    assert result == []

# Generated at 2022-06-11 10:19:16.741047
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play1 = Play()
    # test_case_1
    play1._ds = {'vars_files': [{'name': '/dev/null'}, {'name': '/dev/null'}]}
    assert play1.get_vars_files() == [{'name': '/dev/null'}, {'name': '/dev/null'}]
    # test_case_2
    play1._ds = {'vars_files': {'name': '/dev/null'}}
    assert play1.get_vars_files() == [{'name': '/dev/null'}]

# Generated at 2022-06-11 10:19:28.963894
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    # Note: provide various test data for individual attribute, not just data for constructor
    play.hosts = 'all'
    play.vars = {'var1': 'val1'}
    play.name = 'play1'
    play.max_fail_percentage = 10
    play.strategy = 'strategy1'
    play.serial = ['serial1']
    play.become = True
    play.roles = [Role()]
    data = play.serialize()
    new_play = Play().deserialize(data=data)
    assert new_play == play



# Generated at 2022-06-11 10:19:42.258134
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = "A play"
    eq_(p.get_name(), "A play")

    p = Play()
    p.hosts = "localhost"
    eq_(p.get_name(), "localhost")

    p = Play()
    p.hosts = ["localhost"]
    eq_(p.get_name(), "localhost")


# Generated at 2022-06-11 10:19:48.349200
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    assert Play().get_vars_files() == []
    assert Play(vars_files=None).get_vars_files() == []
    assert Play(vars_files='/path/to/vars.yaml').get_vars_files() == ['/path/to/vars.yaml']
    assert Play(vars_files=['/path/to/vars.yaml']).get_vars_files() == ['/path/to/vars.yaml']


# Generated at 2022-06-11 10:19:49.813525
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    Play.get_vars_files()


# Generated at 2022-06-11 10:20:00.273770
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print("Test Play get_tasks method")
    #create test data
    task1 = Task()
    task2 = Task()
    tasks = [task1, task2]
    block1 = Block()
    block1.block = tasks
    block2 = Block()
    block2.block = tasks
    
    #create test object
    play = Play()
    play.pre_tasks = [block1]
    play.tasks = [block2]
    play.post_tasks = [block2]

    expected = tasks + tasks + tasks
    result = play.get_tasks()
    #print(result)
    if result == expected:
        print("Test Play get_tasks successful")
    else:
        print("Test Play get_tasks failed")


# Generated at 2022-06-11 10:20:11.418744
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # This test will test whether the method compile_roles_handlers
    # in class Play works as expected.

    # We will first create a play object.
    tasks = None
    blocks = None
    handlers = None
    pre_tasks = None
    post_tasks = None
    roles = None
    vars_files = None
    play = Play(name=None, hosts=None, roles=roles, tasks=tasks, blocks=blocks, pre_tasks=pre_tasks, post_tasks=post_tasks, vars_files=vars_files, handlers=handlers)


    # We will now check the method compile_roles_handlers of object play.
    assert True # No assertion to test.



# Generated at 2022-06-11 10:20:13.428792
# Unit test for method get_name of class Play
def test_Play_get_name():
    obj=Play()
    method=getattr(obj, 'get_name')
    # Test with the correct arguments
    assert method()==''

# Generated at 2022-06-11 10:20:18.078452
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ["var1", "var2"]
    assert play.get_vars_files() == ["var1", "var2"]

    play.vars_files = "var3"
    assert play.get_vars_files() == ["var3"]

    play.vars_files = None
    assert play.get_vars_files() == []


# Generated at 2022-06-11 10:20:21.710580
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print("testing Play.get_tasks()")
    temp=Play()
    print(temp.get_tasks())
    assert True==True
test_Play_get_tasks()


# Generated at 2022-06-11 10:20:32.528103
# Unit test for method load of class Play
def test_Play_load():
    # from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from six import string_types

    # FIXME: Integrate proper unit tests
    def test_play(play_ds, expected_name, expected_hosts):
        play_ds = preprocess_data(play_ds, validate_files=False)
        vars_manager = VariableManager()
        inventory = Inventory(loader=None, variable_manager=vars_manager, host_list=[])
        play = Play.load(play_ds, variable_manager=vars_manager, loader=None)

        assert isinstance(play, Play)
        assert play.get_name() == expected_name
        assert play.hosts == expected_hosts


# Generated at 2022-06-11 10:20:42.702555
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print("\n[test] RUNNING TESTS FOR METHOD get_tasks of class Play")
    # generate dummy Play instance
    Play_instance = Play()
    # =================================
    # TEST WHEN pre_task, post_task, tasks are EMPTY
    # =================================
    # print("\n[test] WHEN pre_task, post_task, tasks are EMPTY")
    # set attribute value to be empty
    Play_instance.pre_tasks = []
    Play_instance.post_tasks = []
    Play_instance.tasks = []
    # run the test
    tasks_obtained = Play_instance.get_tasks()
    tasks_expected = []
    # assert that tasks_obtained should be equal tasks_expected

# Generated at 2022-06-11 10:21:20.629991
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    hostvars_manager = make_memory_inventory_manager()
    variable_manager = make_memory_variable_manager()


# Generated at 2022-06-11 10:21:24.589812
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []
    assert not play.compile_roles_handlers()


# Generated at 2022-06-11 10:21:34.142621
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # testing using class

    # Create a Play
    play = Play()
    play.compile_roles_handlers()

    # Create a Role
    role = Role()
    role.name = "test"

    # Create a Module
    from ansible.modules.system import ping
    module = ping.__file__

    # Create a Task
    task = Task()
    task.module_args = module

    # Create a Task
    task2 = Task()
    task2.action = "test"

    # Create a Block
    block = Block()
    block.block = task
    block.rescue = task2
    block.always = task

    # Add attributes to the Play
    play.tasks = block

    # Add attributes to the Role
    role.tasks = block

    # Add role to the Play
    play

# Generated at 2022-06-11 10:21:44.933051
# Unit test for method get_tasks of class Play

# Generated at 2022-06-11 10:21:46.533855
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play.hosts == ''



# Generated at 2022-06-11 10:21:49.157518
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    print('Unit test for method get_tasks of class Play')
    print('not implemented yet')


# Generated at 2022-06-11 10:21:59.775210
# Unit test for method get_name of class Play
def test_Play_get_name():
    import ansible.utils.vars as vars_mock
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook

    # paths that can be used to find a valid inventory
    inventory_path = './test/inventory/test_inventory'

    # create the variable manager and data loader
    variable_manager = VariableManager()
    loader = DataLoader()

    # create the inventory and pass to var manager
    inventory = InventoryManager(loader=loader, sources=inventory_path)
    variable_manager.set_inventory(inventory)

    # variable manager can optionally be passed to playbook constructor

# Generated at 2022-06-11 10:22:09.127121
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()

    assert p.compile_roles_handlers() == []
    assert p.roles == []

    p.roles = [1, 2, 3, 4]
    assert p.roles == [1, 2, 3, 4]
    assert p.compile_roles_handlers() == []
    assert p.roles == [1, 2, 3, 4]

    p = Play()
    p.roles = [Role()]
    # TODO: Make test logic more robust, this is really testing method Role.get_handler_blocks
    assert p.compile_roles_handlers() == []

# Generated at 2022-06-11 10:22:11.162515
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    my_play = Play()
    assert my_play.compile_roles_handlers() == []


# Generated at 2022-06-11 10:22:22.035608
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # hosts, name and remote_user should be set in real case
    fake_play = Play()
    fake_play.pre_tasks = None
    fake_play.post_tasks = None
    fake_play.tasks = []

    assert fake_play.get_tasks() == []

    fake_task = Task()
    fake_task.action = 'fake_action'
    fake_task.name = 'fake_task'
    fake_block = Block()
    fake_block.block = [fake_task]
    fake_task_1 = Task()
    fake_task_1.action = 'fake_action'
    fake_task_1.name = 'fake_task_1'
    fake_block_1 = Block()
    fake_block_1.block = [fake_task_1]
    fake_

# Generated at 2022-06-11 10:22:57.168879
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    Test get_vars_files of class Play
    '''
    vars_files1 = [
        {'foo': 'bar'},
        {'blah': 'bleh'}
    ]
    vars_files2 = [{
        'foo': 'bar',
        'blah': 'bleh'
    }]

    x = Play()
    x.vars_files = None
    assert x.get_vars_files() == []
    x.vars_files = vars_files1
    assert x.get_vars_files() == vars_files1
    x.vars_files = vars_files2
    assert x.get_vars_files() == vars_files2

# Generated at 2022-06-11 10:22:58.794263
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.compile_roles_handlers()

# Generated at 2022-06-11 10:23:08.924555
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_obj=Play()
    play_obj.pre_tasks=[]
    play_obj.tasks=[]
    play_obj.post_tasks=[]
    x=play_obj.get_tasks()
    assert x==[]
    play_obj.pre_tasks=[1]
    x=play_obj.get_tasks()
    assert x==[[1]]
    play_obj.tasks=[2]
    x=play_obj.get_tasks()
    assert x==[[1],[2]]
    play_obj.post_tasks=[3]
    x=play_obj.get_tasks()
    assert x==[[1],[2],[3]]


# Generated at 2022-06-11 10:23:13.546041
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = "vars_files"
    expected = ["vars_files"]
    play_vars_files = play.get_vars_files()
    assert play_vars_files == expected
    

# Generated at 2022-06-11 10:23:19.908483
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = 'a.yml'
    assert p.get_vars_files() == ['a.yml'], "Test method get_vars_files of class Play failed"
    p.vars_files = ['a.yml', 'b.yml']
    assert p.get_vars_files() == ['a.yml', 'b.yml'], "Test method get_vars_files of class Play failed"


# Generated at 2022-06-11 10:23:22.344247
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pl= Play()
    pl.vars_files = ['.vars_files']
    assert pl.get_vars_files() == ['.vars_files']



# Generated at 2022-06-11 10:23:25.603413
# Unit test for method get_name of class Play
def test_Play_get_name():
    """
    Test of method get_name of class Play
    """
    p = Play()
    assert p.get_name() == '', 'Failed to retrieve empty name of play'


# Generated at 2022-06-11 10:23:38.138540
# Unit test for method serialize of class Play
def test_Play_serialize():
    obj = Play()

# Generated at 2022-06-11 10:23:46.261649
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    p.name = 'all'
    p.hosts = 'all'
    p.tasks = [dict(action='debug', msg="Hello world!")]
    assert p.get_name() == 'all'

    p2 = Play()
    p2.name = 'test'
    p2.hosts = 'all'
    p2.tasks = [dict(action='debug', msg="Hello world!")]
    assert p2.get_name() == 'test'

    assert p.get_vars() is not p2.get_vars()

# Generated at 2022-06-11 10:23:47.456963
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-11 10:24:51.571139
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass

# Generated at 2022-06-11 10:24:56.194800
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()

# Generated at 2022-06-11 10:25:09.400279
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Unit test for method get_tasks
    # test1: test with no role
    # set up
    data = {
        'name': 'testPlay',
        'hosts': ['127.0.0.1'],
        'pre_tasks': ['task1', 'task2'],
        'tasks': ['task3', 'task4'],
        'post_tasks': ['task5', 'task6'],
    }
    play = Play()
    play.load_data(data)
    
    # test
    tasklist = play.get_tasks()

    # verify
    assert len(tasklist) == 6
    assert tasklist == data.get('pre_tasks') + data.get('tasks') + data.get('post_tasks')
    
    # test2: test with roles

# Generated at 2022-06-11 10:25:12.926293
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    print('Testing test_Play_compile_roles_handlers')
    play = Play()
    assert isinstance(play.compile_roles_handlers(), list)


# Generated at 2022-06-11 10:25:14.510754
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    check_class(Play, 'compile_roles_handlers')

# Generated at 2022-06-11 10:25:22.510120
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = 'test_play'
    assert p.get_name() == 'test_play'
    p.name = None
    p.hosts = 'test_hosts'
    assert p.get_name() == 'test_hosts'
    p.hosts = []
    assert p.get_name() == ''
    p.hosts = [1,2,3]
    assert p.get_name() == '1,2,3'
    return True


# Generated at 2022-06-11 10:25:30.136371
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play_roles = []
    def return_role_handlers():
        return play_roles
    play.roles = return_role_handlers
    play_roles.append(Role())
    play_roles.append(Role())
    handler1 = {
        'name': 'first-handler', 'action': 'do-something',
        'async': 60, 'poll': 10, 'ignore_errors': True, 'first_available_file': True
    }
    handler2 = {
        'name': 'second-handler', 'action': 'do-something-else',
        'async': 60, 'poll': 10, 'ignore_errors': True, 'first_available_file': True
    }

# Generated at 2022-06-11 10:25:43.598478
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    d = {u'roles': [{u'file': u'', u'repo': u'', u'name': u'test_role'}]}
    p.load_data(d)
    assert (p.get_tasks() == [])
    p.tasks = [u'clean', u'config']
    assert (p.get_tasks() == [u'clean', u'config'])
    p.tasks = [u'clean', [u'config']]
    assert (p.get_tasks() == [u'clean', u'config'])
    p.tasks = [[u'clean'], [u'config']]
    assert (p.get_tasks() == [[u'clean'], [u'config']])

# Generated at 2022-06-11 10:25:44.293877
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-11 10:25:49.205741
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'play'
    assert play.get_name() == 'play'
    play.name = None
    play.hosts = 'host'
    assert play.get_name() == 'host'
    play.hosts = []
    assert play.get_name() == ''
    play.hosts = 123
    assert play.get_name() == '123'



# Generated at 2022-06-11 10:26:58.867704
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    Pass()

# Generated at 2022-06-11 10:27:06.154049
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    my_play = Play()
    my_play_task = Task()
    my_play_pre_task = Task()
    my_play_post_task = Task()
    my_play.tasks.append(my_play_task)
    my_play.pre_tasks.append(my_play_pre_task)
    my_play.post_tasks.append(my_play_post_task)
    my_tasks = my_play.get_tasks()
    assert my_tasks == [my_play_pre_task, my_play_task, my_play_post_task]

# Generated at 2022-06-11 10:27:12.472668
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Returns a list of Handler objects for the defined roles and for this play
    '''
    if __name__ == '__main__':
        hosts = ['localhost']
        loaders = [DataLoader()]
        variable_managers = [VariableManager()]
        play = Play()
        play.set_loader(loaders[0])
        play.set_variable_manager(variable_managers[0])
        play.set_hosts(hosts)
        play.compile_roles_handlers()
        # Verify the objects returned are of type Handler
        

# Generated at 2022-06-11 10:27:21.847998
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_ds = dict(
        name = "Ansible Play ", 
        hosts = "all", 
        gather_facts = "no", 
        roles = [
            dict(
                role = "common", 
                tasks = [
                    dict(name='Read /etc/hosts', command='cat /etc/hosts')], 
                handlers = [
                    dict(name='restart nginx', service='name=nginx state=restarted')]
                ),
            dict(
                role = "web", 
                tasks = [dict(name='Read /etc/passwd', command='cat /etc/passwd')], 
                handlers = [
                    dict(name='restart apache2', service='name=apache2 state=restarted')]
                )
            ]
        )



# Generated at 2022-06-11 10:27:25.941196
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = "test_Play_get_name"
    assert p.name == p.get_name()
    p.name = None
    p.hosts = "10.15.5.5"
    assert p.hosts == p.get_name()


# Generated at 2022-06-11 10:27:32.388865
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['/home/renwei/ansible/hacking/test/units/get_vars_files','home/renwei/ansible/hacking/test/units/get_vars_files']
    if play.get_vars_files() == play.vars_files:
        print("method get_vars_files of class Play pass")
    else:
        print("method get_vars_files of class Play fail")

# Generated at 2022-06-11 10:27:33.020604
# Unit test for method serialize of class Play
def test_Play_serialize():
	pass

# Generated at 2022-06-11 10:27:37.655851
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.deserialize({
        'vars_files': 'foo'
    })
    assert play.get_vars_files() == ['foo']
    play.deserialize({
        'vars_files': ['foo', 'bar']
    })
    assert play.get_vars_files() == ['foo', 'bar']



# Generated at 2022-06-11 10:27:46.185257
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    role_lab = Role()
    pre_tasks = Task()
    tasks = Task()
    post_tasks = Task()
    play = Play()
    play.roles = [role_lab]
    play.pre_tasks = [pre_tasks]
    play.tasks = [tasks]
    play.post_tasks = [post_tasks]
    tasks = play.get_tasks()
    assert tasks[0] == [pre_tasks]
    assert tasks[1] == [tasks]
    assert tasks[2] == [tasks]
    assert tasks[3] == [tasks]
    assert tasks[4] == [post_tasks]

# Generated at 2022-06-11 10:27:56.522006
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = load_playbook_from_file('./test/yaml/serialize/play.yaml')
    play = play.serialize()
    assert isinstance(play["vars_files"], list)
    assert len(play["vars_files"]) == 1
    assert isinstance(play["tasks"], list)
    assert len(play["tasks"]) == 3
    assert isinstance(play["post_tasks"], list)
    assert len(play["post_tasks"]) == 0
    assert isinstance(play["pre_tasks"], list)
    assert len(play["pre_tasks"]) == 0
    assert isinstance(play["handlers"], list)
    assert len(play["handlers"]) == 1
    assert isinstance(play["roles"], list)