

# Generated at 2022-06-11 10:18:22.673298
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'foo'
    assert play.get_name() == 'foo'

# Generated at 2022-06-11 10:18:23.918415
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    ret_val = Play()
    assert ret_val.get_tasks() is not None

# Generated at 2022-06-11 10:18:29.961821
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    '''
    test module Play.get_tasks
    '''
    p = Play()
    tasks = [
        {'name': 'a'},
        {'name': 'b'},
        {'name': 'c'},
        {'name': 'd'},
        {'name': 'e'},
        {'name': 'f'},
        {'name': 'g'},
        {'name': 'h'},
        {'name': 'i'},
        {'name': 'j'},
    ]
    for t in tasks:
        t = Task().load(t, play=p)
        p.tasks.append(t)

    res = p.get_tasks()
    assert len(res) == 10
    # test sorted order of result
    assert res[0].get

# Generated at 2022-06-11 10:18:38.427215
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = "test_vars_files"
    assert play.get_vars_files() == ["test_vars_files"]
    play.vars_files = ["test_vars_files1", "test_vars_files2"]
    assert play.get_vars_files() == ["test_vars_files1", "test_vars_files2"]


# Generated at 2022-06-11 10:18:43.844938
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = {'name': 'test',
            'connection': 'local',
            'hosts': 'localhost',
            'roles': []}
    p = Play()
    p.load_data(data)
    ret = p.get_tasks()
    assert ret == []

# Generated at 2022-06-11 10:18:52.206761
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

# Generated at 2022-06-11 10:18:59.482704
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    result = Play.load(dict(vars_files='/path/to/file.yml')).get_vars_files()
    assert result == ['/path/to/file.yml']
    result = Play.load(dict(vars_files=['/path/to/file.yml'])).get_vars_files()
    assert result == ['/path/to/file.yml']


# Generated at 2022-06-11 10:19:02.765028
# Unit test for constructor of class Play
def test_Play():
    '''
    Play constructor unit test
        >>> play = Play()
        >>> play.get_name() in ('', None)
        True
    '''


# Generated at 2022-06-11 10:19:15.004793
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_noop
    from units.plugins.action.normal import ActionModule

    task_ds = dict(
        name='task_name',
        action='task_action',
        args=dict(foo='bar'),
    )

    handler_ds = dict(
        name='handler_name',
        action='handler_action',
        args=dict(foo='bar'),
    )


# Generated at 2022-06-11 10:19:29.644684
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.vault import VaultLib
    import ansible.constants as C
    import base64
    import yaml
    vault_data = "AQAAQF1bf/yGJfMz+oN/RVhPfJTtHw=="
    vault_password = "automation"
    vault = VaultLib([])
    vault.decrypt(vault.loads(vault_data), vault_password)

# Generated at 2022-06-11 10:19:46.490510
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # GIVEN: Tested class instance
    p = Play()

    # WHEN: deserialize is called and
    #       data is a dictionary which contains the key "roles"
    data = { 'roles' : [ {} ] }
    p.deserialize(data)

    # THEN: the deserialized data should be correctly handled
    assert isinstance(p.roles[0], Role)



# Generated at 2022-06-11 10:19:47.095497
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-11 10:19:49.102203
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    var = play.preprocess_data({})
    assert isinstance(var, dict)
    assert var is not None


# Generated at 2022-06-11 10:19:59.512053
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.copy import ActionModule as ActionModule_copy
    from ansible.playbook.block import Block

    class PlayObject(object):
        def get_handler(self, name):
            pass

    class PlayContext(object):
        def __init__(self):
            self.prompt = {}
            self.prompt_values = {}
            self.callbacks = ''


# Generated at 2022-06-11 10:20:11.463283
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    role = Role()
    role.deserialize(name=u'role_name',
                     tasks=[],
                     handlers=[],
                     default_vars=dict(a=u'b'),
                     vars_prompt=dict(c=u'd'),
                     vars_files=[],
                     meta=dict(e=u'f'),
                     dependencies=[],
                     blocks=None,
                     had_blocks=False,
                     role_path=u'role_path',
                     role_uri=u'role_uri')
    new = Play()

# Generated at 2022-06-11 10:20:20.666988
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # If a play has a list of tasks, each task should be included in the result
    test_play_path = os.path.join(os.getcwd(), 'test/unit/playbook_tests/playbook_get_tasks.yml')
    test_play = Play.load(test_play_path, variable_manager=VariableManager(), loader=DataLoader())
    assert len(test_play.get_tasks()) == 5

    # If an action is included in a block, it should not be included in the result
    assert(test_play.get_tasks()[3].action != 'action_inside_block')

    # If an action is included in a rescue block, it should be included in the result
    assert(test_play.get_tasks()[3].action == 'action_inside_rescue')

    # If

# Generated at 2022-06-11 10:20:25.329697
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers() == []
    p1 = Play()

    # Testing role handler will be checked in class Role
    p.roles.append(p1)
    assert p.compile_roles_handlers() == [p1]

# Generated at 2022-06-11 10:20:27.565835
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    my_play = Play()
    my_play.preprocess_data("foo")

# Generated at 2022-06-11 10:20:38.017549
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    check_for_dict = None
    check_for_list = None
    dict_input = None
    list_input = None
    if check_for_dict == True:
        dict_input = {'vars_files': 'roles/main/vars/main.yml', 'name': 'testplaybook'}
    elif check_for_list == True:
        list_input = {'vars_files': ['roles/main/vars/main.yml', 'roles/main/vars/new.yml'], 'name': 'testplaybook'}
    play = Play()
    setattr(play, 'vars_files', dict_input)
    assert play.get_vars_files() == ['roles/main/vars/main.yml']

# Generated at 2022-06-11 10:20:48.036524
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """
    Asserts the get_tasks method returns a list of tasks from the pre_tasks, tasks, and post_tasks attributes
    """
    p = Play()
    p.pre_tasks = ['pre_task1', 'pre_task2']
    p.tasks = ['task1', 'task2']
    p.post_tasks = ['post_task1', 'post_task2']
    # get_tasks method should return a list of tasks from the pre_tasks, tasks, and post_tasks attributes
    assert p.get_tasks() == ['pre_task1', 'pre_task2', 'task1', 'task2', 'post_task1', 'post_task2']

# Generated at 2022-06-11 10:21:03.308276
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.load( dict(name="test", hosts=["127.0.0.1"],
                    handlers=dict(name="abc", tasks=dict(name="abc")),
                    roles=[dict(name="role", tasks=dict(name="def"))]))
    play._load_included_file = mock.Mock()
    assert play.compile_roles_handlers() == play.handlers

# Generated at 2022-06-11 10:21:03.973314
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-11 10:21:14.825428
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.set_loader(DictDataLoader({}))
    assert play.get_tasks() == []
    play.set_loader(DictDataLoader({"tasks": [{"action": "noop", "name": "test_task"}]}))
    assert len(play.get_tasks()) == 1
    # Test with role too
    play.set_loader(DictDataLoader({"tasks": [{"action": "noop", "name": "test_task"}], "roles": [{"name": "test_role", "tasks": {"main.yml": [{"action": "noop", "name": "test_role_task"}]}}]}))
    assert len(play.get_tasks()) == 2
# Initialization of test object
play_test = Play()
play_test

# Generated at 2022-06-11 10:21:19.499233
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = "/tmp/foo"
    vars = play.get_vars_files()
    assert isinstance(vars, list)
    assert len(vars) == 1
    assert "/tmp/foo" in vars

# Generated at 2022-06-11 10:21:26.163053
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    role = RoleInclude()
    role.name = "test"
    
    data = dict(roles=[role])
    p = Play.load(data, variable_manager=None, loader=None, vars=None)
    assert(p.get_tasks() == [])

    
    
# END class Play


# Generated at 2022-06-11 10:21:31.551439
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test = Play(pre_tasks=[
        Task(name='test1', tags=['tag1'])
    ],
    tasks=[ 
        Task(name='test2', tags=['tag1'])
    ],
    post_tasks=[
        Task(name='test3', tags=['tag1'])
    ])
    print(test.get_tasks())


# Generated at 2022-06-11 10:21:32.791465
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() == []

# Generated at 2022-06-11 10:21:38.640284
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Create test object
    my_play = Play()
    try:
        # Set or modify attributes
        my_play._ds['vars_files'] = None
        my_play.vars_files = None
        #Execute function to get the output
        result = my_play.get_vars_files()
    except:
        pass
    else:
        assert result == [], "Get the expected result"


# Generated at 2022-06-11 10:21:50.723947
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    if (context.CLIARGS['forks'] != 0
        or context.CLIARGS['verbosity'] > test_play.VERBOSITY
       ):
        pytest.skip("Test needs to run with --connection=local")

    # test play with no roles
    p = Play.load(dict(
        name = "a play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='a task'))),
        ]),
        variable_manager=VariableManager(),
        loader=DataLoader()
    )
    tasks = p.compile_roles_handlers()
    assert isinstance(tasks, list)
    assert len(tasks) == 0

    # test play with roles

# Generated at 2022-06-11 10:22:00.512903
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    role1 = Role(
        name="Foo",
        vars={'foo': 'bar'},
        tasks=[],
        handlers=[
            Handler().load({
                'name': 'all',
                'listen': 'this is where I will listen',
                'tasks': [
                    {
                        'debug': 'This will be run as a handler'
                    }
                ]
            })
        ]
    )
    role1.get_implicit_meta_tasks()

# Generated at 2022-06-11 10:22:17.710517
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    vars = dict()
    vars.update({
	"name":"Sagar",
	"age":"23"
    })
    play.vars=vars
    play.vars_prompt=None
    play.roles=None
    play.post_tasks=None
    play.tasks=None
    play.pre_tasks=None
    play.handlers=None
    play.tags=None
    play.name="Dummy Name"
    play.hosts="localhost"
    play.force_handlers=None
    play.max_fail_percentage=None
    play.serial=None
    play.strategy="Dummy Strategy"
    play.order="Dummy Order"
    play.collections=None
    play.included_path=None

# Generated at 2022-06-11 10:22:21.035194
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_Play = Play()
    test_Play.vars_files = []
    assert test_Play.get_vars_files() == []

# Generated at 2022-06-11 10:22:31.023545
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None

    # When vars_files is a list
    play.vars_files = ['test_var_file_1', 'test_var_file_2']
    assert play.get_vars_files() == ['test_var_file_1', 'test_var_file_2']

# # Unit test for method get_tasks of class Play
# def test_Play_get_tasks():
#     play = Play()
#     with pytest.raises(AttributeError):
#         play.get_tasks()
#
#     task = Task()
#     play.pre_tasks = [task]
#     play.tasks = [task]
#     play.post_tasks = [task]
#     assert play.get_tasks() ==

# Generated at 2022-06-11 10:22:35.750147
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    m_data = dict(
        name = 'Test Play',
        hosts = 'all',
        user = 'root'
    )
    p = Play()
    p.preprocess_data(ds=m_data)
    assert m_data.get('remote_user') == 'root'
    assert 'user' not in m_data



# Generated at 2022-06-11 10:22:46.446427
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()

# Generated at 2022-06-11 10:22:57.220482
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    def _task_dump(task):
        if isinstance(task, Block):
            return [_task_dump(t) for t in task.block + task.rescue + task.always]
        return task.action
    def _assert_task_list(task_list, expected_tasks, line_no):
        if len(task_list) != len(expected_tasks):
            raise AssertionError("%d: length of task_list(%d) != expected_tasks(%d)" % \
                                 (line_no, len(task_list), len(expected_tasks)))

# Generated at 2022-06-11 10:22:59.832508
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers(): 
    play = Play()
    play.roles = ['roles']
    assert play.compile_roles_handlers() == []


# Generated at 2022-06-11 10:23:08.646357
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a play instance
    play = Play()
    # add a play role and a handler to that role
    play.roles = [Role()]
    play.roles[0].handlers = [Handler()]
    # call compile_roles_handlers
    play.compile_roles_handlers()
    num_handlers = len(play.handlers)
    # check to see if number of handlers is 1, if not, then 
    # test fails
    assert num_handlers == 1, "expected 1 handler, got %d handlers" %num_handlers



# Generated at 2022-06-11 10:23:13.295684
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert isinstance(p.get_vars_files(), list)
    p.vars_files = ['test_vars_files_1']
    assert p.get_vars_files() == ['test_vars_files_1']


# Generated at 2022-06-11 10:23:15.483049
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()

    assert isinstance(p, Play)
    assert p.serialize() is not None

# Generated at 2022-06-11 10:23:38.591579
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    test_Play_preprocess_data tests the preprocess_data method of the Play
    class.
    '''
    play = Play()

    data = {'hosts': 'all'}
    assert play.preprocess_data(data) == data

    data = {'hosts': 'all', 'user': 'myuser'}
    assert play.preprocess_data(data) == {'hosts': 'all', 'remote_user': 'myuser'}

    with pytest.raises(AnsibleAssertionError):
        data = "abcd"
        play.preprocess_data(data) == data


# Generated at 2022-06-11 10:23:39.543874
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert True

# Generated at 2022-06-11 10:23:50.596190
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    task1 = Task()
    task1._ds['name'] = 'my_task'

    tasks = []
    tasks.append(task1)

    role1 = Role()
    role1._ds['name'] = 'my_role'
    role1._ds['tasks'] = tasks

    roles = []
    roles.append(role1)

    play = Play()
    play._ds['name'] = 'my_play'
    play._ds['roles'] = roles

    handler = Handler()
    handler._ds['name'] = 'my_handler'
    handler._ds['tasks'] = tasks

    handlers = []
    handlers.append(handler)

    play._ds['handlers'] = handlers

    role_handlers = play.compile_roles_handlers()
    assert len(role_handlers) == 1

# Generated at 2022-06-11 10:23:57.018898
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    p = Play()
    ds= {'user':'username','connection':'ssh'}
    testds = p.preprocess_data(ds)
    assert_true(testds['remote_user'] == ds['user'])
    assert_true(testds['remote_user'] == 'username')
    assert_true(testds['connection'] == 'ssh')
    assert_true('user' in ds and 'user' not in testds)


# Generated at 2022-06-11 10:23:58.312397
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    assert True, "Test case not implemented"

# Generated at 2022-06-11 10:24:09.803982
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play._variable_manager = Mock()
    play._loader = Mock()

    #The following code forces a non-empty instance of a Block object to be returned when load_list_of_blocks() is called
    #This is necessary to pass the assert statement in get_tasks() at line 157
    play.pre_tasks = Mock()
    play.pre_tasks.append = Mock()
    play.pre_tasks.append.return_value = [Block.load(
        data={'meta': 'flush_handlers'},
        play=play,
        variable_manager=play._variable_manager,
        loader=play._loader
    )]

    play.tasks = Mock()
    play.tasks.append = Mock()

# Generated at 2022-06-11 10:24:20.402919
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create a new Play object.
    play_obj = Play()

    # Create a mocked object for the 'play_obj._ds' attribute.
    fake__ds = { 'user': 'test' }

    with patch.object(play_obj, '_ds', fake__ds):
        try:
            # Call the preprocess_data method.
            play_obj.preprocess_data(ds=fake__ds)
        except AnsibleAssertionError as e:
            print(FAIL + "AnsibleAssertionError raised when calling the preprocess_data method of Play object." + ENDC)
        except:
            pass
        else:
            print(PASS + "No exception raised when calling the preprocess_data method of Play object." + ENDC)

# Generated at 2022-06-11 10:24:21.701113
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-11 10:24:25.255539
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert Play().get_name() == r''
    assert Play(name='play1').get_name() == 'play1'
    assert Play(hosts='host1').get_name() == 'host1'

# Generated at 2022-06-11 10:24:28.811255
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    foo = {}
    foo[''] = ''
    foo[''] = ''
    foo[''] = ''
    foo[''] = ''
    foo[''] = ''

# Generated at 2022-06-11 10:24:44.088121
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.roles = [Role()]
    #TODO: implement


# Generated at 2022-06-11 10:24:50.221163
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import pytest
    play = Play()
    play.role_handlers = []
    result = play.compile_roles_handlers()
    assert result == []
    # second call to make sure we don't get a new result
    result2 = play.compile_roles_handlers()
    assert result2 == []
    assert result is result2


# Generated at 2022-06-11 10:24:53.265186
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''
    play.name = 'foobar'
    assert play.get_name() == 'foobar'

# Generated at 2022-06-11 10:25:01.672555
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    mock_playbook = MagicMock()
    mock_playbook.vars = {'hostvars': {}}
    mock_playbook.vars_prompt = {}
    mock_playbook.checkvars = {
        'hostvars': {'hostvars_key1': 'hostvars_value1'},
        'vars': {'vars_key1': 'vars_value1'},
        'vars_prompt': {'vars_prompt_key1': 'vars_prompt_value1'}
    }
    mock_variable_manager = VariableManager()
    mock_loader = DictDataLoader({})
    play = Play()
    play.name = '1.1.1.1'
    play.hosts = '1.1.1.1'

# Generated at 2022-06-11 10:25:08.720239
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Load the Play
    play = load_from_file('../../test/unit/fixtures/test_play/test_play.yml')

    # Get the vars associated to the play
    assert isinstance(play.get_vars_files(), list)
    assert any(['test_play.yml' in x for x in play.get_vars_files()])

# Generated at 2022-06-11 10:25:18.790232
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = [{"test.yml": {"test": "1"}}, {"test.yml": {"test": "2"}}]
    assert isinstance(p.get_vars_files(), list)
    assert len(p.get_vars_files()) == 2
    assert isinstance(p.get_vars_files(), list)
    assert p.get_vars_files()[0]["test.yml"]["test"] == "1"
    assert p.get_vars_files()[1]["test.yml"]["test"] == "2"


# Generated at 2022-06-11 10:25:22.510460
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Setup
    play = Play()
    play.pattern = 'all'
    block_list = play.compile_roles_handlers()
    # Test
    assert isinstance(play.roles, list)



# Generated at 2022-06-11 10:25:31.159330
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.vars.update({ 'foo': 'bar' })
    p.roles = [Role(name='foo', tasks=[Task(action=dict(module='debug', args=dict(msg='test')))])]
    p.handlers = [Handler(name='ok', tasks=[Task(action=dict(module='debug', args=dict(msg='test')))])]
    p.pre_tasks = [Task(action=dict(module='debug', args=dict(msg='test')))]
    p.tasks = [Task(action=dict(module='debug', args=dict(msg='test')))]
    p.post_tasks = [Task(action=dict(module='debug', args=dict(msg='test')))]
    p.serialize()


# Generated at 2022-06-11 10:25:44.328869
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    import ansible.playbook.play
    import ansible.utils.vault
    import tempfile
    plays = [
        dict(
            hosts='foo',
            user='root',
            pre_tasks=[
                dict(
                    ping='pong'
                )
            ],
            roles=[
                dict(
                    name='bar',
                )
            ],
            tasks=[
                dict(
                    debug=dict(
                        var='bar'
                    )
                )
            ],
            handlers=[
                dict(
                    meta=dict(
                        flush_handlers='yes'
                    )
                )
            ],
            post_tasks=[
                dict(
                    ping='pong'
                )
            ]
        )
    ]
    play = plays[0]
    vars_file = tempfile.N

# Generated at 2022-06-11 10:25:49.564196
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    obj = Play()
    assert obj.get_vars_files() == []

    obj.vars_files = "hello"
    assert obj.get_vars_files() == ["hello"]

    obj.vars_files = None
    assert obj.get_vars_files() == []

    obj.vars_files = ["hello", "world"]
    assert obj.get_vars_files() == ["hello", "world"]

# Generated at 2022-06-11 10:26:50.465287
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()

    assert play.get_name() == '', 'Hosts list is empty'
    play._ds['hosts'] = 1
    assert play.get_name() == '1', 'Hosts list has 1 element'
    play._ds['hosts'] = [1]
    assert play.get_name() == '1', 'Hosts list has 1 element'
    play._ds['hosts'] = [1, 2]
    assert play.get_name() == '1,2', 'Hosts list has 2 elements'


# Generated at 2022-06-11 10:26:51.478764
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert(True)

# Generated at 2022-06-11 10:26:59.938420
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    # Test 1
    vf = ['some_file.yml']
    p.vars_files = vf
    result = p.get_vars_files()
    assert result == vf
    # Test 2
    p.vars_files = None
    result = p.get_vars_files()
    assert result == []
    # Test 3
    p.vars_files = 'another_file.yml'
    result = p.get_vars_files()
    assert result == ['another_file.yml']


# Generated at 2022-06-11 10:27:08.981637
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Setup args needed to create the object
    log = logging.getLogger('ansible-playbook')
    log.setLevel(logging.ERROR)
    loader = DictDataLoader({})
    results = C.CombinedGlobalAnsibleVars(loader=loader, variables={})
    variable_manager = VariableManager(loader=loader, inventory=None, all_vars_lookup_result=results)

# Generated at 2022-06-11 10:27:18.212864
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # this test doesn't really test anything.  It is only here to make sure
    # that the method `get_vars_files` of `Play` has 100% coverage.
    # It's testing that it does what it does without breaking it.
    p = Play()
    # this is a cheap hack to get a 'self' with a .vars_files set.
    d = p._serializable_dict()
    p._included_path = 'foo_included_path'
    p.vars_files = ['/tmp/vars_files']
    if p.get_vars_files() != p.vars_files:
        raise Exception("Expected that get_vars_files() would return a list of one element "
                        "equal to the value of Play.vars_files")

# Generated at 2022-06-11 10:27:19.944406
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play.preprocess_data(dict(hosts='hosts'))

# Generated at 2022-06-11 10:27:22.460615
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    play.get_name = "test"
    play.hosts = []
    play.roles = []
    play.serialize()

# Generated at 2022-06-11 10:27:23.495823
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    assert True

# Generated at 2022-06-11 10:27:24.134490
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-11 10:27:31.705101
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    class FakeRole(object):
        def __init__(self):
            self.handlers = ["handler1", "handler2", "handler3"]
    class FakePlay(Play):
        def __init__(self):
            self.roles = [FakeRole(), FakeRole(), FakeRole()]
    fake_play = FakePlay()
    fake_play.compile_roles_handlers()
    assert_equal(fake_play.handlers, ["handler1", "handler2", "handler3", "handler1", "handler2", "handler3", "handler1", "handler2", "handler3"])

# Generated at 2022-06-11 10:28:01.510856
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.tasks.append("hello")
    play.pre_tasks.append("hi")
    play.post_tasks.append("bye")
    assert play.get_tasks() == ["hi", "hello", "bye"]
    assert play.get_tasks() == ["hi", "hello", "bye"]

# Generated at 2022-06-11 10:28:05.965262
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()
    test_task = Task()
    test_task.register = 'failed'
    block = Block()
    block.block = [test_task]
    test_play.tasks = [block]
    roles = test_play.compile_roles_handlers()
    assert roles == [block], "Roles are not same"
