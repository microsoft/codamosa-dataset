

# Generated at 2022-06-11 10:18:32.278511
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()

# Generated at 2022-06-11 10:18:36.773039
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize({'roles': [{'_include_path': '../a.yml', '_role_path': '/tmp/b.yml'}]})
    print(play.roles[0].include_path)

# Generated at 2022-06-11 10:18:45.715694
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    assert play.get_vars_files() == []
    play.vars_files = []
    assert play.get_vars_files() == []
    play.vars_files = 'abc.txt'
    assert play.get_vars_files() == ['abc.txt']
    play.vars_files = ['abc.txt']
    assert play.get_vars_files() == ['abc.txt']
    play.vars_files = None
    assert play.get_vars_files() == []



# Generated at 2022-06-11 10:18:47.804836
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # (data)
    # (data) Results:
    assert True == True # TODO: implement your test here


# Generated at 2022-06-11 10:18:54.357807
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()

    # create fake file
    with open(os.path.dirname(os.path.realpath(__file__)) + "/playbooks/playbook.yml", "w") as playbook_file:
        playbook_file.write("")

    # create variables file
    with open(os.path.dirname(os.path.realpath(__file__)) + "/playbooks/vars.yml", "w") as var_file:
        var_file.write("variable: value")

    # create the role file
    with open(os.path.dirname(os.path.realpath(__file__)) + "/playbooks/role-test.yml", "w") as role_var_file:
        role_var_file.write("- name: This is a test\n  variable: value")



# Generated at 2022-06-11 10:19:05.732734
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    task_1 = Task()
    task_1.set_loader(DictDataLoader({}))
    task_2 = Task()
    task_2.set_loader(DictDataLoader({}))
    block = Block()
    block.set_loader(DictDataLoader({}))
    block.block = [task_1]
    block.always = [task_2]
    p.pre_tasks = [task_1]
    p.tasks = [block]
    p.post_tasks = [task_2]
    assert p.get_tasks() == [task_1, task_1, task_2, task_2]



# Generated at 2022-06-11 10:19:08.379994
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = ['invalid']
    Play.preprocess_data(data)


# Generated at 2022-06-11 10:19:09.141411
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:19:19.416940
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Unit test for method compile_roles_handlers of class Play
    '''
    play = Play()
    play._load_vars = Mock(return_value = dict())
    play._variable_manager = Mock()
    play._loader = Mock()
    play._load_roles = Mock(return_value = [])
    play.roles = []
    play.post_tasks = []
    play.tasks = []
    play.pre_tasks = []
    play.handlers = []
    play.only_tags = []

    r1 = Role()
    play.roles.append(r1)
    assert play.compile_roles_handlers() == []
    r1.get_handler_blocks = Mock(return_value = ['h1'])
    assert play.compile_

# Generated at 2022-06-11 10:19:26.820878
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play_name = u'Ansible Play'
    play = Play(name=play_name, host_list=[u'nginx'])
    play.tasks = [{u'meta': u'flush_handlers'}]
    assert play.get_tasks() == [{u'meta': u'flush_handlers'}]


# Generated at 2022-06-11 10:19:45.390840
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.plugins.connection.local import Connection
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.errors import AnsibleAssertionError, AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()
    options = ImmutableDict()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:19:54.325352
# Unit test for constructor of class Play
def test_Play():

    # Test init without args
    p = Play()
    assert isinstance(p, Play)
    assert p._ds == dict()
    assert isinstance(p.vars, dict)
    assert p.vars == dict()
    assert isinstance(p.roles, list)
    assert p.roles == list()
    assert isinstance(p.role_names, list)
    assert p.role_names == list()
    assert isinstance(p.tasks, list)
    assert p.tasks == list()
    assert isinstance(p.post_tasks, list)
    assert p.post_tasks == list()
    assert isinstance(p.pre_tasks, list)
    assert p.pre_tasks == list()
    assert isinstance(p.handlers, list)
    assert p.handlers

# Generated at 2022-06-11 10:20:01.344581
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    if 'user' in ds:
        # this should never happen, but error out with a helpful message
        # to the user if it does...
        if 'remote_user' in ds:
            raise AnsibleParserError("both 'user' and 'remote_user' are set for this play. "
                                     "The use of 'user' is deprecated, and should be removed", obj=ds)

        ds['remote_user'] = ds['user']
        del ds['user']
    return ds


# Generated at 2022-06-11 10:20:07.948979
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds =  {'name': 'Test'}
    p = Play()
    p.preprocess_data(ds)
    assert p._ds == ds
    ds =  {'user': 'Test'}
    p = Play()
    p.preprocess_data(ds)
    assert p._ds == {'remote_user': 'Test'}



# Generated at 2022-06-11 10:20:13.258473
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_play = Play()
    test_play.vars_files = '/etc/hosts'
    assert test_play.get_vars_files() == ['/etc/hosts']
    test_play.vars_files = ['/etc/hosts', '/etc/profile']
    assert test_play.get_vars_files() == ['/etc/hosts', '/etc/profile']


# Generated at 2022-06-11 10:20:14.523115
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # TODO: write a real unit test
    assert False


# Generated at 2022-06-11 10:20:15.508736
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-11 10:20:26.413830
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Create an instance of class Play
    play1 = Play()

    name = play1.get_name()
    assert name == ''

    play1.name = 'Test name'
    assert play1.name == 'Test name'

    name = play1.get_name()
    assert name == 'Test name'

    play1.hosts = ['host1', 'host2', 'host3']
    assert play1.hosts == ['host1', 'host2', 'host3']
    assert isinstance(play1.hosts, list)

    name = play1.get_name()
    assert name == 'host1,host2,host3'
    assert isinstance(name, str)

    play1.hosts = ""
    assert play1.hosts == ""

    name = play1.get_name()

# Generated at 2022-06-11 10:20:37.120739
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = [{'user': 'test'}]
    p = Play.load(ds)
    assert p._ds == [{'remote_user': 'test'}]
    assert p.remote_user == 'test'
    del p._ds[0]['remote_user']
    ds = {'user': 'test'}
    p.preprocess_data(ds)
    assert p._ds == {'remote_user': 'test'}
    assert p.remote_user == 'test'
    del p._ds['remote_user']
    ds = {'hosts': None}
    p.preprocess_data(ds)
    assert p._ds == {'hosts': None}
    assert p._hosts == None
    ds = {'hosts': 'test'}
    p.preprocess

# Generated at 2022-06-11 10:20:39.017507
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.name = "test"
    print(p.get_name())
    

# Generated at 2022-06-11 10:20:54.622127
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = dad.Play()
    task_1 = dad.Task()
    task_2 = dad.Task()
    task_3 = dad.Task()
    play.pre_tasks.append(task_1)
    play.tasks.append(task_2)
    play.post_tasks.append(task_3)
    assert play.get_tasks() == [task_1, task_2, task_3]


# Generated at 2022-06-11 10:20:55.740070
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-11 10:21:04.493867
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Setup
    test_host = "testhost"
    test_tasks = [{"action": {"module": "fail", "args": {"msg": "abc"}}},
                  {"action": {"module": "fail", "args": {"msg": "yolo"}}}]

    test_handlers = [{"listen": "all"},
                     {"action": {"module": "debug", "args": {"msg": "abc"}}},
                     {"action": {"module": "failed", "args": {"msg": "yolo"}}}]
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    inventory.add_host(test_host)

    # Test scenario 1: when handlers are present

# Generated at 2022-06-11 10:21:15.446841
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
  from ansible.vars import VariableManager
  from ansible.inventory import Inventory
  from ansible.playbook.play_context import PlayContext
  from ansible.playbook.task import Task
  play_context = PlayContext()
  variable_manager = VariableManager()
  loader_mock = MagicMock()
  variable_manager.set_inventory(Inventory())
  task1 = Task()
  task2 = Task()
  task3 = Task()
  task4 = Task()
  task1._ds = {'name': 'task1', 'action': {'__ansible_module__': 'mock'}}
  task2._ds = {'name': 'task2', 'action': {'__ansible_module__': 'mock'}}

# Generated at 2022-06-11 10:21:24.064492
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    Test :meth:`Play.get_vars_files`
    '''
    playbook = Play()
    playbook.vars_files = null
    playbook.get_vars_files()
    playbook.vars_files = ['values.yaml']
    playbook.get_vars_files()
    playbook.vars_files = [{'x': 'y'}]
    playbook.get_vars_files()


# Generated at 2022-06-11 10:21:27.658643
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.post_validate()
    play = Play.load(p.serialize(), variable_manager=None)
    assert p.serialize() == play.serialize()

# Generated at 2022-06-11 10:21:30.832090
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Build a Play object that calls compile_roles_handlers
    play_obj = Play()
    play_obj.roles = [MockRole(), MockRole(), MockRole()]
    assert len(play_obj.compile_roles_handlers()) == 150

# Generated at 2022-06-11 10:21:40.800899
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # setup
    playbook = ansible.playbook.PlayBook(loader=DictDataLoader(), variable_manager=VariableManager())
    loader = DictDataLoader({
        "role_name": {
            "tasks": [
                {
                    "name": "This is a task",
                    "debug": {
                        "msg": "This is a debug message"
                    }
                }
            ],
            "handlers": {
                "name": "This is a handler"
            }
        }
    })

    for (playbook_content, expected_result) in [
        ({}, []),
        ({"roles": ["role_name"]}, [])
    ]:
        # exercise
        play = Play().load(playbook_content, variable_manager=VariableManager(), loader=loader)

        # verify

# Generated at 2022-06-11 10:21:51.981010
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = "test_name"
    # test name provided
    assert play.get_name() == "test_name"
    play.name = None
    assert play.get_name() == ''

    # test sequence
    play.hosts = [1,2,3]
    play.name = None
    assert play.get_name() == "1,2,3"
    # test string
    play.hosts = "1,2,3"
    play.name = None
    assert play.get_name() == "1,2,3"
    # test None
    play.hosts = None
    play.name = None
    assert play.get_name() == ""

# Generated at 2022-06-11 10:21:57.078503
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
  play = Play()
  assert play.get_vars_files() == []
  play.vars_files = ['/vars/common.yml', '/vars/apache.yml']
  assert play.get_vars_files() == ['/vars/common.yml', '/vars/apache.yml']


# Generated at 2022-06-11 10:22:16.815606
# Unit test for constructor of class Play
def test_Play():
    # Play is a subclass of Base so the constructor should work without arguments
    play = Play()

    # Play expects two keyword arguments
    play = Play(loader=None, variable_manager=None)

    # Initiaze Play object with constructor
    play = Play(name='UAT', hosts='host4')

# Generated at 2022-06-11 10:22:17.889949
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    assert True == True


# Generated at 2022-06-11 10:22:18.772606
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass

# Generated at 2022-06-11 10:22:29.085211
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Create a new Play
    p = Play()

    # Create two roles.
    r1 = Role()
    r2 = Role()

    # Create a list of roles, assign to 'roles' attribute of the Play
    p.roles = [r1, r2]

    # Create a list of handlers and assign to 'handlers' attribute of the Role
    r1.handlers = [Handler(), Handler()]
    r2.handlers = [Handler(), Handler()]

    # Call the method being tested
    actual_result = p.compile_roles_handlers()

    # Build a list of the handlers from the list of roles
    expected_result = []
    for r in p.roles:
        expected_result.extend(r.handlers)

    # Assert that the expected and actual results are the same
   

# Generated at 2022-06-11 10:22:33.710903
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    p = Play()
    p.pre_tasks = [1,2,3]
    p.tasks = [4,5,6]
    p.post_tasks = [7,8,9]

    assert p.get_tasks() == [1,2,3,4,5,6,7,8,9]


# Generated at 2022-06-11 10:22:44.368899
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Declare instance of class Play
    play = Play()
    # Declare instance of class Role
    role = Role()
    # Declare instance of class Block
    block = Block()
    # Declare instance of class Task
    task = Task()
    # Set value of attribute 'tasks' of instance block
    setattr(block, 'tasks', task)
    # Set value of attribute 'block' of instance block
    setattr(block, 'block', task)
    # Set value of attribute 'pre_tasks' of instance play
    setattr(play, 'pre_tasks', block)
    # Set value of attribute 'tasks' of instance play
    setattr(play, 'tasks', block)
    # Set value of attribute 'post_tasks' of instance play

# Generated at 2022-06-11 10:22:46.398100
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    Unit Test - Test preprocess_data method of class Play
    '''
    pass

# Generated at 2022-06-11 10:22:57.165243
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name == ''
    assert len(p.tags) == 0
    assert len(p.roles) == 0
    assert p.tasks == []
    assert p.handlers == []
    assert p.vars == {}
    assert p.vars_files == []
    assert p.hosts == []
    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.connection == C.DEFAULT_TRANSPORT
    assert p.port == C.DEFAULT_REMOTE_PORT
    assert p.gather_facts == C.DEFAULT_GATHERING
    assert p.max_fail_pct == 0
    assert p.serial == 1
    assert p.strategy == C.DEFAULT_STRATEGY
    assert p.sudo == C.DEFAULT

# Generated at 2022-06-11 10:22:59.663132
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.name = 'test'
    assert play.get_name() == 'test'

# Generated at 2022-06-11 10:23:11.368908
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import os
    import yaml
    l = [ 'play1', 'play2',]
    module_utils = 'module_utils'
    mydir, myname = os.path.split(os.path.abspath(__file__))
    data_dir = os.path.join(mydir, '..', 'data', 'play')
    path = os.path.join(data_dir, 'play_get_tasks.yml')
    with open(path) as f:
        p = Play.load(f.read(), variable_manager=VariableManager(), loader=DataLoader())
        for task in p.get_tasks():
            for t in task:
                if t.action == module_utils:
                    l[0] = l[0] + '*'

# Generated at 2022-06-11 10:23:28.818126
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.load(dict(hosts='localhost'))
    print(p.compile_roles_handlers())



# Generated at 2022-06-11 10:23:41.961503
# Unit test for constructor of class Play
def test_Play():

    play_source = dict(
        name = "Ansible Play",
        hosts = "127.0.0.1",
        gather_facts = "no",
        remote_user = "dev",
        vars = dict(a=1, b=2),
        roles = [
            dict(name="common"),
            dict(name="app1"),
            dict(name="app2")
        ],
        tasks = [
            dict(action=dict(module="setup")),
            dict(action=dict(module="apt", name="*", state="latest"))
        ]
    )

    # Test 1: Create a play from a datastructure
    p = Play.load(data=play_source)

    # Test 2: Create a copy of the play
    p.copy()

    # Test 3: Create a copy of the play

# Generated at 2022-06-11 10:23:47.908644
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    """
    function: test_Play_preprocess_data()
    purpose: To test the method: Play.preprocess_data
    """

    # create a Play() object
    p = Play()

    # create a dict with 'user' key
    ds = dict(user = 'ansible')

    # test if the ds dictionary is returned
    assert (p.preprocess_data(ds) == ds)

# Generated at 2022-06-11 10:23:54.631978
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = dict(
        pre_tasks=[dict(meta=dict(end_play=dict(when='')))],
        post_tasks=[dict(meta=dict(end_play=dict(when='')))],
        tasks=[dict(meta=dict(end_play=dict(when='')))]
    )

    pl = Play.load(data, variable_manager=VariableManager(), loader=DataLoader())

    assert len(pl.get_tasks()) == 3

# Generated at 2022-06-11 10:23:55.057772
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    pass

# Generated at 2022-06-11 10:23:55.861274
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    x = Play()
    assert x.compile_roles_handlers() == []

# Generated at 2022-06-11 10:24:01.681149
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Prepare test data
    ds = {'key1': 'val1', 'key2': 2}
    
    # Run test
    p = Play()
    result = p.preprocess_data(ds)
    
    # Verify results
    assert type(result) == dict
    assert len(result.items()) == 2
    
    

# Generated at 2022-06-11 10:24:12.512909
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()
    test_play.roles = []
    # test the case if play has roles
    r1 = Role()
    r1.name = 'r1'
    r1.handlers = ['h1', 'h2']
    r2 = Role()
    r2.name = 'r2'
    r2.handlers = ['h3', 'h4']
    r3 = Role()
    r3.name = 'r3'
    r3.handlers = ['h5', 'h6']
    test_play.roles.append(r1)
    test_play.roles.append(r2)
    test_play.roles.append(r3)

# Generated at 2022-06-11 10:24:14.644349
# Unit test for method get_name of class Play
def test_Play_get_name():
    myPlay = Play()
    myPlay.name = "myTestName"
    print(myPlay.get_name())

# Generated at 2022-06-11 10:24:26.412710
# Unit test for method serialize of class Play
def test_Play_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    # Test Play

# Generated at 2022-06-11 10:24:45.028908
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    Unit test for method preprocess_data of class Play
    '''
    p = Play()
    p.preprocess_data({})

# Generated at 2022-06-11 10:24:53.854766
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
	
    check= p.compile_roles_handlers()
    assert type(check) == list, "check should be a list"
    #Test is working properly
	
    p = Play()
    p.roles=['role1','role2','role3']
    #The input 'roles' is a list, so it should return the empty list
    check= p.compile_roles_handlers()
    assert type(check) == list, "check should be a list"
    #Test is working properly




# Generated at 2022-06-11 10:25:01.948382
# Unit test for constructor of class Play
def test_Play():
    args = dict(
        connection='local',
        remote_user='me',
        become='True',
        become_method='sudo',
        become_user='root',
        check=False,
        # gather_facts='smart',
        gather_facts='implicit',
        hosts='all',
        name='my play',
        roles='r1,r2',
        tasks='t1,t2',
        vars='@vars.yaml',
        vars_files='/etc/ansible/vars.yml',
    )
    p = Play().load(args)
    assert p.hosts == 'all'
    assert p.name == 'my play'
    assert p.connection == 'local'
    assert p.remote_user == 'me'
    assert p.become is True
    assert p

# Generated at 2022-06-11 10:25:06.498829
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.pre_tasks = [6]
    p.tasks = [7]
    p.post_tasks = [8]
    assert p.get_tasks() == [6, 7, 8]

# Generated at 2022-06-11 10:25:16.152759
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():

    test_tasks = [
        dict(action=dict(module='debug', args=dict(msg="Hello world!"))),
        dict(action=dict(module='setup'))
    ]

    test_play = Play.load(dict(
        name="Ansible Play Test",
        hosts=['localhost'],
        gather_facts='no',
        tasks=test_tasks
    ))

    # test that get_tasks returns the results from the compile method
    assert test_play.get_tasks() == test_play.compile()



# Generated at 2022-06-11 10:25:20.772105
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Create an instance of Play to test method
    p = Play()

    # Return the list of tasks if 'tasks' is present in the datastructure
    data = { 'tasks': [] }
    assert data == p.preprocess_data(data)

    # Return the list of tasks if 'pre_tasks' is present in the datastructure
    data = { 'pre_tasks': [] }
    assert data == p.preprocess_data(data)

    # Return the list of tasks if 'post_tasks' is present in the datastructure
    data = { 'post_tasks': [] }
    assert data == p.preprocess_data(data)

    # Return the list of tasks if 'handlers' is present in the datastructure
    data = { 'handlers': [] }
    assert data == p.preprocess

# Generated at 2022-06-11 10:25:26.860838
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]
    assert play.get_tasks() == [1,2,3,4,5,6,7,8,9]



# Generated at 2022-06-11 10:25:30.322274
# Unit test for method serialize of class Play
def test_Play_serialize():
    # test function
    input_data = {}
    test_instance = Play.load(input_data)
    result = test_instance.serialize()
    print("Result: " + repr(result))
    assert result is not None

# Generated at 2022-06-11 10:25:43.333889
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    p = Play()
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = "sys.yml"
    assert p.get_vars_files() == ["sys.yml"]
    p.vars_files = ["sys.yml", "sec.yml"]
    assert p.get_vars_files() == ["sys.yml", "sec.yml"]

# Generated at 2022-06-11 10:25:48.093289
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import json
    from ansiblelint.rules.TaskHasNameRule import TaskHasNameRule
    from ansiblelint.runner import Runner

    role = Role()
    role.__dict__ = json.load(open('roles/test/meta/main.json'))
    role_collection = RolesCollection()
    role_collection.__dict__ = json.load(open('roles/test/meta/roles_collections.json'))
    runner = Runner(role_collection, 'test', [TaskHasNameRule()], [])
    runner.run()
    assert len(role.compile_roles_handlers()) == 0

# Generated at 2022-06-11 10:26:33.830627
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class Mock_Block(object):
        def __init__(self):
            self.block = []
            self.rescue = []
            self.always = []

        def add_block(self, tasks):
            self.block += tasks

        def add_rescue(self, tasks):
            self.rescue += tasks

        def add_always(self, tasks):
            self.always += tasks

    class Mock_Task(object):
        def __init__(self):
            pass

    p = Play()
    p.pre_tasks = [Mock_Block()]
    p.tasks = [Mock_Block()]
    p.post_tasks = [Mock_Block()]

    assert p.get_tasks() == []

    task1 = Mock_Task()
    task2 = Mock_Task()


# Generated at 2022-06-11 10:26:38.980618
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ["a", "b", "c"]
    assert play.get_vars_files() == ["a", "b", "c"]
    play.vars_files = "d"
    assert play.get_vars_files() == ["d"]
    play.vars_files = None
    assert play.get_vars_files() == []


# Generated at 2022-06-11 10:26:43.276341
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert not p.get_vars_files()
    p.vars_files = None
    assert not p.get_vars_files()
    p.vars_files = 'file1'
    assert p.get_vars_files() == ['file1']


# Generated at 2022-06-11 10:26:44.726583
# Unit test for method get_name of class Play
def test_Play_get_name():
    play=Play()
    assert play.get_name()==''

# Generated at 2022-06-11 10:26:55.297781
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    def test(data, expected=None):
        if expected is None:
            expected = data
        test_dict = {'key': data}
        play.preprocess_data(test_dict)
        assert test_dict['key'] == expected
    yield test, None
    yield test, 'value'
    yield test, ['value']
    yield test, {'key': 'value'}
    yield test, {'key': 'value', 'user': 'me'}, {'key': 'value', 'remote_user': 'me'}
    yield test, {'key': 'value', 'remote_user': 'me', 'user': 'you'}, {'key': 'value', 'remote_user': 'you'}
    yield test, {'key': 'value', 'user': ['me', 'you']},

# Generated at 2022-06-11 10:27:05.706473
# Unit test for constructor of class Play
def test_Play():
    ################################################################################
    # Setup
    ################################################################################
    # Setup Play and verify defaults
    p1 = Play()
    assert p1.name == '', 'Play name not empty by default'
    assert len(p1.deprecated_tags) == 0, 'Play deprecated_tags not empty by default'
    assert len(p1.handlers) == 0, 'Play handlers not empty by default'
    assert len(p1.hosts) == 0, 'Play hosts not empty by default'
    assert p1.max_fail_percentage == 0, 'Play max_fail_percentage not 0 by default'
    assert p1.no_log is False, 'Play no_log not False by default'
    assert len(p1.pre_tasks) == 0, 'Play pre_tasks not empty by default'

# Generated at 2022-06-11 10:27:09.352806
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    # test normal result
    play.name = 'test_name'
    assert play.get_name() == 'test_name'
    # test error result
    play.name = ''
    try:
        assert play.get_name() == ''
    except AnsibleParserError:
        pass
    return True


# Generated at 2022-06-11 10:27:11.736691
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    task = Play()
    task.vars_files = [1,2]
    assert task.get_vars_files() == [1,2]


# Generated at 2022-06-11 10:27:18.895368
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.parsing.dataloader import DataLoader

    play_src = dict(
        name="test play",
        hosts='localhost',
        gather_facts='no',
        vars_files=['/tmp/test_Play_get_vars_files.yml'],
    )

    p = Play().load(
        play_src,
        variable_manager=VariableManager(),
        loader=DataLoader(),
    )

    assert p.get_vars_files() == ['/tmp/test_Play_get_vars_files.yml']



# Generated at 2022-06-11 10:27:28.433438
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    def create_vars_files_testcase(vars_files, expected_vars_files):
        l = loader.DataLoader()
        play_ds = dict(
            vars_files=vars_files
        )
        play = Play.load(play_ds, variable_manager=variables.VariableManager(), loader=l)
        vars_files = play.get_vars_files()
        assert vars_files == expected_vars_files
    create_vars_files_testcase(None, [])
    create_vars_files_testcase([], [])
    create_vars_files_testcase("/path/to/file.yml", ["/path/to/file.yml"])

# Generated at 2022-06-11 10:28:08.753801
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    def_dict = {}
    host_list = ["localhost"]
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host_list[0], "name", "localhost")
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=host_list)
    variable_manager.set_inventory(inventory)
    loader = DataLoader()
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict()), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )