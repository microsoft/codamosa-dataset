

# Generated at 2022-06-11 10:18:27.819139
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = "/home/username/ansible/playbooks/vars.yaml"
    play.deserialize("/home/username/ansible/playbooks/vars.yaml")
    assert play.get_vars_files() == ['/home/username/ansible/playbooks/vars.yaml']


# Generated at 2022-06-11 10:18:31.594667
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    data = {'tags': [], 'hosts': ['all'], 'name': '', 'connection': 'smart', 'vars': {}, 'remote_user': 'root'}
    play.deserialize(data)
    assert play.tags == [] and play.hosts == 'all' and play.name == '' and play.connection == 'smart' and play.vars == {} and play.remote_user == 'root'

# Generated at 2022-06-11 10:18:32.072718
# Unit test for constructor of class Play
def test_Play():
    pass

# Generated at 2022-06-11 10:18:43.357378
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pm = RoleManager()
    pm._role_paths = [my_path]
    pm.load_roles()
    roles = pm.get_roles()
    role = roles[0]

    play = Play()
    play.roles = [role]
    blocks = play.compile_roles_handlers()
    assert len(blocks) == 2
    assert blocks[0][0].name == 'role-handler'
    assert blocks[1][0].name == 'role-handler'
    assert blocks[0][0].block.block[0].name == 'role-handler-inner'
    assert blocks[1][0].block.block[0].name == 'role-handler-inner'



# Generated at 2022-06-11 10:18:49.855052
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    assert play.get_vars_files() == []

    play.vars_files = []
    assert play.get_vars_files() == []

    play.vars_files = 'abc.yml'
    assert play.get_vars_files() == ['abc.yml']

    play.vars_files = ['abc.yml', 'xyz.yml']
    assert play.get_vars_files() == ['abc.yml', 'xyz.yml']



# Generated at 2022-06-11 10:18:57.344578
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = dict(name = 'test', roles = [dict(name = 'test')])
    test = Play()
    test.deserialize(data)
    assert test.roles[0].name == 'test'
    assert test.name == 'test'
# Test data for method get_vars of class Play
test_data_Play_get_vars = [
(
    dict(name = 'test', vars = dict(test = 'test'))
)]


# Generated at 2022-06-11 10:19:06.966339
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    _test_data = [
        # (expected value, input value for vars_files)
        (['./var/foo'], './var/foo'),
        (['./var/foo, ./var/bar'], ['./var/foo, ./var/bar']),
        (['./var/foo', './var/bar'], ['./var/foo', './var/bar'])
    ]
    for expected, input in _test_data:
        play = Play()
        play.vars_files = input
        assert play.get_vars_files() == expected


# Generated at 2022-06-11 10:19:18.162644
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    Unit test for method preprocess_data of class Play
    '''

    # Data parameters for test
    data = {'user': 'bob'}
    ds = {'hosts': 'host1', 'vars': data}

    # Play object for testing
    test_play = Play()
    test_play = test_play.load_data(ds, variable_manager=VariableManager(), loader=None)

    # Ensure no error is raised
    try:
        result = test_play.preprocess_data(test_play.__getattribute__('_ds'))
    except:
        assert False, 'Unexpected exception thrown'

    # Ensure 'user' was cleared and 'remote_user' has the value of 'bob'
    assert 'user' not in result['vars']

# Generated at 2022-06-11 10:19:32.487797
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    def __init__(self, play):
        # play.get_name() => abc
        self._play = play
        self._handler_blocks = []
        self._role_name = 'role_name'

    # Role.get_handler_blocks() => self._handler_blocks
    def get_handler_blocks(self, play):
        return self._handler_blocks

    # Play.get_roles() => [Role()]
    # Play.get_roles().__class__ => <class 'list'>
    # Play.get_roles()[0] => role
    # Play.get_roles()[0].get_handler_blocks() => self._handler_blocks
    # Play.get_roles()[0].get_handler_blocks().__class__ => <class 'list'>
    # Play.get_ro

# Generated at 2022-06-11 10:19:33.665554
# Unit test for method serialize of class Play
def test_Play_serialize():
    pass


# Generated at 2022-06-11 10:19:46.662007
# Unit test for method get_name of class Play
def test_Play_get_name():
  a=Play()
  print("test_get_name of class Play")
  print("name of a :" + a.name)


'''  
  The class Host is used to represent an individual host, which will
    be the target of some action or set of actions.  This class
    contains all the information Ansible uses to connect to and manage a
    host; the main class which contains this information is
    Inventory.
'''

# Generated at 2022-06-11 10:19:50.733682
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    data = {
        'hosts': 'localhost',
        'vars': {
            'a': 'b'
        },
        'tasks': [
            {'debug': 'msg={{a}}'}
        ]
    }
    p = Play()
    p.load_data(data)
    assert p.get_vars_files() == []


# Generated at 2022-06-11 10:19:52.660762
# Unit test for method serialize of class Play
def test_Play_serialize():
    play_obj = Play()
    assert isinstance(play_obj.serialize(), dict)

# Generated at 2022-06-11 10:19:57.658897
# Unit test for method get_name of class Play
def test_Play_get_name():
    play1 = Play()
    # Test: play name is None.
    assert play1.get_name() is None
    play1.name = 'Blah'
    # Test: play name is a string
    assert isinstance(play1.get_name(), str)
    # Test: play name is string.
    assert play1.get_name() == 'Blah'


# Generated at 2022-06-11 10:20:01.737212
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # We don't test the type of the deserialized data becaues some of it is
    # created dynamically in that method which makes the test brittle.
    # We are happy with the exception testing in the method itself.
    play = Play()
    play.deserialize({})



# Generated at 2022-06-11 10:20:06.386790
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # 
    # setup
    # 
    p = Play()
    # 
    # test
    # 
    # 
    # assert
    # 
    assert p.get_vars_files() == []

# Generated at 2022-06-11 10:20:07.766698
# Unit test for method serialize of class Play
def test_Play_serialize():
    # TODO
    return True


# Generated at 2022-06-11 10:20:16.896200
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    # Test with 'user' key in data structure
    ds = {
        "name": "test_play",
        "hosts": ["all"],
        "user": "linux-user",
        "tasks": [
            {
                "action": {
                    "module": "ping"
                }
            }
        ]
    }
    p = Play.load(ds)
    p.post_validate()
    assert p.remote_user == 'linux-user'
    assert not hasattr(p, 'user')
    
    # Test with 'user' and 'remote_user' key in data structure

# Generated at 2022-06-11 10:20:25.189815
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = None
    assert [] == p.get_vars_files()
    p.vars_files = "test"
    assert ["test"] == p.get_vars_files()
    p.vars_files = ["test", "test2"]
    assert ["test", "test2"] == p.get_vars_files()
    p.vars_files = p.vars_files + ["test3"]
    assert ["test", "test2", "test3"] == p.get_vars_files()


# Generated at 2022-06-11 10:20:29.447530
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play_dict = {'hosts': 'localhost', 'user': 'root'}
    play_obj = Play()
    assert play_obj.preprocess_data(play_dict) == {'hosts': 'localhost', 'remote_user': 'root'}


# Generated at 2022-06-11 10:20:58.837365
# Unit test for method get_name of class Play
def test_Play_get_name():
    ### TEST TEMPLATE
    # Arrange
    import ansible.playbook.play
    import ansible.playbook.task.meta
    import ansible.playbook.block

    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import iteritems

    # data object
    data = {}
    data['hosts'] = 'localhost'

    # object to test
    p = ansible.playbook.play.Play()
    # data to compile
    p.load_data(data)

    # Arrange
    expected_return_value = 'localhost'

    # Act
    ret = p.get_name()

    # Assert

# Generated at 2022-06-11 10:21:04.654129
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class Test(unittest.TestCase):
        def setUp(self):
            self.p = Play()
        def test_Play_get_tasks(self):
            self.p.pre_tasks.append("pre_task")
            self.p.tasks.append("task")
            self.p.post_tasks.append("post_task")
            self.assertEqual("pre_task task post_task", " ".join(self.p.get_tasks()))
    unittest.main()

# Generated at 2022-06-11 10:21:08.358165
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    test_Play = Play()
    test_Play.pre_tasks = [1]
    test_Play.tasks = [2]
    test_Play.post_tasks = [3]
    assert test_Play.get_tasks() == [1, 2, 3]

# Generated at 2022-06-11 10:21:20.790576
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Create a Play instance
    play = Play()

    # Create a Role instance
    role = Role()

    # Create a dictionary to store the role data
    role_data = {}
    role_data['role_path'] = '/path/to/role'
    role_data['role_name'] = 'role'
    role_data['role_display_name'] = None

    # Deserialize the data in Role instance
    role.deserialize(role_data)

    # Create a list of Role instances
    roles = []
    roles.append(role)

    # Create a dictionary to store the play data
    data = {}
    data['connection'] = 'ssh'
    data['gather_facts'] = 'yes'
    data['hosts'] = 'localhost'

# Generated at 2022-06-11 10:21:23.976456
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    assert Play.preprocess_data({}) == {}
    assert Play.preprocess_data({'user':'ansible'}) == {'remote_user':'ansible'}
    assert Play.preprocess_data({'remote_user':'ansible'}) == {'remote_user':'ansible'}
    assert Play.preprocess_data({'user':'ansible', 'remote_user':'ansible'}) == '''
{ user:ansible, remote_user:ansible}''' # error




# Generated at 2022-06-11 10:21:33.854838
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    role_ds = [{'role': 'b', 'when': 'x'},
               {'role': 'a', 'when': 'y'},
               {'role': 'c'}]
    play.preprocess_data({'roles': role_ds})
    assert play.roles[0].name == 'b'
    assert play.roles[1].name == 'a'
    assert play.roles[2].name == 'c'

    # role names should be converted to unicode
    assert isinstance(play.roles[0].name, text_type)

    play = Play()
    play.preprocess_data({'variables': []})
    assert play.vars is not None
    assert play.vars == {}

    play = Play()

# Generated at 2022-06-11 10:21:44.569099
# Unit test for method get_tasks of class Play

# Generated at 2022-06-11 10:21:56.994110
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    ''' Unit test for method deserialize of class Play '''
    #
    #   PLAY [all] *********************************************************************
    #

    #
    #   TASK: [ping] *******************************************************************
    #
    #   ok: [localhost] => {"changed": false, "ping": "pong"}
    #
    #   TASK: [debug msg="Hello World!"] ***********************************************
    #
    #   ok: [localhost] => {"msg": "Hello World!"}
    #
    #   PLAY RECAP ********************************************************************
    #
    #   localhost                  : ok=2    changed=0    unreachable=0    failed=0
    #
    #
    #   PLAY [all] *********************************************************************
    #

    #
    #   TASK: [ping] *******************************************************************
    #
   

# Generated at 2022-06-11 10:21:58.598234
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.compile_roles_handlers()


# Generated at 2022-06-11 10:22:10.058807
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from io import StringIO
    import yaml

    inv = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inv)

    playbook_path = os.path.join(os.path.dirname(__file__), 'playbook.yml')
    with open(playbook_path) as f:
        play_source = f.read()

    play = Play.load(play_source, variable_manager=variable_manager, loader=None)
    task_list = play.get_tasks()

# Generated at 2022-06-11 10:22:27.391908
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Given
    play = Play()
    play.pre_tasks = []
    play.post_tasks = []
    play.tasks = [
        'task1',
        'task2',
    ]

    # When
    result = play.get_tasks()

    # Then
    assert result == play.tasks



# Generated at 2022-06-11 10:22:38.064955
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # test does not test a return value of this method yet
    # initialize variables for test
    h = Play()
    h._callbacks = 5
    h._connection_plugins = 5
    h._default_vars = 5
    h._dep_chain = 5
    h._ds = 5
    h._files = 5
    h._force_handlers = 5
    h._included_conditional = 5
    h._included_path = 5
    h._inventory = 5
    h._loader = 5
    h._max_fail_percentage = 5
    h._meta = 5
    h._name = 5
    h._notify = 5
    h._notified_handlers = 5
    h._post_validate = 5
    h._serial = 5
    h._strategy = 5
    h._tags = 5


# Generated at 2022-06-11 10:22:42.054472
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    deserialized = yaml.safe_load(json.dumps(play.serialize()))
    play.deserialize = deserialized
    assert play.serialize() == deserialized
# Confirm that the Play class can be serialized

# Generated at 2022-06-11 10:22:52.704506
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    import os
    #from ansible.errors import AnsibleError
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude

    # Ansible 2.9
    # module_utils/facts/system/bsd.py
    # Ansible 2.9.12
    # module_utils/facts/system/bsd.py

# Generated at 2022-06-11 10:23:02.862261
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # arrange
    play = Play()
    play.roles = []
    for i in range(4):
        r = Role()
        r.name = "role{0}".format(i)
        r.get_handler_blocks = MagicMock(return_value=["handler.{0}".format(i)])
        play.roles.append(r)

    # act
    result = play.compile_roles_handlers()

    # assert
    assert result == ["handler.0", "handler.1", "handler.2", "handler.3"]
    for i in range(4):
        assert play.roles[i].get_handler_blocks.call_count == 1



# Generated at 2022-06-11 10:23:14.767979
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    
    def check(play_hosts, play_roles, role_tasks, role_handler, role_handler_tasks):
        super_set = set()

        for task in role_tasks:
            if task not in super_set:
                super_set.add(task)
        for task in role_handler_tasks:
            if task not in super_set:
                super_set.add(task)

        p = Play()
        p.hosts = play_hosts
        p.roles = [role_tasks, role_handler, role_handler_tasks]
        
        assert p.compile_roles_handlers() == [super_set]

    # check case with one role containing a handler

# Generated at 2022-06-11 10:23:15.729766
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    result = play.serialize()
    assert {} == result


# Generated at 2022-06-11 10:23:25.932448
# Unit test for method compile_roles_handlers of class Play

# Generated at 2022-06-11 10:23:36.312149
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    hosts = [dict(hostname='localhost')]
    play = Play()
    play.vars_files = 'file.yml'
    assert type(play.get_vars_files()) is list
    assert play.get_vars_files()[0] == 'file.yml'
    play.vars_files = ['file1.yml', 'file2.yml']
    assert type(play.get_vars_files()) is list
    assert play.get_vars_files()[0] == 'file1.yml'
    assert play.get_vars_files()[1] == 'file2.yml'



# Generated at 2022-06-11 10:23:47.858225
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._load_roles=[]
    block_list = p.compile_roles_handlers()
    assert block_list == [], "test_Play_compile_roles_handlers 1 failed"

    p = Play()
    p._load_roles=[]
    block_list = p.compile_roles_handlers()
    assert block_list == [], "test_Play_compile_roles_handlers 2 failed"

    p = Play()
    p._load_roles=[]
    block_list = p.compile_roles_handlers()
    assert block_list == [], "test_Play_compile_roles_handlers 3 failed"

    p = Play()
    p._load_roles=[]
    block_list = p.compile

# Generated at 2022-06-11 10:24:30.306507
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
  import sys
  from collections import namedtuple
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars import VariableManager
  from ansible.inventory import Inventory
  from ansible.playbook.play import Play
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible.plugins.callback import CallbackBase
  
  class ResultCallback(CallbackBase):
    """A sample callback plugin used for performing an action as results come in

    If you want to collect all results into a single object for processing at
    the end of the execution, look into utilizing the ``json`` callback plugin
    or writing your own custom callback plugin
    """

# Generated at 2022-06-11 10:24:38.151959
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Dummy values for test
    play_name = 'host1'
    play_hosts = 'host1'
    skip_tags = 'host1'
    only_tags = 'host1'

    # make a Play object
    a_play = Play()

    # make a play data
    data = {'name': play_name, 'hosts': play_hosts, 'skip_tags': skip_tags, 'only_tags': only_tags}

    # initialize the play.
    a_play.deserialize(data)

    # check to make sure the values are correct.
    assert a_play.get_name() == play_name
    assert a_play.hosts == play_hosts
    assert a_play.skip_tags == skip_tags
    assert a_play.only_tags == only_tags
#

# Generated at 2022-06-11 10:24:47.487754
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    with pytest.raises(AnsibleParserError):
        p._deserialize(dict(hosts=[1,2,3]))
    assert p.deserialize({}) is p
    p.deserialize({'hosts': [1,2,3]})
    assert p.hosts == [1,2,3]
    p.deserialize({'vars': {'a': 'b'}})
    assert p.vars == {'a': 'b'}
    p.deserialize({'vars_files': 'test.yml'})
    assert p.vars_files == 'test.yml'



# Generated at 2022-06-11 10:24:54.993415
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    p = Play()
    p.vars_files = ['/etc/passwd', '/etc/shadow']
    assert p.get_vars_files() == ['/etc/passwd', '/etc/shadow']

    p.vars_files = None
    assert p.get_vars_files() == []

    p.vars_files = "/etc/group"
    assert p.get_vars_files() == ["/etc/group"]



# Generated at 2022-06-11 10:25:02.351885
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # data_ds_1 contains 'user' key
    data_ds_1 = {
        'hosts': 'all',
        'gather_facts': 'no',
        'user': 'foo'
    }

    # data_ds_2 contains 'remote_user' key
    data_ds_2 = {
        'hosts': 'all',
        'gather_facts': 'no',
        'remote_user': 'foo'
    }

    # data_ds_3 doesn't contain 'user' key
    data_ds_3 = {
        'hosts': 'all',
        'gather_facts': 'no',
    }

    # data_ds_4 doesn't contain 'user' key and 'remote_user' key
    data_ds_4 = {
    }

    # data_ds_5 contains

# Generated at 2022-06-11 10:25:07.465095
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play._load_roles(['roles'], play)
    roles = play.get_roles()
    play.compile_roles_handlers()
    assert len(play.compile_roles_handlers()) == 5

 

# Generated at 2022-06-11 10:25:08.893599
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    raise NotImplementedError()

# Generated at 2022-06-11 10:25:11.486007
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_play = Play()
    test_play.roles = [Role()]
    assert test_play.compile_roles_handlers() == []

# Generated at 2022-06-11 10:25:16.674680
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    play._ds = {'vars': {}, 'hosts': 'all'}
    play.preprocess_data(play._ds)
    assert play._ds['vars'] == {}
    assert play._ds['hosts'] == 'all'


# Generated at 2022-06-11 10:25:20.836434
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Make a new Play object.
    p = Play()

    # Assign to variables of the Play object.
    p.vars_files = None

    #Check if it is same as expected output.
    assert p.get_vars_files() == []




# Generated at 2022-06-11 10:26:24.265126
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    obj = Play()
    obj._loader = DataLoader()
    obj._variable_manager = VariableManager()
    obj._variable_manager.extra_vars = load_extra_vars(loader=obj._loader, options=context.CLIARGS)
    obj._variable_manager.options_vars = load_options_vars(loader=obj._loader, options=context.CLIARGS)

    data = obj.serialize()
    obj.deserialize(data)



# Generated at 2022-06-11 10:26:33.257821
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansiblelint import AnsibleLintRule

    with open('tests/test_data/plays/play_multiple_task_calls.yml', 'r') as f:
        play_data = yaml.load(f)
        play = Play.load(play_data)

        tasks = play.get_tasks()
        assert len(tasks) == 2

        # This is a long test of all the tasks

# Generated at 2022-06-11 10:26:37.402871
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    ####################################
    #  test variable initialization
    ####################################
    play = Play()
    ####################################
    #  test function execution
    ####################################
    play.compile_roles_handlers()

    print('play.compile_roles_handlers() = %s' % play.compile_roles_handlers())

# Generated at 2022-06-11 10:26:47.968765
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    loader = AnsibleLoader(None)
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'role_name': 'myrole'}
    loader._variable_manager = variable_manager

# Generated at 2022-06-11 10:26:59.059327
# Unit test for method deserialize of class Play

# Generated at 2022-06-11 10:27:02.959896
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    #testing with a null case
    try:
        test_result = play.compile_roles_handlers()
    except Exception as e:
        assert False, "Exception:" + str(e)
    assert test_result == [], "assertion failed"

# Generated at 2022-06-11 10:27:03.663638
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:27:07.790816
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  play = Play()
  play.roles = [Role()]
  play.roles[0]._handlers = [Handler()]
  play.roles[0].from_include = False
  assert play.compile_roles_handlers() == play.roles[0]._handlers # list with single item


# Generated at 2022-06-11 10:27:09.165946
# Unit test for constructor of class Play
def test_Play():
    play = Play()
    assert play is not None


# Generated at 2022-06-11 10:27:18.347248
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    ################################################################################
    # Play.get_vars_files: Test get_vars_files method of Play class
    #
    # Run the get_vars_files and make sure it returns a list
    ################################################################################
    print('Play.get_vars_files: Test get_vars_files method of Play class')

    # Create PLAY_DS object

# Generated at 2022-06-11 10:27:52.305418
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    vars_files_result = p.get_vars_files()

    assert type(vars_files_result) == list
    assert vars_files_result == []


# Generated at 2022-06-11 10:27:53.665272
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()


## Unit Test for method load of class Play

# Generated at 2022-06-11 10:28:03.503166
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    data = dict(name="NAME",
                hosts="A",
                become=True,
                become_user="B",
                become_method="C",
                connection="E",
                gather_facts="G",
                serial="H",
                max_fail_percentage="I")
    p.deserialize(data)
    assert p.name == "NAME"
    assert p.gather_facts == "G"
    assert p.serial == "H"
    assert p.connection == "E"
    assert p.max_fail_percentage == "I"
    assert p.become_method == "C"
    assert p.become_user == "B"
    assert p.become == True
    assert p.hosts == "A"



# Generated at 2022-06-11 10:28:06.568424
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    data = {'roles': [{'name': 'a', 'from_include': True}, {'name': 'b'}]}
    p.deserialize(data)
    assert p.roles[0].name == 'a'