

# Generated at 2022-06-11 10:18:27.818996
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    ds = dict(
        name="This is a test play",
        hosts="all",
        pre_tasks=[
            dict(
                block=[
                    dict(
                        name="pre_task1",
                        debug=dict(msg="pre_task1 msg")
                    )
                ]
            )
        ],
        roles=[
            dict(
                name="role1",
                tasks_path="role1_tasks.yml"
            )
        ],
        tasks=[
            dict(
                include='role1_tasks.yml'
            )
        ],
        post_tasks=[
            dict(
                block=[
                    dict(
                        name="post_task1",
                        debug=dict(msg="post_task1 msg")
                    )
                ]
            )
        ]
    )

    play

# Generated at 2022-06-11 10:18:31.373356
# Unit test for method get_name of class Play
def test_Play_get_name():
    assert Play().get_name() == ''

    p = Play()
    p.name = 'my_play'
    assert p.get_name() == 'my_play'
    p.name = None
    p.hosts = 'localhost'
    assert p.get_name() == 'localhost'
    p.hosts = ['localhost', 'otherhost']
    assert p.get_name() == 'localhost,otherhost'


# Generated at 2022-06-11 10:18:44.359587
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # instanciation
    p = Play()
    # play is object instance with fields attributes
    assert isinstance(p,Play)
    assert isinstance(p.attributes,dict)
    # retrieve the list of field attribute
    att_list = p.attributes.keys()
    # deserialize play json object
    p.deserialize({"name": "play", "hosts": "host1"})
    # verify attribute name of play object after deserialize
    assert p.name == "play"
    # verify attribute hosts of play object after deserialize
    assert p.hosts == "host1"
    # verify the other attributes of play object after deserialize

# Generated at 2022-06-11 10:18:48.979723
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    p.preprocess_data({'user': 'some_user'})
    assert type(p) == Play
    assert p.remote_user == 'some_user'
    p.preprocess_data({'remote_user': 'some_user'})
    assert type(p) == Play
    assert p.remote_user == 'some_user'



# Generated at 2022-06-11 10:18:50.966908
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    #from ansible.playbook.play import Play
    p = Play()
    p.preprocess_data()

# Generated at 2022-06-11 10:18:59.482620
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    my_play = Play()
    my_play.vars_files = ['my_play_var_file.yml']
    assert my_play.get_vars_files() == ['my_play_var_file.yml']
    assert my_play.vars_files == ['my_play_var_file.yml']
    my_play.vars_files = None
    assert my_play.get_vars_files() == []
    assert my_play.vars_files is None

# Generated at 2022-06-11 10:19:00.853110
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
  pass


# Generated at 2022-06-11 10:19:02.592765
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = dict()
    p = Play()
    p.deserialize(data)

# Generated at 2022-06-11 10:19:11.154545
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    '''
    Test the deserialize of class Play.
    '''
    # To avoid the debug data output before the assert, we use context manager here
    with redirect_stdout(StringIO()):
        # call the method under test
        result = Play()
        play_data = {'_uuid': '12345', 'hosts': 'hosts'}
        result.deserialize(play_data)

    assert result._uuid == '12345'
    assert result.hosts == 'hosts'


# Generated at 2022-06-11 10:19:20.511474
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    pre_tasks = [
        {'name': 'first pre task'},
        {'name': 'second pre task'}
    ]
    block1 = {'name': 'Block task'}
    tasks = [
        {'name': 'first task'},
        {'name': 'second task'}
    ]
    post_tasks = [
        {'name': 'first post task'},
        {'name': 'second post task'}
    ]
    for task in pre_tasks:
        p.pre_tasks.append(Task().load(task, p))
    for task in tasks:
        p.tasks.append(Task().load(task, p))

# Generated at 2022-06-11 10:19:39.097889
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():

    play_data = [{"user": "name"}, {"remote_user": "name"}]

    for data in play_data:
        p = Play()
        p.preprocess_data(data)
        p.load_data(data)
        assert isinstance(p, Play) == True
        assert isinstance(p._ds, dict) == True
        assert p._ds == {"remote_user": "name"}


# Generated at 2022-06-11 10:19:49.103030
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()

    assert(play.get_roles() == [])
    assert(play._included_path is None)
    assert(play._action_groups == {})
    assert(play._group_actions == {})


# Generated at 2022-06-11 10:19:59.510767
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = dict(
        hosts=dict(),
        vars_files=dict(),
        roles=dict(),
        vars_prompt=dict(),
        gather_facts=dict(),
        tasks=dict(
            name=dict(),
            action=dict(),
            become=dict(),
            become_user=dict(),
            remote_user=dict(),
            local_action=dict(),
            args=dict(),
            loop=dict(),
            loop_control=dict(),
            tags=dict(),
            register=dict(),
            ignore_errors=dict(),
            when=dict(),
        ),

    )

    class MockPlay(Play):
        def __init__(self):
            super(MockPlay, self).__init__()


    play = MockPlay()

    play.preprocess_data(ds)
    return play

# Generated at 2022-06-11 10:20:01.039150
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    play = Play()
    play.deserialize(play.serialize())

# Generated at 2022-06-11 10:20:10.166855
# Unit test for constructor of class Play
def test_Play():
    yaml_data = '''
    - hosts: 127.0.0.1
      gather_facts: no
      tasks:
        - shell: some command
    '''
    p = Play.load(yaml_data, variable_manager=VariableManager())
    assert type(p) == Play
    assert p.hosts == '127.0.0.1'
    assert p.gather_facts == 'no'
    assert p.tasks[0].action == 'shell'
    assert p.tasks[0].args['_raw_params'] == 'some command'

# Generated at 2022-06-11 10:20:16.505658
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Test Play with empty list
    Play.vars_files = []
    assert Play.get_vars_files() == []

    # Test Play with list with an item
    Play.vars_files = [Play()]
    assert Play.get_vars_files() == [Play()]

    # Test Play with list with multiple items
    Play.vars_files = [Play(), Play()]
    assert Play.get_vars_files() == [Play(), Play()]

    # Test Play with int
    Play.vars_files = 1
    assert Play.get_vars_files() == [1]


# Generated at 2022-06-11 10:20:23.710493
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    import ansible.playbook.play
    p = ansible.playbook.play.Play()
    p._loader = None
    p._variable_manager = None
    p.roles = [
        {'name': 'role1'},
        {'name': 'role2'},
        {'name': 'role3'}
    ]

    p.get_handler_blocks = Mock(return_value=[1, 2, 3])
    print(p.compile_roles_handlers())

# Generated at 2022-06-11 10:20:29.021293
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    '''
    Test Play.get_vars_files
    '''
    play = Play()
    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    play.vars_files = []
    assert play.get_vars_files() == []

# Generated at 2022-06-11 10:20:39.340864
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    task_1 = Task()
    task_2 = Task()
    task_3 = Task()
    task_4 = Task()

    task_1.name = 'task_1'
    task_1.action = 'action_1'

    task_2.name = 'task_2'
    task_2.action = 'action_2'

    task_3.name = 'task_3'
    task_3.action = 'action_3'

    task_4.name = 'task_4'
    task_4.action = 'action_4'

    task_1.set_loader(DictDataLoader({}))
    task_2.set_loader(DictDataLoader({}))
    task_3.set_loader(DictDataLoader({}))

# Generated at 2022-06-11 10:20:40.963420
# Unit test for method get_name of class Play
def test_Play_get_name():
    # GIVEN: A play

    # WHEN: name is not set
    play = Play()
    play.name = ''

    # THEN: get_name should return hosts as lower case
    assert play.get_name() == ''

# Generated at 2022-06-11 10:21:03.802441
# Unit test for method get_name of class Play
def test_Play_get_name():
    playbook = dict(
        host_list=['foo', 'bar', 'baz'],
        plays=[
            dict(
                name='first play',
                hosts='all',
                tasks=[
                    dict(action='ping', name='ping host')
                ]
            ),
            dict(
                name='second play',
                hosts='all',
                tasks=[
                    dict(action='ping', name='ping host')
                ]
            )
        ]
    )
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo='bar')

    # test play without name attribute
    p = Play()
    p.hosts = ['hostname']
    del p.name
    name = p.get_name()
    assert name == 'hostname'

    # test

# Generated at 2022-06-11 10:21:14.658238
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # we'll create a mock role to use
    mock_role = collections.namedtuple('Role', ['get_handler_blocks'])
    mock_handler_blocks = [collections.namedtuple('HandlerBlock', ['block'])]
    mock_role.get_handler_blocks = lambda *args, **kwargs: mock_handler_blocks
    mock_role_list = [mock_role]

    # create a mock play
    mock_play = collections.namedtuple('Play', ['roles'])
    mock_play.roles = mock_role_list

    # compile the role_handlers
    role_handlers = Play._compile_roles_handlers(mock_play)

    # make sure the returned list is what we expect
    assert mock_handler_blocks == role_handlers


# Generated at 2022-06-11 10:21:18.344899
# Unit test for method get_name of class Play
def test_Play_get_name():
    args = dict(
        a = 'b',
        c = 'd'
    )
    test_object = Play()
    test_object.get_name()
    assert test_object


# Generated at 2022-06-11 10:21:20.866583
# Unit test for method serialize of class Play
def test_Play_serialize():
    play = Play()
    assert play.serialize() == dict(hosts='all')


# Generated at 2022-06-11 10:21:22.686722
# Unit test for method get_name of class Play
def test_Play_get_name():
    # TODO: Get hosts from config file, or not?
    hosts = 'localhost'
    play = Play(hosts=hosts)
    assert play.get_name() == hosts, "play.get_name('localhost') should be 'localhost'"


# Generated at 2022-06-11 10:21:33.314327
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    # Testing for
    #
    #     def deserialize(self, data):
    #         super(Play, self).deserialize(data)
    #         self._included_conditional = data.get('included_conditional', None)
    #         self._included_path = data.get('included_path', None)
    #         self._action_groups = data.get('action_groups', {})
    #         self._group_actions = data.get('group_actions', {})
    #
    # Instead of writing the actual test code I just copy-paste the original function and add a couple of print statements and add a small amount of code to test for the condition at the end of the function

    data = {}
    data['included_conditional'] = None

# Generated at 2022-06-11 10:21:43.996432
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    from ansible.playbook.play_context import PlayContext
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.playbook.task
    import ansible.plugins.loader
    import ansible.template
    import ansible.utils.vars
    import ansible.inventory.host
    import ansible.vars.hostvars
    import ansible.utils.display
    import ansible.cache.platform

    # Instantiates a helper object to patch configuration
    context = AnsibleContext({})

    # First test: patching 'inventory_manager' and no patching 'variable_manager'

# Generated at 2022-06-11 10:21:56.516020
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [ 'task1', 'task2' ]
    play.tasks = [ 'task3', 'task4' ]
    play.post_tasks = [ 'task5', 'task6' ]

    block1 = Block()
    block1.block = [ 'block1' ]
    block1.rescue = [ 'block2' ]
    block1.always = [ 'block3' ]

    play.pre_tasks.append(block1)
    play.tasks.append(block1)
    play.post_tasks.append(block1)

    task_list = play.get_tasks()

    assert len(task_list) == 9
    assert 'task1' in task_list
    assert 'task2' in task_list

# Generated at 2022-06-11 10:22:02.974466
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()

# Generated at 2022-06-11 10:22:14.482418
# Unit test for constructor of class Play

# Generated at 2022-06-11 10:22:42.525086
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers() == []



# Generated at 2022-06-11 10:22:49.672965
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = 'test_vars_files'
    assert p.get_vars_files() == [p.vars_files]
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = ['test_vars_files', 'test_vars_files1']
    assert p.get_vars_files() == p.vars_files
# unit test for method serialize of class Play

# Generated at 2022-06-11 10:22:55.386912
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    Play = Play()
    Play.tasks = [Block.load(data={'meta': 'flush_handlers'})]
    Play.pre_tasks = ['test']
    Play.post_tasks = 'test2'
    assert Play.get_tasks() == ['test2', [Block.load(data={'meta': 'flush_handlers'})], 'test']



# Generated at 2022-06-11 10:23:06.972545
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # when pre_task, block, task, post_task
    p = Play()
    pre_tasks = [ MockTask(name='pre_task1'), MockTask(name='pre_task2') ]
    tasks = [ MockTask(name='task1'), MockTask(name='task2') ]
    block = Block(name='block', block=tasks, rescue=[], always=[])
    post_tasks = [ MockTask(name='post_task1'), MockTask(name='post_task2') ]
    setattr(p, 'pre_tasks', pre_tasks)
    setattr(p, 'tasks', [block])
    setattr(p, 'post_tasks', post_tasks)
    tasks = p.get_tasks()

# Generated at 2022-06-11 10:23:18.477840
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    host_regex = re.compile("^host_")
    meta_regex = re.compile("^meta_")
    assert isinstance(host_regex, SRE_Pattern)
    assert isinstance(meta_regex, SRE_Pattern)

    Play.test_compile_roles_handlers = compile_roles_handlers

    myplay = Play()
    myplay.current_play_index = 0
    myplay.ds = {}
    myplay.roles = []

    # Test when there are no roles
    result = myplay.compile_roles_handlers()
    assert result == []

    # Test with one role
    roledata = {}
    handlerdata = {}
    handlerdata['name'] = 'notify_test_task'
    handlerdata['block'] = []
   

# Generated at 2022-06-11 10:23:19.138368
# Unit test for method get_name of class Play
def test_Play_get_name():
    pass

# Generated at 2022-06-11 10:23:29.551070
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play.playbook = Playbook()

    assert play.get_name() == '', 'Expected empty name'

    play.name = 'test name'
    assert play.get_name() == 'test name', 'Expected name test name'

    del play.name
    assert play.get_name() == '', 'Expected empty name'

    play.hosts = [Host(name='localhost')]
    assert play.get_name() == 'localhost', 'Expected name localhost'

    play.hosts = [Host(name='localhost'), Host(name='localhost2')]
    assert play.get_name() == 'localhost,localhost2', 'Expected name localhost,localhost2'

    play.hosts = 'localhost'

# Generated at 2022-06-11 10:23:42.568230
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class MockPlay(Play):
        def __init__(self, pre_tasks, tasks, post_tasks):
            self.pre_tasks = pre_tasks
            self.tasks = tasks
            self.post_tasks = post_tasks
            class MockBlock:
                def __init__(self, block, rescue, always):
                    self.block = block
                    self.rescue = rescue
                    self.always = always
            self.Block = MockBlock


# Generated at 2022-06-11 10:23:53.331347
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # SIMPLE TEST
    playbook = dict(
        name = "simple test",
        hosts = "all",
        roles = [
            dict(
                name = "role1",
                handlers = [
                    dict(
                        name = "handler1"
                    )
                ]
            )
        ]
    )
    p = Play()
    p.deserialize(playbook)
    assert(len(p.compile_roles_handlers()) == 1)

    # INCLUDE TEST
    playbook = dict(
        name = "include test",
        hosts = "all",
        roles = [
            dict(
                name = "role1",
                include = "include1"
            )
        ]
    )
    p = Play()
    p.deserialize(playbook)

# Generated at 2022-06-11 10:24:05.204939
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Check type of test_name
    test_name = Play().get_name()
    assert isinstance(test_name, str)
    test_name = Play(name='test_name').get_name()
    assert isinstance(test_name, str)

    # Check get_name with hosts
    test_name = Play(hosts='test_hosts').get_name()
    assert isinstance(test_name, str)

    # Check get_name with hosts as a list
    test_hosts = ['test_host1', 'test_host2']
    test_name = Play(hosts=test_hosts).get_name()
    assert isinstance(test_name, str)

    # Check get_name with hosts as a list, but no host in the list
    test_name = Play(hosts=[]).get

# Generated at 2022-06-11 10:24:47.859021
# Unit test for method get_name of class Play
def test_Play_get_name():
    # create a play
    play = Play()
    play.name = 'test_name'
    play.hosts = ['host_1', 'host_2']
    # assert if play.get_name() is test_name
    assert play.get_name() is 'test_name'
    assert play.hosts == ['host_1', 'host_2']

# create an instance of class Play
play = Play()

# create a play

# Generated at 2022-06-11 10:24:51.613422
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # TODO: May not work, has many dependencies
    # TODO: Add unit tests for other methods
    # TODO: Figure out what to do with meta tasks
    pass


# Generated at 2022-06-11 10:25:00.795141
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = dict(
        name='test_play',
        hosts='all',
        pre_tasks=[
            'pre_task1',
            'pre_task2',
        ],
        tasks=[
            'task1',
            'task2',
        ],
        post_tasks=[
            'post_task1',
            'post_task2',
        ],
    )
    play = Play.load(data, variable_manager=None, loader=None, vars=None)
    expected_result = ['pre_task1', 'pre_task2', 'task1', 'task2', 'post_task1', 'post_task2']
    result = play.get_tasks()
    assert result == expected_result
# END Unit test for method get_tasks of class Play


# Generated at 2022-06-11 10:25:09.318513
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = [
        {'name': 'one'},
        {'name': 'two'},
        {'name': 'three'},
        {'name': 'four'}
    ]
    p._load_tasks(attr=None, ds=None)
    assert len(p.get_tasks()) == len(p.tasks)
    assert p.get_tasks()[0].name == 'one'

# Generated at 2022-06-11 10:25:16.153319
# Unit test for method get_name of class Play
def test_Play_get_name():
    # create an instance of the class being tested
    play_instance = Play()

    play_instance.name = 'somename'
    assert play_instance.get_name() == 'somename'

    # test case where object has no name attribute
    play_instance = Play()
    play_instance.hosts = 'somehost'
    assert play_instance.get_name() == 'somehost'

# Generated at 2022-06-11 10:25:17.453731
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    pass # Not implemented yet

# Generated at 2022-06-11 10:25:24.193085
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''
    play.name = 'Play_Name'
    assert play.get_name() == 'Play_Name'
    play.hosts = 'hosts'
    play.name = ''
    assert play.get_name() == 'hosts'
    play.hosts = ['host1', 'host2']
    assert play.get_name() == 'host1,host2'


# Generated at 2022-06-11 10:25:27.060971
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    raise SkipTest("Test is not implemented yet")
    # TODO: Pending implementation
    # test setup
    # expected
    # actual
    # Method body
    
    
    

# Generated at 2022-06-11 10:25:38.458912
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()

    # No attributes set
    assert p.get_name() == ''

    p.name = 'TestPlay'
    assert p.get_name() == 'TestPlay'

    p.name = ''
    # A sequence of hosts
    p.hosts = ['host1.example.com', 'host2.example.com']
    assert p.get_name() == 'host1.example.com,host2.example.com'

    # A string of hosts
    p.hosts = 'host1.example.com,host2.example.com'
    assert p.get_name() == 'host1.example.com,host2.example.com'


# Generated at 2022-06-11 10:25:48.953872
# Unit test for method serialize of class Play
def test_Play_serialize():
    t = {
            'name': 'testPlaySerialize',
            'hosts': 'all',
            'roles': [
                {
                    'role': {
                        'name': 'testRoleName',
                        'task': {
                            'name': 'testTaskName',
                            'action': {
                                'name': 'testActionName',
                                'module': 'testModule'
                            }
                        }
                    }
                }
            ]
        }
    p = Play.load(t)
    data = p.serialize()
    roles = data.get('roles')
    assert len(roles) == 1
    assert roles[0].get('role').get('name') == 'testRoleName'

# Generated at 2022-06-11 10:26:53.289456
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    data = {"hosts": ["localhost"], "tasks": [{"name": "debug", "debug": {"msg": "hello world"}}, {"name": "debug", "debug": {"msg": "hello world"}}]}
    data_instance = Play()
    data_instance.deserialize(data)
    tasklist = []
    for task in data_instance.get_tasks():
        if isinstance(task, Block):
            tasklist.append(task.block + task.rescue + task.always)
        else:
            tasklist.append(task)
    if tasklist[0] == [{"name": "debug", "debug": {"msg": "hello world"}}]:
        print("Testing: passed, for Data class Play, method get_task")
    else:
        print("Failed")

# Generated at 2022-06-11 10:26:58.461969
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    #print("Test compile_roles_handlers")
    obj = Play()
    obj.roles = []
    block_list = obj.compile_roles_handlers()
    m_block_list = []
    assert (block_list == m_block_list)



# Generated at 2022-06-11 10:26:59.981785
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._compile_roles_handlers()

# Generated at 2022-06-11 10:27:00.951457
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # TODO
    pass

# Generated at 2022-06-11 10:27:09.717833
# Unit test for method deserialize of class Play

# Generated at 2022-06-11 10:27:18.979278
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Initialize data structures
    play_ds = [
    dict(
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
          dict(
            name = 'Gathering Facts',
            setup = ''
            ),
          dict(
            name = "Obtain the version of Ubuntu currently running on the device named 'cisco_ios'",
            delegate_to = 'cisco_ios',
            ios_facts = ''
            )
          ]
        )
    ]
    # Create Play object
    p = Play()
    # Load datastructure into Play object
    p.load_data(play_ds)
    # Get Play object name
    p_name = p.get_name()
    # Verify the name
    assert p_name == 'all'
 

# Generated at 2022-06-11 10:27:28.515107
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Testing for method preprocess_data of class Play
    play = Play()
    context.CLIARGS = ImmutableDict(tags=['tag1'], skip_tags=['tag2'])
    play.only_tags = frozenset(['tag1'])
    play.skip_tags = set(['tag2'])
    play.post_validate = mock.Mock()
    play.sort_tasks = mock.Mock()
    play.finalize = mock.Mock()

    play.set_loader(DataLoader())
    test_data = dict(
        name="Ansible Play",
        hosts="all",
        tasks=[dict(action=dict(module="shell", args="id"))])
    play.load_data(test_data)
    assert play.name == 'Ansible Play'


# Generated at 2022-06-11 10:27:30.015026
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''

# Generated at 2022-06-11 10:27:37.006071
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    p = Play().load(play_ds, variable_manager=variable_manager, loader=loader)
    res = p.get_vars_files()
    assert res == ['vars_file_one', 'vars_file_two']


# Generated at 2022-06-11 10:27:41.186638
# Unit test for method get_name of class Play
def test_Play_get_name():
    """
    Test get_name method
    """
    # Create a Play object
    p = Play()
    # Set attribute of name
    p.name = "test"

    # Call method get_name
    p.get_name()

    # Check value of attribute name
    assert p.get_name() == p.name
