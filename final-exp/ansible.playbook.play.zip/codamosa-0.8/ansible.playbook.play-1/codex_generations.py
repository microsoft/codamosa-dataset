

# Generated at 2022-06-11 10:18:29.196766
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # 2 roles
    # 3 tasks in each role
    # 1 one task in a role is notified by handler in the same role
    # 1 one task in a role is not notified by handler in other role


# Generated at 2022-06-11 10:18:40.201650
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    assert play.get_name() == ''

    play.name = 'test-name'
    assert play.get_name() == 'test-name'
    assert play.name == 'test-name'

    play.name = None
    play.hosts = 'test-hosts'
    assert play.get_name() == 'test-hosts'
    assert play.name == 'test-hosts'

    play.hosts = ['test-hosts', 'test-hosts1']
    assert play.get_name() == 'test-hosts,test-hosts1'
    assert play.name == 'test-hosts,test-hosts1'


# Generated at 2022-06-11 10:18:47.847182
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    data = {
        'hosts': 'host1',
        'user': 'my_user',
        'tasks': [
            {
                'name': 'my_task',
                'action': 'my_action'
            }
        ]
    }

    play = Play()
    new_data = play.preprocess_data(data)

    assert 'remote_user' in new_data
    assert new_data['remote_user'] == 'my_user'
    assert 'user' not in new_data



# Generated at 2022-06-11 10:18:59.718558
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():    
    ds = dict()
    
    play = Play(ds)
    assert isinstance(play.get_tasks(), list)
    assert not play.get_tasks()
    
    ds['roles'] = list()
    play = Play(ds)
    assert isinstance(play.get_tasks(), list)
    assert not play.get_tasks()
    
    ds['tasks'] = list()
    play = Play(ds)
    assert isinstance(play.get_tasks(), list)
    assert not play.get_tasks()
    
    ds['rescue'] = list()
    play = Play(ds)
    assert isinstance(play.get_tasks(), list)
    assert not play.get_tasks()
    
    ds['always'] = list()
    play

# Generated at 2022-06-11 10:19:12.368707
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultSecret
    from ansible.inventory.host import Host
    v = VaultSecret('sdfhjkh', _get_vault_secrets=dict, salt=None)
    v.vault_secret = 'dddd'

# Generated at 2022-06-11 10:19:15.917848
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.name = "test1"
    play.hosts = "hosts"
    play.roles = [Role(), Role()]
    res = play.compile_roles_handlers()
    assert res == []

# Generated at 2022-06-11 10:19:19.769459
# Unit test for method serialize of class Play
def test_Play_serialize():
	data = dict(
		name='foo',
		vars=dict(a=1, b=2),
		hosts='localhost',
		roles=[Role().serialize()]
	)
	play = Play().load(data)
	play.serialize()
test_Play_serialize()



# Generated at 2022-06-11 10:19:33.436560
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    '''
    Unit test for method compile_roles_handlers of class Play
    '''
    #############################
    # Test setup
    #############################
    role1 = Role({'name': 'role1', 'handlers':[{'name': 'go'}]})
    role2 = Role({'name': 'role2'})
    role3 = Role({'name': 'role3', 'handlers':[{'name': 'stop'}]})
    collection_loader = None
    variable_manager = VariableManager()
    loader = DataLoader()
    loader._basedir = '/'
    variable_manager.set_loader(loader=loader)

# Generated at 2022-06-11 10:19:38.942035
# Unit test for method get_name of class Play
def test_Play_get_name():
    hosts = 'hosts'
    p = Play()

    p.name = 'name'
    assert p.get_name() == 'name'

    p.name = None
    p.hosts = None
    assert p.get_name() == ''

    p.name = None
    p.hosts = hosts
    assert p.get_name() == 'hosts'


# Generated at 2022-06-11 10:19:49.038424
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()


# Generated at 2022-06-11 10:19:57.081071
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    pass

# Generated at 2022-06-11 10:20:04.133656
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = None
    assert play.get_vars_files() == []

    play.vars_files = 'test'
    assert play.get_vars_files() == ['test']
    
    play.vars_files = ['test_1', 'test_2']
    assert play.get_vars_files() == ['test_1', 'test_2']


# Generated at 2022-06-11 10:20:13.344343
# Unit test for method serialize of class Play
def test_Play_serialize():
    vargroup1 = dict(name='foo', prompt='foo please', default='bar', private=True, confirm=False, encrypt=None, salt_size=None, salt=None, unsafe=False)
    play = Play()
    play.load_data(dict(vars_prompt=vargroup1))
    assert play.vars_prompt == [vargroup1]
    #print('play.serialize(): %s' % pprint.pformat(play.serialize()))
    play2 = Play()
    play2.deserialize(play.serialize())
    assert play.vars_prompt == play2.vars_prompt


# Generated at 2022-06-11 10:20:19.862478
# Unit test for method deserialize of class Play

# Generated at 2022-06-11 10:20:29.632998
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    role_1 = Role()
    role_2 = Role()
    # define a Play class instance with roles
    play = Play(roles=[role_1,role_2])
    def get_handler_blocks(self, play=None):
        return [self]
    # define a fake get_handler_blocks method which returns a list of roles
    play.get_roles = lambda: [role_1,role_2]
    role_1.get_handler_blocks = role_2.get_handler_blocks = get_handler_blocks
    # expect to get roles as a list of handlers
    assert play.compile_roles_handlers() == [role_1,role_2]


# Generated at 2022-06-11 10:20:31.417863
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    assert p is not None

test_Play_deserialize()


# Generated at 2022-06-11 10:20:41.574524
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """
    get_tasks method of class Play.

    This method returns a flat list of tasks in this play
    """

# Generated at 2022-06-11 10:20:49.280944
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Preparation phase
    p = Play()
    p.load_data({'name': 'test_play'})
    p._load_roles(None, [{'import_playbook': 'test_playbook', 'roles': ['test_role'], 'name': 'test_role'}]) 
    # Tested method call
    a = p.compile_roles_handlers()
    # Assertion phase
    assert False

# Generated at 2022-06-11 10:20:53.183879
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    print('Testing Play Begin...')
    play = Play()
    result = play.get_vars_files()
    assert (result == [])
    print('Testing Play End!')


# Generated at 2022-06-11 10:20:58.076829
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''
    Test Play class get_name method with different inputs.
    '''
    play = Play()

    ne = play.get_name()
    assert ne == 'Always'

    play.name = 'test'
    ne = play.get_name()
    assert ne == 'test'



# Generated at 2022-06-11 10:21:12.787523
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Unit test for method get_tasks of class Play
    # Ansible.Play
    # get_tasks()
    #     return a list of tasks in the play
    # ...
    # Calls the method block.get_tasks()
    # Ansible.Task
    # get_tasks()
    #     Recursively process this task's block and return all task objects

    # How to test?
    # test_play.yml?
    # Should get_tasks() do the same as get_block_list()?
    pass


# Generated at 2022-06-11 10:21:25.999758
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    v = Play()
    role = Role()
    role.deserialize({"name": "role"})
    setattr(role, 'serialized_attrs', set)
    v.deserialize({"tags": [], "roles": [role.serialize()], "name": "name", "vars_files": [], "handlers": [], "tasks": [], "handlers": [], "hosts": "hosts",
 "post_tasks": [], "pre_tasks": [], "variables": {}, "vars": {"k": "v"}})
    assert isinstance(v, Play)
    assert isinstance(v.tasks, list)
    assert isinstance(v.name, str)
    assert isinstance(v.vars_files, list)

# Generated at 2022-06-11 10:21:34.864433
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.vars.hostvars import HostVars

    t1 = Task()
    t2 = Task()

    h1 = Handler()

    r1 = Role()

    b1 = Block()
    b1.block.append(t1)
    b1.block.append(h1)

    b2 = Block()
    b2.block.append(t2)
    b2.block.append(h1)
    b2.rescue.append(r1)

    p = Play()

# Generated at 2022-06-11 10:21:38.352615
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = 'test_Play_get_vars_files.yml'
    assert p.get_vars_files() == ['test_Play_get_vars_files.yml']



# Generated at 2022-06-11 10:21:46.806686
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # Initialize test objects
    play = Play()
    block = Block(self, play=play)
    block.block = [Task() for n in range(4)]
    play.tasks = [Task(), block]
    play.tasks.extend([Task(), block.copy(), block.copy(), block.copy()])

    # Get tasks from play
    tasklist = play.get_tasks()

    # Assert that we have the correct number of tasks
    assert len(tasklist) == 19

    # Assert that the tasks are of the expected type
    for task in tasklist:
        assert isinstance(task, Task)

# Generated at 2022-06-11 10:21:58.707782
# Unit test for method serialize of class Play
def test_Play_serialize():
    data = {}
    data["roles"] = []
    data["_action_groups"] = {}
    data["_group_actions"] = {}
    data["_use_block"] = False
    data["handler"] = "main"
    data["_included_path"] = None
    data["_variable_manager"] = {}
    data["_extra_vars"] = {}
    data["_ds"] = {}
    data["_role_vars"] = {}
    data["_handlers_loaded"] = False
    data["_tasks_loaded"] = False
    data["_blocks"] = []
    data["_pre_tasks"] = []
    data["_post_tasks"] = []
    data["_tasks"] = []
    data["_handlers"] = []
    data["_roles"] = []

# Generated at 2022-06-11 10:22:10.048640
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    import copy
    import os
    import pytest
    import sys
    import tempfile
    from units.compat import mock

    import ansible.playbook.play
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.vars.manager import VariableManager

    from ansible.utils.vars import combine_vars

    from ansible.utils.vars import combine_vars

    #construct fake test environment
    pb_dir = tempfile.mkdtemp()

    # Construct fake playbook file
    playbook = os.path.join(pb_dir, 'test.yml')
    fd, fp = tempfile.mkstemp()
    fh = os.fdopen(fd, 'w')

    play_data

# Generated at 2022-06-11 10:22:21.034792
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    # from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    # For Ansible 2.7 and below
    from ansible.vars.manager import VariableManager
    # From Ansible 2.8 and above
    # from ansible.vars.hostvars import HostVars
    # from ansible.vars.hostvars import HostVarsVars


# Generated at 2022-06-11 10:22:24.080103
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # Pre-test constructor to setup the variable
    p = Play()
    p.vars_files = "testPlay.yaml"
    # Function under test
    p.get_vars_files()

# Generated at 2022-06-11 10:22:34.023753
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    assert play.get_vars_files() == []
    play.vars_files = 'ansible/test/data/vars_files/test_vars_files.yml'
    assert play.get_vars_files() == ['ansible/test/data/vars_files/test_vars_files.yml']
    play.vars_files = ['ansible/test/data/vars_files/test_vars_files.yml', 'ansible/test/data/vars_files/test_vars_files_2.yml']

# Generated at 2022-06-11 10:22:43.186434
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    print("Start Play.compile_roles_handlers")
    print("End Play.compile_roles_handlers")


# Generated at 2022-06-11 10:22:49.564673
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # create mock role and play objects
    role = Mock()
    role_list = []
    role_list.append(role)

    play = Play()
    play.roles = role_list

    # test the method
    play_handlers_list = play.compile_roles_handlers()
    # test that the returned value is correct
    assert play_handlers_list == role.get_handler_blocks.return_value

# Generated at 2022-06-11 10:22:56.492356
# Unit test for method serialize of class Play
def test_Play_serialize():
    fname="test_data/test_plays/test_data.yml"
    with open(fname, 'r') as test_file:
        play_from_file = Play.load(test_file.read(), variable_manager=VariableManager(), loader=DataLoader())
    d = play_from_file.serialize()
    play_from_dict = Play.deserialize(d)
    assert play_from_dict.serialize() == play_from_file.serialize()


# Generated at 2022-06-11 10:23:01.404613
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Mock()
    p.name = 'test play'
    p.pre_tasks = [Mock(), Mock()]
    p.tasks = [Mock(), Mock()]
    p.post_tasks = [Mock()]
    assert len(p.get_tasks()) == 5

# Generated at 2022-06-11 10:23:04.747333
# Unit test for method get_name of class Play
def test_Play_get_name():
    pb = Play()
    assert pb.get_name() == ''
    pb.name = 'test_name'
    assert pb.get_name() == 'test_name'


# Generated at 2022-06-11 10:23:14.137738
# Unit test for method get_name of class Play
def test_Play_get_name():
  data = dict(
    name='Test Play',
    hosts='127.0.0.1',
    tasks=[]
  )
  play = Play()
  play = play.load(data, variable_manager=None, loader=None)
  assert play.get_name() == 'Test Play'

  data = dict(
    hosts='127.0.0.1',
    tasks=[]
  )
  play = Play()
  play = play.load(data, variable_manager=None, loader=None)
  assert play.get_name() == '127.0.0.1'

# Generated at 2022-06-11 10:23:14.637056
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:23:21.095968
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Initialize a valid instance of class Play
    play = Play()
    play.name = 'my_play'
    play.hosts = 'hosts_string'
    # Validate that method get_name of class Play
    # returns the expected result
    assert play.get_name() == 'my_play'
    play.name = None
    # Validate that method get_name of class Play
    # returns the expected result
    assert play.get_name() == 'hosts_string'

# Generated at 2022-06-11 10:23:27.941402
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p._load_handlers(attr='handlers', ds=[])
    p._load_roles(attr='roles', ds=None)
    block_list = p.compile_roles_handlers()
    assert(type(block_list[0]) == Block)
    assert(type(block_list[1]) == Role)
    assert(block_list[1].get_handler_blocks(play=p) == block_list)


# Generated at 2022-06-11 10:23:41.020047
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks.append(Block(Block(Block())))
    play.pre_tasks.append(Block(Block(Block())))
    play.pre_tasks.append(Block(Block(Block())))
    play.tasks.append(Block(Block(Block())))
    play.tasks.append(Block(Block(Block())))
    play.post_tasks.append(Block(Block(Block())))
    play.post_tasks.append(Block(Block(Block())))
    play.post_tasks.append(Block(Block(Block())))
    assert len(play.get_tasks()) == 9
    play.tasks.append(Block(Block(Block())))
    assert len(play.get_tasks()) == 10
    play.pre_tasks.append

# Generated at 2022-06-11 10:23:54.503855
# Unit test for method get_name of class Play
def test_Play_get_name():
    class TestLoader(Loader):
        def load_from_file(self,path):
            data = utils.parse_yaml_from_file(path)
            return data
    path = 'D:/Projects/IT/Ansible/ansible/test/sanity/playbook/host-tests/includedir.yml'
    p = Play.load(data=path, loader=TestLoader())
    result = p.get_name()
    assert result == ''
    assert result == ''


# Generated at 2022-06-11 10:23:55.821838
# Unit test for method serialize of class Play
def test_Play_serialize():
    p = Play()
    p.serialize()


# Generated at 2022-06-11 10:23:56.832643
# Unit test for method get_name of class Play
def test_Play_get_name():
  pass

# Generated at 2022-06-11 10:24:08.600702
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()

    assert not play.get_vars_files()

    ds = dict(vars_files=["../test/test_vars_files/hosts.yml"])
    play.load(ds)
    assert play.get_vars_files() == ds['vars_files']

    ds = dict(vars_files=["../test/test_vars_files/hosts.yml", "../test/test_vars_files/hosts.yml"])
    play.load(ds)
    assert play.get_vars_files() == ds['vars_files']

    # test that vars_files is string not list
    ds = dict(vars_files="../test/test_vars_files/hosts.yml")
    play.load

# Generated at 2022-06-11 10:24:19.111053
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # GIVEN a Play instance with a load_list_of_blocks function that
    #       returns a list of blocks
    def load_list_of_blocks(ds=None, play=None, use_handlers=None, variable_manager=None, loader=None):
        return [1]
    load_list_of_blocks_patcher = patch('ansible.playbook.block.load_list_of_blocks', side_effect=load_list_of_blocks)
    load_list_of_blocks_patcher.start()
    play = Play()
    play.roles = [MagicMock()]
    # WHEN the compile_roles_handlers method is called
    # THEN the result is a list
    assert isinstance(play.compile_roles_handlers(), list)
    load_list_of_blocks

# Generated at 2022-06-11 10:24:30.725711
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    flush_block = Block.load(
        data={'meta': 'flush_handlers'},
        play=p,
        variable_manager=p._variable_manager,
        loader=p._loader
    )
    
    for task in flush_block.block:
        task.implicit = True
        
    p.pre_tasks.append(flush_block)
    p.tasks.append(flush_block)
    p.post_tasks.append(flush_block)
    p.handlers.append(flush_block)
    p.roles.append(flush_block)
    
    actual = p.get_tasks()

# Generated at 2022-06-11 10:24:37.869535
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # No arguments and no roles
    p = Play()
    assert p.compile_roles_handlers() == []

    # No roles, role includes, or roles_path
    p = Play()
    p.vars = dict()
    p.vars_prompt = list()
    p.vars_files = list()
    p.handlers = ["handler_tasks"]
    p.block = None
    p.default_vars = dict()
    p.roles = []
    p.post_validate()
    assert p.compile_roles_handlers() == ["handler_tasks"]

    # Roles, role includes, handlers and roles_path, but no handlers in roles
    p = Play()
    p.vars = dict()
    p.vars_prompt = list()
    p

# Generated at 2022-06-11 10:24:40.879723
# Unit test for constructor of class Play
def test_Play():

    pl = Play()
    assert isinstance(pl, Play)
    assert pl.vars is None
    assert pl.roles is None
    assert pl.handlers is None
    assert pl.default_vars is None

# Generated at 2022-06-11 10:24:52.898718
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data(): 
    """ test_Play_preprocess_data """ 
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader = loader, variable_manager = variable_manager,  host_list = 'hosts')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:25:00.825097
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    #with pytest.raises(AnsibleParserError):
    #    play.load_data({"hosts": ""})
    #    play.get_name()
    
    play.load_data({"hosts": "test_host", "name": "test_play"})
    assert play.get_name() == 'test_play'
    #del play.name
    play.name = ""
    assert play.get_name() == 'test_host'
    play.load_data({"hosts": ["test_host1", "test_host2"]})
    assert play.get_name() == 'test_host1,test_host2'


# Generated at 2022-06-11 10:25:14.722177
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['foo.yml', 'bar.yml']
    assert play.get_vars_files() == ['foo.yml', 'bar.yml']
    play.vars_files = 'foo.yml'
    assert play.get_vars_files() == ['foo.yml']
    play.vars_files = None
    assert play.get_vars_files() == []


# Generated at 2022-06-11 10:25:21.836557
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Setup
    Passwords = {}
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    play = Play()

    # Exercise
    block_list = play.compile_roles_handlers()

    # Verify
    assert(block_list == [])



# Generated at 2022-06-11 10:25:25.117036
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers() == []
    p.roles = ["notempty"]
    assert p.compile_roles_handlers() == []


# Generated at 2022-06-11 10:25:37.694360
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    task5 = Task()
    task6 = Task()
    task7 = Task()
    task8 = Task()
    task9 = Task()
    task10 = Task()
    block1 = Block(block=[task1])
    block2 = Block(block=[task2])
    block3 = Block(block=[task3])
    block4 = Block(block=[task4])
    block5 = Block(block=[task5])
    block6 = Block(block=[task6])
    block7 = Block(block=[task7])
    block8 = Block(block=[task8])
    block9 = Block(block=[task9])
    block10 = Block(block=[task10])


# Generated at 2022-06-11 10:25:43.328324
# Unit test for method get_name of class Play
def test_Play_get_name():
    def mock_get(*args, **kwargs):
        return True
    p = Play()
    p._ds = { 'hosts': 'localhost' }
    assert p.get_name() == 'localhost'
    p = Play()
    p.name = 'mytest'
    assert p.get_name() == 'mytest'

# Generated at 2022-06-11 10:25:51.837320
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_ds = dict(
        name="test_Play_compile_roles_handlers",
        hosts="127.0.0.1",
        roles=[
            dict(
                name="some_role",
                handlers=[dict(
                    name="some_handler",
                    tags=["test_tag"],
                    tasks=["some_task"]
                )]
            )
        ]
    )

# Generated at 2022-06-11 10:25:54.344866
# Unit test for method get_name of class Play
def test_Play_get_name():
    myplay = Play()
    myplay.vars = dict()
    myplay.roles = dict()



# Generated at 2022-06-11 10:26:06.045225
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    p.post_tasks = [
        Block(role='role1', handlers=['handler1', 'handler2'],
              tasks=[
                  Task(name='task1'),
              ]
        )
    ]
    p.post_tasks += [
        Block(role='role2', handlers=['handler3'],
              tasks=[
                  Task(name='task1'),
              ]
        )
    ]
    p._compile_roles()
    r1 = p._role_inclusions.get('role1')
    r2 = p._role_inclusions.get('role2')
    new_handlers = p.compile_roles_handlers()
    assert len(new_handlers) == 4

# Generated at 2022-06-11 10:26:14.525492
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert p.get_vars_files() == []

    p.vars_files = 1
    assert p.get_vars_files() == [1]

    p.vars_files = None
    assert p.get_vars_files() == []

    p.vars_files = []
    assert p.get_vars_files() == []

    p.vars_files = [1,2]
    assert p.get_vars_files() == [1,2]

    p.vars_files = []
    assert p.get_vars_files() == []



# Generated at 2022-06-11 10:26:22.958051
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    #get the class
    play = Play()
    # the method loads the vars file that includes the host file
    assert play.get_vars_files() == []
    #check if the file exists
    assert os.path.exists(play.get_vars_files())
    #check if the file is a file
    assert os.path.isfile(play.get_vars_files())
    #check if the file is readable
    assert os.access(play.get_vars_files(), os.R_OK)
    #check if the file is writable
    assert os.access(play.get_vars_files(), os.W_OK)
    #check if the file is executable
    assert os.access(play.get_vars_files(), os.X_OK)


# Generated at 2022-06-11 10:26:48.361444
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name == ''
    assert p.hosts == ''
    assert p.roles == []
    assert p.tasks == []
    assert p.vars == {}
    assert p.handlers == []
    assert p.default_vars is False
    assert p.remote_user == 'root'
    assert p.sudo == False
    assert p.sudo_user == 'root'
    assert p.connection == 'smart'
    assert p.gather_facts == True
    assert p.serial is None
    assert p.any_errors_fatal is False
    assert p.max_fail_percentage == 0
    assert p.tags == ['all']
    assert p.skip_tags == []
    assert p.check_mode is False
    assert p.diff is False

# Generated at 2022-06-11 10:26:50.596677
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    t = Task()
    p.add_task(t)
    assert t == p.tasks[0]

# Generated at 2022-06-11 10:26:58.383892
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    assert p.get_vars_files() == []
    p.vars_files = "test.yml"
    assert p.get_vars_files() == ["test.yml"]
    p.vars_files = None
    assert p.get_vars_files() == []
    p.vars_files = ["test.yml", "test2.yml"]
    assert p.get_vars_files() == ["test.yml", "test2.yml"]



# Generated at 2022-06-11 10:27:01.415485
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    p = Play()
    p.preprocess_data({'user': 'user'})
    assert p._ds['remote_user'] == 'user'
    assert 'user' not in p._ds


# Generated at 2022-06-11 10:27:04.257076
# Unit test for method get_name of class Play
def test_Play_get_name():
    '''Test Play.get_name'''
    obj = Play()

    # we should get a string back
    assert isinstance(obj.get_name(), string_types)


# Generated at 2022-06-11 10:27:11.817529
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    # Input parameters
    play_hosts = 'localhost'
    play_user = 'root'
    play_gather_facts = True
    play_roles = ['role1', 'role2']
    play_connection = 'ssh'

    # Declare test Play object
    a_play = Play()

    # Set Play attributes
    a_play.hosts = play_hosts
    a_play.user = play_user
    a_play.gather_facts = play_gather_facts
    a_play.roles = play_roles
    a_play.connection = play_connection

    # Put together test data

# Generated at 2022-06-11 10:27:15.888591
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2, 3]
    play.tasks = [4, 5, 6]
    play.post_tasks = [7, 8, 9]
    assert play.get_tasks() == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-11 10:27:20.621235
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    vars_files = {
        'passed_from_cli_args': True,
        'file_from_cli_args': '/home/test',
        'user': 'test-user'
    }
    p = Play()
    p.vars_files = vars_files
    assert p.get_vars_files() == [vars_files]


# Generated at 2022-06-11 10:27:30.364762
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    p.tasks = []
    assert p.get_tasks() == []
    p.tasks.append(Block(block=[]))
    assert p.get_tasks() == []
    p.tasks[0].block.append(Task())
    assert p.get_tasks() == [p.tasks[0].block[0]]
    p.tasks[0].block.append(Task())
    assert p.get_tasks() == [p.tasks[0].block[0], p.tasks[0].block[1]]
    p.tasks[0].rescue = [Task()]

# Generated at 2022-06-11 10:27:31.446321
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # TODO
    pass



# Generated at 2022-06-11 10:27:50.155683
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1, 2]
    play.tasks = [2, 3]
    play.post_tasks = [3, 4]
    assert play.get_tasks() == [1, 2, 2, 3, 3, 4]

# Generated at 2022-06-11 10:28:00.176997
# Unit test for method get_tasks of class Play

# Generated at 2022-06-11 10:28:00.776572
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass