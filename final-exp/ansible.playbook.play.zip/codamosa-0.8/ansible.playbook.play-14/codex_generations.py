

# Generated at 2022-06-11 10:18:27.876750
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    data = {
        "playbook_uuid": "",
        "vars": None,
        "name": "",
        "hosts": [],
        "_included_conditional": None,
        "_handlers": [],
        "_pre_tasks": [],
        "_post_tasks": [],
        "_tasks": []
    }
    p = Play()
    p.deserialize(data)
    assert p._included_conditional is None
    assert p._included_path is None
    assert p._action_groups == {}
    assert p._group_actions == {}
    assert p.roles == []

    # Test fail
    p2 = Play()
    try:
        p.deserialize(None)
        assert False
    except Exception:
        assert True

    # Test fail

# Generated at 2022-06-11 10:18:33.879587
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    testPlay = Play()
    # test_data

# Generated at 2022-06-11 10:18:45.938116
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    #Create instance of play
    p = Play()
    #Create list of roles
    role1 = Role()
    role2 = Role()
    roles = []
    roles.append(role1)
    roles.append(role2)
    p.roles = roles
    #Create list of tasks for handler for role1
    handler1 = Task()
    handler2 = Task()
    handler1.name = 'handler1'
    handler2.name = 'handler2'
    handler_blocks = []
    handler_blocks.append(handler1)
    handler_blocks.append(handler2)
    #Create block to hold handlers
    block = Block()
    block.block = handler_blocks
    role1.handlers = block
    #Create list of tasks for handler for role2
    handler3 = Task()
    handler4 = Task()

# Generated at 2022-06-11 10:18:50.611276
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    play.pre_tasks = [1,2,3]
    play.tasks = [4,5,6]
    play.post_tasks = [7,8,9]

    expected_result = [1,2,3,4,5,6,7,8,9]
    result = play.get_tasks()

    assert result ==  expected_result


# Generated at 2022-06-11 10:18:53.285975
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    #test_Play_get_vars_files() method is covered in test_playbook_get_vars_files() method of test_playbook.py
    pass

# Generated at 2022-06-11 10:19:06.337853
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    p = Play()
    assert p.compile_roles_handlers() == []
    p._ds = {'roles': ['foo']}
    p._roles = []
    assert p.compile_roles_handlers() == []
    p._roles = [True]
    assert p.compile_roles_handlers() == []
    p._roles = [Role()]
    assert p.compile_roles_handlers() == []
    p._roles = [Role(handlers=[True]), Role(handlers=[False])]
    assert p.compile_roles_handlers() == [True, False]
    p._roles = [Role(handlers=[True]), Role()]
    assert p.compile_roles_handlers() == [True]

# Generated at 2022-06-11 10:19:17.739318
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    playbook = BasePlaybook.load(dict(
        name='test_playbook.yaml',
        hosts='localhost',
        roles=[
            dict(
                name='role1',
                handlers='handlers1.yaml',
                tasks='tasks1.yaml',
            ),
            dict(
                name='role2',
                tasks='tasks2.yaml',
            ),
            dict(
                name='role3',
                handlers='handlers3.yaml',
                tasks='tasks3.yaml',
            ),
        ],
    ))
    results = playbook.compile_roles_handlers()
    assert len(results) == 2
    assert all(isinstance(r, Block) for r in results)
    assert len(results[0].block) == 1

# Generated at 2022-06-11 10:19:20.902218
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    assert p.serialize() == p.deserialize(p.serialize())


# Generated at 2022-06-11 10:19:24.958757
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()
    p.deserialize({'name': 'someName'})
    assert p.get_name() == 'someName'

# Generated at 2022-06-11 10:19:37.061182
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    play = Play()
    data = {
        'hosts': 'localhost',
        'gather_facts': 'yes',
        'user': 'testuser',
        'tasks': [
            {
                'name': 'should fail',
                'fail': {
                    'msg': 'This test should fail'
                }
            }
        ]
    }
    expected = {
        'hosts': 'localhost',
        'gather_facts': 'yes',
        'remote_user': 'testuser',
        'tasks': [
            {
                'name': 'should fail',
                'fail': {
                    'msg': 'This test should fail'
                }
            }
        ]
    }
    play.preprocess_data(data)
    assert expected == play._ds

# Generated at 2022-06-11 10:19:55.852988
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    class TestClass:
        '''
        TEST
        '''
        TestClass_instances = 0
        def __init__(self, a, b):
            TestClass.TestClass_instances += 1
            self.a = a
            self.b = b
        def __repr__(self):
            return "TestClass(a={}, b={})".format(self.a, self.b)

    my_test_classes = [TestClass(1, 2), TestClass(3, 4), TestClass(5, 6)]
    pre_tasks = my_test_classes[0:2]
    tasks = my_test_classes[2:4]
    post_tasks = my_test_classes[1:3]
    Play_inst = Play()
    Play_inst.pre_tasks = pre_tasks

# Generated at 2022-06-11 10:20:06.498525
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
	play_data = {'name': 'test_play', 'hosts': 'localhost', 'tasks': [{'action': {'module': 'shell', 'args': 'ls'}}, {'action': {'module': 'shell', 'args': 'ls -l'}}]}
	play = Play.load(play_data, None, None, None)
	assert len(play.get_tasks()) == 4
	assert isinstance(play.get_tasks()[0], Task)
	assert isinstance(play.get_tasks()[1], Task)
	assert isinstance(play.get_tasks()[2], Task)
	assert isinstance(play.get_tasks()[3], Task)

# Generated at 2022-06-11 10:20:09.539408
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.hosts = ['host1', 'host2']
    assert p.get_name() == 'host1,host2'

# Generated at 2022-06-11 10:20:16.495043
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # arrange
    play = Play()
    # act
    play.vars_files = None
    resp = play.get_vars_files()
    # assert
    assert resp == []

    # act
    play.vars_files = "file1"
    resp = play.get_vars_files()
    # assert
    assert resp == ["file1"]

    # act
    play.vars_files = ["file1", "file2"]
    resp = play.get_vars_files()
    # assert
    assert resp == ["file1", "file2"]


# Generated at 2022-06-11 10:20:27.792990
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play_ds = {
        'name': 'install and configure apache',
        'hosts': ['server1'],
        'remote_user': 'ubuntu',
        'roles': [
            {
                'name': 'apache',
                'handlers': [
                    {
                        'name': 'restart apache2',
                        'service': 'apache2',
                        'state': 'restarted'
                    }
                ]
            }
        ]
    }

    play = Play().load(play_ds, variable_manager=VariableManager(), loader=DictDataLoader())
    assert play.compile_roles_handlers()[0].service == 'apache2'
    assert play.compile_roles_handlers()[0].state == 'restarted'

# Generated at 2022-06-11 10:20:28.516086
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:20:37.262271
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    ds = dict(user=dict(), remote_user=dict())
    with pytest.raises(AnsibleAssertionError) as excinfo:
        p = Play()
        p.preprocess_data(ds)
    assert 'ds should be a dict but was a dict' in to_text(excinfo.value)
    ds = dict()
    p = Play()
    processed_ds = p.preprocess_data(ds)
    assert processed_ds == dict()
    ds = dict(user=dict())
    processed_ds = p.preprocess_data(ds)
    assert processed_ds == dict(remote_user=dict())


# Generated at 2022-06-11 10:20:45.845189
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    # FIXME: If a Play object could be created without any data, this test
    # could be a lot more thorough.

    p = Play()
    p._compile_roles = MagicMock(return_value=())
    p.get_handler_blocks = MagicMock(return_value=(
        Handler(name='foo'),
        Handler(name='bar'),
        Handler(name='baz')
    ))
    result = p.compile_roles_handlers()

    assert result == [
        Handler(name='foo'),
        Handler(name='bar'),
        Handler(name='baz')
    ]

# Generated at 2022-06-11 10:20:49.716691
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    block = Block()
    block.block = Notify()
    handler = Handler()
    handler.block = block
    handler.notify = 'something'
    handler.listen = 'something'
    play.rol

# Generated at 2022-06-11 10:20:53.183561
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    print("test Play.get_name()")
    assert play.get_name() == ''
    print("Test Success!")


# Generated at 2022-06-11 10:21:25.220695
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    # create play 
    my_play = Play()
    my_play.tasks = []
    assert isinstance(my_play, Play) == True
    # this play has no tasks in tasks sections.
    assert my_play.get_tasks() == []
    # add tasks to tasks list
    my_play.tasks.append('a')
    my_play.pre_tasks.append('b')
    my_play.post_tasks.append('c')
    # get tasks from get_tasks() method
    my_play_tasks = my_play.get_tasks()
    # check tasks have been added to the play
    assert len(my_play_tasks) == 3
    # check all tasks are included in the task list
    assert 'a' in my_play_tasks

# Generated at 2022-06-11 10:21:34.449471
# Unit test for method deserialize of class Play
def test_Play_deserialize():
    p = Play()

# Generated at 2022-06-11 10:21:45.181498
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():

    context._init_global_context(config=None)
    context.CLIARGS = AttributeDict(connection='local')
    password = dict(vault_password='password')
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=Inventory())

    class FakeRole:
        def get_handler_blocks(self, play):
            fake_play = play
            fake_play.ROLE_CACHE = dict(handlers=[1])
            return list(fake_play.ROLE_CACHE.get('handlers', []))

    class FakePlay(Play):
        def __init__(self):
            super(FakePlay, self).__init__()
            self.roles = [FakeRole(), FakeRole()]

    play = FakePlay()

    handlers = play.compile_

# Generated at 2022-06-11 10:21:55.332227
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    print('***********Unit test for Play_preprocess_data***********')
    try:
        data = dict(name = 'play_preprocess_data',
                    hosts = 'hosts_preprocess_data',
                    roles = 'roles_preprocess_data',
                    become = 'become_preprocess_data',
                    become_user = None)
        p = Play()
        data_validated = p.preprocess_data(data)
        print(data_validated)
        print('Unit test for Play_preprocess_data finished and passed')
    except Exception as e:
        print(e)

# Generated at 2022-06-11 10:21:57.439073
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    p = Play()
    t = Task()
    b = Block()
    b.task = [t]
    p.tasks = [t, b]
    print(p.get_tasks())



# Generated at 2022-06-11 10:22:04.780034
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    block_list = []
    play_data = dict(
        name="Ansible Play",
        hosts="test host",
        gather_facts="no",
        tasks=[dict(action=dict(module="shell", args="id"), register="shell_out"),
               dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}")))])
    play = Play.load(play_data)
    block_list = play.get_tasks()
    assert len(block_list) == 2

# Generated at 2022-06-11 10:22:15.915657
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

        # setup
        playbook_path = ["testSetup"]
        variable_manager = VariableManager()
        loader = DataLoader()
        variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=["127.0.0.1"]))
        variable_manager.set_vault_secrets(['group_vars/secret.yml'])
        variable_manager.extra_vars = load_extra_vars(loader=loader, options=Options())
        variable_manager.options_vars = load_options_vars(Options())

        # test for play with vars_files==None
        play = Play()
        play.vars_files = None

        assert play.get_vars_files() == []

        # test for play with vars_files=='test_v

# Generated at 2022-06-11 10:22:23.600217
# Unit test for method get_name of class Play
def test_Play_get_name():
    p = Play()
    p.hosts = "somehost"
    p.name = "somename"
    assert p.get_name() == "somename"

    p = Play()
    p.hosts = "somehost"
    assert p.get_name() == "somehost"

    p = Play()
    p.name = "somename"
    assert p.get_name() == "somename"

    p = Play()
    assert p.get_name() == ""


# Generated at 2022-06-11 10:22:26.701912
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    play = Play()
    play.vars_files = ['./test/test_playbook.yml']
    assert play.get_vars_files() == ['./test/test_playbook.yml']


# Generated at 2022-06-11 10:22:29.274750
# Unit test for method preprocess_data of class Play
def test_Play_preprocess_data():
    '''
    Unit test for method preprocess_data of class Play
    '''
    p = Play()
    p.preprocess_data({'user': 'test', 'remote_user': 'test2'})
    p.preprocess_data({'user': 'test'})


# Generated at 2022-06-11 10:23:02.810440
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test for method compile_roles_handlers of class Play
    # Test that handlers from the roles are in fact returned

    # Create a fake role that is only here to test the method
    # compile_roles_handlers
    fake_role = setup_fake_useful_role_with_handlers()

    # Add the fake role to a list (this is the roles attribute of
    # the Play class)
    list_of_roles = [fake_role]

    # Create the play in order to add the list of roles to the
    # play
    the_play = Play()
    the_play.roles = list_of_roles

    # Get the handlers from the play
    handlers_from_play = the_play.compile_roles_handlers()

    # Check that there is one handler in the handlers
    #

# Generated at 2022-06-11 10:23:14.720310
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    test_ins = Play()
    test_ins._load_roles(None, ["../../lib/ansible/roles/test1", "../../lib/ansible/roles/test2"])
    test_ins.roles[0]._load_handlers(None, [{'name': 'handler1', 'when': 'test1'},{'name': 'handler2', 'when': 'test2'}])
    test_ins.roles[1]._load_handlers(None, [{'name': 'handler3', 'when': 'test3'},{'name': 'handler4', 'when': 'test4'}])
    res=test_ins.compile_roles_handlers()
    assert len(res)==4
    assert res[0].name=='handler1'

# Generated at 2022-06-11 10:23:15.405431
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
	pass

# Generated at 2022-06-11 10:23:17.715413
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    play.roles = []
    assert play.compile_roles_handlers() == []

# Generated at 2022-06-11 10:23:18.350531
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass

# Generated at 2022-06-11 10:23:28.662353
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    # Test case
    play = Play()
    role1 = Role()
    role2 = Role()
    roles = [role1, role2]
    play.roles[:0] = roles
    block_list = []
    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    role1.tasks[:0] = [task1, task2]
    role1.handlers[:0] = [task3]
    role2.tasks[:0] = [task4]
    block_list.extend(role1.get_handler_blocks())
    block_list.extend(role2.get_handler_blocks())
    # Start the test
    block_list_returned = play.compile_roles_handlers()
    assert block

# Generated at 2022-06-11 10:23:36.539791
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    # Play object creation
    play = Play()

    # Play object attributes initialization
    play.vars_files = ['/etc/ansible/vars.yml', '/etc/ansible/vars2.yml']

    # check if get_vars_files method of Play class returns proper value
    assert play.get_vars_files() == ['/etc/ansible/vars.yml', '/etc/ansible/vars2.yml']


# Generated at 2022-06-11 10:23:41.961569
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Arrange
    play = Play()
    play.name = 'foo'
    play.hosts = 'bar'
    expected_name = 'foo'

    # Act
    actual_name = play.get_name()

    # Assert
    assert_equal(actual_name, expected_name)

# Generated at 2022-06-11 10:23:52.728757
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
        # test_Play_get_tasks()

        """
        Unit test for Play.get_tasks()

        """

        b1 = Block(
            tasks=[
                Task(action='action1'),
                Task(action='action2'),
                Task(action='action3'),
            ]
        )

        b2 = Block(
            tasks=[
                Task(action='action4'),
                Task(action='action5'),
            ]
        )

        b3 = Block(
            tasks=[
                Task(action='action6'),
            ]
        )


# Generated at 2022-06-11 10:24:04.045766
# Unit test for method get_tasks of class Play

# Generated at 2022-06-11 10:25:00.092954
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play1=Play()
    a= Task()
    b= Task()
    c= Task()
    d= Task()
    e= Task()
    f= Task()
    block=Block()
    block.block=[a,b]
    play1.pre_tasks=[block]
    play1.tasks=[c,d]
    play1.post_tasks=[e,f]
    play1.get_tasks()
    assert (play1.pre_tasks[0].block[0]==a)
    assert (play1.pre_tasks[0].block[1]==b )
    assert (play1.tasks[0]==c)
    assert (play1.tasks[1]==d)
    assert (play1.post_tasks[0]==e)

# Generated at 2022-06-11 10:25:03.463638
# Unit test for method get_name of class Play
def test_Play_get_name():
    play = Play()
    play._validate_hosts = MagicMock(return_value="host1"),
    assert play.get_name() == "host1,"



# Generated at 2022-06-11 10:25:14.399627
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    import unittest
    import sys
    sys.path.append('../lib')
    from ansible.playbook.play import Play
    '''
    :return:
    '''
    play = Play()
    print()
    # pytest.set_trace()
    play.pre_tasks.append(1)
    play.pre_tasks.append(2)
    play.tasks.append(3)
    play.post_tasks.append(4)
    play.post_tasks.append(5)
    print(play.get_tasks())


if __name__ == '__main__':
    test_Play_get_tasks()

# Generated at 2022-06-11 10:25:22.786427
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    testInput = {
        'roles': [{
            'block': [{
                'handler': [{
                    'name': 'task1',
                    'tags': 'test'
                }]
            }],
            'name': 'test_role'
        }],
        'name': 'testname'
    }

    myPlay = Play.load(testInput)
    assert myPlay.compile_roles_handlers() == [[{
        'name': 'task1',
        'tags': 'test'
    }]]


# Generated at 2022-06-11 10:25:31.393793
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    data = dict(
        name="test play",
        hosts='all',
        gather_facts='no',
        vars_files=["./ansible/vars_files/test_files1",
                    "./ansible/vars_files/test_files2"]
        )
    play = Play.load(data, VariableManager(), 'loader')
    vars_files = play.get_vars_files()
    expected_vars_files = ["./ansible/vars_files/test_files1",
                    "./ansible/vars_files/test_files2"]
    assert vars_files == expected_vars_files, "Expected '%s', got '%s'" % (expected_vars_files, vars_files)


# Generated at 2022-06-11 10:25:43.728422
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """
    This is a Unit test for the method get_tasks
    of class Play that is in __main__.py.
    """
    # Testing for the Play method that gets the tasks of the Play
    # Get all the tasks
    play = Play()
    tasks = [
        {
            'name' : 'dns server',
            'action' : {
                'module' : 'command',
                'args' : 'echo test'
            }
        },
        {
            'name' : 'web server',
            'action' : {
                'module' : 'command',
                'args' : 'echo test'
            }
        }
    ]
    play._tasks = tasks
    assert play.get_tasks() == tasks

# Generated at 2022-06-11 10:25:52.070790
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    """ Play: test get_tasks method """
    play = Play()
    play.pre_tasks = [
        {'block': [
            {'tasks': [
                {'debug': {'msg': 'in pre_tasks'}}
             ]}
         ]}
     ]
    play.tasks = [
        {'block': [
            {'tasks': [
                {'debug': {'msg': 'in tasks'}}
             ]}
         ]}
     ]
    play.post_tasks = [
        {'block': [
            {'tasks': [
                {'debug': {'msg': 'in post_tasks'}}
             ]}
         ]}
     ]
    play.rescue = []
    play.always = []
    task_list = play.get_

# Generated at 2022-06-11 10:26:01.881860
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    p = Play()
    p.vars_files = ['./1.yml', './2.yml']
    result = p.get_vars_files()
    assert(len(result) == 2)
    assert('./1.yml' in result)
    assert('./2.yml' in result)

    p.vars_files = './1.yml'
    result = p.get_vars_files()
    assert(len(result) == 1)
    assert('./1.yml' in result)

    p.vars_files = None
    result = p.get_vars_files()
    assert(len(result) == 0)


# Generated at 2022-06-11 10:26:13.536243
# Unit test for constructor of class Play
def test_Play():
    p = Play()
    assert p.name is None
    assert p.hosts is None
    assert p.connection is None
    assert p.port is None
    assert p.remote_user is None
    assert p.become is None
    assert p.become_user is None
    assert p.become_method is None
    assert p.become_flags is None
    assert p.vars is None
    assert p.vars_prompt is None
    assert p.vars_files is None
    assert p.tags is None
    assert p.gather_facts is None
    assert p.roles is None
    assert p.tasks is None
    assert p.post_tasks is None
    assert p.handlers is None
    assert p.pre_tasks is None
    assert p.force_handlers

# Generated at 2022-06-11 10:26:15.032367
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    play = Play()
    assert play.compile_roles_handlers() is None


# Generated at 2022-06-11 10:27:17.214932
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    ansible_options = namedtuple('Options', ['ask_vault_pass', 'connection', 'forks', 'listhosts', 'listtasks',
    'listtags', 'list_tasks', 'module_path', 'private_key_file', 'remote_user', 'scp_extra_args', 'sftp_extra_args',
    'ssh_common_args', 'ssh_extra_args', 'vault_password_files', 'verbosity', 'inventory', 'check', 'sudo_user',
    'sudo', 'ask_sudo_pass', 'diff', 'syntax', 'timeout', 'vault_password_file'])
    ansible_options.ask_vault_pass=False
    ansible_options.connection='ssh'
    ansible_options.forks=100
    ansible_options.listhost

# Generated at 2022-06-11 10:27:24.124548
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():

    p = Play()
    assert p.get_vars_files() == []

    setattr(p, 'vars_files', None)
    assert p.get_vars_files() == []

    setattr(p, 'vars_files', 'hello.yml')
    assert p.get_vars_files() == ['hello.yml']

    setattr(p, 'vars_files', ['hello.yml', 'world.yml'])
    assert p.get_vars_files() == ['hello.yml', 'world.yml']


# Generated at 2022-06-11 10:27:25.588384
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    play = Play()
    assert play.get_tasks() == []

# Generated at 2022-06-11 10:27:31.599852
# Unit test for method get_tasks of class Play
def test_Play_get_tasks():
    with open('test/unit/examples/playbook_play_get_tasks1.json') as file:
        str=json.dumps(json.load(file))
        print(str)
        ds = json.loads(str, strict=False)
        play = Play.load(ds)
        result = play.get_tasks()
        print(result)
if __name__ == "__main__":
    test_Play_get_tasks()

# Generated at 2022-06-11 10:27:32.616696
# Unit test for method compile_roles_handlers of class Play
def test_Play_compile_roles_handlers():
    pass


# Generated at 2022-06-11 10:27:41.977527
# Unit test for method deserialize of class Play

# Generated at 2022-06-11 10:27:52.396329
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # This method accepts no arguments.
    # The method is a simple getter for a class attribute. It
    # is tested as a unit mainly for coverage.
    play = Play()
    play.vars_files = 'path/to/vars_file'
    assert play.get_vars_files() == ['path/to/vars_file']
    play.vars_files = None
    assert play.get_vars_files() == []
    play.vars_files = [
        'path/to/vars1',
        'path/to/vars2'
    ]
    assert play.get_vars_files() == [
        'path/to/vars1',
        'path/to/vars2'
    ]



# Generated at 2022-06-11 10:27:59.001689
# Unit test for method get_name of class Play
def test_Play_get_name():
    # Test case #1
    play = Play()
    play.name = None
    play.hosts = None
    if play.get_name() is '':
        print('Pass')
    else:
        print('Fail')

    # Test case #2
    play = Play()
    play.name = None
    play.hosts = 'host1'
    if play.get_name() is 'host1':
        print('Pass')
    else:
        print('Fail')



# Generated at 2022-06-11 10:28:00.618783
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    # play = Play()
    # assert play.get_vars_files() == []
    pass


# Generated at 2022-06-11 10:28:04.132387
# Unit test for method get_vars_files of class Play
def test_Play_get_vars_files():
    test_play = Play()
    test_play.vars_files = None
    assert test_play.get_vars_files() == []
    test_play.vars_files = "a"
    assert test_play.get_vars_files() == ["a"]