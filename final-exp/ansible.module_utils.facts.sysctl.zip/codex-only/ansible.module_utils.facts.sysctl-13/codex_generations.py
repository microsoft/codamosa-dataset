

# Generated at 2022-06-23 00:27:06.827484
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('', ['-a'])

# Generated at 2022-06-23 00:27:12.138291
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = type('test_module', (object,), {})
    test_module.run_command = lambda self, cmd, *args, **kw: (0, 'foo = bar\nbar = foo\n', '')

    assert get_sysctl(test_module, []) == {'foo': 'bar', 'bar': 'foo'}

# Generated at 2022-06-23 00:27:15.425053
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec=dict())
    assert get_sysctl(module, ['vm.swappiness']) == {'vm.swappiness': '0'}

# Generated at 2022-06-23 00:27:19.842195
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(prefixes=dict(required=True, type='list')))
    sysctl = get_sysctl(module, module.params['prefixes'])
    module.exit_json(msg=sysctl)



# Generated at 2022-06-23 00:27:30.084165
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = lambda x:x

    # Check the defaults
    rc, out, err = module.run_command(['sysctl', 'fs.inotify.max_user_watches'])
    assert rc == 0
    assert out != ''

    # check function output with max_user_watches returned
    assert get_sysctl(module, ['fs.inotify.max_user_watches']) == {'fs.inotify.max_user_watches': out.split(' = ')[1]}

    # check function output with some not existing prefix
    assert get_sysctl(module, ['fs.inotify.max_user_not_existing_watches']) == dict

# Generated at 2022-06-23 00:27:38.202877
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_info = get_sysctl('net.ipv4.conf.all',
                             ['net.ipv4.conf.all.forwarding',
                              'net.ipv4.conf.all.accept_redirects',
                              'net.ipv4.conf.all.send_redirects'])
    assert 'net.ipv4.conf.all.forwarding' in sysctl_info
    assert 'net.ipv4.conf.all.accept_redirects' in sysctl_info
    assert 'net.ipv4.conf.all.send_redirects' in sysctl_info
    assert 'net.ipv4.conf.all.rp_filter' not in sysctl_info

# Generated at 2022-06-23 00:27:48.254949
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    class TestAnsibleModule():
        def __init__(self, params):
            self.params = params
            self.exit_json_called = False
            self.fail_json_called = False
            self._sys_modules_backup = sys.modules.copy()

        def exit_json(self, **kwargs):
            self.exit_json_called = True

        def fail_json(self, **kwargs):
            self.fail_json_called = True

    test_module = TestAnsibleModule({})

# Generated at 2022-06-23 00:27:58.967794
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule(object):
        def __init__(self, result):
            self.rc = result['rc']
            self.stdout = result['out']
            self.stderr = result['err']

            rc = [0, 1]
            if self.rc not in rc:
                raise ValueError('rc value ("%s") must be one of: %s' % (self.rc, rc))

            self.warns = []

        def warn(self, msg):
            self.warns.append(msg)

        def get_bin_path(self, name):
            if name == 'sysctl':
                return 'sysctl'


# Generated at 2022-06-23 00:28:03.742975
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, [])

    assert sysctl != dict()

# Generated at 2022-06-23 00:28:13.579799
# Unit test for function get_sysctl
def test_get_sysctl():

    # Test 1: Test bad data
    # Test that the function return an empty dict
    bad_data = ''

    # Test 2: Test good data
    # Test that the function return a dict that contains the expected values
    # that were queried

# Generated at 2022-06-23 00:28:25.127173
# Unit test for function get_sysctl
def test_get_sysctl():

    # Mock module to mock ansible module
    class MockAnsibleModule():

        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''

        def run_command(self, command):
            self.run_command_called = True
            return self.run_command_rc, self.run_command_stdout, self.run_command_stderr

        def get_bin_path(self, command):
            return command

    # Test case 1: sysctl command should return instance
    def test_sysctl_return_dict(test_stdout, test_stderr):
        m = MockAnsibleModule()

# Generated at 2022-06-23 00:28:36.465885
# Unit test for function get_sysctl
def test_get_sysctl():
    """ Test sysctl gathering """
    test_module = type('test', (object,), {})

    class test_run_command(object):
        # pylint: disable=too-few-public-methods
        def __init__(self, rc=0, value=None):
            self.rc = rc
            self.out = value

        def __call__(self, *_):
            return (self.rc, self.out, None)

    def test_get_bin_path(*args, **kwargs):
        return '/usr/bin/sysctl'


# Generated at 2022-06-23 00:28:41.180056
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.misc.plugins.module_utils.get_sysctl import get_sysctl

    module = None
    result = get_sysctl(module, ['vm.swappiness'])
    assert result.get('vm.swappiness') == "60"
    assert result.get('vm.swappiness.bogus') is None

# Generated at 2022-06-23 00:28:48.337583
# Unit test for function get_sysctl
def test_get_sysctl():
    '''get_sysctl should return an empty dictionary on failure'''
    assert get_sysctl((), ()) == {}
    assert get_sysctl(('foo'), ()) == {}
    assert get_sysctl(('one', 'two'), ()) == {}
    assert get_sysctl(('foo'), ('bar')) == {}
    assert get_sysctl(('one', 'two'), ('bar')) == {}
    '''get_sysctl should handle multiple keys'''
    assert get_sysctl(('sysctl', '-n', 'kern.usermount'), (
        'kern', 'hw', 'usermount'
    )) == {'kern.usermount': '1'}
    '''get_sysctl should handle single keys'''

# Generated at 2022-06-23 00:28:58.376570
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import platform


# Generated at 2022-06-23 00:29:03.707722
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import Mock
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.modules.utils import AnsibleFailJson

    module = Mock(run_command=Mock(return_value=(0, 'foobar=barfoo\n', '')))
    module.get_bin_path = lambda _: 'sysctl'

    try:
        assert get_sysctl(module, ['-a']) == dict(foobar='barfoo')
    except AssertionError:
        raise Exception('Test failed: get_sysctl')

    module = Mock(get_bin_path=lambda _: 'sysctl', run_command=Mock(side_effect=OSError('no sysctl')))

# Generated at 2022-06-23 00:29:08.790777
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({'run_command': test_run_command}, ['kern.boottime']) == {'kern.boottime': '{ sec = 1403585646, '
                                                                                                 'usec = 73767 } '
                                                                                                 'Sat Jul 19 '
                                                                                                 '14:24:06 2014'}


# Generated at 2022-06-23 00:29:20.010414
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    res_args = dict(
        changed=False,
        result=dict()
    )

    # Test sysctl output from a Linux host

# Generated at 2022-06-23 00:29:26.303904
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['vm.swappiness']
    sysctlv = get_sysctl(None, prefixes)

    swappiness = re.compile("^vm.swappiness\s?=\s?(.*)$")
    for line in sysctlv:
        match = swappiness.match(line)
        if match:
            assert True, match.group(1)
        else:
            assert False, 'not found'



# Generated at 2022-06-23 00:29:36.441337
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = type('AnsibleModule', (object,), dict(
        exit_json=lambda self, changed=False, msg=None, meta=None: 0,
        fail_json=lambda self, msg, **kwargs: 0,
        warn=lambda self, msg, **kwargs: 0,
        run_command=lambda self, cmd, **kwargs: (0, '', '')
    ))()

    assert get_sysctl(module, ['net.ipv4.tcp_syncookies']) == {'net.ipv4.tcp_syncookies': '1'}
    with open('/proc/sys/net/ipv4/tcp_syncookies', 'w') as f:
        f.write('2')


# Generated at 2022-06-23 00:29:38.476944
# Unit test for function get_sysctl
def test_get_sysctl():
    print ()
    print ('Testing get_sysctl')

    sysctl = get_sysctl(self, module, prefixes)

    print ('sysctl: ' + sysctl)
    return (sysctl)

# Generated at 2022-06-23 00:29:46.194406
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec=dict())

    import tempfile
    with tempfile.NamedTemporaryFile() as tmp:
        tmp.write(b'sysctl_test:\ntest_value = 9\n')
        tmp.flush()
        m.run_command = lambda x: (0, tmp.read(), '')
        assert m.run_command == m.run_command
        sysctl = get_sysctl(m, ['test'])
        assert sysctl['sysctl_test.test_value'] == '9'
    return True

# Generated at 2022-06-23 00:29:57.374864
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import PY3

    sysctl_out = {
        'kern.boottime': 'Fri Dec 23 21:05:25 2016  -  8:15    ago',
        'kern.hostname': 'hostname',
        'kern.maxfiles': '1048576',
        'kern.maxfilesperproc': '1048576',
        'kern.osreldate': '262546',
        'kern.osrelease': '15.7-RELEASE-p2',
        'kern.version': 'FreeBSD 15.7-RELEASE-p2  #0: Sat Dec 17 11:28:16 UTC 2016     root@amd64-builder.daemonology.net:/usr/obj/usr/src/sys/GENERIC',
    }


# Generated at 2022-06-23 00:30:06.253162
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    module = AnsibleModule({'name': 'test', 'prefixes': ['vm.swappiness']})
    try:
        rc, out, err = module.run_command('cat test_sysctl.txt')
    except Exception as e:
        module.fail_json(msg=to_text(e))

    # Simulate piping output of sysctl
    basic.get_bin_path = lambda x: 'cat'
    module.run_command = lambda cmd: (0, out, '')

    sysctl_pre = get_sysctl(module, ['vm.swappiness'])

    sysctl_post = dict(vm_swappiness='60')

# Generated at 2022-06-23 00:30:15.775700
# Unit test for function get_sysctl
def test_get_sysctl():
    class MockModule(object):
        def run_command(self, cmd):
            return (0, 'net.ipv4.ip_forward: 1\nnet.ipv4.conf.all.rp_filter: 1\nnet.ipv4.conf.default.rp_filter: 1\n', '')

    actual = get_sysctl(MockModule(), ['net.ipv4'])
    assert actual['net.ipv4.ip_forward'] == '1'
    assert actual['net.ipv4.conf.all.rp_filter'] == '1'
    assert actual['net.ipv4.conf.default.rp_filter'] == '1'


# Generated at 2022-06-23 00:30:26.726037
# Unit test for function get_sysctl
def test_get_sysctl():

    class FakeModule(object):
        def __init__(self, sysctl_cmd):
            self.sysctl_cmd = sysctl_cmd
            self.params = dict()

        def get_bin_path(self, name, required=True):
            return self.sysctl_cmd

        def run_command(self, command):
            if self.sysctl_cmd == '/bin/false':
                return ('1', '', '')
            if self.sysctl_cmd == '/bin/true':
                return ('0', '', '')
            if self.sysctl_cmd == '/bin/sysctl':
                return ('0', 'vm.swappiness = 30\nvm.max_map_count = 200000', '')
            return ('0', '', '')

        def warn(self, msg):
            pass

    mocks

# Generated at 2022-06-23 00:30:30.107850
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('Module', (object,), {})()
    prefixes = ['net.ipv4.ip_forward']
    sysctl = get_sysctl(module, prefixes)
    assert sysctl['net.ipv4.ip_forward'] == "1"

# Generated at 2022-06-23 00:30:42.219554
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    ansible_module = AnsibleModule(argument_spec=dict())
    if sys.version_info[0] <= 2:
        get_bin_path = lambda x: '/usr/bin/{0}'.format(x)
    else:
        def get_bin_path(x):
            return '/usr/bin/{0}'.format(x)

    ansible_module.run_command = lambda cmd: (0, os.linesep.join(['vm.stat[threads] = 0', 'vm.swappiness = 1', '', 'hw.acpi.cpu.cx_lowest[0] = C1', 'hw.acpi.cpu.cx_lowest[1] = C1', '']), '')


# Generated at 2022-06-23 00:30:51.998749
# Unit test for function get_sysctl
def test_get_sysctl():
    test_input = """
vm.swappiness = 60
kernel.panic = 0
"""

    test_output = {
        "vm.swappiness": "60",
        "kernel.panic": "0",
    }

    assert get_sysctl(None, []) == {}
    assert get_sysctl(None, None) == {}
    assert get_sysctl('not a real object', None) == {}
    assert get_sysctl({ }, None) == {}

    class MockModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, test_input, None)
            self.get_bin_path = lambda x: x

    assert get_sysctl(MockModule(), None) == test_output
    assert get_sysctl(MockModule(), []) == test_output
   

# Generated at 2022-06-23 00:31:02.806712
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class FakeModule(object):

        def __init__(self):
            self.paths = {
                'sysctl': 'bin/sysctl',
            }
            self.values = {}
            self.rc = 0
            self.out = ''
            self.err = ''
            self.called = {}
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, key):
            return self.paths[key]
        def get_bin_path(self, key):
            return self.paths[key]

        def warn(self, msg):
            pass

# Generated at 2022-06-23 00:31:06.161274
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = ['kern']
    sysctl = get_sysctl(module, prefixes)
    assert 'kern.securelevel' in sysctl.keys()

# Generated at 2022-06-23 00:31:17.914444
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    sysctl_file = os.path.dirname(os.path.realpath(__file__)) + '/files/sysctl.txt'
    with open(sysctl_file, 'r') as f:
        lines = f.read()

    class FakeModule(object):
        def __init__(self, name):
            self.name = name

        def get_bin_path(self, name):
            return 'sysctl'

        def run_command(self, cmd):
            return 0, lines, ''

        def warn(self, msg):
            pass

    test_prefixes = []
    test_prefixes.append('vm.min_free_kbytes')
    test_prefixes.append('kernel.msgmnb')

# Generated at 2022-06-23 00:31:20.965886
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl
    sysctl_out = sysctl.get_sysctl({}, ["net"])
    assert sysctl_out['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-23 00:31:32.360688
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    This function is a unit test for the get_sysctl function. It is not part
    of the module, it is something that is easy to call and check the results
    of.

    $ ansible localhost -m shell -a 'python tests/unit/modules/system/test_sysctl.py'

    """
    class FakeModule:
        def __init__(self):
            self.bin_path = "/sbin:/bin"

        def get_bin_path(self, cmd):
            # The unit test on a macOS system will fail because it does not find
            # sysctl in the bin_path. So we just return the command.
            if cmd == "sysctl":
                return cmd
            return 'cmd_not_found'


# Generated at 2022-06-23 00:31:39.441972
# Unit test for function get_sysctl
def test_get_sysctl():
    get_sysctl(module, [
        'net.ipv4.conf.all.rp_filter',
        'net.ipv4.conf.default.rp_filter',
        'net.ipv4.conf.all.accept_redirects',
        'net.ipv4.conf.default.accept_redirects',
        'net.ipv4.conf.all.send_redirects',
        'net.ipv4.conf.default.send_redirects'
    ])

# Generated at 2022-06-23 00:31:51.724772
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    import os

    class TestModule(object):
        def run_command(self,cmd):
            proc = os.popen(cmd[0]+' '+' '.join(cmd[1:]))
            return (0, proc.read(), '')

        def get_bin_path(self,cmd):
            return get_bin_path(cmd)

        def fail_json(self, *args, **kwargs):
            pass

        def warn(self,args):
            pass

    module = TestModule()
    module.get_bin_path('sysctl')
    result = get_sysctl(module, ['kern.jail'])

# Generated at 2022-06-23 00:31:58.745749
# Unit test for function get_sysctl
def test_get_sysctl():
    # This is a unit test to verify the behaviour of the function get_sysctl
    # This function should return a dictionary of sysctl parameters
    # Including multi line ones
    # This unit test checks this behaviour
    # The fake module returns some sysctl parameters as if run with the command 'sysctl vm.swappiness vfs.read_max'
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, cmd):
            rc = 0
            out = """vm.swappiness = 1
vfs.read_max = 4096
vfs.read_bsd_synchronous = 1
vfs.read_max_active = 10
"""
           

# Generated at 2022-06-23 00:32:09.951550
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 00:32:21.477560
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import tempfile

    # Create temporary modules object for unit tests
    class ModuleTest(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda message, **kw: sys.stderr.write(message)
        def run_command(self, cmd):
            return (0, 'a = 1\nb: 2\nc = 3\n', '')
        def get_bin_path(self, cmd):
            return '/bin/%s' % cmd
    module = ModuleTest()

    # Run test
    sysctl = get_sysctl(module, ['a', 'b.c'])

    # Check result
    assert (sysctl['a'] == '1')
    assert (sysctl['b.c'] == '2')


# Generated at 2022-06-23 00:32:33.103669
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    main_mock = MagicMock()
    main_mock.get_bin_path = MagicMock(return_value='/usr/sbin/sysctl')

# Generated at 2022-06-23 00:32:41.185369
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Test the get_sysctl function
    """
    from ansible.module_utils.basic import AnsibleModule

    data = """
# kernel.domainname = example.com
kernel.hostname = foo
kernel.osrelease = 2.6.32-504.16.2.el6.x86_64
kernel.ostype = Linux
kernel.version = #1 SMP Wed Apr 22 06:48:29 UTC 2015
net.ipv6.conf.all.disable_ipv6 = 0
net.ipv6.conf.default.disable_ipv6 = 0
net.ipv6.conf.lo.disable_ipv6 = 0
"""

# Generated at 2022-06-23 00:32:48.452577
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (object, ), dict(get_bin_path=lambda self, x: x,
                                             warn=lambda self, x: None,
                                             run_command=lambda self, x: (0, 'net.ipv4.ip_forward: 1\n', ''),
                                             ))
    assert get_sysctl(module, ['net.ipv4.ip_forward']) == dict(net_ipv4_ip_forward='1')

# Generated at 2022-06-23 00:32:58.029329
# Unit test for function get_sysctl
def test_get_sysctl():
    '''Mocking of module and command results'''

    import subprocess

    class TestModule(object):
        def get_bin_path(self, bin_path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            class MockPopen(object):
                def __init__(self, *args, **kwargs):
                    pass


# Generated at 2022-06-23 00:33:03.954608
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, prefixes=['net', 'ipv4'])
    assert isinstance(sysctl, dict)
    assert 'net.ipv4.ip_forward' in sysctl
    assert '1' in sysctl.values()

# Generated at 2022-06-23 00:33:11.250490
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    sysctl_cmd = '/usr/sbin/sysctl'
    cmd = [sysctl_cmd, 'vm.swappiness']
    out = '''vm.swappiness = 1
'''
    err = ''
    rc = 0
    module = mod

    new_module = mod.load_params(rc=rc, out=out, err=err)
    sysctl = get_sysctl(new_module, ['-a'])
    assert sysctl['vm.swappiness'] == '1'

# Generated at 2022-06-23 00:33:22.952234
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.basic import AnsibleModule

    results = dict(
        changed=False,
        rc=0,
        stdout='',
        stderr='',
    )

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    module.run_command = lambda args, **kwargs: results
    sysctl = get_sysctl(module, ['net.ipv4.conf.all.accept_source_route'])

    assert 'net.ipv4.conf.all.accept_source_route' in sysctl
    assert sysctl['net.ipv4.conf.all.accept_source_route'] == '0'


# Generated at 2022-06-23 00:33:26.958926
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    sysctl = get_sysctl(module, prefixes=[])
    assert sysctl is not None


# Generated at 2022-06-23 00:33:37.761726
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    prefix = [
        'user.ansible',
        'user.not.a.value',
        'user.not.a.value.yet'
    ]
    sysctl_out = """
user.ansible.test1: 1
user.ansible.test2: 2
user.ansible.test3: 3
user.ansible.test4: 4
user.ansible.test5: 5
user.not.a.value.yet: 6
"""
    module.run_command = lambda cmd: (0, sysctl_out, '')

# Generated at 2022-06-23 00:33:41.441259
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.modules.system.sysctl as sysctl
    module = sysctl.AnsibleModule(argument_spec=dict())
    result = get_sysctl(module, [])
    assert 'kernel.hostname' in result


# Generated at 2022-06-23 00:33:50.495250
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda cmd: (0, 'net.ipv4.ip_forward = 0\nnet.ipv4.conf.default.accept_source_route = 0', '')
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.default.accept_source_route'])
    assert sysctl['net.ipv4.ip_forward'] == '0'
    assert sysctl['net.ipv4.conf.default.accept_source_route'] == '0'

# vim: et ts=4 sw=4 fdm=marker

# Generated at 2022-06-23 00:34:01.845936
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    tmp = tempfile.NamedTemporaryFile()
    tmp.write(b'foo: 1\n')
    tmp.write(b'bar: abcd\n')
    tmp.write(b'baz: \n')
    tmp.write(b'  baz=value\n')
    tmp.flush()
    module.run_command = lambda args: (0, open(tmp.name).read(), '')

    sysctl = get_sysctl(module, ['baz'])
    assert sysctl['baz'] == 'value', sysctl
    assert 'bar' not in sysctl, sysctl


# Generated at 2022-06-23 00:34:04.986199
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    get_sysctl(module, [])


# Generated at 2022-06-23 00:34:11.906969
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    m = basic.AnsibleModule(argument_spec=dict())

    # Test on Linux
    sysctl = get_sysctl(m, ['-n', 'kernel.hostname']);
    assert len(sysctl) == 1
    assert sysctl['kernel.hostname'] != ''

    # Test on Windows
    sysctl = get_sysctl(m, ['-n', 'kernel.hostname']);
    assert len(sysctl) == 0

# Generated at 2022-06-23 00:34:23.331561
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import os

    module = basic.AnsibleModule(argument_spec={'prefix': {'required': False, 'type': 'list', 'default': []}})

    if os.geteuid() != 0:
        module.exit_json(changed=False, failed=True, msg='sysctl module requires root privilege')

    sysctl = get_sysctl(module, module.params['prefix'])

    if sysctl:
        module.exit_json(changed=True, sysctl=sysctl)
    else:
        module.exit_json(changed=False, failed=True, msg='Error reading sysctl: %s' % to_text(sysctl))

# Run directly when invoked from CLI
if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:34:26.773055
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': dict(type='list', default=[])})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl == {'vm.swappiness': '60'}

# Generated at 2022-06-23 00:34:30.342807
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            prefix = dict(required=True, type='list'),
        ),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, module.params['prefix'])

    assert sysctl['vm.swappiness'] == '1'

# Generated at 2022-06-23 00:34:39.386099
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    # a 'fake' module instance with the methods we need
    class FakeModule:
        def get_bin_path(self, name, opt_dirs=[]):
            if name in ('sysctl'):
                return name
        def run_command(self, cmd, check_rc=True, close_fds=True,
                        executable=None, data=None, binary_data=True):
            from random import randint
            from random import choice
            from string import ascii_letters
            from string import digits

            modules = ['a', 'b', 'c', 'd', 'e']
            sysctl = dict()
            for module in modules:
                sysctl[module+':'] = ""


# Generated at 2022-06-23 00:34:39.994264
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-23 00:34:49.919986
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import json
    # ansible.module_utils.basic.AnsibleModule does not
    # have a proper mocking object.
    # I am just mocking its exit_json, so that I can test
    # if the module had exit_json called with the correct arguments
    # or not.
    m = AnsibleModule()
    m.exit_json = mock_func()

# Generated at 2022-06-23 00:34:56.380099
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY2

    sysctl_cmd = 'ansible-test'
    sysctl = dict()

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = lambda x: (0, 'vm.swappiness = 60\nvm.dirty_writeback_centisecs = 5000\nvm.dirty_expire_centisecs = 1500', '')
    sysctl = get_sysctl(module, [])
    assert sysctl['vm.swappiness'] == '60'
    assert sysctl['vm.dirty_writeback_centisecs'] == '5000'
    assert sysctl['vm.dirty_expire_centisecs'] == '1500'


# Generated at 2022-06-23 00:35:06.846120
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    examples = dict()
    examples['kernel_kptr_restrict'] = dict(
        prefixes=['kernel.kptr_restrict'],
        result=dict(kernel_kptr_restrict='0')
    )
    examples['kernel_name'] = dict(
        prefixes=['kernel.name'],
        result=dict(kernel_name='Linux', kernel_name_domainname='(none)', kernel_name_hostname='hostname')
    )
    examples['kernel_printk_devkmsg'] = dict(
        prefixes=['kernel.printk.devkmsg'],
        result=dict(kernel_printk_devkmsg='7')
    )

# Generated at 2022-06-23 00:35:17.419071
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os

    class AnsibleModule(object):
        def __init__(self):
            self.run_command_args = tuple()
            self.run_command_rc = 0
            self.run_command_stdout = ""

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])

        def get_bin_path(self, *args, **kwargs):
            return "/sbin/sysctl"

        def run_command(self, args, check_rc=False):
            self.run_command_args = tuple(args)
            return (self.run_command_rc,
                    self.run_command_stdout,
                    "unittest")

    am = AnsibleModule()

# Generated at 2022-06-23 00:35:28.702298
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/bin/sysctl'

        def run_command(self, cmd):
            test_data = dict(
                kernel_version='3.10.0-327.36.1.el7.x86_64',
                kernel_modules_disabled=1,
                kernel_randomize_va_space=2,
                vm_min_free_kbytes=65536,
            )
            out = '\n'.join([k + ' = ' + str(v) for k, v in test_data.items()])
            return 0, out, ''

    m = FakeModule()
    prefixes = ['kernel', 'vm']

# Generated at 2022-06-23 00:35:35.538667
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeModule()
    sysctl = get_sysctl(module, ['test.test1'])
    assert sysctl == {'test.test1': 'test1 value'}, sysctl
    sysctl = get_sysctl(module, ['test.test2'])
    assert sysctl == {'test.test2': 'test2 value'}, sysctl
    sysctl = get_sysctl(module, ['test.test3'])
    assert sysctl == {'test.test3': 'test3 value\n test3 value continued'}, sysctl


# Generated at 2022-06-23 00:35:44.594283
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert module
    module.get_bin_path = lambda *args: '/bin/sysctl'
    module.run_command = lambda *args: (0, 'a = 1\nb: 2\nc = 3\n\nd = \n  4\ne: 5', '')
    ret = get_sysctl(module, ['a', 'b', 'c'])
    assert ret == dict(a='1', b='2', c='3')

# Generated at 2022-06-23 00:35:55.044779
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, *args, **kwargs):
            return "sysctl"

        def run_command(self, args):
            if args[0] == "sysctl":
                out = "kernel.hostname = localhost.localdomain\n"
                out += "kernel.printk_ratelimit = 5\n"
                out += "\n"
                out += "net.bridge.bridge-nf-call-arptables = 0\n"

# Generated at 2022-06-23 00:35:55.619916
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-23 00:36:08.417298
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test for FreeBSD
    class FakeModule:
        def get_bin_path(self, name):
            return name

        def run_command(self, args):
            return 0, 'hw.acpi.thermal.tz0.temperature: 58\nhw.acpi.thermal.tz0.temperature: 60\nhw.acpi.thermal.tz0.temperature: 60\nhw.acpi.thermal.tz0.temperature: 60\n', ''

        def warn(self, msg):
            pass
    fake_module = FakeModule()
    sysctl = get_sysctl(fake_module, ['hw.acpi.thermal.tz0.temperature'])
    assert sysctl == {'hw.acpi.thermal.tz0.temperature': '60'}

    # Test for Linux


# Generated at 2022-06-23 00:36:18.585695
# Unit test for function get_sysctl
def test_get_sysctl():
    class MockModule(object):
        def __init__(self, sysctl_out):
            self.sysctl_out = sysctl_out

        def get_bin_path(self, name):
            return 'sysctl'

        def run_command(self, cmd):
            return (0, self.sysctl_out, None)

        def warn(self, msg):
            print(msg)

    sysctl_out = '''
net.core.rmem_default = 16777216
net.core.rmem_max = 16777216
net.core.wmem_default = 16777216
net.core.wmem_max = 16777216
'''

# Generated at 2022-06-23 00:36:29.631062
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec=dict())

    # Just set some known values and make sure they are found

# Generated at 2022-06-23 00:36:40.572114
# Unit test for function get_sysctl
def test_get_sysctl():
    module = Mock()
    module.get_bin_path.return_value = 'sysctl'

# Generated at 2022-06-23 00:36:45.698801
# Unit test for function get_sysctl
def test_get_sysctl():
    module = DummyAnsibleModule()
    sysctl = get_sysctl(module, ["kern.boottime", "kern.ostype"])
    assert sysctl.get('kern.boottime').startswith('{ sec = ')
    assert sysctl.get('kern.ostype') == 'Darwin'


# Generated at 2022-06-23 00:36:47.907994
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['-a'])
    assert get_sysctl({}, ['vm.swappiness'])

# Generated at 2022-06-23 00:36:50.029663
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(['kernel.hostname']) == [ 'foo.example.com' ]

# Generated at 2022-06-23 00:36:55.507293
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('DummyModule', (object,), {})()
    module.run_command = lambda x: (0, '''foo = 1
    bar = 2
    baz = 3
    ''', '')
    d = get_sysctl(module, [])
    assert isinstance(d, dict)
    assert d['foo'] == '1'
    assert d['bar'] == '2'
    assert d['baz'] == '3'

# Generated at 2022-06-23 00:37:07.278904
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            prefix=dict(required=True),
        )
    )
    results = get_sysctl(module, module.params['prefix'])
    assert len(results) == 2
    assert 'net.ipv4.ip_local_port_range' in results
    assert 'net.ipv4.ip_forward' in results


# -*- -*- -*- End included fragment: ../../lib_utils/src/lib/utils/sysctl.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: lib/portage/output.py -*- -*- -*-

# pylint: disable=