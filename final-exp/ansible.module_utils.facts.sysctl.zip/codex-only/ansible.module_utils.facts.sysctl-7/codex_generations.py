

# Generated at 2022-06-23 00:27:13.349315
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = get_module(dict())
    test_prefixes = [
        'kern',
    ]
    test_result = get_sysctl(test_module, test_prefixes)
    assert test_result.get('kern.ostype') == 'Darwin'

# Generated at 2022-06-23 00:27:25.023038
# Unit test for function get_sysctl
def test_get_sysctl():
    # unit test availability on 2.6, remove in 2.7
    import __builtin__
    if not hasattr(__builtin__, 'any'):
        __builtin__.any = any

    import mock
    import ansible.module_utils.basic as basic

    sysctl_cmd = '/sbin/sysctl'
    module = basic.AnsibleModule(argument_spec=dict())
    module.run_command = mock.Mock()

    # test simple
    command_rc = 0

# Generated at 2022-06-23 00:27:31.059601
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict()
    )

    prefixes = ['kern.boottime', 'kern.maxvnodes']

    result = get_sysctl(module, prefixes)

    assert result.get('kern.boottime', False)
    assert result.get('kern.maxvnodes', False)

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:27:37.021950
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec=dict(
        prefixes=dict(required=True, type='list'),
    ),)
    sysctl = get_sysctl(module, ['vm.overcommit_memory'])
    assert isinstance(sysctl, dict)
    assert sysctl['vm.overcommit_memory'] == '0'


# Generated at 2022-06-23 00:27:47.329992
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.compat.os import get_distribution
    from ansible.module_utils.compat.os import get_distribution_version

    module = AnsibleModule(argument_spec={},
                           supports_check_mode=True)

    sysctl_open_files = get_sysctl(module, prefixes=['fs.file-max'])
    sysctl_nofile = get_sysctl(module, prefixes=['fs.file-max'])


# Generated at 2022-06-23 00:27:53.315377
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    # test sysctl not found
    with pytest.raises(Exception, match="Unable to read sysctl: .*"):
        get_sysctl(module, ['not-found-sysctl'])

    # test sysctl found
    result = get_sysctl(module, ['kernel.domainname'])
    assert result.get('kernel.domainname') == '(none)'

# Generated at 2022-06-23 00:28:04.736839
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.community.network.tests.unit.compat import unittest
    from ansible_collections.community.network.tests.unit.compat.mock import patch

    class ExecuteTest(unittest.TestCase):

        def setUp(self):
            self.mock_module = patch('ansible_collections.community.network.plugins.modules.network.ios.ios_user.get_sysctl')
            self.get_sysctl = self.mock_module.start()

        def tearDown(self):
            self.mock_module.stop()

        def test_get_sysctl(self):
            m = self.get_sysctl
            prefixes = ['net.ipv4.conf.all.accept_source_route']


# Generated at 2022-06-23 00:28:07.050846
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '0'}

# Generated at 2022-06-23 00:28:14.104093
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl_prefix = [
        'kernel.sem',
        'fs.file-max'
    ]

    if os.path.exists('/proc/sys'):
        writeable_sysctl = get_sysctl(module, sysctl_prefix)
    else:
        writeable_sysctl = {}

    assert 'kernel.sem' in writeable_sysctl
    assert 'fs.file-max' in writeable_sysctl

# Generated at 2022-06-23 00:28:25.738205
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import module_utils.basic
    import json

    sysctl_path = module_utils.basic.get_bin_path('sysctl')
    if not sysctl_path:
        os.environ['PATH'] += ":/sbin"
        sysctl_path = module_utils.basic.get_bin_path('sysctl')

    if not sysctl_path:
        print("No sysctl found")
        return

    prefixes = ['kernel', 'vm.swappiness']
    sysctl = get_sysctl(module_utils.basic.AnsibleModule(dict()), prefixes)

    print(json.dumps(sysctl, indent=4, sort_keys=True))

    assert sysctl['kernel.sem'] == '250  32000 32  128'

# Generated at 2022-06-23 00:28:32.646413
# Unit test for function get_sysctl
def test_get_sysctl():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            'prefixes': dict(),
        }
    )
    (is_fail, result, msg) = get_sysctl(module, ['net.ipv4.tcp_rmem'])
    assert(is_fail == 0)
    assert(result == {'net.ipv4.tcp_rmem': '4096 87380 174760'})


# Generated at 2022-06-23 00:28:43.799191
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.facts.system.sysctl import get_sysctl
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    ansible_cfg = os.path.join(tmpdir, "ansible.cfg")
    cfg_fd = open(ansible_cfg, 'w')
    cfg_fd.write('[defaults]\n')
    cfg_fd.write('roles_path=../\n')
    cfg_fd.close()

    # Create a temporary sysctl command
    sysctl_cmd = os.path.join(tmpdir, "sysctl")
    cmd_fd = open(sysctl_cmd, 'w')

# Generated at 2022-06-23 00:28:55.044335
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = '''
#!/usr/bin/python
import os
import sys

retval = 1
out = ''
err = ''

try:
    out = open(sys.argv[1]).read()
    retval = 0
except Exception as e:
    out = ''
    err = str(e)

print(retval)
print(out)
print(err)
'''

    module_args = dict(
        state='present',
        name='kernel.msgmnb',
        value=2097152,
    )


# Generated at 2022-06-23 00:29:01.932900
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self):
            self.bin_path = "/usr/bin"

# Generated at 2022-06-23 00:29:12.870585
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    prefixes = ['kern.hostname', 'kern.domainname']
    rc, out, err = module.run_command(['env'])
    env = dict()
    for line in out.splitlines():
        if not line.strip():
            continue
        (key, value) = re.split(r'\s?=\s?|: ', line, maxsplit=1)
        env[key] = value.strip()
    sysctl = get_sysctl(module, prefixes)

    assert env['HOSTNAME'] == sysctl['kern.hostname']
    assert env['DOMAINNAME'] == sysctl['kern.domainname']



# Generated at 2022-06-23 00:29:20.199133
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['vm.overcommit_memory']) == {
        'vm.overcommit_memory': '1'
    }
    assert get_sysctl(None, ['kernel.randomize_va_space']) == {
        'kernel.randomize_va_space': '2',
    }
    assert get_sysctl(None, ['kernel.sysrq']) == {
        'kernel.sysrq': '0',
    }

# Generated at 2022-06-23 00:29:25.707235
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    result = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert result['net.ipv4.ip_forward'] == '1'
    result = get_sysctl(module, ['vm.swappiness'])
    assert result['vm.swappiness'] == '60'

# Start of helper code

# Generated at 2022-06-23 00:29:36.051916
# Unit test for function get_sysctl
def test_get_sysctl():
    def test_module(name='sysctl', **kwargs):
        attrs = {}
        for key, value in kwargs.items():
            attrs[key] = value

        attrs['__name__'] = name
        attrs['run_command'] = lambda *args, **kwargs: (0, '', '')
        attrs['get_bin_path'] = lambda *args, **kwargs: '/usr/bin/sysctl'

        class TestModule:
            def __init__(self):
                self.__dict__.update(attrs)

        return TestModule()

    def run_module(*args, **kwargs):
        if len(args) > 0 and isinstance(args[0], dict):
            kwargs = args[0]

# Generated at 2022-06-23 00:29:47.461112
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(
        k=dict(type='str')
    ))

# Generated at 2022-06-23 00:29:58.370121
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(name='get_sysctl')
    m.get_bin_path = lambda x: x

    m.run_command = lambda x: (0, 'kern.maxproc: 65536\nkern.maxthread: 65536', '')
    assert get_sysctl(m, ['kern.maxproc', 'kern.maxthread']) == {'kern.maxproc': '65536', 'kern.maxthread': '65536'}
    m.run_command = lambda x: (1, '', 'Error')
    assert get_sysctl(m, ['kern.maxproc']) == dict()
    m.warn = lambda x: print(x)

# Generated at 2022-06-23 00:30:06.126734
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('FakeModule', (), dict(
        get_bin_path=lambda *args, **kwargs: '/sbin/sysctl',
        run_command=lambda *args, **kwargs: (0, 'a = bogus\nb = test\nc = four words\nd = multiline\n    with more\n    more text\n', ''),
    ))()

    assert get_sysctl(module, []) == {
        'a': 'bogus',
        'b': 'test',
        'c': 'four words',
        'd': 'multiline\nwith more\nmore text',
    }

# Generated at 2022-06-23 00:30:14.664745
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # This is a single value that should always exist, we can test with
    # the "kern" prefix and the "ostype" key
    result = get_sysctl(module, 'kern.ostype'.split(','))
    assert 'kern.ostype' in result

    result = get_sysctl(module, 'security'.split(','))
    assert 'security.mac.portacl_default' in result

# Generated at 2022-06-23 00:30:25.583502
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.system.netstat import get_sysctl

    ansible_config = {
        'module_setup': True,
        'command_warnings': False,
        'bin_dir': '/usr/bin',
        'filesystem_alias': {},
    }
    module = AnsibleModule(ansible_config)

    # line1: 'net.ipv4.tcp_rmem = 4096 87380 67108864',
    # line2: 'net.ipv4.tcp_wmem = 4096 65536 67108864',
    # line3: 'net.ipv4.udp_mem = 8388608 16777216 8388608',
    # line4: 'net.ipv4.

# Generated at 2022-06-23 00:30:29.750057
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({'_run_command': command_mock}, ['foo.bar']) == {'foo.bar': 'baz'}
    try:
        get_sysctl({'_run_command': command_exception_mock}, ['foo.bar'])
        assert False
    except IOError:
        assert True


# Generated at 2022-06-23 00:30:32.161661
# Unit test for function get_sysctl
def test_get_sysctl():

    # Can't unit test without writing a fake sysctl process
    # but this should pass the test suite as a no-op
    pass

# Generated at 2022-06-23 00:30:44.108764
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    module = AnsibleModule(
        check_invalid_arguments=False,
    )

    module.run_command = basic._run_command
    module.debug = lambda x: None

    with open('/proc/sys/kernel/hostname') as file:
        hostname = file.read().strip()


# Generated at 2022-06-23 00:30:52.603244
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    function get_sysctl unit tests
    """

    MockCommand = collections.namedtuple('MockCommand', ['run_command', 'get_bin_path'])

    def mock_run_command(module, cmd, check_rc=False, data=None):
        cmd_str = ' '.join(cmd)
        if cmd_str == "sysctl kernel.printk":
            return (0, "kernel.printk = 0 4 1 7", '')

# Generated at 2022-06-23 00:31:03.019157
# Unit test for function get_sysctl
def test_get_sysctl():
    src_file = os.path.basename(inspect.getsourcefile(get_sysctl))


# Generated at 2022-06-23 00:31:14.790175
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os
    sys.path = [os.path.join(os.path.dirname(__file__), '..', '..', '..', 'hacking')] + sys.path
    from test.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    class AnsibleModuleMock(object):
        class ReturnValue(object):
            def __init__(self, rc=None, out=None, err=None):
                self.rc = rc
                self.out = out
                self.err = err

        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, path, *args, **kwargs):
            return path


# Generated at 2022-06-23 00:31:20.869792
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefix=dict(type='list', required=True),
        )
    )

    module.exit_json(**get_sysctl(module, module.params['prefix']))


if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:31:31.547428
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    def run_command(cmd):
        return(0, "net.ipv4.ip_local_port_range = 9000 65500\nnet.ipv4.ip_forward = 1\nnet.ipv4.ip_forward_use_pmtu = 0", "")

    module.run_command = run_command

    result = get_sysctl(module, ['net*'])
    assert result == {'net.ipv4.ip_local_port_range': '9000 65500', 'net.ipv4.ip_forward': '1', 'net.ipv4.ip_forward_use_pmtu': '0'}

# Generated at 2022-06-23 00:31:35.080401
# Unit test for function get_sysctl
def test_get_sysctl():
    module = DummyTestModule()
    sysctl_vars = get_sysctl(module, [])
    assert('kernel.hostname' in sysctl_vars)
    assert('kernel.hostname' in sysctl_vars)


# Generated at 2022-06-23 00:31:38.303536
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '0'}

# Generated at 2022-06-23 00:31:50.595459
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = AnsibleModule(
        argument_spec=dict()
    )
    test_module.run_command = MagicMock(return_value=(0, 'kern.maxvnodes: 262144\nkern.maxproc: 1064\nkern.maxfiles: 8192\nkern.maxfilesperproc: 5120\n', ''))

    sysctl = get_sysctl(test_module, ['kern.maxvnodes', 'kern.maxproc', 'kern.maxfiles', 'kern.maxfilesperproc'])

    assert sysctl == {'kern.maxvnodes': '262144',
                      'kern.maxproc': '1064',
                      'kern.maxfiles': '8192',
                      'kern.maxfilesperproc': '5120'}

# Generated at 2022-06-23 00:32:00.398529
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.basic import AnsibleModule

    sysctl_cmd = '/sbin/sysctl'

    def run_command(self, cmd, check_rc=True):
        # Check that cmd is 'sysctl' and the last param is '-a'
        if 'sysctl' == cmd[0] and cmd[-1] == '-a':
            out = ''
            for i in range(1, len(cmd) - 1):
                out += '%s = 0\n' % cmd[i]
            return 0, out, ''
        else:
            return 1, '', 'failed'

   

# Generated at 2022-06-23 00:32:04.163904
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    if not get_sysctl(module, ('kern.hostname',)):
        module.fail_json(msg='Failed to get kern.hostname')


# Generated at 2022-06-23 00:32:14.938417
# Unit test for function get_sysctl
def test_get_sysctl():

    sysctl = dict()
    sysctl['net.ipv4.icmp_echo_ignore_broadcasts'] = '1'
    sysctl['net.ipv4.tcp_max_syn_backlog'] = '1280'
    sysctl['net.ipv4.conf.all.accept_source_route'] = '0'
    sysctl['net.ipv4.conf.default.accept_redirects'] = '0'
    sysctl['net.ipv4.conf.eth0.send_redirects'] = '0'
    sysctl['net.ipv4.conf.default.rp_filter'] = '0'
    sysctl['net.ipv4.conf.eth0.arp_ignore'] = '0'

# Generated at 2022-06-23 00:32:26.743170
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Function get_sysctl unit test.
    '''

    # Run this on Python 2.6 through 2.7 and 3.6
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch, MagicMock
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    sys_mocked = MagicMock(return_value=0)


# Generated at 2022-06-23 00:32:38.201412
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
    )

    module.run_command = run_command
    result = get_sysctl(module, ['vm.max_map_count'])
    assert result == {'vm.max_map_count': '1048576'}

    import sys
    if sys.byteorder == 'little':
        result = get_sysctl(module, ['kernel.modules_disabled'])
        assert result == {'kernel.modules_disabled': '0'}

# Generated at 2022-06-23 00:32:50.421229
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Build the mock module and basic input data
    testmod = AnsibleModule(argument_spec=dict(
        prefixes=dict(required=True, type='list'),
    ))
    testmod.get_bin_path = lambda x: x
    testmod.run_command = lambda x: (0, 'net.ipv4.ip_forward: 1\nnet.ipv4.tcp_syncookies: 1\nnet.ipv4.tcp_tw_reuse: 1')

    # Test a simple get
    result = get_sysctl(testmod, ['net.ipv4.ip_forward'])
    assert result['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-23 00:32:59.582085
# Unit test for function get_sysctl
def test_get_sysctl():
    import json
    import os
    import time

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO

    # Set up the module
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=[]),
            test_option=dict(type='str', required=True),
        ),
        supports_check_mode=False,
    )

    # Get sysctl output
    sysctl = get_sysctl(module, module.params['prefixes'])


# Generated at 2022-06-23 00:33:10.397159
# Unit test for function get_sysctl
def test_get_sysctl():
    class Module:
        def __init__(self):
            self.run_command_count = 0
        def get_bin_path(self, name):
            return name
        def warn(self, msg):
            print(msg)
        def run_command(self, cmd):
            if self.run_command_count == 0:
                self.run_command_count += 1
                return 0, 'net:2\nfoo.bar:1\nbar.bar: 2\nhello.world:3\n', ''
            elif self.run_command_count == 1:
                self.run_command_count += 1
                return 0, 'net.ipv4.tcp:1\nfoo.bar.baz:2\nbar.bar= 3\nhello.world=4\n', ''
            return 1,

# Generated at 2022-06-23 00:33:11.998484
# Unit test for function get_sysctl
def test_get_sysctl():
    # FIXME: Make a unit test for this.
    pass

# Generated at 2022-06-23 00:33:19.617379
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    sysctl = get_sysctl(module, ['-a'])

    assert 'kernel.hostname' in sysctl
    assert sysctl['kernel.hostname'] == sysctl['kernel.ostype'] + '-' + sysctl['kernel.osrelease'] + '-' + sysctl['kernel.os']

    assert 'vm.swappiness' in sysctl
    assert int(sysctl['vm.swappiness']) == 60


# Generated at 2022-06-23 00:33:24.584427
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

    # TODO: find a way to set up the sysctl call such that it returns valid data
    #       for testing purposes
    for prefix in [('-a'), ('vm', 'swappiness')]:
        result = get_sysctl(module, prefix)
        assert result is not None

# Generated at 2022-06-23 00:33:27.746656
# Unit test for function get_sysctl
def test_get_sysctl():

    import sysctl
    assert isinstance(sysctl.get_sysctl(sysctl, ['vm']), dict)


# Generated at 2022-06-23 00:33:33.932709
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    module.run_command = lambda x: (0, "a = b\nc: d", "")
    sysctl = get_sysctl(module, ['a.b.c'])
    assert sysctl == {'a': 'b', 'c': 'd'}

# vim: ai et ts=4 sts=4 sw=4 ft=python

# Generated at 2022-06-23 00:33:44.430836
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception


# Generated at 2022-06-23 00:33:54.970186
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    module.run_command = lambda args: (0, 'foo.bar = foo bar\nfoo.baz = baz bar', None)
    assert get_sysctl(module, ['foo.*']) == {'foo.bar': 'foo bar', 'foo.baz': 'baz bar'}
    module.run_command = lambda args: (0, 'foo.bar = foo bar\nfoo.baz:baz bar', None)
    assert get_sysctl(module, ['foo.*']) == {'foo.bar': 'foo bar', 'foo.baz': 'baz bar'}

# Generated at 2022-06-23 00:34:04.351026
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

    from AnsibleModuleUtils import get_sysctl

    module = AnsibleModule({})


# Generated at 2022-06-23 00:34:10.462517
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl
    module = sysctl
    module.run_command = run_command_test
    module.get_bin_path = get_bin_path_test
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    if sysctl != {'net.ipv4.ip_forward': '0'}:
        sys.exit(1)

# Unit test helper

# Generated at 2022-06-23 00:34:21.368488
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    def test_module(prefixes):
        module = AnsibleModule(argument_spec={})
        module.params = {'prefix': prefixes}
        module.warn = basic._ANSIBLE_ARGS['warnings']

        sysctl = get_sysctl(module, prefixes)

        return sysctl

    prefixes = ['kern.boottime']
    sysctl = test_module(prefixes)

    assert sysctl['kern.boottime'].startswith('{ sec = ')

    prefixes = ['net.inet.tcp.blackhole']
    sysctl = test_module(prefixes)

    assert sysctl['net.inet.tcp.blackhole'] == '2'


# Generated at 2022-06-23 00:34:31.667226
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        ),
    )

    # set up a set of fake sysctl output to test the function

# Generated at 2022-06-23 00:34:36.714193
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.sysctl import get_sysctl

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        )
    )

    sysctl = get_sysctl(module, ["kern"], "sysctl")

    assert sysctl['kern.hostname'] == 'localhost'

# Generated at 2022-06-23 00:34:43.662742
# Unit test for function get_sysctl
def test_get_sysctl():
    module = Mock(
        fail_json=Mock(side_effect=Exception),
        run_command=Mock(return_value=('', '', '')),
        get_bin_path=Mock(return_value='sysctl'),
        warn=Mock(),
        params=Mock()
    )

    sysctl = get_sysctl(module, ['kern.hostname'])
    assert isinstance(sysctl, dict)
    assert 'kern.hostname' in sysctl

# Generated at 2022-06-23 00:34:48.327816
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['kernel.hostname', 'kernel.msgmax']
    sysctl = get_sysctl('test', prefixes)
    assert sysctl['kernel.hostname'] == 'test.test.test'
    assert sysctl['kernel.msgmax'] == '65536'

# Generated at 2022-06-23 00:34:58.751894
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule({})

    m.get_bin_path = lambda x: 'sysctl'

# Generated at 2022-06-23 00:35:08.718176
# Unit test for function get_sysctl
def test_get_sysctl():
    module_mock = MagicMock()
    prefixes = ['net.ipv4.tcp_available_congestion_control', 'net.ipv4.tcp*']


# Generated at 2022-06-23 00:35:15.290655
# Unit test for function get_sysctl
def test_get_sysctl():
    # Set up a mock module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.module_utils.common.sys_info import get_sysctl

    sysctl_cmd = 'sysctl -n'
    cmd = sysctl_cmd + ' kern.boottime'
    mock_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    mock_module.run_command = lambda cmd: (0, 'kern.boottime = { sec = 1474746849, usec = 843993 }')
    sysctl = get_sysctl(mock_module, cmd)

    assert sysctl['kern.boottime'] == '{ sec = 1474746849, usec = 843993 }'




# Generated at 2022-06-23 00:35:21.369634
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import ansible.module_utils.system.linux
    module = ansible.module_utils.system.linux.LinuxSysctl()
    module.run_command = basic.AnsibleModule.run_command
    module.get_bin_path = basic.AnsibleModule.get_bin_path
    sysctl = get_sysctl(module, ["vm.dirty_background_ratio"])
    assert sysctl["vm.dirty_background_ratio"] == "10"

# Generated at 2022-06-23 00:35:31.845451
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(supports_check_mode=False)

    # test on OS X with a range of values
    sysctl = get_sysctl(module, ['-d', '-a'])
    assert sysctl['kern.maxprocperuid'] == '2559'
    assert sysctl['machdep.cpu.brand_string'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert sysctl['hw.cachelinesize'] == '64'
    assert sysctl['hw.physmem'] == '17179869184'
    assert sysctl['net.inet.ip.portrange.reservedlow'] == '0'

    # test on Linux with a range of values
    sysctl = get_

# Generated at 2022-06-23 00:35:36.698563
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    results = get_sysctl(module, ['net.ipv4.tcp_syncookies', 'net.ipv4.conf.all.rp_filter'])
    assert results['net.ipv4.tcp_syncookies'] == '1'
    assert results['net.ipv4.conf.all.rp_filter'] == '1'
    assert results['net.ipv4.tcp_mem'] == '''15872  15872  15872'''


# Generated at 2022-06-23 00:35:46.899463
# Unit test for function get_sysctl
def test_get_sysctl():
    import json
    import os
    import tempfile

    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils.pycompat24 import get_exception

    module = basic.AnsibleModule(argument_spec={})
    module.sysctl = lambda *args, **kwargs: None
    module.get_bin_path = lambda *args, **kwargs: 'sysctl'

    (rc, out, err) = common.run_command(['sysctl', '-a'])
    if rc != 0:
        module.fail_json(msg=err)

    fd, path = tempfile.mkstemp()
    os.close(fd)

    f = open(path, 'w')
    f.write(out)
    f.close

   

# Generated at 2022-06-23 00:35:56.881322
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    # typical output of sysctl -a on my machine
    # test parsing several kernel.hostname type prefixes.

# Generated at 2022-06-23 00:36:06.005374
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': {'type': 'list',
                                                       'required': True},
                                          'changed': {'type': 'bool',
                                                      'required': False}})
    sysctl = get_sysctl(module, module.params['prefixes'])
    module.exit_json(ansible_facts=dict(sysctl=sysctl,
                                        ansible_sysctl=sysctl))


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:36:16.548065
# Unit test for function get_sysctl
def test_get_sysctl():
    module = Mock()

    # Default get_sysctl(), function should return an empty dict
    assert get_sysctl(module, []) == {}

    # Passing in paramters, function should return key,value pair dict
    # for keys in params
    module.run_command.return_value = (0, """kern.hz = 100
security.bsd.stack_guard_page = 1""", '')
    assert get_sysctl(module, ['kern.hz']) == {'kern.hz': '100'}

    # Passing in paramters that does not have value, funciton should return
    # key,value pair dict for keys in params and value should be an empty string
    module.run_command.return_value = (0, """kern.hz = 100
security.bsd.stack_guard_page""", '')


# Generated at 2022-06-23 00:36:28.142462
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={
        'prefixes': dict(type='list', required=True, elements='str'),
    })

    sysctl = get_sysctl(module, module.params['prefixes'])
    assert sysctl is not None
    assert isinstance(sysctl, dict)

    for k in sysctl:
        assert isinstance(k, str)
        assert isinstance(sysctl[k], str)

    # Test multiline output
    module = AnsibleModule(argument_spec={
        'prefixes': dict(type='list', required=True, elements='str'),
    })

    sysctl = get_sysctl(module, module.params['prefixes'])
    assert sysctl is not None
    assert isinstance(sysctl, dict)

    for k in sysctl:
        assert isinstance

# Generated at 2022-06-23 00:36:37.225794
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = AnsibleModule(argument_spec={'prefixes': dict(type='list', elements='str'),
                                               'fail_key': dict(type='bool')})
    sysctl = get_sysctl(test_module, ['net.ipv4.ip_forward', 'net.ipv4.conf.default.accept_source_route'])
    assert len(sysctl) == 2
    assert sysctl.get('net.ipv4.ip_forward') == '0'
    assert sysctl.get('net.ipv4.conf.default.accept_source_route') == '0'
    assert sysctl.get('foobar') is None



# Generated at 2022-06-23 00:36:42.595685
# Unit test for function get_sysctl
def test_get_sysctl():
    # get the module object
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'net.ipv4.netfilter.ip_conntrack_max=9000\nnet.ipv4.netfilter.ip_conntrack_tcp_timeout_established=7300', ''))
    module.warn = MagicMock(return_value=None)

    sysctl = get_sysctl(module, ['net.ipv4.netfilter'])
    assert 'netfilter' in sysctl
    assert sysctl['netfilter'] == 'ip_conntrack_max=9000\nip_conntrack_tcp_timeout_established=7300'

# Generated at 2022-06-23 00:36:51.957465
# Unit test for function get_sysctl
def test_get_sysctl():
    module = Mock()
    module.warn = lambda x: None
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, 'kern.maxfiles = 200000\nkern.maxfilesperproc = 200000\nkern.maxvnodes = 200000', '')
    sysctl = get_sysctl(module, ['kern'])
    assert sysctl == {'kern.maxfiles': '200000', 'kern.maxfilesperproc': '200000', 'kern.maxvnodes': '200000'}
    module.run_command = lambda x: (1, '', '')
    sysctl = get_sysctl(module, ['kern'])
    assert sysctl == {}


# Generated at 2022-06-23 00:37:01.800902
# Unit test for function get_sysctl
def test_get_sysctl():
    data = dict(
        dict(key='kernel.panic', value='0'),
        dict(key='kernel.shmmax', value='67108864'),
        dict(key='vm.swappiness', value='60')
    )
    # what to return given a prefix

# Generated at 2022-06-23 00:37:07.627844
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import json

    v1 = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_sysctl = get_sysctl(v1, ['kernel.rando'])

    assert isinstance(test_sysctl, dict), 'Sysctl expected to return a dict, but returned %s' % type(test_sysctl)
    assert test_sysctl['kernel.random.entropy_avail'] == '3770', 'Incorrect value for kernel.random.entropy_avail, expected 3770 but got %s' % test_sysctl['kernel.random.entropy_avail']

# Generated at 2022-06-23 00:37:12.360198
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = AnsibleModule(argument_spec = dict())
    test_sysctl = get_sysctl(test_module, [ 'kernel' ])
    assert isinstance(test_sysctl, dict)
    assert 'kernel.hostname' in test_sysctl.keys()