

# Generated at 2022-06-23 00:27:12.227737
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import os

    os.environ['SYSCTL_SHOW_ALL_LEVELS'] = '1'
    sysctl = get_sysctl(basic.AnsibleModule(argument_spec=dict()), ['vm'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-23 00:27:14.826447
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, None) == {}
    assert get_sysctl(None, []) == {}
    assert get_sysctl(None, ["vm.foo"]) == {}

# Generated at 2022-06-23 00:27:19.997059
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict()
    )

    sysctl = get_sysctl(module, [])

    module.exit_json(changed=False, sysctl=sysctl)

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:27:21.316023
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, []) == {}



# Generated at 2022-06-23 00:27:32.042163
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Simple unit test for the get_sysctl function.
    '''

    import sys
    import sysctl
    import os

    # Import the module we want to test
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

    # Import module we want to test
    from ansible.module_utils.facts.system.sysctl import get_sysctl

    prefix = os.path.join(os.path.dirname(sysctl.__file__), 'tests/fixtures/sysctl')
    sysctl_cmd = ['%s/sysctl_%s' % (prefix, n) for n in ['pg.4', 'path.conf']]


# Generated at 2022-06-23 00:27:43.146537
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:27:44.734183
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    assert type(get_sysctl(module, ['kernel.hostname'])) == dict



# Generated at 2022-06-23 00:27:54.891798
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    assert get_sysctl(module, []) == {}

    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))

    assert get_sysctl(module, []) == {}

    module = MockModule()
    module.run_command = Mock(return_value=(1, '', ''))
    assert get_sysctl(module, []) == {}

    module = MockModule()
    module.run_command = Mock(return_value=(0, '--- test.foo.bar: 42\ntest.foo.baz: true\n', ''))
    assert get_sysctl(module, []) == {'test.foo.bar': '42', 'test.foo.baz': 'true'}

    module = MockModule()
    module.run_command

# Generated at 2022-06-23 00:28:06.430176
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 00:28:11.757975
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=False),
        )
    )
    prefixes = 'vm.max_map_count'
    sysctl = get_sysctl(module, prefixes)
    assert sysctl == {'vm.max_map_count': '262144'}


# Generated at 2022-06-23 00:28:22.021282
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    # Unit test for function get_sysctl with standard settings
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl == {'kernel.hostname': 'localhost.localdomain'}

    # Unit test for function get_sysctl without settings
    sysctl = get_sysctl(module, [])
    assert sysctl == {}

    # Unit test for function get_sysctl with invalid settings
    sysctl = get_sysctl(module, ['invalid.key'])
    assert sysctl == {'invalid.key': ''}

# Generated at 2022-06-23 00:28:33.455343
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys


# Generated at 2022-06-23 00:28:44.187691
# Unit test for function get_sysctl
def test_get_sysctl():
    module = DummyAnsibleModule({'shell': '/bin/bash'})
    prefixes = ['kern.maxproc', 'vm.kmem_size']

    sysctl_cmd = module.get_bin_path('sysctl')
    cmd = [sysctl_cmd]
    cmd.extend(prefixes)
    output = '''kern.maxproc: 800
vm.kmem_size: 1032704000
'''
    expected = {'kern.maxproc': '800', 'vm.kmem_size': '1032704000'}

    (rc, out, err) = module.run_command(cmd)

    if rc == 0:
        key = ''
        value = ''
        for line in out.splitlines():
            if not line.strip():
                continue


# Generated at 2022-06-23 00:28:55.332438
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(argument_spec={
        'prefixes': {
            'type': 'list',
            'required': True
        }
    })

# Generated at 2022-06-23 00:28:58.200023
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['net.ipv4.tcp_wmem']
    result = get_sysctl(prefixes)
    assert type(result) is dict
    assert 'net.ipv4.tcp_wmem' in result
    assert '32768,87380,524288' in result['net.ipv4.tcp_wmem']

# Generated at 2022-06-23 00:29:05.148481
# Unit test for function get_sysctl
def test_get_sysctl():
    """ Test function get_sysctl """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    prefixes = ("net.ipv4.ip_forward", "kernel.randomize_va_space")
    results = get_sysctl(module, prefixes)
    assert(results["net.ipv4.ip_forward"] == "1")

# Generated at 2022-06-23 00:29:15.620044
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:29:19.777722
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

    # Create a mocked sysctl binary, which in turn will return our mocked stdout

# Generated at 2022-06-23 00:29:24.799516
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, [])
    assert sysctl["kernel.panic_on_io_nmi"] == "1"
    assert sysctl["kernel.sysrq"] == "0"
    assert sysctl["net.ipv4.tcp_syncookies"] == "1"

# Generated at 2022-06-23 00:29:30.587469
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({
        'sysctl': 'vm.max_map_count'
    })

    result = get_sysctl(module, module.params['sysctl'])
    assert isinstance(result, dict)
    assert 'vm.max_map_count' in result

# Function to check if a filesystem has the "nodev" option set

# Generated at 2022-06-23 00:29:39.466071
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:29:43.392500
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    result = get_sysctl(module, "net.ipv4.ip_forward")

    assert result["net.ipv4.ip_forward"] is not None


# Generated at 2022-06-23 00:29:46.623821
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeModule()
    sysctl = get_sysctl(module=module, prefixes=['net.'])
    assert sysctl['net.ipv4.ip_forward'] == '1'



# Generated at 2022-06-23 00:29:55.788476
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()

    module.warn = lambda x: sys.stderr.write("WARN: %s\n" % x)
    module.run_command = lambda x: (0, "", "")
    module.get_bin_path = lambda x: "sysctl"

    # single key
    assert get_sysctl(module, ["net.ipv4.tcp_wmem"]) == {"net.ipv4.tcp_wmem": "4096    87380   33554432"}

    # multiple keys

# Generated at 2022-06-23 00:29:59.813354
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=['net.*', 'kernel.*'])
        ),
    )

    sysctl = get_sysctl(module, module.params['prefixes'])

    sys.stdout.write(module.jsonify(sysctl))

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:30:09.935709
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule()
    prefixes = ['kernel.hostname']
    sysctl_cmd = get_bin_path('sysctl')
    cmd = [sysctl_cmd]
    cmd.extend(prefixes)

    sysctl = {}

    try:
        rc, out, err = module.run_command(cmd)
    except (IOError, OSError) as e:
        module.warn('Unable to read sysctl: %s' % to_text(e))
        rc = 1

    if rc == 0:
        key = ''
        value = ''
        for line in out.splitlines():
            if not line.strip():
                continue


# Generated at 2022-06-23 00:30:17.053904
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from .modules.system.sysctl import NetBSD

    module = AnsibleModule(argument_spec=NetBSD.argument_spec)

    sysctl = get_sysctl(module, [])
    assert sysctl

    for key in sysctl:
        assert not key.startswith('__')

    assert 'net.inet.ip.forwarding' in sysctl
    assert sysctl['net.inet.ip.forwarding'] == '0'

# Generated at 2022-06-23 00:30:27.939299
# Unit test for function get_sysctl
def test_get_sysctl():

    module = object()

    # Test for supported platforms where sysctl is not /bin/sysctl
    class MockObj(object):
        def __init__(self, binpath):
            self.__binpath = binpath
            self.__cmd_res = dict()

        def get_bin_path(self, name, opt_dirs=[]):
            return self.__binpath

        def run_command(self, cmd):
            return self.__cmd_res[cmd[0]]

        def add_cmd_res(self, cmd, res):
            self.__cmd_res[cmd] = res

    mock = MockObj('/usr/bin/sysctl')

# Generated at 2022-06-23 00:30:34.235755
# Unit test for function get_sysctl
def test_get_sysctl():
    import argparse
    import json
    p = argparse.ArgumentParser(description="Test get_sysctl")
    p.add_argument("--cmd", required=True)
    p.add_argument("--params", nargs='+')
    p.add_argument("--expected", required=True)
    args = p.parse_args()

    if args.cmd == "sysctl":
        from ansible.module_utils.basic import AnsibleModule
        mod = AnsibleModule(
            argument_spec={},
            supports_check_mode=True,
        )
        print(json.dumps(get_sysctl(mod, args.params), indent=4))
    elif args.cmd == "json":
        print(json.dumps(json.loads(args.expected), indent=4))

# Generated at 2022-06-23 00:30:45.212964
# Unit test for function get_sysctl
def test_get_sysctl():

    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_err = ''
            self.run_command_out = '''
                fs.file-max = 100000
                net.ipv4.ip_forward = 0
                net.ipv4.route.flush = 1
                '''

        def get_bin_path(self, app, required=False):
            return app

        def run_command(self, command):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    sysctl = get_sysctl(FakeModule(), prefixes=[])

# Generated at 2022-06-23 00:30:48.611296
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=yaml.load(DOCUMENTATION))
    result = get_sysctl(module, prefixes=['vm', 'swappiness'])
    assert result['vm.swappiness'] == '1'

# Generated at 2022-06-23 00:30:55.042672
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctls = get_sysctl(module, ['kern.ipc.shmmax'])
    assert sysctls['kern.ipc.shmmax'] == '134217728'

# Generated at 2022-06-23 00:31:05.681515
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test with a single key and ensure the correct value is extracted
    module = type('', (), {})
    prefixes = ['kernel.test']
    # The spec dict exists to emulate sysctl output from a device
    spec = {'kernel.test': '1'}
    module.run_command = lambda cmd: (0, spec['kernel.test'])

    assert get_sysctl(module, prefixes) == spec

    # Test with multiple keys and ensure the correct values are extracted
    module = type('', (), {})
    prefixes = ['kernel.test', 'kernel.test2']
    # The spec dict exists to emulate sysctl output from a device
    spec = {'kernel.test': '1\n2', 'kernel.test2': '2'}

# Generated at 2022-06-23 00:31:17.170250
# Unit test for function get_sysctl
def test_get_sysctl():
    module = open('test/unit/modules/test_sysctl.py', 'r').read()
    # Test dictionary of sysctls.
    # In this line, function get_sysctl is called and a sysctl prefix is provided and a dictionary is returned
    # containing key value pairs for all sysctl keys matching the prefix.
    test_list = dict()
    test_list['kernel.domainname'] = 'somewhere.com'
    test_list['kernel.hostname'] = 'foobar'
    test_list['kernel.msgmnb'] = '65536'
    test_list['kernel.msgmax'] = '65536'
    test_list['kernel.msgmnb'] = '65536'
    test_list['kernel.msgmnb'] = '65536'

# Generated at 2022-06-23 00:31:19.878764
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl
    sysctl.get_sysctl = get_sysctl
    rc, out, err = sysctl.main()

    assert rc == 0
    assert 'kernel.hostname' in out['changed']

# Generated at 2022-06-23 00:31:31.019802
# Unit test for function get_sysctl
def test_get_sysctl():
    """
        Verify sysctl output is parsed correctly
    """

    # Create a mock module for testing
    test_module = AnsibleModule(
        argument_spec=dict()
    )

    # Create a mock for the run_command function.
    test_module.run_command = MagicMock(return_value=(0, """net.ipv4.conf.all.accept_source_route = 0
net.ipv6.conf.all.disable_ipv6 = 1
""", ""))

    # Get sysctl values
    sysctl = get_sysctl(test_module, ['net.ipv4.conf.all.accept_source_route', 'net.ipv6.conf.all.disable_ipv6'])

    # Verify results

# Generated at 2022-06-23 00:31:34.596861
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.params = {'prefixes': ['kern', 'vm']}
    test_value = get_sysctl(module, module.params['prefixes'])

    assert 'kern.ostype' in test_value
    assert 'vm.swapusage' in test_value
    assert test_value['kern.ostype'] == 'FreeBSD'


# Generated at 2022-06-23 00:31:38.860381
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    result = get_sysctl(module, ['kernel.domainname'])
    assert result == {'kernel.domainname': 'localdomain'}

# Generated at 2022-06-23 00:31:51.174585
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import os

    myenv = os.environ.copy()
    myenv['LANG'] = 'C'
    myenv['LC_ALL'] = 'C'
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Test invalid prefix
    res = get_sysctl(module, ['nonexistent_prefix'])
    assert res == dict()

    # Test a valid prefix
    res = get_sysctl(module, ['kernel'])
    assert res != dict()

    # Test two valid prefixes
    res = get_sysctl(module, ['kernel', 'vm'])
    assert res != dict()

    # Test a valid and invalid prefix

# Generated at 2022-06-23 00:31:56.322886
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (object,), dict(run_command=lambda self, x: (0, 'vm.swappiness=100\nvm.overcommit_memory=0\n', '')))()
    sysctl = get_sysctl(module, ['vm'])

    assert sysctl['vm.swappiness'] == '100'
    assert sysctl['vm.overcommit_memory'] == '0'

# Generated at 2022-06-23 00:32:02.406368
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    sysctls = get_sysctl(module, ['net.ipv4.conf.all.forwarding'])
    assert len(sysctls) == 1

    sysctls = get_sysctl(module, ['net.ipv4.conf.all.forwarding', 'net.ipv4.conf.all.proxy_arp'])
    assert len(sysctls) == 2

# Generated at 2022-06-23 00:32:13.445973
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    import unittest
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    data = '''
test.test1 = test1
test.test2: test2
test.test3: test3a
  test3b
test.test4: test4a
  test4b
  test4c
'''

    sysctl_file = tempfile.NamedTemporaryFile(mode='wt', delete=False)
    sysctl_file.write(data)
    sysctl_file.close()

    sysctl_file_name = os.path.basename(sysctl_file.name)
    sysctl_file_dir = os.path.dirname(os.path.realpath(sysctl_file.name))


# Generated at 2022-06-23 00:32:25.150227
# Unit test for function get_sysctl
def test_get_sysctl():

    # Testing default get_sysctl function
    assert get_sysctl(None, []) == {}

    # Testing get_sysctl with one key
    assert get_sysctl(None, ['hw']) == {'hw': '\nhw.model:\n  MacBookAir4,2\nhw.machine:\n  i386\nhw.ncpu:\n  2\nhw.byteorder:\n  1234\nhw.physicalcpu: 2\nhw.physicalcpu_max: 2\nhw.logicalcpu: 2\nhw.logicalcpu_max: 2\nhw.cachesize:\n  262144\n  262144\n  262144'}

    # Testing get_sysctl with multiple keys

# Generated at 2022-06-23 00:32:36.825615
# Unit test for function get_sysctl
def test_get_sysctl():
    MOCK_STDOUT = """
net.ipv4.ip_forward = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv6.conf.all.accept_ra = 2
net.ipv6.conf.default.accept_ra = 2
net.ipv6.conf.all.accept_dad = 1
net.ipv6.conf.default.accept_dad = 1
"""
    sysctl = dict()

# Generated at 2022-06-23 00:32:49.259585
# Unit test for function get_sysctl
def test_get_sysctl():
    args = dict(
        sysctl_cmd='/sbin/sysctl',
        prefixes='-a',
    )
    res = get_sysctl(args)
    assert 'kernel.ostype' in res
    assert 'kernel.osrelease' in res
    assert 'vm.swappiness' in res
    assert 'net.ipv4.ip_forward' in res
    assert 'net.ipv4.conf.default.rp_filter' in res
    assert 'net.ipv4.conf.all.rp_filter' in res
    assert 'net.ipv4.conf.all.log_martians' in res
    assert 'kernel.sysrq' in res
    assert 'kernel.core_uses_pid' in res
    assert 'kernel.msgmnb' in res

# Generated at 2022-06-23 00:32:52.465968
# Unit test for function get_sysctl
def test_get_sysctl():
    module = get_sysctl('module', 'prefix')
    assert module.name == 'sysctl'
    print(module)

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:33:00.755611
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict()
    )

    # Find out where sysctl is on this system
    sysctl_cmd = module.get_bin_path('sysctl')

    # Test if this system even has sysctl
    if sysctl_cmd is None:
        assert(get_sysctl(module, []) == {})
    else:
        # If sysctl is there, running it with no parameters should return
        # all the sysctls, of which there should be at least one.
        result = get_sysctl(module, [])
        assert(len(result) > 0)
        assert(result['kernel.pid_max'] is not None)

    # Running it with a prefix should return a list that only contains
    # sysctl with that prefix.

# Generated at 2022-06-23 00:33:10.870460
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import ansible.module_utils.basic

    class FakeModule(object):
        def __init__(self, params=None):
            self.params = params
            self.run_command = ansible.module_utils.basic.AnsibleModule.run_command

        def get_bin_path(self, executable):
            return executable

    fake_module = FakeModule()
    result = get_sysctl(fake_module, ['foo.kern'])
    assert '/' in result['foo.kern.ostype']
    assert 'FreeBSD' in result['foo.kern.ostype']
    assert '/' in result['foo.kern.paths']
    assert 'bin' in result['foo.kern.paths']

# Generated at 2022-06-23 00:33:15.968569
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (object,), {'warn': print, 'run_command': run_command})
    prefixes = ['net.core.wmem_max']
    sysctl = get_sysctl(module, prefixes)
    assert sysctl['net.core.wmem_max'] == '212992'


# Generated at 2022-06-23 00:33:27.883565
# Unit test for function get_sysctl
def test_get_sysctl():
    rc = 0
    if rc != 0:
        out = sysctl_cmd[0]

# Generated at 2022-06-23 00:33:38.552894
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    def run_command_mock(self, args, check_rc=True):
        return (0, "ipv4.ip_forward = 0\nnet.ipv4.conf.all.rp_filter = 1\nnfs.nfs_use_reserved_ports = 0\n", '')

    original_run_command = AnsibleModule.run_command

    module = AnsibleModule(
        argument_spec={
            'prefixes': {'type': 'list', 'default': []},
        },
        supports_check_mode=False
    )
    module.run_command = run_command_mock

    result = get_sysctl(module, [])

# Generated at 2022-06-23 00:33:43.735607
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    sysctl = get_sysctl(module, ['kernel'])
    assert 'kernel.ostype' in sysctl

# Running test case for get_sysctl
if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:33:54.377890
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('', ['kern']) == {'kern.version': 'OpenBSD 6.2-current (RAMDISK) #0: Mon Dec 26 16:12:19 MST 2016     deraadt@amd64.openbsd.org:/usr/src/sys/arch/amd64/compile/RAMDISK'}

# Generated at 2022-06-23 00:34:00.304222
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (object,), {})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda x, sucess=True: 'sysctl'
    assert get_sysctl(module, ['fs.file-max']) == {u'fs.file-max': u'2000000'}

# Generated at 2022-06-23 00:34:05.912786
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'prefix': 'net.ipv4.ip_forward'})

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-23 00:34:16.417954
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Called from test/units/modules/utils.py
    """
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import create_autospec, MagicMock

    module = MagicMock()

# Generated at 2022-06-23 00:34:27.952945
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import sys

    my_sysctl = sys.modules[basic.__name__]
    my_sysctl.run_command = lambda x: (0, 'A = 2\nB = 3\nC = 4\nD =\nE = a\nF = b', '')
    assert get_sysctl(my_sysctl, ['test_prefix']) == {'A': '2', 'B': '3', 'C': '4', 'D': '', 'E': 'a', 'F': 'b'}
    assert get_sysctl(my_sysctl, ['test_prefix', 'A']) == {'A': '2'}
    assert get_sysctl(my_sysctl, ['test_prefix', 'E']) == {'E': 'a'}

# Generated at 2022-06-23 00:34:33.507002
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeModule(dict())

    # sysctl is only available is the module is run as root
    module.params['ANSIBLE_CHECK_MODE'] = False

    # These are the values we get from a default CentOS 6.5 system
    # Note these values may change with new version of Linux.

# Generated at 2022-06-23 00:34:38.072698
# Unit test for function get_sysctl
def test_get_sysctl():
    import subprocess

    module = subprocess
    module.warn = lambda x: None
    module.run_command = lambda x: (0, 'foo = bar\nbaz: foobar', '')

    assert get_sysctl(module, ['foo', 'bar']) == {'foo': 'bar', 'baz': 'foobar'}

# Generated at 2022-06-23 00:34:41.743014
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl == {'vm.swappiness': '60'}



# Generated at 2022-06-23 00:34:53.438243
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:34:59.026903
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': dict(type='list', required=True)})
    result = get_sysctl(module, prefixes=["kern.loginclass.path"])
    assert result == {'kern.loginclass.path': '/usr/share/sysctl/login.conf'}



# Generated at 2022-06-23 00:35:03.298532
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())


# Generated at 2022-06-23 00:35:14.995824
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    results = {
        'failed': False,
        'changed': False,
        'warnings': [],
    }

    # Create the AnsibleModule mock
    module = AnsibleModule({'foo': 'bar'},
                           bypass_checks=True,
                           check_invalid_arguments=False,
                           running_under_unit_test=True)

    # Build the sysctl output string
    if sys.platform.startswith('freebsd'):
        out = ('net.link.ether.inet.max_age: 20\n'
               'net.link.ether.inet6.max_age: 20')

# Generated at 2022-06-23 00:35:23.911108
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.system import sysctl
    import os

    def temp_listdir(path):
        '''Mock os.listdir for unit test'''
        if path == '/proc/sys/net/core':
            return [ 'core_uses_pid',
                     'core_somaxconn',
                     'core_rmem_max',
                     'somaxconn',
                     'rmem_max']

# Generated at 2022-06-23 00:35:34.130421
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()

    module.warn = lambda msg:msg

# Generated at 2022-06-23 00:35:44.211079
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec=dict())

    # Fake sysctl with the following format:
    #   key: value
    #   key=value
    #   key:
    #   value1
    #   value2
    out = """key1: value
key2=value
key3:
value1
value2"""
    module.run_command = lambda x: (0, out, '')

    sysctl = get_sysctl(module, [])

    assert sysctl == dict(key1='value', key2='value', key3='value1\nvalue2')

# Generated at 2022-06-23 00:35:54.681906
# Unit test for function get_sysctl
def test_get_sysctl():
    import collections
    import module_utils.basic

    class FakeModule(object):
        def __init__(self, **kwargs):
            self._output = kwargs

        def get_bin_path(self, arg):
            return 'sysctl'

        def run_command(self, cmd):
            return (0, self._output[cmd[-1]], '')

    output = collections.defaultdict(str)
    output['fs.file-max'] = 'fs.file-max = 200000'
    output['fs.nr_open'] = 'fs.nr_open = 100000'

    module = FakeModule(**output)
    assert get_sysctl(module, ['fs.file-max']) == {'fs.file-max': '200000'}

# Generated at 2022-06-23 00:36:01.271512
# Unit test for function get_sysctl
def test_get_sysctl():
    if not HAS_SYSCTL:
        raise SkipTest('sysctl is required to run sysctl unit tests')
    module = AnsibleModule(argument_spec={'prefixes': dict(type='list', default=['.'])})
    prefixes = module.params['prefixes']

    sysctl = get_sysctl(module, prefixes)

    assert(sysctl)

# Generated at 2022-06-23 00:36:04.904956
# Unit test for function get_sysctl
def test_get_sysctl():
    """Check that get_sysctl properly parses sysctl output"""
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    class MockRunCommand:

        def __init__(self, stdout=None, stderr=None, rc=0):
            self.stdout = stdout
            self.stderr = stderr
            self.rc = rc

        def __call__(self, *args, **kwargs):
            return self.rc, self.stdout, self.stderr


# Generated at 2022-06-23 00:36:08.243318
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['fs.file-max']
    sysctl = get_sysctl(prefixes)
    assert sysctl['fs.file-max'] == '65536'



# Generated at 2022-06-23 00:36:18.409394
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.basic import load_platform_subclass

    class FakeModule(AnsibleModule):
        def run_command(self, cmd):
            results = dict()
            results['rc'] = 0

# Generated at 2022-06-23 00:36:22.864503
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel'])

    assert 'kernel.hostname' in sysctl
    assert sysctl['kernel.hostname'] != ''

# Generated at 2022-06-23 00:36:28.472286
# Unit test for function get_sysctl
def test_get_sysctl():
    # Just a simple smoke test.
    module = type('AnsibleModule', (object,), dict(get_bin_path=lambda *args: 'sysctl'))()
    results = get_sysctl(module, ['hw'])

    assert isinstance(results, dict)
    assert results
    assert 'hw.availcpu' in results


# Generated at 2022-06-23 00:36:32.481858
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl_info = get_sysctl(module, ['-a'])

    assert 'kernel.modules_disabled' in sysctl_info
    assert sysctl_info['kernel.modules_disabled'] == '0'


# Generated at 2022-06-23 00:36:43.652722
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = {
        'kern.hostname': 'localhost.localdomain',
        'net.inet.ip.forwarding': '0',
        'net.inet6.ip6.forwarding': '0'
    }

    def run_command(module, cmd):
        (key, value) = re.split(r'\s?=\s?|: ', cmd[-1], maxsplit=1)

        if key in sysctl:
            return (0, sysctl[key], '')
        else:
            return (1, '', '')

    module = type('test_get_sysctl', (), {'run_command': run_command})

    assert sysctl == get_sysctl(module, ['kern.hostname', 'net.inet.ip.forwarding'])


# Generated at 2022-06-23 00:36:46.807453
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    assert get_sysctl(module, ['vm.swappiness']) == {'vm.swappiness': '60'}, 'Error parsing sysctl'


# Generated at 2022-06-23 00:36:57.151243
# Unit test for function get_sysctl
def test_get_sysctl():

    module = type('os', (object,), {})

# Generated at 2022-06-23 00:37:02.343610
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sysctl = get_sysctl(module, ['vm.max_map_count'])

    assert sysctl.get('vm.max_map_count', None)

# Generated at 2022-06-23 00:37:11.236370
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec=dict())

    out = to_bytes('''
net.ipv4.fs.may_detach_mounts = 2
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.ip_forward = 0
''')

    rc = 0

    module.run_command = lambda *args, **kwargs: (rc, out, '')

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])

    assert sysctl['net.ipv4.ip_forward'] == '0'
    assert 'net.ipv4.fs.may_detach_mounts' not in sys