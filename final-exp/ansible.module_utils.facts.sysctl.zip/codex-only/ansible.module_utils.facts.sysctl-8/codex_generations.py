

# Generated at 2022-06-23 00:27:15.255987
# Unit test for function get_sysctl
def test_get_sysctl():

    import shlex

    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
            self.warns = []
            self.bin_paths = dict(sysctl='sysctl')

        def get_bin_path(self, binary):
            return self.bin_paths[binary]

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

        def warn(self, msg):
            self.warns.append(msg)

    class Result(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.stdout = out


# Generated at 2022-06-23 00:27:27.293324
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock(return_value=(0, """
net.ipv4.ip_forward: 1
net.ipv6.conf.all.forwarding: 1
net.ipv6.conf.default.forwarding: 1
net.ipv6.conf.lo.forwarding: 1
vm.swappiness: 5
    """, None))

    assert get_sysctl(module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}


# Generated at 2022-06-23 00:27:38.274851
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('test_get_sysctl', (object,), {})
    module.run_command = lambda cmd: (0, 'kern.synchronous_io: 1\nkern.securelevel: -1\nkern.securelevel_disable_nfs: 0\nkern.usrstack: 262144', '')
    module.warn = lambda msg: None

    # Test with no prefixes
    sysctl = get_sysctl(module, [])
    assert sysctl['kern.synchronous_io'] == '1'
    assert sysctl['kern.securelevel'] == '-1'
    assert sysctl['kern.securelevel_disable_nfs'] == '0'
    assert sysctl['kern.usrstack'] == '262144'

# Generated at 2022-06-23 00:27:48.336837
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:27:59.061172
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import textwrap
    from ansible.module_utils.basic import AnsibleModule

    sysctl_output = textwrap.dedent("""\
        net.ipv4.ip_forward = 1
        net.ipv6.conf.all.forwarding = 1
        net.ipv6.conf.default.forwarding = 1
        net.ipv6.conf.lo.forwarding = 1""")

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    module.run_command = lambda cmd, **kwargs: (0, sysctl_output, None)
    value = get_sysctl(module, [])

# Generated at 2022-06-23 00:28:10.612911
# Unit test for function get_sysctl
def test_get_sysctl():
    import platform
    import sys
    from ansible.module_utils.facts.virtual.base import get_module_class

    vm_module = get_module_class('xen')
    if vm_module is None:
        return

    os_ver = platform.linux_distribution()[1]
    python_ver = platform.python_version()
    # Test for vmware
    if vm_module._detect_vm() == 'xen':
        sysctl_map = {'vm.nr_hugepages': '0',
                      'vm.overcommit_memory': '0',
                      'vm.zone_reclaim_mode': '0'}

        sysctl_vars = get_sysctl(vm_module, ['vm.'])

        assert len(sysctl_map) == len(sysctl_vars)


# Generated at 2022-06-23 00:28:14.429453
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(prefixes=['kernel.pid_max']) == {'kernel.pid_max': '1048576'}
    assert get_sysctl(prefixes=['kernel.modprobe']) == {'kernel.modprobe': '/sbin/modprobe'}



# Generated at 2022-06-23 00:28:25.624235
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # this is so we can load this file to use the unit test function without
    # the actual function being loaded as a module
    if not hasattr(module, '_ansible_check_mode'):
        module._ansible_check_mode = False

    sysctls = get_sysctl(module, ['net.ipv4.ip_forward'])

    if module._ansible_check_mode:
        sysctls = dict(net=dict(ipv4=dict(ip_forward=True)))

    assert 'net.ipv4.ip_forward' in sysctls
    assert 'net.ipv4.ip_forward_debug' not in sysctls


# Generated at 2022-06-23 00:28:34.591845
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': dict(type='list', default=['net.ipv4.conf.all'])})
    prefixes=['net.ipv4.conf.all']
    sysctl=get_sysctl(module, prefixes)
    assert isinstance(sysctl, dict)
    assert len(sysctl) > 0
    assert 'net.ipv4.conf.all.accept_source_route' in sysctl.keys()
    assert 'net.ipv4.conf.all.log_martians' in sysctl.keys()
    assert 'net.ipv4.conf.all.promote_secondaries' in sysctl.keys()



# Generated at 2022-06-23 00:28:39.466271
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl(module, prefixes=['net.r', 'vm.swappiness'])
    assert sysctl['net.route.default.iface'] == 'eth0'
    assert sysctl['vm.swappiness'] == '60'
# End unit test for function get_sysctl


# Generated at 2022-06-23 00:28:43.357855
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    sysctl = get_sysctl(module, [])
    assert sysctl is not None, "get_sysctl returned None"

# Generated at 2022-06-23 00:28:51.915143
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type
    module.warn = print
    module.run_command = run_command

    prefixes = ['net.ipv4.tcp_syncookies', 'kernel.shmmax', 'kernel.shmall']

    sysctl = get_sysctl(module, prefixes)

    assert sysctl['net.ipv4.tcp_syncookies'] == '1'
    assert sysctl['kernel.shmmax'] == '4294967295'
    assert sysctl['kernel.shmall'] == '18446744073692774399'


# Generated at 2022-06-23 00:29:00.350646
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # Adapted from AnsibleModule.run_command
    def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None):
        if executable:
            cmd[0] = executable
        rc = None
        msg = None
        if data:
            cmd.extend([to_bytes('-'), to_bytes('-data'), to_bytes(data)])
        if path_prefix:
            cmd[0] = to_bytes(os.path.join(path_prefix, os.path.basename(cmd[0])))

# Generated at 2022-06-23 00:29:12.046450
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-23 00:29:22.179998
# Unit test for function get_sysctl
def test_get_sysctl():
    assert isinstance(get_sysctl('/bin/sysctl', ['a.single.key']), dict)
    assert get_sysctl('/bin/sysctl', ['a.single.key']) == {'a.single.key': '123456789'}
    assert isinstance(get_sysctl('/bin/sysctl', ['not.existing.key']), dict)
    assert get_sysctl('/bin/sysctl', ['not.existing.key']) == {'not.existing.key': ''}
    assert isinstance(get_sysctl('/bin/sysctl', ['multi.line.key']), dict)
    assert get_sysctl('/bin/sysctl', ['multi.line.key']) == {'multi.line.key': 'line 1\nline 2'}

# Generated at 2022-06-23 00:29:25.497695
# Unit test for function get_sysctl
def test_get_sysctl():
    result = dict()
    try:
        result = get_sysctl('', '')
    except Exception as e:
        result['exception'] = str(e)
    return result


# Generated at 2022-06-23 00:29:35.889002
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()
    module.warn = lambda msg: None
    module.get_bin_path = lambda _: 'sysctl'
    module.run_command = lambda cmd: (0, 'kernel.domainname: example.com\n'
      'kernel.hostname: test\n'
      'kernel.osrelease: 5.3.10-1-ARCH\n'
      'kernel.osrevision: 1\n'
      'kernel.ostype: Linux\n'
      'kernel.ostype = Linux\n', '')

    prefixes = ['kernel.domainname', 'kernel.osrevision']
    result = get_sysctl(module, prefixes)

    assert result['kernel.domainname'] == 'example.com'
    assert result['kernel.osrevision'] == '1'

# Generated at 2022-06-23 00:29:42.260229
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = ['net.ipv4.conf.default.proxy_arp']
    if module is not None:
        sysctl = get_sysctl(module, prefixes)
        assert sysctl['net.ipv4.conf.default.proxy_arp'] == '0'

# Generated at 2022-06-23 00:29:53.200889
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import sysctl
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    # The following test should match the sysctl.kernel.hostname value.
    sysctl_prefixes = [
        sysctl.kernel.hostname.oid,
        sysctl.kernel.hostname.key,
    ]


# Generated at 2022-06-23 00:30:02.541989
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import os

    # Create a simple module to test with
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Get the sysctl info
    result = get_sysctl(module, ['kernel.osrelease', 'kernel.hostname'])

    # First verify that we got sysctl info
    assert isinstance(result, dict)

    # Then we check to see if we have the values we expect
    assert os.uname()[2] in result['kernel.osrelease']
    assert os.uname()[1] == result['kernel.hostname']

if __name__ == "__main__":
    test_get_sysctl()

# Generated at 2022-06-23 00:30:13.448799
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    import shutil
    import random
    import string

    # Invoke the environment_fail_json module to get the mock module
    from ansible.module_utils.basic import AnsibleModule

    # Use a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary sysctl.d directory
    sysctl_conf_dir = os.path.join(temp_dir, 'sysctl.d')
    os.mkdir(sysctl_conf_dir)

    # Create a temporary sysctl.d config file
    sysctl_conf_file = os.path.join(sysctl_conf_dir, 'unicorns.conf')
    with open(sysctl_conf_file, 'w') as fd:
        fd.write('kernel.kicking = true\n')


# Generated at 2022-06-23 00:30:16.008969
# Unit test for function get_sysctl
def test_get_sysctl():
    module = DummyModule()
    assert {'kernel.domainname': 'testing'} == get_sysctl(module, ["kernel.domainname"])


# Generated at 2022-06-23 00:30:23.841981
# Unit test for function get_sysctl
def test_get_sysctl():
    class TestAnsibleModule():
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path, opt_dirs=None):
            return "/bin/sysctl"

        def run_command(self, cmd):
            print(cmd)
            return 0, "net.ipv4.ip_forward = 1\n", ""

    module = TestAnsibleModule(dict())
    sysctl = get_sysctl(module, ["-a"])
    assert sysctl["net.ipv4.ip_forward"] == "1"

# Generated at 2022-06-23 00:30:32.690074
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:30:37.523903
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    results = get_sysctl(module, ['kernel.ostype'])
    assert results == { 'kernel.ostype': 'Linux' }

# Generated at 2022-06-23 00:30:47.098224
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os


# Generated at 2022-06-23 00:30:53.351470
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    results = get_sysctl(module, ['kernel.hostname'])
    assert results['kernel.hostname'] is not None

    sysctl_cmd = module.get_bin_path('sysctl')
    cmd = [sysctl_cmd]
    cmd.extend(['kernel.hostname'])

    try:
        rc, out, err = module.run_command(cmd)
    except (IOError, OSError) as e:
        module.warn('Unable to read sysctl: %s' % to_text(e))
        rc = 1
    assert rc == 0

    assert results['kernel.hostname'].upper() == out.strip().upper()

# Generated at 2022-06-23 00:31:04.645989
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:31:08.957421
# Unit test for function get_sysctl
def test_get_sysctl():
    m = AnsibleModule(argument_spec={})

    m.get_bin_path = lambda arg: arg

    result = get_sysctl(m, ['kernel.shmmni'])

    assert result == {
        'kernel.shmmni': '4096'
    }

# Generated at 2022-06-23 00:31:20.442722
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'hacking'))
    from testlib import AnsibleModuleTestCase

    class GetSysctlTest(AnsibleModuleTestCase):
        def get_bin_path(self, arg):
            return os.path.join(os.path.dirname(__file__), 'testdata', arg)

    testcase = GetSysctlTest()
    testcase.run_command = testcase.make_command('sysctl', dict())

    result = testcase.run_command(['-f', '-e'])
    testcase.assertEqual(result, (0, 'hi\nx = 0', ''))


# Generated at 2022-06-23 00:31:31.866437
# Unit test for function get_sysctl
def test_get_sysctl():

    class FakeModule:
        def get_bin_path(self, _):
            return 'sysctl'
        def run_command(self, cmd):
            if 'unknown' in cmd:
                return 1, '', 'Command not found'
            if '-a junk' in cmd:
                return 1, '', 'foo bar baz'
            if '-a' in cmd:
                return 0, 'foo = bar\nbar: baz\nbaz = biz\n ', ''

    module = FakeModule()
    sysctl_all = get_sysctl(module, ['-a'])
    assert sysctl_all == {
        'foo': 'bar',
        'bar': 'baz',
        'baz': 'biz',
    }

    module = FakeModule()

# Generated at 2022-06-23 00:31:41.475521
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(
        argument_spec=dict(),
    )

    get_sysctl_additional_args = {
        'prefixes': ['vm.max_map_count'],
    }

    module.set_module_args(get_sysctl_additional_args)

    # Sysctl usage to reproduce errors when running outside of module_utils.
    try:
        res = get_sysctl(module, get_sysctl_additional_args['prefixes'])
    except Exception:
        err = get_exception()

# Generated at 2022-06-23 00:31:53.272080
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import _load_params
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    import sys

    if sys.version_info[0] > 2:
        AnsibleModule = AnsibleModule
        _load_params = _load_params
        get_exception = get_exception
    else:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.basic import _load_params
        from ansible.module_utils.basic import get_exception

    sysctl = {}
    sysctl['kernel.domainname'] = 'domain.name'


# Generated at 2022-06-23 00:32:04.445645
# Unit test for function get_sysctl
def test_get_sysctl():

    class TestModule(object):
        def get_bin_path(self, name):
            return name

        def warn(self, msg):
            pass

        def run_command(self, cmd):
            res = 0
            err = ""

# Generated at 2022-06-23 00:32:15.250870
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()


# Generated at 2022-06-23 00:32:27.025620
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os
    import types
    import copy
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception

    # Include distro and distro_file_prefixes in the sys.modules so that they
    # can be mocked.
    sys.modules['ansible.module_utils.distro'] = types.ModuleType('distro')
    sys.modules['ansible.module_utils.distro_file_prefixes'] = types.ModuleType('distro_file_prefixes')

    # Mocking the AnsibleModule class
    class AnsibleModule(basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            basic.AnsibleModule.__

# Generated at 2022-06-23 00:32:37.535663
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module_mock = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    module_mock.run_command = lambda x: (0, '{0}\n{1}\n'.format('kernel.shmmax = 4294967295','fs.file-max = 65535'), '')
    assert ('fs.file-max', '65535') in get_sysctl(module_mock, ['fs.file-max']).items()
    assert ('kernel.shmmax', '4294967295') in get_sysctl(module_mock, ['kernel.shmmax']).items()



# Generated at 2022-06-23 00:32:50.168461
# Unit test for function get_sysctl
def test_get_sysctl():
    missing_a_key = False
    good_sysctl = get_sysctl(sysctl_cmd='echo', prefixes=['-e', 'net.ipv4.tcp_abc=1', 'net.ipv4.tcp_xyz=2'])
    if ('net.ipv4.tcp_abc' not in good_sysctl) or ('net.ipv4.tcp_xyz' not in good_sysctl):
        missing_a_key = True
    assert not missing_a_key

    missing_a_key = False
    bad_sysctl = get_sysctl(sysctl_cmd='echo', prefixes=['-e', 'net.ipv4.tcp_abc=1', 'net.ipv4.tcp_xyz=2'])

# Generated at 2022-06-23 00:32:59.361530
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import json
    import shlex

    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     supports_check_mode=False, required_together=None,
                     required_one_of=None, add_file_common_args=False,
                     supports_plugins=False):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive or []
            self.supports_check_mode = supports_check_mode
            self.required_together = required_

# Generated at 2022-06-23 00:33:10.320684
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import os
    import tempfile
    import shutil

    sysctl_cmd = sys.executable + ' ' + os.path.join(os.path.dirname(__file__), 'sysctl.py')

    DATA = '''
net.ipv4.ip_forward: 1
net.ipv4.conf.default.forwarding = 1
dev.splx.spl_kmem_cache_slab_destroy = 1
dev.splx.spl_debug = 0
hfs.hfs_disable_journaling = 0
'''


# Generated at 2022-06-23 00:33:22.260684
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    from ansible.module_utils import basic

    sysctlfile = os.path.join(tempfile.gettempdir(), 'sysctl')
    sysctlcmd = '''
kernel.msgmnb = 65536
net.ipv4.tcp_mem = 181704	181704	181704
    kernel.osrelease = 4.1.0
    foo = bar
    multiline = value
    more = lines
        '''
    open(sysctlfile, 'w').write(sysctlcmd)

    module_args = dict()
    module_args['sysctl_file'] = sysctlfile

    m = basic.AnsibleModule(argument_spec=module_args)
    p = m.params

# Generated at 2022-06-23 00:33:33.614533
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    class EnvFailAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            kwargs['supports_check_mode'] = False
            super(EnvFailAnsibleModule, self).__init__(*args, **kwargs)


# Generated at 2022-06-23 00:33:39.861639
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    to_extract = ['vm.overcommit_memory', 'vm.swappiness', 'kernel.randomize_va_space']
    sysctl = {'kernel.randomize_va_space': '1', 'vm.overcommit_memory': '1', 'vm.swappiness': '60'}
    assert get_sysctl(module, to_extract) == sysctl


# Generated at 2022-06-23 00:33:42.920608
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})

    sysctl = get_sysctl(module, [])
    assert sysctl is not None

# Generated at 2022-06-23 00:33:53.550382
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    # Mock/stub out module_utils functions
    class MockModule(object):
        def __init__(self):
            self.bin_path_cache = {}
            self.fail_json_called = False
            self.warn_called = False

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return self.bin_path_cache[arg]

        def run_command(self, args):
            # Can't use assertEquals because of object comparison
            if args[0] == sysctl_cmd:
                if args[1] != '-a':
                    raise Exception('Unexpected sysctl arguments: %s' % args)
                return (0, sysctl_out, '')

# Generated at 2022-06-23 00:33:56.631392
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    assert len(get_sysctl(module, prefixes=['kern.ostype', 'kern.version'])) == 2

# Generated at 2022-06-23 00:34:08.942387
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    # Test module
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    # Test command
    module.get_bin_path = lambda _cmd: '/bin/sysctl'

    # If the command is not found, the function must return an empty dict
    def run_command_error(self, *args, **kwargs):
        raise OSError

    module.run_command = run_command_error
    assert {} == get_sysctl(module, [])

    # Expected command
    module.run_command = lambda cmd, **kwargs: (0, '\n'.join(['k1 = v1', 'k2: v2', '3\t 4', 'k3 = v3']), '')

# Generated at 2022-06-23 00:34:14.481845
# Unit test for function get_sysctl
def test_get_sysctl():
    # Create mock module
    module = type(sys)('test_sysctl')
    module.run_command = lambda cmd, *args, **kwargs: (0, '', '')
    module.warn = lambda msg: None
    module.get_bin_path = lambda name: name

    # Test get_sysctl
    sysctl = get_sysctl(module, [])
    assert sysctl



# Generated at 2022-06-23 00:34:19.569705
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    prefixes = ['kernel.domainname', 'kernel.ostype']
    sysctl = get_sysctl(module, prefixes)
    assert sysctl
    assert sysctl['kernel.domainname'] == 'localdomain'
    assert sysctl['kernel.ostype'] == 'Linux'



# Generated at 2022-06-23 00:34:26.212507
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={
        'prefixes': dict(type='list', required=True),
    })

    sysctl = get_sysctl(module, [ 'kern.boottime', 'kern.ostype' ])

    assert type(sysctl) is dict
    assert 'kern.boottime' in sysctl
    assert 'kern.ostype' in sysctl

# Generated at 2022-06-23 00:34:32.723837
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule({})

    prefixes = ['net.ipv4.ip_forward']
    test_sysctl = get_sysctl(module, prefixes)

    assert 'net.ipv4.ip_forward' in test_sysctl, test_sysctl
    assert test_sysctl['net.ipv4.ip_forward'] == '1', test_sysctl

    prefixes.append('net.ipv4.ip_forward')
    test_sysctl = get_sysctl(module, prefixes)

    assert 'net.ipv4.ip_forward' in test_sysctl, test_sysctl

# Generated at 2022-06-23 00:34:37.246789
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(arg_spec={'prefix': {'type': 'list', 'default': []}})
    module.run_command = basic.run_command

    prefixes = module.params['prefix']

    assert get_sysctl(module, prefixes)

# Generated at 2022-06-23 00:34:46.931625
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    try:
        out = get_sysctl(module, ['vm.swappiness', 'vm.panic_on_oom'])
    except Exception as e:
        module.fail_json(msg='Unable to read sysctl: %s' % to_text(e))

    assert len(out) == 2
    assert out['vm.swappiness'] == '0'
    assert out['vm.panic_on_oom'] == '0'

# Generated at 2022-06-23 00:34:51.140836
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ['vm.dirty_ratio'])
    assert sysctl['vm.dirty_ratio'] == '40'

# For unit test module, by mocking AnsibleModule class

# Generated at 2022-06-23 00:35:00.808223
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test: For each key in sysctl.conf, return its sysctl value
    sysctl = None
    with open('tests/utils/test_get_sysctl.txt', encoding='utf-8') as f:
        sysctl = f.readlines()

    sysctl_values = {}
    for line in sysctl:
        key, value = re.split(r'\s?=\s?|: ', line, maxsplit=1)
        sysctl_values[key] = value.strip()

    sysctl_out = get_sysctl(sysctl_values.keys())
    for key in sysctl_values.keys():
        if key not in sysctl_out.keys():
            return False
        if sysctl_values[key] != sysctl_out[key]:
            return False

    # Test: For a key not

# Generated at 2022-06-23 00:35:04.723946
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(
        prefixes=dict(type='list')
    ))
    sysctl = get_sysctl(module, ['vm.nr_hugepages'])
    assert sysctl.get('vm.nr_hugepages') == '0'


# Generated at 2022-06-23 00:35:13.396581
# Unit test for function get_sysctl
def test_get_sysctl():
    """get_sysctl unit test"""

    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec = dict()
    )

    module.run_command = run_command_stub

    sysctl = get_sysctl(module, ['kernel.domainname'])
    assert sysctl == {'kernel.domainname': 'example.com'}

    sysctl = get_sysctl(module, ['kernel.domainname', \
                                 'kernel.ostype'])

# Generated at 2022-06-23 00:35:18.969564
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    sysctl = get_sysctl(module, ['kern.hostname', 'machdep.cpu.brand_string'])

    assert isinstance(sysctl, dict)
    assert sysctl['kern.hostname'] == 'tmp'
    assert 'Core' in sysctl['machdep.cpu.brand_string']

# Generated at 2022-06-23 00:35:28.293895
# Unit test for function get_sysctl
def test_get_sysctl():

    prefixes = ["kern.boottime", "kern.hostname"]
    sysctl_mock = {
        'kern.boottime': '{ sec = 1516200789, usec = 736064 } Sat Jan 20 11:19:49 2018\n',
        'kern.hostname': 'pfSense\n'
    }
    module_mock = MockModule()
    module_mock.run_command = Mock()
    module_mock.run_command.return_value = (0, '', '')

    result = get_sysctl(module_mock, prefixes)

    module_mock.run_command.assert_called_once_with([module_mock.get_bin_path('sysctl'), "kern.boottime", "kern.hostname"])
    assert sysctl_

# Generated at 2022-06-23 00:35:30.650103
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule({}, check_mode=False)

    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-23 00:35:38.149449
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    module = patch('ansible_collections.community.general.plugins.modules.system.sysctl.AnsibleModule')

    fake_rc = 0
    fake_out = 'net.ipv4.ip_forward = 0'
    fake_err = ''
    fake_run_command = (fake_rc, fake_out, fake_err)
    module.run_command.return_value = fake_run_command

    set_module_args(dict(names=['net.ipv4.ip_forward'], state='present'))


# Generated at 2022-06-23 00:35:44.091162
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_out = '''
    abc.def = 1
    abc.def.ghi = 2
    jkl.mno = 1
    abc.def.hij: 3
    '''
    sysctl_expected = dict(abc={'def': '1'}, jkl={'mno': '1'})
    assert sysctl_expected == get_sysctl(None, ['abc.*', 'jkl.mno'], sysctl_out)

# Generated at 2022-06-23 00:35:54.587499
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import StringIO

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import ModuleDeprecationWarning
    import warnings

    warnings.simplefilter("ignore", ModuleDeprecationWarning)
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 00:36:07.566548
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    class ModuleStub(object):
        def __init__(self, out=None, err=None, rc=0):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

        def warn(self, msg):
            sys.stderr.write('WARN: %s\n' % msg)

        def exit_json(self, data):
            sys.stdout.write(data)

    def test(out, err, rc, expected_out):
        m = ModuleStub(out=out, err=err, rc=rc)

# Generated at 2022-06-23 00:36:19.019095
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import os
    import json
    import tempfile
    import shutil
    from contextlib import contextmanager
    from ansible.module_utils.basic import AnsibleModule

    @contextmanager
    def fake_sysctl(data):
        sysctl_path = os.path.join(tempfile.gettempdir(), 'sysctl')
        with open(sysctl_path, 'w') as f:
            f.write(data)
        os.environ['PATH'] = ':'.join([os.path.dirname(sysctl_path), os.environ['PATH']])
        yield
        del os.environ['PATH']

    def run_module(prefixes):
        module = AnsibleModule(argument_spec={'prefixes': {'type': 'list'}}, supports_check_mode=False)

# Generated at 2022-06-23 00:36:28.927070
# Unit test for function get_sysctl
def test_get_sysctl():
    fakecommand = dict(
        rc=0,
        stdout='vm.swappiness = 10\nvm.overcommit_memory = 0\n'
    )
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    setattr(module, 'run_command', lambda x, check_rc=True: fakecommand)
    setattr(module, 'get_bin_path', lambda x: x)
    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory'])

    assert sysctl['vm.swappiness'] == '10'
    assert sysctl['vm.overcommit_memory'] == '0'



# Generated at 2022-06-23 00:36:39.927004
# Unit test for function get_sysctl
def test_get_sysctl():

    sysctl = dict()
    sysctl['kern.hostname'] = 'localhost'
    sysctl['kern.ostype'] = 'Darwin'
    sysctl['kern.osrelease'] = '14.0.0'
    sysctl['kern.osversion'] = 'Darwin Kernel Version 14.0.0: Fri Sep 19 00:26:44 PDT 2014; root:xnu-2782.1.97~2/RELEASE_X86_64'
    sysctl['net.inet.tcp.blackhole'] = '2'

    module = DummyModule({'ANSIBLE_MODULE_ARGS': {'prefixes': ['kern', 'net.inet.tcp.blackhole']}})
    get_sysctl(module, ['kern', 'net.inet.tcp.blackhole'])


# Generated at 2022-06-23 00:36:47.929885
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    sysctl = get_sysctl(basic.AnsibleModule(argument_spec={}),
                        ['vm', 'overcommit_memory'])
    assert sysctl == {'vm.overcommit_memory': '0'}

    sysctl = get_sysctl(basic.AnsibleModule(argument_spec={}),
                        ['fs', 'aio-max-size'])
    assert sysctl == {
        'fs.aio-max-size': '1048576',
        'fs.aio-max-nr': '65536'}

# Generated at 2022-06-23 00:36:49.980073
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['vm.swappiness']) == {'vm.swappiness': '0'}


# Generated at 2022-06-23 00:36:52.495175
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    assert get_sysctl(module, ['vm.swappiness']) == {'vm.swappiness': '30'}



# Generated at 2022-06-23 00:36:59.203286
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )
    result = get_sysctl(module, prefixes=['net.ipv4.conf.all.accept_source_route', 'net.ipv6.conf.all.accept_source_route'])

    assert result == {
        'net.ipv4.conf.all.accept_source_route': '0',
        'net.ipv6.conf.all.accept_source_route': '0'
    }

# Generated at 2022-06-23 00:37:04.657027
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl
    module = sysctl

    module.run_command = lambda cmd, check_rc=True: ('', 'kern.bluetooth.version = "1.0"\nkern.ipc.tmpdir = "/tmp"', '')
    assert get_sysctl(module, []) == {'kern.bluetooth.version': '1.0', 'kern.ipc.tmpdir': '/tmp'}