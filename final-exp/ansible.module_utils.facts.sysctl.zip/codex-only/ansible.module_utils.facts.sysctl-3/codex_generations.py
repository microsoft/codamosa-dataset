

# Generated at 2022-06-23 00:27:13.541756
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kern.hostname', 'hw.ncpu', 'kern.fallback_elf_brand'])
    assert to_text(sysctl['kern.hostname']) == 'testhost'
    assert to_text(sysctl['kern.fallback_elf_brand']) == '3'

# Generated at 2022-06-23 00:27:16.162981
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule:
        def __init__(self):
            self.warn = lambda f: None
            self.run_command = lambda f: (0, "", "")
            self.get_bin_path = lambda f: "/sbin/sysctl"

    fake = FakeModule()
    sysctl = get_sysctl(fake, ['vm.swappiness'])

    assert sysctl.get('vm.swappiness') == "60"

# Generated at 2022-06-23 00:27:27.727830
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 1
            self.run_command_out = 'test'
            self.run_command_err = ''
            self.warn_called = False
            self.warn_msg = ''

        def get_bin_path(self, cmd):
            return 'testbin'

        def run_command(self, cmd):
            self.run_command_called = True
            return self.run_command_rc, self.run_command_out, self.run_command_err

        def warn(self, msg):
            self.warn_called = True
            self.warn_msg = msg

    module = FakeModule()

    module.run_command_rc = 0
    module.run_

# Generated at 2022-06-23 00:27:38.820421
# Unit test for function get_sysctl
def test_get_sysctl():
    import os.path
    import tempfile
    import shutil
    from ansible.module_utils.common.process import get_bin_path

    sysctl_path = get_bin_path('sysctl')
    if sysctl_path is None:
        # Omit test on platforms with no sysctl
        return

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 00:27:41.998141
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule('sysctl')
    values = get_sysctl(module, ['kern.version'])

    assert len(values) > 0
    assert values['kern.version']



# Generated at 2022-06-23 00:27:50.665871
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import Mock, patch

    module = Mock()
    prefixes = ['foo', 'bar']
    lines = '''
    foo.bar.baz = blah
    foo.bar.some.key.without.a.value:
    foo.bar.some.key.with.value:       value
    foo.bar.some.key.with.a.multiline
    value that goes over
    multiple lines
    and some final lines
    '''

    module.get_bin_path.return_value = '/bin/sysctl'
    module.run_command.return_value = (0, lines, '')

    result = get_sysctl(module, prefixes)


# Generated at 2022-06-23 00:27:55.509449
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    res = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert res['net.ipv4.ip_forward'] == 0

# Generated at 2022-06-23 00:27:58.662066
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({'run_command': run_command}, ['net.ipv4.tcp_syncookies']) == {'net.ipv4.tcp_syncookies': '1'}



# Generated at 2022-06-23 00:28:10.067135
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = lambda *args, **kwargs: sys.exit(1)
            self.exit_json = lambda *args, **kwargs: sys.exit(0)

    class FakeArgs(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    # Use a fake run_command that returns a fixed value
    class FakeRunCommand(object):
        def __init__(self, **kwargs):
            self.params = kwargs

# Generated at 2022-06-23 00:28:17.059630
# Unit test for function get_sysctl
def test_get_sysctl():
    # Create the module mock
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # Set up for the call to get_sysctl
    # This function does some magic to get an unused value for the actual module
    # parameter name, so we just set values that we're going to test for.
    module.params = dict()
    module.params['prefix'] = 'kernel'

    # The result of module.run_command
    rc = 0

# Generated at 2022-06-23 00:28:28.088625
# Unit test for function get_sysctl
def test_get_sysctl():
    cmd = ["/bin/sh", "-c", "cat src/test/test_sysctl.txt"]

    sysctl = dict()
    key = ''
    value = ''

    rc, out, err = module.run_command(cmd)
    if rc == 0:
        for line in out.splitlines():
            if not line.strip():
                continue

            if line.startswith(' '):
                # handle multiline values, they will not have a starting key
                # Add the newline back in so people can split on it to parse
                # lines if they need to.
                value += '\n' + line
                continue

            if key:
                sysctl[key] = value.strip()


# Generated at 2022-06-23 00:28:32.212236
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import ansible.module_utils.basic

    if sys.version_info.major < 3:
        import mock
    else:
        from unittest import mock

    class MockAnsibleModule(object):

        def __init__(self, *args, **kwargs):
            self.params = dict()
            self.ansible_facts = dict()
            self.changed = False
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.exit_json = lambda **kwargs: sys.exit(0)

        def run_command(self, cmd):
            return 0, '/proc/sys/net/ipv4/tcp_fin_timeout = 60\n\n', ''


# Generated at 2022-06-23 00:28:40.526712
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(
        prefixes=dict(type='list', elements='str'),
    ))
    # The sysctl_mib_support test requires the ansible_os_family to = FreeBSD
    module.params['ansible_os_family'] = 'FreeBSD'
    sysctl = get_sysctl(module, ['kern.features.inet6'])
    assert sysctl['kern.features.inet6'] == '1'


from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 00:28:50.219158
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(prefixes=dict(default='', required=True)))

    # Fake out ansible module adding a sysctl command
    import sys
    sys.modules['ansible.module_utils.basic'] = module
    from ansible.module_utils.basic import get_bin_path
    module.get_bin_path = lambda x: 'sysctl'

    # Fake the return of the get_bin_path function
    module.run_command = lambda x: (0, 'kern.version=16.1-RELEASE\nkern.ostype=FreeBSD\nkern.osrelease=16.1-RELEASE\nkern.osrevision=0', '')


# Generated at 2022-06-23 00:28:55.123959
# Unit test for function get_sysctl
def test_get_sysctl():
    module = DummyAnsibleModule()
    assert {'kern.hostname': 'rhea.local', 'kern.maxproc': '12290', 'kern.maxusers': '0'} == \
            get_sysctl(module, ['kern.hostname', 'kern.maxproc', 'kern.maxusers'])



# Generated at 2022-06-23 00:28:57.281737
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ["kernel.randomize_va_space"])
    assert(sysctl["kernel.randomize_va_space"] == "1")



# Generated at 2022-06-23 00:29:03.127397
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import datetime
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({}, supports_check_mode=True)
    test_module.params = {}


# Generated at 2022-06-23 00:29:06.768147
# Unit test for function get_sysctl
def test_get_sysctl():
    # get_sysctl should return a dict with a key for each key/value pair in
    # the sysctl output.
    assert(len(get_sysctl({}, ['/bin/cat'])) == 7)

# Generated at 2022-06-23 00:29:17.703585
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda x, y: y,
        'run_command': lambda x, y: (0, 'foo=bar\nbaz=baz', ''),
        'warn': lambda x: None
    })()

    assert get_sysctl(module, ['foo']) == {'foo': 'bar'}
    assert get_sysctl(module, ['foo', 'baz']) == {'foo': 'bar', 'baz': 'baz'}

    try:
        module.run_command = lambda x, y: (1, '', '')
        get_sysctl(module, ['foo'])
        assert False, 'Should not be able to read sysctl'
    except AssertionError:
        raise

# Generated at 2022-06-23 00:29:22.286447
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six.moves import StringIO

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    setattr(module, 'run_command', run_command)

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])

    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-23 00:29:33.152298
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 00:29:36.594431
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert get_sysctl(module, []) == {}
    assert get_sysctl(module, ['dbg.bktr_verbose']) == {'dbg.bktr_verbose': '1'}

# Generated at 2022-06-23 00:29:43.101917
# Unit test for function get_sysctl
def test_get_sysctl():
    expected_result = {
        "kernel.hostname": "ubuntu",
        "kernel.domainname": "(none)",
        "kernel.unprivileged_bpf_disabled": "1",
    }
    assert get_sysctl(["kernel.hostname", "kernel.domainname", "kernel.unprivileged_bpf_disabled"]) == expected_result


# Generated at 2022-06-23 00:29:44.947691
# Unit test for function get_sysctl
def test_get_sysctl():
    assert 'kernel.domainname' in get_sysctl(module, ['kernel.domainname'])


# Generated at 2022-06-23 00:29:49.333045
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '0'}

# Generated at 2022-06-23 00:29:54.883225
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(type='list', required=True),
        ),
    )

    result = get_sysctl(module, ['kernel.hostname', 'fs.file-max'])
    assert_equal(result, {'kernel.hostname': 'localhost', 'fs.file-max': '179022'})

# Generated at 2022-06-23 00:30:02.826600
# Unit test for function get_sysctl
def test_get_sysctl():
    testargs = ['/bin/sysctl', 'kern.hostname']
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    module = AnsibleModule(argument_spec=dict())
    try:
        from ansible.module_utils import common_koji

        module.run_command = common_koji.run_command
        module.get_bin_path = lambda x: '/bin/sysctl'
        out = get_sysctl(module, testargs)
    except:
        out = get_exception()

    assert out


# Generated at 2022-06-23 00:30:13.733735
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import os


# Generated at 2022-06-23 00:30:17.053828
# Unit test for function get_sysctl
def test_get_sysctl():
    p = MockModule(dict())
    d = get_sysctl(p, [])
    assert 'net.ipv4.ip_forward' in d and d['net.ipv4.ip_forward'] == '0'


# Generated at 2022-06-23 00:30:27.990704
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    params = dict(
        prefixes=['kernel.hostname']
    )

    module = AnsibleModule(
        argument_spec=params,
        supports_check_mode=True
    )

    # Creating a temporary file to store output of sysctl command
    tmp_fd, tmp_filename = tempfile.mkstemp()
    with open(tmp_filename, "w") as tmp_file:
        tmp_file.write("kernel.hostname = test-hostname")

    params['sysctl_path'] = tmp_filename

    # Calling get_sysctl function to get the output of sysctl command
    rc, out, err = get_sysctl(module, params['prefixes'])

    sysctl = dict()

# Generated at 2022-06-23 00:30:29.011904
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(module, ['net.ipv4.ip_forward'])['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-23 00:30:41.693384
# Unit test for function get_sysctl
def test_get_sysctl():

    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.network.common.utils
    import os
    import sys

    handles, fd_args = ansible.module_utils.basic.AnsibleModule._load_params()
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
        handles = handles,
        fd_args = fd_args,
        add_file_common_args = True,
        no_log = True
    )

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.exit_json = lambda **kwargs: sys.exit(0)

# Generated at 2022-06-23 00:30:49.963587
# Unit test for function get_sysctl
def test_get_sysctl():
    # The following 2 lines are needed to import module.run_command()
    from ansible.modules.system.sysctl import SysctlModule
    m = SysctlModule(dict(prefixes=['net.ipv4.ip_forward']),
                     '',
                     check_invalid_arguments=False, no_log=True)

    # Make sure we actually get back key/value
    sysctl = get_sysctl(m, ['net.ipv4.ip_forward'])
    assert len(sysctl) == 1
    assert isinstance(sysctl['net.ipv4.ip_forward'], int)

# Generated at 2022-06-23 00:30:59.502737
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    prefixes = ['vm.swappiness']
    expected_results = {'vm.swappiness': '0'}
    result = get_sysctl(module, prefixes)
    assert result == expected_results

    prefixes = ['kernel.panic', 'kernel.panic_on_oops']
    expected_results = {'kernel.panic': '0', 'kernel.panic_on_oops': '0'}
    result = get_sysctl(module, prefixes)
    assert result == expected_results

# Generated at 2022-06-23 00:31:01.449262
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    sysctl = get_sysctl(module, ['-a'])
    assert isinstance(sysctl, dict)



# Generated at 2022-06-23 00:31:13.310058
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()

# Generated at 2022-06-23 00:31:19.846060
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os

    # Set up vars
    sysctl_cmd = '/sbin/sysctl'
    prefixes = [ 'vm.swappiness' ]
    sysctl = dict()

    # Run test
    sysctl = get_sysctl(sysctl_cmd, prefixes)

    # Assert test result
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-23 00:31:30.978264
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Test get_sysctl function
    '''
    import re


# Generated at 2022-06-23 00:31:40.816919
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, {})

    prefixes = [ 'net.', 'vm.', 'kern.shmmax' ]
    test_sysctl = { u'net.inet.tcp.blackhole': u'2', u'net.inet.tcp.icmp_may_rst': u'1', u'net.inet.udp.blackhole': u'1', u'kern.shmmax': u'18446744073692774399', u'vm.kmem_size_max': u'33554432', u'vm.kmem_size': u'41943040' }

    sysctl = get_sysctl(module, prefixes)

    assert sysctl == test_sysctl

# Generated at 2022-06-23 00:31:52.966809
# Unit test for function get_sysctl
def test_get_sysctl():

    import os, tempfile

    filepath = os.path.join(tempfile.mkdtemp(), 'test_file')

# Generated at 2022-06-23 00:32:04.285615
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.test_tools import MockModule

    # os.stat_float_times is only available in Python 3.3 and later
    try:
        os.stat_float_times()
    except AttributeError:
        os.stat_float_times = False

    with open('/proc/sys/kernel/ostype', 'r') as f:
        ostype = f.readline().rstrip()

    with open('/proc/sys/kernel/osrelease', 'r') as f:
        osrelease = f.readline().rstrip()

    def run_command(self, cmd, check_rc=True):
        return (0, '', '')

    module = MockModule(argument_spec={})
    module.run_

# Generated at 2022-06-23 00:32:10.567206
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('', ['net.ipv4.ip_forward']) == {}
    assert get_sysctl('', ['net.ipv4.ip_forward', 'net.ipv4.conf.all.rp_filter']) == {}
    assert get_sysctl('', ['net.ipv4.ip_forward', 'net.ipv4.conf.all.rp_filter']) == {}


# Generated at 2022-06-23 00:32:13.862160
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    assert get_sysctl(module, ["vm.overcommit_memory"])["vm.overcommit_memory"] == "1"

# Generated at 2022-06-23 00:32:20.681583
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        )
    )
    test_result = get_sysctl(
        test_module,
        ['fs.file-max']
    )
    assert 'fs.file-max' in test_result
    assert '18446744073709551615' == test_result.get('fs.file-max')

# Generated at 2022-06-23 00:32:32.325175
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os

    # We're testing a function that does subprocess calls, so we set no_log
    # (which could be removed once we're not doing subprocess calls, but that's
    # not in the scope of this fix).
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec=dict())
    if PY3:
        prefixes = ['vm.mmap_rnd_bits']
    else:
        prefixes = ['net.ipv4.tcp_rmem']
    sysctl = get_sysctl(module, prefixes)

    my_env = os.environ.copy()
    # force LC_ALL to C - buggy libc needs this

# Generated at 2022-06-23 00:32:39.445556
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Test script for Ansible module utils function: get_sysctl
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ["net.ipv4.ip_forward", "net.ipv4.conf.all.rp_filter"])

    assert sysctl == {
        "net.ipv4.ip_forward": "1",
        "net.ipv4.conf.all.rp_filter": "1"
    }

# Generated at 2022-06-23 00:32:48.393099
# Unit test for function get_sysctl
def test_get_sysctl():
    """Tests for the get_sysctl function"""
    module = FakeModule()
    module.run_command = lambda x: (0, 'key=value\nkey2: value2\nkey3=\nkey4: ', '')
    module.get_bin_path = lambda x: x
    sysctl = get_sysctl(module, ('-a',))
    assert sysctl['key'] == 'value'
    assert sysctl['key2'] == 'value2'
    assert sysctl['key3'] == ''
    assert sysctl['key4'] == ''


# Generated at 2022-06-23 00:32:51.197336
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:32:59.125427
# Unit test for function get_sysctl
def test_get_sysctl():
    (changed, out) = get_sysctl(None, ['-a'])
    assert(type(changed) == dict)
    assert(changed != {})

    (changed, out) = get_sysctl(None, ['-a', 'vm'])
    assert(type(changed) == dict)
    assert(changed != {})

    (changed, out) = get_sysctl(None, ['-a', 'nfs'])
    assert(type(changed) == dict)
    assert(changed != {})

    (changed, out) = get_sysctl(None, ['-a', 'nfs.foobar'])
    assert(type(changed) == dict)
    assert(changed == {})

# Generated at 2022-06-23 00:33:10.291137
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    test_cases = dict(
        test1='net.ipv4.ip_forward = 0',
        test2='net.ipv4.ip_forward=0',
        test3=' net.ipv4.ip_forward = 0',
        test4='net.ipv4.ip_forward\t= 0',
        test5='net.ipv4.conf.all.rp_filter = 1',
        test6='net.ipv4.conf.all.rp_filter: 1',
        )

    sysctl = get_sysctl(module, list(test_cases.keys()))

    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-23 00:33:22.219359
# Unit test for function get_sysctl
def test_get_sysctl():
    # Simple test
    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ['foo.bar'])
    assert sysctl == {'foo.bar': '1'}
    module.run_command.assert_called_once_with(['sysctl', '-n', 'foo.bar'])

    # Multiple lines
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, 'foo.bar: 0\nbar.baz: 1\n', '')
    sysctl = get_sysctl(module, ['foo.bar', 'bar.baz'])
    assert sysctl == {'foo.bar': '0', 'bar.baz': '1'}

# Generated at 2022-06-23 00:33:33.569436
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:33:43.993859
# Unit test for function get_sysctl
def test_get_sysctl():
    test_sysctl_values = dict()
    test_sysctl_values['vm.overcommit_memory'] = "1"
    test_sysctl_values['kernel.hostname'] = "testhost"

# Generated at 2022-06-23 00:33:54.557780
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()
    module.run_command = lambda x: ([0, 'kernel.sysrq\t= 1\n' +
                                        'kernel.core_pattern = core\n' +
                                        'kernel.core_uses_pid = 1\n' +
                                        'net.core.somaxconn = 1024\n' +
                                        'kernel.core_uses_pid = 1\n' +
                                        'kernel.printk = 4 4 1 7\n'], None, None)
    module.get_bin_path = lambda x: x
    sysctl_out = get_sysctl(module, ['kernel.*', 'net.core.somaxconn'])

    assert(sysctl_out.get('kernel.sysrq') == '1')

# Generated at 2022-06-23 00:34:04.101961
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Note: this test uses a mock module to avoid the overhead of actually calling sysctl.
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.module_utils.parsing.convert_bool import boolean
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    basic._ANSIBLE_ARGS = lambda x: True
    boolean('yes')


# Generated at 2022-06-23 00:34:14.948149
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    module = AnsibleModule(
        argument_spec = dict(),
    )

    if not module.run_command_environ_update.get('LANG', '').startswith('C'):
        module.warn('The current locale is not C. This may cause unexpected results when running the sysctl command because of parsing issues.')

    try:
        sysctl = get_sysctl(module, ['vm.swappiness'])
    except Exception as e:
        module.fail_json(msg=get_exception())
    if sysctl:
        module.exit_json(changed=False, sysctl=sysctl)
    else:
        module.fail_json(msg="Unable to read sysctl")


# Generated at 2022-06-23 00:34:24.375514
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = lambda a: (0, 'key1: value1\nkey2: value2\nkey3: multiline value\n  this is the same value\nkey4:', '')
    result = get_sysctl(module, ['key1', 'key2', 'key3', 'key4'])
    assert result == dict(key1='value1', key2='value2', key3='multiline value\nthis is the same value', key4='')

# Generated at 2022-06-23 00:34:31.539607
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    mock module, get_sysctl should return a dictionary with keys for
    'net.ipv4.conf.all.forwarding' and 'net.ipv4.conf.all.mc_forwarding'
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, 'net.ipv4.conf.all.forwarding = 1\nnet.ipv4.conf.all.mc_forwarding = 0', '')
    module.get_bin_path = lambda *args, **kwargs: 'sysctl'
    prefixes = ['net.ipv4.conf.all.forwarding', 'net.ipv4.conf.all.mc_forwarding']


# Generated at 2022-06-23 00:34:41.848133
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    (actual_result, actual_rc) = get_sysctl(module, ['kern.boottime'])

    assert actual_rc == 0
    assert actual_result['kern.boottime'] is not None

    (actual_result, actual_rc) = get_sysctl(module, ['kern.garbage'])
    assert actual_rc != 0

    (actual_result, actual_rc) = get_sysctl(module, ['kern.boottime', 'kern.garbage'])
    assert actual_rc == 0
    assert actual_result['kern.boottime'] is not None
    assert actual_result['kern.garbage'] is None

    
if __name__ == '__main__':
    from ansible.module_utils.basic import *



# Generated at 2022-06-23 00:34:53.494054
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_output = """kernel.hostname: localhost
kernel.msgmax: 8192
vm.swappiness: 10
net.ipv4.conf.all.forwarding: 1
net.ipv4.conf.all.mc_forwarding: 0
net.ipv4.conf.default.accept_source_route: 0
net.ipv4.conf.default.forwarding: 0
net.ipv4.conf.default.mc_forwarding: 0
net.ipv4.conf.lo.accept_source_route: 0
net.ipv4.conf.lo.forwarding: 0
net.ipv4.conf.lo.mc_forwarding: 0
vm.overcommit_memory: 0
"""

    sysctl = get_sysctl(sysctl_output)

# Generated at 2022-06-23 00:35:04.643194
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.collections.community.network.tests.unit.compat.mock import patch, MagicMock

    module = MagicMock()
    module.run_command.return_value = (0, """kernel.randomize_va_space = 1
net.core.rmem_default = 262144
sysctl.conf (END)
""", "")

    result = get_sysctl(module, ['kernel.randomize_va_space', 'net.core.rmem_default'])
    assert result['kernel.randomize_va_space'] == '1'
    assert result['net.core.rmem_default'] == '262144'
    module.run_command.assert_called_once_with(['sysctl', 'kernel.randomize_va_space', 'net.core.rmem_default'])



# Generated at 2022-06-23 00:35:11.760203
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import populated_facts

    test_module = AnsibleModule({'ANSIBLE_MODULE_ARGS': {}})
    test_module.params = {}

    sysctl_data = populated_facts(test_module)[0].get('ansible_sysctl', {})
    assert 'kernel.osrelease' in sysctl_data
    assert 'net' in sysctl_data

# Generated at 2022-06-23 00:35:21.315192
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_cmd = '/sbin/sysctl'

    results = get_sysctl(sysctl_cmd, ['-n', 'net.ipv4.ip_forward'])
    assert results == {'net.ipv4.ip_forward': '0'}

    results = get_sysctl(sysctl_cmd, ['-a', 'net.ipv4.conf.all'])

# Generated at 2022-06-23 00:35:31.810684
# Unit test for function get_sysctl
def test_get_sysctl():
    test_get_sysctl = dict(processes='75295',
                           kptr_restrict='2',
                           kernel='Darwin',
                           hostname='macbook-pro-3.local',
                           osrelease='14.3.0',
                           version='Darwin Kernel Version 14.3.0: Mon Mar 23 11:59:05 PDT 2015; root:xnu-2782.20.48~5/RELEASE_X86_64',
                           domainname='(none)',
                           users='24',
                           ostype='Darwin',
                           maxproc='10240',
                           user_reserve_kbytes='143360',
                           nx='y')

    mod = AnsibleModule(argument_spec=dict())

    assert get_sysctl(mod, ['kern.']) == test

# Generated at 2022-06-23 00:35:37.665252
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    module = AnsibleModule({})
    # check return code and stderr
    try:
        sysctls = get_sysctl(module, ['-a'])
        assert len(sysctls) > 100
    except Exception:
        assert False, get_exception()
    # check return code with bad prefix
    try:
        sysctls = get_sysctl(module, ['foo'])
        assert len(sysctls) == 0
    except Exception:
        assert False, get_exception()

# Generated at 2022-06-23 00:35:41.414427
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({'run_command': lambda x: (0, "a = b\nc.d: e\n\nf.g: h\ni.j.k = l", None)},
                      ['a', 'b', 'c.d']) == {'a': 'b', 'c.d': 'e', 'f.g': 'h'}



# Generated at 2022-06-23 00:35:46.423110
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': dict(type='list')})
    prefixes = ['net.ipv4.ip_forward']
    assert get_sysctl(module, prefixes) == {'net.ipv4.ip_forward': '0'}

# vim: se sw=4 ts=4 et ft=python :

# Generated at 2022-06-23 00:35:50.777302
# Unit test for function get_sysctl
def test_get_sysctl():
    """ Unit tests for function get_sysctl
    """
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.loadavg'])
    assert sysctl == {'vm.loadavg': '[0.08 0.09 0.03]'}

# Generated at 2022-06-23 00:35:56.339237
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    M = basic.AnsibleModule({})
    result = get_sysctl(M, ["net.ipv4.ip_forward", "net.ipv4.conf.all.forwarding"])
    assert result == {u'net.ipv4.ip_forward': u'0', u'net.ipv4.conf.all.forwarding': u'0'}


# Generated at 2022-06-23 00:36:09.053616
# Unit test for function get_sysctl
def test_get_sysctl():
    is_valid_sysctl = True
    sysctl_cmd = 'sysctl'
    prefixes = ['-a']
    cmd = [sysctl_cmd]
    cmd.extend(prefixes)

    sysctl = dict()

    try:
        rc, out, err = module.run_command(cmd)
    except (IOError, OSError) as e:
        module.warn('Unable to read sysctl: %s' % to_text(e))

    if rc == 0:
        key = ''
        value = ''
        for line in out.splitlines():
            if not line.strip():
                continue


# Generated at 2022-06-23 00:36:10.282988
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl([]);



# Generated at 2022-06-23 00:36:19.897518
# Unit test for function get_sysctl
def test_get_sysctl():
    import module_utils.basic
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Test get_sysctl
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert (len(sysctl) == 1)
    assert (sysctl['vm.swappiness'] == '0')

    # Test get_sysctl with multiple args
    sysctl = get_sysctl(module, ['vm.swappiness', 'fs.file-max'])
    assert (len(sysctl) == 2)
    assert (sysctl['vm.swappiness'] == '0')
    assert (sysctl['fs.file-max'] == '792777')

    # Test

# Generated at 2022-06-23 00:36:31.118547
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    import os

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_prefixes = ['kernel.hostname', 'kernel.somevaluethatisnotreallythere']
    sysctl_cmd = get_bin_path(module, 'sysctl')

    if sysctl_cmd and os.path.exists(sysctl_cmd):
        sysctl = get_sysctl(module, test_prefixes)
        assert sysctl['kernel.hostname'] == 'localhost'
        assert sysctl.get('kernel.somevaluethatisnotreallythere', None) == None
    else:
        assert True

# Generated at 2022-06-23 00:36:34.308182
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    result = get_sysctl(module, prefixes=["kernel.ostype"])
    assert result["kernel.ostype"] == "Linux"

# Generated at 2022-06-23 00:36:41.838761
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils
    import ansible.module_utils.basic

    sysctl_lines = '''
net.ipv4.ip_forward = 1
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.default.secure_redirects = 0
'''

    sysctl_lines2 = '''
net.ipv4.ip_forward = 1
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.default.secure_redirects = 0

fs.aio-max-nr = 1048576
fs.file-max = 6815744
'''


# Generated at 2022-06-23 00:36:51.802153
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (object,), dict())
    module.run_command = lambda cmd: (0, 'foo = bar\nbaz: qux\nspam = eggs\n', '')
    sysctl = get_sysctl(module, ['foo', 'baz'])

    assert sysctl == { 'foo': 'bar', 'baz': 'qux' }

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        )
    )

    sysctl = get_sysctl(module, module.params['prefixes'])

    module.exit_json(changed=False, sysctl=sysctl)

# Generated at 2022-06-23 00:37:01.770607
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=True, type='list'),
        ),
    )

    result = get_sysctl(module, [])
    assert module.fail_json.called
    assert 'Unable to read sysctl' in module.fail_json.call_args[0][1]

    result = get_sysctl(module, ['a', 'nonexistent', 'prefix'])
    assert module.exit_json.called
    assert len(result) == 0

    result = get_sysctl(module, ['a', 'b', 'c', 'd'])
    assert module.exit_json.called
    assert len(result) == 4
    assert 'a' in result
    assert 'b'

# Generated at 2022-06-23 00:37:10.782080
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import tempfile
    import shutil
    import os
    fake_sysctl_output = b'''
kernel.version:
    #1 SMP Thu Feb 4 12:21:05 EST 2016
net.ipv4.conf.all.rp_filter: 0
net.ipv4.conf.default.rp_filter: 0
net.ipv4.conf.lo.rp_filter: 0
'''

    module_args = {}
    tmp_path = tempfile.mkdtemp()
    f = open(os.path.join(tmp_path, 'sysctl'), 'w')
    f.write('#!/bin/sh\necho -e "%s"\n' % fake_sysctl_output)
    f.close()