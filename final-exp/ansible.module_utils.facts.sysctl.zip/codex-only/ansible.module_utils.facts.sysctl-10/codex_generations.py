

# Generated at 2022-06-23 00:27:18.945043
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    # This is necessary since this test module is placed in a path that's not
    # part of sys.path.
    import os
    import sys
    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(test_dir)

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # Check normal paths
    env_var = dict()
    result = dict()
    result['kernel.domainname'] = 'ansible.com'
    result['kernel.fqdn'] = 'ansible.com'
    result['kernel.hostname'] = 'ansible'


# Generated at 2022-06-23 00:27:29.402755
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    # Create mock module object
    module = AnsibleModule(argument_spec={})

    # Mock sysctl command output
    rc = 0

# Generated at 2022-06-23 00:27:38.499830
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Function to test get_sysctl function.
    Returns ok if sysctl value matches expected value.
    Returns fail if sysctl value does not match expected value.
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    result = get_sysctl(module, ["net.ipv4.conf.all.rp_filter"])
    if result['net.ipv4.conf.all.rp_filter'] == '1':
        print("ok")
    else:
        print("fail")

if __name__ == "__main__":
    test_get_sysctl()

# Generated at 2022-06-23 00:27:42.898442
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    result = get_sysctl(module, ['vm.'])
    assert result['vm.max_map_count'] == '262144'
    assert result['vm.vdso_enabled'] == '1'

# Generated at 2022-06-23 00:27:52.097472
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )


# Generated at 2022-06-23 00:27:58.512431
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule({})
    path = get_bin_path(module, 'sysctl')

    if path:
        sysctl_output = get_sysctl(module, [])
        assert 'fs.file-max' in sysctl_output
        assert 'kernel.panic' in sysctl_output
    else:
        assert True

# Generated at 2022-06-23 00:28:09.927483
# Unit test for function get_sysctl
def test_get_sysctl():
    dummy_module = DummyAnsibleModule()

# Generated at 2022-06-23 00:28:17.245773
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    # hack to make this test work on python3
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    class FakeModule:
        def __init__(self):
            self.bin_path = dict()

        def get_bin_path(self, bin_path):
            return self.bin_path[bin_path]

        def run_command(self, cmd):
            if cmd[0] == '/sbin/sysctl':
                stdout = StringIO("foo = bar\nbar:\tbaz\tblah\nfoo.bar = \nquz")
                return 0, stdout.read(), ''

# Generated at 2022-06-23 00:28:28.632536
# Unit test for function get_sysctl
def test_get_sysctl():
    # Create a fake module for testing
    from ansible.module_utils import basic
    fake_module = basic.AnsibleModule(argument_spec={})

    # Get output from 'sysctl -a'
    cmd = ['/usr/sbin/sysctl', '-a']
    try:
        rc, out, err = fake_module.run_command(cmd)
    except (IOError, OSError) as e:
        rc = 1

    # Get sysctl dictionary
    sysctl_dict = get_sysctl(fake_module, [])

    # get_sysctl() should return a dictionary. Ignore if something else is returned.
    if type(sysctl_dict) != dict:
        print('Not a dictionary')

    # Check if get_sysctl() returned the correct output for 'sysctl -a'

# Generated at 2022-06-23 00:28:32.182335
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test to see if sysctl exists (doesn't blow up)
    from ansible.module_utils.basic import AnsibleModule
    assert get_sysctl(AnsibleModule(argument_spec={}), []) is not None


# Generated at 2022-06-23 00:28:43.400231
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    # my_sysctl_mock takes minimum arguments required for __init__ function of
    # AnsibleModule class
    def my_sysctl_mock(self, *args, **kwargs):
        pass

    # my_run_command_mock takes minimum arguments required for run_command
    # function of AnsibleModule class
    def my_run_command_mock(self, *args, **kwargs):
        sysctl_cmd = args[0]

        if sysctl_cmd == ['/sbin/sysctl']:
            # return sysctl output as is
            return 0, '''net.ipv4.ip_forward = 1
net.ipv4.conf.default.rp_filter = 1

kernel.sysrq = 0
''', ''


# Generated at 2022-06-23 00:28:54.912178
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    sysctl_cmd = 'sysctl'
    prefixes = ['-a', 'hw']
    cmd = [sysctl_cmd]
    cmd.extend(prefixes)

    sysctl = dict()

    try:
        rc, out, err = os.popen3(cmd)
    except (IOError, OSError) as e:
        print('Unable to read sysctl: %s' % to_text(e))
        rc = 1

    if rc == 0:
        key = ''
        value = ''
        for line in out.splitlines():
            if not line.strip():
                continue


# Generated at 2022-06-23 00:28:57.997426
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('/sbin/sysctl -n') == {
        'debug.mac.hw_gc_heapsize': '0',
        'debug.mac.hw_gc_heapsize_max': '67108864',
        'debug.nvme.list_pci': '1',
        'debug.nvme.tracelog': '0'
    }

# Generated at 2022-06-23 00:29:03.529648
# Unit test for function get_sysctl
def test_get_sysctl():
    try:
        from ansible.module_utils.basic import AnsibleModule
        has_ansible = True
    except (ImportError, SyntaxError):
        has_ansible = False

    # Test function with AnsibleModule
    if has_ansible:
        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
        )

        assert get_sysctl(module, ['net.ipv4.tcp_syncookies']) == {'net.ipv4.tcp_syncookies': '1'}


# Generated at 2022-06-23 00:29:13.900798
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins  # pylint: disable=import-error
    else:
        import builtins

    class MyModule(object):
        def __init__(self, fail_command=False, fail_open=False):
            self.fail_command = fail_command
            self.fail_open = fail_open

        def warn(self, msg):
            print(msg)

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'sysctl':
                return '/usr/bin/sysctl'
            else:
                return None

        def run_command(self, cmd):
            if self.fail_command:
                raise Exception('failed by request')

# Generated at 2022-06-23 00:29:22.403142
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
        Test function get_sysctl
    '''
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.default.rp_filter = 1', ''))
    result = get_sysctl(test_module, ['net.ipv4.ip_forward', 'net.ipv4.conf.default.rp_filter'])
    assert result == {'net.ipv4.ip_forward': '1', 'net.ipv4.conf.default.rp_filter': '1'}


# Generated at 2022-06-23 00:29:33.302524
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (object, ), {'run_command': run_command})
    sysctl_cmd = ''

    # Test basic sysctl functionality

# Generated at 2022-06-23 00:29:40.518674
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.sysctl import get_sysctl

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = dict()
            for k, v in kwargs.items():
                setattr(self, k, v)

        def get_bin_path(self, path):
            return 'sysctl'

        def run_command(self, cmd):
            return 0, self.output, ''

    def ansible_module(name, **kwargs):
        return AnsibleModule(
            argument_spec=dict(name=dict(type='str')),
            supports_check_mode=True
        )


# Generated at 2022-06-23 00:29:49.217852
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list', required=True)))
    module.run_command = MagicMock()
    module.run_command.return_value = 0, '', ''
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = '/usr/bin/sysctl'

    with patch('os.read', side_effect=OSError):
        with pytest.raises(AnsibleFailJson):
            get_sysctl(module, ['a', 'b', 'c'])

    with patch('os.read', return_value='Hello\nWorld!'):
        result = get_sysctl(module, ['a', 'b', 'c'])
        assert result == {'Hello': 'World!'}


# Generated at 2022-06-23 00:29:55.192029
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = ['vm.swappiness', 'kernel.shmmax']
    sysctl = get_sysctl(module, prefixes)

    # test if the sysctl names and values exist
    assert 'vm.swappiness' in sysctl
    assert 'kernel.shmmax' in sysctl
    assert sysctl['kernel.shmmax'] > 0
    assert sysctl['vm.swappiness'] >= 0

# Generated at 2022-06-23 00:30:04.648502
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.params = dict(
                prefixes=['net.ipv4.ip_forward'],
                run_command_check=True,
                bin_path_message=True,
                missing_bin_path_is_fatal=True,
                fail_on_missing=False,
                data=dict(
                    paths=['/sbin'],
                ),
            )


# Generated at 2022-06-23 00:30:15.775497
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import subprocess

    sysctl = dict()

    sysctl['vm.swappiness'] = '60'
    sysctl['vm.max_map_count'] = '65530'
    sysctl['vm.dirty_background_ratio'] = '0'
    sysctl['net.ipv4.tcp_keepalive_time'] = '120'

    for key in sysctl:
        value = sysctl[key]

        cmd = ['/sbin/sysctl', key]
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        if p.wait() != 0:
            raise Exception(p.stderr.read())


# Generated at 2022-06-23 00:30:23.301988
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test helper functions import
    from ansible.module_utils.basic import AnsibleModule

    # Setup simple test
    module = AnsibleModule({}, {'prefixes': ['net.ipv4.conf.all.rp_filter',
                                              'net.ipv4.conf.default.rp_filter',
                                              'net.ipv4.conf.eth0.rp_filter']})

    get_sysctl(module, module.params['prefixes'])


# ===========================================
# Main
#


# Generated at 2022-06-23 00:30:32.362645
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:30:37.310883
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'search': {'required': True}})
    assert 'net.ipv4.ip_forward' in get_sysctl(module, ['net.ipv4.ip_forward'])


# Generated at 2022-06-23 00:30:47.002140
# Unit test for function get_sysctl
def test_get_sysctl():
    # Note: unihost.sh is used to run this test, where we patch the
    # ansible.utils.module_loader module to import directly from the module
    # path in order to execute this module without installing the module.
    from ansible.utils.module_loader import get_all_file_names
    all_files = get_all_file_names('.')

    # ensure the module was found in the '.' directory
    assert('sysctl.py' in all_files)

    # now import the sysctl module to call the function get_sysctl
    import sysctl
    sysctl_module = sysctl.SysctlModule(argument_spec={}, bypass_checks=True)
    prefixes = ['kern.ostype', 'kern.osrelease']

# Generated at 2022-06-23 00:30:53.307333
# Unit test for function get_sysctl
def test_get_sysctl():
    # call get_sysctl with a non-existing key
    # return value should be empty
    prefixes = ['net.bridge.bridge-nf-call-ip6tables']
    sysctl = get_sysctl(prefixes)
    assert len(sysctl) == 0

    # call get_sysctl with existing net.* prefix
    # return value should be non-empty
    prefixes = ['net.*']
    sysctl = get_sysctl(prefixes)
    assert len(sysctl) > 0

    # call get_sysctl with non existing net.* prefix
    # return value should be empty
    prefixes = ['net.*.fail']
    sysctl = get_sysctl(prefixes)
    assert len(sysctl) == 0

# Generated at 2022-06-23 00:30:57.929441
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    sysctl = get_sysctl(module, ['kernel.osrelease', 'kernel.ostype'])
    assert sysctl['kernel.osrelease'] == '3.10.0-327.el7.x86_64'
    assert sysctl['kernel.ostype'] == 'Linux'


# Generated at 2022-06-23 00:31:02.395539
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    results = get_sysctl(module, ['vm.swappiness'])
    assert results['vm.swappiness'] == '60'

# Generated at 2022-06-23 00:31:14.062384
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('AnsibleModule', (object,), {})

# Generated at 2022-06-23 00:31:25.985397
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = {
            'name': {'required': True},
        },
    )

    module.run_command = MagicMock(return_value=(0, 'kern.hostname: gateway.example.com', ''))
    prefixes = ['kern.hostname']
    result = get_sysctl(module, prefixes)
    assert result == {'kern.hostname': 'gateway.example.com'}

    module.run_command = MagicMock(return_value=(0, 'kern.hostname: gateway.example.com\nkern.version: (null)', ''))
    prefixes = ['kern.hostname', 'kern.version']

# Generated at 2022-06-23 00:31:30.671271
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['fs.protected_hardlinks', 'net.ipv4.ip_forward'])
    assert sysctl == {"fs.protected_hardlinks": "1", "net.ipv4.ip_forward": "0"}



# Generated at 2022-06-23 00:31:39.514314
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    # Should return a dictionary of key/value pairs
    module = basic.AnsibleModule(
        argument_spec=dict(),
    )
    keys = ['kernel.random.uuid', 'kernel.random.boot_id']
    assert get_sysctl(module, keys) == {'kernel.random.uuid': 'f7c3b16d-9cdb-4040-b2f3-3fe3e8642fdf', 'kernel.random.boot_id': 'c63fd47b-0f48-4d51-b5fb-144e8b0c0a93'}

# Generated at 2022-06-23 00:31:51.768919
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = AnsibleModule(argument_spec=dict())

    expected_out = dict(
        net=dict(
            ipv4=dict(
                tcp_tw_recycle=dict(key='net.ipv4.tcp_tw_recycle', value='0'),
                ip_forward=dict(key='net.ipv4.ip_forward', value='0'),
            ),
        ),
        kern=dict(
            cptime=dict(key='kern.cptime', value='1566691478'),
        ),
    )
    sysctl = get_sysctl(test_module, ['net.ipv4.tcp_tw_recycle', 'net.ipv4.ip_forward', 'kern.cptime'])
    assert sysctl == expected_out

# Unit test

# Generated at 2022-06-23 00:32:01.328017
# Unit test for function get_sysctl
def test_get_sysctl():
    import module_utils.basic
    import ansible.module_utils.facts.system.sysctl

    m = module_utils.basic.AnsibleModule(
        argument_spec = dict(),
    )

    # Test the key prefix.
    kern = ansible.module_utils.facts.system.sysctl.get_sysctl(m, ['kern'])
    assert kern['kern.hostname'] == 'localhost'

    # Test the full key.
    hostname = ansible.module_utils.facts.system.sysctl.get_sysctl(m, ['kern.hostname'])
    assert hostname['kern.hostname'] == 'localhost'

# Generated at 2022-06-23 00:32:12.767927
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import MockModule

    class MockAnsibleModule(MockModule, AnsibleModule):
        pass

    def make_mock_module(params):
        m = MockAnsibleModule(params=params)
        m.run_command = run_command
        return m

    def make_mock_result(rc=0, out='', err=''):
        return dict(
            rc=rc,
            stdout=out,
            stderr=err,
        )


# Generated at 2022-06-23 00:32:13.644149
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, 'test') == {}

# Generated at 2022-06-23 00:32:25.361894
# Unit test for function get_sysctl
def test_get_sysctl():
    import re

    # tests will only run if we're running under test harness
    # pylint: disable=undefined-variable
    if 'ANSIBLE_TEST_HARNESS' not in os.environ:
        return

    def _run_cmd(*args, **kwargs):
        # pylint: disable=unused-argument
        return 0, OUTPUT, ''

    def _get_sysctl(module, prefixes):
        return get_sysctl(module, prefixes)


# Generated at 2022-06-23 00:32:29.702729
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'prefixes':{'type':'list', 'required':True}})

    module.ensure_type({'prefixes':'list'}, 'foo')


# Generated at 2022-06-23 00:32:39.765389
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    from ansible.module_utils import basic

    if os.getuid() != 0:
        from nose.plugins.skip import SkipTest
        raise SkipTest("must run as root")

    test_sysctl_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-23 00:32:46.483265
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    sysctl = get_sysctl(module, ['net.ipv6.conf.all.forwarding'])
    assert len(sysctl) == 1
    assert sysctl['net.ipv6.conf.all.forwarding'] == '0'


# Generated at 2022-06-23 00:32:51.631053
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type("obj", (object,), dict(run_command=run_command))
    module.get_bin_path = lambda x: 'sysctl'

    sysctl = get_sysctl(module, ['kern.version'])
    assert sysctl['kern.version'].startswith('Darwin Kernel Version')

# Generated at 2022-06-23 00:32:57.054634
# Unit test for function get_sysctl
def test_get_sysctl():
    test_prefixes = ['net.ipv4.tcp_tw_reuse', 'net.ipv4.route.flush']

# Generated at 2022-06-23 00:33:01.210350
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Test to ensure that the get_sysctl function is working.
    '''
    assert get_sysctl('net.ipv4.ip_forward') == '1'


# Generated at 2022-06-23 00:33:12.042810
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 00:33:23.667474
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = MockModule()
    test_module.run_command = Mock(return_value=(0, sysctl_out, ''))
    test_module.get_bin_path = Mock(return_value='/bin/true')

    prefixes = ['kernel.randomize_va_space', 'fs.aio-max-nr']
    result = get_sysctl(test_module, prefixes)
    assert result['fs.aio-max-nr'] == '1048576'
    assert result.get('fs.something') is None
    assert result.get('kernel.randomize_va_space') == '2'


# Generated at 2022-06-23 00:33:27.465954
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
        'a=1\nb: 2\nc:\n 3'))

    assert {'a': '1', 'b': '2', 'c': '3'} == get_sysctl(module, ['a', 'b', 'c'])


# Generated at 2022-06-23 00:33:33.304678
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six.moves import builtins

    module = basic.AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list'),
        ),
        supports_check_mode=True,
    )

    if not module.check_mode:
        sysctl = get_sysctl(module, prefixes=['kern'])
        assert isinstance(sysctl, Mapping)
        assert "kern.securelevel" in sysctl
        assert sysctl["kern.securelevel"] == "0"


# Generated at 2022-06-23 00:33:41.063087
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    module.params = {}
    module.warn = lambda msg: print(msg, file=sys.stderr)
    module.run_command = lambda cmd: ((0, 'kern.hostname = be.freebsd.org\nkern.ostype = FreeBSD\n', ''), 0)
    sysctl = get_sysctl(module, ['kern.*'])
    assert sysctl["kern.hostname"] == "be.freebsd.org"
    assert sysctl["kern.ostype"] == "FreeBSD"


# Generated at 2022-06-23 00:33:45.889905
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['net.bridge.bridge-nf-call-ip6tables', 'net.bridge.bridge-nf-call-iptables']) == {
        'net.bridge.bridge-nf-call-ip6tables': '0',
        'net.bridge.bridge-nf-call-iptables': '0'
    }

# Generated at 2022-06-23 00:33:55.236425
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    assert module.get_bin_path('true')

    results = get_sysctl(module, ['kernel.hostname', 'fs.file-max'])
    assert results['kernel.hostname'] == 'localhost'
    assert int(results['fs.file-max']) > 0

    results = get_sysctl(module, [])
    assert len(results) > 0

    results = get_sysctl(module, ['kernel.hostname'])
    assert results == dict(kernel_hostname='localhost')

# Generated at 2022-06-23 00:34:01.638684
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    try:
        sysctl_out = get_sysctl(module, "".split())
    except Exception as e:
        module.fail_json(msg="get_sysctl test failed with exception %s" % to_text(e))
    assert isinstance(sysctl_out, dict)
    return sysctl_out


# Generated at 2022-06-23 00:34:13.054837
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors


# Generated at 2022-06-23 00:34:24.491080
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    if sys.version_info[0] > 2:
        # Python 3
        from unittest.mock import patch
        from io import StringIO
    elif sys.version_info[0] < 3:
        # Python 2
        from mock import patch
        from StringIO import StringIO

    from ansible.module_utils.basic import AnsibleModule

    sysctl_mock = StringIO('''
errors = 0
net.bridge.bridge-nf-call-arptables = 0
net.bridge.bridge-nf-call-iptables = 0
net.bridge.bridge-nf-call-ip6tables = 0
kernel.modules_disabled = 1
kernel.sysrq = 0
kernel.core_uses_pid = 1
''')

    # Fill in the expected value for this to work.

# Generated at 2022-06-23 00:34:27.061836
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl = get_sysctl(module, ['kern.bootfile'])

    assert sysctl == {'kern.bootfile': '/kernel'}

# Generated at 2022-06-23 00:34:27.791453
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl() == ''

# Generated at 2022-06-23 00:34:37.329702
# Unit test for function get_sysctl
def test_get_sysctl():
    class MockModule():
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, arg):
            return '/sbin/sysctl'


# Generated at 2022-06-23 00:34:42.112779
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule({})

    sysctl = get_sysctl(module, ['machdep.cpu.brand_string'])

    assert isinstance(sysctl, dict)
    assert sysctl.has_key('machdep.cpu.brand_string')

# Generated at 2022-06-23 00:34:44.854266
# Unit test for function get_sysctl
def test_get_sysctl():
    result = get_sysctl('test', ['vm.swappiness'])
    assert result['vm.swappiness'] == '1'

# Generated at 2022-06-23 00:34:50.067181
# Unit test for function get_sysctl
def test_get_sysctl():
    """Test function for get sysctl"""
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule({})

    sysctl_out = 'net.ipv4.ip_forward = 0\nnet.ipv6.conf.all.forwarding = 0\nnet.ipv6.conf.default.forwarding = 0\nnet.ipv6.conf.eth0.forwarding = 0'
    try:
        mod.run_command = lambda x: (0, sysctl_out, '')
    except TypeError:
        mod.run_command = lambda x: (0, sysctl_out, '')
        pass

    sysctl = get_sysctl(mod, ['net.ipv4'])
    assert sysctl == {'net.ipv4.ip_forward': '0'}

# Generated at 2022-06-23 00:35:00.242831
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import load_platform_subclass
    from ansible.module_utils.facts.system.sysctl import Sysctl

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(aliases=['key']),
            value=dict()
        ),
        supports_check_mode=True
    )

    platform = sysctl = load_platform_subclass(Sysctl, module, 'BSD')()
    sysctl_dict = platform.populate()

    print(to_text(sysctl_dict))

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

if __name__ == '__main__':
    test_get_sys

# Generated at 2022-06-23 00:35:04.674134
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': {'type': 'list', 'required': True}})
    sysctl = get_sysctl(module, ['vm.overcommit_memory'])
    assert sysctl['vm.overcommit_memory'] == '0'



# Generated at 2022-06-23 00:35:16.099505
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_cmd = '/sbin/sysctl'
    prefixes = ['-a']
    cmd = [sysctl_cmd]
    cmd.extend(prefixes)

    sysctl = dict()

    #rc, out, err = module.run_command(cmd)
    #assert rc == 0


# Generated at 2022-06-23 00:35:21.909509
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname', 'vm.swappiness'])

    assert len(sysctl)
    assert sysctl['kernel.hostname'].startswith('ansible')
    assert sysctl['vm.swappiness'].isdigit()



# Generated at 2022-06-23 00:35:23.348668
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('kernel.domainname') == 'localhost'

# Generated at 2022-06-23 00:35:33.590517
# Unit test for function get_sysctl
def test_get_sysctl():
    import_module = __import__('ansible.module_utils.basic', globals(), locals(), ['AnsibleModule'])
    AnsibleModule = import_module.AnsibleModule
    import ansible.module_utils.basic

# Generated at 2022-06-23 00:35:45.188392
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockAnsibleModule()

    module.run_command = mock_run_command
    module.get_bin_path = mock_get_bin_path
    sysctl = get_sysctl(module, ['mib1', 'mib2'])

    assert len(sysctl) == 5
    assert 'mib1.mib2.var1' in sysctl
    assert sysctl['mib1.mib2.var1'] == 'foo1'
    assert 'mib1.mib2.var2' in sysctl
    assert sysctl['mib1.mib2.var2'] == 'foo2'
    assert 'mib1.mib3.var3' in sysctl
    assert sysctl['mib1.mib3.var3'] == 'foo3'

# Generated at 2022-06-23 00:35:49.027059
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    # Testing
    prefixes = ['debug', 'kern']
    actual = get_sysctl(module, prefixes)
    assert isinstance(actual, dict)
    assert actual

# Generated at 2022-06-23 00:35:58.416788
# Unit test for function get_sysctl
def test_get_sysctl():
    import StringIO

    syscmd_mock = StringIO.StringIO()

    syscmd_mock.write('kernel.sem = 250  32000 32  256\n')
    syscmd_mock.write('net.ipv4.ip_forward: 1\n')
    syscmd_mock.write('net.ipv4.conf.all.accept_redirects = 0\n')
    syscmd_mock.write('net.ipv4.conf.all.accept_redirects:  0\n')
    syscmd_mock.write('net.ipv4.conf.default.accept_source_route = 0\n')
    syscmd_mock.write('net.ipv4.conf.default.accept_source_route: 0\n')
    syscmd

# Generated at 2022-06-23 00:36:06.005340
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=['kernel']),
        ),
    )
    prefixes = module.params.get('prefixes')

    sysctl = get_sysctl(module, prefixes)
    assert 'kernel' in '\n'.join(sysctl.keys())
    assert 'panics' in sysctl.keys()
    assert 'reboot-on-panic' in sysctl.keys()

# Generated at 2022-06-23 00:36:16.548027
# Unit test for function get_sysctl
def test_get_sysctl():
    class MockModule:
        def __init__(self):
            self.params = {
                'debug': True,
            }

        def run_command(self, cmd):
            self.runcmd = cmd
            out = '''
net.bridge.bridge-nf-call-ip6tables = 0
net.bridge.bridge-nf-call-iptables = 0
net.bridge.bridge-nf-call-arptables = 0
net.ipv4.ip_forward = 0
'''
            # return rc, out, err
            return 0, out, ''

        def get_bin_path(self, cmd):
            return cmd

        def warn(self, msg):
            self.warnmsg = msg

    m = MockModule()

# Generated at 2022-06-23 00:36:22.399824
# Unit test for function get_sysctl
def test_get_sysctl():
    module = get_module()
    prefixes = ['kern.ccversion']
    result = get_sysctl(module, prefixes)
    # I don't really want to return the full version string here, but I don't
    # know what else to test.
    assert 'kern.ccversion' in result

# AnsibleModule class is defined in ansible.module_utils.basic

# Generated at 2022-06-23 00:36:32.766964
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    assert get_sysctl(module, ['net.ipv4.ip_forward=1']) == {}
    assert get_sysctl(module, ['net.ipv4.ip_forward:1']) == {}
    assert get_sysctl(module, ['net.ipv4.ip_forward ']) == {'net.ipv4.ip_forward': '1'}
    assert get_sysctl(module, [' net.ipv4.ip_forward ']) == {'net.ipv4.ip_forward': '1'}
    assert get_sysctl(module, [' net.ipv4.ip_forward = 1 ']) == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-23 00:36:43.978889
# Unit test for function get_sysctl
def test_get_sysctl():
    """Test function get_sysctl"""
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    distribution_collector = DistributionFactCollector()
    distribution_collector.collect()

    if distribution_collector.facts['distribution'] == 'FreeBSD':
        data = get_sysctl(self, ['kern.ostype', 'kern.osrelease', 'kern.version'])

        assert data == {'kern.ostype': 'FreeBSD',
                        'kern.osrelease': '11.1-RELEASE',
                        'kern.version': 'FreeBSD 11.1-RELEASE #0 r321309: Mon Jul  3 18:46:05 UTC 2017'}

# Generated at 2022-06-23 00:36:46.709987
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule({})
    result = get_sysctl(module, ["kernel.hostname"])
    assert result == {'kernel.hostname': 'foo'}



# Generated at 2022-06-23 00:36:50.077214
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['kernel.ostype'])
    assert sysctl['kernel.ostype'] == 'Linux'

# Generated at 2022-06-23 00:36:52.579001
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule({})
    result = get_sysctl(module, ['vm.foo'])
    assert result == {'vm.foo': '1'}

# Generated at 2022-06-23 00:36:54.567221
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('fs.file-max') == '1048576'

# Generated at 2022-06-23 00:37:03.288379
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import Mock


# Generated at 2022-06-23 00:37:11.977168
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MagicMock()