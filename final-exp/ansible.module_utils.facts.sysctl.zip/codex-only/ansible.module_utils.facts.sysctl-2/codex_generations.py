

# Generated at 2022-06-23 00:27:15.297286
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    module.run_command = lambda cmd: (0, 'key1: 1\nkey2: 2', '')
    assert get_sysctl(module, ['key1', 'key2']) == {'key1': '1', 'key2': '2'}

# Generated at 2022-06-23 00:27:27.333964
# Unit test for function get_sysctl
def test_get_sysctl():

    import os

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['_ansible_version'] = '2.4.0.0'

        def get_bin_path(self, app, opt_dirs=None):
            return os.path.join(os.path.join(self.params['sysctl_path']), app)

        def run_command(self, cmd):
            return self.params['run_command'](cmd)

        def fail_json(self, **kwargs):
            pass


# Generated at 2022-06-23 00:27:38.319302
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec=dict())


# Generated at 2022-06-23 00:27:46.266841
# Unit test for function get_sysctl
def test_get_sysctl():

    # Always run the test.
    load_test = True

    # Run the test if we are running in a container. Used by unit tests.
    if os.environ.get('CONTAINER_RUN', None) is not None:
        load_test = True

    # Skip the test if the test directory does not exist.
    testdir = os.path.dirname(os.path.abspath(__file__))
    if not os.path.isdir(testdir):
        load_test = False

    if not load_test:
        return True

    # Load libraries if possible.
    try:
        from ansible.module_utils import basic
    except ImportError:
        return False

    # load the code under test

# Generated at 2022-06-23 00:27:56.452969
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    module.get_bin_path = lambda x: '/sbin/sysctl'

# Generated at 2022-06-23 00:27:58.359481
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['kernel.hostname']) == {'kernel.hostname': 'localhost'}

# Generated at 2022-06-23 00:28:05.694881
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    # Create the module object
    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Get sysctl values
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])

    # Validate the sysctl value
    module.exit_json(changed=False, sysctl_values=sysctl)


# Generated at 2022-06-23 00:28:10.834576
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    prefixes = ['kernel.printk']
    try:
        from ansible.module_utils.common._collections_compat import Mapping
    except ImportError:
        # Ansible 2.3 compatibility
        Mapping = dict
    assert isinstance(get_sysctl(module, prefixes), Mapping)



# Generated at 2022-06-23 00:28:14.339995
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sysctl = get_sysctl(module, ['kernel.hostname', 'kernel.domainname'])
    assert sysctl['kernel.domainname'] == 'example.com'


# Generated at 2022-06-23 00:28:25.931225
# Unit test for function get_sysctl
def test_get_sysctl():
    # module_utils.basic.AnsibleModule is not available in this context
    class FakeModule():
        def __init__(self):
            self.params = None
            self.exit_json = None
            self.fail_json = None
            self.run_command = None
            self.check_mode = None
            self.warn = None
            self.get_bin_path = None

    class FakeResults(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.stdout = out
            self.stderr = err

    test_get_bin_path_cmds = {
        'linux': '/sbin/sysctl',
        'openbsd': '/sbin/sysctl',
        'freebsd': '/sbin/sysctl',
    }



# Generated at 2022-06-23 00:28:33.900628
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic as basic
    import ansible.module_utils.system as system
    sysctl = get_sysctl(basic.AnsibleModule(argument_spec=dict()), prefixes=['net.ipv4.conf.all.forwarding', 'net.ipv4.conf.default.rp_filter'])
    assert sysctl.get('net.ipv4.conf.all.forwarding') == '1'
    assert sysctl.get('net.ipv4.conf.default.rp_filter') == '1'

# Generated at 2022-06-23 00:28:41.273010
# Unit test for function get_sysctl
def test_get_sysctl():
    import module_utils.systemd.sysctl as sysctl
    module_utils.systemd.sysctl.get_bin_path = lambda x: 'sysctl'
    module = MockAnsibleModule()
    module.run_command = lambda x: [0, 'vm.overcommit_memory = 1', '']
    results = sysctl.get_sysctl(module, ['vm.overcommit_memory'])
    assert(results['vm.overcommit_memory'] == '1')


# Generated at 2022-06-23 00:28:51.493316
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import StringIO
    import ansible.module_utils.systemd.sysctl


# Generated at 2022-06-23 00:28:56.080895
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule({})
    result = get_sysctl(module, ['vm.max_map_count'])
    print(result)
    assert result.get('vm.max_map_count') == '262144'

from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:28:58.452159
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-23 00:29:10.239875
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )

    # Test 1 - sysctl existent
    module.run_command = lambda x: (0, '''foo = 'bar'
net.ipv4.ip_forward = 0''', None)
    result = get_sysctl(module, ['foo', 'net.ipv4.ip_forward'])
    assert result == {'foo': 'bar', 'net.ipv4.ip_forward': '0'}

    # Test 2 - sysctl inexistent
    module.run_command = lambda x: (0, '''foo = 'bar'
net.ipv4.ip_forward = 0''', None)
    result = get_sysctl(module, ['nonexistent'])
   

# Generated at 2022-06-23 00:29:12.301161
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(['kernel.hostname'])['kernel.hostname'] == socket.gethostname()


# Generated at 2022-06-23 00:29:20.875339
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(prefixes=dict(type='list'))
    )

    sysctl = get_sysctl(module, ['fs.inotify.max_user_watches'])
    print(sysctl)
    assert sysctl['fs.inotify.max_user_watches'] == '8192'

# import module snippets
from ansible.module_utils.basic import *  # noqa

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:29:26.677269
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule({u'prefix': u'kernel.ostype'})
    systype = get_sysctl(mod, [u'kernel.ostype'])
    assert u'kernel.ostype' in systype
    assert systype[u'kernel.ostype'] != u''

# Generated at 2022-06-23 00:29:36.635089
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()
    module.run_command = lambda cmd: (0, '\n'.join(['kern.osrelease = 1.2.3',
                                                    'kern.osrevision\n'
                                                    '    = 45',
                                                    'kern.version = 12.345-stable',
                                                    'kern.codetest1 = 123']), '')
    module.warn = lambda msg: None
    prefixes = ['kern.osrelease', 'kern.osrevision', 'kern.version', 'kern.codetest1=']
    sysctl = get_sysctl(module, prefixes)

    assert(sysctl['kern.osrelease'] == '1.2.3')
    assert(sysctl['kern.osrevision'] == '45')

# Generated at 2022-06-23 00:29:47.568849
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefix=dict(type='list', default=[]),
        )
    )


# Generated at 2022-06-23 00:29:58.469096
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}

        def run_command(self, cmd):
            command = ' '.join(cmd)

# Generated at 2022-06-23 00:30:03.146946
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    sysctl = get_sysctl(module, ["kernel.hostname"])
    assert sysctl["kernel.hostname"] == "ubuntu"

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:30:04.787425
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(sysctl_module, ['kern.msgbuf'])


# Generated at 2022-06-23 00:30:06.970525
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(['kern.ostype']) ==  {'kern.ostype': 'Darwin'}

# Generated at 2022-06-23 00:30:11.154141
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    module = sys.modules[__name__]

    sysctl = get_sysctl(module, ['kernel.ostype', 'kernel.osrelease'])

    assert isinstance(sysctl, dict)
    assert 'kernel.ostype' in sysctl
    assert 'kernel.osrelease' in sysctl

# Generated at 2022-06-23 00:30:17.481193
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list')
        )
    )

    ret = get_sysctl(module, ['net.ipv4.conf.all.rp_filter'])
    module.exit_json(msg=ret)

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:30:20.087745
# Unit test for function get_sysctl
def test_get_sysctl():
    result = get_sysctl(None, ['kern.maxvnodes'])
    assert result['kern.maxvnodes'] == '37264'



# Generated at 2022-06-23 00:30:30.522376
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

    sysctl = {
        'net.ipv4.ip_forward': '1',
        'net.ipv4.conf.all.accept_redirects': '0',
        'net.ipv4.conf.all.allow_redirects': '1',
        'net.ipv4.conf.all.secure_redirects': '0',
    }

    module = AnsibleModule()
    module.run_command = mock_run_command(sysctl)
    module.get_bin_path = mock_get_bin_path(sysctl)

    sysctl_out = get_sysctl(module, ['net.ipv4.ip_forward'])


# Generated at 2022-06-23 00:30:42.366618
# Unit test for function get_sysctl
def test_get_sysctl():
    # Given: List of all possible sysctl key-values prefixes,
    #        and a module.
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=True, type='list'),
        )
    )
    prefixes = ['sysctl', 'kernel']

    # When: I run get_sysctl
    sysctl = get_sysctl(module, prefixes)

    # Then: I receive a dict of all sysctl key-values that match the prefixes.

# Generated at 2022-06-23 00:30:52.105689
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:30:58.897736
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule(argument_spec=dict())
    module.params['prefixes'] = ['vm.swappiness', 'net.ipv4.conf']

    sysctl = get_sysctl(module, module.params['prefixes'])

    assert sysctl['vm.swappiness'] == '0'
    assert sysctl['net.ipv4.conf.all.send_redirects'] == '0'


# Generated at 2022-06-23 00:31:05.207107
# Unit test for function get_sysctl
def test_get_sysctl():
    # Import this here to work around ansible 2.x import issues
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module=module, prefixes=['kern'])

    assert 'kern.hostname' in sysctl
    assert re.match(r'^\S+$', sysctl['kern.hostname'])



# Generated at 2022-06-23 00:31:10.612515
# Unit test for function get_sysctl
def test_get_sysctl():
    """ Unit tests for function get_sysctl """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl = dict()

    sysctl = get_sysctl(module, ['-a'])
    assert(len(sysctl) > 0)

# Generated at 2022-06-23 00:31:17.851225
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import platform

    module = AnsibleModule(
        argument_spec=dict(),
    )

    prefixes = ['kernel.domainname']
    sysctl = get_sysctl(module, prefixes)

    # These results will differ on each host, but we can
    # at least verify the module made the right calls
    assert platform.system() in sysctl['kernel.domainname']
    assert sysctl.get('kernel.domainname') is not None

# Generated at 2022-06-23 00:31:27.540068
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl = get_sysctl(module, ['vm.overcommit_memory'])
    assert sysctl == {'vm.overcommit_memory': '0'}

    module.params['prefixes'] = ['net.ipv4', 'net.ipv6']

    sysctl = get_sysctl(module, ['net.ipv4', 'net.ipv6'])
    assert 'net.ipv4.tcp_rmem' in sysctl
    assert 'net.ipv6.tcp_rmem' in sysctl

# Generated at 2022-06-23 00:31:38.901222
# Unit test for function get_sysctl
def test_get_sysctl():
    # --- UnitTests
    # test1
    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list')))
    sysctl_cmd = '/sbin/sysctl'
    cmd = [sysctl_cmd]
    prefixes = ['-a']
    cmd.extend(prefixes)
    sysctl = dict()

    rc = 0

# Generated at 2022-06-23 00:31:46.194972
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    prefixes = [
      'kern.version',
      'machdep.cpu.brand_string',
      'hw',
    ]

    sysctl = get_sysctl(module, prefixes)

    assert sysctl['kern.version']
    assert sysctl['machdep.cpu.brand_string']
    assert sysctl['hw']

# Generated at 2022-06-23 00:31:55.847153
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 00:32:07.407822
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(
        argument_spec = dict(
            params=dict(default=None, required=True, type='list'),
        ),
    )

    get_sysctl_ = get_sysctl

    def get_sysctl(module, prefix):
        return {'kern.ostype': 'FreeBSD'}

    try:
        sysctl = get_sysctl_(module, ['kern.ostype'])
        assert sysctl == {'kern.ostype': 'FreeBSD'}
    finally:
        get_sysctl = get_sysctl_



# Generated at 2022-06-23 00:32:18.626614
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:32:30.034826
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import platform

    major, minor, _, _, _ = platform.python_version_tuple()

    # Python 2.6 requires fake_module
    if (sys.version_info[0] == 2 and int(major) <= 2 and int(minor) <= 6):
        class FakeModule:
            def __init__(self):
                self.params = {}

            def fail_json(self, *args, **kwargs):
                raise Exception(kwargs['msg'])

            def run_command(self, cmd):
                return 0, '', ''

            def warn(self, msg):
                print(msg)

            @staticmethod
            def get_bin_path(binary, required=False, opt_dirs=[]):
                return binary

        fake_module = FakeModule()
        result = get_sys

# Generated at 2022-06-23 00:32:33.964793
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule({})
    result = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert result['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-23 00:32:37.313394
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockAnsibleModule()
    sysctl = get_sysctl(module, [])

    assert sysctl['kernel.shmall'] is not None
    assert sysctl['kernel.shmall'] == '2097152'



# Generated at 2022-06-23 00:32:49.788485
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern', 'maxfiles'])
    assert sysctl == {'kern.maxfiles': '371802'}

    sysctl = get_sysctl(module, ['kern', 'maxvnodes'])
    assert sysctl == {'kern.maxvnodes': '371802'}

    sysctl = get_sysctl(module, ['net', 'bpf'])

# Generated at 2022-06-23 00:32:52.602446
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeModule()
    assert get_sysctl(module, ['vm.swappiness']) == {'vm.swappiness': '60'}

# Unit test fixture

# Generated at 2022-06-23 00:32:57.562080
# Unit test for function get_sysctl
def test_get_sysctl():
    # Expect this to fail because we will use a non-existent command for sysctl
    sysctl = get_sysctl(module=lambda x, y: None, prefixes=[])
    assert not sysctl

    sysctl = get_sysctl(module=lambda x, y: None, prefixes=['kern.boottime'])
    assert sysctl
    assert 'kern.boottime' in sysctl



# Generated at 2022-06-23 00:32:58.616548
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-23 00:33:02.956082
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule()
    test_sysctl = get_sysctl(module, ['vm.overcommit_memory'])
    assert test_sysctl['vm.overcommit_memory'] == '1'



# Generated at 2022-06-23 00:33:13.427427
# Unit test for function get_sysctl
def test_get_sysctl():

    # Test invocation.
    module_exports = {
        'get_bin_path': lambda x: x,
        'run_command': lambda x, check_rc=True, environ_update=None,
                            binary_data=False: (0, 'A = B\nC = D\n', None),
        'warn': lambda x: x
    }

    try:
        import ansible.module_utils.basic
    except ImportError:
        sys.path.append('../../lib/ansible/module_utils')
        import ansible.module_utils.basic


# Generated at 2022-06-23 00:33:24.867728
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['-a']
    module = dict(name='get_sysctl')
    module['run_command'] = lambda cmd, check_rc=None: (0, '', '')

    result = get_sysctl(module, prefixes)
    assert(isinstance(result, dict))
    assert(result == {})

    module['run_command'] = lambda cmd, check_rc=None: (0, 'foo = bar', '')
    result = get_sysctl(module, prefixes)
    assert(isinstance(result, dict))
    assert(result == {'foo': 'bar'})

    module['run_command'] = lambda cmd, check_rc=None: (0, 'foo = bar\nanswer = 42', '')
    result = get_sysctl(module, prefixes)

# Generated at 2022-06-23 00:33:32.365422
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    sysctl = get_sysctl(module, ["kern.boottime"])

    if sysctl != {'kern.boottime': 'Fri Apr 24 15:48:20 2015\n  sec = 1429872100\n  waiting on 5 processes'}:
        module.fail_json(
            msg="Invalid results from get_sysctl: %s" % sysctl
        )


# Generated at 2022-06-23 00:33:37.909248
# Unit test for function get_sysctl
def test_get_sysctl():
    """
        Unit test for function get_sysctl
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    prefixes = ['-a', 'kern']
    expected_result = {'kern.hostname': 'localhost'}
    test_result = get_sysctl(module, prefixes)
    assert test_result == expected_result

# Generated at 2022-06-23 00:33:48.088260
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl._ansible_test_get_sysctl(['']) == {}

    assert get_sysctl._ansible_test_get_sysctl(['''
vm.swappiness
vm.swappiness = 30
net.ipv4.conf.all.rp_filter: 1
kernel.random.read_wakeup_threshold = 4096
    ''']) == {
        'kernel.random.read_wakeup_threshold': '4096',
        'net.ipv4.conf.all.rp_filter': '1',
        'vm.swappiness': '30'
    }

if __name__ == '__main__':
    from ansible.module_utils import basic
    basic._ANSIBALLZ_CACHE = {}
    from ansible.module_utils.basic import AnsibleModule
   

# Generated at 2022-06-23 00:33:56.232923
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    module = AnsibleModule(argument_spec={
        'prefixes': {'type': 'list'}
    })

    result = get_sysctl(module, prefixes=['net.ipv4.conf.all.forwarding'])
    assert isinstance(result, Mapping)
    assert to_text(result['net.ipv4.conf.all.forwarding']) == to_text('0')

# Generated at 2022-06-23 00:34:02.381867
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname'])

    assert isinstance(sysctl, dict), 'get_sysctl returned non-dict'
    assert len(sysctl) == 1, 'invalid sysctl: %s' % sysctl

# Generated at 2022-06-23 00:34:13.964932
# Unit test for function get_sysctl
def test_get_sysctl():
    class Module(object):
        def __init__(self, name, args=dict(), run_command=None):
            self.__name__ = name
            self._run_command = run_command
            self._args = args

        def get_bin_path(self, name):
            return '/usr/bin/%s' % name

        def run_command(self, cmd):
            return self._run_command(cmd)

        def warn(self, msg):
            pass

    def get_sysctl_output(cmd):
        if cmd == ['/usr/bin/sysctl', 'kern.ipc.nmbclusters']:
            return 0, '''kern.ipc.nmbclusters: 65536
''', ''

# Generated at 2022-06-23 00:34:19.617387
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    assert get_sysctl(module, []) == {}
    assert len(get_sysctl(module, ['kernel.hostname'])) == 1
    assert len(get_sysctl(module, ['kernel.hostname', 'kernel.domainname'])) == 2

# Generated at 2022-06-23 00:34:23.849596
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('', ('vm.swappiness', 'net.ipv4.ip_forward')) == {'net.ipv4.ip_forward': '1', 'vm.swappiness': '0'}


# Generated at 2022-06-23 00:34:27.656940
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test to make sure a prefix will return all values from the sysctl
    assert 'kernel.panic' in get_sysctl(['kernel'])
    # Test to make sure a full value is returned
    assert get_sysctl(['kernel.panic_on_oops']) == 0

# Generated at 2022-06-23 00:34:35.552393
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (object,), dict({
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd: (0, ''.join(['%s=%s\n' % (x,x) for x in sorted(['ab', 'ac', 'ad'])]), ''),
        'warn': lambda self, warning: None,
    }))()

    sysctl = get_sysctl(module, ['ab','ac','ad'])

    expected = {
        'ab': 'ab',
        'ac': 'ac',
        'ad': 'ad',
    }

    assert sysctl == expected

# Generated at 2022-06-23 00:34:46.780717
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile

    # Create a temporary test file
    (fd, name) = tempfile.mkstemp()

    # A test set

# Generated at 2022-06-23 00:34:49.723680
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    assert get_sysctl(module, ['kernel']) == get_sysctl(module, ['kern'])



# Generated at 2022-06-23 00:34:55.748364
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ['kern.boottime'])
    assert (sysctl['kern.boottime']).startswith('Mon Jan 16')
    sysctl = get_sysctl(module, ['net.inet.icmp.icmplim'])
    assert (sysctl['net.inet.icmp.icmplim']) == '50'


# Generated at 2022-06-23 00:35:03.438408
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('obj', (object,), dict(run_command=lambda self, cmd, check_rc=True:
                    (0, 'kernel.sysrq: 176  kernel.core_uses_pid: 1\nkernel.msgmnb: 65536  kernel.msgmax: 65536\n',
                     None)))
    sysctl = get_sysctl(module, ['kernel.sysrq', 'kernel.msgmnb'])
    assert sysctl == dict(kernel_sysrq='176', kernel_msgmnb='65536')

# Generated at 2022-06-23 00:35:07.447229
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule({})

    sysctl = get_sysctl(module, ["net.ipv4.ip_forward"])

    assert sysctl["net.ipv4.ip_forward"] == "0"

# Generated at 2022-06-23 00:35:13.437833
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    sysctl = get_sysctl(module, ['kern.version'])

    if not sysctl:
        module.fail_json(msg='Could not find kern.version in sysctl')

    module.exit_json(changed=False, kern_version=sysctl['kern.version'])


# Generated at 2022-06-23 00:35:19.842032
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleModule

    m = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    out = get_sysctl(m, ['vm.max_map_count', 'vm.min_free_kbytes'])
    assert isinstance(out, dict)
    assert len(out) == 2
    assert int(out['vm.max_map_count']) > 1000
    assert int(out['vm.min_free_kbytes']) > 100000

# Generated at 2022-06-23 00:35:30.692809
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 00:35:38.849822
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    prefixes = [ 'net', 'ipv4' ]
    cmd = [ 'cat', os.path.join(os.path.dirname(__file__), 'get_sysctl_cat.txt')]
    rc = 0
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    module.run_command = lambda args: (rc, '', '')

    ret = get_sysctl(module, prefixes)
    assert len(ret) == 6
    assert 'net.ipv4.tcp_max_syn_backlog' in ret
    assert 'net.ipv4.conf.all.rp_filter' in ret

# Generated at 2022-06-23 00:35:45.898447
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = FakeModule()
    test_module.run_command = mock_run_command
    test_module.get_bin_path = mock_get_bin_path
    prefixes = ['kern', 'vm']
    sysctl_dict = get_sysctl(test_module, prefixes)
    assert sysctl_dict['kern.vm.loadavg'] == '0.33 0.27 0.23 1/99 16092'
    assert sysctl_dict['kern.vm.nkmempages'] == '0'



# Generated at 2022-06-23 00:35:51.911299
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    ret = get_sysctl(module, [])
    assert isinstance(ret, dict)
    assert 'kernel.hostname' in ret

    ret = get_sysctl(module, ['kernel.hostname'])
    assert isinstance(ret, dict)
    assert 'kernel.hostname' in ret



# Generated at 2022-06-23 00:35:59.942576
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # Test that sysctl command exists on PATH
    sysctl_cmd = module.get_bin_path('sysctl')

    # Test that kern.version gets returned correctly
    kern_version_prefixes = 'kern.version'
    sysctl = get_sysctl(module, to_bytes(kern_version_prefixes))
    assert is_iterable(sysctl)
    assert len(sysctl) == 1
    assert b'kern.version' in sysctl

# Generated at 2022-06-23 00:36:10.852603
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    assert get_sysctl(module, ['kernel.hostname']) == {'kernel.hostname': 'test.example.com'}
    assert get_sysctl(module, ['kernel.core_uses_pid']) == {'kernel.core_uses_pid': '1'}
    assert get_sysctl(module, ['kernel.msgmax']) == {'kernel.msgmax': '65536'}
    assert get_sysctl(module, ['kernel.msgmni']) == {'kernel.msgmni': '2432'}
    assert get_sysctl(module, ['kernel.msgmnb']) == {'kernel.msgmnb': '65536'}

# Generated at 2022-06-23 00:36:16.547273
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.tcp_max_syn_backlog'])

    assert type(sysctl) is dict
    assert sysctl['net.ipv4.ip_forward'] == '1'
    assert sysctl['net.ipv4.tcp_max_syn_backlog'] == '1024'



# Generated at 2022-06-23 00:36:22.769924
# Unit test for function get_sysctl
def test_get_sysctl():
    module = sysctl_facts
    prefixes = ['net.ipv4.conf.ens192.rp_filter']
    sysctl = get_sysctl(module, prefixes)

    assert not sysctl == None
    assert not sysctl == ''
    assert isinstance(sysctl, dict)
    assert sysctl['net.ipv4.conf.ens192.rp_filter'] == '1'


# Generated at 2022-06-23 00:36:27.575764
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    module.run_command = MagicMock()

    result = get_sysctl(module, ['kernel.ostype'])

    assert result == {'kernel.ostype': 'Linux'}


# Generated at 2022-06-23 00:36:38.113113
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=[]),
        ),
        supports_check_mode=True,
    )

    # Ensure that when a list of prefixes are provided
    # that the keys are prefixed correctly
    foo_bar = 'test_sysctl_foo_bar_value'
    baz = 'test_sysctl_baz_value'

    cmd = module.get_bin_path('sysctl')
    module.run_command([cmd, '-w', 'foo.bar=%s' % foo_bar])
    module.run_command([cmd, '-w', 'baz=%s' % baz])


# Generated at 2022-06-23 00:36:48.940532
# Unit test for function get_sysctl
def test_get_sysctl():

    import os
    import ansible.module_utils.six as six

    class FakeModule:
        def __init__(self):
            self.fail_json = lambda x: None
            self.run_command = lambda x: (0, "", "")

        def get_bin_path(self, path):
            return path

    module = FakeModule()

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.tcp_max_syn_backlog', 'not.a.real.key'])
    assert sysctl == {'net.ipv4.ip_forward': '0', 'net.ipv4.tcp_max_syn_backlog': '128'}

    # test error

# Generated at 2022-06-23 00:36:51.194422
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['kernel.hostname']) == {'kernel.hostname': 'localhost.localdomain'}

# Generated at 2022-06-23 00:36:58.322796
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    try:
        result = get_sysctl(module, ['fs.file-max'])
    except Exception:
        assert False, "Failed to get sysctl info"

    if 'fs.file-max' not in result:
        assert False, "Failed to get sysctl info"
    else:
        assert True, "sysctl info returned"


# Generated at 2022-06-23 00:37:02.635881
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['-w', 'kern.version=1.2.3', '-a'])
    assert sysctl['kern.version'] == '1.2.3'

# Generated at 2022-06-23 00:37:11.463121
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.run_command_lines = []
            self.run_command_rcs = []
            self.run_command_results = []
            self.run_command_exceptions = []

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/%s' % executable

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            self.exit_called = True
