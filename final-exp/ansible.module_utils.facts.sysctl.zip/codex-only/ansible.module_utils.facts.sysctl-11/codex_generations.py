

# Generated at 2022-06-23 00:27:17.476120
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    def run_command(module, cmd, check_rc=True, close_fds=True):
        if len(cmd) < 2:
            return PY3, '', ''
        elif cmd[1] == 'kern.boottime':
            return 0, 'kern.boottime = { sec = 8; microsec = 989898; }', ''
        elif cmd[1] == 'kern.securelevel':
            return 0, 'kern.securelevel = 1', ''
        elif cmd[1] == 'kern.hostname':
            return 0, 'kern.hostname = (hostname)', ''

# Generated at 2022-06-23 00:27:18.889869
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['foo'])
    assert sysctl == {'foo': '42'}

    sysctl = get_sysctl(module, ['bar'])
    assert sysctl == {'bar': ''}


# Generated at 2022-06-23 00:27:29.349606
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    prefixes = ['-a']
    key = 'net.ipv4.ip_forward'
    expected_value = '1'


# Generated at 2022-06-23 00:27:32.613165
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('', '').keys() == {'vm.version'}
    assert get_sysctl('', '').values() == {'FreeBSD 11.0-CURRENT r301003'}

# Generated at 2022-06-23 00:27:43.666999
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    def sysctl_run_command(cmd):
        stdout = StringIO()

# Generated at 2022-06-23 00:27:52.044052
# Unit test for function get_sysctl
def test_get_sysctl():

    # here sys.modules['ansible.module_utils.common.os'] is set by test/utils.py
    get_bin_path = sys.modules['ansible.module_utils.common.os'].get_bin_path
    def run_command(cmd, cwd=None, use_unsafe_shell=False, environ_update=None, check_rc=True, executable=None, data=None):
        if cmd[0] == get_bin_path('sysctl') and cmd[1:3] == ['-a', '-n']:
            return 0, "foo=bar\nbar=baz\n", ''
        else:
            return 1, '', 'command failed'

    # Fake the Module class with the function we want to test
    class FakeModule:
        run_command = run_command
        get

# Generated at 2022-06-23 00:27:58.894221
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = module.get_bin_path('sysctl')

    (rc, out, err) = module.run_command(sysctl)
    assert rc == 0

    options = get_sysctl(module, 'kernel')
    assert 'kernel.ostype' in options
    assert 'kernel.osrelease' in options

    # test with prefixes
    options = get_sysctl(module, ['kernel', 'net'])
    assert 'kernel.ostype' in options
    assert 'kernel.osrelease' in options
    assert 'net.ipv4.ip_forward' in options



# Generated at 2022-06-23 00:28:10.427677
# Unit test for function get_sysctl
def test_get_sysctl():

    class TestModule(object):
        def __init__(self):
            self.run_command = test_run_command

    def test_run_command(command, **kwargs):
        pass

    test_module = TestModule()


# Generated at 2022-06-23 00:28:13.989093
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl()

    assert isinstance(sysctl, dict)
    assert 'kernel.hostname' in sysctl
    assert 'kernel.random.uuid' in sysctl
    assert 'kernel.random.entropy_avail' in sysctl

# Generated at 2022-06-23 00:28:25.628911
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Test data.

# Generated at 2022-06-23 00:28:35.174717
# Unit test for function get_sysctl
def test_get_sysctl():
    module = DummyModule()

# Generated at 2022-06-23 00:28:42.937695
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    get_sysctl: Return a dict of values from sysctl
    '''
    module = AnsibleModule(argument_spec=dict())

    rc, out, err = module.run_command('set -o pipefail; sysctl -a | grep net.ipv4.ip_local_port_r')
    module.exit_json(changed=False, rc=rc, stdout=out, stderr=err)
    keys = get_sysctl(module, 'net.ipv4.ip_local_port_range'.split())

# Generated at 2022-06-23 00:28:54.476447
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile

    # Workaround for AnsibleModule not being available in unit tests
    try:
        from ansible.modules.network.common.utils import ComplexList
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 00:29:01.631701
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    EXPECTED = {
        'net.ipv4.ip_forward': '1',
        'net.ipv4.ip_forward_use_pmtu': '1',
        'net.ipv6.conf.all.forwarding': '0',
        'net.ipv6.conf.default.forwarding': '1',
        'net.ipv6.conf.default.use_tempaddr': '1'
    }


# Generated at 2022-06-23 00:29:12.260499
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test function get_sysctl with a prefix that should have results
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )
    result = get_sysctl(module, ['net.ipv4'])
    assert result is not None
    assert 'net.ipv4.conf.all.rp_filter' in result
    assert '2' == result['net.ipv4.conf.all.rp_filter']

    # Test function get_sysctl with a prefix that should not have results
    result = get_sysctl(module, ['net.ipv1'])
    assert result is not None
    assert len(result) == 0


# Generated at 2022-06-23 00:29:22.311123
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile
    import os
    import shutil

    def write_sysctl_file(content):
        tmpdir = tempfile.mkdtemp()
        f = open(os.path.join(tmpdir, 'sysctl.conf'), 'w')
        f.write(content)
        f.close()

        return tmpdir

    def remove_sysctl_file(path):
        shutil.rmtree(path)

    def get_module_mock():
        def get_bin_path(name):
            return 'echo'

        def run_command(cmd):
            return (0, '', '')

        def warn(msg):
            pass


# Generated at 2022-06-23 00:29:26.012150
# Unit test for function get_sysctl
def test_get_sysctl():
    module = {}
    module['run_command'] = lambda *args: (1, '', '')
    rc, out, err = module['run_command']('sysctl', 'kern.maxproc')
    assert rc == 1


# Generated at 2022-06-23 00:29:36.287547
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['-a'])

    assert sysctl
    assert 'kernel.hostname' in sysctl
    assert 'kernel.domainname' in sysctl
    assert 'net.ipv4.route.min_pmtu' in sysctl
    # assert 'kernel.sysrq' in sysctl
    assert 'kernel.modprobe' in sysctl
    #assert 'kernel.hotplug' in sysctl
    assert 'kernel.panic_on_oops' in sysctl
    assert 'kernel.pid_max' in sysctl
    assert 'kernel.threads-max' in sysctl

# Generated at 2022-06-23 00:29:43.631003
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import basic

    os_version = 'FreeBSD 8.2-RELEASE-p10'


# Generated at 2022-06-23 00:29:52.240925
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule({})
    test_prefixes = ['vm', 'fs']
    test_sysctl = {'vm.swappiness': '1', 'fs.file-max': '432328', 'fs.inotify.max_queued_events': '1048576', 'fs.inotify.max_user_instances': '128', 'fs.inotify.max_user_watches': '532480'}
    result_sysctl = get_sysctl(test_module, test_prefixes)
    assert result_sysctl == test_sysctl


# Generated at 2022-06-23 00:29:55.271581
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.sysctl import get_sysctl

    module = AnsibleModule()
    assert dict == type(get_sysctl(module, ["kernel.ostype", "kernel.osrelease"]))

# Generated at 2022-06-23 00:30:01.339100
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.sysctl import test_get_sysctl as get_sysctl_module
    from ansible.module_utils.facts.system.sysctl import  get_sysctl as get_sysctl_module_real

    fake_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    expected_out = dict(
        kernel_printk = '0 4 1 7'
        )
    out = get_sysctl_module(fake_module)

    assert out == expected_out

    fake_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-23 00:30:11.973596
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MagicMock()
    config_file = dict(
        sysctl=dict(
            ipv4=dict(
                ip_forward=1,
                ip_nonlocal_bind=0,
                tcp_tw_recycle=1
            ),
            net=dict(
                core=dict(
                    default_qdisc='fq',
                    rmem_max=16777216,
                    wmem_max=16777216,
                ),
            )
        )
    )

    def get_bin_path(program):
        return '/sbin/' + program

    module.get_bin_path = get_bin_path


# Generated at 2022-06-23 00:30:22.871928
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from sys import version_info

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=True, type='list')
        ),
        supports_check_mode=False
    )

    if version_info[0] < 3:
        expected = {
            'kern.securelevel': '1',
            'kern.version': 'OpenBSD 6.4 (GENERIC) #0: Thu Oct 25 13:12:42 MDT 2018     deraadt@amd64.openbsd.org:/usr/src/sys/arch/amd64/compile/GENERIC',
            'vm.loadavg': '0.00 0.01 0.05 1/117 22723'
        }

# Generated at 2022-06-23 00:30:29.448004
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    a = AnsibleModule({})

    assert get_sysctl(a, ('vm.version',)) == {'vm.version': 'FreeBSD 11.0-CURRENT #297 r285677: Wed Apr 5 18:51:17 UTC 2017'}
    assert get_sysctl(a, ('vm.overcommit', 'vm.overcommit_memory')) == {'vm.overcommit_memory': '2', 'vm.overcommit': '1'}

# Generated at 2022-06-23 00:30:42.079023
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    class FakeConfig(object):
        def __init__(self):
            self.run_command_no_persist = True

    config = FakeConfig()

    class FakeModule(object):
        """ Fake class for AnsibleModule, which has dependencies that are
        not easy to mock/fake.
        """
        def __init__(self, params):
            self.config = config
            self._params = params

            self._result = dict(
                msg='',
                rc=0,
                diff=dict(
                    before='',
                    after='')
            )
            self.check_mode = False


# Generated at 2022-06-23 00:30:48.558692
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    (rc, out, err) = module.run_command('echo -n "vm.swappiness = 99" > /proc/sys/vm/swappiness')
    assert rc == 0
    sysctl_result = get_sysctl(module, ['vm.swappiness'])
    assert sysctl_result == {'vm.swappiness': '99'}


# Generated at 2022-06-23 00:30:59.372483
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = ['kern.hostname', 'kern.version']
    rc = 0
    out = """kern.hostname: localhost
kern.version: FreeBSD 12.1-RELEASE-p2 r353797M GENERIC amd64
kern.ostype: FreeBSD
kern.osreldate: 1300024
"""
    sysctl = {u'kern.version': u'FreeBSD 12.1-RELEASE-p2 r353797M GENERIC amd64', u'kern.hostname': u'localhost'}
    assert get_sysctl(module, prefixes) == sysctl


# Generated at 2022-06-23 00:31:10.897371
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_distribution
    this_module = AnsibleModule(
        argument_spec=dict()
    )
    this_module.get_bin_path = lambda x: '/usr/sbin/sysctl'
    this_module.run_command = lambda x: (0, "net.ipv4.ip_forward = 0\nnet.ipv4.conf.all.accept_local = 0\n", "")
    this_module.warn = lambda x: None
    sysctl = get_sysctl(this_module, "net.ipv4.ip_forward net.ipv4.conf.all.accept_local".split(' '))

# Generated at 2022-06-23 00:31:22.727015
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os

    sys.modules['ansible'] = type('mock_ansible_module', (), {})
    sys.modules['ansible.module_utils'] = type('mock_ansible_module_utils', (), {})
    module = sys.modules['ansible.module_utils']

    class mock_run_command:
        def __init__(self, invocation):
            pass

        def __call__(self, invocation):
            mock_run_command.invocations.append(invocation)

            mock_run_command.invocation_count += 1


# Generated at 2022-06-23 00:31:26.798145
# Unit test for function get_sysctl
def test_get_sysctl():
    result = get_sysctl({'run_command': {'bin_path': 'sysctl'}}, ["vm.max_map_count"])
    assert result == {"vm.max_map_count": "65530", "vm.max_map_count.legacy_va": "65532"}

# Generated at 2022-06-23 00:31:38.486164
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class TestException(Exception):
        pass

    module = MagicMock()

# Generated at 2022-06-23 00:31:50.694022
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os

    test_module = type('test_module', (object,), dict(run_command = lambda self, cmd, check_rc=True:
        (0, '\n'.join(['net.ipv4.ip_local_port_range = %s %s' % (sys.maxsize, sys.maxsize),
                        'net.ipv4.tcp_tw_reuse = 0',
                        'net.ipv4.tcp_tw_recycle = 0']), '')))()

    sysctl = get_sysctl(test_module, ['net.ipv4.ip_local_port_range', 'net.ipv4.tcp_tw_reuse'])


# Generated at 2022-06-23 00:32:00.604613
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    fake_expect = """[david@targethost ~]$ sysctl net.ipv4.ip_forward
net.ipv4.ip_forward = 1"""
    sysctl_return = {'net.ipv4.ip_forward': '1'}

    with patch_get_bin_path(module) as get_bin_path_mock:
        get_bin_path_mock.return_value = '/usr/sbin/sysctl'

        with patch_module_run_command(module) as run_command_mock:
            run_command_mock.return_value = (0, fake_expect, "")

# Generated at 2022-06-23 00:32:12.154146
# Unit test for function get_sysctl
def test_get_sysctl():
    data = """\
    net.ipv4.ip_forward = 0
    net.ipv4.conf.default.rp_filter = 1
    net.ipv4.conf.default.accept_source_route = 0
     net.ipv6.conf.all.forwarding = 1
    net.ipv6.conf.default.forwarding = 1
    net.ipv6.conf.all.accept_ra_rtr_pref = 1
    net.ipv6.conf.all.accept_ra_pinfo = 1
"""

# Generated at 2022-06-23 00:32:22.988425
# Unit test for function get_sysctl
def test_get_sysctl():
    from units.compat.mock import Mock, patch

    module = Mock(run_command=Mock(side_effect=[
        (0,
         'kernel.msgmnb = 65536\n'
         'kernel.msgmax = 65536\n'
         'kernel.msgmni = 2428',
         ''),
        (1, '', 'Error')
    ]), params=dict())

    module._ansible_no_log = False

    # We patch here as we do not want to test the actual call being made, just
    # that it happens with the right parameters
    with patch('ansible.module_utils.basic.AnsibleModule.get_bin_path') as gbp:
        gbp.return_value = 'this_is_sysctl'


# Generated at 2022-06-23 00:32:24.972751
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict()
    )

    prefixes = []
    results = get_sysctl(module, prefixes)
    assert results != {}
    assert 'kernel.version' in results

# Generated at 2022-06-23 00:32:34.631734
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils
    module_mock = ansible.module_utils.basic.AnsibleModule({})
    module_mock.run_command = lambda *args, **kwargs: (0, b'path.to.something = 1\npath.to.something.else = 1', '')
    module_mock.get_bin_path = lambda *args, **kwargs: 'sysctl'
    ret = get_sysctl(module_mock, ['path.to'])
    assert ret['path.to.something'] == '1'
    assert ret['path.to.something.else'] == '1'

# Generated at 2022-06-23 00:32:39.251354
# Unit test for function get_sysctl
def test_get_sysctl():

    sysctl = get_sysctl(['net'])
    assert sysctl['net.ipv4.ip_local_port_range'] == '32768    61000'

    sysctl = get_sysctl(['net', 'net.ipv4.ip_local_port_range'])
    assert sysctl['net.ipv4.ip_local_port_range'] == '32768    61000'

# Generated at 2022-06-23 00:32:47.221248
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    This is basic unit test of the get_sysctl function.
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    # AnsibleModule.warn is used for debugging purposes in this test
    module.warn('sysctl %s' % sysctl)
    assert sysctl == {'vm.swappiness': '60'}

# Generated at 2022-06-23 00:32:56.858957
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import sys
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    sysctl_data = '''
net.ipv4.ip_forward = 0
net.ipv6.conf.all.forwarding = 0
fs.file-max = 65536
kernel.panic = 1
kernel.panic_on_oops = 1
kernel.sysrq = 1
kernel.softlockup_panic = 1
'''

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    with tempfile.NamedTemporaryFile() as f:
        f.write(sysctl_data)
        f.flush()

        module.run_command = lambda x, _env: (0, open(f.name).read(), '')
        module

# Generated at 2022-06-23 00:33:05.853514
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule, get_distribution
    from ansible.module_utils.facts import get_sysctl

    module = AnsibleModule({'run_command': ['echo', 'net.ipv4.ip_forward = 1'],
                            'warn': False,
                            'get_bin_path': lambda x: '/usr/bin/sysctl'})

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])

    assert sysctl == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-23 00:33:17.402811
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    sysctl_info = '''net.ipv4.netfilter.ip_conntrack_max = 163840
net.ipv4.netfilter.ip_conntrack_tcp_be_liberal = 1
net.ipv4.netfilter.ip_conntrack_tcp_timeout_close = 5
net.ipv4.netfilter.ip_conntrack_tcp_timeout_close_wait = 5
net.ipv4.netfilter.ip_conntrack_tcp_timeout_establish = 180'''


# Generated at 2022-06-23 00:33:22.303960
# Unit test for function get_sysctl
def test_get_sysctl():
    # pylint: disable=unused-argument
    module = type('', (), {})()
    module.run_command = lambda *args: (0, 'foo=1', '')
    module.warn = lambda *args, **kw: None

    assert get_sysctl(module, ['foo']) == {'foo': '1'}

# Generated at 2022-06-23 00:33:26.663354
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    assert get_sysctl(AnsibleModule(argument_spec=dict()), ['net'])
    assert get_sysctl(AnsibleModule(argument_spec=dict()), ['net.ipv4'])

# Generated at 2022-06-23 00:33:34.584374
# Unit test for function get_sysctl
def test_get_sysctl():
    """Tests for function get_sysctl."""
    __salt__ = {'cmd.run': lambda cmd: 'kern.maxproc: 64\nkern.maxprocperuid: 32',
                'cmd.retcode': lambda cmd: 0}
    prefixes = ['kern.maxproc', 'kern.maxprocperuid']
    expected_sysctl = {'kern.maxproc': '64', 'kern.maxprocperuid': '32'}
    module = ''

    assert expected_sysctl == get_sysctl(module, prefixes)

# Generated at 2022-06-23 00:33:36.573436
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(dict(), 'vm.swappiness') == {'vm.swappiness': '60'}


# Generated at 2022-06-23 00:33:39.621869
# Unit test for function get_sysctl
def test_get_sysctl():
    assert {} == get_sysctl(None, ['nonexistent.key'])
    assert {'nonexistent.key': ''} == get_sysctl(None, ['nonexistent.key', '-e'])

# Generated at 2022-06-23 00:33:41.007735
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, []) == None

# Generated at 2022-06-23 00:33:50.902361
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock


    class TestAnsibleModule(unittest.TestCase):

        def setUp(self):
            self._mock_module = Mock(spec=AnsibleModule)
            self._mock_module.params = {'prefix': 'vm.overcommit_memory'}
            self._mock_module.run_command = Mock(return_value=(0, 'vm.overcommit_memory = 0', ''))

        def test_get_sysctl(self):
            result = get_sysctl(self._mock_module, ['vm.overcommit_memory'])

# Generated at 2022-06-23 00:33:53.759749
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeModule({ 'prefixes': [] })
    rc = get_sysctl(module, module.params['prefixes'])


# Generated at 2022-06-23 00:33:57.265848
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    actual = get_sysctl(module, prefixes=['kernel.ostype'])
    assert('kernel.ostype' in actual)



# Generated at 2022-06-23 00:34:09.449021
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:34:15.051030
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'test': dict(type='bool', required=False)})
    module.exit_json(
        ansible_facts={
            'sysctl': get_sysctl(module, ['kern'])
        }
    )


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:34:21.057937
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    import ansible.modules.system.sysctl

    module = ansible.modules.system.sysctl.SysctlModule(argument_spec={})

    module.get_bin_path = lambda x: '/sbin/sysctl'
    module.run_command = lambda x: (0, '', '')

    get_sysctl(module, ['-a'])

# Generated at 2022-06-23 00:34:31.380118
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    no_matching_path = ['no/matching/path']

    module.run_command = lambda cmd: (0, 'foo = bar', '')
    sysctl = get_sysctl(module, no_matching_path)
    assert sysctl == {'foo': 'bar'}

    module.run_command = lambda cmd: (1, '', 'error message')
    sysctl = get_sysctl(module, no_matching_path)
    assert sysctl == {}

    class TestException(Exception):
        pass

    module.run_command = lambda cmd: raise_exception(TestException('test'))

# Generated at 2022-06-23 00:34:34.429380
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

    prefixes = ('kernel.hostname',)
    sysctl = get_sysctl(module, prefixes)
    assert sysctl.get('kernel.hostname') == socket.gethostname()

# Generated at 2022-06-23 00:34:39.620712
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY2

    module = basic.AnsibleModule(argument_spec={})

    sysctl = get_sysctl(module, ['kern.bootfile'])
    if PY2:
        assert('/netbsd' == sysctl['kern.bootfile'])
    else:
        assert('/netbsd' == sysctl['kern.bootfile'])

# Generated at 2022-06-23 00:34:42.112350
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_values = get_sysctl(module, ['-a'])
    assert sysctl_values['kern.hostname'] == 'localhost'

# Generated at 2022-06-23 00:34:53.784309
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_cmd = './empty_sysctl'
    cmd = [sysctl_cmd]
    cmd.extend(['net.ipv4.tcp_max_syn_backlog', 'net.ipv4.conf.all.forwarding'])
    err = []

    def fake_run_command(*args, **kwargs):
        class f_ret:
            def __init__(self):
                self.rc = 0
                self.stdout = 'net.ipv4.tcp_max_syn_backlog: 4096\nnet.ipv4.conf.all.forwarding: 0\n'
                self.stderr = err
        return f_ret()

    class FakeModule:
        def __init__(self):
            self.run_command = fake_run_command

# Generated at 2022-06-23 00:34:57.240610
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    result = get_sysctl(module, ['net.core.somaxconn'])
    assert result['net.core.somaxconn'] == 128

# Generated at 2022-06-23 00:34:59.416429
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctls = get_sysctl(module, ['kernel.domainname'])
    assert sysctls['kernel.domainname'] == 'example.org'

# Generated at 2022-06-23 00:35:03.773489
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    sysctl = get_sysctl(module, ['net.core.netdev_max_backlog'])
    assert sysctl == {"net.core.netdev_max_backlog": "80"}



# Generated at 2022-06-23 00:35:15.042045
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from sys import version_info

    if version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    mock_module = type('AnsibleModule', (object,), dict(
        fail_json=lambda self, *args, **kwargs: builtins.exit(1),
        warn=lambda self, *args, **kwargs: True,
        run_command=lambda self, args, check_rc=True: (0, "", ""),
        exit_json=lambda self, changed=False, results=dict(), **kwargs: True,
        check_mode=False,
        no_log=set(),
        params=dict(
            prefix=['kern.version'],
        )
    ))()



# Generated at 2022-06-23 00:35:17.359848
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '0'}

# Generated at 2022-06-23 00:35:25.509920
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.all.accept_redirects = 0\nnet.ipv4.conf.all.accept_source_route = 0\n', ''))
    res = get_sysctl(module, ['-n', 'net.ipv4.ip_forward'])
    assert res['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-23 00:35:35.209104
# Unit test for function get_sysctl
def test_get_sysctl():
    import platform
    import sys
    import tempfile
    import os

    sysctl_cmd = 'sysctl'
    if platform.system() == "FreeBSD":
        sysctl_cmd = 'sysctl -n'

    # Use the existing sysctl_cmd to get a baseline value to compare against.
    with tempfile.TemporaryFile() as fh:
        rc, out, err = module.run_command(sysctl_cmd + ' kern.hostname')
        fh.write(out)
        fh.seek(0)
        value = fh.read().strip().decode(u"utf-8")


# Generated at 2022-06-23 00:35:46.615927
# Unit test for function get_sysctl
def test_get_sysctl():
    import os

    from ansible_collections.misc.not_a_real_collection.plugins.modules import sysctl

    module = sysctl

    module.get_bin_path = lambda _: '/sbin/sysctl'

    # Importing check_output from commands doesn't work on py2

# Generated at 2022-06-23 00:35:50.620336
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sysctl = get_sysctl(module, ['kernel'])
    assert 'kernel.hostname' in sysctl
    assert 'kernel.shmmax' in sysctl


# Generated at 2022-06-23 00:35:59.495091
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import sys
    import yaml

    from ansible_collections.jctanner.systemd.tests.unit.compat.mock import patch
    from ansible_collections.jctanner.systemd.plugins.module_utils import systemctl

    # Hacky way to find the command in PATH for unit tests
    for path in os.getenv('PATH').split(':'):
        if os.path.exists(os.path.join(path, 'sysctl')):
            cmd = os.path.join(path, 'sysctl')
            break

    with open('test/unit/output/sysctl', 'r') as f:
        expected_results = yaml.safe_load(f)


# Generated at 2022-06-23 00:36:07.784357
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefix=dict(required=False, type='list', default=[]),
        ),
        supports_check_mode=False,
    )
    prefixes = module.params['prefix']
    sysctl = get_sysctl(module, prefixes)
    result = dict(sysctl=sysctl)
    module.exit_json(**result)

from ansible.module_utils.basic import *

main()

# Generated at 2022-06-23 00:36:17.984406
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    # invalid command
    rc, out, err = module.run_command('invalidcommand')
    assert rc != 0 and not out and err

    # prefixes param is optional
    sysctl = get_sysctl(module)
    assert isinstance(sysctl, dict)

    # test prefixed output
    rc, out, err = module.run_command('echo "foo = bar\nbar = foo"')
    assert rc == 0 and not err and out
    sysctl = get_sysctl(module, [ out.splitlines()[0].split(' = ')[0] ])
    assert sysctl == { out.splitlines()[0].split(' = ')[0]: out.splitlines()[0].split(' = ')[1] }

# Generated at 2022-06-23 00:36:26.396789
# Unit test for function get_sysctl
def test_get_sysctl():
    make_sysctl_output = lambda s: '\n'.join(map(lambda a: ' = '.join(a), s))
    assert get_sysctl({}, ['/bin/echo', make_sysctl_output([('foo', 'bar')])]) == {'foo': 'bar'}
    assert get_sysctl({}, ['/bin/echo', make_sysctl_output([('foo', 'bar'), ('baz', None)])]) == {'foo': 'bar', 'baz': None}
    assert get_sysctl({}, ['/bin/echo', make_sysctl_output([('foo', 'bar'), ('baz', '')])]) == {'foo': 'bar', 'baz': ''}

# Generated at 2022-06-23 00:36:35.875947
# Unit test for function get_sysctl
def test_get_sysctl():
    mock = MagicMock()
    for line in [
        'kern.loginclass.class: staff',
        'kern.loginclass.name: staff',
        'kern.loginclass.path: /usr/bin:/bin:/usr/sbin:/sbin',
        'kern.loginclass.ipriviliged: 0',
        'kern.loginclass.user: _staff',
        'kern.loginclass.group: _staff',
    ]:
        mock.run_command.return_value = (0, line, '')
        sysctl = get_sysctl(mock, ['-a'])
        assert sysctl['kern.loginclass.class'] == 'staff'
        assert '_staff' in sysctl['kern.loginclass.user']

# Generated at 2022-06-23 00:36:46.953113
# Unit test for function get_sysctl
def test_get_sysctl():
    mock_module = MockModule()

    sysctl_out1 = '''\
hw.physmem: 8589934592
vm.swapusage: 8192    0    8192
hw.ncpu: 2
hw.byteorder: 1234
'''

    mock_module.run_command = Mock(return_value=(0, sysctl_out1, ''))
    sysctl1 = get_sysctl(mock_module, [])
    assert sysctl1 == {
        'hw.physmem': '8589934592',
        'vm.swapusage': '8192    0    8192',
        'hw.ncpu': '2',
        'hw.byteorder': '1234'
    }


# Generated at 2022-06-23 00:36:51.000512
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockLinux()
    result = get_sysctl(module, ['vm'])
    assert('vm.overcommit_ratio' in result)
    assert('vm.panic_on_oom' not in result)


# Generated at 2022-06-23 00:37:01.735447
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:37:07.616648
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(typs='list', default=[])
        ),
        supports_check_mode=True
    )

    module.run_command = fake_run_command

    assert isinstance(get_sysctl(module, ['kern.boottime']), dict)
    assert isinstance(get_sysctl(module, []), dict)

