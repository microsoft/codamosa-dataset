

# Generated at 2022-06-23 00:27:18.803508
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModuleMock('/bin/echo true'
                               ' && /bin/echo "kern.hostname = foo"')
    sysctl = get_sysctl(module, ['kern.hostname'])
    assert sysctl == {'kern.hostname': 'foo'}

    module = AnsibleModuleMock('/bin/echo true'
                               ' && /bin/echo "kern.hostname = foo\\nfoo.bar = bar"')
    sysctl = get_sysctl(module, ['kern.hostname', 'foo.bar'])
    assert sysctl == {'kern.hostname': 'foo', 'foo.bar': 'bar'}


# Generated at 2022-06-23 00:27:29.295212
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import ansible.modules.system.os_family
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO

    try:
        from test.support import EnvironmentVarGuard
    except ImportError:
        from test.test_support import EnvironmentVarGuard


# Generated at 2022-06-23 00:27:35.746762
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = AnsibleModule(argument_spec=dict())

    test_sysctl = get_sysctl(test_module, ['kern.osrelease', 'hw.acpi.thermal.tz0.temperature'])
    assert test_sysctl == {'hw.acpi.thermal.tz0.temperature': '28.5C', 'kern.osrelease': '11.0-STABLE'}


# Generated at 2022-06-23 00:27:41.998530
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test module argument parse.
    assert get_sysctl(module=None, prefixes=None) is None
    assert get_sysctl(module=None, prefixes=[]) is None
    assert get_sysctl(module=None, prefixes=['hw', 'hw']) is None
    assert get_sysctl(module=None, prefixes=['hw', 'hw']) is None

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 00:27:50.531667
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    module.run_command = lambda cmd: (0, 'vm.swappiness = 0\nvm.overcommit_memory = 1\n', '')

    exp_result = {'vm.swappiness': '0', 'vm.overcommit_memory': '1'}
    assert get_sysctl(module, ['vm.swappiness']) == exp_result

    # Test multiline values
    module.run_command = lambda cmd: (0, 'vm.swappiness = 0\nvm.overcommit_memory = 1\nvm.vdso_enabled = 1\n  Value: 1\n', '')
    exp_result['vm.vdso_enabled'] = ('1\n  Value: 1')

# Generated at 2022-06-23 00:27:53.779704
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )


# Generated at 2022-06-23 00:27:55.561619
# Unit test for function get_sysctl
def test_get_sysctl():
    # FIXME: Unit test this. We shouldn't be relying on the network
    # connection to test this.
    pass

# Generated at 2022-06-23 00:27:59.636883
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.version'])
    assert 'vm.version' in sysctl and sysctl['vm.version'] != ''



# Generated at 2022-06-23 00:28:04.800281
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefix': dict(type='list')})
    prefix = ['net.ipv4.ip_forward']
    result = {u'net.ipv4.ip_forward': u'0'}
    assert get_sysctl(module, prefix) == result


# Generated at 2022-06-23 00:28:12.118808
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    import ansible.module_utils.system
    ansible.module_utils.basic.ANSIBLE_ARGS = ['--syntax-check', '-vvvv', '-C']

    # Setup a dummy module
    module = ansible.module_utils.system.SystemModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=[]),
        ),
        supports_check_mode=True,
    )

    assert get_sysctl(module, module.params['prefixes']) == dict()

# Generated at 2022-06-23 00:28:16.890452
# Unit test for function get_sysctl
def test_get_sysctl():
    print ('Running unit test')
    print (get_sysctl('/sbin', ['net.ipv4.tcp_congestion_control']))

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:28:27.934880
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import load_platform_subclass

    mock_module = load_platform_subclass('ansible.netcommon.network_cli', 'NetworkModule')

    prefixes = ['kernel.printk', 'fs.file-max']
    values = {
        'kernel.printk': '4 4 1 7',
        'fs.file-max': '100000'
    }

    with patch('ansible.module_utils.basic.AnsibleModule.run_command'):
        mock_module.run_command.return_value = 0, 'kernel.printk = 4 4 1 7\nfs.file-max = 100000',

# Generated at 2022-06-23 00:28:33.900764
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule()
    EXPECTED_RETVAL = {
        'kernel.domainname': 'example.com'
    }
    TEST_CMD_OUTPUT = 'kernel.domainname = example.com'
    module.run_command = MagicMock(return_value=(0, TEST_CMD_OUTPUT, ''))
    assert get_sysctl(module, ['not_important']) == EXPECTED_RETVAL

# Generated at 2022-06-23 00:28:44.328117
# Unit test for function get_sysctl

# Generated at 2022-06-23 00:28:48.438726
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockAnsibleModule()
    module.run_command = MockRunCommand()
    sysctl = get_sysctl(module, ['hw.memsize'])

    assert sysctl == {'hw.memsize': '67108864'}



# Generated at 2022-06-23 00:28:58.489377
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    # Return the expected result for the command sysctl -a
    # If the command is run on a different platform, it will return
    # different result. These result must be updated in the unit test
    # to reflect the new values.


# Generated at 2022-06-23 00:29:07.513246
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    p = m.get_bin_path('sysctl')
    import os
    if not os.path.exists(p):
        m.fail_json(msg='Could not find sysctl')

    sysctl = get_sysctl(m, [])
    assert sysctl
    assert isinstance(sysctl, dict)



# Generated at 2022-06-23 00:29:18.777669
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Test the get_sysctl function with a known sysctl output
    """

    import tempfile
    import os
    import shutil


    # Create a test sysctl output file
    (fd, filename) = tempfile.mkstemp()

# Generated at 2022-06-23 00:29:22.095571
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    get_sysctl does not work on python2 without backports
    so it can't be tested on travis, which uses python2.7
    '''
    pass

# Generated at 2022-06-23 00:29:32.956610
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Unit test for get_sysctl()
    """
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    # AnsibleModule.run_command is the function which actually invokes
    # the 'sysctl' command.  For the purposes of this unit test we need
    # to fake out its behavior.  To do this we will "monkey patch" it
    # with a class which returns predetermined output for the 'sysctl'
    # command.
    #
    # We define this class inside the unit test function because it
    # doesn't make sense to define a class which only has a single user
    # at the module level.  Monkeying with AnsibleModule.run_command
    # isn't a good idea either because it's likely that it could
    # conflict with other stuff.
   

# Generated at 2022-06-23 00:29:40.370108
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.modules.network.ios import get_sysctl


# Generated at 2022-06-23 00:29:49.157315
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefixes = dict(),
        )
    )
    sysctl = get_sysctl(module, ['vm', 'swapusage'])

    assert sysctl['vm.swapusage.total']
    assert sysctl['vm.swapusage.used']
    assert sysctl['vm.swapusage.free']
    assert sysctl['vm.swapusage.sin']
    assert sysctl['vm.swapusage.sout']

    assert "vm.swapusage.total = 0\nvm.swapusage.used = 0\nvm.swapusage.free = 0\nvm.swapusage.sin = 0\nvm.swapusage.sout = 0" == sysctl['vm.swapusage']
# end of test_get_sysctl

# Generated at 2022-06-23 00:29:59.953121
# Unit test for function get_sysctl
def test_get_sysctl():
    """ Unit tests for get_sysctl """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, to_bytes('''
net.ipv4.ip_forward = 0
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.ip_local_max_links = 35
'''), '')
    sysctl = get_sysctl(module, ["net.ipv4.conf.default.proxy_arp", "vm.swappiness"])

# Generated at 2022-06-23 00:30:09.937040
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    # pylint: disable=too-many-locals
    def get_bin_path(name, *args):
        return '/bin/sysctl'

    module_args = dict()

    m = AnsibleModule(argument_spec=module_args)
    m.get_bin_path = get_bin_path

    out = '''
a = 1
b = 2
c = 3
d =
    1
    2
    3
'''

    m.run_command = lambda *args, **kwargs: (0, out, '')

    compiled_regex = re.compile(r'\s?=\s?|: ')

# Generated at 2022-06-23 00:30:15.550956
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec = dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])

    assert isinstance(sysctl, dict)

    assert 'net.ipv4.ip_forward' in sysctl
    assert sysctl['net.ipv4.ip_forward'] in ['0', '1']



# Generated at 2022-06-23 00:30:26.480323
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch, MagicMock


# Generated at 2022-06-23 00:30:30.179915
# Unit test for function get_sysctl
def test_get_sysctl():

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])

    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-23 00:30:36.096893
# Unit test for function get_sysctl
def test_get_sysctl():
    """ Unit test for function get_sysctl """
    module_run_command_mock = MagicMock()
    current_sysctl = get_sysctl('foo')
    module_run_command_mock.assert_called_once_with('foo')
    assert current_sysctl == {'key1' : 'value1'}


# Generated at 2022-06-23 00:30:46.160205
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {})()
    module.run_command = Mock(return_value=(0, 'net.ipv4.tcp_max_syn_backlog = 2048\nnet.ipv4.ip_forward = 1\nnet.ipv4.conf.default.accept_source_route = 0\nnet.ipv4.conf.all.rp_filter = 1\n', ''))
    get_sysctl(module, ['net.ipv4.tcp_max_syn_backlog', 'net.ipv4.ip_forward', 'net.ipv4.conf.default.accept_source_route'])

# Generated at 2022-06-23 00:30:48.281136
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = ['vm', '.']
    assert isinstance(get_sysctl(module, prefixes), dict)


# Generated at 2022-06-23 00:31:00.773373
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    test_text = u'''

net.core.rmem_default = 16777216
net.core.rmem_max = 16777216
net.core.somaxconn = 511
net.core.wmem_default = 16777216
net.core.wmem_max = 16777216
'''

    with open(sysctl_cmd, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo "%s"\n' % test_text)


# Generated at 2022-06-23 00:31:12.497840
# Unit test for function get_sysctl
def test_get_sysctl():
    # Define module mock class
    class AnsibleModuleMock:
        def get_bin_path(self, bin_path):
            return bin_path

        def run_command(self, command):
            if command == ['sysctl', 'vm.swappiness']:
                return (0, 'vm.swappiness = 0\n', None)
            elif command == ['sysctl', 'net.ipv4.conf.all.forwarding']:
                return (0, 'net.ipv4.conf.all.forwarding = 0\n', None)

# Generated at 2022-06-23 00:31:21.460967
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl = get_sysctl(module, ['hw', 'memsize'])

    if PY2:
        expected_output = {'hw.memsize': '4294967296'}
    else:
        expected_output = {b'hw.memsize': b'4294967296'}

    module.exit_json(changed=False, stdout=sysctl, stderr='')

# Generated at 2022-06-23 00:31:27.998398
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    result = get_sysctl(module, [])
    assert result
    assert not isinstance(result, list)
    assert isinstance(result, dict)

    result = get_sysctl(module, ['vm.overcommit_memory=0'])
    assert result
    assert not isinstance(result, list)
    assert isinstance(result, dict)

# Generated at 2022-06-23 00:31:34.348145
# Unit test for function get_sysctl
def test_get_sysctl():
    fake_module = type('', (object,), {'run_command': lambda *a, **k: (0, 'kern.securelevel: 1\nkern.test: 2', '')})

    sysctl = get_sysctl(fake_module, [])

    assert len(sysctl) == 2
    assert sysctl['kern.securelevel'] == '1'
    assert sysctl['kern.test'] == '2'


# Generated at 2022-06-23 00:31:37.254241
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list')))
    get_sysctl(module, prefixes)

# Generated at 2022-06-23 00:31:39.021456
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('', ['rescue']) == {'rescue.level': '1'}



# Generated at 2022-06-23 00:31:51.359146
# Unit test for function get_sysctl
def test_get_sysctl():
    # For the purposes of testing, we define a function that "acts" like a module
    class TestModule(object):
        def __init__(self, ansible_args):
            self.params = ansible_args

        def get_bin_path(self, command):
            # For testing, assume the command sysctl exists in the path
            return "sysctl"

        def run_command(self, command):
            # For testing, assume that there is no error and use the command
            # that was passed in as the input for get_sysctl
            # and that the output will contain the command to show the parameter
            return 0, command[0], ""

        def warn(self, warning_msg):
            # Override the warning method to do nothing
            pass


# Generated at 2022-06-23 00:32:02.215281
# Unit test for function get_sysctl
def test_get_sysctl():
    # Trivial module stub
    class StubModule():
        def run_command(self, cmd):
            return (0, '''
kern.clockrate: { hz = 100, tick = 10000, tickadj = 25, profhz = 100, stathz = 100 }
kern.hostname: foo.bar
kern.hz: 100
kern.maxfiles: 49152
kern.maxusers: 128
kern.ostype: FreeBSD
kern.osrelease: 12.0-RELEASE-p6
kern.posix1version: 200112
''', '')

        def get_bin_path(self, cmd):
            return cmd

    module = StubModule()
    sysctl = get_sysctl(module, ['kern'])

# Generated at 2022-06-23 00:32:13.399969
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = lambda cmd: (0, 'kern.maxfiles: 1234\nkern.maxfilesperproc: 2345', '')
    assert get_sysctl(module, ['kern.maxfiles', 'kern.maxfilesperproc']) == {
        'kern.maxfiles': '1234',
        'kern.maxfilesperproc': '2345'
    }

    module.run_command = lambda cmd: (1, '', 'sysctl: unknown oid')
    assert get_sysctl(module, ['kern.maxfiles']) == {}


# Generated at 2022-06-23 00:32:25.103795
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec=dict(),
    )

    # Generate a fake module with a fake bin path so that we can test
    # the return values.
    m.params['_ansible_verbosity'] = 0
    m.params['ANSIBLE_MODULE_ARGS'] = ''
    m.bin_path = './%s' % m.get_bin_path('sysctl')

    # Test our ability to skip empty lines in the output
    m.run_command = lambda x, **kwargs: (0, '\n\n# \nkernel.hostname = test\nkernel.domainname = test\n', '')

# Generated at 2022-06-23 00:32:36.784297
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    if sys.version_info.major != 2:
        # In Python 3 readline returns an str instead of a byte string
        # this will break our tests
        raise Exception('Tests must be run in Python 2.')

    # We need to set this to use the current sys.stdout so we can mock run_command
    # which will print stdout/stderr while its running
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic

    class TestAnsibleModule(AnsibleModule):
        pass


# Generated at 2022-06-23 00:32:42.632176
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object
    prefixes = ['-a']
    sysctl = get_sysctl(module, prefixes)
    assert type(sysctl) == type(dict())
    assert 'kernel' in sysctl
    assert 'user' in sysctl
    assert 'vm' in sysctl



# Generated at 2022-06-23 00:32:50.123926
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, [])

    assert sysctl is not None
    assert 'kernel.ostype' in sysctl
    assert sysctl['kernel.ostype'] == 'Linux'
    assert 'kernel.osrelease' in sysctl
    assert sysctl['kernel.osrelease'] == '3.10.0-327.el7.x86_64'

# Generated at 2022-06-23 00:32:58.140028
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(dict(), ['kernel.domainname']) == {'kernel.domainname': 'nelchael.wlan.frogfoot.net'}
    assert get_sysctl(dict(), ['kernel.domainname', 'kernel.ostype']) == {'kernel.domainname': 'nelchael.wlan.frogfoot.net', 'kernel.ostype': 'Linux'}
    assert get_sysctl(dict(), ['no.such.sysctl']) == dict()
    assert get_sysctl(dict(), ['kernel.domainname', 'no.such.sysctl']) == {'kernel.domainname': 'nelchael.wlan.frogfoot.net'}

# Generated at 2022-06-23 00:33:09.804517
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils._text import to_bytes
    import json
    from ansible.module_utils import basic
    import os

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Mock module.run_command
    def mock_run_command(args):
        sysctl = dict()
        sysctl['kern.domainname'] = 'localdomain'
        sysctl['kern.hostname'] = 'localhost'
        sysctl['kern.osreldate'] = '1100027'

        if args[0] == module.get_bin_path('sysctl'):
            return 0, json.dumps(sysctl), ''

        return 0, '', ''

    module.run_command = mock_run_command



# Generated at 2022-06-23 00:33:21.748269
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.compat.tests import unittest
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )

    module.run_command = lambda args: (0, 'kern.hostname = mongos\nnet.inet.ip.forwarding: 1', '')

    out = get_sysctl(module, ['kern.hostname', 'net.inet.ip.forwarding'])

    assert('net.inet.ip.forwarding' in out)
    assert(out['net.inet.ip.forwarding'] == '1')

    assert('kern.hostname' in out)
    assert(out['kern.hostname'] == 'mongos')

# vim: set et ts=4 sw=4

# Generated at 2022-06-23 00:33:24.878107
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module)

    assert 'kern.hostname' in sysctl
    assert 'net.inet.ip.forwarding' in sysctl


# Generated at 2022-06-23 00:33:36.468126
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):

        def run_command(self, args, check_rc=True):
            return (0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.all.forwarding = 1\nnet.ipv4.conf.default.forwarding = 1\n', '')

    module = TestModule()
    result = {'net.ipv4.ip_forward': '1', 'net.ipv4.conf.all.forwarding': '1', 'net.ipv4.conf.default.forwarding': '1'}
    assert result == get_sysctl(module, [])


if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:33:45.996901
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # sysctl module is not installed on this system
    module.expect_failure = True
    assert get_sysctl(module, ['kernel.bootloader_type']) == {}

    # sysctl module is installed on this system
    # add more tests here to be sure the function runs properly
    module.expect_failure = False
    assert 'syslinux' in get_sysctl(module, ['kernel.bootloader_type'])['kernel.bootloader_type']

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-23 00:33:57.743447
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    path1 = '.ansible_test/etc/sysctl.d/01-test.conf'
    path2 = '.ansible_test/etc/sysctl.conf'
    path3 = '.ansible_test/etc/sysctl.x_broken'

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list'),
        ),
    )

    try:
        os.makedirs(os.path.dirname(path1))
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise


# Generated at 2022-06-23 00:34:05.912908
# Unit test for function get_sysctl
def test_get_sysctl():
    import module_utils.system.sysctl as mysysctl
    import sys

    fake_module = sys.modules[__name__]
    fake_module.get_bin_path = lambda x: 'sysctl'
    fake_module.run_command = lambda x: (0, 'vm.swappiness = 1', '')

    sysctl = mysysctl.get_sysctl(fake_module, ['vm.swappiness'])
    assert sysctl.get('vm.swappiness') == '1'


# Generated at 2022-06-23 00:34:16.867258
# Unit test for function get_sysctl
def test_get_sysctl():
    try:
        import __builtin__ as builtins
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        import builtins
        from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    setattr(builtins, "__salt__", {"cmd.run": get_sysctl})
    module.run_command = lambda *args, **kwargs: __salt__["cmd.run"](*args, **kwargs)

    module.get_bin_path = lambda *args, **kwargs: "test_sysctl"
    result = get_sysctl(module, ["kernel.hostname"])
    assert result == {"kernel.hostname": "myhost"}

# Generated at 2022-06-23 00:34:25.092189
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'check_mode': False})
    module.run_command = lambda x: (0, "", "")
    assert module.run_command(['sysctl', '-w', 'foo=bar'])[0] == 0
    assert module.run_command(['sysctl', '-w', 'foo.bar=bar'])[0] == 0
    assert get_sysctl(module, ['foo.bar']) == {'foo.bar': 'bar'}

# Generated at 2022-06-23 00:34:34.950372
# Unit test for function get_sysctl
def test_get_sysctl():
    # python3 compatibility:
    # Test_module = None
    Test_module = type('', (), {})()
    Test_module.run_command = run_cmd
    Test_module.warn = warn
    Test_module.get_bin_path = get_path

    prefixes = ['net.ipv4.conf']
    sysctl = get_sysctl(Test_module, prefixes)


# Generated at 2022-06-23 00:34:43.703407
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {})()

    import mock
    import operator
    import os

    def run_command(args, **kwargs):
        return 0, 'net.ipv4.ip_forward: 0', ''

    module.run_command = mock.MagicMock(side_effect=run_command)
    module.get_bin_path = mock.MagicMock(side_effect=operator.itemgetter('/sbin/sysctl'))

    sysctl = get_sysctl(module, 'net.ipv4.ip_forward')

    assert sysctl == {'net.ipv4.ip_forward': '0'}

# Generated at 2022-06-23 00:34:46.046764
# Unit test for function get_sysctl
def test_get_sysctl():
    assert 'kern.ostype' in get_sysctl(object, ['-a'])


# Generated at 2022-06-23 00:34:56.769810
# Unit test for function get_sysctl
def test_get_sysctl():
    # Example sysctl output
    sysctl_output = """
net.ipv4.ip_forward = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.default.secure_redirects = 1
net.ipv4.conf.default.send_redirects = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 1
net.ipv4.conf.all.send_redirects = 1
    """

    sysctl = get_sysctl

# Generated at 2022-06-23 00:35:00.122228
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec=dict())
    assert get_sysctl(module, ['kernel.osrelease'])['kernel.osrelease'] == '4.4.0-31-generic'

# Generated at 2022-06-23 00:35:02.882584
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['net.ipv4.ip_forward'])['net.ipv4.ip_forward'] == '1'



# Generated at 2022-06-23 00:35:08.072269
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = [ 'kernel.ngroups_max' ]
    sysctl = get_sysctl(module, prefixes)
    assert int(sysctl['kernel.ngroups_max']) > 0
    assert not 'kernel.sched_rr_timeslice_ms' in sysctl


# Generated at 2022-06-23 00:35:18.568334
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Unit test for function get_sysctl
    """
    import sys
    # Python 2 and 3 compatible "metaclass"
    # This is required to have the AnsibleModule and AnsibleAction available
    class AnsibleMeta(type):
        """Metaclass for Ansible"""
        def __new__(cls, name, bases, d):
            module = type.__new__(cls, name, bases, d)
            if sys.version_info[0] >= 3:
                module._ANSIBLE_ARGS = frozenset(dir(module))
            else:
                module._ANSIBLE_ARGS = frozenset(dir(module))
            return module

    # Python 2 and 3 compatible metaclass usage
    # This is required to have the AnsibleModule and AnsibleAction available

# Generated at 2022-06-23 00:35:29.532153
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3

    module_args = dict()
    module = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True, **module_args)

    # Set module.run_command so we can control the return value
    def fake_run_command(args, **kwargs):
        module.run_command_args = args
        return mock_run_command(args, **kwargs)

    module.run_command = fake_run_command

    # Set up the mock return values
    module.run_command_args = None
    mock_run_command = dict()
    mock_run_command[('sysctl', '-a')] = 0, "", ""


# Generated at 2022-06-23 00:35:38.474618
# Unit test for function get_sysctl
def test_get_sysctl():
    '''Test basic functionality'''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    prefixes = ['vm.max_map_count']

    m = dict(
        run_command=dict(
            return_value=(0, 'vm.max_map_count = 262144', '')),
        get_bin_path=dict(
            return_value='/usr/bin/sysctl'))

    module.execute_module(mock_module=m)
    sysctl = get_sysctl(module, prefixes)
    assert sysctl == {'vm.max_map_count': '262144'}


# Generated at 2022-06-23 00:35:42.784352
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    prefixes = ['kern.ostype', 'kern.osrelease']
    assert get_sysctl(module, prefixes) == {
        'kern.ostype': 'Darwin',
        'kern.osrelease': '15.6.0'
    }


# Generated at 2022-06-23 00:35:53.609120
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os.path

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
    os.environ['ANSIBLE_MODULE_UTILS'] = os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils')

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = fake_run_command
    module.get_bin_path = fake_get_bin_path

    sysctl = get_sysctl(module, ['kern.boottime'])
    assert sysctl['kern.boottime'] == 'Sat Nov 19 15:09:02 2016'
    sysctl = get_sysctl

# Generated at 2022-06-23 00:36:05.730476
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.constants as C
    # Setting to False to lower code coverage test to ignore tests below
    if C.DEFAULT_KEEP_REMOTE_FILES is False:
        C.DEFAULT_KEEP_REMOTE_FILES = True

    # Null IO
    class NullIO:
        def write(self, x):
            pass

    # Null Module
    class NullModule:
        def __init__(self):
            self.params = dict()
            self.sysctl = dict()
            self.warnings = list()

        def get_bin_path(self, x, opt_dirs=[]):
            # Return a non-existing file to test the run_command error handling
            return '/non-existing-file'


# Generated at 2022-06-23 00:36:10.577659
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    results = get_sysctl(module, ['vm.overcommit_memory', 'vm.swappiness'])
    expected_results = {'vm.overcommit_memory': '0',
                        'vm.swappiness': '60'}
    assert results == expected_results

# Generated at 2022-06-23 00:36:18.443197
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    module = AnsibleModule(
        argument_spec=dict()
    )

    try:
        sysctl = get_sysctl(module, ['kernel.random_maxtry'])
        assert sysctl['kernel.random_maxtry'] == '30'
    except AssertionError as e:
        exception = get_exception()
        module.fail_json(msg=str(exception))



# Generated at 2022-06-23 00:36:29.308524
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    # Create fake test module
    test_module = AnsibleModule(
        argument_spec = dict()
    )

    # Test a real result from sysctl, run in a subprocess
    # to prevent side effects from the sysctl call
    if 0 == os.system('python -c "from ansible.module_utils.basic import AnsibleModule; from ansible.module_utils.basic import get_sysctl; import json; print json.dumps(get_sysctl(AnsibleModule(argument_spec=dict()), [\'vm.stats_accounting_run_max\']))"'):
        raise AssertionError(
            "Unit test for get_sysctl was successful, but expected a fail"
        )



# Generated at 2022-06-23 00:36:40.159464
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern'])
    assert set(sysctl.keys()) == {'kern.bootfile', 'kern.boottime', 'kern.hostid', 'kern.hostname', 'kern.hz', 'kern.osreldate', 'kern.posix1version', 'kern.ostype', 'kern.osrelease', 'kern.version', 'kern.domainname', 'kern.maxpartitions'}
    assert sysctl['kern.osreldate'] == '120000'
    assert sysctl['kern.hostname'] == 'testhost'


# Generated at 2022-06-23 00:36:48.475389
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {'params': {}, 'run_command' : [],
                           'warn' : [], 'get_bin_path' : []})()
    module.params = {}
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.warn = lambda *args, **kwargs: None
    module.get_bin_path = lambda *args, **kwargs: []
    assert set(get_sysctl(module, ['kernel.sched_child_runs_first']).keys()) == set(['kernel.sched_child_runs_first'])

# Generated at 2022-06-23 00:36:57.961632
# Unit test for function get_sysctl
def test_get_sysctl():
    class DummyModule:
        def get_bin_path(self, name):
            return name

        def run_command(self, args):
            class DummyException(Exception):
                pass
            if args[0] == 'sysctl':
                raise OSError('File not found')
            else:
                raise DummyException('This should never happen')
        def warn(self, message):
            pass

    module = DummyModule()
    # Test IOError and OSError
    assert get_sysctl(module, ['a']) == {}
    module = DummyModule()
    # Test empty output
    rc = 0
    out = ''
    err = ''
    module.run_command = lambda args: (rc, out, err)
    assert get_sysctl(module, ['a']) == {}
    #

# Generated at 2022-06-23 00:37:08.268537
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    sysctl_result = """
    kernel.hostname = localhost
    kernel.sem = 250  32000 32  512
    kernel.shmmax = 68719476736
    kernel.shmall = 4294967296
    """

    sysctl_dict = {
        'kernel.hostname': 'localhost',
        'kernel.sem': '250  32000 32  512',
        'kernel.shmmax': '68719476736',
        'kernel.shmall': '4294967296'
    }

    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list')))
    module.run_command = lambda cmd: (0, sysctl_result, '')