

# Generated at 2022-06-20 18:40:52.694835
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.chdir = '/tmp'
    module.run_command = lambda x: [ 0, 'answer=42', '' ]
    assert module.get_bin_path('sysctl') == 'sysctl'
    assert get_sysctl(module, []) == {'answer': '42'}

# Generated at 2022-06-20 18:41:03.736877
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # test with 6.0
    module.run_command = lambda cmd: (0, 'vm.max_map_count = 65530\n', None)
    assert get_sysctl(module, ['vm.max_map_count'])['vm.max_map_count'] == '65530'

    # test with 5.5
    module.run_command = lambda cmd: (0, 'vm.max_map_count: 65530\n', None)
    assert get_sysctl(module, ['vm.max_map_count'])['vm.max_map_count'] == '65530'

    # test with 5.5 and two arguments

# Generated at 2022-06-20 18:41:12.570460
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.arguments import ArgumentSpec
    from ansible.module_utils.facts.sysctl import get_sysctl

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='str', required=True),
        ),
    )

    prefixes = ' '.join(module.params['prefixes'])

    sysctl = dict()

    get_sysctl(module, prefixes)

# Generated at 2022-06-20 18:41:16.455599
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({'bin_path': {'sysctl': '/sbin/sysctl'}, 'run_command': test_run_command}, ['-a']) == {'vm.swappiness': '60'}



# Generated at 2022-06-20 18:41:23.516187
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    from ansible.module_utils.basic import AnsibleModule

    dummy_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl_data = get_sysctl(dummy_module, ['-n', 'fs.file-max'])
    sys.stderr.write("{0}\n".format("fs.file-max" in sysctl_data))

    sysctl_list_data = get_sysctl(dummy_module, ['-a'])
    sys.stderr.write("{0}\n".format("fs.file-max" in sysctl_list_data))



# Generated at 2022-06-20 18:41:32.408695
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:41:34.798136
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(['/proc/sys/net/ipv4/ip_forward'], 'net.ipv4.ip_forward') == 1

# Generated at 2022-06-20 18:41:38.324668
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockAnsibleModule()
    prefixes = ['-a']
    result = get_sysctl(module, prefixes)
    assert result, 'get_sysctl should not return empty'


# Generated at 2022-06-20 18:41:46.879813
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule
    module.run_command = mock.MagicMock(return_value=(0, 'vm.swappiness = 60', ''))
    assert get_sysctl(module, ['vm.swappiness']) == {'vm.swappiness': '60'}

    module.run_command = mock.MagicMock(return_value=(0, ['vm.swappiness = 60', 'vm.overcommit_memory = 0'], ''))
    assert get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory']) == {'vm.swappiness': '60', 'vm.overcommit_memory': '0'}

    module.run_command = mock.MagicMock(return_value=(0, 'vm.swappiness = 60', ''))

# Generated at 2022-06-20 18:41:54.131619
# Unit test for function get_sysctl
def test_get_sysctl():
    """Test get_sysctl function"""
    # test_module must be available in the test directory
    # since it is used by the module_utils.basic.py load_platform_subclass
    # to determine which implementation to load
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.os.linux import get_sysctl

    test_module = AnsibleModule()

    assert get_sysctl(test_module, ['kernel.shmmax']) == {'kernel.shmmax': '68719476736'}


# Generated at 2022-06-20 18:42:08.426825
# Unit test for function get_sysctl
def test_get_sysctl():
    class Module(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name):
            return name

        def run_command(self, args, check_rc=False, close_fds=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

        def warn(self, msg):
            pass

    def test_parse(sysctl_out, expected):
        module = Module()
        module.run_command_results = [(0, sysctl_out, '')]

        result = get_sysctl(module, [])

        assert result == expected


# Generated at 2022-06-20 18:42:17.730519
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl

    # Test with a sysctl that exists
    test = sysctl.get_sysctl({'get_bin_path': lambda x: '/sbin/sysctl'}, ['net.ipv4.ip_local_port_range'])
    assert 'net.ipv4.ip_local_port_range' in test
    assert test['net.ipv4.ip_local_port_range'] == '32768    61000'

    # Test with a sysctl that does not exist
    test = sysctl.get_sysctl({'get_bin_path': lambda x: '/sbin/sysctl'}, ['does.not.exist'])
    assert 'does.not.exist' not in test

# Generated at 2022-06-20 18:42:29.629003
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': {'type': 'list', 'default': []}})
    res = {}

    res['rc'] = 0

# Generated at 2022-06-20 18:42:34.816364
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    test_sysctl = get_sysctl(module, ['kern.ostype', 'kern.osrelease'])
    assert isinstance(test_sysctl, dict)
    assert 'kern.ostype' in test_sysctl
    assert 'kern.osrelease' in test_sysctl

# Generated at 2022-06-20 18:42:46.320679
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    # get_sysctl requires a module, create a fake one to use for testing
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)

    # test a simple get_sysctl call
    prefixes = ['vm.swappiness']
    expected_sysctl = {'vm.swappiness': '60'}
    sysctl = get_sysctl(module, prefixes)
    assert sysctl == expected_sysctl

    # test a get_sysctl call with multiple prefixes
    prefixes = ['vm', 'net']

# Generated at 2022-06-20 18:42:50.753007
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'prefixes': {'type': 'list', 'required': True}}, supports_check_mode=True)

    sysctl = get_sysctl(module, module.params['prefixes'])

    module.exit_json(changed=False, sysctl=sysctl)


if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:43:01.378539
# Unit test for function get_sysctl
def test_get_sysctl():
    module = mock.MagicMock()
    sysctl_cmd = '/sbin/sysctl'
    sysctl_out = '''
        net.ipv4.conf.all.rp_filter = 1
        net.ipv4.conf.default.rp_filter = 1
    '''
    sysctl_out_error = '''
        ERROR: '/proc/sys/net/ipv4/conf/all/rp_filter' is an unknown key

    '''
    expected_dict = {
        'net.ipv4.conf.all.rp_filter': '1',
        'net.ipv4.conf.default.rp_filter': '1'
    }
    expected_dict_error = {}
    expected_rc = 0
    expected_rc_error = 1


# Generated at 2022-06-20 18:43:09.329665
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:43:19.176362
# Unit test for function get_sysctl
def test_get_sysctl():
    module = Mock()

# Generated at 2022-06-20 18:43:21.204860
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(prefixes=['net.ipv4.ip_forward']) == '1'

# Generated at 2022-06-20 18:43:44.388196
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = type('module', (object,), {'run_command': run_command, 'get_bin_path': lambda self, path: path})
    test_module_instance = test_module()
    assert get_sysctl(test_module_instance, ["fs.file-max"]) == {'fs.file-max': '1048576'}
    assert get_sysctl(test_module_instance, ["fs.inotify.max_user_watches"]) == {'fs.inotify.max_user_watches': '100000'}
    assert get_sysctl(test_module_instance, ["kernel.shmall"]) == {'kernel.shmall': '4294967296'}

# Generated at 2022-06-20 18:43:47.285114
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModuleTestUtils.get_module_mock('sysctl')
    values = get_sysctl(module, ['kernel.hostname'])
    assert len(values) > 0
    assert 'kernel.hostname' in values



# Generated at 2022-06-20 18:43:52.442381
# Unit test for function get_sysctl
def test_get_sysctl():
    _module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    _sysctl = get_sysctl(_module, ['net.ipv4.ip_default_ttl'])

    assert _sysctl['net.ipv4.ip_default_ttl'] == '64'



# Generated at 2022-06-20 18:44:02.819224
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)


# Generated at 2022-06-20 18:44:09.598413
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda *args, **kwargs: (0, 'foo = bar\nbar: baz\nother: value', '')

    assert get_sysctl(module, ['foo']) == {'foo': 'bar', 'bar': 'baz'}


# Generated at 2022-06-20 18:44:11.102559
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['kern']).get('kern.ostype') == 'FreeBSD'

# Generated at 2022-06-20 18:44:20.724958
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    my_module = AnsibleModule(argument_spec=[], supports_check_mode=True)

    # Mock up os.path.exists to return True so the sysctl binary will be found.
    # We previously tested to see if the binary exists before trying to run it.
    my_module.run_command = lambda x: (0, '', '')
    my_module.get_bin_path = lambda x: os.path.realpath(os.path.join(os.path.dirname(__file__), 'test_sysctl'))

    cli_sysctl = get_sysctl(my_module, ('test.item=one', 'test.something.else'))
    assert len(cli_sysctl) == 2

# Generated at 2022-06-20 18:44:25.094067
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    prefixes = ['kern.boottime', 'kern.bufcachepercent']
    assert get_sysctl(module, prefixes) == {
        'kern.boottime': 'Tue Jan 17 13:37:51 2017',
        'kern.bufcachepercent': '25'
    }



# Generated at 2022-06-20 18:44:30.860450
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test get_sysctl function
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    # This is a real world example that's easy to test
    result = get_sysctl(module, ['vm.swappiness'])
    assert result == {
        "vm.swappiness": "1"
    }

    result = get_sysctl(module, ['vm.swappiness', 'vm.laptop_mode'])
    assert result == {
        "vm.swappiness": "1",
        "vm.laptop_mode": "0"
    }

    result = get_sysctl(module, ['net.ipv4.route.flush'])

# Generated at 2022-06-20 18:44:41.628192
# Unit test for function get_sysctl
def test_get_sysctl():
    test_dict = dict()
    test_dict['key1'] = 'value1'
    test_dict['key2'] = 'value2'
    test_dict['key3'] = 'value3'
    test_dict['key4'] = 'value4'
    test_dict['key5'] = 'value5'

    test_string = ''

    for key in test_dict:
        test_string += key + " = " + test_dict[key] + "\n"

    test_string += 'key6 = value6\n'
    test_string += 'key7 = value7\n'

    for key in test_dict:
        test_string += key + " = " + test_dict[key] + "\n"

    class TestModule:
        def __init__(self):
            self.params = dict()

# Generated at 2022-06-20 18:45:05.448561
# Unit test for function get_sysctl
def test_get_sysctl():

    # Set up fake module object
    class FakeModule(object):
        def __init__(self, params):
            self._params = params
            self._results = {'rc': 0,
                             'out': '',
                             'err': ''}

        def get_bin_path(self, path):
            return path

        def run_command(self, args):
            if args[0] != self._params['cmd']:
                self._results['rc'] = 1
                self._results['out'] = ''
                self._results['err'] = "Unrecognised command: %s" % args[0]
            else:
                self._results['rc'] = self._params['rc']
                self._results['out'] = self._params['out']
                self._results['err'] = self._params['err']
            return

# Generated at 2022-06-20 18:45:05.970023
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-20 18:45:12.630828
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test the sysctl module on Linux. Let's only do this when the system look
    # like a Linux-like system.
    import platform
    if platform.system() != "Linux":
        return

    # Test module import
    from ansible.module_utils.basic import AnsibleModule

    # Instantiate the module.
    module = AnsibleModule(
        argument_spec = dict(),
    )

    # Test module function
    sysctl = get_sysctl(module, ["kernel.hostname"])

    assert sysctl["kernel.hostname"] == socket.gethostname()

    sysctl = get_sysctl(module, ["kernel.hostname", "kernel.random.boot_id"])

    assert "kernel.hostname" in sysctl
    assert "kernel.random.boot_id" in sysctl

    # Test the function

# Generated at 2022-06-20 18:45:21.758142
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    assert get_sysctl(module, ['kern.boottime'])
    assert 'kern.boottime' in get_sysctl(module, ['kern.boottime']).keys()
    assert get_sysctl(module, [])
    assert not get_sysctl(module, []).keys()
    assert get_sysctl(module, ['kern.boottime', 'kern.version'])
    assert 'kern.boottime' in get_sysctl(module, ['kern.boottime', 'kern.version']).keys()
    assert 'kern.version' in get_sysctl(module, ['kern.boottime', 'kern.version']).keys()



# Generated at 2022-06-20 18:45:29.446320
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    data = dict(
        rc=0,
        stdout='foo = bar\n',
        stderr='',
    )
    module = AnsibleModule(name='test_get_sysctl')
    module.run_command = lambda *args: (data['rc'], data['stdout'], data['stderr'])

    expected = dict(
        foo='bar',
    )
    actual = get_sysctl(module, ['foo'])
    assert expected == actual

# Generated at 2022-06-20 18:45:37.278244
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Returned data structure

# Generated at 2022-06-20 18:45:48.585132
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os
    import tempfile

    this_dir = os.path.dirname(__file__)
    sys.path.insert(0, os.path.abspath(os.path.join(this_dir, '..', '..')))

    try:
        from ansible.module_utils import basic
        from ansible.module_utils.local import LocalAnsibleModule
    except ImportError:
        return False

    sysctl_output = b"""
vm.overcommit_memory = 1
fs.file-max = 2097152
kernel.random.read_wakeup_threshold = 256
kernel.random.write_wakeup_threshold = 256
kernel.random.entropy_avail = 4096
"""


# Generated at 2022-06-20 18:45:54.318914
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    test = dict(
        params = dict(
            prefixes = [ 'kern.version' ]
        ),
        expected = dict(
            stdout = "",
            rc = 1,
            stderr = ''
        )
    )

    module = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(required=True, type='list')
        )
    )


# Generated at 2022-06-20 18:45:58.857481
# Unit test for function get_sysctl
def test_get_sysctl():
    module = DummyModule()
    assert get_sysctl(module, ['kern.boottime']) == {'kern.boottime': '{ sec = 1468664151, usec = 466584 } Thu Jul  7 08:09:11 2016'}


# Generated at 2022-06-20 18:46:03.530885
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl(module, prefixes=['net.ipv4.tcp_mem', 'net.ipv4.tcp_rmem'])
    assert sysctl == {'net.ipv4.tcp_mem': '8388608 8388608 8388608', 'net.ipv4.tcp_rmem': '4096 87380 16711680'}

# Generated at 2022-06-20 18:46:37.695843
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile

    (fd, tmpfile) = tempfile.mkstemp()
    os.write(fd, b'net.ipv4.ip_forward = 1\nnet.ipv4.conf.all.rp_filter = 1\nnet.ipv6.conf.default.accept_ra = 0\n')
    os.close(fd)
    sysctl = get_sysctl(tmpfile)
    os.remove(tmpfile)
    assert sysctl.get('net.ipv4.ip_forward') == '1'
    assert sysctl.get('net.ipv4.conf.all.rp_filter') == '1'
    assert sysctl.get('net.ipv6.conf.default.accept_ra') == '0'


# Generated at 2022-06-20 18:46:40.179110
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert isinstance(get_sysctl(module, ['']), dict)

# Generated at 2022-06-20 18:46:50.908381
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common.process import get_bin_path
    # provide a fake sysctl executable
    def test_get_bin_path(name):
        return './sysctl.sh'

    # provide a fake run_command function
    def test_run_command(cmd, *args, **kwargs):
        import codecs
        output = codecs.open('sysctl_out', encoding='utf-8').read()
        error = codecs.open('sysctl_err', encoding='utf-8').read()
        return 0, output, error

    old_get_bin_path = get_bin_path
    get_bin_path = test_get_bin_path

    # pretend we are a module
    class DummyModule:
        def __init__(self):
            pass

# Generated at 2022-06-20 18:46:55.131389
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    data = get_sysctl(module, ['net.ipv4.ip_forward'])

    assert data['net.ipv4.ip_forward'] == '1'



# Generated at 2022-06-20 18:47:02.144658
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os

    class SysctlModule(AnsibleModule):
        def __init__(self):
            self.params = {
                'prefixes': ['kern.ipc'],
            }
            super(SysctlModule, self).__init__(
                argument_spec=dict(),
                supports_check_mode=True
            )

        def run_command(self, args):
            if args[0] != '/sbin/sysctl':
                raise AssertionError('sysctl not called')

# Generated at 2022-06-20 18:47:07.603898
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args
    from .. import sysctl
    from .module_utils import AnsibleExitJson
    from .module_utils import AnsibleFailJson
    from .module_utils.common.arguments import AnsibleModule

    module = sysctl.__name__
    sysctl_cmd = 'sysctl'
    prefixes = ['-n', 'kern', 'maxvnodes']
    rc = 0
    stdout = 'kern.maxvnodes: 4194304'
    stderr = ''
    key = 'kern.maxvnodes'

# Generated at 2022-06-20 18:47:17.964971
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    class FakeModule:
        def __init__(self, cmd):
            self.cmd = cmd
            self.run_command = MockRunCommand()

        def get_bin_path(self, cmd):
            return self.cmd


# Generated at 2022-06-20 18:47:18.906742
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl() == 'hello'

# Generated at 2022-06-20 18:47:30.278003
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import platform

    module = AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = lambda *args, **kwargs: (0, '', '')

    # This would be a good thing to test but the problem is the output will
    # be different based on the platform and some Linux distros won't
    # have these keys at all. As a result we aren't going to test for content
    # but rather the dict structure.
    sysctl = get_sysctl(module, ['kernel'])
    assert isinstance(sysctl, dict)
    assert 'kernel.hostname' in sysctl


# Generated at 2022-06-20 18:47:37.141779
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = FakeModule()
    test_prefixes = ['vm.dirty_ratio', 'vm.dirty_background_ratio']
    test_returned_dict = get_sysctl(test_module, test_prefixes)
    assert test_returned_dict['vm.dirty_ratio'] == '20'
    assert test_returned_dict['vm.dirty_background_ratio'] == '10'



# Generated at 2022-06-20 18:49:08.037222
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(['net.ipv4.conf.all.accept_local']) == {'net.ipv4.conf.all.accept_local': '0'}


# Generated at 2022-06-20 18:49:11.844093
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    sysctl = get_sysctl(module, ['vm.max_map_count'])
    assert sysctl == {'vm.max_map_count': '262144'}


# Generated at 2022-06-20 18:49:17.927008
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('FakeModule', (object,), {
        'run_command': lambda *args: (0, 'hw.ncpu = 4\nnet.inet.tcp.sendspace = 32768\ndev.drm.0.dpms = 1\n', ''),
        'get_bin_path': lambda *args: '/sbin/sysctl',
        'warn': lambda *args: None
    })

    expected = {
        'dev.drm.0.dpms': '1',
        'hw.ncpu': '4',
        'net.inet.tcp.sendspace': '32768',
    }
    result = get_sysctl(module, ['hw.ncpu', 'net.inet.tcp.sendspace', 'dev.drm.0.dpms'])
    assert expected == result




# Generated at 2022-06-20 18:49:25.200330
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    fake_rc = 0
    fake_out = """vm.max_map_count = 262144
fs.inotify.max_queued_events = 16384
fs.inotify.max_user_instances = 128
fs.inotify.max_user_watches = 8192
net.ipv4.tcp_ecn = 0
net.ipv4.tcp_keepalive_time = 7200
net.ipv4.tcp_fin_timeout = 60"""
    fake_err = ''
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
        fake_stdout = StringIO(fake_out)

# Generated at 2022-06-20 18:49:28.548019
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(sysctl_cmd='/sbin/sysctl', prefixes=['kern.timecounter.hardware'])['kern.timecounter.hardware'] == 'TSC'

# Generated at 2022-06-20 18:49:38.339113
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    mock_command = Mock(return_value=(0, '10\n20\n', ''))
    sysctl_res = get_sysctl(module, ['net.ipv4.tcp_max_syn_backlog', 'net.ipv4.tcp_max_orphans'], command_fn=mock_command)
    assert sysctl_res == {'net.ipv4.tcp_max_syn_backlog': '10', 'net.ipv4.tcp_max_orphans': '20'}

    mock_command = Mock(return_value=(0, '10\nbut: 20\n', ''))

# Generated at 2022-06-20 18:49:43.916778
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {'run_command': run_command_mock, 'get_bin_path': get_bin_path_mock})
    rc, out, err = run_command_mock()

    result = get_sysctl(module, ['fs.file-nr'])
    assert result
    assert result['fs.file-nr'] == '1133       0    131072'

    result = get_sysctl(module, ['fs.file-nr', 'net.bridge.bridge-nf-call-iptables'])
    assert result
    assert result['fs.file-nr'] == '1133       0    131072'
    assert result['net.bridge.bridge-nf-call-iptables'] == '0'


# Generated at 2022-06-20 18:49:47.794763
# Unit test for function get_sysctl
def test_get_sysctl():
    # This module is actually tested as part of the Unix module unit tests
    # due to it's confusing, nested implementation of parameters, if you
    # decide to break it out into a separate module, please write unit tests here
    pass



# Generated at 2022-06-20 18:49:55.640796
# Unit test for function get_sysctl
def test_get_sysctl():

    class MockModule(object):
        def __init__(self, prefixes):
            self.prefixes = prefixes
            self.ansible_facts = dict(sysctl=dict())
            self.params = dict()
            self.warn_msg = list()
            self.bin_path_exceptions = []

        def warn(self, msg):
            self.warn_msg.append(msg)

        def get_bin_path(self, exe, required=True, opt_dirs=[]):
            if exe in self.bin_path_exceptions:
                raise Exception('No such file: %s' % exe)
            return exe

        def run_command(self, cmd):
            self.ansible_facts['sysctl'] = dict(
                cmd_output=dict(),
            )

# Generated at 2022-06-20 18:50:06.610478
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    class Module(object):
        def __init__(self, x, y):
            self.exit_json = lambda x: sys.exit(0)
            self.fail_json = lambda x: sys.exit(1)
            self.warn = lambda x: sys.exit(1)
            self.run_command = lambda x: (0, '''net.ipv4.ip_forward: 0
kernel.msgmnb: 65536
kernel.msgmax: 65536
kernel.msgmni: 2878
''', '')

        def get_bin_path(self, x):
            return x

    module = Module('foo', 'bar')
    get_sysctl(module, [])

if __name__ == '__main__':
    test_get_sysctl()