

# Generated at 2022-06-20 18:40:55.754407
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd: (0, "net.core.somaxconn: 140\nnet.core.wmem_max: 12492800\n", "")

    assert get_sysctl(module, ['net.core']) == {
        "net.core.somaxconn": "140",
        "net.core.wmem_max": "12492800",
    }

# Generated at 2022-06-20 18:41:00.223570
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    assert get_sysctl(module, []) == {}
    assert get_sysctl(module, ['not.a.valid.prefix']) == {}
    assert get_sysctl(module, ['kernel.hostname']) == {'kernel.hostname': 'localhost'}
    assert get_sysctl(module, ['kernel.hostname', 'kernel.domainname']) == {'kernel.hostname': 'localhost', 'kernel.domainname': '(none)'}

# Generated at 2022-06-20 18:41:09.113374
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl

    def mock_run_command(module, cmd, check_rc=True):
        if cmd == ['sysctl', 'net.ipv4.tcp_rfc1337'] or cmd == ['sysctl', '-n', 'net.ipv4.tcp_rfc1337']:
            return (0, '0', '')
        elif cmd == ['sysctl', 'net.ipv6.conf.default.accept_ra_rtr_pref'] or cmd == ['sysctl', '-n', 'net.ipv6.conf.default.accept_ra_rtr_pref']:
            return (0, '1', '')

# Generated at 2022-06-20 18:41:11.258613
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(['net.ipv4.conf.all.accept_redirects']) == '0'

# Generated at 2022-06-20 18:41:21.329398
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    :return: A tuple containing a module for testing and a dictionary with the output of sysctl for mibs test and
    net.inet.ip.forwarding.
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-20 18:41:27.322640
# Unit test for function get_sysctl
def test_get_sysctl():
    test_get_sysctl.prefixes = ['kernel.osrelease', 'vm.hugepagesize']
    test_get_sysctl.sysctl = get_sysctl(module, test_get_sysctl.prefixes)
    expected = {
        'kernel.osrelease': '3.10.0-327.36.3.el7.x86_64',
        'vm.hugepagesize': '2048 kB',
    }
    assert test_get_sysctl.sysctl == expected



# Generated at 2022-06-20 18:41:35.198549
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    module = AnsibleModule(
        argument_spec = dict()
    )

    sysctl_info = get_sysctl(module, ['vm.swappiness=', 'kernel.randomize_va_space=', 'fs.file-max='])
    assert sysctl_info['vm.swappiness'] == '60'
    assert sysctl_info['kernel.randomize_va_space'] == '2'
    assert sysctl_info['fs.file-max'] == '262144'


# Generated at 2022-06-20 18:41:45.330469
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'_ansible_verbosity': 3}, 'test')
    assert module.get_bin_path('sysctl')
    module.fail_json = LambdaType = type(lambda: None)
    # check sysctl with only one prefix
    sysctl = get_sysctl(module, ['net.ipv4.ip_local_port_range'])
    assert sysctl['net.ipv4.ip_local_port_range'] == '32768   60999'
    # check sysctl with multiple prefixes
    sysctl = get_sysctl(module, ['net', 'fs'])
    assert sysctl['net.ipv4.ip_local_port_range'] == '32768   60999'

# Generated at 2022-06-20 18:41:49.076704
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert 'kernel.hostname' in get_sysctl(module, ['kernel.hostname']).keys()


# Generated at 2022-06-20 18:41:57.344536
# Unit test for function get_sysctl
def test_get_sysctl():
    def run_command(cmd):
        (key, value) = re.split(r'\s?=\s?|: ', cmd[2], maxsplit=1)

        return (0, '%s = %s' % (key, value), '')

    class TestModule:
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: False

        def run_command(self, cmd):
            return run_command(cmd)

        def get_bin_path(self, name):
            return name


# Generated at 2022-06-20 18:42:06.608938
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Test get_sysctl function
    """
    module_args = {}
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    prefixes = ['vm.swappiness']

    sysctl = get_sysctl(module, prefixes)
    assert sysctl == {'vm.swappiness': '0'}

# Generated at 2022-06-20 18:42:17.984293
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Test that get_sysctl returns the expected result.
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    sysctl_output = """
kernel.pid_max = 32768
net.ipv4.somaxconn = 128
net.ipv4.ip_local_port_range = 1024 65000
net.ipv4.tcp_fin_timeout = 30

# this is a comment

net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_keepalive_time = 7200
"""

    if PY3:
        sysctl_output = sysctl

# Generated at 2022-06-20 18:42:29.942106
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test in a recent Linux with key-value pairs
    test_stdout = "kernel.pid_max = 4194303\n" \
                  "kernel.threads-max = 49152\n\n" \
                  "net.ipv4.netfilter.ip_conntrack_generic_timeout = 600\n" \
                  "net.ipv4.netfilter.ip_conntrack_icmp_timeout = 30\n\n" \
                  "fs.file-max = 2097152\n" \
                  "fs.inotify.max_queued_events = 16384\n" \
                  "fs.inotify.max_user_instances = 1024\n" \
                  "fs.inotify.max_user_watches = 8192\n"

# Generated at 2022-06-20 18:42:36.157533
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict()
    )
    sysctl = get_sysctl(module, ['net.ipv4.ip_local_port_range'])
    ports = sysctl['net.ipv4.ip_local_port_range']
    assert '32768' in ports
    assert '60999' in ports
    assert len(ports.split()) == 2
    assert sysctl['net.ipv4.ip_local_port_range:'] == ports



# Generated at 2022-06-20 18:42:44.450406
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm','swap'])

    # A complete list of valid variables to check isn't possible to get so
    # just check a couple things to make sure the basics are working
    assert sysctl['vm.swappiness'] == '10'
    assert sysctl['vm.nr_hugepages'] == '0'



# Generated at 2022-06-20 18:42:56.379050
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins          # pylint: disable=import-error
    else:
        import builtins                          # pylint: disable=import-error
    module = builtins.__dict__['__import__']('ansible.modules.system.sysctl')
    if sys.version_info[0] < 3:
        return_value = {}
        setattr(module.__builtin__, 'open', lambda: return_value)
    else:
        return_value = {}
        setattr(module.builtins, 'open', lambda: return_value)
    return_value['readlines'] = lambda: ['kern.maxvnodes = 52000\n']
    ret = module.get_sysctl(None, [])


# Generated at 2022-06-20 18:42:59.634387
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.sysctl import get_sysctl

    actual_sysctl = get_sysctl(
        AnsibleModule({}),
        ["kern.maxvnodes"]
    )

    assert actual_sysctl == {"kern.maxvnodes": "99999"}

# Generated at 2022-06-20 18:43:08.771243
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(arg1=dict(type=str)))


# Generated at 2022-06-20 18:43:18.747033
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test empty input
    result = get_sysctl({}, [])
    assert result == {}

    # Test single line output
    result = get_sysctl({}, ['net.ipv6.conf.all.disable_ipv6'])
    assert result == {'net.ipv6.conf.all.disable_ipv6': '0'}

    # Test multiple line output
    result = get_sysctl({}, ['net.ipv6.conf.all.router_solicitations'])

# Generated at 2022-06-20 18:43:21.101840
# Unit test for function get_sysctl
def test_get_sysctl():
    result = get_sysctl(sysctl_cmd, prefixes)
    assert result == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-20 18:43:40.182281
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    sysctl = get_sysctl(module, ['kern.boottime'])
    assert sysctl.get('kern.boottime') is not None
    assert sysctl.get('kern.boottime')[:20] == '{ sec = '
    sysctl = get_sysctl(module, ['kern.boottime', 'kern.hostname'])
    assert sysctl.get('kern.boottime') is not None
    assert sysctl.get('kern.hostname') is not None
    sysctl = get_sysctl(module, ['vm.swapusage'])
    assert sysctl.get('vm.swapusage') is not None
    assert sysctl

# Generated at 2022-06-20 18:43:46.504155
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import GET_SYSTEM_SYSTEM
    m = basic.AnsibleModule(
        argument_spec=dict(
            prefixes='list',
        ),
    )

    facts = GET_SYSTEM_SYSTEM()
    sysctl = get_sysctl(m, facts['system'])
    assert sysctl
    assert sysctl['kernel.ostype'] == 'Linux'
    assert sysctl['kernel.pid_max'] == '32768'

# Generated at 2022-06-20 18:43:53.303184
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    expected_sysctl = {
        'kern.ostype': 'Darwin',
        'kern.priv.proc': '0',
        'kern.priv.sysvipc': '0',
    }

    result_sysctl = get_sysctl(module, ['-a', '^kern\.priv', '-d'])

    assert result_sysctl == expected_sysctl

# Generated at 2022-06-20 18:44:02.923024
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = dict(kernel={'ostype': 'Linux',
                          'consoledevice': 'tty0',
                          'domainname': '(none)',
                          'hostname': 'host1',
                          'modprobe': '/sbin/modprobe'},
                  vm={'swappiness': '60',
                      'panic_on_oom': '0'})


# Generated at 2022-06-20 18:44:08.028940
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    ret = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert ret.has_key('net.ipv4.ip_forward')

# Generated at 2022-06-20 18:44:16.806439
# Unit test for function get_sysctl
def test_get_sysctl():
    class ModMock(object):
        def __init__(self):
            self.params = []

        def get_bin_path(self, cmd):
            return "sysctl"


# Generated at 2022-06-20 18:44:27.047510
# Unit test for function get_sysctl
def test_get_sysctl():
    """ Unit test for function get_sysctl. """
    sysctl_cmd = '/sbin/sysctl'
    cmd = [sysctl_cmd]
    cmd.append('-a')

    rc = 0

# Generated at 2022-06-20 18:44:32.572297
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    result = get_sysctl(module, ['kernel.sched_min_granularity_ns'])
    assert result == {
        'kernel.sched_min_granularity_ns': '100000',
    }

# Generated at 2022-06-20 18:44:36.182506
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('Module', (object,), dict())
    setattr(module, '_exec_xcmd', lambda cmd: (0, b'foo = bar', b''))
    assert get_sysctl(module, prefixes=['foo']) == dict(foo=b'bar')

# Generated at 2022-06-20 18:44:43.295116
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeModule()
    assert get_sysctl(module, ["net.core.wmem_max"]) == {"net.core.wmem_max": "12582912"}
    assert get_sysctl(module, ["net.core.wmem_max", "notfound"]) == {"net.core.wmem_max": "12582912"}
    assert get_sysctl(module, ["notfound", "notfound"]) == {}
    assert get_sysctl(module, []) == {}



# Generated at 2022-06-20 18:45:08.390944
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test 1: Only one parameter passed
    # Expected result: {'vm.swappiness': '0'}

    # Test 2: Two parameters passed
    # Expected result: {'net.ipv6.conf.all.forwarding': '0',
    #                   'net.ipv6.conf.all.mc_forwarding': '0',
    #                   'net.ipv6.conf.all.proxy_ndp': '0'}

    # Test 3: Invalid parameter passed
    # Expected result: {}

    # Assume that ansible module object is class DummyAnsibleModule
    # with member function run_command, which returns 1 for all
    # commands executed.
    class DummyAnsibleModule:
        def get_bin_path(self, arg):
            return "sysctl"


# Generated at 2022-06-20 18:45:13.227464
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['-r', 'net'])
    assert sysctl is not None
    assert sysctl['net.ipv4.lo.accept_local'] == "1"

# Generated at 2022-06-20 18:45:20.953746
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    assert get_sysctl(basic.AnsibleModule(argument_spec=dict()), ['kern.securelevel', 'kern.ostype']) == {
        'kern.securelevel': '1', 'kern.ostype': 'Darwin'}
    assert get_sysctl(basic.AnsibleModule(argument_spec=dict()), ['net.inet.ip.forwarding', 'net.local.stream.sendspace']) == {
        'net.inet.ip.forwarding': '0', 'net.local.stream.sendspace': '262144'}

# Generated at 2022-06-20 18:45:31.378000
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-20 18:45:38.056282
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    result = get_sysctl(module, ['vm.max_map_count'])

    expected = {'vm.max_map_count': '262144'}
    assert result == expected

    result = get_sysctl(module, ['kernel.shmmax'])

    expected = {'kernel.shmmax': '18446744073692774399'}
    assert result == expected

# Generated at 2022-06-20 18:45:44.356625
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern'])
    assert sysctl
    assert sysctl['kern.hostname']

# Generated at 2022-06-20 18:45:50.785376
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile
    import os

    filehandle, tmpfile = tempfile.mkstemp()
    os.write(filehandle, b"net.ipv4.tcp_fin_timeout = 30\nnet.ipv4.tcp_tw_reuse = 1")
    os.close(filehandle)

    sysctl = parse_sysctl(tmpfile)

    assert sysctl == {
        'net.ipv4.tcp_fin_timeout': "30",
        'net.ipv4.tcp_tw_reuse': "1"
    }

# Generated at 2022-06-20 18:45:53.829415
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['kern']
    sysctl = get_sysctl(prefixes)
    keys = sysctl.keys()
    assert 'kern.boottime' in keys

# Generated at 2022-06-20 18:46:05.082538
# Unit test for function get_sysctl
def test_get_sysctl():
    tests = [
        (dict(), ['vm.overcommit_memory=0']),
        (dict(vm_overcommit_memory='0'), ['vm.overcommit_memory=0']),
        (dict(vm_overcommit_memory='0'), ['vm.overcommit_memory']),
        (dict(vm_overcommit_memory='0', vm_panic_on_oom='0'), ['vm.overcommit_memory', 'vm.panic_on_oom']),
        (dict(vm_overcommit_memory='0'), ['vm.overcommit_memory', 'vm.panic_on_oom']),
    ]

    for (expected, actual) in tests:
        assert expected == get_sysctl(dict(run_command=lambda *args, **kwargs: (0, '\n'.join(actual), '')))


# Generated at 2022-06-20 18:46:13.132181
# Unit test for function get_sysctl
def test_get_sysctl():
    import AnsibleModule
    import copy
    import sys

    module = AnsibleModule.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    (attributes, sysctl_output) = copy.deepcopy(sysctl_info)
    module.run_command = mock_run_command(sysctl_output)

    output = get_sysctl(module, ('net.ipv4.conf.all.rp_filter',))

    if sys.version_info[0] >= 3:
        assert attributes['net.ipv4.conf.all.rp_filter'] == to_text(output['net.ipv4.conf.all.rp_filter'])

# Generated at 2022-06-20 18:46:52.553698
# Unit test for function get_sysctl
def test_get_sysctl():
    # Given
    module = mock.MagicMock()
    prefixes = [
        'kern.hostname',
        'net.inet.ip.portrange.',
    ]

    expected_sysctl = {
        'kern.hostname': 'foobar.local',
        'net.inet.ip.portrange.first': '32768',
        'net.inet.ip.portrange.last': '60999',
    }

    # When
    sysctl = get_sysctl(module, prefixes)

    # Then
    assert sysctl == expected_sysctl

# Generated at 2022-06-20 18:47:00.389028
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl("", "") == {}
    assert get_sysctl("line1\nline2\n", "") == {}
    assert get_sysctl("line1 not a valid line\nline2\n", "") == {}
    assert get_sysctl("kern.hostname = example.com\n", "") == {'kern.hostname': 'example.com'}
    assert get_sysctl("kern.hostname: example.com\n", "") == {'kern.hostname': 'example.com'}
    assert get_sysctl("kern.hostname = example.com\nnet.inet.ip.ttl: 64\n", "") == {'kern.hostname': 'example.com', 'net.inet.ip.ttl': '64'}
    assert get_

# Generated at 2022-06-20 18:47:05.156553
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    expected = {
        u'fs.file-max': u'2408478',
        u'kernel.randomize_va_space': u'2'
    }

    result = get_sysctl(module, ['-a'])
    assert(result)
    assert(isinstance(result, dict))
    assert(expected['fs.file-max'] in result)
    assert(expected['kernel.randomize_va_space'] in result)

# Generated at 2022-06-20 18:47:17.130904
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()

    result = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert result['net.ipv4.ip_forward'] == '1'

    result = get_sysctl(module, ['vm.swappiness'])
    assert result['vm.swappiness'] == '60'

    result = get_sysctl(module, ['vm.swappiness', 'net.ipv4.ip_forward'])
    assert result['vm.swappiness'] == '60'
    assert result['net.ipv4.ip_forward'] == '1'

    result = get_sysctl(module, ['net.ipv4.ip_forward', 'vm.swappiness'])
    assert result['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-20 18:47:22.221893
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict()
    )


# Generated at 2022-06-20 18:47:28.946241
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('MockModule', (object,), {
        'run_command': lambda *args: (0, '', ''),
    })

    sysctl = get_sysctl(module, [])
    assert sysctl == {}

    sysctl = get_sysctl(module, ['net.ipv4.tcp_syncookies=1'])
    assert sysctl == {'net.ipv4.tcp_syncookies': '1'}

# Generated at 2022-06-20 18:47:39.805574
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    # Setup a get_sysctl function that returns known data

# Generated at 2022-06-20 18:47:47.749025
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    # AnsibleModule.run_command() does not work in unit test, we need to mock it
    class MockAnsibleModule(AnsibleModule):
        def run_command(self, cmd):
            if cmd == ['/bin/sysctl', '-b', 'kern.malloc_canaries']:
                return 0, '1337\n', ''
            elif cmd == ['/bin/sysctl', '-b', 'kern.hostid']:
                return 0, '0x00005d5f\n', ''
            elif cmd == ['/bin/sysctl', '-b', 'kern.hostname']:
                return 0, 'localhost\n', ''

# Generated at 2022-06-20 18:47:53.096012
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['kernel.ostype'])
    assert sysctl['kernel.ostype'] == 'Linux'

# Generated at 2022-06-20 18:48:02.692677
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Test get_sysctl function
    """
    import sys

    # put all of our test data in a dictionary
    # to make it easier to see what we are testing
    try:
        import mock
    except:
        sys.exit("""ansible_collections.misc.not_a_real_collection.plugins.modules.net_tools.get_sysctl
requires the 'mock' module.  Please install it on your local python interpreter.
For more information, see https://github.com/ansible/ansible/wiki/Mocking""")

    sysctl_dict = {}
    sysctl_dict['extra'] = {}
    sysctl_dict['extra']['command'] = "sysctl"

# Generated at 2022-06-20 18:49:39.095295
# Unit test for function get_sysctl
def test_get_sysctl():
    """
        Returns True if the sysctl value is retrieved and matches the expected value
        Returns False if the sysctl value is not found or does not match the expected value
    """
    import os
    import dummy_module

    module = dummy_module.AnsibleModule(argument_spec=dict())

    rc, out, err = module.run_command('uname -r')
    kernel_release = out.splitlines()[0]

    sysctl = get_sysctl(module, 'kernel.osrelease')
    if sysctl:
        return sysctl['kernel.osrelease'] == kernel_release
    else:
        return False

# Generated at 2022-06-20 18:49:42.188873
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.sysctl as sysctl

    m = AnsibleModule(argument_spec=dict())

    sysctl_values = sysctl.get_sysctl(m, ['kernel.hostname'])

    assert sysctl_values.get('kernel.hostname') == 'sysctl'

# Generated at 2022-06-20 18:49:52.197283
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl_out = """
    kernel.osrelease = 3.5.0-17-generic
    kernel.ostype = Linux

    net.ipv4.tcp_syncookies = 1
    net.ipv4.tcp_tw_reuse = 0

    net.ipv6.conf.all.disable_ipv6 = 0
    """

    module.run_command = mock_run_command(sysctl_out)

    sysctl = get_sysctl(module, ['net'])

    assert sysctl['net.ipv4.tcp_syncookies'] == '1'

# Generated at 2022-06-20 18:49:58.353367
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type(str('_'), (object,), {})
    setattr(module, 'get_bin_path', lambda self, arg: arg)

    setattr(module, 'run_command', lambda self, arg: (0, '''
net.ipv4.ip_local_port_range: 32768   61000
net.ipv4.tcp_syncookies: 1''', ''))

    assert get_sysctl(module, ['net.ipv4.ip_local_port_range', 'net.ipv4.tcp_syncookies']) == \
        {
            u'net.ipv4.ip_local_port_range': u'32768   61000',
            u'net.ipv4.tcp_syncookies':      u'1'
        }

# Generated at 2022-06-20 18:50:05.095271
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.run_command = MagicMock()
    module.run_command.return_value = (0, b'net.ipv4.tcp_mtu_probing = 1', b'')
    result = get_sysctl(module, ['net.ipv4.tcp_mtu_probing'])
    assert result == { 'net.ipv4.tcp_mtu_probing': '1' }

# Generated at 2022-06-20 18:50:09.979550
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    module.exit_json(changed=False, sysctl=get_sysctl(module, ['kernel', 'fs']))

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:50:14.933757
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import json

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    sysctls = get_sysctl(module, ['kernel'])

    assert sysctls['kernel.ostype'] == 'Linux'
    assert sysctls['kernel.domainname'] == '(none)'
    assert sysctls['kernel.panic'] == '0'
    assert sysctls['kernel.sem'] == '250 32000 32 1024'
    assert sysctls['kernel.printk'] == '4 4 1 7'
    assert sysctls['kernel.panic_on_oops'] == '1'


# Generated at 2022-06-20 18:50:24.444820
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(sysctl_mock, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1',}
    assert get_sysctl(sysctl_mock, ['net.ipv4','net.ipv6']) == {'net.ipv4.ip_forward': '1', 'net.ipv6.conf.all.forwarding': '1', 'net.ipv4.conf.all.forwarding': '1', 'net.ipv4.conf.default.forwarding': '1', 'net.ipv4.conf.docker0.forwarding': '1', 'net.ipv6.conf.all.forwarding': '1',}

# Mock class for running unit tests

# Generated at 2022-06-20 18:50:29.189175
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    val = get_sysctl(module, ['-a'])
    assert isinstance(val, dict)
    assert val.keys()
    assert val['kernel.domainname'] == '(none)'
    assert 'net.ipv4.ip_forward' in val

# Generated at 2022-06-20 18:50:34.143851
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    assert get_sysctl(module, ['vm', 'vfs']) == {'vm.vfs_cache_pressure': '100'}
    assert get_sysctl(module, ['vm', 'nonsense']) == {}