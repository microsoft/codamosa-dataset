

# Generated at 2022-06-20 18:40:51.721091
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    m_ansible = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
        bypass_checks = True
    )

    # Mock out the run_command function
    m_ansible.run_command = ansible.module_utils.common.process.run_command

    # Mock out the class to return values we want

# Generated at 2022-06-20 18:40:59.230906
# Unit test for function get_sysctl
def test_get_sysctl():

    class Module(object):
        def __init__(self):
            self.params = {}
            self.params['warn'] = False


# Generated at 2022-06-20 18:41:08.574001
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    SYSCTL_KEY_VALUE = """\
kernel.domainname = ansible.com
kernel.hostname = ansible.com
kernel.osrelease = 2.6.32-431.el6.x86_64
kernel.ostype = Linux
"""

    sysctl_file = tempfile.NamedTemporaryFile(delete=False)
    sysctl_file.write(SYSCTL_KEY_VALUE)
    sysctl_file.close()
    fname = sysctl_file.name

    # Get sysctl from file
    basic.ANSIBLE_ARGS = basic.parse_args(['-c', fname])

# Generated at 2022-06-20 18:41:19.739183
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    These tests are meant to assert against the return value of
    `get_sysctl`. If you change the module, you will have to change the
    results of these tests.

    These tests depend on the output of `sysctl` on the system where
    the tests are being run.
    '''

    # Avoids: TypeError: unorderable types: ModuleType() > ModuleType()
    # when the tests are run by their name, as opposed to `nosetests -s`.
    # The tests are run by name by the jenkins ansible-tests harness, so
    # this is important to avoid unhelpful errors.
    def cmp_module(a, b):
        return 0

    class ModuleStub(object):
        def __init__(self):
            self.params = {}


# Generated at 2022-06-20 18:41:28.737473
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    MODULE_NAME = os.path.splitext(os.path.basename(__file__))[0]
    temp_dirname = tempfile.mkdtemp()

    test_data = (
      ('vm.overcommit_memory', '0'),
      ('kernel.panic', '111'),
      ('kernel.sem', '250 32000 32 128'),
    )

    test_str = '\n'.join(map(lambda x: '{} = {}'.format(x[0], x[1]), test_data)) + '\n'

    test_sysctl_path = os.path.join(temp_dirname, 'sysctl')
    with open(test_sysctl_path, 'w') as f:
        f

# Generated at 2022-06-20 18:41:37.866862
# Unit test for function get_sysctl
def test_get_sysctl():

    # Import necessary libraries
    import ansible.modules.network.general as general
    sysctl_data = general.get_sysctl([u'net.ipv4.ip_forward', u'kernel.sem'])
    assert sysctl_data[u'net.ipv4.ip_forward'] == u'0'
    assert sysctl_data[u'kernel.sem'] == u'250  32000 32  4096'

    # Try to get some non-existing sysctls.
    general.get_sysctl([u'ansible.test'])
    general.get_sysctl([u'ansible.test1', u'ansible.test2'])

# Generated at 2022-06-20 18:41:44.351978
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic

    module_args = dict(prefixes=['kernel.shmall'])
    module_args['_ansible_check_mode'] = True

    module = ansible.module_utils.basic.AnsibleModule(
        **module_args)

    sysctl = get_sysctl(module, module_args['prefixes'])

    assert 'kernel.shmall' in sysctl
    assert '2097152' == sysctl['kernel.shmall']

# Generated at 2022-06-20 18:41:50.317065
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    prefixes = ['kern.boottime', 'kern.hostuuid']
    test_module = AnsibleModule({'prefixes': prefixes})

    sysctl = get_sysctl(test_module, prefixes)
    assert 'kern.boottime' in sysctl
  

# Generated at 2022-06-20 18:41:57.807248
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    In order to make this test actually test something we need to mock the run_command function
    which is included in the module.
    """

    # Define the mocked version of run_command
    def run_command(self, *args, **kwargs):
        """
        Return the desired string that would be returned if run_command was called with
        the given args and kwargs.
        """

        # We could probably do something more clever here. This is just meant to be a placeholder
        # until we figure out the actual test cases that we want to test.

        # Return a string so we can parse it
        return 0, '''    hw.memsize: 8589934592
    kern.randompid: 2
''', ''

    # Import the module that we're testing
    # We assume that the test is located in the

# Generated at 2022-06-20 18:42:03.397726
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert module.get_sysctl(['net.ipv4.ip_local_port_range']) == {'net.ipv4.ip_local_port_range': '32768   60999'}


# Generated at 2022-06-20 18:42:12.481117
# Unit test for function get_sysctl
def test_get_sysctl():
    args = dict(
        prefixes=['-a'],
    )
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=args)
    result = get_sysctl(module, module.params['prefixes'])
    assert result



# Generated at 2022-06-20 18:42:17.518744
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    sysctl = get_sysctl(module, ['net.core.rmem_max', 'net.core.wmem_max'])
    assert(sysctl['net.core.rmem_max'] == '12582912')
    assert(sysctl['net.core.wmem_max'] == '12582912')


# Generated at 2022-06-20 18:42:23.740444
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(name, **kwargs):
        # emulate the AnsibleModule object
        m = type('TestModule', (object,), dict(params=kwargs))
        m.run_command = lambda *args, **kwargs: (0, 'net.ipv4.ip_forward = 1\nnet.ipv4.tcp_syncookies = 1\n', '')
        m.fail_json = lambda **kwargs: None
        m.warn = lambda msg: None
        m.get_bin_path = lambda name: '/bin/' + name
        return m

    m = test_module('test', debug=False)
    result = get_sysctl(m, ['net.ipv4.ip_forward'])

# Generated at 2022-06-20 18:42:33.267851
# Unit test for function get_sysctl
def test_get_sysctl():
    test_sysctl_cmd = "/bin/sysctl"
    test_cmd = [test_sysctl_cmd]
    prefixes = ["kern.maxfiles", "kern.maxfilesperproc"]
    test_cmd.extend(prefixes)
    test_out = """kern.maxfiles: 12288
kern.maxfilesperproc: 10240"""

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, prefixes)

    assert sysctl == {'kern.maxfiles': '12288', 'kern.maxfilesperproc': '10240'}

# Generated at 2022-06-20 18:42:36.306328
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    module.run_command = run_command
    assert get_sysctl(module, ['kernel.randomize_va_space']) == {'kernel.randomize_va_space': '2'}


# Generated at 2022-06-20 18:42:38.891531
# Unit test for function get_sysctl
def test_get_sysctl():
    # Put here some test to see if return values are what we expect

    pass


# Generated at 2022-06-20 18:42:43.586435
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    sysctl = get_sysctl(module, ['kernel.'])
    assert len(sysctl) > 0
    assert sysctl['kernel.hostname'] == 'tom'

# Generated at 2022-06-20 18:42:46.082345
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(
        prefixes=dict(type='list'),
    ))

    assert module.get_sysctl(['foo.bar']) == dict()

# Generated at 2022-06-20 18:42:50.557683
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module_exit = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    assert isinstance(get_sysctl(module_exit, ['kern.version']), dict)
    assert 'kern.version' in get_sysctl(module_exit, ['kern.version'])

# Generated at 2022-06-20 18:43:01.206171
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    sys.path.append('../')

    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True)
        )
    )

    test_module.run_command = lambda x: (0, 'a.b.c: "d"\ne.f.g: h', '')
    assert get_sysctl(test_module, 'prefixes') == dict(a_b_c='d', e_f_g='h')

    test_module.run_command = lambda x: (1, '', '')
    assert get_sysctl(test_module, 'prefixes') == dict()


# Generated at 2022-06-20 18:43:12.826943
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['kern.securelevel']) == {'kern.securelevel': '0'}


# Generated at 2022-06-20 18:43:14.497227
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = ['net.netfilter']
    assert get_sysctl(module, prefixes)

# Generated at 2022-06-20 18:43:17.393396
# Unit test for function get_sysctl
def test_get_sysctl():
    from units.compat.mock import Mock

    module = Mock()
    res = get_sysctl(module, ['kern.bootfile'])
    assert(res == {'kern.bootfile': '/boot/kernel/kernel'})

# Generated at 2022-06-20 18:43:28.060476
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    import sys

    module = sys.modules['ansible.module_utils.basic']

# Generated at 2022-06-20 18:43:34.338682
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.utils.pytest import AnsibleExitJson
    from ansible.utils.pytest import AnsibleFailJson

    try:
        import __main__
        __main__.__loader__ = None
    except AttributeError:
        pass

    class Module:
        def __init__(self):
            self.params = {}
            self.exit_json = AnsibleExitJson
            self.fail_json = AnsibleFailJson
            self.user = 'root'
            self.warn = lambda s: sys.stderr.write(s + '\n')

        def get_bin_path(self, arg):
            return arg

        def run_command(self, arg):
            kw = dict()
            if arg[0] == 'sysctl':
                kw["rc"] = 0
               

# Generated at 2022-06-20 18:43:38.307860
# Unit test for function get_sysctl
def test_get_sysctl():
    ansible_mod = MagicMock()
    ansible_mod.module.run_command.return_value = (0, 'net.ipv4.tcp_syncookies = 1', None)
    ansible_mod.get_bin_path.return_value = 'sysctl'
    ansible_mod.warn.return_value = False

    result = get_sysctl(ansible_mod, ['net.ipv4.tcp_syncookies'])
    assert result == {'net.ipv4.tcp_syncookies': '1'}

    ansible_mod.warn.assert_not_called()

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-20 18:43:44.940304
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = {
        'net.ipv4.conf.default.rp_filter': '0',
        'net.ipv4.icmp_echo_ignore_broadcasts': '0',
        'net.ipv4.tcp_syncookies': '1'
    }

    assert sysctl == get_sysctl(['net.ipv4.conf.default.rp_filter', 'net.ipv4.icmp_echo_ignore_broadcasts', 'net.ipv4.tcp_syncookies'])

# Generated at 2022-06-20 18:43:56.108674
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule, ModuleFailException

    module = AnsibleModule(
        argument_spec=dict()
    )
    results = get_sysctl(module, ["foo"])
    assert results == {}

    # Now test with a working sysctl
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    results = get_sysctl(module, ["example"])
    assert results == {"example": "1"}

    # Test with multiple prefixes
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    results = get_sysctl(module, ["example", "test"])
    assert results == {"example": "1", "test": "1"}

# Generated at 2022-06-20 18:43:56.657512
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-20 18:44:00.840085
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    my_mod = AnsibleModule(argument_spec={})
    sysctl_ret = get_sysctl(my_mod, 'kernel.ostype')
    assert sysctl_ret == {'kernel.ostype': 'FreeBSD'}

# Generated at 2022-06-20 18:44:27.386346
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={
        'prefixes': dict(type='list', default=[]),
    })

    # Mock values
    command_output = (
        'net.ipv4.ip_local_port_range = 1024 65535\n'
        'net.ipv4.tcp_congestion_control = cubic\n\n'
        'net.ipv4.tcp_max_syn_backlog = 2048\n'
    )

    expected = dict(
        net = dict(
            ipv4 = dict(
                tcp_congestion_control = 'cubic',
                ip_local_port_range = '1024 65535',
                tcp_max_syn_backlog = '2048',
            )
        )
    )

    # Mock AnsibleModule.run_

# Generated at 2022-06-20 18:44:33.930414
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(type='list', required=True),
        )
    )

    sysctl = get_sysctl(module, module.params['prefixes'])
    module.exit_json(changed=False, sysctl=sysctl)


from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 18:44:36.226785
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # should return an empty dict for an empty list
    assert get_sysctl(module, ['badkey']) == dict(), "Empty dict not returned from empty list"

    assert get_sysctl(module, ['kernel.hostname']) == {'kernel.hostname': 'local.host'}, "kernel.hostname not being returned"

# Generated at 2022-06-20 18:44:39.093774
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:44:43.626771
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('AnsibleModule', (object,), {'warn': print, 'run_command': run_command})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    print(sysctl)

# Function run_command for unit testing

# Generated at 2022-06-20 18:44:46.981616
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    results = get_sysctl(module, ['net.ipv4'])
    assert results['net.ipv4.conf.all.rp_filter'] == '1'

# Generated at 2022-06-20 18:44:53.699891
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl = get_sysctl(module, ['dev.cdrom.info'])
    assert sysctl == dict(dev=dict(cdrom=dict(info='CdromPeripheral Bus:0 Drive:1')))

    sysctl = get_sysctl(module, ['vm.stats'])
    assert 'kern' in sysctl
    assert 'vm' in sysctl['kern']
    assert 'vm_stats_misc' in sysctl['kern']['vm']
    assert 'vm_stats_misc' in sysctl['kern']['vm']

from ansible.module_utils.basic import AnsibleModule
main = AnsibleModule(
    argument_spec=dict(),
)


# Generated at 2022-06-20 18:44:59.773888
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.facts.system.sysctl import get_sysctl
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    sysctl = get_sysctl(module, ["kern.ostype", "kern.version"])

    assert sysctl["kern.ostype"] == "Darwin"
    assert sysctl['kern.version'].startswith('Darwin Kernel Version')

# Generated at 2022-06-20 18:45:08.464027
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import io
    import traceback
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat

    class TestModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.bin_path = None
            self.params = {
                'debug': False,
                'warn': False,
            }

        def get_bin_path(self, binary):
            return '/bin/%s' % binary

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, use_unsafe_shell=False, data=None, binary_data=False):
            self.run_command_calls += 1
            if self.bin_path is None:
                self.bin_path

# Generated at 2022-06-20 18:45:15.351177
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    dhcp_prefixes = ['net.ipv4.ip_forward', 'net.ipv6.conf.all.forwarding']
    res = get_sysctl(module, dhcp_prefixes)
    assert res['net.ipv4.ip_forward'] == '0'
    assert res['net.ipv6.conf.all.forwarding'] == '0'

# Generated at 2022-06-20 18:46:00.400627
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('Module', (object,), {'run_command': lambda *arg: (0, 'foo.bar: 1\nfoo.blah: 2', None), 'get_bin_path': lambda *arg: None})
    sysctl = get_sysctl(module, ['foo'])
    assert sysctl['foo.bar'] == '1'

    module = type('Module', (object,), {'run_command': lambda *arg: (1, None, None), 'get_bin_path': lambda *arg: None})
    sysctl = get_sysctl(module, ['foo'])
    assert sysctl == {}


# Generated at 2022-06-20 18:46:10.356112
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def run_command(self, cmd, check_rc=True, close_fds=False):
            stdout = '''
net.ipv4.tcp_window_scaling = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.ip_local_port_range: 32768    61000'''
            return (0, stdout, 'err')

        def warn(self, msg):
            print(msg)

    sysctl = get_sysctl(TestModule(), ['net.ipv4'])
    assert(sysctl['net.ipv4.tcp_window_scaling'] == '1')

# Generated at 2022-06-20 18:46:16.111698
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl_utils
    import os

    mod = sysctl_utils.get_sysctl(['-a'])
    txt = os.path.basename(__file__).split('.')[0]
    assert mod[txt + '.test_var'] == 'test_value'

test_var = "test_value"

# Generated at 2022-06-20 18:46:19.159949
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Test to check if the get_sysctl function returns a dictionary of key value pairs
    '''
    assert(get_sysctl({'bin_path': lambda x: 'sysctl'}, ['test']) == {})

# Generated at 2022-06-20 18:46:27.494933
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import load_platform_subclass

    # Setup AnsibleModule
    m = AnsibleModule({})
    load_platform_subclass(m, 'linux')

    # Setup get_sysctl return
    # Return enough to make sure they are being processed properly.
    m.run_command.return_value = (0, """foo: bar
baz = qux
asdf = jkl
    hjkl = op
    ik = lm
    no = pq
xyzzy = thud
""", '')

    # Test get_sysctl execution
    # get_sysctl's first argument is AnsibleModule, so skip over it

# Generated at 2022-06-20 18:46:34.034521
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=[]),
        ),
        supports_check_mode=True
    )

    if 'NETWORKING_IPV6' in os.environ:
        sysctl = get_sysctl(module, prefixes=['net.ipv6.conf'])
        assert sysctl['net.ipv6.conf.all.disable_ipv6'] == '1'

# Generated at 2022-06-20 18:46:46.463049
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    sys.path.append('.')
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Create dummy sysctl output

# Generated at 2022-06-20 18:46:55.332403
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    module.fail_json = Mock(name='fail_json')


# Generated at 2022-06-20 18:46:59.795603
# Unit test for function get_sysctl
def test_get_sysctl():
    print('test')
    import subprocess

    module = subprocess
    prefixes = []
    sysctl = get_sysctl(module, prefixes)

    assert len(sysctl) > 0
    assert 'kernel.domainname' in sysctl

# Generated at 2022-06-20 18:47:05.700698
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier

    from ansible.module_utils.basic import AnsibleModule

    my_env = dict(PATH='/usr/sbin:/bin:/usr/bin')
    my_env.update(dict(ANSIBLE_MODULE_ARGS='{"prefixes": ["vm", "kernel", "net"]}'))
    my_env.update(dict(ANSIBLE_MODULE_REQUIREMENTS=''))

    module = AnsibleModule(environment=my_env)

    sysctl = get_sysctl(module, ['vm', 'kernel', 'net'])

    assert isinstance(sysctl, dict)


if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:48:50.306809
# Unit test for function get_sysctl
def test_get_sysctl():

  import os
  import sys
  module_name = 'ansible.module_utils.sysctl'
  module_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'lib')
  sys.path.append(module_path)

  from ansible.module_utils.basic import AnsibleModule
  bin_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'bin')
  sys.path.append(bin_path)
  from ansible.module_utils.basic import get_bin_path
  module = AnsibleModule(
      argument_spec = dict(),
      supports_check_mode = True
  )

  module.get_bin_path = get_bin

# Generated at 2022-06-20 18:48:54.558869
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    module.run_command = lambda x: (0, 'kernel.domainname = example.org', '')
    assert get_sysctl(module, ['kernel.domainname']) == {'kernel.domainname': 'example.org'}

# Generated at 2022-06-20 18:49:02.389100
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile

    def run_command(self, cmd, input=None, cwd=None, in_data=None, binary=False,
                    path_prefix=None, use_unsafe_shell=False, prompt_regex=None):
        t = tempfile.NamedTemporaryFile()
        t.write('hello = world\n')
        t.write('foo = bar\n')
        t.flush()
        return 0, t.name, ''

    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    m.run_command = run_command

# Generated at 2022-06-20 18:49:12.280788
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Unit test for the get_sysctl function
    """

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(prefixes=dict(required=True, type='list')))

    sysctl_output = """kernel.panic = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0"""


# Generated at 2022-06-20 18:49:14.371714
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    assert module.get_sysctl(['net.ipv4.ip_forward'])['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-20 18:49:18.123005
# Unit test for function get_sysctl
def test_get_sysctl():
    key = 'kernel.osrelease'
    value = '2.6.32-431.el6.x86_64'

    module = MockAnsibleModule(argument_spec={})
    result = get_sysctl(module, [key])
    expected = {key: value}

    assert result == expected



# Generated at 2022-06-20 18:49:21.683911
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    sysctl_module = basic.AnsibleModule(
        argument_spec = dict()
    )

    assert get_sysctl(sysctl_module, ['vm.swappiness']) == {'vm.swappiness': '60'}

# Generated at 2022-06-20 18:49:25.512224
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible import module_utils
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    sysctl = module_utils.facts.sysctl.get_sysctl(module, [])

    assert sysctl.get('version.python') is not None
    assert sysctl.get('version.python') == '%d.%d' % (sys.version_info[0], sys.version_info[1])

# Generated at 2022-06-20 18:49:29.966305
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic as basic_mod
    module = basic_mod.AnsibleModule(argument_spec=dict())
    sysctls = get_sysctl(module, ['-a'])
    assert sysctls.get('kernel.osrelease') == '4.4.0-75-generic'

# Generated at 2022-06-20 18:49:34.705704
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    result = get_sysctl(module, ['kernel.hostname'])
    assert result
    assert 'kernel.hostname' in result
    assert result['kernel.hostname'].startswith('leela')