

# Generated at 2022-06-20 18:40:50.958686
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.modules.system.sysctl
    module = ansible.modules.system.sysctl
    sysctl = get_sysctl(module, ['kernel.randomize_va_space'])
    assert sysctl['kernel.randomize_va_space'] == '2'

# Generated at 2022-06-20 18:40:52.530782
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['net.inet.ip.portrange.randomized'])

# Generated at 2022-06-20 18:41:03.603405
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec=dict(),
    )

    with open('/proc/sys/vm/swappiness', 'r') as swappiness:
        swappiness_value = swappiness.readline()

    try:
        sysctl = get_sysctl(module, ['vm.swappiness'])
        assert sysctl['vm.swappiness'] == swappiness_value.strip()
    except Exception:
        err = get_exception()
        if PY3:
            err = to_text(err)
        module.fail_json(msg=err)

    module.exit_json(changed=False)

# Generated at 2022-06-20 18:41:12.156184
# Unit test for function get_sysctl
def test_get_sysctl():
    args = dict(
        prefixes=['kern.version'],
    )
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.sysctl import get_sysctl
    module = AnsibleModule(argument_spec=args, supports_check_mode=True)
    sysctl = get_sysctl(module, args['prefixes'])
    assert sysctl['kern.version'].startswith('FreeBSD 12.0')


# Generated at 2022-06-20 18:41:21.329424
# Unit test for function get_sysctl
def test_get_sysctl():
    # set up module
    module = type('AnsibleModule', (), {})
    sysctl_cmd = '/sbin/sysctl'
    module.run_command = lambda x: (0, 'kernel.hostname = localhost\nkernel.osrelease = 3.10.0-327.el7.x86_64\nkernel.ostype = Linux', '')
    module.get_bin_path = lambda x: sysctl_cmd
    module.warn = lambda x: None

    # test the function
    result = get_sysctl(module, ['kernel'])
    assert result['kernel.hostname'] == 'localhost'
    assert result['kernel.osrelease'] == '3.10.0-327.el7.x86_64'

# Generated at 2022-06-20 18:41:26.744898
# Unit test for function get_sysctl
def test_get_sysctl():
    # sysctl and sysctl -a should both return a dict containing the lines
    # with the same key and value.
    # The key should not have spaces on either side of =, : or =:
    # The value should not have spaces on the leading or trailing edge.
    assert get_sysctl(['-a']) == get_sysctl(['net.ipv4.ip_forward'])

# Unit tests for function get_sysctl_for_prefix

# Generated at 2022-06-20 18:41:30.134088
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.basic import AnsibleModule

    c = PlayContext()
    d = dict(ANSIBLE_MODULE_ARGS={})
    m = AnsibleModule(**d)
    s = get_sysctl(m, [])
    assert isinstance(s, dict)
    assert 'kernel.hostname' in s

# Generated at 2022-06-20 18:41:39.936256
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['net.ipv4.ip_forward', 'kernel.sysrq']) == {
        'net.ipv4.ip_forward': '0',
        'kernel.sysrq': '0'
    }
    assert get_sysctl({}, ['kernel.pid_max']) == {'kernel.pid_max': '32768'}
    assert get_sysctl({}, ['net.ipv4.ip_forward', 'kernel.sysrq', 'not.a.real.control']) == {
        'net.ipv4.ip_forward': '0',
        'kernel.sysrq': '0'
    }

# Generated at 2022-06-20 18:41:48.034609
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.sysctl = dict()

        def get_bin_path(self, cmd):
            return cmd

        def warn(self, msg):
            pass

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            if cmd[0] == 'sysctl':
                return 0, self.sysctl, ''
            if cmd[0] == 'sysclt':
                return 1, '', 'sysclt command not found'
            raise Exception('Unexpected command %s' % cmd[0])


# Generated at 2022-06-20 18:41:56.742952
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Returns a dict of k=v pairs by calling sysctl and passing it a list
    of prefixes to iterate over.

    :return: dict
    """
    import sys
    import os
    import tempfile

    # python2 doesn't have mock.patch
    # get around this issue by loading an import and setting an attribute
    # to the new value
    sys.modules['__main__'].run_command = lambda self, cmd, check_rc=True, close_fds=True, executable=None, data=None: (0, "", "")
    sys.modules['__main__'].open = lambda self, f, mode, buffering: tempfile.TemporaryFile(mode=mode, suffix=".out", dir="/tmp")

    # Our test data, we will feed this to run_command

# Generated at 2022-06-20 18:42:09.334974
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test the sysctl module with the default params
    # We will mock this with a function that returns a string
    # that we can use to test results
    class module:
        @staticmethod
        def get_bin_path(name):
            return 'sysctl'

        @staticmethod
        def run_command(cmd):
            return 0, "kern.hostname = test01\nkern.ostype =  FreeBSD\nkern.osrelease = 12.0-RELEASE \nkern.boottime = Sat Mar 24 22:47:10 2018", ''


# Generated at 2022-06-20 18:42:19.536897
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info[0] == 2:
        from mock import Mock, patch
    else:
        from unittest.mock import Mock, patch

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-20 18:42:30.719473
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.modules.system import sysctl
    from ansible.module_utils.six import StringIO
    class AnsibleModule(object):
        def __init__(self):
            self.run_command_called = False
            self.warn_called = False
            self.params = dict()

        def run_command(self, cmd):
            assert cmd == ['/usr/bin/sysctl', 'net.ipv4.ip_forward']
            self.run_command_called = True
            return 0, 'net.ipv4.ip_forward = 1', ''

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/sysctl'

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 18:42:42.257714
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os
    import tempfile

    test_cmd = 'test/modules/test_systemd_get_sysctl.sh'
    test_data_file = os.path.join(os.path.dirname(__file__), test_cmd)
    (test_fd, test_path) = tempfile.mkstemp()

    os.write(test_fd, b'#!/bin/bash\n')
    os.write(test_fd, b'sysctl -n $@\n')
    os.close(test_fd)
    os.chmod(test_path, 0o755)

    # This is where the testing begins


# Generated at 2022-06-20 18:42:46.359068
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    sys.path.append('../test/library')
    from ansible_module_get_sysctl import FakeAnsibleModule

    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-20 18:42:49.053036
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl() == dict()

# Generated at 2022-06-20 18:42:54.568188
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test with a list of prefixes
    prefixes = [
      'net.ipv4.ip_forward',
      'net.ipv4.conf.all.rp_filter'
    ]
    module = MockModule()
    sysctl = get_sysctl(module, prefixes)
    assert len(sysctl) == 2

# Unit test helper class to mock AnsibleModule

# Generated at 2022-06-20 18:43:00.341010
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.randomization'])
    assert sysctl['kernel.randomization'] == '28'
    sysctl = get_sysctl(module, ['kernel.randomization', 'kernel.pid_max'])
    assert sysctl['kernel.randomization'] == '28'
    assert sysctl['kernel.pid_max'] == '4194303'

# Generated at 2022-06-20 18:43:01.338810
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-20 18:43:07.815021
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    module.run_command = basic.run_command
    module.get_bin_path = basic.get_bin_path

    sysctl = get_sysctl(module, ['net.core.somaxconn'])
    assert to_bytes(sysctl['net.core.somaxconn']) == to_bytes('128')

# Generated at 2022-06-20 18:43:23.613222
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec={})

    # Mock module.run_command so that we can intercept and return the test data

# Generated at 2022-06-20 18:43:27.095081
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    values = get_sysctl(module, ['kernel', 'sem'])
    assert(values['kernel.sem'] == '250     32000   100 128')

# Hack for AnsibleModule to test sysctl

# Generated at 2022-06-20 18:43:34.742206
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that it returns a dictionary of keys and values
    assert get_sysctl(module, ['kernel.hostname']).get('kernel.hostname') is not None

    # Test that it returns the right values
    assert get_sysctl(module, ['kernel.hostname']) == {'kernel.hostname': 'localhost'}

    # Test that it iterates over values
    assert get_sysctl(module, ['kernel.hostname', 'kernel.osrelease']) == {'kernel.hostname': 'localhost', 'kernel.osrelease': '2.6.32-696.1.1.el6.x86_64'}

    # Test that a nonexistent sysct returns an empty dictionary

# Generated at 2022-06-20 18:43:37.709250
# Unit test for function get_sysctl
def test_get_sysctl():

    module = AnsibleModule(argument_spec={'prefixes': dict(required=True)})
    sysctl = get_sysctl(module, ['foo.bar'])
    assert sysctl == dict()


# Generated at 2022-06-20 18:43:46.976673
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    current_platform = sys.platform
    def sysctl(prefixes):
        if current_platform == 'darwin':
            path = 'tests/fixtures/sysctl/darwin.txt'
        elif current_platform == 'freebsd':
            path = 'tests/fixtures/sysctl/freebsd.txt'
        elif current_platform == 'linux':
            path = 'tests/fixtures/sysctl/linux.txt'
        else:
            path = 'tests/fixtures/sysctl/unknown.txt'

        with open(path, 'rb') as f:
            output = f.read()

        return 0, output, ''

    module.run_command = sysctl



# Generated at 2022-06-20 18:43:58.823128
# Unit test for function get_sysctl
def test_get_sysctl():
    module = 'fake'
    sysctl_cmd = module.get_bin_path('sysctl')
    cmd = [sysctl_cmd]
    cmd.extend('fake_args')
    fake_rc = 0

# Generated at 2022-06-20 18:44:05.806167
# Unit test for function get_sysctl
def test_get_sysctl():
    '''Return sysctl values when passed a prefix'''
    from ansible.module_utils.basic import AnsibleModule
    cmd = 'which sysctl'
    rc = 0
    out = 'out'
    err = 'err'
    module = AnsibleModule(
        argument_spec=dict()
    )

    class TestAnsibleModule():
        def __init__(self, argument_spec):
            self.params = dict()

        def run_command(self, cmd):
            return rc, out, err

        def get_bin_path(self, binary):
            if binary == 'sysctl':
                return cmd

    ret = dict(
        kernel=dict(
            domainname='(none)',
            hostname='testhost',
            msgmnb='65536',
        )
    )

# Generated at 2022-06-20 18:44:15.066830
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = type('', (), {}) # create an anonymous class

    # set the method get_bin_path to return the sysctl command
    def get_bin_path_method(cmd):
        return '/sbin/%s' % cmd

    # set the method run_command to return some test values

# Generated at 2022-06-20 18:44:21.372014
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Test sysctl output parsing.
    """
    import sys
    import StringIO
    import ansible.module_utils

    # Create an artificial module class with the minimal needed members
    class AnsibleModule:
        def __init__(self, argspec, supports_check_mode=False):
            self.params = dict()
            self.check_mode = supports_check_mode
            self.argument_spec = argspec
            self.run_command = self.run_command_fallback

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'sysctl':
                return '/sbin/sysctl'
            elif arg == 'env':
                return '/usr/bin/env'


# Generated at 2022-06-20 18:44:28.927877
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Make sure that we can parse output from sysctl
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils.facts.sysctl import get_sysctl

    module = AnsibleModule(supports_check_mode=True)
    ansible_module._module = module

    out = '''
kernel.domainname = example.com
kernel.hostname = host.example.com
kernel.osrelease = 2.6.32-431.el6.x86_64
kernel.ostype = Linux
kernel.version = #1 SMP Fri Nov 22 03:15:09 UTC 2013
'''
    # Test case where output is exactly as expected

# Generated at 2022-06-20 18:44:48.717560
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['kernel.ostype'])

    assert sysctl == {'kernel.ostype': 'Linux'}

# Generated at 2022-06-20 18:44:54.995591
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

    if not HAS_SYSCTL:
        module.fail_json(msg='sysctl is not installed')

    sysctl = get_sysctl(module, ['-n', 'net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}

    sysctl = get_sysctl(module, ['-a', '-n', 'net.ipv4.ip_forward'])
    assert sysctl == {
        'net.ipv4.ip_forward': '1',
    }


# Generated at 2022-06-20 18:44:59.369217
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec=dict())
    res = get_sysctl(module, ['net.ipv4.conf.all.forwarding'])
    assert to_bytes(res['net.ipv4.conf.all.forwarding']) == to_bytes('0')

# Generated at 2022-06-20 18:45:08.102064
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:45:14.290963
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    sys.path = ['.'] + sys.path

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list'),
        ),
    )

    sysctl = get_sysctl(module, ['kernel'])
    assert sysctl and 'kernel.hostname' in sysctl
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-20 18:45:16.199528
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = []

    results = get_sysctl(module, prefixes)

    assert(isinstance(results, dict))

# Generated at 2022-06-20 18:45:27.405171
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.network.common.utils import get_module
    from ansible.module_utils.network.common.utils import load_provider

    module = get_module(NetworkModuleArgs())
    load_provider(module, NetworkModuleArgs(**{'use_srx': True}))

    sysctl_cmd = module.get_bin_path('sysctl')
    cmd = [sysctl_cmd]
    cmd.extend(['-a'])

    sysctl = dict()

    try:
        rc, out, err = module.run_command(cmd)
    except (IOError, OSError) as e:
        rc = 1

    if rc == 0:
        key = ''
        value = ''

# Generated at 2022-06-20 18:45:36.026046
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import sys
    import tempfile

    sysctl_file = '/tmp/sysctl-unit-tests'
    sysctl_data = '''
kernel.msgmax = 65536
kernel.msgmnb = 65536
kernel.msgmni = 1280
kernel.sysrq = 1
kernel.shmmax = 68719476736
kernel.shmall = 4294967296
kernel.core_pattern = core
'''

    with open(sysctl_file, 'w') as f:
        f.write(sysctl_data)

    os.environ['PATH'] += os.pathsep + os.path.dirname(sysctl_file)


# Generated at 2022-06-20 18:45:36.540252
# Unit test for function get_sysctl
def test_get_sysctl():
    pass  # TODO

# Generated at 2022-06-20 18:45:47.681329
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test with sysctl returning a single key/value pair on one line
    class TestModule:
        def __init__(self):
            self.params = {'prefixes': ['-a']}

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, None, 'swappiness = 10\n'

    test_module = TestModule()
    actual = get_sysctl(test_module, ['swappiness'])
    expected = {'swappiness': '10'}
    assert actual == expected

    # Test with a key/value pair on multiple lines
    test_module = TestModule()
    actual = get_sysctl(test_module, ['kernel'])
    expected = {'kernel': 'Linux'}
    assert actual == expected

# Generated at 2022-06-20 18:46:26.537458
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec = dict()
    )
    test_module.run_command = fake_run_command
    test_module.get_bin_path = fake_get_bin_path

    sysctl = get_sysctl(test_module, ['kernel.hostname'])

    assert (sysctl['kernel.hostname'] == "fakehostname")


# Generated at 2022-06-20 18:46:28.135237
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule()
    prefixes = ['-a']
    sysctl = get_sysctl(module, prefixes)
    assert(sysctl)

# Generated at 2022-06-20 18:46:33.907919
# Unit test for function get_sysctl
def test_get_sysctl():
    # Retrieve network.ipv4.ip_forward sysctl value in presence of multiple
    # prefixes
    sysctl = get_sysctl(module=None,
                        prefixes=[
                            'net.ipv4.ip_forward',
                            'net.ipv4.route.flush'
                        ])
    assert sysctl['net.ipv4.ip_forward'] == '1'
    # Retrieve net.ipv4.ip_forward sysctl value in the absence of multiple
    # prefixes
    sysctl = get_sysctl(module=None, prefixes=['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-20 18:46:38.272806
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule({}, {})
    sysctl = get_sysctl(module, ["kernel"])
    assert sysctl["kernel.ostype"] == "Linux"


# Generated at 2022-06-20 18:46:41.850107
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['net.ipv4.conf.all.forwarding']
    sysctl = get_sysctl(prefixes)
    assert sysctl['net.ipv4.conf.all.forwarding'] == '1'

# Generated at 2022-06-20 18:46:49.654598
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    v = get_sysctl(module, ['fs.aio-'])
    assert v['fs.aio-max-nr'] == 2147483647
    assert v['fs.aio-nr'] in [1179648, 3109148]
    assert v['fs.aio-max-size'] == 2147483647
    assert v['fs.aio-nr'] in [1179648, 3109148]

# This is necessary after both AnsibleModule and test_get_sysctl have been executed in this test module
del AnsibleModule

# Generated at 2022-06-20 18:46:50.676807
# Unit test for function get_sysctl
def test_get_sysctl():
    pass



# Generated at 2022-06-20 18:46:55.324881
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl
    sysctl_values = sysctl.get_sysctl(['kernel.domainname', 'fs.file-max'])
    assert 'kernel.domainname' in sysctl_values
    assert 'fs.file-max' in sysctl_values

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:47:05.184836
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    import os

    module = AnsibleModule({}, supports_check_mode=True)

    # Create sysctl.conf
    sysctl_values_file = os.path.join(os.path.dirname(__file__), 'sysctl_values')
    os.environ["ANSIBLE_SYSTEM_SYSCTL_VALUES_FILE"] = sysctl_values_file

    # Test module
    sysctl = get_sysctl(module, ['--all'])


# Generated at 2022-06-20 18:47:17.131267
# Unit test for function get_sysctl
def test_get_sysctl():
    from units.compat import unittest
    from units.compat.mock import patch, MagicMock

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class ModuleMock:
        def __init__(self):
            self.params = {
                'name': 'net.ipv4.ip_forward',
            }

        def run_command(self, cmd):
            return 0, 'net.ipv4.ip_forward = 1', ''

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def fail_json(self, *args, **kwargs):
            raise AnsibleFailJson(args, kwargs)

        def exit_json(self, *args, **kwargs):
            raise

# Generated at 2022-06-20 18:49:00.911774
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule({})
    module.run_command.return_value = (0, "kern.securelevel: 0\nkern.hostname: myhost.mydomain\n", None)
    assert get_sysctl(module, ["kern"]) == {'kern.securelevel': '0', 'kern.hostname': 'myhost.mydomain'}


# Generated at 2022-06-20 18:49:06.023603
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(commands=dict(type='list')))
    m_run_command = MagicMock(return_value=(0, 'net.ipv4.ip_forward: 1\nnet.ipv4.tcp_syncookies: 0\nnet.ipv4.conf.all.accept_redirects: 0\n', ''))
    m_get_bin_path = MagicMock(return_value='/sbin/sysctl')
    module.run_command = m_run_command
    module.get_bin_path = m_get_bin_path
    sysctl = get_sysctl(module, ['-a'])
    assert 'net.ipv4.ip_forward' in sysctl
    assert 'net.ipv4.tcp_syncookies'

# Generated at 2022-06-20 18:49:14.122206
# Unit test for function get_sysctl
def test_get_sysctl():
    modulemock = AnsibleModule(argument_spec={})
    modulemock.run_command = MagicMock()
    sysctl_cmd = 'sysctl'
    cmd = [sysctl_cmd]
    cmd.append('kern.maxfiles')
    cmd.append('kern.maxfilesperproc')
    modulemock.run_command.return_value = (0, 'kern.maxfiles: 10000\nkern.maxfilesperproc: 10000', '')
    sysctl = get_sysctl(modulemock, ['-n', 'kern.maxfiles', '-n', 'kern.maxfilesperproc'])
    assert sysctl == dict(kern_maxfiles='10000', kern_maxfilesperproc='10000')

# Generated at 2022-06-20 18:49:22.423309
# Unit test for function get_sysctl
def test_get_sysctl():

    import ansible.module_utils.basic
    import ansible.module_utils.systemd

    test_sysctls = {
        "kernel": {
            "kernel.domainname": "",
            "kernel.hostname": "localhost.localdomain"
        },
        "vm": {
            "vm.max_map_count": "65530"
        }
    }

    def run_command(module, cmd):
        import json

        rc = 0
        err = ''
        cmd = ' '.join(cmd)

        if cmd.endswith('sysctl'):
            out = json.dumps(test_sysctls)
        else:
            rc = 1
            out = ''
            err = 'Unable to execute command: %s' % cmd

        return rc, out, err

    sysctl_

# Generated at 2022-06-20 18:49:25.199121
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    sysctl = get_sysctl(module, prefixes='vm.swappiness')
    assert sysctl == {'vm.swappiness': '0'}


# Generated at 2022-06-20 18:49:36.019458
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {})()

# Generated at 2022-06-20 18:49:36.860611
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['-a'])

# Generated at 2022-06-20 18:49:43.251191
# Unit test for function get_sysctl
def test_get_sysctl():
    # Unused argument
    # pylint: disable=W0613
    module = None

# Generated at 2022-06-20 18:49:52.982970
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO

    sysctl_cmd = '#sysctl'
    sysctl_out = b"""
    net.ipv4.ip_forward = 0
    net.ipv4.conf.default.rp_filter = 1
    net.ipv4.conf.default.accept_source_route = 0
    kernel.sysrq = 0
    kernel.core_uses_pid = 1
    net.ipv4.tcp_syncookies = 1
    kernel.msgmnb = 65536
    kernel.msgmax = 65536
    kernel.shmmax = 68719476736
    kernel.shmall = 4294967296
    """


# Generated at 2022-06-20 18:49:55.355725
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl('test_data/sysctl')
    assert sysctl['kernel.random.uuid'] == '201F4D88-BC36-4444-8F74-7814B50C9243'