

# Generated at 2022-06-20 18:40:49.357400
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Function get_sysctl unit test
    """
    pass

# Generated at 2022-06-20 18:41:00.705396
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    module.run_command = run_command
    sysctl_out = get_sysctl(module, ('kern',))
    assert sysctl_out['kern.maxfiles'].startswith('12288')
    sysctl_out = get_sysctl(module, ('kern.maxfiles',))
    assert sysctl_out['kern.maxfiles'].startswith('12288')
    sysctl_out = get_sysctl(module, ('kern', 'kern.maxfiles'))
    assert sysctl_out['kern.maxfiles'].startswith('12288')
    sysctl_out = get_sysctl(module, ('doesnotexist',))
    assert sysctl_out

# Generated at 2022-06-20 18:41:05.978432
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils._text import to_bytes

    sysctl_cmd = get_bin_path('sysctl')

    # Test with nonexistant key
    out = to_bytes('''
net.ipv4.ip_forward: 0
''')
    sysctl = get_sysctl(None, [b'net.ipv4.ip_nonexistant'], out, sysctl_cmd)
    assert sysctl == {}

    # Test with one key and value
    out = to_bytes('''
net.ipv4.ip_forward: 0
''')
    sysctl = get_sysctl(None, [b'net.ipv4.ip_forward'], out, sysctl_cmd)

# Generated at 2022-06-20 18:41:15.523294
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    module = AnsibleModule(argument_spec={'prefixes': dict(required=True, type='list')})
    module.run_command = lambda *args, **kwargs: (0, 'foo = 10\nbar: 20\n', '')

    assert module.get_bin_path('sysctl') == '/bin/sysctl'
    assert get_sysctl(module, ['foo']) == {'foo': '10', 'bar': '20'}


# Generated at 2022-06-20 18:41:23.805638
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat24

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )

    try:
        # Test with real sysctl
        module.run_command = module.run_command
        s = get_sysctl(module, ['-p'])
    except Exception:
        # Test with mock sysctl
        module.run_command = MockSysctl
        s = get_sysctl(module, ['-p'])

    assert s['kernel.hostname'] == 'TestHost'
    assert s['kernel.msgmax'] == '65536'
    assert s['kernel.msgmnb'] == '65536'



# Generated at 2022-06-20 18:41:27.871191
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': {'type': 'list', 'default': ['kernel']}})
    result = get_sysctl(module, ['kernel'])
    assert 'kernel.hostname' in result
    assert 'kernel.pid_max' in result
    assert 'kernel.real-root-dev' in result

# Generated at 2022-06-20 18:41:33.119552
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.common.sys_info import get_sysctl

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    value = get_sysctl(module, ['vm.overcommit_memory'])

    assert value['vm.overcommit_memory'] == '0'

# Generated at 2022-06-20 18:41:43.859344
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

    module.run_command = MagicMock(return_value=(0, "net.ipv4.conf.all.rp_filter: 1\nnet.ipv4.tcp_max_syn_backlog: 1234\n", ""))
    result = get_sysctl(module, ["net.ipv4.conf.all.rp_filter", "net.ipv4.tcp_max_syn_backlog"])
    assert result == {"net.ipv4.conf.all.rp_filter": "1", "net.ipv4.tcp_max_syn_backlog": "1234"}

    module.run_command = MagicMock(return_value=(1, "", "fake error"))

# Generated at 2022-06-20 18:41:53.464480
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None,['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward':'0'}
    assert get_sysctl(None,['kernel.osrelease']) == {'kernel.osrelease':'4.4.4-301.fc23.x86_64'}
    assert get_sysctl(None,['kernel.osrelease', 'kernel.ostype']) == {
        'kernel.osrelease':'4.4.4-301.fc23.x86_64',
        'kernel.ostype':'Linux'}

# Generated at 2022-06-20 18:42:05.508698
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.zfs_utils import get_sysctl
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    rval = get_sysctl(module, ["net.inet.ip.forwarding"])
    assert(rval == {'net.inet.ip.forwarding': '1'})

    module = AnsibleModule(argument_spec={})
    rval = get_sysctl(module, ["kern.hostname"])
    assert(rval == {'kern.hostname': 't1-pon1-r1-rtr2.rccr.rccr.net'})

    module = AnsibleModule(argument_spec={})
    rval = get

# Generated at 2022-06-20 18:42:11.736300
# Unit test for function get_sysctl
def test_get_sysctl():
    # Can't test in CI as sysctl is not installed
    pass

# Generated at 2022-06-20 18:42:15.708795
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    prefixes = ['-n', '-a']
    result = get_sysctl(module, prefixes)
    assert isinstance(result, dict)

# Generated at 2022-06-20 18:42:25.557585
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:42:28.803592
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule()

    sysctl = get_sysctl(module, ['vm.swappiness'])

    assert sysctl == {'vm.swappiness': '60'}



# Generated at 2022-06-20 18:42:32.399362
# Unit test for function get_sysctl
def test_get_sysctl():
    args = {}
    rc, out, err = get_sysctl(args, prefixes=['vm', 'fs'])
    assert rc == 0
    assert 'vm.swappiness' in out
    assert 'fs.file-max' in out

# Generated at 2022-06-20 18:42:39.935105
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Unit test for get_sysctl function.

    It requires the external sysctl command, so it is not run by default.
    """
    from ansible.utils import ANSIBLE_LIB_DIR
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec={
            'prefixes': {'type': 'list', 'required': True},
        },
    )

    test_module.run_command = run_command

    test_sysctl = get_sysctl(test_module, test_module.params['prefixes'])
    assert test_sysctl == {
        'kern.hostname': 'test_hostname',
        'kern.ostype': 'test_ostype',
    }


# Shim to replace ansible.module_utils.basic

# Generated at 2022-06-20 18:42:49.377964
# Unit test for function get_sysctl
def test_get_sysctl():
    tests_vars = dict(
        test_get_sysctl1 = dict(
            prefixes=['fs.file-max'],
            sysctl={
                'fs.file-max': '1048576'
            }
        ),
        test_get_sysctl2 = dict(
            prefixes=['kernel.randomize_va_space'],
            sysctl={
                'kernel.randomize_va_space': '2'
            }
        ),
        test_get_sysctl3 = dict(
            prefixes=['kernel.randomize_va_space', 'fs.file-max'],
            sysctl={
                'kernel.randomize_va_space': '2',
                'fs.file-max': '1048576'
            }
        ),
    )


# Generated at 2022-06-20 18:42:59.714251
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    # test we can read values
    assert(get_sysctl(module, ['kern.bootfile']) == {'kern.bootfile': '/boot/kernel/kernel'})
    # test we can read multiline values
    assert(get_sysctl(module, ['vm.swap_info']) == {'vm.swap_info': '/dev/ada0p3\t\n         65536\t\t16404\t\t0\t\t 0'})
    # test we do not get corrupted value for empty value
    assert(get_sysctl(module, ['kern.bootfile', '']) == {'kern.bootfile': '/boot/kernel/kernel'})
    # test

# Generated at 2022-06-20 18:43:07.996345
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('obj', (object,), {
        'get_bin_path': lambda self, arg: '/sbin/sysctl',
        'run_command': lambda self, cmd: (0, 'vm.max_map_count = 262144\nnet.ipv4.conf.default.rp_filter = 1\n', None)})()
    prefixes = ['kernel.randomize_va_space', 'vm.max_map_count']
    sysctl = get_sysctl(module, prefixes)
    assert sysctl == {
        'kernel.randomize_va_space': '1',
        'vm.max_map_count': '262144'
    }

# Generated at 2022-06-20 18:43:17.712487
# Unit test for function get_sysctl
def test_get_sysctl():
    # Get the md5 hashes of all our sysctl values
    sysctl_values = get_sysctl(prefixes=['net', 'ipv4'])
    # If our sysctl doesn't have these values, then somethiing's gone wrong, fail the test
    for s in ['net.ipv4.icmp_echo_ignore_all', 'net.ipv4.ip_forward', 'net.ipv4.conf.all.accept_redirects', 'net.ipv4.conf.all.secure_redirects', 'net.ipv4.conf.all.send_redirects']:
        if s not in sysctl_values:
            raise AssertionError("Unable to retrieve sysctl value for '%s'" % s)

# Generated at 2022-06-20 18:43:31.056057
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile
    from ansible.module_utils.six import StringIO


# Generated at 2022-06-20 18:43:36.890711
# Unit test for function get_sysctl
def test_get_sysctl():
    print("get_sysctl")
    sysctl = get_sysctl("net.ipv4.ip_local_port_range")
    print("sysctl = %s" % sysctl)
    assert sysctl['net.ipv4.ip_local_port_range'] == '32768    60999'


# Generated at 2022-06-20 18:43:37.493030
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:43:45.904272
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os

    sysctl_cmd = AnsibleModule(
        argument_spec = dict(),
    ).get_bin_path('sysctl')

    cmd = [sysctl_cmd]
    cmd.extend(['-a'])

    rc, out, err = AnsibleModule(
        argument_spec = dict(),
    ).run_command(cmd)

    sysctl = get_sysctl(AnsibleModule(
        argument_spec = dict(),
    ), ['-a'])

    assert len(sysctl) == len(out.strip().splitlines())
    assert os.uname()[1] == sysctl['kern.hostname']

# Generated at 2022-06-20 18:43:57.471082
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import json
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 18:44:05.106542
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None  # noqa: F401
    assert get_sysctl(module, ["net.ipv4.ip_forward"]) == {'net.ipv4.ip_forward': '1'}
    assert get_sysctl(module, ["kernel.core_pattern"]) == {'kernel.core_pattern': 'core'}
    assert get_sysctl(module, ["kernel.core_pattern", "net.ipv4.ip_forward"]) == {
        'net.ipv4.ip_forward': '1',
        'kernel.core_pattern': 'core'
    }
    assert get_sysctl(module, ["kernel.core_pattern", "non-existent-key"]) == {'kernel.core_pattern': 'core'}
    assert get_sysctl(module, ["non-existent-key"])

# Generated at 2022-06-20 18:44:14.455926
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    class TestGetSysctl(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp(prefix='ansible-test-sysctl-')
            self.sysctl_file = os.path.join(self.tempdir, 'sysctl.conf')
            # Create a fake /proc/sys/net/ipv4/ip_local_port_range
            self.ip_local_port_file = os.path.join(self.tempdir, 'net', 'ipv4', 'ip_local_port_range')

# Generated at 2022-06-20 18:44:20.931209
# Unit test for function get_sysctl
def test_get_sysctl():
    """Function get_sysctl returns expected data structure"""

    class FakeModule():
        def __init__(self):
            self.rc = 0
            self.warn = print
            self.run_command = self.run_cmd

        def run_cmd(self, cmd, check_rc=False):
            self.rc = 0
            self.cmd = cmd
            self.out = "vm.swappiness: 1\nvm.dirty_writeback_centisecs: 1500\nvm.dirty_expire_centisecs: 3000\nvm.dirty_background_ratio: 10\nvm.dirty_ratio: 20"
            self.err = ''

    m = FakeModule()
    sysctl = get_sysctl(m, ['vm.swappiness', 'vm.dirty_*'])

# Generated at 2022-06-20 18:44:25.288467
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()
    module.warn = print
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    assert get_sysctl(module, ['']) == {
        'hw.machine': 'amd64',
        'hw.model': 'AMD A10-6700 APU with Radeon(tm) HD Graphics',
        'hw.ncpu': '4',
        'hw.pagesize': '4096',
        'hw.physmem': '17163642880',
        'hw.usermem': '17156665344',
    }



# Generated at 2022-06-20 18:44:35.763050
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_keys = ['vm.swappiness', 'net.ipv4.ip_forward']

    # Generate fake module object and results
    class FakeModule(object):
        def __init__(self, params=None):
            self.params = params or dict()
            self.fail_json = lambda *args, **kwargs: dict(failed=True, msg='test')

        def get_bin_path(self, arg):
            return arg

        def run_command(self, cmd):
            res = dict(rc=0, stdout='', stderr='')
            if cmd[0] == 'sysctl':
                res['stdout'] = '\n'.join([
                    'vm.swappiness = 60',
                    'net.ipv4.ip_forward = 1',
                ])

# Generated at 2022-06-20 18:44:52.229174
# Unit test for function get_sysctl
def test_get_sysctl():
    import shlex
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.sysctl import get_sysctl

    def run_command(self, cmd):
        if ' '.join(cmd) == 'sysctl net.ipv4.conf.all.rp_filter':
            return (0, 'net.ipv4.conf.all.rp_filter = 1', '')
        return (0, '', '')

    module = AnsibleModule(argument_spec=dict())
    module.run_command = run_command
    prefixes = shlex.split('net.ipv4.conf.all.rp_filter')

    sysctl = get_sysctl(module, prefixes)

# Generated at 2022-06-20 18:44:53.271616
# Unit test for function get_sysctl
def test_get_sysctl():
    print(get_sysctl())

# Generated at 2022-06-20 18:44:59.739771
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.system.sysctl as sysctl_utils

    module_args = dict()

    # Construct a basic module
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # Run the function
    sysctl_values = sysctl_utils.get_sysctl(module, ['kernel.*', 'vm.*'])
    assert sysctl_values['kernel.sem'] is not None
    assert sysctl_values['vm.max_map_count'] is not None

# Generated at 2022-06-20 18:45:08.423876
# Unit test for function get_sysctl
def test_get_sysctl():
    m = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(required=True, type='list')
        )
    )

# Generated at 2022-06-20 18:45:18.990382
# Unit test for function get_sysctl
def test_get_sysctl():
    """Unit test for function get_sysctl"""
    module = type('', (), {})()
    module.run_command = lambda x: (0, "kern.boottime: { sec = 1370859331, usec = 606094 }\nkern.bootfile: /mach_kernel\nkern.handler_class: net.inet.tcp.tcb_hashsize\nkern.machdep.xcpm.asid_bits: 8\nkern.maxvnodes: 96000\nkern.memorystatus_vm_pressure_level: 0\nkern.vm.phys_page_size: 4096\n", '')
    prefixes = ['kern.maxvnodes']
    sysctl_cmd = get_sysctl(module, prefixes)

# Generated at 2022-06-20 18:45:29.817973
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl

    module = sysctl
    module.params = {}
    prefixes = ['kernel', 'vm']
    prefixes_bad = ['kernel', 'vmm']

    # Test to make sure we get some results
    results = get_sysctl(module, prefixes)
    assert len(results) > 0

    # Test to make sure we get an  empty dict when no results
    results = get_sysctl(module, prefixes_bad)
    assert len(results) == 0

    module.warn = lambda msg: msg
    module.warn.called = False

    def test_run_command(*args):
        if args[1].startswith('sysctl'):
            raise IOError('atest')
        return relevant_output, err, exit_status


# Generated at 2022-06-20 18:45:37.513798
# Unit test for function get_sysctl
def test_get_sysctl():
    from nose.tools import assert_equals

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'one': 'asdf', 'two': 'jkl;'})

    # If a command fails, rc will be non-zero, and out and err will be empty.
    module.run_command = lambda x: (0, '', '')
    assert_equals({}, get_sysctl(module, ['/etc/sysctl.conf']))
    assert_equals({}, get_sysctl(module, ['nonexistent_key', 'nonexistent_value']))
    assert_equals({}, get_sysctl(module, ['nonexistent_key', 'nonexistent_value', 'nonexistent_prefix']))

# Generated at 2022-06-20 18:45:43.549490
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=True, type='list')
        )
    )

    sysctls = get_sysctl(m, m.params['prefixes'])

    assert sysctls, sysctls



# Generated at 2022-06-20 18:45:51.807179
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import StringIO

    class Mod():
        def __init__(self):
            self.params = {'warn': print}
            self.run_command = self.fake_run_command

        def fake_run_command(self, cmd):
            out = StringIO.StringIO()

            out.write("""
kernel.osrelease = 3.10.0-957.1.3.el7.x86_64
kernel.sysrq = 16
kernel.yyyyy = 1
kernel.yyyyy = 2
kernel.zzzzz = 4
""")
            out.seek(0)
            return (0, out, '')

    a = Mod()


# Generated at 2022-06-20 18:45:55.534059
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    assert get_sysctl(module, ['net.ipv4.ip_forward'])['net.ipv4.ip_forward'] is "1"


# Generated at 2022-06-20 18:46:16.422410
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl_results = get_sysctl(module, [ 'net.ipv4.conf.all.rp_filter' ])
    assert sysctl_results.get('net.ipv4.conf.all.rp_filter') == '1'


# Generated at 2022-06-20 18:46:25.150804
# Unit test for function get_sysctl
def test_get_sysctl():
    ''' Test function get_sysctl '''
    import sys

    if sys.version_info[0] < 3:
        from mock import Mock, patch
    else:
        from unittest.mock import Mock, patch

    from ansible.module_utils.basic import AnsibleModule

    # pylint: disable=E1101
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    mock_module = Mock()
    mock_module.get_bin_path.return_value = '/usr/bin/sysctl'


# Generated at 2022-06-20 18:46:30.595415
# Unit test for function get_sysctl
def test_get_sysctl():
    class _module:
        def get_bin_path(self, arg):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            out = """
kern.maxfiles: 1234
kern.maxfilesperproc: 1234
kern.nkp = 1"""
            return 0, out, ''
    module = _module()
    assert get_sysctl(module, []) == { 'kern.maxfiles': '1234', 'kern.maxfilesperproc': '1234', 'kern.nkp' : '1' }

# Generated at 2022-06-20 18:46:33.537307
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl
    s = sysctl.get_sysctl({}, ["kernel.version", "vm.swappiness"])

    assert "kernel.version" in s
    assert "vm.swappiness" in s

# Generated at 2022-06-20 18:46:38.424510
# Unit test for function get_sysctl
def test_get_sysctl():

    import mock

    module = mock.Mock()
    module.warn = mock.Mock()
    module.run_command = mock.Mock()
    rc = 0

# Generated at 2022-06-20 18:46:49.201267
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:46:57.135667
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class Module(object):
        def __init__(self):
            self.ansible_module = AnsibleModule(
                argument_spec={},
                supports_check_mode=True
            )

        def get_bin_path(self, d, opt_dirs=[]):
            return 'sysctl'

        def run_command(self, cmd, check_rc=True, close_fds=False, executable=None, data=None):
            if cmd[0] == 'sysctl':
                return (1, cmd, '')

        def warn(self, msg):
            msg = msg.replace('\n', '')
            assert msg == 'Unable to read sysctl: No such file or directory'

    module = Module()

# Generated at 2022-06-20 18:47:05.971199
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('Obj', (), {'run_command': test_run_command, 'warn': print, 'get_bin_path': lambda self, item: item})()
    module = module()
    # Return code
    assert get_sysctl(module, []) == dict()
    assert get_sysctl(module, []) == dict()
    # Header
    assert get_sysctl(module, []) == dict()
    assert get_sysctl(module, []) == dict()
    # Empty value
    assert get_sysctl(module, []) == dict(key="")
    assert get_sysctl(module, []) == dict(key="")
    # Value
    assert get_sysctl(module, []) == dict(key="value")
    assert get_sysctl(module, []) == dict(key="value")


# Generated at 2022-06-20 18:47:12.659406
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'kernel.version'])
    assert sysctl['net.ipv4.ip_forward'] == '1'
    assert sysctl['kernel.version'].startswith('#')

    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.osrelease'])
    assert sysctl['kernel.osrelease']

    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['fs.file-nr'])
    assert sysctl['fs.file-nr']

    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-20 18:47:17.022884
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict()
    )
    prefixes = ['-n', 'hw.physmem']

    set_module_args(dict(
        prefixes=prefixes,
    ))

    sysctl = get_sysctl(module, prefixes)
    assert sysctl['hw.physmem'] == '8589934592'

# Generated at 2022-06-20 18:48:08.826884
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sysctl = get_sysctl(module, ['net.ipv4.tcp_tw_reuse', 'net.ipv4.tcp_fin_timeout'])
    assert sysctl == {'net.ipv4.tcp_tw_reuse': '1', 'net.ipv4.tcp_fin_timeout': '30', 'net.ipv4.tcp_fin_timeout.2': '30'}


# Generated at 2022-06-20 18:48:09.511693
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-20 18:48:18.840456
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    # Define a fake sysctl output:
    out = '''
net.core.somaxconn = 8192
fs = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.ip_forward = 0
vm.swappiness = 0
net.ipv4.conf.all.rp_filter = 0
'''

    module.run_command = lambda x: (0, out, None)

# Generated at 2022-06-20 18:48:25.169080
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (), {})
    module.run_command = lambda x: (0, '\n'.join(x), '')
    module.warn = lambda x: x
    module.get_bin_path = lambda x: x
    sysctl = get_sysctl(module, ['-a'])
    assert len(sysctl) > 0
    assert sysctl.get('kern.hostname')



# Generated at 2022-06-20 18:48:29.404994
# Unit test for function get_sysctl
def test_get_sysctl():
    args = {}
    from ansible.modules.system.setup import get_sysctl

    sysctl = get_sysctl(args, ('kernel.pid_max', 'kernel.domainname'))

    assert sysctl['kernel.pid_max'] is not None, 'get_sysctl() should return a valid value'
    assert sysctl['kernel.domainname'] is not None, 'get_sysctl() should return a valid value'
    assert sysctl['kernel.random.read_wakeup_threshold'] is None, 'get_sysctl() should not return an invalid value'

# Generated at 2022-06-20 18:48:38.934262
# Unit test for function get_sysctl
def test_get_sysctl():
    class MockModule(object):
        '''
        Mock class to provide a mock run_command function that read a mocked
        output.
        '''
        def __init__(self):
            self.run_command_calls = []
            self.run_command_responses = []

        def run_command(self, command):
            self.run_command_calls.append(command)
            return self.run_command_responses.pop(0)

    # Test happy path
    m = MockModule()
    m.run_command_responses = [(0, 'net.bridge.bridge-nf-call-ip6tables = 1', '')]

# Generated at 2022-06-20 18:48:44.330603
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    if sys.version_info.major >= 3:
        import io
        sys.stdout = io.StringIO()  # noqa

    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 18:48:52.086104
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Get the sysctl values for just the path 'kernel'
    sysctl = get_sysctl(module, ['kernel'])

    # Check that it returned data
    assert sysctl, "The sysctl call failed."

    # Check a couple of the returned values.
    assert sysctl['kernel.hostname'] == 'localhost', "The kernel.hostname returned was incorrect."
    assert 'kernel.sem' in sysctl, "The kernel.sem parameter was not found in the output of the sysctl command."



# Generated at 2022-06-20 18:48:58.914233
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import PY2
    if not PY2:
        import builtins
        builtin_module_name = 'builtins'
    else:
        import __builtin__
        builtin_module_name = '__builtin__'

    m = __import__(builtin_module_name, globals(), locals(), ['object'], 0)
    (failures, tests) = doctest.testmod(m)
    sys.exit(failures)

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:49:04.836098
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = AnsibleModule(argument_spec={})

    test_command = "/usr/bin/sysctl -a"
    test_output = '''
        net.ipv4.ip_forward = 1
        net.ipv4.conf.all.send_redirects = 1
        net.ipv4.conf.default.send_redirects = 1
'''

    test_module.run_command = Mock(return_value=(0, test_output, ""))

    actual_output = get_sysctl(test_module, ['-a'])

    test_module.run_command.assert_called_once_with(test_command)

# Generated at 2022-06-20 18:50:34.612383
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['-a'])

    assert 'kernel.hostname' in sysctl
    assert sysctl['kernel.hostname'] == 'andrew-test-centos-6'

# Generated at 2022-06-20 18:50:40.828389
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    cmd = ['sysctl', '--system']
    rc = 0

# Generated at 2022-06-20 18:50:48.921611
# Unit test for function get_sysctl
def test_get_sysctl():
    test = {}
    test['expected'] = {u'net.core.rmem_max': u'124928', u'net.core.somaxconn': u'32768', u'net.core.rmem_default': u'124928', u'net.core.wmem_max': u'124928', u'net.core.wmem_default': u'124928'}
    test['stdout'] = '''net.core.rmem_max: 124928
net.core.somaxconn: 32768
net.core.rmem_default: 124928
net.core.wmem_max: 124928
net.core.wmem_default: 124928'''

    assert get_sysctl(None, ['net.core']) == test['expected']