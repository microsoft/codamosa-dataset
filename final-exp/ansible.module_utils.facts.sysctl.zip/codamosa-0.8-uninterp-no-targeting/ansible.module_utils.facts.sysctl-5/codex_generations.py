

# Generated at 2022-06-20 18:40:48.294884
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': {'type': 'list', 'required': True}})
    assert module.get_sysctl(['kernel.domainname']) == { "kernel.domainname": "localdomain" }
    assert module.get_sysctl(['kernel.domainname', 'kernel.hostname']) == { "kernel.domainname": "localdomain", "kernel.hostname": "localhost" }


# Generated at 2022-06-20 18:40:59.594609
# Unit test for function get_sysctl
def test_get_sysctl():
    test_cases = [
        {
            'args': [],
            'out': {},
        },
        {
            'args': ['vm.swappiness'],
            'out': {'vm.swappiness': '60'},
        },
        {
            'args': ['vm.swappiness', 'vm.dirty_background_ratio'],
            'out': {
                'vm.swappiness': '60',
                'vm.dirty_background_ratio': '10'
            },
        },
    ]

    import ansible.module_utils.basic
    import ansible.module_utils.facts

    class FakeModule(object):
        def __init__(self, args):
            args = {}

# Generated at 2022-06-20 18:41:03.325906
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )
    assert get_sysctl(module, [])
    assert get_sysctl(module, ['-a'])

# Generated at 2022-06-20 18:41:07.280809
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    result = get_sysctl(module, ['kernel'])
    assert result['kernel.ostype'] == 'FreeBSD'


# Generated at 2022-06-20 18:41:18.652378
# Unit test for function get_sysctl
def test_get_sysctl():
    # Create an in-memory "file" with sample output.
    class FakeModule():
        def __init__(self):
            self.core = dict()
            self.core['name'] = 'core'
            self.core['path'] = '/proc/sys'
            self.core['defaults'] = dict()
            self.core['defaults']['conf_file'] = '/etc/sysctl.conf'
            self.core['defaults']['persist_file'] = '/etc/sysctl.d/99-ansible-sysctl.conf'
            self.bin_path = dict()
            self.bin_path['sysctl'] = '/sbin/sysctl'

        def get_bin_path(self, path):
            return self.bin_path[path]


# Generated at 2022-06-20 18:41:23.235629
# Unit test for function get_sysctl
def test_get_sysctl():

    import ansible.module_utils.basic as module_utils

    module = module_utils.basic.AnsibleModule(argument_spec={'prefixes': dict(type='list')})

    sysctl = get_sysctl(module, ['vm.overcommit_memory'])

    assert isinstance(sysctl, dict)
    assert 'vm.overcommit_memory' in sysctl
    assert sysctl['vm.overcommit_memory'] == '1'



# Generated at 2022-06-20 18:41:30.314909
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import platform
    import sys
    import tempfile
    import time

    # Set up a temporary file for the sysctl data
    tmp = tempfile.NamedTemporaryFile()
    sysctl_file = tmp.name
    tmp.close()

    # Create a file with sysctl data
    tmp = open(sysctl_file, 'w')

    if platform.system() == 'FreeBSD':
        tmp.write('security.bsd.see_other_gids: 0\n' +
                  'security.bsd.see_other_uids: 0\n' +
                  'security.bsd.stack_guard_page: 1\n' +
                  'security.bsd.unprivileged_proc_debug: 0\n')

# Generated at 2022-06-20 18:41:41.756212
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    # sysctl -aN -nN -NN -NNN -NNNN

# Generated at 2022-06-20 18:41:53.635158
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    TEST_STDOUT = '''
    net.ipv4.conf.all.rp_filter = 1
    net.ipv4.conf.default.rp_filter = 1
    net.ipv4.tcp_keepalive_time = 7200
    net.ipv4.tcp_rmem = 4096 87380 4194304
    net.ipv4.tcp_wmem = 4096 65536 4194304
    '''
    TEST_STDERR = '''
    '''

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-20 18:42:05.630804
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {})
    module.run_command = lambda *a, **kw: (0, '''net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
''', None)
    module.get_bin_path = lambda _: '/sbin/sysctl'

# Generated at 2022-06-20 18:42:16.774858
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('MockModule', (object,), {
        'run_command': lambda self, cmd: (0, 'vm.swappiness = 1\nvm.overcommit_memory = 2\n', ''),
        'warn': lambda self, text: None,
    })()
    result = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory'])
    assert result == {'vm.swappiness': '1', 'vm.overcommit_memory': '2'}


# Generated at 2022-06-20 18:42:18.683753
# Unit test for function get_sysctl
def test_get_sysctl():
    module = []
    prefixes = []
    sysctl = get_sysctl(module, prefixes)

    assert sysctl != None

# Generated at 2022-06-20 18:42:30.617787
# Unit test for function get_sysctl
def test_get_sysctl():
    # Import Ansible here, since not part of integrated test framework.
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    # Set args and kwargs to values expected by AnsibleModule.
    args = []
    kwargs = {
        'argument_spec': {},
        'check_invalid_arguments': None,
        'bypass_checks': False,
        'no_log': False,
        'supports_check_mode': False,
        '_ansible_version': '2.5',
    }
    # Create an AnsibleModule with the arguments required by get_sysctl.
    mod = AnsibleModule(**kwargs)

    # Run get_sysctl.
    sysctl = get_sysctl(mod, ['fs.file-max'])

# Generated at 2022-06-20 18:42:42.059178
# Unit test for function get_sysctl
def test_get_sysctl():
    # unit test for function get_sysctl
    # requires that sysctl be installed and functional
    # and that mock be installed
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.run_command = None
            self.get_bin_path = None

    class FakeAnsibleModule(object):
        def __init__(self):
            self.run_command = FakeModule()
            self.get_bin_path = FakeModule()

    module = FakeAnsibleModule()
    module.run_command.return_code = 0
    module.run_command.stderr = ''

# Generated at 2022-06-20 18:42:50.754593
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    # Setup

# Generated at 2022-06-20 18:42:53.498025
# Unit test for function get_sysctl
def test_get_sysctl():
    module = get_sysctl(['kern', 'vm', 'swap'], True)

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:43:04.628318
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        prefixes = dict(type='list')
    ))

    expected_sysctl = {
        'net.ipv4.ip_forward': '1',
        'net.ipv4.ip_local_port_range': '32768   61000',
        'net.ipv4.tcp_fin_timeout': '30',
    }

    module.run_command = lambda *args, **kwargs: (0, '''
net.ipv4.ip_forward = 1
net.ipv4.ip_local_port_range = 32768   61000
net.ipv4.tcp_fin_timeout = 30
''', '')


# Generated at 2022-06-20 18:43:07.962958
# Unit test for function get_sysctl
def test_get_sysctl():

    import ansible.module_utils.basic as utils
    assert get_sysctl(utils.AnsibleModule(argument_spec={}), ['-a'])

# Generated at 2022-06-20 18:43:09.989683
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl("", ["vm.swappiness"])["vm.swappiness"] == "60"

# Generated at 2022-06-20 18:43:16.173806
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    assert get_sysctl(module, ['kernel.domainname', 'kernel.hostname']) == {
        'kernel.domainname': 'localdomain',
        'kernel.hostname': 'localhost.localdomain',
    }


# Generated at 2022-06-20 18:43:29.582453
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    prefixes = ['net.ipv4']
    sysctl = get_sysctl(module, prefixes)

    assert sysctl is not {}, "Failed to get sysctl values"
    assert sysctl['net.ipv4.ip_forward'] == '1', "Unexpected sysctl value"


# Generated at 2022-06-20 18:43:36.378253
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile
    import shutil
    import sys
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a directory for the fake command to live in
    bindir = os.path.join(tmpdir, 'bin')
    os.mkdir(bindir)

    # create a file for the fake command to live in
    command = os.path.join(bindir, 'sysctl')
    with open(command, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo "sysctl.conf.1 = value\n"')
        f.write('echo "sysctl.conf.2 = value"')
    os.chmod(command, 0o755)
    os.chmod(bindir, 0o755)



# Generated at 2022-06-20 18:43:45.941679
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()

    class FakeRunner:
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    module.get_bin_path = lambda x: x
    module.run_command = FakeRunner().run_command

    assert get_sysctl(module, []) == dict()
    assert get_sysctl(module, ['foo']) == dict()

    out = '''\
foo = bar
foobar = bar
foomultiline = bar
  bar
  baz
foomultiline = bar
  bar
  baz
'''

# Generated at 2022-06-20 18:43:51.754927
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    def fake_run_command(cmd):
        output = dict()
        output['rc'] = 0
        output['stderr'] = ''

# Generated at 2022-06-20 18:43:58.513662
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import json

    m = AnsibleModule(argument_spec={'prefixes': dict(type='list', default=['net.ipv4.ip_forward'])})

    out = get_sysctl(m, m.params['prefixes'])

    assert out == json.loads(to_text('''{"net.ipv4.ip_forward": "1"}'''))

# Generated at 2022-06-20 18:44:01.935254
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    cmd_bins = {
        "sysctl": "bin/sysctl",
    }

    test = get_sysctl(AnsibleModule(cmd_bins=cmd_bins), ["kern.*"])
    assert test is not None


# Generated at 2022-06-20 18:44:12.321612
# Unit test for function get_sysctl
def test_get_sysctl():

    # Imports inside the function because we need the sysctl module imported
    import json
    import os
    import sys
    import tempfile
    sys.path.append('../..')
    from lib.modules.system import sysctl as sysctl_module

    # Mock sysctl
    sysctl_mock = {
        'kern.hostname': 'sid.example.com',
        'kern.ostype': 'Darwin',
        'kern.osrelease': '19.6.0',
        'hw.ncpu': '8',
        'hw.memsize': '17179869184',
        'kern.domainname': '',
        'vm.swapusage': 'total = 2048.00M  used = 512.00M  free = 1536.00M  (encrypted)',
    }
    sys

# Generated at 2022-06-20 18:44:22.963440
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    module = AnsibleModule({})
    module.run_command = lambda x: (0, 'net:\n\t.ipv4.ip_forward = 1', '')
    prefix = ['net.ipv4.ip_forward']
    output = get_sysctl(module, prefix)
    assert output['net.ipv4.ip_forward'] == '1'
    module.run_command = lambda x: (0, 'net:\n\t.ipv4.ip_forward = 1\n\t.ipv4.conf.default.forwarding = 1', '')
    output = get_sysctl(module, prefix)
    assert output['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-20 18:44:31.371919
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    test_sysctl_stdout = StringIO(u'''
kernel.hostname = ansible-test
kernel.user_name = ansible-test
kernel.domain = ansible-test
net.ipv4.conf.default.rp_filter = 1
''')

    test_results = {
        "kernel.domain": "ansible-test",
        "kernel.hostname": "ansible-test",
        "kernel.user_name": "ansible-test",
        "net.ipv4.conf.default.rp_filter": "1"
    }


# Generated at 2022-06-20 18:44:38.531125
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    prefixes = ('kernel.randomize_va_space', 'fs.file-max')
    sysctl = get_sysctl(module, prefixes)
    assert sysctl
    vars = ['fs.file-max', 'kernel.randomize_va_space']
    for var in vars:
        assert var in sysctl.keys()
    assert sysctl['kernel.randomize_va_space'] == '1'

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 18:45:01.803203
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import Facts
    import json

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    facts = Facts()
    results = facts.populate()

    if len(results['warnings']):
        module.fail_json(msg=results)

    sysctl = get_sysctl(module, ['kernel'])
    print(json.dumps(sysctl, sort_keys=True,
                     indent=4, separators=(',', ': ')))


if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:45:04.940481
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(module, ["kernel.ostype", "kernel.hostname", "vm.min_free_kbytes"]) == {'kernel.hostname': 'centos.example.com', 'kernel.ostype': 'Linux'}

# Generated at 2022-06-20 18:45:07.990729
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule({'run_command.return_value': (0, "keys=values\nkvm=test", "")})
    sysctl = get_sysctl(module, [])
    assert sysctl == {"keys": "values", "kvm": "test"}


# Generated at 2022-06-20 18:45:12.439754
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['hw.physmem'])
    assert sysctl['hw.physmem'] == '4294967296'

# Generated at 2022-06-20 18:45:22.248583
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import json
    import os

    class TestException(Exception):
        pass

    def get_sysctl_cmd(cmd):
        path = os.environ['PATH']
        if path.find('/usr/sbin') == -1:
            os.environ['PATH'] = path + os.pathsep + '/usr/sbin'

        if cmd == ['/usr/sbin/sysctl', 'net.ipv4.ip_forward']:
            return (0, 'net.ipv4.ip_forward = 1\n', '')

# Generated at 2022-06-20 18:45:29.275826
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # this test won't work on Windows
    if module.get_bin_path('sysctl'):
        data = get_sysctl(module, [])
        assert 'kernel.version' in data
        assert data['kernel.version'].startswith('Linux ')
    else:
        assert True

# Generated at 2022-06-20 18:45:38.057020
# Unit test for function get_sysctl
def test_get_sysctl():

    class MockModule(object):
        def get_bin_path(self, name):
            return 'sysctl'

        def run_command(self, cmd):
            return 0, ('net.ipv4.tcp_wmem = 4096 87380 16777216\n'
                       'net.ipv4.tcp_rmem = 4096 87380 16777216\n'
                       'net.ipv4.tcp_mem = 786432 1048576 26777216\n'
                       'net.ipv4.tcp_rfc1337 = 0'), ''

    module = MockModule()

    sysctl = get_sysctl(module, ['net.ipv4.tcp_wmem'])

    assert ('net.ipv4.tcp_wmem' in sysctl)

# Generated at 2022-06-20 18:45:49.610763
# Unit test for function get_sysctl
def test_get_sysctl():
    test = dict()
    test['vars'] = dict()
    test['vars']['ansible_executable'] = '/usr/bin/ansible'
    test['vars']['systemd'] = dict()
    test['vars']['systemd']['user'] = False
    test['vars']['systemd']['version'] = 229
    test['vars']['systemd']['preset-all'] = dict()
    test['vars']['systemd']['preset-all']['rc'] = 0

# Generated at 2022-06-20 18:46:01.058973
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    sysctl = {}
    sysctl['test.test1'] = '1'
    sysctl['test.test2'] = 'two'
    sysctl['test.test3'] = 'three'
    sysctl['test.test4'] = '4'

    def run_command_find_sysctl(sysctl_cmd, prefixes):
        assert sysctl_cmd == 'sysctl'
        assert prefixes == ['-a']

        lines = []

        for x, y in sysctl.items():
            lines.append('%s = %s' % (x, y))

        return 0, '\n'.join(lines), ''

    module.run_command = run_command_find_sysctl


# Generated at 2022-06-20 18:46:10.923063
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:46:50.420454
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('net.ipv4.conf.all.rp_filter') == '1'
    assert get_sysctl('kernel.hostname') == 'testhostname'
    assert get_sysctl('vm.swappiness') == '60'
    assert get_sysctl('net.ipv4.conf.all.accept_redirects') == '1'
    assert get_sysctl('net.ipv4.conf.all.forwarding') == '0'
    assert get_sysctl('net.ipv4.conf.all.secure_redirects') == '0'
    assert get_sysctl('net.ipv4.conf.all.send_redirects') == '1'


# Generated at 2022-06-20 18:46:59.239695
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    # The keys we want to use.  This is not a test of sysctl,
    # just a test of get_sysctl
    prefixes = [
        'net.ipv4.ip_forward',
        'net.ipv4.ip_nonlocal_bind',
    ]

    results = get_sysctl(module, prefixes)

    assert len(results.keys()) == 2
    assert 'net.ipv4.ip_forward' in results.keys()
    assert 'net.ipv4.ip_nonlocal_bind' in results.keys()

    assert '0' == results['net.ipv4.ip_forward']

# Generated at 2022-06-20 18:47:05.440612
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    sample_sysctl = """
    abc=xyz
    abcd=abcxyz
    123=abc
    123abc=123abc
    """

    sample_expected_dict = {
        "abc" : "xyz",
        "abcd" : "abcxyz",
        "123" : "abc",
        "123abc" : "123abc"
    }

    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    def run_command_mock(module, command):
        """ Run Command Mock """
        return 0, sample_sysctl, ""

    setattr(test_module, 'run_command', run_command_mock)


# Generated at 2022-06-20 18:47:12.207432
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MagicMock()

# Generated at 2022-06-20 18:47:15.617882
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sysctls = get_sysctl(module, ['vm.swappiness'])
    assert sysctls == {'vm.swappiness': '60'}

# Generated at 2022-06-20 18:47:21.409669
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list')))

    mock_sysctl = {
        'net.ipv4.ip_forward': '1',
        'net.ipv4.conf.all.accept_redirects': '0',
    }

    # Test straight copy from mock dictionary
    assert get_sysctl(module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}

    # Test with full sysctl command output

# Generated at 2022-06-20 18:47:32.469745
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [('0', 'net.ipv4.tcp_rmem\nnet.ipv4.tcp_rmem = 4096 12582912 16777216\n', '')]
            self.warn_count = 0

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

        def warn(self, msg):
            self.warn_count += 1

    module = FakeModule()
    sysctl = get_sysctl(module, ['net.ipv4.tcp_rmem'])


# Generated at 2022-06-20 18:47:42.824447
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Find some facts about the system that sysctl can actually return
    rc, out, err = module.run_command([module.get_bin_path('sysctl'), '-a'])
    sysctl_list = [line.split(':')[0].strip() for line in out.splitlines()]

    # Mockup some values
    sysctl_values = dict()
    for var in sysctl_list:
        sysctl_values[var] = var + '_value'

    # Mockup output of sysctl -a
    def my_run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        rc = 0


# Generated at 2022-06-20 18:47:49.423015
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # Test sysctl command output with both spaces and '=',s
    output = ''
    output += 'net.ipv4.ip_forward = 1\n'
    output += 'net.ipv4.conf.default.rp_filter = 1\n'
    output += '\n'
    output += 'net.core.wmem_max = 12582912\n'
    output += 'net.core.rmem_max = 12582912\n'
    output += 'net.core.rmem_default = 3145728\n'
    output += 'net.core.wmem_default = 3145728\n'


# Generated at 2022-06-20 18:47:58.692029
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os

    def run_module(prefixes):
        # create a dummy module for testing
        module = AnsibleModule(
            argument_spec=dict()
        )
        # make sure we are not running with a real sysctl in path
        orig_path = os.environ['PATH']
        os.environ['PATH'] = ''

        try:
            return get_sysctl(module, prefixes)
        finally:
            os.environ['PATH'] = orig_path

    # Test nominal cases
    sysctl = run_module(["kernel.memsize"])
    assert sysctl == {"kernel.memsize": "524288"}

    sysctl = run_module(["kern.posix1version"])

# Generated at 2022-06-20 18:49:27.391779
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    module.params = dict(prefixes=['net.ipv4.ip_forward', 'net.ipv4.conf.all.forwarding'])
    result = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.all.forwarding'])
    assert result['net.ipv4.ip_forward'] == result['net.ipv4.conf.all.forwarding']

# Generated at 2022-06-20 18:49:37.469803
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile
    import os

    tmp_fd, tmp_name = tempfile.mkstemp()

# Generated at 2022-06-20 18:49:43.608228
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(
        prefixes=dict(type='list', required=True),
    ))


# Generated at 2022-06-20 18:49:53.225617
# Unit test for function get_sysctl
def test_get_sysctl():
    import json
    import shutil
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    with tempfile.NamedTemporaryFile(delete=True) as tmpf:
        # Make sure the tempfile is gone
        tmpf.close()
        shutil.copyfile('/etc/sysctl.conf', tmpf.name)

        # The following test is used to ensure that get_sysctl reads
        # multiple lines from the sysctl output. 'net.core.somaxconn'
        # has a value that is broken up into 2 lines.
        data = '''
kernel.panic = 60
net.core.somaxconn = 128

net.core.somaxconn_low =
    1024
net.core.somaxconn_verylow =
    128
'''


# Generated at 2022-06-20 18:50:04.233464
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    def run_module():
        module_args = dict(
            prefixes=dict(type='list', required=True),
        )

        module = AnsibleModule(
            argument_spec=module_args,
        )
        rc = get_sysctl(module, module.params['prefixes'])
        return rc

    # Check the normal case

    result = run_module()
    assert result['net.ipv4.tcp_fin_timeout'] == '15'
    assert result['net.ipv4.tcp_sack'] == '1'

    # Check the error case

    result = run_module()
    assert result['net.ipv4.tcp_fin_timeout'] == '15'

# Generated at 2022-06-20 18:50:08.074167
# Unit test for function get_sysctl
def test_get_sysctl():
    '''Test sysctl output parsing'''

# Generated at 2022-06-20 18:50:10.430968
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = ['vm.overcommit_memory']
    output = "vm.overcommit_memory = 0"
    sysctl = get_sysctl(module, prefixes)
    assert sysctl.get("vm.overcommit_memory") == "0"

# Generated at 2022-06-20 18:50:15.728038
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.facts.system.sysctl import get_sysctl

    module = AnsibleModule()

    sysctl_cmd = module.get_bin_path('sysctl')

    module.run_command = lambda cmd, **kwargs: (0, '''
dev.mac_hid.mousemoved = 0
hw.physmem = 4294967296
hw.usermem = 4027838464
hw.ncpu = 1
hw.byteorder = 1234
hw.pagesize = 65536
hw.vectorunit = 0
hw.optional.floatingpoint = 1
''', '')

    result = get_sysctl(module, [])


# Generated at 2022-06-20 18:50:25.392787
# Unit test for function get_sysctl
def test_get_sysctl():
    import re
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path(self, arg, *args, **kwargs):
        return arg

    setattr(AnsibleModule, "get_bin_path", get_bin_path)

    module = AnsibleModule(
        argument_spec=[],
        supports_check_mode=True,
    )


# Generated at 2022-06-20 18:50:35.424328
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd, data=None: (0, "net.ipv4.forwarding = 1", None)
    sysctl = get_sysctl(module, ['net.ipv4.forwarding'])
    assert sysctl == dict(net=dict(ipv4=dict(forwarding='1')))
    module.run_command = lambda cmd, data=None: (0, "net.ipv4.forwarding = 0", None)
    sysctl = get_sysctl(module, ['net.ipv4.forwarding'])
    assert sysctl == dict(net=dict(ipv4=dict(forwarding='0')))