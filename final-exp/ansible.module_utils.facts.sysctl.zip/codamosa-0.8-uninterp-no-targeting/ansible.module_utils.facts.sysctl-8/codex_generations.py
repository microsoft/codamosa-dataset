

# Generated at 2022-06-20 18:40:56.347670
# Unit test for function get_sysctl
def test_get_sysctl():
    class module():
        def get_bin_path(self, cmd):
            return '/bin/'+cmd
        def run_command(self, cmd):
            out = 'kernel.hostname: foo.bar\nkernel.sem = 250  32000 100 128'
            return 0, out, ''
        def warn(self, msg):
            return
    m = module()

    ret = get_sysctl(m, ['kernel.hostname', 'kernel.sem'])
    assert ret['kernel.hostname'] == 'foo.bar'
    assert ret['kernel.sem'] == '250  32000 100 128'

# Generated at 2022-06-20 18:40:59.641976
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    result = get_sysctl(module, ['kernel.hostname'])
    assert result['kernel.hostname'] == 'localhost'

# Generated at 2022-06-20 18:41:07.784724
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ('net.ipv4.tcp_congestion_control'))
    assert sysctl['net.ipv4.tcp_congestion_control'] == 'reno'

#
# Fake module for testing get_sysctl
#

# configure required arguments, these will be set by the AnsibleModule object
FAKE_REQUIRED_ARGUMENTS = [
    '_ansible_sysctl_prefix'
]

# This is required to maintain backwards compatibility with Ansible < 2.0
FAKE_PARAMETERS = {}

# AnsibleModule object that can be used to create and run fake ansible modules

# Generated at 2022-06-20 18:41:11.104291
# Unit test for function get_sysctl
def test_get_sysctl():
    # Basic run to make sure it doesn't explode
    get_sysctl(dict(command='/bin/true'), 'net.ipv4.conf.all.forwarding')



# Generated at 2022-06-20 18:41:19.903312
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    kern_shmall = get_sysctl(module, ['kern.shmall'])
    assert kern_shmall['kern.shmall'] == '16777216'

    kern_shmall = get_sysctl(module, ['kern.shmall', 'kern.shmmax'])
    assert kern_shmall['kern.shmall'] == '16777216'
    assert kern_shmall['kern.shmmax'] == '67108864'



# Generated at 2022-06-20 18:41:28.797562
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type(str('test'), (object,), {'run_command': run_command, 'warn': warn})

# Generated at 2022-06-20 18:41:40.092108
# Unit test for function get_sysctl
def test_get_sysctl():
    module = object()
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: ([0, 'kernel.ostype: Linux\n'
                                          'kernel.osrelease: 3.2.0-4-amd64\n'
                                          'kernel.name: Linux\n'
                                          'kernel.version: #1 SMP Debian 3.2.63-2+deb7u2 x86_64\n'
                                          'kernel.hostname: nginx1'],
                                    '', '')


# Generated at 2022-06-20 18:41:48.100714
# Unit test for function get_sysctl
def test_get_sysctl():
    import mock
    import sys
    import __builtin__ as builtins
    import copy

    # Mock the module
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.warn = mock.MagicMock()
    module.warn.return_value = None
    module.run_command = mock.MagicMock()
    retval = (0, 'net.ipv4.conf.all.accept_source_route = 0\nnet.ipv4.conf.all.accept_redirects = 0\nnet.ipv4.conf.all.secure_redirects = 0\n', '')
    module.run_command.return_value = retval

    # Mock the input argument

# Generated at 2022-06-20 18:41:51.785727
# Unit test for function get_sysctl
def test_get_sysctl():
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, [])
    assert sysctl is not None
    assert 'kernel.version' in sysctl

# Generated at 2022-06-20 18:41:53.763806
# Unit test for function get_sysctl
def test_get_sysctl():
    x = get_sysctl(None, ['vm.swappiness'])
    assert 'vm.swappiness' in x


# Generated at 2022-06-20 18:42:08.198937
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={
        'prefixes': dict(type='list', required=True),
    })


# Generated at 2022-06-20 18:42:17.520522
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import EnvironmentDict
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sysctl = get_sysctl(module, ['kern', 'ctrl'])
    assert sysctl['kern.ctrl.string'].startswith('string to print on Ctrl+Alt+Delete')
    assert sysctl['kern.ctrl.reboot'] == '1'
    assert sysctl['kern.ctrl.crash'].startswith('string to print on Ctrl+Alt+ESC')
    assert sysctl['kern.ctrl.trap'] == '1'

# Generated at 2022-06-20 18:42:29.335891
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={})
    m.fail_json = lambda msg: msg
    m.debug = lambda msg: msg

    cmd = '''
# This is a comment
kernel.hostname = host.example.com
kernel.domainname = example.com
kernel.ostype = Linux
kernel.osrelease = 4.4.0
kernel.osrevision = 80generic
kernel.version = #24 SMP Sun Apr 10 13:45:15
kernel.version = UTC 2016
kernel.arch = x86_64
kernel.pid_max = 65536

# This is another comment
net.ipv4.tcp_timestamps = 0
net.ipv4.tcp_tw_reuse = 1
'''
    cmd_rc = 0


# Generated at 2022-06-20 18:42:33.906988
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    set_module_args(dict(prefixes=['net.ipv4.conf.default.forwarding']))
    result = get_sysctl(module)
    assert result['net.ipv4.conf.default.forwarding'] == '0'

# Generated at 2022-06-20 18:42:45.653095
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # Create a fake module, to get command locations from it, and to allow
    # calling run_command (which is not normally available in unit tests)
    if sys.version_info < (2, 7):
        module = AnsibleModule(
            argument_spec=dict()
        )
    else:
        module = AnsibleModule
        module.get_bin_path = AnsibleModule.get_bin_path
        module.run_command = AnsibleModule.run_command

    # test 1: get single valid value
    sysctl_output = '''
security.bsd.see_other_uids: 0
'''
    module.run_command = Mock(return_value=(0, sysctl_output, ''))

# Generated at 2022-06-20 18:42:56.824985
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        )
    )

    result = {'prefixes': ['vm.swappiness', 'kernel.pid_max']}
    out = 'vm.swappiness = 1\nkernel.pid_max = 99999'

    prefixes = ['vm.swappiness', 'kernel.pid_max']
    raw = {'rc': 0, 'err': '', 'out': out}
    with patch.object(module, 'run_command', return_value=raw):
        sysctl = get_sysctl(module, prefixes)
        for k in result.keys():
            assert sysctl[k] == result[k]

# Generated at 2022-06-20 18:42:59.619845
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    prefixes = ['vm.overcommit_memory']
    assert get_sysctl(module, prefixes) == {'vm.overcommit_memory': '0'}


# Generated at 2022-06-20 18:43:08.744687
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import re
    import sys

    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Prepend an empty string so that we get the full tree of sysctl
    # parameters. It is necessary to use sys.prefix instead of '' here
    # because of the way Python handles package-relative imports which
    # are used when running unit tests.
    prefixes = [sys.prefix]

    sysctl = get_sysctl(module, prefixes)

    '''
    Verify that at least kernel.printk is in output.
    '''
    if 'kernel.printk' not in sysctl:
        module.fail_json(msg='kernel.printk not in sysctl output')
    # Check that the value looks like what we expect

# Generated at 2022-06-20 18:43:15.183934
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(argument_spec={})
    m.run_command = lambda x: ([0, 'vm.dirty_writeback_centisecs = 1500000', ''], '', '')
    res = get_sysctl(m, ['vm.dirty_writeback_centisecs'])
    assert res['vm.dirty_writeback_centisecs'] == '1500000'

# Generated at 2022-06-20 18:43:21.688289
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Test the get_sysctl function.
    '''
    # Patch ansible module
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec = dict(),
    )
    m.get_bin_path = lambda *args: '/bin/sysctl'
    m.run_command = lambda *args: (0, 'net.inet.ip.forwarding = 1\nnet.inet.ip.redirect = 1', '')

    # Test
    sysctl_out = get_sysctl(m, ['net.inet.ip'])
    assert sysctl_out == {'net.inet.ip.forwarding': '1', 'net.inet.ip.redirect': '1'}

# Generated at 2022-06-20 18:43:41.884506
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import StringIO
    import os
    import tempfile
    import shutil
    from ansible.module_utils import basic

    out = StringIO()
    sysctl_cmd = 'sysctl'
    args = 'kernel.shmmax vm.swappiness'


# Generated at 2022-06-20 18:43:46.003145
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl(dict(), ['kernel.hostname'])
    assert 'kernel.hostname' in sysctl, "kernel.hostname should be in sysctl"
    assert sysctl['kernel.hostname'], "kernel.hostname should have a value"



# Generated at 2022-06-20 18:43:50.787807
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    prefixes = ['vm.swappiness']
    params = get_sysctl(module, prefixes)

    assert params['vm.swappiness'] == '0'

    prefixes = ['net.core.rmem_default', 'net.core.rmem_max']
    params = get_sysctl(module, prefixes)

    assert params['net.core.rmem_default'] == '212992'
    assert params['net.core.rmem_max'] == '212992'

# Generated at 2022-06-20 18:44:01.356196
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import types

    test_module = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(type='list', required=True),
        ),
        supports_check_mode=False
    )

    # Test a known sysctl key
    sysctl = get_sysctl(test_module, ["kernel.pid_max"])

    if sysctl is not None:
        print("Module get_sysctl returned true when it should have returned false")
        return 1

    if isinstance(sysctl, types.DictType):
        print("Module get_sysctl returned a dictionary when it should have returned false")
        return 1


# Generated at 2022-06-20 18:44:02.690900
# Unit test for function get_sysctl
def test_get_sysctl():
    assert 'version' in get_sysctl(None, ['kern.ostype'])

# Generated at 2022-06-20 18:44:08.528748
# Unit test for function get_sysctl
def test_get_sysctl():
    module = get_module(False)
    sysctl = get_sysctl(module, [])
    assert len(sysctl) > 0

    sysctl = get_sysctl(module, ['net.ipv4.route.flush'])
    assert len(sysctl) == 1
    assert sysctl['net.ipv4.route.flush'] == "1"


# Generated at 2022-06-20 18:44:17.083458
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:44:27.253908
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Test get_sysctl with output from sysctl -a
    '''
    bogusmodule = object
    bogusmodule.run_command = lambda a, b, c: (0, MOCK_OUTPUT, None)

    result = get_sysctl(bogusmodule, [])
    assert(result["debug.lowpri_throttle_enabled"] == "0")
    assert(result["hw.busfrequency"] == "12000000")
    assert(result["hw.cachelinesize"] == "64")
    assert(result["hw.l1dcachesize"] == "32768")
    assert(result["hw.l1icachesize"] == "65536")
    assert(result["hw.l2cachesize"] == "262144")


# Generated at 2022-06-20 18:44:31.370788
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net'])
    assert sysctl["net.ipv4.ip_forward"] == "1"

# Generated at 2022-06-20 18:44:42.081497
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.pycompat24 import get_exception_type
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list')))

    prefixes = [
        'vm.overcommit_memory',
        'vm.swappiness'
    ]

    sysctl = dict()

# Generated at 2022-06-20 18:45:08.675137
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:45:12.211340
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    assert get_sysctl(module, []) == {}

# Generated at 2022-06-20 18:45:22.003524
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    # Stub out for unit testing
    def stub_run_command(module, cmd):
        return (0, 'net.ipv4.ip_forward = 1\nnet.ipv4.tcp_syncookies = 1\nvm.swappiness = 0', '')

    module._ansible_module.run_command = stub_run_command

    expected = {
        'net.ipv4.ip_forward': '1',
        'net.ipv4.tcp_syncookies': '1',
        'vm.swappiness': '0'
    }

    result = get_sysctl(module._ansible_module, ['net.ipv4.ip_forward', 'net.ipv4.tcp_syncookies', 'vm.swappiness'])

# Generated at 2022-06-20 18:45:32.659236
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from contextlib import contextmanager

    bin_path = 'bin/'

    @contextmanager
    def get_bin_path_mock(bin_name):
        yield bin_path

    empty_sysctl_out = '''
'''

    populated_sysctl_out = '''
kernel.domainname = ansible.com
kernel.hostname = test_host
'''

    module = basic.AnsibleModule(
        argument_spec=dict(
        )
    )

    target_sysctl = dict()

    test_sysctl = get_sysctl(module, [])
    assert(test_sysctl == target_sysctl)

    module.run_command = lambda command: (0, populated_sysctl_out, '')

# Generated at 2022-06-20 18:45:38.754419
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import sys
    # We need to find the directory ansible is running in to find the test data
    # This is not perfect, but should work.  If it fails, it may mean that the
    # tests are being run somewhere else
    ans_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
    test_data = os.path.join(ans_path, 'test/units/module_utils/data')
    sys.path.insert(0, ans_path)
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    # Create a fake module for testing
    fake_module = AnsibleModule(
        argument_spec=dict()
    )

# Generated at 2022-06-20 18:45:49.749853
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible_collections.community.general.tests.unit.compat.mock import patch

    module = AnsibleModule({})

    # test basic return
    with patch.object(AnsibleModule, 'run_command', return_value=(0, "vm.shmmax = 4294967295\nvm.shmall = 268435456", '')):
        assert get_sysctl(module, ['vm.shmmax', 'vm.shmall']) == {'vm.shmmax': '4294967295', 'vm.shmall': '268435456'}

    # test empty return

# Generated at 2022-06-20 18:45:55.768756
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({'run_command': run_command}, []) == {}

    assert get_sysctl({'run_command': run_command}, ['fs']) == {'fs': '\nfile-max'}

    assert get_sysctl({'run_command': run_command}, ['fs', 'file-max']) == {'fs.file-max': '64'}

# Support unit test function

# Generated at 2022-06-20 18:46:06.832637
# Unit test for function get_sysctl
def test_get_sysctl():
    # First off, test if we can get net.ipv4.icmp_echo_ignore_all. This one should be
    # there on all systems.
    sysctl = get_sysctl(sysctl_prefixes=['net.ipv4.icmp_echo_ignore_all'])
    assert sysctl == {'net.ipv4.icmp_echo_ignore_all': '0'}

    # Test if we can get net.ipv4.conf.all.secure_redirects. This one is present on
    # all systems but is not set on all.
    sysctl = get_sysctl(sysctl_prefixes=['net.ipv4.conf.all.secure_redirects'])

# Generated at 2022-06-20 18:46:12.145182
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (object,), {})
    module.get_bin_path = lambda *args: '/sbin/sysctl'
    module.warn = lambda *args: None
    module.set_fact = lambda *args: None
    module.run_command = lambda cmd: (0, '/proc/sys/kernel/hostname\nhostname = foo.example.com\n', None)
    assert get_sysctl(module, ['-a']) == dict(hostname='foo.example.com')



# Generated at 2022-06-20 18:46:22.144578
# Unit test for function get_sysctl
def test_get_sysctl():

    import ansible.module_utils.basic
    import ansible.module_utils.six.moves

    module = ansible.module_utils.basic.AnsibleModule({}, {})
    module.run_command = lambda cmd: (0, 'net.ipv4.conf.all.forwarding = 0\nnet.ipv4.conf.all.mc_forwarding = 0\nnet.ipv4.ip_forward = 0\nnet.ipv4.ip_forward_use_pmtu = 0\nnet.ipv4.ip_local_port_range = 32768    61000\nnet.ipv6.conf.default.forwarding = 0\nnet.ipv6.conf.all.forwarding = 0\nnet.ipv6.conf.all.mc_forwarding = 0\n', '')

# Generated at 2022-06-20 18:47:06.429677
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import os

    # Read in mock data from test file
    with open(os.path.join(os.path.dirname(__file__), 'sysctl.txt'), 'rb') as f:
        test_data = f.read()

    # Mock module input parameters
    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = lambda x: (0, test_data, '')

    # Run get_sysctl against mock data
    res = get_sysctl(module, ['net.ipv6'])

    # Assert if the function worked

# Generated at 2022-06-20 18:47:17.607409
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, sysctl):
            return '/sbin/sysctl'

        def fail_json(self, keys, msg):
            assert isinstance(msg, str)
            for key in keys:
                self.params[key]

        def run_command(self, cmd, check_rc=False):
            assert isinstance(cmd, list)
            out = ''
            if self.params['_out'] == 'error':
                return 1, '', 'Test error'

# Generated at 2022-06-20 18:47:29.280011
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    module_args = {}
    prefixes = []

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        mutually_exclusive=[],
        required_together=[]
    )
    module.connection = Connection(module._socket_path)

    # This should return a dict with at least some values as it is
    # vary platform/kernel specific.
    result = get_sysctl(module, prefixes)
    assert isinstance(result, dict)
    assert len(result) > 0

    # This will return an empty dict with no prefixes.
    result = get_sysctl(module, [])
    assert isinstance(result, dict)

# Generated at 2022-06-20 18:47:38.074003
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    sysctl_module = AnsibleModule(
        argument_spec={
            'prefixes': dict(type='list')
        }
    )

    sysctl = get_sysctl(sysctl_module, sysctl_module.params['prefixes'])

    if sysctl_module.params['prefixes'][0] not in sysctl:
        sysctl_module.fail_json(msg='Could not get sysctl for %s' % sysctl_module.params['prefixes'][0])

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:47:44.310377
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    key1 = 'net.ipv4.conf.all.forwarding'
    key2 = 'net.ipv4.conf.all.accept_redirects'
    value1 = '1'
    value2 = '0'
    prefix = ['net.ipv4.conf.all']
    sysctl = get_sysctl(module, prefix)
    assert sysctl[key1] == value1
    assert sysctl[key2] == value2


# Generated at 2022-06-20 18:47:47.857335
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (object,), {})()
    module.run_command = lambda command: (0, 'net.ipv4.ip_forward: 1', '')
    assert get_sysctl(module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-20 18:47:55.997441
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    result = get_sysctl(module, ['-a'])
    assert len(result) > 0
    assert 'kernel.osrelease' in result

# The code below is needed for the unit tests
# Note that to run the unit tests you will need to execute:
# $ ansible-test units --python-version 3.5 --coverage lib/ansible/module_utils/facts/system/bsd.py

try:
    import json
except ImportError:
    import simplejson as json



# Generated at 2022-06-20 18:48:05.963227
# Unit test for function get_sysctl
def test_get_sysctl():
    """Test the get_sysctl function with a variety of prefixes

    """
    import sys
    import inspect

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        """A fake ansible module"""

        def __init__(self, module_name):
            self.name = module_name
            self.params = {}
            self.log = []

        def run_command(self, cmd):
            return 0, '\n'.join(self.log), ''

        def get_bin_path(self, cmd, required=True):
            return '/bin/echo'

        def warn(self, msg):
            self.log.append(msg)

    # This is the place to put your tests. The function get_sysctl is the main
    # function to test.

    # get the source

# Generated at 2022-06-20 18:48:11.071457
# Unit test for function get_sysctl
def test_get_sysctl():
    module = get_module(dict(ANSIBLE_MODULE_ARGS={}))

    prefixes = ['kern.boottime']

    # The return code is not checked, so this will always return successfully
    assert get_sysctl(module, prefixes) == {
        'kern.boottime': 'Tue Jul  5 09:06:49 2016  -1.867156854 seconds'
    }

    # There is no kern.boottime2, so this will return nothing
    prefixes = ['kern.boottime2']

    assert get_sysctl(module, prefixes) == {}

# Import common test code for unit testing
from ansible.module_utils.basic import *
from ansible.module_utils.shell import *
from ansible.module_utils.six import PY2


# Generated at 2022-06-20 18:48:17.236867
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockAnsibleModule()
    prefixes = ['kernel.hostname', 'net.core']
    sysctl = get_sysctl(module, prefixes)

    assert len(sysctl) == 3
    assert sysctl.get('kernel.hostname') == 'hostname'
    assert sysctl.get('net.core.netdev_max_backlog') == '300'
    assert sysctl.get('net.core.rmem_max') == '524288'



# Generated at 2022-06-20 18:49:17.509334
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # empty sysctl output
    module.run_command = lambda *args, **kwargs: (0, '', '')
    assert get_sysctl(module, []) == {}

    # sysctl output with three prefixes
    module.run_command = lambda *args, **kwargs: (0, 'kernel.randomize_va_space = 2\n'
                                                       'net.ipv4.ip_forward = 1\n'
                                                       'net.ipv4.tcp_syncookies = 1\n', '')

# Generated at 2022-06-20 18:49:25.200199
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat24

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
    )

    rc = 0
    out = """
kernel.hostname = vagrant-ubuntu-trusty-64
net.ipv4.ip_forward = 1
net.ipv4.conf.all.send_redirects = 1
net.ipv4.conf.default.send_redirects = 1
fs.file-max = 65535
""".strip()
    err = ""
    test_run_command = lambda module, cmd: (rc, out, err)
    module.run_command = ansible.module_utils.pycompat24.functools.partial(test_run_command, module)

# Generated at 2022-06-20 18:49:28.547466
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('obj', (), {'run_command': get_sysctl})
    assert get_sysctl(module, ('kern.version',))['kern.version'].startswith('FreeBSD')

# Generated at 2022-06-20 18:49:38.338950
# Unit test for function get_sysctl
def test_get_sysctl():

    # Mock the run_command module
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    sysctl_cmd = '/sbin/sysctl'
    cmd = [sysctl_cmd, '-a']

    sysctl = dict()

# Generated at 2022-06-20 18:49:46.328792
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = {
        'kern.boottime': '{ sec = 644687105, usec = 657502 } Sun Mar  8 18:45:05 2015',
        'kern.hostname': 'localhost.local',
        'kern.maxfilesperproc': '10240',
    }

    assert sysctl == get_sysctl(module, ['kern.boottime', 'kern.hostname', 'kern.maxfilesperproc'])

# Generated at 2022-06-20 18:49:54.534861
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.common.sys_info import get_sysctl
    module = basic.AnsibleModule(
        argument_spec = dict(),
    )
    module._ansible_tmpdir = '/tmp'
    module._ansible_keep_remote_files = False

    (rc, out, err) = module.run_command('mktemp')
    module._ansible_remote_tmp = out.strip()
    module._ansible_remote_tmp += module._ansible_tmpdir
    rc = None
    if not module.selinux_enabled():
        actual = get_sysctl(module, ['kernel.hostname'])
        assert actual['kernel.hostname']

# Generated at 2022-06-20 18:50:00.917394
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=[])
        )
    )

    sysctl = get_sysctl(module, ['-a'])
    assert sysctl

    sysctl = get_sysctl(module, [])
    assert not sysctl



# Generated at 2022-06-20 18:50:10.013331
# Unit test for function get_sysctl
def test_get_sysctl():
    import inspect
    import os
    import sys

    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, os.path.dirname(parentdir))

# Generated at 2022-06-20 18:50:12.154467
# Unit test for function get_sysctl
def test_get_sysctl():
    module = ansible.utils.module_runner.AnsibleModule(argument_spec={})
    res = get_sysctl(module, ['kern.boottime'])
    assert 'kern.boottime' in res

# Generated at 2022-06-20 18:50:14.816385
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['kernel.randomize_va_space']) == {'kernel.randomize_va_space': '1'}