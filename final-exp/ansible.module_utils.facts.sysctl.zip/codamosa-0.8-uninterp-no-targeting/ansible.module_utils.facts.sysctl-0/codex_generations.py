

# Generated at 2022-06-20 18:40:50.855111
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-20 18:40:58.055816
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'ANSIBLE_MODULE_ARGS': {'prefixes': ['kernel.shm*'], 'sysctl_path': '/sbin/sysctl'}})
    requested_params = {'kernel.shmall': 128, 'kernel.shmmax': 1610612736, 'kernel.shmmni': 4096}
    result = get_sysctl(module, module.params['prefixes'])
    assert result == requested_params

# Generated at 2022-06-20 18:41:07.620328
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    module.get_bin_path = lambda prog=None: '/sbin/sysctl'


# Generated at 2022-06-20 18:41:18.948728
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        )

    # Set module functions as needed by get_sysctl

# Generated at 2022-06-20 18:41:28.275867
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:41:35.067109
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = mock.Mock(return_value=(0, 'kernel.hostname = localhost\nnet.ipv4.ip_forward = 1', None))
    result = get_sysctl(module, ['kernel.hostname', 'net.ipv4.ip_forward'])
    assert result['kernel.hostname'] == 'localhost'
    assert result['net.ipv4.ip_forward'] == '1'



# Generated at 2022-06-20 18:41:45.262113
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_output = '''
net.ipv4.ip_forward = 1
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.all.secure_redirects = 1
net.ipv4.conf.default.secure_redirects = 1
net.ipv4.conf.all.log_martians = 0
'''


# Generated at 2022-06-20 18:41:55.244599
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    # No sysctl
    sysctl = get_sysctl(module, ['hw', 'model'])
    assert sysctl == dict(), sysctl
    sysctl = get_sysctl(module, ['net.ipv4', 'icmp_echo_ignore_broadcasts'])
    assert sysctl == dict(), sysctl
    # Found
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl == dict(vm_swappiness='10'), sysctl
    sysctl = get_sysctl(module, ['net.ipv4', 'conf', 'all', 'forwarding'])
    assert sysctl == dict(net_ipv4_conf_all_forwarding='1'), sysctl


# Generated at 2022-06-20 18:42:06.821156
# Unit test for function get_sysctl
def test_get_sysctl():
    class ModuleMock():
        def __init__(self):
            self.fail_json = None
            self.warn = None
            self.params = None
            self.run_command = None

        def fail(self, msg):
            self.fail_json(msg=msg)

        def get_bin_path(self, name, required=True, opt_dirs=[]):
            return name

    class RunCommandMock():
        def __init__(self, retcode, out, err):
            self.retcode = retcode
            self.out = out
            self.err = err

        def __call__(self, cmd):
            return self.retcode, self.out, self.err


# Generated at 2022-06-20 18:42:18.068833
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('AnsibleModule', (object,), {})
    module.fail_json = lambda *args, **kwargs: None
    module.run_command = lambda x: (0, 'dev.cdrom.info_msg: VERBOSE=0\nhw.busclock: 100000000\nhw.acpi.thermal.tz0.temperature: 69.0', '')
    module.warn = lambda x: None
    module.get_bin_path = lambda x: x

    prefixes = ['dev.cdrom.info_msg', 'hw.busclock', 'hw.acpi.thermal.tz0.temperature']
    sysctl = get_sysctl(module, prefixes)


# Generated at 2022-06-20 18:42:25.861509
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule()
    result = get_sysctl(m, prefixes)
    assert result == {'key': 'some value', 'key2': 'some value\nsecond line'}

# Generated at 2022-06-20 18:42:36.120178
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=['net.ipv4.ip_forward', 'net.ipv4.ip_forward']),
        ),
        supports_check_mode=True,
    )
    try:
        res = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.ip_forward'])
    except:
        print("Failed get_sysctl")
    print("is %s" % res['net.ipv4.ip_forward'])
    module.exit_json(changed=False)


if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-20 18:42:47.319973
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test module args
    module = type('obj', (object,), {
        "get_bin_path": dict,
        "run_command": dict,
    })
    sysctl_cmd = '/sbin/sysctl'
    prefixes = ['-a']

    # Test command
    try:
        rc, out, err = module.run_command([sysctl_cmd] + prefixes)
    except (IOError, OSError) as e:
        module.warn('Unable to read sysctl: %s' % to_text(e))
        rc = 1

    # Test output
    assert isinstance(rc, int)
    assert isinstance(out, str) or isinstance(out, bytes)
    assert isinstance(err, str) or isinstance(err, bytes)

    # Test return values

# Generated at 2022-06-20 18:42:52.834251
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl(['dev.cdrom'])
    assert sysctl != {}
    assert 'dev.cdrom' in sysctl

    sysctl = get_sysctl(['kern.boottime'])
    assert sysctl != {}
    assert 'kern.boottime' in sysctl


# Generated at 2022-06-20 18:42:55.905653
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['kern.hostname']) == dict(kern_hostname='/sbin/sysctl: unknown oid \'kern.hostname\'')


# Generated at 2022-06-20 18:43:06.420321
# Unit test for function get_sysctl
def test_get_sysctl():
    import collections

    fake_rc = 0
    fake_out = 'net.ipv4.ip_forward = 0\nnet.ipv4.tcp_syncookies = 1'
    fake_err = ''
    fake_run_command = collections.namedtuple('fake_run_command', 'rc out err')
    fake_run_command.rc = fake_rc
    fake_run_command.out = fake_out
    fake_run_command.err = fake_err
    fake_module = collections.namedtuple('fake_module', 'run_command')
    fake_module.run_command = fake_run_command

    fake_prefixes = ['net.ipv4.ip_forward', 'net.ipv4.tcp_syncookies']

    fake_run_command.rc = 0
    fake_

# Generated at 2022-06-20 18:43:12.603916
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={
        'prefixes': {'type': 'list', 'required': True}
    })

    assert get_sysctl(module, [])
    assert get_sysctl(module, ['vm.nr_hugepages'])
    assert get_sysctl(module, ['missing_node'])

# Generated at 2022-06-20 18:43:19.650427
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    module.run_command = lambda x: (0, "kernel.hostname = test\nkernel.domainname = localdomain\nkernel.osrelease = 2.6.32-573.8.1.el6.x86_64", '')

    result = get_sysctl(module, 'kernel.hostname')

    assert result['kernel.hostname'] == 'test'
    assert result['kernel.domainname'] == 'localdomain'
    assert result['kernel.osrelease'] == '2.6.32-573.8.1.el6.x86_64'

# Generated at 2022-06-20 18:43:24.694832
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    sysctl = get_sysctl(module, [])
    assert len(sysctl) > 0

    # Check that splitting is correctly done
    assert sysctl['kern.ident'] == 'FreeBSD'
    assert sysctl['kern.maxvnodes'] == '0'



# Generated at 2022-06-20 18:43:31.887750
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    mod = basic.AnsibleModule(argument_spec={})
    mod.run_command = lambda cmd: (0, 'kernel\nkern.security.jail.jailed: 0\nuser\nuser.cs_path: /usr/bin:/bin:/usr/sbin:/sbin\n', '')

    sysctl = get_sysctl(mod, ['kernel', 'user'])

    assert sysctl == { 'kernel': '', 'kern.security.jail.jailed': '0', 'user': '', 'user.cs_path': '/usr/bin:/bin:/usr/sbin:/sbin' }


# Generated at 2022-06-20 18:43:44.548002
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.modules.system.get_sysctl as get_sysctl

    module = get_sysctl

    module.get_sysctl = get_sysctl
    results = get_sysctl.__wrapped__(module, prefixes=['debug.foo='])

    assert results == {
        'debug.foo': 'bar'
    }



# Generated at 2022-06-20 18:43:51.035185
# Unit test for function get_sysctl
def test_get_sysctl():
    """Unit test for get_sysctl"""
    from ansible_collections.community.general.tests.unit.compat.mock import create_autospec, patch
    from ansible_collections.community.general.plugins.modules.system import sysctl

    module = sysctl
    module.get_bin_path = create_autospec(module.get_bin_path)
    module.get_bin_path.return_value = 'sysctl'
    module.run_command = create_autospec(module.run_command)
    module.get_bin_path = create_autospec(module.warn)

# Generated at 2022-06-20 18:43:55.193356
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
            argument_spec = dict(
                prefixes = dict(type='list', required=False, default=['kern']),
                arguments = dict(type='str', required=False, default=''),
                ),
            supports_check_mode=True,
            )
    # the module function is not available on import
    module.get_bin_path = get_bin_path
    module.run_command = run_command
    # skip if this will not be supported by the system
    bin_path = module.get_bin_path('sysctl')
    if bin_path:
        # this is what will be mocked by the unittest framework
        sysctl = dict(
            machdep = dict(
                hw_ncpu = '4',
            ),
        )
        # this is the data that

# Generated at 2022-06-20 18:44:03.927068
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    module = basic.AnsibleModule(
        argument_spec = dict(),
    )

    sysctl_cmd = get_bin_path(module, 'sysctl')
    cmd = [sysctl_cmd, to_bytes(''), to_bytes('kernel.threads-max')]
    rc, out, err = module.run_command(cmd)
    assert rc == 0
    assert out.startswith(b'kernel.threads-max = ')
    assert err == b''

    sysctl = get_sysctl(module, [to_bytes(''), to_bytes('kernel.threads-max')])

# Generated at 2022-06-20 18:44:13.186611
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Run unit test for function get_sysctl
    """
    import os

    import ansible.module_utils.basic
    from ansible.module_utils.pycompat24 import get_exception

    from units.mock import patch

    mock_module_args = dict(
        name='net.ipv4.ip_forward',
    )

    # Test for exception if command sysctl is not found
    set_module_args(mock_module_args)

    real_sysctl_cmd = ansible.module_utils.basic.ANSIBLE_MODULE_UTILS['get_bin_path']('sysctl')

    module = get_sysctl_module()
    p = patch.object(ansible.module_utils.basic.ANSIBLE_MODULE_UTILS, 'get_bin_path')

# Generated at 2022-06-20 18:44:15.959995
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )
    assert get_sysctl(module, ['-a'])

# Generated at 2022-06-20 18:44:26.350129
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    results = {'rc': 0, 'stdout': 'kern.boottime: { sec = 1524081011, usec = 916261 }\nkern.bootfile: /mach_kernel', 'stderr': ''}
    module = AnsibleModule(argument_spec={})
    MOCK_MODULE = type('MockModule', (), {})
    setattr(MOCK_MODULE, 'run_command', lambda x: results)
    setattr(MOCK_MODULE, 'get_bin_path', lambda x: x)
    sysctl = get_sysctl(MOCK_MODULE, ['kern.boottime', 'kern.bootfile'])
    assert 'kern.boottime' in sysctl

# Generated at 2022-06-20 18:44:29.106723
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl

    if sysctl.platform == 'FreeBSD' or sysctl.platform.startswith('MacOS'):
        prefixes = ['-n', 'kern.ostype']
        assert sysctl.get_sysctl(sysctl.MockModule(), prefixes) == {'kern.ostype': sysctl.platform}

# Generated at 2022-06-20 18:44:40.113536
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    cmd = module.get_bin_path('sysctl')
    cmd = [cmd, 'vm.swappiness']

    rc, out, err = module.run_command(cmd)
    selected_sysctl = dict()
    result = dict()

    for line in out.splitlines():
        if not line.strip():
            continue

        if line.startswith(' '):
            # handle multiline values, they will not have a starting key
            # Add the newline back in so people can split on it to parse
            # lines if they need to.
            result[key] += '\n' + line
            continue


# Generated at 2022-06-20 18:44:49.069483
# Unit test for function get_sysctl
def test_get_sysctl():
    class TestAnsibleModule:
        def __init__(self):
            self.params = dict()
        def get_bin_path(self, arg):
            return "sysctl"
        def run_command(self, arg):
            out = "net.ipv4.ip_forward = 0\n"
            out += "net.ipv4.conf.default.rp_filter = 1\n"
            out += "net.ipv4.conf.default.accept_source_route = 0\n"
            out += "kernel.sysrq = 0\n"
            out += "kernel.core_uses_pid = 1\n"
            out += "net.ipv4.tcp_syncookies = 1\n"

# Generated at 2022-06-20 18:45:05.413497
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    test_result = dict(
        changed=False,
        rc=0,
        stdout='',
        stderr=''
    )

    # Python 3 has implicit byte-to-string conversion in stdout/stderr.
    # This makes comparing the actual output with that from the module
    # difficult, so we need to encode our expected output as bytes.
    if sys.version_info[0] == 3:
        test_result['stdout'] = test_result['stdout'].encode('utf-8')
        test_result['stderr'] = test_result['stderr'].encode('utf-8')

    def fake_run_command(cmd):
        test_result['rc'] = 0


# Generated at 2022-06-20 18:45:11.277199
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test module args
    module_args = dict(
            prefixes=dict(type='list'),
        )

    # AnsibleModule arguments
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # Need to mock the module.run_command function for this to work
    prefixes = ['net']
    import sysctl
    module.run_command = sysctl.get_sysctl
    module.get_bin_path = lambda x: x

    out = sysctl.get_sysctl(module, prefixes)
    assert isinstance(out, dict)

# Generated at 2022-06-20 18:45:21.028705
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.modules import get_sysctl

    module = unittest.TestCase()

    #####################################
    # Initial values
    cmd = ['sysctl', 'kern.ostype']
    sysctl = dict()

    #####################################
    # Mock and test with the following sysctl output:
    #   kern.ostype = FreeBSD
    #   kern.osrelease = 9.3-RELEASE-p1
    #   kern.osreldate = 1432039019
    #   kern.version = FreeBSD

# Generated at 2022-06-20 18:45:31.451968
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
            argument_spec = dict(),
            supports_check_mode = True
            )
    sysctl = get_sysctl(module, ['-a'])
    assert isinstance(sysctl, dict)
    for key, value in sysctl.items():
        assert isinstance(key, str)
        assert isinstance(value, str)
    for key in [
        'kernel.forkfail',
        'kernel.osrelease',
        'kernel.ostype',
        'kernel.panic_on_oops',
        'kernel.random.boot_id',
        'kernel.random.uuid',
        'kernel.sched_domain.cpu0.groups'
        ]:
        assert key in sysctl



# Generated at 2022-06-20 18:45:38.065781
# Unit test for function get_sysctl
def test_get_sysctl():
    module = get_module_mock()
    cmd = [module.get_bin_path('sysctl'), 'net.ipv4.ip_forward', 'vm.swappiness']

    rc = 0
    out = '\n'.join([
        'net.ipv4.ip_forward = 1',
        'vm.swappiness = 60',
    ])
    err = ''

    module.run_command.return_value = rc, out, err

    sysctl = get_sysctl(module, cmd[1:])

    expected_sysctl = {
        'net.ipv4.ip_forward': '1',
        'vm.swappiness': '60',
    }

    assert sysctl == expected_sysctl


# Generated at 2022-06-20 18:45:39.997347
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl() == "foo"

# Generated at 2022-06-20 18:45:50.326521
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json

    # Test when sysctl call is successful
    sysctl_out = '''
fs.file-max = 589832
fs.inotify.max_user_instances = 128
net.ipv4.route.flush = 1
net.ipv4.route.max_size = 8388608
'''
    sysctl = {
        'fs.file-max': '589832',
        'fs.inotify.max_user_instances': '128',
        'net.ipv4.route.flush': '1',
        'net.ipv4.route.max_size': '8388608',
    }

# Generated at 2022-06-20 18:45:54.820958
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_dict = get_sysctl(['vm.swappiness'])
    assert len(sysctl_dict) == 1
    assert 'vm.swappiness' in sysctl_dict
    assert isinstance(sysctl_dict['vm.swappiness'], str)

# Generated at 2022-06-20 18:46:05.880005
# Unit test for function get_sysctl
def test_get_sysctl():
    module = fake_module()

    sysctl = dict()
    sysctl['kern.hostname'] = 'host-name'
    sysctl['kern.maxproc'] = '2000'
    sysctl['kern.maxprocperuid'] = '200'
    sysctl['kern.securelevel'] = '-1'
    sysctl['kern.fallback_elf_brand'] = '3'
    sysctl['kern.features.inet6'] = '1'
    sysctl['kern.features.inet'] = '1'
    sysctl['kern.features.bpfjit'] = '1'
    sysctl['vm.max_wired'] = '-1'

    module.run_command = lambda cmd: ("%s" % sysctl).split('\n')


# Generated at 2022-06-20 18:46:13.531883
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('Module', (object,), {
        'get_bin_path': lambda self, str: 'sysctl',
        'run_command': lambda self, arr: (0, 'kern.boottime: { sec = 1457644948, usec = 812409 }\nkern.bootfile: /kernel', ''),
        'warn': lambda self, str: print('WARN: %s' % str)
    })()

    # we get this from the module.run_command mock
    dct = {'kern.boottime': '{ sec = 1457644948, usec = 812409 }',
           'kern.bootfile': '/kernel'}

    assert get_sysctl(module, []) == dct
    assert get_sysctl(module, ['does.not.exist']) == dct

# Generated at 2022-06-20 18:46:30.752102
# Unit test for function get_sysctl
def test_get_sysctl():
    # Set up mock module and results
    test_module = type('module', (object,), {'run_command': FakeRunCommand, 'warn': FakeWarn})()
    test_module.get_bin_path = lambda x: 'sysctl'
    test_prefixes = ['kern.maxfiles']
    test_result = get_sysctl(test_module, test_prefixes)
    assert test_result['kern.maxfiles'] == '20480'


# Generated at 2022-06-20 18:46:33.315001
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.modules.system.sysctl import get_sysctl

    assert get_sysctl({}, ['dev.cdrom.info']) == {}



# Generated at 2022-06-20 18:46:41.258991
# Unit test for function get_sysctl
def test_get_sysctl():

    # Test with a single key
    keys = {'kern.hostname': 'localhost.local'}
    out = ""
    for (k, v) in keys.items():
        out += "%s = %s\n" % (k, v)

    test_mock = {
        'run_command.return_value': (0, out, ""),
    }

    result = get_sysctl(test_mock, [])
    assert result == keys

    # Test with multiple keys
    keys = {'kern.hostname': 'localhost.local', 'kern.osrelease': '12.0-RELEASE'}
    out = ""
    for (k, v) in keys.items():
        out += "%s = %s\n" % (k, v)


# Generated at 2022-06-20 18:46:47.535888
# Unit test for function get_sysctl
def test_get_sysctl():
    """Simple test for parsing sysctl output"""

    module = AnsibleModule(
        argument_spec = dict()
    )

    sysctl = get_sysctl(
        module = module,
        prefixes = [
            'kernel.threads-max',
            'kernel.pid_max',
        ]
    )

    assert sysctl['kernel.threads-max'] == '524288'
    assert sysctl['kernel.pid_max'] == '4194303'


# Generated at 2022-06-20 18:46:56.013641
# Unit test for function get_sysctl
def test_get_sysctl():
    # sysctl.py is executed as python module, so it cannot import ansible
    # modules. Ansible modules are imported only during execution of ansible
    # playbooks. To execute unit test, we need to import sysctl.py as separate
    # module, thus we need to recreate get_bin_path function here

    def get_bin_path(name):
        return name

    module = type('FakeModule', (object,),
                  {'get_bin_path': get_bin_path})()

    assert get_sysctl(module, ['fs.pipe-max-size']) == {'fs.pipe-max-size': '1048576'}

# Generated at 2022-06-20 18:47:00.597014
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sysctl = get_sysctl(module, [])
    print(sysctl)



# Generated at 2022-06-20 18:47:07.605077
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    if sys.version_info.major == 2:
        import __builtin__ as builtins
    else:
        import builtins

    class Module:
        def __init__(self):
            self._gather_subset = [
                'min',
                '!config',
                '!facter'
            ]
            self.check_mode = False
            self.file_args = None
            self.argument_spec = None
            self.params = None
            self.module_args = None
            self.fail_json = False
            self.no_log = None
            self.changed = False

        @staticmethod
        def get_bin_path(bin_name):
            if bin_name == 'sysctl':
                return 'sysctl'

        def run_command(self, cmd):
            out

# Generated at 2022-06-20 18:47:17.965624
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': dict()})

# Generated at 2022-06-20 18:47:29.454644
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {
        'run_command': run_command,
        'get_bin_path': get_bin_path,
        'warn': warn,
    })


# Generated at 2022-06-20 18:47:39.917856
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(supports_check_mode=True)

    if not module.check_mode:
        rc, out, err = module.run_command('sysctl -n -e machdep.cpu.brand_string')
        if rc == 0:
            cpu_type = out.strip()
        else:
            cpu_type = 'unknown'

        # Test that we can pass the prefixes in as a list.
        sysctl = get_sysctl(module, ['-n', '-e', 'machdep.cpu.brand_string'])
        assert sysctl['machdep.cpu.brand_string'] == cpu_type



# Generated at 2022-06-20 18:48:17.492463
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        # Suppress the warning about missing required parameters, as
        # they are not needed for this test.
        check_invalid_arguments=False,
    )
    sysctl = get_sysctl(module, ["kern.version"])
    assert sysctl.get("kern.version", "") != ""

# Generated at 2022-06-20 18:48:27.886439
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    def mock_run_command(cmd):
        return 0, '{0} = {1}\n{0}.foo = {2}\n{0}.bar = {3}\n'.format(
                'net.ipv4.tcp_tw_reuse', '0', '1', '0'), ''

    module.run_command = mock_run_command

    sysctl = get_sysctl(module, ['net.ipv4.tcp_tw_reuse'])

    assert sysctl['net.ipv4.tcp_tw_reuse'] == '0'
    assert sysctl['net.ipv4.tcp_tw_reuse.foo'] == '1'

# Generated at 2022-06-20 18:48:35.332574
# Unit test for function get_sysctl
def test_get_sysctl():
    """
        This test should fail if either we can't import the module, or
        if we can't find the sysctl binary
    """
    import ansible.module_utils.basic as basic
    basic._ANSIBLE_ARGS = None
    HAS_SYSCTL = 'sysctl' in basic.ANSIBLE_MODULE_UTILS
    assert HAS_SYSCTL
    assert 'kernel' in get_sysctl(basic, ['kernel']).keys()

# Generated at 2022-06-20 18:48:37.728055
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['kern']
    test_sysctls = get_sysctl({}, prefixes)
    assert len(test_sysctls) != 0

# Generated at 2022-06-20 18:48:43.685114
# Unit test for function get_sysctl
def test_get_sysctl():

    class TestModule(object):
        @staticmethod
        def get_bin_path(name):
            return 'sysctl'

        @staticmethod
        def run_command(args):
            return (0, """fs.file-max = 100000
kernel.core_pattern = /corefiles/core.%h.%e.%p
kernel.core_uses_pid = 1""", None)

    test_module = TestModule()
    prefixes = ['fs*', 'kernel*']
    sysctl = get_sysctl(test_module, prefixes)
    assert sysctl['fs.file-max'] == "100000"
    assert sysctl['kernel.core_pattern'] == "/corefiles/core.%h.%e.%p"
    assert sysctl['kernel.core_uses_pid'] == "1"

# Generated at 2022-06-20 18:48:53.358813
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import platform

    # Add python version-specific mock module to class namespace
    if platform.python_version() > '2.7':
        from unittest.mock import patch, mock_open, MagicMock
    else:
        from mock import patch, mock_open, MagicMock

    # Something for `run_command` to return for testing.
    run_command_out = '''
kernel.osrelease = 2.6.32-573.el6.x86_64
kernel.hostname = el6.x86_64
kernel.ostype = Linux
kernel.osrelease_name = redhat-6.9'''

    # Something for `run_command` to return for testing.
    run_command_err = ''


# Generated at 2022-06-20 18:49:01.888455
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.tcp_mem'])
    assert 'net.ipv4.tcp_mem' in sysctl
    assert 'net.ipv4.tcp_rmem' not in sysctl
    assert 'net.ipv4.tcp_wmem' not in sysctl
    sysctl = get_sysctl(module, ['kernel.random.entropy_avail'])
    assert 'kernel.random.entropy_avail' in sysctl
    assert 'kernel.random.read_wakeup_threshold' not in sysctl
    assert 'kernel.random.write_wakeup_threshold' not in sysctl

from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 18:49:12.014738
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils.shell.sysctl import get_sysctl

    # TODO: Create a proper mock class instead of using a dict
    class AnsibleModuleMock(dict):
        def __init__(self, *args, **kwargs):
            super(AnsibleModuleMock, self).__init__(*args, **kwargs)
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('test')


# Generated at 2022-06-20 18:49:18.041566
# Unit test for function get_sysctl
def test_get_sysctl():

    import os
    import stat

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.bin_dir = None

        def get_bin_path(self, executable, required=True):
            if executable == 'sysctl':
                return os.path.join(self.tmpdir, 'bin', 'sysctl')

        def run_command(self, cmd):
            return 0, cmd, ''

    # Create a fake sysctl binary in a temporary directory
    def make_test_sysctl(tmpdir):
        sysctl_path = os.path.join(tmpdir, 'bin', 'sysctl')
        sysctl_dir = os.path.dirname(sysctl_path)
        sysctl_

# Generated at 2022-06-20 18:49:22.488619
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'vm.overcommit_memory = 2\nkernel.pid_max = 3', '')
    sysctl = get_sysctl(module, ['vm.overcommit_memory'])
    assert sysctl == {'vm.overcommit_memory': '2'}

# Generated at 2022-06-20 18:50:15.547167
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('', 'net.ipv6.conf.all.disable_ipv6'.split()) == {'net.ipv6.conf.all.disable_ipv6': '0'}

# Generated at 2022-06-20 18:50:22.208431
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = {
        'net.ipv4.ip_forward': '1',
        'net.ipv4.conf.default.accept_source_route': '0',
        'net.ipv4.tcp_tw_reuse': '1',
        'kernel.sysrq = 1': '1'
    }
    assert get_sysctl(None, ['net.ipv4.*_source_route', 'kernel.sysrq * 1']) == sysctl

# Generated at 2022-06-20 18:50:32.285058
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, params=None):
            self.params = params


# Generated at 2022-06-20 18:50:39.399906
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.modules import get_sysctl

    module = MagicMock()
    module.run_command.return_value = (0, '', '')

    sysctl = get_sysctl(module, ['sysctl.test.prefix=test_value prefix', 'sysctl.test.prefix.one=test_value_1', 'sysctl.test.prefix.two=test_value_2', 'sysctl.test.prefix.three=test_value_3', 'sysctl.test.prefix.four=test_value_4', 'sysctl.test.prefix.five=test_value_5'])

# Generated at 2022-06-20 18:50:48.241913
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    import platform
    import sys

    if sys.platform.startswith('linux'):
        # example from linux
        module.run_command = lambda x: (0, 'kernel.msgmnb = 65536\nnet.ipv4.tcp_fin_timeout = 60\nnet.ipv4.tcp_keepalive_time = 600\n', None)
        result = get_sysctl(module, ['kernel.msgmnb', 'net.ipv4.tcp_fin_timeout', 'net.ipv4.tcp_keepalive_time'])