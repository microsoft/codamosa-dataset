

# Generated at 2022-06-20 18:40:52.009044
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:41:05.305985
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.modules.system.sysctl import get_sysctl
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    def get_bin_path_mock(name):
        return "/bin/%s" % name


# Generated at 2022-06-20 18:41:17.298378
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ["test.test.test.test=test", "test.test.test.test2=test2", "test.test.test.test3=test3", "test.test.test.test4=test4"]) == {'test.test.test.test': 'test', 'test.test.test.test2': 'test2', 'test.test.test.test3': 'test3', 'test.test.test.test4': 'test4'}

# Generated at 2022-06-20 18:41:27.878105
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_lines = """
net.core.somaxconn = 8192
net.ipv4.tcp_keepalive_time = 7200
net.ipv4.tcp_keepalive_intvl = 75
net.ipv4.tcp_keepalive_probes = 9

net.ipv4.route.flush = 1
user.pw_expire = 0
kernel.randomize_va_space = 2
kernel.sysrq = 0
kernel.core_uses_pid = 1
kernel.shmmax = 4294967295
kernel.shmall = 268435456
"""

# Generated at 2022-06-20 18:41:37.632328
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl = get_sysctl(module, ['kern', 'maxproc'])

    assert sysctl['kern.maxproc'] == '23889'

    sysctl = get_sysctl(module, ['machdep', 'memsize'])

    assert sysctl['machdep.memsize'] == '4294967296'

    sysctl = get_sysctl(module, ['kern', 'net.inet6.ip6.v6only'])

    assert sysctl['kern.net.inet6.ip6.v6only'] == '0'

# Generated at 2022-06-20 18:41:46.542422
# Unit test for function get_sysctl
def test_get_sysctl():
    """ This tests get_sysctl function
    """
    from ansible.modules.system.sysctl import get_sysctl
    import sys

    # Set up fake module object
    class AnsibleModuleFake(object):
        def __init__(self):
            self.params = {}
            self.called = False
            self.check_mode = False
            self.changed = False
            self.exit_args = {}
            self.exit_args['changed'] = False
            self.fail_json_called = False
            self.warnings = []
            self.fail_json_args = {}
        def get_bin_path(self, arg):
            # Fake sysctl path for testing
            return sys.executable

# Generated at 2022-06-20 18:41:54.461021
# Unit test for function get_sysctl
def test_get_sysctl():
    import json
    import ansible.modules.system.sysctl as sysctl
    module = sysctl.AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # Test the function by itself
    prefixes = ['hw.memsize', 'hw.ncpu']

    sysctl = get_sysctl(module, prefixes)

    assert len(sysctl) == 2
    assert 'hw.memsize' in sysctl
    assert 'hw.ncpu' in sysctl
    assert sysctl['hw.memsize'] == '4294967296'
    assert sysctl['hw.ncpu'] == '4'

# Generated at 2022-06-20 18:42:06.427768
# Unit test for function get_sysctl
def test_get_sysctl():
    import os, json, ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
      argument_spec = dict(),
      supports_check_mode = False,
      check_invalid_arguments = False
    )
    # Test call with prefixes on OS-es with a sysctl
    for os_name in ["FreeBSD", "SunOS", "Linux", "AIX"]:
        os.environ['ANSIBLE_SYSTEM_NAME'] = os_name
        sysctl = get_sysctl(m, ["vm.overcommit_memory"])
        assert sysctl
        sysctl = get_sysctl(m, ["vm.overcommit_memory", "vm.overcommit_ratio"])
        assert sysctl
    del os.environ['ANSIBLE_SYSTEM_NAME']

# Generated at 2022-06-20 18:42:13.428531
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sysctl = get_sysctl(module, ['net', 'ipv4'])
    assert sysctl['net.ipv4.tcp_syn_retries'] == '6', \
        'incorrect default value for net.ipv4.tcp_syn_retries'

# Generated at 2022-06-20 18:42:19.651112
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    prefixes = [
        'kernel.version',
        'kernel.ostype',
        'kernel.osrelease',
        'kernel.domainname',
    ]

    sysctl = get_sysctl(module, prefixes)
    assert len(sysctl) == 4
    assert sysctl['kernel.version'] == '#1 SMP Wed Dec 4 00:58:37 PST 2013'

# Generated at 2022-06-20 18:42:34.609217
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    # Arrange
    module = AnsibleModule({}, 'sysctl')
    module.run_command = mock.Mock(return_value=(0, """key1 = value1
key2 = value2
key3 =
    value3a
    value3b
    value3c""", ""))
    expected_sysctl = {'key1': 'value1', 'key2': 'value2', 'key3': """    value3a
    value3b
    value3c"""}

    # Act
    actual_sysctl = get_sysctl(['key1', 'key2', 'key3'])

    # Assert
    assert expected_sysctl == actual_sysctl



# Generated at 2022-06-20 18:42:46.223694
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_mock = {
        'hw.machine': 'i386',
        'hw.memsize': '16777216',
        'hw.model': 'MacBookPro9,2',
    }

    class ModuleMock(object):
        def warn(self, msg):
            return
        def get_bin_path(self, cmd):
            return cmd
        def run_command(self, cmd):
            values = dict()
            if cmd[0] in sysctl_mock:
                values[cmd[0]] = sysctl_mock[cmd[0]]

            if cmd[0] == 'sysctl':
                out = '\n'.join(list(values.keys())) + '\n'

# Generated at 2022-06-20 18:42:58.229440
# Unit test for function get_sysctl
def test_get_sysctl():
    import module_utils.basic

    class TestModule(object):
        def __init__(self, args):
            self.args = args

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd):
            if cmd == ['sysctl', 'kernel.ostype']:
                return 0, 'kernel.ostype = Linux\n', ''
            if cmd == ['sysctl', 'kernel.osrelease', '-C']:
                return 0, '''
kernel.osrelease = 4.1.6
                                    ''', ''
            raise Exception('should not get here')

        def warn(self, msg):
            self.warn_msg = msg

    data = { 'MODULE_ARGS': {}}
    tmp = TestModule(data)

# Generated at 2022-06-20 18:43:08.012105
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule({})
    module.run_command = lambda args: (0, to_bytes('net.ipv4.ip_forward = 0\nnet.ipv4.conf.default.rp_filter = 1\n\nnet.ipv4.conf.all.rp_filter = 1'), None)

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.default.rp_filter'])
    assert sysctl['net.ipv4.ip_forward'] == '0'
    assert sysctl['net.ipv4.conf.default.rp_filter'] == '1'

# Generated at 2022-06-20 18:43:18.268333
# Unit test for function get_sysctl
def test_get_sysctl():
    class MockModule(object):
        def __init__(self, sysctl):
            self.sysctl = sysctl

        def run_command(self, cmd):
            prefixes = cmd[1:]
            sysctl = dict(self.sysctl)
            out = ""
            rv = ""
            for key, value in sysctl.items():
                if any(key.startswith(prefix) for prefix in prefixes):
                    rv += "%s \t %s\n" % (key, value)
            return (0, rv, '')

    sysctl = {'net.ipv4.ip_forward': '0',
        'net.ipv4.conf.all.send_redirects': '0',
        'net.ipv4.conf.default.send_redirects': '0'}


# Generated at 2022-06-20 18:43:18.912255
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-20 18:43:25.055528
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (object,), dict())
    prefixes = ['net.ipv4.ip_forward', 'net.ipv4.tcp_syncookies']
    assert get_sysctl(module, prefixes) == {
        'net.ipv4.ip_forward': '1',
        'net.ipv4.tcp_syncookies': '1',
        }

# Generated at 2022-06-20 18:43:33.179909
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict(prefixes=dict(required=True, type='list')))

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.vvv('Checking for sysctl unit test data in tests/unit/module_utils/test_get_sysctl.yml')
    from ansible.module_utils import basic

# Generated at 2022-06-20 18:43:43.779169
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MagicMock()
    class ModuleResult(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
        def __eq__(self, other):
            return (self.rc == other.rc and
                    self.out == other.out and
                    self.err == other.err)

# Generated at 2022-06-20 18:43:54.803495
# Unit test for function get_sysctl
def test_get_sysctl():
    """Test if get_sysctl is working correctly."""
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule({})

    # TODO: Mocking a lot of stuff in order to be able to run this test
    # together with all the other tests in unit tests. Need to find a better
    # solution.
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    builtins.__dict__['_ansible_module'] = module
    builtins.__dict__['_ansible_version'] = 'test'
    builtins.__dict__['_ansible_module'] = module

# Generated at 2022-06-20 18:44:11.087610
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    module_mock = sys.modules['ansible.module_utils.basic']
    module_mock.run_command = run_command_mock

    module_mock.get_bin_path = lambda x: x

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    result = get_sysctl(module, ['vm.swappiness'])

    assert result['vm.swappiness'] == '0'



# Generated at 2022-06-20 18:44:14.191115
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    sysctl = get_sysctl(module, ['-a'])

    assert sysctl

    assert sysctl.get('kern.maxfiles')

# Generated at 2022-06-20 18:44:24.754463
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    class FakeCollector():
        def __init__(self, module):
            self.data = dict()
            self.data['sysctl'] = dict()
            for key in ['kernel.hostname', 'kernel.osrelease', 'net.ipv4.route.flush']:
                self.data['sysctl'][key] = key

    def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
        if cmd == ['/sbin/sysctl', '-a']:
            rc = 0

# Generated at 2022-06-20 18:44:30.684532
# Unit test for function get_sysctl
def test_get_sysctl():
    test_commands = {'sysctl': '/bin/sysctl'}
    test_sysctl = dict(hw_disknames="ad8 acd0 cd0")

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.run_command = lambda cmd: (0, '\n'.join(['%s: %s' % (k, v) for k, v in test_sysctl.items()]), '')
    module.get_bin_path = lambda name: test_commands.get(name)
    actual_sysctl = get_sysctl(module, ['hw'])
    module.fail_json(msg='Expected %s but got %s' % (test_sysctl, actual_sysctl))

    test

# Generated at 2022-06-20 18:44:41.493752
# Unit test for function get_sysctl
def test_get_sysctl():
    raw_output = '''
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.apparmor.rp_filter = 1
net.ipv4.conf.apparmor.accept_source_route = 0
net.ipv4.conf.apparmor.accept_redirects = 0
'''.strip()

# Generated at 2022-06-20 18:44:50.251377
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:44:57.644406
# Unit test for function get_sysctl
def test_get_sysctl():
    """Unit test for function get_sysctl"""

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list', default=[])))
    sysctl = get_sysctl(module, module.params['prefixes'])

    import pprint
    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(sysctl)


# function main

# Generated at 2022-06-20 18:45:07.703835
# Unit test for function get_sysctl
def test_get_sysctl():
    from collections import namedtuple
    MockModule = namedtuple('MockModule', ['run_command', 'get_bin_path', 'warn'])

    sysctl_out = """kern.maxfiles: 12288
kern.maxfilesperproc: 10240
kern.openfiles: 635
net.inet.ip.portrange.hifirst: 49152
net.inet.ip.portrange.hilast: 65535
net.inet.ip.portrange.first: 1024
net.inet.ip.portrange.last: 4999
net.inet.icmp.icmplim: 200
vm.loadavg: { 0.04 0.00 0.02 }
"""
    def mock_run_command(bin_name, bin_args):
        if bin_args[0] == 'sysctl':
            return

# Generated at 2022-06-20 18:45:13.643242
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.plugins.modules.system.sysctl import get_sysctl, parse_sysctl_cmd

    module = AnsibleModule({})

    sysctl_base = "net.ipv4.tcp_"
    sysctl_var = "tcp_mem"
    sysctl_value = "1 1 2"

    mock_get_bin_path = patch.object(module, "get_bin_path")
    mock_get_bin_path.return_value = "/sbin/sysctl"

    mock_run_command = patch.object(module, "run_command")

# Generated at 2022-06-20 18:45:24.582167
# Unit test for function get_sysctl
def test_get_sysctl():
    module_mock = MockModule()

# Generated at 2022-06-20 18:45:55.594851
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(**kwargs)

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def warn(self, msg):
            pass

        def run_command(self, cmd):
            if cmd[0] != '/usr/bin/sysctl':
                raise OSError(cmd[0] + ' not found in $PATH')
            return 0, sysctl_out, ''

    sysctl_out = '''
    # sysctl output
    kernel.msgmni = 50
    kernel.msgmax = 65536
    kernel.msgmnb = 32768
    '''

    # test if get_sysctl returns a dict of sysctl prefixes and values
    module = Fake

# Generated at 2022-06-20 18:46:02.507547
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {})()
    module.run_command = lambda x: (0, 'hw.ncpu: 1\nhw.ncpu: 2', '')
    module.get_bin_path = lambda x: x
    module.warn = lambda x: x

    result = get_sysctl(module, ['hw'])
    assert 'hw.ncpu' in result
    assert result['hw.ncpu'] == '1\nhw.ncpu: 2'

# Generated at 2022-06-20 18:46:09.189917
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        )
    )

    rc, out, err = module.run_command(['/bin/true'])

    try:
        sysctl_data = get_sysctl(module, module.params['prefixes'])
        sysctl_valid = True
    except:
        sysctl_valid = False

    assert (rc == 0) and out == '' and err == ''
    assert sysctl_valid

# Generated at 2022-06-20 18:46:10.307353
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, []) == {}



# Generated at 2022-06-20 18:46:20.971706
# Unit test for function get_sysctl
def test_get_sysctl():
    class ModuleStub(object):
        @staticmethod
        def get_bin_path(name):
            return name

        @staticmethod
        def run_command(cmd):
            test_data = '''
net.ipv4.conf.all.accept_source_route = 0

# IPv4 source route verification
net.ipv4.conf.all.rp_filter = 1

kernel.panic = 5
kernel.panic_on_oops = 0
kernel.panic_on_unrecovered_nmi = 0
kernel.panic_on_io_nmi = 0
'''
            return (0, test_data, '')

        @staticmethod
        def warn(msg):
            return


# Generated at 2022-06-20 18:46:29.780718
# Unit test for function get_sysctl

# Generated at 2022-06-20 18:46:33.718409
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    get_sysctl(module, ["vm.swappiness"])
    get_sysctl(module, ["vm", "swappiness"])

# Generated at 2022-06-20 18:46:41.547278
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock, MagicMock

    class TestSysctl(unittest.TestCase):
        def setUp(self):
            self.mock_module = MagicMock()
            self.mock_module.get_bin_path.return_value = 'sysctl'
            self.mock_module.run_command.return_value = (0, "net.ipv4.ip_forward = 1\nnet.ipv4.conf.all.rp_filter = 1", "")

        def tearDown(self):
            pass


# Generated at 2022-06-20 18:46:51.515866
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    # Multiline and colon+space, comma and equal+space separated values
    sysctl = get_sysctl(module, ['net.ipv4.conf.all.secure_redirects', 'net.ipv4.conf.all.accept_source_route'])
    assert sysctl['net.ipv4.conf.all.secure_redirects'] == '0\n0'
    assert sysctl['net.ipv4.conf.all.accept_source_route'] == '0'

    # key without value
    module.run_command = lambda x, **kw: (1, '', '')

# Generated at 2022-06-20 18:46:55.554021
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MagicMock()
    module.run_command = Mock(return_value=(0, 'foo = bar\nbar = foo\n', None))
    sysctl = get_sysctl(module, ['foo', 'bar'])
    assert sysctl == {'foo': 'bar', 'bar': 'foo'}


# Generated at 2022-06-20 18:47:47.780563
# Unit test for function get_sysctl
def test_get_sysctl():
    filename = 'sysctl.txt'

    with open(filename) as f:
        output = f.read()

    sysctl = get_sysctl('', ['%s' % filename])

    test_value = '''
aaa.bbb.ccc = "ddd"
eee.fff.ggg = 2
hhh.iii.jjj = 3
'''

    sysctl_test_value = '''
eee.fff.ggg = 2
hhh.iii.jjj = 3
'''

    sysctl_nonexistent_value = '''
kkk.lll.mmm = 4
'''

    assert(output == sysctl['%s' % filename])
    assert(sysctl_test_value == sysctl['%s' % filename])

# Generated at 2022-06-20 18:47:57.637289
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # sysctl -a, with all values replaced with example values

# Generated at 2022-06-20 18:48:01.908408
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': {'type': 'list', 'required': True}})
    sysctl = get_sysctl(module, prefixes=module.params['prefixes'])
    assert isinstance(sysctl, dict)



# Generated at 2022-06-20 18:48:05.806611
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    module.run_command = lambda x: ('', '', '')
    module.warn = lambda x: None

    assert get_sysctl(module, []) == {}

# Generated at 2022-06-20 18:48:06.965788
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['net', 'ipv4']
    assert get_sysctl({'test': 1}, prefixes)

# Generated at 2022-06-20 18:48:09.777102
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl(module, ['fs.file-max'])
    assert sysctl['fs.file-max'] == '6815744'

# Generated at 2022-06-20 18:48:18.990687
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    module.params = {}
    module.get_bin_path = lambda x: x

    # Test for error running sysctl
    module.run_command = lambda x: (1, '', 'error')
    assert get_sysctl(module, ['foo']) == dict()

    # Test for error splitting line
    module.run_command = lambda x: (0, 'foo: bar\nbadkey: baz', '')
    assert get_sysctl(module, ['foo']) == dict()

    # Test for key: value
    module.run_command = lambda x: (0, 'foo: bar\nbar: baz', '')
    assert get_sysctl

# Generated at 2022-06-20 18:48:22.109643
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['vm.swappiness']) == {'vm.swappiness': '0'}
    assert get_sysctl({'run_command': (1, 'a = b', '')}, ['vm.swappiness']) == {}

# Generated at 2022-06-20 18:48:29.837750
# Unit test for function get_sysctl
def test_get_sysctl():
    """
        This module is used to test the get_sysctl function
    """

    module = AnsibleModule(argument_spec=dict())
    prefixes = ['kernel.ostype', 'kern.ipc.maxsockbuf']
    sysctl_cmd = module.get_bin_path('sysctl')
    cmd = [sysctl_cmd]
    cmd.extend(prefixes)

    sysctl = dict()

    try:
        rc, out, err = module.run_command(cmd)
    except (IOError, OSError) as e:
        module.warn('Unable to read sysctl: %s' % to_text(e))
        rc = 1

    if rc == 0:
        key = ''
        value = ''

# Generated at 2022-06-20 18:48:35.158652
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl_vars = get_sysctl(module, ('kern', 'ipc'))
    assert('kern.ipc.maxsockbuf' in sysctl_vars)
    assert(sysctl_vars['kern.ipc.maxsockbuf'] == '2097152')


# Generated at 2022-06-20 18:50:23.102643
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import tempfile
    import shutil
    import os
    sys.path.append('/usr/share/ansible')
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 18:50:33.184112
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ['kernel.keys.root_maxkeys', 'net.ipv4.ip_forward', 'net.ipv4.ip_forward_aggressive'])
    assert 'kernel.keys.root_maxkeys' in sysctl
    assert 'net.ipv4.ip_forward' in sysctl
    assert 'net.ipv4.ip_forward_aggressive' in sysctl
    assert sysctl['kernel.keys.root_maxkeys'] == 0
    assert sysctl['net.ipv4.ip_forward'] == 0
    assert sysctl['net.ipv4.ip_forward_aggressive'] == 0

# This is a test helper function for unit tests of this module.
# It is not intended for use in actual playbooks.

# Generated at 2022-06-20 18:50:39.245856
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils import common_koji

    module = basic.AnsibleModule(
        argument_spec = dict(),
    )
    module.run_command = common_koji.run_command

    assert get_sysctl(module, []) == {}
    assert get_sysctl(module, ['kernel.ostype']) == {'kernel.ostype': 'Linux'}
    assert get_sysctl(module, ['kernel.ostype', 'kernel.sem']) == {'kernel.ostype': 'Linux',
                                                                   'kernel.sem': '250 512000 100 1024'}

