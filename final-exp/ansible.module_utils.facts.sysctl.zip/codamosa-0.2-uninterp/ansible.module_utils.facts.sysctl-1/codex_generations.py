

# Generated at 2022-06-17 01:24:35.524720
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:24:40.675036
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:24:43.295415
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:24:47.026404
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:24:50.626322
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:24:57.642879
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kern.boottime'])
    assert sysctl['kern.boottime'] == '{ sec = 1511375083, usec = 859000 } Sun Nov 12 12:11:23 2017'

# Generated at 2022-06-17 01:25:03.399013
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:08.822104
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:11.827063
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}


# Generated at 2022-06-17 01:25:16.200630
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:25:23.752764
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:29.617659
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:34.917752
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'
    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.dirty_ratio'])
    assert sysctl['vm.swappiness'] == '60'
    assert sysctl['vm.dirty_ratio'] == '20'

# Generated at 2022-06-17 01:25:39.739890
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:25:41.788709
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:53.246011
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 01:25:57.642350
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:26:00.377322
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda x: (0, 'foo = bar\nbar = foo\n', '')
    assert get_sysctl(module, ['foo', 'bar']) == dict(foo='bar', bar='foo')

# Generated at 2022-06-17 01:26:09.736431
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    try:
        sysctl = get_sysctl(module, ['kernel.hostname'])
    except Exception as e:
        module.fail_json(msg=get_exception())

    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:26:14.416760
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern.ostype', 'kern.osrelease'])
    assert sysctl['kern.ostype'] == 'Darwin'
    assert sysctl['kern.osrelease'] == '16.7.0'

# Generated at 2022-06-17 01:26:23.424622
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern.ostype'])
    assert sysctl['kern.ostype'] == 'FreeBSD'

# Generated at 2022-06-17 01:26:26.402032
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:26:28.785482
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:26:32.129803
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:26:34.698343
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert get_sysctl(module, ['vm.swappiness']) == {'vm.swappiness': '0'}

# Generated at 2022-06-17 01:26:40.876762
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-17 01:26:51.380153
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 01:26:56.414810
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'


# Generated at 2022-06-17 01:26:59.778301
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:05.936422
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:20.374212
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:27:23.318416
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:27:25.998802
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:27:28.633348
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:27:32.631385
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:37.186101
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:39.560792
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:27:42.811580
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-17 01:27:51.782584
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.all.forwarding'])
    assert sysctl['net.ipv4.ip_forward'] == '1'
    assert sysctl['net.ipv4.conf.all.forwarding'] == '1'

# Generated at 2022-06-17 01:28:00.003325
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory'])
    assert sysctl['vm.swappiness'] == '60'
    assert sysctl['vm.overcommit_memory'] == '0'

    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory', 'vm.overcommit_ratio'])
    assert sysctl['vm.swappiness'] == '60'
    assert sysctl['vm.overcommit_memory']

# Generated at 2022-06-17 01:28:29.650453
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'


# Generated at 2022-06-17 01:28:32.614270
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:28:35.092026
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:28:39.042935
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:28:44.131877
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:28:54.117499
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-17 01:28:59.777797
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl == {'kernel.hostname': 'localhost'}

# Generated at 2022-06-17 01:29:11.870649
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:29:17.152712
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:29:23.491375
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:29:58.892322
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:30:05.939683
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:30:10.526450
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:30:14.008677
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern.boottime'])

    assert 'kern.boottime' in sysctl
    assert 'sec' in sysctl['kern.boottime']
    assert 'usec' in sysctl['kern.boottime']
    assert 'tv_sec' in sysctl['kern.boottime']
    assert 'tv_usec' in sysctl['kern.boottime']

# Generated at 2022-06-17 01:30:19.204373
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kern.ostype'])
    assert sysctl['kern.ostype'] == 'Darwin'

# Generated at 2022-06-17 01:30:23.079837
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-17 01:30:25.723413
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern.ostype'])
    assert sysctl['kern.ostype'] == 'FreeBSD'

# Generated at 2022-06-17 01:30:28.969274
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:30:31.358481
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:30:34.373482
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:31:26.157010
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:31:28.569692
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:31:35.033528
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:31:38.558985
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    result = get_sysctl(module, ['kernel.hostname'])
    assert result['kernel.hostname'] == 'localhost.localdomain'

# Generated at 2022-06-17 01:31:43.037936
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 01:31:47.984606
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:31:57.407824
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:32:05.702236
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl == {'vm.swappiness': '60'}

    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory'])
    assert sysctl == {'vm.swappiness': '60', 'vm.overcommit_memory': '0'}

    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory', 'vm.overcommit_ratio'])
    assert sysctl == {'vm.swappiness': '60', 'vm.overcommit_memory': '0', 'vm.overcommit_ratio': '50'}

# Generated at 2022-06-17 01:32:10.077603
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-17 01:32:14.557006
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'