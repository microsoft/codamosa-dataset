

# Generated at 2022-06-17 01:24:34.758068
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:24:38.308609
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:24:46.900212
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.default.rp_filter = 1', ''))
    result = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.default.rp_filter'])
    assert result == {'net.ipv4.ip_forward': '1', 'net.ipv4.conf.default.rp_filter': '1'}


# Generated at 2022-06-17 01:24:49.863848
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:24:55.160923
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:24:56.916300
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:24:59.797492
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:25:06.843151
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:14.235675
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:25:16.566406
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kern.version'])
    assert sysctl['kern.version']


# Generated at 2022-06-17 01:25:28.232534
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['-a'])
    assert sysctl
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:25:32.088177
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:37.132674
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:39.193051
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:25:41.343208
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:25:43.728722
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:25:48.161391
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:51.977524
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:25:59.975974
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.all.forwarding'])
    assert sysctl['net.ipv4.ip_forward'] == '1'
    assert sysctl['net.ipv4.conf.all.forwarding'] == '1'

# Generated at 2022-06-17 01:26:06.615156
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:26:31.000504
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:26:34.013272
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:26:36.464936
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:26:41.474646
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.all.forwarding'])
    assert sysctl == {'net.ipv4.ip_forward': '1', 'net.ipv4.conf.all.forwarding': '1'}

# Generated at 2022-06-17 01:26:46.685787
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:26:51.464704
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:26:56.734846
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:26:58.995683
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:27:05.936831
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:13.365849
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda x: (0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.all.forwarding = 1\nnet.ipv4.conf.default.forwarding = 1\nnet.ipv4.conf.lo.forwarding = 1\nnet.ipv4.conf.eth0.forwarding = 1\nnet.ipv4.conf.eth1.forwarding = 1\n', '')
    assert get_sysctl(module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-17 01:28:08.766664
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:28:13.673659
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:28:17.745797
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern.boottime'])
    assert sysctl['kern.boottime']

# Generated at 2022-06-17 01:28:21.826069
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:28:25.009618
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:28:29.438777
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:28:32.778812
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost.localdomain'

# Generated at 2022-06-17 01:28:39.148499
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:28:42.797040
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:28:53.792553
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:29:59.284224
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:30:04.770919
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'


# Generated at 2022-06-17 01:30:13.425155
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'foo = bar\nbar = foo\n', '')
    assert get_sysctl(module, ['foo']) == {'foo': 'bar', 'bar': 'foo'}

    module.run_command = lambda x: (0, 'foo = bar\nbar = foo\n', '')
    assert get_sysctl(module, ['foo', 'bar']) == {'foo': 'bar', 'bar': 'foo'}

    module.run_command = lambda x: (0, 'foo = bar\nbar = foo\n', '')

# Generated at 2022-06-17 01:30:17.225898
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:30:19.641938
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:30:26.765583
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:30:29.558294
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:30:31.227827
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kern.hostname'])
    assert sysctl['kern.hostname'] == 'localhost'

# Generated at 2022-06-17 01:30:42.935490
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:30:47.947459
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:33:24.975658
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:33:28.323577
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:33:37.318693
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    try:
        sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    except Exception as e:
        module.fail_json(msg=get_exception())

    module.exit_json(changed=False, sysctl=sysctl)



# Generated at 2022-06-17 01:33:44.554858
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:33:47.761579
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:33:52.144589
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:33:57.420211
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-17 01:34:04.881341
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

    # Test that we can get a value with a space in it
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost.localdomain'

    # Test that we can get a value with a newline in it
    sysctl = get_sysctl(module, ['kernel.core_pattern'])

# Generated at 2022-06-17 01:34:09.924264
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:34:14.274828
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'