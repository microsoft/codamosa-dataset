

# Generated at 2022-06-17 01:24:38.140381
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-17 01:24:48.853148
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory'])
    assert sysctl['vm.swappiness'] == '60'
    assert sysctl['vm.overcommit_memory'] == '0'

    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory', 'vm.overcommit_ratio'])
    assert sysctl['vm.swappiness'] == '60'
    assert sysctl['vm.overcommit_memory']

# Generated at 2022-06-17 01:24:52.153689
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'foo = bar\nbar = foo\n', '')
    assert get_sysctl(module, []) == {'foo': 'bar', 'bar': 'foo'}
    module.run_command = lambda x: (0, 'foo = bar\nbar = foo\n', '')
    assert get_sysctl(module, ['foo']) == {'foo': 'bar'}
    module.run_command = lambda x: (0, 'foo = bar\nbar = foo\n', '')
    assert get_sysctl(module, ['foo', 'bar']) == {'foo': 'bar', 'bar': 'foo'}
    module.run_

# Generated at 2022-06-17 01:25:03.024913
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 01:25:09.402874
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'prefixes': dict(type='list')})

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:13.826088
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:25:22.504759
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {})()
    module.get_bin_path = lambda x: '/sbin/sysctl'
    module.run_command = lambda x: (0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.default.rp_filter = 1', '')
    module.warn = lambda x: None

    assert get_sysctl(module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}
    assert get_sysctl(module, ['net.ipv4.conf.default.rp_filter']) == {'net.ipv4.conf.default.rp_filter': '1'}

# Generated at 2022-06-17 01:25:28.895110
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:25:33.187315
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:25:44.266222
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 01:25:54.048013
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        ),
        supports_check_mode=True,
    )

    sysctl = get_sysctl(module, module.params['prefixes'])
    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-17 01:25:57.831920
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-17 01:26:01.022006
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-17 01:26:04.204245
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-17 01:26:13.010267
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.all.forwarding = 1\nnet.ipv4.conf.default.forwarding = 1\nnet.ipv4.conf.lo.forwarding = 1\n', ''))
    result = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert result == {'net.ipv4.ip_forward': '1'}


# Generated at 2022-06-17 01:26:21.246049
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'foo = bar\nbar = foo', '')

    assert get_sysctl(module, ['foo']) == {'foo': 'bar'}
    assert get_sysctl(module, ['foo', 'bar']) == {'foo': 'bar', 'bar': 'foo'}
    assert get_sysctl(module, ['foo', 'bar', 'baz']) == {'foo': 'bar', 'bar': 'foo'}

# Generated at 2022-06-17 01:26:31.482737
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:26:35.344333
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:26:40.393635
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:26:49.797212
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.all.forwarding = 1', ''))
    assert get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.all.forwarding']) == {'net.ipv4.ip_forward': '1', 'net.ipv4.conf.all.forwarding': '1'}


# Generated at 2022-06-17 01:26:57.496468
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:27:04.088105
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda x: (0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.all.forwarding = 1', '')
    assert get_sysctl(module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}
    assert get_sysctl(module, ['net.ipv4.conf.all.forwarding']) == {'net.ipv4.conf.all.forwarding': '1'}

# Generated at 2022-06-17 01:27:10.112128
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:20.564677
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 01:27:22.103153
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:27:25.546175
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:28.751874
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:32.758247
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:27:38.268959
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['kern.boottime'])
    assert sysctl['kern.boottime'] == '{ sec = 1488552838, usec = 0 } Thu Mar 2 15:47:18 2017'

# Generated at 2022-06-17 01:27:41.366458
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '0'


# Generated at 2022-06-17 01:27:57.649594
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern.ostype', 'kern.osrelease'])
    assert sysctl['kern.ostype'] == 'Darwin'
    assert sysctl['kern.osrelease'] == '15.6.0'

# Generated at 2022-06-17 01:28:02.610791
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost.localdomain'

# Generated at 2022-06-17 01:28:05.671426
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:28:08.570368
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-17 01:28:14.485865
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:28:17.536597
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:28:21.489242
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl == {'vm.swappiness': '60'}

# Generated at 2022-06-17 01:28:24.173171
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:28:29.061490
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'


# Generated at 2022-06-17 01:28:34.420839
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:28:54.595404
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:28:59.282078
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost.localdomain'


# Generated at 2022-06-17 01:29:04.876028
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['kernel.hostname'])

    assert sysctl['kernel.hostname'] == 'localhost.localdomain'

# Generated at 2022-06-17 01:29:09.605096
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:29:13.163346
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:29:18.695735
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 01:29:24.643734
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['kern.ostype'])
    assert sysctl['kern.ostype'] == 'Darwin'

# Generated at 2022-06-17 01:29:27.597216
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.conf.all.rp_filter'])
    assert sysctl['net.ipv4.conf.all.rp_filter'] == '1'


# Generated at 2022-06-17 01:29:29.661862
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:29:39.956878
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'net.ipv4.ip_forward = 1\nnet.ipv4.conf.default.rp_filter = 1\nnet.ipv4.conf.all.rp_filter = 1', '')

# Generated at 2022-06-17 01:30:26.763711
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:30:29.557550
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:30:32.353024
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:30:35.674293
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:30:41.925721
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-17 01:30:47.874567
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:30:53.981954
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 01:31:00.169328
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:31:07.782564
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:31:11.601894
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:32:55.671665
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl['kernel.hostname'] == 'localhost'

# Generated at 2022-06-17 01:33:03.555297
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

    sysctl = get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory'])
    assert sysctl['vm.swappiness'] == '60'
    assert sysctl['vm.overcommit_memory'] == '0'

# Generated at 2022-06-17 01:33:11.166201
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['kern.boottime'])
    assert sysctl['kern.boottime']

    sysctl = get_sysctl(module, ['kern.boottime', 'kern.hostname'])
    assert sysctl['kern.boottime']
    assert sysctl['kern.hostname']

# Generated at 2022-06-17 01:33:16.293492
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:33:20.774406
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '0'

# Generated at 2022-06-17 01:33:25.446576
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'

# Generated at 2022-06-17 01:33:28.412703
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:33:34.408582
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

# Generated at 2022-06-17 01:33:43.775308
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl['net.ipv4.ip_forward'] == '1'

    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.conf.all.forwarding'])
    assert sysctl['net.ipv4.ip_forward'] == '1'
    assert sysctl['net.ipv4.conf.all.forwarding'] == '1'

# Generated at 2022-06-17 01:33:48.100202
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda x: (0, 'foo = bar\nbar = foo', '')
    assert get_sysctl(module, ['foo']) == {'foo': 'bar'}