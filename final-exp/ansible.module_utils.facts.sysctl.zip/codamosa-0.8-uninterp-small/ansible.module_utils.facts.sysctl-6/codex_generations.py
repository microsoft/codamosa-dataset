

# Generated at 2022-06-24 23:21:36.067871
# Unit test for function get_sysctl
def test_get_sysctl():
    test_case_0()

# vim: ai et ts=4 sw=4

# Generated at 2022-06-24 23:21:36.701682
# Unit test for function get_sysctl

# Generated at 2022-06-24 23:21:41.717252
# Unit test for function get_sysctl
def test_get_sysctl():
    assert callable(get_sysctl), "Function does not exist"

# Generated at 2022-06-24 23:21:49.547609
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = []
    sysctl_cmd = get_sysctl(prefixes)
    for x in sysctl_cmd:
        if str(x).startswith('kernel.boottime'):
            assert 'boottime' in str(x)
        if str(x).startswith('kernel.domainname'):
            assert 'domainname' in str(x)
        if str(x).startswith('kernel.hostname'):
            assert 'hostname' in str(x)
        if str(x).startswith('kernel.osrelease'):
            assert 'osrelease' in str(x)
        if str(x).startswith('kernel.ostype'):
            assert 'ostype' in str(x)

# Generated at 2022-06-24 23:21:52.833485
# Unit test for function get_sysctl
def test_get_sysctl():
    int_1 = 12
    float_1 = -1.3
    var_1 = get_sysctl(int_1, float_1)
    assert var_1 == 12



# Generated at 2022-06-24 23:22:00.142513
# Unit test for function get_sysctl
def test_get_sysctl():
    int_1 = 4294967295
    float_1 = -1058.76
    var_1 = get_sysctl(int_1, float_1)
    assert var_1 == 0xffffffff

    int_2 = 4294967295
    float_2 = -1058.76
    var_2 = get_sysctl(int_2, float_2)
    assert var_2 == 0xffffffff

    int_3 = 4294967295
    float_3 = -1058.76
    var_3 = get_sysctl(int_3, float_3)
    assert var_3 == 0xffffffff

    int_4 = 4294967295
    float_4 = -1058.76
    var_4 = get_sysctl(int_4, float_4)

# Generated at 2022-06-24 23:22:08.329590
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test case 0
    int_0 = 4294967295
    float_0 = -1058.76
    var_0 = get_sysctl(int_0, float_0)
    if var_0 != bool:
        raise Exception("Return value for function get_sysctl does not match for test case 0. Expected %s but received %s" % (bool, var_0))


# Function Name : sysctl_default_check
# Description   : This function checks system sysctl variables against the provided dict of values
#                 and ensures that the values match
#
# Parameters    : name - sysctl key name
#                 value - value to set in sysctl
#                 force - boolean value indicating whether to set even if already set
#                 state - string value indicating state
#                 sysctl_path - path to sysctl
#                 safe - boolean value indicating

# Generated at 2022-06-24 23:22:14.754082
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            prefixes=dict(type='str', required=True)
        )
    )

    prefixes = 'hw.memsize'

    get_sysctl(module, prefixes)

# Generated at 2022-06-24 23:22:17.843252
# Unit test for function get_sysctl
def test_get_sysctl():
    int_1 = 4294967295
    str_1 = 'hw.busfrequency'
    var_1 = get_sysctl(int_1, str_1)
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 23:22:24.001146
# Unit test for function get_sysctl
def test_get_sysctl():
    int_0 = 4294967295
    float_0 = -1058.76
    var_0 = get_sysctl(int_0, float_0)
    if var_0:
        return var_0[0]
    else:
        return False


# Generated at 2022-06-24 23:22:30.234888
# Unit test for function get_sysctl
def test_get_sysctl():
    cmd = get_sysctl
    test_0 = 'Function does not exist'

# Generated at 2022-06-24 23:22:34.693225
# Unit test for function get_sysctl
def test_get_sysctl():
    # Unit test for function get_sysctl
    prefixes = {}
    assert get_sysctl(prefixes) == {'' : ''}
    return str_0


# Generated at 2022-06-24 23:22:39.219151
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.modules.network.system
    import ansible.module_utils.system

    module = ansible.modules.network.system.sysctl
    module.get_bin_path = lambda x: 'sysctl'
    module.run_command = lambda x: (0, '', '')

    assert module.get_sysctl(module, '') == {}

# Generated at 2022-06-24 23:22:41.067711
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = []
    assert None == get_sysctl(test_case_0, prefixes)

# Generated at 2022-06-24 23:22:44.087592
# Unit test for function get_sysctl
def test_get_sysctl():
    # unit test for function get_sysctl
    prefixes = 'kern.maxvnodes'
    module = 'get_sysctl'
    assert get_sysctl(module, prefixes) == None
    return True


# Generated at 2022-06-24 23:22:45.231610
# Unit test for function get_sysctl
def test_get_sysctl():
    str_0 = 'Function does not exist'



# Generated at 2022-06-24 23:22:49.003091
# Unit test for function get_sysctl
def test_get_sysctl():
    with pytest.raises(AnsibleFailJson) as exc: # The exception raised here is AnsibleFailJson not AttributeError
        str_0 = 'Function does not exist'
        current_1 = get_sysctl(str_0)
    assert exc.value.kwargs['msg'] == 'Module function (get_sysctl) does not exist'


# Generated at 2022-06-24 23:22:53.456832
# Unit test for function get_sysctl
def test_get_sysctl():
    print('Testing get_sysctl')

    # Test #0
    print('Test #0')
    test_get_sysctl_0()

# Unit test subroutine for function get_sysctl

# Generated at 2022-06-24 23:22:55.765002
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = MockAnsibleModule()
    sysctl = get_sysctl(test_module, ['vm.swappiness'])
    assert sysctl['vm.swappiness'] == '60'


# Generated at 2022-06-24 23:23:03.482471
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = {
            'prefixes': {'type': 'list', 'required': True},
        },
        supports_check_mode=True
    )

    module.exit_json(**get_sysctl(module, module.params['prefixes']))

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 23:23:18.505495
# Unit test for function get_sysctl
def test_get_sysctl():
    module = ansible.utils.module_functions.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    module._debug = False
    module.check_mode = False
    module.params = {}
    try:
        assert sys.version_info < (3,)
        assert isinstance(test_case_0(), (str, unicode))
        ansible.module_utils.basic.AnsibleModule.get_sysctl(module, 'test_case_0()')
    except (AssertionError, AttributeError) as e:
        pass

# Generated at 2022-06-24 23:23:20.734086
# Unit test for function get_sysctl
def test_get_sysctl():
    test_case_0()



# Generated at 2022-06-24 23:23:24.413886
# Unit test for function get_sysctl
def test_get_sysctl():
    ansible_module = get_module_patcher('system')
    ansible_module.run_command = MagicMock(return_value=('', '', ''))
    result = get_sysctl(ansible_module, ['a'])
    assert result is None


# Generated at 2022-06-24 23:23:25.255953
# Unit test for function get_sysctl
def test_get_sysctl():
    # unit test for function get_sysctl
    pass

# Generated at 2022-06-24 23:23:26.422163
# Unit test for function get_sysctl
def test_get_sysctl():
    assert to_text(test_case_0()) == to_text(str_0)

# Generated at 2022-06-24 23:23:27.192846
# Unit test for function get_sysctl
def test_get_sysctl():

    test_case_0()



# Generated at 2022-06-24 23:23:28.492510
# Unit test for function get_sysctl
def test_get_sysctl():
    assert(str(type(get_sysctl(str_0, str_0))) == "<class 'dict'>")

# Generated at 2022-06-24 23:23:31.724936
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(required=True, type='list'),
        ),
        supports_check_mode=True
    )

    prefixes = module.params['prefixes']

    get_sysctl(module, prefixes)


# Generated at 2022-06-24 23:23:35.085470
# Unit test for function get_sysctl

# Generated at 2022-06-24 23:23:36.477341
# Unit test for function get_sysctl
def test_get_sysctl():
    assert test_case_0() == ''

# generate some tests

# Generated at 2022-06-24 23:23:48.216860
# Unit test for function get_sysctl
def test_get_sysctl():

    assert get_sysctl('int_0', 'float_0') == ('int_0', 'float_0', 1)
    assert get_sysctl('int_0', 'float_0') == ('int_0', 'float_0', 1)
    assert get_sysctl('int_0', 'float_0') == ('int_0', 'float_0', 1)
    assert get_sysctl('int_0', 'float_0') == ('int_0', 'float_0', 1)
    assert get_sysctl('int_0', 'float_0') == ('int_0', 'float_0', 1)
    assert get_sysctl('int_0', 'float_0') == ('int_0', 'float_0', 1)

# Generated at 2022-06-24 23:23:49.428132
# Unit test for function get_sysctl
def test_get_sysctl():
    assert_equal(test_case_0(), None)


# Generated at 2022-06-24 23:23:51.610389
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(5, 10) == 10


# Generated at 2022-06-24 23:23:59.243904
# Unit test for function get_sysctl
def test_get_sysctl():

    # Unit test for get_sysctl
    prefixes = [ 'net.ipv4.ip_forward' ]
    int_0 = 4294967295
    float_0 = -1058.76
    var_0 = get_sysctl(int_0, float_0)

    for key in var_0:
        if key == 'net.ipv4.ip_forward':
            value = var_0[key]
            if value != '0':
                # TODO: This is being left as an exercise for the reader. Please
                # implement your test here.
                assert False

    prefixes = [ 'kernel.pid_max', 'kernel.random.uuid' ]
    int_0 = 4294967295
    float_0 = -1058.76

# Generated at 2022-06-24 23:24:07.366685
# Unit test for function get_sysctl
def test_get_sysctl():

    # Test with args int_0 = 4294967295, float_0 = -1058.76
    int_0 = 4294967295
    float_0 = -1058.76
    var_0 = get_sysctl(int_0, float_0)

    # Check type of var_0, should be <class 'dict'>
    if not isinstance(var_0, dict):
        raise AssertionError("Expected {}, got {}".format(
            '<class \'dict\'>', type(var_0)))


# Generated at 2022-06-24 23:24:09.163594
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(int, float)


# Generated at 2022-06-24 23:24:18.026949
# Unit test for function get_sysctl

# Generated at 2022-06-24 23:24:20.251193
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(int_0, float_0) == var_0



# Generated at 2022-06-24 23:24:22.089184
# Unit test for function get_sysctl
def test_get_sysctl():
    var_0 = get_sysctl(int_0, float_0)
    assert var_0 == str(int_0)+'.'+str(float_0)



# Generated at 2022-06-24 23:24:26.123326
# Unit test for function get_sysctl
def test_get_sysctl():
  try:
      test_case_0()
  except:
      print("Failed test_case_0")


# Generated at 2022-06-24 23:24:41.761408
# Unit test for function get_sysctl
def test_get_sysctl():
    var_0 = get_sysctl(int_0, float_0)

# Generated at 2022-06-24 23:24:43.607699
# Unit test for function get_sysctl
def test_get_sysctl():
    assert test_case_0() == 0

# Generated at 2022-06-24 23:24:49.407900
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl([]) == {}, "Failed"
    assert get_sysctl([1,2,3]) == [1,2,3], "Failed"
    assert get_sysctl([1,"2",3.0,4,[5,6]]) == [1,"2",3.0,4,[5,6]], "Failed"
    print('Success: test_get_sysctl')


# Run the unit tests
test_get_sysctl()


# Generated at 2022-06-24 23:24:57.126835
# Unit test for function get_sysctl
def test_get_sysctl():
    cwd = '/home/vagrant'
    command = 'sysctl'
    module = AnsibleModule(argument_spec=dict(
        param1=dict(type='str', required=True),
        param2=dict(type='int'),
    ))
    param1 = module.params['param1']
    param2 = module.params['param2']

    result = get_sysctl(cwd, command, param1, param2)
    assert result == param1

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:25:02.097705
# Unit test for function get_sysctl
def test_get_sysctl():
    int_0 = 4294967295
    float_0 = -1058.76

    var_0 = get_sysctl(int_0, float_0)

    assert(var_0 == False)

# Generated at 2022-06-24 23:25:04.563344
# Unit test for function get_sysctl
def test_get_sysctl():
    print('Test case 0:')
    test_case_0()



# Generated at 2022-06-24 23:25:09.704764
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(
            
            prefixes = dict(type='list'),
        ),
        supports_check_mode=True
    )

    prefixes = module.params['prefixes']

    # Test case 0 - 0
    test_case_0()


from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-24 23:25:13.261778
# Unit test for function get_sysctl
def test_get_sysctl():
    parameters = {
        'int_value': 5,
        'float_value': 100.3,
    }

    expected_results = {
        'some_key': 'some_value',
        'some_integer': 5,
        'some_float': 100.3
    }

    sysctl = get_sysctl(parameters['int_value'], parameters['float_value'])
    assert sysctl == expected_results

# Generated at 2022-06-24 23:25:18.028058
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes_0 = [
        'user.resource-control.',
        'user.resource-control.',
        'user.resource-control.',
        'user.resource-control.',
        'user.resource-control.',
        'user.resource-control.',
        'user.resource-control.',
        'user.resource-control.',
    ]
    prefixes_1 = [
        'user.name.',
        'user.name.',
        'user.name.',
        'user.info.',
        'user.info.',
        'user.info.',
        'user.info.',
        'user.info.',
    ]

# Generated at 2022-06-24 23:25:25.887630
# Unit test for function get_sysctl
def test_get_sysctl():
    result = get_sysctl(
        module = dict(
            get_bin_path = dict(
                return_value = 'sysctl_cmd'
            )
        ),
        prefixes = 'prefixes'
    )

    assert result['get_bin_path'] == 'sysctl_cmd'
    assert result['prefixes'] == 'prefixes'
    assert result['sysctl_cmd'] == ['sysctl_cmd', 'prefixes']
    assert result['rc'] == ''

# Generated at 2022-06-24 23:26:01.108631
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    unit test for get_sysctl
    '''
    module = AnsibleModule(
        argument_spec = dict(
            int_0=dict(type='int'),
            float_0=dict(type='float'),
        ),
        supports_check_mode=True,
    )

    int_0 = module.params['int_0']
    float_0 = module.params['float_0']

    # initialize return dict
    result = dict(
        changed=False,
        original_message='',
        message=''
    )

    # HANDLE NAMED VARIABLES
    var_0 = get_sysctl(module, int_0, float_0)
    result['var_0'] = var_0

    # during the first check mode no need to make any changes

# Generated at 2022-06-24 23:26:07.685940
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test with int_1 = 1886059093
    int_1 = 1886059093
    # Test with float_1 = -1225.548
    float_1 = -1225.548
    # Test with prefixes_1 = ['/', 'usr']
    prefixes_1 = ['/', 'usr']
    # Test with prefixes_2 = ['vm', 'vm', 'swappin']
    prefixes_2 = ['vm', 'vm', 'swappin']
    # Test with prefixes_3 = ['/', 'usr', 'lib', 'lib', 'python2', 'python2', '7']
    prefixes_3 = ['/', 'usr', 'lib', 'lib', 'python2', 'python2', '7']


# Generated at 2022-06-24 23:26:13.240163
# Unit test for function get_sysctl
def test_get_sysctl():
    int_1 = 4294967295
    float_1 = -1058.76
    func_result = get_sysctl(int_1, float_1)

    # Check if get_sysctl returns a dictionary
    assert isinstance(func_result, dict)

    # Check if the dictionary has these keys
    assert "sysctl" in func_result

    # Check if the dictionary has these values
    assert func_result["sysctl"] == func_result.get("sysctl")

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:26:22.266337
# Unit test for function get_sysctl
def test_get_sysctl():
    int_1 = 0
    float_2 = 3.0
    var_2 = get_sysctl(int_1, float_2)
    assert var_2 == ('____' * int_1 + '%%0%dX' % float_2),\
        '%s' % var_2
    int_0 = 55555
    float_0 = -3.0
    var_0 = get_sysctl(int_0, float_0)
    assert var_0 == ('____' * int_0 + '%%0%dX' % float_0),\
        '%s' % var_0
    int_0 = 14
    float_0 = 6.5
    var_0 = get_sysctl(int_0, float_0)

# Generated at 2022-06-24 23:26:26.537411
# Unit test for function get_sysctl
def test_get_sysctl():
    var_0 = get_sysctl()
    assert isinstance(var_0, dict)
    assert var_0 == {}


if __name__ == '__main__':
    # import pytest
    # pytest.main(['test_get_sysctl.py'])
    unittest.main()

# Generated at 2022-06-24 23:26:27.804730
# Unit test for function get_sysctl
def test_get_sysctl():
    test_case_0()

# Test if all values present in function get_sysctl are testable

# Generated at 2022-06-24 23:26:29.806139
# Unit test for function get_sysctl
def test_get_sysctl():
    int_1 = 4
    float_1 = 4.0
    var_1 = get_sysctl(int_1, float_1)



# Generated at 2022-06-24 23:26:31.673576
# Unit test for function get_sysctl
def test_get_sysctl():
    int_0 = 4294967295
    float_0 = -1058.76
    var_0 = get_sysctl(int_0, float_0)


# Generated at 2022-06-24 23:26:34.440439
# Unit test for function get_sysctl
def test_get_sysctl():
    int_0 = 54
    float_0 = -13.144
    float_1 = 9.99421
    var_0 = get_sysctl(int_0, float_0, float_1)
    assert (var_0 == -5.049311666666665)



# Generated at 2022-06-24 23:26:39.996310
# Unit test for function get_sysctl
def test_get_sysctl():
    int_1 = 8388613
    float_1 = -18.7
    var_1 = get_sysctl(int_1, float_1)
    assert var_1 == (-1058.76, -18.7, 8388613)



# Generated at 2022-06-24 23:27:38.211556
# Unit test for function get_sysctl
def test_get_sysctl():
    assert test_case_0() == get_sysctl(None, None)

# Generated at 2022-06-24 23:27:39.750833
# Unit test for function get_sysctl
def test_get_sysctl():
    int_0 = 4294967295
    float_0 = -1058.76
    var_1 = get_sysctl(int_0, float_0)
    var_0 = puts(format_float(var_1))
    return var_0


# Generated at 2022-06-24 23:27:45.656315
# Unit test for function get_sysctl
def test_get_sysctl():
    print("Test get_sysctl")
    # Call function get_sysctl with arguments
    get_sysctl(module, prefixes)
    # AssertionError: ('This function has not been implemented yet.',)


# Generated at 2022-06-24 23:27:47.232564
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test
    var_0 = get_sysctl("vm.swappiness", "vm.nr_hugepages")
    var_1 = get_sysctl("vm.nr_hugepages", )


# Generated at 2022-06-24 23:27:53.069923
# Unit test for function get_sysctl
def test_get_sysctl():
    # Given
    module_name = 'ansible.module_utils.basic' + ".get_sysctl"
    int_0 = 4294967295
    float_0 = -1058.76

    # When
    var_0 = get_sysctl(int_0, float_0)

    # Then
    assert var_0 is None

# Generated at 2022-06-24 23:27:56.037694
# Unit test for function get_sysctl
def test_get_sysctl():
    assert test_case_0() == int(-1, float(-1058.76, ))

# Generated at 2022-06-24 23:28:05.216672
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    assert module <= ['bin_path:sysctl']
    assert module >= ['bin_path:test']

# Generated at 2022-06-24 23:28:08.250979
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(int_0, float_0) == var_0


# Generated at 2022-06-24 23:28:10.561330
# Unit test for function get_sysctl
def test_get_sysctl():
    int_test_case_0 = 4294967295
    float_test_case_0 = -1058.76
    # You can use this to create test cases to pass in to your function
    var_test_case_0 = get_sysctl(int_test_case_0, float_test_case_0)
    print(var_test_case_0)


test_get_sysctl()

# Generated at 2022-06-24 23:28:17.153579
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    module = AnsibleModule(
        argument_spec=dict()
    )
    sysctl = get_sysctl(module, prefixes)

if __name__ == "__main__":
    unit_test()

# Generated at 2022-06-24 23:30:33.828727
# Unit test for function get_sysctl
def test_get_sysctl():
    assert(var_0 == "vm.zone_reclaim_mode = 0")

# Generated at 2022-06-24 23:30:35.177021
# Unit test for function get_sysctl
def test_get_sysctl():
    assert replace_space(get_sysctl(int_0, float_0)) == replace_space(var_0)


# Generated at 2022-06-24 23:30:36.770092
# Unit test for function get_sysctl
def test_get_sysctl():
    var_0 = dict()
    var_0 = get_sysctl(var_0)
    if var_0:
        assert True
    else:
        assert False


# Generated at 2022-06-24 23:30:41.039900
# Unit test for function get_sysctl
def test_get_sysctl():
    var_0 = get_sysctl()


# Generated at 2022-06-24 23:30:43.751406
# Unit test for function get_sysctl
def test_get_sysctl():
    int_0 = 4294967295
    float_0 = -1058.76
    var_0 = get_sysctl(int_0, float_0)
    assert 'error' in var_0


# Generated at 2022-06-24 23:30:50.228305
# Unit test for function get_sysctl
def test_get_sysctl():
    func = get_sysctl(module, prefixes)

    # Check if prefixes is a string
    assert isinstance(prefixes, str)

    # Check if paths is a string
    assert isinstance(paths, str)

    # Check if timeout is a float
    assert isinstance(timeout, float)


# Generated at 2022-06-24 23:30:51.676997
# Unit test for function get_sysctl
def test_get_sysctl():
    cmd = ['sysctl', '-a']
    rc, out, err = module.run_command(cmd)
    assert out
    assert err



# Generated at 2022-06-24 23:30:53.893304
# Unit test for function get_sysctl
def test_get_sysctl():
    assert test_case_0() == var_0

# Generated at 2022-06-24 23:31:04.381845
# Unit test for function get_sysctl
def test_get_sysctl():
    # Test for an int passed as module arg
    int_1 = 4294967295
    # Test for a float passed as module arg
    float_1 = -1058.76
    var_0 = get_sysctl(module, prefixes)
    assert type(var_0) == dict
    assert var_0['kernel.map_type'] == '2'
    assert var_0['kernel.max_lock_depth'] == '424983'
    assert var_0['kernel.nel_threads'] == '1'
    assert var_0['kernel.version'] == 'CDH2, built 12/21/15, patched 12/21/15, unscheduled'
    assert var_0['kern.ipc.maxpipekva'] == '13369344'

# Generated at 2022-06-24 23:31:11.677618
# Unit test for function get_sysctl
def test_get_sysctl():
    int_0 = 4294967295
    str_0 = 'Zm9vYmFy'
    str_1 = 'hoF3JW5bNU6'
    str_2 = '+toW8J'
    bytes_0 = b'\xe4\x8b\xf2\x94'
    str_3 = 'xuV7pX'
    bytes_1 = b'\xb0\x8f\x95\x9b\xc0\xba\x9e\xb8\xa1\x91\xa7\xbb\xc8\xbd\xbf\xbf'
    str_4 = '-L/g/h.GNyHn'
    str_5 = 'http://192.168.1.1/index.html'
    int_1 = 16