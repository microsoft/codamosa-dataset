

# Generated at 2022-06-11 03:56:58.522341
# Unit test for function get_sysctl
def test_get_sysctl():
    test_module = type('AnsibleModule', (object,), {})
    test_module.run_command = lambda x: (0, 'net.ipv4.tcp_retries2 = 6\nnet.ipv4.tcp_synack_retries = 5\nnet.ipv4.tcp_syn_retries = 5\n', None)
    test_module.warn = lambda x: None
    test_module.get_bin_path = lambda x: '/sbin/sysctl'

    test_sysctl = get_sysctl(test_module, ['net.ipv4.tcp_retries2'])
    assert test_sysctl == {'net.ipv4.tcp_retries2': '6'}

# Generated at 2022-06-11 03:57:08.071963
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    # Create a temporary file to contain the sysctl output
    (test_fd, test_file) = tempfile.mkstemp()
    # Create the sysctl output file
    os.write(test_fd, b"""
net.ipv4.ip_forward = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.ip_local_port_range = 9000 65500
kernel.pty.max = 5120
""")
    os.close(test_fd)
    # Create the test module
    module = AnsibleModule(
        argument_spec=dict()
    )
    # Set some needed attributes
    module.sysctl_path = test_file

# Generated at 2022-06-11 03:57:17.452544
# Unit test for function get_sysctl
def test_get_sysctl():
    mock_module = AnsibleModule({})
    mock_module.get_bin_path = lambda x: x

# Generated at 2022-06-11 03:57:19.566442
# Unit test for function get_sysctl
def test_get_sysctl():
    # Can't unit test this one because it requires running commands
    # pylint: disable=unused-argument
    pass



# Generated at 2022-06-11 03:57:30.454941
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    # Create a test ansible module for function get_sysctl
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Get sysctl tests - passing 2 prefixes
    test_prefixes = ['kern', 'net']
    test_sysctl = get_sysctl(test_module, test_prefixes)

    assert 'kern.version' in test_sysctl
    assert 'net.inet.tcp.recvspace' in test_sysctl
    assert test_sysctl['net.inet.tcp.recvspace'] == '65535'

    # Get sysctl test - passing 1 prefix
    test_prefixes = ['kern']

# Generated at 2022-06-11 03:57:32.562894
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = []
    sysctl = get_sysctl(module, prefixes)

    assert len(sysctl.keys()) > 0

# Generated at 2022-06-11 03:57:41.230997
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule as _AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO

    class AnsibleFailJson(_AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.__dict__.update(kwargs)

        def exit_json(self, *args, **kwargs):
            super(AnsibleFailJson, self).exit_json(*args, **kwargs)

        def fail_json(self, *args, **kwargs):
            super(AnsibleFailJson, self).fail_json(*args, **kwargs)


# Generated at 2022-06-11 03:57:49.628280
# Unit test for function get_sysctl
def test_get_sysctl():
    # module is un-used but required for registering
    class MockModule(object):
        def __init__(self):
            self.sysctl_cmd = 'sysctl'
            self.rc = 0

# Generated at 2022-06-11 03:57:59.349599
# Unit test for function get_sysctl
def test_get_sysctl():

    class FakeModule(object):

        def __init__(self):
            self.params = dict()
            self.results = dict()

        def fail_json(self, **args):
            self.exit_args = args
            self.exit_args['failed'] = True

        def exit_json(self, **args):
            self.exit_args = args
            self.exit_args['failed'] = False

        def get_bin_path(self, *args, **kwargs):
            return '/bin/sysctl'

        def run_command(self, *args, **kwargs):
            return 0, '', ''

# Generated at 2022-06-11 03:58:08.838973
# Unit test for function get_sysctl
def test_get_sysctl():
    import os


# Generated at 2022-06-11 03:58:24.416810
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os

    sysctl_cmd = None
    sysctl_cmd = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    ).get_bin_path('sysctl')
    sysctl_cmd = os.path.realpath(sysctl_cmd)
    print("sysctl_cmd: %s" % sysctl_cmd)

    import ansible.module_utils.basic
    import ansible.module_utils.common.process

    ansible.module_utils.basic.AnsibleModule = AnsibleModule
    ansible.module_utils.common.process.run_command = lambda *args, **kwargs: (0, '', '')

    # ModuleTestCase
    import ansible.module_utils.basic


# Generated at 2022-06-11 03:58:29.024066
# Unit test for function get_sysctl
def test_get_sysctl():

    test_sysctl = get_sysctl(self, ['-b', 'net.ipv4.tcp_rmem'])
    assert test_sysctl == {'net.ipv4.tcp_rmem': '4096        87380   4194304'}


# Generated at 2022-06-11 03:58:37.937745
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'raw_sysctl': 'true'})

    sysctl_output = '''
kernel.pid_max = 4194303
kernel.sched_autogroup_enabled = 0
kernel.sched_child_runs_first = 0
kernel.sched_latency_ns = 20000000
kernel.sched_min_granularity_ns = 3000000
kernel.sched_wakeup_granula\\
    rity_ns = 15000000
kernel.sem = 250  3200032  256
'''


# Generated at 2022-06-11 03:58:48.681371
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(
            prefix = dict(required=True)
        )
    )

    # Create a dict of the 'sysctl -a' output with the key being the sysctl
    # name and value being the sysctl value.
    module.run_command = get_sysctl_a

    # Set module.params for the test.
    module.params = dict(prefix = ['net'])

    # Check that get_sysctl() returns the expected sysctls.

# Generated at 2022-06-11 03:58:50.507187
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_vals = get_sysctl(None, [])
    assert 'kernel.ostype' in sysctl_vals

# Generated at 2022-06-11 03:58:56.278592
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    # Normal path
    sysctl = get_sysctl(module, ['net.ipv4.conf.all.rp_filter'])
    assert sysctl['net.ipv4.conf.all.rp_filter'] == '1'

    # Key not found
    sysctl = get_sysctl(module, ['dummy.not.found'])
    assert sysctl == {}

# Generated at 2022-06-11 03:59:03.329154
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    import ansible.module_utils.basic
    import ansible.module_utils.system.sysctl
    import ansible.module_utils.system.sysctl

    class TestModule(unittest.TestCase):
        def test_get_sysctl(self):
            mod = ansible.module_utils.basic.AnsibleModule(
                argument_spec=dict(),
                supports_check_mode=False
            )

# Generated at 2022-06-11 03:59:12.459674
# Unit test for function get_sysctl
def test_get_sysctl():
    import tempfile

    def test_params(prefixes, expected_lines, expected_sysctl):
        module = MockModule()
        module.run_command = Mock(return_value=(0, expected_lines, ''))
        returned_sysctl = get_sysctl(module, prefixes)
        assert returned_sysctl == expected_sysctl

    # Test with some valid sysctl output
    prefixes = ['vm.swappiness']
    expected_lines = '''
vm.swappiness = 30
'''
    expected_sysctl = {'vm.swappiness': '30'}
    test_params(prefixes, expected_lines, expected_sysctl)

    # Test with some invalid sysctl output
    prefixes = ['vm.swappiness']
    expected_lines = '''
'''
    expected_sysctl = {}
    test

# Generated at 2022-06-11 03:59:15.412068
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    sysctl = get_sysctl(module, ['kern.timecounter.hardware'])

    assert dict(kern='kern.timecounter.hardware') == sysctl

# Generated at 2022-06-11 03:59:19.479658
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    sysctl = get_sysctl(module, ['compat', 'compat.linux'])
    assert sysctl == {
        'compat.linux.osrelease': '2.6.32-573.18.1.el6.x86_64',
    }

# Generated at 2022-06-11 03:59:33.444279
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    sysctl = get_sysctl(module, ['kern.hostuuid', 'kern.randompid'])
    assert sysctl['kern.hostuuid'] == 'E5EACF29-3B5A-5659-D6E8-B5D2898A7F0D'
    assert sysctl['kern.randompid'] == '0'


# Generated at 2022-06-11 03:59:37.336171
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['kernel.hostname', 'fs.inotify.max_user_watches']
    sysctl = get_sysctl(module, prefixes)
    assert sysctl['kernel.hostname'] == 'foo'
    assert sysctl['fs.inotify.max_user_watches'] == '12288'



# Generated at 2022-06-11 03:59:46.925611
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule


    sysctl_out ="""net.ipv4.conf.all.rp_filter: 1
    net.ipv4.conf.default.rp_filter: 1
    net.ipv4.conf.lo.rp_filter: 1
    net.ipv4.conf.noeth0.rp_filter: 1
    """
    sysctl_err = ""


# Generated at 2022-06-11 03:59:56.415269
# Unit test for function get_sysctl
def test_get_sysctl():
    module, prefixes = None, None

    # Expected sysctl output

# Generated at 2022-06-11 04:00:05.363671
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.system import sysctl

    sysctl_cmd = get_bin_path('sysctl')

    if not sysctl_cmd:
        pytest.skip("'sysctl' was not found in path")

    module = basic.AnsibleModule(
        argument_spec={})

    # Get the sysctl output
    sysctl_output = module.run_command(sysctl_cmd)

    # Make sure sysctl ran successfully
    assert sysctl_output[0] == 0

    sysctl_dict = sysctl.get_sysctl(module, [])

    sysctl.get_

# Generated at 2022-06-11 04:00:11.767519
# Unit test for function get_sysctl
def test_get_sysctl():
    expected_result = {
        'debug.debugger_on_panic': '1',
        'debug.kdb.stop_cpus_on_panic': '1'
    }

    module = FakeAnsibleModule(
        query=["debug.debugger_on_panic", "debug.kdb.stop_cpus_on_panic"]
    )

    result = get_sysctl(module, module.params['query'])

    module.exit_json(changed=False, result=result)

    assert result == expected_result


# Generated at 2022-06-11 04:00:20.491077
# Unit test for function get_sysctl
def test_get_sysctl():
    module = _FakeModule()

    # Setup test environment
    current_sysctls = get_sysctl(module, ['kernel'])
    for k, v in current_sysctls.items():
        module.run_command(['sysctl', '-w', '%s=%s' % (to_text(k), to_text(v))])

    # Test sysctl
    test_name = 'kernel.test_key'
    test_value = 'test_value'
    module.run_command(['sysctl', '-w', '%s=%s' % (test_name, test_value)])
    test_sysctl = get_sysctl(module, [test_name])
    assert test_sysctl[test_name] == test_value

    # Cleanup

# Generated at 2022-06-11 04:00:29.148862
# Unit test for function get_sysctl
def test_get_sysctl():

    import os
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sysctl_cmd = module.get_bin_path('sysctl')

    (rc, out, err) = module.run_command([sysctl_cmd, 'kern.version'])
    assert rc == 0
    assert out.strip() == 'kern.version = Darwin Kernel Version 16.7.0: Thu Jun 15 17:36:27 PDT 2017; root:xnu-3789.70.16~2/RELEASE_X86_64'

    (rc, out, err) = module.run_command([sysctl_cmd, '-n', 'kern.version'])
    assert rc == 0

# Generated at 2022-06-11 04:00:33.720567
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    sysctls = get_sysctl(module, ['vm'])
    assert sysctls == {'vm.max_map_count': '65530', 'vm.overcommit_memory': '0', 'vm.dirty_ratio': '10', 'vm.dirty_background_ratio': '5', 'vm.min_free_kbytes': '8192'}


# Generated at 2022-06-11 04:00:42.020119
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 04:01:10.116850
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible import context
    from ansible.cli import CLI
    from ansible.module_utils.basic import AnsibleModule

    context.CLIARGS = CLI.base_parser(
        command_name='ansible-test',
        usage="%prog [options] collection.module",
        desc="create and run tests for an ansible module"
    ).parse_args([])

    module_args = dict()
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-11 04:01:19.016630
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    class FakeModule(object):
        def __init__(self, ansible_module):
            self.ansible_module = ansible_module

        def get_bin_path(self, app):
            return get_bin_path(self.ansible_module, app)

        def run_command(self, cmd):
            return self.ansible_module.run_command(cmd)

        def warn(self, warning):
            self.ansible_module.warn(warning)

    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.warnings = list()

        def warn(self, warning):
            self.warn

# Generated at 2022-06-11 04:01:27.111073
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))


# Generated at 2022-06-11 04:01:32.089672
# Unit test for function get_sysctl
def test_get_sysctl():
    m = AnsibleModule(argument_spec={'keys': dict(type='list', default=['kernel', 'fs'])})
    sysctl = get_sysctl(m, m.params['keys'])
    for key in m.params['keys']:
        assert key in sysctl
        assert sysctl[key] is not None

# Generated at 2022-06-11 04:01:36.913924
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockAnsibleModule()
    assert get_sysctl(module, ['vm', 'swappiness']) == {
                                                      "vm.swappiness": '60',
                                                      }
    assert get_sysctl(module, ['vm', 'swappiness', 'extra_prefix']) == {
                                                                      "vm.swappiness": '60',
                                                                      }

# A mocked AnsibleModule for unit testing

# Generated at 2022-06-11 04:01:40.779188
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, 'foo = bar\n bar = foo', '')
    sysctl = get_sysctl(mock_module, ['foo'])

    assert sysctl == {'foo' : 'bar', 'bar' : 'foo'}

# Generated at 2022-06-11 04:01:47.020516
# Unit test for function get_sysctl
def test_get_sysctl():
    import json

    module = AnsibleModule(argument_spec={'prefixes': {'type': 'list', 'required': True}})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert 1 == sysctl.get('net.ipv4.ip_forward', 0)

    sysctl = get_sysctl(module, ['kernel.hostname', 'net.ipv4.ip_forward'])
    assert 'localhost' == sysctl.get('kernel.hostname', '')
    assert 1 == sysctl.get('net.ipv4.ip_forward', 0)


# Generated at 2022-06-11 04:01:54.618633
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 04:01:57.641453
# Unit test for function get_sysctl
def test_get_sysctl():
    module = get_module_mock()
    sysctl = get_sysctl(module, ['kernel', 'ostype'])
    assert 'kernel.ostype' in sysctl
    assert sysctl['kernel.ostype'] == 'FreeBSD'


# Generated at 2022-06-11 04:02:05.452853
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    import json

    module_args = dict(
        prefixes=['net', 'dev', 'ipv6']
    )
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    result = get_sysctl(module, module.params['prefixes'])
    assert result is not None
    assert isinstance(result, dict)
    assert len(result) > 0

    module.exit_json(changed=False, meta=result)

if __name__ == '__main__':
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 04:02:54.635271
# Unit test for function get_sysctl

# Generated at 2022-06-11 04:03:01.339542
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('test_mod', (object,), {
        'run_command': lambda x, y: (0, '', ''),
        'get_bin_path': lambda x: '',
        'warn': lambda x: None
    })()

    result1 = get_sysctl(module, [])
    result2 = get_sysctl(module, ['vm.overcommit_memory'])
    result3 = get_sysctl(module, ['vm.overcommit_memory', 'vm.laptop_mode'])

    assert result1 == {}
    assert result2 == {'vm.overcommit_memory': '0'}
    assert result3 == {'vm.overcommit_memory': '0', 'vm.laptop_mode': '0'}

# Generated at 2022-06-11 04:03:03.860902
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    sysctl = get_sysctl(module, ['kernel.hostname'])
    assert sysctl == {'kernel.hostname': 'testhost.example.org'}



# Generated at 2022-06-11 04:03:08.411077
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    sysctl = get_sysctl(module, ['-a'])
    # make sure values are strings (ansible)
    for k in sysctl:
        sysctl[k] = to_text(sysctl[k])
    assert sysctl['kernel.printk'] == '4 4 1 7'


# Generated at 2022-06-11 04:03:16.817944
# Unit test for function get_sysctl
def test_get_sysctl():
    # Check when there is no output
    arg = {'run_command': lambda cmd, check_rc=True: (0, '', '')}
    assert get_sysctl(arg, []) == {}

    # Check some output
    arg = {'run_command': lambda cmd, check_rc=True: (0, 'a: 1\nb: 2', '')}
    assert get_sysctl(arg, []) == {'a': '1', 'b': '2'}

    # Check when there is multiline output
    arg = {'run_command': lambda cmd, check_rc=True: (0, 'a: 1\n        b\n        c\nb: 2', '')}
    assert get_sysctl(arg, []) == {'a': '1\nb\nc', 'b': '2'}

   

# Generated at 2022-06-11 04:03:22.765311
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        ),
    )

    sysctl = get_sysctl(module, module.params['prefixes'])
    assert sysctl
    assert 'net.ipv4.ip_local_port_range' in sysctl
    assert 'WARNING: Unsafe sysctl(5) key net.ipv4.ip_local_port_range' in sysctl.get('net.ipv4.ip_local_port_range', '')

# Generated at 2022-06-11 04:03:25.806710
# Unit test for function get_sysctl
def test_get_sysctl():
    module = 'module'
    prefixes = ['-a']
    sysctl = get_sysctl(module, prefixes)
    assert sysctl != {}


# Generated at 2022-06-11 04:03:33.645912
# Unit test for function get_sysctl
def test_get_sysctl():
    test = dict()

    test['bin_path'] = [
        'bin/sysctl'
    ]

    test['run_command'] = [
        ["bin/sysctl", "-a"],
        (0, "kern.bootfile: /boot/kernel/kernel\nnet.inet.icmp.icmplim: 100", "")
    ]

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import _ANSIBLE_ARGS

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        **_ANSIBLE_ARGS
    )

    module.run_command = lambda *args, **kwargs: test['run_command'].pop(0)

# Generated at 2022-06-11 04:03:41.904755
# Unit test for function get_sysctl
def test_get_sysctl():
    # Create a fake module
    class AnsibleModule(object):
        def __init__(self):
            pass

        @staticmethod
        def warn(msg):
            pass

        @staticmethod
        def get_bin_path(name):
            return '/bin/' + name


# Generated at 2022-06-11 04:03:48.441189
# Unit test for function get_sysctl
def test_get_sysctl():
    return {
        'net.ipv4.conf.all.forwarding': '1',
        'net.ipv4.conf.all.mc_forwarding': '0',
        'net.ipv4.conf.default.forwarding': '0',
        'net.ipv4.conf.default.mc_forwarding': '0',
        'net.ipv4.conf.eth0.forwarding': '0',
        'net.ipv4.conf.eth0.mc_forwarding': '0',
        'net.ipv4.conf.lo.forwarding': '0',
        'net.ipv4.conf.lo.mc_forwarding': '0',
    }


# Generated at 2022-06-11 04:05:42.962056
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys

    sys.modules['ansible'] = object()
    exec('''
try:
    from ansible.module_utils.common.network import get_sysctl
except ImportError:
    pass
''', sys.modules['ansible.module_utils.common.network'].__dict__)

    module = sys.modules['ansible.module_utils.common.network']

    sysctl_cmd = '/bin/sysctl'
    module.get_bin_path = lambda arg: arg

    prefixes = ' -b'.split(' ')

    module.run_command = lambda cmd: (0, 'hw.physmem: 2281701376\nhw.ncpu: 2', None)
    res = get_sysctl(module, prefixes)
    assert res['hw.physmem'] == '2281701376'


# Generated at 2022-06-11 04:05:45.780896
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    result = get_sysctl(module, ['kernel.sem'])

    assert isinstance(result, dict)
    assert 'kernel.sem' in result
    assert result['kernel.sem'] == '250   32000   32   128'

# Generated at 2022-06-11 04:05:52.760668
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import get_sysctl

    class TestGetSysctl(unittest.TestCase):

        @patch('ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils.run_command')
        def test_get_sysctl_success(self, run_command_mock):
            run_command_mock.return_value = 0, '''
net.ipv4.ip_forward = 1
net.ipv6.conf.all.disable_ipv6 = 1''',

# Generated at 2022-06-11 04:05:58.272525
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = get_sysctl(
        {
            'debug': True,
            'run_command': lambda *args:
                (0, 'kernel.domainname = localdomain\n', '')
                if args == ('sysctl',)
                else (1, '', 'could not find sysctl')
        },
        []
    )

# Generated at 2022-06-11 04:06:07.173184
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Test getting sysctl values on Linux systems
    '''
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.mock import patch
    import json
    import sys

    if sys.version_info[:2] == (3, 4) and PY3:
        import imp
        import_mock = imp.load_source('ansible.module_utils.pycompat24', 'lib/ansible/module_utils/pycompat24.py')

# Generated at 2022-06-11 04:06:14.453805
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule:
        def __init__(self):
            self.run_command = FakeRunCommand()
            self.get_bin_path = FakeBinPath()

    class FakeRunCommand:
        def __init__(self):
            self.stdout = '''foo.bar = 1
foo.bar.baz = 2
foo.bar2: 3
'''

    class FakeBinPath:
        def __init__(self):
            pass

        def __call__(self, binary):
            return binary

    assert get_sysctl(FakeModule(), ["foo.bar", "foo.bar2"]) == {
        'foo.bar': '1',
        'foo.bar.baz': '2',
        'foo.bar2': '3',
    }

# Generated at 2022-06-11 04:06:18.887570
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.run_command = run_command

    sysctl_dict = get_sysctl(module, ['kern.ostype', 'kern.osrelease'])
    assert sysctl_dict == {u'kern.ostype': u'Darwin', u'kern.osrelease': u'16.4.0'}



# Generated at 2022-06-11 04:06:22.822827
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(
        None,
        ['/sbin/sysctl', 'net.ipv4.ip_local_port_range', 'kernel.sem']) == {
            'kernel.sem': '256 32000 32 1024',
            'net.ipv4.ip_local_port_range': '32768   61000'
        }


# Generated at 2022-06-11 04:06:24.808057
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    For test of get_sysctl function, see the unit tests in test/units/module_utils/system/test_sysctl.py
    '''
    pass

# Generated at 2022-06-11 04:06:30.048871
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl = get_sysctl(module, ['net.ipv6'])
    assert isinstance(sysctl, dict)
    assert 'net.ipv6.conf.all.autoconf' in sysctl.keys()
    assert sysctl['net.ipv6.conf.all.autoconf'] == '0'

