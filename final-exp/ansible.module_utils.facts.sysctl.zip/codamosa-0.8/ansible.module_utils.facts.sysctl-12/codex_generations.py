

# Generated at 2022-06-11 03:56:55.140144
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    forgot_to_replace_this_string

    sample_output = """kernel.hostname = whatever
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.all.accept_source_route = 0
"""

    module = basic.AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=True
    )

    m_run_command = module.run_command
    def run_command(cmd, *args, **kwargs):
        return 0, sample_output, None
    module.run_command = run_command


# Generated at 2022-06-11 03:57:03.055587
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MagicMock()
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    module.warn = warn
    module.run_command = check_output

    assert get_sysctl(module, ['kern.hostname']) == {'kern.hostname': 'localhost'}
    assert get_sysctl(module, ['kern.hostname', 'kern.osrelease']) == {'kern.hostname': 'localhost',
                                                                       'kern.osrelease': '17.7.0'}

# Generated at 2022-06-11 03:57:12.487812
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {})
    prefixes = [
        'net.ipv4.conf.all.accept_redirects',
        'net.ipv4.conf.all.accept_source_route',
        'net.ipv4.conf.all.log_martians',
    ]

    expected_results = {
        'net.ipv4.conf.all.accept_redirects': '0',
        'net.ipv4.conf.all.accept_source_route': '0',
        'net.ipv4.conf.all.log_martians': '0'
    }


# Generated at 2022-06-11 03:57:20.385335
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.common.sysctl import sysctl_defaults


# Generated at 2022-06-11 03:57:23.917194
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = get_sysctl(module, [])
    assert isinstance(result, dict)

# Generated at 2022-06-11 03:57:33.047007
# Unit test for function get_sysctl
def test_get_sysctl():

    class MockModule(object):
        def __init__(self):
            self.check_mode = False

        def get_bin_path(self, cmd, required=False):
            if cmd == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None

        def run_command(self, cmd, check_rc=True):
            self.cmd = cmd
            return 0, '', ''

        def warn(self, arg):
            pass

    m = MockModule()
    assert get_sysctl(m, ['vm', 'swappiness']) == {'vm.swappiness': '0'}
    assert m.cmd == ['/sbin/sysctl', 'vm', 'swappiness']

# Generated at 2022-06-11 03:57:39.830809
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    keys = get_sysctl(module, ['kern.*'])

    assert keys
    assert 'kern.ostype' in keys
    assert 'kern.version' in keys
    assert len([s for s in keys if 'kern.' in s]) > 1

    keys = get_sysctl(module, ['kern.ostype'])
    assert 'kern.ostype' in keys
    assert len(keys) == 1

# Generated at 2022-06-11 03:57:47.495507
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    module = AnsibleModule({}, {}, {})

    if PY3:
        # Python3 specific sysctl
        sysctl = get_sysctl(module, ['vm.max_map_count'])
        assert sysctl == {'vm.max_map_count': '262144'}

        # Special case for this test
        sysctl = get_sysctl(module, ['vm.swappiness'])
        assert sysctl == {'vm.swappiness': '60'}
    else:
        sysctl = get_sysctl(module, ['vm.swappiness'])
        assert sysctl == {'vm.swappiness': '60'}

        # Python2 specific sysctl
        sysctl = get_

# Generated at 2022-06-11 03:57:53.516604
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='list', default=['kern.boottime'])
    ))

    keys = module.params.get('name')
    assert module.get_bin_path('sysctl')

    got_sysctl = get_sysctl(module, keys)
    assert got_sysctl
    assert len(got_sysctl.keys()) == len(keys)
    assert got_sysctl['kern.boottime'] is not None

# Generated at 2022-06-11 03:58:03.540890
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args

    with patch('ansible_collections.notstdlib.moveitallout.plugins.modules.system.sysctl.get_bin_path') as get_bin_path_mock:
        get_bin_path_mock.return_value = 'sysctl'

        with patch('ansible_collections.notstdlib.moveitallout.plugins.modules.system.sysctl.run_command') as run_command_mock:
            input_dict = dict(
                foo='bar',
                baz='qux',
                quux='corge',
            )

           

# Generated at 2022-06-11 03:58:13.575749
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.net_tools.linux.ip_sysctl import get_available_sysctl

    available_sysctl = get_available_sysctl({})
    module = AnsibleModule(argument_spec={'prefix': {'type': 'str'}})
    prefix = module.params.get('prefix')
    sysctl = get_sysctl(module, [prefix])
    assert sysctl == {available_sysctl[prefix]['sysctl']: available_sysctl[prefix]['value']}


# Generated at 2022-06-11 03:58:15.903125
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = {}
    assert get_sysctl(sysctl, "vm.max_map_count") == 262144

# Generated at 2022-06-11 03:58:26.750213
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    import ansible.module_utils.basic
    import ansible.module_utils.systemd


# Generated at 2022-06-11 03:58:33.548019
# Unit test for function get_sysctl
def test_get_sysctl():
    """Hacky unit test to check get_sysctl"""

    # If this file is not called sysctl.py, this test will fail
    # import sysctl as function_to_test
    function_to_test = get_sysctl
    assert function_to_test.__name__ == 'get_sysctl', 'Function name changed to %s' % function_to_test

    # see if it works
    test_input = ['kern', 'vm']
    fake_module = FakeModule()
    assert function_to_test(fake_module, test_input)



# Generated at 2022-06-11 03:58:41.253581
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # test some kernel entries
    results = get_sysctl(module, ['-n', 'kern.ostype'])
    assert results['kern.ostype'] == 'Darwin'

    results = get_sysctl(module, ['-n', 'kern.version'])
    assert results['kern.version']

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 03:58:48.169945
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefix=dict(type='list', default=['kern', 'net', 'vm'])
        )
    )

    sysctl = get_sysctl(module, module.params.get('prefix'))

    assert module.params.get('prefix')

    for key, value in sysctl.items():
        assert key in sysctl
        assert value in sysctl.values()

# Generated at 2022-06-11 03:58:57.648116
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.compat.tests.mock import patch

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.bin_path = '/bin'

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/%s' % name

        def run_command(self, cmd):
            out = """sysctl test1 = value1
sysctl test2 = value2
test3 =
    with

    multiple

    lines
test4 = value4
sysctl test5 = value5
sysctl test6 = value6"""
            return 0, out, None

    module = MockModule()

# Generated at 2022-06-11 03:59:03.882177
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Unit test for function get_sysctl
    '''
    import json
    import os

    # example of a single_value
    single_value = '''
net.ipv4.ip_forward = 0
'''
    # example of a multi_value
    multi_value = '''
net.ipv4.route.flush = 1
net.ipv4.route.max_size = 8024376
net.ipv4.route.min_adv_mss = 216
net.ipv4.route.gc_timeout = 60000
'''

    # create temp files to read results into
    with open('single_value.txt', 'w') as single_value_file:
        single_value_file.write(single_value)

# Generated at 2022-06-11 03:59:07.514442
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({})
    test_prefixes = ['net.ipv4.ip_forward']

    assert test_module.get_bin_path('sysctl')
    assert get_sysctl(test_module, test_prefixes)

# Generated at 2022-06-11 03:59:16.654339
# Unit test for function get_sysctl
def test_get_sysctl():
    module = stdlib_module.ModuleStub()

# Generated at 2022-06-11 03:59:27.092572
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    sysctl = get_sysctl(module, ['-a'])
    assert 'kernel.domainname' in sysctl


# Generated at 2022-06-11 03:59:35.765705
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    sysctlout1 = '''
kernel.hostname = localhost
kernel.domainname = example.com
net.ipv4.ip_forward = 1
net.ipv6.conf.default.forwarding = 1
net.ipv6.conf.all.forwarding = 1
net.ipv6.conf.eth0.accept_dad = 0
'''.strip()


# Generated at 2022-06-11 03:59:45.216269
# Unit test for function get_sysctl

# Generated at 2022-06-11 03:59:47.629914
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('module', (object,), dict())
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, 'foo = 1\nbar = baz\nbar: long line\n       continues', '')
    module.warn = lambda x: None
    result = get_sysctl(module, [])
    assert result == dict(foo='1', bar='baz\nlong line continues')

# Generated at 2022-06-11 03:59:57.088000
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    def run_command(module, cmd):
        cmdstr =  " ".join(cmd)
        commands = {
            "sysctl kern.hostname": "kern.hostname: computer.example.org",
            "sysctl kern.hostname kern.domainname":
                "kern.hostname: computer.example.org\nkern.domainname: example.org",
        }
        out = commands[cmdstr]
        return (0, out, '')

    m = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    m.run_command = run_command


# Generated at 2022-06-11 04:00:06.224516
# Unit test for function get_sysctl
def test_get_sysctl():
    import platform
    import tempfile
    import filecmp
    import os

    # Test module_utils.basic.get_sysctl with a temp file before starting
    # the test to make sure our function works as expected.
    module = AnsibleModule(
        argument_spec=dict()
    )

    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile.write(b"foo.bar = 1\n")
    tmpfile.write(b"foo.bar.baz: hello\n")
    tmpfile.write(b"foo.bar.qux = a. longer test value that goes\n")
    tmpfile.write(b"   over multiple lines\n")
    tmpfile.flush()

# Generated at 2022-06-11 04:00:15.530000
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('obj', (), {
        'get_bin_path': lambda *args, **kwargs: '/sbin/sysctl',
        'run_command': lambda *args, **kwargs: (0, 'kernel.msgmnb = 65536\nkernel.msgmax = 65536\nkernel.printk =  4       1       7\nkernel.printk_ratelimit = 5\nkernel.printk_ratelimit_burst = 10\nkernel.sysrq = 0\n', ''),
    })()

    sysctl = get_sysctl(module, ['kernel'])


# Generated at 2022-06-11 04:00:24.371686
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import os
    import tempfile
    import shutil

    module = basic.AnsibleModule(
        argument_spec=dict()
    )


# Generated at 2022-06-11 04:00:28.013111
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('module', ['kern']) == {
        'kern.maxvnodes': '589824',
        'kern.ipc.nmbclusters': '65536',
        'kern.ipc.soacceptqueue': '128',
        'kern.maxprocperuid': '60000'
    }

# Generated at 2022-06-11 04:00:36.509815
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b


# Generated at 2022-06-11 04:01:00.836304
# Unit test for function get_sysctl
def test_get_sysctl():
    module = 'dummy'
    prefixes = ['-a']

# Generated at 2022-06-11 04:01:10.610623
# Unit test for function get_sysctl

# Generated at 2022-06-11 04:01:19.435896
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import tempfile
    class FakeModule:
        def __init__(self, **kwargs):
            self.params = {
                'sysctl': {
                    'kernel.msgmax': 65507,
                    'kernel.sem': '500  32000 32  4096',
                },
            }
            for key in kwargs:
                self.params[key] = kwargs[key]
        def get_bin_path(self, name):
            return '/sbin/' + name

        def run_command(self, cmd):
            class FakeCmd:
                def __init__(self, cmd, stdout):
                    self.cmd = cmd
                    self.stdout = stdout
            if not self.params['sysctl']:
                return (0, '', '')

# Generated at 2022-06-11 04:01:27.531318
# Unit test for function get_sysctl
def test_get_sysctl():

    module = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(required=True, type='list'),
        ),
    )

    sysctl = get_sysctl(module, module.params['prefixes'])

    assert sysctl == {'hw.ncpu': '2', 'hw.byteorder': '1234', 'vm.version': 'BSD VM 2.2.2', 'kern.version': 'Darwin Kernel Version 13.2.0: Thu Apr 17 23:03:13 PDT 2014; root:xnu-2422.100.13~1/RELEASE_X86_64'}
    assert sysctl['vm.version'] == 'BSD VM 2.2.2'

from ansible.module_utils.basic import *


# Generated at 2022-06-11 04:01:37.165566
# Unit test for function get_sysctl
def test_get_sysctl():
    # ModuleFixture instance to test
    module = AnsibleModule({'_ansible_module_name': 'get_sysctl', '_ansible_module_template': 'fixtures/get_sysctl.py'})

    # our test sysctl values
    sysctl_test = {
        'net.ipv4.ip_forward': '1',
        'net.ipv4.conf.all.rp_filter': '1',
        'net.ipv4.conf.default.rp_filter': '1',
        'kernel.randomize_va_space': '2'
    }
    # test getting sysctl values
    sysctl = get_sysctl(module, sysctl_test.keys())
    assert sysctl, "Should return sysctl values"

# Generated at 2022-06-11 04:01:39.212002
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list', required=True)))
    assert get_sysctl(module, ['-a'])

# Generated at 2022-06-11 04:01:45.403504
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Mock the run_command so we don't actually hit the filesystem.
    module.run_command = lambda x: (0, 'kernel.domainname = localdomain\nnet.ipv4.ip_local_port_range = 9000 65500\n', '')

    actual = get_sysctl(module, ['kernel.domainname'])

    assert len(actual) == 1
    assert 'kernel.domainname' in actual
    assert actual['kernel.domainname'] == 'localdomain'

# Generated at 2022-06-11 04:01:53.090099
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    # Make sure we don't actually try to run a command
    module.run_command = lambda cmd: (0, '', '')
    # Add a fake sysctl command to our module so get_sysctl can find it
    module.get_bin_path = lambda cmd: '/bin/sysctl'
    module.warn = lambda msg: ''

    # Test normal operation

# Generated at 2022-06-11 04:01:55.475806
# Unit test for function get_sysctl
def test_get_sysctl():
    import module_utils.basic
    m = module_utils.basic.AnsibleModule(argument_spec=dict())
    result = get_sysctl(m, [])
    assert result
    assert isinstance(result, dict)

# Generated at 2022-06-11 04:01:59.157071
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        ),
    )

    result = get_sysctl(module, ['vm.max_map_count'])

    assert 'vm.max_map_count' in result

# Generated at 2022-06-11 04:02:46.329837
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Test get_sysctl function.
    :return: none
    '''
    sysctl = get_sysctl('/proc/sys/kernel/hostname')
    assert sysctl.get('kernel.hostname') == 'myhostname'
    assert sysctl.get('kernel.ostype') == 'SunOS'
    assert sysctl.get('kernel.osrelease') == '5.11'
    assert sysctl.get('kernel.version') == '#1 SMP Thu Feb 6 17:59:53 MST 2014'
    assert sysctl.get('kernel.domainname') == '(none)'
    assert sysctl.get('kernel.pid_max') == '32768'
    assert sysctl.get('vm.swappiness') == '1'

# Generated at 2022-06-11 04:02:55.636716
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )


# Generated at 2022-06-11 04:02:57.822926
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    module.run_command = lambda *a, **kw: (0, "net.core.somaxconn = 128", "")
    assert module.get_sysctl(['net']) == {"net.core.somaxconn": "128"}



# Generated at 2022-06-11 04:03:00.109338
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['vm.overcommit_ratio'])
    assert sysctl['vm.overcommit_ratio'] == '50'

# Generated at 2022-06-11 04:03:02.408933
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils as module_utils

    results = get_sysctl(module_utils, ['x'])
    assert 'x' in results
    assert results['x'] == 'y'

# Generated at 2022-06-11 04:03:04.610978
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeAnsibleModule()
    assert get_sysctl(module, ['vm.swappiness']) == {'vm.swappiness': '1'}



# Generated at 2022-06-11 04:03:13.245213
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MagicMock()
    module.run_command = MagicMock()
    module.run_command.return_value = (0, """

        kernel.hostname = test-hostname
        net.ipv4.ip_forward = 1
        net.ipv4.ip_forward.foo = 1
        net.ipv4.ip_forward_bar = 0
        net.ipv4.ip.key = 1
        net.ipv4.ip.value = some value with newline
            continuation
        """, '')

    output = get_sysctl(module, ["net.ipv4.ip_forward"])


# Generated at 2022-06-11 04:03:17.345270
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    sysctl_content = 'net.ipv4.ip_forward = 0\n' \
                     'net.ipv4.tcp_syncookies = 1\n' \
                     'net.ipv4.route.flush = 1\n' \
                     'net.ipv6.conf.all.forwarding\n' \
                     '    = 0\n' \
                     'net.ipv6.conf.default.accept_ra = 2\n'

    fd, sysctl_path = tempfile.mkstemp()
    with open(sysctl_path, 'w') as f:
        f.write(sysctl_content)


# Generated at 2022-06-11 04:03:20.869433
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec=dict(prefixes=dict(type='list', elements='str')))
    vals = get_sysctl(module, ['kernel.hostname'])
    assert vals['kernel.hostname'] == 'testhost'



# Generated at 2022-06-11 04:03:26.502494
# Unit test for function get_sysctl
def test_get_sysctl():
    module_mock = MockModule()
    module_mock.run_command = Mock(return_value=(0, KERN_VERSION_STR, ''))

    kern_version = get_sysctl(module_mock, ['kern.version'])

    assert 'kern.version' in kern_version
    assert kern_version['kern.version'] == KERN_VERSION_STR.split(' = ')[1].strip()


# Generated at 2022-06-11 04:05:12.742899
# Unit test for function get_sysctl
def test_get_sysctl():

    module = None
    prefixes = ['fs.file-max']
    cmd = module.get_bin_path('sysctl') + ' ' + ' '.join(prefixes)
    rc = 0
    out = 'fs.file-max = 2000000'
    err = ''
    module.run_command = lambda *a, **kw: (rc, out, err)
    result = get_sysctl(module, prefixes)
    assert rc == 0
    assert len(result) == 1
    assert result['fs.file-max'] == '2000000'


# Generated at 2022-06-11 04:05:13.242901
# Unit test for function get_sysctl
def test_get_sysctl():
    pass


# Generated at 2022-06-11 04:05:21.788079
# Unit test for function get_sysctl
def test_get_sysctl():
    # Create a "fake" module
    test_module = type('', (), {
        'run_command': lambda self, command, check_rc=True: (
            0,
            """
net.ipv4.ip_forward = 1
net.ipv6.conf.all.forwarding = 0
            """,
            ''
        ),
        'warn': lambda self, msg: None,
        'get_bin_path': lambda self, name: name
    })()

    assert get_sysctl(test_module, ['net.ipv4.ip_forward', 'net.ipv6.conf.all.forwarding']) == {
        'net.ipv4.ip_forward': '1',
        'net.ipv6.conf.all.forwarding': '0'
    }

# Generated at 2022-06-11 04:05:24.710991
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    sysctl = get_sysctl(module, ['kern.ostype'])
    assert 'kern.ostype' in sysctl



# Generated at 2022-06-11 04:05:25.784516
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    assert get_sysctl(module, [])

# Generated at 2022-06-11 04:05:31.997647
# Unit test for function get_sysctl
def test_get_sysctl():
    mock_module = MagicMock()
    mock_cmd = MagicMock()
    expected_sysctls = {
        'vm.swappiness': '60',
    }
    mock_cmd.return_value = (0, 'vm.swappiness = 60', '')

    retval = get_sysctl(mock_module, ['/proc/sys/vm', 'vm.swappiness'])

    assert retval == expected_sysctls
    mock_cmd.assert_called_once_with(['/sbin/sysctl', '/proc/sys/vm', 'vm.swappiness'])

# Generated at 2022-06-11 04:05:39.350122
# Unit test for function get_sysctl
def test_get_sysctl():
    fake_module = type('module', (), dict(run_command=lambda self, cmd: (0, 'vm.overcommit_memory = 1\n'
                                                                           'vm.swappiness = 60\n'
                                                                           'net.core.somaxconn = 128', '')))()
    result = get_sysctl(fake_module, ['vm.overcommit_memory', 'vm.swappiness', 'net.core.somaxconn'])
    assert('vm.overcommit_memory' in result)
    assert(result['vm.overcommit_memory'] == '1')
    assert('vm.swappiness' in result)
    assert(result['vm.swappiness'] == '60')
    assert('net.core.somaxconn' in result)

# Generated at 2022-06-11 04:05:46.691259
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('obj', (object, ), dict(run_command=lambda self, cmd: (0, '', '')))

    assert get_sysctl(module, ['net.ipv4.tcp_fin_timeout = 30']) == dict(net_ipv4_tcp_fin_timeout='30')
    assert get_sysctl(module, ['net.ipv4.tcp_fin_timeout=30']) == dict(net_ipv4_tcp_fin_timeout='30')
    assert get_sysctl(module, ['net.ipv4.ip_forward: 0']) == dict(net_ipv4_ip_forward='0')
    assert get_sysctl(module, ['net.ipv4.ip_forward: 1']) == dict(net_ipv4_ip_forward='1')
   

# Generated at 2022-06-11 04:05:52.184159
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule({})
    rc, out, err = m.run_command(['/bin/echo', '-e', 'net.ipv4.ip_forward = 1\nnet.ipv4.ip_forward: 1'])
    assert rc == 0
    sysctl = get_sysctl(m, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}
    assert sysctl['net.ipv4.ip_forward'] == '1'


# Generated at 2022-06-11 04:06:01.882549
# Unit test for function get_sysctl
def test_get_sysctl():

    # Test function can be imported
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import get_sysctl

    module = AnsibleModule(
        argument_spec=dict(
            prefix=[dict(type='str', required=True)]
        ),
        supports_check_mode=False
    )

    keys_to_check = [
        'net.ipv4.tcp_syncookies',
        'net.ipv4.ip_forward'
    ]

    sysctl = get_sysctl(module, keys_to_check)

    assert sysctl.get('net.ipv4.tcp_syncookies', None)
    assert sysctl.get('net.ipv4.ip_forward', None)