

# Generated at 2022-06-11 03:56:49.780886
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict()
    )
    sysctl = get_sysctl(module, ["kernel.hostname"])
    print(sysctl)

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 03:57:00.297640
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.modules.extras.system.sysctl as sysctl
    sysctl.sysctl = get_sysctl
    module = sysctl.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            value=dict(required=True, default=None),
            sysctl_set=dict(required=False, default=None),
            reload=dict(required=False, default=None),
            state=dict(required=False, default='present', choices=['present', 'absent']),
        ),
        supports_check_mode=True
    )
    # Test kernel.sched_rt_runtime_us
    module.params['name'] = 'kernel.sched_rt_runtime_us'
    ret = sysctl.main()
    assert ret.get('sysctl', None)

# Generated at 2022-06-11 03:57:09.817277
# Unit test for function get_sysctl

# Generated at 2022-06-11 03:57:13.201629
# Unit test for function get_sysctl
def test_get_sysctl():
    # use assert_equals to ensure that this function returns expected results
    sysctl_cmd = 'test/loopback/sysctl/bin/sysctl'
    prefixes = ['-a', 'net.ipv4.conf.all']
    sysctl = get_sysctl(sysctl_cmd, prefixes)
    # assert that keys have expected values
    assert sysctl['net.ipv4.conf.all.accept_local'] == '1'
    assert sysctl['net.ipv4.conf.all.accept_redirects'] == '1'

# Generated at 2022-06-11 03:57:20.785598
# Unit test for function get_sysctl

# Generated at 2022-06-11 03:57:30.003978
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import get_platform

    module = AnsibleModule(argument_spec=dict())

    if get_platform().startswith("FreeBSD"):
        prefixes = ['kern.hostname']
    else:
        prefixes = ['kernel.hostname']

    actual = get_sysctl(module, prefixes)
    if get_platform().startswith("FreeBSD"):
        expected = {'kern.hostname': 'foo'}
    else:
        expected = {'kernel.hostname': 'foo'}

    assert actual == expected

# Generated at 2022-06-11 03:57:39.204977
# Unit test for function get_sysctl
def test_get_sysctl():
    # Create the module and args
    from ansible.modules.network.linux import sysctl
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import StringIO
    fd, sysctl_path = basic._configure_module()
    sysctl_cmd = sysctl.Sysctl(sysctl_path, '', '', '')
    sysctl_cmd.run_command = run_command

    # Test 1 - get all sysctls
    def run_command_sysctl_all(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
        stdout = "kernel.hostname = adesk-rhel-01\nkernel.printk = 4 4 1 7\nkernel.printk_devkmsg = on"
        stder

# Generated at 2022-06-11 03:57:46.276879
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(args):
        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
        )
        module.run_command = lambda x: ('', '/proc/sys/net/ipv4/ip_forward: 1\n/proc/sys/net/ipv4/conf/all/rp_filter: 0\n/proc/sys/net/ipv4/conf/all/route_localnet: 0', '')
        return module

    module = test_module(dict())

# Generated at 2022-06-11 03:57:55.813160
# Unit test for function get_sysctl
def test_get_sysctl():
    # We need to mock OS, then we can mock module.run_command
    import sys
    if sys.version_info[0] > 2:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    mock_module = MagicMock()
    mock_module.run_command = MagicMock(return_value=(0, "kern.maxfilesperproc: 12288\nkern.maxfiles: 12288\nkern.maxproc: 12288\n", ""))
    sysctl_out = get_sysctl(mock_module, ["kern.maxfilesperproc", "kern.maxfiles", "kern.maxproc"])
    assert sysctl_out["kern.maxfilesperproc"] == "12288"

# Generated at 2022-06-11 03:58:05.656862
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={
        'prefixes': dict(type='list', required=True),
    })
    sysctl = get_sysctl(module, ['net.ipv4.icmp_echo_ignore_all'])
    assert sysctl == {'net.ipv4.icmp_echo_ignore_all': '0'}
    sysctl = get_sysctl(module, ['net.ipv4.icmp_echo_ignore_all', 'kernel.pid_max'])
    assert sorted(sysctl) == sorted(['net.ipv4.icmp_echo_ignore_all', 'kernel.pid_max'])
    assert sysctl['net.ipv4.icmp_echo_ignore_all'] == '0'
    assert sysctl['kernel.pid_max'] == '32768'

# Generated at 2022-06-11 03:58:19.466306
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sysctl = get_sysctl(module, ['vm', 'vfs'])
    assert len(sysctl) == 4
    assert sysctl['vm.vfs.cache_pressure'] == '10000'
    assert sysctl['vm.vfs.cache_pressure_debug'] == '0'
    assert 'vm.vfs.cache_pressure_updated_at' in sysctl
    assert sysctl['vm.vfs.cache_pressure_updated_by'] == 'kworker/u9:3-events_power_efficient'

# Generated at 2022-06-11 03:58:25.468479
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())

    sysctl = get_sysctl(module, ['kernel'])

    assert type(sysctl) == dict
    assert len(sysctl) >= 5
    assert sysctl['kernel.core_pattern'].startswith('core') == True
    assert sysctl['kernel.core_pattern'].endswith('core') == True
    assert sysctl['kernel.core_uses_pid'] == '1'

# Generated at 2022-06-11 03:58:31.095965
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.common.sysctl import get_sysctl

    module = basic.AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        ),
    )

    assert get_sysctl(module, ["fs.file-max"]) == {"fs.file-max": "300000"}

# Generated at 2022-06-11 03:58:41.062977
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule as AM
    from ansible.module_utils.pycompat24 import get_exception
    import tempfile
    import os

    # Make and destroy a temporary directory
    # This is the easiest way to create a temporary directory
    # that we can use PYTHON_MODULE_UTILS_PATH with.
    temp_dir = tempfile.mkdtemp()
    shutil.rmtree(temp_dir)

    AM_mock = AM(argument_spec={})
    AM_mock.params = {}
    AM_mock.run_command = MagicMock()
    sysctl_cmd = '/sbin/sysctl'
    fake_binary = os.path.join(temp_dir, 'sysctl')
    os.mkdir(temp_dir)
   

# Generated at 2022-06-11 03:58:46.394320
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.sysctl import get_sysctl
    module = AnsibleModule(argument_spec={'prefixes': dict(type='list', elements='str', required=True)})
    assert get_sysctl(module, ['vm.swappiness']) == {'vm.swappiness': '60'}

# Generated at 2022-06-11 03:58:55.017179
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.six import iteritems

    sysctl = dict()

    sysctl['net.ipv4.ip_forward'] = '1'
    sysctl['net.ipv4.conf.default.rp_filter'] = '1'

    module = basic.AnsibleModule(argument_spec=dict())
    module.run_command = lambda cmd: (
        0,
        '\n'.join(['%s = %s' % (key, value) for key, value in iteritems(sysctl)]) + '\n',
        None
    )

    assert get_sysctl(module, ['net.ipv4.*']) == sysctl

# Generated at 2022-06-11 03:59:02.691607
# Unit test for function get_sysctl

# Generated at 2022-06-11 03:59:11.746211
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.solaris import get_sysctl as gs

    if PY2:
        import __builtin__ as builtins
    else:
        import builtins

    class MockModule:
        def get_bin_path(self, path):
            return 'sysctl'


# Generated at 2022-06-11 03:59:20.188203
# Unit test for function get_sysctl
def test_get_sysctl():
    """This is a test for the get_sysctl() function"""

    # Test that get_sysctl() gets correct values from running sysctl
    test_cmd_output = b"""
net.core.somaxconn = 500
net.core.netdev_budget = 300
net.core.netdev_max_backlog = 1000
net.core.rmem_max = 2097152
"""
    assert get_sysctl(test_cmd_output, ['-a']) == {'net.core.netdev_budget': '300', 'net.core.netdev_max_backlog': '1000', 'net.core.rmem_max': '2097152', 'net.core.somaxconn': '500'}

    # Test that get_sysctl() properly skips blank lines in the returned output

# Generated at 2022-06-11 03:59:29.442252
# Unit test for function get_sysctl
def test_get_sysctl():

    # Create a dummy, empty module object
    module = type('', (),{})()

    # Set the bin path so the test will pass
    module.get_bin_path = lambda x: ""

    # Set a command output to be returned by the run_command function
    check_output = "kernel.sysrq = 1\n" \
                   "kernel.shmmax = 1\n" \
                   "kernel.shmall = 2\n" \
                   "kernel.printk = 1\n" \
                   "kernel.sysrq = 1\n" \
                   "kernel.shmmax = 1\n" \
                   "kernel.shmall = 2\n" \
                   "kernel.printk = 1\n"

    # Create a dict to hold the results for the run_command function

# Generated at 2022-06-11 03:59:44.000390
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'path': {'module': '/usr/bin/sysctl'}}, check_invalid_arguments=False)


# Generated at 2022-06-11 03:59:48.912980
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert get_sysctl(module, ['kern.boottime']) == {'kern.boottime': '{ sec = 1477335664, usec = 139025 } Sat Oct 29 14:51:04 2016'}
    assert get_sysctl(module, []) == {}


# Generated at 2022-06-11 03:59:58.431393
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(argument_spec={})

    # Test with a simple sysctl value
    output = """
hw.physmem = 1073741824
hw.usermem = 1071644672
kern.securelevel = -1
kern.version = FreeBSD 11.1-RELEASE-p1 #0 r321309: Fri Jul 21 02:08:28 UTC 2017     root@releng2.nyi.freebsd.org:/usr/obj/usr/src/sys/GENERIC  amd64
kern.version_epoch = 0
"""
    m.run_command = lambda args: (0, output, '')
    assert {} != get_sysctl(m, ['hw.physmem'])

# Generated at 2022-06-11 04:00:08.032140
# Unit test for function get_sysctl
def test_get_sysctl():
    """Test get_sysctl() module.get_bin_path() returns correct path

    get_sysctl() function gets system parameters from
    sysctl(8).

    module.get_bin_path() returns correct path for sysctl(8)

    get_sysctl() returns a dictionary of parameters with the
    prefix given in prefixes

    """


# Generated at 2022-06-11 04:00:16.962559
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import os
    import ansible.module_utils.basic

    files_to_remove = []

    def remove_files():
        for file_name in files_to_remove:
            os.unlink(file_name)


# Generated at 2022-06-11 04:00:17.294448
# Unit test for function get_sysctl
def test_get_sysctl():
    pass



# Generated at 2022-06-11 04:00:20.387749
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('Module', (object,), {
        'get_bin_path': lambda x, y: '/sbin/sysctl',
        'run_command': lambda x, y: (0, '', '')
    })

    result = get_sysctl(module, ['key=value', 'key=value:'])

    assert type(result) is dict
    assert len(result) == 2
    assert result['key'].strip() == 'value'

# Generated at 2022-06-11 04:00:25.780600
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-11 04:00:32.308911
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule(AnsibleModule):
        def __init__(self):
            AnsibleModule.__init__(self)

        def get_bin_path(self, arg, required=False):
            return ""
        def run_command(self, arg):
            return (0, "vm.overcommit_memory = 0\nvm.overcommit_ratio = 50\n", 1)
        def warn(self, arg):
            pass

    module = MockAnsibleModule()

    sysctl = get_sysctl(module, ["-a"])
    assert sysctl['vm.overcommit_memory'] == '0'
    assert sysctl['vm.overcommit_ratio'] == '50'


# Generated at 2022-06-11 04:00:37.263252
# Unit test for function get_sysctl
def test_get_sysctl():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, 'vm.swappiness = 60\nvm.dirty_ratio = 15', ''))
    output = get_sysctl(mock_module, ['vm.swappiness', 'vm.dirty_ratio'])
    assert output == {'vm.swappiness': '60', 'vm.dirty_ratio': '15'}


# Generated at 2022-06-11 04:00:52.564686
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list'),
        )
    )
    sysctl = get_sysctl(module, prefixes=('net.ipv4.conf.all.forwarding',))
    assert sysctl['net.ipv4.conf.all.forwarding'] == '1'




# Generated at 2022-06-11 04:01:00.362739
# Unit test for function get_sysctl
def test_get_sysctl():
    class TestModule():
        def run_command(self, cmd):
            out = """\
net.ipv4.ip_forward: 1
net.ipv4.conf.default.rp_filter = 1

net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.accept_source_route = 0

# Kernel sysctl configuration file for Red Hat Linux
#
# For binary values, 0 is disabled, 1 is enabled.  See sysctl(8) and
# sysctl.conf(5) for more details.

# Controls IP packet forwarding
net.ipv4.ip_forward = 0

# Controls source route verification
net.ipv4.conf.default.rp_filter = 1
"""
            return(0, out, '')


# Generated at 2022-06-11 04:01:10.116855
# Unit test for function get_sysctl
def test_get_sysctl():
    import re
    import sys
    import sys
    import tempfile
    import textwrap
    import unittest

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    class TestGetSysctl(unittest.TestCase):
        def setUp(self):
            self.stdout = ''
            self.stdin = None
            self.cmd = ''
            self.rc = None
            self.args = None

        def _run_module(self, module_args, cmd, rc=0, stdout=None, stdin=None):
            if not stdout:
                stdout = self.stdout

# Generated at 2022-06-11 04:01:19.021064
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    # stub module.run_command() function
    cmd = 'sysctl -a'
    stdout = """
kernel.shmmax = 18446744073692774399
kernel.shmall = 18446744073692774399
kernel.shmmin = 1
kernel.shmmni = 4096
kernel.shmseg = 128
"""
    module.run_command = lambda *args, **kwargs: (0, stdout, '')

    sysctl = get_sysctl(module, [])

# Generated at 2022-06-11 04:01:23.642323
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic

    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_stdout = None
            self.run_command_stderr = None

        def get_bin_path(self, name, opts=None):
            if name == 'sysctl':
                return '/bin/' + name

        def run_command(self, cmd, check_rc=False, executable=None):
            self.run_command_called = True
            self.run_command_rc = 0
            self.run_command_stdout = None
            self.run_

# Generated at 2022-06-11 04:01:31.517712
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.common.system import get_sysctl as utils_get_sysctl
    from ansible.module_utils.common.system import SystemInfo

    module = basic.AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', default=[]),
        ),
    )

    sysctl_results = utils_get_sysctl(module, ['fs', 'net'])
    sysinfo = SystemInfo(module)
    sysctl_info = sysinfo.get_sysctl()

    assert sysctl_results == sysctl_info

# Generated at 2022-06-11 04:01:39.758663
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    sysctl = get_sysctl(module, ['-a'])

# Generated at 2022-06-11 04:01:47.551838
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=True, type='list'),
        ),
        supports_check_mode=False,
    )

    module.run_command = MagicMock(return_value=(0, 'foo: 1\nbar: 2\n', ''))
    data = get_sysctl(module, ['/proc/sys/net/ipv4/ip_forward',
                               '/proc/sys/kernel/hostname'])
    assert data == {'foo': '1', 'bar': '2'}

    module.run_command = MagicMock(return_value=(1, '', ''))

# Generated at 2022-06-11 04:01:51.626837
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec = dict())
    from ansible.module_utils.facts.system.sysctl import get_sysctl

    pref = ['fs.file-max']
    assert get_sysctl(module, pref) == {'fs.file-max': '262144'}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 04:01:56.462948
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward', 'net.ipv4.icmp_echo_ignore_broadcasts'])
    assert sysctl

    # systemd is a standalone service
    if 'systemd' not in sysctl.keys():
        assert 'net.ipv4.ip_forward' in sysctl.keys()
        assert 'net.ipv4.icmp_echo_ignore_broadcasts' in sysctl.keys()



# Generated at 2022-06-11 04:02:30.751166
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import json

    module = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(type='list'),
        ),
        supports_check_mode = False
    )


# Generated at 2022-06-11 04:02:38.074752
# Unit test for function get_sysctl
def test_get_sysctl():
    class MockModule(object):
        def get_bin_path(self, name):
            if name == "sysctl":
                return "/sbin/sysctl"
            else:
                raise Exception("Should not be called")

        def run_command(self, cmd):
            if cmd != ["/sbin/sysctl", "-a"]:
                raise Exception("Should be calling /sbin/sysctl -a")

            return 0, """
kernel.msgmnb = 65536
kernel.msgmax = 65536
kernel.msgmni = 24576
kernel.msgmnb = 65536
kernel.msgmax = 65536
""", ""

    m = MockModule()

    sysctl = get_sysctl(m, ['-a'])

    assert len(sysctl) == 5

# Generated at 2022-06-11 04:02:47.999740
# Unit test for function get_sysctl

# Generated at 2022-06-11 04:02:56.968146
# Unit test for function get_sysctl
def test_get_sysctl():
    # Empty list of prefixes
    assert {} == get_sysctl('', [])

    # Define a module_utils object with a mocked run_command
    class module_utils_object:
        def get_bin_path(self, bin_path):
            return bin_path

        def run_command(self, cmd):
            return 0, '', ''

    m = module_utils_object()

    # Test if all sysctls are returned
    assert get_sysctl(m, []) != {}

    # Test if an empty json is returned when sysctl is not available
    class module_utils_object:
        def get_bin_path(self, bin_path):
            return None

        def run_command(self, cmd):
            return 0, '', ''

    m = module_utils_object()

    assert {} == get

# Generated at 2022-06-11 04:02:59.815955
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list')
        )
    )

    sysctl = get_sysctl(module, module.params['prefixes'])
    assert isinstance(sysctl, dict)

# Generated at 2022-06-11 04:03:03.613990
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockAnsibleModule('get_sysctl')
    value = get_sysctl(module, ['kern.securelevel'])
    print("The value of key kern.securelevel is: %s" % value['kern.securelevel'])
    assert value['kern.securelevel'] == '0'


# Generated at 2022-06-11 04:03:12.242464
# Unit test for function get_sysctl
def test_get_sysctl():
    "Return correct output for sysctl -n net.ipv4.conf.all.rp_filter=1"

    class FakeModule(object):
        @staticmethod
        def run_command(cmd):
            output = "net.ipv4.conf.all.rp_filter: 1"
            return (0, output, '')

        @staticmethod
        def get_bin_path(name, opt_dirs=[]):
            return 'sysctl'

        @staticmethod
        def warn(msg):
            pass

    module = FakeModule()
    result = get_sysctl(module, ['net.ipv4.conf.all.rp_filter'])


# Generated at 2022-06-11 04:03:13.088037
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['foo']) == {}

# Generated at 2022-06-11 04:03:20.944971
# Unit test for function get_sysctl
def test_get_sysctl():

    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = lambda command, check_rc=True: (0, "key1=value1\nkey2=value2\nkey3:\n value3a\n value3b", None)
    sysctl = get_sysctl(module, ["key1", "key2", "key3"])
    assert sysctl == {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3a\nvalue3b"
    }


# Generated at 2022-06-11 04:03:24.858401
# Unit test for function get_sysctl
def test_get_sysctl():
    fake_module = FakeModule()
    fake_module.run_command = FakeRunCommand()

    result = get_sysctl(fake_module, ["kernel.domainname"])

    assert result == {'kernel.domainname': 'vagrantup.com'}


# Generated at 2022-06-11 04:04:31.556644
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from module_utils.common.sysctl import get_sysctl
    module = AnsibleModule(argument_spec={'prefixes':{'type': 'list', 'default': ['kernel']}})
    sysctl = get_sysctl(module, module.params['prefixes'])
    assert(sysctl['kernel.hostname'] == 'jupiter')

# Generated at 2022-06-11 04:04:37.515840
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        dict(
            params=dict(
                prefixes=dict(default=["kernel.shmmax", "vm.swappiness"]),
            ),
        ),
    )
    sysctl = get_sysctl(module, module.params['prefixes'])
    assert isinstance(sysctl, Mapping)
    assert set(sysctl.keys()) == set(module.params['prefixes'])

    assert sysctl['kernel.shmmax'].isdigit()
    assert sysctl['vm.swappiness'].isdigit()



# Generated at 2022-06-11 04:04:39.773116
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    sysctl = get_sysctl(module, ['kernel.domainname'])
    assert sysctl == {'kernel.domainname': 'localdomain'}



# Generated at 2022-06-11 04:04:40.252929
# Unit test for function get_sysctl
def test_get_sysctl():
    pass

# Generated at 2022-06-11 04:04:46.560113
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys
    import unittest
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    args = dict(prefixes=["net.2"])

    class AnsibleExitJson(Exception):
        def __init__(self, value):
            self.value = value

    class AnsibleFailJson(Exception):
        def __init__(self, value):
            self.value = value

    class ModuleMock():
        def __init__(self, fail_json, exit_json):
            self.fail_json = fail_json
            self.exit_json = exit_json
            self.run_command = self.run_command_mock
            self.get_bin_path = self.get_bin_path_mock


# Generated at 2022-06-11 04:04:50.019746
# Unit test for function get_sysctl
def test_get_sysctl():
    """ get_sysctl() returns the value of sysctls  """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctls = [u'fs.file-max', u'fs.file-nr']
    results = get_sysctl(module, sysctls)

    assert results == {u'fs.file-max': u'3104248', u'fs.file-nr': u'283\t0\t3104248'}

# Generated at 2022-06-11 04:04:50.440510
# Unit test for function get_sysctl
def test_get_sysctl():
    pass


# Generated at 2022-06-11 04:04:56.013236
# Unit test for function get_sysctl
def test_get_sysctl():
    """Test the get_sysctl function"""
    class FakeModule:
        """Fake this module"""
        def __init__(self):
            """Do some initialisation"""
            self.warnings = []

        def get_bin_path(self, name):
            """Pretend of sysctl is on the path"""
            if name == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None

        def run_command(self, command):
            """Fake the run_command method in the real module"""
            if command == ['/sbin/sysctl']:
                return 0, "%s:\n\t%s" % ('kern.hostname', 'localhost'), False
            else:
                raise Exception("Unknown command")


# Generated at 2022-06-11 04:04:58.814668
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sysctl = get_sysctl(module, ['kernel.perf_cpu_time_max_percent'])
    assert sysctl == {'kernel.perf_cpu_time_max_percent': '0'}

# Generated at 2022-06-11 04:05:03.565582
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    options = {
        'kernel.hostname': 'testhost',
        'vm.swappiness': 0,
    }

    def mock_run_command(*cmd):
        return (0, '\n'.join(['%s = %s' % kv for kv in options.items()]), None)

    module.run_command = mock_run_command

    output = get_sysctl(module, ['kernel.hostname', 'vm.swappiness'])
    assert output == options