

# Generated at 2022-06-11 03:56:55.281282
# Unit test for function get_sysctl
def test_get_sysctl():
    '''
    Unit test for the "get_sysctl" function.
    invoke the function twice, with different arguments
    '''
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    assert get_sysctl(module, ['vm.swappiness']) == {u'vm.swappiness': u'10'}
    assert get_sysctl(module, ['vm.swappiness', 'vm.overcommit_memory']) == {u'vm.swappiness': u'10', u'vm.overcommit_memory': u'0'}

# Generated at 2022-06-11 03:57:02.753473
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock

    class MockModule():
        def run_command(self, cmd):
            return (0, 'foo = bar\nxyz: abc', '')

    mm = MockModule()
    mm.get_bin_path = MagicMock(return_value='/usr/sbin/sysctl')

    result = get_sysctl(mm, ['-a'])

    assert result['foo'] == 'bar'
    assert result['xyz'] == 'abc'

# Generated at 2022-06-11 03:57:06.254854
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )
    result = get_sysctl(module, ["vm.overcommit_memory"])
    assert result["vm.overcommit_memory"] == "0"

# Generated at 2022-06-11 03:57:15.716056
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sysctl = get_sysctl(module, ['-a'])
    assert sysctl
    assert isinstance(sysctl, dict)



# Generated at 2022-06-11 03:57:25.551313
# Unit test for function get_sysctl

# Generated at 2022-06-11 03:57:28.414727
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctldict = get_sysctl(module, prefixes=["kernel"])
    assert sysctldict.get('kernel.hostname') is not None


# Generated at 2022-06-11 03:57:32.429302
# Unit test for function get_sysctl
def test_get_sysctl():
    args = dict(
        prefixes=['net.ipv4.route.flush']
    )
    from ansible.modules.system.sysctl import get_sysctl
    result = get_sysctl(args)
    assert result['net.ipv4.route.flush'] == '1'



# Generated at 2022-06-11 03:57:41.125460
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict

    m_mod = basic.AnsibleModule(
        argument_spec=dict()
    )

    m_mod.run_command = lambda *args, **kwargs: (0, 'net.ipv4.ip_forward = 0', '')
    res = get_sysctl(m_mod, ['net.ipv4.ip_forward'])
    assert res == dict(net_ipv4_ip_forward='0')


# Generated at 2022-06-11 03:57:44.289475
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = get_sysctl(module, ['-a'])
    assert len(result.keys()) > 0
    assert 'kern.ipc.maxsockbuf' in result.keys()

# Generated at 2022-06-11 03:57:47.187610
# Unit test for function get_sysctl
def test_get_sysctl():
    module = None
    prefixes = ['net.ipv4.ip_forward']
    sysctl = get_sysctl(module, prefixes)
    assert sysctl == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-11 03:58:07.613908
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import json

    # Create a module object
    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # mock out the return code, command, and stdout
    module.run_command = ansible.module_utils.six.moves.mock.Mock()
    module.run_command.return_value = 0, json.dumps({
        'kernel.domainname': 'example.com',
        'kernel.osrelease': '4.4.0-66-generic'
    }), ''

    # test get_sysctl

# Generated at 2022-06-11 03:58:14.965649
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import assertCountEqual
    from io import BytesIO

    # our base mock
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda cmd: (0, 'kernel.domainname = localdomain\nkernel.hostname = localhost\n', None)
    module.check_mode = lambda: False
    module.exit_json = lambda **kwargs: None
    module.warn = lambda message: module.fail_json(msg=message, failed=True)

    module.fail_json = lambda **kwargs: None
    module.exit_json = lambda **kwargs: None

    # test that we get back a dict of the two keys

# Generated at 2022-06-11 03:58:23.060897
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict()
    )
    sysctl = get_sysctl(module, ['/proc/sys/fs/file-nr'])
    assert sysctl['fs.file-nr'] == '1020 0 120768'
    sysctl = get_sysctl(module, ['/proc/sys/fs'])
    assert sysctl['fs.file-nr'] == '1020 0 120768'
    sysctl = get_sysctl(module, ['/proc/sys/'])
    assert sysctl['fs.file-nr'] == '1020 0 120768'

# Generated at 2022-06-11 03:58:33.254029
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils
    import ansible.modules
    import ansible.runner

    # Mock the module
    class MockModule(ansible.modules.core.basic.AnsibleModule):
        def run_command(self, cmd):
            valid_sysctl = {'hw.usermem': '61063680',
                            'hw.usermem64': '61063680',
                            'kern.maxfiles': '25600',
                            'kern.maxfilesperproc': '25600'}

            for sysctl in cmd:
                self.assertIn(sysctl, valid_sysctl)

            return 0, '\n'.join('%s: %s' % (k, v) for k, v in valid_sysctl.items()), ''

    # Assign the module to a runner, so that

# Generated at 2022-06-11 03:58:38.586317
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), {})()
    module.get_bin_path = lambda x: '/sbin/sysctl'
    module.run_command = lambda x: (0, '  value = new_value', '')
    module.warn = lambda x: None
    assert get_sysctl(module, []) == {'value': 'new_value'}

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 03:58:41.480819
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ["fs.file-max"]
    module = None
    sysctls = get_sysctl(module, prefixes)
    assert sysctls is not None

# Generated at 2022-06-11 03:58:51.900351
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(*args, **kwargs):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        kwargs.update({'ANSIBLE_MODULE_ARGS': args})
        module = AnsibleModule(**kwargs)
        return module.exit_json(**module.params)

    module = test_module(prefixes=['net.ipv4.ip_forward', 'kernel.modules_disabled'])
    p = module.params
    assert p['prefixes'] == ['net.ipv4.ip_forward', 'kernel.modules_disabled']
    assert p['sysctl'] == {'net.ipv4.ip_forward': '1',
                           'kernel.modules_disabled': '1'}


# Generated at 2022-06-11 03:59:00.654584
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.bin_path = dict()
            self.run_command = self.mock_run_command

        def get_bin_path(self, command, required=True):
            return self.bin_path.get(command, command)

        def mock_run_command(self, command, check_rc=True):
            rc = 0
            out = ''
            err = ''


# Generated at 2022-06-11 03:59:09.796515
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    os.environ['PATH'] = '/sbin:/usr/sbin:/usr/local/sbin'
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Return a fake shell result when called with sysctl -a

# Generated at 2022-06-11 03:59:18.680102
# Unit test for function get_sysctl
def test_get_sysctl():
    import ansible.module_utils.basic
    import sys

    class MockModule(object):
        def __init__(self):
            self._ansible_module_instance = True

        @staticmethod
        def run_command(cmd):
            return 0, 'kernel.domainname\n  random.bogus.key=10\n  random.key.2=\n  random.key.3:  \n  random.key.4 =  ', ''

        @staticmethod
        def get_bin_path(cmd, opts=None, required=False):
            return '/bin/%s' % cmd

        @staticmethod
        def warn(msg):
            print(msg)

    module = MockModule()

    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic

# Generated at 2022-06-11 03:59:35.398254
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})

    test_sysctl = get_sysctl(module, [])

    assert test_sysctl['kernel.hostname']
    assert test_sysctl['vm.swappiness']


# Generated at 2022-06-11 03:59:39.355914
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'net.ipv4.ip_forward: 1', ''))
    assert get_sysctl(module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}


# Generated at 2022-06-11 03:59:48.875911
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Test the get_sysctl function.

    Expected sysctl output (without error):
    ```
    user.max_user_namespaces = 0
    kernel.unprivileged_userns_clone = 0
    ```

    Expected sysctl output (with error):
    ```
    user.max_user_namespaces = 0
    kernel.unprivileged_userns_clone = 0
    error: "Bad value"
    ```
    """

    # Mock the `run_command()` call from the module.
    from units.compat.mock import MagicMock
    from ansible.modules.system.sysctl import get_sysctl
    module = MagicMock()

    # Test the successful case.

# Generated at 2022-06-11 03:59:54.705291
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec = dict(
            prefixes = dict(
                type='list',
                required=True,
            )
        )
    )
    sysctl = get_sysctl(module, module.params['prefixes'])
    module.exit_json(
        cmd=module.params['prefixes'],
        sysctl=sysctl,
        changed=True,
    )


# Generated at 2022-06-11 04:00:03.452535
# Unit test for function get_sysctl
def test_get_sysctl():

    class FakeModule(object):
        def __init__(self):
            self.run_command = self._fake_run_command

        def _fake_run_command(self, cmd):
            rc = 0
            out = None
            if cmd == ['sysctl', 'kern.timecounter']:
                out = 'kern.timecounter = TSC\n'

# Generated at 2022-06-11 04:00:12.777204
# Unit test for function get_sysctl
def test_get_sysctl():

    import sys, os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname('test_get_sysctl'), '..')))
    from module_utils.basic import AnsibleModule

    module = AnsibleModule()
    module.run_command = lambda x, **kwargs: (0, 'foo = 1\nbar: 2\nbaz = three', '')
    assert get_sysctl(module, ['foo', 'bar', 'baz']) ==  {'foo': '1', 'bar': '2', 'baz': 'three'}

    module.run_command = lambda x, **kwargs: (0, 'foo = one\ntwo\nthree\nbar = four', '')

# Generated at 2022-06-11 04:00:16.392373
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    prefixes = [ 'kern.boottime' ]
    assert get_sysctl(module, prefixes)

# Generated at 2022-06-11 04:00:22.686650
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    import os.path

    module = AnsibleModule(argument_spec=dict(prefixes=dict(type='list', default=['kernel'])))
    module.run_command = lambda *args, **kwargs: (0, 'kernel.hostname=host1\nkernel.domainname=domain1.com', '')

    sysctl = get_sysctl(module, module.params['prefixes'])

    assert sysctl == {'kernel.domainname': 'domain1.com', 'kernel.hostname': 'host1'}

# Generated at 2022-06-11 04:00:28.214454
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={'test_param': dict(type='str', required=False)})
    assert test_module.get_sysctl([])  == {'net.ipv4.ip_forward': '1'}
    assert test_module.get_sysctl(['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}


# Generated at 2022-06-11 04:00:34.938778
# Unit test for function get_sysctl
def test_get_sysctl():
    '''This provides a unit test for the get_sysctl function'''

    sysctl = get_sysctl(None, ['-a'])
    assert 'kernel.hostname' in sysctl

    sysctl = get_sysctl(None, ['kern.*name'])
    assert 'kernel.hostname' in sysctl

    sysctl = get_sysctl(None, ['kern.domainname'])
    assert 'kern.domainname' in sysctl

    sysctl = get_sysctl(None, ['net.inet.ip.forwarding'])
    assert 'net.inet.ip.forwarding' in sysctl


# Generated at 2022-06-11 04:01:04.244040
# Unit test for function get_sysctl
def test_get_sysctl():
    # TODO: Write unit test
    assert True

# Generated at 2022-06-11 04:01:09.668409
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    out = get_sysctl(module, ['net.ipv4.tcp_timestamps'])
    assert out == {'net.ipv4.tcp_timestamps': '1'}



# Generated at 2022-06-11 04:01:18.604570
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule({})
    try:
        from ansible.module_utils.six.moves.configparser import ConfigParser
    except ImportError:
        from ConfigParser import ConfigParser
    sysctl = ConfigParser()
    sysctl_data = {'net.ipv4.tcp_fin_timeout': '60',
                   'net.ipv4.tcp_keepalive_time': '1800',
                   'net.ipv4.tcp_keepalive_probes ': '3',
                   'net.ipv4.tcp_keepalive_intvl': '15'}
    sysctl.add_section('net.ipv4')

# Generated at 2022-06-11 04:01:26.648126
# Unit test for function get_sysctl
def test_get_sysctl():
    source_dir = os.path.dirname(os.path.abspath(__file__))
    sysctl_data_path = os.path.join(source_dir, 'sysctl.txt')

    with open(sysctl_data_path, 'rb') as f:
        fake_result = f.read()

    sysctl_results = dict()

    key = ''
    value = ''
    for line in fake_result.splitlines():
        # skip empty lines
        if not line.strip():
            continue

        if line.startswith(' '):
            # handle multiline values, they will not have a starting key
            value += line
            continue

        if key:
            sysctl_results[key] = value.strip()


# Generated at 2022-06-11 04:01:36.311752
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl

    # If we're not running as root, bail out
    if sysctl.__salt__['cmd.has_exec'](os.path.join(sys.prefix, 'bin/python')):
        sysctl.__opts__['test'] = True
        return {}

    # Using the sysctl module to test our function
    results = sysctl.show_all(output_format='python')

    # Run our function against the results from the sysctl module
    sysctl_list = []
    for key, val in results.items():
        sysctl_list.append('%s' % key)

    sysctl_results = get_sysctl(sysctl, sysctl_list)

    # Compare the final results
    if sysctl_results != results:
        raise Exception('get_sysctl test failed')


# Generated at 2022-06-11 04:01:38.979884
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    try:
        sysctl_out = get_sysctl(module, [])
    except Exception as e:
        assert False, "Unable to read sysctl: %s" % to_text(e)

# Generated at 2022-06-11 04:01:46.732560
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import os

    filename = os.path.dirname(os.path.dirname(__file__)) + '/test/fixtures/kernel/proc_sys.txt'
    fh = open(filename, 'r')
    expected_sysctl = fh.read()
    fh.close()

    test_module = basic.AnsibleModule({})
    test_module.run_command = lambda x: (0, '', '')
    test_module.get_bin_path = lambda x: '/usr/sbin/sysctl'
    test_module.open_file = lambda x, y: open(filename, 'r')
    sysctl = get_sysctl(test_module, '-a')
    assert expected_sysctl == sysctl

# Unit tests for function get_

# Generated at 2022-06-11 04:01:54.339004
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    test_module = AnsibleModule(
        argument_spec=dict()
    )

    expected_sysctl = {
        'kernel.ostype': 'FreeBSD',
        'kernel.osrelease': '10.3-RELEASE',
        'kernel.version': 'FreeBSD 10.3-RELEASE r299103 GENERIC amd64'
    }

    if PY3:
        expected_sysctl['kernel.osrelease'] = '10.3-RELEASE-p7'

    test_sysctl = get_sysctl(test_module, ['kernel.ostype', 'kernel.osrelease', 'kernel.version'])

    assert test_sysctl == expected_sysctl, 'Test get_sysctl'

# Generated at 2022-06-11 04:02:02.211934
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl_ret = {
        'fs.binfmt_misc.status': 'enabled',
        'kernel.msgmnb': '65536',
        'kernel.msgmax': '65536',
        'kernel.msgmni': '2878',
        'kernel.shmmax': '68719476736',
    }

    sysctl_prefixes = [
        'fs.binfmt_misc.status',
        'kernel.msgmnb',
        'kernel.msgmax',
        'kernel.msgmni',
        'kernel.shmmax',
    ]


# Generated at 2022-06-11 04:02:09.318996
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={'prefixes': dict(type='list')})
    sysctl_output = '''
user.max_user_namespaces:  0
vm.swappiness:  60
vm.vfs_cache_pressure:  100
'''

    sysctl_cmd = MagicMock(return_value=(0, sysctl_output, ''))
    prefixes = ['vm.swappiness', 'user.max_user_namespaces']

    with patch.object(module, 'run_command', sysctl_cmd):
        result = get_sysctl(module, prefixes)

    assert result == {'vm.swappiness': '60', 'user.max_user_namespaces': '0'}


# Generated at 2022-06-11 04:03:17.384512
# Unit test for function get_sysctl

# Generated at 2022-06-11 04:03:26.346986
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('_Module', (object,), dict())
    class _Module:
        class _Run:
            @staticmethod
            def run_command(cmd, *args, **kwargs):
                if cmd[0] == '/sbin/sysctl' and cmd[-1] == 'vm.swappiness':
                    return (0, 'vm.swappiness = 5', '')
                elif cmd[0] == '/sbin/sysctl':
                    return (0, '\n'.join([
                        'net.ipv4.ip_forward = 1',
                        'net.ipv4.conf.all.forwarding = 1',
                        'net.ipv4.conf.default.forwarding = 1',
                        'net.ipv6.conf.all.forwarding = 1',
                    ]), '')

# Generated at 2022-06-11 04:03:29.336963
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={
        "prefixes": dict(required=True, type='list')
    })

    sysctl = get_sysctl(module, ['vm.overcommit_memory'])
    assert sysctl == {'vm.overcommit_memory': '0'}

# Generated at 2022-06-11 04:03:37.482159
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict()
    )

    prefixes = ['vm.swappiness','vm.dirty_background_ratio']

    with patch.object(module, "run_command", return_value=[0, 'vm.swappiness = 3\nvm.dirty_background_ratio = 10', '']):
        sysctl = get_sysctl(module, prefixes)
        assert sysctl == {'vm.swappiness': '3', 'vm.dirty_background_ratio': '10'}

    with patch.object(module, "run_command", return_value=[1, '', '']):
        sysctl = get_sysctl(module, prefixes)
        assert sysctl == {}


# Generated at 2022-06-11 04:03:39.335230
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import sysctl
    module = sysctl

    assert 'mib' not in sysctl.get_sysctl(module, ['kern.mib'])

# Generated at 2022-06-11 04:03:43.215254
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Test the get_sysctl function.
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['net.ipv4.ip_forward'])
    assert sysctl == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-11 04:03:52.176974
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    # expected sysctl output:
    # key1 = value1
    # key2 = value2
    # key3 = value3
    #    key4: value4
    #    key5 = value5
    # key6 = value6
    #
    # The spaces on the key4 and key 5 lines are significant and are used to
    # test multiline values.
    out = """
key1 = value1
key2 = value2
key3 = value3
    key4: value4
    key5 = value5
key6 = value6
    """


# Generated at 2022-06-11 04:03:59.922357
# Unit test for function get_sysctl
def test_get_sysctl():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    prefix = 'test_get_sysctl_'

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'sysctl.conf')


# Generated at 2022-06-11 04:04:04.187284
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefix=dict(required=True, type='list'),
        )
    )

    result = get_sysctl(module, module.params['prefix'])
    module.exit_json(changed=False, sysctl=result)

if __name__ == '__main__':
    test_get_sysctl()

# Generated at 2022-06-11 04:04:08.496821
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('FakeModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
        'get_bin_path': lambda self, cmd, opts=None: cmd,
    })()

    sysctl = get_sysctl(module, ['vm.swappiness'])

    if 'vm.swappiness' not in sysctl:
        raise AssertionError('"vm.swappiness" not found in sysctl dictionary.')