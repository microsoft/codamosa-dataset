

# Generated at 2022-06-11 03:56:58.143546
# Unit test for function get_sysctl
def test_get_sysctl():

    class TestModule(object):
        def __init__(self):
            self.run_command = self._run_command
            self.warn = self._warn

        def get_bin_path(self, name):
            return '/usr/bin/' + name

        def _warn(self, msg):
            pass

        def _run_command(self, cmd):
            return (0, 'a = 1\nb: 2\nc =\n   3', '')

    tm = TestModule()
    out = get_sysctl(tm, [])
    assert out == {'a': '1', 'b': '2', 'c': '3'}, 'get_sysctl returned incorrect dict: %s' % out

    # Test with a prefix to make sure it doesn't get included in the output

# Generated at 2022-06-11 03:57:07.696402
# Unit test for function get_sysctl
def test_get_sysctl():

    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.system as system

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    class FakeDistribution(object):
        def __init__(self, distname, version):
            self.name = distname
            self.version = version

    def get_bin_path(name):
        return 'sysctl'

    def run_command(cmd):
        return (0, 'kernel.domainname = test.example', '')

    def get_distribution():
        return FakeDistribution('OpenBSD', '6.3')

    module = AnsibleModule({}, FakeModule({}))

# Generated at 2022-06-11 03:57:17.090300
# Unit test for function get_sysctl
def test_get_sysctl():
    module = sys.modules[__name__]

    class Bin_Path(object):
        def __init__(self, value):
            self.values = {
                'sysctl': value
            }

        def get_bin_path(self, name, required=False):
            return self.values[name]

    class Run_Command(object):
        def __init__(self, value):
            self.values = {
                'sysctl': value
            }

        def run_command(self, args, check_rc=False):
            key = args.pop(0)
            return self.values[key]

    class Warn(object):
        def __init__(self, value):
            self.warnings = []

        def warn(self, message):
            self.warnings.append(message)


# Generated at 2022-06-11 03:57:19.929253
# Unit test for function get_sysctl
def test_get_sysctl():
    prefixes = ['net.ipv4.ip_forward']
    results = get_sysctl(module, prefixes)
    assert results == {'net.ipv4.ip_forward': '1'}

# Generated at 2022-06-11 03:57:30.866019
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    os_name = module.params.get('ansible_os_family', 'Linux')


# Generated at 2022-06-11 03:57:39.908156
# Unit test for function get_sysctl
def test_get_sysctl():
    from collections import namedtuple
    from ansible.module_utils.facts import ansible_module

    TestModule = namedtuple('TestModule', 'run_command get_bin_path warn')

    def test_command(command):
        if command == ['sysctl', 'net.ipv4.ip_forward']:
            return (0, 'net.ipv4.ip_forward = 1', None)
        else:
            return (0, '', None)

    def test_warn(warning):
        pass

    def test_bin(binary):
        return binary

    test_sysctl_module = TestModule(run_command=test_command,
                                    get_bin_path=test_bin,
                                    warn=test_warn)


# Generated at 2022-06-11 03:57:46.158968
# Unit test for function get_sysctl
def test_get_sysctl():
    module = FakeModule()
    sysctl = {
        "net.ipv4.ip_forward": "1",
        "net.ipv4.conf.default.rp_filter": "1",
        "net.ipv4.conf.all.rp_filter": "1",
        "net.ipv4.tcp_syncookies": "1",
        "kernel.sysrq": "0",
        "kernel.core_uses_pid": "1",
    }
    assert get_sysctl(module, ["net.ipv4.conf.*.rp_filter", "kernel.sysrq"]) == sysctl


# Generated at 2022-06-11 03:57:54.581514
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = run_command

    sysctl_list = ['net.ipv4.tcp_congestion_control', 'net.ipv4.tcp_window_scaling']
    sysctl_dict = get_sysctl(test_module, sysctl_list)

    assert sysctl_dict['net.ipv4.tcp_congestion_control'] == 'Westwood'
    assert sysctl_dict['net.ipv4.tcp_window_scaling'] == '1'

# Mock function for testing get_sysctl

# Generated at 2022-06-11 03:58:04.392625
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    def run_cmd(cmd):
        stdout = ""
        rc = 0
        if cmd[1] == "fs.file-max":
            stdout = "fs.file-max = 200000\n"
            rc = 0
        elif cmd[1] == "vm.swappiness":
            stdout = "vm.swappiness = 1\n"
            rc = 0
        elif cmd[1] == "vm.laptop_mode":
            stdout = "vm.laptop_mode = 5\n"
            rc = 0
        elif cmd[1] == "fs.file-max":
            stdout = "fs.file-max = 200000\n"
            rc = 0

# Generated at 2022-06-11 03:58:07.529776
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(None, ['vm.swappiness']) == {'vm.swappiness': '1'}
    assert len(get_sysctl(None, ['vm.swappiness', 'vm.vfs_cache_pressure'])) == 2

# Generated at 2022-06-11 03:58:15.719010
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    sys = get_sysctl(m, ['vm', 'net'])
    assert sys['vm.max_map_count'] == '262144'

# Generated at 2022-06-11 03:58:26.648004
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('MockModule', (object,), {
        '_ansible_check_mode': False,
        'warn': lambda self, msg: print(msg),
    })()

# Generated at 2022-06-11 03:58:35.306005
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule(object):
        def __init__(self):
            self.rc = 0

# Generated at 2022-06-11 03:58:46.350711
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctl = dict()
    sysctl['hw.acpi.thermal.tz0.temperature'] = '41 C'
    sysctl['hw.acpi.thermal.tz1.temperature'] = '40 C'
    sysctl['hw.acpi.thermal.tz0.passive.cooling_enabled'] = '1'
    sysctl['hw.acpi.thermal.tz0.active.cooling_enabled'] = '0'
    sysctl['hw.acpi.thermal.tz0.thermal_flags'] = '0'
    sysctl['hw.acpi.thermal.tz0.temperature_polling_rate'] = '10'
    sysctl['hw.acpi.thermal.tz0.passive.temperature_hysteresis'] = '3'

# Generated at 2022-06-11 03:58:56.034775
# Unit test for function get_sysctl
def test_get_sysctl():
    import argparse
    import os
    import tempfile

    # Create a temporary file for test output
    tmp_fd, tmp_name = tempfile.mkstemp()

    # Write the test output

# Generated at 2022-06-11 03:59:00.477997
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl(module, ['-a'])
    assert get_sysctl(module, [])
    assert get_sysctl(module, ['kernel'])
    assert get_sysctl(module, ['kernel.shm*'])
    assert get_sysctl(module, ['blahblah'])
    assert get_sysctl(module, ['net.ipv4.ip_local_port_range'])

# Generated at 2022-06-11 03:59:09.578440
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule():
        def __init__(self):
            self.params = {}
            self.params['failed'] = False
            self.params['warnings'] = []
            self.params['warned'] = False


# Generated at 2022-06-11 03:59:13.503177
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Make sure get_sysctl will not fail if sysctl executable is missing.
    sysctl = get_sysctl(module, ['-a'])
    assert sysctl == {}


# Generated at 2022-06-11 03:59:16.774173
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.common.sys_info import get_sysctl

    module = basic.AnsibleModule({})
    result = get_sysctl(module, ['-a'])
    assert result != {}

# Generated at 2022-06-11 03:59:24.057856
# Unit test for function get_sysctl
def test_get_sysctl():

    # import python modules
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        print("failed=True msg='ansible.module_utils.basic is required'")
        sys.exit(1)

    # import ansible.module_utils.common.system deps
    from ansible.module_utils.system import sysctl_prefix_uniq

    # define module
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # test get_sysctl
    sysctl_default = get_sysctl(module, [])
    assert sysctl_default

    # test get_sysctl
    sysctl_prefix_uniq_out = sysctl_prefix_uniq(module)
    assert sysctl_prefix_uniq_out

    # test sysctl_prefix

# Generated at 2022-06-11 03:59:40.921602
# Unit test for function get_sysctl
def test_get_sysctl():
    class Module(object):
        def __init__(self):
            self.params = dict()
            self.fail_json = lambda **kwargs: 1/0
            self.run_command = lambda cmd: (0, 'kernel.max_pid = 2147483648\nnet.ipv4.ip_local_port_range = 32768    60999\nnet.ipv4.tcp_tw_recycle = 0\n', '')
        def get_bin_path(self, name):
            return name
    module = Module()
    sysctl = get_sysctl(module, ['kernel.max_pid', 'net.ipv4.ip_local_port_range'])
    assert len(sysctl) == 2
    assert sysctl['kernel.max_pid'] == '2147483648'

# Generated at 2022-06-11 03:59:45.026320
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    module.run_command = run_command
    sysctl = get_sysctl(module, ['fs.file-max'])
    assert sysctl['fs.file-max'] == '131072'



# Generated at 2022-06-11 03:59:54.623963
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import ansible.module_utils.common.network.bsd.sysctl as sysctl_utils
    orig_sysctl = sysctl_utils.get_sysctl
    sysctl_utils.get_sysctl = lambda x,y: {'hw.sensors': 'cpu0:cpu1:cpu2:cpu3:cpu4:cpu5:cpu6:cpu7\nhw.sensors.cpu0.temp0:       20.00 degC\nhw.sensors.cpu1.temp0:       20.00 degC\nhw.sensors.cpu2.temp0:       20.00 degC\n', 'kern.random.sys.seeded': '1'}
    module = basic.AnsibleModule(
        argument_spec=dict(),
    )

# Generated at 2022-06-11 04:00:03.365339
# Unit test for function get_sysctl

# Generated at 2022-06-11 04:00:12.694668
# Unit test for function get_sysctl
def test_get_sysctl():
    module = type('', (), dict())
    module.run_command = lambda cmd: (0, 'net.ipv4.conf.default.accept_source_route = 0\nnet.ipv4.conf.all.accept_source_route = 0\nnet.ipv4.conf.eth0.accept_source_route = 0\n', '')
    module.warn = print
    module.get_bin_path = lambda x: 'sysctl'

# Generated at 2022-06-11 04:00:21.463519
# Unit test for function get_sysctl
def test_get_sysctl():
    import os

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=True, type='list'),
        )
    )
    module.run_command = lambda x: (0, 'kernel.hostname = foo.bar\nkernel.sysrq = 0\nkernel.sem = 500      64000   500  128\nkernel.shmmax = 4294967295\n', '')

    x = module.get_bin_path('sysctl')
    assert x.endswith('sysctl')

    sysctl = get_sysctl(module, ['kernel.hostname', 'kernel.sysrq', 'kernel.sem', 'kernel.shmmax'])


# Generated at 2022-06-11 04:00:23.669541
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl({}, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '0'}

# Generated at 2022-06-11 04:00:30.654333
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import ansible.utils.module_docs as m
    from ansible.module_utils.common.collections import ImmutableDict

    test_module = type(sys)('test_module')
    test_module.fail_json = lambda ** kwargs: None
    test_module.exit_json = lambda ** kwargs: None
    test_module.get_bin_path = lambda ** kwargs: 'sysctl'
    test_module.run_command = lambda ** opt: (0, 'foo = bar\nbar = baz\n', '')

    sysctl = get_sysctl(test_module, [])
    assert sysctl == {'foo': 'bar', 'bar': 'baz'}



# Generated at 2022-06-11 04:00:39.132637
# Unit test for function get_sysctl
def test_get_sysctl():
    import sys
    import StringIO
    import mock

    MOCK_STDOUT = StringIO.StringIO()
    MOCK_STDERR = StringIO.StringIO()
    MOCK_STDOUT_VALUE = StringIO.StringIO()
    MOCK_STDERR_VALUE = StringIO.StringIO()
    prefixes = ['kernel.printk']

# Generated at 2022-06-11 04:00:39.951283
# Unit test for function get_sysctl
def test_get_sysctl():
    assert get_sysctl('kern.*')

# Generated at 2022-06-11 04:01:04.922630
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MockModule()
    sysctl_cmd = module.get_bin_path('sysctl')
    expected_cmd = [sysctl_cmd]
    expected_cmd.extend(['kern.version'])

    # First test: no exceptions, valid return code and output
    module.run_command.side_effect = [
        (0, "kern.version = Darwin Kernel Version 13.3.0: Tue Jun  3 21:27:35 PDT 2014; root:xnu-2422.110.17~1/RELEASE_X86_64", ''),
    ]
    output = get_sysctl(module, ['kern.version'])

# Generated at 2022-06-11 04:01:14.746978
# Unit test for function get_sysctl
def test_get_sysctl():
    # WHAT: Create some dummy input data and test the get_sysctl function
    # WHY:  Ansible modules need unit tests
    #
    # Setup dummy input data
    class module:
        class warn:
            def __init__(self, *args):
                pass


# Generated at 2022-06-11 04:01:22.765705
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    fake_sysctl = dict()

    def fake_run(self, cmd, tmpfile):
        pass

    def fake_get_bin_path(self, arg):
        return '/sbin/sysctl'

    def fake_get_sysctl_value(module, prefixes):
        return fake_sysctl

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Mock modules so we can use get_sysctl
    module.run_command = fake_run
    module.get_bin_path = fake_get_bin_path
    module.get_sysctl_value = fake_get_sysctl_value


# Generated at 2022-06-11 04:01:26.103860
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    prefixes = ['vm.max_map_count']
    sysctl = get_sysctl(module, prefixes)
    assert(sysctl.get('vm.max_map_count') != '')



# Generated at 2022-06-11 04:01:34.430112
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network import NetworkModule

    module = NetworkModule(
        argument_spec=dict(),
        connect_on_load=False
    )

    # sysctl show vm.nr_hugepages is a test that does not require sudo
    assert get_sysctl(module, ['vm.nr_hugepages'])['vm.nr_hugepages'] == '0'

    # Testing for a field that does not exist to return empty dict
    assert not get_sysctl(module, ['vm.test_answer'])
    assert not get_sysctl(module, ['vm.test_answer'])

# Generated at 2022-06-11 04:01:39.136166
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic

    ms = basic.AnsibleModuleStub(argument_spec={})
    assert ms.get_bin_path('sysctl')
    # This test assumes the value of the sysctl is 100 or greater, not
    # unreasonable, but not guaranteed or enforced by the implementation.
    assert get_sysctl(ms, ['kern.somaxconn'])['kern.somaxconn'] != '100'



# Generated at 2022-06-11 04:01:46.877432
# Unit test for function get_sysctl
def test_get_sysctl():
    """
    Function get_sysctl
    """
    module = FakeAnsibleModule()
    module.get_bin_path = lambda x=None: '/sbin/sysctl'

    prefixes = ['-a']

    sysctl = dict()
    sysctl['kernel.msgmnb'] = '65536'
    sysctl['kernel.msgmax'] = '65536'
    sysctl['kernel.msgmni'] = '2878'
    sysctl['kernel.msgmnb'] = '65536'
    sysctl['kernel.msgmax'] = '65536'
    sysctl['kernel.msgmni'] = '2878'
    sysctl['kernel.msgmnb'] = '65536'
    sysctl['kernel.msgmax'] = '65536'

# Generated at 2022-06-11 04:01:54.510616
# Unit test for function get_sysctl
def test_get_sysctl():
    import sysctl

    # We would use the mock library here but it doesn't exist in Python 2.6
    # The purpose of this test is to verify the module's usage of sysctl()
    # not to test the entire module.
    # So manually mocking out the rather simple get_bin_path() function is fine
    def get_bin_path(name):
        return name

    def run_command(cmd):
        return 0, '', ''

    def warn(msg):
        pass

    module = sysctl
    module.get_bin_path = get_bin_path
    module.run_command = run_command
    module.warn = warn


# Generated at 2022-06-11 04:02:02.444279
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        ),
    )

    # Make a fake module class
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = module.exit_json
            self.fail_json = module.fail_json
            self.warn = module.warn

        def get_bin_path(self, arg):
            if arg == 'sysctl':
                return '/sbin/sysctl'
            else:
                self.fail_json(msg='Expected sysctl')


# Generated at 2022-06-11 04:02:07.216936
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(type='list', required=True),
        )
    )
    try:
        (rc, out, err) = module.run_command(['sysctl', 'kern.boottime'])
        module.exit_json(stdout=out, changed=True)
    except Exception as e:
        module.fail_json(msg=to_text(e))


# Generated at 2022-06-11 04:02:47.130101
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec={})
    # Set sysctl -w foo=bar, then return the value
    sysctl = get_sysctl(module, ["sysctl", "-w", "foo=bar"])
    assert sysctl['foo'] == 'bar', "sysctl did not return the expected value"

# Generated at 2022-06-11 04:02:56.232886
# Unit test for function get_sysctl
def test_get_sysctl():
    module = {}
    module['run_command'] = lambda cmd, check_rc=True, close_fds=True: (0, '', '')

    sysctl = get_sysctl(module, ['kernel'])
    assert sysctl['kernel.nr_hugepages'] == '0'

    sysctl = get_sysctl(module, ['kernel.nr_hugepages=0', 'kernel.sched_latency_ns'])
    assert sysctl['kernel.nr_hugepages'] == '0'
    assert sysctl['kernel.sched_latency_ns'] == '20000000'

    # No output from sysctl
    module['run_command'] = lambda cmd, check_rc=True, close_fds=True: (1, '', '')

# Generated at 2022-06-11 04:02:57.196855
# Unit test for function get_sysctl
def test_get_sysctl():
    sysctls = get_sysctl()
    assert sysctls['vm.max_map_count'] == '262144'

# Generated at 2022-06-11 04:03:04.572196
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    # Make sure order is preserved
    module = AnsibleModule(
        argument_spec=dict(),
    )

    module.run_command = lambda cmd: (
        0,
        '''
        net.ipv4.tcp_mem = 8388608 8438168 8785984
        net.ipv4.tcp_rmem = 4096    87380   16777216

        net.ipv4.tcp_wmem = 4096    87380   16777216
        ''',
        ''
    )

    sysctl = get_sysctl(module, ['net.ipv4.*'])

    module.exit_json(
        sysctl=sysctl,
    )


# Generated at 2022-06-11 04:03:11.228030
# Unit test for function get_sysctl
def test_get_sysctl():
    module = MagicMock()
    prefixes = ['fs.file-max', 'vm.max_map_count']
    get_sysctl_out = """\
net.ipv4.route.flush = 1
fs.file-max = 2097152
vm.max_map_count = 65530
"""

    expected = {
        'fs.file-max': '2097152',
        'vm.max_map_count': '65530'
    }

    module.run_command.return_value = (0, get_sysctl_out, '')

    assert get_sysctl(module, prefixes) == expected

# Generated at 2022-06-11 04:03:14.507335
# Unit test for function get_sysctl
def test_get_sysctl():
    test_sysctl = dict()
    test_sysctl['vm.swappiness'] = '60'
    test_sysctl['vm.vfs_cache_pressure'] = '50'

    assert get_sysctl(None, ['vm.swappiness', 'vm.vfs_cache_pressure']) == test_sysctl

# Generated at 2022-06-11 04:03:18.227866
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system.sysctl import main
    module = AnsibleModule(argument_spec={})
    result = main.get_sysctl(module, ['kernel.ostype'])
    assert 'kernel' in result
    assert 'ostype' in result['kernel']

# Generated at 2022-06-11 04:03:27.367524
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    result = get_sysctl(module, [ 'kernel' ])

    assert result['kernel.panic']
    assert result['kernel.domainname']


# - name: Test get_sysctl
#   hosts: localhost
#   tasks:
#     - name: Test get_sysctl
#       sysctl:
#         name: kernel.panic
#         value: 1
#       register: result
#     - name: Test results
#       assert:
#         that:
#           - "result.changed" in "result"
#           - "result.msg" in "result"
#     - name: Test get_sysctl
#       sysctl:
#         name: kernel.panic
#         value: 1
#       register: result
#     - name: Test results
#

# Generated at 2022-06-11 04:03:29.649928
# Unit test for function get_sysctl
def test_get_sysctl():
    module = Mock()
    prefixes = ['kernel', 'os']
    test_sysctl = get_sysctl(module, prefixes)

    assert test_sysctl['kernel'] == 'Linux'


# Generated at 2022-06-11 04:03:37.846480
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic


# Generated at 2022-06-11 04:05:27.734458
# Unit test for function get_sysctl
def test_get_sysctl():
    class FakeModule:
        class run_command_result:
            rc = 0
            stdout = b"net.ipv4.ip_local_port_range: 32768   32000"
            stderr = b""

            def __init__(self, rc, stdout, stderr):
                self.rc = rc
                self.stdout = stdout
                self.stderr = stderr

        def run_command(self, cmd):
            return self.run_command_result(self.run_command_result.rc,
                                           self.run_command_result.stdout,
                                           self.run_command_result.stderr)

    fake_module = FakeModule()


# Generated at 2022-06-11 04:05:35.723925
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    import tempfile

    m = basic.AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=True, type='list'),
        )
    )

    # Return some dummy data.

# Generated at 2022-06-11 04:05:43.273003
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.kernel_config import KernelConfig

    module = AnsibleModule(
        argument_spec=dict()
    )

    sysctl = get_sysctl(module, [])

    test_sysctl = dict()
    test_sysctl['sysctl.conf'] = dict()
    test_sysctl['sysctl.conf']['kernel.domainname'] = 'yaddayadda.example.com'
    test_sysctl['sysctl.conf']['kernel.hostname'] = 'yaddayadda'
    test_sysctl['sysctl.conf']['kernel.corpse_max_state'] = '1'

# Generated at 2022-06-11 04:05:50.628575
# Unit test for function get_sysctl
def test_get_sysctl():
    # Unit test setup
    sysctl_cmd = '/sbin/sysctl'
    prefixes = ['net', 'ipv4']
    out = """
net.ipv4.ip_forward: 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.default.send_redirects = 0
"""

    # Unit test execution
    result = get_sysctl(sysctl_cmd, prefixes)

# Generated at 2022-06-11 04:05:59.859690
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule, get_platform
    from ansible.module_utils.parsing.convert_bool import boolean

    if get_platform() == 'Linux':
        k, v = 'kernel.domainname', 'example.com'
        m = basic.AnsibleModule(argument_spec=dict())
        s = get_sysctl(m, ['kernel.domainname'])
        assert(s[k] == v)

        m = basic.AnsibleModule(argument_spec=dict(boolean=dict(type='bool', default=False)))
        s = get_sysctl(m, ['vm'])
        assert(not boolean(s['vm.overcommit_memory']))


# Generated at 2022-06-11 04:06:03.408017
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    assert get_sysctl(module, ['-p']) != {}
    assert get_sysctl(module, ['-p', 'kernel.acpi']) != {}
    assert get_sysctl(module, ['-n', 'net.ipv4.ip_forward']) != {}

# Generated at 2022-06-11 04:06:12.362028
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible_collections.misc.not_a_real_collection.plugins.modules import get_sysctl
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.params.update({})
    module.get_bin_path = lambda x: 'echo'
    module.run_command = lambda x: ('', 'vm.statistics.vm.v_page_size: 131072\nfoo: bar\n vm.statistics.vm.v_page_size: 1234', '')
    assert get_sysctl(module, ['vm.statistics.vm.v_page_size']) == {'vm.statistics.vm.v_page_size': '131072\n\n1234', 'foo': 'bar'}

# Generated at 2022-06-11 04:06:18.323858
# Unit test for function get_sysctl
def test_get_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    ansible_module = AnsibleModule(
        argument_spec=dict(
            prefixes=dict(required=True, type='list'),
        )
    )

    sysctl = get_sysctl(ansible_module, ['vm.swappiness', 'net.ipv4.conf.all.forwarding', 'net.ipv4.conf.all.mc_forwarding', 'net.ipv4.tcp_keepalive_time', 'net.ipv4.tcp_wmem'])


# Generated at 2022-06-11 04:06:21.345089
# Unit test for function get_sysctl
def test_get_sysctl():
    module = AnsibleModule(argument_spec=dict())
    rc, out, err = module.run_command(['/usr/bin/sysctl', 'net.ipv4.tcp_max_syn_backlog', 'kernel.osrelease'])
    results = get_sysc

# Generated at 2022-06-11 04:06:28.662972
# Unit test for function get_sysctl
def test_get_sysctl():

    test_module = sys.modules[__name__]
    test_module.run_command = mock.Mock(return_value=('0', 'net.ipv4.ip_forward = 1', ''))
    assert get_sysctl(test_module, ['net.ipv4.ip_forward']) == {'net.ipv4.ip_forward': '1'}

    test_module.run_command = mock.Mock(return_value=('1', '', 'No such file or directory'))
    test_module.warn = mock.Mock()
    assert get_sysctl(test_module, ['net.ipv4.ip_forward']) == {}
    assert test_module.warn.called

# vim: expandtab tabstop=4 shiftwidth=4