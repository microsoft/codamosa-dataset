

# Generated at 2022-06-12 10:47:21.538794
# Unit test for function match
def test_match():
    command = Command('brew install aaa',
                      'Error: No available formula for aaa\n==> Searching for '
                      'similar formula...\nWarning: homebrew/science/freebayes '
                      'is deprecated.\nThis formula was renamed to '
                      'homebrew/science/freebayes.\n==> Searching taps...\n'
                      'Caskroom/cask/airfoil is not installed\n'
                      'Error: No available cask for airfoil\n==> Searching for '
                      'similar cask...\nError: Cask \'rubymine\' definition is '
                      'invalid: Bad header line: #\nPlease report this bug: '
                      'https://github.com/caskroom/homebrew-cask/issues/new')
    assert match(command) == True


# Generated at 2022-06-12 10:47:32.184608
# Unit test for function match
def test_match():
    assert match(Command('brew install php', 'Error: No available formula for php'))
    assert not match(Command('brew install php', 'Error: No available formula for php5'))
    assert match(Command('brew install vim', 'Error: No available formula for vim'))
    assert not match(Command('brew install vim', 'Error: No available formula for vim5'))
    assert match(Command('brew install python', 'Error: No available formula for python'))
    assert not match(Command('brew install python', 'Error: No available formula for python5'))
    assert match(Command('brew install node', 'Error: No available formula for node'))
    assert not match(Command('brew install node', 'Error: No available formula for node5'))
    assert match(Command('brew install mysql', 'Error: No available formula for mysql'))

# Generated at 2022-06-12 10:47:38.034996
# Unit test for function match
def test_match():
    assert(match('brew install hoge'))
    assert(match('brew install hoge --with-fuga'))
    assert(match('sudo brew install hoge'))
    assert(match('sudo brew install hoge --with-fuga'))
    assert(not match('brew install'))
    assert(not match('brew install hoge fuga'))
    assert(not match('sudo brew install hoge fuga'))


# Generated at 2022-06-12 10:47:46.693700
# Unit test for function match
def test_match():
    command = """Error: No available formula for yes"""
    assert match(command)
    command = """Error: No available formula for yes
    brew install yes
    Error: No available formula for yes
    brew install yes"""
    assert match(command)
    command = """Error: No available formula for yes
    brew install yes
    Error: No available formula for yes"""
    assert match(command)
    command = """brew install yes
    Error: No available formula for yes
    brew install yes"""
    assert match(command)
    command = """Error: No available formula for yes
    Error: No available formula for yes"""
    assert match(command)
    command = """Error: No available formula for yes
    Error: No available formula for yes
    Error: No available formula for yes"""
    assert match(command)

# Generated at 2022-06-12 10:47:48.093192
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('brew install git-flow') == 'brew install gitflow'

# Generated at 2022-06-12 10:47:53.234299
# Unit test for function match
def test_match():
    command = """
        Error: No available formula for sfantti
        Searching for similarly named formulae...
        This similarly named formula was found:
        sf-ant-tasks
        To install it, run:
          brew install sf-ant-tasks
    """.strip()
    assert match(Command(script='./test', output=command))



# Generated at 2022-06-12 10:48:00.334356
# Unit test for function get_new_command
def test_get_new_command():
    command = 'brew install rpbi'
    output = 'Error: No available formula for rpbi'
    assert get_new_command(type('cmd', (object,), {'script': command, 'output': output})) == 'brew install ruby-build', get_new_command(type('cmd', (object,), {'script': command, 'output': output}))
    command = 'brew install ruby-build'
    assert get_new_command(type('cmd', (object,), {'script': command, 'output': output})) == 'brew install ruby-build', get_new_command(type('cmd', (object,), {'script': command, 'output': output}))

# Generated at 2022-06-12 10:48:02.099017
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('brew install vim') == 'brew install vim'

# Generated at 2022-06-12 10:48:06.445367
# Unit test for function match
def test_match():
    match1 = match(Command('brew install git', 'Error: No available formula for git'))
    match2 = match(Command('brew install gits') < 'Error: No available formula for gits')
    assert match1 > match2


# Generated at 2022-06-12 10:48:13.987300
# Unit test for function match
def test_match():
    assert False == match(Command('brew install aaa', 'Error: No available formula for aaa'))
    assert False == match(Command('brew update', ''))
    assert False == match(Command('brew install foo', ''))
    assert False == match(Command('brew install', ''))
    assert False == match(Command('brew install foo', 'Error: No available formula for bar'))
    assert False == match(Command('brew install vim', 'Error: No available formula for aaa\nYou meant: vim'))
    assert True == match(Command('brew install vim', 'Error: No available formula for vim\nYou meant: vim'))
    assert False == match(Command('brew install vim', 'Error: No available formula for vim\nLooking for a similarly named formula...'))

# Generated at 2022-06-12 10:48:25.672657
# Unit test for function match
def test_match():
    assert match(Command('brew install git', '2.3.4',
                         'Error: No available formula for git'))
    assert not match(Command('brew install git', '2.3.4',
                         'Error: No available formula for gitt'))
    assert not match(Command('brew install git', '2.3.4',
                         'Error: No available formula '))
    assert not match(Command('brew install git', '2.3.4',
                         'Error: No available formula for git\n'))
    assert not match(Command('brew install git', '2.3.4',
                         'Error: No available formula for git\n'))
    assert not match(Command('brew install git', '2.3.4',
                         'Error: No available formula for git\nError: No available formula for gitt'))



# Generated at 2022-06-12 10:48:33.419738
# Unit test for function get_new_command
def test_get_new_command():
    command = ("brew install abcl",
               "Error: No available formula for abcl\n==> Searching for a "
               "formula to install...\n==> Searching local taps...\n==> Searching "
               "taps on GitHub...\n==> Caskroom/cask/brew-cask not found.\n==> "
               "Homebrew/homebrew-core not found.\n==> Homebrew/homebrew-science not "
               "found.\nError: No formulae found in taps.")
    assert get_new_command(command)[0] == 'brew install abc'

# Generated at 2022-06-12 10:48:34.446793
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-12 10:48:37.760489
# Unit test for function get_new_command
def test_get_new_command():
    command = type("obj", (object,), {'script':'brew install test1',
                   'output':'Error: No available formula for test1'})()
    assert get_new_command(command) == 'brew install test'

# Generated at 2022-06-12 10:48:42.262708
# Unit test for function match
def test_match():
    assert match(
        Command('brew install foo', 'Error: No available formula for foo\n'))
    assert match(Command('brew install bar',
                         'Error: No available formula: bar\n'))
    assert not match(
        Command('brew install foo', 'Error: No such file or directory @ apply\n'))
    assert not match(Command('brew install foo', 'Error: foo is not installed\n'))


# Generated at 2022-06-12 10:48:45.176215
# Unit test for function match
def test_match():
    assert match(Command('brew install foo', 'Error: No available formula for foo')) is True
    assert match(Command('brew install foo', 'Error: No available formula for bar')) is False


# Generated at 2022-06-12 10:48:47.247379
# Unit test for function match
def test_match():
    assert match(Command('brew install mysql-connector-c', ''))
    assert not match(Command('brew install hello', ''))

# Generated at 2022-06-12 10:48:53.884866
# Unit test for function match
def test_match():
    assert match(Command(script='brew install javac',
                         output='Error: No available formula for javac'))
    assert match(Command(script='brew install javaca',
                         output='Error: No available formula for javaca'))

    assert not match(Command(script='brew install javac',
                             output='Error: No available for javac'))
    assert not match(Command(script='brew install javaca',
                             output='Error: No available for javaca'))
    assert not match(Command(script='brew install',
                             output='Error: No available formula for javac'))



# Generated at 2022-06-12 10:48:56.269876
# Unit test for function match
def test_match():
    assert match(Commands('brew install test', 'Error: No available formula'))
    assert not match(Commands('test', 'Error: No available formula'))
    assert not match(Commands('brew install test', 'Error: No available'))

# Generated at 2022-06-12 10:48:58.036451
# Unit test for function match
def test_match():
    from thefuck.specific.brew import match
    assert match('''Error: No available formula for cask''')
    assert match('''Error: No available formula for cask''') is False


# Generated at 2022-06-12 10:49:14.424402
# Unit test for function match
def test_match():
    assert match(Command('brew install zsh', 'Error: No available formula for zsh'))
    assert match(Command('brew install zsh', 'Error: No available formula for zsh\n'))


# Generated at 2022-06-12 10:49:19.399249
# Unit test for function match
def test_match():
    command_with_correct_output = 'brew install vim\nError: No available formula for vim\n'
    command_with_incorrect_output = 'brew install vim\nError: No available formula for vim\nError: No available formula for hello'
    assert match(command_with_correct_output)
    assert not match(command_with_incorrect_output)

# Generated at 2022-06-12 10:49:21.046273
# Unit test for function match
def test_match():
    assert match(Command('brew install Caskroom/cask/sublime-text3')) == True


# Generated at 2022-06-12 10:49:23.480275
# Unit test for function match
def test_match():
	assert match(Command('brew install hkp', 'Error: No available formula for hkp\n')) is True


# Generated at 2022-06-12 10:49:27.685440
# Unit test for function get_new_command
def test_get_new_command():
    # Note: This test should not be run on Travis as it needs to run brew command
    from thefuck.types import Command

    assert ('brew install git-extras' ==
            get_new_command(Command('brew install git_extras',
                                    'Error: No available formula for git_extras')))


# Generated at 2022-06-12 10:49:38.237372
# Unit test for function match
def test_match():
    assert (match(Command('brew install astyle', 'Error: No available formula for astyle\n')) is
            True)
    assert (match(Command('brew install astyle', 'Error: No available formula for astyle\nError: No available formula for astyle')) is
            False)
    assert (match(Command('brew install astyle', 'Error: No available formula for astyle\nError: No available formula for astyle\n')) is
            True)
    assert (match(Command('brew install astyle', 'Error: No available formula for astyle\nError: No available formula for astyle\nError: No available formula for astyle\n')) is
            False)

# Generated at 2022-06-12 10:49:44.795152
# Unit test for function match
def test_match():
    assert match(Command('brew install fuck',
                         'Error: No available formula for fuck\n'))
    assert not match(Command('brew install thefuck',
                             'Error: No available formula for thefuck\n'
                             'Searching formulae...\n'
                             'thefuck: stable 3.10'))
    assert not match(Command('brew update',
                             'Error: No available formula for fuck\n'))
    assert not match(Command('brew --version',
                             'Error: No available formula for fuck\n'))


# Generated at 2022-06-12 10:49:46.997203
# Unit test for function match
def test_match():
    assert match(Command('brew install foo', 'Error: No available formula for foo\n'))
    assert not match(Command('brew install foo', ''))

# Generated at 2022-06-12 10:49:48.931733
# Unit test for function get_new_command
def test_get_new_command():
    assert 'brew install thefuck' == get_new_command(
        'brew install thefukk')

# Generated at 2022-06-12 10:49:53.373045
# Unit test for function match
def test_match():
    assert match(Command('brew install git', 'Error: No available formula for git'))
    assert match(Command('brew install python',
                         'Error: No available formula for python'))
    assert not match(Command('brew install git',
                             'Error: No available formula for python3'))
    assert not match(Command('brew install git'))

# Generated at 2022-06-12 10:50:08.773990
# Unit test for function match
def test_match():
    assert match(Command('brew install hellof',
                         'Error: No available formula for hellof'))
    assert match(Command('brew install hellof', 'Error: No available formula'))
    assert not match(Command('brew install hellof',
                             'Error: No available formula'))
    assert not match(Command('brew install hellof',
                             'Error: No available'))


# Generated at 2022-06-12 10:50:14.398789
# Unit test for function match
def test_match():
    # test 1: no matched command
    assert not match(Command('brew install test', ''))

    # test 2: not exist but lowercase
    not_exist_formula = 'test'
    output = 'Error: No available formula for {}'.format(not_exist_formula)
    assert match(
        Command(
            'brew install {}'.format(not_exist_formula), output))

    # test 3: not exist but uppercase
    not_exist_formula = 'TEST'
    output = 'Error: No available formula for {}'.format(not_exist_formula)
    assert not match(
        Command(
            'brew install {}'.format(not_exist_formula), output))

    # test 4: not exist but mixed with uppercase
    mixed_formula_name = 'Test'
    not_

# Generated at 2022-06-12 10:50:16.359969
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('brew install geany') == 'brew install gedit'



# Generated at 2022-06-12 10:50:24.984830
# Unit test for function match
def test_match():
    command1 = type('Cmd', (object,), {'script': 'brew install sdkfjlsdkfj'})
    assert not match(command1)

    command2 = type('Cmd', (object,), {'script': 'brew install node',
                                       'output': 'Error: No available formula for node'})
    assert not match(command2)

    command3 = type('Cmd', (object,), {'script': 'brew install node',
                                       'output': 'Error: No available formula for nod'})
    assert match(command3)



# Generated at 2022-06-12 10:50:27.100140
# Unit test for function match
def test_match():
    assert match(Command('brew install clang-fomrmater'))


# Generated at 2022-06-12 10:50:28.184059
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('brew install ruby').script == 'brew install rbenv'

# Generated at 2022-06-12 10:50:30.479307
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import types
    command = types.Command('brew install readline', '')
    assert get_new_command(command).script == 'brew install readline-x'

# Generated at 2022-06-12 10:50:37.014985
# Unit test for function match
def test_match():
    assert (match(Command('brew install weechat-curses', 'Error: No available formula for weechat-curses')) is True)
    assert (match(Command('brew install weechat-curses', 'Error: weechat-curses is not yet provided')) is False)
    assert (match(Command('brew install ruby', 'Error: No available formula')) is False)



# Generated at 2022-06-12 10:50:41.105042
# Unit test for function match
def test_match():
    assert match(Command('brew install sdwfsdfsd',
                         'Error: No available formula for sdwfsdfsd'))
    assert not match(Command('brew install caskroom/cask/brew-cask',
                             'Error: No available formula for caskroom'))



# Generated at 2022-06-12 10:50:42.278738
# Unit test for function match
def test_match():
    assert match(Command('brew install package', ''))


# Generated at 2022-06-12 10:51:05.796339
# Unit test for function match
def test_match():
    assert match(Command('brew install foo', 'Error: No available formula for foo'))
    assert not match(Command('brew install foo', 'Error: No available formula'))


# Generated at 2022-06-12 10:51:08.803017
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command("brew install adb"))
    # brew install android-platform-tools
    print(get_new_command("brew install xcode"))
    # brew install xcode-select
    print(get_new_command("brew install atom"))
    # brew install web-flow/tap/atom


# Generated at 2022-06-12 10:51:17.148064
# Unit test for function match
def test_match():
    # Test 1
    assert match(Command('brew install vim',
                         'Error: No available formula for vim',
                         '/usr/bin/vim'))

    # Test 2
    assert not match(Command('brew install vim',
                         'Error: No available formula for python',
                         '/usr/bin/vim'))

    # Test 3
    assert not match(Command('brew install',
                         'Error: No available formula for vim',
                         '/usr/bin/vim'))


# Generated at 2022-06-12 10:51:24.860161
# Unit test for function get_new_command
def test_get_new_command():
    existing_formula = 'maven'
    assert get_new_command('brew install %s' % existing_formula) == 'brew install maven@3'
    # Test case for formula name with capitalized letter
    existing_formula = 'maven-shell'
    assert get_new_command('brew install %s' % existing_formula) == 'brew install maven-shell'
    # Test case for formula name with special characters
    existing_formula = 'm-cli'
    assert get_new_command('brew install %s' % existing_formula) == 'brew install m-cli'

# Generated at 2022-06-12 10:51:27.211044
# Unit test for function match
def test_match():
    return match('''==> Searching for similarly named formulae...
Error: No available formula for javac
Searching taps...
==> Searching taps...
E, [2015-12-13T13:35:04.890666 #1089] ERROR -- : Error: No available formula for javac
''')


# Generated at 2022-06-12 10:51:28.853516
# Unit test for function match
def test_match():
    assert match(Command('brew install foobar',
                         'Error: No available formula for foobar'))



# Generated at 2022-06-12 10:51:37.905135
# Unit test for function match
def test_match():
    command_1 = 'brew install caskroom/cask/atom'
    output_1 = ('Error: No available formula for caskroom/cask/atom\n\n'
                'Searching formulae...\nSearching taps...\n')
    command_2 = 'brew install caskroom/cask/pycharm'
    output_2 = ('Error: No available formula for pycharm\n\n'
                'Searching formulae...\nSearching taps...\n')
    command_3 = 'brew install pycharm'
    output_3 = ('Error: No available formula for pycharm\n\n'
                'Searching formulae...\nSearching taps...\n')
    command_4 = 'brew install pycharm-community'

# Generated at 2022-06-12 10:51:42.968924
# Unit test for function match
def test_match():
    assert match(Command('brew install foo', 'Error: No available formula for foo\nSearching formulae...\nSearching taps...\n'))
    assert not match(Command('brew install foo', 'Error: No available formula with the name "foo"\nSearching formulae...\nSearching taps...'))


# Generated at 2022-06-12 10:51:47.142247
# Unit test for function match
def test_match():
    # Perfect match
    command1 = 'brew install vim'  # This will work
    assert match(command1) == False
    command2 = 'brew install bull'  # Will have an error
    assert match(command2) == True
    command3 = 'brew install'
    assert match(command3) == False

# Generated at 2022-06-12 10:51:48.432894
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('brew install gfk') == 'brew install fftw'

# Generated at 2022-06-12 10:52:34.941057
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('brew install foo') == 'brew install foo')
    assert(get_new_command('brew install foo 2>&1') == 'brew install foo 2>&1')
    assert(get_new_command('brew install fabric 2>&1') == 'brew install fabiic 2>&1')
    assert(get_new_command('brew install parllel 2>&1') == 'brew install parallel 2>&1')
    assert(get_new_command('brew install zsh 2>&1') == 'brew install zsh')

# Generated at 2022-06-12 10:52:38.966628
# Unit test for function match
def test_match():
    assert match(Command('brew install git', 'Error: No available formula for '
                                            'git\n', ''))
    assert not match(Command('brew install git', '\n', ''))
    assert not match(Command('sudo apt-get install git', '\n', ''))


# Generated at 2022-06-12 10:52:42.247918
# Unit test for function get_new_command
def test_get_new_command():
    script = 'brew install treeeee'
    output = 'Error: No available formula for treeeee'
    command = Command(script, output)

    assert get_new_command(command) == "brew install tree"

# Generated at 2022-06-12 10:52:45.144969
# Unit test for function match
def test_match():
    assert match(Command(script='brew install wyo') == False)
    assert match(Command(script='brew install wget') == False)
    assert match(Command(script='brew install wget',
                         output='Error: No available formula for wyo'))


# Generated at 2022-06-12 10:52:52.207399
# Unit test for function match
def test_match():
    script = 'brew install chrome'
    output = 'Error: No available formula for chrome'

    assert match(Command(script, output)) == True

    script = 'brew install chrome'
    output = 'Error: No available formula for firefox'

    assert match(Command(script, output)) == False

    script = 'brew install chrome'

    assert match(Command(script, 'some random output text')) == False



# Generated at 2022-06-12 10:52:57.303591
# Unit test for function match
def test_match():
    cmd = """brew install sbev"""
    cmd_true = """Error: No available formula for sbev"""
    assert match(Command(script=cmd, output=cmd_true))
    cmd = """brew install"""
    assert not match(Command(script=cmd, output=cmd_true))
    cmd = """brew install sbev"""
    cmd_false = """Error: No available formula for pack"""
    assert not match(Command(script=cmd, output=cmd_false))



# Generated at 2022-06-12 10:53:04.847246
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('brew install tap', '')) == \
        'brew install tap'
    assert get_new_command(Command('brew install grpe', '')) == \
        'brew install grep'
    assert get_new_command(Command('brew install grp', '')) == \
        'brew install grp'
    assert get_new_command(Command('brew install g', '')) == \
        'brew install g'

# Generated at 2022-06-12 10:53:05.954890
# Unit test for function match
def test_match():
    assert match('brew install rvm')


# Generated at 2022-06-12 10:53:10.504457
# Unit test for function match
def test_match():
    assert match('brew install fck')
    assert match('brew install fck --with-all-baubles')
    assert not match('brew in st fck')
    assert not match('brew install fck 2>&1 | grep \'No available formula\'')

# Generated at 2022-06-12 10:53:19.013002
# Unit test for function match
def test_match():
    # If there is no available formula
    assert not match(Command('brew install asd',
                             'Error: No available formula for asd'))

    # If the error message is caused by not existing in the formula
    assert match(Command('brew install te',
                         'Error: No available formula for te'))

    # If the error message is not caused by not existing in the formula
    assert not match(Command('brew install te',
                             'Error: /usr/local is not writable.'))

    # If the specific command is not for installation
    assert not match(Command('brew search te',
                             'Error: No available formula for te'))

    # If the command is not for brew
    assert not match(Command('ls',
                             'Error: No available formula for te'))


# Generated at 2022-06-12 10:54:42.513309
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('brew install thefuck') == 'brew install thisfuck'

# Generated at 2022-06-12 10:54:45.744907
# Unit test for function match
def test_match():
    assert match(Command('brew install chromi',
                  'Error: No available formula for chromi'))
    assert not match(Command('brew install chromi', 'No available formula'))


# Generated at 2022-06-12 10:54:47.775912
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.brew_not_found import get_new_command
    assert get_new_command('brew install a') == 'brew install a'

# Generated at 2022-06-12 10:54:57.058309
# Unit test for function match
def test_match():
    assert match(Command('brew install foo', 'Error: No available formula for foo'))
    assert not match(Command('brew install foo', 'Error: No available formula for foobar'))
    assert not match(Command('brew install foo', 'Error: No available formula for f'))
    assert not match(Command('brew install foo', 'Error: No available formula for foobar\n'
                                                'Error: No available formula for f'))
    assert not match(Command('brew install foo', 'Error: No available formula for fo'))
    assert match(Command('brew install iojs', 'Error: No available formula for iojs'))
    assert match(Command('brew install git', 'Error: No available formula for git'))
    assert match(Command('brew install gcc', 'Error: No available formula for gcc'))

# Generated at 2022-06-12 10:55:02.266612
# Unit test for function match
def test_match():
    assert not match(Command('brew install git', ''))
    assert match(Command('brew install not-exist-formula',
                         'Error: No available formula for not-exist-formula'))
    assert match(Command('brew install brew-cask',
                         'Error: No available formula for brew-cask'
                          ', did you mean homebrew/science/bwa?'))
    assert not match(Command('brew install git-ftp', ''))



# Generated at 2022-06-12 10:55:05.232468
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('brew install vim') == 'brew install vim'
    assert get_new_command('brew install krypton') == 'brew install kubernetes-cli'
    assert get_new_command('brew install something') == 'brew install something'

# Generated at 2022-06-12 10:55:09.958588
# Unit test for function match
def test_match():
    script = "brew install not_exist_formula"
    output = "Error: No available formula for not_exist_formula"
    command = type('obj', (object,), {'script': script, 'output': output})

    assert match(command)



# Generated at 2022-06-12 10:55:12.461897
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.brew_no_available_formula import get_new_command
    assert get_new_command('brew install gpr') == 'brew install gnupg'

# Generated at 2022-06-12 10:55:15.590810
# Unit test for function match
def test_match():
    from thefuck.specific.brew import match

    assert match(command=Command('brew install git',
                                 'Error: No available formula for git'))

    assert not match(command=Command(r'brew install git',
                                     'Error: No available formula for git\ntest'))

# Generated at 2022-06-12 10:55:22.830965
# Unit test for function match
def test_match():
    assert match(Command(script='brew install qt',
                         output='Error: No available formula for qt'))
    assert match(Command(script='brew install qt',
                         output='Error: No available formula for qt@5.5'))
    assert match(Command(script='brew install ttt',
                         output='Error: No available formula for ttt'))
    assert not match(Command(script='brew install qt',
                             output='Error: No available formula for qt5'))
    assert not match(Command(script='brew install',
                             output='Error: No available formula for qt'))

