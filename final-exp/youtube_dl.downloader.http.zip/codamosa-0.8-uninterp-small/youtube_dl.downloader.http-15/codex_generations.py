

# Generated at 2022-06-26 11:26:53.453836
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:26:56.849489
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()


# unit test

# test_HttpYTDL_real_download.py

# Generated at 2022-06-26 11:26:58.439026
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:26:59.734607
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    print("test_HttpFD() failed.")


# Generated at 2022-06-26 11:27:12.639631
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    assert 'httpfd_1.tmp.mp4' == http_f_d_0.undo_temp_name('tmp.mp4')
    assert True == http_f_d_0.fixup_0(http_f_d_0.filename, http_f_d_0.info_0, True, http_f_d_0.info_0)
    assert False == http_f_d_0.fixup_1(http_f_d_0.filename, http_f_d_0.info_0, True, http_f_d_0.info_0)

# Generated at 2022-06-26 11:27:19.255146
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    return
    # assert any(flag.get_name() == 'j' for flag in HttpFD.real_download.flags
    # if flag.get_name() == 'j'
    # assert HttpFD.real_download.return_type.get_name() == 'bool'
    test_case_0()

if __name__ == '__main__':
  test_HttpFD_real_download()
  # python_toolbox.main(HttpFD, 'HttpFD')

# Generated at 2022-06-26 11:27:21.702628
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert_raises(TypeError, HttpFD)
    assert_raises(TypeError, HttpFD, False, '\nHRU')


# Generated at 2022-06-26 11:27:32.108359
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    bool_0 = True
    str_0 = '\nHRU'
    http_f_d_0 = HttpFD(bool_0, str_0)
    str_1 = 'http://www.youtube.com/watch?v=s7FLg9XBJso'

# Generated at 2022-06-26 11:27:38.497799
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = 'a'
    str_1 = 'a'
    http_f_d_0 = HttpFD(str_0, str_1)
    str_0 = 'http://www.youtube-d.com/b'
    dict_0 = {
        'a': 'b',
        'c': 'd',
        'e': 'f'
    }
    http_f_d_0.real_download(str_0, dict_0, None, 0)

# Classes for unit test - do not remove

# Generated at 2022-06-26 11:27:39.836923
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:28:25.274218
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:28:38.345240
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:28:41.668462
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Testing HTTP with downloader
    #
    #     test_case_0()

    test_case_0()

if __name__ == "_main__":
    test_HttpFD()

# Generated at 2022-06-26 11:28:54.909669
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd_0 = HttpFD()
    print(str(http_fd_0.get_num_connections()))
    http_fd_0.close()
    http_fd_0.add_headers({'User-Agent': 'fake', 'Content-Type': 'fake', 'Accept-Charset': 'fake', 'Accept': 'fake', 'Accept-Encoding': 'fake', 'Connection': 'fake'})

# Generated at 2022-06-26 11:29:02.340382
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url_0= 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4'
    ydl_0 = object()
    filename_0= 'bla.mp4'
    info_dict_0 = {}
    params_0 = {}
    headers_0 = {}
    test_0 = False
    retries_0 = 5
    sleep_interval_0 = 3
    countdown_0 = None
    ctx_0 = {'status': 'downloading', 'elapsed': 0, 'start_time': 0, 'filename': filename_0, 'speed': None, 'filename': filename_0, 'total_bytes': None, 'tmpfilename': 'bla.mp4', 'downloaded_bytes': 0, 'eta': None}
    _hook_progress

# Generated at 2022-06-26 11:29:06.460046
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    obj_0 = HttpFD(test_case_0)
    int_0 = obj_0.real_download(test_case_0)
    assert (int_0 == 0)
    pass


# Generated at 2022-06-26 11:29:08.092907
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = 'wJ1Y'


# Generated at 2022-06-26 11:29:16.118576
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case for method real_download of class HttpFD
    # Test case for real_download, downloads a test file and
    # compares the file size
    hfd = HttpFD()
    hfd._test = False
    hfd.test = True
    hfd._TEST_FILE_SIZE = 5000000
    hfd._hook_progress = lambda d: d
    hfd._sleep = lambda x, d: d
    hfd.real_download(url='http://ipv4.download.thinkbroadband.com/5MB.zip', info_dict={})
    return True


# Generated at 2022-06-26 11:29:19.474699
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_httphandler = HttpFD('', '', 0)
    assert isinstance(test_httphandler, HttpFD)


# Generated at 2022-06-26 11:29:30.803271
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    obj_0 = downloader.FD()
    obj_1 = HttpFD(obj_0)
    obj_2 = {}
    obj_2['url'] = 'http://google.com'
    obj_2['retries'] = int(3)
    obj_2['continuedl'] = bool_0
    obj_2['fragment_retries'] = int(10)
    obj_2['skip_unavailable_fragments'] = bool_0
    obj_2['noprogress'] = bool_0
    obj_2['test'] = bool_0
    obj_2['filename'] = 'example.mp4'
    obj_2['urlhandle'] = obj_0
    obj_2['http_chunk_size'] = int(1000000)

# Generated at 2022-06-26 11:30:15.205945
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL()
    ydl.prepare_filename = lambda x: 'filename'
    ydl.report_error = lambda *args: None

    # Case 0: url is youtube.com/watch?v=<VIDEO ID>
    test_case_0()

# Generated at 2022-06-26 11:30:17.101994
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD()
    fd.real_download(str_0, str_1)



# Generated at 2022-06-26 11:30:18.095601
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    global str_0



# Generated at 2022-06-26 11:30:24.364154
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD('http://example.com', Range(
        0, 20, 100), 'wb', 10, 'video.mp4')
    assert isinstance(http_fd.url, str) and isinstance(http_fd.range, Range) and isinstance(http_fd.open_mode, str) and isinstance(http_fd.block_size, int) and isinstance(http_fd.filename, str)


# Generated at 2022-06-26 11:30:25.714085
# Unit test for constructor of class HttpFD
def test_HttpFD():
    constructor_test_helper(HttpFD)


# Generated at 2022-06-26 11:30:27.845981
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case 0
    res_0 = test_case_0()


# Generated at 2022-06-26 11:30:29.727754
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'wJ1Y'


# Generated at 2022-06-26 11:30:31.602116
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    try:
        assert True
    except:
        mylib.my_print("Assertion failed")


# Generated at 2022-06-26 11:30:34.151204
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hfd = HttpFD('http://www.google.com', 'a')
    test_case_0()


# Generated at 2022-06-26 11:30:43.596133
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:31:44.836908
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test = HttpFD(False, 'http://www.youtube.com/')
    test.real_download(1, 1)
    test.real_download(1, 1)
    test.real_download(12306, 6)
    test.real_download(12306, 6)
    test.real_download(31322, 13)
    test.real_download(31322, 13)
    test.real_download(323, 23)
    test.real_download(323, 23)
    test.real_download(5, 5)
    test.real_download(5, 5)
    test.real_download(31, 1)
    test.real_download(31, 1)
    test.real_download(376, 6)
    test.real_download(376, 6)

# Generated at 2022-06-26 11:31:47.796998
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = False
    str_0 = 'fsk'
    http_f_d_0 = HttpFD(bool_0, str_0)
    assert http_f_d_0.ydl == None


# Generated at 2022-06-26 11:31:48.631865
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:31:50.749456
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:31:54.863611
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def test_case():
        print("== Start test_case ==")
        test_case_0()
        print("== End   test_case ==")
    test_case()


# Generated at 2022-06-26 11:32:05.048540
# Unit test for constructor of class HttpFD
def test_HttpFD():
    int_0 = 1307
    str_0 = 'http'
    str_1 = 'blob'
    http_f_d_0 = HttpFD(str_0, str_1)
    http_f_d_0.real_download(int_0, int_0)
    http_f_d_0.real_download(int_0, int_0)
    http_f_d_0.real_download(int_0, int_0)
    http_f_d_0.real_download(int_0, int_0)
    http_f_d_0.real_download(int_0, int_0)
    http_f_d_0.real_download(int_0, int_0)

# Generated at 2022-06-26 11:32:06.944530
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:32:08.502911
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 11:32:11.470811
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(False, 'fsk').verbose == False
    assert HttpFD(True, 'fsk').verbose == True
    assert HttpFD(False, 'fsk') != None


# Generated at 2022-06-26 11:32:13.252350
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert test_case_0() == None

# Simulate tests from Python code that was compiled from Java code

# Generated at 2022-06-26 11:33:46.176327
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    for i in range(3):
        test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:33:53.224695
# Unit test for constructor of class HttpFD
def test_HttpFD():
    int_0 = 3080
    str_0 = 'test'
    bool_0 = False
    http_f_d_0 = HttpFD(bool_0, str_0)
    assert_equals(http_f_d_0.report_destination, None)

# Generated at 2022-06-26 11:33:54.809965
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD(True, 'http')

# Test case 0

# Generated at 2022-06-26 11:33:56.457481
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

test_cases = [
    test_case_0,
]


# Generated at 2022-06-26 11:33:58.313839
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if TESTING == 2:
        if VERBOSE:
            print('Test 0')
        test_case_0()


# Generated at 2022-06-26 11:34:07.663466
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    import optparse
    parser = optparse.OptionParser(usage='Usage: %prog [options] file-url')
    parser.add_option('-v', '--verbose', action='store_true', dest='verbose',
                      help='Turn on debug messages.')
    (options, args) = parser.parse_args()
    if len(args) < 1:
        parser.print_usage()
        sys.exit(1)
    FORMAT = '%(asctime)-15s %(message)s'
    if options.verbose:
        logging.basicConfig(level=logging.DEBUG, format=FORMAT)
    else:
        logging.basicConfig(level=logging.INFO, format=FORMAT)


# Generated at 2022-06-26 11:34:08.582299
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

main()

# Generated at 2022-06-26 11:34:12.859787
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD(False, 'fsk')
    assert http_f_d_0.ydl is not None
    assert http_f_d_0._downloader is not None
    assert http_f_d_0._num_retries == 5
    assert http_f_d_0._retry_max == False


# Generated at 2022-06-26 11:34:20.518399
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:34:27.786959
# Unit test for constructor of class HttpFD
def test_HttpFD():
    int_0 = 1130
    bool_0 = False
    str_0 = 'fsk'
    http_f_d_0 = HttpFD(bool_0, str_0)
    char_array_0 = http_f_d_0.params
    int_1 = char_array_0.get('retries')
    int_2 = http_f_d_0.ydl.opts.report_warning
    str_1 = 'fsk'
    int_3 = http_f_d_0.ydl.opts.http_chunk_size
    int_4 = http_f_d_0.ydl.opts.sleep_interval
    int_5 = http_f_d_0.ydl.opts.socket_timeout
    str_2 = 'fsk'
    int