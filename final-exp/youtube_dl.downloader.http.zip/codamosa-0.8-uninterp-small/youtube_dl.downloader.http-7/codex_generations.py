

# Generated at 2022-06-26 11:26:56.328950
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    print("Unit test for HttpFD completed")


# Generated at 2022-06-26 11:27:03.369122
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    float_0 = 699.96
    int_0 = 535
    http_f_d_0 = HttpFD(float_0, int_0)
    var_0 = http_f_d_0._setup(http_f_d_0)
    http_f_d_0.real_download(var_0)


# Generated at 2022-06-26 11:27:05.748876
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # http_f_d_0=HttpFD(813.88995,335)
    test_case_0()


# Generated at 2022-06-26 11:27:06.906762
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:27:18.559382
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:27:20.338462
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:21.700805
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:23.312937
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # Test 0
    test_case_0()

# Converts form data to a dictionary

# Generated at 2022-06-26 11:27:34.176911
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    logger = logging.getLogger('test_HttpFD_real_download')
    logger.debug("testing HttpFD.real_download")
    ydl = YoutubeDL(params={'quiet': True, 'skip_download': True})
    http_fd = HttpFD(ydl)
    # Test common case
    test_url = 'https://www.youtube.com'
    res = http_fd.real_download(test_url, info_dict={'id': 'DUMMY'})
    assert res, "HttpFD.real_download returned False for common case"

    # Test error cases
    # Test for HTTPError exception
    test_url = 'https://www.youtube.com/not-found'
    res = http_fd.real_download(test_url, info_dict={'id': 'DUMMY'})


# Generated at 2022-06-26 11:27:36.385221
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print("Test for method real_download of class HttpFD")
    print("[TODO] Not implemented")


# Generated at 2022-06-26 11:28:22.156513
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'Entering unit test for HttpFD'
    var_0 = print(str_0)
    str_1 = 'Executing HttpFD.__init__()'
    var_1 = print(str_1)
    var_2 = HttpFD(None, None, None, None, None, None, None)
    str_2 = 'Executing HttpFD.to_screen()'
    var_3 = print(str_2)
    str_3 = 'Executing HttpFD.to_stderr()'
    var_4 = print(str_3)
    str_4 = 'Executing HttpFD.report_error()'
    var_5 = print(str_4)
    str_5 = 'Executing HttpFD.report_retry()'
    var_6 = print

# Generated at 2022-06-26 11:28:23.303101
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:28:25.060236
# Unit test for constructor of class HttpFD
def test_HttpFD():
    obj_0 = HttpFD('https://www.youtube.com/watch?v=kBEbq919sOQ')
    test_case_0()

test_HttpFD()

# Generated at 2022-06-26 11:28:31.714391
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Byte default
    var_1 = HttpFD('http://www.google.com', None)

    # Chunked
    var_2 = HttpFD('http://www.google.com', None, 0)

    # Byte
    var_3 = HttpFD('http://www.google.com', None, 1000000)

    # Byte default
    with var_1 as var_4:
        # var_5 = type(var_4)
        var_6 = var_4.read(10)
        var_7 = var_4.read(20)
        # var_8 = var_4.seek(10, 0)
        # var_8 = var_4.seek(10, 1)
        # var_8 = var_4.seek(10, 2)
        # var_9 = var_4.tell

# Generated at 2022-06-26 11:28:42.100446
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url_0 = 'http://www.youtube.com/get_video_info?el=detailpage&video_id=U0u6UfChhY4'

# Generated at 2022-06-26 11:28:48.022069
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .retry import RetryDownload
    from .compat import (compat_HTTPError, compat_urllib_error,
        compat_urllib_request)
    from .utils import (
        encodeFilename,
        sanitize_open,
        ContentTooShortError,
        XAttrMetadataError,
        XAttrUnavailableError,
        write_xattr)
    from .postprocessor import FFmpegMergerPP
    from .downloader import FileDownloader
    with open('./http_fd_test.txt', mode='w') as f:
        f.write('Hello, world!')

# Generated at 2022-06-26 11:28:57.212408
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    var_0 = HttpFD()
    str_0 = 'https://live.staticflickr.com/65535/50214992458_b6ac9087c0_o.jpg'
    str_1 = 'test_file'
    var_1 = var_0.real_download(str_0, str_1, {}, 0, True)
    int_0 = 0
    int_1 = 1
    var_2 = int_0 == int_1
    if var_2:
        int_2 = 0
    else:
        int_2 = 1
    return int_2


# Generated at 2022-06-26 11:29:08.195773
# Unit test for constructor of class HttpFD
def test_HttpFD():
    buffer_size = 16
    chunk_size = 3
    httpfd = HttpFD('http://pu.edu.pk/images/banner/banner1.jpg', buffer_size, chunk_size)
    print(httpfd)
    print(httpfd.buffer[:buffer_size])
    print(httpfd.read())
    print(httpfd.read())
    print(httpfd.read())
    print(httpfd.read())
    print(httpfd.read())
    print(httpfd.read())
    httpfd.seek(0)
    print(httpfd.read())
    return


# Generated at 2022-06-26 11:29:12.376520
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('BEGIN OF UNIT TEST')
    #
    str_0 = 'Testing file download'
    var_0 = print(str_0)
    #
    str_0 = 'Unit test for HttpFD completed'
    var_0 = print(str_0)
    #
    return


# Generated at 2022-06-26 11:29:15.276094
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = 'Unit test for method real_download of class HttpFD'
    var_0 = print(str_0)

# Generated at 2022-06-26 11:29:50.584968
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD()

# Generated at 2022-06-26 11:30:00.445427
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    httpfd = HttpFD()
    httpfd._downloader = DummyYDL()

# Generated at 2022-06-26 11:30:11.955946
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    x = HttpFD()

# Generated at 2022-06-26 11:30:15.879239
# Unit test for constructor of class HttpFD
def test_HttpFD():
    obj_0 = HttpFD()
    str_0 = obj_0.ydl.params['nocheckcertificate']
    str_1 = obj_0.ydl._opener.handlers[0]._ca_certs


# Generated at 2022-06-26 11:30:23.507209
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # no args
    fd = HttpFD()
    assert isinstance(fd, FD) is True
    assert isinstance(fd, HttpFD) is True
    assert fd.url == 'http://www.youtube.com/get_video_info?el=detailpage&video_id=U0u6UfChhY4'
    assert fd.filename == None
    assert fd.params == {}
    assert fd.info_dict == {}
    assert fd.yp == None

    # args
    fd = HttpFD('http://www.youtube.com/get_video_info?el=detailpage&video_id=U0u6UfChhY4', 'test.m4a', {}, {})
    assert isinstance(fd, FD) is True

# Generated at 2022-06-26 11:30:34.900006
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:30:41.565628
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    httpFD = HttpFD()
    test_data = {
        'outtmpl': '%(extractor)s-%(id)s.%(ext)s',
        'nooverwrites': True,
        'usenetrc': True,
        'username': 'username',
        'password': 'password',
    }

    test_case_0(test_data)
    # test_case_1()
    # test_case_2()
    # test_case_3()


# Generated at 2022-06-26 11:30:43.993947
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.youtube.com/watch?v=U0u6UfChhY4', 'test_output.flv')
    assert(fd._initialize() == FDError.NO_ERROR)


# Generated at 2022-06-26 11:30:53.922662
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:31:04.038904
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class Ctx:
        pass

    ctx = Ctx()
    ctx.params = {'noprogress': False, 'quiet': True}
    ctx.ydl = YoutubeDL(ctx.params)
    ctx.ydl.progress_hooks = []

    ctx.data = YoutubeDLHandlerMock()
    ctx.data_len = 1024*1024
    ctx.block_size = 1024
    ctx.tmpfilename = 'tmp'
    ctx.filename = 'filename.mp4'
    ctx.is_test = False
    ctx.started = False

    str_0 = 'http://www.youtube.com/get_video_info?el=detailpage&video_id=U0u6UfChhY4'

# Generated at 2022-06-26 11:31:56.078237
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create an object of the tested class
    obj = HttpFD()

    # Perform the test
    obj.real_download(str_0)



# Generated at 2022-06-26 11:32:06.025295
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("Unit test for constructor of class HttpFD")

    ydl = YoutubeDL("http://www.youtube.com/watch?v=U0u6UfChhY4", 'U0u6UfChhY4')


# Generated at 2022-06-26 11:32:14.791744
# Unit test for constructor of class HttpFD
def test_HttpFD():
    tmp_dir = os.path.abspath('./tmp')
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)
    filepath = os.path.join(tmp_dir, 'youtube-dl.py')
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('')
    hfd = HttpFD(filepath, {})
    hfd.report_destination(filepath)
    hfd.report_finish(filepath)
    hfd.report_progress(0, 1, filepath)
    hfd.report_unable_to_resume()
    hfd.report_retry(None, 1, 2)
    hfd.report_error('abc.abc')

# Generated at 2022-06-26 11:32:27.490820
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    httpfd = HttpFD()
    httpfd.real_download(test_case_0.str_0)

# Generated at 2022-06-26 11:32:31.116136
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD()
    url = 'http://www.google.com'
    info_dict = {}
    try:
        fd.real_download(url, info_dict)
    except:
        pass

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:32:38.157210
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    # AssertionError: No value provided for arg 'url'
    http_fd.real_download(url = 'http://www.youtube.com/get_video_info?el=detailpage&video_id=U0u6UfChhY4', filename = '20180702T1609-U0u6UfChhY4.info', info_dict = {}, retries = 10, data = None, headers = {}, query = None, test = True, chunk_size = -1, expected_status = None, continue_dl = False)

# Generated at 2022-06-26 11:32:48.205329
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    httpfd = HttpFD()
    # Test with a YouTube video
    # Test with a YouTube video

# Generated at 2022-06-26 11:32:56.997973
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    dl_object = HttpFD(ExternalFD())

# Generated at 2022-06-26 11:33:02.613912
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD({
        'url': 'http://www.youtube.com/get_video_info?el=detailpage&video_id=U0u6UfChhY4',
        'param': 'test',
        'info_dict': {'title': 'test', 'uploader': 'test'},
        'filename': 'test',
        'test': True,
     })
    assert fd.ydl is not None
    assert fd.params is not None



# Generated at 2022-06-26 11:33:10.513555
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd_0 = HttpFD()
    assert isinstance(httpfd_0, FileDownloader)
    assert isinstance(httpfd_0, FossilizeMixin)
    str_0 = '%s' % httpfd_0
    assert str_0 == '<youtube_dl.downloader.f4m.F4mFD object>'
    assert httpfd_0.params == {
        'usenetrc': False,
        'verbose': False,
    }

# Generated at 2022-06-26 11:34:58.051719
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:35:05.465703
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('\n--- Testing HttpFD constructor ---')
    proc_0 = Process(target=test_case_0, args=())
    proc_0.start()
    proc_0.join(timeout=2.0)
    if proc_0.is_alive():
        proc_0.terminate()
        proc_0.join()


# Generated at 2022-06-26 11:35:09.467582
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    TestCase_0 = TestCase()
    TestCase_0.test_case_0()


# Generated at 2022-06-26 11:35:23.446827
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:35:25.464493
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    httpfd = HttpFD()
    httpfd.real_download(None)


# Generated at 2022-06-26 11:35:31.864248
# Unit test for constructor of class HttpFD
def test_HttpFD():
    s = HttpFD(None)
    assert (s.ydl.opener.addheaders[0] == ('User-Agent', 'yt-dl-test-case'))
    assert (isinstance(s, FD))
    assert (s.url is None)


# Generated at 2022-06-26 11:35:33.197237
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD()
    return


# Generated at 2022-06-26 11:35:37.310005
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd_0 = HttpFD(
        YoutubeDL(),
        'http://www.youtube.com/get_video_info?el=detailpage&video_id=U0u6UfChhY4',
        {},
        {'test': True},
    )
    assert isinstance(http_fd_0, HttpFD)

if __name__ == '__main__':
    test_case_0()
    test_HttpFD()

# Generated at 2022-06-26 11:35:40.164792
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    obj_0 = HttpFD()
    obj_0.real_download()


# Generated at 2022-06-26 11:35:43.877947
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    http_fd.real_download(test_case_0)

test_HttpFD_real_download()