

# Generated at 2022-06-26 11:26:55.736433
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:26:56.762705
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    raise Exception("Not implemented.")


# Generated at 2022-06-26 11:26:58.075415
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert test_case_0() is None


# Generated at 2022-06-26 11:26:59.200727
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:01.085468
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

test_HttpFD()


# Generated at 2022-06-26 11:27:02.262389
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:27:04.044272
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

test_HttpFD()

# Generated at 2022-06-26 11:27:05.993894
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD()

# Generated at 2022-06-26 11:27:09.484668
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    from sys import exit
    exit(test_HttpFD_real_download())

# Generated at 2022-06-26 11:27:12.550010
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Testing real_download...')
    test_case_0()
    print('Testing real_download passed!')

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:59.403124
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Constructor without parameters
    http_fd_0 = HttpFD()

    # Accessing variable 'pause_down' of HttpFD
    var_0 = http_fd_0.pause_down
    assert var_0 == None

    # Accessing variable 'max_data_len' of HttpFD
    var_0 = http_fd_0.max_data_len
    assert var_0 == None

    # Accessing variable 'resume_len' of HttpFD
    var_0 = http_fd_0.resume_len
    assert var_0 == 0

    # Accessing variable 'init_len' of HttpFD
    var_0 = http_fd_0.init_len
    assert var_0 == 0

    # Accessing variable 'chunk_size' of HttpFD
    var_0 = http

# Generated at 2022-06-26 11:28:04.900364
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    args_0 = {'dest': None, 'start_time': 1498145450.9331393, 'chunk_size': None, 'url': 'https://www.youtube.com/watch?v=_uX9q3VjqnE', 'filename': None, 'retries': 10, 'data_len': None, 'test': False, 'open_mode': 'wb', 'is_resume': False, 'resume_len': 0, 'max_filesize': None, 'block_size': 8192, 'min_filesize': None, 'nopart': False}
    obj_0 = HttpFD()
    obj_0.real_download(args_0)

# Test cases for class BaseFileDowloader


# Generated at 2022-06-26 11:28:06.768121
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # not implemented
    test_case_0()


# Generated at 2022-06-26 11:28:07.482778
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass

# Generated at 2022-06-26 11:28:09.270512
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert (True)


# Generated at 2022-06-26 11:28:20.120703
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    real_download = HttpFD.real_download

    # Prepare mock object 'info_dict' in a try block in order to set it to None once it goes out of scope

# Generated at 2022-06-26 11:28:29.029402
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    http_fd.params = {}
    http_fd.ydl = None
    http_fd.report_error = None
    http_fd.report_retry = None
    http_fd.report_resuming_byte = None
    http_fd.report_resume_byte = None
    http_fd.report_destination = None
    http_fd.report_unable_to_resume = None
    http_fd.try_utime = None
    http_fd.try_rename = None
    http_fd.to_screen = None
    http_fd.to_stderr = None
    http_fd.calc_speed = None
    http_fd.calc_eta = None
    http_fd.best_block_size = None

# Generated at 2022-06-26 11:28:30.915226
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert HttpFD().real_download('test') == True


# Generated at 2022-06-26 11:28:37.948266
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(0, 'test_destination', \
                     {'test_key': 'test_value'})
    assert http_fd.ydl is not None
    assert http_fd.dest is 'test_destination'
    assert http_fd.params == {'test_key': 'test_value'}
    assert isinstance(http_fd.ydl, YoutubeDL)


# Generated at 2022-06-26 11:28:50.609923
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    method_name = 'real_download'

    def test_0(self):
        assert str(self.method_return[0]) == 'False',\
            '%s returned %s instead of %s on line %s' % (method_name, str(self.method_return[0]), 'False', self.error_line)

    def test_1(self):
        assert str(self.method_return[0]) == 'True',\
            '%s returned %s instead of %s on line %s' % (method_name, str(self.method_return[0]), 'True', self.error_line)

    var_0 = test_case_0()

    with patch('TestCase.assertTrue', side_effect=test_0) as mock_method:
        var_0.real_download()
        var_1

# Generated at 2022-06-26 11:29:25.562705
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:29:29.980950
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:29:31.663377
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:29:35.737473
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = "http://www.youtube.com"
    http_fd_0 = HttpFD(str_0)
    http_fd_0.to_screen(str_0)
    http_fd_0.report_error(str_0)

# Generated at 2022-06-26 11:29:43.568629
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    for i in range(0, 7):
        try:
            if i == 0:
                test_case_0()
            else:
                assert(False)
        except NameError as e:
            print(' NameError '.join(['Test case ', str(i), ' failed.']))
        except TypeError as e:
            print(' TypeError '.join(['Test case ', str(i), ' failed.']))
        except AssertionError as e:
            print(' AssertionError '.join(['Test case ', str(i), ' failed.']))
        else:
            print('Test case ' + str(i) + ' passed.')

# Testing

# Generated at 2022-06-26 11:29:44.877991
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert(isinstance(HttpFD, object))


# Generated at 2022-06-26 11:29:45.961573
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    return True


# Generated at 2022-06-26 11:29:48.057586
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:29:51.578600
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import HttpFD
    import progress_hooks
    progress_hooks.test_imports(HttpFD)
    # FIXME: add unit test for real_download() of class HttpFD
    assert False


# Generated at 2022-06-26 11:29:58.468747
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bytes_0 = None
    dict_0 = 128, 32, 32
    float_0 = 1343.542
    str_0 = "^nzKs7[a\x0b^\t'hS0"
    http_f_d_0 = HttpFD(float_0, str_0)

if __name__ == "__main__":
    global_var_0 = None
    test_case_0()
    test_HttpFD()

# Generated at 2022-06-26 11:31:18.499358
# Unit test for constructor of class HttpFD
def test_HttpFD():
    float_0 = 2812.59
    float_1 = float_0
    str_0 = "\x7fJg\x18\x1b\x0b^\x0c)K\x0c\x1b5"
    http_f_d_0 = HttpFD(float_0, str_0)
    assert http_f_d_0.ydl == float_0
    assert http_f_d_0.params == str_0
    assert http_f_d_0.retries == 5
    assert not http_f_d_0.continuedl
    # Test if succeeded in asserting the following:
    # assert http_f_d_0.filename != str_0
    bool_0 = http_f_d_0.filename == str_0
    assert bool_0
    #

# Generated at 2022-06-26 11:31:21.031671
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = sys.argv[1]
    ydl_0 = YoutubeDL()
    http_f_d_0 = HttpFD(ydl_0, str_0)


# Generated at 2022-06-26 11:31:29.287922
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url_0 = "URL"
    tmpfilename_0 = "TMPFILENAME"
    filename_0 = "FILENAME"
    info_0 = "INFO"
    data_0 = "DATA"
    params_0 = {'noprogress': True}
    ydl_0 = YoutubeDL(params_0)
    http_fd_0 = HttpFD(ydl_0, url_0, tmpfilename_0, filename_0, info_0, data_0)
    assert not http_fd_0 is None
    #test_case_0()

test_HttpFD()
#
#
# class HlsFD(FD):
#     """ Wrapper for hlsnative downloader """
#     def __init__(self, ydl, filename, info_dict):
#         super(HlsFD,

# Generated at 2022-06-26 11:31:30.591327
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    pass


# Generated at 2022-06-26 11:31:32.906935
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:31:34.923764
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Main entry of this program.
if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:31:36.934088
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 11:31:38.445677
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:31:39.899448
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("Inside test_HttpFD")
    var_0 = HttpFD(None, None)


# Generated at 2022-06-26 11:31:43.805714
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert_equals(test_case_0(), None)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
# ABSTRACT METHODS
    

# Generated at 2022-06-26 11:34:28.216700
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:34:29.826633
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:34:31.580950
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:34:34.327279
# Unit test for constructor of class HttpFD
def test_HttpFD():
    method_name = 'test_HttpFD'
    print(method_name)

    a_http_fd = HttpFD(0)
    assert a_http_fd is not None



# Generated at 2022-06-26 11:34:37.732725
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case 0
    try:
        test_case_0()
    except Exception as err:
        print('Exception caught in test_case_0')
        print(err)

test_HttpFD_real_download()

# Generated at 2022-06-26 11:34:41.097100
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd_0 = HttpFD()
    print("http_fd_0 is: " + str(http_fd_0))
    print("bytes_0 is: " + str(bytes_0))


# Generated at 2022-06-26 11:34:41.872753
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:34:46.154100
# Unit test for constructor of class HttpFD
def test_HttpFD():
    dict_0 = {'0': '0', '0': '0'}
    float_0 = 1243.246
    str_0 = "^nzKs7[a\x0b^\t'hS0"
    http_f_d_0 = HttpFD(float_0, str_0)
    return http_f_d_0


# Generated at 2022-06-26 11:34:48.715557
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert type(test_case_0()) == bool, 'Failed to test method real_download of class HttpFD'

# Generated at 2022-06-26 11:34:50.128363
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD()
