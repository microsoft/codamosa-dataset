

# Generated at 2022-06-26 11:26:57.102364
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    bool_0 = False
    str_0 = 'x'
    http_f_d_0 = HttpFD(bool_0, str_0)
    http_f_d_0.real_download(None, None, None, None, None, None)


# Generated at 2022-06-26 11:27:01.961771
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    '''
    Calls:
        test_case_0()
    '''
    str_0 = "http://ipv4.download.thinkbroadband.com/100MB.zip"
    bool_0 = True
    str_1 = "tmp"
    http_f_d_0 = HttpFD(bool_0, str_1)
    http_f_d_0.real_download(str_0, {}, {}, {})
    # test_case_0()


# Generated at 2022-06-26 11:27:02.893360
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:04.330879
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:27:05.450483
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:06.563256
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:09.195929
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Unit test entry point

# Generated at 2022-06-26 11:27:10.908673
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:19.021480
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print("testing: HttpFD.real_download()")
    bool_0 = True
    str_0 = '|BP|3u'
    http_f_d_0 = HttpFD(bool_0, str_0)
    str_0 = 'z6Ue'
    str_1 = 'dc'
    dict_0 = {str_0:str_1}
    str_0 = '6'
    dict_1 = {str_0:(str_0 + str_0)}
    str_0 = 'b'
    dict_2 = {str_0:None}
    str_0 = 'I'
    dict_3 = {str_0:None}
    str_0 = 'R'
    dict_4 = {str_0:None}
    str_0 = 'ZW8g'


# Generated at 2022-06-26 11:27:20.050111
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:28:01.480616
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case 0
    http_f_d_0 = HttpFD()
    _url = 'http://example.com/file.mp4'
    _filename = '-'
    _info_dict = {'id': '5678'}
    _params = {'nocheckcertificate': True}
    http_f_d_0.real_download(_url, _filename, _info_dict, _params)


# Generated at 2022-06-26 11:28:03.950615
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        http_f_d_0 = HttpFD()
    except Exception as err:
        print(err)
        return False

    return True


# Generated at 2022-06-26 11:28:09.571366
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    return http_f_d_0

if __name__ == '__main__':
    # test_case_0()
    # test_case_1()
    # test_case_2()
    test_HttpFD()
    print("All unit test have passed!")

# Generated at 2022-06-26 11:28:13.299944
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # TODO: Add parameters for test
    http_f_d_0 = HttpFD()
    filename = "test_filename"
    info_dict = None
    return http_f_d_0.real_download(filename, info_dict)


# Generated at 2022-06-26 11:28:24.360470
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    params = {'retries': 0, 'noprogress': False}
    http_fd.params = params
    http_fd.to_stdout = lambda s: s
    http_fd.to_stderr = lambda s: s
    http_fd.report_warning = lambda s: s
    http_fd.report_error = lambda s: s
    http_fd._hook_progress = lambda status: status
    http_fd.report_retry = lambda e, count, max_: s
    http_fd.report_file_already_downloaded = lambda s: s
    http_fd.report_unable_to_resume = lambda s: s
    http_fd.report_destination = lambda s: s

# Generated at 2022-06-26 11:28:25.353747
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
# End unit test


# Generated at 2022-06-26 11:28:27.861418
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:28:29.019572
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    HttpFD().real_download()



# Generated at 2022-06-26 11:28:40.934843
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from urllib.parse import urlparse
    from urllib.request import Request, urlopen
    httpfd = HttpFD()
    assert isinstance(httpfd, HttpFD)

    assert hasattr(httpfd, 'params')
    assert isinstance(httpfd.params, dict)
    assert httpfd.params == {'proxy': None, 'sleep_interval': 1.0, 'max_sleep_interval': 15.0, 'max_retries': 10, 'retry_on_http_200': False}

    assert hasattr(httpfd, 'ydl')
    assert isinstance(httpfd.ydl, YoutubeDL)

    assert hasattr(httpfd, 'test')
    assert isinstance(httpfd.test, bool)
    assert not httpfd.test

    assert hasattr(httpfd, 'quiet')

# Generated at 2022-06-26 11:28:44.452806
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    >>> test_case_0()
    >>>
    """
    pass

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:29:27.822663
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile, os, errno
    from .utils import encodeFilename

    def _remove_files(files):
        for f in files:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except OSError as ose:
                if ose.errno != errno.ENOENT:
                    raise

    def _test_case(test_params):
        out_f_l = []
        out_f_l_file = []
        i = 0
        while True:
            out_f = tempfile.NamedTemporaryFile(delete=False)
            out_f_l_file.append(out_f.name)
            out_f_l_file.append(encodeFilename(out_f.name))

# Generated at 2022-06-26 11:29:30.014267
# Unit test for constructor of class HttpFD
def test_HttpFD():

    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:29:40.444171
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    url = 'http://example.com/test.mp4'

    class FakeYDL:
        download_retcode = 0
        params = {}

        def to_screen(self, *args, **kwargs):
            pass

        def urlopen(self, *args, **kwargs):
            return FakeUrlOpen()

        def to_stderr(self, *args, **kwargs):
            pass

        def download(self, *args, **kwargs):
            return self.download_retcode

        def report_resuming_byte(self, byte):
            pass

        def report_retry(self, err, count, max_retries):
            pass

        def report_unable_to_resume(self):
            pass


# Generated at 2022-06-26 11:29:46.851036
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create directory for test files
    test_dir = os.path.join(os.path.dirname(__file__), '..', 'Simulator', 'YouTubeDL', 'test')
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    ydl = None

# Generated at 2022-06-26 11:29:51.007203
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD()
    assert http_f_d_0.real_download(
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        {'test': True}
    ) is True


# Generated at 2022-06-26 11:30:01.963708
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()

    # Testing the behaviour when the download finishes successfully
    result_1 = http_fd.real_download(
        {
            'filename': 'test',
            'tmpfilename': 'test_tmp',
            'url': 'https://www.example.com/index.html',
            'resume_len': 0,
            'open_mode': 'wb',
            'chunk_size': 0,
            'block_size': 0,
            'data_len': None,
            'retries': 0,
            'continuedl': False,
            'start_time': time.time()
        }
    )
    # Check the result
    assert(result_1 == True)

    # Testing the behaviour when the download doesn't finish successfully

# Generated at 2022-06-26 11:30:02.983930
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert type(HttpFD()) == HttpFD


# Generated at 2022-06-26 11:30:14.272372
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    http_fd = HttpFD()
    http_fd.report_destination = lambda filename: None
    http_fd.report_progress = lambda percentage, speed, eta: None

    # Test case 1:
    # test 'obtain some meta data first' code path
    test_case_1_url = 'https://a.example.com/'
    test_case_1_dest = '-'
    test_case_1_stream = None
    test_case_1_params = { 'nocheckcertificate': True }

    test_case_1_http_headers = {'Accept-Encoding': 'identity'}

# Generated at 2022-06-26 11:30:15.597683
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()


# Generated at 2022-06-26 11:30:24.926081
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Test real_download(...) with all the optional parameters
    """
    # Test 1:

# Generated at 2022-06-26 11:31:03.483506
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = True
    str_0 = '|BP|3u'
    http_f_d_0 = HttpFD(bool_0, str_0)


# Generated at 2022-06-26 11:31:09.430417
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    # self.to_screen('[debug] real_download: Downloading chunk 0-11 bytes')
    # self.report_retry(URLError(SSLError(1, 'winerror 10054')), 1, 3)
    # self.report_retry(URLError(SSLError(1, 'winerror 10054')), 2, 3)
    # self.report_retry(URLError(SSLError(1, 'winerror 10054')), 3, 3)
    # self.report_error('giving up after 3 retries')

test_case_1_str_0 = '|BP|3u'
test_case_1_str_1 = '0dq|'
test_case_1_int_0 = 2
test_case_1

# Generated at 2022-06-26 11:31:11.442782
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    # print('unit_test real_download(): OK')


# Generated at 2022-06-26 11:31:14.021863
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = True
    str_0 = ''
    http_f_d_0 = HttpFD(bool_0, str_0)


# Generated at 2022-06-26 11:31:15.089488
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

test_HttpFD()

# Generated at 2022-06-26 11:31:16.766307
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if not test_case_0():
        print('[FAIL]')
    else:
        print('[PASS]')


# Generated at 2022-06-26 11:31:24.801787
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = True
    str_0 = '|BP|3u'
    http_f_d_0 = HttpFD(bool_0, str_0)
    print(http_f_d_0)

    bool_0 = True
    str_0 = '|BP|3u'
    http_f_d_0 = HttpFD(bool_0, str_0)
    test_case_0()

    bool_0 = True
    str_0 = '|BP|3u'
    http_f_d_0 = HttpFD(bool_0, str_0)
    test_case_0()

    test_case_0()



# Generated at 2022-06-26 11:31:27.732684
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = True
    str_0 = '|BP|3u'
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-26 11:31:29.962130
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    '''Only the first assert is correct'''
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:31:31.980044
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test 1: Normal case
    test_case_0()


# Generated at 2022-06-26 11:32:47.908626
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert_equals(HttpFD.real_download(None, 'http://www.youtube.com?v=BaW_jenozKc'), True)


# Generated at 2022-06-26 11:32:49.402846
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert test_case_0()

# Main function, used to generate a test report of all test cases

# Generated at 2022-06-26 11:32:50.267083
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 11:32:52.960698
# Unit test for constructor of class HttpFD
def test_HttpFD():
    t_c_0 = test_case_0()
    print(t_c_0)

# Generated at 2022-06-26 11:32:53.906371
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 11:32:54.855276
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:32:56.357781
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD('D', 'rc')


# Generated at 2022-06-26 11:33:00.799137
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    var_0 = HttpFD(None, None)
    var_1 = "http://www.tinyurl.com/a3qe3"
    var_2 = var_0.real_download(None, var_1)
    assert type(var_2) == bool


# Generated at 2022-06-26 11:33:02.736208
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:33:06.927779
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        httpFD = HttpFD(True, 'one')
        bool_0 = True
        str_0 = '|BP|3u'
        http_f_d_0 = HttpFD(bool_0, str_0)
        list_0 = None
        var_0 = http_f_d_0.real_download(list_0, str_0)
        return True
    except:
        return False