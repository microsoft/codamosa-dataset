

# Generated at 2022-06-26 11:26:56.112467
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:26:57.785544
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:02.182745
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = YDL()
    ydl.add_info_extractor(MockIE())
    ydl.params['noplaylist'] = True
    ydl.download(['mock'])
    assert(os.path.exists('mock'))


# Generated at 2022-06-26 11:27:04.376448
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

################################################################################


# Generated at 2022-06-26 11:27:06.310599
# Unit test for constructor of class HttpFD
def test_HttpFD():
    instance = HttpFD(1, 1)
    assert isinstance(instance, HttpFD)


# Generated at 2022-06-26 11:27:09.394754
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:10.769929
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Testing case 0
    test_case_0()

test_HttpFD()

# Generated at 2022-06-26 11:27:13.334217
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD()
    # print(globals())
    # print(locals())

# Generated at 2022-06-26 11:27:15.633238
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:23.001307
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD(False, [False, True])
    count_0 = http_f_d_0.real_download('/usr/bin/youtube-dl', '', '/usr/bin/youtube-dl',
                                                 '', '', '\t', 'http://www.youtube.com', '', '',
                                                 '', '', '', 0, '', '', '', '', 0, 4,
                                                 '', '', '', '', '', '', '', '', '', '', False)
    assert count_0 == 0


# Generated at 2022-06-26 11:28:03.444730
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd_0 = HttpFD()
    assert http_fd_0._chunk_size == 1, http_fd_0._chunk_size
    assert http_fd_0._chunked == False, http_fd_0._chunked
    assert http_fd_0._closed == True, http_fd_0._closed
    assert len(http_fd_0.ctx) == 5, len(http_fd_0.ctx)
    assert http_fd_0.ctx[0] == None, http_fd_0.ctx[0]
    assert http_fd_0.ctx[1] == None, http_fd_0.ctx[1]
    assert http_fd_0.ctx[2] == 0, http_fd_0.ctx[2]

# Generated at 2022-06-26 11:28:07.703194
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd = HttpFD('test_str', -1, 0, 'test_str2', 1,
        'test_str3', 'test_str4', True, 'test_str5', {}, 'test_str6', ['test_str'])


# Generated at 2022-06-26 11:28:09.198087
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd = HttpFD()
    httpfd.testHttpFD()


# Generated at 2022-06-26 11:28:11.773208
# Unit test for constructor of class HttpFD
def test_HttpFD():
    num_0 = 1
    list_0 = [0]
    httpd_0 = HttpFD(list_0, num_0)

    return True


# Generated at 2022-06-26 11:28:13.565010
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    obj = TestHttpFD()
    assert obj.real_download("url", "file") == True


# Generated at 2022-06-26 11:28:20.622285
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print(HttpFD.real_download.__name__)
    print(test_case_0.__name__)

    # Arrange
    filename = "mock"
    info_dict = {'filename': filename}
    downloader = HttpFD(FakeYDL(), info_dict)

    # Act
    # Assert
    try:
        downloader.real_download(filename, info_dict)
    except UnavailableVideoError:
        pass


# Generated at 2022-06-26 11:28:23.257043
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(test_case_0)
    http_fd.test(1)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:28:26.119998
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd = HttpFD()
    httpfd.downloaded_bytes = 0
    httpfd.total_bytes = 0
    httpfd.tmpfilename = '-'
    httpfd.filename = '-'


# Generated at 2022-06-26 11:28:35.089207
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD.best_block_size(5, 1000, 8) == 8
    assert HttpFD.best_block_size(5, 1000, 1024) == 1024
    assert HttpFD.best_block_size(5, 1000, 1200) == 1000
    assert HttpFD.best_block_size(5, 1000, 950) == 950
    assert HttpFD.best_block_size(5, 1000, 819) == 819
    assert HttpFD.best_block_size(5, 1000, 0) == 0


# Generated at 2022-06-26 11:28:41.501735
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD(str_0, str_1, str_1)
    bool_0 = http_fd.real_download(str_0, str_1, str_0, str_1, str_1, str_1, str_1, str_0)
    if True:
        print ('unit_test', bool_0)

if __name__ == '__main__':
    test_case_0()
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:29:27.202007
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case 0
    HttpFD_0 = HttpFD()
    assert HttpFD_0.ydl is None, \
        'HttpFD() did not set ydl to None'
    assert HttpFD_0.params is None, \
        'HttpFD() did not set params to None'
    assert HttpFD_0.to_screen == std_out, \
        'HttpFD() did not set to_screen'
    assert HttpFD_0.dump_intermediate_pages == False, \
        'HttpFD() did not set dump_intermediate_pages'
    assert HttpFD_0.progress_hooks == [], \
        'HttpFD() did not set progress_hooks'


# Generated at 2022-06-26 11:29:37.387023
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Initialization
    http_fd_0 = HttpFD(YoutubeDL())
    http_fd_0.to_screen = lambda *args, **kwargs: __print_args__(*args, **kwargs)
    http_fd_0.report_destination = lambda *args, **kwargs: __print_args__(*args, **kwargs)
    http_fd_0.report_progress = lambda *args, **kwargs: __print_args__(*args, **kwargs)
    http_fd_0.report_resuming_byte = lambda *args, **kwargs: __print_args__(*args, **kwargs)
    http_fd_0.report_retry = lambda *args, **kwargs: __print_args__(*args, **kwargs)

# Generated at 2022-06-26 11:29:39.677796
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hfd_0 = HttpFD()
    hfd_0.__init__()
    test_case_0()


# Generated at 2022-06-26 11:29:42.377256
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    hfd = HttpFD()
    hfd.real_download()
    # Now call the unit test in the class of hfd, with the default parameters
    # hfd.test_real_download()


# Generated at 2022-06-26 11:29:44.462639
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    h = HttpFD()
    ret = h.real_download("URL", "filename", str_0, str_0, str_0)
    assert ret == False


# Generated at 2022-06-26 11:29:48.835461
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_HttpFD_obj = HttpFD()
    test_HttpFD_obj.test_case_0()
    return test_HttpFD_obj

if __name__ == '__main__':
    test_HttpFD_obj = test_HttpFD()
    test_HttpFD_obj.test_case_0()

# Generated at 2022-06-26 11:29:56.076241
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Testing real_download ...')

    # Setup test case for constructor
    youtube_dl_0 = youtube_dl()
    if os.path.isdir('./data'):
        shutil.rmtree('./data', True)
    shutil.copytree('../data', './data')

    httpfd_0 = HttpFD(youtube_dl_0)
    httpfd_0.params['nooverwrites'] = True
    httpfd_0.params['nocheckcertificate'] = True
    httpfd_0.params['retries'] = 3
    httpfd_0.params['buffer_size'] = 32 * 1024
    httpfd_0.params['continuedl'] = False


# Generated at 2022-06-26 11:30:07.975925
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpFD_0 = HttpFD(None)

    # Verify unknown method of class HttpFD is not implemented
    try:
        httpFD_0.unknown_method()
    except NotImplementedError:
        pass

    # Verify method 'real_download' of class HttpFD is not implemented
    try:
        pass
        # httpFD_0.real_download('unit_test', 'unit_test', None, None, None, None)
    except NotImplementedError:
        pass

    # Verify method 'try_utime' of class HttpFD is not implemented
    try:
        httpFD_0.try_utime('unit_test', 'unit_test')
    except NotImplementedError:
        pass

    # Verify method 'available' of class HttpFD is not implemented

# Generated at 2022-06-26 11:30:08.988244
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass


# Generated at 2022-06-26 11:30:11.721896
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        HttpFD()
    except:
        print("unit test for constructor of class HttpFD failed")
        return False
    return True


# Generated at 2022-06-26 11:30:56.280070
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

test_HttpFD_real_download()

# Generated at 2022-06-26 11:30:57.284983
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:31:04.138348
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    float_0 = 9.8485
    bool_0 = False
    str_0 = 'z"05=@&^]9IoE'
    http_f_d_0 = HttpFD(bool_0, str_0)
    list_0 = []
    bool_1 = False
    http_f_d_1 = HttpFD(list_0, bool_1)
    var_0 = http_f_d_1.real_download(float_0, http_f_d_0)


if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:31:07.683967
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD(True, 'hello')
    assert http_fd.params == {'nocheckcertificate': True, 'quiet': True, 'outtmpl': '%(id)s', 'noprogress': True, 'continuedl': True, 'verbose': True}
    assert http_fd.ydl == True


# Generated at 2022-06-26 11:31:09.557826
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:31:11.520075
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Running test_HttpFD_real_download...')
    test_case_0()


# Generated at 2022-06-26 11:31:17.211463
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_case_0(self):
        long_0 = 9999999999
        long_1 = 9999999999
        http_f_d_0 = HttpFD(long_0, long_1)
        long_0 = 200
        long_1 = 1
        http_f_d_1 = HttpFD(long_0, long_1)
    test_case_0(test_HttpFD)


# Generated at 2022-06-26 11:31:19.125790
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()
    print('Done')

# Generated at 2022-06-26 11:31:21.339502
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD()

if __name__ == '__main__':
    test_case_0()
    test_HttpFD()
    print('Test finished!')

# Generated at 2022-06-26 11:31:24.837272
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = True
    str_0 = 'H"05=@&^]9IoE'
    http_f_d_0 = HttpFD(bool_0, str_0)


# Build the program

# Generated at 2022-06-26 11:32:53.339826
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:55.703555
# Unit test for constructor of class HttpFD
def test_HttpFD():
    list_0 = []
    bool_0 = False
    http_f_d_0 = HttpFD(list_0, bool_0)
    return http_f_d_0.real_download()


# Generated at 2022-06-26 11:32:56.612890
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:58.836532
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:33:00.212129
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:33:01.318877
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:33:05.031603
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        str_0 = 'bI=XA<Vf3G'
        list_0 = []
        bool_0 = True
        http_f_d_0 = HttpFD(list_0, bool_0)
    except NameError as name_error:
        assert False
    except TypeError as type_error:
        assert False
    except Exception as exception:
        assert False


# Generated at 2022-06-26 11:33:07.163149
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("Test http_fd.py#HttpFD")

    #Test cases
    test_case_0()

    print("Test pass")

# Call the testing function
test_HttpFD()

# Generated at 2022-06-26 11:33:08.722955
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    for i in range(10):
        test_case_0()

# Generated at 2022-06-26 11:33:14.325715
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = False
    list_0 = []
    http_f_d_0 = HttpFD(list_0, bool_0)
    str_0 = '2QxC52_a'
    list_1 = []
    bool_1 = False
    http_f_d_1 = HttpFD(list_1, bool_1)
    var_0 = http_f_d_1.real_download(str_0, http_f_d_0)


test_HttpFD()