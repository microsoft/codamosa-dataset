

# Generated at 2022-06-26 11:26:59.237926
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

# run unit tests
if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:00.887314
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    test_case_0()

test_HttpFD()

# Generated at 2022-06-26 11:27:02.054902
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


test_HttpFD()

# Generated at 2022-06-26 11:27:04.263506
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    int_0 = None
    str_0 = ''
    http_f_d_0 = HttpFD(int_0, str_0)

    # Test case 0
    test_case_0()


# Generated at 2022-06-26 11:27:06.192774
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:09.245307
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD()

# Generated at 2022-06-26 11:27:16.767938
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    int_0 = None
    str_0 = '1235'
    http_f_d_0 = HttpFD(int_0, str_0)
    str_0 = 'a'
    int_0 = 0
    ydl_0 = YDL(int_0, str_0)
    any_0 = 0
    dict_0 = {}
    dict_0['noprogress'] = any_0
    dict_0['logger'] = ydl_0
    dict_0['simulate'] = any_0
    dict_0['progress_hooks'] = [(Any(), Any())]
    dict_0['outtmpl'] = 'a'
    dict_0['continuedl'] = any_0
    dict_0['test'] = any_0
    dict_0['noresizebuffer'] = any

# Generated at 2022-06-26 11:27:17.902564
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:25.039286
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    int_0 = None
    str_0 = 'P\x1e\x19Rz\x03p\x1c'
    http_f_d_0 = HttpFD(int_0, str_0)
    ctx = None
    int_1 = -1
    test_case_0()

    charset_0 = 'cp1251'
    bytes_0 = str_0.encode(charset_0)
    str_1 = bytes_0.decode(charset_0, 'ignore')
    http_f_d_0.real_download(ctx, int_1, str_1)


# Generated at 2022-06-26 11:27:36.386426
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_base_url = 'http://example.com/'
    test_downloader = YoutubeDL(params=dict(nooverwrites=True))
    test_downloader.params['test'] = True
    test_downloader.params['nocheckcertificate'] = True
    test_filename = os.path.join(get_temp_dir(), 'test_%(ext)s')
    test_info = {
        'id': 'test_youtube_id',
        'ext': 'mp4',
        'title': 'test video',
        'url': test_base_url,
        'upload_date': '20100101',
        'format': 'bestvideo'
    }
    test_filename = test_downloader.prepare_filename(test_info)

# Generated at 2022-06-26 11:28:22.110034
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD()
    info_dict_0 = {}
    info_dict_0 = {}
    http_f_d_0.real_download(info_dict_0, {})


# Generated at 2022-06-26 11:28:28.829986
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    path = 'test.flv'
    res = HttpFD().real_download(url, path, {'writeheader': None, 'progress_hooks': [None]})
    print(res)
    print(os.path.getsize('test.flv'))
    assert os.path.getsize('test.flv') == 2576270
    os.remove('test.flv')

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:28:32.290523
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Run unit tests if run from the commandline
    if __name__ == '__main__':
        http_f_d = HttpFD()

# Generated at 2022-06-26 11:28:36.899620
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    # http_f_d_0.retry('one')
    # http_f_d_0._real_download()

    print(http_f_d_0._TEST_FILE_SIZE)


# Generated at 2022-06-26 11:28:48.651818
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url_tup = ('http://www.youtube.com/watch?v=3q8cWY25eUA', 5, None)
    test_case_0()

# Generated at 2022-06-26 11:28:54.260747
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD()
    http_f_d_0.params['noprogress'] = False
    http_f_d_0.params['logger'] = getLogger('TestLogger')
    http_f_d_0.add_progress_hook(lambda x: None)
    http_f_d_0.add_progress_hook(lambda x: None)
    http_f_d_0.add_progress_hook(lambda x: None)
    http_f_d_0.add_progress_hook(lambda x: None)
    http_f_d_0.add_progress_hook(lambda x: None)
    http_f_d_0.add_progress_hook(lambda x: None)

# Generated at 2022-06-26 11:28:59.425568
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test if class constructor works as expected.
    # If yes, set the value of this flag to False.
    # If no, set the value of this flag to True.
    test_case_0.test_flag = True

    # Test case 0
    test_case_0()

    if test_case_0.test_flag == False:
        print("Test case 0 passed successfully")
    else:
        print("Test case 0 failed")


# Generated at 2022-06-26 11:29:01.019710
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:29:03.023925
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    assert(http_f_d_0 is not None)


# Generated at 2022-06-26 11:29:14.991921
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    unittest.TestCase.assertTrue(HttpFD().real_download({"url": "http://www.gutenberg.org/cache/epub/11/pg11.txt", "filename": "a_tale_of_two_cities.txt"}, "GET", None, None, tuple(), 0, {}, None, False, False, False, False, False, False, False, False, {}))
    unittest.TestCase.assertFalse(HttpFD().real_download({"url": "https://www.pandora.com/backend/newuser/validateUsername.do?validateNew=false&username=ytdl", "filename": "ytdl"}, "GET", None, None, tuple(), 0, {}, None, False, False, False, False, False, False, False, False, {}))


# Generated at 2022-06-26 11:30:19.516919
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert http_f_d_0 == test_case_0()

# OOP

# Generated at 2022-06-26 11:30:21.062966
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD()

# Generated at 2022-06-26 11:30:26.426930
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    assert(http_f_d_0.name == '<fdopen>')
    assert(http_f_d_0.mode == 'w')
    assert(http_f_d_0.closed == False)
    assert(http_f_d_0.newlines == None)


# Generated at 2022-06-26 11:30:38.739441
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD()
    info_dict_0 = {'title': 'test'}
    http_f_d_1 = HttpFD()
    http_f_d_2 = HttpFD()
    assert http_f_d_0.real_download(info_dict_0, 'http://www.test.com/test.test', {'test_option': True}, 'fake.test', 'test') == True
    assert http_f_d_1.real_download(info_dict_0, 'http://www.test.com/test.test', {'test_option': True}, '-', 'test') == True

# Generated at 2022-06-26 11:30:41.643595
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    # Create the class instance
    test_HttpFD_real_download()
    # Perform the unit test
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:30:43.314345
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing HttpFD constructor')
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:30:44.347277
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_1 = HttpFD()


# Generated at 2022-06-26 11:30:47.823408
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()

# Function: test
#
# Parameters:
#   argv - command arguments
#
# Return:
#   True for PASS, False for FAIL

# Generated at 2022-06-26 11:30:58.182154
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def get_destfile_name(url):
        url_basename = url_basename(url)
        destfile = 'test_files/' + url_basename
        return destfile

    def download_test_file(url):
        destfile = get_destfile_name(url)
        ydl = YoutubeDL({})
        http_f_d = HttpFD(ydl=ydl, params={})
        http_f_d.real_download(url, destfile, {}, {}, {}, {}, {})

    test_url = 'http://www.archive.org/download/ksnn_compilation_master_the_internet/ksnn_compilation_master_the_internet_512kb.mp4'
    destfile = get_destfile_name(test_url)

# Generated at 2022-06-26 11:31:06.422540
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    with mock.patch('youtube_dl.utils.scheme_re') as mock_scheme_re:
        mock_scheme_re.search = MagicMock(return_value = False)
        http_f_d = HttpFD()
        url = 'http://www.youtube.com/watch?v=dQw4w9WgXcQ'
        info = {'chunk_size': None, 'known_length': None, 'http_chunk_size': None}
        req_headers = {'Youtubedl-no-compression': 'True'}
        filename = 'dQw4w9WgXcQ'

# Generated at 2022-06-26 11:32:32.555316
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Make a test download before the main one
    http_fd_0 = HttpFD()
    ctx_0 = http_fd_0.new_ctx()
    ctx_0['url'] = 'https://curl.haxx.se/download/curl-7.71.1.tar.lz'
    ctx_0['filename'] = 'test.tar.lz'
    ctx_0['resume_len'] = 0
    ctx_0['retries'] = 0
    ctx_0['continued'] = False
    ctx_0['max_buffer_size'] = 2000000
    ctx_0['chunk_size'] = 1024
    ctx_0['ratelimit'] = 0
    ctx_0['noresizebuffer'] = False

# Generated at 2022-06-26 11:32:34.834264
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_HttpFD_real_download_0()
    test_HttpFD_real_download_1()
    test_HttpFD_real_download_2()
    test_HttpFD_real_download_3()

# Test for real_download

# Generated at 2022-06-26 11:32:38.649953
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD()
    result = http_f_d_0.real_download('http://www.youtube.com/watch?v=J---aiyznGQ', None, None)
    print(result)


# Generated at 2022-06-26 11:32:39.485276
# Unit test for constructor of class HttpFD
def test_HttpFD(): test_case_0()



# Generated at 2022-06-26 11:32:43.348000
# Unit test for constructor of class HttpFD
def test_HttpFD():
    '''
    Test constructor of class HttpFD
    '''
    http_f = HttpFD()
    assert http_f.ydl is not None, 'HttpyFD class instance should have ydl member'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:32:46.069978
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()
    print('Tests finished')

# Generated at 2022-06-26 11:32:48.598013
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('test_HttpFD')
    test_case_0()
    print('test_HttpFD done')


# Generated at 2022-06-26 11:32:56.613829
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert_raises(TypeError, HttpFD, None)
    # HttpFD('-') raises an exception of different type.
    # assert_raises(TypeError, HttpFD, '-')
    assert_raises(TypeError, HttpFD, object())
    assert_raises(TypeError, HttpFD, [])
    assert_raises(TypeError, HttpFD, {})
    assert_raises(TypeError, HttpFD, '', 'w+')
    test_case_0()

if __name__ == "__main__":
    raise SystemExit(subprocess.call([sys.executable, "-m", "unittest", "youtube_dl.postprocessor.http_fd"]))

# Generated at 2022-06-26 11:33:02.090910
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test with 0 fragment
    ret = get_test_path().append('data', 'http_fragment_0.info.json').read_bytes().decode('utf-8')
    info = json.loads(ret)
    f = HttpFD()
    assert f.get_test_cases() == [test_case_0]
    f.params['test'] = True
    f.real_download(info)


# Generated at 2022-06-26 11:33:09.851227
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import sys
    import tempfile
    import shutil
    import locale

    class TestContextManager(object):
        def __init__(self, value):
            self.value = value
        def __enter__(self):
            return self.value
        def __exit__(self, exc_type, exc_value, traceback):
            pass

    class Context(object):
        stream = None
        tmpfilename = None
        filename = None
        open_mode = 'wb'
        chunk_size = 0
        block_size = 1024*1024
        resume_len = 0
        data_len = None
        is_resume = False
        start_time = 0
        has_range = False
        def __enter__(self):
            self.start_time = time.time()
            return self