

# Generated at 2022-06-26 11:26:56.644831
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    file_dict = {
        'url': 'http://www.sample-videos.com/audio/mp3/crowd-cheering.mp3',
        'format': 'mp3',
        'format_id': 'mp3',
        'ext': 'mp3',
    }
    downloader = HttpFD(file_dict, 0)
    result = downloader.real_download(test=True)
    assert_equals(result, True)

if __name__ == "__main__":
    import nose
    nose.main()

# Generated at 2022-06-26 11:27:03.856465
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD('5U6NxS6_JUg', 4175)
    # Run tests
    assert http_f_d_0.real_download('5U6NxS6_JUg', 4175) is True

if __name__ == '__main__':
    test_case_0()
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:05.844968
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:08.946257
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    HttpFD.real_download(False, False, False, False, False, False, False, False)


# Generated at 2022-06-26 11:27:10.879185
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # TODO: add proper tests
    #test_case_0()
    print('***********************')
    print('Test #0 is not implemented')
    print('***********************')
    print('')

# Generated at 2022-06-26 11:27:12.729121
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD()

# Generated at 2022-06-26 11:27:19.726241
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    dict_0 = {'test_dir':''}
    int_0 = 2854
    http_f_d_0 = HttpFD(dict_0, int_0)
    str_0 = 'http://video.google.com/videoplay?docid=-9050474362583451279#'
    str_1 = '-'
    dict_1 = {}
    bool_0 = http_f_d_0.real_download(str_0, str_1, dict_1)

# Generated at 2022-06-26 11:27:20.745399
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:23.990062
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """httpfd.TestCase_0"""
    test_case_0()

if __name__ == '__main__':
    # __package__ = 'httpfd'
    # import inspect
    # print(inspect.getsource(httpfd))
    test_HttpFD()

# Generated at 2022-06-26 11:27:30.256991
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:28:10.910780
# Unit test for constructor of class HttpFD
def test_HttpFD():
    obj_0 = HttpFD(None, None, {})


# Generated at 2022-06-26 11:28:15.658039
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing constructor of class HttpFD')
    test_HttpFD = HttpFD(1)
    test_HttpFD.__init__
    assert test_HttpFD._fd == 1
    assert test_HttpFD._length == None
    assert test_HttpFD._pos == None
    assert test_HttpFD._info == None


# Generated at 2022-06-26 11:28:17.945931
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    httpFD_0 = HttpFD("", "", {})
    test_case_0()
    return ok(0, 0)


# Generated at 2022-06-26 11:28:28.079322
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    downloader = Youtubedl()
    downloader.params = {'test': True,}
    downloader.report_warning = mock.Mock()
    downloader.report_retry = mock.Mock()
    downloader.report_error = mock.Mock()
    downloader.to_screen = mock.Mock()
    downloader.to_stderr = mock.Mock()
    downloader.report_file_already_downloaded = mock.Mock()
    downloader.report_resuming_byte = mock.Mock()
    downloader.report_unable_to_resume = mock.Mock()
    downloader.report_destination = mock.Mock()
    downloader.best_block_size = mock.Mock()
    downloader.calc_speed = mock.Mock

# Generated at 2022-06-26 11:28:36.337687
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Declare objects
    obj_0 = HttpFD(obj_45, obj_44)

    # Print test case number and description
    print("Test Case 0:")
    test_case_0()

    # Print description and number of test cases
    print("\nNumber of test cases ran: 0")
    
#main
if __name__ == '__main__':
    # Run test case
    test_HttpFD_real_download()
    

#end

# Generated at 2022-06-26 11:28:41.681731
# Unit test for constructor of class HttpFD
def test_HttpFD():
    deobfuscate_hs(test_case_0)
    test_case_0()
    fd = HttpFD(
        'https://www.youtube.com/v/8djQux0AuQM&autoplay=1', {'noprogress': True}, '-', None, None)
    print('trying to find info')
    fd.get_info()
    print('done')


# Generated at 2022-06-26 11:28:54.953558
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD(None, {'nooverwrites': False}, None, None)
    http_fd.to_screen = test_case_0
    http_fd.report_destination = test_case_0
    http_fd.report_retry = test_case_0
    http_fd.report_error = test_case_0
    http_fd.report_resuming_byte = test_case_0
    http_fd.report_unable_to_resume = test_case_0
    http_fd.report_file_already_downloaded = test_case_0
    http_fd._hook_progress = test_case_0
    http_fd.sanitize_open = sanitize_open
    http_fd.slow_down = test_case_0
    http_fd

# Generated at 2022-06-26 11:29:02.364698
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:29:13.682943
# Unit test for constructor of class HttpFD
def test_HttpFD():
    const_0 = 'http://v.youku.com/v_show/id_XMzk5ODcxNjg0.html'
    const_1 = urlopen
    const_2 = 'GET'

# Generated at 2022-06-26 11:29:16.085909
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Local test, disabled
    # HttpFD(test_case_0, '%s/t.srt')
    return True


# Generated at 2022-06-26 11:29:50.242049
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:29:51.326542
# Unit test for constructor of class HttpFD
def test_HttpFD():
    tmp = HttpFD()


# Generated at 2022-06-26 11:29:55.099498
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = YoutubeDL()
    ydl.fd = HttpFD.get_fd(url, ydl)
    ydl.fd.preload()


# Generated at 2022-06-26 11:30:06.966542
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Set up test objects
    ydl = YoutubeDL()

# Generated at 2022-06-26 11:30:17.539380
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("test_HttpFD:")
    # Testing byte range requests

# Generated at 2022-06-26 11:30:25.045153
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL({})
    url = 'http://localhost:8080/1.flv'
    data = compat_urllib_request.urlopen(url)
    headers = {'Referer': 'http://www.youtube.com/'}
    http_fd = HttpFD(ydl, url, {'http_headers': headers, 'test': True})
    http_fd.process_info({'name': '1.flv'})
    http_fd.try_retrieve(data, headers, False)


# Generated at 2022-06-26 11:30:37.464421
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Setup
    test_case_0()

    http_fd = HttpFD(object, {})

    assert isinstance(http_fd, Downloader)
    assert hasattr(http_fd, 'report_retry')
    assert hasattr(http_fd, 'retry')
    assert hasattr(http_fd, '_do_download')
    assert hasattr(http_fd, 'to_screen')
    assert hasattr(http_fd, 'report_error')
    assert hasattr(http_fd, 'report_unable_to_resume')
    assert hasattr(http_fd, 'report_resuming_byte')
    assert hasattr(http_fd, 'report_destination')
    assert hasattr(http_fd, 'best_block_size')

# Generated at 2022-06-26 11:30:42.619836
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Testing real_download...')

    # Setup test case
    test_case_0()

    # Unit test
    try:
        # Set argument
        proxy = None
        # Call the method
        HttpFD.real_download(proxy)
    except:
        # Print error message and exit
        e = sys.exc_info()[1]
        print('Exception occurred: %s' % str(e))
        sys.exit(1)



# Generated at 2022-06-26 11:30:44.988146
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD({'noprogress': 'True'}, 'http://127.0.0.1/download.pdf', 'w')
    assert http_fd != None


# Generated at 2022-06-26 11:30:50.759225
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    httpFD = HttpFD()
    url = 'http://www.download.com/file'
    params = {}
    filename = 'temp'
    info_dict = {}
    httpFD.real_download(url, params, filename, info_dict)
    if filename == httpFD.params['outtmpl']:
        test_case_0()


# Generated at 2022-06-26 11:31:48.228414
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # Make sure bool_0 is False
    test_case_0()

    # Create an object of class HttpFD
    obj_0 = HttpFD()

    # Call the class's method on the given parameters
    obj_0.real_download(None, None, None, None, None, None, None)

    # Test case passed
    print('Passed test case: test_HttpFD_real_download')


# Generated at 2022-06-26 11:31:49.323928
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Dummy main

# Generated at 2022-06-26 11:32:01.054175
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing constructor for class HttpFD:')

    url = 'http://www.google.pl'
    params = {
        'noprogress': False,
        'logtostderr': False,
        'quiet': False,
        'no_warnings': False,
        'default_search': 'auto',
        'source_address': None
    }
    ydl = YoutubeDL(params)

    t0 = time.time()
    t1 = int(round(t0 * 1000))
    t2 = int(math.floor(t0))

    # Test case #0

# Generated at 2022-06-26 11:32:11.172143
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    global tmpfilename
    global info_dict
    global args
    global open_mode
    global byte_counter
    global filename
    global is_test
    global block_size
    global is_resume
    global data_len
    global resume_len
    global url
    global data
    global stream
    global has_range
    global start
    global ctx
    global retries
    global count
    global slow_down
    global best_block_size
    global calc_speed
    global calc_eta
    global try_rename
    global try_utime
    global writewarning
    global hook_progress
    global hook_download_pause
    global to_screen
    global encrypt_filename
    global report_destination
    global report_file_already_downloaded
    global report_unable_to_res

# Generated at 2022-06-26 11:32:14.631021
# Unit test for constructor of class HttpFD
def test_HttpFD():
    start_time = 0
    params = {'noprogress': True, 'quiet': True, 'ratelimit': '1K'}
    retries = 0
    ydl = 'None'

    test_obj = HttpFD(start_time, params, retries, ydl)
    return test_obj


# Generated at 2022-06-26 11:32:19.364555
# Unit test for constructor of class HttpFD
def test_HttpFD():
    global _http_fd
    _http_fd = HttpFD()
    assert _http_fd.__class__.__name__ == "HttpFD"


# Generated at 2022-06-26 11:32:21.119101
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd_0 = HttpFD(0)


# Generated at 2022-06-26 11:32:26.734583
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import unittest
    import ytdl
    from tests import YdlTestCase

    # Case with url: https://www.youtube.com/watch?v=jNQXAC9IVRw
    class TestRealDownload(YdlTestCase):

        def test_real_download(self):
            pass

    if __name__ == '__main__':
        unittest.main()



# Generated at 2022-06-26 11:32:34.911613
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    httpfd_0 = HttpFD()
    httpfd_0.report_retry = lambda x, y, z: None
    test_case_0()
    udinfo_0 = {'url': 'http://www.example.com/', 'filename': 'abc.abc', 'info_dict': {'ext': 'abc'}, 'resume_len': 0, 'add_header': {}, 'test': False, 'http_chunk_size': 10485760, 'params': {'cachedir': False}, 'cookies': None, 'nocheckcertificate': False, 'headers': {}, 'random_headers': False, 'http_headers': {}}
    urlopen_0 = None
    compat_urllib_error_0 = None
    sanitized_Request_0 = None
    ctx_0 = DownloadContext

# Generated at 2022-06-26 11:32:43.974659
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD()
    assert http_fd.ydl != None
    assert http_fd.params != None
    assert http_fd.to_screen!= None
    assert http_fd.to_stderr != None
    assert http_fd.get_infos() == None
    assert http_fd.calc_eta != None
    assert http_fd.calc_speed != None
    assert http_fd.check_downloaded() == False
    assert http_fd.best_block_size != None
    assert http_fd.slow_down() == None
    assert http_fd.report_retry() == None
    assert http_fd.report_error() == None
    assert http_fd.report_resuming_byte() == None

# Generated at 2022-06-26 11:33:59.716810
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case

    def test_case_0():
        bytes_0 = b'\x1a\x90\x4a\x0f'
        str_0 = '?YF?>D??\u007f\u0011'
        str_1 = 'I@Hd?\x7f\x16\u0011\x16'
        dict_0 = {str_1: str_1, str_1: str_1}
        http_f_d_0 = HttpFD(str_1, dict_0)
        var_0 = http_f_d_0.real_download(bytes_0, str_0)

    test_case_0()



# Generated at 2022-06-26 11:34:00.826651
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:34:02.792390
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd_0 = HttpFD('label_0', 'params_0')


# Generated at 2022-06-26 11:34:09.422886
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'v'
    str_1 = 'j=P(b>|T:T6'
    dict_0 = {str_1: str_1, str_1: str_1}
    http_f_d_0 = HttpFD(str_1, dict_0)
    assert (dict_0 is http_f_d_0.ydl.params)
    assert (http_f_d_0.use_curl == False)
    assert (http_f_d_0.ydl.params.get('test') is None)


# Generated at 2022-06-26 11:34:10.340065
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:34:16.098187
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'eR'
    str_1 = '?O?A'
    var_1 = os.path.join(str_0, str_1)
    dict_0 = {str_1: str_1, str_1: str_1}
    http_f_d_0 = HttpFD(var_1, dict_0)
    var_0 = http_f_d_0.para
    print(var_0)


# Generated at 2022-06-26 11:34:20.986155
# Unit test for constructor of class HttpFD
def test_HttpFD():
    reg_0 = r'[a-z]'
    http_f_d_0 = HttpFD(str_1)
    dict_1 = http_f_d_0.retries
    dict_2 = http_f_d_0.params
    dict_3 = http_f_d_0.ydl
    dict_4 = http_f_d_0.chunk_size
    dict_5 = http_f_d_0.block_size
    dict_6 = http_f_d_0.fragment_index


# Generated at 2022-06-26 11:34:28.550124
# Unit test for constructor of class HttpFD
def test_HttpFD():
    dict_0 = {'user-agent': 'youtube-dl'}
    http_f_d_0 = HttpFD('https://www.youtube.com/watch?v=aM3q6LVuU6c', dict_0)
    assertEqual(http_f_d_0.ydl, None)
    assertEqual(http_f_d_0.url, 'https://www.youtube.com/watch?v=aM3q6LVuU6c')
    assertEqual(http_f_d_0.parsed_url, {'scheme': 'https', 'netloc': 'www.youtube.com', 'path': '/watch', 'params': '', 'query': 'v=aM3q6LVuU6c', 'fragment': ''})

# Generated at 2022-06-26 11:34:39.908244
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing constructor for class HttpFD')
    bytes_0 = b'\xa3\xa5\xde\x8c'
    str_0 = 'fJ'
    str_1 = '?A?v)!@&Oo'
    dict_0 = {str_1: str_1, str_1: str_1}
    http_f_d_0 = HttpFD(str_1, dict_0)
    assert(http_f_d_0.ydl.params['ydl_http_proxy'] == str_1)
    assert(http_f_d_0.ydl.params['ydl_http_basic_auth'] == dict_0)
    var_0 = http_f_d_0.real_download(bytes_0, str_0)

# Generated at 2022-06-26 11:34:40.610891
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
