

# Generated at 2022-06-26 11:27:00.518529
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

test_HttpFD()

# Generated at 2022-06-26 11:27:02.125097
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert test_case_0() == 0
    return 0


# Generated at 2022-06-26 11:27:06.907962
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print(os.getcwd())
    try:
        HttpFD.real_download('https://www.youtube.com/watch?v=5qap5aO4i9A', HttpFD.params)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 11:27:10.231710
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("Testing constructor of class HttpFD")
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:11.690180
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # test case 0
    test_case_0()


# Generated at 2022-06-26 11:27:12.729960
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:20.097828
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    float_0 = -108.302931
    float_1 = -108.302931
    http_f_d_0 = HttpFD(float_0, float_1)

    assert http_f_d_0.real_download('http://www.youtube.com/get_video_info?video_id=xqW6xBwn6Lk') == True
    
    
# Execution
if __name__ == '__main__':
    test_case_0()
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:21.540743
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case 0
    yield test_case_0


# Generated at 2022-06-26 11:27:22.521695
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:23.757179
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case 0
    test_case_0()
    pass


# Generated at 2022-06-26 11:28:11.534353
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    http_f_d_0 = HttpFD(bool_0, dict_0)

    # Unit test for the method 'real_download'
    set_0 = None
    bytes_0 = b'\x06\xfdO\xd1\xd6\x16\xc6\x90'
    bool_1 = True
    dict_1 = {bool_1: bool_1, bool_1: bool_1}
    http_f_d_0 = HttpFD(bool_1, dict_1)
    var_0 = http_f_d_0.real_download(set_0, bytes_0)

    # Unit test for the method '_processed_size_now'
   

# Generated at 2022-06-26 11:28:13.739603
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('[UT] Running test for method real_download of class HttpFD')
    test_case_0()


# Generated at 2022-06-26 11:28:15.021678
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:28:17.724034
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    print(http_f_d_0.p)

test_HttpFD()
test_case_0()

# Generated at 2022-06-26 11:28:19.599775
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Unit tests for class HttpFD

# Generated at 2022-06-26 11:28:28.824878
# Unit test for constructor of class HttpFD
def test_HttpFD():
    set_0 = None
    bytes_0 = b'\x06\xfdO\xd1\xd6\x16\xc6\x90'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    http_f_d_0 = HttpFD(bool_0, dict_0)

    # Check fields of created object
    if set_0 is not http_f_d_0.params:
        raise Exception("Expected field 'params' of created object to be set_0, but got %s" % str(http_f_d_0.params))


# Generated at 2022-06-26 11:28:32.290789
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    print("Unit test HttpFD done")


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:28:33.517774
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert test_case_0() == True

# Generated at 2022-06-26 11:28:40.934885
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    set_0 = None
    bytes_0 = b'\x06\xfdO\xd1\xd6\x16\xc6\x90'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    http_f_d_0 = HttpFD(bool_0, dict_0)
    var_0 = http_f_d_0.real_download(set_0, bytes_0)
    assert var_0 == True


# Generated at 2022-06-26 11:28:49.537499
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    set_0 = None
    bytes_0 = b'\x06\xfdO\xd1\xd6\x16\xc6\x90'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    http_f_d_0 = HttpFD(bool_0, dict_0)
    var_0 = http_f_d_0.real_download(set_0, bytes_0)
    assert var_0 == True


# Generated at 2022-06-26 11:29:50.880889
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:29:51.599192
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    test_case_0()


# Generated at 2022-06-26 11:29:53.939546
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD('filename', 'url')
    return http_f_d_0.ydl is not None


# Generated at 2022-06-26 11:29:55.841463
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:30:06.614919
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = True
    http_fd_0 = HttpFD(bool_0, bool_0)
    print(http_fd_0)

if __name__ == '__main__':
    set_0 = None
    bytes_0 = b'\x06\xfdO\xd1\xd6\x16\xc6\x90'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    http_f_d_0 = HttpFD(bool_0, dict_0)
    test_HttpFD()
    var_0 = http_f_d_0.real_download(set_0, bytes_0)

# Generated at 2022-06-26 11:30:14.091285
# Unit test for constructor of class HttpFD
def test_HttpFD():
    set_0 = None
    bytes_0 = b'\x06\xfdO\xd1\xd6\x16\xc6\x90'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    http_f_d_0 = HttpFD(bool_0, dict_0)
    assert not http_f_d_0.is_test
    assert isinstance(http_f_d_0.ydl, Ydl)


# Generated at 2022-06-26 11:30:15.159004
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:30:15.851511
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:30:17.035176
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print("Testing real_download method of class HttpFD")
    test_case_0() # testing not implemented yet
    print("Success!")


# Generated at 2022-06-26 11:30:18.011775
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:32:31.933233
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass
    # TODO: Implement test: test_HttpFD_real_download


# Generated at 2022-06-26 11:32:32.891504
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:34.573309
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    print('Unit test for method real_download of class HttpFD complete.')


# Generated at 2022-06-26 11:32:35.898730
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Function: constructor')
    print('Param 0')
    test_case_0()


# Generated at 2022-06-26 11:32:37.101397
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Unit tests for class F4mFD


# Generated at 2022-06-26 11:32:39.550245
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD(True, {True: True, True: True})


# Generated at 2022-06-26 11:32:40.365939
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # test case 0
    test_case_0()

# Generated at 2022-06-26 11:32:47.180194
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert isinstance(HttpFD({}, b''), HttpFD)
    assert isinstance(HttpFD(False, {}), HttpFD)
    assert isinstance(HttpFD(False, {}), HttpFD)
    assert isinstance(HttpFD(False, {True: True, False: False}), HttpFD)
    assert isinstance(HttpFD(False, {False: True, True: False}), HttpFD)


# Generated at 2022-06-26 11:32:49.325350
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print("Executing test: test_HttpFD_real_download")
    test_case_0()
    print("Success test: test_HttpFD_real_download")


# Generated at 2022-06-26 11:32:50.232522
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

