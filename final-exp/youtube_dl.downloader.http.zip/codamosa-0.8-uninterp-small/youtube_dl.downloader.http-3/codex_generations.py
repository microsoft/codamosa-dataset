

# Generated at 2022-06-26 11:26:57.102201
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    set_proxy()
    set_socket()

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    
    logger.info('Test case passed')


# Generated at 2022-06-26 11:27:01.597631
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Setup
    str_0 = 'Q95ko'
    http_f_d_0 = HttpFD(str_0, str_0)


# Generated at 2022-06-26 11:27:03.646770
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_decorator(test_case_0)


# Generated at 2022-06-26 11:27:04.736061
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

# Generated at 2022-06-26 11:27:05.894666
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:07.084333
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:27:10.008937
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:11.842415
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD()

# Generated at 2022-06-26 11:27:22.090290
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    try:
        str_0 = 'http://download.thinkbroadband.com/5MB.zip'
        str_1 = '5MB.zip'
        user_agent_0 = 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
        http_f_d_0 = HttpFD(str_0, str_1, user_agent_0)
        assert (not (http_f_d_0 is None))
    except:
        assert False


# Generated at 2022-06-26 11:27:25.370195
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD('http://www.youtube.com/watch?v=BaW_jenozKc', 'test.mp4')
    http_f_d_0.real_download({'test': True})

test_HttpFD_real_download()
test_case_0()

# Generated at 2022-06-26 11:28:08.205697
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd_0 = HttpFD()
    fd_0.real_download('http://youtube.com','/home/user/youtubedl/tmp/youtube.com.part')
    assert str_0
    test_case_0()


# Generated at 2022-06-26 11:28:18.828053
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert test_HttpFD.__name__ == '__main__'

    from youtube_dl.extractor.generic import GenericIE
    from youtube_dl.downloader.http_head_downloader import HttpHeadDownloader
    from youtube_dl.downloader.http_fd import HttpFD
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import UnavailableVideoError
    from youtube_dl.utils import RegexNotFoundError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import GeoRestrictedError
    from youtube_dl.compat import compat_urllib_request
    from pytest import raises

    # Test for the constructor of the class HttpFD with input URL that
    # raises an error (UnavailableVideoError) when trying to get the
    # length via HEAD request
   

# Generated at 2022-06-26 11:28:22.582953
# Unit test for constructor of class HttpFD
def test_HttpFD():
    object_1 = HttpFD({}, {'noprogress': True}, 'http://example.com/sample.mp4', None, None, None)
    assert isinstance(object_1, HttpFD)


# Generated at 2022-06-26 11:28:24.490900
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if test_case_0():
        print('Test case 0 [passed]')


# Generated at 2022-06-26 11:28:31.366488
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if test_case_0() == 'Test case passed':
        print("Passed test case 0")
    else:
        # [last_path, filename] = os.path.split(locals()[cur_frame.f_code.co_name].c_filename)
        raise AssertionError("Test case 0 failed")
    

if __name__ == '__main__':
    test_HttpFD_real_download()

 
    # real_download = resolve_member(YoutubeDL, 'real_download')
    # real_download = resolve_member(YoutubeDL, '_real_extract_YoutubeDL')
    # if real_download == None:
    #     print("real_download not found")
    # else:
    #     print("real_download found - result: " + str(real_download()

# Generated at 2022-06-26 11:28:34.097171
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for case str_0
    _test_HttpFD()
    if ('FAIL'):
        raise Exception('Test failed')



# Generated at 2022-06-26 11:28:39.154961
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    hfd = HttpFD(None, None, None, None, None)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()


# Generated at 2022-06-26 11:28:40.764368
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'Test case passed'


# Generated at 2022-06-26 11:28:52.542674
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # setup
    test_case = 0
    HttpFD_obj = HttpFD(0, 0, 0, None, None)
    try:
        # this is a test case for bug in file download.
        HttpFD_obj.real_download("http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4", "output")
        test_case += 1
    except Exception as e:
        print("{0} encountered an exception: {1}".format("HttpFD_obj.real_download", e))


# Generated at 2022-06-26 11:29:01.747456
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:29:42.953654
# Unit test for constructor of class HttpFD
def test_HttpFD():
    set_0 = {'X|S79H~<(O\x0f'}
    str_0 = '7l`bpP5KV7A'
    http_f_d_0 = HttpFD(set_0, str_0)
    int_0 = 1437679032
    bool_0 = False
    http_f_d_0.real_download(bool_0, int_0)
    var_0 = http_f_d_0.fd
    var_1 = http_f_d_0.download_retcode
    var_2 = http_f_d_0.last_effective_url
    var_3 = http_f_d_0.filename
    var_4 = http_f_d_0.headers
    var_5 = http_f_d_0.tmp

# Generated at 2022-06-26 11:29:43.741563
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert "HttpFD"


# Generated at 2022-06-26 11:29:53.400646
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    suite = unittest.TestSuite()
    suite.addTest(unittest.FunctionTestCase(test_case_0))
    runner = unittest.TextTestRunner()
    runner.run(suite)


# Generated at 2022-06-26 11:29:54.431026
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:29:56.035477
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

test_HttpFD_real_download()

# Generated at 2022-06-26 11:29:57.198751
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:29:58.591577
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:30:05.958821
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_2 = '<\tB=!D@<1tI~G\x0b'
    set_1 = {str_2}
    str_3 = '\x0b49\x0b\x0b\x0b\x0b\x0b\x0b\x0b'
    http_f_d_1 = HttpFD(set_1, str_3)
    assert http_f_d_1 != None


# Generated at 2022-06-26 11:30:07.887763
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:30:08.900928
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Function main

# Generated at 2022-06-26 11:31:25.906727
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Testing method real_download of class HttpFD.')

    print('\nTesting phase 0, with parameters: False, 1437679032.')
    test_case_0()

    print('\nTesting completed.')


if __name__ == "__main__":
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:31:28.749151
# Unit test for constructor of class HttpFD
def test_HttpFD():
    set_0 = {'ytdl.filesize'}
    str_0 = '../test/test.mkv'
    http_f_d_0 = HttpFD(set_0, str_0)
    test_case_0()


# Generated at 2022-06-26 11:31:29.961724
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0() # normal

test_HttpFD_real_download()

# Generated at 2022-06-26 11:31:31.678006
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:31:38.802969
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = '7/z/P>oV}&/dv'
    set_0 = {str_0}
    str_1 = 'r`f\x0f\x0e\x0f\x0e\x0e\x0f\x0e\x0f\x0e\x0e'
    http_f_d_0 = HttpFD(set_0, str_1)
    assert http_f_d_0
    assert http_f_d_0._hook_progress
    assert http_f_d_0._TEST_FILE_SIZE



# Generated at 2022-06-26 11:31:48.289984
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:31:50.617400
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    assert True


# Generated at 2022-06-26 11:31:52.993596
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == "__main__":
    test_HttpFD()

# Generated at 2022-06-26 11:31:56.121601
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
	# Unit testing for the class HttpFD
    test_HttpFD()

# Generated at 2022-06-26 11:31:59.981211
# Unit test for constructor of class HttpFD
def test_HttpFD():
    set_0 = {'fLKjJ;2~x'}
    str_0 = ':~[&hK7f+L=g?'
    http_f_d_0 = HttpFD(set_0, str_0)


# Generated at 2022-06-26 11:35:04.667091
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:35:05.626377
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:35:12.513667
# Unit test for constructor of class HttpFD
def test_HttpFD():
    set_0 = {'\twM)R\x01#\x01PQE\x05'}
    str_0 = 'K1vI'
    http_f_d_1 = HttpFD(set_0, str_0)


# Generated at 2022-06-26 11:35:17.023601
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD({})
    if http_f_d_0.params['noprogress'] == False:
        print('WARNING: assert failed')



# Generated at 2022-06-26 11:35:17.634089
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert test_case_0() == None

# Generated at 2022-06-26 11:35:19.053536
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:35:20.412031
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:35:26.439279
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bool_0 = False
    set_0 = {'@Y&Gw&?\r\tV'}
    str_0 = 'Z:)8`G<[;5Gd\r{id1OK'
    http_f_d_0 = HttpFD(set_0, str_0)
    assert isinstance(http_f_d_0, HttpFD)
    test_case_0()

test_HttpFD()

# Generated at 2022-06-26 11:35:33.133232
# Unit test for constructor of class HttpFD
def test_HttpFD():
    set_0 = {"@Y&Gw&?\r\tV"}
    str_0 = 'Z:)8`G<[;5Gd\r{id1OK'
    htfd_0 = HttpFD(set_0, str_0)
    assert type(htfd_0) == HttpFD


# Generated at 2022-06-26 11:35:36.066216
# Unit test for constructor of class HttpFD
def test_HttpFD():
    set_0 = set()
    str_0 = ''
    http_f_d_0 = HttpFD(set_0, str_0)
    assert(http_f_d_0.ydl is not None)
