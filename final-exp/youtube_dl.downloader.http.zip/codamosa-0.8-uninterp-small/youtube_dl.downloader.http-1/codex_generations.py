

# Generated at 2022-06-26 11:26:58.759941
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url_0 = 'https://sh.st/st/e1e03b0efb9a85b746ca05f8e0cbb99a/pornhub.com_solo_naked_and_masturbating_in_hotel_room_with_amazing_booty_by_booty_lovers.mp4.mp4'
    filename_0 = '/tmp/sh.st_e1e03b0efb9a85b746ca05f8e0cbb99a_pornhub.com_solo_naked_and_masturbating_in_hotel_room_with_amazing_booty_by_booty_lovers.mp4.mp4'
    int_1 = 24
    dict_0 = {}

# Generated at 2022-06-26 11:27:04.691828
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    int_0 = -451
    str_0 = ']0JI/\\eV\t3|?)EyQI2'
    http_f_d_0 = HttpFD(int_0, str_0)
    http_f_d_0.real_download(int_0, str_0, str_0, int_0, int_0)


# Generated at 2022-06-26 11:27:16.435392
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    int_0 = 312
    str_0 = 's>D:Rn\rgV7zT6T3q6olQN6'
    http_f_d_0 = HttpFD(int_0, str_0)
    # str_1 = 'R"%c;Oj{&F0]A5C:P5"tP!2gfjGtb'
    # str_2 = 'Y_W\\J\\>`h1~[I\x0e4W'
    # str_3 = 'C\x0c!\n'
    # str_4 = '\x0e&\x0f6'
    # int_1 = 5
    # y_t_f_d_0 = YTFD(str_1, str_2, str_3, str_4

# Generated at 2022-06-26 11:27:17.951542
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Tests whether constructor returns a value
    test_case_0()


# Generated at 2022-06-26 11:27:19.773689
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('* test constructor of class HttpFD')
    test_case_0()


# Generated at 2022-06-26 11:27:21.221744
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    assert False # TODO: implement your test here


# Generated at 2022-06-26 11:27:23.162215
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("Testing constructor of class HttpFD")
    test_case_0()
    print("Testing constructor of class HttpFD finished")


# Generated at 2022-06-26 11:27:29.274229
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Parameters
    http_f_d_0 = HttpFD(-451, ']0JI/\\eV\t3|?)EyQI2')
    # Fields initialization
    int_0 = http_f_d_0.status
    str_0 = http_f_d_0.url
    assert(int_0 == -451 and str_0 == ']0JI/\\eV\t3|?)EyQI2')



# Generated at 2022-06-26 11:27:38.901766
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    int_0 = -7272
    str_0 = 'Vx\x1d\'$T\rD\x0cE'
    http_f_d_0 = HttpFD(int_0, str_0)
    int_1 = -273
    str_1 = '\x0bwb-8V|SDs3x\x1dg'
    http_f_d_1 = HttpFD(int_1, str_1)
    str_2 = '\x0f\x1d_\x1b\x02\tC'
    str_3 = '5K5YY\x18\x1a\x1a\x0f'

# Generated at 2022-06-26 11:27:40.248151
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:28:15.116560
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:28:17.808451
# Unit test for constructor of class HttpFD
def test_HttpFD():
    var_0 = HttpFD(params={'http_chunk_size': 1048576})
    assert var_0.params['http_chunk_size'] == 1048576



# Generated at 2022-06-26 11:28:27.915564
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = '* test real_download() of class HttpFD'
    var_0 = print(str_0)
    # Test 0
    # test constructor of class HttpFD
    str_0 = '  test case 0'
    var_0 = print(str_0)
    str_0 = '{'
    var_0 = print(str_0)
    str_0 = '    \'outtmpl\': \'%(id)s\','
    var_0 = print(str_0)
    str_0 = '    \'quiet\': True,'
    var_0 = print(str_0)
    str_0 = '}'
    var_0 = print(str_0)
    var_1 = test_case_0()
    # Test 1
    # test real_download() of class H

# Generated at 2022-06-26 11:28:36.199306
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = '* test constructor of class HttpFD'
    var_0 = print(str_0)
    str_1 = '** HttpFD w/o options'
    var_1 = print(str_1)
    var_2 = HttpFD()
    str_3 = '** HttpFD w/ options'
    var_3 = print(str_3)
    var_4 = HttpFD(params={'test':'test'})


# Generated at 2022-06-26 11:28:37.149067
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()



# Generated at 2022-06-26 11:28:42.072024
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = '* test real_download of class HttpFD'
    var_0 = print(str_0)
    list_0 = ['http://s.ytimg.com/yts/jsbin/html5player-vflW8jV3C/html5player.js']
    var_1 = None
    var_2 = test_HttpFD_download_with_resume(list_0, var_1)


# Generated at 2022-06-26 11:28:44.954916
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

# Single unit test for HttpFD
if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:28:47.264994
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Unit test for method real_download of class HttpFD
    """
    pytube.HttpFD.test_case_0()
    pytube.HttpFD.test_unit_real_download_0()


# Generated at 2022-06-26 11:28:57.257176
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = '* test constructor of class HttpFD'
    var_0 = print(str_0)

    f = HttpFD("GET", "http://www.google.com", {})
    f.read(4)
    f.read(4)
    f.read(4)
    f.read(4)
    f.close()

    f = HttpFD("GET", "http://www.google.com", {})
    var_1 = f.read(4)
    var_2 = f.read(4)
    var_3 = f.read(4)
    var_4 = f.read(4)
    f.close()


# Generated at 2022-06-26 11:29:01.667492
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Run the unit test
    test_case_0()

# Main entry point
if __name__=='__main__':
    # Execute the unit test
    test_HttpFD()

# Generated at 2022-06-26 11:29:43.032092
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = '\n    Unit test for method real_download of class HttpFD\n    '
    if 'Linux' in platform.platform():
        # This test fails on Travis
        return
    def test_hook(d):
        # type: (Dict[str, Any]) -> None
        str_1 = '\n        This is a test hook for method real_download of class YoutubeDL\n        '
        test_dict = {'downloaded_bytes': 0, 'filename': None, 'total_bytes': None, 'status': 'downloading'}
        if d['status'] == 'downloading':
            assert d['filename'] is None
            assert d['total_bytes'] is None
            assert d['downloaded_bytes'] > test_dict['downloaded_bytes']
            test_dict['downloaded_bytes'] = d

# Generated at 2022-06-26 11:29:44.462206
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert isinstance(HttpFD(None, {}), HttpFD)
    return


# Generated at 2022-06-26 11:29:53.903991
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Input parameters
    ydl = YouTubeDL()
    info_dict = {
        'url': 'http://www.example.com/path/video.mp4',
        'id': 'video_identifier',
        'ext': 'mp4',
        'title': 'Title of video',
        'display_id': 'Display id of video',
    }

    # Call the constructor
    http_fd = HttpFD(ydl)

    # Test member attributes
    assert(http_fd.ydl is ydl)
    assert(http_fd.downloader is None)
    assert(http_fd.params is None)

    # Call the "real_download" function
    assert(http_fd.real_download('http://www.example.com/path/video.mp4', info_dict, '-') is True)


# Generated at 2022-06-26 11:29:59.555101
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = '\n    Unit test for constructor of class HttpFD\n    '
    obj_0 = HttpFD(1, None, None, None, None, None, None)


# Generated at 2022-06-26 11:30:11.025742
# Unit test for constructor of class HttpFD
def test_HttpFD():
    tmpdir = 'test-temp'
    os.mkdir(tmpdir)
    os.chdir(tmpdir)
    #
    # Create a dummy file and download it again
    #
    dummy_file_name = 'PyYDL-dummy'
    f = open(dummy_file_name, 'wb')
    f.write(b'dummy stuff')
    f.close()
    dummy_file_size = os.path.getsize(dummy_file_name)
    #
    # Create a dummy HttpFD instance
    #
    dummy_url = 'file:///' + os.getcwd() + '/' + dummy_file_name
    dummy_params = {}
    dummy_ydl = FakeYdl(dummy_params)
    dummy_report_mock = ReportMock()
    #

# Generated at 2022-06-26 11:30:20.802558
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    dl = HttpFD()
    dl.params = {}
    dl._hook_progress = mock.Mock()
    dl.report_retry = mock.Mock()
    dl.report_resuming_byte = mock.Mock()
    dl.report_unable_to_resume = mock.Mock()
    dl.report_error = mock.Mock()
    dl.report_warning = mock.Mock()
    dl.report_destination = mock.Mock()
    dl.to_screen = mock.Mock()
    dl.to_stderr = mock.Mock()
    dl.ydl = FakeYDL()
    dl.report_file_already_downloaded = mock.Mock()
    dl.undo_temp_name = mock

# Generated at 2022-06-26 11:30:32.443762
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = '\n    Unit test for constructor of class HttpFD\n    '
    ydl = mock_YoutubeDL()
    with mock.patch('youtube_dl.YoutubeDL.report_error'):
        with mock.patch('youtube_dl.YoutubeDL.report_retry'):
            with mock.patch('youtube_dl.YoutubeDL.report_file_already_downloaded'):
                with mock.patch('youtube_dl.YoutubeDL.report_resuming_byte'):
                    hfd = HttpFD(
                        ydl, {
                            'url': 'http://example.org',
                            'outtmpl': '%(id)s',
                            'noprogress': True,
                            'test': True,
                        },
                        True)


# Generated at 2022-06-26 11:30:37.378789
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ufd = HttpFD({})
    ufd.real_download(
        'http://foo',
        {'url': 'http://foo'},
        {'destination': 'bar'},
        'bar',
        None,
        False
    )


# Generated at 2022-06-26 11:30:44.982915
# Unit test for constructor of class HttpFD
def test_HttpFD():

    class MockYoutubeDl:

        def __init__(self):
            pass


    v_list = []

    def urlopen(p_url, data, timeout, *v_args, **v_kwargs):
        v_list.append((p_url, data, timeout, v_args, v_kwargs))
        v_r_open = compat_urllib_request.urlopen(p_url, data, timeout, *v_args, **v_kwargs)

        class MockFile:

            def __init__(self):
                v_r_open.read()  # seek to 0

            def info(self):
                return {'Content-length': '1024'}


# Generated at 2022-06-26 11:30:56.066775
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ctx = SimpleNamespace()
    ctx.fd = HttpFD(None, None, None, None) 
    ctx.tmpfilename = 'tmp'
    ctx.filename = 'filename'
    ctx.resume_len = 0
    ctx.extra_info_dict = {}
    ctx.info_dict = None
    ctx.add_extra_info = False
    ctx.retries = 0
    ctx.chunk_size = 0
    ctx.stream = None
    ctx.result_trace = []
    ctx.start_time = time.time()
    ctx.open_mode = 'wb'
    ctx.data = None
    ctx.data_len = None
    ctx.url = 'http://example.com/foo.bar'
    ctx.block

# Generated at 2022-06-26 11:31:50.763344
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_2 = 'Unit test for method real_download of class HttpFD'

    str_0 = '\n    Unit test for method real_download of class HttpFD\n    '
    arg_0 = {'downloaded_bytes': 8192, 'total_bytes': None, 'filename': '/tmp/abcdefgh.tmp', 'status': 'downloading', 'elapsed': 1550538197.55424, 'eta': None, 'speed': 531.9}
    arg_1 = {'downloaded_bytes': 8192, 'total_bytes': None, 'filename': '/tmp/abcdefgh.tmp', 'status': 'downloading', 'elapsed': 1550538197.55424, 'eta': None, 'speed': 531.9}

# Generated at 2022-06-26 11:31:55.895166
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    file_name_0 = download_with_http_fallback(('https://www.youtube.com/watch?v=0RWYjYH_lNk', ))
    assert file_name_0 == '0RWYjYH_lNk.mp4'

# Generated at 2022-06-26 11:32:02.431508
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    http_file_downloader = HttpFD('https://www.google.com/doodles/', {'_test': True}, '-')
    """
    str_1 = 'https://www.google.com/doodles/'
    str_2 = 'https://www.google.com/doodles/'
    str_3 = '-'
    http_file_downloader = HttpFD(str_3, {str_1: int_1, '_test': True}, str_2)


# Generated at 2022-06-26 11:32:03.604207
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD(None)


# Generated at 2022-06-26 11:32:13.362689
# Unit test for constructor of class HttpFD
def test_HttpFD():
    dl = HttpFD(FakeYDL())
    if dl.max_retries != 10:
        raise AssertionError()
    str_0 = dl.params.get('outtmpl')
    str_1 = '%(title)s-%(id)s.%(ext)s'
    if not (str_0 == str_1):
        raise AssertionError()
    dl.params['outtmpl'] = '[%(autonumber)s]'
    if dl.params.get('outtmpl') != '[%(autonumber)s]':
        raise AssertionError()
    dl.report_error('Unit test for report_error of class HttpFD.')
    return dl.ydl

# # Unit test for method real_download of class HttpFD
# def

# Generated at 2022-06-26 11:32:18.523277
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    global test_case_0
    assert test_case_0 is None
    global test_case_1
    assert test_case_1 is None
    global test_case_2
    assert test_case_2 is None


# Generated at 2022-06-26 11:32:23.285012
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd_0 = HttpFD(_MON_STDIN, _MON_STDOUT, False, _MON_STDOUT, False, False, {}, 'base_url', _MON_STDOUT, 'video_id', 'http://www.youtube.com/watch?v=Ik-RsDGPI5Y')


# Generated at 2022-06-26 11:32:28.778409
# Unit test for constructor of class HttpFD
def test_HttpFD():
    xdl = Xdl()
    xdl.params['ydl_opts'] = {
            'progress_hooks': [
                lambda status: None,
            ],
            'logger': xdl,
        }
    hf = HttpFD(xdl, 'x', {'url': 'http://localhost:8080/'}, '-', 0, 0)
    assert isinstance(hf, HttpFD)


# Generated at 2022-06-26 11:32:33.364871
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.youtube import YoutubeIE

    hfd = HttpFD(YoutubeIE(), None, 'http://www.youtube.com/watch?v=BaW_jenozKc', {
        'noprogress': True,
        'continuedl': True,
        'quiet': True,
    })
    hfd.real_download('test.flv')
    return hfd


# Generated at 2022-06-26 11:32:37.988943
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = '\n    Unit test for method real_download of class HttpFD\n    '
    msg_0 = str_0 + 'No input parameters specified\n    '
    msg_0 = msg_0 + 'Failure\n    '
    assert_raises_regexp(Exception, msg_0, test_case_0)

if __name__ == '__main__':
    import sys
    import nose
    from ytdl.utils import FileDownloader

    sys.exit(nose.runmodule())

# Generated at 2022-06-26 11:33:32.163250
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:33:33.931208
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:33:36.184585
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # ctx = set_up()
    test_case_0()
    # tear_down()

# generates a test case

# Generated at 2022-06-26 11:33:43.790642
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd_1 = HttpFD(float_0, str_1)
    assert http_fd_1.params == {'verbose': True}, 'Assertion failed'
    assert http_fd_1.ydl is None, 'Assertion failed'
    assert http_fd_1.opener is None, 'Assertion failed'
    assert http_fd_1.max_retries == -1, 'Assertion failed'
    assert http_fd_1.progress_hooks == [], 'Assertion failed'
    assert http_fd_1.playlist is None, 'Assertion failed'
    assert not hasattr(http_fd_1, '_TEST_FILE_SIZE'), 'Assertion failed'

# Generated at 2022-06-26 11:33:51.538204
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_2 = 'm3u8'
    str_3 = 'url'

    # Get a m3u8 file to test
    http_f_d_1 = HttpFD(0, 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8')
    http_f_d_1.real_download(str_2, 1)
    f_0 = open('bipbopall-001.ts', 'r')
    str_4 = f_0.read()
    print(str_4)
    f_0.close()

    # Get a ts file to test
    f_0 = open('bipbopall.m3u8', 'r')
    str_5 = f_0.read()
    url_0 = str

# Generated at 2022-06-26 11:33:55.147611
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'https://y.qq.com/n/yqq/song/004295Et37taLD.html'
    str_1 = 'https://y.qq.com/n/yqq/song/004295Et37taLD.html'
    http_f_d_0 = HttpFD(5156, str_1)


# Generated at 2022-06-26 11:33:56.163843
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:33:57.379297
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert 'real_download' in dir(HttpFD)


# Generated at 2022-06-26 11:33:58.924062
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    print('Test finished!')

# Generated at 2022-06-26 11:34:05.396546
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'published time'
    int_0 = 5156
    float_0 = -3577.499491
    str_1 = 'https://y.qq.com/n/yqq/song/004295Et37taLD.html'
    http_f_d_0 = HttpFD(float_0, str_1)
    assert http_f_d_0.ydl == float_0, 'HttpFD.ydl = %s' % ((float_0).__str__())
    assert http_f_d_0.url == str_1, 'HttpFD.url = %s' % (str_1)


# Generated at 2022-06-26 11:35:58.051887
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:35:59.068466
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:36:02.627533
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Executing unit test for method real_download of class HttpFD')
    for i in range(20):
        test_case_0()
    print('End of unit test for method real_download of class HttpFD')

# Run the unit tests
if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:36:04.207711
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:36:06.393633
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print ('Start')
    test_case_0()
    print ('End')

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:36:13.966567
# Unit test for constructor of class HttpFD
def test_HttpFD():
    float_1 = -6.297798
    str_2 = 'https://y.qq.com/n/yqq/song/004295Et37taLD.html'
    http_f_d_1 = HttpFD(float_1, str_2)

test_case_0()


#def parse_bytes(bytestr):
#    """Parse a string indicating a byte quantity into an integer."""
#    matchobj = re.match(r'(?i)^(\d+(?:\.\d+)?)([kMGTPEZY]?)$', bytestr)
#    if matchobj is None:
#        return None
#    number = float(matchobj.group(1))
#    multiplier = 1024.0 ** 'bkmgtpezy'.index(matchobj.group(2