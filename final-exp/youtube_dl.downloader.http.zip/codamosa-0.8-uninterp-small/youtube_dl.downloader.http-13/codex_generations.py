

# Generated at 2022-06-26 11:27:00.172772
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = ''
    bytes_0 = b'\xfc\xa9\x0cl\xc9\xb8]\xf0\xfa\xd0x\xfe\xc5\xcc\xc9\xcf\xfe\x13'
    http_f_d_0 = HttpFD(str_0, bytes_0)

    http_f_d_0.real_download(str_0, bytes_0, 1, 1024, None)

test_case_0()
test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:02.015233
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# End of test for method real_download of class HttpFD



# Generated at 2022-06-26 11:27:06.744048
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    obj_0 = HttpFD()
    obj_0.real_download(params={}, filename='', info_dict={}, tmpfilename='L\x1e\x17\x06\x0f>\x10\x12\x1d', retries=9)


# Generated at 2022-06-26 11:27:12.772175
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = ''
    bytes_0 = b'\xfc\xa9\x0cl\xc9\xb8]\xf0\xfa\xd0x\xfe\xc5\xcc\xc9\xcf\xfe\x13'
    http_f_d_0 = HttpFD(str_0, bytes_0)


# Generated at 2022-06-26 11:27:22.960188
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_1 = ''

# Generated at 2022-06-26 11:27:23.875896
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:24.780314
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:30.693367
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = 'lTnT3Tf-C3q'
    str_1 = 'lTnT3Tf-C3q'
    str_2 = 'lTnT3Tf-C3q'
    str_3 = '-TnT3Tf-C3q'
    str_4 = 'lTnT3Tf-C3q'
    bytes_0 = b'\xfc\xa9\x0cl\xc9\xb8]\xf0\xfa\xd0x\xfe\xc5\xcc\xc9\xcf\xfe\x13'

# Generated at 2022-06-26 11:27:33.758893
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Constructor that takes no arguments
    assert HttpFD()
    # Constructor that takes one argument
    assert HttpFD("")
    # Constructor that takes two arguments
    assert HttpFD("", "")



# Generated at 2022-06-26 11:27:40.368844
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = ''
    bytes_0 = b'\xfc\xa9\x0cl\xc9\xb8]\xf0\xfa\xd0x\xfe\xc5\xcc\xc9\xcf\xfe\x13'
    http_f_d_0 = HttpFD(str_0, bytes_0)
    
    print('[*] Start to test')
    http_f_d_0.real_download(str_0, str_0, bytes_0, -1, str_0)
    print('[*] End of method call')

test_HttpFD_real_download()
test_case_0()

# Generated at 2022-06-26 11:28:27.376362
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('https://dldir1.qq.com/weixin/Windows/WeChatSetup.exe', 'D:/download/WeChatSetup.exe')
    fd.download()
    #fd.download(outtmpl='D:/download/WeChatSetup.exe', retries=10)
    #fd.download(outtmpl='D:/download/WeChatSetup.exe', retries=10, chunk_size=1024*64)
    #fd.download(outtmpl='D:/download/WeChatSetup.exe', retries=10, chunk_size=1024*64)

if __name__ == '__main__':
    test_case_0()
    test_HttpFD()

# Generated at 2022-06-26 11:28:30.925092
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    num_0 = 0
    num_1 = 0
    str_1 = ''
    str_0 = ''
    print(num_0, num_1, str_0, str_1)



# Generated at 2022-06-26 11:28:41.908528
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Class HttpFD_real_download0
    class HttpFD_real_download0():
        pass

    # Class HttpFD_real_download1
    class HttpFD_real_download1():
        pass

    # Class HttpFD_real_download2
    class HttpFD_real_download2():
        pass

    # Class HttpFD_real_download3
    class HttpFD_real_download3():
        pass

    # Class HttpFD_real_download4
    class HttpFD_real_download4():
        pass

    # Class HttpFD_real_download5
    class HttpFD_real_download5():
        pass

    # Class HttpFD_real_download6
    class HttpFD_real_download6():
        pass

    # Class HttpFD_real_download

# Generated at 2022-06-26 11:28:45.613289
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(str_0, str_1, int_1, float_0, float_0)
    assert http_fd is not None


# Generated at 2022-06-26 11:28:57.569312
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd_0 = HttpFD()
    down_ctx_0 = DownloadContext()
    down_ctx_1 = DownloadContext()

    down_ctx_0.data = None
    down_ctx_1.data_len = -1
    down_ctx_0.tmpfilename = 'tmp.\x00'
    down_ctx_0.block_size = -1
    down_ctx_0.filename = 'K\x1f\x00\x00\x00\x00\x00'
    down_ctx_1.chunk_size = -1
    down_ctx_1.data = None
    down_ctx_1.tmpfilename = 'tmp.\x00'
    down_ctx_0.data_len = -1

# Generated at 2022-06-26 11:29:02.768926
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('', '', test_case_0, {
        'usenetrc': False,
        'username': None,
        'password': None,
    }, {
        'test': True,
    })
    assert fd is not None


# Generated at 2022-06-26 11:29:14.827573
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:29:17.700014
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(None, None, lambda d: None)
    assert h._ydl != None
    compare_val_0 = h._ydl.params != None
    assert compare_val_0


# Generated at 2022-06-26 11:29:23.504118
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case #0
    httpfd = HttpFD()
    httpfd.download([('http://www.youtube.com/watch?v=BaW_jenozKc', {}, False)], {})
    
    
if __name__ == "__main__":
    # Test case #0
    test_case_0()

# Generated at 2022-06-26 11:29:34.485696
# Unit test for constructor of class HttpFD
def test_HttpFD():
    dir_0 = tempfile.mkdtemp()

# Generated at 2022-06-26 11:30:09.935880
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:30:10.676934
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    print('test_HttpFD completed')


# Generated at 2022-06-26 11:30:13.784389
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Main
if __name__ == '__main__':
    # Unit tests for this class
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:30:14.857366
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    return test_case_0()


# Generated at 2022-06-26 11:30:16.008610
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Simple test

# Generated at 2022-06-26 11:30:17.058350
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:30:18.716317
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:30:21.234619
# Unit test for constructor of class HttpFD
def test_HttpFD():
    list_0 = []
    http_f_d_0 = HttpFD(-95.71152, list_0)
    assert type(http_f_d_0) == HttpFD


# Generated at 2022-06-26 11:30:32.925084
# Unit test for constructor of class HttpFD
def test_HttpFD():
    global var_0
    var_0 = None
    test_case_0()
    global assert_count
    assert_count += 1
    assert var_0 == True, '== True'

if __name__ == "__main__":
    #test_HttpFD()
    #assert_count += 1
    #assert is_xdg_available() == True, '== True'
    #assert_count += 1
    #assert real_download(b'\xedL\x19D}!\xff"L\x17D@9\xd9\x19\x00', 1633.217342) == True, '== True'
    assert_count += 1
    assert sanitize_open('1.txt', 'wb')[0] is not None, 'is not None'
    assert_count += 1
    assert undo

# Generated at 2022-06-26 11:30:36.021749
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

################################################################################

# #!/usr/bin/env python3
# # -*- coding: UTF-8 -*-

# main()

# Generated at 2022-06-26 11:32:00.313497
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:32:05.651878
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Constructor with three parameters
    http_f_d_0 = HttpFD(2.0, [1])

    # Verify call to method real_download
    test_case_0();
    return 0


# Module level execution
if __name__ == '__main__':

    # Test class HttpFD
    error_code = test_HttpFD()

    # Return error code
    sys.exit(error_code)

# Generated at 2022-06-26 11:32:06.778412
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:08.669378
# Unit test for constructor of class HttpFD
def test_HttpFD():
    var_0 = HttpFD(4)
    assert(var_0.ydl == 4)
    

# Generated at 2022-06-26 11:32:12.720323
# Unit test for constructor of class HttpFD
def test_HttpFD():
    list_0 = []
    http_f_d_0 = HttpFD(1.867, list_0)
    print(http_f_d_0._HttpFD__left)
    print(http_f_d_0._HttpFD__speed_idx)


# Generated at 2022-06-26 11:32:13.798305
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:14.777016
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:32:16.713179
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:32:18.877600
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:20.738242
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Execute all tests

# Generated at 2022-06-26 11:35:40.097961
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD(None)
    http_f_d_0.report_error(None)


# Generated at 2022-06-26 11:35:43.809733
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_0 = [
        (1, 1, 1)
    ]
    for test_input, expected, actual in test_0:
        assert expected == actual


# Generated at 2022-06-26 11:35:46.124971
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:35:46.993685
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:35:47.790636
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:35:54.498626
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bytes_0 = b'\xedL\x19D}!\xff"L\x17D@9\xd9\x19\x00'
    float_0 = 1633.217342
    float_1 = -95.71152
    list_0 = []
    http_f_d_0 = HttpFD(float_1, list_0)
    test_case_0()
    bytes_1 = b'\xedL\x19D}!\xff"L\x19D\x81\xb7\x8f\x86\xd4\x00'
    float_0 = 4294.833200
    float_1 = -64.835288
    list_0 = []
    http_f_d_0 = HttpFD(float_1, list_0)
    boolean_

# Generated at 2022-06-26 11:35:59.228641
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bytes_0 = b'\xedL\x19D}!\xff"L\x17D@9\xd9\x19\x00'
    float_0 = 1633.217342
    float_1 = -95.71152
    list_0 = []
    http_f_d_0 = HttpFD(float_1, list_0)


# Generated at 2022-06-26 11:36:00.073069
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:36:01.152719
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    return

# SIGNATURE_START

# Generated at 2022-06-26 11:36:02.348996
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()