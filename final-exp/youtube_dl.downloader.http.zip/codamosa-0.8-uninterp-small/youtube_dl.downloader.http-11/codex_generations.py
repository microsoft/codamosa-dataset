

# Generated at 2022-06-26 11:27:02.235553
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Testing real_download function ...')
    list_0 = []
    str_0 = ''
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    http_f_d_0 = HttpFD(1,list_0)
    http_f_d_0._hook_progress = _hook_progress
    http_f_d_0.report_destination = report_destination
    http_f_d_0.report_error = report_error
    http_f_d_0.report_retry = report_retry
    http_f_d_0.report_resuming_byte = report_resuming_byte
    http_f_d_0.report_unable_to_resume = report_un

# Generated at 2022-06-26 11:27:05.304731
# Unit test for constructor of class HttpFD
def test_HttpFD():
    for i in range(100):
        test_case_0()


# Generated at 2022-06-26 11:27:10.322166
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert check_test_case("test_case_0", test_case_0, "HttpFD.real_download")

test_cases_HttpFD_real_download = [test_case_0]

# Testing of method real_download of class HttpFD

# Generated at 2022-06-26 11:27:12.162106
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert HttpFD(0, []).real_download('', {}) == False


# Generated at 2022-06-26 11:27:13.928162
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:16.993562
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ctx = HttpFD(
        data=None,
        params={
            'retries': 10,
            'continuedl': True
        }
    )


# Generated at 2022-06-26 11:27:18.887058
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    real_download('http://dont_supply_real_url', {})


# Generated at 2022-06-26 11:27:19.726258
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

testCounter = 0


# Generated at 2022-06-26 11:27:24.576183
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url = 'https://upload.wikimedia.org/wikipedia/commons/7/72/IPhone_Internals.jpg'
    dest = 'dest.jpg'
    hfd = HttpFD(url, dest)
    r = hfd.real_download(url, dest)
    if r:
        print('Downloaded to: ' + dest)
    else:
        print('Download failed.')
        
test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:25.487974
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:28:11.640759
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create an input of type 'HttpFD'
    ctx_0 = HttpFD()
    # Create an input of type 'str'
    url_0 = 'test_value_1'
    # Create an input of type 'dict'

# Generated at 2022-06-26 11:28:21.740029
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_1 = 'HttpFD.__init__'

    HttpFD_instance = HttpFD('test_filename', {}, 'test_ydl')

    if hasattr(HttpFD_instance, 'test_filename') == False:
        print(str_1 + ' failed')
    else:
        print(str_1 + ' passed')

    if hasattr(HttpFD_instance, 'test_params') == False:
        print(str_1 + ' failed')
    else:
        print(str_1 + ' passed')

    if hasattr(HttpFD_instance, 'test_ydl') == False:
        print(str_1 + ' failed')
    else:
        print(str_1 + ' passed')


# Generated at 2022-06-26 11:28:29.906565
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD.__name__ == 'HttpFD'
    assert len(HttpFD.__bases__) == 2
    assert HttpFD.__bases__[0].__name__ == 'FD'
    assert HttpFD.__bases__[1].__name__ == 'YoutubeDL'
    assert len(HttpFD.__dict__) == 11
    assert HttpFD.__init__.__name__ == '__init__'
    assert HttpFD.__init__.__doc__ is None
    assert HttpFD.real_download.__name__ == 'real_download'
    assert HttpFD.real_download.__doc__ is None
    assert HttpFD.best_block_size.__name__ == 'best_block_size'
    assert HttpFD.best_block_size.__doc__

# Generated at 2022-06-26 11:28:36.849607
# Unit test for constructor of class HttpFD
def test_HttpFD():

    str_0 = 'HttpFD'
    str_1 = 'test_case_0'
    obj_0 = HttpFD()
    assert not obj_0 == None

    # verify that expected methods exist
    obj_0.real_download
    obj_0.test
    obj_0.best_block_size
    obj_0.get_test


# Generated at 2022-06-26 11:28:44.342634
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Init objects
    ctx = {
        'block_size': 81920,
        'chunk_size': -1,
        'data': None,
        'data_len': None,
        'filename': '',
        'has_range': False,
        'is_resume': False,
        'open_mode': 'wb',
        'resume_len': 0,
        'start_time': 1542682520.9261942,
        'stream': None,
        'tmpfilename': '',
    }
    info_dict = {
        'id': 'id_kwcgLnjw8Y',
        'upload_date': '20010101',
        'uploader': 'uploader1',
        'uploader_id': 'uploaderId1',
    }

# Generated at 2022-06-26 11:28:48.829330
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Arguments of __init__:
    url = "short.com"
    params = {"params": "params"}
    ydl = YoutubeDL(params)

    # Constructor
    httpfd = HttpFD(ydl, url, params)

# Generated at 2022-06-26 11:28:50.297742
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Method setup
    pytest.skip('Unimplemented test case')


# Generated at 2022-06-26 11:28:51.652796
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd_0 = HttpFD(None, dict(), dict(), dict())
    # test_case_0
    test_case_0()


# Generated at 2022-06-26 11:28:53.623978
# Unit test for constructor of class HttpFD
def test_HttpFD():
    obj_0 = HttpFD()
    obj_1 = HttpFD()

# Generated at 2022-06-26 11:29:01.966775
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case 0
    dow_0 = HttpFD()
    assert isinstance(dow_0, Downloader), 'test_case_0: assert type(dow_0) type is Downloader'
    assert not dow_0._is_http, 'test_case_0: assert dow_0._is_http is False'
    assert not dow_0.params, 'test_case_0: assert dow_0.params is False'
    assert dow_0.ydl is None, 'test_case_0: assert dow_0.ydl is None'
    assert dow_0._TEST_FILE_SIZE == 1000000, 'test_case_0: assert dow_0._TEST_FILE_SIZE is 1000000'

# Generated at 2022-06-26 11:29:43.535619
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.google.com', '', 'http://192.168.0.1:8080', '', 'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0')
    assert fd.ydl is not None
    assert fd.proxies is not None
    assert fd.test is False
    assert fd.params is not None
    assert fd.url is not None
    assert fd.dest is not None
    assert fd.video_id is None
    assert fd.urlhandle is None
    assert fd._is_test_download is False
    assert fd.max_temp_files is not None
    assert fd._total_bytes is None
    assert fd._info

# Generated at 2022-06-26 11:29:53.237704
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case 0
    fd = HttpFD(
        test_dir_0, 'test_case_0', test_url_0, headers_0, test_retries_0,
        test_params_0, test_pt_0)
    assert_equal(fd._filename, 'test_case_0')
    assert_equal(fd._url, test_url_0)
    assert_equal(fd._tmpfilename, None)
    assert_equal(fd._tries, test_retries_0)
    assert_equal(fd._retries, test_retries_0)
    assert_equal(fd._total_bytes, None)
    assert_equal(fd._progress_hooks, test_pt_0)
    assert_equal(fd._start, None)
    assert_equal(fd._now, None)

# Generated at 2022-06-26 11:29:56.175403
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'Unimplemented test case'
    # Constructor for class HttpFD not implemented
    # http_fd = HttpFD(url, params)


# Generated at 2022-06-26 11:29:59.240903
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    httpfd = HttpFD()

    # Case 0
    try:
        test_case_0()
    except NotImplementedError:
        pass


# Generated at 2022-06-26 11:30:00.625731
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hfd_0 = HttpFD()
    pass


# Generated at 2022-06-26 11:30:05.778466
# Unit test for constructor of class HttpFD
def test_HttpFD():
    filename = 'Random.jpg'
    test_HttpFD = HttpFD(filename)
    assert test_HttpFD.filename == filename
    assert isinstance(test_HttpFD, HttpFD)
    assert test_HttpFD.ydl == youtube_dl.YoutubeDL


# Generated at 2022-06-26 11:30:07.177214
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test method real_download of class HttpFD"""
    return




# Generated at 2022-06-26 11:30:17.711725
# Unit test for constructor of class HttpFD
def test_HttpFD():
    _HttpFD = HttpFD({}, {})
    assert hasattr(_HttpFD, 'ydl')
    assert hasattr(_HttpFD, 'http_test')
    assert hasattr(_HttpFD, 'http_headers')
    assert hasattr(_HttpFD, 'report_warning')
    assert hasattr(_HttpFD, 'report_error')
    assert hasattr(_HttpFD, 'report_retry')
    assert hasattr(_HttpFD, 'report_resuming_byte')
    assert hasattr(_HttpFD, 'report_file_already_downloaded')
    assert hasattr(_HttpFD, 'report_unable_to_resume')
    assert hasattr(_HttpFD, 'report_destination')
    assert hasattr(_HttpFD, 'to_screen')
    assert hasattr(_HttpFD, 'to_stderr')


# Generated at 2022-06-26 11:30:20.096155
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for instatiation of class HttpFD
    str_0 = 'Unimplemented test case'


# Generated at 2022-06-26 11:30:22.327697
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Testing method real_download of class HttpFD')

    # Create HttpFD object
    obj = HttpFD()

    # Call method
    # obj.real_download()

    # Report result



# Generated at 2022-06-26 11:31:38.409421
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Init for test case `test_case_0`
    str_0 = 'Unimplemented test case'


# Generated at 2022-06-26 11:31:42.766106
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create an instance of HttpFD
    hfd = HttpFD()
    
    # Check constructor values
    assert hfd.file_size is None, 'File size (actual size) is not None'
    
    # Call destructor for hfd
    del hfd

### Create an instance of HttpFD, then immediately delete it

# Generated at 2022-06-26 11:31:47.275229
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = io.BytesIO(b'0123456789')
    http_fd = HttpFD(fd, 10)
    assert http_fd.size == 10
    assert http_fd.tell() == 0
    assert http_fd.read(5) == b'01234'
    assert http_fd.tell() == 5


# Generated at 2022-06-26 11:31:48.148810
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case(test_case_0)


# Generated at 2022-06-26 11:31:50.193126
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Test constructor HttpFD')
    hfd = HttpFD(None, None, None)
    assert hfd.context is not None
    assert hfd.context.dldir is not None


# Generated at 2022-06-26 11:32:01.396587
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd_0 = HttpFD('http://127.0.0.1:8080/test/test.txt', {'test': True})
    assert httpfd_0.url == 'http://127.0.0.1:8080/test/test.txt'
    assert isinstance(httpfd_0.ydl, YoutubeDL)
    assert httpfd_0.headers == {'test': True}
    assert httpfd_0.params['noprogress'] == True
    assert httpfd_0.params['retries'] == 10
    assert httpfd_0.params['fragment_retries'] == 10
    assert httpfd_0.frag_index == 1
    assert httpfd_0.continuedl == True
    assert httpfd_0.continuedl_wait == 5

# Generated at 2022-06-26 11:32:03.321729
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_HttpFD_0 = HttpFD(
        params={
            'test': True,
        }
    )

if __name__ == '__main__':
    test_case_0()
    test_HttpFD()

# Generated at 2022-06-26 11:32:13.236834
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if '<ERROR>' in test_HttpFD_real_download.__doc__:
        # This test method was created from an empty test case
        # We need to insert some code to avoid errors
        str_0 = 'Unimplemented test case'
        assert False, 'Unimplemented test case'
    # Create an instance of class HttpFD
    # test_HttpFD_real_download.HttpFD_0 = HttpFD('.')
    # We need to set one attribute of class HttpFD used in real_download
    # test_HttpFD_real_download.HttpFD_0.ydl = '<ERROR>'
    # Call method real_download with appropriate arguments
    str_0 = 'Unimplemented test case'
    assert False, 'Unimplemented test case'


# Generated at 2022-06-26 11:32:25.665018
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:32:30.579503
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD()
    if h.ydl is None:
        print('Attribute ydl of HttpFD is not initialized correctly')
    if h.params is None:
        print('Attribute params of HttpFD is not initialized correctly')
        return False
    if h._TEST_FILE_SIZE != 10485760:
        print('Value of attribute _TEST_FILE_SIZE of HttpFD is not initialized correctly')
        return False


# Generated at 2022-06-26 11:35:41.513339
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('', 0, {})
    assert fd.html_url is ''
    assert fd.inc_size == 0
    assert fd.params == {}


# Generated at 2022-06-26 11:35:48.511427
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(1, temp_name = 'temp_name', url = 'url', params = {}, info_dict = {})

    assert http_fd._filename == 'temp_name'
    assert http_fd._size == 1
    assert http_fd._closed
    assert http_fd._buf == ''
    assert http_fd._info_dict == {}
    assert http_fd._temp_name == 'temp_name'
    assert http_fd._url == 'url'
    assert http_fd._params == {}


# Generated at 2022-06-26 11:35:50.528904
# Unit test for constructor of class HttpFD
def test_HttpFD():
    #Test 1:
    htmlfd_1 = HttpFD(None, None, None, None)
    test_case_0()

# Unit tests

# Generated at 2022-06-26 11:35:56.454894
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    hfd = HttpFD()
    hfd.report_progress()
    hfd.report_warning()
    hfd.report_error()
    hfd.to_screen()
    hfd.trouble()
    hfd.report_retry()
    hfd.report_skip_dest()
    hfd.report_destination()
    hfd.report_finish()
    hfd.report_file_already_downloaded()
    hfd.report_unable_to_resume()
    hfd.report_resuming_byte()
    hfd.best_block_size()
    hfd.calc_eta()
    hfd.calc_speed()
    hfd.slow_down()
    hfd.to_stderr()
    hfd.to_screen()
    h

# Generated at 2022-06-26 11:36:05.618627
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Arguments: object
    http_fd_1 = HttpFD(None)
    assert isinstance(http_fd_1, HttpFD)
    assert isinstance(http_fd_1.params, dict)  # public
    assert isinstance(http_fd_1.ydl, YoutubeDL)  # public
    assert isinstance(http_fd_1.max_blocks_read, int)  # public
    assert isinstance(http_fd_1.max_retries, int)  # public
    assert isinstance(http_fd_1.wait_dl, int)  # public
    assert isinstance(http_fd_1.buffered_bytes, int)  # public
    assert isinstance(http_fd_1.socket_timeout, float)  # public

# Generated at 2022-06-26 11:36:06.822275
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert test_case_0() == 0
    return True


# Generated at 2022-06-26 11:36:14.356885
# Unit test for constructor of class HttpFD