

# Generated at 2022-06-26 11:26:56.373377
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        test_case_0()
        print("Test case passed")
    except:
        print("Test case failed")

test_HttpFD()

# Generated at 2022-06-26 11:26:58.357749
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


if __name__ == '__main__':
    test_HttpFD()
    os.remove(str_0)

# Generated at 2022-06-26 11:26:59.276663
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:04.906540
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD('GET')
    http_f_d_0.real_download(b'~\xcb\xf1OJ\x93a\x8c\x95\xcf\x9a\x9d\xdf', '\x11')
    http_f_d_0.real_download(b'\x00\x11\x00\x11\x00\x11\x00\x11\x00\x11', '\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01')

# Generated at 2022-06-26 11:27:07.314603
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()
    assert True

# Generated at 2022-06-26 11:27:08.069618
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:27:09.544100
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:11.744798
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

# Entry point for program
if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:27:22.047234
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    filename = 'test'
    url = 'http://www.youtube.com'
    ydl = YoutubeDL()
    ydl.params = {
        'continuedl': False,
        'quiet': False,
        'nooverwrites': False,
        'outtmpl': filename,
        'test': True,
        'logger': sys.stderr.write,
        'retries': 10,
    }
    ydl.to_stderr = lambda *args, **kargs: None
    ydl.to_screen = lambda *args, **kargs: None
    ydl.report_error = lambda *args, **kargs: None
    ydl._hook_progress = lambda *args, **kargs: None
    ydl.report_retry = lambda *args, **kargs: None
    y

# Generated at 2022-06-26 11:27:22.938658
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()



# Generated at 2022-06-26 11:28:05.006429
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # Initialization
    httpFD_instance = HttpFD()
    httpFD_instance.params = {'continuedl':True}

    # Set up context for method real_download
    ctx = DownloadContext()
    ctx.filename = ''
    ctx.tmpfilename = ''
    ctx.data = object()
    ctx.stream = None
    url = 'www.youtube.com/watch?v=HWHpjKtbuD4'
    is_test = True
    retries = 10
    count = 1
    ctx.data.info = lambda: object()
    ctx.data.info.__getitem__ = lambda x: 100
    ctx.data.read = lambda x: 100
    ctx.data.read.__getitem__ = lambda x: 100


# Generated at 2022-06-26 11:28:07.235467
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = 'Test case passed'
    var_0 = print(str_0)


# Generated at 2022-06-26 11:28:12.340093
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_num = 0
    print('Test case ' + str(test_case_num))
    str_0 = 'Expected output: '
    str_1 = 'true'
    str_0 += str_1
    print(str_0)
    _HttpFD_real_download()
    test_case_0()


# Generated at 2022-06-26 11:28:15.894702
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("Testing constructor of HttpFD")
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

__all__ = ['HttpsFD', 'HttpFD']

# Generated at 2022-06-26 11:28:25.017454
# Unit test for constructor of class HttpFD
def test_HttpFD():
     print('Running HttpFD constructor test')
     # Create file descriptor
     httpfd = HttpFD('http://localhost/1.txt', {})
     # check if the fd is created
     if httpfd is not None:
         # Get file name
         httpfd_file_name = httpfd.name
         # check if file name returned is 1.txt
         if httpfd_file_name == 'http://localhost/1.txt':
             print('Test case passed')
            # return 1;
         else:
             print('Test case failed')
            # return 0;
     else:
         print('Test case failed')
        # return 0;


# Generated at 2022-06-26 11:28:31.690672
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    obj_0 = HttpFD(url='Test Url')
    int_0 = 0
    while int_0 < 10:
        int_1 = 0

# Generated at 2022-06-26 11:28:38.733458
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    var_1 = HttpFD()
    str_0 = 'http://localhost/'
    var_2 = '-'
    var_3 = list()
    var_4 = 'a'
    var_3.append(var_4)
    var_5 = var_1.real_download(str_0, var_2, var_3)
    var_6 = assertEqual(var_5, True)


# Generated at 2022-06-26 11:28:45.570701
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Testing of real_download
    # test case
    str_0 = 'Test case passed'
    var_0 = real_download()
    if (var_0 == 1):
        print(str_0)
    else:
        str_1 = "\033[1;31;m" + str_0 + "\033[0m"
        print(str_1)



# Generated at 2022-06-26 11:28:48.651836
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case 0
    try:
        test_case_0()
    except:
        print('Test failed')
    else:
        print('Test passed')

# Generated at 2022-06-26 11:28:49.631894
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:29:22.208225
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    obj_0 = HttpFD()
    var_0 = obj_0.real_download(None, 'Test String #1', None, None)
    if var_0 == True:
        test_case_0()


# Generated at 2022-06-26 11:29:25.403382
# Unit test for constructor of class HttpFD
def test_HttpFD():
    var_1 = HttpFD(params={})
    return var_1


# Generated at 2022-06-26 11:29:35.183957
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Initialize the HttpFD object
    http = HttpFD({'noprogress': True, 'quiet': True, 'logger': SimpleLogger()})
    # Set up the prerequisites for the test case
    class TestContext:
        pass
    ctx = TestContext()
    ctx.chunk_size = 0
    ctx.data_len = -1
    ctx.resume_len = 0
    ctx.block_size = -1
    ctx.open_mode = 'wb'
    ctx.stream = None
    ctx.tmpfilename = ''
    ctx.filename = ''
    ctx.start_time = 10000000
    ctx.is_resume = True
    ctx.has_range = False
    # Set up the variables needed for the test case

# Generated at 2022-06-26 11:29:44.356738
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url_0 = 'https://developer.mozilla.org/static/img/opengraph-logo.c4558f1bce69.png'
    expected_result = True
    obj_0 = HttpFD(None, None, None, None, None)
    obj_0.filename = 'test-download.png'
    obj_0.test = True
    actual_result = obj_0.real_download(url_0, None, 1)
    if expected_result != actual_result:
        print("test_HttpFD_real_download: Test case failed: ", expected_result, ", actual result: ", actual_result)
        return False

# Generated at 2022-06-26 11:29:53.876451
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = 'Starting test for method real_download of class HttpFD'
    var_0 = print(str_0)
    url = 'http://www.google.com'
    filename = 'index.html'
    ydl = YoutubeDL()
    ydl.download([url])
    var_1 = (url == ydl.get_media_data().get('url'))
    if (var_1):
        str_1 = 'Test case passed'
        var_2 = print(str_1)
    else:
        str_2 = 'Test case failed'
        var_3 = print(str_2)
    var_4 = (filename == ydl.get_media_data().get('title'))
    if (var_4):
        str_3 = 'Test case passed'

# Generated at 2022-06-26 11:30:00.676817
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'Object: '
    str_1 = ' is not an instance of HttpFD.'
    str_2 = 'Unit test failed. '
    str_3 = 'Unit test passed.'
    var_0 = HttpFD()
    if instance(var_0, HttpFD):
        var_1 = print(str_3)
    else:
        var_1 = print(str_2 + str_0 + str_1)


# Generated at 2022-06-26 11:30:02.479730
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD()


# Generated at 2022-06-26 11:30:13.784238
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    #print('running test_case_1')
    str_0 = 'url=https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf, filename=test_case_1_dummy_pdf_file, is_test=True, params={}'
    var_0 = HttpFD().real_download(str_0, 'test_case_1_dummy_pdf_file', True, {})
    var_1 = os.path.isfile('test_case_1_dummy_pdf_file')
    if (var_0 and var_1):
        str_1 = 'Test case passed'
        var_2 = print(str_1)
        return True
    else:
        str_2 = 'Test case failed'
        var_3 = print

# Generated at 2022-06-26 11:30:18.138480
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'This test case is to verify constructor of HttpFD'
    var_0 = print(str_0)
    obj_0 = HttpFD(None, None)
    if obj_0 is None:
        var_0 = print('Test case passed')
    else:
        var_0 = print('Test case failed')


# Generated at 2022-06-26 11:30:23.675860
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('[+] Testing method real_download of class HttpFD')
    Test0 = HttpFD()
    Test0.real_download()
    result0 = str(Test0)
    print(result0)
    test_case_0()
    print('[-] Finished testing method real_download of class HttpFD')
    print('--------------------------------------------------------------------------------')


# Generated at 2022-06-26 11:30:59.450798
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':

    test_HttpFD()

    pass

# Generated at 2022-06-26 11:31:07.257860
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    class MockSocket():
        def __init__(self, data, timeout_infinity = False):
            self.data = data
            self.timeout_infinity = timeout_infinity
            self.current_pos = 0
            self.timeout_counter = 0
            return
        def read(self, block_size):
            data = self.data[self.current_pos:self.current_pos+block_size]
            self.current_pos = self.current_pos + block_size
            if self.timeout_counter > 10 and data and not self.timeout_infinity:
                return b''
            else:
                self.timeout_counter = self.timeout_counter + 1
                return data
        def close(self):
            return

# Generated at 2022-06-26 11:31:11.454194
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    assert type(http_f_d_0) == HttpFD

if __name__ == "__main__":
    test_HttpFD()

# Generated at 2022-06-26 11:31:12.358719
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:31:15.506856
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    

# Generated at 2022-06-26 11:31:17.638700
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    return

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:31:18.521316
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

# Generated at 2022-06-26 11:31:27.195160
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os, tempfile, unittest, shutil, filecmp, random
    from .common import random_test_data

    class TestRealDownload(unittest.TestCase):
        # Common test data
        temp_file_attr = dict(prefix='ytdl', suffix='.tmp')
        temp_file_size = 100000
        temp_file_data = random_test_data(temp_file_size)
        # A stream of bytes to be written to test file when downloading.
        # Each byte is generated by a function randomizer(), and an initial value
        # for this function is specified by an argument file_seed.
        file_seed = random.randint(0, 0xFF)


# Generated at 2022-06-26 11:31:32.807125
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url = 'http://example.com/test'

    ytdl = YoutubeDL()
    ytdl.params['continuedl'] = False
    ytdl.params['noprogress'] = True
    ytdl.params['logger'] = MockLogger()
    ytdl.fd = HttpFD()
    ytdl.fd.ydl = ytdl

    # Test download of completely non-existing file
    # (urlopen raises HTTPError with code 404)
    ytdl.fd.retries = 1
    ytdl.fd.max_retries = 2
    ytdl.fd.test(False)
    ytdl.fd.test(True)

    # Test download of single-chunk small file
    # (urlopen raises HTTPError with code 416)
    ytdl.add_

# Generated at 2022-06-26 11:31:34.224126
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:32:10.004221
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:10.812380
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_1 = HttpFD(0, 0)

# Generated at 2022-06-26 11:32:11.426690
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD()


# Generated at 2022-06-26 11:32:12.564558
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

test_HttpFD()

# Generated at 2022-06-26 11:32:19.481168
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test cases
    test_case_0()

# Extra unit testing
if __name__ == '__main__':
    print('-' * 30)
    print('Executing unit tests.')
    print('-' * 30)
    test_HttpFD_real_download()
    print('-' * 30)
    print('Unit tests finished.')
    print('-' * 30)

# Generated at 2022-06-26 11:32:20.969621
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert issubclass(HttpFD, FileDownloader)
    assert HttpFD.__name__ == 'HttpFD'
    assert HttpFD.__module__ == 'youtube_dl.downloader.http'


# Generated at 2022-06-26 11:32:22.935160
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:32:23.940007
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:32:25.065050
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:26.306082
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:34:12.655701
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = ':08 /xb&^IGr'
    tuple_0 = (str_0,)
    bool_0 = None
    int_0 = 141
    str_1 = 'm\x0b'
    http_f_d_0 = HttpFD(int_0, str_1)
    var_0 = http_f_d_0.real_download(tuple_0, bool_0)

    # NOTE: The test case is not working: if assertion fails,
    # this will not be signaled.
    expected_value = False
    if var_0 != expected_value:
        print("Expected {0} but got {1}".format(expected_value, var_0))


# Generated at 2022-06-26 11:34:13.773171
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

test_HttpFD_real_download()

# Generated at 2022-06-26 11:34:17.056747
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD(
        141,
        'm\x0b',
        '\x7f\x1c',
        '\x0e\x7f',
    )


# Generated at 2022-06-26 11:34:18.131193
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Test class HttpFD

# Generated at 2022-06-26 11:34:18.899314
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:34:25.082624
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    bool_0 = bool()
    str_0 = '#'
    str_1 = ''
    bool_1 = bool()
    str_2 = ""
    str_3 = "\t"
    bool_2 = bool()
    bool_3 = bool()
    str_4 = chr(56)
    str_5 = 'r'
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    str_6 = ""
    str_7 = "\t"
    bool_7 = bool()
    str_8 = '\x00'
    bool_8 = bool()
    str_9 = '\\\x00qw'
    bool_9 = bool()
    str_10 = '~^'
    str_11 = '1'
    bool_10 = bool()

# Generated at 2022-06-26 11:34:35.011991
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if test_case_0():
        assert True
    else:
        assert False

if __name__ == '__main__':

    # Unit tests
    test_HttpFD_real_download()

    # Setup and run
    FileDownloader = (
        # Vidlii specific
        VidliiIE.ie_key(),
        XTubeUserIE.ie_key(),
        XTubeIE.ie_key(),
        # Archive specific
        ArchiveOrgIE.ie_key(),
        # generic
        GenericIE.ie_key(),
    )
    if True:
        fd = FileDownloader(progress_hooks=[test_hook])
    else:
        # For testing purposes download in a dummy directory
        # and force resuming
        temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-26 11:34:37.128360
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 11:34:39.736353
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD(0, '', 1)

# Generated at 2022-06-26 11:34:43.829671
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_2 = ':08 /xb&^IGr'
    tuple_1 = (str_2,)
    bool_1 = None
    int_1 = 141
    str_3 = 'm\x0b'
    http_f_d_1 = HttpFD(int_1, str_3)
    bool_2 = http_f_d_1.real_download(tuple_1, bool_1)
    assert bool_2 == False
