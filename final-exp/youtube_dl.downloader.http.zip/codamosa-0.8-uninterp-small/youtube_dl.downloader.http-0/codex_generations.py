

# Generated at 2022-06-26 11:27:12.550624
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test args passed to HttpFD.real_download
    test_args = [
        ({'params': {'noprogress': True}}),
        ({'params': {'noprogress': True}}),
        ({'params': {'noprogress': True}}),
    ]

    # Test return value of HttpFD.real_download
    # Getting the return value of real_download is unfortunately hard, because
    # the function is normally called inside a child process spawned by
    # FileDownloader. So it seems the only option is to run the function in the
    # parent process, but that means some code in the function which isn't
    # designed to be run there will cause an error.
    # The solution is to use this stub.

# Generated at 2022-06-26 11:27:15.191044
# Unit test for constructor of class HttpFD
def test_HttpFD():
    run_test(test_case_0, 'test_case_0')

# Unit tests for methods of class HttpFD


# Generated at 2022-06-26 11:27:20.921547
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Init HttpFD
    http_f_d_0 = HttpFD(None, None)
    # Construct info_dict
    info_dict_0 = {'duration': str_0}
    # Call tested method
    http_f_d_0.real_download(str_0, info_dict_0, http_f_d_0)

    pass  # Replace this line by a call to your test case


# Generated at 2022-06-26 11:27:22.258728
# Unit test for constructor of class HttpFD
def test_HttpFD():
    global http_f_d_0
    test_case_0()


# Generated at 2022-06-26 11:27:32.570307
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    urls = [
        'http://test.test/test.test',
        'https://test.test/test.test',
    ]
    for url in urls:
        # Test 1
        try:
            test_case_0()
        except (UnicodeEncodeError, UnicodeDecodeError) as e:
            pass
        except (TypeError, AttributeError) as e:
            pass
        except (Exception, ) as e:
            raise
    # Test 2
    http_f_d_0 = HttpFD('http://test.test/test.test', '-')

# Generated at 2022-06-26 11:27:35.557063
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = compat_str(0)

    http_f_d_0 = HttpFD(str_0, str_0)
    return



# Generated at 2022-06-26 11:27:41.810602
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Initialize fields of class HttpFD
    str_0 = 'http://www.example.com/file.mp4'
    str_1 = 'example.mp4'
    http_f_d_0 = HttpFD(str_0, str_1)
    http_f_d_0.params = {'retries': 1}
    http_f_d_0.to_screen = lambda x: None
    http_f_d_0.report_destination = lambda x: None
    http_f_d_0.report_progress = lambda x: None
    http_f_d_0.report_error = lambda x: None
    http_f_d_0.report_retry = lambda x: None
    http_f_d_0.report_resuming_byte = lambda x: None
    http

# Generated at 2022-06-26 11:27:42.539102
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:51.612678
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test whether it can be downloaded normally:
    url = 'http://www.baidu.com/'
    downloader = HttpFD(url, None)
    downloader.real_download(False)
    # Test whether it can be downloaded in test mode:
    url = 'http://www.baidu.com/'
    downloader = HttpFD(url, None)
    downloader.real_download(True)
    # Test whether it can be downloaded normally when URL is invalid:
    url = 'http://www.baidu.com_INVALID'
    downloader = HttpFD(url, None)
    downloader.real_download(False)
    # Test whether it can be downloaded in test mode when URL is invalid:
    url = 'http://www.baidu.com_INVALID'
   

# Generated at 2022-06-26 11:27:53.024749
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:28:33.332634
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'test_HttpFD'
    ydl = YoutubeDL()
    ydl = None
    ir_0 = HttpFD(ydl)
    ir_0 = None


# Generated at 2022-06-26 11:28:42.829120
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    str_0 = 'test_HttpFD_real_download'
    str_1 = 'http://www.youtube.com/watch?v=dQw4w9WgXcQ'
    dict_1 = {}
    dict_1['page_url'] = str_1
    dict_1['format'] = '137+140'
    dict_1['noplaylist'] = True
    dict_2 = {}
    dict_2['youtube_include_dash_manifest'] = False
    dict_2['youtube_include_dash_manifest'] = False
    dict_2['noplaylist'] = True
    dict_2['retries'] = 10

# Generated at 2022-06-26 11:28:47.864691
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # This function is a unit test for method real_download of class HttpFD
    #   Parameters:
    #
    #   Returns:
    #       None

    # Test case 0:
    #   Method:  real_download, parameter
    #   Expected:

    test_case_0()


# Generated at 2022-06-26 11:28:49.867010
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_1 = 'test_HttpFD'
    ins_HttpFD = HttpFD()


# Generated at 2022-06-26 11:28:54.818205
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # HttpFD.real_download(self, info_dict, *, filename, info_dict_paramst, download, skip_existing)
    # Test case 0
    str_1 = 'test_case_0'


# Generated at 2022-06-26 11:28:59.162543
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hfd = HttpFD(context = None)
    hfd2 = HttpFD(context = None, filename = None)
    print(hfd.__dict__)
    print(hfd2.__dict__)
    print('unit test')
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:29:09.015773
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    h = ydl.HttpFD()

    # Test 1:
    assert h.real_download(ydl.FileDownloadContext({'url': 'test', 'tmpfilename': 'tmp'}))
    assert os.path.isfile('tmp')
    assert os.stat('tmp').st_size == 0
    os.remove('tmp')

    # Test 2:
    assert h.real_download(ydl.FileDownloadContext({'url': 'test', 'tmpfilename': '-', 'chunk_size': 1024, 'data_len': 2048}))
    assert os.stat('tmp').st_size == 0
    os.remove('tmp')


# Generated at 2022-06-26 11:29:11.067442
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:29:12.428434
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    try:
        assert(0) #
    except:
        pass


# Generated at 2022-06-26 11:29:15.880502
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hfd = HttpFD()

# Check if a string is an URL to download file
#
# @param str str          String to be checked
# @return boolean         Return True if str is an URL

# Generated at 2022-06-26 11:29:55.630639
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Initialize class HttpFD with fake parameters
    http_f_d_0 = HttpFD(None, None)

    # Verify if the constructor of class HttpFD successfully returns a HTTPFileDownloader object
    assert http_f_d_0 is not None



# Generated at 2022-06-26 11:29:56.935176
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:30:02.984868
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD((), 4342)
    assert isinstance(http_f_d_0.ydl, YoutubeDL)
    assert http_f_d_0.params == {}
    assert http_f_d_0.info_dict == {}
    assert not http_f_d_0._num_retries


# Generated at 2022-06-26 11:30:08.372524
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    int_0 = 4874
    str_0 = 'bFd=7'
    tuple_0 = ()
    bool_0 = False
    http_f_d_0 = HttpFD(tuple_0, int_0)
    http_f_d_0.real_download(bool_0, str_0)



# Generated at 2022-06-26 11:30:10.660051
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    try:
        test_case_0()
        assert False
    except UnboundLocalError:
        pass


# Generated at 2022-06-26 11:30:11.722224
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD()


# Generated at 2022-06-26 11:30:20.762414
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Boolean value 'bool_0'
    bool_0 = False
    # String value 'str_0'
    str_0 = ']Sa]C'
    # Empty tuple 'tuple_0'
    tuple_0 = ()
    # Integer value 'int_0'
    int_0 = 4342
    # Class 'http_f_d_0'
    http_f_d_0 = HttpFD(tuple_0, int_0)
    # Method 'real_download' of class 'HttpFD'
    var_0 = http_f_d_0.real_download(bool_0, str_0)
    # AssertionError
    if var_0 != True:
        raise AssertionError()


# Generated at 2022-06-26 11:30:24.925979
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'test file'
    tuple_0 = (1, 2, 3)
    int_0 = 3
    http_f_d_0 = HttpFD(tuple_0, int_0)
    http_f_d_0.real_download(True, str_0)
    int_1 = http_f_d_0.get_num_retries()
    if int_1 < int_0:
        print('FAILED')
    else:
        print('PASSED')

if __name__ == '__main__':
    test_case_0()
    test_HttpFD()

# Generated at 2022-06-26 11:30:28.718200
# Unit test for constructor of class HttpFD
def test_HttpFD():
    tuple_0 = ()
    int_0 = 8083
    http_f_d_0 = HttpFD(tuple_0, int_0)


# Generated at 2022-06-26 11:30:30.816284
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

test_cases = [test_HttpFD_real_download]


# Generated at 2022-06-26 11:31:58.682659
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:08.586718
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD(())

# Generated at 2022-06-26 11:32:16.067001
# Unit test for constructor of class HttpFD
def test_HttpFD():
    tuple_0 = ('X',)
    int_0 = 548
    http_f_d_0 = HttpFD(tuple_0, int_0)

# Generated at 2022-06-26 11:32:26.734843
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def test_func(bool_0, str_0):
        # 1. Setup
        tuple_0 = ()
        int_0 = 4342
        http_f_d_0 = HttpFD(tuple_0, int_0)
        # 2. Invoke
        var_0 = http_f_d_0.real_download(bool_0, str_0)
        # 3. Assert
        return var_0
    # Setup
    bool_1 = False
    str_1 = 'o2Qyj'
    # Invoke
    var_0 = test_HttpFD_real_download()
    # Assert
    assert var_0


# Generated at 2022-06-26 11:32:27.650409
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Verify that real_download method works correctly
    # Not Implemented
    raise NotImplementedError


# Generated at 2022-06-26 11:32:31.105420
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    bool_0 = True
    str_0 = 'Qzj'
    tuple_0 = ()
    int_0 = -20604
    http_f_d_0 = HttpFD(tuple_0, int_0)
    var_0 = http_f_d_0.real_download(bool_0, str_0)

if __name__ == '__main__':
    #test_case_0()
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:32:33.867861
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Executing test_HttpFD...')
    http_fd = HttpFD({'test-field': None}, 2000)
    assert isinstance(http_fd, HttpFD)
    print('test_HttpFD has executed successfully.')


# Generated at 2022-06-26 11:32:41.771572
# Unit test for constructor of class HttpFD
def test_HttpFD():
    tuple_0 = ()
    int_0 = random.randint(1, 8)
    http_f_d_0 = HttpFD(tuple_0, int_0)
    # filetype = 'video_id'
    str_0 = 'video_id'
    # filename = 'video_id'
    # info_dict = {},
    # params = {},
    # progress_hooks = ()
    bool_0 = False
    # info = 'info'
    int_1 = random.randint(1, 248)
    # test = False,
    int_2 = random.randint(1, 65)
    # retries = 2,
    int_3 = random.randint(1, 117)
    # true_start = False,
    # test_downloader = None,
    # d

# Generated at 2022-06-26 11:32:43.348978
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:32:45.287556
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    for _ in range(100):
        test_case_0()
