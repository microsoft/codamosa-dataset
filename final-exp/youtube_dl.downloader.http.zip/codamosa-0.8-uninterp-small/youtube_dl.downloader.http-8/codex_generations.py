

# Generated at 2022-06-26 11:27:02.498985
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def __wrap_foo(self_0, info_dict_0, filename_0, info_0):
        try:
            foo(self_0, info_dict_0, filename_0, info_0)
        except RetryDownload:
            pass

    def foo(self_0, info_dict_0, filename_0, info_0):
        print('[download] test_case_1.py has already been downloaded')
        raise SucceedDownload()
    test_case_0()
    test_case_1 = HttpFD(True, True)
    test_case_0()
    test_case_1.report_destination = __wrap_foo
    test_case_2 = {
        'filetime': None,
        'test_case_1': 'url',
    }

# Generated at 2022-06-26 11:27:14.405025
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create an object
    obj = HttpFD(False, False)
    # Access protected member in order to set initial values for test
    obj._ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    obj._ydl.params['restrictfilenames'] = True
    obj._ydl.params['nocheckcertificate'] = False
    obj._ydl.params['prefer_ffmpeg'] = True
    obj._ydl.params['verbose'] = True
    obj._ydl.params['quiet'] = True

    # Create input variables
    url = 'https://www.youtube.com/watch?v=1FJHYqE0RDg'
    filename = '1FJHYqE0RDg.%(ext)s'

# Generated at 2022-06-26 11:27:21.569744
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = YDL(ydl_opts)
    old_hooks = ydl.add_default_info_extractors()
    url = 'http://sample.mp4'
    info_dict = {
        'id': 'http://sample.mp4',
    }
    stream_dict = {
        'itag': '0',
        'url': url,
        'http_headers': {},
        'player_url': None,
        'title': 'test',
    }
    ydl.params['json_output'] = True

    # Setup download context

# Generated at 2022-06-26 11:27:29.109169
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d_0 = HttpFD()
    with test_requests.mock() as m:
        m.get("https://httpbin.org/range/1024?chunk_size=1024", headers={'content-range': 'bytes 0-1023/1024'}, content=b'\x00' * 1024)
        m.get("https://httpbin.org/range/1024?chunk_size=1024", headers={'content-range': 'bytes 1024-2047/1024'}, content=b'\x00' * 1024)
        http_f_d_0.real_download(bool_0, bool_0)
        ctx = http_f_d_0.ctx
        assert ctx.data_len == 1024
        assert ctx.chunk_size == 1024

# Generated at 2022-06-26 11:27:32.020238
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    bool_0 = bool(True)
    http_f_d_0 = HttpFD(bool_0, bool_0)


# Generated at 2022-06-26 11:27:33.293079
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:34.494352
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:27:35.676926
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass

test_case_0()

# Generated at 2022-06-26 11:27:41.946981
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test URL
    url = 'https://github.com/downloads/rg3/youtube-dl/youtube-dl-2012.02.27.1.exe'
    # Data length for the test file
    data_len = 181309
    # Chunk size for the test file
    chunk_size = 100
    # Max number of attempts for download
    max_attempts = 3
    # Download output file
    dest = 'test_output'
    # Header name for a range request
    b_range_header = 'Range'
    # Test URL range
    test_range = 'bytes=0-%s' % chunk_size

    http_f_d = HttpFD(0, 0)
    http_f_d.params['noprogress'] = True
    http_f_d.params['quiet'] = True


# Generated at 2022-06-26 11:27:42.650912
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:28:25.188016
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # str_0 = '^A2$Z@"@V@mCl\'fsw-J'
    # list_0 = None
    # float_0 = 9103.0
    # http_f_d_0 = HttpFD(float_0, float_0)
    # var_0 = http_f_d_0.real_download(str_0, list_0)
    # assert var_0 == True
    pass



# Generated at 2022-06-26 11:28:31.791768
# Unit test for constructor of class HttpFD
def test_HttpFD():
    float_0 = float(0)
    float_1 = float(0)
    float_2 = float(0)
    float_3 = float(0)
    float_4 = float(0)
    float_5 = float(0)
    float_6 = float(0)
    float_7 = float(0)
    float_8 = float(0)
    float_9 = float(0)
    float_10 = float(0)
    float_11 = float(0)
    float_12 = float(0)
    float_13 = float(0)
    float_14 = float(0)
    float_15 = float(0)
    float_16 = float(0)
    float_17 = float(0)
    float_18 = float(0)
    float_19 = float(0)

# Generated at 2022-06-26 11:28:34.047328
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:28:34.707296
# Unit test for constructor of class HttpFD
def test_HttpFD():
    pass


# Generated at 2022-06-26 11:28:36.890523
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Describing the unit test class

# Generated at 2022-06-26 11:28:48.607430
# Unit test for constructor of class HttpFD
def test_HttpFD():
    expected_instance_attributes = ['ydl', 'params', 'to_screen', 'to_stderr', 'max_retries', '_hook_progress', '_TEST_FILE_SIZE', '_errno_from_exception', 'report_error', 'report_warning', 'report_retry', 'report_resuming_byte', 'report_restarting', 'report_file_already_downloaded', 'report_unable_to_resume', 'report_destination', 'try_rename', 'undo_temp_name', 'try_utime', 'best_block_size', 'calc_speed', 'calc_eta', 'sanitize_open', 'slow_down', 'real_download']

    http_fd_0 = HttpFD(0, 0)

    # Check that all expected instance attributes are present

# Generated at 2022-06-26 11:28:49.807330
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:28:50.300766
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return


# Generated at 2022-06-26 11:28:52.278364
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD()
    assert isinstance(http_fd, HttpFD)


# Generated at 2022-06-26 11:28:54.818467
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:29:59.019891
# Unit test for constructor of class HttpFD

# Generated at 2022-06-26 11:30:01.871010
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    assert isinstance(http_f_d_0, HttpFD)


# Generated at 2022-06-26 11:30:04.696924
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD(None, None)
    assert isinstance(http_f_d_0, HttpFD)


# Generated at 2022-06-26 11:30:05.822224
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # placeholder
    return


# Generated at 2022-06-26 11:30:16.412075
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:30:21.028037
# Unit test for constructor of class HttpFD
def test_HttpFD():
    float_0 = 19077.0
    float_1 = 9002.0
    http_f_d_0 = HttpFD(float_0, float_1)
    float_2 = http_f_d_0.max_speed()
    float_3 = http_f_d_0.min_speed()
    float_4 = http_f_d_0.avg_speed()


# Generated at 2022-06-26 11:30:22.846286
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


# Generated at 2022-06-26 11:30:24.170076
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 11:30:33.378937
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

if __name__ == '__main__':

    # Only for debugging purposes.
    # For unit testing, use test_HttpFD_real_download()
    if not test_HttpFD_real_download():
        raise RuntimeError('test_HttpFD_real_download failed')

    # Run the unit test for HttpFD.
    # This will be run if the test is not executed from the YouTubeDL test suite.
    # It will not run from the YouTubeDL test suite, because there is another
    # test function in the YouTubeDL test suite that covers the unit test part.
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:30:43.220020
# Unit test for constructor of class HttpFD
def test_HttpFD():
    global urlopen

    urlopen = lambda url, data=None, timeout=None, *a, **kw: compat_urllib_request.urlopen(url, data, timeout=5, *a, **kw)
    c0 = lambda c: compat_ord('0') <= c <= compat_ord('9')
    n_b_s = lambda s: len(s) == 0 or (not c0(s[0]) and n_b_s(s[1:]))
    h_b_s_f = lambda *a: (False,)
    def _test_case_0():
        str_0 = '^A2$Z@"@V@mCl\'fsw-J'
        list_0 = None
        float_0 = 9103.0

# Generated at 2022-06-26 11:33:27.337258
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# Tests the method calc_speed of class HttpFD
# 1. Time elapsed must be greater than 0
# 2. Bytes must be greater than 0
# 3. The speed must be in the range 0.0 to 1000000000.0

# Generated at 2022-06-26 11:33:30.763793
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(0, 0)
    assert http_fd.ydl is None
    assert http_fd.params == {}
    assert http_fd.tmpfilename is None
    assert http_fd.prev_hooks == {}
    test_case_0()
    print("Test completed successfully")


# Generated at 2022-06-26 11:33:31.697273
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert isinstance(HttpFD, type)


# Generated at 2022-06-26 11:33:36.532341
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = '^A2$Z@"@V@mCl\'fsw-J'
    list_1 = None
    float_0 = 9103.0
    http_f_d_0 = HttpFD(float_0, float_0)
    return

test_case_0()
test_HttpFD()

# Generated at 2022-06-26 11:33:44.627078
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from random import randint
    from random import random
    from random import seed
    str_0 = '^A2$Z@"@V@mCl\'fsw-J'
    int_0 = randint(0, 0)
    float_0 = 9103.0
    float_1 = 9103.0
    float_2 = 9103.0
    float_3 = 9103.0
    float_4 = 9103.0
    float_5 = 9103.0
    float_6 = 9103.0
    float_7 = 9103.0
    float_8 = 9103.0
    float_9 = 9103.0
    float_10 = 9103.0
    float_11 = 9103.0
    float_12 = 9103.0
    float_13 = 9103.0
    float

# Generated at 2022-06-26 11:33:52.183731
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression
    #
    test_case_0()

    #
    # Test using an expression


# Generated at 2022-06-26 11:33:55.241954
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl_0 = YoutubeDL()
    int_0 = -16
    bool_0 = True
    http_f_d_0 = HttpFD(ydl_0, int_0, bool_0)
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:33:57.675806
# Unit test for constructor of class HttpFD
def test_HttpFD():
    int_0 = 1
    str_0 = 'V{=;Qaxh7'
    http_f_d_0 = HttpFD(int_0, str_0)


# Generated at 2022-06-26 11:33:59.428586
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(0, None)
    assert http_fd != None


# Generated at 2022-06-26 11:34:01.043635
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    method_0 = HttpFD.real_download
    test_case_0()

