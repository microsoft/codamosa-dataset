

# Generated at 2022-06-26 11:27:03.502140
# Unit test for constructor of class HttpFD
def test_HttpFD():
    float_0 = -764.66
    dict_0 = {float_0: float_0}
    http_f_d_0 = HttpFD(float_0, dict_0)
    assert(http_f_d_0.name == float_0)
    assert(http_f_d_0.info == dict_0)


# Generated at 2022-06-26 11:27:13.608540
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    float_0 = -2624.2
    dict_0 = {float_0: float_0}
    http_f_d_0 = HttpFD(float_0, dict_0)
    str_0 = 'zX'
    str_1 = 'TQ'
    url_0 = 'http://www.youtube.com/watch?v=BaW_jenozKc&feature=topvideos_film'
    dict_1 = {str_0: 'BaW_jenozKc', str_1: 'TQ'}
    bool_0 = http_f_d_0.real_download(url_0, dict_1)
    assert bool_0


# Generated at 2022-06-26 11:27:17.530495
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    http_fd.real_download("url", None, None)

if __name__ == "__main__":

    test_case_0()
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:21.234941
# Unit test for constructor of class HttpFD
def test_HttpFD():
    float_0 = 556.79
    dict_0 = {float_0: float_0}
    http_f_d_0 = HttpFD(float_0, dict_0)
    print(http_f_d_0)


# Generated at 2022-06-26 11:27:23.527526
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # test_case_0 passed
    test_case_0()

if __name__ == '__main__':
    test_HttpFD_real_download()
# }}}

# Generated at 2022-06-26 11:27:29.158194
# Unit test for constructor of class HttpFD
def test_HttpFD():
    DummyHttpFD = mock.Mock()
    dict_0 = {'http_fd_a': DummyHttpFD}
    http_FD_0 = HttpFD('http_fd_url', dict_0)
    try:
        assert dict_0[DummyHttpFD] == DummyHttpFD
    except Exception:
        pass
    try:
        assert http_FD_0.url == 'http_fd_url'
    except Exception:
        pass
    try:
        assert dict_0[DummyHttpFD] == http_FD_0
    except Exception:
        pass

# test of download() method with DownloadError, ContentTooShortError and FileNotFoundError

# Generated at 2022-06-26 11:27:34.681102
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_arg_0 = ()
    HttpFD_class = HttpFD.HttpFD
    http_fd_ins = HttpFD_class(*test_arg_0)
    test_arg_1 = (test_arg_0)
    http_fd_ins.real_download(test_arg_1)

test_case_0()
test_HttpFD_real_download()

# Generated at 2022-06-26 11:27:41.763984
# Unit test for constructor of class HttpFD
def test_HttpFD():
    boolean_0 = False
    float_4 = 23
    boolean_1 = False
    float_1 = -365.7
    float_3 = 99.3
    float_2 = -36.4
    string_0 = '9Sg'
    string_1 = 'gP3q0'
    char_0 = 'Y'
    boolean_2 = True
    int_0 = 0
    float_5 = 66
    http_f_d_0 = HttpFD(int_0, {string_0: char_0, string_1: float_1})
    assert http_f_d_0.http_data_len == 66
    int_1 = http_f_d_0.download(boolean_0, float_2, float_3)
    assert int_1 == 0

# Generated at 2022-06-26 11:27:45.725253
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd_0 = HttpFD(3, {3: 3})
    http_fd_0.params = {3: 3, 'noresizebuffer': True}
    assert http_fd_0.real_download({3: 3, 'retries': 1, 'test': True, 'data': 3, 'retries_sleep': 3, 'resume_len': 3}, 'a')

# Test #1
# real_download() should return True

# Generated at 2022-06-26 11:27:56.408853
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_case_0()

# End of Main routine

#     *************
#     *   Main   *
#     *************

# Begin of Main routine

# Main routine:
parser = argparse.ArgumentParser(description='Download videos from YouTube.com.')
parser.add_argument('url', help='URL of the video to download')
parser.add_argument('-h', '--help', help='show this help message and exit', action='store_true')
parser.add_argument('-v', '--version', help='print program version and exit', action='version', version='%(prog)s 2016.01.10')
parser.add_argument('-u', '--username', help='account username')
parser.add_argument('-p', '--password', help='account password')
parser.add_argument

# Generated at 2022-06-26 11:28:38.733635
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # ARRANGE
    http_fd_0 = HttpFD()
    http_fd_1 = HttpFD()
    global str_0
    global str_1
    # ACT
    test_case_0()
    # ASSERT
    assert (http_fd_0.http_fd_a == 0), "http_fd_0.http_fd_a == %s" % str(0)
    assert (http_fd_1.http_fd_url == 'http://localhost:8000/fd/fd_a.gz'), "http_fd_1.http_fd_url == %s" % str('http://localhost:8000/fd/fd_a.gz')


# Generated at 2022-06-26 11:28:45.564078
# Unit test for constructor of class HttpFD
def test_HttpFD():
    str_0 = 'http_fd_a'
    str_1 = 'http_fd_url'

    # Init
    http_fd_a = HttpFD(str_1, str_0)

    # Asserts
    assert http_fd_a.url == str_1
    assert http_fd_a.ydl == str_0


# Generated at 2022-06-26 11:28:46.729411
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    tt.launch_subprocess(test_case_0, (), tt.normal_exit)


# Generated at 2022-06-26 11:28:58.266550
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from nose.tools import eq_, ok_, raises
    from yt_dl import YoutubeDL

    try:
        import ssl
        ok_(ssl.SSLContext)  # Requires Python 2.7.9 or 3.4
    except (ImportError, AttributeError):
        return

    def test_https():
        eq_('https', real_download(YoutubeDL(), 'https://127.0.0.1/'))

    test_https()

    import certifi
    if hasattr(certifi, 'old_where'):
        certifi.where = certifi.old_where

        test_https()

        import ssl
        orig_ssl_create_default_context = ssl.create_default_context


# Generated at 2022-06-26 11:29:10.824195
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    it = HttpFD()
    # Test case with bad arguments
    try:
        it.real_download(None, None, None)
    except Exception as e:
        assert_match('argument "info_dict" is required', str(e))
    try:
        it.real_download(None, None, None, None, None)
    except Exception as e:
        assert_match('argument "info_dict" is required', str(e))
    try:
        it.real_download(None, None, None, None, None, None, None)
    except Exception as e:
        assert_match('argument "info_dict" is required', str(e))
    try:
        it.real_download(None, None, None, None, None, None, None, None)
    except Exception as e:
        assert_match

# Generated at 2022-06-26 11:29:15.507413
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD({})
    fd.real_download({'url': 'http_fd_url', 'http_fd': 'http_fd_a'})

if __name__ == '__main__':
    test_case_0()
    test_HttpFD_real_download()

# Generated at 2022-06-26 11:29:27.645622
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('test_HttpFD()')
    arguments = sys.argv[1:]
    if len(arguments) < 3:
        print('test_HttpFD(): test case 0')
        test_case_0()
    else:
        print('test_HttpFD(): test case 1')
        str_0 = arguments[0]
        str_1 = arguments[1]
        str_2 = arguments[2]
        assert str_0 == 'http_fd_a'
        assert str_1 == 'http_fd_url'
        assert str_2 == 'http_fd_info_dict'

# Generated at 2022-06-26 11:29:38.052717
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing constructor of class HttpFD ... ')
    http_fd_0 = HttpFD({'http_chunk_size': 2, 'http_nocache': True}, None, 'http://www.youtube.com/watch?v=SbaJMzde0D0')
    http_fd_1 = HttpFD({'http_chunk_size': 2, 'http_nocache': True, 'ratelimit': 1}, None, 'http://www.youtube.com/watch?v=SbaJMzde0D0')
    http_fd_2 = HttpFD({'http_chunk_size': 2, 'http_nocache': True, 'noresizebuffer': True}, None, 'http://www.youtube.com/watch?v=SbaJMzde0D0')
    http_fd_3

# Generated at 2022-06-26 11:29:41.660413
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    hfd = HttpFD()
    res = hfd.real_download()
    assert res == True

if __name__ == '__main__':
    hfd = HttpFD()
    hfd.real_download()
    # test_HttpFD_real_download()

# Generated at 2022-06-26 11:29:42.930239
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    test_case_0()


# Generated at 2022-06-26 11:30:21.880081
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    ctx = { 
        'tmpfilename': 'tmpfilename', 
        'filename': 'filename', 
        'resume_len': 0, 
        'open_mode': 'wb'
    }
    http_fd._real_download( 'http://www.example.com/', ctx, 'GET', '', 
        { 'x-test': 'hello' }, '', is_test=True, retries=0 )
    assert os.path.isfile(ctx['tmpfilename']) == True
    os.remove(ctx['tmpfilename'])


# Generated at 2022-06-26 11:30:23.905994
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:30:35.313252
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    t_http_fd = HttpFD()
    t_url = None # replace with test value
    t_filename = None # replace with test value
    t_info_dict = None # replace with test value
    t_resume_len = None # replace with test value
    t_total_size = None # replace with test value
    t_ctx = None # replace with test value
    t_max_prebuffer = None # replace with test value
    t_retries = None # replace with test value
    t_fragment_retries = None # replace with test value
    t_temp_name = None # replace with test value
    t_is_test = None # replace with test value

# Generated at 2022-06-26 11:30:37.589626
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    pass


# Generated at 2022-06-26 11:30:38.904352
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()


# Generated at 2022-06-26 11:30:46.765392
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-26 11:30:57.078975
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    HttpFD_real_download = HttpFD.real_download.__func__

    def test_params(url, params, filename, info_dict):
        if (filename == '-') and sys.version_info >= (3, 2):
            filename = sys.stdout.buffer
        return {
            'url': url,
            'params': params or {},
            'filename': filename,
            'info_dict': info_dict or {},
        }

    def test0():
        print('Test case 0')
        print('url: %s' % 'http://ipv4.download.thinkbroadband.com/100MB.zip')
        print('filename: %s' % '100MB.zip')
        print('params: %s' % {})

# Generated at 2022-06-26 11:30:59.404141
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD()
    if http_fd is not None:
        print("Constructor of class HttpFD work")
        return True

    return False


# Generated at 2022-06-26 11:31:00.744989
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    print('Test of HttpFD is passed')

# test_HttpFD()

# Generated at 2022-06-26 11:31:08.276451
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor('test_ie')
    ydl.prepare_filename = lambda x: x['id']
    ydl.params = {'nooverwrites': True, 'continuedl': True, 'skip_download': True}
    filepath = ydl.prepare_filename({'id': 'test', 'title': 'test title'})

# Generated at 2022-06-26 11:32:24.509606
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()
    return 0

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:32:28.028155
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if not hasattr(unittest, 'skipTest'):
        # for Python 2.6
        import unittest2 as unittest
    from .common import test_case_main
    test_case_main('test_HttpFD', [test_case_0])

# Generated at 2022-06-26 11:32:33.415900
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def check_result(res, fn):
        if os.path.exists(fn):
            os.remove(fn)
        assert res == True
        assert os.path.exists(fn)
        assert os.path.getsize(fn) > 0
        os.remove(fn)
    urls = ['https://www.youtube.com/watch?v=9bZkp7q19f0', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ']
    fns = ['temp_video.mp4', 'temp_video2.mp4']
    for (url, fn) in zip(urls, fns):
        http_f_d_0 = HttpFD()
        res = http_f_d_0.real_download(url, fn, False)

# Generated at 2022-06-26 11:32:41.409119
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # First test a file with size greater than 0
    # and a temporary file different from the destination file
    http_f_d_0 = HttpFD()
    real_download0 = http_f_d_0.real_download(
        'http://www.google.com',
        {},
        'tmp-file.tmp',
        'google.com'
    )
    # Second test a file with size greater than 0
    # and a temporary file equal to the destination file
    http_f_d_1 = HttpFD()
    real_download1 = http_f_d_1.real_download(
        'http://www.google.com',
        {},
        'google.com',
        'google.com'
    )
    # Third test a file with size equal to 0
    http_f_d_

# Generated at 2022-06-26 11:32:44.222808
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()  # Default constructor
    assert http_f_d_0.__class__ == HttpFD


# Generated at 2022-06-26 11:32:54.881010
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD()

    # Test case 0
    # Check the download of small file
    assert fd.real_download({'url': 'http://ipv4.download.thinkbroadband.com/5MB.zip', 'params': {'noprogress': True}}, 'test_case_0.zip')

    # Test case 1
    # Check the download of big file (4GB), using multiple connections
    assert fd.real_download({'url': 'http://ipv4.download.thinkbroadband.com/4GB.zip', 'params': {'noprogress': True}}, 'test_case_1.zip')

    # Test case 2
    # Check the download of a file with a retry

# Generated at 2022-06-26 11:32:58.871326
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_f_d = HttpFD()
    ### http://example.com/
    ### http://www.example.com/
    ### http://example.com/
    # url = urlopen('http://example.com/').geturl()
    # url = urlopen('http://www.example.com/').geturl()
    # url = urlopen('http://example.com/').geturl()
    # assert http_f_d.real_download(url, {}, {'skip_existing': True}) == True



# Generated at 2022-06-26 11:33:06.218697
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Case 1: test constructor with default arguments
    http_f_d = HttpFD()
    if http_f_d is None:
        print('case 1: test constructor with default arguments: failed')
        return False
    else:
        print('case 1: test constructor with default arguments: passed')

    # Case 2: test constructor with other arguments
    ydl = True
    params = {'noprogress': True, 'retries': 10, 'continuedl': True, 'noresizebuffer': True}
    http_f_d = HttpFD(ydl, params)
    if http_f_d is None:
        print('case 2: test constructor with other arguments: failed')
        return False
    else:
        print('case 2: test constructor with other arguments: passed')

    # Case 3: test constructor with a wrong

# Generated at 2022-06-26 11:33:10.082213
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    _run_test_download_method(
        HttpFD(),
        test_case_ids = [0, 1],
        num_tries = 1,
        max_len = 16384,
        chunk_size = 16384,
        verbose = True,
        )


# Generated at 2022-06-26 11:33:12.514779
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("class HttpFD:")
    print("def __init__(self):")
    http_f_d_0 = HttpFD()


# Generated at 2022-06-26 11:35:07.820793
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d_0 = HttpFD()
    status_0 = HttpFD.status
    assert status_0 == 'Not connected yet'
    protocol_0 = HttpFD.protocol
    assert protocol_0 == 'http'
    socket_type_0 = HttpFD.socket_type
    assert socket_type_0 == socket.SOCK_STREAM
    try:
        host_0 = HttpFD.host
        assert False
    except AttributeError:
        pass
    try:
        port_0 = HttpFD.port
        assert False
    except AttributeError:
        pass
    try:
        source_address_0 = HttpFD.source_address
        assert False
    except AttributeError:
        pass
    timeout_0 = HttpFD.timeout
    assert timeout_0 == socket

# Generated at 2022-06-26 11:35:10.062518
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_f_d = HttpFD()




# Generated at 2022-06-26 11:35:13.593629
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print("start of test_HttpFD")
    http_f_d_0 = HttpFD()
    print("end of test_HttpFD")


# Generated at 2022-06-26 11:35:22.798926
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # http_f_d_1 = HttpFD();
    # http_f_d_1.real_download(None, 'http://www.python.org', None, None);

    http_f_d_1 = HttpFD();
    http_f_d_1.real_download('test_file', 'http://www.python.org/index.html', None, None);
    assert os.path.exists('test_file');
    os.remove('test_file');
    pass;


# Generated at 2022-06-26 11:35:29.871908
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()

    # The number of times a download is tried
    http_fd.preferredencoding = 'utf-8'

# Generated at 2022-06-26 11:35:37.886932
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # Test case 0
    # Real download with wrong size specification
    # Destination file must be downloaded fully, no chunks
    global test_case_0_ctx
    test_case_0_ctx = None
    def test_case_0_hook_progress(status):
        test_case_0_ctx = status
    http_f_d_0 = HttpFD()
    http_f_d_0.params['noprogress'] = False

# Generated at 2022-06-26 11:35:48.859248
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test simple download (no problems expected)
    # Downloaded file is expected to be t_file_0a.txt
    url_0a = 'http://krum.rz.tu-clausthal.de/~bfr/pub/http_fd/' \
             't_file_0a.txt'
    # Open destination file t_file_0a.txt for writing
    stream_0a = io.open('t_file_0a.txt', 'wb')

    # Obtain info() object for the given URL
    info_0 = compat_urllib_request.build_opener(
        compat_urllib_request.HTTPCookieProcessor()).open(url_0a)

    # Check that info_0.info() is a valid return value of the
    # open()-method of the

# Generated at 2022-06-26 11:35:50.370317
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:35:51.664954
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_case_0()


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-26 11:35:57.173710
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # http_f_d_0.real_download(url='', filename='', info_dict=None, headers=None, reporthook=None, progress_hook=None, downscale_polymatroid=True)
    # TODO: inspect real_download for better testing
    http_f_d_1 = HttpFD()
    http_f_d_0.real_download('', '', {}, {}, httplib.HTTPResponse)
    http_f_d_0.real_download('', '', {}, {}, httplib.HTTPResponse)
    http_f_d_0.real_download('', '', {}, {}, httplib.HTTPResponse)