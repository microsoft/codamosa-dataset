

# Generated at 2022-06-24 11:52:54.435057
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    from .extractor import get_info_extractor

    ie = get_info_extractor('youtube', None)
    # Stolen from test_suite.py

# Generated at 2022-06-24 11:53:01.397467
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD(None, params={'noprogress': True, 'continuedl': False, 'ratelimit': 3072000, 'noresizebuffer': True, 'test': True})
    fd.data = compat_urllib_request.urlopen('https://github.com/rg3/youtube-dl/raw/master/README.md')
    fd.data_len = int(fd.data.info().get('Content-Length', None))
    fd.tmpfilename = fd.filename = 'test'
    fd.open_mode = 'wb'
    assert fd.real_download(is_test=True)
    os.remove('test')

# Generated at 2022-06-24 11:53:09.946399
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test two error conditions with retries
    params = {'usenetrc': False, 'nooverwrites': False, 'retries': 2}
    def mytest2(ydl, e):
        """Make sure we get the same exception back"""
        assert isinstance(e, compat_urllib_error.HTTPError)
        assert e.code in [503, 504]
    def mytest(ydl, e):
        """Check if we get a 503 or a 504 error"""
        assert isinstance(e, compat_urllib_error.HTTPError)
        assert e.code in [503, 504]
        return True
    urlopen = URLOpen()

# Generated at 2022-06-24 11:53:20.378151
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test the HttpFD real_download() method
    # (see https://github.com/ytdl-org/youtube-dl/issues/67)

    import unittest
    import tempfile
    import os
    import sys
    import shutil

    # Test URL and length of file
    URL = 'http://ipv4.download.thinkbroadband.com/5MB.zip'
    DATALEN = 5 * 1024 * 1024

    class TestDownload(unittest.TestCase):
        def setUp(self):
            # Put temporary file in our own directory so we can find it
            # later to check if downloading was successful
            temp_dir = os.path.dirname(os.path.abspath(__file__))
            # Make sure our directory exists
            assert os.path.isdir(temp_dir)

# Generated at 2022-06-24 11:53:31.584098
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    from .YoutubeDL import YoutubeDL
    class Params():
        def __init__(self, verbose=False, test=False):
            self.verbose = verbose
            self.test = test
            self.noresizebuffer = False
            self.retries = 10
            self.continuedl = True
            self.buffersize = None
            self.noprogress = False
            self.ratelimit = None
            self.min_filesize = None
            self.max_filesize = None
            self.test = test
        def get(self, key, default=None):
            return getattr(self, key, default)
        def __contains__(self, key):
            return hasattr(self, key)

    params = Params(test=True)
    params.test = True

# Generated at 2022-06-24 11:53:41.626531
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import FileDownloader
    from .downloader.external import ExternalFD
    from .utils import encodeFilename

    class FakeYDL:
        params = {
            'nooverwrites': False,
            'continuedl': False,
            'exit_on_error': True,
        }
        def to_screen(self, *_):
            pass
        def trouble(self, *_):
            pass
    class FakeFD(ExternalFD):
        def __init__(self, *args, **kwargs):
            self.ydl = FakeYDL(*args, **kwargs)
            self.params = FakeYDL.params
            self.tmpfilename = None

# Generated at 2022-06-24 11:53:53.357490
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import pytest
    if pytest.config.option.tbstyle == 'short':
        pytest.skip("--tb=short disables the check")
    print('Testing method HttpFD.real_download')
    def real_download(self, info_dict, filename, info_dict_len, test, resuming):
        info_dict['downloaded_bytes'] = 0
        info_dict['total_bytes'] = info_dict_len
        info_dict['tmpfilename'] = info_dict['filename'] = filename
        info_dict['status'] = 'downloading'
        info_dict['elapsed'] = 0
        with open(filename, 'wb') as f:
            for i in range(info_dict_len):
                f.write(b'\0')
        info_dict['status'] = 'finished'


# Generated at 2022-06-24 11:54:00.167534
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os
    import sys
    import tempfile
    tmpdir = tempfile.mkdtemp()
    tmpfilename = os.path.join(tmpdir, 'tmpfile')

# Generated at 2022-06-24 11:54:11.609727
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test 'real_download' method of class 'HttpFD'."""
    # Skip tests if module 'socks' is unavailable
    if not have_socks:
        return True
    # Skip tests if module 'pycurl' is unavailable
    if not have_pycurl:
        return True
    # Skip tests if module 'ssl' is unavailable
    if not have_ssl:
        return True
    # Tests of 'real_download' method of class 'HttpFD' are very tricky.
    # We need a mock server that mimics a real one. For example,
    # a mock server could be written using the 'BaseHTTPServer' module,
    # but it would be mocked too much. More difficult is to capture
    # the socket in order to send data to the client (mock server)
    # from the client (HttpFD). The 's

# Generated at 2022-06-24 11:54:22.402610
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # read a small file (legally) hosted at github to check if the headers are handled correctly
    # if the file was read correctly, the first 4 bytes should be b'PK\x03\x04'

    url = 'https://github.com/rg3/youtube-dl/blob/master/youtube_dl/version.py'
    filename = 'test_version.py'

    # parameters for HttpFD constructor

# Generated at 2022-06-24 11:54:26.914446
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD('http://www.example.org/one.txt', {}, None).get_size() == 12
    assert HttpFD('http://www.example.org/two.txt', {}, None).get_size() == 14



# Generated at 2022-06-24 11:54:31.962873
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create HttpFD instance with the smallest possible length,
    # and check the length of the dummy file it holds
    # (1kB is the minimal possible size of the dummy file)
    h = HttpFD(1024)
    assert h.size == 1024
    h.close()


# class IsolatedFD


# Generated at 2022-06-24 11:54:42.009203
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test without progress hook
    fd = HttpFD(
        'http://example.com/', {
            'noprogress': True,
            'quiet': True,
            'ratelimit': 10240,
            'retries': 10,
        })
    assert fd.prog_hooks == []
    # Test with progress hook
    fd = HttpFD(
        'http://example.com/', {
            'noprogress': True,
            'quiet': True,
            'ratelimit': 10240,
            'retries': 10,
        },
        lambda d: d,
    )
    assert fd.prog_hooks == [lambda d: d]



# Generated at 2022-06-24 11:54:51.104212
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # import doctest
    # doctest.testmod()
    from .common import FakeYDL

    fd = HttpFD(False, {}, False)
    fd.ydl = FakeYDL()
    # test_urls = [('http://127.0.0.1:8080/%s' % path, bytes) for path, bytes in [
    #     ('1k', 1024),
    #     ('2k', 2 * 1024),
    #     ('4k', 4 * 1024),
    #     ('4k_5', 4 * 1024 + 512),
    #     ('4k_1', 4 * 1024 + 1),
    #     ('4k_0', 4 * 1024),
    #     ('6k_0', 6 * 1024),
    #     ('2k_1', 2 * 1024 + 1),
   

# Generated at 2022-06-24 11:54:57.510838
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    # Setup test environment
    test = True
    # Testing single chunk download
    ydl = FakeYDL()
    ie = InfoExtractor()
    ie.ydl = ydl
    ie._writeinfojson = lambda *a: None
    ie._hook_progress = lambda *a: None

    # Testing single chunk download

# Generated at 2022-06-24 11:55:05.458694
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import test_http_server
    import tempfile
    import socket
    import threading

    test_file_data = b'\x41' * 1000000
    test_file_size = len(test_file_data)
    test_file_name = 'test.file'

    class TestContentServer(test_http_server.TestServerHandler):
        def do_HEAD(self):
            self.send_response(302)
            self.send_header('Content-Length', test_file_size)
            self.send_header('Content-Type', 'video/mp4')
            self.send_header('ETag', '"test-etag"')
            self.send_header('Connection', 'close')
            self.send_header('Accept-Ranges', 'none')
            self.end_headers()


# Generated at 2022-06-24 11:55:18.400350
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    from .utils import encodeFilename
    from .extractor import gen_extractors
    from .compat import is_py2

    # Create a test file
    tmpfilename = 'test'
    stream, tfn = sanitize_open(tmpfilename, 'wb')
    try:
        os.write(stream.fileno(), b'hello')
    finally:
        stream.close()
    # Create an extractor
    ie = gen_extractors(u'test')[0]
    # Create a FileDownloader
    ydl = FileDownloader({'outtmpl': u'-'})
    # Instantiate an HttpFD
    fd = HttpFD(ydl, ie, u'http://127.0.0.1:3/test', {'test_option': True})
    # Patch url

# Generated at 2022-06-24 11:55:26.939923
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def faux_sleep(self, t):
        now = time.time()
        self.time_counter += t
        if self.time_counter > self.exit_time:
            assert self.exit_time == 0
            self.exit_time = now + t
        assert self.exit_time - now < t + .5
        return None

    def faux_resume_len(self, filename):
        self.opened_files.append(filename)
        if filename == 'Dumpty.flv':
            return 800
        elif filename.endswith('.flv'):
            return 400
        else:
            return None

    class MyFD(HttpFD):
        def __init__(self, params, filename, info_dict):
            HttpFD.__init__(self, params, filename, info_dict)


# Generated at 2022-06-24 11:55:33.740378
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if sys.version_info < (2, 6):
        return
    try:
        import json
    except ImportError:
        return
    json_data = '''
{"test": "test", "bar": 2, "foo": ["foo", 3]}
    '''
    (fd1, fn1) = tempfile.mkstemp()

# Generated at 2022-06-24 11:55:46.955870
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import ssl
    import tempfile
    import warnings
    import shutil
    import subprocess

    def try_execute(cmd):
        try:
            out = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
            return out.decode()
        except (OSError, subprocess.CalledProcessError) as err:
            if err.output:
                return err.output.decode()
            else:
                return str(err)

    dl = HttpFD()

    @contextlib.contextmanager
    def workdir(name):
        old_dir = os.getcwd()
        if not os.path.isdir(name):
            os.makedirs(name)
        os.chdir(name)

# Generated at 2022-06-24 11:55:53.554511
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Tests for HttpFD.real_download"""
    # Test for basic downloading
    def test_basic_downloading(self):
        """Test for basic downloading"""
        self.assertEqual(self.fd1.real_download('', self.url, '-'), True)
        self.assertEqual(self.fd1.real_download('-', self.url, '-'), True)
        self.assertEqual(self.fd1.real_download(self.tmpfilename, self.url, '-'), True)
        self.assertEqual(self.fd1.real_download(self.tmpfilename, self.url, '-'), True)
        video_data = open(self.tmpfilename, 'rb').read()
        self.assertEqual(video_data, self._TEST_URL_DATA)

    #

# Generated at 2022-06-24 11:56:00.037347
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import mock

    class DummyYTDL(object):
        def __init__(self, std_headers, params):
            self.params = params
            self.std_headers = std_headers

        def to_screen(self, *args, **kargs):
            pass

        def to_stdout(self, *args, **kargs):
            pass

        def to_stderr(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def urlopen(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass


# Generated at 2022-06-24 11:56:11.871411
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import testutils
    import http_testserver

    def download(ctx):
        def _callback(status):
            if status['status'] == 'downloading':
                return {'test_status': True}
        with testutils.test_server(handler=http_testserver.IncrementalHandler) as server:
            t0 = time.time()
            server.protocol = 'http'
            server.base_url = 'http://%s:%d/' % (server.server_address[0], server.server_address[1])
            server.handler.set_header('Content-Length', '42')
            server.handler.set_header('X-Test-Header', 'testheader')
            server.handler.set_header('Content-Type', 'application/octet-stream')

# Generated at 2022-06-24 11:56:13.950658
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """ Test for HttpFD constructor """
    hfd = HttpFD(None, {}, None, None)



# Generated at 2022-06-24 11:56:23.795945
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 11:56:36.058054
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_data_len = 1000  # total file size in bytes
    test_data_block_len = 100
    test_byte_counter = 250
    test_block_size = test_data_block_len * 10
    test_chunk_size = 50 * test_data_block_len
    test_resume_len = 200

    class TestClass(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'retries': 100,
                'test': True,
            }
            self.to_screen = lambda msg: None
            self.report_destination = lambda msg: None
            self.report_progress = lambda *args, **kargs: None
            self.report_error = lambda msg: None
            self.report_file_already_downloaded

# Generated at 2022-06-24 11:56:47.874984
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import tempfile

    (testfh, testfn) = tempfile.mkstemp()
    os.close(testfh)

    hdf = HttpFD(None, {}, 'Downloader')
    # Disable sleep()s in slow_down() to speed up this test
    hdf.real_download = types.MethodType(
        get_real_download(lambda s, a, b, c: None), hdf)

    url = 'http://127.0.0.1:%s/' % find_port()
    request = sanitized_Request(url, headers={
        'Accept-Encoding': 'identity;q=1, *;q=0'})
    serve_content(url, 'abcd' * 1000)

    # Test that we get NotFoundError if the server returns 404
    h

# Generated at 2022-06-24 11:56:59.745374
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for zero bytes file
    fd = HttpFD('http://www.example.org/')
    assert fd.size() == 0
    assert fd.read(32) == b''
    assert fd.size() == 0
    assert fd.read(32) == b''
    fd.close()

    # Test for non-zero bytes file
    fd = HttpFD('http://www.example.org/index.html')
    assert fd.size() > 0
    assert fd.read(32) != b''
    assert fd.size() > 0
    assert fd.read() != b''


# Generated at 2022-06-24 11:57:10.220347
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import random
    import re

    # Test urls

# Generated at 2022-06-24 11:57:19.704309
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL(object):
        def __init__(self):
            self.params = {'noprogress': True, 'logger': YoutubeDLHandler()}
        def to_stdout(self, s, on_same_line=False):
            pass
        def to_stderr(self, s):
            pass
        def trouble(self, s, tb=None):
            pass
        def report_error(self, s):
            pass
        def report_warning(self, s):
            pass
        def report_retry(self, s, t, m):
            pass
        def report_file_already_downloaded(self, f):
            pass
        def report_destination(self, f):
            pass
        def report_resuming_byte(self, s):
            pass

# Generated at 2022-06-24 11:57:30.290805
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 11:57:41.941130
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYtdl:
        def __init__(self, block_size, num_blocks):
            self.block_size = block_size
            self.num_blocks = num_blocks
            self.num_called = 0

        def urlopen(self, url_request):
            # Simulate the connection to an HTTP server
            # First we imitate receiving the HTTP headers and
            # the response code (200)
            class FakeUrlopen:
                def __init__(self, block_size, num_blocks):
                    self.block_size = block_size
                    self.num_blocks = num_blocks
                    self.num_called = 0

                def info(self):
                    # Return a fake set of HTTP headers
                    return {
                        'Content-Length': str(self.block_size * self.num_blocks),
                    }



# Generated at 2022-06-24 11:57:53.968483
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class MyYDL(YoutubeDL):
        def download(self, url, *args, **kwargs):
            self.url = url
            self.params = kwargs
            self.urlopen_counter = 0

            class MyResponse:
                def __init__(self, headers, data):
                    self.headers =headers
                    self.data = data

                def info(self):
                    return self.headers

                def read(self, n):
                    ret = self.data[:n]
                    self.data = self.data[n:]
                    return ret


# Generated at 2022-06-24 11:58:04.762319
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import http.server
    import socketserver
    import threading
    import urllib.request
    from .compat import compat_str
    from .utils import encodeFilename, sanitize_open

    HTTPPORT = 8554
    TEMPDIR = tempfile.mkdtemp()

    class TestServer(socketserver.TCPServer, object):
        allow_reuse_address = True

    class TestHandler(http.server.BaseHTTPRequestHandler, object):
        def do_GET(self):
            path = self.path[1:]
            self.send_response(200)
            self.end_headers()
            if path == 'content':
                self.wfile.write(b'No more data available')

# Generated at 2022-06-24 11:58:13.283138
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if has_encodings:
        encodings.aliases.aliases['utf8'] = 'utf-8' # Python 2.6 wants utf8 instead of utf-8
    # A test that can be performed without an actual network connection
    h = open_https(
        'https://github.com/rg3/youtube-dl/blob/master/README.md',
        None, False, False, 'youtube-dl', 'test-agent')
    info = h.info()
    h.close()

    # Check if the header has a valid Content-Type
    m = re.match(r'.*; charset=(.+)', info['Content-Type'])

# Generated at 2022-06-24 11:58:23.663104
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_url_ok(url, full_filename, expected_result, expected_msg):
        msg = '%s: ' % url
        try:
            ytdl = YoutubeDL({'quiet': True})
            h = ytdl.urlopen(url)
            assert expected_result == h.check_version(full_filename)
            assert full_filename == h._test_filename()
            msg += 'OK'
        except AssertionError:
            msg += 'FAIL, expected %r, got %r' % (expected_msg, h._test_filename())
        print(msg)

    test_url_ok('http://127.0.0.1/version', '100.100.100.100', False, '100.100.100.100')

# Generated at 2022-06-24 11:58:35.564739
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        from test import test_support
    except ImportError:
        from test import support as test_support
    test_support.verbose = 1

    def test1():
        print('-- running test 1 --')
        ydl = YoutubeDL()
        ydl.params['logger'] = YoutubeLogger()
        ydl.params['progress_hooks'] = [lambda d: sys.stdout.write('%s\n' % str(d))]
        dummy_url = u'http://localhost:9211/watch?v=BaW_jenozKc'
        # dummy URL must not be accessed

# Generated at 2022-06-24 11:58:44.769824
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create the object
    info = {
        'url': 'http://localhost/video.mp4',
        'http_headers': {'User-Agent': 'Test'},
        'player_url': 'http://localhost/swf/player.swf',
        'urlhandle': compat_urllib_request.Request(
            'http://localhost/video.mp4',
            None,
            {'User-Agent': 'Test'}
        ),
    }
    dl = HttpFD(FakeYDL(), info)
    # Test methods
    assert dl.get_url() == 'http://localhost/video.mp4'
    assert dl.get_basename() == 'video.mp4'
    assert dl.get_basic_headers() == {'User-Agent': 'Test'}
    assert dl

# Generated at 2022-06-24 11:58:48.362612
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://example.com/', {'test': 'value'})
    assert fd.test() == 'value'
    assert is_html(fd) == True


# Test if the file downloader works

# Generated at 2022-06-24 11:58:52.866187
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create a mock object
    class MockYDL(object):
        def __init__(self):
            self.params = {
                'playliststart': 1,
                'playlistend': 2,
                'playlistreverse': True,
            }

    # Create an object
    ydl = MockYDL()
    info = {
        'id': 'test',
        'title': 'test',
        'url': 'http://127.0.0.1/test.flv',
        'player_url': 'http://127.0.0.1/swf/',
        'ext': 'flv',
        'format': '0',
    }
    filename = '-' # standard output
    outtmpl = '-%(playlist_index)s-%(id)s.%(ext)s'


# Generated at 2022-06-24 11:58:56.882168
# Unit test for constructor of class HttpFD
def test_HttpFD():
    sim_fd = io.BytesIO(b'foo')
    sim_fd.name = 'bar'
    fd = HttpFD(sim_fd)
    assert fd.read() == b'foo'
    assert fd.name == 'bar'



# Generated at 2022-06-24 11:59:04.752484
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url = 'http://example.com/test.bin'
    hd = HttpFD(
        url, None, None, {
            'nopart': True,
            'test': True,
            'continuedl': True,
            'noresizebuffer': True,
            'continuedl': True,
            'limitrate': 100000
        })
    # check if get_size is not implemented
    assert hd.get_size() == -1, 'get_size() not implemented'
    return True

# # HACK: fix for https://bitbucket.org/pypa/setuptools/issue/196/package_data-not-included-in-binary
# import youtube_dl
# import fnmatch
# import os
# import sys

# def _py2exe_datafiles():
#    

# Generated at 2022-06-24 11:59:16.064267
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import io
    out = io.BytesIO()
    h = HttpFD(out, None, {'noprogress': True})
    h.block_size = 1
    h.retries = 3
    h.max_fragment_retries = 2

    def hf_progress(status, *args):
        status = args[0]
        if status == 'downloading':
            print('\r[download] %s bytes @ %s bytes/sec ETA %02d:%02d' % args[1:])
        elif status == 'finished':
            print('\r[download] %s bytes @ %s bytes/sec ETA %02d:%02d' % args[1:])
        elif status == 'error':
            print('\r[download] error: ' + args[1])
   

# Generated at 2022-06-24 11:59:25.449672
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for correct Content-Length detection
    class ContentLengthHandler(BaseHandler):
        def http_open(self, req):
            headers = {'Content-Length': '31415'}
            return self.parent.open(req, timeout=req.timeout, cafile=cafile, capath=capath, cadefault=cadefault, context=req.context, check_hostname=check_hostname, **headers)

    opener = build_opener(ContentLengthHandler)

    class TestHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            kwargs['opener'] = opener
            HttpFD.__init__(self, *args, **kwargs)

    fd = TestHttpFD('http://localhost', 1024)
    assert fd.get_content_len()

# Generated at 2022-06-24 11:59:36.605872
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # NOTE: Helper functions for testing follow

    class LogMessage:
        def __init__(self, test, message, level=None):
            self.test = test
            self.message = message
            self.level = level

        def __eq__(self, other):
            if isinstance(other, LogMessage):
                return (self.message == other.message) and (self.level == other.level)
            return False

        def __repr__(self):
            return 'LogMessage(%s)' % self.message

        def __str__(self):
            return 'LogMessage(%s)' % self.message


# Generated at 2022-06-24 11:59:42.873242
# Unit test for constructor of class HttpFD
def test_HttpFD():

    class DummyYDL(object):
        def __init__(self):
            self.params = {}

    ydl = DummyYDL()

    # Normal usage
    downloader = HttpFD(ydl=ydl, parameters={'continuedl': True})

    # Test 'nocontinuedl' and 'test'
    ydl.params.update({'nocontinuedl': True, 'test': True})
    downloader = HttpFD(ydl=ydl, parameters={})

    # Test size limit
    downloader = HttpFD(ydl=ydl, parameters={
        'continuedl': True,
        'noresizebuffer': True,
        'min_filesize': 10,
        'max_filesize': 100,
    })

    # Test timeout
    downloader = Http

# Generated at 2022-06-24 11:59:52.895698
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import http.server
    import socketserver
    import random

    # mimic HTTP server returning HTTP 416
    class Http416Handler(http.server.SimpleHTTPRequestHandler):
        def do_GET(self):
            self.send_response(416)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write(b'HTTP 416')
            self.wfile.close()


    # mock urllib2.urlopen

# Generated at 2022-06-24 11:59:56.818319
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    h = HttpFD('http://www.google.com/', {'noprogress': True})
    # check that temp file was opened in binary mode
    assert type(h.fileobj.fileobj) == tempfile._TemporaryFileWrapper
    # check that temp file was opened in write mode
    assert h.fileobj.fileobj.file.mode == 'w+b'


# Generated at 2022-06-24 12:00:08.691234
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL(dict(nooverwrites=True, forceurl=True, forcetitle=True, quiet=True))
    ydl.add_info_extractor(lambda: None)  # Dummy IE

    # Test with a video (gets redirected)
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['nooverwrites'] = True
    fd = HttpFD(ydl, None, 'http://www.youtube.com/watch?v=BaW_jenozKc', {})
    assert fd.get_size() == None
    assert fd.real_url == 'https://www.youtube.com/watch?v=BaW_jenozKc'

    # Test with a redirector

# Generated at 2022-06-24 12:00:16.985622
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def _test(**kwargs):
        fd = HttpFD(
            'http://www.example.org/',
            {'test': 'abc'},
            '-',
            'wb',
            1048576,
            'Mozilla/5.0',
            {'http_chunk_size': 1048576, 'noprogress': True, 'logger': FakeLogger()},
            lambda x: True,
            '_test_suite',
            test=True,
            **kwargs)
        fd.test_counter = (0, 0)
        fd.real_download = lambda: fd.test_counter[0] >= 4

        for i in range(5):
            fd.read(1048576)
        assert fd.test_counter == (4, 4)



# Generated at 2022-06-24 12:00:20.218921
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # TODO: remove this function
    # This function does not appear to ever be called
    # as you can see for yourself, this function has been
    # marked as a no-op with the 'pass' statement
    pass



# Generated at 2022-06-24 12:00:30.721699
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    '''
    This method unit tests real_download() method of HttpFD class
    unit testing is done by comparing the downloaded file size with
    the expected size of the file to be downloaded
    '''
    url = 'http://localhost:8080/%s' % test_parameters['url']
    ydl = YoutubeDL(test_params)
    fd = HttpFD(ydl, url, params=test_params)
    fd.real_download(test_filename, info_dict, True)
    downloaded_file_size = os.path.getsize(test_filename)
    expected_file_size = test_parameters['expected_filesize']

# Generated at 2022-06-24 12:00:42.761873
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(object):
        def __init__(self, filename, mode):
            self.filename = filename
            self.mode = mode
            self.content = b''
        def write(self, data):
            self.content += data

    # prepare
    http_fd = HttpFD(None, {'noprogress': True, 'test': True})
    http_fd.test_results = {}
    http_fd.to_screen = lambda *x: None
    http_fd.to_stderr = lambda *x: None
    http_fd.report_error = lambda *x: None
    http_fd.report_retry = lambda *x: None
    http_fd.report_file_already_downloaded = lambda *x: None

# Generated at 2022-06-24 12:00:50.964911
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 12:01:04.858093
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # For now a test function tests three real_download() calls:
    # the first is a regular download; the second one resumes download;
    # the third one ensures that a whole file would be downloaded in a
    # case when a remote webserver ignores/supports Range HTTP header.
    # In all cases the block size is limited to 64 bytes.
    from .utils import DateRange

    # Create a test instance of HttpFD class
    class MockYDL(object):
        params = {
            'ratelimit': 0,
            'retries': 0,
            'nooverwrites': False,
            'continuedl': True,
            'buffersize': 0,
            'noresizebuffer': True,
            'test': True,
        }

        def __init__(self):
            self.logger = MockLogger()


# Generated at 2022-06-24 12:01:11.903191
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create a fake outputfile
    import os
    (fd, filename) = tempfile.mkstemp(prefix='youtube-dl-test_', suffix='.tmp')
    os.close(fd)

    headers = {
            'ETag': 'abc',
            'Content-Range': 'bytes 0-123/90123',
            'Accept-Ranges': 'bytes',
            'Content-Length': 90123,
    }
    h = HttpFD(None, headers, filename, {'continuedl': True})
    # os.path.isfile(filename) should return True at this point
    assert h.get_start_pos(90123) == 0
    assert h.get_end_pos(90123) == 123
    os.remove(filename)


# Generated at 2022-06-24 12:01:18.064677
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('-- Running test for HttpFD')
    fd = HttpFD(urlopen('http://www.google.com'))
    print('HTTP response headers:')
    for header, value in fd.headers.items():
        print('%s: %s' % (header, value))
    print('HTTP response body:')
    print(compat_str(fd.read(1024)))


# Generated at 2022-06-24 12:01:23.067725
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Import modules to be tested
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl.utils import sanitize_open
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.extractor import gen_extractors
    # Reset variables shared between unit tests and other methods of FileDownloader
    FileDownloader._TEST_FILE_SIZE = None
    # Create objects to be tested
    ydl = YoutubeDL()
    ie = InfoExtractor()
    ie.params = ydl.params
    ie.params['nooverwrites'] = True
    ie.params['continuedl'] = False
    ie.params['nopart'] = True
    ie.params['retries'] = 0
    ie.add_default_

# Generated at 2022-06-24 12:01:28.421955
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 12:01:40.472644
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    >>> from test import *
    >>> import os
    >>> fd, fname = test_download(test_url_prefix + '-test.' + test_suffix)
    >>> assert os.path.isfile(fname)
    >>> os.remove(fname)
    >>> fd, fname = test_download('http://127.0.0.1:0/')
    Traceback (most recent call last):
        ...
    URLError: <urlopen error [Errno 111] Connection refused>
    >>> os.remove(fname)
    >>> fd, fname = test_download(test_url_prefix + '-test-with-spaces.' + test_suffix)
    >>> assert os.path.isfile(fname)
    >>> os.remove(fname)
    """



# Generated at 2022-06-24 12:01:53.358450
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import tempfile
    import http.client
    import time

    if sys.version_info < (2, 6):
        return
    if http.client is compat_http_client:
        return

    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write(b'asdf')
    temp_file.flush()

    # Wait for mtime to change (workaround for Windows)
    time.sleep(1.01 - time.time() % 1)

    temp_file.write(b'qwer')
    temp_file.close()

    # Check if file is being downloaded
    h = HttpFD(compat_urllib_request.urlopen('file://' + temp_file.name), temp_file.name, {})

# Generated at 2022-06-24 12:02:02.283270
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create an instance of the class, but do not use it's methods
    instance = HttpFD()
    # Let's fake a few methods that are called from real_download
    instance.report_error = lambda msg: sys.stderr.write("ERROR: " + msg + "\n")
    instance.report_retry = lambda exc, t, r: sys.stderr.write("RETRY: %s (%d of %d)\n" % (exc, t, r))
    instance.best_block_size = lambda d, s: None
    instance.to_screen = lambda msg: sys.stdout.write("FAKE: " + msg + "\n")
    instance.slow_down = lambda s, n, c: None
    instance.calc_speed = lambda s, n, c: None

# Generated at 2022-06-24 12:02:03.201451
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass

# Generated at 2022-06-24 12:02:13.749361
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import StringIO
    from xml.dom import minidom
    from collections import OrderedDict
    from io import StringIO
    from types import TracebackType
    from typing import Any, Dict, Generator, List, Optional, Tuple, Type, Union
    # Initializing
    ydl_opts = {
        'noprogress': True,
    }
    HttpFD_inst = HttpFD(ydl_opts)
    print("Constructor test #1 - Success")
    # Testing: HttpFD._hooks

# Generated at 2022-06-24 12:02:15.124356
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert isinstance(HttpFD(None, {}), FileDownloader)



# Generated at 2022-06-24 12:02:22.833795
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = MockYtdl()
    def sanitize_open(filename, open_mode):
        if open_mode == 'wb':
            return (io.BytesIO(b''), filename)
        if open_mode == 'ab':
            return (io.BytesIO(b'\0' * 8192), filename)
        raise Exception('Unexpected open_mode')
    ydl.params['test'] = True
    ydl.sanitize_open = sanitize_open
    ydl.report_error = lambda *args, **kargs: None
    fd = HttpFD(ydl, {}, {})
    # Test return when _TEST_FILE_SIZE is None
    fd.params['test'] = False

# Generated at 2022-06-24 12:02:34.972414
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYtdl:
        def __init__(self, *args, **kwargs):
            self._download_retval = True
            self._download_count = 0

        def to_screen(self, message):
            pass

        def urlopen(self, *args, **kwargs):
            class Response:
                headers = {'Content-Length': 42}
                def info(self):
                    return self.headers
                def read(self, size=None):
                    return b'a' * size

            return Response()

        def trouble(self, *args, **kwargs):
            pass

        def report_error(self, message):
            pass

        def calculate_percent(self, bytes_counter, data_len):
            return '%d' % bytes_counter


# Generated at 2022-06-24 12:02:43.031094
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a mock object for class HttpFD
    class HttpFD_real_download_Test(HttpFD):
        def __init__(self):
            self.params = {
                'noprogress': False,
                'logger': MockLogger(),
            }
        def calc_speed(self, start, now, bytes_downloaded):
            return 0 if now - start == 0 else bytes_downloaded / (now - start)
        def calc_eta(self, start, now, total_bytes_expected, bytes_downloaded):
            return None if now - start == 0 or total_bytes_expected <= bytes_downloaded else (total_bytes_expected - bytes_downloaded) / self.calc_speed(start, now, bytes_downloaded)

# Generated at 2022-06-24 12:02:49.679672
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    from .compat import compat_http_client, compat_urllib_parse, compat_urllib_request
    from .utils import encode_data_uri

    with tempfile.NamedTemporaryFile(delete=False) as t:
        fd = t.fileno()
        fd_name = t.name

    urlh = compat_urllib_request.urlopen(BYPASS_THROTTLING_HOSTNAME_TEMPLATE.format('0.0.0.0', fd))
    assert urlh.headers.get('Content-Disposition') == 'attachment; filename="LICENSE"'
    assert urlh.read() == compat_urllib_request.urlopen('http://yt-dl.org/LICENSE').read()

    urlh = compat_urllib