

# Generated at 2022-06-24 11:52:56.012783
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case 1 - no resuming, no rate limiting
    f = HttpFD('http://www.example.com/', {'noresizebuffer': True}, test = True)
    assert f.content_length == 100 * 1024
    assert f.block_size == 1024 * 1024
    assert f.start_time is not None
    assert f.end_time is None

    # Test case 2 - resuming, no rate limiting
    f = HttpFD('http://www.example.com/', {'noresizebuffer': True, 'continue_dl': True},
               resume_len = 50000, test = True)
    assert f.content_length == 100 * 1024
    assert f.block_size == 1024 * 1024
    assert f.start_time is not None
    assert f.end_time is None

    # Test case 3 -

# Generated at 2022-06-24 11:53:07.164649
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Run the real_download method of the HttpFD class for a (short) sample file.
    This method is used by FileDownloader to download files.
    """
    # sample file URL and target file name
    url = "https://upload.wikimedia.org/wikipedia/commons/0/00/Blank.ogg"
    basename = "Blank.ogg"
    # alternative sample file URL
    # url = "https://upload.wikimedia.org/wikipedia/commons/d/df/WMA_sample_file.wma"
    # basename = "WMA_sample_file.wma"
    # alternative sample file URL
    # url = "https://upload.wikimedia.org/wikipedia/en/6/67/MPEG-1_Audio_Layer_III_sample_file%2C_very_high

# Generated at 2022-06-24 11:53:17.967147
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    from youtube_dl.utils import encode_compat_str
    info = {'test': 'ok'}

    for use_proxy in [False, True]:
        for params in [{},
                {'continuedl': True},
                {'continuedl': True, 'noprogress': True},
                {'ratelimit': 3128000},
                {'ratelimit': 3128000, 'noprogress': True},
                {'noresizebuffer': True},
                {'test': True}]:
            params.update(info)

            fd = HttpFD(BytesIO(b'foobar'), 'http://example.com/', params,
                        use_proxy=use_proxy)
            assert fd.read() == b'foobar'

# Generated at 2022-06-24 11:53:23.535712
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD('http://localhost/', {'nooverwrites': True})
    (fd, retr) = h.get_fd()
    assert fd is not None
    assert retr == 0
    assert fd.name.startswith('.')
    fd.close()
    os.remove(fd.name)

    h = HttpFD('http://localhost/', {'nooverwrites': True})
    (fd, retr) = h.get_fd(use_meta_name=True, meta_name='foo')
    assert fd is not None
    assert retr == 0
    assert fd.name.startswith('.')
    assert fd.name.endswith('.foo')
    fd.close()
    os.remove(fd.name)

    h

# Generated at 2022-06-24 11:53:34.212408
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import glob
    fd = HttpFD(None, {}, {'ratelimit': 1048576, 'retries': 10})

    # Test downloads with different block lengths
    fd._TEST_FILE_SIZE = 103
    for block_length in [0, 1, 5, fd._TEST_FILE_SIZE - 1, fd._TEST_FILE_SIZE]:
        filename = 'test_%s_bytes_blocks.tmp.download' % block_length
        d = DownloadContext(fd, filename, 'wb', block_length, None, None, 0, None)

# Generated at 2022-06-24 11:53:37.336133
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert_raises(IOError, HttpFD, None, 'rb', {'noprogress':True}, None, None)


# Generated at 2022-06-24 11:53:49.228196
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test 1
    s_input = {'url': 'http://example.com/video.mp4', 'filename': None, 'info_dict': {}, 'params': {}, 'add_headers': {}, 'test': False}
    s_output = HttpFD(**s_input)
    assert s_output.url == s_input['url']
    assert s_output.filename == s_input['filename']
    assert s_output.info_dict == s_input['info_dict']
    assert s_output.params == s_input['params']
    assert s_output.test == s_input['test']

    # Test 2

# Generated at 2022-06-24 11:53:57.959825
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from ssl import SSLError
    from socket import error as SocketError
    from socket import timeout as SocketTimeout

    class FakeOpener(object):
        def __init__(self, retval):
            self.retval = retval
        def open(self, _):
            self.open_calls += 1
            return self.retval

    class FakeResponse(object):
        def __init__(self, data, info):
            self.data = data
            self.info = lambda: info
            self.headers = info

    class FakeUrlRequest(object):

        def __init__(self, headers=None):
            self.headers = headers or {}

        def __setitem__(self, name, value):
            self.headers[name] = value


# Generated at 2022-06-24 11:54:08.370331
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hd = HttpFD(YoutubeDL(), {}, 'http://www.example.com/', {})
    hd._prepare_and_start_frag_download({'filename': 'Blah.fblah', 'tmpfilename': 'Blah.fblah'})
    # Check whether the expected keys are present in the resulting dictionary
    assert set(hd.info.keys()) >= {
        'filename',
        'tmpfilename',
        'stream',
        'resume_len',
        'test',
        'url',
        'headers',
    }
    # Check whether this function correctly parses Content-Range headers
    assert (hd._get_content_range('bytes 0-499/1234') == [0, 500, 1234])

# Generated at 2022-06-24 11:54:19.838458
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import sanitize_open

    class DummyYDL(object):
        def urlopen(self, *args, **kwargs):
            return DummyUrlopen(*args, **kwargs)

    class DummyUrlopen(object):
        def __init__(self, request):
            self.request = request
            self.headers = {
                'Content-Length': '100',
                'Accept-Ranges': 'bytes',
                'Content-Range': 'bytes 10-20/100',
            }

        def info(self):
            return self.headers

        def read(self, size=None):
            return b'x' * size


# Generated at 2022-06-24 11:54:32.533285
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_constructor(**kwargs):
        assert isinstance(HttpFD(**kwargs), compat_http_client.HTTPConnection)
    test_constructor(proxy_host='localhost', proxy_port=8080)
    # test_constructor(proxy_host=None, proxy_port=None)
    # test_constructor(proxy_host=None, proxy_port=8080)
    # test_constructor(proxy_host='localhost', proxy_port=None)
    # test_constructor(proxy_host='localhost', proxy_port=8080,
    #                  proxy_username='username', proxy_password='password')
    test_constructor(proxy_host='localhost', proxy_port=8080,
                     proxy_username=None, proxy_password=None)



# Generated at 2022-06-24 11:54:34.681408
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# vim:set ts=4 sw=4 sts=4 expandtab:

# Generated at 2022-06-24 11:54:45.808790
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import tempfile
    import random
    def _test_readline(fd):
        s = fd.readline()
        assert isinstance(s, compat_str)
        return s.strip()
    # Workaround for WinXP error
    # TypeError: must be convertible to a buffer, not instance
    def _test_write(fd, s):
        s = s.encode('ascii')
        return fd.write(s)

    # Create random junk.
    random.seed(0)
    # In Python < 2.7 tempfile.TemporaryFile does not work if the file mode
    # is binary.
    fd = tempfile.TemporaryFile(mode='w+')
    bs = bytearray(random.getrandbits(8) for _ in range(2**20))


# Generated at 2022-06-24 11:54:57.710506
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DummyYDL(object):
        def report_error(self, *args, **kargs):
            pass
        def report_retry(self, *args, **kargs):
            pass
        def report_resuming_byte(self, *args, **kargs):
            pass
        def report_unable_to_resume(self, *args, **kargs):
            pass
        def report_file_already_downloaded(self, *args, **kargs):
            pass
        def report_destination(self, *args, **kargs):
            pass
        def urlopen(self, *args, **kargs):
            class DummyResponse(object):
                def info(self):
                    return {'Content-length': str(DummyUrlopen.content_length)}

# Generated at 2022-06-24 11:55:03.272445
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 11:55:15.145227
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    def determine_test_chunk_size():
        """
        Determine an chunk size for HTTP-chunked testing.
        """
        if not hasattr(test_HttpFD_real_download, 'test_chunk_size'):
            for test_chunk_size in (2000, 200):
                if test_chunk_size <= test_HttpFD_real_download.data_len:
                    break
            else:
                raise ValueError('Not enough data for testing')
            test_HttpFD_real_download.test_chunk_size = test_chunk_size
        return test_HttpFD_real_download.test_chunk_size

    def _mock_download(ydl, info_dict, filename, ctx):
        ctx.returncode = 0
        ctx.tmpfilename = filename
        assert c

# Generated at 2022-06-24 11:55:24.869714
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import pytest
    from youtube_dl.utils import encode_compat_str

    # First, let's test download of a sample file from Internet
    # We'll use a JPG file from Wikimedia Commons for it (http://commons.wikimedia.org/wiki/File:Sediment_on_Mars.jpg)
    # (it's size is about 600 KB, so it should be a good choice for a unit test)
    url = 'http://upload.wikimedia.org/wikipedia/commons/5/5a/Sediment_on_Mars.jpg'
    # We also need a file name for downloaded file
    file_name = 'sample_file.jpg'

    # We will simulate opening a file with a name 'file_name' in write mode
    # in the very first run of real_download() method.
    #

# Generated at 2022-06-24 11:55:36.356528
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class _HttpFD(HttpsFD):
        def __init__(self, ydl, info_dict):
            super(_HttpFD, self).__init__(ydl, info_dict)
            self.content_length = 200
            self.resume_len = 0

        def _do_query(self, url_or_request, data, headers):
            return url_or_request

        def _read_chunk(self):
            if self.resume_len == self.content_length:
                return b''
            return b'o' * min(16, self.content_length - self.resume_len)

    ydl = MockYDL()
    info_dict = {}
    fd = _HttpFD(ydl, info_dict)
    fd.urlhandle = Mock()
    fd.url

# Generated at 2022-06-24 11:55:49.006010
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test HttpFD initialization
    url = 'http://www.google.com/test.html'
    http_fd = HttpFD(url, {'noprogress': True})
    correct_info = {
        'url': url,
        'filename': url.split('/')[-1],
        'expected_size': None,
    }
    if http_fd.info != correct_info:
        raise AssertionError('Incorrect info dictionary: %r != %r' % (http_fd.info, correct_info))
    http_fd.close()

    # Test overriding of filename
    url = 'http://www.google.com/test.html'

# Generated at 2022-06-24 11:56:01.128409
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def download_block_generator(url):
        class FakeResponse(object):
            def info(self):
                return {'Content-length': str(len(url))}
        for i in url:
            yield i
        raise StopIteration()

    hfd = HttpFD(None, None)
    hfd.ydl = FakeYDL()
    hfd.ydl.urlopen = lambda url: FakeResponse()
    hfd.ydl.urlopen.side_effect = download_block_generator

    # Test downloading of a small file
    hfd.url = 'a'
    hfd.filename = 'test_1'
    hfd.ctx.block_size = 1
    hfd.ctx.params = {}
    hfd.real_download(False)

# Generated at 2022-06-24 11:56:13.349250
# Unit test for constructor of class HttpFD
def test_HttpFD():
    downloader = FD()
    downloader.add_info_extractor(YoutubeIE())
    downloader.add_info_extractor(MetacafeIE())
    downloader.add_info_extractor(GenericIE())
    url = 'http://example.com/'
    info = downloader.extract_info(url, downloader.suitable_download_extractors(url)[0])
    title = 'Example Domain'
    ext = '.mp4'
    filename = '%s-%s.%s' % (title, url, ext)
    assert info['title'] == title
    assert info['id'] == url
    assert info['ext'] == ext
    assert info['format'] == 'DASH video'

# Generated at 2022-06-24 11:56:20.341553
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return HttpFD(None, None)

if __name__ == '__main__':
    # Test HttpFD on Google home page
    from .FileDownloader import FileDownloader
    ydl = FileDownloader({'usenetrc': False, 'username': 'test', 'password': 'test', 'quiet': True, 'forceurl': True, 'forcetitle': True, 'forcethumbnail': True, 'forcedescription': True, 'forcefilename': True, 'forcejson': True, 'dump_intermediate_pages': True})
    ydl.add_info_extractor(type('IE', (object,), {'_VALID_URL': r'.*', '_TEST': {'url': 'http://www.google.com', 'file': 'test_http.tmp'}})())

# Generated at 2022-06-24 11:56:31.039169
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = FakeYDL()
    # Prepare test file in one block.
    block_size = 1024
    with tempfile.NamedTemporaryFile() as tf:
        # Write data in one block
        data = os.urandom(block_size * 256)
        tf.write(data)
        tf.flush()
        tf_name = encodeFilename(tf.name)
        tf.seek(0)

        # Retrieve file size
        file_size = os.path.getsize(tf_name)

        # Test case 1. Download the entire file
        #   Download a known file and compare to the original
        test_fd = HttpFD(ydl, {'noprogress': True, 'quiet': True}, None)
        info_dict = {}

# Generated at 2022-06-24 11:56:41.573056
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test if HTTP range header is built correctly
    class FakeYDL:
        def __init__(self):
            self.params = {'continuedl': True}

    ydl = FakeYDL()
    fd = HttpFD(ydl, {}, 'http://example.org/video.mp4', headers={'Cookie': 'foo=bar'}, test=True)
    assert 'Cookie' in fd.headers
    assert fd.headers['Cookie'] == 'foo=bar'
    fd.init_and_start()
    assert fd.headers['Cookie'] == 'foo=bar'
    assert fd.real_url == 'http://example.org/video.mp4'
    assert fd.urlh.geturl() == 'http://example.org/video.mp4'
    assert f

# Generated at 2022-06-24 11:56:47.931858
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 11:57:01.890310
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_single(test_dict):
        params, result = test_dict['params'], test_dict['result']
        filename, info, data_len, test_blocksize, test_bufsize = result
        t = HttpFD(**params)
        t.real_download()
        assert t.params.get('outtmpl') == filename, test_dict
        assert t.info == info, test_dict
        assert t.data_len == data_len, test_dict
        assert t.params.get('buffersize') == test_bufsize, test_dict
        assert t.block_size == test_blocksize, test_dict


# Generated at 2022-06-24 11:57:14.032829
# Unit test for constructor of class HttpFD
def test_HttpFD():
    stream = io.BytesIO(b'abc')

    httpfd = HttpFD(stream, None, 'http', 'http://localhost/foo.bin')
    assert httpfd.name == 'http://localhost/foo.bin'
    assert httpfd.real_download == False
    assert httpfd.stream == stream
    assert httpfd.close == stream.close
    assert httpfd.tell() == 0
    assert httpfd.read(1) == b'a'
    assert httpfd.tell() == 1
    assert httpfd.read(2) == b'bc'
    assert httpfd.tell() == 3
    httpfd.close()
    # Test that no exception is raised after closing
    httpfd.read(1)
    httpfd.seek(0)
    httpfd.seek(2, 1)

# Generated at 2022-06-24 11:57:23.846441
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def get_testcases():
        testcases = []
        # Expected results
        # (block size, content length, #blocks, #remaining bytes, expected
        # content length)
        testcases.append((1024, 10240, 10, 0, 10240))
        testcases.append((1024, 10240, None, 0, 10240))
        testcases.append((1024, None, None, 0, 0))
        testcases.append((1024, 10230, None, 10, 10230))
        testcases.append((1024, 10230, 10, 10, 10230))
        testcases.append((1024, 10230, 9, 114, 10230))
        testcases.append((0, None, None, 0, 0))
        return testcases

    def make_stream(content):
        data = compat_StringIO()
        data

# Generated at 2022-06-24 11:57:29.222239
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test HTTP connection
    data = HttpFD(urlopen('http://fr0.org/'), None).read()
    assert(b'<title>fr0.org</title>' in data)

    # Test FTP connection
    data = HttpFD(urlopen('ftp://ftp.freesoftware.com/mirrors/gnu/gparted/gparted-live-0.6.1-6.iso'), None).read()
    assert(data[0] == '\x1f' and data[1] == '\x8b')

    # Test file
    assert(HttpFD(open(__file__), None).read() == open(__file__, 'rb').read())

    # Test unsupported protocol

# Generated at 2022-06-24 11:57:41.056913
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for the case _TEST_FILE_SIZE = None
    h = HttpFD('-', {'url': 'http://www.example.com/video.mp4', 'proxy': None, 'noprogress': True, 'test': True})
    assert h.url == 'http://www.example.com/video.mp4'
    assert h.ydl == None
    assert h.params['noprogress']
    assert not h.params['proxy']
    assert not h.params['retries']
    assert h.params['test']

    h = HttpFD('-', {'url': 'http://www.example.com/video.mp4', 'proxy': 'http://127.0.0.1', 'retries': 5, 'noprogress': True})

# Generated at 2022-06-24 11:57:52.836721
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import httplib
    from .utils import sanitized_Request, encodeFilename
    from .extractor import get_info_extractor

    class MockServer(object):
        # Must be initialized before monkey patching
        original_classes = {}
        original_functions = {}

        def __init__(self, test_dict):
            self.test_dict = test_dict

        def start(self):
            def mock_urlopen(request):
                key = request.get_full_url()
                value = self.test_dict[key]
                if isinstance(value, compat_http_client.HTTPException):
                    raise value
                elif isinstance(value, tuple):
                    block, content_length = value

# Generated at 2022-06-24 11:58:00.035889
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Unit test for method real_download of class HttpFD"""
    from youtube_dl.compat import compat_urllib_request
    from http.server import BaseHTTPRequestHandler
    from http.server import HTTPServer
    from threading import Thread
    from tempfile import NamedTemporaryFile
    from urllib.parse import urlparse
    from .utils import sanitize_open

    # Server
    class HttpServer(BaseHTTPRequestHandler):
        def do_HEAD(self):
            parsed_url = urlparse(self.path)
            if parsed_url.path == '/does_not_exist.tmp':
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')

# Generated at 2022-06-24 11:58:02.190602
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD({}, {'test': True}, None)
    http_fd.test()



# Generated at 2022-06-24 11:58:12.111631
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import unittest
    import tempfile

    class TestHttpFD(unittest.TestCase):
        # This test method tests the real_download() method of class HttpFD
        # We use a real file on the Net to download it
        def test_real_download(self):
            url = "https://www.kernel.org/pub/linux/kernel/v3.x/linux-3.15.tar.xz"
            req = compat_urllib_request.Request(url, headers={'User-Agent': 'Test/1.0 (bla@bar.invalid)'})
            data = compat_urllib_request.urlopen(req)
            length = int(data.info()["Content-Length"])
            # Create a temporary file and a HttpFD object, then download the real file
            f = tempfile

# Generated at 2022-06-24 11:58:22.651764
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Tests the real_download method of class HttpFD"""

    def download_mockup(self, url_dict, info_dict, timeout=None,
                        retries=None, resume=None, retry_on_error=None,
                        chunk_size=None, expected_status=None,
                        require_title=True, verbose=None):
        """Mockup of 'test_download' of class YoutubeDL.
        It works by creating a local file, if one doesn't exist,
        based on the url and the expected downloaded size.
        It then returns a dictionary of values, such as 'url' and 'status'
        (i.e. 'content-type') from the file and HTTP headers
        """

        # Open the mockup file if it exists and return its headers

# Generated at 2022-06-24 11:58:34.705442
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test function for class HttpFD
    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'nooverwrites': False,
                'continuedl': True,
                'noresizebuffer': True,
                'retries': 5,
                'buffersize': 524288,
                'test': True,
                'preferredcodec': None,
                'preferredquality': None,
            }
            self.to_screen = sys.stdout.write
            self.to_stderr = sys.stderr.write

        def urlopen(self, request):
            headers = {
                # python 2.6.4
                'Content-Type': 'text/html; charset=UTF-8',
                'Content-Length': '20',
            }

# Generated at 2022-06-24 11:58:43.977960
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # HttpFD needs a YouTubeDL object for initialization.
    # This object is never used, but by providing a fake
    # object we can avoid messy hacks.
    class FakeYDL:
        params = {}

    # The highest level object that is ever used
    hfd = HttpFD(FakeYDL(), {})

    def urlopen_fake(request):
        class FakeSocket:
            def __init__(self, data):
                self.data = data
            def makefile(self, *args):
                return io.BytesIO(self.data)

        # Headers are ignored, as long as we don't try to resume.

# Generated at 2022-06-24 11:58:54.519013
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Tests real_download method of HttpFD, which is the main method for
       downloading files.
    """

    import socket, sys, os
    import urllib.request as urllib2
    from io import BytesIO

    from tempfile import NamedTemporaryFile
    from .compat import compat_http_server, compat_socket, urllib_error, compat_str

    if sys.platform == 'win32':
        # On Windows, we need to bind to the localhost but not to 127.0.0.1
        SOCKET_HOST = 'localhost'
    else:
        SOCKET_HOST = '127.0.0.1'

    # Prepare a small plaintext file
    test_file = '''this is
a test
file
'''

# Generated at 2022-06-24 11:59:03.307333
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import re
    import shutil
    import sys
    import unittest
    import urllib.parse
    import urllib.request
    import tempfile

    sys.path.append('..')
    from tests import FakeYDL, FakeHttpServer

    class HttpFDTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.server = FakeHttpServer(8888)  # port 8888
            cls.server.start()

        @classmethod
        def tearDownClass(cls):
            cls.server.stop()

        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-24 11:59:14.482300
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(object):
        def __init__(self, content, content_offset=0):
            self._content = content
            self._offset = content_offset

        def read(self, size):
            if size is None:
                size = len(self._content) - self._offset
            else:
                size = min(len(self._content) - self._offset, size)
            ret = self._content[self._offset:self._offset + size]
            self._offset += size
            return ret

        def info(self):
            return {
                'Content-length': len(self._content),
            }


# Generated at 2022-06-24 11:59:24.490997
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # Unit test for real_download method of class HttpFD.
    # It is a command line program. It downloads a sample file from
    # internet, then checks its md5 to make sure it is not corrupted.
    # It is intended to be run only for development purposes.

    import os
    import sys
    import hashlib
    import tempfile

    if sys.version_info[:3] == (3, 2, 3):
        from http.client import BadStatusLine
        from http.client import IncompleteRead
    elif sys.version_info[:3] == (3, 4, 2):
        from http.client import BadStatusLine
        from http.client import IncompleteRead
    else:
        IncompleteRead = None
        BadStatusLine = None


# Generated at 2022-06-24 11:59:30.303178
# Unit test for constructor of class HttpFD
def test_HttpFD():
    dl = HttpFD(YtdlFD(), {'noprogress': True})
    dl.real_download(
        {'url': 'http://a/b',
         'http_headers': {'Range': 'bytes=100-'}},
        '-', 'ab')
    dl.real_download(
        {'url': 'http://a/b',
         'http_headers': {'Range': 'bytes=100-'}},
        '-', 'wb')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:59:36.825089
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class Mock(object):
        def __init__(self, test_instance):
            self.test_instance = test_instance
        def __getattr__(self, attr):
            return getattr(self.test_instance, attr)
        def __setattr__(self, attr, value):
            if attr == 'test_instance':
                object.__setattr__(self, attr, value)
            else:
                setattr(self.test_instance, attr, value)

    class MockYDL(object):
        def __init__(self, test_instance):
            self.test_instance = test_instance

# Generated at 2022-06-24 11:59:47.758634
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 11:59:54.045624
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import encodeFilename
    # Test DownloadError()

# Generated at 2022-06-24 12:00:05.338446
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    import shutil
    import youtube_dl.utils as utils

    testdata = compat_urllib_request.urlopen('http://upload.wikimedia.org/wikipedia/commons/1/1f/Thomas_Edison_head.jpg').read()
    tmpdir = tempfile.mkdtemp(prefix='youtube-dl-test_')
    tmpfile = os.path.join(tmpdir, '%(title)s.%(ext)s')

# Generated at 2022-06-24 12:00:09.814591
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from . import FileDownloader
    fd = HttpFD(FileDownloader({'nooverwrites': True}), 'http://www.youtube.com/', {}, '-')
    assert fd.name() == 'http://www.youtube.com/'
    assert fd.get_size() is None
    assert fd.get_filename() == '-'
    assert fd.get_temp_filename() == '-'
    assert not fd.is_finished()
    assert not fd.get_handle()
    assert fd.read(1) == b''
    assert fd.done()


# Generated at 2022-06-24 12:00:17.833715
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import json

    # Import mock_socket for patching socket module
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Import urllib.response for patching urllib.request in python 3
    urllib_response = compat_urllib_request.response
    # Import urllib.error for patching urllib.request in python 2
    urllib_error = compat_urllib_request.error

    from .extractor.common import InfoExtractor

    # Downloads a file in chunks, and reports the progress to stdout
    # What this test does is to download a file in chunks, and report
    # the progress to stdout (simulating youtube-dl's behaviour)

    # Let's suppose we want to download:
    # http://www.example.com

# Generated at 2022-06-24 12:00:26.376654
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Testing method real_download of class HttpFD...')
    # Creating temporary directory
    tmp_dir_name = tempfile.mkdtemp(prefix='youtube-dl_test_' + sys.version.replace(' ', '_').replace('.', '_') + '_')
    tmp_dir_fd = os.open(tmp_dir_name, os.O_RDONLY)
    tmp_dir_fd = compat_fd(tmp_dir_fd)

    # Creating some temporary files
    tmp_file_names = [
        os.path.join(tmp_dir_name, 'a'),
        os.path.join(tmp_dir_name, 'aa'),
        os.path.join(tmp_dir_name, 'aaa'),
        os.path.join(tmp_dir_name, 'aaaa'),
    ]


# Generated at 2022-06-24 12:00:37.861734
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import socket
    from .compat import (compat_urllib_error, compat_http_client,
                         compat_urllib_request, compat_urllib_parse)
    from .extractor import get_info_extractor
    from .utils import parse_qsl

    def _gen_test_server(port, accept_ranges):
        # Test web server
        import http.server
        import socketserver
        import threading
        Handler = lambda *args: http.server.SimpleHTTPRequestHandler(*args, directory='.')

        class MyTCPServer(socketserver.TCPServer):
            allow_reuse_address = True
        server = MyTCPServer(("", port), Handler)
        server_thread = threading.Thread(target=server.serve_forever)
        server_thread.daemon

# Generated at 2022-06-24 12:00:46.886232
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Testcase 1 HttpFD
    test1 = HttpFD(
        'http://www.google.com',
        {'noprogress': True},
        'get',
        {'testkey': 'testvalue'},
        None,
        "testuseragent")
    assert test1.ydl == None
    assert test1.params == {'noprogress': True}
    assert test1.method == 'get'
    assert test1.headers == {
        'testkey': 'testvalue',
        'User-Agent': 'testuseragent'}
    assert test1.test == False

    # Testcase 2 HttpFD

# Generated at 2022-06-24 12:00:53.662961
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import threading
    import time

    from .http_server import ServerHandler

    test_file_size = 200
    min_file_size = 50

    class TestHandler(ServerHandler):
        def do_GET(self):
            content_length = self.send_response(200)
            content_length.send_header('Content-Length', str(test_file_size))
            content_length.send_header('Content-Type', 'text/plain')
            content_length.end_headers()
            for i in range(test_file_size):
                self.wfile.write('%02d' % i)
            self.wfile.flush()

    class TestThread(threading.Thread):

        def __init__(self, *args, **kwargs):
            self.done = threading.Event()

# Generated at 2022-06-24 12:01:06.758343
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 12:01:15.385395
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .YoutubeDL import YoutubeDL
    for test in ['http://httpbin.org/bytes/102400', 'http://httpbin.org/bytes/102400?seed=42']:
        ydl = YoutubeDL()
        ydl.params['test'] = True
        ydl.params['noprogress'] = True
        ydl.params['quiet'] = True
        ydl.params['min_filesize'] = 0
        ydl.params['max_filesize'] = 1024
        ydl.params['prefer_free_formats'] = False
        for format in ['flv', '3gp', 'mp4', 'webm']:
            ydl.params['format'] = format
            for noresizebuffer in [True, False]:
                ydl.params['noresizebuffer'] = noresizebuffer
               

# Generated at 2022-06-24 12:01:21.543315
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        fd = HttpFD(sanitized_Request('http://www.example.com'), None, {'noprogress': True, 'retries': 3})
    except Exception as err:
        print('Failed to download from HTTP: %s' % err, file=sys.stderr)
        sys.exit(2)

    for _ in range(4):
        print(fd.read(5))


# Generated at 2022-06-24 12:01:33.899707
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile

# Generated at 2022-06-24 12:01:42.931527
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def open_test_url(url, params=None):
        return HttpFD(sanitized_Request(url), params, None)

    assert open_test_url('http://example.com/index.html').size() == -1, 'expecting -1 for Content-Length not specified'
    assert open_test_url('http://example.com/index.html').read() == b'<html>...'

    assert open_test_url('http://example.com/index.html', {'http_chunk_size': '1'}).size() == -1, 'expecting -1 for Content-Length not specified'

# Generated at 2022-06-24 12:01:55.364971
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def test_download(self):
        for fmt_urls in self.test_data:
            self.test_data[fmt_urls]['count'] = 0
            self.test_data[fmt_urls]['total'] = 0
            self.test_data[fmt_urls]['success'] = 0

# Generated at 2022-06-24 12:02:00.441994
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params = { 'noprogress': True, 'ratelimit': 7010, 'retries': 10 }
    outtmpl = '%(id)s-%(format)s'
    dl = HttpFD(params, outtmpl)

    assert dl.ydl is not None
    assert dl.params is params
    assert dl.outtmpl is outtmpl



# Generated at 2022-06-24 12:02:12.275705
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    import os
    import time
    import shutil

    # hack to make set_range work (pylint: disable=W0212)
    compat_http_client.HTTPConnection._http_vsn = 10
    compat_http_client.HTTPConnection._http_vsn_str = 'HTTP/1.0'
    # get a dummy http server
    from .test import get_test_server_handler
    handler = get_test_server_handler('/test')
    from http.server import HTTPServer
    server = HTTPServer(("127.0.0.1", 0), handler)
    # get a dummy http client
    from .test import DummyYDL
    ydl = DummyYDL()
    ydl.params['test'] = True

# Generated at 2022-06-24 12:02:23.110518
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for file-like object
    data = io.BytesIO(b'foobarbaz')
    fd = HttpFD(data)
    eq_(fd.read(3), b'foo')
    eq_(fd.get_data_len(), 9)
    eq_(fd.get_chunk_size(), None)

    # Test for object with properties
    class Data(object):
        def __init__(self, b):
            self.b = b
            self.pos = 0
        def read(self, n):
            ret = self.b[self.pos:self.pos + n]
            self.pos += n
            return ret
        def tell(self):
            return self.pos
    data = Data(b'foobarbaz')
    fd = HttpFD(data)

# Generated at 2022-06-24 12:02:35.215550
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    filename = 'test_HttpFD_real_download_filename'
    tmpfilename = filename + '.tmp'
    try:
        os.unlink(filename)
    except OSError:
        pass

    # Test retries parameter
    for retries in 1, 2, 5:
        test_data = 'foo'
        http_server = test_server.HttpServer(port_num=0, blocks=[test_data])
        http_server.start()
        url = http_server.get_url()
        hd = HttpFD({'retries': retries}, None, None)
        hd.add_info_dict({'url': url})
        success = hd.real_download(True)
        http_server.stop()
        assert success
        assert open(filename, 'rb').read() == test_data

# Generated at 2022-06-24 12:02:43.206435
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import codecs
    import os

    def dummy_encode(str):
        return str

    def check_equal(file1, file2):
        size = os.path.getsize(file1)
        if size != os.path.getsize(file2):
            return False
        f1, f2 = codecs.open(file1, 'rb'), codecs.open(file2, 'rb')
        try:
            while True:
                s1, s2 = f1.read(1024), f2.read(1024)
                if s1 != s2:
                    return False
                if len(s1) == 0:
                    break
        finally:
            f1.close()
            f2.close()
        return True


# Generated at 2022-06-24 12:02:52.101374
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os
    u = compat_urlparse.urlparse('http://www.example.org/')

    def _test_nofilename(fd):
        assert fd.name == '<fd:%d>' % fd.fileno()
        assert repr(fd) == '<HttpFD %s>' % fd.name
        assert str(fd) == fd.name
        try:
            fd.seek(0, os.SEEK_CUR)
        except (OSError, IOError, NotImplementedError):
            pass
        else:
            raise AssertionError('HttpFD.seek should fail')
        assert fd.read() == b'content'
        assert fd.read() == b''
        assert fd.read() == b''

    test_filename = '-'
    test_