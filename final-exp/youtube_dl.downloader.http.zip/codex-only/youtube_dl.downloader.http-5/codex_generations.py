

# Generated at 2022-06-24 11:52:53.904121
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FD(HttpFD):
        _TEST_FILE_SIZE = 50000

        # Mocks
        def __init__(self):
            HttpFD.__init__(self, 'test', {})

        def report_destination(self, filename):
            log('report_destination: %s' % filename)

        def report_retry(self, source_err, count, t):
            log('report_retry: %s' % source_err)

        def report_error(self, msg):
            log('report_error: %s' % msg)

        def report_resuming_byte(self, resume_len):
            log('report_resuming_byte: %s' % resume_len)


# Generated at 2022-06-24 11:53:01.802162
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _t(s):
        return s.encode('ascii')

    def _tb(s):
        return s.encode('ascii')

    def _tus(s):
        return s.encode('utf-8')

    def _tu(s):
        if sys.version_info >= (3,):
            return s.encode('utf-8')
        else:
            return s.decode('utf-8').encode('ascii')

    class MockOpener(object):
        def __init__(self, headers, data=None):
            if data is None:
                data = b''
            self.headers = headers
            self.data = io.BytesIO(data)


# Generated at 2022-06-24 11:53:08.001119
# Unit test for constructor of class HttpFD
def test_HttpFD():
    config_dict, _ = readOptions({
        'ratelimit': '50',
        'retries': '1',
        'buffersize': '2048',
        'noresizebuffer': 'True',
    }, defaults={
        'ratelimit': 0,
        'noresizebuffer': False,
        'retries': 10,
        'buffersize': 1024,
    })
    # Test call without any parameter
    fd = HttpFD(
        None, None, {}, {}, {}, {}, {}, {}, {}, None, 10.0,
        False, False, False, False, None, None)
    # Test changing parameters

# Generated at 2022-06-24 11:53:18.005406
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import re
    ctx = {
        'filepath': None,
        'filename': None,
        'tmpfilename': None,
        'stream': None,
        'open_mode': None,
        'resume_len': None,
        'data': None,
        'block_size': None,
        'data_len': None,
        'chunk_size': None,
        'is_resume': None,
        'has_range': None,
        'start_time': time.time(),
    }
    hf = HttpFD(ctx, {}, None, {})

# Generated at 2022-06-24 11:53:29.536842
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # For testing purposes, we will use _TEST_FILE_SIZE defined in HttpFD class
    file_size = HttpFD._TEST_FILE_SIZE
    # We will write this string to the file
    sample_string = 'this is a string with 32 bytes length'
    assert len(sample_string) == 32
    # We will write this string to the file every 512 bytes, so it is easier
    # to determine the position of the downloaded content
    marker_string = '|'
    marker_string_length = len(marker_string)
    assert marker_string_length == 1
    # We will split the file into chunks and download them all
    chunk_size = 1024
    # We will do not more than this number of retries if an error occurs
    number_of_retries = 3
    # The file will be saved to this

# Generated at 2022-06-24 11:53:34.099298
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYtdl(object):
        def __init__(self, test_name):
            self.to_screen_called = []
            self.to_stderr_called = []

            self.test_name = test_name
            self.download_retval = True
            self.count_slow_down = 0
            self.count_best_block_size = 0
            self.count_calc_speed = 0
            self.count_calc_eta = 0
            self.count_hook_progress = 0

            self._TEST_FILE_SIZE = 100000

        def report_resuming_byte(self, byte_counter):
            self.to_screen_called.append('report_resuming_byte')


# Generated at 2022-06-24 11:53:43.269721
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def chunk_gen():
        yield 'abc'
        yield 'def'
        yield 'ghijklmnopqrstuvwxyz'

    class FakeSocket(object):
        def __init__(self):
            self.data = io.BytesIO()

        def makefile(self, mode, bufsize):
            return self.data

        def read(self, num_bytes=None):
            if num_bytes:
                s = self.data.read(num_bytes)
                return s
            else:
                return self.data.read()

        def close(self):
            pass

    import http.client
    class FakeResponse(object):
        def __init__(self):
            self.status = 200
            self.reason = 'OK'
            self.debug_level = 0
            self.data = FakeSocket

# Generated at 2022-06-24 11:53:54.702369
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    import shutil
    import operator
    import subprocess
    import socket
    import random
    import atexit
    import traceback

    from .utils import PostProcessingError

    mock_server_process = None

    def start_mock_server():
        global mock_server_process

# Generated at 2022-06-24 11:54:06.632056
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for constructor for HttpFD class
    url = 'http://www.example.org/'
    http_fd = HttpFD(url, None, 16384)
    assert http_fd.url == url
    assert http_fd.ydl is None
    assert http_fd.chunk_size == 16384
    assert http_fd.start_time is not None

    # Test for _prepare_connection method of HttpFD class
    assert http_fd._prepare_connection() is None
    assert http_fd.data is None
    assert http_fd.data_len is None
    assert http_fd.resume_len == 0
    assert http_fd.retries == 10
    assert http_fd.filename == url
    assert http_fd.tmpfilename == url + '.part'
    assert http_fd.open_

# Generated at 2022-06-24 11:54:18.524423
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 11:54:31.712675
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD()
    # "Safe" values for testing the module
    fd.params['retries'] = 0
    fd.params['buffersize'] = 0
    fd.params['noresizebuffer'] = True
    fd.params['test'] = True
    # Fake real_download_bigfile
    def real_download_bigfile(self, ctx):
        ctx.data_len = ctx.block_size = self._TEST_FILE_SIZE
        ctx.data.read = lambda sz: ('a' * ctx.block_size + '\n')[:sz]
        ctx.data.info = lambda: {'Content-Length': ctx.data_len}

# Generated at 2022-06-24 11:54:43.119193
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class Dummy_HttpFD(HttpFD):
        def calc_eta(self, start, now, total, downloaded):
            return 3
        def calc_speed(self, start, now, downloaded):
            return 4
        def best_block_size(self, speed, old_bs):
            return speed
        def slow_down(self, start, now, transferred):
            pass
        def report_retry(e, count, retries):
            pass
        def report_destination(e, count, retries):
            pass
        def to_screen(self, *args, **kargs):
            return
        def to_stderr(self, *args, **kargs):
            return
        def report_error(self, *args, **kargs):
            return

# Generated at 2022-06-24 11:54:51.906466
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Set up mock objects
    class YDL(object):
        def urlopen(self, url):
            assert url.get_full_url() == 'http://test_url'
            assert url.headers.get('Range') == 'bytes=0-%d' % (TestHttpFD._TEST_FILE_SIZE - 1)
            class Data(object):
                def __init__(self, data):
                    self.data = data[:]
                def read(self, size):
                    return self.data.pop()
                def info(self):
                    return {'Content-length': '%d' % len(data)}
            return Data(data)
        def to_screen(self, s):
            print(s)

# Generated at 2022-06-24 11:54:58.146012
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            self.counter = 0
            self.tmp_names = []
            self.hooks = {
                'progress': [self.hook],
            }
            self.expected_filetime = None
            self.expected_atime = None
            self.expected_mtime = None
            HttpFD.__init__(self, *args, **kwargs)

        def hook(self, status):
            self.counter += 1
            if status['status'] == 'finished':
                self.expected_filetime = status['elapsed']
                if sys.platform == 'win32':
                    self.expected_atime = self.expected_filetime / 2.0
                else:
                    self.expected_atime = self.expected_

# Generated at 2022-06-24 11:55:03.625512
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import socket
    import sys
    import time
    from . import compat_urllib_error
    from .utils import sanitize_open, encodeFilename
    from .extractor import gen_extractors

    class MockYDL:
        params = {}
        _screen_file = sys.stdout

        def report_resuming_byte(self, byte):
            print('report_resuming_byte: %s' % byte)

        def report_retry(self, source_error, count, max):
            print('report_retry: source_error: %s, count: %s, max: %s' % (source_error, count, max))

        def report_file_already_downloaded(self, file_name):
            print('report_file_already_downloaded: %s' % file_name)



# Generated at 2022-06-24 11:55:15.995260
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    from io import UnsupportedOperation
    from io import SEEK_END
    from io import SEEK_SET
    from io import DEFAULT_BUFFER_SIZE

    # Data
    data = b'foobarbaz'  # 8 bytes

    # Test data without content-length header
    # (not given with HTTP 200)
    headers = {
        'Accept-Ranges': 'bytes',
        'Connection': 'close',
        'Content-Type': 'video/mp4',
    }
    urlopen_mock = compat_urllib_request.urlopen
    urlopen_mock.return_value.info.return_value = headers
    urlopen_mock.return_value.read.return_value = data

# Generated at 2022-06-24 11:55:25.559314
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Preparing
    ###########################################################################

    # Instantiating
    http_fd = HttpFD()

    # HTTP request
    ###########################################################################

    # Fake server settings
    httpd_port = get_free_port()
    httpd_server = StoppableHTTPServer(('', httpd_port), StoppableHTTPServerHandler)
    httpd_server.socket.settimeout(30)
    httpd_server.timeout = 30

    httpd_server_thread = threading.Thread(target=httpd_server.serve_forever)
    httpd_server_thread.daemon = True
    httpd_server_thread.start()

    # Request line
    url = 'http://localhost:%s/content.txt' % httpd_port
    # Request headers

# Generated at 2022-06-24 11:55:37.407855
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    gen_extractors()  # Ensure load of all extractors
    from .extractor import list_extractors
    from .utils import prepend_extension
    import io
    import json
    import tempfile
    import threading
    import time

    out, err = io.StringIO(), io.StringIO()
    global _hook_progress
    _hook_progress_results = []

    def _hook_progress(status):
        _hook_progress_results.append(status)
        out.write('%s\n' % json.dumps(status))
        out.flush()


# Generated at 2022-06-24 11:55:49.373739
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .compat import encodeFilename
    from .utils import DateRange

    # _TEST_FILE_SIZE is used as a max data size for setting Content-Length HTTP header
    # and for limiting block size.
    _TEST_FILE_SIZE = 100000
    expected_data = b'a' * _TEST_FILE_SIZE


# Generated at 2022-06-24 11:56:01.428058
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Testing a download for extractor/common.py
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = YoutubeDL({'format': 'best', 'quiet': True})
    ydl.add_default_info_extractors()
    info_dict = ydl.extract_info(url, download=False)
    filename = ydl.prepare_filename(info_dict)
    info_dict['filename'] = filename
    test_filename = 'test.flv'
    try:
        os.remove(test_filename)
    except OSError:
        pass
    dest_stream = open(test_filename, 'wb')
    h = HttpFD(ydl, info_dict, dest_stream)
    h.download()

# Generated at 2022-06-24 11:56:13.548472
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # 1.1 MB file with fairly random content from apache.org
    # http://mirror.ovh.net/ftp.apache.org/dist/httpd/httpd-2.4.7.tar.gz
    # md5: 8e3a8f54e0bdda355ec7c17b8939f7b2
    # cksum: 3478215096 1486898
    test_file = 'c90cf6d8e7c92ccaa44ed23226dce30e2c8b7e215ec22d40c7c94fbdcc8fbfad'
    test_url = 'http://www.apache.org/dyn/closer.cgi?filename=/httpd/httpd-2.4.7.tar.gz&action=download'

# Generated at 2022-06-24 11:56:17.893494
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(
        None, # ydl
        { # params
            'noprogress': True,
            'quiet': True,
        },
        None, #url
        None, # filename
        None, # info_dict
        None, # tmpfilename
        None, # data
    )
    assert h


# Generated at 2022-06-24 11:56:28.730538
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test exceptions for bad filenames
    for bad_filename in ['\x08']:
        try:
            HttpFD(bad_filename, {})
        except (OSError, IOError):
            pass
        else:
            raise AssertionError('HttpFD does not fail with %s filename' % bad_filename)

    # Test for filenames with non-ASCII characters
    for filename, filename_str in [
            ('test\u2603', 'test\\u2603'),
            ('test\u2603.txt', 'test\\u2603.txt')]:
        fd = HttpFD(filename, {})
        if fd.name != filename_str:
            raise AssertionError('HttpFD renames filenames with non-ASCII characters incorrectly')

    # Test for special names

# Generated at 2022-06-24 11:56:39.845352
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """This test exercises downloader/http.py on file download using
    real HTTP server (lighttpd). It also verifies whether the
    resulting file is correct.
    """

    # We need to override methods from FileDownloader class
    class TestFD(HttpFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.test_result_file = os.path.join(self.ydl.temp_dir, 'test.bin')
            self.test_data_len = None

        def report_error(self, *args, **kargs):
            super(TestFD, self).report_error(*args, **kargs)
            self.test_result = False


# Generated at 2022-06-24 11:56:50.518903
# Unit test for constructor of class HttpFD
def test_HttpFD():
    '''
    Run:
    youtube-dl --rm-cache-dir --verbose --test --test-http-fd-func
    '''

    import json
    import urllib
    import random
    import socket
    import shutil
    import tempfile

    from .extractor import gen_extractors

    server_socket = socket.socket()
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(('127.0.0.1', 0))
    server_socket.listen(5)
    # We have to store server_socket somewhere, because in Python 3 __del__ is
    # not called when exiting with an exception
    test_server_socket = [server_socket]
    port = server_socket.getsockname

# Generated at 2022-06-24 11:56:51.469662
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass

# Generated at 2022-06-24 11:57:04.029203
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Check for filesize detection
    urlh = compat_urllib_request.urlopen('http://ftp.apnic.net/stats/apnic/delegated-apnic-latest')
    hd = HttpFD(urlh)
    assert hd.geturl() == 'http://ftp.apnic.net/stats/apnic/delegated-apnic-latest'
    assert hd.realurl == 'http://ftp.apnic.net/stats/apnic/delegated-apnic-latest'
    assert hd.filename == 'delegated-apnic-latest'
    assert hd.info() == urlh.info()
    assert hd.size == urlh.info().get('Content-Length')
    assert hd.read(8192) == urlh.read(8192)

# Generated at 2022-06-24 11:57:16.059277
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ''' Test HttpFD_real_download
    Test download a file, download it a second time with resume,
    and download it when content-length is missing (chunked response)

    Note: In this test we are using textblocks of different lengths to
    ensure the best_block_size() works correctly.
    '''

    # params for test
    params = {
        'nooverwrites': True,
        'continuedl': True,
        'noprogress': True,
        'quiet': True,
        'ratelimit': 0,
        'retries': 0,
    }

    # Prepare test server
    server = ServerRunner(server_name='test_HttpFD_real_download', port=0, quiet=True)
    server.start()

# Generated at 2022-06-24 11:57:27.438381
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from youtube_dl.utils import sanitize_open
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import (
        compat_html_unescape,
        compat_HTTPError,
        compat_urllib_error,
    )

    urlopen = compat_urllib_request.urlopen
    urlretrieve = compat_urllib_request.urlretrieve
    Request = compat_urllib_request.Request

    if sys.version_info >= (3, 0):
        def b(x):
            return x
    else:
        def b(x):
            return x.encode('ascii')

    def urlopen_side_effect(request):
        if request.get_full_url() == 'http://www.example.com/':
            return compat_ur

# Generated at 2022-06-24 11:57:39.098150
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    import datetime
    import sys
    import tempfile
    # 2015-04-29 (qw3rtman):
    # For some reason `from __future__ import unicode_literals` breaks this test
    # when run by nosetests. In interactive mode (by hand) it works fine.
    # It might be connected to the following fact that `test_HttpFD_real_download`
    # can only be launched from command line (by hand) and only after `nosetests` has
    # been run first.
    # Anyway, the following line fixes the problem in this test and
    # it contains the same string literally as the import line above
    # which is not working in nosetests.
    unicode_type=unicode
    assert sys.version_info < (3, 0)
    from collections import namedtuple


# Generated at 2022-06-24 11:57:50.204779
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with a file
    fd = HttpFD(open(__file__, 'rb'), {'Content-Length': str(os.path.getsize(__file__))})
    assert fd.size() == os.path.getsize(__file__), 'file size should be read from Content-Length'
    assert fd.tell() == 0, 'HttpFD.tell() should initially return 0'
    assert fd.read(1) == b'#'[0], 'HttpFD.read(1) should read a single byte from file'
    assert fd.tell() == 1, 'HttpFD.tell() should be 1 after reading one byte'

# Generated at 2022-06-24 11:57:59.390996
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # noinspection PyUnusedLocal
    def _hook_progress(d):
        if 'status' in d and d['status'] in ('finished', 'downloading'):
            print('\r[{status}]'.format(**d))
            if d['status'] == 'finished':
                sys.stdout.write('\n')
                sys.stdout.flush()

    # noinspection PyUnusedLocal
    def _hook_temp_name(name, filename):
        return name

    downloader = HttpFD()
    downloader.params['logger'] = _FakeLogger((lambda *args, **kargs: None, lambda *args, **kargs: None))
    downloader.params['nooverwrites'] = True
    downloader.params['retries'] = 0

# Generated at 2022-06-24 11:58:08.176793
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test using a proxy
    url = 'http://localhost:8080/'
    with _ContextManager() as ctxm:
        ht = HttpFD(ctxm(), {'http_proxy': 'http://localhost:8080/'})
        ht.check_connection(url, proxies={})
        ht.report_url(url, {'http_proxy': None})
        assert not ht.test_proxy_for_url(url, {})
        assert ht.test_proxy_for_url(url, {'http': 'http://localhost:8080/'})



# Generated at 2022-06-24 11:58:18.999727
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors
    # Fetch all extractors
    info_dict = {
        'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'extractor': 'youtube',
        'player_url': None,
    }
    ie = gen_extractors(info_dict)

    # Find YouTube extractor
    yt_ie = None
    for ie in ie:
        if ie.IE_NAME == 'youtube':
            yt_ie = ie
            break
    assert(yt_ie is not None)

    # Test without player_url
    info_dict['player_url'] = None

# Generated at 2022-06-24 11:58:25.178178
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import urlparse
    from .downloader import HttpFD

    def content_gen():
        for i in range(10):
            # DEBUG: uncomment next line to see how the test handles
            # a content-length of None.
            # if i == 5: raise ValueError()
            for ii in range(10):
                yield str(i)+str(ii)

    class MockServer(object):
        class Handle(object):
            def __init__(self, content=None):
                self.content = content
                self.bytes_sent = 0
                self.started = False
                self.closed = False

            def start_response(self, status, response_headers):
                assert(status == '200 OK')
                self.content_length = dict(response_headers).get('Content-length', None)
                self.started = True

# Generated at 2022-06-24 11:58:30.890558
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print("Testing real_download...")
    data_len = None
    taken_len = 0
    resume_len = 0
    chunk_size = -1
    data = None
    def establish_connection():
        nonlocal resume_len, data_len, data
        # Uses a fake server, so no real connection established
        data_len = 1024 * 10
        if is_test and data_len > _TEST_FILE_SIZE:
            data_len = _TEST_FILE_SIZE
            if not resume_len:
                resume_len = 8
        data = compat_http_client.HTTPResponse(
            compat_http_client.HTTPConnection("example.com"),
            status=200)
        data.begin()
        return data
    def download():
        nonlocal taken_len, data_len, data
       

# Generated at 2022-06-24 11:58:41.022070
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Test real_download method
    """

    def content_gen():
        """
        Generator producing correct data
        """
        while True:
            yield 'asdf'

    def truncating_content_gen():
        """
        Generator producing cut data
        """
        for _ in range(2):
            yield 'asdf'

    def disconnecting_content_gen():
        """
        Generator producing correct data, but with connection closing after the first request
        """
        for _ in range(1):
            yield 'asdf'

    class ContentTooShortError(compat_urllib_error.URLError):
        """
        Class for simulating ContentTooShortError
        """

# Generated at 2022-06-24 11:58:49.117970
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    (my_tmp_dir, my_retval) = tempfile.mkstemp()
    def my_hook_progress(status):
        print(status)
    params = {
        'noprogress': True,
    }
    my_InfoExtractor = InfoExtractor(params)
    my_IE_NAME = 'test_IE'
    my_URL = 'http://www.clipconverter.cc/static/images/icons/icon_download_video.png'
    my_IE = my_InfoExtractor(my_InfoExtractor, my_IE_NAME, my_URL)
    my_InfoExtractor.add_info_extractor(my_IE)
    my_filename = 'icon_download_video.png'
    my_ydl = YoutubeDL(params)
    my_ydl.add_info

# Generated at 2022-06-24 11:58:59.566381
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import shutil
    import tempfile
    
    # Create temp dir
    temp_dir = tempfile.mkdtemp()

    # Create a fake HttpFD instance
    instance = HttpFD()
    instance._TEST_FILE_SIZE = 100 * 1024 * 1024  # 100 MiB
    instance.to_screen = lambda *args, **kwargs: None
    instance.report_error = lambda *args, **kwargs: None
    instance.report_retry = lambda *args, **kwargs: None
    instance.report_destination = lambda *args, **kwargs: None
    instance.report_resuming_byte = lambda *args, **kwargs: None
    instance.report_unable_to_resume = lambda *args, **kwargs: None

# Generated at 2022-06-24 11:59:10.545796
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import urllib.request, tempfile, os, time

    # Test with file size known in advance
    def test_1(**download_params):
        params = {'nooverwrites': True, 'continuedl': False, 'ratelimit': 200000}
        params.update(download_params)
        hd = HttpFD(urllib.request, params)
        (tmpfd, tmpfilename) = tempfile.mkstemp(prefix='youtubedl-test-1-')
        os.close(tmpfd)
        temp_files = [tmpfilename]

# Generated at 2022-06-24 11:59:21.403332
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os
    import sys
    import tempfile
    import time
    import shutil
    import random
    import base64
    import json
    import subprocess

    # Generate random string with supplied length
    def rstring(l):
        return base64.b64encode(os.urandom(l)).decode()

    # Get first non-empty line from supplied stream
    def sreadline(stream):
        line = stream.readline()
        while not line:
            line = stream.readline()
        return line.strip()

    server_args = ['python', '-m', 'http.server', '--cgi']
    downloader_args = [sys.executable, '-m', 'youtube_dl.downloader.http', '--quiet', '--quiet', '--force-url', 'true']
    num

# Generated at 2022-06-24 11:59:30.842560
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import threading
    import time
    import traceback
    import urllib.error
    import urllib.parse
    sys.path.append('../')
    from ytdl.utils import FakeYDL
    print('@UT@START')
    print('@UT@SET ' + 'TestHttpFD')
    ydl = FakeYDL()
    hfd = HttpFD(ydl, {'noprogress': True, 'retries': 0, 'quiet': True})
    hfd.to_screen = lambda str: print('@UT@MSG ' + str)
    hfd.to_stderr = lambda str: print('@UT@MSG ' + str)
    class TestHttpServerThread(threading.Thread):
        def __init__(self):
            threading.Thread.__

# Generated at 2022-06-24 11:59:37.165369
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    test_content_type = 'test_content_type'
    test_filename = 'test_filename'
    test_url = 'test_url'
    test_data = b'0123456789'
    with tempfile.NamedTemporaryFile() as f:
        f.write(test_data)
        f.flush()
        f.seek(0)
        h = HttpFD(f, test_url, test_content_type, test_filename)
        # Testing that the descriptor is functional
        assert h.read() == test_data
    h = HttpFD(BytesIO(test_data), test_url, test_content_type, test_filename)
    # Testing that the descriptor is functional
    assert h.read() == test_data
    h.close()
    # Testing constructor with

# Generated at 2022-06-24 11:59:43.161455
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Creating a test file
    import tempfile
    tdir = tempfile.mkdtemp(prefix='youtubedl-test-')
    tfn = os.path.join(tdir, 'test.bin')
    with open(tfn, 'wb') as tf:
        tf.write(b'\x00' * 1000 + b'\xff' * 1000)


# Generated at 2022-06-24 11:59:53.125671
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Suppress error messages
    def my_hook(*args, **kargs):
        pass
    youtube_dl.extractor.gen_extractors()
    ydl_opts = {
        'forceurl': True,
        'forcetitle': True,
        'quiet': True,
        'nocheckcertificate': True,
        'simulate': True,
        'format': '47',
        'outtmpl': '%(id)s.%(ext)s',
        'progress_hooks': [my_hook],
    }
    class DummyYDL:
        def __init__(self, opts):
            self.opts = opts
        def to_stderr(self, s):
            pass
        def trouble(self, s, tb=None):
            pass

# Generated at 2022-06-24 12:00:03.922654
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    from .common import FileDownloader
    from .utils import sanitize_open, encodeFilename

    assert_all_pass = []
    assert_all_fail = []
    assert_all_counters = {}

    def assert_equals(counter, expected, result=None,
                      progress_hook=None, params=None):
        if params is None:
            params = {}

        def _progress_hook(status):
            for k, v in status.items():
                if k in ('status', 'filename', 'tmpfilename', 'total_bytes'):
                    continue
                if isinstance(v, float):
                    v = int(v)
                assert_status[k] = v
            if progress_hook:
                progress_hook(status)


# Generated at 2022-06-24 12:00:09.721535
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile

    data = 'abcde12345'
    tmpfd, tmpfilename = tempfile.mkstemp(prefix='yt-dl test_')
    os.write(tmpfd, data)
    os.close(tmpfd)
    hd = HttpFD(data, {'url': 'http://www.example.com/%s' % tmpfilename, 'tempfilename': tmpfilename})
    hd.read(5)
    hd.read(5)
    hd.close()
    assert os.path.isfile(tmpfilename) == 0
    assert hd.bytes_downloaded == 10
    assert hd.len == 10
    assert hd.info() == {'url': 'http://www.example.com/%s' % tmpfilename, 'tempfilename': tmpfilename}
    assert hd.tell

# Generated at 2022-06-24 12:00:19.367614
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 12:00:23.546609
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(HttpFD):
        def __init__(self):
            HttpFD.__init__(self, {'nooverwrites': True, 'continuedl': True,
                'noprogress': False, 'retries': 8, 'test': True}, '_test', '-', 1, None)
            self.to_screen = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_file_already_downloaded = lambda *args, **kargs: None
            self.report_resuming_byte = lambda *args, **kargs: None
            self.report_destination = lambda *args, **kargs: None
            self.report_un

# Generated at 2022-06-24 12:00:35.118389
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestException(Exception): pass
    class TestYDL():
        def __init__(self):
            self.to_screen_lock = threading.Lock()
            self.recorded = []
            self.error = None
            self.is_test = True
            self.params = {
                'buffersize': 1024,
                'noresizebuffer': False,
                'test': True,
                'ratelimit': None,
                'retries': 5,
                'fragment_retries': 10,
                'skip_unavailable_fragments': False,
            }
            self.pause = False
            self.download_retcode = None

        def to_screen(self, *args):
            with self.to_screen_lock:
                self.recorded += args
                self.recorded += ('\n', )



# Generated at 2022-06-24 12:00:49.516146
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test 1
    # Prepare
    # Test
    class HttpFD_test(HttpFD):
        def __init__(self):
            self._TEST_FILE_SIZE = 100 
            self.params = {'continuedl': True}
            self.ydl = None
            self.to_screen = to_screen_test_1
            self.report_resuming_byte = report_resuming_byte_test_1
            self.report_destination = report_destination_test_1
            self.report_unable_to_resume = report_unable_to_resume_test_1
            self.report_error = report_error_test_1
            self.report_retry = report_retry_test_1
            self.best_block_size = best_block_size_test_1

# Generated at 2022-06-24 12:01:03.932454
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import test_http_server
    @contextmanager
    def make_server(port):
        yield test_http_server.make_server(port)


# Generated at 2022-06-24 12:01:10.234082
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    params = {'quiet':True}
    ydl = YoutubeDL(params)
    filename = 'iran.webm'
    fd = HttpFD(ydl, 'http://www.example.com/'+filename, {}, filename + '.tmp', 'wb')
    fd.real_download(params)


# Generated at 2022-06-24 12:01:21.413985
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 12:01:27.709634
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_fd(fd):
        fd.write(b'foo')
        fd.close()

    fd = HttpFD('http://localhost/')
    fd.close()
    test_fd(fd)
    fd = HttpFD('http://localhost/', {'noprogress': True})
    fd.close()
    test_fd(fd)



# Generated at 2022-06-24 12:01:39.949350
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create HttpFD object
    fd = HttpFD(
        'http://www.google.com/',
        {'noprogress':True}
    )
    # Test readline method
    bytes = fd.readline(8)
    assert bytes == b'<!doctype'
    # Test read method
    bytes = fd.read(8)
    assert bytes == b' html><ht'
    # Test read method with len argument set to None
    bytes = fd.read(None)
    assert len(bytes) == 92
    # Test close method
    fd.close()
    # Test read method when file is closed
    raises(EOFError, lambda : fd.read(8))
    raises(EOFError, lambda : fd.readline(8))


# Generated at 2022-06-24 12:01:52.910990
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = FakeYDL()
    info = {'url': 'http://127.0.0.1/video.mp4'}
    # Test with params (should use params['noprogress'] and params['progress_with_newline'])
    params = {'format': 'bestvideo', 'noprogress': True, 'progress_with_newline': False}
    http_fd = HttpFD(ydl, params, info)
    assert http_fd.params == params
    assert http_fd.info == info
    assert http_fd.skip_report_progress is False
    # Test without params (should use ydl.params['noprogress'] and ydl.params['progress_with_newline'])
    http_fd = HttpFD(ydl, {}, info)
    assert http_fd.params

# Generated at 2022-06-24 12:02:01.941556
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import encode_data_uri
    test_data = 'Hello World'
    test_uri = encode_data_uri(test_data, 'text/plain')
    h = HttpFD(test_uri, None)
    assert h.read(1) == 'H'
    assert h.read(5) == 'ello '
    assert h.read(1) == 'W'
    assert h.read(4) == 'orld'
    assert h.read(1) == ''  # end of file
    assert h.read(0) == ''  # end of file

    # readline should be case-insensitive
    test_uri = encode_data_uri('foo\nbar', 'text/plain')
    h = HttpFD(test_uri, None)

# Generated at 2022-06-24 12:02:13.089024
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # No test can be performed if a proxy is defined in the environment
    if os.environ.get('http_proxy') is not None:
        print('[no test] Skipping httpfd test because of proxy')
        return

    import tempfile
    # Test that HttpFD can be used to download a file via HTTP
    print(('Starting download test using HttpFD.'))
    (handle, fd) = tempfile.mkstemp(prefix='youtube-dl-test_')
    f = os.fdopen(handle, 'wb')
    YTDL_TEST_URL = 'http://www.google.com/'
    # Test that HttpFD can be used as a FileDownloader
    print(('Downloading %s to %s' % (YTDL_TEST_URL, fd)))
    fd = Http

# Generated at 2022-06-24 12:02:19.412831
# Unit test for constructor of class HttpFD
def test_HttpFD():
    info = dict(
        url = 'http://localhost:8080/',
        http_headers = {'Test-Header': 'Test-Value'}
    )

    ydl = FakeYDL()
    hd = ydl.build_fd('http', info, {})
    assert isinstance(hd, HttpFD)
    return hd


# Generated at 2022-06-24 12:02:32.228164
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from YoutubeDL.utils import encodeFilename
    import sys
    import shutil
    import tempfile
    import socket
    import errno
    import ssl
    from .compat import compat_HTTPError, compat_ssl_match_hostname
    from .extractor.common import InfoExtractor

    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
            self.tmpfilename = self.filename = None

        def to_screen(self, s):
            print(s)

        def to_stderr(self, s):
            print(s, file=sys.stderr)

        def trouble(self, s, tb=None):
            raise Exception(s)


# Generated at 2022-06-24 12:02:40.376399
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Test constructor of class HttpFD
    """
    assert_raises(ValueError, lambda: HttpFD(None, None))
    assert_raises(ValueError, lambda: HttpFD('http://www.example.com/index.html', 'wb'))
    assert_raises(ValueError, lambda: HttpFD('http://www.example.com/index.html', 'ab'))
    assert not hasattr(HttpFD('http://www.example.com/index.html', 'rb'), 'stream')
    assert not hasattr(HttpFD('http://www.example.com/index.html', 'wb'), 'stream')
    assert not hasattr(HttpFD('ftp://www.example.com/index.html', 'wb'), 'stream')


# Generated at 2022-06-24 12:02:46.586618
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    config = {
        'outtmpl': u'%(id)s',
        'format': 'best',
    }
    hfd = HttpFD(config, None)