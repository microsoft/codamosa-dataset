

# Generated at 2022-06-24 11:52:55.884423
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test(obj):
        assert obj.bytes_downloaded == 100
        assert obj.url == 's3://some/path'
        obj.get_content_type()
        obj.get_content_length()
        obj.get_fd()
        obj.clean()

    test(HttpFD('s3://some/path', 100, None))
    test(HttpFD('s3://some/path', 100, 100))
    test(HttpFD('s3://some/path', 100, 'unknown'))
    test(HttpFD('s3://some/path', 100, 'video/mp4'))

    def test(url, fd):
        assert HttpFD(url, None, None).get_content_length(fd) == 42

    test('http://localhost', io.BytesIO(b'x' * 42))


# Generated at 2022-06-24 11:53:04.001670
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url = 'http://example.com/abc'
    def uo_side_effect(req):
        return socket.socket()

    with mock.patch('youtube_dl.utils.urlopen') as uo:
        uo.side_effect = uo_side_effect
        hfd = HttpFD(url, None, {})
        assert isinstance(hfd, HttpFD)
        assert hfd.url == url
        assert type(hfd.name) == int
        hfd.close()


# Generated at 2022-06-24 11:53:11.506888
# Unit test for constructor of class HttpFD
def test_HttpFD():
    '''
    This unit test creates an index.html file, then creates a HttpFD object
    that downloads the file.  Once the HttpFD object is created, it verifies
    that HttpFD.data contains the correct index file.

    This unit test does not verify that HttpFD can retry and resume downloads.
    '''
    # Simple web server.
    import socket
    import BaseHTTPServer
    import SimpleHTTPServer
    httpd = BaseHTTPServer.HTTPServer(('localhost', 0), SimpleHTTPServer.SimpleHTTPRequestHandler)
    httpd_port = httpd.server_port
    import threading
    httpd_thread = threading.Thread(target=httpd.serve_forever)
    httpd_thread.daemon = True
    httpd_thread.start()

    # Create a

# Generated at 2022-06-24 11:53:22.738908
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with values that trigger the exception in __init__
    for args in [(0, 1), (-1, 1), (1, 0), (1, -1)]:
        try:
            HttpFD(*args)
            assert False, 'Created HttpFD with wrong parameters: ' + str(args)
        except ValueError:
            pass

    # Create the object with a proper set of arguments
    hfd = HttpFD(1, 1, max_buffer_size = 100)
    # Check the initial values
    assert hfd.min_buffer_size == 1 and hfd.max_buffer_size == 100, 'Bad default values for min_buffer_size, max_buffer_size'
    assert hfd.downloaded_bytes == 0, 'Bad default value for downloaded_bytes'

# Generated at 2022-06-24 11:53:25.241898
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print(HttpFD('https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/youtube_dl/version.py'))


# Generated at 2022-06-24 11:53:34.481855
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print(u'Testing constructor of class HttpFD')
    # unicode URLs
    _ = HttpFD(u'http://www.w3.org/', u'this_is_a_test.tmp')
    _ = HttpFD(u'http://☃.net/')
    _ = HttpFD(u'http://www.w3.org/', u'this_is_a_test.tmp')
    _ = HttpFD(u'http://☃.net/', u'this_is_a_test.tmp')
    print(u'Passed')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:53:42.060889
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def _test_urlopen(req):
        assert isinstance(req, Request)
        return compat_http_client.HTTPResponse(
            compat_http_client.HTTPConnection('localhost'), 200)

    chunk_size = 1024 * 1024
    ydl = YoutubeDL({'progress_hooks': [lambda _: None]})
    ydl.urlopen = _test_urlopen
    fd = HttpFD(ydl, 'http://localhost', {'Accept': 'video/*'}, None, chunk_size)
    fd.read(1)
    fd.close()



# Generated at 2022-06-24 11:53:53.575503
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    from .__main__ import parseOpts
    from .YoutubeDL import YoutubeDL
    from .utils import urlopen, urljoin

    def test_downloader(ydl, params, filename, download, count):
        class Options(object):
            def __init__(self):
                self.noprogress = False
                self.logger = ydl
                self.params = params
        opts = Options()
        fd = HttpFD(ydl, params, filename, info_dict=None, download=download)
        fd.add_progress_hook(params['test_progress_hook'])
        fd.test_counter = count
        fd.real_download(opts, fd.url, fd.info_dict)


# Generated at 2022-06-24 11:54:05.939584
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # TODO move this to tests
    class MockYDL(object):
        def __init__(self):
            self.params = {
                'verbose': True,
                'logger': YoutubeDL()
            }

    ydl = MockYDL()
    fd = HttpFD(ydl, 'http://127.0.0.1/50x', {
        'noprogress': False,
        'continuedl': True,
        'quiet': False,
        'ratelimit': None,
        'retries': 5,
        'buffersize': None,
        'noresizebuffer': False,
    })
    assert fd.best_block_size(0.0, 0) == 8192
    assert fd.best_block_size(0.1, 0) == 8192
    assert f

# Generated at 2022-06-24 11:54:17.684761
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, params={})
    # Test if the following calls print an informative message
    fd.report_warning('test')
    # Test if the following calls do nothing
    fd.report_resuming_byte(1234)
    fd.report_retry('my error', 5, 5)
    fd.report_file_already_downloaded('nul')
    fd.report_unable_to_resume()
    fd.report_restart('nul')
    # Test if the following calls raise an exception
    fd.report_error('test')
    # Test if the following calls return without errors
    fd.report_destination('nul')
    fd.try_rename('', '')
    fd.try_utime('', None)

# Generated at 2022-06-24 11:54:27.897398
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test for real_download with chunked download
    # (chunk_size > 0)
    ydl = YoutubeDL()
    ydl.params['continuedl'] = True
    # Skipping '_hook_progress' test
    ydl._hook_progress = lambda *args, **kargs: None
    ydl.report_retry = lambda *args, **kargs: None
    ydl.report_error = lambda *args, **kargs: None
    ydl.report_destination = lambda *args, **kargs: None
    ydl.report_resuming_byte = lambda *args, **kargs: None
    ydl.report_unable_to_resume = lambda *args, **kargs: None
    ydl.report_file_already_downloaded = lambda *args, **kargs: None


# Generated at 2022-06-24 11:54:37.410316
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Helper functions
    def retrieve_webpage(url, params=None, encoding=None):
        """ Wrapper for YoutubeDL.urlopen """
        return HttpFD(YoutubeDL()).retrieve(
            url, filename=None, data=None, headers={},
            expected_size=None, resume=False,
            query=params,
            retries=0,
            chunk_size=-1,
        )
    # Mock urllib.urlopen and os functions
    class MockUrlOpen(object):
        """
        Mock urlopen
        """
        def __init__(self):
            self.data_len = None
            self.request_headers = {}
            self.request_url = None
            self.file_data = b''
            self.request_count = 0
            self.resp_headers = {}


# Generated at 2022-06-24 11:54:48.543785
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    dl = Downloader()
    dl.params['noprogress'] = True
    dl.add_info_extractor(genericIE)
    dl.add_info_extractor(YoutubeIE())
    dl.add_info_extractor(MetacafeIE())
    dl.add_info_extractor(DailymotionIE())
    dl.add_info_extractor(VimeoIE())
    dl.add_info_extractor(YoutubePlaylistIE())
    dl.add_info_extractor(YahooIE())
    dl.add_info_extractor(SoundcloudIE())
    dl.add_info_extractor(YoutubeChannelIE())
    dl.add_info_extractor(InfoQIE())

# Generated at 2022-06-24 11:54:59.583197
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYDL(object):
        params = {}
        def __init__(self):
            self.trouble = []
            self.to_screen = []
        def trouble(self, message, tb):
            self.trouble.append(message)
        def to_screen(self, message):
            self.to_screen.append(message)
        def to_stderr(self, message):
            self.to_screen.append(message)
    f = FakeYDL()
    # It should not crash on non-HTTP URLs
    fd = HttpFD(f, 'file:///etc/fstab', {}, None)
    fd.read(1024)
    # It should not crash when server does not set Content-Length

# Generated at 2022-06-24 11:55:05.591495
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import test_http_server
    import threading

    # Construct an HttpFD object, and test its behavior
    def test(ctx):
        # Construct an HttpFD object
        hdf = HttpFD(ctx.url, None, None, None)

        # Basic read()
        result = hdf.read(5)
        ctx.assertEqual(result, b'hello')

        # read() at the end
        result = hdf.read(5)
        ctx.assertEqual(result, b'')

        # readline()
        hdf.seek(0)
        result = hdf.readline()
        ctx.assertEqual(result, b'hello\n')

        # readlines()
        hdf.seek(0)
        result = hdf.readlines()

# Generated at 2022-06-24 11:55:18.583315
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    outf = os.path.join(tmpdir, 'out')

# Generated at 2022-06-24 11:55:27.056304
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Unit tests for real_download of class HttpFD"""

    # We prepare several test files, each with its own md5 hash and
    # size, and they are all smaller than 1MB.

# Generated at 2022-06-24 11:55:33.828717
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # extract all urls from the first two pages of YouTube search for ytdl
    url = "https://www.youtube.com/results?search_query=ytdl&page=1"

    # this test downloads the youtube page
    # test_urlopen = HttpFD()
    # html = test_urlopen.get_urldata(url).decode()
    html_filename = 'test_data/html/ytdl_url.html'
    with open(html_filename, 'r') as html_file:
        html = html_file.read()

    # extracts the links
    links = extract_links(html)

    # test url

# Generated at 2022-06-24 11:55:38.631272
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # We have to provide some non-empty string as parameter to HttpFD constructor
    fd = HttpFD('a')
    assert fd.real_url is None
    assert fd.content_type is None
    assert fd.status == 200
    assert fd.filename is None
    assert fd.info() == {}

    fd = HttpFD('a', {'url': 'b'})
    assert fd.real_url == 'b'
    assert fd.content_type is None
    assert fd.status == 200
    assert fd.filename is None
    assert fd.info() == {'url': 'b'}

    fd = HttpFD('a', {'url': 'b', 'c': 'd'})
    assert fd.real_url == 'b'
    assert f

# Generated at 2022-06-24 11:55:50.034228
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 11:55:53.843902
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD().read(5) == b''
    assert HttpFD(content_length=5).read(5) == b'\0' * 5

# Unit tests for sanitize_open() function

# Generated at 2022-06-24 11:56:04.209925
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import gzip
    import tempfile

    def _test_read(fd, maxlen, res):
        assert (fd.read(maxlen) == res)

    def _test_read_b(fd, maxlen, res):
        assert (fd.read(maxlen) == res.encode('ascii'))

    # Test HttpFd creation and basic functionality
    hfd = HttpFD('http://www.google.com/', None, 'GET', 'test_user')
    _test_read_b(hfd, 10, '<!doctype')
    hfd.close()

    # Test data reading with maxlen specified
    hfd = HttpFD('http://www.google.com/', None, 'GET', 'test_user')

# Generated at 2022-06-24 11:56:15.614148
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if not compat_urllib_request:
        return
    url = 'http://127.0.0.1:15672/testfile'

    class HeadRequest(compat_urllib_request.Request):
        def get_method(self):
            return "HEAD"

    class RangeRequest(compat_urllib_request.Request):
        def get_method(self):
            return "GET"

    # Test all possible combinations of count and start
    for count in (None, 10, 1000):
        for start in (None, 0, 1000):
            # Construct class instance
            hfd = HttpFD(
                HeadRequest(url),
                RangeRequest(url),
                start=start,
                count=count,
                blocksize=8192)
            # Test realstart and realcount
            assert hfd.real

# Generated at 2022-06-24 11:56:17.350700
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(None, None)
    assert h.ydl is None


# Generated at 2022-06-24 11:56:28.357466
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import io
    import sys
    import shutil
    import filecmp
    import tempfile

    if os.path.exists('test'):
        shutil.rmtree('test')
    if os.path.exists('test.out'):
        os.remove('test.out')

    def check_equality(expected_fn, actual_fn):
        if not filecmp.cmp(expected_fn, actual_fn, False):
            raise ValueError('Files are not equal: %r %r' % (expected_fn, actual_fn))

    ##########
    # Tester #
    ##########

    class Tester(object):
        def __init__(self):
            self.test_count = 0


# Generated at 2022-06-24 11:56:39.281826
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """http_fd.py unit test"""

    class HeadRequest(compat_urllib_request.Request):
        def get_method(self):
            return "HEAD"

    DL = HttpFD(test_server_port=8080).setup('http://localhost:8080/test.mp4', {'noprogress': True})
    ASSERT_EQ(DL.ydl.urlopen(HeadRequest('http://localhost:8080/test.mp4')).headers['Content-length'], '100')
    ASSERT_EQ(DL.params['test'], 'test')
    ASSERT_EQ(DL.ydl.urlopen(HeadRequest('http://localhost:8080/test.mp4')).headers['Content-length'], '100')

# Generated at 2022-06-24 11:56:46.282559
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test HTTPS
    https_pafy = HttpFD(
        'https://www.youtube.com/watch?v=1MqJO3lxrXc',
        params={'simulate': True})

    assert 'filename' in https_pafy.info

    # Test HTTP
    http_pafy = HttpFD(
        'http://www.youtube.com/watch?v=1MqJO3lxrXc',
        params={'simulate': True}
    )
    assert 'filename' in http_pafy.info

    # Test invalid URL prefix

# Generated at 2022-06-24 11:56:53.349746
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    (test_result, test_exc) = run_method(HttpFD, 'real_download', params={
        'test': True,
        'quiet': True,
        'nooverwrites': True,
        'continuedl': True,
        'noresizebuffer': True,
        'test_writesize': 100,
        'test_download_rate': 20000,
        'test_max_speed': 200000,
    }, filename='-')
    assert test_result is True, test_exc
# Class to manage downloading files

# Generated at 2022-06-24 11:57:05.345697
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import time, os

    class TestFD(HttpFD):
        """A test downloader class that pretends to download in chunks of
        5 bytes and then raises ContentTooShortError. Used to test
        retries, etc."""
        def real_download(self, filename, info_dict):
            try:
                stream, tmpfilename = sanitize_open(filename, 'wb')
            except (OSError, IOError) as err:
                self.report_error('unable to open for writing: %s' % str(err))
                return False
            fileSize = 100
            self.report_destination(filename)
            block = b""
            while len(block) < fileSize:
                block += b'xxxxx'
                stream.write(block)
                self.report_progress(len(block), fileSize, None)


# Generated at 2022-06-24 11:57:17.219782
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import doctest
    import sys
    if sys.version_info[0] == 2:
        import urllib2 as compat_urllib_request
        import urllib as compat_urllib_parse
        import urlparse
        compat_urlparse = urlparse
        import httplib as compat_http_client
    elif sys.version_info[0] == 3:
        import urllib.request as compat_urllib_request
        import urllib.parse as compat_urllib_parse
        import urllib.parse as urlparse
        compat_urlparse = urlparse
        import http.client as compat_http_client
    import socket
    import errno
    import time
    import io
    import os
    import tempfile
    import shutil
    import threading
    import atexit
   

# Generated at 2022-06-24 11:57:28.870319
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Mock objects
    class MockYDL(object):
        def __init__(self):
            self.urlopen = mock.MagicMock()
            self.to_screen = mock.MagicMock()
            self.report_error = mock.MagicMock()
            self.report_retry = mock.MagicMock()
            self.report_destination = mock.MagicMock()
            self.report_file_already_downloaded = mock.MagicMock()
            self.report_unable_to_resume = mock.MagicMock()
            self.report_resuming_byte = mock.MagicMock()
            self.slow_down = mock.MagicMock()
            self.best_block_size = mock.MagicMock()
            self.calc_speed = mock.MagicMock()

# Generated at 2022-06-24 11:57:40.727359
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    import io
    import json
    import os
    import shutil
    import sys
    import tempfile
    import threading
    from urllib import error, request

    import pytest

    from youtube_dl.utils import encodeArgument, encodeFilename, get_filesystem_encoding

    def setup_module():
        """Create a temporary directory and a http server to serve the files
        used in tests
        """
        import json
        import os
        import socketserver
        import threading
        import urllib.request

        import http.server
        import http.server

        class RequestHandler(
                http.server.SimpleHTTPRequestHandler):

            def log_request(self, *args):
                pass

        _tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-24 11:57:44.557683
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(config=False)
    h.to_screen('Hallo')
    h.report_error('oh my god')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:57:48.832117
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.google.com/', headers={})
    assert fd.headers == {'Youtubedl-no-compression': 'True'}
    assert not fd.closed
    fd.close()
    assert fd.closed



# Generated at 2022-06-24 11:57:58.542305
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # TODO: download large files and resume
    # The purpose of this test is to find out, if the downloader
    # is able to download different file chunks with different block sizes,
    # not to test if it is able to download files from internet
    from .utils import encodeFilename
    from .HttpFD import sanitize_open
    from .extractor import get_suitable_downloader

    class DummyYtdl():
        def __init__(self, to_screen_fn, params, report_error_fn, report_warning_fn, report_retry_fn, report_file_already_downloaded_fn, report_destination_fn, report_unable_to_resume_fn, report_resuming_byte_fn):
            self.to_screen = to_screen_fn
            self.params = params
            self

# Generated at 2022-06-24 11:58:09.642059
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # pylint: disable=protected-access
    '''
    Test method real_download of class HttpFD.
    This test is part of functional test suite yt_download.py
    '''
    class Mock_YoutubeDL(object):
        '''
        Mock class youtube_dl.YoutubeDL
        '''
        def __init__(self):
            self.params = {
                'noresizebuffer': False,
                'test': True,
                'retries': 10,
                'buffersize': None,
            }

        def urlopen(self, req):
            '''
            Simulate urlopen() method of class youtube_dl.YoutubeDL
            '''

# Generated at 2022-06-24 11:58:10.322079
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass



# Generated at 2022-06-24 11:58:16.523095
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from io import BytesIO
    from http.server import BaseHTTPRequestHandler
    from socketserver import TCPServer
    from threading import Thread

    DOWNLOAD_FILE = b'\x01' * (2 * 1024 * 1024 + 1)

    class MockHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Length', str(len(DOWNLOAD_FILE)))
            self.end_headers()
            self.wfile.write(DOWNLOAD_FILE)

    url = 'http://127.0.0.1:%d/download' % (get_free_port(),)
    httpd = TCPServer(('', 0), MockHandler)
    httpd_thread = Thread(target=httpd.serve_forever)
    httpd

# Generated at 2022-06-24 11:58:23.939973
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .downloader import YoutubeDL
    test_dict = {'status': 'error',
                 'filename': 'file.tmp',
                 'tmpfilename': 'file.tmp.part',
                 'total_bytes': 100,
                 'downloaded_bytes': 0,
                 'elapsed': 0,
                 'total_frags': 1,
                 'frag_index': 0,
                 'frag_previous_len': 0,
                 'frag_count': 1,
                 'speed': 0,
                 'eta': None}

# Generated at 2022-06-24 11:58:25.555125
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Empty unit test
    pass



# Generated at 2022-06-24 11:58:26.136857
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass

# Generated at 2022-06-24 11:58:37.061777
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # initialize an HttpFD object
    class TestFD(HttpFD):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args: None
            self.to_stderr = lambda *args: None
            self.report_error = lambda msg: None
            self.report_retry = lambda *args: None
            self.report_resuming_byte = lambda *args: None
            self.report_destination = lambda *args: None
            self.report_unable_to_resume = lambda *args: None
            self.report_file_already_downloaded = lambda *args: None
            self._hook_progress = lambda *args: None
            self.urlopen = self.fake_urlopen
            self.best_block_size = lambda *args: 1


# Generated at 2022-06-24 11:58:41.093818
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    fd = HttpFD(BytesIO(b'foobar'), {'content-type': 'video/webm'})
    assert fd.read() == b'foobar'
    assert fd.get_headers() == {'content-type': 'video/webm'}



# Generated at 2022-06-24 11:58:49.182634
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    from youtube_dl.utils import sanitize_url

    # Open an empty file
    testf = BytesIO()
    fd = HttpFD(testf, testf, {'noprogress': True})
    assert fd.read() == b''

    # Try to open a remote file
    remote_testf = sanitize_url('http://ipv4.download.thinkbroadband.com/5MB.zip')
    fo = urllib.request.urlopen(remote_testf)
    fd = HttpFD(fo, remote_testf, {'noprogress': True})
    fd.read(10)
    stats = fd.get_stats()
    assert stats['downloaded_bytes'] == 10
    fd.readline()
    stats

# Generated at 2022-06-24 11:58:59.608510
# Unit test for constructor of class HttpFD
def test_HttpFD():
    d = HttpFD(
        {
            'url': 'http://a.b/c',
            'http_chunk_size': 10,
            'outtmpl': '%(id)s.%(ext)s',
        },
        {})
    assert d.ydl is not None
    assert d.params['noprogress'] is True
    assert d.params['http_chunk_size'] == 10
    assert d.params['outtmpl'] == '%(id)s.%(ext)s'

    d = HttpFD(
        {
            'url': 'http://a.b/c',
            'http_chunk_size': -10,
        },
        {})
    assert d.ydl is not None
    assert d.params['http_chunk_size'] == 0

# Generated at 2022-06-24 11:59:10.652434
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import os
    import random
    import re
    import threading
    import time
    import urllib.parse
    import unittest
    import warnings

    from typing import Optional

    from .utils import (
        encodeFilename,
    )

    try:
        import ssl
    except ImportError:
        ssl = None

    from .compat import (
        compat_http_server,
        compat_str,
    )

    from .utils import (
        HEADRequest,
        XAttrUnavailableError,
        encodeFilename,
        md5,
        sanitize_open,
        write_xattr,
    )

    from .extractor import gen_extractors

    # Some tests may require long time to complete if they are run on slow
    # internet connection, so they have been disabled by

# Generated at 2022-06-24 11:59:21.502017
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    import unittest
    import shutil
    from .extractor.common import InfoExtractor

    def test_download(self, filename, info_dict):
        tmp_dir = tempfile.mkdtemp(prefix='youtubedl-test-')
        self.to_screen('[debug] Running %r in %r' % (filename, tmp_dir))

        dest_filename = os.path.join(tmp_dir, 'dst')

# Generated at 2022-06-24 11:59:30.870912
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test with test run on a file of size 12 bytes
    data = ('a' * 4 + '\n',
            'a' * 4 + '\n',
            'a' * 2 + '\n',
            'a' * 2 + '\n')
    pb_hook = [lambda x: None, lambda x: None, lambda x: None, lambda x: None]
    def dummy_urlopen(request):
        if request.data:
            url = request.data
            request.data = request.headers['Range'].split('=')[-1]
        else:
            url = request.get_full_url()
        class DummySocket(object):
            def __init__(self, i):
                self.i = i

# Generated at 2022-06-24 11:59:39.493389
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading

    import testserver
    from testserver import HttpServerHandlerBase

    class HttpServerHandler(HttpServerHandlerBase):
        def do_GET(self):
            if self.path == '/test_redirect.html':
                self.send_response(302)
                self.send_header('Location', self.server.server_address[1])
                self.end_headers()
            elif self.path == '/test_404.html':
                self.send_response(404)
                self.end_headers()
            elif self.path == '/test_200.html':
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain')
                self.send_header('Content-Length', '1')
                self.end_headers()
                self.wfile

# Generated at 2022-06-24 11:59:49.869941
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def CheckFD(fd, res):
        assert fd.read() == res, 'test failed'
        return True

    u = '127.0.0.1:5454/bytes/'
    args = ParseArgs(['-o', '-', u + '100'])[0]

    fd = HttpFD(args, {})
    # small blocks
    fd.real_download(u + '100', args, {}, CheckFD, lambda n: n)
    fd.real_download(u + '100k', args, {}, CheckFD, lambda n: n)
    # large blocks
    fd.real_download(u + '100', args, {}, CheckFD, lambda n: n * 16)

# Generated at 2022-06-24 11:59:59.168855
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import threading
    from .http import FileDownloader
    from .utils import sanitize_open, sanitize_url

    def check_download(url, params):
        fd = HttpFD(FileDownloader({}))
        fd.add_header('Youtubedl-no-compression', 'True')
        filename = tempfile.mkstemp()[1]
        success = fd.real_download(url, filename, params)
        if success:
            fd.finished()
        else:
            fd.report_error('test failed')
        return success

    def check_fragment_download(url, params, data_len=None, chunk_size=None):
        fd = HttpFD(FileDownloader({}))

# Generated at 2022-06-24 12:00:00.896872
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass
    # TODO: implement

# Generated at 2022-06-24 12:00:10.016575
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test that the constructor selects the best downloader
    url = 'http://127.0.0.1/'
    paf = '127.0.0.1'
    ua = 'FooBar'
    headers = {
        'Accept-Charset': 'UTF-8,*;q=0.5',
        'Accept': 'text/html',
        'User-Agent': ua,
    }
    expected_headers = {
        'Accept-Charset': 'UTF-8,*;q=0.5',
        'Accept': 'text/html',
        'User-Agent': ua,
        'Range': 'bytes=0-',
    }

# Generated at 2022-06-24 12:00:17.933948
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL({'noprogress': True})
    # Pseudo url
    url = 'http://pseudo/'

    # Test real file download
    filename = 'LICENSE'
    real_url = 'file://' + os.path.abspath(filename)
    fd = HttpFD(ydl, real_url, {'http_headers': {'User-Agent': 'MyPocket'}}).open()
    data = fd.read()
    assert 'GNU GENERAL PUBLIC LICENSE' in data, 'Download of a local file failed!'
    assert 'MyPocket' in fd.headers['User-Agent'], 'User agent not set!'
    fd.close()

    # Test pseudo-file download
    length = 39274

# Generated at 2022-06-24 12:00:26.229485
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://g.co/dev/youtube-dl')
    assert fd.url == 'http://g.co/dev/youtube-dl'
    assert fd.endbyte is None
    assert fd.startbyte == 0
    assert fd.filesize is None
    assert not fd.closed
    assert fd.headers == {}

    fd = HttpFD('http://g.co/dev/youtube-dl', endbyte=300, startbyte=100)
    assert fd.url == 'http://g.co/dev/youtube-dl'
    assert fd.endbyte == 300
    assert fd.startbyte == 100
    assert fd.filesize is None
    assert not fd.closed
    assert fd.headers == {}


# Generated at 2022-06-24 12:00:37.685907
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 12:00:46.728008
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import unittest
    import sys
    import threading
    import zlib
    import re
    import random
    import os
    import shutil
    import time
    import socket
    import itertools
    import struct
    import subprocess
    import tempfile
    import errno
    import json
    import binascii
    import hmac
    import hashlib
    import http.server
    import socketserver
    from http.server import HTTPServer, BaseHTTPRequestHandler
    import urllib.parse
    import base64
    from collections import defaultdict
    from collections import OrderedDict
    import shutil
    from hashlib import md5
    from hashlib import sha256
    from random import randint
    import csv
    import re
    import operator
    import gzip
    import io
    import math

# Generated at 2022-06-24 12:00:53.532411
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Suppress print()
    real_print = print
    def print_dummy(*args, **kwargs):
        pass
    print = print_dummy

    class _TestYDL:
        def __init__(self):
            self.params = {}
            self.to_screen = print
            self.to_stderr = print
            self.report_warning = print

        def urlopen(self, req, data=None, timeout=None):
            real_urlopen_called[0] = True
            assert 'Range' in req.headers
            assert req.headers['Range'] == 'bytes=0-%d' % test_HttpFD._TEST_FILE_SIZE
            assert not data
            assert timeout is None

# Generated at 2022-06-24 12:01:06.634504
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DummyYDL(object):
        def __init__(self, params, info_dict):
            self.params = params
            self.info_dict = info_dict
        def urlopen(self, *args, **kwargs):
            return compat_urllib_request.urlopen(*args, **kwargs)

# Generated at 2022-06-24 12:01:11.902088
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('-- Testing constructor of class HttpFD --')
    filename = '-'
    mode = 'w'
    import sys
    fd = HttpFD(filename, mode, sys.stderr)
    assert fd.name == filename
    assert fd.mode == mode
    assert fd.fileobj == sys.stderr
    print('OK')


# Generated at 2022-06-24 12:01:23.839309
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    This is a unit test for method real_download of class HttpFD.
    Tests if method real_download can download a file from a given URL.
    This method uses mock_server.py to setup a mock server that serves files from directory test/files/.
    The method is tested on file test/files/firmware.bin by downloading it from the mock server.
    """
    import subprocess
    import re
    import sys
    import urllib.parse
    import http.server
    import socketserver
    import os
    import base64
    import tempfile
    import shutil
    import ssl
    import socket
    import struct

    ############################
    ####### SETUP MOCK #######
    ############################
    # Load mock_server.py and start a mock server.
    mockServerPath = os.path

# Generated at 2022-06-24 12:01:35.550735
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None

    params = {'nooverwrites': True, 'continuedl': False}

    # src is None
    with pytest.raises(TypeError):
        HttpFD(DummyYDL(params), None)

    # src is not None but it is not supported URL or file
    with pytest.raises(ValueError) as excinfo:
        HttpFD(DummyYDL(params), 'foobar')
    assert str(excinfo.value) == 'Invalid URL: foobar'

    # Test opening a file

# Generated at 2022-06-24 12:01:46.676500
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYDL(object):
        def urlopen(self, request):
            return FakeUrlopen(request)

    class FakeUrlopen(object):
        def __init__(self, request):
            self.headers = {}
            self.code = None
            self.len = None
            self.fp = io.BytesIO(b'foobarbaz')

        def info(self):
            info = compat_http_client.HTTPMessage(compat_StringIO())
            for k, v in self.headers.items():
                info.addheader(k, v)
            info.addheader('Content-length', str(self.len))
            info.addheader('Content-Type', 'video/webm')
            return info

        def getcode(self):
            if self.code is None:
                return 200
           

# Generated at 2022-06-24 12:01:48.953743
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        HttpFD(None, None, None, None, None)
    except TypeError:
        pass
    else:
        raise AssertionError('HttpFD constructor accepts less than 3 arguments')

# Generated at 2022-06-24 12:01:59.399613
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Regular test
    fd = HttpFD('http://www.google.com', {'noprogress': True})
    fd.read(100)
    fd.close()
    # Test a download that isn't a multiple of BUFFER_SIZE
    fd = HttpFD('http://www.google.com', {'noprogress': True})
    fd.read(1001)
    fd.close()
    # Test a download of a non-existent file
    try:
        HttpFD('http://www.goggle.com', {'noprogress': True}).close()
    except (compat_urllib_error.URLError, compat_http_client.HTTPException):
        pass
    else:
        raise AssertionError('Download of invalid URL did not fail!')


# Generated at 2022-06-24 12:02:11.438368
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import pytest
    from youtube_dl.compat import parse_http_header_quotes
    HttpFD = HttpFD(pytest.ensure_legacy_YoutubeDL({}))
    HttpFD.report_retry = lambda a1, a2, a3: None
    HttpFD.report_finish = lambda *x: None
    HttpFD.report_destination = lambda *x: None
    HttpFD.to_stderr = lambda *x: None
    HttpFD.to_screen = lambda *x: None
    HttpFD.report_content_too_short = lambda *x: None
    HttpFD.report_unable_to_resume = lambda *x: None
    HttpFD.report_file_already_downloaded = lambda *x: None
    HttpFD

# Generated at 2022-06-24 12:02:20.163025
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test whether the constructor of class HttpFD works
    # This creates a small dummy file on the filesystem
    import tempfile
    dummyfile = tempfile.NamedTemporaryFile(delete=False)
    dummyfile.write('testtesttest')
    dummyfile.close()
    h = HttpFD(dummyfile.name, None)
    assert isinstance(h, HttpFD)
    try:
        assert h.downloaded == 10
        assert h.filesize == 10
        assert h.name == dummyfile.name
        assert h.pp.buffer_size
        assert h.progressive == True
        assert h.start_time == 0
    finally:
        os.remove(dummyfile.name)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 12:02:33.098181
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    filename, info = test_download()
    assert os.path.isfile(filename)
    assert info['status'] == 'finished'
    assert info['downloaded_bytes'] == info['total_bytes'] == os.path.getsize(filename)
    assert info['filename'] == filename
    assert os.path.getsize(filename)

    filename2, info2 = test_download(
        {'continuedl': True, 'noprogress': True, 'retries': 2})
    assert os.path.isfile(filename2)
    assert info2['status'] == 'finished'
    assert info2['downloaded_bytes'] == info2['total_bytes'] == os.path.getsize(filename2)
    assert info2['filename'] == filename2
    assert os.path.getsize(filename2)


# Generated at 2022-06-24 12:02:44.877578
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Construction
    # See http://en.wikipedia.org/wiki/POST_(HTTP)#Use_for_submitting_web_forms
    # for explanation of the example
    post_content = [
        ('search', 'test query'),
        ('num', '100'),
        # The tuple ('testname', 'test value') will be encoded as
        # 'testname=test+value'
        ('testname', 'test value'),
    ]
    fd = HttpFD(u'test.com', post_content, {'User-Agent': 'Test'})
    vals = fd.read().split('&')
    vals.sort()
    assert vals == ['num=100', 'search=test+query', 'testname=test+value']

# Generated at 2022-06-24 12:02:52.735303
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from test import test_utils

    ydl = YoutubeDL({'verbose': False})
    ydl.add_progress_hook(lambda x: None)

    test_utils.print_title('Testing HttpFD.real_download')

    # -- Retry
    # Succeed on third attempt
    test_utils.print_info('Testing retries')
    def get_retry_content(tries):
        if tries == 3:
            return b'abc'
        else:
            return None
    hf = HttpFD(ydl, 'http://localhost:8080/retry', test_url=True, params={'retries': 4})
    assert hf.real_download({'url': 'http://localhost:8080/retry'}, lambda d: d, get_retry_content)

    # -- Test content