

# Generated at 2022-06-24 11:52:55.615755
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # testcase: download 1,25 MiB of random data and check if everything is OK
    import tempfile
    import random

    def rnd_chr():
        return chr(random.randint(0, 255))

    data = ''.join(rnd_chr() for _ in xrange(0, int(1.25 * 1024 * 1024)))
    urlh = compat_urllib_request.urlopen('http://127.0.0.1:%d/%s' % (server_port, urllib.quote_plus(data)))

    with tempfile.NamedTemporaryFile(delete=False) as tmpf:
        tmpf_name = tmpf.name
    hd = HttpFD(ydl=DummyYDL(), params={})

# Generated at 2022-06-24 11:53:01.116251
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Checking the '-U' option
    test_instance = HttpFD()
    stream = io.BytesIO()

    def _hook(status):
        stream.truncate(0)
        stream.seek(0)
        for k in status:
            stream.write((k + ':' + status[k] + '\n').encode('utf-8'))
        stream.flush()

    test_instance.params = {
        'test': True,
        'format': 'best',
        'outtmpl': '%(title)s.f%(format_id)s.%(ext)s',
        'verbose': True,
        'progress_hooks': [_hook],
    }


# Generated at 2022-06-24 11:53:09.855258
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # No exceptions should be raised when testing constructor of class HttpFD
    fd = HttpFD('http://www.youtube.com', params={'noprogress': True})

    # Negative test case
    try:
        fd = HttpFD('http://127.0.0.1', params={'noprogress': True})
    except MaxDownloadsReached:
        print('MaxDownloadsReached exception caught')

    # Negative test case
    try:
        fd = HttpFD('http://127.0.0.1/', params={'noprogress': True})
    except UnavailableVideoError:
        print('UnavailableVideoError exception caught')

    # Negative test case

# Generated at 2022-06-24 11:53:20.306209
# Unit test for constructor of class HttpFD
def test_HttpFD():

    def _test_downloader(**kwargs):
        class MockYDL(object):
            def __init__(self):
                self.params = {
                    'nooverwrites': False,
                    'continuedl': False,
                    'ratelimit': None,
                    'retries': 10,
                    'buffersize': 1024,
                    'noresizebuffer': False,
                    'test': False,
                }
                self.params.update(kwargs)
            def toScreen(self, message):
                print(message)
            def trouble(self, message, tb):
                print(message, tb)
            def report_warning(self, message):
                print('WARNING: ' + message)
            def report_error(self, message, tb=None):
                print('ERROR: ' + message)
           

# Generated at 2022-06-24 11:53:24.372287
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Tests for HttpFD"""
    h = HttpFD(sanitize_open('-'), {})
    for i in range(10):
        h.write(bytes(i))
    h.close()

# vim:tabstop=4 shiftwidth=4 expandtab


# Generated at 2022-06-24 11:53:35.151956
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Should skip the real download and return True
    # when it detects that the file has already been fully downloaded
    fd = HttpFD(None, {'continuedl': True})
    class DummyData(object):
        def __init__(self, headers):
            self.headers = compat_urllib_request.HTTPMessage(compat_StringIO.StringIO(headers))
    data = DummyData('Content-Length: 12800768\r\nContent-Range: bytes 0-12800767/12800768\r\n')
    class DummyReport(object):
        def __init__(self):
            self.resume_len = 12800768
        def report_file_already_downloaded(self, filename):
            self.report_file_already_downloaded_called = True

# Generated at 2022-06-24 11:53:44.838195
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    filename = 'test.mp4'
    url = 'http://testurl.com/'
    test_dict = {
        'test_filename': filename,
        'test_url': url,
        'test_data_len': 100,
        'test_tmpfilename': filename,
    }
    class TestHttpFD(HttpFD):
        def __init__(self, ydl):
            self.ydl = ydl
            self.ctx = YoutubeDLDownloader(self.ydl)
            self.ctx.data_len = test_dict.get('test_data_len', None)
            self.ctx.filename = test_dict['test_filename']
            self.ctx.tmpfilename = test_dict.get('test_tmpfilename', filename)

# Generated at 2022-06-24 11:53:55.710629
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    (fd1, tmpfile1) = tempfile.mkstemp()
    os.close(fd1)
    (fd2, tmpfile2) = tempfile.mkstemp()
    os.close(fd2)
    # make sure tmpfile1 doesn't exist
    try:
        os.remove(tmpfile1)
    except:
        pass
    # make tmpfile2 exist
    open(tmpfile2, 'w').write('a')

    fd = HttpFD('foo', 'wb', tmpfile1, tmpfile2)

    assert(fd.name == tmpfile2)

    fd.close()

    # tmpfile1 should not exist
    assert(not os.path.exists(tmpfile1))
    # tmpfile2 should exist

# Generated at 2022-06-24 11:54:07.484089
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Unit test for constructor of class HttpFD"""
    # Creating HttpFD with no parameters
    myFD = HttpFD()
    assert myFD.url == None, "Constructor of class HttpFD failed: variable url = %s (should be None)" % myFD.url
    assert myFD.ydl == None, "Constructor of class HttpFD failed: variable ydl = %s (should be None)" % myFD.ydl
    assert myFD.params == {}, 'Constructor of class HttpFD failed: variable params = %s (should be {})' % myFD.params

    # Creating HttpFD with url
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    myFD1 = HttpFD(url)

# Generated at 2022-06-24 11:54:19.270645
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    def progress_hook(status):
        print(status)

    url = 'http://www.google.com/index.html'
    max_filesize = 1000
    try:
        hd = HttpFD(url, None, {'progress_hooks': [progress_hook],
                    'max_filesize': max_filesize})
    except (compat_urllib_error.URLError, socket.error) as err:
        print('Error: unable to download video data: %s' % str(err))
        sys.exit(1)
    except (compat_urllib_error.HTTPError) as err:
        print('Error: server returned HTTP %s ERROR' % str(err.code))
        print(err.read())
        sys.exit(1)

# Generated at 2022-06-24 11:54:32.309847
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test arguments
    url = 'http://speedtest.ftp.otenet.gr/files/test100k.db.gz'
    filename = None
    info_dict = {}

    # Set params (extracted from common code)
    params = {
        'nooverwrites': False,
        'continuedl': False,
        'noprogress': False,
        'ratelimit': None,
        'retries': 10,
        'buffersize': '1024',
        'noresizebuffer': False,
        'test': True,
        'min_filesize': 0,
        'max_filesize': None,
        'prefer_free_formats': False,
        'xattr_set_filesize': False,
    }
    ydl = YoutubeDL(params)

    # Create the

# Generated at 2022-06-24 11:54:43.558891
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print(HttpFD({'noprogress': True}, 'http://localhost/file.mp4', {}))
    print(HttpFD({'noprogress': True}, 'bttps://localhost/file.mp4', {}))
    print(HttpFD({'noprogress': True}, 'https://localhost/file.mp4', {}))
    print(HttpFD({'noprogress': True}, 'https://localhost:123/file.mp4', {}))
    print(HttpFD({'noprogress': True}, 'ftp://localhost/file.mp4', {}))
    print(HttpFD({'noprogress': True}, 'ftp://localhost:123/file.mp4', {}))
    print(HttpFD({'noprogress': True}, 'smb://localhost/file.mp4', {}))
   

# Generated at 2022-06-24 11:54:52.186220
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hfd = HttpFD(None, 'http://www.example.com/video.mp4', {
        'http_chunk_size': 1,
        'test': True,
    })
    assert hfd._calc_chunksize(1, 0) == 1
    assert hfd._calc_chunksize(10, 1) == 10
    assert hfd._calc_chunksize(10, 2) == 5
    assert hfd._calc_chunksize(10, 6) == 2
    assert hfd._calc_chunksize(10, 10) == 1
    assert hfd._calc_chunksize(10, 11) == 1
    assert hfd._calc_chunksize(10, 20) == 1
    assert hfd._calc_chunksize(10, 0) == 10

# Generated at 2022-06-24 11:55:02.029864
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class MockYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kwargs: None

        def download(self, *args, **kwargs):
            self.download_called_with = (args, kwargs)

        def post_process(self, *args, **kwargs):
            self.post_process_called_with = (args, kwargs)


# Generated at 2022-06-24 11:55:07.667109
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import tempfile
    from .compat import move_safe
    #
    # Create temp file
    (testin, testinnm) = tempfile.mkstemp(prefix='in', suffix='.test')
    testoutnm = testinnm + '.testout'

# Generated at 2022-06-24 11:55:20.211691
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Unit test for method real_download of class HttpFD
    It tests that:
    - method real_download correctly downloads a file
    - method real_download correctly resumes a download
    - method real_download correctly skips a download
    - method real_download correctly detects an unfinished download
    - method real_download correctly reports an error trying to download a missing file
    """
    from .compat import urlopen, Request
    from .utils import TempFileName
    from .utils import encodeFilename, decodeFilename, write_bytes
    from .downloader import max_retries

    # Test 1
    # Test 2
    # Test 3
    # Test 4
    # Test 5
    # Test 6

    # Test 1: a file is correctly downloaded (first time and resuming)
    # Test 2: a file is correctly skipped
    # Test 3:

# Generated at 2022-06-24 11:55:32.737782
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # HttpFD without any parameters
    fd = HttpFD(None, None, None)
    assert (fd.ydl is None) and (fd.url is None)
    assert fd.handle is None
    assert (fd.tmpfilename is None) and (fd.title is None)
    assert fd.params is None
    assert not fd.started
    assert fd.name == 'http'
    # HttpFD with all parameters
    fd = HttpFD(1, 2, 3)
    assert fd.ydl == 1 and fd.url == 2 and fd.params == 3
    assert fd.handle is None
    assert fd.tmpfilename is None and fd.title is None
    assert not fd.started
    assert fd.name == 'http'

# Simple test for download function

# Generated at 2022-06-24 11:55:45.997391
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from ytdl.utils import HeadRequest
    from ytdl.utils import sanitized_Request
    # Test illegal parameters

# Generated at 2022-06-24 11:55:58.700094
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import unittest
    import tempfile
    from youtube_dl.utils import encodeFilename

    class Test(unittest.TestCase):
        # only run this test if curl is available
        @unittest.skipUnless(compat_os_name == 'nt' or 'HTTP_PROXY' in os.environ, 'for windows and non-anonymizing proxies only')
        def _run_test(self, params):
            httpdl = HttpFD()
            httpdl.params = params
            url = 'http://ipv4.download.thinkbroadband.com/1GB.zip'
            filename = '-' if params.get('continuedl', True) else tempfile.mktemp()

# Generated at 2022-06-24 11:56:03.141493
# Unit test for constructor of class HttpFD
def test_HttpFD():
    resume_len = 0
    chunk_size = 0
    params = {
        'continuedl': True,
    }
    info = {
        'url': 'http://www.example.org/video.mp4',
    }
    h = HttpFD(resume_len, chunk_size, params, info, '-')
    return h


# Generated at 2022-06-24 11:56:14.843766
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a test url
    url = 'http://127.0.0.1/dummy.bin'

    # Create a test file
    dummy_content = b'Hello, world! This is a test file'
    dummy_file_obj = io.BytesIO(dummy_content)

    # Create a dummy HTTP server
    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Length', str(len(dummy_content)))
            self.end_headers()
            self.wfile.write(dummy_content)

    # Start the server
    server_address = ('127.0.0.1', random.randint(10000, 65535))

# Generated at 2022-06-24 11:56:26.337333
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Specify url, filename and result to check if real_download is working correctly"""
    test_cases = [
        ('http://quotes.toscrape.com/random', '/tmp/quote.txt', True),
        ('http://quotes.toscrape.com/random', '/tmp/quote.html', False),
    ]
    passed = True
    ydl = YoutubeDL()
    ydl.params['noprogress'] = True

    for urll, filename, result in test_cases:
        with tempfile.NamedTemporaryFile(mode='w+t', delete=False) as f:
            # tempfile does not permit delete=False with 'b' mode
            pass
        os.unlink(f.name)
        fd = HttpFD(ydl, f.name, urll, {})
        f

# Generated at 2022-06-24 11:56:37.993608
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import urllib.error
    import urllib.parse
    import urllib.request
    import socket
    import http.client
    import tempfile
    import shutil
    import os.path
    import ssl
    from unittest.mock import patch
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import (
        compat_urllib_error,
        compat_urllib_request,
        compat_urllib_response,
        compat_urllib_parse,
    )
    from youtube_dl.utils import sanitize_open

# Generated at 2022-06-24 11:56:49.760239
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """http_test.test_HttpFD_real_download"""
    import shutil
    import tempfile
    import threading
    import time
    from . import FakeYDL
    from . import http_server

    filename = 'test.mp4'
    tmp_file = os.path.join(tempfile.gettempdir(), '%s.part' % filename)
    shutil.copy(path_to_data_file('test.mp4'), tmp_file)
    assert os.path.exists(tmp_file)

# Generated at 2022-06-24 11:57:02.920043
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class ContentTooShortError(Exception): pass
    class RetryDownload(Exception): pass
    class NextFragment(Exception): pass
    class SucceedDownload(Exception): pass
    def urlopen(*args, **kwargs):
        class FD:
            def __init__(self, blocks, headers=None):
                self.headers = headers or {}
                self.blocks = blocks
                self.i = 0
                self.len = len(self.blocks)
            def read(self, size):
                if self.i >= self.len:
                    return b''
                self.i += 1
                return self.blocks[self.i - 1]
            def info(self):
                return self.headers
        return FD(test_blocks, test_headers)

# Generated at 2022-06-24 11:57:15.193641
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import time
    from .pytest_utils import FakeYDL
    ydl = FakeYDL()
    ydl.params['sleep_interval'] = 0
    h = HttpFD(ydl, {'url': 'http://127.0.0.1:9000/files/3MiB.file'})
    # Test with min_filesize and max_filesize set
    h.params['min_filesize'] = 2000000
    h.params['max_filesize'] = 3500000
    assert h.real_download('http://127.0.0.1:9000/files/3MiB.file', '3MiB.file', {}) is False
    h.params['min_filesize'] = 1000000
    h.params['max_filesize'] = 4000000

# Generated at 2022-06-24 11:57:16.746231
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Constructor test
    h = HttpFD(sanitize_open)
    assert h.ydl is not None


# Generated at 2022-06-24 11:57:28.342235
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert sys.version_info[0] < 3  # python2.6-compatibility
    url = 'http://a.b/c'
    head = {'content-type': 'image/gif'}

# Generated at 2022-06-24 11:57:40.202918
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    #return
    # Open files
    video_url = input(u"videourl:")
    dest_path = "clip.mp4"
    x_forwarded_for_ip = input(u"ip:")
    fd_1 = HttpFD(video_url, dest_path, {}, {'x_forwarded_for': x_forwarded_for_ip})
    #fd_2 = HttpFD(video_url, dest_path, {}, {})
    #fd_3 = HttpFD(video_url, dest_path, {}, {'x_forwarded_for': '1.2.3.4'})
    #fd_4 = HttpFD(video_url, None, {}, {})
    #fd_5 = HttpFD(video_url, dest_path, {'contin

# Generated at 2022-06-24 11:57:51.689969
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # See [embed]IE_is_crap in YoutubeDL.py
    assert HttpFD('http://127.0.0.1').real_url == 'http://127.0.0.1/'
    assert HttpFD('http://127.0.0.1/').real_url == 'http://127.0.0.1/'
    assert HttpFD('http://127.0.0.1/abc').real_url == 'http://127.0.0.1/abc'
    assert HttpFD('http://127.0.0.1/abc.def').real_url == 'http://127.0.0.1/abc.def'

# Generated at 2022-06-24 11:57:59.641795
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeOpener(object):
        def __init__(self, fileobj, headers=None):
            self.fileobj = fileobj
            self.headers = headers
        def open(self, *args, **kwargs):
            return self

    # FD initialized with seekable fileobj
    fd = HttpFD(
        FakeOpener(io.BytesIO(b'test')),
        {
            'url': 'http://example.com',
            'filesize': 4,
            'filename': 'test',
            'http_headers': {},
        }
    )
    assert fd.url == 'http://example.com'
    assert fd.filesize == 4
    assert fd.filename == 'test'
    assert fd.tell() == 0

# Generated at 2022-06-24 11:58:05.426920
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test method real_download of class HttpFD"""
    #self.report_error(self.to_screen(u'\r[download] %s of %s bytes at avg. rate of %s\x1b[K' % (self.format_bytes(byte_counter), self.format_bytes(data_len), self.format_speed(speed))))
    #self.to_screen(u'\r[download] %s of %s at %s ETA %s\x1b[K' % (self.format_bytes(byte_counter), self.format_bytes(data_len), self.format_speed(speed), self.format_seconds(eta)))
    #self.to_screen(u'\r[download] %s of %s bytes at %s ETA %s\x1b[K' % (self.format

# Generated at 2022-06-24 11:58:16.071490
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for the constructor of the HttpFD class. It doesn't really
    # do any downloading, but it does make sure that it does some
    # proper parsing of the HTTP header
    url = 'http://www.google.com'
    fd = HttpFD(url, None, None)
    (version, code, message) = fd.get_header()
    assert re.match(r'HTTP/1\.[01] \d{3} .+', '%s %s %s' % (version, code, message))
    (version, code, message) = fd.get_header()
    assert (version, code, message) == (None, None, None)

    # Now try a different format of the server response
    url = 'http://www.youtube.com'

# Generated at 2022-06-24 11:58:25.457702
# Unit test for constructor of class HttpFD
def test_HttpFD():
    t = HttpFD(
        'http://127.0.0.1:8080/missing',
        {'noprogress': True},
        None,
        '-'
    )
    assert not t.test()
    t = HttpFD(
        'http://127.0.0.1:8080/test' + str(time.time()),
        {'noprogress': True},
        None,
        '-'
    )
    assert t.test()
    t = HttpFD(
        'http://127.0.0.1:8080/redirect1',
        {'noprogress': True},
        None,
        '-'
    )
    assert t.test()

# Generated at 2022-06-24 11:58:36.632097
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 11:58:43.033588
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import doctest
    import test_utils as utils

    def download(*args):
        # Reuse real_download test
        return utils.real_download(*args)

    optionflags = doctest.NORMALIZE_WHITESPACE | \
                  doctest.ELLIPSIS

    tests = (
        'httpfd_real_download',
    )

    for test in tests:
        doctest.run_docstring_examples(getattr(HttpFD, test), globals(), optionflags=optionflags)


# Generated at 2022-06-24 11:58:50.635435
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from . import FileDownloader
    # Needs to be initialized for URL openers
    ydl = FileDownloader({})

    # Prepare input and output file names
    in_tmp, in_filename = tempfile.mkstemp(prefix='youtubedl-test-in-')
    os.close(in_tmp)
    out_tmp, out_filename = tempfile.mkstemp(prefix='youtubedl-test-out-')
    os.close(out_tmp)

    # test #1: Download a file via HTTP
    test_url = 'http://upload.wikimedia.org/wikipedia/commons/6/63/Wikipedia-logo.png'

    fd = HttpFD(ydl, test_url, out_filename, {
        'continuedl': True,
        'quiet': True,
    })

# Generated at 2022-06-24 11:59:00.783374
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import youtube_dl.utils
    ctx = youtube_dl.FileDownloadContext(None, '-', {}, None)
    data = compat_urllib_request.URLopener().open('http://www.google.com/')
    ctx.data = data
    ctx.tmpfilename = '-'
    ydl = YoutubeDL()
    ydl.report_warning = lambda *args, **kwargs: None
    ydl.report_error = lambda *args, **kwargs: None
    ydl._hook_progress({
        'status': 'downloading',
        })
    ydl.to_stderr = lambda *args, **kwargs: None
    ydl._TEST_FILE_SIZE = 1024
    ydl.params = {}
    ydl.slow_down = lambda *args, **kwargs: None


# Generated at 2022-06-24 11:59:12.254164
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'some-file')
    tmp_sub_file = os.path.join(tmp_dir, 'subdir', 'some-sub-file')

# Generated at 2022-06-24 11:59:22.935813
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params = {'noprogress': True, 'quiet': True, 'skip_download': True}
    # open local test file
    url = os.path.join(sys.path[0], 'test', 'test.mp4')
    def test(params, url):
        h = HttpFD(params, url, {})
        assert h.get_url() == url
        assert h.get_content_type() == 'video/mp4'
        assert h.get_size() == 243901
        assert h.get_filename() == 'test.mp4'
        assert 0 <= h.read(10) < h.read()
    test(params, url)
    test(params, compat_urlparse.urlparse(url))

# Generated at 2022-06-24 11:59:35.991176
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    from .compat import compat_http_server
    from .utils import encodeFilename

    class ServerHandler(compat_http_server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Disposition', 'attachment; filename="%s"' % self.path[1:])
            self.end_headers()
            f = open(encodeFilename(sys.argv[1]), 'rb')
            self.wfile.write(f.read())
            f.close()

    httpd = compat_http_server.HTTPServer(('127.0.0.1', 0), ServerHandler)
    httpd_port = http

# Generated at 2022-06-24 11:59:47.106628
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # normal usage
    fd = HttpFD('http://www.youtube.com', {})
    assert fd.url == 'http://www.youtube.com'
    assert fd.headers == {}
    assert fd.filename == '-'

    # no URL
    pytest.raises(TypeError, HttpFD)

    # non-ASCII URL
    pytest.raises(AssertionError, HttpFD, b'http://example.com/foo\xe3', {})

    # check filename parameter
    fd = HttpFD('http://example.com/foo.bar', {}, 'foo.bar')
    assert fd.url == 'http://example.com/foo.bar'
    assert fd.filename == 'foo.bar'

# Generated at 2022-06-24 11:59:55.481440
# Unit test for constructor of class HttpFD
def test_HttpFD():
    filename = tempfile.mktemp(prefix='youtube-dl-http-test-')

# Generated at 2022-06-24 12:00:07.257330
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import socket
    import sys
    from .compat import compat_http_server
    from .compat import blank_page
    from .compat import test_socket
    from .compat import silence_socket_errors
    from http.server import BaseHTTPRequestHandler
    from http.server import HTTPServer
    from tempfile import mkstemp

    # Mock YDL class
    class YDL:
        def __init__(self):
            self.params = {'noprogress': True}
            self.server = None
            self.http_handler = None
            self.fd = None
            self.urlretrieve_hook = None
            self.info_dict = {}

        def urlretrieve(self, url, fd, urlretrieve_hook):
            self.urlretrieve_hook = urlretrieve_hook

# Generated at 2022-06-24 12:00:15.926064
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def urlopen(request):
        return request.url

    class YTDL(object):
        def __init__(self, params, ydl=None):
            self.params = params
            self.ydl = ydl if ydl is not None else self

        def urlopen(self, *args, **kwargs):
            return urlopen(*args, **kwargs)

        def to_screen(self, *args, **kwargs):
            pass

        def to_stderr(self, *args, **kwargs):
            pass

        def trouble(self, *args, **kwargs):
            pass

        def report_warning(self, *args, **kwargs):
            pass

    timestamp = time.time()

# Generated at 2022-06-24 12:00:24.733625
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print(('%s: running test_HttpFD_real_download()' % __file__))
    import io
    import os
    import tempfile
    from .common import InfoExtractor
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    test_ie = YoutubeIE(InfoExtractor())
    test_ie.params['noplaylist'] = True
    # We don't want to actually post a rating while running the test
    def _fake_rate_video(self, video_id, rating):
        assert rating in ('like', 'dislike', 'none'), rating
        return True
    test_ie._rate_video = _fake_rate_video.__get__(test_ie)
    # We also don't want to sleep for a second nor call time.time()
    old_sleep

# Generated at 2022-06-24 12:00:33.431052
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = Jake_YDL(params={'noprogress': True})
    ydl.add_default_info_extractors()
    url = 'http://www.youtube.com/get_video_info?&video_id=BaW_jenozKc&el=detailpage&ps=default&eurl=&gl=US&hl=en'
    fd = HttpFD(ydl, url, {})
    assert fd.url == url
    assert fd.ydl is ydl
    assert fd.download_retry == 5
    assert fd.download_retry_max == 10
    assert fd.download_retry_sleep == 1.0
    assert fd.download_rate_limit == 0
    assert fd.download_rate_limit_min == 0.0
    assert f

# Generated at 2022-06-24 12:00:44.370196
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = FakeYDL()
    ydl.params['test'] = True
    ydl.params['quiet'] = True
    fd = HttpFD(ydl, 'http://localhost/', {'http_chunk_size': 5}, 'name', {'opt': 'val'})
    ctx = fd._ctx
    assert ctx['block_size'] == 5
    assert ctx['chunk_size'] == ctx['block_size']
    assert ctx['data_len'] == 10

    # Test with Content-Length: 0
    fd = HttpFD(ydl, 'http://localhost/', {'http_chunk_size': 5}, 'name', {'opt': 'val', 'http_headers': {'Range': 'bytes=0-10'}})
    ctx = fd._ctx


# Generated at 2022-06-24 12:00:51.094669
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http = HttpFD(params={'test': True}, ydl=FakeYDL())
    info = {'http_headers': {'content-type': 'video/webm'}}
    assert http.real_download(
        'http://localhost/test.webm',
        info,
        {'tmpfilename': '-', 'continuedl': False, 'ratelimit': None},
        {})


# Unit tests for method best_block_size of class HttpFD

# Generated at 2022-06-24 12:01:04.947745
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 12:01:14.837306
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class Counter(object):

        def __init__(self, limit):
            self.count = 0
            self.limit = limit

        def __call__(self):
            if self.count >= self.limit:
                raise IOError('.')
            else:
                self.count += 1
                return 'Z'

    from io import BytesIO as StringIO
    fd = HttpFD(
        Counter(1),
        {'url': 'http://example.com/video.mp4', 'test': True},
        {'outtmpl': u'%(id)s%(ext)s'})
    assert fd.real_download(1)
    assert fd.tmpfilename == u'-'
    assert fd.filename == u'video.mp4'
    assert fd.size == 1

    fd

# Generated at 2022-06-24 12:01:18.374085
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test the constructor of the class HttpFD
    fd = HttpFD(encodeFilename('-'), {'noprogress': True})
    fd = HttpFD(encodeFilename('-'), {'logger': True})


# Generated at 2022-06-24 12:01:23.374683
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(
        sanitized_Request('http://example.com/'),
        downloader=None,
        params=None)
    assert not fd.close
    assert fd.closed
    assert fd.fileno() == -1
    assert fd.mode == 'rb'
    assert fd.name == 'http://example.com/'
    assert fd.peek(1000) == ''
    assert fd.read() == ''
    assert fd.read(1000) == ''
    assert fd.readline() == ''
    assert fd.readline(1000) == ''
    assert list(fd.readlines()) == []
    assert list(fd.readlines(1000)) == []
    assert fd.readable()
    assert not fd.seekable()

# Generated at 2022-06-24 12:01:35.174992
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing HttpFD ...')
    dl = FakeYDL()
    dl.params['nooverwrites'] = False
    dl.params['continuedl'] = True
    dl.params['nocheckcertificate'] = True
    dl.add_info_extractor(SimpleTestIE(dl))
    dl.params['test'] = True
    set_work_folder(gettempdir())
    output_file = 'DownloadTest.test_download-test'
    if sys.version_info > (3, 0):
        output_file = output_file.encode('utf-8')
    dl.params['outtmpl'] = output_file
    url = 'http://127.0.0.1:8080/test.mp4'

# Generated at 2022-06-24 12:01:38.840591
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, {'test_option': True})
    assert fd.ydl


# Generated at 2022-06-24 12:01:52.686095
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading
    import socket
    import re
    import tempfile
    import os.path
    try:
        import OpenSSL.SSL
    except ImportError:
        OpenSSL = None

    server = None
    client_socket = None
    CA_CERT_FILE = os.path.join(os.path.dirname(__file__), 'fake_ca_cert.pem')

    def _create_ssl_context():
        ssl_ctx = OpenSSL.SSL.Context(OpenSSL.SSL.SSLv23_METHOD)
        ssl_ctx.use_privatekey_file(os.path.join(os.path.dirname(__file__), 'fake_ca_key.pem'))
        ssl_ctx.use_certificate_file(CA_CERT_FILE)
        return ssl_ctx

# Generated at 2022-06-24 12:02:01.777446
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import test_http

    # pylint: disable=E0611
    from youtube_dl.downloader.http import my_os_name, my_system

    if 'posix' not in my_system and 'nt' not in my_system:  # Linux or Windows
        from nose.plugins.skip import SkipTest

        raise SkipTest('Test for real_download is Linux or Windows only')

    if 'nt' in my_system:  # Windows
        # Python for Windows (pywin32) has no support for xattr
        from nose.plugins.skip import SkipTest

        raise SkipTest('Test for real_download is Linux only')

    if my_os_name == 'mac':
        # OS X doesn't support xattr by default
        from nose.plugins.skip import SkipTest


# Generated at 2022-06-24 12:02:11.353948
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Just construct the class and try to download a couple of
       files; see testHttpFd() or testHttpFdBase() above."""
    h = HttpFD()
    h.download('http://localhost/250Kb.bin', {'quiet': True})
    h.download('http://localhost/1.bin', {'quiet': True})
    h.download('http://localhost/500Kb.bin', {'quiet': True})
    h.download('http://localhost/10Mb.bin', {'quiet': True})
    h.download('http://localhost/100Mb.bin', {'quiet': True})


# Generated at 2022-06-24 12:02:23.088925
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading
    import socketserver
    import time
    import http.server

    # Small files:
    # - no range request / shorter than a block
    # - full range
    # - range request / shorter than a block
    # - range request / larger than a block
    # - range request / larger than a block / test _TEST_FILE_SIZE
    # - range request / larger than a block / test resuming
    # - range request / larger than a block / test resuming / test _TEST_FILE_SIZE

    # Very large files:
    # - no range request
    # - range request / test resuming

    test_HttpFD_real_download__small_data = ('abcd0011223344556677889900aabbccddeeff' * 1000).encode('utf-8')


# Generated at 2022-06-24 12:02:30.943184
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    fd = HttpFD(BytesIO(b'abc'), 'http://example.com/')
    assert fd.read() == b'abc'
    assert fd.readline() == b'abc'
    fd.release()

if __name__ == '__main__':
    test_HttpFD()


# vim: ts=4 sw=4 sts=4 expandtab

# Generated at 2022-06-24 12:02:36.625095
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Test case for method real_download() of the HttpFD class.
    """

    # Setup
    filename_prefix = 'test_real_download'
    filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), '%s.flv' % filename_prefix)
    filename_gz = filename + '.gz'
    if not os.path.exists(filename):
        # Download test file for unit test
        import shutil
        from .extractor import YoutubeIE
        youtube_ie = YoutubeIE(YoutubeDL({'nooverwrites': 'True', 'outtmpl': filename_prefix + '.%(ext)s'}))
        test_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-24 12:02:49.489562
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import time
    if sys.version_info < (2, 6):
        return
    # Test for using custom urlopen
    def urlopener_hook(url_data):
        if url_data.get('url') == 'http://127.0.0.1:8080/timeout':
            class FakeSocket:
                def makefile(self, mode, bufsize):
                    time.sleep(3)
                    return io.BytesIO(b'Hello')
            csock = FakeSocket()
            return csock, 'http://127.0.0.1:8080/timeout'
        return compat_urllib_request.urlopen(url_data.get('url'))

    def retries(n, _1, _2):
        return n < 3
