

# Generated at 2022-06-24 11:52:45.856439
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import doctest, downloader
    return doctest.run_docstring_examples(downloader.HttpFD.real_download, globals())

# End of Unit test for method real_download of class HttpFD




# Generated at 2022-06-24 11:52:47.363247
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return HttpFD(ydl=True, params={})


# Generated at 2022-06-24 11:52:48.108505
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass



# Generated at 2022-06-24 11:52:54.028838
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Tests are only available if pycrytodome is installed
    import Cryptodome
    import hashlib
    # Create a dummy class, imitating DownloadContext
    class DummyClass(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)
    # Create the httpfd instance
    httpfd = HttpFD(DummyClass(params={}), DummyClass(to_screen=lambda *args: None))
    # Get the urlopen function from youtube_dl.utils
    from youtube_dl import utils
    urlopen = utils.urlopen
    # Patch urlopen with our dummy function

# Generated at 2022-06-24 11:53:01.858211
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create a simple test object
    h = HttpFD(None, None, {'noprogress': True})

    # Test if it has the needed attributes
    assert hasattr(h, 'ydl')
    assert hasattr(h, 'params')
    assert hasattr(h, 'info_dict')
    assert hasattr(h, 'tmpfilename')
    assert hasattr(h, 'url')
    assert hasattr(h, 'filename')
    assert hasattr(h, 'simulate')
    assert hasattr(h, 'test')
    assert hasattr(h, 'is_test')
    assert hasattr(h, 'cancel_pending')
    assert hasattr(h, 'fd')
    assert hasattr(h, 'dl')
    assert hasattr(h, 'retries')

# Generated at 2022-06-24 11:53:08.082771
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test_')
    filename = os.path.join(temp_dir, 'test_video.flv')
    url = 'http://localhost/test_video.flv'
    hfd = HttpFD(url, {'outtmpl': filename})
    hfd.test()
    hfd.close()
    assert os.path.exists(filename)
    os.remove(filename)
    hfd = HttpFD(url, {'outtmpl': filename, 'continuedl': True})
    hfd.test()
    hfd.close()
    assert os.path.exists(filename)
    os.remove(filename)

# Generated at 2022-06-24 11:53:18.009855
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a temporary file, then download URL to this file
    filename = mkdtemp()
    fd = HttpFD(FileDownloader(), {}, 'http://127.0.0.1:8080/dummy', 'wb', False)
    fd.real_download(filename, {'skip_existing': False, 'test': True})
    assert os.path.exists(filename)
    assert os.stat(filename).st_size < fd._TEST_FILE_SIZE
    assert os.path.isfile(filename)
    os.remove(filename)
    # Download dummy file to stdout
    fd = HttpFD(FileDownloader(), {}, 'http://127.0.0.1:8080/dummy', 'wb', False)
    import tempfile
    old_stdout = sys.stdout


# Generated at 2022-06-24 11:53:29.538334
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # pylint: disable=no-member
    info_dict = {
        'url': 'http://blabla.com/video123.flv',
        'ext': 'flv',
        'player_url': 'http://blabla.com/player.swf',
        'width': 400,
        'height': 300,
    }
    params = {
        'format': '35/best',
        'outtmpl': '%(id)s-%(format)s.%(ext)s',
    }
    # pylint: disable=no-member
    info_dict['n_entries'] = 1
    params['test'] = True
    params['nooverwrites'] = False
    params['continuedl'] = True
    ydl = FakeYDL()

# Generated at 2022-06-24 11:53:37.470458
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    import atexit
    import shutil
    tmpdir = tempfile.mkdtemp(prefix='youtube-dl-test_')
    atexit.register(lambda : shutil.rmtree(tmpdir))
    fd = HttpFD(tmpdir)
    assert 'ok' in fd.readline()
    assert fd.fileno()
    fd.close()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:53:49.481098
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import types
    import http.client
    import random
    import shutil
    import urllib.request
    import urllib.error
    from _common import HttpFD, SameFileError, SupportedVCS
    from _common import calc_expected_filesize
    from _common import DEFAULT_OUTTMPL
    from _common import MaxDownloadsReached
    from _common import parse_filesize
    from _common import parse_fragment_retries
    from _common import parse_iso8601
    from _common import sanitize_open
    from _common import set_filesize
    from _common import set_limit_rate
    from _common import set_socket_timeout
    from _common import set_verbosity
    from _common import sanitize_url
    from _common import sleep

# Generated at 2022-06-24 11:53:56.041110
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Set up some fake input
    def myurlretrieve(url, filename, reporthook):
        test_FD = HttpFD(url, {'outtmpl': filename}, reporthook)
        test_FD.close()
    filename = 'foo'
    test_url = 'bar'
    test_params = {'noprogress': True,
                   'logger': YoutubeDL(None).logger}
    test_reporthook = lambda x:None
    myurlretrieve(test_url, filename, test_reporthook)

# Generated at 2022-06-24 11:54:01.748883
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Tests that real_download function of class HttpFD downloads a file
    with HttpFD.
    """
    import tempfile
    import os
    import shutil
    from .compat import compat_urllib_request
    from .utils import determine_ext
    from .compat import compat_tempfile_gettempdir

    def _test_http_download(http_test_server):
        # Set up parameters for HttpFD.real_download
        tmpdir = tempfile.mkdtemp(dir=compat_tempfile_gettempdir())
        test_file_path = os.path.join(tmpdir, 'test_file')
        info_dict = {}
        params = {'quiet': True, 'nooverwrites': True, 'continuedl': True, 'noprogress': True}
       

# Generated at 2022-06-24 11:54:12.309007
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    # Build test cases
    test_cases = []
    test_cases.append({
        'params': {},
        'expected': {
            'expected_content_range': None,
            'expected_data_len': 10,
            'expected_open_mode': 'wb',
            'expected_resume_len': 0,
        }
    })
    test_cases.append({
        'params': {
            'continuedl': True,
        },
        'expected': {
            'expected_content_range': None,
            'expected_data_len': 5,
            'expected_open_mode': 'ab',
            'expected_resume_len': 5,
        }
    })

# Generated at 2022-06-24 11:54:22.939899
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class ContentTooShortError(Exception):
        def __init__(self, view, actual, expected):
            self.args = (actual, expected)

    def urlopen(req):
        class Data(object):
            def info(self):
                return {'Content-Length': str(len(content))}

            def read(self, _):
                return content.pop(0)

        class Response(object):
            def __init__(self, data):
                self.data = data

            def read(self, chunk_size):
                return self.data.read(chunk_size)

        def read(chunk_size):
            assert request.headers['Range'] == 'bytes=0-{}'.format(chunk_size), 'Wrong range header in chunked download, {}'.format(chunk_size)

# Generated at 2022-06-24 11:54:34.140505
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.ie_key() == 'Generic':
            continue
        success = False
        for url in ie.working_urls():
            try:
                fd = HttpFD(url)
            except (compat_urllib_error.URLError, socket.error):
                print('URLError at %s' % url)
                break
            try:
                fd.real_download(None, None)
                success = True
            except StopDownloading:
                pass
            finally:
                fd.close()
        if success:
            break
    else:
        raise Exception('No working extractor')



# Generated at 2022-06-24 11:54:45.255205
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Inputs
    FILE_SIZE = 1000
    TEST_FILE_SIZE = 10
    URL = 'http://localhost'

    with closing(io.BytesIO(b'a' * FILE_SIZE)) as test_file:
        # Create request
        request = sanitized_Request(
            URL, None, {'Range': 'bytes=%d-' % (FILE_SIZE - TEST_FILE_SIZE)})
        request.add_header('User-Agent', 'TestAgent')

        # Create http_fd
        http_fd = HttpFD(
            test_file,
            params={'noprogress': True},
            info_dict={},
            url=URL,
            filename='name',
            test=True
        )

        # Test
        info = http_fd.info()
        assert info['size'] == FILE_SIZE

# Generated at 2022-06-24 11:54:47.642313
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # test error reporting
    return
# test for real_download


# Generated at 2022-06-24 11:54:58.676490
# Unit test for constructor of class HttpFD
def test_HttpFD():
    '''
    Test the constructor of HttpFD
    '''
    tmpdir = tempfile.gettempdir()
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    filename = encodeFilename(tmpfile.name)
    assert os.path.exists(filename)
    tmpfile.close()
    assert os.path.exists(filename)
    assert os.path.isfile(filename)
    h = HttpFD(None, {'nopart': True, 'continuedl': True}, filename, 'wb')
    assert h.fd.closed == False
    h.close()
    assert h.fd.closed == True
    assert os.path.exists(filename)
    assert os.path.isfile(filename)
    os.remove(filename)
    assert not os

# Generated at 2022-06-24 11:55:04.833090
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.common import InfoExtractor
    from .utils import prepend_extension

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'usenetrc': False,
                'username': None,
                'password': None,
                'videopassword': None,
                }
            self.cache = None
        def to_screen(self, something):
            print(something)
        def trouble(self, *args, **kargs):
            pass  # just ignore the trouble
        def download_with_retry(self, recode_opts, *args, **kargs):
            assert recode_opts is None
            return True
        def fix_url(self, url):
            return url

# Generated at 2022-06-24 11:55:18.302294
# Unit test for constructor of class HttpFD
def test_HttpFD():
    '''
    $ python -m youtube_dl.FileDownloader --test-http-fd
    '''
    from .utils import encodeArgument

    def test_valid_url(url):
        HttpFD(url)

    def test_invalid_url(url):
        try:
            HttpFD(url)
        except ExtractorError:
            pass

    # valid
    test_valid_url('http://127.0.0.1/')
    test_valid_url('http://user:pass@127.0.0.1/')
    test_valid_url('http://user:@127.0.0.1/')
    test_valid_url('http://127.0.0.1:8080/')
    test_valid_url('http://[::1]/')
    test_valid

# Generated at 2022-06-24 11:55:26.883962
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing constructor of HttpFD...')
    # Test if unspecified proxy causes trouble
    urlopenFunc = compat_urllib_request.urlopen

    def urlopen_dummy(req):
        print('Dummy URLOpener called')
        return urlopenFunc(req)
    compat_urllib_request.urlopen = urlopen_dummy

    # Dummy arguments
    testargs = ['prog', 'url', '-o', 'filename']
    params = {}
    def getval(param, args=testargs):
        return params.get(param, defaultParams[param])
    def istrue(param, args=testargs):
        return params.get(param, False)

    res = HttpFD(getval, istrue, testargs)
    # Check if unspecified proxy causes trouble

# Generated at 2022-06-24 11:55:33.678483
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def check_download_progress(p):
        if 'entries' in p:
            for ep in p['entries']:
                if ep is not None:
                    check_download_progress(ep)
        elif 'status' in p:
            if p['status'] == 'finished':
                assert p['_total_bytes_estimate'] == p['_total_bytes_variable']
                assert p['_total_bytes_estimate'] == p['_downloaded_bytes_variable']
                assert p['total_bytes'] == p['downloaded_bytes']
                assert p['speed'] is not None
                assert p['elapsed'] is not None
            elif p['status'] == 'downloading':
                assert p['total_bytes'] is not None
                assert p['downloaded_bytes'] <= p['total_bytes']
               

# Generated at 2022-06-24 11:55:46.910037
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def raise_IOError():
        raise IOError()
    def raise_ContentTooShortError():
        raise ContentTooShortError(99, 100)
    def raise_socket_error(*args):
        raise socket.error(*args)
    def raise_compat_urllib_error_HTTPError(*args):
        raise compat_urllib_error.HTTPError(*args)
    def raise_compat_urllib_error_URLError(*args):
        raise compat_urllib_error.URLError(*args)

    fd = HttpFD(
        {'test_suite': True},
        ['http://127.0.0.1/']
    )
    fd._TEST_FILE_SIZE = 100
    # Sanity check

# Generated at 2022-06-24 11:55:53.489564
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def make_data():
        num_blocks = int(random.expovariate(0.5) + 0.5)
        for x in range(num_blocks):
            yield bytes(int(random.expovariate(2)) + 1)
    fd = HttpFD(make_data())
    fd.size = sum(map(len, make_data()))
    return fd


# Generated at 2022-06-24 11:56:04.049120
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test method real_download
    class MockYDL(object):
        def __init__(self):
            self.params = {
                'continue_dl': True,
                'ratelimit': None,
                'retries': 10,
                'logger': YoutubeLogger(),
                'noresizebuffer': False,
                'test': True,
            }

    class MockOpener(object):
        def __init__(self):
            self.cnt = 0

        def open(self, request):
            assert isinstance(request, compat_urllib_request.Request)
            assert request.headers['Range'] == 'bytes=0-7'
            self.cnt += 1
            class MockResponse(object):
                def __init__(self, headers):
                    self.info = lambda: headers

# Generated at 2022-06-24 11:56:06.617142
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(None, {'noprogress': True}, None, None)
    assert h



# Generated at 2022-06-24 11:56:17.171042
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import unittest

    class MyException(Exception):
        pass

    class MockYDL(object):
        def __init__(self, content):
            self._content = content
            self._pos = 0
            self._headers = {
                'Content-Length': str(len(content)),
            }

        def urlopen(self, req):
            range = compat_str(req.get_header('Range'))
            if range:
                m = re.search(r'bytes=(\d+)-(\d+)?', range)
                start = int(m.group(1))
                if m.group(2) is not None:
                    stop = int(m.group(2)) + 1
                else:
                    stop = None
                assert start <= len(self._content), 'Invalid start range'

# Generated at 2022-06-24 11:56:28.225446
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # fake objects
    count = 0
    def urlopen(request):
        class BytesIO(object):
            def __init__(self, data):
                self.data = data
            def info(self):
                class Info(object):
                    def get_all(self, key):
                        if key == 'content-length':
                            return ['1024']
                        return []
                    getheaders = get_all
                return Info()
            def read(self, bytes_):
                global count
                if count < 8:
                    data = self.data[:31]
                    self.data = self.data[31:]
                    count += 1
                elif count < 11:
                    data = self.data[:512]
                    self.data = self.data[512:]
                    count += 1
                elif count < 12:
                    data

# Generated at 2022-06-24 11:56:39.175591
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys

    class DummyYDL:
        def __init__(self):
            self.params = {}
            self.to_screen = lambda *args, **kwargs: None
            self.to_stderr = lambda *args, **kwargs: None

        def report_error(self, msg):
            sys.stderr.write('ERROR: %s\n' % msg)

        def report_destination(self, filename):
            sys.stderr.write('Destination: %s\n' % filename)

        def report_retry(self, error, count, retries):
            sys.stderr.write('Retrying (%s/%s): %s\n' % (count, retries, error))


# Generated at 2022-06-24 11:56:50.400826
# Unit test for constructor of class HttpFD
def test_HttpFD():
    stream = io.BytesIO()
    fd = HttpFD(stream, 'wb')
    # default
    assert fd.close_stream is None
    assert fd.always_close_stream is False
    # non-standard
    fd = HttpFD(stream, 'wb', close_stream=False)
    assert fd.close_stream is False
    assert fd.always_close_stream is False

    # Test the context manager protocol
    with HttpFD(stream, 'wb', close_stream=False) as fd:
        pass

    assert stream.closed is True

    with HttpFD(stream, 'wb', always_close_stream=True) as fd:
        pass

    assert stream.closed is True


# Generated at 2022-06-24 11:56:58.350592
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.common import InfoExtractor

    ie = InfoExtractor()
    ie.params = {}
    fd = HttpFD(ie)

    assert(fd.params['noresizebuffer'] == False)
    assert(fd.best_block_size() == 8192)

    fd.params['noresizebuffer'] = True
    assert(fd.best_block_size() == 8192)


# Generated at 2022-06-24 11:57:06.041495
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # pylint: disable=protected-access
    # Constructor with _return_none as a hook
    def _return_none(*_args, **_kwargs):
        return None
    fd = HttpFD(params={'ratelimit': 12345, 'noresizebuffer': True}, hook_progress=_return_none)
    assert fd.params['ratelimit'] == 12345
    assert fd.params['noresizebuffer']
    assert fd.hook_progress is _return_none
    assert fd._TEST_FILE_SIZE == 256 * 1024



# Generated at 2022-06-24 11:57:17.548577
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    fakeydl = None
    ext = InfoExtractor({})
    ext.add_info_extractor(_test_IE('test', [], None))
    fd = FileDownloader({'username': 'user', 'password': 'passwd', 'usenetrc': False, 'quiet': True})
    fd.add_info_extractor(ext)
    fakeydl = fd._real_download

    # Test 1: normal test, 200 OK expected
    # This test should pass
    test_url = 'http://127.0.0.1:8181/200'
    filename = 'test1.tmp'

# Generated at 2022-06-24 11:57:29.039583
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 11:57:40.853130
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # unit test for constructor of class HttpFD
    # (somewhat yucky to run it here, but makes test_downloader easier to read)
    from io import BytesIO

    class MockHeadRequest(compat_urllib_request.Request):
        def get_method(self):
            return 'HEAD'

    class MockGetRequest(compat_urllib_request.Request):
        def get_method(self):
            return 'GET'

    class MockUrllib2(object):
        class Request(object):
            pass

        class URLError(Exception):
            def __init__(self, reason):
                self.reason = reason

        class HTTPError(Exception):
            def __init__(self, code, msg, headers, fp):
                self.code = code
                self.msg = msg


# Generated at 2022-06-24 11:57:49.903207
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    hf = HttpFD(BytesIO(b'foo'), url="http://example.com")
    assert hf.name == "http://example.com"
    assert hf.url == "http://example.com"
    assert hf.getheader("Content-type") == "text/plain; charset=utf-8"
    assert hf.read() == b'foo'
    assert len(hf.fileno()) == 1  # Must be convertible to a file descriptor number
    hf.seek(1)
    assert hf.tell() == 1


# Generated at 2022-06-24 11:57:59.211897
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_data = (
        # URL, expected_fp, expected_resume_len, expected_is_test, expected_data_len, expected_content_type
        ('http://domain.com/video.mp4', 'video.mp4', 0, False, None, None),
        ('http://domain.com/video.mp4?test', 'video.mp4', 0, True, None, None),
        ('http://domain.com/video.mp4?test', 'video.mp4', 0, True, 100, None),
        ('http://domain.com/video.mp4?test', 'video.mp4', 0, True, 100, 'video/mp4'),
    )

# Generated at 2022-06-24 11:58:10.161132
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """ Test real_download method of class HttpFD.
    
        As real_download method is a generator, it can't be tested in regular way.
        For example using mock library.
        So, we need to call next() and get values from the generator instead.
    """
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    result = next(HttpFD._real_download('ytdl_test_data/real_download_test_data.txt',
                              #'test_download_test_data.txt',
                              {'nooverwrites': True, 'continuedl': True, 'noprogress': True},
                              {'id': 'test_download'}, 'test_download.txt',
                              True, {}))


# Generated at 2022-06-24 11:58:20.767945
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def checksum(s):
        return hashlib.md5(s).hexdigest()

# Generated at 2022-06-24 11:58:28.090741
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert_raises_regex(IOError, 'No input file or URL specified; use --default-search "auto"', HttpFD,
        {}, {}, u'')

    assert_raises_regex(IOError, 'error: bad URL', HttpFD, {}, {}, u'http:///')

    assert_raises_regex(IOError, '"/": Path contains illegal character -2', HttpFD, {}, {}, u'http:///foo\xfe')

    assert_raises_regex(IOError, '"/": Path contains illegal character -2', HttpFD, {}, {}, u'http:///foo\xfe')


# Generated at 2022-06-24 11:58:39.079946
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import youtube_dl.postprocessor
    class MyPostProcessor(youtube_dl.postprocessor.PostProcessor):
        def run(self, information):
            self.ydl.http_external_downloader.params['noprogress'] = True
            # HttpFD.__init__ sets default value of params['retries'] to 0
            # so let's change the value
            self.ydl.http_external_downloader.params['retries'] = 1
            self.ydl.postprocessors.append(information)

    class YDL(object):
        info_dict = {}
    ydl = YDL()
    ydl.http_external_downloader = HttpFD(ydl)
    ydl.postprocessors = []

    # Create video file

# Generated at 2022-06-24 11:58:47.583159
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test 1: Test constructor with valid URL
    fd = HttpFD('http://www.example.com/index.html')
    assert (fd.url == 'http://www.example.com/index.html')
    assert (fd.http_headers == [])
    assert (fd.filename == 'index.html')
    assert (fd.info_dict == {})
    # Test 2: Test constructor with invalid URL
    try:
        fd = HttpFD('foobar')
        assert False
    except AssertionError:
        raise
    except:
        pass
    # Test 3: Test constructor with URL with http_headers
    fd = HttpFD('http://www.example.com/index.html', {'Range': 'bytes=0-5'})

# Generated at 2022-06-24 11:58:58.769267
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class Dummy(object):
        def __init__(self):
            self.http_headers = {
                'Foo': 'bar'
            }
            self.urlhandle = Dummy()
            self.urlhandle.url = 'test'
            self.params = {}
            self.max_temp_file_size = 16 * 1024 * 1024
            self.to_screen = lambda x: None
            self.to_stderr = lambda x: None
            self.report_error = lambda x: None
            self.report_file_already_downloaded = lambda x: None
            self.add_progress_hook = lambda x: None

    test = Dummy()

    ext = os.path.splitext('test')[1]
    filename = 'test' + ext


# Generated at 2022-06-24 11:59:09.421630
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        os.remove(test_filename)
    except (IOError, OSError) as err:
        if err.errno != errno.ENOENT:
            raise

    stream = io.BytesIO()
    assert stream.tell() == 0

    # Test non-resumable download
    HttpFD(sanitized_Request('http://localhost:8765/' + test_url), stream, test_filename, range_start=None, range_end=None)
    assert stream.tell() == test_downloaded
    assert os.path.getsize(encodeFilename(test_filename)) == test_downloaded
    os.remove(test_filename)

    # Test resumable download
    stream = io.BytesIO()
    assert stream.tell() == 0

# Generated at 2022-06-24 11:59:20.602789
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Unit test for method real_download of class HttpFD."""
    from .extractor.common import InfoExtractor
    from .utils import RegexNotFoundError

    # Create temporary directory
    import tempfile
    tmpdir = tempfile.mkdtemp()
    tmpdir = encodeFilename(tmpdir)

    # Create fake InfoExtractor instance and its download method
    class FakeInfoExtractor(InfoExtractor):
        def _download_webpage(self, url, *args, **kwargs):
            return b'The contents of the requested webpage'

        def _real_extract(self, url):
            self.to_screen(u'Testing HttpFD')
            self.to_screen(u'Trying to download a file')
            info = {}

# Generated at 2022-06-24 11:59:30.709673
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_http_req_handler():
        test_http_req_handler.req_count = test_http_req_handler.req_count + 1

        class TestHTTPResponse(object):
            def __init__(self, code):
                self.code = code
                self.headers = {
                    'Accept-Ranges': 'bytes',
                }
        class TestHTTPErrorProcessor(object):
            def http_response(self, request, response):
                if response.code == 416:
                    raise compat_urllib_error.HTTPError(request.get_full_url(), 416, '', {}, None)
                else:
                    return response
            https_response = http_response

        if test_http_req_handler.req_count == 1:
            return TestHTTPResponse(200)
       

# Generated at 2022-06-24 11:59:37.077678
# Unit test for constructor of class HttpFD
def test_HttpFD():
    (c, o, e) = get_cmd_output('/bin/echo -n foo', active_live_probers=False, extra_env={'LC_ALL': 'C'}) # use C locale because of different output on different OS
    c = int(c)
    assert c == 0
    assert o == b'foo'
    assert e == b''
    fd = HttpFD(c, o, e, None, None)
    assert fd.real_url is None
    assert fd.headers == {}
    assert fd.status == 200
    assert fd.content_type == b'text/plain'
    assert fd.redirect_url is None
    assert fd.final_url == 'http://youtubedl.org/'
    assert fd.real_download_url is None

# Generated at 2022-06-24 11:59:43.121676
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ctx = HttpFD._DownloadContext()

    ctx.tmpfilename = tempfile.mkstemp()[1]
    ctx.stream = None

    # The following two lines would not work if test_real_download
    # was a module-level function, because they would be executed
    # as soon as the module is imported.
    # A local function is needed in order to execute these lines
    # only when the test is actually being run.
    listener = GenericIE()
    ctx.ydl = YoutubeDL(listener.params)

    ctx.filename = '-'
    ctx.open_mode = 'wb'
    ctx.test = True
    ctx.block_size = 10000
    ctx.start_time = time.time()
    ctx.data_len = 409600
    ctx.resume_

# Generated at 2022-06-24 11:59:49.092323
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test whether HttpFD class can be initialized without exceptions
    http_test = HttpFD(params=None, ydl=None)
    # If HttpFD class can be initialized, test some of its methods
    assert http_test.best_block_size(0.0, 1024) > 0
    assert http_test.best_block_size(1.0, 1024) > 0


# Generated at 2022-06-24 11:59:58.020518
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Test the constructor of HttpFD.

    Return an error message if something goes wrong, None otherwise.
    """

    fd = HttpFD(urlopen('http://www.example.com/'))
    meta = fd.info()
    size = int(meta.getheaders("Content-Length")[0])
    if size < 100:
        return 'Content of http://www.example.com/ is not long enough to be downloaded (%d bytes)' % size
    if fd.size() != size:
        return 'HttpFD.size() returns %d, should be %d' % (fd.size(), size)

    return None

# Test HttpFD.retrieve() and HttpFD.retrieve_range()

# Generated at 2022-06-24 12:00:08.850613
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # Classes with mocked methods used in method real_download
    class MockInfoExtractor(object):
        def __init__(self):
            self._downloader = MockDownloader()

    class MockYDL(object):
        def __init__(self):
            self._ie = MockInfoExtractor()

    # Create the object to test
    testobj = HttpFD()

    # Add some attributes needed for the test
    testobj.ydl = MockYDL()
    testobj._TEST_FILE_SIZE = 1000  # bytes

    # Prepare the mocking of urlopen
    class MockUrlOpen(object):
        def __init__(self, data_len_or_exception):
            self.data_len_or_exception = data_len_or_exception


# Generated at 2022-06-24 12:00:17.139125
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # import mock
    from .compat import compat_urllib_error
    from .utils import sanitize_open
    import socket
    import tempfile
    # TODO add test for 'xattr_set_filesize'
    # TODO add test for 'updatetime'
    # TODO add test for 'continuedl'
    # TODO add test for 'noresizebuffer'
    # TODO add test for 'retries'
    # TODO add test for 'ratelimit'
    # TODO add test for 'buffersize'
    # TODO add test for 'noprogress'
    # TODO add test for 'test'
    # TODO add test for 'continuedl'
    # TODO add test for 'min_filesize'
    # TODO add test for 'max_filesize'


# Generated at 2022-06-24 12:00:22.719496
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    url_data = StringIO('\n'.join((
        'HTTP/1.1 200 OK',
        'Server: nginx',
        'Date: Tue, 26 Aug 2014 12:56:45 GMT',
        'Content-Type: text/html; charset=UTF-8',
        'Connection: keep-alive',
        'Keep-Alive: timeout=10',
        'Content-Length: 32',
        '',
        '1234567890abcdef1234567890abcdef',
    )))

    url_handler = compat_urllib_request.addinfourl(url_data, {}, 'http://example.com')

# Generated at 2022-06-24 12:00:34.110697
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    if sys.platform == 'win32':
        import msvcrt

    @staticmethod
    def _make_test_server():
        from http.server import HTTPServer, SimpleHTTPRequestHandler

        class MyRequestHandler(SimpleHTTPRequestHandler):
            def do_GET(h):
                if h.path == '/':
                    h.send_response(301)
                    h.send_header('Location', '/index.html')
                elif h.path == '/404':
                    h.send_error(404, 'File not found')
                elif h.path == '/405':
                    h.send_error(405, 'Method not allowed')

# Generated at 2022-06-24 12:00:42.569174
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url_base = 'file://' + compat_os_path.abspath(compat_os_path.join(os.getcwd(), 'test')) + compat_os_path.sep
    filename = compat_os_path.join('test', '__init__.py')
    url = url_base + filename

    fd = HttpFD(url, {'noprogress': True, 'quiet': True})
    assert fd.url == url
    assert fd.filename == filename
    assert fd.info() == 'Test'

# Generated at 2022-06-24 12:00:50.789532
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def urlopen_side_effect(*args, **kargs):
        class HTTPMock:
            def __init__(self, headers, data_len, chunk_size=None, **kargs):
                self.headers = headers
                self.data_len = data_len
                self.pos = 0
                self.chunk_size = chunk_size
            def read(self, byte_counter):
                if self.pos >= self.data_len:
                    return ''
                if self.chunk_size is not None:
                    byte_counter = min(byte_counter, self.chunk_size)
                self.pos += byte_counter
                return '\0' * byte_counter
            def info(self):
                return self.headers

# Generated at 2022-06-24 12:01:04.847056
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(HttpFD):
        def __init__(self, *args, **kwargs):
            super(TestFD, self).__init__(*args, **kwargs)
            self.retval = False
            self.test_block_size = 1024 * 1024 * 5
            self.try_rm('x')
            self.try_rm('xx')
        def best_block_size(self, s, l):
            self.assertGreater(s, 0)
            self.assertGreater(l, 0)
            return self.test_block_size
        def slow_down(self, a, b, c):
            pass
        def to_screen(self, s):
            pass
        def report_destination(self, s):
            pass
        def report_progress(self, s):
            pass

# Generated at 2022-06-24 12:01:12.115440
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, 'test.tmp')
    ctx = Context()
    ctx.params['retries'] = 0
    ctx.params['continuedl'] = False
    ctx.params['tmpfilename'] = test_file
    ctx.params['noprogress'] = True
    ctx.params['test'] = True
    ydl = YoutubeDL(ctx.params)
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(FakeIE(ydl))
    ie = ydl.get_info_extractor('fake')
    ie._set_downloader(HttpFD(ydl, ctx))

# Generated at 2022-06-24 12:01:24.083324
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test normal playback
    fd = HttpFD('http://example.com/')
    assert fd.read(1) == '<'

# Generated at 2022-06-24 12:01:30.213929
# Unit test for constructor of class HttpFD
def test_HttpFD():
    filehandle, urlhandle = HttpFD(
        'http://www.youtube.com/watch?v=BaW_jenozKc', {'noprogress': True}, None).download()
    try:
        assert isinstance(filehandle, io.BufferedIOBase)
        with urlhandle:
            urlhandle.read(1)
    finally:
        filehandle.close()


# Generated at 2022-06-24 12:01:41.195223
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # base class TestCase needs to be imported from unittest module
    # (previously TestCase class was imported from youtube_dl.FileDownloader module)
    from unittest import TestCase  # @UnresolvedImport

    class MockYTDLSocket(object):
        def __init__(self, data, *args, **kwargs):
            super(MockYTDLSocket, self).__init__(*args, **kwargs)
            self.data = data
            self.i = 0

        def read(self, size):
            r = self.data[self.i:self.i+size]
            self.i += size
            return r

        def info(self):
            return {'Content-length': str(len(self.data))}


# Generated at 2022-06-24 12:01:54.007535
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # The test case is based on real example and checks if real_download does not
    # download the whole file as a result of HTTP 416 response.
    #
    # For test we pretend that chunk size is much larger than actual file size.
    # And we check that after receiving 416 HTTP response real_download does not
    # download the whole file.
    #
    # You may notice that this test actually is not a unit test.
    # In fact it is an integration test. But it is smaller than usual integration
    # test, so it is kept.

    class MockResponse(object):
        def __init__(self, length=1000):
            self.length = length

# Generated at 2022-06-24 12:01:59.436343
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test successful download
    url = "http://example.com/some/file.mp3"
    tmpfilename = TempFileName("file.mp3")
    assert (
        http_test_server(
            lambda data: [
                b'HTTP/1.0 200 OK\r\n',
                b'Content-Length: ' + str(len(data)).encode('ascii') + b'\r\n',
                b'\r\n',
                data
            ])(url, tmpfilename, 10) == 10
    )
    os.remove(encodeFilename(tmpfilename))
    # Test successful download with several retries (and two download function calls)
    url = "http://example.com/some/file.mp3"
    tmpfilename = TempFileName("file.mp3")

# Generated at 2022-06-24 12:02:11.438032
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _setUp(test):
        class FakeYtdl(object):
            @staticmethod
            def urlopen(*args, **kwargs):
                return FakeUrlopen(*args, **kwargs)

        class FakeUrlopen(object):
            def __init__(self, *args, **kwargs):
                self.headers = {}

# Generated at 2022-06-24 12:02:20.420619
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test if given URL is valid
    fd1 = HttpFD(
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        params={'noprogress': True},
        progress_hooks=[]
    )
    assert fd1

    # Test if valid URL ends with a slash
    fd2 = HttpFD(
        'http://www.youtube.com/watch?v=BaW_jenozKc/',
        params={'noprogress': True},
        progress_hooks=[],
    )
    assert fd2 == fd1

    # Test if invalid URL will not instantiate

# Generated at 2022-06-24 12:02:33.097965
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import ssl
    from .compat import ssl_wrap_socket

    class FakeSocket(object):
        def __init__(self, data):
            self._data = data
            self._buffer = b''
            self.closed = False
            if not isinstance(self._data, list):
                self._data = [self._data]
            self._data_len = sum(len(x) for x in self._data)

        def _read_data(self, size=-1):
            if len(self._data) == 0:
                return b''
            data = self._data.pop(0)
            if size >= 0 and len(data) > size:
                self._data.insert(0, data[size:])
                data = data[:size]
            return data


# Generated at 2022-06-24 12:02:41.273323
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import random
    import tempfile
    from .utils import encodeFilename

    class DummyYDL(object):
        def __init__(self):
            self.to_screen_lock = threading.RLock()
            self.sleep_secs = 0.1
            self.best_block_size = 1024    # 1 KB
            self.filesystem_encoding = sys.getfilesystemencoding()
            self._opener = compat_urllib_request.build_opener()
        def urlopen(self, req, *args, **kargs):
            # req is a sanitized request
            print('%r %r %r' % (req, args, kargs))
            return self._opener.open(req, *args, **kargs)

# Generated at 2022-06-24 12:02:51.304024
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    unit test of method HttpFD.real_download of class HttpFD
    """
    import sys
    import math
    import time
    def h(x):
        return int(math.floor(math.log10(x))+1)
    t_start = time.time()
    ydl = YoutubeDL()
    t_end = time.time()
    t_elapsed = t_end - t_start
    t_elapsed = (t_elapsed)
    print("%s: elapsed: %ss" % ("YoutubeDL", t_elapsed), file=sys.stderr, flush = True)
    t_start = time.time()
    httpFD = HttpFD(ydl)
    t_end = time.time()
    t_elapsed = t_end - t_start
   