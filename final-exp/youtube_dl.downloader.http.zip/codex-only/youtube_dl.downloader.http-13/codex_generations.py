

# Generated at 2022-06-24 11:52:56.350472
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test 1. An URL
    fd = HttpFD('http://www.google.com')
    assert(fd.url == 'http://www.google.com')
    assert(fd.use_proxy == 0)
    assert(fd.proxies == {})
    assert(fd.params == {})
    assert(fd.ydl == None)

    # Test 2. An URL together with params
    fd = HttpFD('http://www.google.com', params={'hello': 'world'})
    assert(fd.url == 'http://www.google.com')
    assert(fd.use_proxy == 0)
    assert(fd.proxies == {})
    assert(fd.params == {'hello': 'world'})
    assert(fd.ydl == None)

    # Test 3. GET params

# Generated at 2022-06-24 11:53:07.163932
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYoutubeDL(object):
        def __init__(self, params):
            self.params = params
            self.downloaded_bytes = 0
            self.total_bytes = None

# Generated at 2022-06-24 11:53:13.442480
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for HttpFD constructor
    fd = HttpFD(
        'http://www.youtube.com/get_video_info?video_id=BaW_jenozKc',
        {
            'cookiefile': 'cookies.txt',
            'noprogress': True,
            'proxy': '127.0.0.1:813',
            'ratelimit': '50k',
            'retries': 10,
            'socket-timeout': 20,
            'test': True,
            'user-agent': 'test-user-agent',
        }
    )

    assert isinstance(fd.ydl, YoutubeDL) and isinstance(fd.params, dict)

    # Test if params are correctly passed to ydl object

# Generated at 2022-06-24 11:53:24.333440
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class TestFD(object):
        def __init__(self, name, mode):
            self.name = name
            self.mode = mode
            self.closed = False
            self.metadata = {}
            if mode == 'wb':
                self.bytes = ''
            elif mode == 'ab':
                self.bytes = 'abc'
            else:
                assert False, 'Unsupported mode'

        def close(self):
            self.closed = True

        def write(self, b):
            if self.closed:
                raise ValueError('I/O operation on closed file')
            self.bytes += b

        def __len__(self):
            return len(self.bytes)

    def test(filename, mode, blocks, expected_bytes, expected_blocks):
        fd = TestFD(filename, mode)
        http_

# Generated at 2022-06-24 11:53:35.152423
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys

    def test_download(filename):
        from .extractor import gen_extractors
        from .YoutubeDL import YoutubeDL

        ie = gen_extractors(YoutubeDL())[0]
        test_fd = HttpFD(ie.ydl, ie, {'noprogress': True})
        info = {
            'url': 'http://127.0.0.1:8080/%s' % filename,
            'http_headers': {
                'Range': 'bytes=0-%d' % HttpFD._TEST_FILE_SIZE,
            }
        }
        return test_fd.real_download(info, 'test_file')

    # Make sure we can download the whole file
    assert test_download('file')

    # Make sure we can download a piece of file
    #

# Generated at 2022-06-24 11:53:44.837841
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_data_size, test_data_size_str = 500000, '500000'
    test_filename = os.path.join(
        'test', 'test_real_download.bin'.format(test_data_size))
    resumable_filename = os.path.join(
        'test', 'test_real_download.bin_resumable'.format(test_data_size))
    test_url = 'http://localhost/fd_dummy.bin.part'

    # Make sure there is no dummy local file
    if os.path.isfile(test_filename):
        os.remove(test_filename)

    # Generate data of defined size
    test_data = urandom(test_data_size)

    # Create a dummy server that provides pre-generated test data on request

# Generated at 2022-06-24 11:53:55.710609
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import prepare_filename, determine_ext

    # Test with valid file, should return True
    class TestIE(InfoExtractor):
        IE_DESC = 'Dummy IE for test'
        _VALID_URL = r'https://localhost/valid'

        def _real_extract(self, url):
            self.report_extraction(r'Test')
            return {'id': 'id', 'ext': 'mp4', 'title': 'title', 'url': 'https://localhost/valid'}

    t = TestIE(YoutubeIE())
    t.params['outtmpl'] = r'%(id)s'
    t.params['nooverwrites'] = True
    t.ydl.add_

# Generated at 2022-06-24 11:54:07.485073
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import ctypes
    try:
        ctypes.CDLL('librtmp.so', mode=ctypes.RTLD_GLOBAL)
    except OSError:
        raise SkipTest('rtmpdump not available')

    # Create a temporary directory
    downloader = HttpFD()
    try:
        os.mkdir('./unit')
        os.chdir('./unit')
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    # Download a file with real_download

# Generated at 2022-06-24 11:54:19.270813
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # This part of the unit test is inspired by:
    # https://github.com/rg3/youtube-dl/blob/master/youtube_dl/downloader/fragment.py
    # The aim of the test is to verify that HttpFD.real_download works correctly
    # In particular, it must be able to correctly resume download of a file
    # and correctly handle errors
    # A server (that simulates a non-resuming and a resuming one) is created,
    # and two threads are created in order to download the same file
    # In the first thread the server does not support resume,
    # in the second one it does
    # The test is passed if the downloaded files are identical
    # (this is verified in the thread)
    import os.path, random, socket, threading, time
    from http.server import HTTPServer

# Generated at 2022-06-24 11:54:32.309414
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _make_HttpFD_real_download_test(params, content_length_ok, fsize, fcrc32, expected_success, msg,
                                        resume_len=0,
                                        content_length=None,
                                        content_range=None,
                                        blocksize_min=8192,
                                        blocksize_max=131072,
                                        content_offset=0,
                                        chunksize=0,
                                        is_test=False):
        def _http_download(ydl, url, filename, info_dict):
            with open(fsize, 'rb') as f:
                for offset in itertools.count(0, chunksize or blocksize_min):
                    csize = min(blocksize_min, os.path.getsize(fsize) - offset)

# Generated at 2022-06-24 11:54:37.445339
# Unit test for constructor of class HttpFD
def test_HttpFD():
    args = [
        (('foo', 'wb'), ('foo', 'wb'), None),
        (('-', 'wb'), ('-', 'wb'), sys.stderr),
        ((sys.stdout, 'wb'), ('-', 'wb'), None),
        (('-', 'w'), ('-', 'w'), sys.stdout),
        ((sys.stdout, 'w'), ('-', 'w'), None),
    ]

    for orig_args, new_args, stderr_arg in args:
        try:
            fd = HttpFD(*orig_args)
        except TypeError:
            print(u'ERROR: constructor with %s raised TypeError' % repr(orig_args))
            continue

        opened_file, mode = new_args
        if opened_file != fd._opened_file:
            print

# Generated at 2022-06-24 11:54:44.126096
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    This unit test is written for the purpose of finding bugs in method
    'real_download' of class HttpFD (in module youtube_dl.downloader.http).

    It uses the class itself to download a given file but only a small part
    of it, no bigger than _TEST_FILE_SIZE (500kb currently).
    Then, it compares the downloaded file to the original file.
    The two must be equal, otherwise that would mean that the downloaded file
    is incomplete or incorrect, which would be a bug.
    """
    import random
    import unittest
    from ..utils import encodeFilename


# Generated at 2022-06-24 11:54:55.703269
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os
    import tempfile
    from .compat import compat_http_server
    from .compat import compat_urllib_parse
    from .utils import encodeFilename

    if os.name == 'nt':
        # Requires a Unix-style filesystem
        return

    class DummyServer(compat_http_server.HTTPServer):
        def handle_error(self, *args):
            pass

    class DummyHandler(compat_http_server.BaseHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            self.file = open(encodeFilename(self.path[1:]), 'rb')
            compat_http_server.BaseHTTPRequestHandler.__init__(self, *args, **kwargs)

        def do_GET(self):
            self.send_response(200)

# Generated at 2022-06-24 11:54:58.574181
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # test for HttpFD constructor
    # Create an instance of HttpFD with a fake url
    fd = HttpFD('http://fake_video.org/video.mp4')

    assert fd.url == 'http://fake_video.org/video.mp4'
    # TODO: add test for _real_download function


# Generated at 2022-06-24 11:55:01.418764
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD(YoutubeDL(), dict())
    ret = fd.real_download('http://example.com/video.mp4', '-', 1, 2, 3, 4)
    assert ret is False, 'Did not handle HTTP error codes'
    assert fd.num_retries == 2, 'Did not use retries'



# Generated at 2022-06-24 11:55:07.225697
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD(None, params={
        'nooverwrites': True,
        'continuedl': True,
        'noprogress': True,
        'quiet': True,
    })
    def _hook_temporary_error(e):
        pass
    def _hook_download_error(e):
        pass
    def _hook_content_too_short(e):
        pass
    def _hook_unavailable_format(e):
        pass
    def _hook_post_process(e):
        pass
    fd._hook_temporary_error = _hook_temporary_error
    fd._hook_download_error = _hook_download_error
    fd._hook_content_too_short = _hook_content_too_short
    fd._hook_unavailable_format

# Generated at 2022-06-24 11:55:20.114016
# Unit test for constructor of class HttpFD
def test_HttpFD():
    xfd = HttpFD(
        ydl=object(),
        tmpfilename='-',
        dl=object(),
        params=object(),
        info_dict=object(),
        url=object(),
        filename=object(),
    )
    assert xfd.tmpfilename == '-'
    assert xfd.stream is None

    xfd = HttpFD(
        ydl=object(),
        tmpfilename='a.part',
        dl=object(),
        params=object(),
        info_dict=object(),
        url=object(),
        filename=object(),
    )
    assert xfd.tmpfilename == 'a.part'
    assert xfd.stream is None

    xfd.close()

    xfd.open()
    assert xfd.stream is not None
    xfd.close()


# Generated at 2022-06-24 11:55:32.603541
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    from .post import multipart_encode
    # from .compat import compat_urllib_request, compat_urllib_error
    from .compat import (
        compat_urllib_request, compat_urlparse, compat_urllib_error)
    from .extractor import get_info_extractor
    from .YoutubeDL import YoutubeDL

    _TEST_FILE_SIZE = 200 * 1024

    class _FakeYDL(YoutubeDL):
        def __init__(self):
            pass

        def to_screen(self, message):
            print(message)

    class _FakeHttpFD(HttpFD):
        def __init__(self, ydl, params={}):
            self.ydl = ydl
            self.params = params
            self.downloaded = 0


# Generated at 2022-06-24 11:55:45.898915
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .downloader import HttpFD
    from .utils import encodeArgument
    from .extractor.common import InfoExtractor
    from .compat import (compat_urllib_request,
                         compat_urllib_error,
                         compat_urlparse,
                         compat_urllib_parse_unquote,
                         compat_urllib_parse_urlparse)

    urlopenCount = 0

    class FakeOpener:

        def __init__(self, resultFileObj, headers, url):
            self.resultFileObj = resultFileObj
            self.headers = headers
            self.url = compat_urlparse.urlparse(url)
            global urlopenCount
            urlopenCount += 1


# Generated at 2022-06-24 11:55:58.554612
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if sys.version_info >= (3, 0, 0):
        return True
    from test import mock
    from collections import namedtuple

    Context = namedtuple(
        'Context',
        'data_len block_size open_mode tmpfilename filename data data_len filename '
        'filename resume_len chunk_size tmpfilename stream'
    )
    Block = namedtuple('Block', 'read')

    def get_ctx(**kwargs):
        kwargs.setdefault('open_mode', 'wb')
        kwargs.setdefault('resume_len', 0)
        kwargs.setdefault('block_size', 8192)
        kwargs.setdefault('chunk_size', 0)
        return Context(**kwargs)


# Generated at 2022-06-24 11:56:06.364703
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    fd, testfname = tempfile.mkstemp(dir=tempdir)
    os.write(fd, b'foobarbaz')
    os.close(fd)

    tname = lambda *x: os.path.join(tempdir, *x)
    fd = HttpFD('http://localhost/%s' % testfname,
        { 'nopart': True,
          'continuedl': True,
          'quiet': True,
          'test': True })

    # Test reading
    assert fd.read(3) == b'foo'
    assert fd.read(2) == b'ba'
    assert fd.read(4) == b'rbaz'
    assert f

# Generated at 2022-06-24 11:56:16.947300
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Tests downloading files via method download() HttpFD.
    """
    import shutil
    import tempfile
    import socket
    import random
    old_socket = socket.socket
    old_socket_constructor = socket.socket

# Generated at 2022-06-24 11:56:24.878992
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test instantiation
    fd = HttpFD(
        'http://127.0.0.1/video.mp4', {
            'noprogress': True,
            'test': True,
        }
    )
    # Test get_size()
    assert fd.get_size() == 8192
    # Test read()
    assert fd.read(100) == b'\x00' * 100
    # Test close()
    fd.close()



# Generated at 2022-06-24 11:56:36.977255
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 11:56:42.021199
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test HttpFD constructor
    import tempfile
    file = tempfile.TemporaryFile()
    file.write(b'test')
    file.seek(0)
    info = {'headers': 'header', 'url': 'url', 'status': 'status'}
    fd = HttpFD('test', file, info)
    assert fd.name == 'test'
    assert fd.geturl() == 'url'
    assert fd.info() == 'header'
    assert fd.getcode() == 'status'
    assert fd.read() == b'test'
    # Test writing
    def write_ret(*args, **kwargs):
        raise Exception('should not call fd.write()')
    fd.write = write_ret
    assert fd.write('not') is write_ret



# Generated at 2022-06-24 11:56:52.145316
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import warnings
    from io import BytesIO
    from youtube_dl.utils import urlopen

    # Test all expected arguments and a few variations, using the same URL
    url = 'http://example.com/'
    for test_args in ([], ['key1', 'val1'], ['key1', 'val1', 'key2', 'val2']):
        args = ['filename'] + test_args + [url]
        warn_ctx = warnings.catch_warnings(record=True)
        h = HttpFD(*args)
        assert len(warn_ctx.records) == 0
        assert h.url == url
        assert h.args == tuple(test_args)
        assert h.filename == 'filename'
        assert h.name == '<HttpFD filename>'
        assert h.mode == 'rb'

# Generated at 2022-06-24 11:57:04.232823
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # "Chunked" download, blocks of 1024 bytes
    test_result = HttpFD._real_download(
        dict(
            tmpfilename='-',
            data=FakeData(''),
            stream=sys.stdout,
            block_size=1024,
            max_chunk_size=1024,
            min_chunk_size=1024),
        {},
        True,
    )
    assert test_result is True

    # "Chunked" download, blocks of 128 bytes

# Generated at 2022-06-24 11:57:16.238280
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import random
    import string
    import tempfile
    from .utils import encodeFilename

    def gen_data(length):
        char_set = string.ascii_letters + string.digits + string.punctuation
        return ''.join(random.choice(char_set) for _ in xrange(length))

    class MockUrlOpen(object):
        def __init__(self, headers, data):
            self.headers = headers
            self.data = data
            self.pos = 0
        def info(self):
            return self.headers
        # pylint: disable=no-self-use
        def geturl(self):
            return "http://example.com/"
        # pylint: disable=no-self-use
        def read(self, size=-1):
            r = ''


# Generated at 2022-06-24 11:57:27.733904
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import shutil
    import tempfile
    from .compat import bytes_to_intlist

    class MockYtdl(object):
        def __init__(self, params):
            self.params = params

        def urlopen(self, request):
            class MockResponse(six.StringIO):
                def __init__(self, headers):
                    super(MockResponse, self).__init__()
                    self.headers = headers
                    if 'Content-Length' in headers:
                        self.len = headers['Content-Length']
                        assert self.len > 0
                        self.write(b'0' * self.len)
                        self.seek(0)
                    else:
                        self.len = None
                def info(self):
                    return self.headers


# Generated at 2022-06-24 11:57:39.437733
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys

    sys.stderr = io.BytesIO()
    h = HttpFD(None, {})
    h.report_destination(None)
    h.report_warning('foo')
    h.report_error('bar')
    h.report_retry(None, 99, 100)
    out = sys.stderr.getvalue()
    sys.stderr = sys.__stderr__
    transparent_out = out.replace('\r', '').replace('\n', '')
    assert (transparent_out ==
            '                                                             \rfoo\rbar\r[download]   0.0% of 100.0MiB at  0.00KiB/s ETA 99:00                                     \r')

if __name__ == '__main__':
    test_Http

# Generated at 2022-06-24 11:57:50.701983
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # test usual download
    ctx = DownloadContext(DownloadContext.create_workflow())
    ctx.data = FakeData('foobarbaz')
    ctx.open_mode = 'wb'
    ctx.filename = 'test.mp4'
    ctx.tmpfilename = 'test.mp4.part'
    ctx.data_len = len(ctx.data.data)
    ctx.chunk_size = 0
    ctx.block_size = 1024
    ctx.resume_len = 0
    ctx.stream = None
    ctx.has_range = False
    ctx.start_time = time.time()
    ctx.is_resume = False

    hfd = HttpFD('http://www.example.com/video.mp4',ctx)


# Generated at 2022-06-24 11:57:55.267961
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from io import BytesIO
    from .extractor.common import random_str

    for test_i in range(50):
        for redirects_i in range(5):
            for chunk_size_i in [0, 1, 2, 3, 4, 5]:
                for j in range(10):
                    # Tests for method real_download may be run multiple times.
                    # That is why we should generate a random string to use
                    # as content of a test file to avoid cases when a file
                    # may be considered as already downloaded on a next run.
                    random_bytes = random_str(512).encode('utf-8')
                    http_response = BytesIO(random_bytes)
                    # base_fn = 'httpfd_real_download_%02d_%02d_%02d_%02d' % (test_

# Generated at 2022-06-24 11:58:06.840521
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test constructor of class HttpFD:
    fd = HttpFD('http://www.example.com/')
    assert fd is not None and fd._url == 'http://www.example.com/'
    fd = HttpFD('http://www.example.com/', {})
    assert fd is not None and fd._url == 'http://www.example.com/'
    fd = HttpFD('http://www.example.com/', {'param': 'value'})
    assert fd is not None and fd._url == 'http://www.example.com/' and fd._params == {'param': 'value'}
    fd = HttpFD('http://www.example.com/', {'param': 'value'}, {}, 'destfile', True)
    assert fd

# Generated at 2022-06-24 11:58:12.617302
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class Test(HttpFD):
        def __init__(self, params={}):
            HttpFD.__init__(self, params)
    test = Test()
    assert test.params["prefer_insecure"] is False
    test = Test({'prefer_insecure': True})
    assert test.params["prefer_insecure"] is True
    test = Test({'prefer_insecure': False})
    assert test.params["prefer_insecure"] is False

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:58:18.280756
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Returns True if the test failed, otherwise returns False."""

    def test_get_method():
        class FakeYDL:
            def __init__(self, data, info_dict, filename='-'):
                self.data = data
                self.info_dict = info_dict
                self.filename = filename

            def urlopen(self, url):
                return compat_urllib_request.addinfourl(self.data, self.info_dict, url)

        def get_http_func(method='GET', data_len=None, data_len_diff=0, urlopen_error=None):
            def http_func(ydl, *args, **kwargs):
                data = ydl.data
                info_dict = ydl.info_dict
                filename = ydl.filename
                headers = sanitize_

# Generated at 2022-06-24 11:58:22.521667
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = FakeYDL()
    info_dict = {
        'id': 'test',
        'url': 'http://127.0.0.1:8080/'
    }
    HttpFD(ydl, info_dict)


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:58:28.822402
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Tests whether HttpFD works correctly.

    N.B.: Result is not automatically tested, this is only meant for
    manual inspection of the output.
    """

    test_server = 'http://localhost:8181/'
    urls = [
        'ttt',
        'ttt/',
        'ttt/Bar',
        'ttt/Bar/',
        'ttt/Bar/Baz',
        'ttt/Bar/Baz/',
        'ttt/Bar/Baz/index.html',
        'ttt/Bar/Baz/index2.html',
        ]

    def request_handler(conn):
        data = conn.recv(1024)
        lines = data.split('\n')
        first_line = lines[0]
        method, uri, protocol = first

# Generated at 2022-06-24 11:58:39.249946
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('HttpFD: real_download')

    # Download the whole file
    dst = tempfile.NamedTemporaryFile()
    fd = HttpFD(dst.name, 'https://www.google.com', {})
    fd.real_download({'tmpfilename': dst.name, 'filename': dst.name})

    # Download a piece of a file
    dst = tempfile.NamedTemporaryFile()
    fd = HttpFD(dst.name, 'https://www.google.com', {})
    fd.real_download({'tmpfilename': dst.name, 'filename': dst.name}, test=True)

    # Download a piece of a file using HTTP range header
    dst = tempfile.NamedTemporaryFile()

# Generated at 2022-06-24 11:58:47.724760
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test that it requires urllib
    try:
        del sys.modules['urllib']
        del sys.modules['urllib2']
    except KeyError:
        pass
    else:
        assert 'urllib' not in sys.modules, 'urllib imported before test'
        assert 'urllib2' not in sys.modules, 'urllib2 imported before test'
        with pytest.raises(ImportError):
            HttpFD(None, {})
    # Test that it fails if no url is provided
    with pytest.raises(IOError):
        HttpFD(None, {'url': None})
    # Test that it doesn't work with an empty url
    with pytest.raises(IOError):
        HttpFD(None, {'url': ''})



# Generated at 2022-06-24 11:58:58.903259
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # A HTTP request which returns at least 512 bytes of data with given
    # block size is considered successful.
    # The test is skipped if it takes longer than 5 seconds.
    import requests
    import httplib
    params = {
        'noprogress': True,
        'logger': MockLogger(),
    }
    blocksizes = [1 << n for n in xrange(5, 15)]  # [32, 64, ..., 16384]
    # blocksizes = [1 << n for n in xrange(5, 16)]  # [32, 64, ..., 65536]
    # blocksizes = [1 << n for n in xrange(5, 11)]  # [32, 64, ..., 1024]

# Generated at 2022-06-24 11:59:08.375608
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    >>> fd = HttpFD(
    ...     'http://server.com/file.txt',
    ...     { 'test': 'value' },
    ...     { 'destination': 'file.txt', 'noprogress': True, 'test2': 'value2' })
    >>> fd.test()
    'value'
    >>> fd.test2()
    Traceback (most recent call last):
    KeyError: 'test2'
    >>> fd.destination
    'file.txt'
    >>> fd.noprogress
    True
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:59:14.078314
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    from .compat import http_server
    from .compat import compat_urlparse

    HOST, PORT = '127.0.0.1', 0

    class Handler(http_server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == '/test_range_download':
                self.send_response(200)
                self.send_header('Content-Type', 'video/webm')
                self.send_header('Content-Length', '4096')
                self.send_header('Accept-Ranges', 'bytes')
                self.end_headers()
                self.wfile.write(b'OK')
            elif self.path == '/test_download_chunked':
                self.send_response(200)

# Generated at 2022-06-24 11:59:24.229227
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import compat_urlparse
    from .compat import StringIO

    class FakeYDL:
        params = {
            'nooverwrites': True,
            'continuedl': True,
            'noprogress': True,
            'quiet': True,
            'logger': None,
        }

        def __init__(self, params=None):
            if params is not None:
                self.params.update(params)

        def trouble(self, *args, **kargs):
            pass

        def to_screen(self, *args, **kargs):
            pass

        def urlopen(self, url):
            return FakeUrlOpen(url)

        def temp_name(self, filename):
            return filename + '-download'


# Generated at 2022-06-24 11:59:35.989513
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _test(downloader, params=None):
        params = params or {}
        content = b'testcontent'
        info_dict = {}

        def test_server():
            import socketserver
            import http.server
            class Handler(http.server.BaseHTTPRequestHandler):
                def do_HEAD(self):
                    self.send_response(200)
                    self.send_header('Content-Length', len(content))
                    self.end_headers()

                def do_GET(self):
                    self.send_response(200)
                    self.send_header('Content-Length', len(content))
                    self.end_headers()
                    self.wfile.write(content)

            return socketserver.TCPServer(('0.0.0.0', 0), Handler)

        srv = test_server()
        orig

# Generated at 2022-06-24 11:59:42.540709
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    return HttpFD(params={'test': True}).real_download(
        FakeYtdlUrlRequest(
            'http://localhost/video.mp4?range=0-100',
            'HTTP/1.0 206 Partial Content',
            {'Content-Type': 'video/mp4', 'Content-Range': 'bytes 0-100/1024'},
            b'\x00' * 101),
        {'tmpfilename': '-', 'test': True})


# Generated at 2022-06-24 11:59:52.594877
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(object):
        test_filename = None
        test_data = None

        def __init__(self):
            self.params = {'nooverwrites': True, 'continuedl': True}
            self.to_screen = lambda _, __: None
            self.report_error = lambda _: None
            self.best_block_size = lambda _, __: 1 << 20
            self.slow_down = lambda _, __, ___: None
            self.calc_eta = lambda *_: None
            self.calc_speed = lambda *_: None
            self.report_retry = lambda *_: None
            self.report_resuming_byte = lambda *_: None
            self.report_unable_to_resume = lambda *_: None

# Generated at 2022-06-24 12:00:03.674378
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # unit testing for the HttpFD part of FileDownloader
    # This will not test the whole FileDownloader but only the part that
    # deals with HttpFD.

    class FakeYDL(object):
        """Fake object for FileDownloader"""
        def __init__(self):
            self.params = {}
            self.to_screen = lambda *x: None

    # This is the object we will be testing
    fd = HttpFD(FakeYDL())

    # len()
    datagen = [b'content1', b'content2']
    dataiter = fd.retry_generator(lambda: datagen, 2)().__next__
    ht = HttpFD.ReadWrapper(dataiter, 'rb', lambda *args: None)

    assert len(ht) is None

# Generated at 2022-06-24 12:00:15.411010
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    import threading
    import time

    # simple HTTP server used to test real_download
    # it serves a file (name is provided in the first HTTP request)
    class TestServer(threading.Thread):
        def __init__(self):
            super(TestServer, self).__init__()
            self.daemon = True
            self.host = 'localhost'
            self.port = 0  # 0 - to select an arbitrary unused port
            self.is_ready = threading.Event()
            self.server = None
            self.tmpfiles = []  # used to remove temporary files when server stops
            self.url = None
            self.start()
            # wait for server start
            self.is_ready.wait()


# Generated at 2022-06-24 12:00:24.456804
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    global _TEST_FILE_SIZE
    _TEST_FILE_SIZE = 1000
    hf = HttpFD(None, None)
    # Execute the test only if curl is available
    if hf.have_curl():
        hf.real_download('https://www.google.com/images/srpr/logo11w.png', {'noprogress': True})
        # Testing error when file size is lesser than minimum limit
        # size: 160KB, min_filesize: 1MB
        hf.params['min_filesize'] = 1000000
        hf.real_download('https://www.google.com/images/srpr/logo11w.png', {'noprogress': True})
        # Testing error when file size is lesser than maximum limit
        # size: 160KB, max_files

# Generated at 2022-06-24 12:00:35.970158
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    f = HttpFD(BytesIO(b'abc'), 3)
    f.b = 'def'
    assert f.tell() == 0
    assert f.read(3) == b'abc'
    f.seek(0)
    assert f.read(1) == b'a'
    assert f.read(2) == b'bc'
    assert f.read(2) == b''
    f.seek(0)
    assert f.read() == b'abc'
    f.seek(0)
    assert f.read() == b''
    f.seek(0)
    assert f.read(None) == b'abc'
    f.seek(0)
    assert f.read(None) == b''
    f.seek(0)
    assert f.readline

# Generated at 2022-06-24 12:00:49.523111
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.common import InfoExtractor
    url = 'http://redirector.googlevideo.com/videoplayback?id=c3bdf3e3a7a8b9bf&itag=18&source=picasa&ip=0.0.0.0&ipbits=0&expire=1334650653&sparams=id,itag,source,ip,ipbits,expire&signature=2D54079ECF00B0E690BEC6C9D6E7C823B74BCCB7.B55D39C1B2C9E56C97F3158D9C9E6EEB40C443A2&key=lh1'
    ie = InfoExtractor()
    stream = ie.ydl.urlopen(url)
    fd = Http

# Generated at 2022-06-24 12:01:03.932395
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params={}
    params['progress_hooks'] = []
    params['test'] = True
    params['noprogress'] = False
    params['retries'] = 5
    params['continuedl'] = True
    params['noresizebuffer'] = False
    params['buffersize'] = 16384
    params['nopart'] = False
    params['updatetime'] = True
    params['test'] = True

    # Check that we can instantiate the class
    from .downloader import Downloader
    from .extractor import YoutubeIE

    ydl = Downloader(params)
    ydl.add_info_extractor(YoutubeIE())


# Generated at 2022-06-24 12:01:11.517556
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ctx = {
        'filename': '-',
        'tmpfilename': '-',
        'stream': None,
        'open_mode': 'wb',
        'data': None,
        'resume_len': 0,
        'chunk_size': 0,
        'block_size': None,
        'data_len': None,
        'retries': 20,
        'start_time': time.time(),
        'has_range': False,
    }

    def data_generator(len_):
        if len_ is None:
            while True:
                yield compat_urllib_request.urlopen('http://localhost:9191/test.dat').read()
        else:
            assert len_ <= self._TEST_FILE_SIZE

# Generated at 2022-06-24 12:01:23.267514
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    This function tests method real_download of class HttpFD.
    It creates a dummy file, writes to it and downloads the contents of
    a dummy file. After that, it compares the contents of the dummy file
    and the downloaded file.

    :return: True if contents of the dummy and downloaded files match, False otherwise.
    """
    print('Testing HttpFD.real_download ...')
    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, 'file')
    # Size of the dummy file
    size = 10 * 1024 * 1024
    # Contents of dummy file
    contents = os.urandom(size)
    # The file to which the contents of the downloaded file will be compared
    contents_file = os.urandom(size)
    # Downloaded filename

# Generated at 2022-06-24 12:01:28.590953
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-24 12:01:40.597089
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Test the constructor of class HttpFD."""
    # Non-existing file
    assert HttpFD('/nonexisting', None, None) is None
    # Invalid URL
    assert HttpFD('http://%%%@!@!', None, None) is None
    # Invalid server
    assert HttpFD('http://www.no_such_server.example.com/', None, None) is None
    # Valid file URL
    test_file = get_test_file('test.mp4')
    assert HttpFD(test_file, None, None) is not None
    assert HttpFD(test_file, {'nopart': True}, None) is None
    assert HttpFD(test_file, {'noprogress': True, 'continuedl': False}, None) is not None
    assert HttpFD

# Generated at 2022-06-24 12:01:53.446103
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    class FakeYtdlFD(object):
        def __init__(self, ydl):
            self.ydl = ydl

    def fake_make_dl_dir(self, dl_dir, force):
        return dl_dir

    def fake_hook_progress(self, status):
        return

    class FakeHttpFD(HttpFD):
        def __init__(self, params, ydl):
            super(FakeHttpFD, self).__init__(FakeYtdlFD(ydl), params)

        def undo_temp_name(self, tmpname):
            return tmpname

        def report_error(self, msg, *args):
            print(msg % args)

        def _hook_progress(self, status):
            return fake_hook_progress(self, status)


# Generated at 2022-06-24 12:02:02.338828
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Non-existing URL
    assert HttpFD(None, {'noprogress': True}, None, None).urlopen(URL_NOT_FOUND) is None

    # Non-existing URL with an HTTP redirect to it
    assert HttpFD(None, {'noprogress': True}, None, None).urlopen(URL_REDIRECT_NOT_FOUND) is None

    # Test that a too large file raises an error
    test_url = 'http://localhost/1'
    info = {
        'url': test_url,
        'http_headers': {
            'User-Agent': 'youtube-dl/X.Y.Z',
        },
    }
    # Set up a local HTTP server for testing

# Generated at 2022-06-24 12:02:13.382664
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors
    from .utils import match_filter_func

    sha1s = '41a627c93e28d23ec425c1a8369a08e6e71aa924 sha1:41a627c93e28d23ec425c1a8369a08e6e71aa924'

    # TODO make a test for extractor mismatch
    _, info_dict = next(gen_extractors(('http://www.youtube.com/watch?v=BaW_jenozKc#t=2m25s',), match_filter_func=match_filter_func))


# Generated at 2022-06-24 12:02:21.462802
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = FakeYDL()
    ydl.params['nooverwrites'] = True
    ydl.params['logtostderr'] = False
    downer = HttpFD(ydl, params={'nooverwrites': True})

    # Use a local server to test the actual downloading process
    server_port = find_free_port()
    server = SocketServer.TCPServer(('127.0.0.1', server_port), SimpleHTTPServer.SimpleHTTPRequestHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.start()
    atexit.register(server.shutdown)
    atexit.register(server_thread.join)


# Generated at 2022-06-24 12:02:33.864747
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import urllib.parse
    import random
    import json
    import os

    random.seed(0)
    from .extractor.common import InfoExtractor

    class TestingInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, download_func=None):
            super(TestingInfoExtractor, self).__init__(downloader)
            self._download_func = download_func
            self._fake_title = 'Fake Video'

        @staticmethod
        def suitable(url):
            return False

        def _real_extract(self, url):
            download_info = self._download_func(url)

# Generated at 2022-06-24 12:02:45.541558
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    params = {
        'continuedl': False,
        'nooverwrites': True,
        'outtmpl': '-',  # output to stdout
        'quiet': True,
        'ratelimit': 0,
        'noresizebuffer': False,
    }
    hfd = HttpFD(params, DummyYDL())
    test_url = 'http://ipv4.download.thinkbroadband.com/5MB.zip'
    headers = {'Youtubedl-no-compression': 'True'}
    info = {'url': test_url}
    result = hfd.real_download(info, test_url, headers)
    assert result is True
    assert hfd.ydl.urlopen_counter == 1
    assert hfd.ydl.read_block_counter == 100

# Generated at 2022-06-24 12:02:52.034613
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeDummyYDL(object):
        def __init__(self):
            self.params = {
                'cachedir': False,
                'noresizebuffer': True,
                'test': True,
                'retries': 3,
                'noprogress': True,
            }
        def to_screen(self, msg):
            print(msg)
        def to_stderr(self, msg):
            print(msg, file=sys.stderr)
        def report_error(self, msg):
            raise DownloadError(msg)
        def report_warning(self, msg):
            print('WARNING: %s' % msg, file=sys.stderr)