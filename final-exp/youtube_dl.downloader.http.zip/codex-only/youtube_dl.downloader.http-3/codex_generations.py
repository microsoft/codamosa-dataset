

# Generated at 2022-06-24 11:52:50.955817
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Download a file and write it to stdout
    test_url = 'http://upload.wikimedia.org/wikipedia/commons/7/72/Icterina_cooki.ogg'
    fd = HttpFD(test_url, { 'noprogress': True })
    fsize = int(fd.headers['Content-Length'])
    sys.stdout.write(fd.read(fsize))
    fd.close()

# Generated at 2022-06-24 11:52:59.764511
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # pylint: disable=R0903
    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
        def to_screen(self, *args):
            pass
        def trouble(self, *args):
            pass
        def report_error(self, *args):
            pass
        def report_warning(self, *args):
            pass
        def report_retry(self, *args):
            pass
        def report_resuming_byte(self, *args):
            pass
        def report_unable_to_resume(self, *args):
            pass
        def report_file_already_downloaded(self, *args):
            pass
        def report_destination(self, *args):
            pass

# Generated at 2022-06-24 11:53:09.285470
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading
    import unittest

    from . import _download_retry

    try:
        import ssl
        _DOWNLOAD_TEST_SSL = hasattr(ssl, 'SSLContext')
    except ImportError:
        _DOWNLOAD_TEST_SSL = False

    class MockServer(threading.Thread):
        # Small HTTP Server that serves the data in 'data'
        timeout = 2
        chunk_size = 1024
        def __init__(self, data):
            threading.Thread.__init__(self)
            self.data = data
            self.running = True
            self.server = None
            self.server_port = None
            self.address = None
            self.base_url = None
            self.base_https_url = None

        def run(self):
            self.server = socket

# Generated at 2022-06-24 11:53:17.502905
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import tempfile
    fd = HttpFD()
    tmp = tempfile.mktemp()
    with open(tmp, 'wb') as stream:
        fd._real_download(
            {
                'url': 'https://upload.wikimedia.org/wikipedia/commons/7/72/IPhone_Internals.jpg',
                'params': {'ratelimit': 1024},
            },
            stream)
    try:
        assert os.path.getsize(tmp) == fd._TEST_FILE_SIZE
        os.remove(tmp)
    except AssertionError:
        print('[warning] The test file has incorrect size. It is possible that HttpFD.real_download has changed.')
        raise


# Generated at 2022-06-24 11:53:21.341817
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD('https://github.com/ytdl-org/youtube-dl/raw/master/youtube_dl/version.py')
    print('data_len: %s' % h.data_len)
    data = h.read(10)
    print('read: %s' % (data,))
    data = h.read(10)
    print('read: %s' % (data,))
    h.close()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:53:31.864945
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test sequence (test_seq):
    # 1. Test downloading small file in chunks
    # 2. Test downloading large file in chunks
    # 3. Test downloading small file in a single GET
    # 4. Test downloading large file in a single GET
    # 5. Test resuming downloading after download was interrupted
    # 6. Test resuming downloading when the server is not supporting partial
    #    content request. Test that the already downloaded file is deleted.
    # 7. Test raise ContentTooShortError when the last chunk cannot be
    #    downloaded.
    url1 = 'http://example.com/file1.bin'
    url2 = 'http://example.com/file2.bin'
    url3 = 'http://example.com/file3.bin'
    
    # size of a test file
    fsize = 16384
    # size of a

# Generated at 2022-06-24 11:53:41.816926
# Unit test for constructor of class HttpFD

# Generated at 2022-06-24 11:53:46.943444
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    fname = sys.argv[1]

# Generated at 2022-06-24 11:53:56.561163
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    from .extractor import gen_extractors

    class TestHttpFD(HttpFD):
        def __init__(self, ydl, params, info_dict):
            HttpFD.__init__(self, ydl, params, info_dict)
            self.report_retries = 0

        def report_retry(self, source_error, count, retries):
            self.report_retries += 1
            HttpFD.report_retry(self, source_error, count, retries)

        def report_destination(self, *args, **kwargs):
            pass


# Generated at 2022-06-24 11:53:58.475921
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import pytest
    # TODO
    pytest.skip()

# Generated at 2022-06-24 11:54:08.637090
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test: constructor
    (fd1, n) = test_HttpFD_download()

    # Test: read
    data = read_http_stream(fd1)
    if data is not None:
        data = sub_xen_for_win('HTTP', data)
    assert data == test_HttpFD_data

    # Test: seek
    pos = fd1.seek(17)
    assert pos == 17
    data = read_http_stream(fd1)
    if data is not None:
        data = sub_xen_for_win('3.14', data)
    assert data == test_HttpFD_seek_data
    # Test: close
    fd1.close()
    assert not fd1.closed
    fd1.close()
    assert fd1.closed

    # Test: constructor with

# Generated at 2022-06-24 11:54:19.909334
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # for each of the next 10 numbers, i, we test if real_download can correctly download
    # from a server which sends i / 10 of the requested data, and then close the connection.
    # This means that we are testing if real_download can properly resume when the server
    # closes the connection halfway through.
    for i in range(1,10):
        class Server(http.server.HTTPServer):
            def __init__(self, request_handler, i):
                self.i = i / 10
                return http.server.HTTPServer.__init__(self, ('localhost', 0), request_handler)
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)

# Generated at 2022-06-24 11:54:23.359227
# Unit test for constructor of class HttpFD
def test_HttpFD():
    '''
    Make sure HttpFD constructor doesn't break.
    '''
    fd = HttpFD(params={})



# Generated at 2022-06-24 11:54:34.681849
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_read(byte_count):
        return 'content' if byte_count >= len('content') else None

    def test_readline():
        return 'content'
    fd = HttpFD('http://example.com', {'Content-Type': 'video/mp4'}, test_read, test_readline)

    # Test read
    assert fd.read() == 'content'
    assert fd.read(4) == 'cont'

    # Test seek
    fd.seek(0)
    assert fd.read() == 'content'

    # Test realine
    fd.seek(0)
    assert fd.readline() == 'content'
    assert fd.readline() == ''
    assert fd.readline() == ''

    # Test tell
    fd.seek(1)

# Generated at 2022-06-24 11:54:35.345336
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # It is a placeholder
    return True

# Generated at 2022-06-24 11:54:46.472167
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import os
    import tempfile
    import threading

    # Mock the HttpFD._hook method
    calls_lock = threading.Lock()
    calls = []

    def hook(d):
        with calls_lock:
            calls.append(d)

    class ContentTooShortError(Exception):
        pass

    class HeadRequest(compat_urllib_request.Request):
        def get_method(self):
            return 'HEAD'

    class MockServerHandler(compat_http_server.BaseHTTPRequestHandler):
        def send_head(self):
            if self.path == '/range_not_satisfiable':
                data = 'Range Not Satisfiable'
                self.send_response(416)
                self.send_header('Content-Type', 'text/plain')
                self.send_header

# Generated at 2022-06-24 11:54:57.853409
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Tests the HttpFD.real_download method.
    # It ensures the method can be used to download a small file (731 bytes)
    # using a single connection.
    # It also ensures the method can be used to download a small file (731 bytes)
    # using multiple connection (fragments of 100 bytes).
    from .utils import sanitize_open
    from .utils import encodeFilename


# Generated at 2022-06-24 11:55:03.789793
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test whether HttpFD.__init__ sets the correct start position
    # Return true if test succeeded
    # Return false if test failed
    # Return 'skip' if test was skipped

    # If HttpFD is not available, skip the test
    try:
        HttpFD
    except NameError:
        return 'skip'

    # File names
    tmpfilename = 'tmpfilename'

    # Create test file
    stream = open(tmpfilename, 'wb')
    stream.write(b'0123456789')
    stream.close()

    # Test cases
    class TestCase():
        def __init__(self, url, start_pos, exp_pos, exp_len):
            self.url = url
            self.start_pos = start_pos
            self.exp_pos = exp_pos
            self.exp_

# Generated at 2022-06-24 11:55:16.431738
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import io
    import os
    from io import BytesIO
    from io import SEEK_SET, SEEK_END

    class l1_BytesIO(BytesIO):
        def __init__(self, *args, **kwargs):
            super(l1_BytesIO, self).__init__(*args, **kwargs)
            self._limit = 1024 * 1024 * 2

        def read(self, size=None):
            if self.closed:
                raise ValueError('I/O operation on closed file.')
            if size is None:
                size = -1
            elif not isinstance(size, int):
                raise TypeError('Must be integer, not ' + type(size).__name__)
            if size < 0:
                size = self._limit

# Generated at 2022-06-24 11:55:25.713195
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    from types import ModuleType

    class DummyModule(ModuleType):
        pass

    dummy_module = DummyModule(u'dummy_module')
    dummy_module.params = {}

    # Test normal use cases
    http_fd = HttpFD(dummy_module, u'http://localhost/', u'myfile.tmp', u'wb')
    assert http_fd.name == 'myfile.tmp'
    assert http_fd.tmpfilename == 'myfile.tmp'
    assert http_fd.mode == 'wb'
    assert http_fd.close_called == False

    http_fd.write(b'hello')
    http_fd.close()
    assert http_fd.close_called == True
    http_fd.next_chunk(0, 3)
    assert http_

# Generated at 2022-06-24 11:55:37.563932
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test HttpFD.real_download() method
    from StringIO import StringIO
    from .extractor import gen_extractors
    from .downloader import gen_ydl

# Generated at 2022-06-24 11:55:49.473243
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeToStderr:
        def __init__(self):
            self.str = ''

        def write(self, s):
            self.str += s

        def isatty(self):
            return True

    class FakeUrlOpen:
        def __init__(self):
            self.data = []
            self.headers = {}
            self.times_called = 0

        def add_data(self, data):
            self.data.append(data)

        def add_header(self, header, value):
            self.headers[header] = value

        def read(self, byte_count):
            self.times_called += 1
            return self.data.pop(0)

        def info(self):
            return self.headers

    class FakeYDL:
        def __init__(self):
            self

# Generated at 2022-06-24 11:56:01.469459
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from types import SimpleNamespace

    raise unittest.SkipTest
    # TODO: Add support for this test in Travis, currently it fails with
    # OSError: [Errno 38] Function not implemented on Linux
    # (OSError: [Errno 1] Operation not permitted on Mac OS X,
    #  OSError: [Errno 95] Operation not supported on Windows)
    class HttpFDSimpleNamespace(SimpleNamespace):
        def __init__(self, **kwargs):
            super(HttpFDSimpleNamespace, self).__init__(**kwargs)
            self.stream = None


# Generated at 2022-06-24 11:56:13.548368
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Download a small file
    # version 1: we expect the whole file in a single read() operation
    # version 2: we expect the whole file in two read() operationso
    # version 3: we expect the whole file in several read() operations
    for version in [1, 2, 3]:
        class HTTPHandler(compat_urllib_request.HTTPHandler):
            def __init__(self, path, buffer_len):
                compat_urllib_request.HTTPHandler.__init__(self)
                self.path = path
                self.buffer_len = buffer_len
                self.block_size = 2 * self.buffer_len

            def http_open(self, req):
                self.req = req

# Generated at 2022-06-24 11:56:20.393071
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import copy
    class FakeYDL:
        params = {'test': True, 'noprogress': True, 'quiet': True}
        def to_screen(self, msg):
            print('[debug] ' + msg)
        def to_stderr(self, msg):
            print('[error] ' + msg)
        def urlopen(self, url_request):
            class FakeUrlOpen:
                def __init__(self, headers, body):
                    self.headers = headers
                    self.__body = body
                    self.__pos = 0
                def info(self):
                    return self.headers
                def read(self, n):
                    if self.__pos >= len(self.__body):
                        return b''
                    r = self.__body[self.__pos:self.__pos + n]
                   

# Generated at 2022-06-24 11:56:31.139213
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Test ability to download only part of a file and then download a whole file at once.
    A real HTTP server is used to serve the file.
    """
    # _TEST_FILE_SIZE is a number of bytes to download at once
    # before stopping a test, to speed-up testing process
    _TEST_FILE_SIZE = 10000

    class TestServer(SocketServer.TCPServer):
        allow_reuse_address = True

    class TestHandler(SimpleHTTPServer.SimpleHTTPRequestHandler):
        def send_head(self):
            path = self.translate_path(self.path)
            if os.path.isdir(path):
                return self.send_error(404, "No permission to list directory")
            f = None
            ctype = self.guess_type(path)

# Generated at 2022-06-24 11:56:38.966095
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    hfd = HttpFD()
    assert hfd.real_download(dict(url='http://test.test/test.test', params={'test': 'test'}), '-', False)
    sys.stdout = old_stdout
    sys.stderr = old_stderr
test_HttpFD_real_download()


# Generated at 2022-06-24 11:56:50.359767
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.youtube import YoutubeIE
    from .compat import compat_str

    def test_download_url(url):
        ie = YoutubeIE(params={
            'outtmpl': '-',
            'fixup': 'none',
        })

        class TestInfoExtractor(YoutubeIE):
            def _real_extract(self, url):
                info = YoutubeIE._real_extract(self, url)

                # This should not be set as it cannot be determined.
                # See issue #6065.
                del info['end_time']

                return info

        ie = TestInfoExtractor(params={
            'outtmpl': '-',
            'fixup': 'none',
        })
        info = ie.extract(url)

        return info



# Generated at 2022-06-24 11:57:03.414762
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create an instance
    h = HttpFD(None, {'noprogress': True}, None)
    # Use the download method
    # The file test was selected using the following command line:
    #  youtube-dl --get-filename --video-id cYplvwBvGA4

# Generated at 2022-06-24 11:57:15.650882
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test normal constructor
    fd = HttpFD('http://localhost/', params={'noprogress': True})
    # Test constructor with headers
    fd = HttpFD('http://localhost/', params={'noprogress': True}, headers={'Range': 'bytes=0-10'})
    # Test constructor with HTTP Error
    try:
        fd = HttpFD('https://localhost/', params={'noprogress': True})
        assert False
    except compat_urllib_error.HTTPError as e:
        assert e.code == 403
    # Test constructor with invalid URL

# Generated at 2022-06-24 11:57:26.785202
# Unit test for constructor of class HttpFD
def test_HttpFD():
    '''
    This is a simple unittest for the constructor of HttpFD.
    It assumes that HTTPBasicDownloader is available and that the
    file it downloads is small and the connection is good.
    '''

    d = HttpFD(
        YouTubeDL({}),
        {
            'url': 'http://quirkysoft.com/test/test.txt',
            'http_headers': {'Range': 'bytes=0-7'},
        },
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        True,
        False)
    data = d.read(4)
    d.close()
    assert(data == 'test')
    print('Test passed.')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:57:28.608391
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import doctest
    doctest.run_docstring_examples(HttpFD.real_download, globals())

# Generated at 2022-06-24 11:57:34.653095
# Unit test for constructor of class HttpFD
def test_HttpFD():
    require(
        'wget',
        'python3',
        reason='tests for HttpFD are not run')

    import io
    import http.server
    import socketserver
    import threading
    import urllib.request
    import shutil

    import youtube_dl.utils
    from youtube_dl.utils import encodeArgument

    port = 9999
    httpd_server = None
    test_file_size = 200000
    test_file_name = 'testfile'
    url = 'http://127.0.0.1:%s/%s' % (port, test_file_name)
    test_file_path = os.path.abspath('%s.part' % test_file_name)


# Generated at 2022-06-24 11:57:43.431059
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def test_exists(filename):
        return os.path.exists(filename)

    def test_rm(filename):
        os.remove(filename)

    class TestFD(HttpFD):
        def __init__(self, *args, **kwargs):
            HttpFD.__init__(self, *args, **kwargs)
            self._num = 0

        def _prepare_and_start_frag_download(self, filename, info):
            self._num += 1
            return (self._num, os.path.join(info['id'], str(self._num)))

    def g(s):
        return bytes(s, 'utf-8')

    data = g('a' * 100 + 'b' * 100 + 'c' * 100)
    data2 = g('x' * 100)
   

# Generated at 2022-06-24 11:57:54.433562
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class Dummy:
        def __init__(self, **kw):
            self.__dict__.update(kw)
    class DummyYDL:
        def __init__(self, **kw):
            self.__dict__.update(kw)

        @staticmethod
        def to_screen(*args, **kargs): pass
        @staticmethod
        def to_stderr(*args, **kargs): pass
        def trouble(*args, **kargs): pass
        def report_error(*args, **kargs): pass
        def report_warning(*args, **kargs): pass
        def slow_down(*args, **kargs): pass


# Generated at 2022-06-24 11:58:05.637177
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    This unit test is intended to verify that download method is working fine. If this test fails
    it may indicate that files are not being downloaded as expected.
    """
    import sys
    import tempfile
    import shutil
    import doctest

    class TestFD(HttpFD):
        def __init__(self, params, ydl):
            self.params = params
            self.ydl = ydl
            self.retcode = 1
            self.destination = '-'
            self.downloaded_bytes = 0
            self.info = {
                'url': "https://github.com/rg3/youtube-dl/archive/master.zip",
                'title': 'Youtube DL Test',
            }
            self.dest_bytes = None


# Generated at 2022-06-24 11:58:16.225796
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import io
    # io.BufferedRandom isn't supported in Python <3.3
    if hasattr(io, 'BufferedRandom'):
        hfd = HttpFD('http://foobar/', {'noprogress': True, 'retries': 0})
        assert(isinstance(hfd.fobj.raw, io.BufferedRandom))
    hfd = HttpFD('http://foobar/', {'noprogress': True, 'retries': 0})
    assert(isinstance(hfd.fobj.raw, io.BufferedIOBase))
    hfd = HttpFD('http://foobar/', {'noprogress': True, 'retries': 0})
    assert(isinstance(hfd.fobj.raw, io.IOBase))

# Generated at 2022-06-24 11:58:25.546018
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # test redirects
    url = 'http://www.youtube.com/v/8l-VmunYhQs'
    fd = HttpFD('--flat-playlist', url)
    assert fd.url == 'https://www.youtube.com/watch?v=8l-VmunYhQs'
    url = 'http://i.ytimg.com/vi/8l-VmunYhQs/hqdefault.jpg'
    fd = HttpFD('--flat-playlist', url)
    assert fd.url == 'https://i.ytimg.com/vi/8l-VmunYhQs/hqdefault.jpg'

    # test unicode

# Generated at 2022-06-24 11:58:27.308869
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD('http://example.org')



# Generated at 2022-06-24 11:58:38.226504
# Unit test for constructor of class HttpFD
def test_HttpFD():

    # Open the test file and read the first few characters
    h = HttpFD(test_url, test_dest, params)
    (data, tmpfile) = h.readblock(0, 60)
    h.close()

    # Print information about the test
    test = 'Downloading and printing two blocks from a test file (reusing existing connection)'
    sys.stdout.write('Testing %s ...\n' % test)

    if (tmpfile == test_dest and
        data == 'This is a test file for youtube-dl.\nVisit '):
        sys.stdout.write('Test of %s successful.\n' % test)
        success = success + 1
    else:
        sys.stdout.write('Test of %s failed.\n' % test)


# Generated at 2022-06-24 11:58:46.905302
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import HEADRequest
    from .compat import compat_http_server

    # should create temp directory and change dir there
    tmpfilename = tempfile.NamedTemporaryFile(prefix='youtube-dl-test_').name
    filename = 'test.mp4'

    # should test that the downloaed file is actually a proper mp4 file
    # (e.g. check with the mime type)
    # make sure there is no such file
    assert not os.path.exists(filename)


# Generated at 2022-06-24 11:58:58.361562
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class DummyYDL(object):
        params = {}
        def __init__(self):
            self.to_stderr = lambda s: sys.stderr.write(s)
            self.to_screen = lambda s: sys.stdout.write(s)
        def trouble(self, s, tb=None):
            sys.stderr.write('\n%s\n' % s)
            if tb:
                sys.stderr.write(''.join(traceback.format_tb(tb)))
            sys.stderr.write('\n')
            sys.stderr.flush()
            os.kill(os.getpid(), signal.SIGINT)
        def urlopen(self, req):
            return _url_open(req)
    ydl = DummyYDL

# Generated at 2022-06-24 11:59:08.969289
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # see HttpFD.__init__ comments for arguments explanation
    url = 'http://example.com/'
    start = 10
    end = 90
    duration = None
    chunk_size = 80
    params = {}
    fd = HttpFD(url, start, end, duration, chunk_size, params)
    urlopen = fd._urlopen
    assert urlopen == fd.urlopen
    assert urlopen.geturl() == url
    assert urlopen.get_method() == 'GET'
    range_headers = urlopen.headers.get('Range')
    assert range_headers == 'bytes=%d-%d' % (start, end)
    assert fd.pos == 0
    assert fd.closed is False
    assert fd.size == chunk_size
    assert fd.duration == duration
   

# Generated at 2022-06-24 11:59:14.135261
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    f = HttpFD(BytesIO('foobar'), 'http://www.example.org/', 'test.mp4')
    s = f.read()
    assert s == b'foobar'
    f.close()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:59:20.041925
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    >>> t = HttpFD(sanitize_open('-'), 'wb')
    >>> t.write(b'hello world')
    11
    >>> t.close()
    >>> t = HttpFD(sanitize_open('-'), 'wb', 7)
    >>> t.write(b'hello')
    5
    >>> t.close()
    """
    pass


# Generated at 2022-06-24 11:59:27.303896
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, 611)
    assert fd.real_download == 611
    assert fd.len == 611
    assert fd.read(None) == ''
    assert fd.read(1000) == ''
    assert fd.read(100) == ''
    assert fd.read() == ''

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 11:59:33.990749
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import random
    import tempfile

    # Test with one argument
    fd = HttpFD(urllib.request.urlopen('http://www.google.com'), 'wb')
    fd.close()
    fd = HttpFD(urllib.request.urlopen('http://www.google.com'), 'rb')
    fd.close()

    # Test with two arguments and their combination
    fd = HttpFD(urllib.request.urlopen('http://www.google.com'), 'wb', tempfile.TemporaryFile())
    fd.close()

    fp = tempfile.TemporaryFile()
    fd = HttpFD(fp, 'wb', urllib.request.urlopen('http://www.google.com'))
    fd.close()

    fp

# Generated at 2022-06-24 11:59:42.908639
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors
    import sys
    from .extractor.common import InfoExtractor
    from .utils import std_headers
    from .downloader import YoutubeDL
    from .compat import compat_urllib_request

    url = sys.argv[1]

    ie = InfoExtractor()
    ie.add_info_extractor(_ALL_CLASSES[YoutubeIE.ie_key()])

    fd = HttpFD(url, ie, YoutubeDL(params={}), std_headers)
    fd.download()



# Generated at 2022-06-24 11:59:47.766974
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL:
        def urlopen(self, req):
            class FakeHTTPResponse:
                def __init__(self, headers, body):
                    self.headers = headers
                    self.body = body

                def info(self):
                    return self.headers

                def read(self, size):
                    return self.body

            class TestException(Exception):
                pass

            if req.headers.get('Range') == 'bytes=0-499':
                return FakeHTTPResponse(
                    {
                        'Content-Length': '500',
                        'Content-Range': 'bytes 0-499/1000',
                    },
                    ''.join(map(chr, range(256))).encode('ascii'))
            elif req.headers.get('Range') == 'bytes=500-999':
                return

# Generated at 2022-06-24 11:59:55.864868
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url = 'http://www.youtube.com/get_video_info?video_id=BaW_jenozKc'

    class DummyFD:

        def __init__(self, blocks):
            self.blocks = list(blocks)
            self.i = 0

        def read(self, n):
            if self.i >= len(self.blocks):
                return b''
            else:
                curr_i = self.i
                self.i += 1
                return self.blocks[curr_i]

        def info(self):
            return {
                'Content-length': str(sum(map(len, self.blocks))),
                'Last-modified': 'Fri, 28 Feb 2014 15:43:02 GMT',
                'Random-shit': 'wtf',
            }

    # all blocks the same length


# Generated at 2022-06-24 12:00:07.774026
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class RealDownloadTestReport(object):

        def __init__(self, test):
            self.test = test

        def to_screen(self, msg):
            self.test.assertTrue(isinstance(msg, compat_str))

        def to_stderr(self, msg):
            self.test.assertTrue(isinstance(msg, compat_str))

        def trouble(self, msg, tb=None):
            self.test.assertTrue(isinstance(msg, compat_str))
            if tb is not None:
                self.test.assertTrue(isinstance(tb, compat_str))

        def report_error(self, msg, tb=None):
            self.test.assertTrue(isinstance(msg, compat_str))

# Generated at 2022-06-24 12:00:16.196327
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL:
        def __init__(self):
            self.to_screen_string = ''
            self.to_stderr_string = ''

        def fix_url(self, url):
            assert(url)
            return url

        def report_error(self, msg):
            assert(msg)
            self.to_stderr_string += msg + '\n'

        def report_retry(self, msg, count, retries):
            assert(msg)
            self.to_stderr_string += msg + '\n'

        def report_file_already_downloaded(self, filename):
            assert(filename)
            self.to_screen_string += 'File %s already fully downloaded' % filename

        def report_unable_to_resume(self):
            self.to

# Generated at 2022-06-24 12:00:21.728948
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import tempfile
    import urllib.request
    import urllib.error
    import http.client

    TEST_FILE_SIZE = 1000 * 1024 * 1024 + 1
    TEST_FILE_URL = ('https://pypi.python.org/packages/source/y/youtube-dl/'
        'youtube-dl-2015.08.08.tar.gz')
    TEST_FILE_NAME = os.path.join(tempfile.gettempdir(), 'HttpFD_real_download_test')
    if os.path.exists(TEST_FILE_NAME):
        os.remove(TEST_FILE_NAME)
    assert not os.path.exists(TEST_FILE_NAME)

    class ProgressHook(object):
        def __init__(self):
            self.downloaded_bytes = 0

# Generated at 2022-06-24 12:00:25.722317
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import doctest
    doctest.testmod(optionflags=(doctest.REPORT_ONLY_FIRST_FAILURE | doctest.ELLIPSIS))

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-24 12:00:37.222120
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    filename = '-'
    tmpfilename = None
    resume_len = 0
    block_size = 1024
    open_mode = 'wb'
    data = None
    data_len = None
    stream = None
    start_time = time.time()

    ctx = contextlib.nested(
        compat_urllib_request.urlopen('http://www.google.com'),
        tempfile.NamedTemporaryFile()
    )
    ctx = contextlib.nested(
        (filename, tmpfilename, resume_len, block_size, open_mode, data, data_len, stream, start_time),
        ctx
    )
    ctx = contextlib.nested(ctx, ctx.__enter__())

# Generated at 2022-06-24 12:00:46.270907
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Tests HttpFD.real_download() method."""

    from .utils import FakeYDL
    from .extractor.common import InfoExtractor

    ie = InfoExtractor(FakeYDL(), {})
    ie.set_downloader(HttpFD())
    ie.params['operate_null'] = True
    ie.add_info_extractor(lambda i: ({'id': 'a', 'url': 'http://localhost:8080/', 'ext': 'mp4'}, [{'url': 'http://localhost:8080/'}]))

    # Test file download

# Generated at 2022-06-24 12:00:54.238314
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def make_test_downloader(params=None):
        from youtube_dl.YoutubeDL import YoutubeDL
        return YoutubeDL(params)

    # Test basic functionality
    d = make_test_downloader()
    hd = HttpFD(d, d.params)
    assert isinstance(hd, HttpFD)
    assert hd.ydl is d

    # Test several parameter values
    for test_param in ('continuedl', 'nooverwrites', 'ratelimit', 'retries', 'noresizebuffer', 'test', 'min_filesize', 'max_filesize'):
        d.params[test_param] = 'test_value'
        hd = HttpFD(d, d.params)
        assert getattr(hd, test_param) == 'test_value'
        del d.params

# Generated at 2022-06-24 12:01:07.073131
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import get_info_extractor

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = YoutubeDL()

    class FakeYDL:
        def __init__(self):
            self.params = {}

    ydl = FakeYDL()

    ie = get_info_extractor(ydl, url)
    info = ie.extract(url)
    assert info['id'] == 'BaW_jenozKc'
    title = info['title']
    assert title == 'youtube-dl test video "\'/\\ä↭𝕐"'

    fd = HttpFD(ydl, url, info['formats'], info)
    filename, info = fd.download()
    assert filename == title + get_extension(info)
   

# Generated at 2022-06-24 12:01:13.476079
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _check_file_equal(safe_filename, filename):
        with io.open(filename, 'rb') as f:
            if _TEST_FILE_SIZE != os.path.getsize(filename):
                return False
            data = f.read(_TEST_FILE_SIZE)
        with io.open(safe_filename, 'rb') as f:
            if _TEST_FILE_SIZE != os.path.getsize(safe_filename):
                return False
            safe_data = f.read(_TEST_FILE_SIZE)
        return data == safe_data

    tempdir = tempfile.mkdtemp()
    safe_filename = os.path.join(tempdir, 'safe_file')
    # Some webservers (e.g. YouTube) know how to handle Range headers

# Generated at 2022-06-24 12:01:25.491520
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import tempfile
    import traceback
    import unittest
    import warnings
    import youtube_dl
    # We do not use unittest.TestCase here because we need to test early
    # (HttpFD.real_download is called by __init__)

    class NullFD:
        def read(self, size):
            return b'\0' * size

    class TestHttpFD(youtube_dl.downloader.http.HttpFD):
        _TEST_FILE_SIZE = 20
        _TEST_RETRIES = 3

        def __init__(self, ydl, params, test_ctx):
            super(TestHttpFD, self).__init__(ydl, params)
            self._test_ctx = test_ctx
            self._test_ctx['ctx_stack'] = []


# Generated at 2022-06-24 12:01:37.954345
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import urllib
    import tempfile
    import random
    import shutil

    file_size = 50
    range_size = 5
    num_modes = 5

    def bad_downloader(range_start=None, range_end=None, content_length=file_size, real_download=False, test_file=None):
        headers = {}
        if range_start is not None:
            headers.update({'Range': 'bytes=%s-%s' % (range_start, range_end)})
        req = sanitized_Request('http://localhost/%s' % test_file, headers=headers)
        retval = urllib.urlopen(req).read()

# Generated at 2022-06-24 12:01:47.311982
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # pylint: disable=W0612
    # W0612: Unused variable 'dummy'
    valid_urls = [
        # youtube
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        'http://youtu.be/BaW_jenozKc',
        'https://www.youtube.com/watch?v=BaW_jenozKc',
        'https://youtu.be/BaW_jenozKc',
        # github
        'http://github.com',
        'https://github.com',
    ]
    for url in valid_urls:
        try:
            HttpFD(url, {'noprogress': True}, None)
        except Exception as err:
            print('Unable to handle ' + url, err)

# Generated at 2022-06-24 12:01:58.406898
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD('http://test.com/test.mp4', {'noprogress': True}, 'test-uid')
    fd.real_download(
        'test1.mp4', {'test': True, 'format': 'best','min_filesize': 1024*1024},
        fd.ydl.urlopen(sanitized_Request('http://test.com/test.mp4')),
        1024*1024, 1024)
    assert os.path.isfile('test1.mp4') and os.stat('test1.mp4').st_size == 1024*1024
    os.remove('test1.mp4')
    fd = HttpFD('http://test.com/test.mp4', {'noprogress': True}, 'test-uid')

# Generated at 2022-06-24 12:02:04.595310
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    assert HttpFD(BytesIO(b'data'), None, {'ytdl_url': 'http://example.com', 'ytdl_filename': 'example.mp4'}).size() == 4

# If a file:// URL points to a local HTML file, attempt to find and return the
# URL of the real media file linked by the <video> element

# Generated at 2022-06-24 12:02:18.185844
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import *
    from .extractor import *
    from .compat import *

    class MockYDL(object):
        def __init__(self):
            self.preferredcodec = 'm4a'
            self.preferredquality = 0
            self.params = {'nooverwrites': True}
            self.socket_timeout = 5
            self.noprogress = True
            self.progress_hooks = []
            self.add_info_dict = False
            self.to_screen = False
            self.to_stderr = lambda x: None
            self.to_stdout = lambda x: None

        def urlopen(self, request):
            raise ValueError('This is just a test')

        def report_warning(self, message):
            pass

    fd = HttpFD

# Generated at 2022-06-24 12:02:30.273099
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import socket
    from .compat import compat_urllib_error, compat_urllib_request
    from .utils import encodeFilename

    # Uncomment for running this unit test
    # from .utils import YoutubeDLHandler
    # from .YoutubeDL import YoutubeDL
    # urllib.request.install_opener(
    #     urllib.request.build_opener(YoutubeDLHandler(YoutubeDL())))

    # This unit test should be completed.
    # It should download a small test file and then check its contents.
    # It also should test both range downloading and single request downloading.
    # HttpFD.real_download = _real_download
    # HttpFD._TEST_FILE_SIZE = 1024


# Generated at 2022-06-24 12:02:35.926365
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # test stream
    stream = io.BytesIO(b'foobar')
    hfd = HttpFD(stream, 'rb')
    assert hfd.read(3), b'foo'
    assert hfd.read(3), b'bar'
    assert hfd.read(3), b''
    assert hfd.read(3), b''
    assert hfd.close() is None

    # test file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b'foobar')
        f.close()
        hfd = HttpFD(f, 'rb')
        assert hfd.read(3), b'foo'
        assert hfd.read(3), b'bar'
        assert hfd.read(), b''
        assert hfd.read(), b''
       

# Generated at 2022-06-24 12:02:41.763108
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _test_real_download(params):
        class DummyYDL:
            def urlopen(self, *args, **kwargs):
                raise compat_urllib_error.URLError(str(params))
        return HttpFD(DummyYDL(), params).real_download(None, None)

    assert not _test_real_download({'retries': 0})
    assert _test_real_download({'retries': 1})
    assert _test_real_download({'retries': 2})



# Generated at 2022-06-24 12:02:51.541274
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Prepares a test server
    import BaseHTTPServer
    server = BaseHTTPServer.HTTPServer(('127.0.0.1', 0), BaseHTTPServer.BaseHTTPRequestHandler)
    server_port = server.server_port
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.setDaemon(True)
    server_thread.start()
    # Waits for the server to start
    for i in range(100):
        time.sleep(0.01)
        try:
            urllib2.urlopen('http://127.0.0.1:%s/' % server_port)
            break
        except urllib2.URLError:
            pass
    # Checks HttpFD