

# Generated at 2022-06-12 17:00:02.910676
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import base64
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .compat import str_to_bytes
    from .utils import encode_data_uri
    class _TestInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            super(_TestInfoExtractor, self).__init__(downloader)

        def _real_initialize(self):
            return

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test video',
                'description': 'test description',
                'ext': 'mp4',
            }


# Generated at 2022-06-12 17:00:17.189047
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        a = HttpFD()
    except:
        a = None
    assert a is None

    try:
        a = HttpFD({})
    except:
        a = None
    assert a is None

    try:
        a = HttpFD({'url': ''})
    except:
        a = None
    assert a is None

    try:
        a = HttpFD({'url': ''}, {})
    except:
        a = None
    assert a is None

    try:
        a = HttpFD({'url': ''}, {'outtmpl': 'test.tmp'})
    except:
        a = None
    assert a is not None


# Generated at 2022-06-12 17:00:20.133798
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(None, 'http://www.google.com/')
    if h.url != 'http://www.google.com/':
        print('test failed: %r' % h.url)



# Generated at 2022-06-12 17:00:34.195833
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .downloader import FileDownloader
    from .utils import std_headers

    class MyFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            FileDownloader.__init__(self, ydl, params)

        def process_info(self, info_dict):
            print(info_dict)

        def report_retry(self, error, count, retries):
            pass


# Generated at 2022-06-12 17:00:41.901097
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test without parameters
    hfd = HttpFD(None, {})

    # Test with empty parameter name
    hfd = HttpFD(None, {'': None})

    # Test with empty parameter value
    hfd = HttpFD(None, {'noprogress': None})

    # Test with unknown parameter name
    hfd = HttpFD(None, {'unknown_parameter': None})



# Generated at 2022-06-12 17:00:54.733448
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io

    # io.BytesIO in python 2 cannot handle unicode.
    # So, encode str (unicode in python 2) to bytes using utf-8 encoding.
    tmp_content = b'12345' * (2 ** 15) + b'67890'
    tmp_stream = io.BytesIO(tmp_content)
    size = len(tmp_content)
    # Construct original data_len for different cases
    data_len = [None, 1234567, size, tmp_content.find(b'67890'), size - 1]

    # Construct expected range_header for different cases
    range_header = [(None, None), (1234567, 1234567), ('0-', size - 1), ('32768-', size - 1), ('0-32767', 32768)]

    # Construct expected range_start and range_end

# Generated at 2022-06-12 17:01:05.649532
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test constructor
    u = compat_urllib_request.urlopen('http://www.google.com')
    h = HttpFD(u, None)
    assert isinstance(h, HttpFD) and isinstance(h, FileDownloader)

    # Test read method
    s = u.read(5)
    sh = h.read(5)
    assert s == sh and isinstance(sh, type(s))

    # Test close method
    assert h.close() is None

if __name__ == '__main__':
    # Run tests if called directly
    test_HttpFD()
    print('Tests successful')

# Generated at 2022-06-12 17:01:19.379325
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    def data_generator(size):
        for i in range(size):
            yield bytes((i % 256,))

    class FakeData(object):
        blocks = []
        block_size = 10
        position = -1

        def read(self, size):
            self.position += 1
            if self.position == len(self.blocks):
                return b''
            else:
                return self.blocks[self.position]

        def info(self):
            info = {'Content-Length': len(self.blocks) * self.block_size}
            return compat_http_client.HTTPMessage(StringIO.StringIO(
                'Content-Length: %s\r\n' % info['Content-Length']))

    class FakeSocketError(Exception):
        errno = errno.ECONNRESET

   

# Generated at 2022-06-12 17:01:32.154272
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class MockYtdl:
        def __init__(self, params):
            self.params = params
        def report_error(self, *args, **kwargs):
            print('ERROR: %s' % args[0])
        def report_retry(self, *args, **kwargs):
            print('RETRY: %s' % args[0])
        def report_destination(self, *args, **kwargs):
            print(args[0])
        def report_progress(self, *args, **kwargs):
            print(args[0]['_percent_str'])
        def to_screen(self, *args, **kwargs):
            print('STATUS: %s' % args[0])

# Generated at 2022-06-12 17:01:43.305667
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import hashlib
    import tempfile
    import subprocess
    import shutil
    import re
    import os.path

    # Ensure chardet is present, otherwise this test won't work
    try:
        import chardet
    except ImportError:
        sys.stderr.write('Skipping test_HttpFD_real_download: chardet not found\n')
        return

    from youtube_dl.utils import encodeFilename

    from .test_downloader import MockYDL
    from .http_server import Server, Handler

    server = Server(Handler)
    port = server.port
    td = tempfile.mkdtemp(prefix='youtube-dl-test_HttpFD_real_download-')
    old_wd = os.getcwd()

# Generated at 2022-06-12 17:02:26.157730
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _run_test(fd, test_params):
        for attr in 'test_result test_retries test_exceptions test_min_filesize test_max_filesize test_postprocessors'.split():
            value = test_params.pop(attr, None)
            if value is None:
                continue
            setattr(fd, '_TEST_%s' % attr.upper(), value)
        assert not test_params
        # This test is not indented for ratelimit test.
        fd.params['noprogress'] = True
        return fd.real_download(
            {'url': 'dummy_url', 'test': True},
            'dummy_filename',
            info_dict={'_test': True})
    # Successfull download

# Generated at 2022-06-12 17:02:38.588960
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import shutil
    import tempfile
    from .compat import urlopen

    def fake_best_block_size(bytes_left, elapsed_time):
        return min(256, bytes_left)

    # Save the original method for test verification
    original_best_block_size = HttpFD.best_block_size
    HttpFD.best_block_size = fake_best_block_size

    # The original method is restored after the test
    def restore():
        HttpFD.best_block_size = original_best_block_size
    request.addfinalizer(restore)

    def fake_calc_eta(start, now, total, completed):
        return None

    # Save the original method for test verification
    original_calc_eta = HttpFD.calc_eta
    HttpFD.calc

# Generated at 2022-06-12 17:02:51.335011
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import threading
    import os
    import signal
    import shutil
    import socket
    import time
    import stat
    import ssl
    from .utils import encodeFilename, prepend_extension
    from .DownloadContext import DownloadContext
    from .compat import (compat_str, compat_urllib_parse_urlparse, compat_urllib_error, compat_urllib_request,
                         compat_urllib_request_urlopen, compat_http_client, compat_urllib_error_URLError,
                         compat_http_client_HTTPException, compat_http_client_IncompleteRead)
    from .extractor import gen_extractors

    retval = True
    fn = prepend_extension('http-test', 'tmp')
    fn = encodeFilename(fn)

# Generated at 2022-06-12 17:02:58.462902
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Call method real_download of class HttpFD and check whether it behaves as expected.
    """
    def get_test_data():
        """
        Return first bytes of file UPLOAD_VIDEO_FILENAME.
        Assumption: UPLOAD_VIDEO_FILENAME is a video file.
        """
        fd = open(UPLOAD_VIDEO_FILENAME, 'rb')
        fd.seek(0)
        return fd.read(100)

    # Unsuccessful downloads
    # - download filename is None
    params = {'noprogress': True}
    err = 'Missing filename'
    fd = HttpFD(params)
    url = 'http://localhost/%s' % UPLOAD_VIDEO_FILENAME
    data = get_test_data()
    bad_http_

# Generated at 2022-06-12 17:03:00.513610
# Unit test for constructor of class HttpFD
def test_HttpFD():
    data = (b'a' * 1024 + b'\n') * 16
    f = io.BytesIO(data)
    fd = HttpFD(f, 1024, 1024)
    for (i, line) in enumerate(fd):
        assert line == b'a' * 1024 + b'\n'


# Generated at 2022-06-12 17:03:05.294404
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test constructor without a filename
    HttpFD(None, {}, None, None)

    # Test constructor with a filename
    HttpFD('filename', {}, None, None)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 17:03:15.798109
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ytdl = YoutubeDL(YDLAudioExtractors())

    # we test each extractor
    for ie in ytdl._ies:
        if not hasattr(ie, '_TEST'):
            continue
        url = ie._TEST
        # we test both with and without the 'test' parameter
        for test in True, False:
            test_params = {'format': 'bestaudio/best', 'nooverwrites': True, 'quiet': True, 'simulate': True, 'noplaylist': True}
            if test:
                test_params['test'] = True
            ytdl.params.update(test_params)
            # we should get the same result when downloading twice the same file

# Generated at 2022-06-12 17:03:24.033810
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(test_http_headers_1, test_http_test_data_1, 'wb')
    assert fd.geturl() == 'http://testserver.com/test/'
    assert fd.getcode() == 200
    assert fd.info().getheaders('Content-Length') == ['38']
    assert fd.info().getheaders('Content-Type') == ['text/plain; charset=utf-8']
    assert fd.info().getheaders('Content-Encoding') == ['gzip']
    assert fd.read(4) == b'Lorem'
    assert fd.read(4) == b' ips'
    assert fd.read() == b'um dolor sit amet, consectetur adipiscing elit.'
    assert fd.read() == b

# Generated at 2022-06-12 17:03:35.332568
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os
    import tempfile
    import time
    import shutil
    from .downloader import FileDownloader

    dl = FileDownloader()
    dl.params.update({'outtmpl': '%(tmpfilename)s.part'})

    tmpdir = tempfile.mkdtemp(prefix='youtubedl-test-', suffix='-tmpdir')

# Generated at 2022-06-12 17:03:44.597342
# Unit test for constructor of class HttpFD
def test_HttpFD():
    (instream, outstream) = os.pipe()
    fd = HttpFD(instream, outstream, 'http://localhost/')

    fd.write('abc')
    fd.write('def')

    assert(fd.tell() == 3)
    assert(fd.read(1) == 'd')
    assert(fd.tell() == 4)

    fd.seek(-3, 1)
    assert(fd.read(1) == 'b')
    assert(fd.tell() == 3)
    fd.seek(0, 2)
    assert(fd.tell() == 6)
    assert(fd.read() == '')

    read_pos = fd.tell()
    fd.close()
    assert(read_pos == 6)

    fd.seek(-3, 2)
    f

# Generated at 2022-06-12 17:05:09.297012
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class NullFD:
        def __init__(self,params):
            pass

        def report_resuming_byte(self,byte):
            print("[download] Resuming download at byte %s" % (byte,))

        def report_retry(self,source_error,count,retries):
            print("[download] Retrying (%s/%s)..." % (count,retries))

        def report_destination(self,filename):
            print("[download] Destination: %s" % (filename,))

        def report_file_already_downloaded(self,filename):
            print("[download] %s has already been downloaded" % (filename,))

        def report_unable_to_resume(self):
            print("[download] Unable to resume.")


# Generated at 2022-06-12 17:05:17.178551
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test if HttpFD is constructed for 'http://...' URL and
    # (StreamingFD is constructed for '-' and 'file://' URLs)
    assert isinstance(FileDownloader({}, {'nooverwrites': True}, {}, None).open_fs('http://www.example.com/'), HttpFD)
    assert isinstance(FileDownloader({}, {'nooverwrites': True}, {}, None).open_fs('-'), StreamingFD)
    assert isinstance(FileDownloader({}, {'nooverwrites': True}, {}, None).open_fs('file:///tmp/xxx'), StreamingFD)



# Generated at 2022-06-12 17:05:26.753915
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    from .utils import encodeFilename
    from .compat import compat_http_client
    from .compat import compat_str
    from .compat import compat_urllib_error
    from .compat import compat_urlparse
    from .utils import DateRange
    class _MockYDL(object):
        def __init__(self, params):
            self.params = params
    class _MockConfig(object):
        def __init__(self, opts):
            self.opts = opts
    class _MockExtractor(object):
        def __init__(self, ie_key):
            self.ie_key = ie_key
        def _request_webpage(self, *args, **kwargs):
            raise BaseException('unexpected called _request_webpage')

# Generated at 2022-06-12 17:05:39.088213
# Unit test for constructor of class HttpFD
def test_HttpFD():
    urlopen = compat_urllib_request.urlopen
    def urlopen_test(req, timeout=None):
        assert req.get_full_url() == 'http://example.com/'
        assert req.get_method() == 'GET'
        headers = dict(req.headers)
        assert headers.pop('Youtubedl-no-compression') == 'True'
        assert headers.pop('Range') == 'bytes=0-49'
        assert not headers
        return compat_http_client.HTTPResponse(
            io.BytesIO((b'content1\n' * 10)[:-1]),
            {'content-length': '49'},
            url='http://example.com',
            status=206,
            reason='Partial Content')
    urlopen.side_effect = urlopen_test

# Generated at 2022-06-12 17:05:49.390804
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Test HttpFD constructor."""
    # Test invalid URLs
    for u in ['example.com', 'http://']:
        assert_raises(IOError, HttpFD, u, {})
    # Test empty content-length
    assert_raises(IOError, HttpFD, 'http://example.com',
                  {'content-length': ''})
    # Test invalid content-length
    assert_raises(IOError, HttpFD, 'http://example.com',
                  {'content-length': 'abc'})
    # Test negative content-length
    assert_raises(IOError, HttpFD, 'http://example.com',
                  {'content-length': '-1'})
    # Test zero content-length

# Generated at 2022-06-12 17:05:56.038338
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.youtube.com/watch?v=BaW_jenozKc', {})
    assert fd.url == 'http://www.youtube.com/watch?v=BaW_jenozKc'
    assert not fd.is_test
    assert fd.ydl is None
    assert fd.socks_proxy_rdns is False
    assert not fd.params
    assert not fd.proxies
    assert not fd.warned
    assert not fd.get_headers()

# Generated at 2022-06-12 17:05:58.083426
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd = HttpFD(params={})
    if httpfd.ydl is not None:
        raise Exception('HttpFD constructor failed')



# Generated at 2022-06-12 17:06:05.223859
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DummyYDL:
        def __init__(self, params):
            self.params = params

        @staticmethod
        def to_screen(message):
            pass

        @staticmethod
        def problem(message):
            pass

        @staticmethod
        def report_error(message):
            pass

        def report_retry(self, error, count, retries):
            pass

    class DummyFD:
        params = {'nooverwrites': True}
        ydl = DummyYDL(params)
        filename = 'test'
        tmpfilename = 'test.part'
        resume = True
        try_rename = staticmethod(os.rename)
        try_utime = staticmethod(lambda x, y: True)
        undo_temp_name = staticmethod(lambda x: 'test')


# Generated at 2022-06-12 17:06:16.552193
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Verify behavior when http server sends incomplete data
    class MockServer(object):
        def __init__(self):
            self.answer = [
                'HTTP/1.1 200 OK\r\n',
                'Content-Length: 101\r\n',
                '\r\n',
                'b' * 101,
            ]
            self.sock = None
            self.port = 0
            self.thread = None
        def start(self):
            assert self.thread is None
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind(('0.0.0.0', 0)) # bind to random

# Generated at 2022-06-12 17:06:28.926966
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # same as test_real_download() but using HttpFD
    def test_real_download():
        byte_counter = 0
        block_size = 1024
        data = b''

        def hook(status):
            nonlocal byte_counter
            nonlocal block_size
            nonlocal data

            if status['status'] == 'finished':
                assert data == compat_struct_pack('1024s', b'yt-test-data')
                assert byte_counter == 1024
                return
            elif status['status'] == 'downloading':
                assert status['downloaded_bytes'] == byte_counter
                data += ctx.data.read(min(status['downloaded_bytes'], 1024) - len(data))
                assert status['elapsed'] > 0
                assert status['total_bytes'] is None