

# Generated at 2022-06-12 16:59:55.887978
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import types
    fd = HttpFD('http://www.google.com/', {'test': 'Test header'})
    assert(fd.url == 'http://www.google.com/')
    assert(fd.headers == {'test': 'Test header'})
    assert(isinstance(fd.real_download, types.MethodType))
    assert(fd.endbyte == -1)


# Generated at 2022-06-12 17:00:02.135664
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing HttpFD constructor')
    url = 'http://www.example.org/'
    u = compat_urllib_request.urlopen(url)
    fd = HttpFD(u, 1024)
    assert fd.read(10) == '<!doctype '
    assert fd.name == url
    print('finished')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:00:07.146820
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(lambda: (None, None, b'foo'))
    assert fd.real_download is None
    assert fd.read(8) == b'foo'
    assert fd.read(8) == b''



# Generated at 2022-06-12 17:00:19.746700
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from six.moves.urllib_parse import urlparse

    def _test_read_blocks(fd, block_size):
        """ Test reading of file with given block size """
        # Try seeking back to start of file
        fd.seek(0)
        assert fd.tell() == 0

        # Test read all
        fd.seek(0, 2)
        assert fd.tell() == fd._totalsize
        fd.seek(0)
        assert fd.read() == TEST_DATA

        # Try read blocks of given size
        fd.seek(0)
        bytes_read = 0
        while True:
            block = fd.read(block_size)
            if not block:
                break
            assert block == TEST_DATA[bytes_read:bytes_read + len(block)]

# Generated at 2022-06-12 17:00:33.787601
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from StringIO import StringIO
    from .compat import compat_http_client
    from .utils import urlopen
    url = 'http://repo.or.cz/w/youtube-dl.git/blob_plain/HEAD:/test/testfile_extended.csv'
    fd = HttpFD(urlopen(url),
                lambda s: s.read(),
                lambda l: None,
                lambda *args: None)
    assert fd.size() == 130
    assert fd.read(1) == '#'
    assert fd.read(10) == 'extended_di'

# Generated at 2022-06-12 17:00:45.780127
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test example
    fd = HttpFD('http://example.com/')
    assert fd.url == 'http://example.com/'
    assert fd.status == 'http'
    assert fd.filename == 'example.com'
    assert fd.title == 'example.com'
    assert fd.get_size() is None
    assert fd.get_filesize() is None

    # Test example.com
    fd = HttpFD('http://example.com/')
    assert fd.url == 'http://example.com/'
    assert fd.status == 'http'
    assert fd.filename == 'example.com'
    assert fd.title == 'example.com'
    assert fd.get_size() is None
    assert fd.get_filesize() is None

# Generated at 2022-06-12 17:00:56.475480
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import random
    from .extractor.youtube import YoutubeIE
    from .downloader import FileDownloader
    ydl = YoutubeIE(FileDownloader({
        'format': 'bestvideo[height<=480]/best',
        'nocheckcertificate': True,
    }))

    # Mock urlopen, get the actual parameters of real_download
    original_urlopen = HttpFD.urlopen
    HttpFD.urlopen = lambda s, req: original_urlopen(s, req)

    HttpFD.real_download(ydl, {
        'url': 'http://localhost:99999/',
        'filename': 'test.bin',
        'total_size': random.randint(1000000, 9999999),
    })

    # Restore urlopen
    HttpFD.urlopen = original_urlopen


# Generated at 2022-06-12 17:01:08.252132
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Unit test for method real_download of class HttpFD.
    When running this script it will download a single fragment of a file.
    Test if the correct fragment is downloaded.
    """
    url = 'http://localhost:9000/'
    file_size = 10000
    fileb = os.urandom(file_size)
    range_size = 1000
    range_start = 3
    range_end = range_start + range_size - 1

    class LimitedTestServer(http.server.HTTPServer):
        def __init__(self, server_address, RequestHandlerClass, fileb, file_size):
            self.fileb = fileb
            self.file_size = file_size
            http.server.HTTPServer.__init__(self, server_address, RequestHandlerClass)


# Generated at 2022-06-12 17:01:22.212135
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    res_bunch = namedtuple('res_bunch', 'code url headers')
    url_bunch = namedtuple('url_bunch', 'code url headers')
    req_bunch = namedtuple('req_bunch', 'code url headers')
    def urlopen(req):
        req = req_bunch(*req)
        assert req.code == 200
        assert req.headers.get('User-Agent') == 'Wget/1.16.3'
        if req.url.startswith('http://localhost/%3F'):
            return res_bunch(200, 'http://localhost/%3Fabcdef', {})

# Generated at 2022-06-12 17:01:34.045832
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def _test_same(**kwargs):
        fd1 = HttpFD(**kwargs)
        fd2 = HttpFD(**kwargs)
        return fd1 == fd2 and fd1 is not fd2 and str(fd1) == str(fd2)

    assert _test_same(url='http://abc.com/')
    assert _test_same(url='http://abc.com/', filename='abc.flv')
    assert _test_same(url='http://abc.com/', filename='abc.flv', params={'opt': 1})

    assert not _test_same(url='http://abc.com/', filename='def.flv')
    assert not _test_same(url='http://abc.com/', params={'opt': 1})
    assert not _test_

# Generated at 2022-06-12 17:02:15.972397
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.youtube import YoutubeIE
    import pytest

    class MyYoutubeIE(YoutubeIE):
        def report_signature_info(self, filename, video_id, video_title, video_description, video_thumbnail, hd_thumbnail, hd_url, hd_width, hd_height, hd_player_url, hd_ext, duration, view_count, comment_count, age_limit, uploader):
            pass

        def _real_extract(self, url):
            return {'id': 'a'}


# Generated at 2022-06-12 17:02:28.972349
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import os
    import threading
    import time
    import types
    import urllib.parse
    import unittest

    import http.server
    import socketserver

    from .utils import urlopen, urljoin, urlhandle_detect_ext
    from .utils import sanitized_Request, time_to_milliseconds
    from .compat import compat_http_server

    fake_http_server = lambda func: type(
        'FakeHTTPServer', (socketserver.TCPServer,), {
            'allow_reuse_address': True,
            'handle_request': lambda self: func(self.request),
        })
    FakeBaseHTTPRequestHandler = compat_http_server.BaseHTTPRequestHandler


# Generated at 2022-06-12 17:02:40.343420
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import random
    import tempfile
    test_data = randombytes(37)
    test_data_len = len(test_data)
    test_data_len_str = str(test_data_len)
    test_data_off = random.randint(0, test_data_len - 1)
    test_data_off_str = str(test_data_off)
    test_data_rem = test_data_len - test_data_off
    test_data_rem_str = str(test_data_rem)
    real_data_len = test_data_len + (random.randint(0, 1000))
    real_data_len_str = str(real_data_len)


# Generated at 2022-06-12 17:02:52.433590
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    import traceback


    def next_fragment(exc):
        return isinstance(exc, NextFragment)


    # Test suite
    class TestFD(HttpFD):
        _OUT_FILE = tempfile.NamedTemporaryFile(delete=False)
        _IN_FILE = open(__file__, 'rb')
        _DATA_LEN = os.path.getsize(__file__)
        _BLOCK_SIZE = 1024 * 8
        _RETRIES = 10
        _MAX_RETRIES = _RETRIES
        _TIMEOUT = 10
        _RETRY_WAIT = 0

        def __init__(self, params=None):
            super(TestFD, self).__init__(params)

# Generated at 2022-06-12 17:03:02.592426
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
    h = HttpFD(FakeYDL({'continuedl': True, 'nooverwrites': True}))
    assert h.params == {'continuedl': True, 'nooverwrites': True}
    h = HttpFD(FakeYDL({'continuedl': False, 'nooverwrites': False}))
    assert h.params == {'continuedl': False, 'nooverwrites': False}
    h = HttpFD(FakeYDL({}))
    assert h.params == {}


# Generated at 2022-06-12 17:03:06.978093
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return HttpFD(
        'http://videos-v-i-d-e-o-s.com/video123456789.mp4', {
            'verbose': True,
            'test': True,
            'noprogress': True,
            'quiet': True,
        }, 'http://videos-v-i-d-e-o-s.com/video123456789.mp4',
        'video123456789.mp4', 'video', 0)



# Generated at 2022-06-12 17:03:17.009215
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os

    # unit tests are executed in a subdirectory (wanted behavior)
    # we have to chdir to the test directory to get the correct path
    test_dir = os.getcwd()
    os.chdir(os.path.abspath('..'))

    hd = HttpFD()
    hd.params['noprogress'] = True

    rd = hd.real_download
    rd(
        sanitized_Request('http://localhost:8090/test.mp4'),
        'test.mp4',
        {'test': 'value'},
        True,
        'mp4',
        None,
        False,
        'wb',
        False,
        0,
        None,
        'test.mp4.tmp',
    )
    # print("test.mp4

# Generated at 2022-06-12 17:03:24.885702
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_cases = [
        ('http://127.0.0.1/%C3%A5%C3%A6%C3%B8', u'åæø'),
        ('http://127.0.0.1/asdf', u'asdf'),
        ('http://127.0.0.1/%E2%82%AC%C2%A3', u'€£'),
        ('http://127.0.0.1/asdf', u'asdf', {'noprogress': True}),
        ('http://127.0.0.1/asdf', u'asdf', {'ratelimit': 1024}),
        ('http://127.0.0.1/asdf', u'asdf', {'noresizebuffer': True}),
    ]

# Generated at 2022-06-12 17:03:33.142441
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import lib
    import unittest
    import urllib2

    class HttpFDTest(unittest.TestCase):
        def setUp(self):
            self.httpfd = ForgivingFD(
                urllib2,
                dict(test=True),
                lambda *a, **k: None,
                lambda *a, **k: None,
            )

    unittest.main(argv=['', 'Test.testName'], testRunner=lib.test_runner.TinyRunner)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:03:43.774764
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL()
    ydl.add_progress_hook(lambda d: None)
    ydl.add_default_info_extractors()
    destfilename = os.path.expanduser('~/test.mp3')
    if os.path.exists(destfilename):
        os.remove(destfilename)
    assert not os.path.exists(destfilename)

    url = 'http://3.bp.blogspot.com/-0C9J9HgcuZc/TdD3FEHkRnI/AAAAAAAAA54/wnWpbeYTBvM/s1600/maybach_music_2(2).mp3'
    filename = ydl.prepare_filename(ydl.extract_info(url))
    assert filename == destfilename


# Generated at 2022-06-12 17:05:10.761215
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:05:19.334719
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import prepend_extension
    # Suppress console output
    ydl = YoutubeDL({'quiet': True, 'no_warnings': True})
    import uuid

# Generated at 2022-06-12 17:05:27.913714
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    start = time.time()

# Generated at 2022-06-12 17:05:40.184159
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _gen_headers(n, ts=None):
        return {'Content-Length': n, 'Last-Modified': ts or time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime())}

    class _TestInfoExtractor:
        def __init__(self):
            self._set_cookie = []

        def set_cookie(self, name, value):
            self._set_cookie.append((name, value))

    ies = _TestInfoExtractor()
    ie = InfoExtractor('', {}, None, ies)
    ie._downloader.params['test'] = True
    ie._downloader.params['nooverwrites'] = True
    ie._downloader.params['continuedl'] = False

# Generated at 2022-06-12 17:05:49.937405
# Unit test for constructor of class HttpFD
def test_HttpFD():
    args = [
        '--quiet',
        '--socket-timeout', '10',
        '--no-resize-buffer',
        '--min-filesize', '1',
        '--max-filesize', '100000',
        '--test-url', 'http://www.google.com/index.html',
    ]
    ydl = YoutubeDL(args)
    dl = HttpFD(ydl, {'url': 'http://www.google.com/index.html'})
    assert dl.ydl is ydl
    assert dl.params['url'] == 'http://www.google.com/index.html'
    assert dl.params['quiet'] is True
    assert dl.params['socket_timeout'] == 10
    assert dl.params['noresizebuffer'] is True
   

# Generated at 2022-06-12 17:05:55.705478
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    ydl.add_default_info_extractors()
    # Test small chunked download
    info = {}
    fd = HttpFD(ydl, 'http://localhost:23456/233', 'test-download-chunk.mp4', info, {})
    assert fd.real_download('-', {
        'continuedl': True,
        'quiet': True,
        'test': True,
        'chunk_size': 233,
        'noprogress': True,
    })
    os.remove('test-download-chunk.mp4')
    assert info['filesize'] == 233
    # Test small download with Range header
    info = {}

# Generated at 2022-06-12 17:06:03.673353
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import decode_compat_str

    # simulate stdin
    class TestFD():
        def __init__(self):
            self.buffer = b''
            self.stop_reading = False

        def write(self, b):
            if self.stop_reading:
                return
            self.buffer += b
            if b'\n' in self.buffer or len(self.buffer) > 10:
                self.stop_reading = True
                return

        def read(self, bytes):
            return self.buffer

        def close(self):
            pass

    tf = TestFD()
    h = HttpFD(tf, None, params={
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 0,
        })
    h.real

# Generated at 2022-06-12 17:06:07.929840
# Unit test for constructor of class HttpFD
def test_HttpFD():
    downloader = YoutubeDL()
    fd = HttpFD(downloader, {}).get('http://site/video.mp4')
    fd.download(ctx=None)
    return fd



# Generated at 2022-06-12 17:06:18.836653
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import urlopen
    import tempfile
    import shutil
    import json
    import os

    test_data = b'''
    HTTP/1.1 200 OK
    Content-Length: 100000
    Content-type: text/plain


    '''

    expected_data = b''

    with tempfile.NamedTemporaryFile() as sf:
        with tempfile.NamedTemporaryFile() as tf:
            with tempfile.TemporaryDirectory() as tmpdir:
                config = os.path.join(tmpdir, 'config')

# Generated at 2022-06-12 17:06:31.071332
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import shutil
    from .utils import strip_jsonp, encode_compat_str
    from .extractor import gen_extractors
    from .compat import compat_str

    for ie in gen_extractors():
        if not hasattr(ie, '_TEST'):
            continue
        for t in ie._TEST:
            t_url = t['url']
            t_note = t.get('note')

            t_stdout = t.get('output')
            if t_stdout is not None:
                t_stdout = strip_jsonp(t_stdout)

            test_result = None
            test_video_url = 'http://didnotwork.de/video.mp4'

            _, test_video_ext = os.path.splitext(test_video_url)

