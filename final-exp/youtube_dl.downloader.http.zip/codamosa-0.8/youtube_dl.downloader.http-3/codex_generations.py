

# Generated at 2022-06-12 17:00:11.511378
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hfd = HttpFD(
        {'url': 'http://example.com', 'title': 'testvideo', 'id': 'testvideo', 'ext': 'test'}, {}, {}, {})
    assert hfd.url == 'http://example.com'
    assert hfd.title == 'testvideo'
    assert hfd.test == True
    assert hfd.http_headers == {}
    assert hfd.params['http_chunk_size'] == 10485760
    assert hfd.retries == 10
    assert hfd.prefer_free_formats == False
    assert hfd.continuedl == False
    assert hfd.noprogress == False
    assert hfd.ratelimit == None
    assert hfd.noresizebuffer == False
    assert hfd.buffersize == None

    h

# Generated at 2022-06-12 17:00:21.935293
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    from .utils import encodeFilename

    class DummyYDL(object):

        def __init__(self):
            self.params = {}

        def report_error(self, msg):
            print('ERROR: ' + msg)

        def to_screen(self, msg):
            print('LOG: ' + msg)

        def urlopen(self, request):
            request_str = str(request.get_full_url())
            if request_str.startswith('http://foo.bar/'):
                raise compat_urllib_error.HTTPError(
                    'http://foo.bar/', 404, 'Not Found', {}, None)

# Generated at 2022-06-12 17:00:35.896595
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import uuid
    import tempfile

    class TestBuffer(object):
        def __init__(self):
            self.data = []

        def write(self, s):
            self.data.append(s)

        def getvalue(self):
            return b''.join(self.data)

    tmp_path = tempfile.gettempdir()
    tmp_name = os.path.join(tmp_path, uuid.uuid1().hex)
    tmp_dst = tempfile.TemporaryFile()
    tmp_src = TestBuffer()

    with open(__file__, 'rb') as fileh_src:
        tmp_src.write(fileh_src.read())

    h = HttpFD(tmp_dst, None, tmp_src)
    for chunk in h.chunks():
        tmp_d

# Generated at 2022-06-12 17:00:47.389475
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    import re

    # Check if a known extractor is loaded and registered
    for ie in gen_extractors():
        if ie.IE_NAME == 'Youtube':
            youtube_ie = ie()
            break
    else:
        print('Warning: youtube-dl not available.')
        return []
    downloader = youtube_ie.ydl

    # Check if the method real_download is still there
    if downloader.params.get('forcetitle', False):
        print('Warning: The interface of the test method has changed!')
        return []


# Generated at 2022-06-12 17:00:57.469852
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import mock
    from .utils import *

    url = 'http://www.example.com/file.mp4'
    tmp_filename = 'test'
    filename = 'test'
    basename = 'test.mp4'

    # Test Content-Length = None
    op, req = build_opener_and_requests()
    mock_urlopen = mock.Mock(return_value=MockResponse(CONTENT))
    req.urlopen = mock_urlopen

    hfd = HttpFD(op, url, mock.Mock(), mock.Mock(), mock.Mock(), {}, {'nopart': False})

    with open(tmp_filename, 'wb') as f:
        assert hfd.real_download(f, tmp_filename, filename, basename, mock.Mock(), None)

    # Test

# Generated at 2022-06-12 17:01:08.412256
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:01:22.367395
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test one
    params = {'noprogress': True,
              'logger': DummyLogger()}
    info = {'url': 'http://localhost/',
            'http_headers': {'Foo':'Bar'}}
    d = HttpFD(info, params, True)
    d.add_progress_hook(lambda x: None)
    assert d.ydl is not None
    assert d.info is info
    assert d.params == params
    assert d.start() is None
    info['http_headers']['Content-Length'] = '100'
    assert d.real_download(info, params) is False
    # Test two
    import tempfile

# Generated at 2022-06-12 17:01:34.195838
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import encodeFilename

    # File to download
    url = 'https://github.com/rg3/youtube-dl/raw/master/youtube_dl/LICENSE'
    # Expected file size in bytes
    file_size = 1044
    # File hash (sha256)
    file_hash = 'd751713988987e9331980363e24189ce'

    # Temporary directory to download file
    import tempfile
    temp_dir = tempfile.mkdtemp()
    # Temporary filename
    filename = 'LICENSE'
    temp_file = os.path.join(temp_dir, filename)

    # Initialize YoutubeDL object
    ydl = YoutubeDL()

    # Initialize extractor
    ie = InfoExtractor(ydl, None)


# Generated at 2022-06-12 17:01:38.228016
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .downloader import YoutubeDL
    h = HttpFD(YoutubeDL(), dict())
    h.test()
    h.close()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:01:42.652803
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import shutil
    import socket
    import tempfile
    import time

    test_file_size = 10000
    # These functions need to be defined to allow compiling on non-posix platforms
    def getloadavg():
        return (0, 0, 0)

    def get_proxies_server():
        return None

    def get_environ_proxies_server():
        return None

    httpfd = HttpFD()
    proxies = httpfd.ydl.proxies

    # Creating test file to serve via HTTP
    temp_dir = tempfile.mkdtemp()
    test_file_path = os.path.join(temp_dir, 'test')

# Generated at 2022-06-12 17:02:20.247132
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    from .utils import FakeYDL
    from .extractor import get_info_extractor
    from .compat import compat_http_server
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_error
    from .compat import compat_urlparse

    # Tested code requires at least Python 2.6 due to next_fragment exception,
    # so we don't need to calculate skip_travis_test_reason

    def create_http_server(handler_class, port=0):
        server = compat_http_server.HTTPServer(('', port), handler_class)
        port = server.server_port
        thread = threading.Thread(target=server.serve_forever)
       

# Generated at 2022-06-12 17:02:34.209838
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params = {
        'noprogress': True,
    }
    fd = HttpFD(params)
    assert 'format_note' in fd.info
    assert 'retries' in fd.info
    assert 'fragment_retries' in fd.info
    assert 'continuedl' in fd.info
    assert 'test' in fd.info
    assert 'noprogress' in fd.info
    assert 'noresizebuffer' in fd.info
    assert 'httpproxy' in fd.info
    assert 'encoding' in fd.info
    assert fd.info['http_chunk_size'] == None
    assert fd.info['proxy'] == None
    assert fd.info['username'] == None
    assert fd.info['password'] == None

# Generated at 2022-06-12 17:02:42.470410
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil
    import os.path

    # Test data
    test_url = 'http://ipv4.download.thinkbroadband.com/200MB.zip'

    def Response(url, data_len, block_size):
        class R(object):
            def __init__(self, url, data_len, block_size):
                self.url = url
                self.data_len = data_len
                self.block_size = block_size
                self.byte_counter = 0

            def read(self, num_bytes):
                if self.byte_counter + num_bytes > self.data_len:
                    num_bytes = self.data_len - self.byte_counter
                d = b'\0' * num_bytes
                self.byte_counter += num_bytes
                return

# Generated at 2022-06-12 17:02:54.002938
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil

    def _run_test(params):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 17:03:04.143192
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import youtube_dl.utils as utils
    urls = ('http://www.youtube.com/watch?v=BaW_jenozKc',
            'http://www.google.com/',
            'http://localhost/does-not-exist',
            'http://localhost:1/does-not-exist-either')
    params = {'outtmpl': '%(id)s.%(ext)s', 'quiet': True}
    for url in urls:
        h = HttpFD(url, params)

# Generated at 2022-06-12 17:03:05.365229
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(None, {}, {}).read(1) == ''


# Generated at 2022-06-12 17:03:15.836492
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import is_outdated_version

    if is_outdated_version(urllib_request_version, '3.3'):
        return  # Python 3.2 and below is not supported

    fd = HttpFD('http://127.0.0.1:9/', {'noprogress': True})
    assert(fd.return_code == -1)
    assert(fd.handle.headers['User-Agent'].startswith('Python-urllib'))
    assert(fd.url == 'http://127.0.0.1:9/')

    fd = HttpFD('http://127.0.0.1:9/', {'noprogress': True}, 'Mozilla/5.0')
    assert(fd.return_code == -1)

# Generated at 2022-06-12 17:03:24.062330
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # URL opener
    class MyOpener(compat_urllib_request.FancyURLopener):
        def http_error_206(self, url, fp, errcode, errmsg, headers, data=None):
            pass
    my_opener = MyOpener()

    # Test with test data
    chunks = []
    for chunk in ['first ', 'second part', ' of test data']:
        chunks.append(chunk.encode('utf-8'))
    data = b''.join(chunks)
    info = {
        'Content-Type': 'video/webm',
        'Content-Length': str(len(data)),
    }

    # Test
    t = HttpFD(my_opener, 'http://localhost/video.webm', info, False)
    assert t.read()

# Generated at 2022-06-12 17:03:35.333751
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with a short file
    shortfile = test_server.make_shoutcast_stream()
    shortres = urlopen(shortfile)
    shortcontent = shortres.read()
    shortres.close()

    for fd1 in [shortres, sanitized_Request(shortfile)]:
        fd2 = HttpFD(fd1, {'noprogress': True})

# Generated at 2022-06-12 17:03:40.935792
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test without output template
    h = HttpFD(None, {})
    assert h.outtmpl is None
    # Test with normal output template
    h = HttpFD('%(id)s-%(uploader)s-%(title)s.%(ext)s', {})
    assert h.outtmpl == '%(id)s-%(uploader)s-%(title)s.%(ext)s'
    h.discharge_file_template()
    assert h.filename == '%(id)s-%(uploader)s-%(title)s.%(ext)s'
    assert h.tmpfilename == '%(id)s-%(uploader)s-%(title)s.%(ext)s.part'

# Generated at 2022-06-12 17:05:08.643900
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # 1. HttpFD should open the file with binary mode
    # 2. When data_len is None, have to do download without limit
    # 3. HttpFD should skip the remaining data when byte_counter exceeds data_len
    def gen_data_block(byte_counter, data_len):
        if not data_len:
            return b'bytes'
        if byte_counter >= data_len:
            return b''
        # make sure that we have to test data_len in the final loop run
        block_size = min(data_len - byte_counter, len(b'bytes') + 1)
        return compat_struct_pack('=B', block_size) + b'bytes' * block_size


# Generated at 2022-06-12 17:05:18.145121
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _download(ctx, params, url, filename, info_dict):
        # Copy HttpFD.real_download to HttpFD._real_download as it is
        # private and we need to test it.
        HttpFD.real_download = HttpFD._real_download

        fd = HttpFD(params, url, filename, info_dict)
        fd.test_socket_timeouts = [2, 3]
        ctx.nbytes = 1024 * 1024


# Generated at 2022-06-12 17:05:28.871021
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    This is a unit test of HttpFD.real_download(...) method.
    """


# Generated at 2022-06-12 17:05:35.156383
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys

    class FakeYDL:
        @staticmethod
        def urlopen(request):
            return sys.stdin

    http_fd = HttpFD('http://abc', FakeYDL())
    assert http_fd.real_download(None, {'noprogress': True, 'retries': 1})

# Generated at 2022-06-12 17:05:44.244962
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYDL(object):
        def __init__(self):
            self.params = {}

    test_ydl = FakeYDL()

    fd = HttpFD(test_ydl, 'http://www.example.com', {})
    assert isinstance(fd.ydl, FakeYDL)
    assert fd.url == 'http://www.example.com'
    assert fd.headers == {}
    assert fd._test_block_read_size() is None

    test_ydl.params['test'] = 'my_url'
    fd = HttpFD(test_ydl, None, None)
    assert fd.url == 'my_url'
    assert fd.headers is None
    assert fd._test_block_read_size() == HttpFD.TEST_BLOCK_

# Generated at 2022-06-12 17:05:53.061961
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    timeout = 3  # seconds
    # This file is the first few bytes of a gzip-compressed file
    filename = 'http://www.google.com/intl/en_ALL/images/logo.gif'
    # Compressed size: 786 bytes
    # Original size: 1443 bytes
    # Compression ratio: 1.8
    test_bytes = (b'\x1f\x8b\x08\x08x\xe1\xb9\x11R\x00\x03logo.gifI'
                  b'\x00\xad\xd2\x9d+\x1b\x0e\xc0\xf4@\xa4\x10\x14\x9c\xaf\x18\xfa')


# Generated at 2022-06-12 17:05:55.212396
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('TODO')

# Generated at 2022-06-12 17:06:02.900572
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    video_id = 'BaW_jenozKc'
    # Get the video webpage, so we can use the 'url' value from the result (it's the download URL)
    youtube_dl_args = {'nocheckcertificate': True, 'quiet': True}
    ydl = YoutubeDL(youtube_dl_args)
    video_url = ydl.extract_info(video_id, download=False)['url']
    # Define the HttpFD object
    httpfd = HttpFD(ydl, {}, {}, {})
    # Call the real_download method on the HttpFD object
    httpfd.real_download(video_url, None, True)
# The following 3 functions were used to test the function real_download defined above

# Generated at 2022-06-12 17:06:14.540534
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    HttpFD._TEST_FILE_SIZE = 1024
    fd = HttpFD(FakeYDL(), {})
    ctx = fd._ctx
    ctx.filename = '-'
    ctx.tmpfilename = '-'
    ctx.stream = six.BytesIO()
    ctx.block_size = 1024
    ctx.data = type('FakeData', (object, ), {'read': lambda self, bytes: b'x' * bytes})()
    assert fd.real_download(True)
    assert ctx.stream.tell() == 1024
    ctx.stream.seek(0)
    assert ctx.stream.read() == b'x' * 1024
    ctx.stream = None
    assert not fd.real_download(True)

    # Test that block size is adjusted
    HttpFD._

# Generated at 2022-06-12 17:06:24.295105
# Unit test for constructor of class HttpFD
def test_HttpFD():
    s = compat_http_server.HTTPServer(
        ("localhost", 0), compat_http_server.SimpleHTTPRequestHandler)
    t = Thread(target=s.serve_forever)
    t.daemon = True
    t.start()
    return HttpFD(
        s.server_address, 'GET',
        '/test.bin',
        {
            'User-Agent': 'youtube-dl-test',
        },
    )


if __name__ == '__main__':
    assert isinstance(test_HttpFD(), HttpFD)