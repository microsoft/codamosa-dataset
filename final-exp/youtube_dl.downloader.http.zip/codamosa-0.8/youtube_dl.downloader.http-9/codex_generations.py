

# Generated at 2022-06-12 17:00:07.716375
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    '''Test method real_download of class HttpFD with a test web server.'''

    # We need a web server that answers our test content
    web_server = test_server.TestServer()

    # We need a file (data) to be download for the test
    random_file = os.path.basename(web_server.test_file)
    test_file = web_server.test_dir + '/' + random_file
    test_url = web_server.test_url + '/' + random_file

    # We need an HttpFD object

# Generated at 2022-06-12 17:00:20.176536
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os
    import shutil
    from tempfile import mkdtemp
    from .downloader import FD_NAME

    test_dir = mkdtemp()
    ctx = {
        'filename': 'test.mp4',
        'tmpfilename': os.path.join(test_dir, 'test.part'),
        # 'resume_len': 0,
        # 'open_mode': 'wb'
    }
    url = 'http://localhost:8080/test.dat'
    headers = {
        'Range': 'bytes=0-%s' % (1 << 20)
    }
    ydl = FakeYDL()
    params = {
        'continuedl': True,
        'noresizebuffer': True
    }
    fd = HttpFD(ydl, params, ctx, url, headers)

# Generated at 2022-06-12 17:00:34.260683
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    '''
    This is a unit test for class HttpFD in python-youtube-dl/youtube_dl/FileDownloader.py

    Method real_download downloads the file from a URL, optionally resuming a previous
    download attempt.

    Method real_download generates a temporary file name for resuming downloads.
    The file name is generated based on a URL and its length. While testing, we
    need to use the same file name, so the tests can be run multiple times.
    '''

    def gen_tempnam(ctx):
        '''
        This is a helper method to generate a file name to be used as the value of
        ctx.tmpfilename. The file name is generated based on the URL of the file
        being downloaded (ctx.url) and its length (ctx.data_len).
        '''


# Generated at 2022-06-12 17:00:43.964094
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if not HttpFD:
        raise Exception('HttpFD unavailable')
    fd = HttpFD(None, {}, {})
    if fd._HttpFD__opener is None:
        raise Exception('Opener was not created')
    if fd._HttpFD__cookiejar is None:
        raise Exception('CookieJar was not created')
    if fd._HttpFD__context.check_socket_callback is None or fd._HttpFD__context.method is None or fd._HttpFD__context.cookiejar is None:
        raise Exception('SSL context was not created')
    return True


# Generated at 2022-06-12 17:00:49.577413
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(test_urls_opener, params={})
    test_urls_opener.open = lambda x: compat_urllib_request.addinfourl(BytesIO(b'abc'), '', test_urls[x])
    assert fd.real_download('http://www.example.com/') == b'abc'


# Generated at 2022-06-12 17:00:54.864976
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://example.com', {'noprogress': True, 'logtostderr': True})
    # Test that we do not get an error in case of empty content.
    assert fd.read() == b''

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:01:01.933273
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def hd(hx, d, v=None):
        return HttpFD(d, {'test_option': v}).info()['test_option']

    assert hd(None, {}) is None
    assert hd(None, {}, 1) == 1
    assert hd(None, {'test_option': 2}) == 2


# Generated at 2022-06-12 17:01:10.272704
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    This unit test downloads a big file from the internet
    and checks that the downloaded file has the expected size.
    """
    file_len_test = 1024*1024
    _TEST_FILE = 'http://distribution.bbb3d.renderfarming.net/video/mp4/bbb_sunflower_1080p_60fps_normal.mp4'

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

        def to_screen(self, message):
            print(message)

        def trouble(self, message, tb=None):
            print(message)
            if tb:
                print(tb)
            raise Exception(message)

        def report_error(self, message, tb=None):
            print(message)

# Generated at 2022-06-12 17:01:24.120049
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Decorator function to run test on dummy_FD instance
    def run_test(func):
        def inner(self, *args):

            # Dummy FD to be tested
            dummy_fd = DummyFD()
            dummy_fd._real_download = DummyRealDownload()

            # Setting parameters for testing
            dummy_fd.params = {'nooverwrites': False}
            dummy_fd.report_error = DummyReportError()
            dummy_fd.to_screen = DummyToScreen()
            dummy_fd.report_retry = DummyReportRetry()
            dummy_fd.report_resuming_byte = DummyReportResumingByte()
            dummy_fd.report_unable_to_resume = DummyReportUnableToResume()
            dummy_fd.report_file_already_downloaded

# Generated at 2022-06-12 17:01:35.087516
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with a Youtube video (Chuck Norris approved)
    youtube_url = 'http://www.youtube.com/watch?v=5YnGHckuUOQ'
    ydl = YoutubeDL({'outtmpl': '-'})
    ydl.add_info_extractor(YoutubeIE(ydl))
    result = ydl.extract_info(youtube_url, download=False)
    assert result['id'] == '5YnGHckuUOQ'

    fd = HttpFD(ydl, result['formats'][-1]['url'], {}, False, result, None)
    assert fd.name == result['formats'][-1]['url']
    assert fd.mode == 'rb'
    assert fd.readable()
    assert not fd.writable()
   

# Generated at 2022-06-12 17:02:15.302363
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import test_http_server
    test_server = test_http_server.TestHTTPServer()
    try:
        test_server.start()
        testfd = HttpFD(test_server.server_address)
        assert testfd.probe_size()
        data = testfd.read(10)
        assert data == b'0123456789'
        data = testfd.read(5)
        assert data == b'56789'
        assert testfd.tell() == 15
        assert testfd.size() == 200
        testfd.close()
    finally:
        test_server.stop()


# Generated at 2022-06-12 17:02:18.280308
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import doctest
    doctest.testmod(HttpFD)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:02:32.072027
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # The command generates a file test.dat of the exact size of 67108864
    # bytes.
    # $ dd if=/dev/zero bs=67108864 count=1
    command = ['dd', 'if=/dev/zero', 'bs=67108864', 'count=1']
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # TODO: stop the server after the test is complete
    # It's better to have some other way to control the server.
    address = ('127.0.0.1', 8181)
    httpd = HTTPServer(address, SimpleHTTPRequestHandler)
    threading.Thread(name='Test HTTP Server', target=httpd.serve_forever).start()

# Generated at 2022-06-12 17:02:38.935190
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(None, {}, None)
    for p in [{'noprogress': True}, {'logtostderr': True}]:
        for t in [True, False]:
            for s in [True, False]:
                for dl in [True, False]:
                    for n in [True, False]:
                        for f in [True, False]:
                            h = HttpFD(p, t, s, dl, n, f)


# Generated at 2022-06-12 17:02:51.381614
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DummyYDL(object):
        """ Dummy object with attribute for testing write_xattr method """

        def __init__(self, to_screen=None, to_stderr=None, params=None):
            self.to_screen = to_screen
            self.to_stderr = to_stderr
            self.params = params

        def urlopen(self, request, retries=None, ignore_http_code=None, sleep_time=None,
                    max_sleep_time=None, _pool=None, _pool_connections=None, _pool_maxsize=None):
            """ Mock method for urlopen """
            raise NotImplementedError

    def mock_write_xattr(filename, attr, value):
        """ Mock method for write_xattr """

# Generated at 2022-06-12 17:02:58.490661
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Testing HttpFD.real_download.

    It tests basic functionality of real_download
    as well as download for a YouTube video having
    duration greater than 60 minutes.
    """
    fd = HttpFD(
        # required.
        params={
            'outtmpl': '%(id)s.%(ext)s',
            'noprogress': True,
        },
        # optional.
        progress_hooks=[],
        # optional. Set to True for quick execution.
        is_test=False
    )

    # test real_download for a simple download with filename having extension

# Generated at 2022-06-12 17:03:06.594050
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import get_suitable_downloader

    class MockYDL:
        params = {'noprogress': True}
        outtmpl = 'mock.%(ext)s'
        progress_hooks = []

    class MockExtractor:
        def __init__(self, urls, ie_key):
            self.urls = urls
            self.ie_key = ie_key

        def _get_videos_info_for_url(self, url):
            return {
                'id': 1,
                'url': url,
                'ext': 'mp4',
                'title': 'mock',
                'thumbnail': 'http://example.com/thumbnail.jpg',
                'format': 'mock-format-%s' % url,
            }

    mock_yd

# Generated at 2022-06-12 17:03:12.454119
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing HttpFD constructor...')
    http_fd_test_inst = HttpFD(params={}, ydl=object())
    http_fd_test_inst.report_retry(Exception('foo'), 1, 3)
    http_fd_test_inst.to_screen('\r')
    print('Done.')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:03:21.733070
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a test target object
    ydl = YoutubeDL()
    ydl.params['outtmpl'] = 'test_%(testid)s.%(ext)s'
    ydl.params['nooverwrites'] = True
    ydl.params['continuedl'] = False
    ydl.params['noprogress'] = True
    hfd = HttpFD(ydl, {'testid': 'test_HttpFD_real_download', 'ext': 'flv'})

    # The test function

# Generated at 2022-06-12 17:03:34.189372
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Make sure we use external programs for running tests
    external_downloader_test()

    # Create a temporary directory and save the cwd
    tmpd = tempfile.mkdtemp()
    os.chdir(tmpd)

    # Create a valid test configuration
    ydl_opts = {
        'nooverwrites': True,
        'logger': MyLogger(),
        'simulate': True,
        'outtmpl': '%(id)s.%(ext)s',
    }

    # Test empty urls list
    h = HttpFD()
    h.prepare(ydl_opts)
    h.download(None)

    # Test non-existing URL
    h = HttpFD()
    h.prepare(ydl_opts)

# Generated at 2022-06-12 17:04:50.461761
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    from .compat import compat_urllib_request

    req = compat_urllib_request.Request(
        'http://127.0.0.1/256_bytes',
        headers={'Range': 'bytes=0-7'})

    res = compat_urllib_request.urlopen(req)
    hfd = HttpFD(req, BytesIO(res.read()), 8, res.info())
    assert hfd.size() == 256
    assert hfd.read(4) == b'\x00\x01\x02\x03'
    assert not hfd.readable()
    assert hfd.seekable()
    assert hfd.tell() == 4
    assert hfd.seek(8) == 8
    assert hfd.tell() == 8

#

# Generated at 2022-06-12 17:04:55.351594
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create an instance with each possible parameter value
    t = HttpFD(params={},
               ydl=None,
               errorfunc=None,
               max_filesize=None,
               test=False,
               continuous=False)

    assert isinstance(t, HttpFD)


# Generated at 2022-06-12 17:05:03.221485
# Unit test for constructor of class HttpFD
def test_HttpFD():

    # Test the case where the download finishes in one single chunk
    d = HttpFD(None, {}, 'http://localhost:9314/1', {})
    testing = 'ciao' * 100000
    r = compat_urllib_request.Request(
        'http://localhost:9314/1', None, {})
    d.data = compat_urllib_request.urlopen(r)
    assert d.read(len(testing)) == testing
    assert d.read(len(testing)) == ''

    # Test the case where the download finishes in multiple chunks
    # and the last read does not return a multiple of chunksize
    d = HttpFD(None, {'test': True, 'continuedl': True, 'chunksize': 100000}, 'http://localhost:9314/1', {})

# Generated at 2022-06-12 17:05:14.528330
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import socket
    import subprocess

    if sys.version_info < (2, 7):
        return

    # 3 blocks with 5 chunks each for 15 chunks total
    # 1 chunk is 35 KB in size, to fit in small_test filesize range of HttpFD
    block_len = CHUNK_SIZE * 5
    count = 3
    data_len = block_len * count
    blocks = [
        b'a' * block_len,
        b'b' * block_len,
        b'c' * block_len,
    ]

    with tempfile.NamedTemporaryFile(suffix='.part') as tf:
        tmpfilename = tf.name

    def _hook_progress(d):
        pass


# Generated at 2022-06-12 17:05:25.236772
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Download to a temporary file
    fd1 = HttpFD(
        u'http://www.example.com/test/test.dat', {'nooverwrites': True, 'continuedl': True})
    assert fd1.tmpfilename != 'test.dat'

    # Don't download to a temporary file
    fd2 = HttpFD(
        u'http://www.example.com/test/test.dat', {'nooverwrites': True, 'continuedl': False})
    assert fd2.tmpfilename == 'test.dat'

    # Download to stdout
    fd3 = HttpFD(u'http://www.example.com/test/test.dat', {'nooverwrites': True})
    assert fd3.tmpfilename == '-'

    # Specify filename explicitly

# Generated at 2022-06-12 17:05:37.855896
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Open a fake file
    f = open(TESTFN, 'wb')

# Generated at 2022-06-12 17:05:48.384371
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Not a test as such, but useful as a debugging/execution aid

    # enable debugging
    import youtube_dl.utils
    youtube_dl.utils.debug_print = True

    # instantiate HttpFD
    import sys
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({'outtmpl': sys.argv[2]})
    fd = HttpFD(ydl, {'url': sys.argv[1], 'noprogress': False})

    # perform download
    import os
    os.environ['TZ'] = 'Europe/Berlin'
    fd.real_download(sys.stdout.buffer)


if __name__ == '__main__':
    test_HttpFD_real_download()


# Generated at 2022-06-12 17:05:58.508638
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import requests
    import shutil
    from tempfile import NamedTemporaryFile
    from ytdl import YoutubeDL
    ydl = YoutubeDL({
        'progress_hooks': [
            lambda d: sys.stdout.write('[%s] ' % d.get('status', 'unknown')),
            lambda d: sys.stdout.write('%(filename)s\n' % d),
        ], 
        'quiet': True
    })
    def urlopen(request):
        return requests.get(request.full_url, stream=True, headers={'Range': 'bytes=0-100'})
    fd = HttpFD(ydl, 'http://i.4cdn.org/g/1448182423574.webm')
    fd.ydl.urlopen = urlopen

# Generated at 2022-06-12 17:06:12.447095
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def nop(*args, **kwargs):
        return None

    def nop_hook(status):
        return {
            'status': status,
            'elapsed': 0,
            'filename': 'foo',
            'tmpfilename': 'tmp.foo',
            'downloaded_bytes': 0,
            'total_bytes': 0,
            'eta': None,
            'speed': 0,
        }

    def gen(text):
        yield compat_str(str(text))
        yield None


# Generated at 2022-06-12 17:06:16.982529
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    '''
    HttpFD Unit Test
    '''
    import pytube
    v = pytube.YouTube("https://www.youtube.com/watch?v=YpV7gZ9XUoE")
    ys = v.streams.first()
    ys.download()