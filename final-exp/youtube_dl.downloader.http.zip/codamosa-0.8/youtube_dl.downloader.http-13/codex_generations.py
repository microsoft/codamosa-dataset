

# Generated at 2022-06-12 17:00:03.696957
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _gen_data_set(length):
        return ''.join(chr(random.randint(0, 0xff)) for _ in range(length))

    def _test(data_len, chunk_size, start_pos, end_pos):
        params = {
            'ratelimit': 0,
            'retries': 10,
            'noresizebuffer': True,
            'test': True,
        }
        head = b'HTTP/1.0 200 OK\r\nContent-Length: %s\r\n\r\n' % data_len
        data = _gen_data_set(data_len)
        req = MockRequest('GET', 'https://example.com/foo.bar', None, None, None)

        # function simulating start of download

# Generated at 2022-06-12 17:00:08.122783
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with a local file
    f = HttpFD(open('LICENSE'), 'http://localhost/LICENSE')
    f.test('LICENSE')



# Generated at 2022-06-12 17:00:20.455931
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Expected input parameters
    filename = u'-'  # '-'

# Generated at 2022-06-12 17:00:22.882972
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(None, None, None, None).pp.name == 'http'

# Generated at 2022-06-12 17:00:36.971870
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import encodeFilename

    class TestIE(InfoExtractor):
        def __init__(self, downloader=None):
            self.downloaded = []
            InfoExtractor.__init__(self, downloader)

        def report_destination(self, filename):
            self.downloaded.append(encodeFilename(filename))

        def report_error(self, message):
            print(message)

        def _download_webpage(self, url, video_id, note=None, errnote=None, fatal=True):
            return {'url': url, 'id': video_id, 'title': 'TITLE'}


# Generated at 2022-06-12 17:00:47.674105
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import re
    import os
    import tempfile
    import shutil
    import sys
    import http.server
    import socketserver
    import ssl
    import threading
    import urllib

    def cut_off_chunk(stream):
        """
        Stream wrapper that cuts off a stream after certain size (8192 bytes).
        """
        size = 0
        for s in stream:
            size += len(s)
            if size > 8192:
                break
            yield s

    def http_auth(request, response, content):
        """
        Test basic HTTP authentication.
        """
        assert 'Authorization' in request.headers
        assert request.headers['Authorization'].startswith('Basic ')
        encoded = request.headers['Authorization'][6:]

# Generated at 2022-06-12 17:00:57.664049
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Check if it gives proper output for given input
    # (This is just a smoketest).
    import filecmp

    filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'HttpFD.test')
    filename2 = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'HttpFD.test2')

    # Prepare test file
    with open(filename, 'wb') as stream:
        for i in range(0, 10000):
            stream.write(b'%06d\n' % i)

    # Download it via HttpFD

# Generated at 2022-06-12 17:01:08.444192
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .compat import (
        compat_urllib_request,
        compat_urllib_parse,
        compat_urllib_error,
        compat_urlparse,
    )

    # Source: http://people.virginia.edu/~rj6n/unicode/

# Generated at 2022-06-12 17:01:22.422723
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import test_urls as test_urls_mod

    def _run_test(test_name, test_url_data, args={}, expected_buf=None):
        print('%s: ' % test_name, end='')
        if isinstance(test_url_data, str):
            test_url = test_url_data
        else:
            test_url, video_id = test_url_data

        class DummyHttpFd:
            def __init__(self_):
                self_.params = args.copy()
                self_.to_screen = lambda *args: None
                self_.to_stderr = lambda *args: None

            @staticmethod
            def urlopen(request):
                # Convert URL to the redirection used by real_download
                video_id = request.get_

# Generated at 2022-06-12 17:01:34.195172
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    from .compat import compat_urllib_error
    from .utils import HttpClient
    from .postprocessor import FFmpegMergerPP
    import os


# Generated at 2022-06-12 17:02:16.393759
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .compat import compat_http_server
    from .compat import urlopen
    import random
    import threading
    import time

    # Server that sends content in a single chunk
    class SingleChunkTestServer(compat_http_server.HTTPServer):
        def __init__(self, content, block_size=None):
            if block_size:
                import io
                self._content = io.BytesIO(content)
                self._block_size = block_size
            else:
                self._content = content
                self._block_size = None
            compat_http_server.HTTPServer.__init__(self, ('127.0.0.1', 0), SingleChunkTestServer.SingleChunkTestRequestHandler)

        def handle_error(self, *args):
            pass


# Generated at 2022-06-12 17:02:29.710169
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(urlopen('http://www.google.com/'))
    assert fd.read(4) == '<!do'
    assert fd.read()

    fd = HttpFD(urlopen('http://www.google.com/'))
    assert fd.read(4) == '<!do'
    assert fd.fileno() is None
    assert fd.read()

    fd = HttpFD(urlopen('http://www.google.com/'))
    assert fd.read(4) == '<!do'
    assert fd.tell() == 4
    assert fd.read()

    fd = HttpFD(urlopen('http://www.google.com/'), close=False)
    assert fd.read(4) == '<!do'

# Generated at 2022-06-12 17:02:40.570477
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    FILE_SIZE = 8192
    FILE_SIZE_OVER_LIMIT = FILE_SIZE + 2048
    test_fd = HttpFD(None, {}, 'http://localhost', None)
    with tempfile.NamedTemporaryFile(prefix='ytdl-test-size', delete=False) as tf, \
        tempfile.NamedTemporaryFile(prefix='ytdl-test-maxsize', delete=False) as tf_max, \
        tempfile.NamedTemporaryFile(prefix='ytdl-test-minsize', delete=False) as tf_min:
        for i in range(FILE_SIZE // 10):
            tf.write(b'0123456789')
            tf.flush()
            tf_max.write(b'0123456789')
            tf_max.flush

# Generated at 2022-06-12 17:02:52.643930
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:03:00.030951
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import StringIO
    data = StringIO.StringIO('Hello World\nThis is a test\n')
    fd = HttpFD(data, {'content-type': 'audio/mpeg'})
    assert fd.read() == 'Hello World\nThis is a test\n'
    assert fd.size == 22
    assert fd.name == 'http-response.audio/mpeg'

# Download a single file

# Generated at 2022-06-12 17:03:11.124791
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # A small utility to prepare a test file with a given size
    def _prepare_test_file(tmpfilename, size):
        with open(tmpfilename, 'wb') as test_file:
            test_file.write(b'a' * size)

    # The test is made by creating a file of 500kB and
    # check that real_download downloads only 300kB
    # creating/downloading a 500kB would take too much time
    # and is not needed here

    # first of all we need a valid download context
    # with proper fields, in case real_download makes use of them
    class FakeInfo:
        def __init__(self, video_id):
            self.video_id = video_id


# Generated at 2022-06-12 17:03:19.603487
# Unit test for constructor of class HttpFD

# Generated at 2022-06-12 17:03:26.048709
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def get_test_HttpFD(stream, params, filename, resume_len, tmpfilename):
        class TestHttpFD(HttpFD):
            def __init__(self, ydl, params, filename, resume_len, tmpfilename):
                super(TestHttpFD, self).__init__(ydl, params, filename, resume_len, tmpfilename)
                self.stream = stream
                self.tmpfilename = tmpfilename
                self.noise_bytes = b''
                self.chunk_size = self.params.get('testchunksize')
                if self.chunk_size is not None:
                    # Add random noise bytes to the beginning of the file,
                    # to make sure that only the chunk is downloaded properly
                    self.noise_bytes = compat_urandom(random.randint(0, self.chunk_size))


# Generated at 2022-06-12 17:03:36.489661
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(HttpFD):
        def __init__(self, ydl, params, info_dict):
            self.ydl = ydl
            self.ydl.params = params
            self.ydl.params['outtmpl'] = '%(ep)s.%(format_id)s.%(ext)s'
            self.ydl.params['nooverwrites'] = False
            self.ydl.params['continuedl'] = True
            self.ydl.info_dict = info_dict

        def _hook_progress(self, status):
            pass

        def _downloader_fatal(self, msg, exc_info=None):
            pass
    class MockYDL(object):
        def to_screen(self, msg):
            print(msg)

# Generated at 2022-06-12 17:03:45.290858
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    fd, fname = tempfile.mkstemp(prefix='youtube-dl-test_')
    assert(fd > 0)
    f = HttpFD(fd, 'wb', 4, {'foo': 'bar'})
    assert(f.info().get('foo') == 'bar')
    assert(f.read(4) == b'')
    assert(f.read(4) == b'')
    f.write(b'hello')
    assert(f.read(4) == b'')
    f.write(b'world')
    f.close()
    assert(os.path.getsize(fname) == 10)
    os.close(fd)
    try:
        os.unlink(fname)
    except (OSError, IOError):
        pass


# Generated at 2022-06-12 17:05:11.254656
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def test_download(t):
        # Create a new HttpFD object
        ydl = YouTubeDL()
        ydl.params.update(t['params'])
        http_fd = HttpFD(ydl, t['info_dict'], t['params'])
        http_fd._hook_progress = lambda x: None
        # Download the file
        success = http_fd.real_download(
            t['url'],
            t['filename'],
            t['info_dict'],
            t['resume_len'],
            t['add_header_row']
        )
        # Test if the downloaded file size is correct
        if ('expected_bytes' not in t) or t['expected_bytes'] is None:
            return success

# Generated at 2022-06-12 17:05:16.584740
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    try:
        from io import BytesIO
    except ImportError:
        from StringIO import StringIO as BytesIO

    from tempfile import NamedTemporaryFile

    from .extractor.common import InfoExtractor
    from .utils import encodeFilename

    # Helper functions
    def urlopen_text(url, data=None, relurl=None, headers={}):
        if relurl:
            assert url.endswith(relurl)
        return compat_urllib_request.urlopen(
            compat_urllib_request.Request(
                url, data=data, headers=headers))

    def urlopen_bytes(url, data=None, relurl=None, headers={}):
        if relurl:
            assert url.endswith(relurl)

# Generated at 2022-06-12 17:05:26.513006
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil
    from .utils import encodeFilename

    filename = tempfile.mktemp(prefix='youtube-dl-test-', suffix='.tmp')
    dest_stream, dest_filename = sanitize_open(
        filename, 'wb')
    ydl = FakeYDL()

    fd = HttpFD(ydl, None, {
        'continuedl': False,
        'nooverwrites': False,
        'retries': 10,
        'test': True,
        'verbose': True,
        'ratelimit': None,
        'noresizebuffer': True,
        'logger': ydl,
    })

    def _hook_progress_test(status):
        assert status['status'] in ['downloading', 'finished']
        tmpfilename = status['tmpfilename']


# Generated at 2022-06-12 17:05:38.859497
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    destination = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_downloaded_file.tmp')
    if os.path.isfile(destination):
        os.remove(destination)
    # Test for valid URL
    h = HttpFD(None)
    h.params = {
        'nocheckcertificate': True,
        'test': True,
    }
    h.to_screen = h.to_stderr = lambda x: None
    h.report_destination = lambda x: None
    assert(h.real_download('http://localhost/test', {'test_option': None}, {'test_request': None}, destination))
    assert(os.path.isfile(destination))
    os.remove(destination)
    # Test

# Generated at 2022-06-12 17:05:49.174610
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test function for method real_download of class HttpFD
    """
    url = 'http://localhost:1337/greeting'
    # instanciate a server for testing the method real_download of class HttpFD
    server = Server(url)
    # Start the server
    Thread(target=server.serve_forever).start()
    # instanciate a HttpFD object
    hfd = HttpFD(None, params={'quiet': True},
        progress_hooks=[lambda x: None])
    # set options of the HttpFD object
    hfd.to_screen = False
    hfd.report_destination = lambda filename: None
    # test HTTP download
    assert hfd.real_download(url, None, 'test_HttpFD_real_download', {'test': 'test'})

# Generated at 2022-06-12 17:05:58.368982
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile

    # Set up logging
    class FakeLogger():
        @staticmethod
        def debug(fmt, *args, **kwargs):
            print(fmt % args)
        @staticmethod
        def warning(fmt, *args, **kwargs):
            print(fmt % args)
    ydl_logger = FakeLogger()

    # Set up callback to notice
    def notice_hook(data):
        print('%s' % data)
    notice_hook_handler = lambda x: None
    notice_hook_handler.__name__ = 'notice_hook'

    # Set up callback to test
    def test_hook(data):
        if data['status'] == 'finished':
            print('%s  Download finished' % data['filename'])

# Generated at 2022-06-12 17:06:05.377329
# Unit test for constructor of class HttpFD
def test_HttpFD():
    urlopen = compat_urllib_request.build_opener(URLOpenMixin).open
    with urlopen('http://example.com/') as f:
        http_fd = HttpFD(f, 'http://example.com/')
        assert http_fd.read(1) == b'<'
        assert http_fd.read() == f.read()
        assert http_fd.read() == b''
        assert http_fd.geturl() == 'http://example.com/'
        assert http_fd.info() is not None
        assert http_fd.getheader('Content-Type') == 'text/html'
        assert http_fd.getcode() == 200
        assert http_fd.geturl() == 'http://example.com/'
        # http_fd.close() # no close method



# Generated at 2022-06-12 17:06:09.221876
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(FakeYDL(), {}, u'http://127.0.0.1:0/')
    assert fd.ydl is not None
    assert fd.params == {}
    assert fd.url == u'http://127.0.0.1:0/'



# Generated at 2022-06-12 17:06:20.379626
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import unescapeHTML


# Generated at 2022-06-12 17:06:32.288300
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kargs: None

        def urlopen(self, req):
            class FakeResponse(object):
                def __init__(self, info):
                    self.info = lambda: info
                    self.read = self._read
                    self.read_len = 0
                    self.read_data = os.urandom(self._TEST_FILE_SIZE)

                def _read(self, n=-1):
                    n = n if n >= 0 else len(self.read_data)
                    data = self.read_data[self.read_len:self.read_len + n]
                    self.read_len += len(data)
                    return data
