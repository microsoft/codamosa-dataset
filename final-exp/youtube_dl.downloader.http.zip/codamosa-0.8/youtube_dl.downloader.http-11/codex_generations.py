

# Generated at 2022-06-12 17:00:03.535953
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Encodings
    assert HttpFD(BytesIO(b'Foo'), 'blah') == b'Foo'
    assert HttpFD(BytesIO(b'\xc3\xa4\xc3\xb6\xc3\xbc'), 'iso-8859-1') == 'äöü'
    assert HttpFD(BytesIO(b'\xe4\xf6\xfc'), 'iso-8859-1') == 'äöü'
    assert HttpFD(BytesIO(b'\xe4\xf6\xfc'), 'utf-8') == 'äöü'
    assert HttpFD(BytesIO(b'\xc3\xa4\xc3\xb6\xc3\xbc'), 'latin1') == 'äöü'

# Generated at 2022-06-12 17:00:08.349092
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create HttpFD instance
    Instance = HttpFD()

    # Get filesize
    assert Instance._TEST_FILE_SIZE == 8192, "Unexpected filesize"



# Generated at 2022-06-12 17:00:20.570231
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import socket
    import youtube_dl.utils
    # Get the IP of www.google.com
    ip = socket.gethostbyname('www.google.com')
    # Create an HttpFD object (wrap it in an object to simulate a YoutubeDL object)
    ydl = youtube_dl.YoutubeDL({'cookiefile': 'test.cookie', 'noprogress':True})
    ydl.fd = HttpFD(ydl, ip, '/', {'Range': 'bytes=0-10'}, {'User-Agent': 'Test'})
    # Test read()
    print(ydl.fd.read(5))
    ydl.fd.close()
    # Test realclose()

# Generated at 2022-06-12 17:00:28.091556
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import doctest
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    suite = doctest.DocTestSuite(HttpFD)
    unittest.TextTestRunner().run(suite)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:00:41.561938
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import socket, sys
    if sys.version_info[:2] >= (2, 7):
        from urllib.error import HTTPError
    else:
        from urllib2 import HTTPError
    from .compat import compat_urllib_error, compat_urllib_request

    # Sample real-world data
    #url = 'https://vimeo.com/157748416'
    #headers = {'User-Agent': 'Mozilla/5.0'}

    # Sample youtube-dl data
    url = 'http://127.0.0.1:82/'
    headers = {'User-Agent': 'test'}


# Generated at 2022-06-12 17:00:49.667255
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params = {
        'test': True,
    }
    info_dict = {
        'id': 'test',
        'title': 'test',
        'url': 'http://localhost/test.file',
        'ext': 'mp4',
        'format': 'Test format',
        'player_url': None,
    }
    fd = HttpFD(params, info_dict)
    return fd



# Generated at 2022-06-12 17:00:58.841885
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Simple test for constructor of class HttpFD
    """
    from .extractor.youtube import YoutubeIE
    from .utils import std_headers

    ydl = YoutubeIE(dict())
    headers = std_headers
    filename = u"test"
    url = "http://test.test/test"
    params = {
        'username': 'user',
        'password': 'pass',
        'format': 'best',
        'noprogress': True,
    }
    ydl.fd.add(u'test', headers, url, filename, 1, params)
    info_dict = {
        'id': 'test',
        'upload_date': '20120101',
        'extractor': 'test',
        'uploader': 'test',
    }

# Generated at 2022-06-12 17:01:03.035077
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .postprocessor.ffmpeg import FFmpegExtractAudioPP
    from .utils import DateRange
    import os
    import sys

    def _run_test(filename, tmpfilename, do_dl, test_size, retcode = 0, expected_status = 'finished', contentlength = None, mimetype = 'video/webm', test = None):
        class FakeYtdl(object):
            def __init__(self, params):
                self.params = params
            def to_screen(self, *args, **kargs):
                pass
            def trouble(self, *args, **kargs):
                pass
            def report_error(self, *args, **kargs):
                pass
            def urlopen(self, *args, **kargs):
                return compat_ur

# Generated at 2022-06-12 17:01:05.651118
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for python 2.6 and python 2.7
    assert HttpFD(sanitized_Request(''), None).read(100) == ''
    return True


# Generated at 2022-06-12 17:01:19.381906
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params = {
        'usenetrc': True,
        'username': 'foo',
        'password': 'bar',
        'read_size': '10k',
        'limit_rate': '5k',
        'retries': '5',
        'continuedl': True,
        'nocheckcertificate': True,
        'prefer_insecure': True,
        'http_chunk_size': '3k',
        'outtmpl': u'%(title)s.f%(id)s.%(ext)s',
        'sleep_interval': 5,
    }
    fd = HttpFD('http://host:80/%s', 'dummy.srt', params)
    assert fd.url == 'http://host:80/dummy.srt'
    assert f

# Generated at 2022-06-12 17:02:02.534469
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # http_chunk_size is set to be >= test cases' chunk_sizes
    http_chunk_size = 5
    http_retries = 5
    http_test = True
    # http_test should be closed/unset after test ends, however
    # closing/unsetting it in test (e.g. by assigning None to it) may cause
    # errors (see https://github.com/ytdl-org/youtube-dl/issues/5373)
    # hence the use of del statement to remove it after the test.

# Generated at 2022-06-12 17:02:14.735478
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile

    class MyHttpFd(HttpFD):
        def __init__(self, ydl):
            self.ydl = ydl

        def to_screen(self, msg):
            print(msg)

        def to_stderr(self, msg):
            print(msg)

        def report_error(self, msg):
            print(msg)

        def report_retry(self, err, count, retries):
            print('try again')

    ydl = FakeYDL()
    ydl.params['retries'] = 3
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    h = MyHttpFd(ydl)


# Generated at 2022-06-12 17:02:27.761850
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    HttpFD: Test ability of real_download() method to download a file in chunks.

    When measuring speed and ETA real_download() should ignore chunks
    downloaded by previous runs.
    """
    import tempfile
    import unittest
    import shutil
    import os
    import socket
    import time
    from http.client import HTTPResponse
    from http.client import BadStatusLine
    from http.client import CannotSendRequest
    from http.client import ResponseNotReady
    from http.client import NotConnected

    from .compat import compat_http_client
    from .compat import compat_urllib_error
    from .utils import encodeFilename
    from .utils import TAG_RE

    class FakeSocket(object):
        """Fake Socket object."""


# Generated at 2022-06-12 17:02:36.895832
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import socket
    # Create test socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Try to connect to an unreachable host
    try:
        s.connect(('10.255.255.1', 80))
    except socket.error:
        pass

    # Assert that HttpFD constructor doesn't raise any exception
    # (see https://github.com/rg3/youtube-dl/issues/519)
    HttpFD(s, None, None, None, None)


# Generated at 2022-06-12 17:02:49.220163
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import socket
    def mock_urlopen(request):
        class MockSocket(object):
            def __init__(self, bufsize):
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.connect(('localhost', 80))
                self.data = b''
                self.bufsize = bufsize
            def recv(self, bufsize):
                sock = self.sock
                data = self.data
                bufsize = self.bufsize
                if len(data) < bufsize:
                    data += sock.recv(bufsize - len(data))
                ret = data[:bufsize]
                self.data = data[bufsize:]
                return ret

# Generated at 2022-06-12 17:02:53.752727
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD("http://example.com/", None, {'test_option': 1})
    assert h.has_high_speed()
    assert not h.troublesome_server()
    assert h.params['test_option'] == 1

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:03:04.099574
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a test file with a known content
    test_file_content = b'I am a test file. This is my content.'
    test_file = io.BytesIO(test_file_content)
    test_file.name = 'test_file.txt'

    # Create a test server
    def test_handler(*args):
        return test_file

    def serve_forever(server):
        server.handle_request()

    _, port = testserver.find_unused_port()
    server = testserver.Server(('localhost', port), test_server.BaseHTTPRequestHandler)
    server.handle = test_handler
    server_thread = threading.Thread(target=serve_forever, args=(server,))
    server_thread.start()

    # Create a destination filename
    destination = tempfile.mktemp

# Generated at 2022-06-12 17:03:12.133125
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_url = 'https://example.com/foo.bar'
    test_temp_name = 'xyz123'
    test_filename = 'test-filename.txt'
    test_data = b'Test content'
    test_mtime = 1426391566

    class MockRequest(object):
        def __init__(self, data, info, headers=None):
            self.data = data
            self.info = lambda: info
            self.headers = headers

    class MockYtdl(object):
        def __init__(self, response):
            self.response = response

        def urlopen(self, *args, **kwargs):
            return self.response

    mock_urlopen_map = {}
    oc = object()  # one-time counter


# Generated at 2022-06-12 17:03:20.276542
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import re

    URL = 'http://www.example.com/'
    # Create a memory wrapper to simulate object returned by urllib2.urlopen
    class Content:
        def __init__(self, content=b'abcdefghijkl'):
            self.content = content
        def read(self, *args, **kwargs):
            return self.content
        def info(self):
            return {}

    content = Content()

    # Create a HttpFD object with no content-length header and make sure that
    # it throws an exception
    try:
        fd = HttpFD(content, URL, 'wb')
        assert False
    except IOError as err:
        assert re.match(r'Length of the data \(0 bytes\) is smaller than min_filesize \(1 bytes\)', str(err)) is not None

# Generated at 2022-06-12 17:03:26.599484
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class HttpTestDataContextManager(object):
        def __init__(self, data):
            self.data = data

        def __enter__(self):
            return self.data

        def __exit__(self, exc_type, exc_value, traceback):
            pass


# Generated at 2022-06-12 17:04:36.888845
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    ydl = YoutubeDL()
    ydl.params['noprogress'] = True
    url = 'https://github.com/ytdl-org/youtube-dl/archive/master.zip'
    filename = '-'
    info = {
        'url': url,
        'http_headers': {'User-Agent': str(ydl)},
        'filesize': 1780459,
    }
    # test for normal downloading
    fd = HttpFD(ydl, filename, info, None, False)
    fd.prepare_and_start()
    for i in range(0, info['filesize'], 1024 * 32):
        sys.stdout.write(fd.read(1024 * 32))
    sys.stdout.flush()
    fd.finish()

# Generated at 2022-06-12 17:04:43.809111
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # pylint: disable=W0212
    # Create an instance of class HttpFD
    HTTP_FD = HttpFD('http://www.example.com/test.html', test=True)

    # Test attribute 'url'
    assert HTTP_FD.url == 'http://www.example.com/test.html'
    # Test attribute 'title'
    assert HTTP_FD.title is None
    # Test attribute '_info_dict'
    assert HTTP_FD._info_dict == {}
    # Test attribute 'params'

# Generated at 2022-06-12 17:04:48.802782
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    def _test_block_size(block_size):
        hd = HttpFD()
        ctx = hd.ctx
        ctx.tmpfilename = '-'
        ctx.open_mode = 'wb'
        ctx.block_size = block_size
        ctx.is_test = True
        ctx.data_len = hd._TEST_FILE_SIZE

        # requested range end
        is_single_chunk = block_size * 2 > hd._TEST_FILE_SIZE
        range_end = hd._TEST_FILE_SIZE - 1 if is_single_chunk else block_size * 2 - 1

        # http header with requested range

# Generated at 2022-06-12 17:04:58.846047
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create and initialize a progress message hook
    progress_message_hook = []
    def progress_message_hook_listener(d):
        progress_message_hook.append(d)

    # Create a test HttpFD object
    http_fd = HttpFD(
        {}, None, {
            'noprogress': True,
            'retries': 0,
            'continuedl': True,
            'ratelimit': 0,
            'noresizebuffer': True,
            'logger': YoutubeDL(None),
            'progress_hooks': [progress_message_hook_listener],
        })

    # Run real_download() method

# Generated at 2022-06-12 17:05:10.208186
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Testing corner cases of https://github.com/ytdl-org/youtube-dl/issues/8291
    # Uses internal method _TEST_FILE_SIZE to limit memory needed by the test.
    # TODO: consider use of setUpClass on Python 2
    # (not available on Python 3) to run it just once (and prepare class variables here)
    class MockYtdlFD:
        ydl = None

# Generated at 2022-06-12 17:05:19.044629
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    dl = YoutubeDL({})
    dl.report_warning = lambda *args, **kargs: None
    url_info = {'url': 'http://localhost:1024'}

# Generated at 2022-06-12 17:05:27.037516
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYDL:
        params = None

    ydl = FakeYDL()

    for (p, fp) in [
            ('http://www.google.com/index.html', None),
            ('-', sys.stderr),
            ('http://www.google.com/index.html', sys.stderr)]:
        h = HttpFD(ydl, p, {}, fp)
        assert h.url == 'http://www.google.com/index.html'
        assert h.temp_name == p
        assert h.fd is fp


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 17:05:39.357561
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for proper operation of the constructor of HttpFD
    #
    # This test is designed to catch instances where the constructor may throw
    # a "BadStatusLine" exception. See
    # http://stackoverflow.com/questions/1450393/python-http-client-library-to-get-headers-and-content-in-separate-variables

    # Test for zero length URL
    try:
        hfd = HttpFD('http://', None, {})
    except (compat_urllib_error.URLError, compat_http_client.BadStatusLine) as err:
        # Python 2.6 raises a URLError, while 2.7 raises a BadStatusLine
        assert str(err) == 'unknown url type: http'
    else:
        assert 0

    # Test URL ending in '/

# Generated at 2022-06-12 17:05:49.601551
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import threading
    # This variable is used to indicate if the test file has been downloaded in its entirety.
    # The test_download_progress hook sets it to True
    file_downloaded = False

    # This function tests the content of the temporary test file
    def check_downloaded_file():
        assert os.path.splitext(ydl.tmpfilename)[1] == (
            ydl.params.get('outtmpl') or ydl.params['outtmpl']).split('%(ext)s')[1]
        assert ydl.real_download(ydl.params['url'], {
            'tmpfilename': ydl.tmpfilename,
            'progress_hooks': [ydl.hook_test_progress],
            'noprogress': True
            })
        file_downloaded = True


# Generated at 2022-06-12 17:05:58.662116
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # This test is designed to be run from the current directory
    # Note: the test may fail if youtube-dl is already in PYTHONPATH

    import os
    import tempfile
    from .compat import encodeFilename, compat_urllib_error

    # Preparing test data
    data = b'\x00\xF0foobar\t\n\t<\xF2>'
    hash = 'b087cce69d97e4e18b78f4c4c7e4348f'
    url = 'http://127.0.0.1:43998/content.mp4'
    url2 = 'http://127.0.0.1:43998/redirect1'
    url3 = 'http://127.0.0.1:43998/redirect2'

# Generated at 2022-06-12 17:08:52.863372
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def multipart_dl(stream, headers, newurl=None, expected_frags=None):
        from .YoutubeDL import YoutubeDL
        from .compat import compat_urllib_request

        def urlopen(req):
            req = compat_urllib_request.Request(
                newurl if newurl is not None else req.get_full_url(),
                data=req.get_data(), headers=req.headers)
            return stream
        ydl = YoutubeDL({'continuedl': True})
        ydl.params['noprogress'] = True
        ydl.params['noresizebuffer'] = True
        ydl.params['test'] = True
        ydl.urlopen = urlopen
        newurl = newurl or 'http://example.com/video.mp4'
        parts = HttpFD

# Generated at 2022-06-12 17:08:59.139575
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Define some test data
    s = 'README.md\x00https://raw.github.com/rg3/youtube-dl/master/README.md\n'

    # Retrieve length of data
    data_len = len(s)

    # Construct HttpFD object
    http_fd = HttpFD(BytesIO(s.encode('utf-8')), data_len)

    # Assert length of data
    assert http_fd.len == data_len


# Generated at 2022-06-12 17:09:08.503420
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # a file that's big enough to make sure resuming works
    url = 'https://github.com/rg3/youtube-dl/raw/master/youtube_dl/LICENSE'
    # if this test fails then the file is too small and this test won't work
    # this would be inconsistent to the first test for real_download
    assert int(compat_urllib_request.urlopen(url).info()['Content-length']) > 1000 * 1000 * 10
    out_file = xbmcvfs.File(os.path.join(TEST_OUT_DIR, 'out'), 'w+')
    test_socket = TestSkt()
    ydl = YoutubeDL({})
    ydl.to_stderr = lambda msg: None
    ydl.to_screen = lambda msg: None
    ydl.report_error

# Generated at 2022-06-12 17:09:14.608659
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test(*a, **ka):
        print(('Test: HttpFD(%s, %s)' % (a, ka)))
        fd = HttpFD(*a, **ka)
        print(('\tlen(fd) = %d' % len(fd)))
        print(('\tfd.real_url = %s' % fd.real_url))
        print(('\tfd.content_type = %s' % fd.content_type))
        print(('\tfd.name = %s' % fd.name))
        return fd

    #first, test with a local file
    tstfd = test('testid', 'test', 'file://' + os.path.abspath(__file__))
    for i in range(len(tstfd)):
        assert tst

# Generated at 2022-06-12 17:09:25.473610
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    from .utils import search_dict

    def get_info_dict(downloader, **kwargs):
        ie = gen_extractors().next()
        ie.extract(downloader, 'http://localhost/')
        return search_dict(ie.info_dict, *kwargs)

    # No resuming
    downloader = FD_Registry().downloader_for('http://localhost/')
    if not downloader.real_download(get_info_dict(downloader), '-'):
        raise AssertionError('Test file couldn\'t be downloaded')

    # Check resume
    downloader = FD_Registry().downloader_for('http://localhost/')