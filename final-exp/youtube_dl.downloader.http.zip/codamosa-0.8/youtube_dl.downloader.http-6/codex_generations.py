

# Generated at 2022-06-12 17:00:01.188650
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a dummy output file
    with open('test', 'wb') as output_file:
        output_file.write(b'Hello World')
    output_file.close()

    h = HttpFD(
        params = {'nooverwrites': True, 'verbose': True},
        info_dict = {'id': 'test'}
    )
    h.to_screen('\n')
    assert h.real_download(
        url='file://' + os.path.abspath('test'),
        filename='test2',
        info_dict={'id': 'test', 'title': 'testTitle', 'ext': 'testExt'}
    ) == True

    # Remove the dummy output file
    os.remove('test')


# Generated at 2022-06-12 17:00:03.469743
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://127.0.0.1/')
    fd.read()
    fd.close()


# Generated at 2022-06-12 17:00:14.602735
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD('http://www.example.com/').read(1024)
    assert HttpFD(sanitized_Request('http://www.example.com/'))
    # Only when it's actually read do we discover it was a 404
    assert '404' in HttpFD('http://www.example.com/foo-bar-qux',
                           expected_status=None).read(1024)
    assert HttpFD('http://www.example.com/foo-bar-qux',
                  expected_status=(200, 404)).read(1024)


# Generated at 2022-06-12 17:00:23.121627
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # check if we can get HttpFD objects
    # no exception should be raised in the following tests
    # we kind of depend of a network connection
    assert_raises(IOError, HttpFD, 'http://foo/bar', None, 'wb')
    assert_raises(IOError, HttpFD, 'http://foo/bar', None, 'wb', 16384)
    assert_raises(IOError, HttpFD, 'http://foo/bar', None, 'wb', 16384, 10)
    fd = HttpFD('http://foo/bar', None, 'wb', 16384, 10, False)
    assert_raises(IOError, fd.retrieve, 'http://foo/bar', '-')
    fd = HttpFD('http://foo/bar', None, 'wb', 16384, 10)


# Generated at 2022-06-12 17:00:37.125404
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    info = {
        'url': 'http://127.0.0.1:1337/testfile.bin',
        'http_headers': {'Referer': 'http://127.0.0.1'},
        'player_url': 'http://127.0.0.1/player.swf',
    }
    tmpfilename = tempfile.mktemp(prefix='youtubedl-test-', suffix='.tmp')
    try:
        fd = HttpFD(info, params={'continuedl': True, 'quiet': True,
                                  'nooverwrites': True,
                                  'test': True})
        success = fd.real_download(tmpfilename)
        assert success
    finally:
        if os.path.exists(tmpfilename):
            os.remove(tmpfilename)



# Generated at 2022-06-12 17:00:47.742074
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url = 'http://127.0.0.1:8080/3.mp4'
    target_file = '3.mp4'
    fsize = os.path.getsize(target_file)
    # Sanity check
    assert int(fsize) > 0
    # Initialize test
    stream = SanitizedFileObject(open(target_file, 'rb'))
    urllib2.install_opener(urllib2.build_opener(urllib2.HTTPHandler, urllib2.HTTPSHandler))
    def test_urlopen(request):
        return urllib2.Request.get_method(request) == 'HEAD' and stream or 'http://127.0.0.1:8080/3.mp4'

# Generated at 2022-06-12 17:00:58.673896
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    old_threading = compat_threading.threading
    old_time = compat_time.time
    old_os = compat_os
    old_shutil = compat_shutil
    old_stat = compat_stat
    old_atexit = compat_atexit
    old_base64 = compat_base64
    old_struct = compat_struct
    old_hashlib = compat_hashlib
    old_http_client = compat_http_client
    old_http_cookiejar = compat_http_cookiejar
    old_cookielib = compat_cookielib
    old_re = re
    old_email_message = email_message
    old_socket = compat_socket

# Generated at 2022-06-12 17:01:08.883116
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test the constructor of HttpFD
    # This test is incomplete, as it does not test the download logic
    # Test for HTTP connection
    http1 = HttpFD(params={})
    http1.add_header('Range', 'bytes=100-199/1234')
    http1.add_header('Cookie', '$Version=0; Skin=new;')
    http1.add_header('Accept-Charset', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7')
    http1.add_header('bar', 'foo')
    print(http1.headers)
    http1.report_destination('foo')
    # Test for HTTP connection with proxy
    http2 = HttpFD(params={'proxy': 'http://foobar.invalid'})
   

# Generated at 2022-06-12 17:01:22.729246
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    WGETDOWNLOADER = 'wget --continue --no-check-certificate --load-cookie %(cookie_file)s --save-cookie %(cookie_file)s --keep-session-cookies'
    url = 'http://127.0.0.1/files/100k.bin'
    fd = HttpFD(None, {'wget_downloader': WGETDOWNLOADER, 'quiet': True, 'retries': 3, 'fragment_retries': 10, 'test': True, 'prefer_insecure': True}, {'url': url})
    # Check data length
    info = {'url': url, 'http_headers': {'Content-length': str(100*1024)}}
    fd.real_download(info, '100k.test', lambda x: None)

# Generated at 2022-06-12 17:01:34.393597
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Downloading and verifying file')
    url = 'https://raw.githubusercontent.com/danieljo/youtube-dl/master/LICENSE'
    cfg = {
        'nooverwrites': True,
        'outtmpl': 'test_%(id)s',
        'continuedl': True,
        'simulate': True,
        'dump_intermediate_pages': False,
        'noprogress': False,
        'logger': YoutubeDL(),
    }
    fd = HttpFD(cfg, url, None)
    fd.prepare()
    fd.real_download(params={'test': True})

    assert isinstance(fd.tmpfilename, str)
    assert fd.tmpfilename.startswith('test_')
    tmpname = fd.tmpfilename

# Generated at 2022-06-12 17:02:14.815864
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(sanitized_Request('http://localhost/'), None)
    assert fd.real_url == 'http://localhost/'
    assert fd.headers == {}
    assert fd.status == 200
    fd = HttpFD(sanitized_Request('http://localhost/'), compat_urllib_response.addinfourl(None, {}, 'http://localhost/'))
    assert fd.real_url == 'http://localhost/'
    assert fd.status == 200
    fd = HttpFD(sanitized_Request('http://localhost/'), compat_urllib_response.addinfourl(None, {'location': 'http://localhost:8080/'}, 'http://localhost/'))
    assert fd.real_url == 'http://localhost:8080/'

# Generated at 2022-06-12 17:02:27.867050
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:02:39.695338
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case where open() succeeds
    def test_1():
        class MyHttpFD(HttpFD):
            def _real_initialize(self, *args, **kwargs):
                raise NotImplementedError()
            def _do_open(self, *args, **kwargs):
                pass
        hf = MyHttpFD('/dev/null', 'wb')
        assert not hf.closed
        assert hf.fp is None
        assert hf.url == '/dev/null'
        assert hf.temp_file is None
        hf.close()
        assert hf.closed
        assert hf.fp is None
    test_1()
    # Test case where open() raises an IOError

# Generated at 2022-06-12 17:02:51.846737
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Test real_download of class HttpFD
    """

    def urlopen(request):
        return FakeYTDLHTTPResponse(
            StringIO('\n'.join(map(str, list(range(100000)))) + '\n'),
            {'Content-Type': 'text/plain'})

    params = {
        'nooverwrites': False,
        'continuedl': False,
        'noprogress': False,
        'retries': 10,
        'buffersize': 1024,
        'noresizebuffer': False,
        'test': True,
    }

    class FakeYTDL(object):
        def __init__(self):
            self.params = params

# Generated at 2022-06-12 17:03:03.344650
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Mock objects
    test_url = 'http://www.example.com/video.mp4'
    test_filename = 'video.mp4'
    test_tmpfilename = test_filename + '.tmp'
    test_data_len = 5
    test_block_size = 1
    test_headers = {}
    test_params = {}

    def test_progress_hook(status):
        pass


# Generated at 2022-06-12 17:03:14.717619
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Unit test for method real_download of class HttpFD.
    """
    # Testing parameters
    test_name = 'test_url.bin'
    test_download_size = 1024*1024 # Bytes

    # Testing code
    # File to simulate
    f = open(test_name, 'rb')
    f.seek(0, os.SEEK_END)
    file_size = f.tell()
    # Prepare parameters for open
    params = {
        'noprogress': True,
        'retries': 0,
    }
    # Open
    test_fd = HttpFD(test_name, params)
    test_fd.test = True
    # Configure test parameters
    test_fd.start()
    test_fd.test_result = {}

# Generated at 2022-06-12 17:03:23.669804
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    from .compat import HTMLParser
    from .compat import compat_urllib_error

    class MockOpener(object):

        def __init__(self):
            self.cookies = []

        def open(self, request, timeout=None):
            return BytesIO(b'abcdefghijklmnopqrstuvwxyz')

    class MockServerHandler(object):
        def __init__(self):
            self.wfile = BytesIO()

        def send_response(self, status, msg=None):
            pass

        def send_header(self, key, value):
            pass

        def end_headers(self):
            pass

    class MockServer(object):
        def __init__(self):
            self.req = None
            self.code = 200

# Generated at 2022-06-12 17:03:31.873606
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    from urllib.parse import urlencode
    video_id = 'BaW_jenozKc'
    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'nocheckcertificate': True,
                'simulate': True,
                'quiet': True,
                'skip_download': True,
            }
            self.progress_hooks = []
        # Fake urlopen
        def urlopen(self, req):
            params = dict(req.data)
            # The following values must be present in request data
            assert 'video_id' in params
            assert params['video_id'] == video_id
            assert 'eurl' in params
            assert 'el' in params
            assert 'range' in params

# Generated at 2022-06-12 17:03:42.611331
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test 1. Prevent crash on old Python versions
    # (http.client.HTTPMessage has no attribute 'get_payload')
    if hasattr(http.client.HTTPMessage, 'get_payload'):
        return  # Newer Python versions pass this test.
    class MockContent(object):
        def read(self):
            pass
    class MockResponse(object):
        def __init__(self):
            self.headers = http.client.HTTPMessage()
            self.headers.status = 200
            self.headers.reason = 'OK'
            self.headers.getheaders = MockContent().read
    class MockUrlopen(object):
        def __init__(self, url, data, headers):
            pass

# Generated at 2022-06-12 17:03:54.389579
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    '''
    Test the real_download() method of class HttpFD
    '''

    class DummyYDL(object):
        '''
        Dummy class for the youtube-dl object
        '''
        params = {}
        def to_screen(self, msg):
            '''
            Emulate the to_screen() function for the YoutubeDL object
            '''
            print(msg)

    dummy_ydl = DummyYDL()

    real_download(
        dummy_ydl,
        {
            'url': 'https://golang.org/doc/gopher/frontpage.png',
            'filename': 'gopher.png',
            'info_dict': {},
        },
        {
            'test': True
        }
    )


# Generated at 2022-06-12 17:04:58.208678
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Note: the filename should be a filename on the filesystem,
    # preferably in the current directory
    url = 'http://localhost/~chunchu/4x4.mp4'
    httptestfd = HttpFD(url, {'noprogress': True})
    filename = httptestfd.get_filename()
    ext = determine_ext(url)

    # The filename that is returned should end in the determined extension
    assert filename.endswith(ext)

    # Since the filename is on a HTTP server, its size is unknown
    size = httptestfd.get_size()
    assert size == -1

    # Download the file using download()
    # Note: the downloaded file should be deleted by the test framework
    httptestfd.download()

    # Open the downloaded file

# Generated at 2022-06-12 17:05:09.193338
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFunction(object):
        def try_utime(self, filepath, modification_time):
            return True

        def to_stderr(self, text):
            print(text)

        def report_error(self, text):
            pass

        def report_retry(self, text, count, retries):
            pass

        def report_destination(self, text):
            pass

        def calc_speed(self, start, now, bytes_downloaded):
            return 1

        def report_resuming_byte(self, byte_counter):
            pass

        def report_unable_to_resume(self):
            pass

        def report_file_already_downloaded(self, file_name):
            pass

        def slow_down(self, start, now, transferred, chunk_size):
            return

# Generated at 2022-06-12 17:05:18.468341
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:05:23.605377
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD('http://www.google.com/', None, 'wb', 'fake-filename').size is None
    assert HttpFD('http://www.google.com/', 42, 'wb', 'fake-filename').size == 42
    assert HttpFD('http://www.google.com/', '42', 'wb', 'fake-filename').size == 42



# Generated at 2022-06-12 17:05:30.067856
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    def check_equals(v1, v2, msg = None):
        if not v1 == v2:
            print(msg or '')
            print('v1 =', v1)
            print('v2 =', v2)
            raise Exception('check_equals failed')

    def test(ctx = None, url = None, tmpfilename = None, filename = None, blocks = None):
        '''
        @type ctx: _DownloadContext
        '''
        tmpfile = io.FileIO(tmpfilename, 'wb')
        socket.socket = MockSocket(blocks)
        httpfd.urlopen = MockUrlOpen(httpfd, blocks)

        # Do test
        httpfd.real_download(ctx, url, tmpfile)

        # Check result
        tmpfile.close()

# Generated at 2022-06-12 17:05:41.586357
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from io import BytesIO
    from .FileDownloader import FileDownloader
    from .extractor import gen_extractors
    extractors = gen_extractors()
    fd = FileDownloader({'nooverwrites': True}, extractors)
    fd.add_info_extractor(None)
    hdfd = HttpFD(fd, 'http://example.com/')

# Generated at 2022-06-12 17:05:51.060557
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print("Testing real_download() method of class HttpFD")
    # test with https servers
    url1 = 'https://www.youtube.com/watch?v=J---aiyznGQ'
    url2 = 'https://www.youtube.com/watch?v=9bZkp7q19f0'
    url3 = 'https://www.youtube.com/watch?v=lp-EO5I60KA'
    url_list = [url1, url2, url3]
    for url in url_list:
        print("Testing " + url)
        if not real_download_test(url):
            print("Failed testing " + url)
            return
        print("Completed testing " + url)
    print("Completed testing real_download() method of class HttpFD")


# Generated at 2022-06-12 17:05:59.507082
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestYDL(object):
        params = {'noprogress': True, 'retries': 3}
        def __init__(self):
            self.to_stderr = lambda *args, **kargs: None
            self.to_screen = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
        def fix_url(self, url):
            return url
        def urlopen(self, req):
            return compat_urllib_request.urlopen(req)
        def report_retry(self, info, count, retries):
            pass
        def report_file_already_downloaded(self, filename):
            pass
        def report_destination(self, filename):
            pass

# Generated at 2022-06-12 17:06:12.792210
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL()
    ydl.params['noprogress'] = True
    ydl.add_default_info_extractors()

# Generated at 2022-06-12 17:06:25.281451
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.common import InfoExtractor
    from .compat import urlparse

    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ie = InfoExtractor(params={'nooverwrites': True})
    ie.add_info_extractor(
        r'http://(?:www\.)?youtube\.com/watch(?:.*v=|.*/)(?P<id>[0-9A-Za-z_-]{11})',
        youtube_IE)
    ie.add_default_info_extractors()
    info_dict = ie.extract(url)

    # Download the video

# Generated at 2022-06-12 17:08:25.519798
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # We do not need a real download for testing
    class DummyYDL(object):
        params = {}
        def __init__(self):
            self.urlopen_handlers = []
        def add_info_extractor(self, ie):
            pass
        def download(self, filenames):
            pass
        def report_error(self, msg, tb=None):
            pass
        def report_warning(self, msg):
            pass
        def to_screen(self, msg):
            pass
        def trouble(self, msg, tb=None):
            pass
        def urlopen(self, request):
            for handler in self.urlopen_handlers:
                response = handler(request)
                if response is not None:
                    return response
            return None

# Generated at 2022-06-12 17:08:35.357169
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import get_info_extractor
    # Create a new HttpFD subclass object
    class TestHttpFD(HttpFD):
        def download(self, filename, info_dict):
            raise NotImplementedError()
        def report_error(self, msg):
            raise NotImplementedError()
    http_fd = TestHttpFD(YoutubeDL({'continuedl': True, 'nooverwrites': True, 'test': True}))
    # Assert initial state of http_fd
    assert http_fd.ctx.chunk_size == 0
    assert http_fd.ctx.data is None
    assert http_fd.ctx.data_len is None
    assert http_fd.ctx.filename is None
    assert http_fd.ctx.is_resume is False

# Generated at 2022-06-12 17:08:40.346072
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = YoutubeDL({'quiet': True})
    fd = HttpFD(ydl, {'nooverwrites': True, 'continuedl': True}, {'url': 'https://example.com/'})
    # test_data and test_data_len are defined in test_utils (defined above)
    with mock.patch('youtube_dl.utils.urlopen') as urlopen_mock:
        urlopen_mock.return_value.read.side_effect = (
            # first call: simulate server response with no data
            # to trigger connection retry
            lambda _: b'',
            # second call: simulate server response with one block of data
            lambda b: test_data[:b],
            # third call: simulate server response with full data
            lambda _: test_data,
        )
        filename

# Generated at 2022-06-12 17:08:50.043881
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Checks that HttpFD.real_download method downloads the given url."""

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen_lock = threading.Lock()

        def to_screen(self, message):
            with self.to_screen_lock:
                print(message)

        def trouble(self, message, tb=None):
            raise Exception('An error occurred. ' + message)

        def problem(self, message):
            raise Exception('A problem occurred. ' + message)

        def report_error(self, message, tb=None):
            raise Exception('An error occurred: ' + message)

    def _get_test_file():
        """Returns test file's name."""

# Generated at 2022-06-12 17:08:59.424839
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Testing with YouTube video: http://www.youtube.com/watch?v=BaW_jenozKc
    # this test take aprox. 1:30 mins to complete
    from .extractor.youtube import YoutubeIE

    youtube_dl = YoutubeDL()
    youtube_dl.params['verbose'] = True
    youtube_dl.params['format'] = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio'  # audio only
    youtube_dl.params['outtmpl'] = '%(id)s.%(ext)s'

    ie = YoutubeIE()
    info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')


# Generated at 2022-06-12 17:09:08.736249
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .compat import parse_qs
    from .utils import parse_filesize

    sess = compat_urllib_request.build_opener()

# Generated at 2022-06-12 17:09:10.326246
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    from .post import get_downloader

# Generated at 2022-06-12 17:09:12.679070
# Unit test for constructor of class HttpFD
def test_HttpFD():
    info = {'password': 'test'}
    downer = HttpFD(DummyYDL(), info)
    assert downer.ydl is not None
    assert downer.info is not None



# Generated at 2022-06-12 17:09:24.185583
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Base test (no parameters)
    fd = HttpFD('http://www.google.de/', {})
    assert fd.data is None
    assert fd.tmpfilename is None
    assert fd.start_time is None
    assert fd.filename is None
    assert fd.params == {}

    # Test parameters
    fd = HttpFD('http://www.google.de/', {'noprogress': True, 'progress_with_newline': True})
    assert fd.data is None
    assert fd.tmpfilename is None
    assert fd.start_time is None
    assert fd.filename is None
    assert fd.params == {'noprogress': True, 'progress_with_newline': True}
