

# Generated at 2022-06-12 17:00:13.613000
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Testing method real_download of class HttpFD')

    class MockYtdl(object):
        def __init__(self, params, options):
            self.params  = params
            self.options = options

        def report_retry(self, error, count, retries):
            print('%d/%d: %s' % (count, retries, str(error)))

        def report_resuming_byte(self, byte_counter):
            print('Resuming download at byte %d' % byte_counter)

        def report_destination(self, filename):
            print('Destination: ' + filename)

        def to_stderr(self, message):
            print(message)

        def to_screen(self, message):
            print(message)

        def report_error(self, message):
            print

# Generated at 2022-06-12 17:00:22.668469
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_eq(args1, args2):
        fd1 = HttpFD(*args1)
        fd2 = HttpFD(*args2)
        assert fd1 == fd2
        assert fd1.fileno() == fd2.fileno()
        assert fd1.isatty() == fd2.isatty()
        fd1.close()
        fd2.close()

    def test_ne(*args):
        fd1 = HttpFD(*args)
        fd2 = HttpFD(*args)
        assert fd1.get_headers() != fd2.get_headers()
        assert fd1.geturl() != fd2.geturl()
        assert fd1.fileno() != fd2.fileno()
        fd1.close()

# Generated at 2022-06-12 17:00:36.478097
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:00:47.425235
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL:
        def __init__(self):
            self.params = {'nooverwrites': True, 'continuedl': True, 'noprogress': True, 'retries': 10, 'test': True}

        def to_screen(self, s):
            pass

        def trouble(self, s, tb=None):
            raise TypeError(s)

        def report_error(self, s):
            raise TypeError(s)

        def report_retry(self, s, tb=None):
            pass

        def report_resuming_byte(self, bytes):
            pass

        def report_file_already_downloaded(self, file_name):
            pass

        def report_unable_to_resume(self):
            pass


# Generated at 2022-06-12 17:00:58.117835
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Usage: python -m youtube_dl.FileDownloader --test-httpfd-real-download
    print('Testing real_download')
    import socket
    socket.setdefaulttimeout(10)
    class MyFD(HttpFD):
        def __init__(self, *args, **kwargs):
            HttpFD.__init__(self, *args, **kwargs)
            assert self.params.get('nocheckcertificate')
        def to_screen(self, *args, **kwargs):
            pass
        def to_stderr(self, *args, **kwargs):
            pass
        def slow_down(self, *args, **kwargs):
            pass


# Generated at 2022-06-12 17:00:59.458355
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return


# Generated at 2022-06-12 17:01:07.334329
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Test the constructor of class HttpFD."""
    # With test.mp4 already on disk, the constructor should open the
    # file and not download it.
    fd = HttpFD('test.mp4')

    # Check that the file has been opened.
    assert fd.fp
    # Check that the file is not empty.
    assert fd.fp.read()
    # The file should have been marked as downloadable.
    assert fd.download

    # The filename is test.tmp.part.
    assert fd.name == 'test.tmp.part'


# Generated at 2022-06-12 17:01:21.290984
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import shutil
    import time
    import urllib
    from extractor import YoutubeIE
    from url_info import UrlInfo

    file_size = 1024 ** 2

    # To fasten down the test we use a local HTTP server
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('127.0.0.1', 0))
    s.listen(1)
    serverport = s.getsockname()[1]
    t = threading.Thread(target=lambda: http_server(s))
    t.daemon = True
    t.start()
    time.sleep(0.1)

    # Download an URL from our local

# Generated at 2022-06-12 17:01:33.357089
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor

    def check_real_download(ie, params):
        # We have to construct an InfoExtractor instance to test real_download
        # method.
        # To be able to do that we need to mock several things
        # InfoExtractor._print_info is not needed
        ie._print_info = lambda *args, **kargs: None

        # We don't want to download the file, so we substitute urlopen
        # with a lambda that returns a StringIO

# Generated at 2022-06-12 17:01:34.463860
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    return FD_Test().run(HttpFD)



# Generated at 2022-06-12 17:02:16.455546
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import glob

    # Let's not run real downloads if the commands are restricted,
    # as in the distributed binary
    if isinstance(sys.argv, types.ModuleType):
        return

    tmp = os.path.join(gettempdir(), 'youtube-dl')
    if not os.path.isdir(tmp):
        os.makedirs(tmp)

# Generated at 2022-06-12 17:02:24.349663
# Unit test for constructor of class HttpFD
def test_HttpFD():
    info = {'url': 'http://127.0.0.1:81/', 'http_headers': {}}
    fd = HttpFD(info)
    assert fd.real_download is False
    assert fd.info is info
    info = {'url': 'http://127.0.0.1:82/'}
    fd = HttpFD(info)
    assert fd.real_download is True
    assert fd.info is info



# Generated at 2022-06-12 17:02:37.352460
# Unit test for constructor of class HttpFD
def test_HttpFD():
    for protocol, control_url in [('http', 'http://localhost:8001/'), ('https', 'https://localhost:8002/'), ('ftp', 'ftp://localhost:8003/')]:
        def get_downloader(proto, url):
            return HttpFD(YoutubeDL(), url, proto)
        # test that the method get_size raises an error if the server does not support HEAD
        # (supports downloading the file with no Content-Length)
        dl = get_downloader(protocol, control_url + 'nocontentlength')
        try:
            dl.get_size()
            assert False, 'get_size should raise an error when HEAD is not supported'
        except HEADRequestUsed:
            pass  # as expected

# Generated at 2022-06-12 17:02:49.662084
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # It does not have a destructor
    # Therefore it cannot be tested for memory leaks
    h = HttpFD(None, {'noprogress': True})
    assert h is not None
    for i in range(3):
        h.report_retry(None, i + 1, 3)
    h.report_error('xxx')
    h.report_resuming_byte(50)
    h.report_destination('/tmp/xxx')
    h.report_unable_to_resume()
    h.to_stderr('yyy')
    h.to_screen('zzz')
    h.slow_down(time.time(), time.time() + 1, 1000)
    assert isinstance(h.calc_eta(time.time(), time.time(), 2000, 1000), int_or_none)

# Generated at 2022-06-12 17:03:01.457135
# Unit test for constructor of class HttpFD
def test_HttpFD():
    urlh = compat_urllib_request.urlopen('http://www.google.com/')
    fd = HttpFD(urlh)
    data_len = int(urlh.headers.get('Content-Length', 0))
    assert fd.len == data_len
    assert fd.tell() == 0
    if data_len:
        s = fd.read(data_len / 2)
        assert fd.tell() == len(s)
        fd.seek(0)
        assert fd.tell() == 0
        assert fd.read(data_len / 2) == s
        fd.seek(-data_len / 2, 2)
        assert fd.tell() == data_len / 2
        fd.seek(data_len / 2)

# Generated at 2022-06-12 17:03:11.171417
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test that the constructor raises IOError if no HTTP URL is given
    try:
        HttpFD('foobar', params={})
        assert False
    except IOError:
        pass
    except:
        assert False

    # Test that info() raises IOError if not connected
    h = HttpFD('http://www.google.com/', params={})
    try:
        h.info()
        assert False
    except IOError:
        pass
    except:
        assert False


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:03:20.445895
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create and return a StringIO object to be used when testing
    # HttpFD object for file download
    def createTestSIO(content, bufsize=0):
        out_sio = io.BytesIO()
        out_sio.write(content)
        out_sio.seek(0, os.SEEK_SET)
        return out_sio

    # Create a http response with Content-Range HTTP header
    def createResponse(content, start=None, end=None, total=None):
        resp = compat_urllib_response.addinfourl(
            createTestSIO(content),
            compat_httplib.HTTPMessage(createTestSIO('')),
            'http://localhost/', 200)
        resp.code = 200

# Generated at 2022-06-12 17:03:33.005821
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Unit test for method real_download of class HttpFD
    httpfd_instance = HttpFD(None, params={'noprogress': True})
    setattr(httpfd_instance, 'report_error', lambda s: print('ERROR: %s' % s))
    setattr(httpfd_instance, 'report_retry', lambda s1, s2, s3: print('RETRY: %s %s %s' % (s1, s2, s3)))
    setattr(httpfd_instance, 'report_unable_to_resume', lambda: print('UNABLE TO RESUME'))
    setattr(httpfd_instance, 'report_resuming_byte', lambda s: print('RESUMING BYTE: %d' % s))


# Generated at 2022-06-12 17:03:40.905216
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from . import FileDownloader
    ydl = FileDownloader({})
    #
    # Test for non existing file
    assert not ydl.try_retrieve_nonexisting_file('http://localhost/nonexisting')
    #
    # Test for existing file
    urlh = compat_urllib_request.urlopen('http://localhost/test')
    hd = HttpFD(ydl, urlh, None, {'test': True}, {})
    assert hd.test()
#
# Test for test_download

# Generated at 2022-06-12 17:03:47.960845
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Simple test for HttpFD constructor.
    Run it directly for debug output:
    $ python -m youtube_dl.FileDownloader test_HttpFD
    """
    import sys
    testurl = 'https://github.com/rg3/youtube-dl/raw/master/README.md'
    testfilename = 'test'
    maxsize = 100000
    test = HttpFD(
        testurl, testfilename, max_filesize=maxsize,
        progress_hooks=None, retry_hooks=None,
        data=None, params=None, basic_auth_login=None,
        basic_auth_password=None, ua=None,
        referer=None, params=None, bufsize=16384)
    fsize = None
    readsize = 0

# Generated at 2022-06-12 17:05:16.806777
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import encodeFilename, sanitize_open

    def _test_real_download(self):
        # Generate dummy test data
        fake_headers = {'content-type': 'video/webm', 'content-length': str(len(data))}
        self.urlopen.return_value.__enter__.return_value.info.return_value = fake_headers
        self.urlopen.return_value.__enter__.return_value.read.side_effect = lambda n: data[:n]

        tmpfilename = '-'
        stream = None
        chunked = False

        # Run the code to be tested
        info = {
            'report_warning': self.report_warning,
        }

# Generated at 2022-06-12 17:05:27.414503
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import urlencode_postdata

    data = (('a', 'b'),
            ('c', 'd'),
            ('e', 'f'),
            )
    post = urlencode_postdata(data)
    fd = HttpFD(data, post)
    assert fd.headers['Content-Type'] == 'application/x-www-form-urlencoded'
    assert int(fd.headers['Content-Length']) == len(post)
    assert fd.size == len(post)
    assert fd.get_content_type() == 'application/x-www-form-urlencoded'
    assert fd.get_size() == len(post)
    assert fd.read(4) == post[:4]
    assert fd.read(4) == post[4:8]


# Generated at 2022-06-12 17:05:29.444789
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD().read(100) == b''
    assert HttpFD().close() is None


# Generated at 2022-06-12 17:05:38.536308
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Basic test for HttpFD class."""

    # Dummy URL
    url = 'http://example.com/'

    hfd = HttpFD(url, {}, {})

    # check if fileno() is defined
    if hfd.fileno() is None:
        sys.exit('fileno() not defined')
    if not hfd:
        sys.exit('__nonzero__() not defined or not working')
    if len(hfd) < 0:
        sys.exit('__len__() not defined or not working')



# Generated at 2022-06-12 17:05:49.001479
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # HttpFD should be able to be initialized with either the new-style
    # arguments (url, filename) or the old-style arguments (url,
    # file_handle, info_dict)
    from io import BytesIO

    handle = BytesIO()
    HttpFD(None, handle, None)

    fd = HttpFD(None, 'filename', None)
    assert fd.name == 'filename'
    assert not fd.isatty()
    assert fd.mode == 'wb'

    fd = HttpFD('http://www.foo.bar/', 'filename', None)
    assert fd.name == 'filename'
    assert fd.url == 'http://www.foo.bar/'
    assert not fd.isatty()
    assert fd.mode == 'wb'
   

# Generated at 2022-06-12 17:05:58.265571
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test if non-ASCII characters are correctly handled in Content-Disposition
    # filename parameter
    # (reproduces http://yt-dl.org/ticket/5862)
    params = {
        'outtmpl': '%(id)s.%(ext)s'
    }
    info_dict = {
        'id': 'كيف تنزل',
        # id is already a sanitized string ready to be used as a filename
        # thus the following line is a hack to allow test to run
        # without having to introduce output_template parameter
        'title': 'abc'
    }
    fd = HttpFD(params, '123.mp4', info_dict)
    assert (fd.title == info_dict['id'])
    # Test if HTTP headers with non-ASCII characters are

# Generated at 2022-06-12 17:06:04.886992
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # This is a unit test for method real_download of class HttpFD.
    # It tests the method with various file lengths and chunk sizes,
    # both chunked and non-chunked.
    # Test data is generated in loop below since no server to host these files is available.
    # An HTTP server is spawned for each test case and serves generated file.
    # Test is finished when all cases are tested, i.e. server is sent request for /finish.
    # Response for /finish contains filename, content-length and HTTP response code.
    # This data is checked to ensure that test cases are properly tested.
    class MockYDL:
        def __init__(self):
            self.to_stderr = lambda msg: None
            self.to_screen = lambda msg: None

# Generated at 2022-06-12 17:06:16.412864
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['verbose'] = False

    def _hook_progress(d):
        if d['status'] == 'finished':
            m = hashlib.sha256()
            with open(encodeFilename(d['filename']), 'rb') as f:
                for block in read_blocks(f):
                    m.update(block)
            assert d['filename'].endswith(m.hexdigest())
    ydl.add_progress_hook(_hook_progress)

    def _prepare_urlhook(url, true_url, info_dict):
        return url

    ydl.add_info_extractor(type(__name__ + '.IE'), True, _prepare_urlhook)


# Generated at 2022-06-12 17:06:26.793949
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD(FakeYDL(),
                {})
    filename = u'filename'
    data = {
        'url': 'http://localhost:8080/%s' % filename,
        'fragment_base_url': 'http://localhost:8080/%s' % filename,
        'fragments': 2,
    }
    assert fd.real_download({
        'filename': filename,
        'info_dict': data,
        'test': True,
        'expected_status': 200,
        'chunk_size': 16,
        'retries': 1,
    })


# Generated at 2022-06-12 17:06:36.693519
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import shutil
    from .extractor import gen_extractors
    from .PostProcessor import FFmpegPostProcessor
    MAX_SIZE = 5000
    MIN_SIZE = 1000
    with tempfile.NamedTemporaryFile(mode='w+b', prefix='youtubedl_test_') as outf:
        outf.write(b'123')
        outf.flush()
        filename = outf.name
        outf.close()
    tmpdir = tempfile.mkdtemp(prefix='youtubedl_test_')
    def download_hook(status):
        assert status['status'] == 'downloading'
        if status['downloaded_bytes'] > MAX_SIZE:
            raise IOError('Exceeded max size')
    def test_chunks(**test_params):
        fd