

# Generated at 2022-06-12 17:00:00.984749
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    # This is potentially insecure if someone can
    # inject code to test.py via the URL
    test_py = os.path.abspath(__file__)
    test_url = compat_urlparse.urljoin('file:', pathname2url(test_py))
    fd = HttpFD(
        DummyYDL({'outtmpl': '-'}), {},
        test_url, 'test.py',
        {})
    data_len = 500000
    fd.params['test'] = True
    fd.real_download(data_len=data_len, filename='-')
    assert sys.stdout.getvalue() == open(test_py, 'rb').read(data_len)


# Generated at 2022-06-12 17:00:08.648011
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Constructor test
    h = HttpFD(None, {}, None)
    # Test block_size
    assert h.best_block_size(0.0, 90000) > 0
    assert h.best_block_size(10.0, 1) == 1
    assert h.best_block_size(10.0, 100000) >= h.best_block_size(10.0, 100001)
    # Test inheritance



# Generated at 2022-06-12 17:00:20.743542
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from io import BytesIO
    from io import StringIO
    import sys
    pars = argparse.ArgumentParser()
    YdlLogger = logging.getLogger('youtube_dl')
    h = logging.StreamHandler(StringIO())
    YdlLogger.addHandler(h)
    YdlLogger.setLevel(logging.DEBUG)
    args_dict = vars(pars.parse_args())
    hdfd = HttpFD(YdlLogger, args_dict)
    hdfd.test = True
    hdfd.params['test'] = True
    hdfd.params['quiet'] = True

# Generated at 2022-06-12 17:00:35.002268
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import socket
    import sys
    import threading
    import time

    # Run a webserver, serve just one file, then shutdown and exit
    class TestServer(threading.Thread):

        def __init__(self, document_root, port):
            super(TestServer, self).__init__()
            self.document_root = document_root
            self.port = port
            self.daemon = True
            self.socket = None


# Generated at 2022-06-12 17:00:46.578319
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import http.client
    import socks
    import ssl
    import socket
    import os
    import tempfile
    import shutil
    import time
    import re
    import ydl_hooks
    import random
    import string

    server_mode = (
        os.environ.get('TEST_HTTP_SERVER', None) == 'local' or
        os.environ.get('TEST_HTTPS_SERVER', None) == 'local')

    # Generate a random string of length LEN_SUFFIX
    LEN_SUFFIX = 100
    suffix = ''.join(random.choice(string.printable) for _ in range(LEN_SUFFIX))


# Generated at 2022-06-12 17:00:53.326388
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # preparation for test
    fd = HttpFD()
    # test data
    data = {
        'url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        'filename': '-',
        'info_dict': {},
        'params': {},
    }

    # run
    result = fd.real_download(data)

    # assertions
    assert result == True



# Generated at 2022-06-12 17:01:00.463381
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def _test_HttpFD_download(params, info_dict):
        tmpfilename = tempfile.mktemp(prefix='youtubedl-test_')
        try:
            return HttpFD(params, info_dict).download(tmpfilename, {'test_status': 'downloading'})
        finally:
            if os.path.exists(tmpfilename):
                os.remove(tmpfilename)
    try:
        assert _test_HttpFD_download(None, None)
        assert _test_HttpFD_download({}, {'test_status': 'downloading'})
    except compat_urllib_error.HTTPError:
        pass
    except (compat_urllib_error.URLError, socket.timeout):
        pass

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:01:09.750871
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.generic import GenericIE
    ie = GenericIE()

# Generated at 2022-06-12 17:01:23.254372
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for correct exception handling when dealing with wrong parameter types
    try:
        HttpFD('string_instead_of_dict')
        assert False
    except TypeError:
        pass
    try:
        HttpFD({'url': 'http://www.youtube.com'})
        assert False
    except TypeError:
        pass

    # Test for correct behavior of returned object
    hd = HttpFD({'url': 'http://www.youtube.com', 'filename': '-'})
    assert hd.read(12) == '<!doctype html'
    hd.close()

    # Test for HTTP error handling

# Generated at 2022-06-12 17:01:34.782433
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading
    # FIXME what is this supposed to test?
    # The only effect is to suppress printing to stdout
    def my_hook(status):
        pass
    fd = HttpFD(None, params={'progress_hooks': [my_hook]})
    class MyFD(object):
        def __init__(self, r, w):
            self.r = r
            self.w = w
            self.off = 0
        def read(self, l):
            if self.off >= len(self.r):
                return b''
            else:
                ret = self.r[self.off : self.off + l]
                self.off += l
                return ret
        def write(self, b):
            self.w.append(b)
    # Dummy file to download
    dl

# Generated at 2022-06-12 17:02:16.076508
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test if real_download() works correctly.
    # YouTube video is requested with test_file_size().
    # If it completes with correct content length and with no exception,
    # then all went well
    fd = HttpFD()
    test_video_url = "http://www.youtube.com/watch?v=BaW_jenozKc"
    urlhandle = compat_urllib_request.urlopen(test_video_url)
    info = dict(compat_urlparse.parse_qsl(urlhandle.info().get('Content-Disposition', '')))
    filename = info.get('filename') or 'test'
    file_size = fd.test_file_size(urlhandle.geturl(), filename, (0, -1))

# Generated at 2022-06-12 17:02:28.973312
# Unit test for constructor of class HttpFD

# Generated at 2022-06-12 17:02:33.178685
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    $ python -m test.test_HttpFD
    """
    import os
    import sys
    import tempfile

    def check_fd_copy(fd, data_len, has_length_func=True):
        if has_length_func:
            assert fd.get_length() == data_len
            assert int(fd) == data_len
        else:
            assert fd.get_length() is None
            assert int(fd) == 0
        assert fd.get_type() == 'http'
        assert fd.read(1) == b'a'
        assert fd.read(100000) == b'bcdefghijk'
        assert fd.read(1) == b''

    # File-like object having 'length' attribute

# Generated at 2022-06-12 17:02:42.164679
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http = HttpFD(null_output())
    http.params['nooverwrites'] = True
    http.params['continuedl'] = True
    http.params['noprogress'] = True
    http.params['quiet'] = True
    http.params['noresizebuffer'] = True
    http.params['min_filesize'] = 10 * 1024 * 1024
    http.params['max_filesize'] = 12 * 1024 * 1024
    # from https://github.com/ytdl-org/youtube-dl/issues/6192

# Generated at 2022-06-12 17:02:53.790197
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:03:04.141138
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import encode_data_uri

    class MockIE(InfoExtractor):
        def __init__(self, downloader, test, success=False):
            super(MockIE, self).__init__(downloader)
            self._test = test
            self._success = success

        def _real_extract(self, url):
            data_len = self._test.get('data_len')
            expected_length = self._test.get('expected_length')
            expected_headers = self._test.get('expected_headers')
            block_size = self._test.get('block_size')
            is_test = self._test.get('is_test')

# Generated at 2022-06-12 17:03:08.714931
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import get_info_extractor
    youtube_ie = get_info_extractor('Youtube')
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info = youtube_ie._real_extract(url)
    test = HttpFD(dict(params=dict(test=True)), info['url'], info['title'])
    test._do_download()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:03:18.283453
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Encoding for some tests
    encoding = locale.getpreferredencoding()

    def check(**kwargs):
        fd = HttpFD(**kwargs)
        if fd.start() is False:
            return False
        s = fd.read()
        fd.close()
        return len(s) > 0

    # Check that test server is up
    assert check(url='http://localhost/')
    assert check(url='http://localhost/?1', opts={'quiet': True})
    assert check(url='http://localhost/?2', params={'quiet': True})
    assert check(url='http://localhost/?3', opts={'quiet': True}, params={'quiet': False, 'noprogress': True})

# Generated at 2022-06-12 17:03:28.009853
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors

    ydl = YoutubeDL({'quiet': True})
    gen_extractors(ydl)
    ydl.add_info_extractor(HttpIE(ydl, i_key='http'))

    test_url = 'http://www.google.com/humans.txt'
    info = ydl.extract_info(test_url, download=False)
    down, _, _ = ydl.download(['http://www.google.com/humans.txt'])
    assert down == True

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:03:38.154510
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = FakeYDL()
    fd = HttpFD(ydl, params={'nopart': True, 'ratelimit': 0})

    # Since we're using a fake urllib2, urlopen will always return the
    # same value and we can check if we've called urlopen twice.
    assert fd.real_download('https://example.com/foo.bin')
    assert fd.num_urlopen == 1

    # Test if actual download works (downloads to '/dev/null')
    info_dict = {
        'id': 'foo',
        'ext': 'bin',
        'title': 'foo',
        'filesize': 100,
        'fulltitle': 'foo',
        'format': '',
    }

# Generated at 2022-06-12 17:04:57.244712
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD(
        'http://127.0.0.1:0',
        {'test': 'test value'},
        {
            'youtube_include_dash_manifest': False,
            'noprogress': True,
            'quiet': True,
            'logger': False
        },
        '-'
    )

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:05:04.366540
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # parameters for test
    test_data_len = 1 << 15  # 32768 bytes
    test_data_block_len = 1 << 7  # 128 bytes
    test_chunk_size = 1 << 16  # 65536 bytes
    test_slow_server_rate = 256  # bytes per second
    test_retries = 3
    test_backoff_factor = 1.0
    test_sleep_time = 10  # seconds
    test_read_timeout = 0.5  # seconds
    test_data_len_precision = 1 << 3  # 8 bytes
    test_chunk_size_precision = 1 << 3  # 8 bytes
    # HTTP header to be sent by server
    test_response_headers = {
        'Content-Length': str(test_data_len),
    }

# Generated at 2022-06-12 17:05:15.212847
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .compat import compat_urllib_request, compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_error
    from .utils import sanitize_open

    # First check I can't instantiate
    stdout = sys.stdout
    try:
        with stdout_binary():
            h = HttpFD(sys.stdout)
    except (OSError, IOError) as err:
        assert str(err).endswith('[Errno 9] Bad file descriptor'), 'HttpFD ctor should fail with BADF on closed fd'
    else:
        assert False, 'HttpFD ctor should fail with BADF on closed fd'

    # Then check I can instantiate

# Generated at 2022-06-12 17:05:25.407895
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    import threading
    import unittest
    import urllib.request
    import youtube_dl.HookServer
    class MockUrlOpen(object):
        def __init__(self, url):
            self._url = url
        def read(self, size):
            if len(self._url) > size:
                ret_val, self._url = self._url[:size], self._url[size:]
            else:
                ret_val, self._url = self._url, ''
            return ret_val
    class MockYoutubeDl(object):
        def __init__(self):
            self.params = {}
        def urlopen(self, request):
            url = request.get_full_url()
            # len(b'http://127.0.0.1:

# Generated at 2022-06-12 17:05:38.050897
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Extractor for testing
    def test_extractor(url):
        assert url == 'https://example.org/video.mp4'
        return {
            'id': 'test',
            'url': url,
            'title': 'test',
            'ext': 'mp4',
            'format': 'test',
            'thumbnail': 'https://example.org/thumbnail',
        }
    info_dict = {
        'id': 'test',
        'url': 'https://example.org/video.mp4',
        'title': 'test',
        'ext': 'mp4',
        'format': 'test',
        'thumbnail': 'https://example.org/thumbnail',
    }
    params = {
        'noprogress': True,
        'test': True,
    }
   

# Generated at 2022-06-12 17:05:48.786008
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import http_server
    import unittest

    class HttpFDRealDownloadTests(unittest.TestCase):
        def test_real_download(self, test_server='localhost:8080'):
            """
            This method tests real_download() with multiple requests and
            values of retries and chunksize.

            :param test_server: hostname (or IP address) of a server that
                can be used for testing
            """

            # This is the most simple case, when all goes well
            #
            # The file is downloaded in one chunk of 100 bytes.
            #
            # Both test server and client implement HTTP/1.1
            # and the server supports persistent connections.

            filename = 'test_file'
            tmpfilename = filename + '.tmp'

# Generated at 2022-06-12 17:05:58.192221
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # We use 'range' to test resuming and 'test' to test using a non-standard
    # file size for testing
    params = {
        'noprogress': True,
        'retries': 5,
        'range': (100, 500),
        'test': True,
    }
    blocks = []
    def hook(_):
        if not blocks:
            return
        assert blocks[-1][1] > _['downloaded_bytes']
    def block_read(n):
        block = b'-' * n
        blocks.append((time.time(), n))
        return block
    f = FakeYDL({'url': 'http://dummyurl/'})
    f.add_info_extract({'id': 'a'})

# Generated at 2022-06-12 17:06:05.277488
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .downloader.f4m import F4mFD
    def _basename(path):
        return os.path.basename(path.rstrip(os.sep))
    _random_key = lambda: ''.join(random.choice(string.ascii_lowercase) for _ in range(random.randint(1, 10)))
    _shorten_url = lambda url: _basename(urlparse(url).path)
    def _chunks(content, size):
        num_chunks = int(math.ceil(len(content) / size))
        return [content[i * size:(i + 1) * size] for i in range(num_chunks)]



# Generated at 2022-06-12 17:06:11.113581
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test different block sizes
    block_sizes = [1<<8, 1<<10, 1<<12, 1<<16, 1<<20]
    for i in range(len(block_sizes)):
        # Test the result of download function
        assert HttpFD._test_block_sizes(block_sizes[i]) == HttpFD._TEST_OUTPUT_HASH['%s' % block_sizes[i]], \
            'Download (block size = %d) failed' % block_sizes[i]


# Generated at 2022-06-12 17:06:23.515378
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test object attributes
    header_test = 'header_test'
    tmpfilename_test = 'tmpfilename_test'
    stream_test = 'stream_test'
    filename_test = 'filename_test'
    open_mode_test = 'open_mode_test'
    test_data = 'test_data'
    test_data_len = len(test_data)
    test_block_size = 5

    class FakeDummyFD:
        def __init__(self, stream_test, header_test):
            self.stream_test = stream_test
            self.header_test = header_test
        def info(self):
            return self.header_test
        def read(self, block_size):
            if self.stream_test:
                test_data = self.stream_test.pop(0)
