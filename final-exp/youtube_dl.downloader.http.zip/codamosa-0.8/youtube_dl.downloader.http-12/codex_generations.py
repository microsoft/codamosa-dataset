

# Generated at 2022-06-12 17:00:07.420204
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(
        'http://www.example.org/video.flv',
        5242880,
        {},
        {})
    assert fd.real_download == True
    assert fd.tries == 3
    assert fd.retry_on_ioerror == True
    assert fd.chunk_size == 1048576  # (1,4)
    assert (5242880 - 1) % 1048576 == 0
    assert fd.endbyte == 5242880 - 1
    assert fd.startbyte == 0
    assert fd.filename == 'video.flv'
    assert fd.total_bytes == 5242880
    assert fd.headers == {}
    assert fd.url == 'http://www.example.org/video.flv'

    f

# Generated at 2022-06-12 17:00:19.969529
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import sys
    import platform

    def print_test_output(test_name, res, message):
        print('    Test %-30s: %s' % (test_name, message))
        print('        Result: %s' % (res and 'OK' or 'FAILURE'))
        print('')

    # Dummy class to trick YoutubeDL into thinking it's running on Windows
    class Windows(object):
        @staticmethod
        def version():
            return 'Windows'

    if not sys.platform.startswith('linux'):
        sys.stderr.write('This test is designed for Linux, skipping.\n')
        return


# Generated at 2022-06-12 17:00:27.778805
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import StringIO
    io = StringIO.StringIO()
    fd = HttpFD(io, 'wb', 1024)
    assert fd.name == io.name
    assert fd.mode == 'wb'
    assert fd.close == io.close
    assert fd.fileno() == io.fileno()
    fd.close()


# Test for HttpFD.write

# Generated at 2022-06-12 17:00:41.280729
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def get_info(filename, info_dict, params, **kwargs):
        if 'format' in params:
            info_dict['ext'] = params['format']

    ydl = YoutubeDL({
        'format': 'bestaudio',
        'progress_hooks': [],
        'simulate': True,
        'nooverwrites': True,
        'continuedl': True,
        'quiet': True,
    })
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(get_info)
    ydl.prepare_filename = lambda info: 'test'
    ydl.params['prefer_free_formats'] = False
    ydl.params['https_proxy'] = '0.0.0.0'
    fake_urlopen = test_

# Generated at 2022-06-12 17:00:54.733624
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import socket
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_error
    from .utils import encodeFilename

    class DummyHttpFD(HttpFD):
        def __init__(self, params, info_dict):
            HttpFD.__init__(self, params, info_dict)
            self.content_length = None
            self.resume_len = 0
            self.done = False

        def download(self, filename, info_dict):
            self.filename = filename
            self.content_length = int(info_dict.get('contentlength', -1))
            self.done = True
            return True

        def slow_down(self, start, now, byte_counter):
            return


# Generated at 2022-06-12 17:01:07.419313
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Check if files are downloaded correctly
    def open_function(filename, mode):
        filename = encodeFilename(filename)
        assert re.search(r'^[a-zA-Z0-9]{5,}$', filename)
        if mode == 'wb':
            return (lambda: None, lambda: None), open(filename, mode)
        return None

    class Info():
        def __init__(self, length):
            self.length = length

    # Test for retries
    def read_retry(self, size=-1):
        self.attempt += 1
        if self.attempt < self.max_attempt:
            raise compat_urllib_error.URLError(compat_socket_error(104, 'Connection reset by peer'))
        return 'a' * self.length

    #

# Generated at 2022-06-12 17:01:21.361400
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import filecmp
    import tempfile

    (tmpfd, tmpfn) = tempfile.mkstemp(prefix='youtubedl-test-')
    os.close(tmpfd)
    tfn2 = tmpfn + '2'

# Generated at 2022-06-12 17:01:33.442728
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HEAD = b'\r\n'.join(
        [b'HTTP/1.1 200 OK',
         b'Content-Type: text/plain',
         b'Content-Length: 0',
         b'', b''])
    fd = compat_HTTPErrorProcessor()(compat_urllib_request.Request('http://localhost/'), None, HTTPDummyServer(HEAD))
    assert isinstance(fd, HttpFD)
    assert fd.headers.get_content_type() == 'text/plain'
    assert fd.headers_array == HEAD.split(b'\r\n')
    assert fd.headers_dict == {'Content-Type': 'text/plain', 'Content-Length': '0'}
    assert not fd.read(1)
# Test get_headers

# Generated at 2022-06-12 17:01:43.880155
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case 1: it is already open
    fd = io.BytesIO(b'abc')
    hfd = HttpFD(fd, None)
    assert isinstance(hfd, io.BufferedReader)
    assert hfd.length == 3
    assert hfd.tell() == 0
    assert fd.tell() == 3
    assert hfd.read(1) == b'a'
    assert hfd.read(2) == b'bc'
    assert hfd.read(1) == b''
    assert hfd.tell() == 3

    # Test case 2: it is a file path
    fd = tempfile.NamedTemporaryFile()
    fd.write(b'abc')
    fd.flush()
    fd.seek(0)


# Generated at 2022-06-12 17:01:46.733359
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return HttpFD(
        {
            'url': 'http://localhost/',
            'http_chunk_size': 1*1024,
            'http_test_chunk_count': 50,
            'filename': '-'
        },
        None
    )

# Used with test_HttpFD

# Generated at 2022-06-12 17:02:31.084750
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def my_hook(*args, **kwargs):
        pass

    # Test with test server that returns HTTP 404 on every request
    ydl = YoutubeDL({
        'outtmpl': '%(id)s%(ext)s',
        'progress_hooks': [my_hook],
        'nooverwrites': True,
        'nopart': True,
        'quiet': True,
    })
    dl = HttpFD(ydl, {'url': 'http://127.0.0.1:8000/', 'http_chunk_size': UNKNOWN_FILE_SIZE})
    assert not dl.test()

    # Test with a test server that returns HTTP 200 on every request

# Generated at 2022-06-12 17:02:41.230730
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import encodeFilename

    # Configure the test
    params = {
        'outtmpl': '%(id)s.%(ext)s',
        'quiet': True,
        'nooverwrites': True,
        'format': 'best',
    }
    url = 'https://github.com/rg3/youtube-dl/archive/master.zip'
    data_len = 1330891

    # Create the test object
    ydl = _RealYdl(params)
    ydl.add_info_extractor(_FakeIE(url))

# Generated at 2022-06-12 17:02:53.082640
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Unit test for method real_download of class HttpFD"""
    from .extractor import YoutubeIE
    ydl = YoutubeDL({
        'outtmpl': '-'
    })
    ydl.add_info_extractor(YoutubeIE())
    ydl.params['test'] = True
    ydl.to_screen = lambda s: None
    ydl.process_info = lambda i: i
    ydl.report_error = lambda msg: print(msg, file=sys.stderr)
    url = 'https://github.com/rg3/youtube-dl/blob/master/youtube_dl/YoutubeDL.py'
    fd = HttpFD(ydl, {'url': url, 'ext': 'mp4'}, {'noprogress': True})

# Generated at 2022-06-12 17:03:04.058160
# Unit test for constructor of class HttpFD
def test_HttpFD():
    id = 'testid'
    url = 'http://127.0.0.1/%s' % id
    data = 'testdata'
    range_start = 0
    range_end = 5
    info = {
        'id': id,
        'url': url,
        'fragment_base_url': url,
        'fragment_index': None,
        'fragment_count': None,
        'fragments': None,
        'http_headers': {},
        'extra_http_headers': [],
        'mime_type': 'video/mp4',
        'downloader_options': {'testopt': 'testval'},
        'params': {},
    }
    headers = {'testheader': 'testvalue', 'User-agent': 'testuseragent'}


# Generated at 2022-06-12 17:03:12.074784
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case where file size is known
    fd = HttpFD('http://www.example.org', {'content-length': 3})
    assert fd.real_download is False
    assert fd.size == 3
    assert fd.read(1) == b'o'
    assert fd.read(4) == b'k\x00\x00'
    assert fd.read(4) == b''
    # Test case where file size is unknown
    fd = HttpFD('http://www.example.org', {})
    assert fd.real_download is False
    assert fd.size is None
    assert fd.read(1) == b'o'
    assert fd.read(4) == b'k\x00\x00'

# Generated at 2022-06-12 17:03:20.212423
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with no data
    httpfd = HttpFD(lambda len: (0, ''))
    assert httpfd.len == 0
    assert httpfd.tell() == 0

    # Test with one block of data
    httpfd = HttpFD(lambda len: (len, 'X' * len))
    assert httpfd.len == 5
    assert httpfd.tell() == 0
    assert httpfd.read(2) == 'XX'
    assert httpfd.tell() == 2
    assert httpfd.read(2) == 'XX'
    assert httpfd.tell() == 4
    assert httpfd.read() == 'X'
    assert httpfd.tell() == 5
    assert httpfd.read() == ''
    assert httpfd.tell() == 5

    # Test with two blocks of data

# Generated at 2022-06-12 17:03:24.713466
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(
        'http://www.youtube.com/get_video_info?video_id=BaW_jenozKc',
        'test.f4m',
        {'test': 10485760},
        {'quiet': True},
    )
    http_fd._prepare_and_start()
    http_fd.read(1000)
    http_fd.close()
    os.remove('test.f4m')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:03:35.691922
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    global _TEST_FILE_SIZE
    import io
    import test_http
    import zlib
    from .compat import byte_str

    def _test_download(params, results):
        orig_file_size = _TEST_FILE_SIZE

        def setUp():
            global _TEST_FILE_SIZE
            _TEST_FILE_SIZE = results['file_size']
            # make sure to use a unique config directory
            params['config_dir'] = os.path.join(params['config_dir'], 'test_download')
            # don't litter
            params['nooverwrites'] = True
            params['noprogress'] = True
            params['verbose'] = False
            params['quiet'] = True
            params['logger'] = test_http.NullLogger()


# Generated at 2022-06-12 17:03:36.885556
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import doctest
    doctest.testmod(sys.modules[__name__])
# Main function of the script

# Generated at 2022-06-12 17:03:45.529379
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import shutil
    import tempfile
    import threading
    import time

    from .utils import encodeFilename

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'nooverwrites': True,
                'continuedl': True,
                'noresizebuffer': True,
                'retries': 0,
                'buffersize': 1024,
                'test': True,
            }
            self.to_screen = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None

        def urlopen(self, request, retries=None, fatal=False):
            faker = UrlFaker()

# Generated at 2022-06-12 17:05:06.354740
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _progress_hook(status):
        print(status)
        if status['status'] == 'error':
            raise Exception('Download failed')
    ydl = YoutubeDL({'progress_hooks': [_progress_hook]})
    fd = HttpFD(ydl, {}, 'https://example.com', force_fake_http=True)
    fd.real_download(os.path.join(config.get_temp_dir(), '__test_HttpFD__temp.file'))
    for test_file_size in itertools.chain([0, 1, 100, 1000, 10000, 100000, 1000000, 10000000], range(10, 100, 10), range(100, 1000, 100), range(1000, 10000, 1000)):
        print('Test file size %d' % test_file_size)
        fd

# Generated at 2022-06-12 17:05:10.849517
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(None, None, {'noprogress': True}, None)
    http_fd.to_screen('Testing HttpFD')
    return http_fd

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:05:18.437763
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd = HttpFD(None, 'http://www.youtube.com/watch?v=BaW_jenozKc', {})
    assert httpfd.url == 'http://www.youtube.com/watch?v=BaW_jenozKc'
    assert httpfd.ydl == None
    assert httpfd.params == {}

    httpfd = HttpFD(None, 'https://127.0.0.1/', {'noprogress': True})
    assert httpfd.url == 'https://127.0.0.1/'
    assert httpfd.ydl == None
    assert httpfd.params == {'noprogress': True}



# Generated at 2022-06-12 17:05:23.297248
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print("running test HttpFD_real_download")
    global c
    global ctx
    c = HttpFD(self)
    #ctx = DownloadContext()
    #ctx.ydl = YoutubeDL()
    test_url = "http://www.example.com"
    c.real_download(test_url,ctx)


# Generated at 2022-06-12 17:05:28.664687
# Unit test for constructor of class HttpFD
def test_HttpFD():
    temp_file = tempfile.TemporaryFile()
    fd = HttpFD(temp_file)
    fd.write(b'hello')
    fd.close()
    if temp_file.tell() != 5:
        raise AssertionError('HttpFD not working')



# Generated at 2022-06-12 17:05:40.855053
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'continuedl': True,
                'nooverwrites': True,
                'logtostderr': True,
                'quiet': True,
                'noprogress': True,
                'retries': 10,
                'test': True,
                'buffersize': 8096,
                'noresizebuffer': True,
            }
            self.cache = {}

        def to_screen(self, message): print(message)
        def to_stderr(self, message): print(message)
        def report_warning(self, message): print(message)
        def report_error(self, message, tb=None): print(message)

# Generated at 2022-06-12 17:05:50.443825
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import shutil
    import tempfile

    _TEST_FILE = 'https://github.com/ytdl-org/youtube-dl/raw/master/README.md'

    def _test_result_file(filename, expected_size):
        # Check if file exists and has correct size
        assert os.path.getsize(filename) == expected_size

    # TODO: check if file is not corrupted?

    tmpdir = tempfile.mkdtemp(prefix='ytdl-test-')

# Generated at 2022-06-12 17:05:59.079944
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with a local file
    with tempfile.NamedTemporaryFile() as t:
        test_file = t.name
        test_data = b'hello world'
        t.write(test_data)
        t.flush()
        fd = HttpFD(test_file, {}, 'test_file')
        assert fd.real_download == False
        assert fd.len == len(test_data)
        assert fd.read(5) == test_data[0:5]
        assert fd.read() == test_data[5:]
        fd.close()

    # Test with a remote file (disabled for now)
    return
    for proto in ('http', 'https'):
        test_url = proto + '://bit.ly/1R7LaVi'
        fd = Http

# Generated at 2022-06-12 17:06:12.751308
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import (
        encodeFilename,
    )
    from .extractor.common import (
        InfoExtractor,
    )
    from .compat import (
        compat_urllib_request,
        compat_urllib_error,
    )
    import socket

    # Define fake test server
    class SocketServerBase:
        BUFFER_SIZE = 1024
        TIMEOUT = 300  # wait for 5 min to receive next request
        CONTENT_LENGTH = 42
        WAIT_AFTER_CONTENT_LENGTH_RESPONSE = 0.1  # fake download speed is 1 Mb/s
        # Resume requests should always read at least one byte
        MAX_RESUME_BLOCK_SIZE = 16 * 1024
        WAIT_BETWEEN_REQUESTS = 0.1  # allow client to

# Generated at 2022-06-12 17:06:25.232673
# Unit test for constructor of class HttpFD
def test_HttpFD():
    content_type = 'video/webm'
    filename = 'test'
    info_dict = {
        'id': 'test',
        'title': 'test',
        'ext': 'webm',
        'url': 'http://example.com/',
        'thumbnail': 'http://example.com/thumbnail.jpg',
        'upload_date': '20120101',
        'uploader': 'ExampleUploader',
    }
    params = {
        'format': 'best',
        'outtmpl': 'test.%(ext)s',
    }

    dl = FakeYDL()
    dl.process_info(info_dict)

    fd = HttpFD(dl, params, filename, content_type)

    assert fd.name == filename