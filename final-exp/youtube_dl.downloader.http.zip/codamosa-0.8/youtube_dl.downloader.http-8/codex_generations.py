

# Generated at 2022-06-12 17:00:01.880433
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

    class FakeInfo(object):
        url = 'http://blabla.com/video.mp4'
        filename = 'video.mp4'

    ydl = FakeYDL({})
    info = FakeInfo()
    downer = HttpFD(ydl, info)
    assert downer.ydl is ydl
    assert downer.params is ydl.params
    assert downer.max_resume_tries == 3
    assert downer.initial_blocksize == 1048576
    assert downer.algorithm == 'experimental'

    ydl = FakeYDL({'continuedl': True})
    info = FakeInfo()
    downer = HttpFD(ydl, info)
    assert down

# Generated at 2022-06-12 17:00:16.045631
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(
        'http://example.com/video1.mp4', {'http_headers': {'Range': 'bytes=0-4/11'}},
        'rb', 'video1.mp4', 1024, ratelimit=2000, retries=10,
        chunksize=1024*8, resume_len=0, test=True)
    print('Initial value')
    print('ratelimit = %d' % fd.ratelimit)
    print('chunksize = %d' % fd.chunksize)
    print('resume_len = %d' % fd.resume_len)
    print('retries = %d' % fd.retries)
    print('test = %r' % fd.test)
    # Test chunksize

# Generated at 2022-06-12 17:00:22.475179
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if not os.path.exists('test.mp4'):
        download_webpage('http://techslides.com/demos/sample-videos/small.mp4', 'test.mp4')
    info_dict = {}
    try:
        fd = HttpFD('test.mp4', info_dict, 'http://techslides.com/demos/sample-videos/small.mp4', {})
        assert fd is not None
    finally:
        os.remove('test.mp4')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:00:36.008046
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(
        'http://example.com:8080/%s?video_id=xyz0',
        {'noprogress': True, 'retries': 0},
        None
    )

# Generated at 2022-06-12 17:00:40.509483
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    h = HttpFD(BytesIO(b'foobar'), 'rb', 6)
    assert h.read() == b'foobar'
    assert h.size == 6
    assert h.tell() == 6
    h.seek(0)
    assert h.read(3) == b'foo'
    assert h.read(1) == b'b'
    assert h.read() == b'ar'
    h.seek(-1, 2)
    assert h.read() == b'r'
    assert h.tell() == 6
    h.seek(-1, 1)
    assert h.read() == b'r'
    assert h.tell() == 5
    h.seek(1)
    assert h.read() == b'bar'
    assert h.tell() == 6
   

# Generated at 2022-06-12 17:00:49.300875
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    fd = HttpFD(BytesIO(b'foo'), 3)
    assert fd.size == 3
    assert fd.read() == b'foo'
    assert fd.tell() == 3
    fd.seek(0)
    assert fd.tell() == 0
    assert fd.read() == b'foo'
    assert fd.tell() == 3
    fd.seek(-1)
    assert fd.tell() == 2
    assert fd.read() == b'o'
    assert fd.tell() == 3
    assert fd.read() == b''
    fd.seek(0)
    assert fd.readline() == b'foo'
    assert fd.readline() == b''

# Generated at 2022-06-12 17:00:58.618457
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import io
    import http.client
    import SocketServer

    class MyTCPServer(SocketServer.TCPServer):
        allow_reuse_address = True

    class MyTCPHandler(SocketServer.StreamRequestHandler):
        def handle(self):
            self.wfile.write('HTTP/1.0 200 OK\r\nContent-Length: 1000000\r\n\r\n')
            self.wfile.write('a'*1000000)

    httpd = MyTCPServer(('127.0.0.1', 0), MyTCPHandler)
    addr, port = httpd.server_address

    t = Thread(target=httpd.serve_forever)
    t.daemon = True
    t.start()

    conn = http.client.HTTPConnection(addr, port)
   

# Generated at 2022-06-12 17:01:08.820253
# Unit test for constructor of class HttpFD
def test_HttpFD():
    t = HttpFD(params={})

    # Test 1
    f = t.get_fd({
            'filenames': ['-'],
            'outtmpl': u'%(stitle)s.%(ext)s',
            'nooverwrites': False,
            'continuedl': False,
            'restrictfilenames': True})
    assert f == sys.stdout

    # Test 2
    f = t.get_fd({
            'filenames': ['-'],
            'outtmpl': u'%(stitle)s.%(ext)s',
            'nooverwrites': True,
            'continuedl': False,
            'restrictfilenames': False})
    assert f == sys.stdout

    # Test 3

# Generated at 2022-06-12 17:01:16.004641
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL()
    ydl.http_fd = HttpFD(ydl)
    ydl.http_fd.run({
        'url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        'filename': '-',
        'info_dict': {},
    })


# Generated at 2022-06-12 17:01:29.193432
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    from .utils import encodeFilename, prepend_extension
    from .cache import FileCache

    def _print_status(status):
        print(status['status'])

    def _print_status_2(status):
        print('Fetching: %s' % status['filename'])

    HttpFD._TEST_FILE_SIZE = 1073741824
    urlh = compat_urllib_request.urlopen('https://github.com/rg3/youtube-dl/archive/master.zip')
    info = dict(size=int(urlh.info()['Content-length']))
    urlh.close()
    url = 'https://github.com/rg3/youtube-dl/archive/master.zip'

    fd = HttpFD(FileCache(), _print_status_2)
    f

# Generated at 2022-06-12 17:02:31.848771
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from tempfile import NamedTemporaryFile
    tmpdesc, tmppath = None, None
    try:
        with NamedTemporaryFile() as tmpfile:
            tmpdesc, tmppath = tmpfile.fileno(), tmpfile.name
            fd = HttpFD(tmpdesc, 'http://localhost/test')
            assert fd.name == 'http://localhost/test'
    finally:
        if tmpdesc is not None:
            os.close(tmpdesc)
        if tmppath is not None:
            os.remove(tmppath)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:02:41.646820
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test setup
    import io
    import tempfile
    import os

    # Test data
    data = b'abcdefghijklmnop'*1000

    def read_f_func(url, headers):
        assert url == 'http://www.random.org/'
        assert headers == {'Range': 'bytes=0-1024'}
        return io.BytesIO(data[:1024])

    def read_t_func(url, headers):
        assert url == 'http://www.random.org/'
        assert headers == {'Range': 'bytes=2048-'}
        return io.BytesIO(data[2048:])

    # Prepare temporary directory
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)
    tmpf = tempfile.NamedTemporaryFile()
    tmp

# Generated at 2022-06-12 17:02:53.377597
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    print('Running real_download method unit test, you may ignore some error messages in the output')

    def get_test_params():
        return {
            'format': 'bestvideo+bestaudio/best',
            'outtmpl': '-'
        }
    '''
    # Prints the output of the method with given url
    url = 'http://download.thinkbroadband.com/200MB.zip'
    http_fd = HttpFD(None, get_test_params())
    print(http_fd.real_download(url, info_dict=None))
    '''
    # Download the file in chunks of size 500kB
    url = 'http://download.thinkbroadband.com/200MB.zip'
    http_fd = HttpFD(None, get_test_params())

# Generated at 2022-06-12 17:03:04.105535
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a "temporary" directory
    temp_dir = tempfile.mkdtemp()

    class FakeYtdl(object):
        def __init__(self):
            self.params = {'continuedl': False, 'nooverwrites': True}
            self.to_stderr = lambda s: sys.stderr.write(s)
            self.to_screen = self.to_stderr
            self.report_error = self.to_stderr
            self.urlopen = compat_urllib_request.urlopen
            self.urlretrieve = compat_urllib_request.urlretrieve

    fake_ydl = FakeYtdl()


# Generated at 2022-06-12 17:03:15.168924
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class DummyYDL(object):
        def __init__(self):
            self.params = {
                'continuedl': True,
                'nooverwrites': False,
                'retries': 10,
                'logger': YoutubeDL(),
            }
            self.progress_hooks = []
        def to_screen(self, *args, **kargs):
            pass
        def urlopen(self, *args, **kargs):
            return mock_server(open_live=True)
        def report_warning(self, *args, **kargs):
            pass
        def report_error(self, *args, **kargs):
            pass
        def report_resuming_byte(self, *args, **kargs):
            pass

# Generated at 2022-06-12 17:03:24.290397
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test method real_download of class HttpFD"""

    class InfoObject(object):
        def __init__(self, info_dict={}):
            self.info = copy.copy(info_dict)

    def build_open(url, headers, params):
        def _open(filename, mode):
            f = io.BytesIO()
            f.close = lambda: None

            # Add special headers
            # TODO: Relax this hardcoded name
            f.name = filename
            f.filename = filename
            f.headers = {
                'etag': 'abcdefg',
                'content-length': '1234567',
                'last-modified': 'Mon, 03 Jan 2000 00:00:00 GMT',
            }
            return f, filename
        return _open

    # Open destination file doesn't fail
    ydl

# Generated at 2022-06-12 17:03:35.517880
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import shutil
    import tempfile

    # http://michael.orlitzky.com/archives/494
    def close_all_fds():
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        for fd in range(3, min(soft, hard)):
            try:
                os.close(fd)
            except OSError:
                pass

    close_all_fds()

    def get_random_string(l=10):
        return ''.join(random.choice(string.ascii_letters) for i in range(l))

    def mkdtemp_unicode():
        _tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 17:03:41.089702
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for successful instantiation of HttpFD
    def test_instantiation_1():
        params = {
            'noprogress': True,
            'logger': DummyLogger(),
        }
        # Test for a http download
        info = {
            'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        }
        http_fd = HttpFD(params, info)
        assert http_fd is not None

    # Test for unsuccessful instantiation of HttpFD
    def test_instantiation_2():
        params = {
            'noprogress': True,
            'logger': DummyLogger(),
        }
        # Test for a ftp download

# Generated at 2022-06-12 17:03:48.048056
# Unit test for constructor of class HttpFD
def test_HttpFD():
    password_mgr = compat_urllib_request.HTTPPasswordMgrWithDefaultRealm()
    password_mgr.add_password(None, 'http://example.org/path/', 'username', 'password')
    password_mgr.add_password(None, 'http://example.com/', 'username', 'password')
    proxy_handler = compat_urllib_request.ProxyHandler({'http': 'http://example.com:8080/'})
    http_auth_handler = compat_urllib_request.HTTPBasicAuthHandler(password_mgr)
    proxy_auth_handler = compat_urllib_request.ProxyBasicAuthHandler(password_mgr)
    cookie_handler = compat_urllib_request.HTTPCookieProcessor(cookielib.CookieJar())

# Generated at 2022-06-12 17:03:57.988645
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if os.path.exists('test'):
        shutil.rmtree('test')
    if os.path.exists('test.tmp'):
        os.remove('test.tmp')
    if os.path.exists('test.test'):
        os.remove('test.test')
    if os.path.exists('test.null'):
        os.remove('test.null')
    os.mkdir('test')
    def test(**kwargs):
        outputname = kwargs.get('outtmpl') or 'test'

# Generated at 2022-06-12 17:05:16.765199
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    fd = HttpFD(sys.stdout, 'http://www.google.com/', {}, {})
    status = fd.real_download(False, count=1, retries=0, fragment_base=None, info_dict=None)
    assert status is True
    assert fd._downloaded_bytes > 0


# Generated at 2022-06-12 17:05:21.804631
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    return True


if __name__ == '__main__':
    test_all_cases(globals())

## test_all_cases
# Test all the cases in a module
#
# @param cases A dictionary of name: function pairs, presumably everything in globals()
# @return True if everything worked, False if any case failed

# Generated at 2022-06-12 17:05:29.171116
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test with a small test file

    # Create the test environment
    import random
    import shutil
    import tempfile
    import time

    testenv = TempTestEnv()
    tmpdir = testenv.gettempdir()
    testfile = os.path.join(tmpdir, 'test.mp4')

    # Create the test file
    with open(testfile, 'wb') as f:
        for i in range(_TEST_FILE_SIZE // 2):
            f.write(struct.pack('B', random.randint(0, 255)))

    # The test itself

# Generated at 2022-06-12 17:05:41.056476
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Verify that HttpFD.real_download() works.
    """
    # We don't want to make real HTTP requests
    def dummy_urlopen(req, *args, **kwargs):
        return compat_StringIO(u'foobarbaz')

    class DummyYDL(object):
        def __init__(self):
            self.params = {
                'continuedl': True,
                'nooverwrites': False,
            }

    # Mock the getaddrinfo() call
    orig_getaddrinfo = socket.getaddrinfo

    # Generate dummy IP addresses

# Generated at 2022-06-12 17:05:50.621722
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from collections import namedtuple

    TestCase = namedtuple('TestCase', 'test_name url_result expected_result expected_exc')

    def test_func():
        class FakeYDL(object):
            def __init__(self):
                self.params = {
                    'noprogress': False,
                }

        ydl = FakeYDL()


# Generated at 2022-06-12 17:05:56.100111
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # test case 1
    fd = HttpFD()
    fd.params['test'] = True
    ret = fd.real_download(
        'http://127.0.0.1:8080/1', '-',
        {'size': 100}, 0, None)
    assert ret == True
    assert fd.filename == '-'
    assert fd.tmpfilename == '-'
    assert fd.chunk_size is None
    assert fd.has_range is False

    # test case 2
    fd = HttpFD()
    fd.params['test'] = True
    ret = fd.real_download(
        'http://127.0.0.1:8080/2', '-',
        {'size': 100}, 0, 1)
    assert ret == True
    assert f

# Generated at 2022-06-12 17:06:03.966914
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import tempfile
    import urllib.request

    url = 'http://releases.ubuntu.com/12.04/ubuntu-12.04.3-desktop-amd64.iso'
    # Create temporary file
    tmp_fd, tmp_filename = tempfile.mkstemp(prefix='youtube-dl-test_httpfd-')
    os.close(tmp_fd)
    # File-descriptor based downloader
    fd = HttpFD(
        urllib.request.Request(url, None, std_headers),
        tmp_filename,
        'wb',
        {'continuedl': True, 'noprogress': True},
        lambda d, b, t: dl_progress_hook,
        lambda d: None)

# Generated at 2022-06-12 17:06:15.329197
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # create objects of the class
    content_type = 'application/octet-stream'
    data = b'a\r\nb\rc\nd\r\ne'
    info = {
        'size'            : len(data),
        'content-type'    : content_type,
        }
    content_length = info['size']

    hfd = HttpFD(data, info, 'test.mp4', {'content-type': 'text/plain'})

    # test info() method
    assert 'size' in hfd.info(), 'missed key "size"'
    assert 'content-type' in hfd.info(), 'missed key "content-type"'
    assert len(hfd.info()) == len(info)

    # test real_ioproxy() method
    assert hfd.real_ioproxy()

# Generated at 2022-06-12 17:06:28.181116
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Tested code is called more directly to prevent failures in case of new
    # command line parameters.

    cfg = {}
    ie = InfoExtractor()
    ie.params = {}
    ie.params['usenetrc'] = False
    ie.params['username'] = None
    ie.params['password'] = None
    ie.params['videopassword'] = None
    ie.params['ap_mso'] = None
    ie.params['ap_username'] = None
    ie.params['ap_password'] = None
    ie.params['ap_list'] = None
    ie.params['outtmpl'] = '%(id)s'
    ie.params['ignoreerrors'] = False
    ie.params['ratelimit'] = float('inf')
    ie.params['retries'] = 0
    ie.params

# Generated at 2022-06-12 17:06:33.342246
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for constructor of class HttpFD, making sure it's instantiated
    # properly for each of the protocols
    for proto in ('http', 'https'):
        fd = HttpFD(proto, DummyYDL(), None, {})
        assert isinstance(fd, HttpFD)

if __name__ == '__main__':
    test_HttpFD()