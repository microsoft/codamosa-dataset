

# Generated at 2022-06-12 17:00:07.535076
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def real_download(self, filename, info_dict):
        HttpFD.real_download(self, filename, info_dict)

    # test for non-existing file
    class TestHttpFD(HttpFD):
        def __init__(self):
            self.params = {'nooverwrites': True, 'continuedl': False}
            self.to_screen = lambda a: None
            self.report_error = lambda a, b: None
            self.report_warning = lambda a, b: None
            self.report_destination = lambda a: None

        def try_rename(self, tmpfn, f):
            raise OSError(errno.ENOENT, 'No such file or directory')

        def check_file_size(self, f, c, resume_len):
            return False


# Generated at 2022-06-12 17:00:20.059917
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class MyHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            self.to_screen_calls = 0
            self.to_stderr_calls = 0
            self.download_calls = 0
            self.hook_progress_calls = 0
            self.report_progress_calls = 0
            self.report_resuming_byte_calls = 0
            self.report_unable_to_resume_calls = 0
            self.report_destination_calls = 0
            self.undo_temp_name_calls = 0
            self.try_rename_calls = 0
            self._hook_progress = self._hook_progress_orig
            self.report_progress = self.report_progress_orig
            # Set up a temp dir so we can

# Generated at 2022-06-12 17:00:34.136923
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    run as
    python -m youtube_dl.YoutubeDL.utils -- test_real_download
    """
    #@UnresolvedImport
    import unittest
    import sys
    if sys.version_info[0] == 3:
        #@UnresolvedImport
        from io import BytesIO
    else:
        from StringIO import StringIO as BytesIO
    class HttpFDMock(compat_urllib_request.HTTPHandler):
        def __init__(self, url, urlopen):
            compat_urllib_request.HTTPHandler.__init__(self)
            self._url = url
            self._urlopen = urlopen
        def http_open(self, req):
            return self.do_open(self._urlopen, req)


# Generated at 2022-06-12 17:00:45.319550
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.google.com')
    assert fd.real_downloader is not None
    assert fd.tmpfilename is None
    assert fd.close_tmp_file is True
    assert fd.name is None
    assert fd.content_type == 'text/html; charset=ISO-8859-1'
    assert fd.closed is False
    assert fd.size is None
    assert fd.read() == b'<!doctype html><html itemscope="itemscope" itemtype="http://schema.org/WebPage">'
    fd.close()
    assert fd.closed is True

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:00:56.184257
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os, io, json
    import tempfile
    import shutil

    import socket
    import http.server

    class FakeServer(http.server.HTTPServer):
        """A server that can return a fixed content-length and content."""

        def __init__(self, nbytes, content, *args, **kwargs):
            super(FakeServer, self).__init__(*args, **kwargs)
            self.nbytes = nbytes
            self.content = content

        def finish_request(self, request, client_address):
            request.send_response(200)
            request.send_header('Content-Length', str(self.nbytes))
            request.end_headers()
            request.wfile.write(self.content)


# Generated at 2022-06-12 17:01:08.065847
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test cases:
    # [ (url, filename, data) ]
    # url: URL to get
    # filename: Filename to compare to (None if not available)
    # data: Data to compare to (None if not available)
    test_cases = [
        # Non-existent server
        (
            'http://localhost:1/',
            None, None
        ),
        # Non-existent file
        (
            'http://localhost/~a/inexistent',
            'http', None
        ),
        (
            'http://github.com/',
            'http',
            b'302 Found'
        ),
    ]


# Generated at 2022-06-12 17:01:10.279406
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import doctest
    return doctest.testmod(HttpFD)



# Generated at 2022-06-12 17:01:24.175257
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create DummyHttpFD instance
    httpFD = DummyHttpFD()
    # Prepare to be able to overwrite method _hook_progress()
    httpFD._hook_progress = lambda x: True
    # Set test_urls

# Generated at 2022-06-12 17:01:32.418907
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test1(count):
        for i in range(count):
            ydl = YoutubeDL(params)
            http_fd = HttpFD(ydl, params, dl, info_dict)
            http_fd.download()

    def test2(count):
        ydl = YoutubeDL(params)
        http_fd = HttpFD(ydl, params, dl, info_dict)
        for i in range(count):
            http_fd.download()

#    test1(20)
#    test2(20)



# Generated at 2022-06-12 17:01:43.306794
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class TestDownloader(object):
        def to_screen(self, *args, **kargs):
            pass
    d = TestDownloader()

    # Test filename
    fd = HttpFD(d, 'http://www.google.com/test.bin', {'test.test': '1'})
    eq_(fd.test(), 'test.bin')
    eq_(dict(fd.info())['test.test'], '1')

    fd = HttpFD(d, 'http://www.google.com/test.bin', {'tmpfilename': '/tmp/abc'})
    eq_(fd.test(), '/tmp/abc')

    fd = HttpFD(d, 'http://www.google.com/test.bin', {'tmpfilename': '-'})
    eq_(fd.test(), '-')

   

# Generated at 2022-06-12 17:02:27.017290
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile

    data = b'test'
    tmpdir = tempfile.gettempdir()
    fn = os.path.join(tmpdir, 'youtubedl', 'test')
    if os.path.exists(fn):
        os.remove(fn)
    fd = HttpFD(data, fn, 'wb')
    assert fd.tell() == 0
    fsize = fd.write(data)
    assert fd.tell() == len(data)
    assert fsize == len(data)
    fd.close()
    with open(fn, 'rb') as f:
        assert f.read() == data
    os.remove(fn)



# Generated at 2022-06-12 17:02:39.149764
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test that it can connect
    info = {
        'url': 'http://www.example.com',
    }
    fd = HttpFD(ydl=FakeYDL(), params={}, info_dict=info)
    fd.prepare()
    fd.download(close_connection=True)
    # Test that it reports an error
    fd = HttpFD(ydl=FakeYDL(), params={}, info_dict=info)
    fd.prepare()
    try:
        fd.download(close_connection=True)
    except DownloadError as err:
        assert 'test succeeded' in str(err)


# Test cases for HttpFD.best_block_size method

# Generated at 2022-06-12 17:02:48.897736
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """ Testing function for HttpFD class """
    # Set parameters
    params = {
        'noprogress': False,
        'quiet': True,
    }
    # Create an HttpFD object
    http_fd = HttpFD(params)
    # Call its download() method (supposed to raise an error)
    try:
        http_fd.download(
            {'url': '#', 'filename': '-'},
            {},
            False,
            '-',
            {})
    except Exception:
        pass

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:03:00.032997
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DummyYDL(object):
        def report_error(self, msg):
            raise AssertionError(msg)
        def to_screen(self, msg):
            pass
        def to_stderr(self, msg):
            pass
        def urlopen(self, request):
            raise NotImplementedError()

    class MyHttpFD(HttpFD):
        _TEST_FILE_SIZE = 1024

        def __init__(self, ydl, params):
            super(MyHttpFD, self).__init__(ydl, params, None)
            self.download_retval = True

        def slow_down(self, start, now, downloaded):
            pass

        def best_block_size(self, elapsed_time, bytes_downloaded):
            return 1024


# Generated at 2022-06-12 17:03:07.265279
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import sanitize_open, encodeFilename

    # fixtures
    class UndefinedException(Exception):
        pass

    class TestFD(object):
        def __init__(self, params, info_dict):
            self.params = params
            self.to_stderr = lambda s: None
            self.to_screen = lambda s: None
            self.report_error = lambda s: None
            self.report_retry = lambda a, b, c: None
            self.report_resuming_byte = lambda a: None
            self.report_unable_to_resume = lambda: None
            self.report_file_already_downloaded = lambda a: None
            self.report_destination = lambda a: None

            self._hook_progress = lambda d: None

            self.ydl = MockYtd

# Generated at 2022-06-12 17:03:17.226406
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # The main "test" is to run it until it does not throw
    # an exception.
    #
    # In case of an exception the concatenated output of all
    # downloads is tested against:
    # - test_content_small: abcdefghij
    # - test_content_large: [content of large_file]
    # If the test fails, the last content is dumped to stdout.
    #
    # To speed up the test, the available network connections are
    # counted and each download uses that many connections.

    # The test URL - will be downloaded, the content must be
    # test_content_small or test_content_large
    url = 'http://127.0.0.1:8080/'
    test_content_small = (b'abcdefghij')
    test_content_large = open

# Generated at 2022-06-12 17:03:24.969393
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io, sys

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
        def report_error(self, *args):
            pass
        def report_retry(self, *args):
            pass
        def report_resuming_byte(self, *args):
            pass
        def report_destination(self, *args):
            pass
        def report_unable_to_resume(self, *args):
            pass
        def report_file_already_downloaded(self, *args):
            pass
        def urlopen(self, req):
            assert req.headers.get('range') == 'bytes=0-1'
            return FakeHTTPResponse(io.BytesIO(b'12'), {'content-length': '2'}, req)

# Generated at 2022-06-12 17:03:35.818438
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    import unittest

    import ssl

    from contextlib import closing

    import http.server as httpserver
    import socketserver

    from youtube_dl.utils import encodeFilename, expanded_path, format_bytes
    from youtube_dl.YoutubeDL import YoutubeDL

    port = None
    tmpdir = None
    server_code = None
    server_process = None

    class MyHandler(httpserver.SimpleHTTPRequestHandler):
        def do_GET(self):
            global server_code
            if server_code is None:
                self.send_response(200)
                self.send_header('Content-Length', '42')
                self.end_headers()
                self.wfile.write(b'I am a test. Hear me roar!')
            else:
                self.send_

# Generated at 2022-06-12 17:03:37.520271
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert isinstance(HttpFD().real_download(None, None, None, {}), bool)

# Generated at 2022-06-12 17:03:45.938017
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:05:12.950117
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test HTTP retrieval
    # The test download is an approximately 1.5MB mpeg file from
    # http://www.quirksmode.org/html5/videos/big_buck_bunny.mp4
    if sys.platform.startswith('darwin') and sys.version_info < (3, 0):
        # Workaround for random hangs on OSX with Python < 3.0
        # TODO fix this in a better way
        raise unittest.SkipTest('Hanging on OSX with Python < 3.0')
    url = 'http://www.quirksmode.org/html5/videos/big_buck_bunny.mp4'
    test_file = HttpFD(None, {}, url, {}).test()
    assert test_file is not None

    # Test HTTP retrieval using headers
    # The test

# Generated at 2022-06-12 17:05:25.064251
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    class A:
        def __getattr__(self, item):
            return None
    class B:
        def __init__(self, item):
            self.item = item
            self.info = {'Content-Length': len(item)}
        def read(self, num):
            item = self.item
            self.item = None
            return item
    class Context:
        pass
    ctx = Context()
    ctx.filename = 'test-file'
    ctx.tmpfilename = 'test-file'
    ctx.stream = io.open(ctx.tmpfilename, 'wb')
    ctx.stream.write(b'abc')
    assert ctx.stream.tell() == 3
    ctx.stream.close()

# Generated at 2022-06-12 17:05:37.696782
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Test the HttpFD constructor"""
    from .FakeYDL import FakeYDL
    fd = HttpFD(FakeYDL(), {'noprogress': True}, 'http://localhost/path')
    assert fd.ydl is not None
    assert fd.params is not None
    assert fd.url == 'http://localhost/path'

# Generated at 2022-06-12 17:05:44.533566
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test the http streams
    for stream_url in ['http://127.0.0.1:8080/', 'http://localhost:8080/', 'http://example.com/']:
        try:
            fd = HttpFD(stream_url, params={})
            info_dict = fd.prepare_fn(fd, stream_url)
            print(info_dict)
        except (compat_urllib_error.HTTPError, compat_urllib_error.URLError, ValueError) as err:
            pass
    return 0

if __name__ == '__main__':
    sys.exit(test_HttpFD())

# Generated at 2022-06-12 17:05:53.578901
# Unit test for constructor of class HttpFD
def test_HttpFD():
    dummy_urlopener = mock.Mock()
    dummy_urlopener.read = lambda: 'testfile'
    dummy_urlopener.info.return_value = {'Content-length': len('testfile'), 'Content-type': 'video/x-flv'}
    h = HttpFD(dummy_urlopener, 'testfile', {'nopart': True, 'continuedl': True, 'nooverwrites': False})
    assert not h.partnum
    assert h.name == 'testfile'
    assert h.mode == 'wb'
    assert not h.continuedl
    assert h.total == len('testfile')

    # test partnum

# Generated at 2022-06-12 17:06:03.003795
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import is_outdated_version
    from .extractor.common import InfoExtractor
    from .compat import (
        compat_HTTPError,
        compat_urllib_request,
    )
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .downloader.external import FFmpegFD
    import os
    import socket
    import tempfile
    import urlparse

    if is_outdated_version('2.5'):
        return

    # Test downloader using an actual server

    # Test server: HTTP server (Python 3)
    class EchoServer(HTTPServer):
        def __init__(self, server_address):
            super(EchoServer, self).__init__(
                server_address, SimpleHTTPRequestHandler)


# Generated at 2022-06-12 17:06:14.639513
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # We do not want to make real HTTP requests
    def mock_urlopen(req):
        assert False
    # We will inject an object that behaves like a socket
    class MockSocket(object):
        def __init__(self, data):
            self.data = data
            self.len = len(data)
            self.ptr = 0
        def info(self):
            return {'Content-Length': '%d' % self.len}
        def close(self):
            pass
        def read(self, size=8192):
            if self.ptr >= self.len:
                return b''
            n = min(size, self.len - self.ptr)
            r = self.data[self.ptr:self.ptr+n]
            self.ptr += n
            return r
    # We put the data that we want

# Generated at 2022-06-12 17:06:18.196878
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert_raises(ValueError, HttpFD, 'http://www.example.org/', None, 'wb')
    HttpFD('http://www.example.org/', DummyYDL({}))



# Generated at 2022-06-12 17:06:30.200770
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # pylint: disable=line-too-long
    s = '1234 A Quick Brown Fox Jumps Over The Lazy Dog'

    hd = HttpFD(io.BytesIO(s.encode('utf-8')), {'Content-Type': 'text/plain'}, 'test.txt')
    assert hd.read() == s.encode('utf-8')

    hd = HttpFD(io.BytesIO(s.encode('utf-8')), {'Content-Type': 'text/plain'}, 'test.txt', 1024)
    assert hd.read() == s.encode('utf-8')
    assert hd.fileno() is None
    assert repr(hd) == '<HttpFD test.txt>'
    assert hd.tell() == len(s)

    hd = H

# Generated at 2022-06-12 17:06:34.839586
# Unit test for constructor of class HttpFD
def test_HttpFD():
    urlopen = compat_urllib_request.urlopen
    try:
        compat_urllib_request.urlopen = lambda *args, **kwargs: args[0]
        assert HttpFD(DummyYDL(), '', params={}) == ''
    finally:
        compat_urllib_request.urlopen = urlopen

