

# Generated at 2022-06-12 17:00:06.709102
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def download(self, filename, info_dict, downcmd):
        assert downcmd == ['wget', '-c', '--passive-ftp', '-t', '3', '--user-agent', 'test agent', '--', 'http://www.example.com/video.mp4', '-O', '-']
        assert getattr(self, 'test_video_length', None) is not None
        return [self.test_video_length]

    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.IE_NAME = 'test_ie'
    ie.params = {'http_chunk_size': 8, 'nopart': False, 'usenetrc': False}
    ie.http_headers = {}
    ie.add_info_extractor(ie)
   

# Generated at 2022-06-12 17:00:19.525654
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # test for method real_download of class HttpFD
    def real_download_tester(ydl, file_size, num, download_len):
        # test with different sizes and combinations of file_size and download_len
        assert num == int(num)
        assert download_len == int(download_len)
        # download_len == 0: test that whole file is downloaded
        # if download_len == file_size then the file is downloaded in the first loop
        # iteration and second loop iteration is not needed and skipped
        if download_len == file_size:
            num = 1
        if download_len == 0:
            download_len = file_size
        assert num > 0
        # count is a number of downloaded blocks and downloaded_bytes is a number of bytes downloaded
        # Note that there is one additional download - when testing download_len

# Generated at 2022-06-12 17:00:32.120547
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hd = HttpFD('http://www.youtube.com/get_video_info?video_id=BaW_jenozKc', {'test': 'data'}, 'http://www.youtube.com/watch?v=BaW_jenozKc')
    assert hd.real_url == 'http://www.youtube.com/get_video_info?video_id=BaW_jenozKc'
    assert hd.info_dict == {'test': 'data'}
    assert hd.url == 'http://www.youtube.com/watch?v=BaW_jenozKc'
    s = hd.read(1024)
    assert s.startswith('status=fail')
    hd.close()


# Generated at 2022-06-12 17:00:44.749420
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # No byte range
    h = HttpFD('http://127.0.0.1/', None, {}, {})
    assert h.url == 'http://127.0.0.1/'
    assert h.headers == {}
    assert h.test == False
    assert h.partial == False
    assert h.byte_range == None

    # With byte range
    h = HttpFD('http://127.0.0.1/', None, {'test': True, 'bytes': '0-499', 'continue': True}, {})
    assert h.url == 'http://127.0.0.1/'
    assert 'Range' in h.headers
    assert h.headers['Range'] == 'bytes=0-499'
    assert h.test == True
    assert h.partial == True
    assert h.byte

# Generated at 2022-06-12 17:00:55.806361
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # 512 kB
    FIRST_SIZE = 512 * 1024
    # 1 MB
    SECOND_SIZE = 1024 * 1024

    ctx = {
        'params': { 'nooverwrites': True, 'continuedl': True },
        'filename': '-',
        'test': True,
    }

    # Test write_chunk with smaller chunk
    first_chunk = b'a' * FIRST_SIZE
    fd = HttpFD(ctx, update_url_query=lambda u, s: u).start()
    done = fd.write_chunk(first_chunk)
    assert not done
    assert fd.get_size() == FIRST_SIZE
    fd.finish()
    # Skipping the first chunk, we should read the second one
    assert fd.read(FIRST_SIZE)

# Generated at 2022-06-12 17:01:07.799515
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def assertEqual(a, b):
        if a != b:
            assert False, '%r != %r' % (a, b)
    def assertTupleEqual(a, b):
        if a != b:
            assert False, '%s != %s' % (repr(a), repr(b))
    ydl = YoutubeDL()
    ydl.params['noprogress'] = False
    ydl.params['logger'] = MockLogger()
    # From real life

# Generated at 2022-06-12 17:01:21.730723
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import DateRange
    from .compat import parse_qsl

    # Try to instantiate the class and make sure it does not raise any error
    h = HttpFD(None, None, None, None, None)
    assert isinstance(h, HttpFD)

    if sys.version_info >= (3,):
        return
    elif sys.version_info >= (2, 7):
        kwargs = {}
    else:
        kwargs = {'strandard_errors': 'ignore'}
    cmd = [sys.executable, '-c',
           "import youtube_dl.YoutubeDL;ydl = youtube_dl.YoutubeDL({'usenetrc': '-c'});ydl.download(['http://example.org/index.html'])"]
    retcode = subprocess

# Generated at 2022-06-12 17:01:33.729530
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Test HttpFD constructor and attributes."""

    # Test 'assert' statements in constructor (no exception raised)
    HttpFD(
        downloader=None,
        params={},
        filename='',
        info_dict={},
        url='http://foo',
        dest='/dev/null',
        resume=None,
        data=object(),
        resume_len=0,
        chunk_size=0,
        start_time=0,
    )

    # Test None, 0, 1 and invalid values of 'chunk_size'
    info_dict = {}

# Generated at 2022-06-12 17:01:44.100948
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from collections import namedtuple
    import unittest
    import socket
    import ssl
    import gzip

    def make_socket(ports=(0, 0)):
        class Sock(object):
            def __init__(self, ports):
                self.host, self.port = ports

            def getpeername(self):
                return (self.host, self.port)

            def makefile(self, *args, **kwargs):
                return b'foobarbaz'

            def close(self):
                pass
        return Sock(ports)

    class TestHttpFD(unittest.TestCase):
        def test_create_connection(self):
            fd = HttpFD(make_socket((b'localhost', 80)), None)

# Generated at 2022-06-12 17:01:49.457395
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return [FileDownloader(params={'nooverwrites': True}).test(
        'http://releases.ubuntu.com/precise/ubuntu-12.04-preinstalled-desktop-armhf+omap4.img.xz',
        list(range(0, 1000, 100)) + list(range(1000, 1024, 1)))]

# Generated at 2022-06-12 17:02:35.531852
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    import os
    import socket
    import tempfile
    import shutil
    import subprocess
    import threading
    import time

    class MockServer(object):
        """
        Sets up a local HTTP server that is served from the current working directory
        """

        SERVER_ADDRESS = 'localhost'
        SERVER_PORT = 8558
        SERVER_URL = 'http://%s:%s/' % (SERVER_ADDRESS, SERVER_PORT)

        def __init__(self, test_files):
            self.test_files = dict(test_files)

        def start(self):
            self.httpd = StoppableHttpServer((self.SERVER_ADDRESS, self.SERVER_PORT),
                StoppableHttpRequestHandler)
            self.httpd.serve_forever()


# Generated at 2022-06-12 17:02:46.605742
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import io
    class FakeOpener:
        def __init__(self):
            self.http_code = 0
        def open(self, req):
            self.req = req
            return self
        def info(self):
            return compat_httplib.HTTPMessage(io.BytesIO(b'Content-Length: 100\n'))
    fd = HttpFD(FakeOpener(), None, 'http://foo/bar')
    assert fd.name == 'http://foo/bar'
    assert fd.real_url == 'http://foo/bar'
    assert fd.headers == {}
    assert fd.length == 100
    assert fd.end_pos == 100
    assert fd.size() == 100



# Generated at 2022-06-12 17:02:56.190326
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .downloader import FileDownloader
    from .extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        def _real_initialize(self):
            self.to_screen('Test IE: initialized')
        @staticmethod
        def suitable(url):
            return True
        def _real_extract(self, url):
            ie = self
            class MockIE(TestIE):
                def _real_extract(inner_self, url):
                    ie.to_screen('Test IE: extracting')
                    fd = ie.http_fd
                    ie.to_screen('Test IE: http_fd = ' + str(fd))
                    if fd is None or not fd.good_enough:
                        ie.to_screen('Test IE: returning')
                        return

# Generated at 2022-06-12 17:03:05.593075
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import tempfile
    import random

    ydl = YoutubeDL({'nooverwrites': True, 'quiet': True, 'simulate': True})

    # Create large file in temp directory
    size = 1024 * 1024 * 2  # 2 MiB
    test_file_path = os.path.join(tempfile.gettempdir(), 'ytdl_test_file')
    _, test_file_path = tempfile.mkstemp(prefix='ytdl_test_file_')
    test_file = open(test_file_path, 'wb')
    test_file.seek(size - 1)
    test_file.write(b'\0')
    test_file.close()

    url = 'file://' + test_file_path
    filename = '-'


# Generated at 2022-06-12 17:03:15.995230
# Unit test for constructor of class HttpFD
def test_HttpFD():
    options = {
        'quiet': True,
        'skip_download': True,
        'format': '42',
    }
    ydl = YoutubeDL(options)
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_info_extractor(MetacafeIE())
    ydl.add_info_extractor(DailymotionIE())

    # Youtube
    test_cases = [
        # test that the 'source_address' parameter is honored
        ('http://www.youtube.com/watch?v=BaW_jenozKc', 'source_address'),
        # test that the 'prefer_insecure' parameter is honored
        ('https://www.youtube.com/watch?v=BaW_jenozKc', 'prefer_insecure')
    ]


# Generated at 2022-06-12 17:03:24.177796
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_common(httpfd, filename, url, params):
        assert httpfd.filename == filename
        assert httpfd.url == url
        assert httpfd.params == params
        assert httpfd.downtotal == 0
        assert httpfd.tmpfilename == '-'

    params = {
        'continuedl': True,
        'nooverwrites': True,
        'retries': 10,
        'buffersize': '1024',
        'noresizebuffer': True,
        'test': True,
    }

# Generated at 2022-06-12 17:03:35.448843
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading
    from pytube.compat import urlopen

    class DummyYDL(object):
        def __init__(self, *args):
            self.params = {'retries': 1}

        def report_error(self, msg):
            raise Exception(msg)

        def report_retry(self, err, count, retries):
            raise RetryDownload(err, count, retries)

        def slow_down(self, start, now, byte_counter):
            time.sleep(0.1)

        def best_block_size(self, elapsed_time, bytes_now):
            return 1024

        def calc_speed(self, start, now, bytes_so_far):
            return float()

        def calc_eta(self, start, now, total_bytes, bytes_so_far):
            return

# Generated at 2022-06-12 17:03:43.457459
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(SanitizeFilenameFD(), {}, None, {}).__class__.__name__ == 'SanitizeFilenameFD'
    assert HttpFD(None, {}, None, {}).__class__.__name__ == 'KnownLengthHttpFD'
    assert HttpFD(None, {'noprogress': True}, None, {}).__class__.__name__ == 'HttpFD'
    assert HttpFD(None, {'continuedl': True}, None, {}).__class__.__name__ == 'DummyFD'
    assert HttpFD(None, {'nopart': True}, None, {}).__class__.__name__ == 'DummyFD'

# Generated at 2022-06-12 17:03:55.457743
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-12 17:04:00.481228
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL({'quiet': True})
    fd = HttpFD(ydl, 'https://www.google.com')
    assert 'google.com' in fd.url
    content = fd.read().decode('utf-8')
    assert '<!doctype html>' in content
    fd.close()
    fd.close()


# Generated at 2022-06-12 17:05:27.122661
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # The example file was chosen because it is small and because
    # some user complained that it only downloads 16 bytes
    # videodownload.py --test http://aol.com/
    from .geturl import test_ydl
    def report_retry(self, source_error, count, retries):
        print('retry')
    test_ydl.FD.report_retry = report_retry
    fd = test_ydl.FD()
    fd.report_destination = lambda x: None
    fd.report_progress = lambda x: print(x)
    fd.report_warning = lambda x: print(x)
    fd.report_error = lambda x: print(x)
    fd.real_download('http://www.cnbc.com/', None)


# }}}



# Generated at 2022-06-12 17:05:31.370783
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hd = HttpFD(None, [], {}, None)
    if hd is None:
        print('ERROR: unable to instantiate class HttpFD')
    else:
        print('sucessfully instantiated class HttpFD')


# Generated at 2022-06-12 17:05:42.211890
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """This test downloads a real file, verifies that its contents are correct,
       and then deletes it."""
    from sys import stdout
    FD = HttpFD(None, None)  # Instantiation works without arguments

    # The website is chosen so that:
    #  a) The file is small and loads quickly.
    #  b) Its contents are likely not to change.
    #  c) It is served over HTTPS, so we can use verify=True.
    #  d) It has a real filename in the URL.
    #  e) The URL doesn't have '&amp;' which would need escaping.
    first_url = 'https://github.com/rg3/youtube-dl/blob/master/README.md'

# Generated at 2022-06-12 17:05:51.443198
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class MyFD(HttpFD):
        def __init__(self, desc, params):
            self.desc = desc
            self.params = params

        def check_status(self):
            return True

    info = {'test': True}
    params = {'testkey': 'testvalue'}
    myfd = MyFD(info, params)
    assert myfd.test == True
    assert myfd.testkey == 'testvalue'
    assert myfd.info['test'] == True
    assert myfd.params['testkey'] == 'testvalue'

if __name__ == '__main__':
    # test constructor
    test_HttpFD()
    # test sanitize_open()
    f = sanitize_open('test.txt', 'w')
    f.write(b'foo')

# Generated at 2022-06-12 17:06:01.511151
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    params = {
        'usenetrc': False,
        'username': 'uname',
        'password': 'pword',
        'noprogress': False,
        'retries': 10,
        'continuedl': True,
        'nofatal': True,
        'nopart': False,
        'updatetime': False,
        'test': True,
        'verbose': True,
    }
    ydl = YoutubeDL(params)
    info = {}
    ydl.report_warning = Mock()
    ydl.report_error = Mock()
    ydl.to_screen = Mock()

# Generated at 2022-06-12 17:06:02.670711
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # No test implemented
    return

# Generated at 2022-06-12 17:06:12.045220
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import get_filesystem_encoding
    h = HttpFD(DummyYoutubeDL({}), None, None)
    assert h.proto == 'http'
    tmpdir = os.path.dirname(h.temp_name('test'))
    assert isinstance(tmpdir, str)
    assert tmpdir.endswith('youtube-dl')
    assert os.path.exists(tmpdir)
    assert get_filesystem_encoding() in get_encodings_compatible(sys.getfilesystemencoding())
    os.rmdir(tmpdir)


# Generated at 2022-06-12 17:06:24.543522
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import shutil
    import tempfile

    # since this test may call slow_down() and thereby time.sleep()
    # we patch time.sleep to do nothing to speed up the test
    old_sleep = time.sleep

    class dummy_sleep:
        def __call__(self, t):
            pass

    time.sleep = dummy_sleep()

    fd = HttpFD(test_opts, {})
    tmpdir = tempfile.mkdtemp(prefix='ytdl-test-')
    tmpfile = os.path.join(tmpdir, 'xxx')


# Generated at 2022-06-12 17:06:32.378927
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if sys.version_info[:2] == (3, 2):
        return True
    assert HttpFD(None, fake_url, None, None, True) is None
    assert HttpFD(None, fake_url, None, None, False) is not None
    assert HttpFD(dict(), fake_url, None, None, False) is not None
    assert HttpFD(None, fake_url, {}, None, False) is not None
    assert HttpFD(None, fake_url, None, {}, False) is not None
    return True

test_HttpFD()

# Generated at 2022-06-12 17:06:40.434261
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Test the constructor of the class HttpFD. This will download the file
    http://www.example.com/ to a temporary directory.
    """
    import tempfile
    import shutil
    import os
    import random

    def info_dict_extractor(filename, download_url, info_dict):
        return info_dict

    tmpdir = tempfile.mkdtemp()