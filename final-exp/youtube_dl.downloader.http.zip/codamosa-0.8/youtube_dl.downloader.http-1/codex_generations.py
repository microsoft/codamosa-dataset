

# Generated at 2022-06-12 17:00:03.178337
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import os

    out, err = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = StringIO(), StringIO()

    tmp_fd = tempfile.NamedTemporaryFile(mode='w+b', delete=False)
    tmp_fd.seek(0)
    tmp_fd.truncate(0)
    old_tmp_filename = tmp_fd.name
    old_tmp_handle = tmp_fd.file
    tmp_fd.close()

    # os.unlink(tmp_fd.name)

# Generated at 2022-06-12 17:00:17.508806
# Unit test for constructor of class HttpFD
def test_HttpFD():
    t = HttpFD(
        'http://www.example.org/',
        {
            'outtmpl': ('-' if sys.version_info[0] > 2 else '-') + '%(ext)s',
            'continuedl': True,
            'nooverwrites': False,
        }, SrvHttpProgress(), None)
    t.add_header('Range', 'bytes=0-') # Simulate retrying
    t.download({
        'url': 'http://www.example.org/video.mp4',
        'fragment_base_url': 'http://www.example.org/video-part%d.ts',
        'fragment_count': 2,
        'fragment_index': 2,
        'chunk_size': 5,
    })



# Generated at 2022-06-12 17:00:31.778713
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class TestException(Exception):
        pass

    test_exception_raised = False

    def test_http_equiv_hook(s):
        raise TestException()

    def test_http_head_hook(s):
        raise TestException()


# Generated at 2022-06-12 17:00:44.613057
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # For testing purposes, we use a local webserver to provide a test
    # file, and simulate various server errors.  The test file is
    # generated on the fly by the webserver, based on the query string.
    # It will be a file of the given length, containing the numbers 1-n
    # in ASCII.

    fd = HttpFD(
        'http://127.0.0.1:23300/%(length)s',
        {
            'http_chunk_size': 10,
            'http_test': True,
        })

    # If we request a file that does not exist, we should get an IOError
    # with an error code of 404.
    success = False

# Generated at 2022-06-12 17:00:51.367031
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    HttpFD_real_download_test_log = open("HttpFD_real_download_test_log.txt", "w")
    HttpFD_real_download_test_log.truncate()
    if sys.version_info < (2, 7):
        HttpFD_real_download_test_log.write("test_HttpFD_real_download is not performed, since your python version is too low!")
        return
    import os
    import tempfile

    class State(object):
        def __init__(self):
            self.category = 'test'
            self.tmpfilename = None
            self.tmpfilenames = []
            self.succ = False

        def report_error(self, msg):
            self.succ = False

# Generated at 2022-06-12 17:01:03.841605
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil
    import os
    import re
    import time
    import random
    import urllib.request

    # Test parameters
    url = 'http://example.com/video.mp4'
    filename = 'video.mp4'

    def slow_down_call():
        return False

    def real_download(ydl, filename, info_dict, params):
        http_fd = HttpFD(ydl, params)
        return http_fd.real_download(url, filename, info_dict)

    def test_normal():
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
        os.mkdir(test_dir)
        os.chdir(test_dir)

# Generated at 2022-06-12 17:01:18.186881
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test 1: simulate a file
    simulator = io.BytesIO(b'foobar')
    fd = HttpFD(simulator, 'http://127.0.0.1/foo.bin')
    assert fd.size() == 6
    assert fd.get_bytes(0, 3) == b'foo'
    assert fd.get_bytes(5, 5) == b'r'
    assert fd.get_bytes(0, 7) == b'foobar'
    assert fd.get_bytes(0, 200) == b'foobar'
    assert fd.get_bytes(3, 6) == b'bar'
    assert fd.get_bytes(2, 5) == b'oba'
    assert fd.get_size() == 6

# Generated at 2022-06-12 17:01:31.135273
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class MyHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            HttpFD.__init__(self, *args, **kwargs)
            self.filepath = tempfile.mkstemp('.test_ytdl_download')[1]
            self.stream = open(self.filepath, 'wb')

        def undo_temp_name(self, tmpfilename):
            return self.filepath

    ydl = FakeYdl()
    fd = MyHttpFD(
        ydl,
        {'url': 'https://www.example.com/test.mp4', 'test': True},
        {})

# Generated at 2022-06-12 17:01:40.061772
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    args = []
    params = {}
    data = compat_urllib_request.Request('http://example.org', None, {'User-Agent': 'test'})
    from io import BytesIO
    data = compat_urllib_response.addinfourl(BytesIO(b'\xff' * 100),
                                             data.headers, data.full_url)
    HttpFD._downloader = 'test'
    _real_download(data, None, '-', args, params, '-', {})

# Generated at 2022-06-12 17:01:48.431053
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import threading
    import tempfile
    import os
    import shutil
    import socket
    import time
    import pickle
    import random

    class MockServer(object):
        def __init__(self, port):
            self.port = port
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.settimeout(0.5)
            self.sock.bind(('localhost', port))
            self.sock.listen(5)
            self.connection = None
            self.stop_event = threading.Event()

        def run(self):
            self.stop_event.clear()

# Generated at 2022-06-12 17:02:22.147399
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, None, {'noprogress': True}, {})
    assert fd is not None



# Generated at 2022-06-12 17:02:35.696756
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Requires internet connection
    print('Testing real_download')
    ydl = YoutubeDL(params={'noprogress':True, 'logger': MyLogger(),
        'quiet': True})
    info_dict = {}
    url = 'http://releases.ubuntu.com/14.04.1/ubuntu-14.04.1-desktop-amd64.iso'
    filename = 'ubuntu-14.04.1-desktop-amd64.iso'
    tmpfilename = filename + '.part'
    params = {'continuedl': True, 'quiet': True}
    hdlr = HttpFD(ydl, params, filename, info_dict)
    # We have to simulate a real download:
    # 1. Put a file in the filesystem
    # 2. Download only a chunk of the file
    # 3. Put another file

# Generated at 2022-06-12 17:02:47.487839
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import encodeFilename, decodeFilename
    from .extractor import gen_extractors
    from .downloader import HttpFD

    # We need a bunch of extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'generic':
            break

    # A real world example

# Generated at 2022-06-12 17:02:52.298726
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, {'noprogress': True})
    fd.report_destination('')
    fd.to_screen('test')
    fd.to_stderr('test')
    fd.download(dict, '', '', {})



# Generated at 2022-06-12 17:03:02.592405
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://example.org', params={'noprogress': True})
    assert fd.url == 'http://example.org/'
    assert fd.params['noprogress']
    assert 'progress_hooks' not in fd.params
    fd = HttpFD(u'http://example.org', u'dst', params={'noprogress': False})
    assert fd.params['noprogress'] is False
    assert 'progress_hooks' in fd.params
    assert len(fd.params['progress_hooks']) == 1
    assert fd._TEST_FILE_SIZE == 1048576



# Generated at 2022-06-12 17:03:06.888187
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Tested in:
     test_download()
     test_download_with_options()
     test_extract_info()
     test_urlopen()
     test_urlopen_cached()
     test_suitable()
     test_YoutubeDL()
     test_YoutubeDL_process_info()
     test_YoutubeDL_process_ie_result()
     test_YoutubeDL_extract_info()
     test_YoutubeDL_extract_info_ie()
     test_YoutubeDL_download()

# Generated at 2022-06-12 17:03:16.937021
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test without http_chunk_size set
    fd = HttpFD(None, 'http://www.example.com/video.mp4', {}, 'http://www.example.com/video.mp4', None, 'video.mp4')
    assert not fd.chunk_size
    assert fd.resume_len == 0
    assert fd.open_mode == 'wb'
    assert fd.has_range is False

    # Test with http_chunk_size set to 1M
    fd = HttpFD(None, 'http://www.example.com/video.mp4', {}, 'http://www.example.com/video.mp4', None, 'video.mp4', 1 << 20)
    assert fd.chunk_size == 1 << 20
    assert fd.resume_len

# Generated at 2022-06-12 17:03:24.799143
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def add_mock_files(*files):
        for item in files:
            if isinstance(item, tuple):
                file_name, file_size = item
                file_data = None
            else:
                file_name = item
                file_size = None
                file_data = None
            mock_files[file_name] = {
                'size': file_size,
                'data': file_data,
                'write_calls': 0,
            }

    def fake_urlopen(request):
        cl = request.get_header('Content-Length')
        if cl is not None:
            cl = int(cl)
        url_name = compat_urllib_parse_unquote(request.get_full_url())
        _, _, file_name = url_name.partition('file://')

# Generated at 2022-06-12 17:03:35.691144
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .YoutubeDL import YoutubeDL
    from .PostProcessor import PostProcessor
    assert HttpFD(YoutubeDL({}), None, None, None, 0, 'http://www.example.org', {}).ydl is YoutubeDL({})
    assert HttpFD(YoutubeDL({}), None, None, None, 0, 'http://www.example.org', {}).url == 'http://www.example.org'
    assert HttpFD(YoutubeDL({}), None, None, None, 0, 'http://www.example.org', {}).pp is None
    assert not HttpFD(YoutubeDL({}), None, None, None, 0, 'http://www.example.org', {}).download_retry == {}

# Generated at 2022-06-12 17:03:44.729991
# Unit test for constructor of class HttpFD
def test_HttpFD():
    info_dict = {
        'id': 'BaW_jenozKc',
        'ext': 'mp4',
        'url': 'http://example.com/video.mp4?param=value',
        'player_url': "http://example.com/player.swf",
        'downloader_options': {
            'http_chunk_size': 10485760,
        },
    }
    def hook(status):
        print(status)
    ydl = YoutubeDL()
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.add_progress_hook(hook)
    h = HttpFD( ydl, info_dict['url'], info_dict)
    h.download()

# Generated at 2022-06-12 17:05:11.019230
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import ExtractorError

    # Setup mocks
    inst = YoutubeIE(InfoExtractor())
    inst.params = {'nooverwrites': True, 'outtmpl': '%(id)s%(ext)s'}
    inst.report_warning = lambda msg: None
    inst.report_error = lambda msg: None
    inst.to_stdout = lambda msg: None
    inst.to_stderr = lambda msg: None

    # Test file already exists
    test_real_download(inst, '123456789abcdef-1.mp4', {}, 0)
    test_real_download(inst, '123456789abcdef-2.mp4', {}, 2)
    # Test file

# Generated at 2022-06-12 17:05:19.503926
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # This function will test the method real_download of class HttpFD
    # in downloader/http.py. In particular, it will test that the
    # downloaded and expected files are the same size (we call the
    # method by force, because only HttpFD has the method and not
    # HttpFD itself, which is the class of the object).
    try:
        import mock
        import tempfile
        import io
    except ImportError:
        print("Missing dependencies for test_HttpFD.py")
        return
    # Define some constant values
    url = 'http://www.youtube.com/watch?v=90AiXO1pAiA'
    filename = 'test.flv'
    open_mode = 'wb'
    tmpfilename = tempfile.NamedTemporaryFile().name

# Generated at 2022-06-12 17:05:31.535339
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with a non-existent file
    fd = HttpFD('http://www.example.com/', {'noprogress': True})
    assert not fd.probe_file(False)
    assert fd.real_url is None
    assert fd.stream is None
    assert fd.filename is None
    assert fd.headers is None
    # Test with a non-supported scheme
    fd = HttpFD('ftp://ftp.example.com/', {'noprogress': True})
    assert not fd.probe_file(False)
    assert fd.real_url is None
    assert fd.stream is None
    assert fd.filename is None
    assert fd.headers is None


# Check if original_url is a valid URL.

# Generated at 2022-06-12 17:05:42.354766
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # We need objects for the test itself
    class DummyFD(object):
        def __init__(self):
            self.ctx = ctx = Context()
            ctx.prepare_test()

    # We are testing real_download() method of class HttpFD
    test_fd = HttpFD()
    # We need to initialize that test_fd with a Context
    test_fd.ctx = DummyFD().ctx

    # Let's create a dummy url and a file to download
    test_url = 'http://127.0.0.1:1234/'
    test_fd.ctx.tmpfilename = 'tmpfilename.tmp'

    # We need to create a temp file and open it for writing
    # Also we create a file descriptor for it
    tf = tempfile.NamedTemporaryFile(delete=False)
    test

# Generated at 2022-06-12 17:05:48.308583
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_get_url():
        # Test url
        url = 'http://regex.info/blog/'
        # Check get_url
        test_get_url.get_url = HttpFD(url, params).get_url()
        if test_get_url.get_url == url:
            print('Test get_url passed')
        else:
            print('Test get_url FAILED')

    def test_is_seekable():
        # Test is_seekable
        test_is_seekable.is_seekable = HttpFD(None, params).is_seekable()
        if test_is_seekable.is_seekable == False:
            print('Test is_seekable passed')
        else:
            print('Test is_seekable FAILED')


# Generated at 2022-06-12 17:05:58.415761
# Unit test for constructor of class HttpFD

# Generated at 2022-06-12 17:06:05.031322
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class TestFD(HttpFD):
        def __init__(self, *args, **kwargs):
            HttpFD.__init__(self, *args, **kwargs)

        def real_download(self, filename, info_dict):
            return self.download(filename, info_dict)

    # Test download of two fragments [0:1000] and [1000:2000]
    test_url = 'https://upload.wikimedia.org/wikipedia/commons/transcoded/d/de/Elephant_seal_calf_at_Piedras_Blancas.webm/Elephant_seal_calf_at_Piedras_Blancas.webm.360p.webm'

# Generated at 2022-06-12 17:06:12.896690
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .utils import encode_data_uri

    working = True
    def testing(name, params):
        # Test for HttpFD behaviour
        global working

        if not working:
            return

        def report_warning(message):
            # print(message)
            pass
        def report_error(message):
            print(message)
        def to_screen(message):
            print(message)
        def to_stdout(message):
            print(message)
        def slow_down(start, now, byte_counter):
            pass
        def best_block_size(elapsed_time, bytes):
            # block_size
            return 131072

        def calc_speed(start, now, bytes_downloaded):
            return bytes_downloaded / (now - start)


# Generated at 2022-06-12 17:06:25.375915
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    if sys.version_info >= (3, ):
        return
    if sys.version_info >= (2, 6):
        import socket
        socket.setdefaulttimeout(10)
    # http://www.youtube.com/watch?v=BaW_jenozKc
    # 2011.07.28, 480p, 38.4 MB
    sys.stderr.write('Testing HttpFD...\n')

# Generated at 2022-06-12 17:06:35.576592
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Dummy class for representing info_dict
    class DummyInfoDict:
        simulation = False
        def get(self, key):
            if key == 'url':
                return 'http://www.youtube.com/watch?v=LFsbjKdiQ_Y'
            elif key == 'http_headers':
                return {'User-Agent': 'youtube-dl test'}
            elif key == 'test':
                return True
            elif key == 'protocol':
                return 'http'
            return None

    # Testing if constructor raises errors
    dl = HttpFD(
        DummyInfoDict(), {'noprogress': True, 'quiet': True},
        'testval', 'testval2.mp4')
    # Testing if constructor downloads and returns filename
    dl.test()
   