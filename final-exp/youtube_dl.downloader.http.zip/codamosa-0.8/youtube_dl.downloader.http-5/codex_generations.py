

# Generated at 2022-06-12 16:59:59.611636
# Unit test for constructor of class HttpFD
def test_HttpFD():
    print('Testing constructor of class HttpFD...')
    fd = HttpFD(urlopen('http://example.com/'))
    print('Done.')


# Generated at 2022-06-12 17:00:03.657027
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for error reporting for non-existant URL
    try:
        h = HttpFD('http://127.0.0.1/nonexistant', {}, {})
        h.retrieve()
    except:
        pass
    else:
        assert False


# Generated at 2022-06-12 17:00:18.022930
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO

    # Forbid urllib2 to complain that it doesn't know how to handle
    # BytesIO instances
    compat_urllib_request.data_types_map[BytesIO] = 'unknown'

    # Constructor of HttpFD should not complain if BytesIO is passed as a URL ('-' is not a URL)
    fd = HttpFD('-', {}, BytesIO(b'content'))

    # Check if file descriptor methods work as expected
    assert fd.read() == b'content'
    assert fd.read(2) == b'co'
    assert fd.tell() == 2
    fd.seek(0)
    assert fd.read() == b'content'
    info = fd.info()

# Generated at 2022-06-12 17:00:32.547381
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    downloader = DummyYDL()
    fd = HttpFD(downloader, params={
        'test': True,
        'retries': 1,
        'ratelimit': 30000,
        'buffersize': 10,
        'noresizebuffer': False,
        'continuedl': True
    })
    url = 'http://ipv4.download.thinkbroadband.com/10MB.zip'

    def _write_chunks(fd, num_chunks, chunk_size):
        for _ in range(num_chunks):
            data_block = 'a' * chunk_size
            byte_counter = fd.ctx.resume_len + len(data_block)
            if fd.ctx.data_len is not None:
                data_len_left = fd.ctx.data_len

# Generated at 2022-06-12 17:00:44.973575
# Unit test for constructor of class HttpFD
def test_HttpFD():
    f = HttpFD(test_url, params={'noprogress': True})
    assert f.get_size() == 2393
    assert f.read(100) == b'<!DOCTYPE html PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>301 Moved Permanently</title>\n</head><body>\n<h1>Moved Permanently</h1>\n<p>The document has moved <a href="http://example.com/">here</a>.</p>\n<hr>\n<address>Apache Server at youtube-dl.org Port 80</address>\n</body></html>\n'
    assert f.read(100) == b''

# Generated at 2022-06-12 17:00:53.418317
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Test HttpFD constructor
    """
    # Test with unicode
    fd = HttpFD(u'http://www.example.com/', {'noprogress': True}, u'unicode_filename')

    # Test with str
    fd = HttpFD('http://www.example.com/', {'noprogress': True}, u'unicode_filename')

    # Test with binary
    fd = HttpFD(b'http://www.example.com/', {'noprogress': True}, b'bytes_filename')


# Generated at 2022-06-12 17:01:05.969183
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.youtube import YoutubeIE

    def download(params):
        params = params.copy()
        params.setdefault('verbose', True)
        params.setdefault('quiet', True)
        params.setdefault('format', 'best')
        params.setdefault('noprogress', True)
        params.setdefault('forcetitle', True)
        params.setdefault('forceurl', True)
        params.setdefault('forcethumbnail', True)
        params.setdefault('forcedescription', True)
        params.setdefault('simulate', True)
        params.setdefault('noplaylist', True)
        params.setdefault('logger', YoutubeIE()._downloader.report_warning)
        params.setdefault('test', True)


# Generated at 2022-06-12 17:01:09.628866
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, None, None, 'not_a_real_filename', {})
    assert fd.real_download is None
    assert fd.progressive is False



# Generated at 2022-06-12 17:01:15.517779
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os
    (fd, dl) = HttpFD(test=True)
    assert fd.closed
    assert os.path.isfile(dl)
    os.remove(dl)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:01:28.749219
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # not testing every possibility. It's just for basic coverage.

    class DummyYDL(object):
        def __init__(self):
            self.params = {
                'continuedl': True,
                'nooverwrites': True,
                'retries': 3,
                'buffersize': '1024',
                'noresizebuffer': True,
            }
            self.to_stderr = lambda msg: None
            self.to_screen = lambda msg: None
            self.report_error = lambda msg: None
            self.report_retry = lambda err: None
            self.report_resuming_byte = lambda byte_counter: None
            self.report_destination = lambda filename: None


# Generated at 2022-06-12 17:02:12.192094
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _test_HttpFD_real_download(args):
        fd, filename, data_len, test_data_len, test_seek, min_filesize, max_filesize, retries = args
        ctx = {
            'filename': filename,
            'tmpfilename': filename,
            'data_len': data_len,
        }
        fd.real_download(ctx, retries)
        assert ctx['data_len'] == test_data_len
        assert os.path.getsize(encodeFilename(filename)) == test_seek
        if min_filesize is not None:
            assert ctx['data_len'] >= min_filesize
        if max_filesize is not None:
            assert ctx['data_len'] <= max_filesize


# Generated at 2022-06-12 17:02:19.299309
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test: empty params
    params = {
    }
    fd = HttpFD(params)
    fd.add_progress_hook(fd._hook_test_progress)

    # Test: simple download
    params = {
        'url': 'http://upload.wikimedia.org/wikipedia/commons/d/d1/El_Greco_-_View_of_Toledo.jpg',
        'outtmpl': 'test.jpg',
    }
    fd = HttpFD(params)
    fd.add_progress_hook(fd._hook_test_progress)
    result = fd.download()
    assert result, 'error when downloading file'
    assert fd.corrected_filename() == 'test.jpg', 'bad filename after download'

# Generated at 2022-06-12 17:02:32.884448
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # No authentication
    fd1 = HttpFD(
        'http://localhost/', 'http://localhost/my%20file', {}, ratelimit=10240)
    assert fd1.real_url == 'http://localhost/my%20file'
    assert fd1.url == 'http://localhost/my file'
    assert fd1.headers == {}
    fd2 = HttpFD(
        'http://user@localhost/', 'http://user@localhost/my%20file', {},
        ratelimit=10240)
    assert fd2.real_url == 'http://user@localhost/my%20file'
    assert fd2.url == 'http://user@localhost/my file'
    assert fd2.headers == {}
    # With authentication

# Generated at 2022-06-12 17:02:40.699310
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url = 'http://www.iana.org/domains/example/'

    class TestHttpFD(HttpFD):
        def __init__(self):
            HttpFD.__init__(self, dl, params={})

        def real_download(self, filename, info_dict):
            return self.try_download(url, filename, info_dict)

    dl = Downloader()
    dl.add_info_extractor(None)
    test_http_fd = TestHttpFD()
    assert test_http_fd.real_download('dummy.tmp', {})



# Generated at 2022-06-12 17:02:52.734171
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url = 'https://www.example.org/'
    filename = '-'
    params = {
        'continuedl': True,
        'sleep_interval': 0,
        'noresizebuffer': True,
    }

    fd = HttpFD(
        DummyYDL(),
        {'url': url},
        filename,
        params,
        '',
        '',
        0,
        None,
        None)

    # Test whether the block size is chosen correctly.
    # The expected result is a number between 512 and 8192.
    assert (512 <= fd.best_block_size(5.0, 512) <= 8192)

    # This is a dummy test to make sure that the constructor
    # does not raise an exception.
    # It is not possible to test the functionality, because
    #

# Generated at 2022-06-12 17:03:04.010334
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request

    class MockInfoExtractor(InfoExtractor):
        def download(self, url_or_request):
            self.to_screen('%s: Downloading %s' % (self.IE_NAME, url_or_request))
            return super(MockInfoExtractor, self).download(url_or_request)

    class MockIE(MockInfoExtractor):
        IE_NAME = 'MockIE'
        IE_DESC = 'Mock IE'
        _VALID_URL = r'(?i)^https?://.*\.(?P<ext>mkv|flv|mp4|m4a)$'


# Generated at 2022-06-12 17:03:15.123491
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import json
    from .downloader import FileDownloader
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE

    ydl = FileDownloader({
        'outtmpl': '%(id)s%(ext)s'
    })


# Generated at 2022-06-12 17:03:23.700092
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile

    def _test_httpfd_real_download(httpfd, params, retries, test_file_size):
        httpfd.params = params
        test_tmpfilename = tempfile.NamedTemporaryFile(delete=False)
        test_tmpfilename.close()
        test_data_len = test_file_size + 1

        class TestURLopener(compat_urllib_request.FancyURLopener):
            # Emulate that a webserver serves the whole file,
            # despite of requested Range
            def http_error_206(*args, **kwargs):
                raise compat_urllib_error.HTTPError(
                    None, 416, 'Range not satisfiable', None, None)

            def http_error_416(*args, **kwargs):
                raise compat_urllib

# Generated at 2022-06-12 17:03:29.189441
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Initializing some test variables
    block_sizes = [1, 5, 10, 20, 50, 100, 500, 1000, 5000]
    test_data_len = 5000
    test_data = b'abcdefghij'
    test_urlopen_data = b'x' * (test_data_len - len(test_data)) + test_data
    # Initializing test counters
    request_call_cnt = 0
    urlopen_call_cnt = 0
    read_call_cnt = 0
    write_call_cnt = 0
    write_byte = 0
    write_byte_cnt = 0
    block_size_idx = 0
    def request(url, *args, **kwargs):
        nonlocal request_call_cnt
        nonlocal block_size_idx

# Generated at 2022-06-12 17:03:40.590633
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    fd = HttpFD(BytesIO(b''))

    assert fd.headers is None

    fd.headers = ['header1']
    assert fd.headers == ['header1']

    fd.headers = 'header2'
    assert fd.headers == ['header2']

    fd.headers = 'header1\nheader2'
    assert fd.headers == ['header1\nheader2']

    fd.headers = ['header1']
    fd.headers = ['header2']
    assert fd.headers == ['header2']

    fd.headers = 'header1\nheader2'
    fd.headers = 'header2\nheader3'
    assert fd.headers == ['header2\nheader3']

    fd.info = compat_httpl

# Generated at 2022-06-12 17:04:58.398803
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import get_info_extractor
    ie = get_info_extractor('Youtube', downloader=None)
    site = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ie.extract(site)


# Generated at 2022-06-12 17:05:09.453910
# Unit test for constructor of class HttpFD
def test_HttpFD():
    urlopen = compat_urllib_request.build_opener(compat_urllib_request.HTTPCookieProcessor()).open

    fd = HttpFD(urlopen('http://www.youtube.com/'), 8192)

    # Read all data
    s = fd.read()
    assert(len(s) == fd.size)

    # Read data in chunks of 50 bytes
    s = b''
    while 1:
        r = fd.read(50)
        if r is None or len(r) == 0:
            break
        s += r
    assert(len(s) == fd.size)

    # Read data by blocks
    fd.start()
    s = fd.read_block()
    while len(s) != 0:
        s = fd.read

# Generated at 2022-06-12 17:05:14.917202
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL(object):
        def __init__(self):
            self._ydl = YoutubeDL({'test': True, 'nooverwrites': True, 'forceurl': True, 'forcetitle': True, 'simulate': True, 'quiet': True, 'noprogress': True})
            self._ydl.add_default_info_extractors()

        def to_screen(self, message, skip_eol=False):
            pass

        def trouble(self, message, tb=None):
            pass

        def report_error(self, message, tb=None):
            pass

        def report_warning(self, message):
            pass

        def to_stderr(self, message):
            pass

        def fixed_template(self, s):
            return s


# Generated at 2022-06-12 17:05:25.279923
# Unit test for constructor of class HttpFD
def test_HttpFD():
    s = HttpFD(
        {'ytdl_pd.progress_hook': None,
         'ytdl_pd.simulate': True,
         'ytdl_pd.quiet': False,
         'ytdl_pd.nooverwrites': False,
         'ytdl_pd.forcetitle': False,
         'ytdl_pd.continue_dl': True,
         'ytdl_pd.noprogress': False,
         'ytdl_pd.logger': None},
        {'url': 'foobar',
        'title': 'Some Text'},
        '-')
    assert s.get_info('filename') == '-'
    assert s.get_info('title') == 'Some Text'
    assert s.get_info('url') == 'foobar'

# Generated at 2022-06-12 17:05:37.907280
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test cases for HttpFD.__init__()

    # Test case 1: single URL, no test flag
    # Expected result:
    # 'url': 'http://localhost/',
    # 'filename': 'localhost',
    # 'test': False,
    # 'data': None
    http_fd = HttpFD(
        url='http://localhost/',
        params=None,
        output_params=None)
    assert http_fd.url == 'http://localhost/'
    assert http_fd.filename == 'localhost'
    assert not http_fd.test
    assert http_fd.data is None

    # Test case 2: list of URLs, test flag set
    # Expected result:
    # 'url': ['http://localhost/', 'http://localhost/dir/dir/'],
    # 'filename': '

# Generated at 2022-06-12 17:05:48.787231
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test_readline(read, s):
        a = readline(read)
        assert a == s, 'Read [%r] but expected [%r]' % (a, s)

    pairs = (
        (b'', b''),
        (b'\n', b'\n'),
        (b'\r\n', b'\r\n'),
        (b'foo\n', b'foo\n'),
        (b'foo\r\n', b'foo\r\n'),
        (b'foo\r\nbar\n', b'foo\r\n'),
        (b'foo\nbar\r\n', b'foo\n'),
    )
    for s, expected in pairs:
        read = compat_StringIO(s)
        yield test_readline, read, expected

# Generated at 2022-06-12 17:05:54.681820
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL({'nooverwrites': True, 'forceurl': True, 'forcetitle': True, 'quiet': True})
    ydl.add_default_info_extractors()

    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info = ydl.extract_info(url, download=False)
    filename = info['id'] + '.' + info['ext']

    # Test constructor
    hfd = HttpFD(ydl, info, filename)

    # Test get_size()
    assert hfd.get_size() is None

    # Test downlaod
    hfd.download(force_resume=True)
    assert os.path.isfile(filename)
    assert hfd.get_size() == os.path.gets

# Generated at 2022-06-12 17:06:01.749121
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    info = ydl.extract_info(url, download=False)
    dl1 = HttpFD(ydl, info).next()
    dl2 = HttpFD(ydl, info, True).next()

    # test if the file descriptors are of the same class (compare its name)
    if dl1.__class__.__name__ == dl2.__class__.__name__:
        print('success')
    else:
        print('failure')


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-12 17:06:13.590645
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import get_info_extractor
    from .utils import ExtractorError
    from .compat import unittest
    from .downloadermock import DownloaderMock
    from .compat import HTMLParser

    class TestInfoExtractors(unittest.TestCase):

        def setUp(self):
            self.server_socket = socket.socket()
            self.server_socket.bind(('localhost', 0))
            self.server_socket.listen(1)
            self.url_elements = self.server_socket.getsockname()
            self.server_url = 'http://%s:%s/' % self.url_elements
            self.single_urls = [self.server_url + 'single/']
            self.server_sockets = [self.server_socket]
            self

# Generated at 2022-06-12 17:06:15.002834
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD(None, {}, None)

