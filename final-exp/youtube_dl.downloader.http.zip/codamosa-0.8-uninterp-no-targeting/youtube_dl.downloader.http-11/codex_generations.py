

# Generated at 2022-06-22 07:03:51.796887
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class HttpFdMock(object):
        def __init__(self, ydl):
            self.ctx = {
                'data_len': 200,
                'resume_len': 0,
                'tmpfilename': 'tmpfilename.tmp',
                'filename': 'filename',
            }

        def report_retry(self, source_error, count, retries):
            pass

        def report_destination(self, filename):
            pass

        def slow_down(self, start, now, byte_counter):
            pass

        def best_block_size(self, elapsed_time, bytes_downloaded):
            pass

        def calc_speed(self, start, now, bytes_downloaded):
            pass

        def calc_eta(self, start, now, total_bytes, bytes_downloaded):
            pass



# Generated at 2022-06-22 07:04:02.724996
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:04:13.950497
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .FileDownloader import FileDownloader
    from .extractor import gen_extractors

    fd = FileDownloader({})
    fd.add_info_extractor(gen_extractors()[0])
    # fd.add_info_extractor(gen_extractors()[1])
    fd.params['youtube_include_dash_manifest'] = True

    fd.add_progress_hook(lambda d: sys.stdout.write('\r[%s] %s   ' % (dlstatus(d), d['_percent_str'])))
    fd.add_progress_hook(fd.calc_percent)
    fd.add_progress_hook(fd.status_hook)
    fd.add_progress_hook(fd.write_stats_file_hook)
    fd

# Generated at 2022-06-22 07:04:26.754279
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .compat import parse_qs, compat_urllib_error, urlparse
    from .utils import YoutubeDLHandler, parse_codecs
    from .extractor import gen_extractors

    class MyYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kargs):
            super(MyYoutubeDL, self).__init__(*args, **kargs)
            self._ies = gen_extractors()
            self.params['nooverwrites'] = True
            self.params['forcetitle'] = True
            self.params['forcethumbnail'] = True
            self.params['forceid'] = True
            self.params['forceurl'] = True
            self.params['forcetthumb'] = True
            self.params['forcedescription'] = True

# Generated at 2022-06-22 07:04:33.857022
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), bytes(sys.argv[4], 'utf-8'), {})
    fd.read(int(sys.argv[5]))
    fd.close()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:04:36.118631
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(max_speed=1048576)
    # Test setter and getter of max_speed property
    fd.max_speed = 2097152
    assert fd.max_speed == 2097152
    # Test getter of default_block_size property
    assert fd.default_block_size == 1048576

# Generated at 2022-06-22 07:04:48.269966
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(HttpFD):
        """
        TestFD class provides test methods for both HttpFD class and
        real_download() method.

        Test methods are called inside real_download() method.
        """

        def __init__(self):
            HttpFD.__init__(self)
            self.test_methods_lists = {
                'establish_connection': [
                    self.test_range_and_chunk_size, self.test_resume_and_open_mode,
                ],
                'download': [
                    self.test_filesize_limits, self.test_requests_counter,
                ],
            }

        def report_destination(self, filename):
            """
            This method does not call to_screen() from parent HttpFD class,
            so we need to overwrite it.
            """

# Generated at 2022-06-22 07:04:54.737831
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(
        downloader=DummyYDL({'nooverwrites': True, 'continuedl': True, 'quiet': True}),
        filename='test',
        info_dict=None,
        params={'noprogress': True},
        prev_hooks={'download_hook': [lambda x: 0/0]},
    ).test()

# Generated at 2022-06-22 07:05:01.384071
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Encoding an IDN to ASCII and back
    url = 'http://идн.рф/'
    url_bytes = url.encode('idna')
    url_bytes_utf8 = url_bytes.decode('utf-8')
    assert url_bytes_utf8 == 'xn--d1abbgf6aiiy.xn--p1ai'
    # http://tools.ietf.org/html/rfc3987#section-4.4
    assert urllib_parse.urlparse(url_bytes_utf8.encode('idna')).geturl() == 'http://xn--d1abbgf6aiiy.xn--p1ai/'

# Generated at 2022-06-22 07:05:10.550124
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    fd, fname = tempfile.mkstemp()

    assert isinstance(open(fname, 'rb'), HttpFD)
    assert isinstance(open(fname, 'rb', 4), HttpFD)
    assert isinstance(open(fname, 'rb', 4, 'fake_conf'), HttpFD)

    # Make sure a non-existent file raises IOError
    try:
        fd = open('nonexistent', 'rb')
    except (IOError, OSError):
        pass
    else:
        raise RuntimeError('Could open nonexistent file')

    # Clean up
    os.close(fd)
    os.remove(fname)


# Generated at 2022-06-22 07:05:55.017612
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Download file in chunks with random_number samples per chunk
    def random_number():
        return randint(0, 32767)
    random_number.__name__ = 'random_number'
    def download(url, chunk_size, x=0):
        fd = HttpFD(None, params={'ratelimit': 0})
        fd.chunk_size = chunk_size
        fd.real_download(url, fd.params)
        return fd.content_length
    # Download file with range HTTP header
    def test_range(url, offset, length):
        fd = HttpFD(None, params={'ratelimit': 0})
        fd.chunk_size = length
        fd.downloaded_bytes = offset
        fd.real_download(url, fd.params)
       

# Generated at 2022-06-22 07:06:06.125623
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import jsonrpclib
    import sys
    import tempfile
    import shutil
    import os
    import re
    import random
    import json
    import subprocess
    import time
    import unittest
    import platform
    import testserver
    import glob

    def _gen_random_string(length):
        return ''.join([random.choice('0123456789abcdefghijklmnopqrstuvwxyz') for _ in range(length)])

    def _gen_file_with_size(path, file_size):
        with open(path, 'wb') as outf:
            size = 0
            while size < file_size:
                outf.write(os.urandom(min(file_size - size, 524288)))
                size += 524288


# Generated at 2022-06-22 07:06:19.423193
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def test_func(size, max_size):
        """
        Fake _download_webpage() that returns a random string of requested
        length.
        """

        def _download_webpage(url_or_request, video_id, note, errnote, fatal):
            if size is None:
                return ''.join(random.choice(string.ascii_letters) for _ in range(max_size))
            else:
                return ''.join(random.choice(string.ascii_letters) for _ in range(size))


# Generated at 2022-06-22 07:06:30.797070
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYDL():
        params = {
            'nooverwrites': True,
            'continuedl': True,
        }
        def to_stdout(*args, **kargs):
            pass
        def to_stderr(*args, **kargs):
            pass
        def trouble(*args, **kargs):
            pass

    for url in [
                'http://www.youtube.com/watch?v=BaW_jenozKc',
                'http://http.server/file.txt',
                'rtmp://rtmp.server/app/swfurl']:
        # Check that filename is constructed correctly
        h = HttpFD(FakeYDL(), {}, url)
        assert h.title is None
        assert h.sanitized_url == url
    assert h.filename == 'index.html'

# Generated at 2022-06-22 07:06:43.793789
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # pylint: disable=unused-argument
    """
    Test HttpFD.real_download method
    """
    import sys
    import tempfile
    # import os
    import time
    import shutil
    import random
    import socket
    import itertools
    import hashlib
    # import mimetools
    import random
    from .utils import sanitize_open, sanitized_Request, write_xattr

    # LENGTH = 1000000
    LENGTH = 150000

    httpd_port = random.randrange(2**10, 2**15 - 1)
    server = TestServer()
    server.start(httpd_port)
    url = 'http://localhost:%s/%d' % (httpd_port, LENGTH)
    tmpd = tempfile.mkdtemp()
    tmpf

# Generated at 2022-06-22 07:06:53.714400
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil
    import os.path
    fd, fname = tempfile.mkstemp()
    os.fdopen(fd).write(b'First line\nSecond line\nThird line\n')
    os.fdopen(fd).close()
    import random
    class Options(object):
        default_outtmpl = '%(id)s'
        quiet = True
        verbose = False
        max_sleep = 10
        sleep_interval = 7
        max_tries = 1
        chunk_size = 64
        test = True
    class YDL(object):
        params = Options()
    class DummyProcessor(object):
        def __init__(self, ydl):
            self.ydl = ydl

# Generated at 2022-06-22 07:06:57.913306
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # The end of the file is tested

    # Set up
    ydl = FakeYDL()
    fd = HttpFD(ydl, {})
    tmpfilename = 'fake'
    url = 'http://127.0.0.1:9192/range/1024'
    info = {'url': url}

# Generated at 2022-06-22 07:07:08.309794
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        from io import BytesIO as DataIO
    except ImportError:
        from cStringIO import StringIO as DataIO
    # Check io.BytesIO compatibility
    fd = HttpFD('test', io.BytesIO(b'blabla'), {'Content-Type': 'video/webm'})
    assert(fd.read(5) == b'blabl')
    assert(fd.readline() == b'a')
    assert(fd._size() == 6)
    assert(fd._real_total_size() == 6)
    assert(fd._real_pos() == 6)
    fd.close()

    # Check cStringIO.StringIO compatibility
    fd = HttpFD('test', DataIO('blabla'), {'Content-Type': 'video/webm'})

# Generated at 2022-06-22 07:07:21.816915
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # basic testing for HttpFD
    # mostly check that it doesn't raise any exception

    def test_download(url, params, filename='dummy.tmp'):
        from .extractor import GenExtractor
        from .downloader import get_suitable_downloader

        tfd = HttpFD(get_suitable_downloader(GenExtractor()), params, filename)

        tfd.add_info_extractor(GenExtractor())
        tfd.prepare()
        tfd.download(url)

    def test_simple(url, params):
        try:
            test_download(url, params)
        except KeyboardInterrupt:
            raise
        except Exception as err:
            if not isinstance(err, compat_HTTPError) or err.code != 416:
                raise


# Generated at 2022-06-22 07:07:33.142922
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Method tests the correctness of real_download method of class HttpFD
    """
    import tempfile
    import random
    import hashlib
    import shutil

    # Save original socket.error, that might be modified by tested code
    socket_error = socket.error

    class MockYdl(object):

        def __init__(self, tmpdir, chunk_size=None, resumable=False,
                     data_length=None, server_error=None, socket_error=None,
                     sleep_time=None, block_size=32 * 1024, open_mode='wb'):
            self.tmpdir = tmpdir
            self.chunk_size = chunk_size
            self.resumable = resumable
            self.data_length = data_length
            self.server_error = server_error

# Generated at 2022-06-22 07:08:45.046500
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import bool_or_none
    from .common import encodeFilename
    from .utils import write_xattr

    class InfoDict(dict):
        pass

    class MockHttpFD(HttpFD):
        def __init__(self, nop, params, ydl, info_dict):
            self.to_screen = nop
            self.to_stderr = nop
            self.report_error = nop
            self.report_unable_to_resume = nop
            self.report_retry = nop
            self.report_destination = nop
            self.report_resuming_byte = nop
            self.report_file_already_downloaded = nop
            self.slow_down = nop
            self.best_block_size = nop
            self.calc

# Generated at 2022-06-22 07:08:56.130088
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Tests real_download method of HttpFD class."""

    # Creating test file
    def make_files(file_size):
        """Creates files of different size for testing."""
        for file_size in [0] + list(set(file_size)):
            fname = 'test_file_%s' % file_size
            with open(fname, 'wb') as f:
                f.truncate(file_size)

    def make_server():
        """Starts server for test."""
        TestHandler.protocol_version = 'HTTP/1.0'
        server = http_server.HTTPServer(('localhost', 0), TestHandler)
        server_thread = threading.Thread(target=server.handle_request)
        server_thread.daemon = True
        server_thread.start()

# Generated at 2022-06-22 07:09:04.313204
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYtdlUrlopen:
        def __init__(self, headers, data):
            self.data = data
            self.headers = headers
        def read(self, len):
            return self.data.read(len)
        def info(self):
            return compat_urllib_request.addinfourl(
                StringIO(compat_urllib_parse.urlencode(self.headers)), 'Header', 'http://localhost/')

    fd = HttpFD(FakeYoutubeDL(), dict(params=dict(noprogress=True)))

# Generated at 2022-06-22 07:09:11.803334
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test if HttpFD raises an exception if the URL refers to a non-existing file
    url = 'http://localhost:8080/a-file-that-does-not-exist-%s' % random.random()
    httpfd = HttpFD(urlopen(url))
    try:
        httpfd.read(1)
        assert False, 'expected an exception'
    except (IOError, compat_urllib_error.URLError) as e:
        assert isinstance(e, compat_HTTPError)
        assert e.getcode() == 404
    assert httpfd.read(10) == ''
    httpfd.close()
    assert httpfd.closed
    assert httpfd.tell() == 0
    assert httpfd.seekable()
    assert not httpfd.writable()
    assert not httpfd.isat

# Generated at 2022-06-22 07:09:23.815893
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import common
    from .downloader import FileDownloader

    file_size = 100

    # When using testserver with self-signed certificate we should ignore
    # SSL related errors (-k/--no-check-certificate).
    #
    # - SSL: CERTIFICATE_VERIFY_FAILED
    # Python 2.6 through 2.6.8 (included) does not support SNI
    # (http://bugs.python.org/issue10272).
    # Bypass SSL error with python < 2.7
    #
    # - ssl.CertificateError: hostname 'testserver' doesn't match u'testserver'
    #
    # The server's hostname is used to generate the certificate.  Some
    # versions of Python (2.6.9+) use the hostname of the local PC to


# Generated at 2022-06-22 07:09:35.872545
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create a list of dictionaries
    list_params = [{'noprogress': True, 'quiet': True}, {'noprogress': False, 'quiet': True}, {'noprogress': True, 'quiet': False}, {'noprogress': False, 'quiet': False}]
    # Create a list of lists
    list_responses = [['a', 'b', 'c'], ['d', 'e', 'f'], ['g', 'h', 'i'], ['j', 'k', 'l']]
    # Test constructor for each element of list_params and list_responses
    i = 0
    for params in list_params:
        for response in list_responses:
            i += 1
            hf = HttpFD(params, response, 'to_stderr', 'to_screen')

# Generated at 2022-06-22 07:09:47.948019
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for issue #1033
    class MyHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            def my_hook(*args, **kwargs):
                self._hook_progress = lambda *args, **kwargs: [args, kwargs]
            kwargs['progress_hooks'] = [my_hook]
            HttpFD.__init__(self, *args, **kwargs)

    test = MyHttpFD('http://www.example.com/', {'nooverwrites': True, 'continuedl': True}, ratelimit=None, retries=None, retry_on_http_error=None)
    assert test._hook_progress == [], '_hook_progress is not empty (1)'

    test.report('http_header_received')
    assert test

# Generated at 2022-06-22 07:10:00.067577
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    #Test on a small file
    RETRYDOWNLOAD = compat_urllib_error.URLError('TEST RETRYDOWNLOAD')
    class TestException(Exception):
        def __init__(self, msg='TEST EXCEPTION'):
            self.msg = msg
        def __str__(self):
            return self.msg
    class TestData(object):
        def __init__(self, min_read=8, max_read=8, data_len=10, real_len=10, block_count=2):
            self._min_read = min_read
            self._max_read = max_read
            self._data_len = data_len
            self._real_len = real_len
            self._block_count = block_count
            self._block = 0
            self._data = ''


# Generated at 2022-06-22 07:10:12.359155
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_class = HttpFD()
    test_class.best_block_size = lambda time_, down_, up_: 0
    test_class.params = {'noresizebuffer': True}
    test_class.report_destination = lambda filename: None
    test_class.report_error = lambda desc: None
    test_class.report_retry = lambda desc, count, retries: None
    test_class.report_unable_to_resume = lambda: None
    test_class.to_screen = lambda desc: None
    test_class.to_stderr = lambda desc: None
    test_class.undo_temp_name = lambda filename: filename
    test_class.try_rename = lambda filename, filename2: None

# Generated at 2022-06-22 07:10:23.709711
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import mimetools

    range_tot = 5*1024*1024
    range_start = 0
    range_end = range_tot - 1
    url = 'http://127.0.0.1:%s/%s' % (TEST_HTTP_PORT, 'test_' + str(range_tot))

    # Test the case when "Accept-Ranges: bytes" is present in the response headers
    # and the requested range is valid
    #stream = HttpFD(range_start, range_end, {'url': url})
    #assert stream.headers['status'] == 206, 'status code should be 206'
    #assert stream.headers['content-range'] == 'bytes %s-%s/%s' % (range_start, range_end, range_tot), 'Content-Range header