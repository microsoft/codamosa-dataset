

# Generated at 2022-06-22 07:03:42.038172
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import testutils
    fd = HttpFD(
        testutils.params,
        testutils.target,
        testutils.info_dict)
    fd.params['test'] = True
    fd.real_download()
# Class CurlFD

# Generated at 2022-06-22 07:03:55.335188
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    'Test method real_download of class HttpFD'
    from .test import MockYDL
    def _check_file(fname):
        if not os.path.exists(fname):
            print('File {} does not exist'.format(fname))
            return False
        if os.path.getsize(fname) != HttpFD._TEST_FILE_SIZE:
            print('Error: expected file %s to be %s bytes, got %s bytes' % (fname,
                HttpFD._TEST_FILE_SIZE, os.path.getsize(fname)))
            return False
            os.unlink(fname)
        return True

    ydl = MockYDL()
    test_server = HttpServerThread(ydl)
    test_server.start()


# Generated at 2022-06-22 07:03:57.724847
# Unit test for constructor of class HttpFD
def test_HttpFD():
    FD1 = HttpFD('test')
    assert FD1.params['noprogress']
    FD2 = HttpFD('test', {'noprogress': False})
    assert not FD2.params['noprogress']

# Generated at 2022-06-22 07:04:07.308889
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.common import InfoExtractor
    from .utils import calc_value_bytes

    # Test constructor with test data

# Generated at 2022-06-22 07:04:20.152954
# Unit test for constructor of class HttpFD

# Generated at 2022-06-22 07:04:28.805876
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """ Test the content of a downloaded file.
    Use a small version of the big buck bunny video available at
    http://download.blender.org/peach/bigbuckbunny_movies
    """
    # Test file is only available via HTTP(S) and in a small size
    url = 'https://upload.wikimedia.org/wikipedia/commons/transcoded/8/83/Big_Buck_Bunny_small.ogv/Big_Buck_Bunny_small.ogv.480p.webm'
    # This test is only executed if ffmpeg is available
    try:
        _ = get_exe_version('ffmpeg')
    except (IOError, OSError):
        return True
    # Create a YoutubeDL object with some parameters

# Generated at 2022-06-22 07:04:42.778674
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Configuration
    max_filesize = 50 * 1024 * 1024  # 50 MiB
    test_filesize = int(max_filesize / 2)  # 25 MiB
    check_filesize = test_filesize - 1000  # 24999 KiB
    block_size = 1024  # 1 KiB
    retries = 2

    # Create a large file with random bytes using /dev/urandom.
    # On Linux try to use the getrandom() syscall if available,
    # as it will give us a non-blocking syscall.
    # On other systems, use /dev/urandom.

# Generated at 2022-06-22 07:04:46.854167
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test if instantiating of HttpFD works without errors
    fd = HttpFD('http://www.google.com/', {})
    del fd

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:04:57.561389
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class NullHttpFD(HttpFD):
        def _opener(self, *args, **kwargs):
            return _NullOpener(*args, **kwargs)
        def report_error(self, *args, **kwargs):
            raise Exception(args[0])
        def report_retry(self, *args, **kwargs):
            raise Exception(args[0])
        def report_destination(self, *args, **kwargs):
            pass
        def report_resuming_byte(self, *args, **kwargs):
            pass
        def report_unable_to_resume(self, *args, **kwargs):
            pass
        def report_file_already_downloaded(self, *args, **kwargs):
            pass

    hfd = NullHttpFD()

# Generated at 2022-06-22 07:05:09.768655
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    from .extractor.common import InfoExtractor
    
    class DummyIE(InfoExtractor):
        IE_NAME = 'Dummy'
    ie = DummyIE()
    ie.params = {}
    out = sys.stdout
    filename = '-'
    
    h = HttpFD(out, filename, ie)
    assert h.fd is out
    assert h.cache == False
    assert h.continuedl == True
    assert h.noresizebuffer == True
    assert h.ratelimit == None
    assert h.retries == 10
    assert h.test == False
    assert h.nooverwrites == False
    assert h.writedescription == False
    assert h.writeinfojson == False
    assert h.writethumbnail == False

# Generated at 2022-06-22 07:05:52.027004
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # TODO: Maybe I should use something like unittest.TestCase
    class MockYDL:
        def __init__(self):
            self.to_screen = lambda s: None
            self.report_error = lambda msg: None
            self.report_resuming_byte = lambda byte: None
            self.report_retry = lambda err: None
            self.report_destination = lambda filename: None
            self.report_file_already_downloaded = lambda filename: None
            self.urlopen = lambda req: None

        def __call__(self, *args, **kwargs):
            return MockYDL()

    class MockData:
        def __init__(self, info_dict, block_count, block_size=8096):
            self.block_count = block_count

# Generated at 2022-06-22 07:06:03.849428
# Unit test for constructor of class HttpFD
def test_HttpFD():
    web_page = u'''
    <html>
    <head>
    <title>Unit test for youtube-dl</title>
    </head>
    <body>
    <div id="content">
    <p><b>Download <a href="/test.flv">this</a> video file.</b></p>
    </div>
    </body>
    </html>'''

    def dummy_urlopen(req):
        class DummyResponse:
            def info(self):
                return {'content-type': 'text/html; charset=UTF-8'}
            def geturl(self):
                return req.get_full_url()
        return DummyResponse()

    ie = HttpFD(0)
    ie.http_headers = None
    ie.ydl = MockYDL()
   

# Generated at 2022-06-22 07:06:04.868984
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return std_headers


# Generated at 2022-06-22 07:06:07.261614
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import test_httpfd
    test_httpfd.main()


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:06:19.541514
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DummyHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            super(DummyHttpFD, self).__init__(*args, **kwargs)
            self._TEST_FILE_SIZE = 100000

    # test write error
    with make_temp_file('w') as (outf, tmpfilename):
        outf.close()
        dest = DummyHttpFD(
            {'url': 'http://localhost/dummy-video.mp4'},
            {'outtmpl': tmpfilename, 'ratelimit': None},
            'dummy-video')
        dest.real_download(None, None)
        dest.to_screen.assert_any_call('\n')

# Generated at 2022-06-22 07:06:30.886393
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors
    # start unit test for constructor of class HttpFD
    url = 'https://github.com/rg3/youtube-dl/raw/master/youtube_dl/YoutubeDL.py'
    filename = 'youtube_dl/YoutubeDL.py'
    filesize = 12288
    # open extracted from https://github.com/rg3/youtube-dl/raw/master/youtube_dl/YoutubeDL.py
    # and write it to file.
    # length of data written must be equal to file size or an error is thrown
    class MockYDLogger(object):
        def debug(x):
            pass
        def warning(x):
            pass
        def error(x):
            pass

# Generated at 2022-06-22 07:06:43.907204
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def format_bytes(b):
        if b is None:
            return 'Unknown'
        if b > 1048576:
            return '%0.2f MB' % (b / 1048576.0)
        elif b > 1024:
            return '%0.1f KB' % (b / 1024.0)
        else:
            return '%d bytes' % b


# Generated at 2022-06-22 07:06:53.714047
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def _test_read(fd, size):
        return compat_str(b'spam\n' * size)
    fd = HttpFD(_test_read, {'content-length': str(sys.maxsize)}, 'http://foo')
    assert fd.size == sys.maxsize
    assert fd.tell() == 0
    assert fd.read(4) == b'spam'
    assert fd.tell() == 4
    assert fd.read(2) == b'\nsp'
    assert fd.tell() == 6
    assert fd.read() == b'am\nspam\n' * (sys.maxsize // 7)
    assert fd.tell() == sys.maxsize
    assert fd.read() == b''
    assert fd.tell() == sys.max

# Generated at 2022-06-22 07:06:57.009489
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd1 = HttpFD('http://localhost/')
    fd2 = HttpFD('http://localhost/', params={'noprogress': 'True'})

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:07:01.675427
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """ Test HttpFD.__init__() """
    hd = HttpFD(YoutubeDL(), None)
    # If we get to this point without raising an exception, the test has passed



# Generated at 2022-06-22 07:08:12.732251
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    from collections import OrderedDict
    from youtube_dl.utils import write_string
    from youtube_dl.compat import compat_str
    from .extractor.common import InfoExtractor
    from .downloader import FileDownloader
    from .postprocessor import FFmpegMergerPP
    from .utils import sanitize_open
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    test_content = b'foo'
    test_content_length = len(test_content)

    # Test _preload_content
    fd = HttpFD(BytesIO(test_content), None, None, None, None, preload_content=True, test=True)
    assert fd.len == test_content_length

# Generated at 2022-06-22 07:08:24.595097
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if not isinstance(HttpFD().real_download, types.MethodType):
        # Running on a compiled version of youtube-dl,
        # don't test HttpFD.real_download()
        return

    ydl = YoutubeDL()
    ydl.params['noprogress'] = True

    def get_urlopen_mock(content=b'abc', headers=None, side_effect=None):
        def urlopen_mock(request):
            class MockResponse:
                def info(self):
                    return headers or {'Content-Length': '3'}

                def read(self, *args):
                    return content

            if side_effect is not None:
                side_effect()
            return MockResponse()

        return urlopen_mock


# Generated at 2022-06-22 07:08:29.074553
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL({})
    fd = HttpFD(ydl, None, {}, {})
    assert fd.params['ratelimit'] == None
    assert fd.params['noresizebuffer'] == False
    assert fd.ydl is ydl
    assert fd.filename is None
    assert fd.prev_video_url == ''



# Generated at 2022-06-22 07:08:34.546259
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            self.test_data_len = None
            HttpFD.__init__(self, *args, **kwargs)

        def data_len(self, meta):
            return self.test_data_len

    # Try to download a file with known size, hope it's small enough
    fd = TestHttpFD(test_urls.VIDEO_INFO, params={
        'test': True,
        'noprogress': True,
        'quiet': True,
    })
    fd.test_data_len = int(fd.ydl.urlopen(fd.url).info()['Content-Length'])

# Generated at 2022-06-22 07:08:47.394595
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Check HTTP 200
    urlh = compat_urllib_request.urlopen('http://www.youtube.com/')
    fd = HttpFD(urlh, None)
    assert fd.name == 'http://www.youtube.com/'
    assert fd.geturl() == 'http://www.youtube.com/'
    assert fd.headers['Content-Type'] == 'text/html; charset=utf-8'
    assert fd.headers['Content-Length'] == '0'
    assert fd.read() == b''
    assert fd.close() is None

    with pytest.raises(ValueError):
        HttpFD(object(), None, 'http://www.youtube.com/')

# Generated at 2022-06-22 07:08:57.827481
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(HttpFD):
        def __init__(self, tmpfilename, info_dict):
            self.info_dict = info_dict
            self.params = {}
            super(TestFD, self).__init__(tmpfilename, {})

    class DummyYDL(object):
        def __init__(self):
            self.params = {}

        def report_error(self, msg, tb=None):
            pass

        def report_warning(self, msg):
            pass

        def to_stderr(self, msg):
            sys.stderr.write(msg)

        def to_screen(self, msg):
            sys.stdout.write(msg)


# Generated at 2022-06-22 07:09:02.775714
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for incorrect URL
    try:
        HttpFD('http://', {'noprogress': True})
    except IOError as err:
        assert 'No host given' in str(err)
    else:
        raise AssertionError('IOError with "No host given" error message expected')

    # Test correct URL
    HttpFD('http://127.0.0.1', {'noprogress': True})



# Generated at 2022-06-22 07:09:10.481323
# Unit test for constructor of class HttpFD
def test_HttpFD():

    class TestInfoExtractor(InfoExtractor):
        IE_NAME = 'unittest'
        _TEST = {
            'url': 'http://unittest/',
        }

    ie = TestInfoExtractor()

    # Test 1: Test with file URL
    fd = HttpFD(ie, ie.url_result('http://unittest/file.bin'))
    assert fd.real_download is True
    assert_equal(fd.filename, 'file.bin')
    assert_equal(fd._total_size, None)
    assert_equal(fd.url, 'http://unittest/file.bin')
    assert fd.get_filesize() is None

    # Test 2: Test with non-file URL
    # (mimic a YouTube video with age restriction)
    fd = Http

# Generated at 2022-06-22 07:09:16.101170
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from sys import stderr
    h = HttpFD('http://google.com', {'progress_hooks': [lambda x: stderr.write('\r{0}\r'.format(x))]})
    for line in h.readlines():
        print(line)
    h.close()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:09:27.820299
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import io
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    class TestHttpFD(HttpFD):
        def __init__(self):
            self.bytes_to_read = 1024 * 1024 * 5
    hfd = TestHttpFD()

# Generated at 2022-06-22 07:11:36.945016
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    rd = HttpFD().real_download
    def run(data_len, block_size, content_range, resume_len, open_mode=None, urlopen_side_effect=None, urlopen_return_value=None):
        # Mock urlopen method
        def urlopen(request):
            if urlopen_side_effect is not None:
                urlopen_side_effect(request)
            return urlopen_return_value

        # Mock request
        class Request(object):
            def __init__(self, headers):
                self._headers = headers

            def add_header(self, name, value):
                self._headers[name] = value

        # Mock info object
        class Info(object):
            def __init__(self):
                self._headers = {}


# Generated at 2022-06-22 07:11:39.539052
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(
        'http://example.com/foo',
        {
            'http_chunk_size': 10,
            'test': True,
        }
    )
    return fd

# Generated at 2022-06-22 07:11:45.845495
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from collections import namedtuple

    class DummyYDL(object):
        params = {}

    def retry_dummy(self, *a, **k):
        pass

    ydl = DummyYDL()
    ydl.retry = _RetryWrapper(retry_dummy, ydl)

    info = namedtuple('Info', [
        'url', 'filename', 'http_headers', 'http_chunk_size',
        'http_total_content_length', 'http_range', 'report_warning'
    ])

    url = 'http://example.com/'

    headers = {'User-Agent': 'Foo', 'Content-Type': 'video/mp4'}

# Generated at 2022-06-22 07:11:53.163653
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test basic functionality
    inst = HttpFD('foo').read(5)
    assert inst == 'foo'

    # Test chunked mode
    inst = HttpFD('foo').read(5)
    assert inst == 'foo'

    # Test resuming
    inst = HttpFD(
        'foo', resume_len=1).read(5)
    assert inst == 'oo'

    # Test resuming with size specified
    inst = HttpFD(
        'foo', data_len=3, resume_len=1).read(5)
    assert inst == 'oo'

    # Test resuming with size specified
    inst = HttpFD(
        'foo', data_len=3, resume_len=1).read(5)
    assert inst == 'oo'

    # Test resuming with size specified
    inst = H

# Generated at 2022-06-22 07:12:04.161797
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from tempfile import mkdtemp
    from shutil import rmtree
    import sys
    import atexit
    import io
    import os
    import ssl

    # Create a temporary directory
    tmpdir = mkdtemp()
    tmpfile = os.path.join(tmpdir, 'youtubedl-testfile')
    tmpfile_sha1 = '6d0a293f5b5f5c5a5a81a9df7d25b642ca0f7a1e'
    tmpfile_sha256 = '3b2bbadb9e9a24dcfb3d3e2f3a66b8d7ffb2884046068eb6150f1bf9b8c4b4fd'

# Generated at 2022-06-22 07:12:10.606155
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile, shutil
    from YoutubeDL import YoutubeDL
    ydl = YoutubeDL()

    # testing HttpFD method real_download on a file which size is
    # greater than _TEST_FILE_SIZE
    ydl.params['test'] = True
    test_url = 'http://localhost:8080/test/test.mp4'
    test_filename = encodeFilename(
        tempfile.mkstemp()[1],
        ydl.params['outtmpl']
    )
    # HttpFD uses True for test flag, so override
    # original value True with new one True
    ydl.params['test'] = True
    with open(test_filename, 'wb') as f:
        f.write(b'\x00' * (ydl._TEST_FILE_SIZE + 1))
    test_

# Generated at 2022-06-22 07:12:21.391265
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(
        'http://test.test/test.test',
        {'test_option': 'test value'},
        lambda d: None,
        lambda d: None,
        ytdl=None,
        params={})
    assert fd.test_option == 'test value'
    assert not hasattr(fd, 'test_option2')
    assert not hasattr(fd, 'nofile')
    assert not hasattr(fd, 'http')
    assert not hasattr(fd, 'bytes')
    assert not hasattr(fd, 'fileno')
    assert not hasattr(fd, 'tell')
    assert hasattr(fd, 'close')
    assert hasattr(fd, 'read')
    assert hasattr(fd, 'seek')
    assert hasattr(fd, 'urlopen')


# Generated at 2022-06-22 07:12:33.154560
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # The purpose of this test is to ensure method real_download of
    # class HttpFD downloads the whole file correctly and handles
    # server errors correctly. The test fails if the download takes a
    # long time (more than 30s).
    import tempfile
    import threading
    import BaseHTTPServer
    import SocketServer
    import ssl
    import time
    import atexit
    import os

    # The test server
    class ErrorTestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
        def do_HEAD(self):
            self.send_response(200)
            self.send_header('Content-Length', self._content_length)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Connection', 'close')
            self.end_headers()


# Generated at 2022-06-22 07:12:41.215261
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test for method real_download of class HttpFD"""
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl._setup_opener()
    url = "http://www.youtube.com/watch?v=BaW_jenozKc"
    filename = "cat.flv"

# Generated at 2022-06-22 07:12:52.711605
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    dl_path = '%s/%s' % (sys.argv[1], sys.argv[2])