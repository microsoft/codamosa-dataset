

# Generated at 2022-06-22 07:03:55.813792
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Check if all data can be read via read()
    for test_size in [ 300, 512, 1000, 1024, 2000, 2048, 2049, 2051, 3000, 4096, 4097, 5000, 5*1024*1024, 30*1024*1024 ]:
        def myread(n):
            return myfd.read(n)
        test_data = os.urandom(test_size)
        myfd = HttpFD(myread, len(test_data))
        assert myfd.size == test_size
        assert myfd.read() == test_data
        assert myfd.read() == b''

    # Check if all data can be read by iterating over lines

# Generated at 2022-06-22 07:04:04.082497
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import test_download
    dl = test_download.FakeYDL()
    url = 'http://127.0.0.1:9000/test/test.mp4'
    dl.params['test'] = True
    info = {
        'url': url,
        'id': 'test',
        'duration': 100,
        'stitle': 'foobar',
        'ext': 'mp4',
        'format': 'mp4',
        'title': 'test',
    }
    dl.process_info(info)
    http_fd = HttpFD(dl, url, info)
    http_fd.test(dl.tmpfilename)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:04:16.745815
# Unit test for constructor of class HttpFD
def test_HttpFD():
    success = True
    def _test_HttpFD(url, filename, data_len=None, test_length=False):
        global success
        try:
            fd = HttpFD(
                url, filename, {
                    'noprogress': True,
                    'test': True,
                    'quiet': True,
                    'simulate': True,
                    'retries': 1,
                })
            if fd is None:
                print('ERROR: fd is None')
                success = False
                return
            assert isinstance(fd, HttpFD)
        except (OSError, IOError) as err:
            print('ERROR: %s' % str(err))
            success = False
        else:
            print('SUCCESS: %s' % url)

# Generated at 2022-06-22 07:04:29.083912
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeHtmlParser(object):
        def __init__(self):
            self.method = 'GET'
            self.video_id = '_hs3nmfqFLQ'

# Generated at 2022-06-22 07:04:43.042104
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """ This function tests the constructor of class HttpFD. """
    info = {
        'url': 'http://www.example.com/video.flv',
        'player_url': None,
        'downloader': 'wget',
        'downloader_options': ['--test-option', 'example value'],
        'params': {},
        'http_headers': {},
    }
    fd = HttpFD(info)
    assert fd.handle is None
    assert fd.pid is None
    assert fd.url == 'http://www.example.com/video.flv'
    assert fd.player_url is None
    assert fd.info.get('downloader') == 'wget'

# Generated at 2022-06-22 07:04:55.041777
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYdl(object):
        def __init__(self):
            self.params = {
                'usenetrc': False,
                'username': None,
                'password': None,
                'noprogress': True,
                'quiet': True,
                'retries': 10,
                'continuedl': False,
                'noresizebuffer': True,
                'test': True,
                'prefer_insecure': False
            }
            self.to_screen = lambda s: sys.stdout.write(s)
            self.to_stderr = lambda s: sys.stderr.write(s)
            self.to_stderr_fp = sys.stderr
            self.urlopen = compat_urllib_request.urlopen
            self.max_temp_file_

# Generated at 2022-06-22 07:04:59.942442
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    fd1 = HttpFD(None, BytesIO(b'abc'))
    fd2 = HttpFD(None, BytesIO(b'abc'), 4)
    assert fd1.read(3) == b'abc'
    assert fd1.read(3) == b''
    assert fd2.read(3) == b'abc'
    assert fd2.read(3) == b''

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:05:10.901443
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors
    def test(ydl):
        ie = gen_extractors(ydl, "http://example.com/xyz")[0]
        assert ie.IE_NAME == 'generic'
        info = ydl.extract_info("http://example.com/xyz")
        assert info is None
    with YoutubeDL(dict(noplaylist=True, forceurl=True)) as ydl:
        test(ydl)
        ydl.params['test'] = True
        test(ydl)
        ydl.params['test_print_debug_header'] = True
        test(ydl)
        # test(ydl)  # uncomment to get data printed

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:05:20.950519
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import encode_data_url

    h = YoutubeDLHandler()
    h._downloader = DummyYDL()
    h.params = {
        'noprogress': True,
        'retries': 0,
        'test': True,
        'continuedl': True,
        'noresizebuffer': True,
    }
    h._hook_progress = lambda *args: None
    h.to_screen = lambda *args: None
    h.to_stderr = lambda *args: None
    h.report_error = lambda *args: None

    # Test HTTP error
    ctx = {
        'filename': '-1',
        'tmpfilename': '-1',
        'data': compat_StringIO(),
    }

# Generated at 2022-06-22 07:05:32.021508
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import threading
    import Queue
    import socket
    import tempfile
    import BaseHTTPServer
    HTTP_PORT = 9001

    class TestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
        def do_GET(self):
            filename = self.path[1:]
            self.send_response(200)

# Generated at 2022-06-22 07:06:12.914913
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    import copy

    # Test case with one fragment
    test_fragment = {
        'url': 'http://www.test.com/test.flv',
        'min_filesize': 0,
        'max_filesize': None,
        'fragment-index': 0,
        'fragments': [{
            'url': 'http://www.test.com/test.flv',
            'min_filesize': 0,
            'max_filesize': None,
        }],
    }

    # Test case with two fragments
    test_fragments = copy.deepcopy(test_fragment)
    test_fragments['url'] = 'http://www.test.com/test.flv.001'

# Generated at 2022-06-22 07:06:23.159930
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(
        'http://shink.in/content/10MB.zip',
        {
            'http_chunk_size': 1024 * 128,
            'noprogress': True,
        })
    return fd.read(10)

if __name__ == '__main__':
    print('testing HttpFD constructor')
    import sys, os.path
    if len(sys.argv) < 2:
        print('Usage: %s filename' % os.path.basename(sys.argv[0]))
        sys.exit(1)
    print(test_HttpFD())

# Generated at 2022-06-22 07:06:32.341276
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import encodeFilename
    from .compat import sanitize_open

    class DummyYDL(object):
        def __init__(self):
            self.params = {
                'nooverwrites': False,
                'continuedl': False,
                'noprogress': False,
                'retries': 10,
                'buffersize': '2M',
            }

        def trouble(self, msg, tb=None):
            if tb is not None:
                raise Exception(msg).with_traceback(tb)
            raise Exception(msg)

        def to_screen(self, msg):
            print(msg)

        def report_error(self, msg, tb=None):
            self.trouble(msg, tb)


# Generated at 2022-06-22 07:06:45.287029
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url = 'http://127.0.0.1/'
    dest = '-'
    tmpfilename = None
    fd = HttpFD(url, dest, params={})
    assert fd.url == url
    assert fd.filename == dest
    assert fd.dest == dest
    assert fd.tmpfilename == tmpfilename
    assert fd.params == {}

    url = 'http://127.0.0.1/abc'
    dest = '-'
    tmpfilename = None
    fd = HttpFD(url, dest, params={'nopart': True})
    assert fd.url == url
    assert fd.filename == dest
    assert fd.dest == dest
    assert fd.tmpfilename == tmpfilename
    assert fd.params == {'nopart': True}


# Generated at 2022-06-22 07:06:54.303559
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:07:03.148838
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test download of a small file and a file that is larger than _TEST_FILE_SIZE
    test_urls = [
        'http://example.com/download',
        'http://example.com/largefile',
    ]
    # Test scenarios when retries, byte ranges and piece size are different

# Generated at 2022-06-22 07:07:16.010673
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            self.urlopen_calls = []
            self.report_retry_calls = []
            self.report_error_calls = []
            self.report_destination_calls = []
            self.report_unable_to_resume_calls = []
            self.report_file_already_downloaded_calls = []
            self.undo_temp_name_calls = []
            self.try_rename_calls = []
            self.to_screen_calls = []
            self.to_stderr_calls = []
            self.calc_eta_calls = []
            self.try_utime_calls = []
            self._hook_progress_calls

# Generated at 2022-06-22 07:07:28.250538
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import random
    import time
    import re
    import socket
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from http.server import SimpleHTTPRequestHandler
    from http.server import SimpleHTTPRequestHandler as httpserver_SimpleHTTPRequestHandler
    from socketserver import ThreadingMixIn

    # Set up a directory for the test
    rootdir = 'HttpFDTestPages'
    if not os.path.isdir(rootdir):
        os.mkdir(rootdir)

    # The default size of the file to be send
    SIZE = 69768

    # -------------
    # test handlers
    # -------------

    # A handler that serves a file of size SIZE

# Generated at 2022-06-22 07:07:39.231245
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Simple test for HttpFD.real_download
    """

    # Test basic download
    ctx = HttpFDRepresentation({}, {'nooverwrites': True}, '-')

    # Test download with chunksize
    ctx = HttpFDRepresentation({}, {'nooverwrites': True, 'continuedl': True, 'noprogress': True}, '-')
    ctx.chunk_size = 0x10000
    ctx.data_len = 0x10000 * 2 + 0x1000

    # Test download with min_filesize
    ctx = HttpFDRepresentation({'min_filesize': 0x100000}, {'nooverwrites': True, 'continuedl': True, 'noprogress': True}, '-')

# Generated at 2022-06-22 07:07:52.166997
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import gzip
    import shutil
    import sys
    import tempfile
    import threading
    import time

    from .utils import sanitize_open

    if sys.version_info < (3, 0):
        from .compat import compat_http_server  # noqa
    else:
        import http.server as compat_http_server

    class MyHandler(compat_http_server.BaseHTTPRequestHandler):

        def do_GET(self):
            # response status 200
            self.protocol_version = 'HTTP/1.1' # HTTP-1.1
            self.send_response(200)
            self.send_header('Test-Header', 'test-value')
            self.send_header('Content-Type', 'text/html')
            self.send_header('Content-Length', '5')


# Generated at 2022-06-22 07:08:58.234533
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Test real_download method of class HttpFD.
    """
    http_test_server = TestServer()
    http_test_server.start()
    if not http_test_server.is_alive():
        return False
    # youtube-dl should download a test file, one chunk at a time
    from .compat import compat_urllib_error
    class MockDownloader(object):
        def __init__(self):
            self.to_screen_values = []
            self.to_stderr_values = []
            self.to_screen_locked = False
            self.params = {
                'ratelimit': None,
                'retries': 1,
                'buffersize': 16384,
                'noresizebuffer': False,
                'test': True,
            }

# Generated at 2022-06-22 07:09:05.659874
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .filedownloader import FileDownloader
    from .utils import encodeFilename

    class InfoExtractorMockup(InfoExtractor):
        def __init__(self, downloader):
            self._downloader = downloader

# Generated at 2022-06-22 07:09:15.121022
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    if sys.version_info >= (3, 0):
        return

    def fake_urlopen(req, data=None, timeout=None):
        def info():
            return {
                'Content-length': length,
                'Content-Range': 'bytes %d-%d/%d' % (range_start, range_end, length),
            }
        def read(n):
            return b'\x00' * min(n, length - pos)
        length = 1000
        range_start = req.headers.get('Range')
        range_start = int_or_none(range_start) if range_start else None
        range_end = range_start + length - 1 if range_start else length - 1
        pos = 0

# Generated at 2022-06-22 07:09:24.818746
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .FileDownloader import FileDownloader
    from .utils import prepend_extension
    from .extractor import get_info_extractor
    from .compat import compat_str

    # Create a test object

# Generated at 2022-06-22 07:09:30.405922
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd = HttpFD('http://www.google.com/', {'noprogress': True, 'quiet': True})
    assert httpfd.handle()
    assert httpfd.filename is not None
    assert httpfd.len == os.path.getsize(httpfd.filename)

# Generated at 2022-06-22 07:09:42.240507
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading
    import time
    class MockYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'retries': 1,
                'test': True
            }
            self.server_params = {
                'total_size': HttpFD._TEST_FILE_SIZE + 1,
                'chunk_size': HttpFD._TEST_FILE_SIZE,
                'duration': 2.0,
            }
            self.server_events = []
            self.port = None
        def report_error(self, message):
            self.server_events.append(('error', message))
            sys.stderr.write(message + '\n')

# Generated at 2022-06-22 07:09:53.666570
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import youtube_dl.utils
    # Make sure we have a local copy of this file
    infile = os.path.join(sys.path[0], __name__) + '.py'
    # Download this file in chunks of 2^0 = 1 bytes
    test = HttpFD(None, {'nooverwrites': True, 'continuedl': True, 'noprogress': True, 'quiet': True,
                         'test': True, 'retries': 0, 'buffersize': 0})
    test.report_destination = lambda filename: None
    test.to_stdout = lambda line: sys.stdout.write(line)
    test.to_stderr = lambda line: sys.stderr.write(line)

# Generated at 2022-06-22 07:10:02.054728
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Just a sanity test for HttpFD constructor."""
    # url = 'http://localhost/index.html'
    # Test with real HTTP server
    # url = 'http://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest'
    # Test with real HTTPS server
    url = 'https://github.com/rg3/youtube-dl/raw/master/README.md'
    fd = HttpFD(url, {})
    fd.close()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:10:14.059960
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import filecmp
    import urllib.error
    import urllib.request
    import socket
    import ssl

    try:
        from unittest import mock
    except ImportError:
        import mock

    from .common import (
        FakeYDL, FakeHttpServer, FakeHttpsServer,
        FakeHeadRequestHandler, FakeGetRequestHandler,
        Cookie,
    )

    from .downloader_http import HttpFD
    from .downloader_http import SanitizedHttpsHandler

    from .utils import (
        encodeFilename,
        compat_urllib_parse,
        compat_urllib_request,
    )


# Generated at 2022-06-22 07:10:25.190684
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for correct handling of HTTP error codes; see
    # https://github.com/rg3/youtube-dl/issues/738
    # Subprocess call to HTTP server will be stderr output as:
    # <url> <HTTP error code>
    m = __import__('threading')
    import time
    import urllib2
    import cgi
    import BaseHTTPServer
    TEST_PORT = 8019

    class TestServer(BaseHTTPServer.HTTPServer):
        timeout = 10

    class TestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write('ok')

        def do_POST(self):
            print >> sys.stderr, self.path,