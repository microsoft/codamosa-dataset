

# Generated at 2022-06-22 07:03:55.659402
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    from .compat import compat_urlparse

    # Test if HttpFD creates a valid temporary file on disk
    def create_temp_file():
        temp_file = HttpFD(ydl=None, url='http://127.0.0.1:8080/', params={})
        assert os.path.isfile(temp_file.name)
        temp_file.close()
        os.remove(temp_file.name)

    # Test if HttpFD deletes the temporary file on disk
    def delete_temp_file():
        temp_file = HttpFD(ydl=None, url='http://127.0.0.1:8080/', params={})
        temp_file.close()
        assert not os.path.isfile(temp_file.name)

    # Test if Http

# Generated at 2022-06-22 07:04:04.472626
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    pass
# Test cases:
# 1. file_size > 10 MB
# 2. file_size < 10 MB
# 3. file_size == 0
# 4. no file size info
# 5. retry (2 times)
# 6. close connection by server
# 7. timeout (2 times)
# 8. HTTP error 500
# 9. HTTP error 400
# 10. socket error
# 11. range not satisfiable
# 12. resume
# 13. resuming after server connection close
# No more test cases for HttpFD.
# Test cases for other methods:
# 1. file_size < min_filesize
# 2. file_size > max_filesize
# 3. too many redirects (3)
# 4. no content-length in response headers
# 5. youtube-dl test (simulate download)
# 6. youtube-dl

# Generated at 2022-06-22 07:04:17.298074
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Run all unit tests for method real_download of class HttpFD.
    """
    from .utils import get_testdata_file

    filename = get_testdata_file(os.path.join('test', 'testvideo.mp4'))

# Generated at 2022-06-22 07:04:29.657678
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://example.com/video.mp4', {'http_chunk_size': 10, 'nooverwrites': True, 'quiet': True, 'continue_dl': True, 'ratelimit': 1024, 'retries': 3, 'test': True, 'noprogress': True, 'noresizebuffer': True})
    assert fd._CHUNK_SIZE == 10
    assert fd.params['continuedl']
    assert fd.params['nooverwrites']
    assert fd.params['quiet']
    assert fd.params['ratelimit'] == 1024
    assert fd.params['retries'] == 3
    assert fd.params['test']
    assert fd.params['noprogress']
    assert fd.params['noresizebuffer']


# Unit

# Generated at 2022-06-22 07:04:43.642696
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Check constructor with test parameters
    def test_parameters(param, expected_status, expected_content_type, expected_filename):
        http_params = {
            'noprogress': True,
            'quiet': True,
        }
        http_params.update(param)
        http_params = Params(**http_params)
        info = {
            'url': 'http://127.0.0.1:9/abcd',
        }

        fd = HttpFD(info, http_params,
                    dl=None,
                    test=True)

        # Info dictionary should have been filled with new entries
        assert 'status' in info
        assert 'content_type' in info
        assert 'filename' in info

        # Check status
        assert info['status'] == expected_status

        # Check content type

# Generated at 2022-06-22 07:04:55.557441
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil
    import atexit
    test_dir = (os.getenv('TEST_DIR') or tempfile.mkdtemp(prefix='youtube-dl-test-')).rstrip('/')
    atexit.register(lambda: shutil.rmtree(test_dir, ignore_errors=True))
    test_tmppath = '%s/%%(id)s-%%(id)s.%%(ext)s' % test_dir
    test_filename = '%s/%%(id)s.%%(ext)s' % test_dir
    ydl = YoutubeDL()

# Generated at 2022-06-22 07:05:08.818120
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FakeYDL:
        def __init__(self):
            self.params = {}

    stream = io.BytesIO(b'')
    fd = HttpFD(FakeYDL(), stream, 'http://youtube.com/abcdef')
    assert fd.get_size() is None
    assert fd.read(4) == b''
    assert fd.read() == b''
    assert fd.read() == b''

    fd.content_length = 10
    assert fd.get_size() == 10

    stream = io.BytesIO(b'1234567890')
    fd = HttpFD(FakeYDL(), stream, 'http://youtube.com/abcdef', 'rb', 10)
    assert fd.get_size() == 10

# Generated at 2022-06-22 07:05:20.569100
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from compat_http_client import parse_headers
    from .http_head import FakeHttpResponse

    class TestFD(HttpFD):
        def __init__(self, params, filename, info_dict):
            fake_headers = FakeHttpResponse(info_dict.get('filesize'),
                                            info_dict.get('filetime'))
            HttpFD.__init__(self, info_dict['url'], params, filename,
                            parse_headers(fake_headers))
            # HttpFD expects tmpfilename to exist and be open
            open(encodeFilename(self.tmpfilename), 'ab').close()

    info_dict = {
        'url': 'http://localhost/file.dat',
        'filesize': 1337,
        'filetime': 42.0,
    }
    filename = u'-'
   

# Generated at 2022-06-22 07:05:30.383413
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO

    s = BytesIO(b'foo')
    fd = HttpFD(s, 3)

    assert fd.size == 3
    assert fd.read(2) == b'fo'
    assert fd.read(2) == b'o'
    assert fd.read(2) == b''
    assert fd.read(2) == b''
    assert fd.read() == b''

    assert fd.read(2, 2) == b'o'
    assert fd.read(2, 1) == b'o'
    assert fd.read(2, 0) == b'f'
    assert fd.read(2, 1) == b'o'
    assert fd.read(2, 1) == b''

# Generated at 2022-06-22 07:05:43.129024
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def _test_readline(fd):
        s = fd.readline()
        assert s == b'a\x00\x01\x02c\r\nd\r\r\n'
        assert fd.readline() == b'e\r\r\r\n'
        assert fd.readline() == b'f\r\r'
        assert fd.readline() == b'\r\n'
        assert fd.readline() == b'g'
    _test_readline(HttpFD(BytesIO(b'a\x00\x01\x02c\r\nd\r\r\ne\r\r\r\nf\r\r\r\rg'), 14, int_or_none(None)))

# Generated at 2022-06-22 07:06:24.075691
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create the object
    u = 'http://localhost/'
    fd = HttpFD(u, None, {}, None, '-')
    assert fd.ydl is None
    assert fd.url == u
    assert fd.outtmpl == '-'
    assert fd.params == {}
    assert fd.retries == 3
    assert fd.max_sleep == 10

    # Call the (dummy) download method
    assert not fd.download(
        {'url': u, 'filepath': '-'},
        {},
        {'test': sys.stdout})


# Generated at 2022-06-22 07:06:35.809953
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    This function will test the method real_download() of HttpFD class
    in youtube_dl/downloader/http.py by calling the method with the given
    test url.
    """

    # Define a class to emulate DownloadContext
    class FakeDownloadContext:
        def __init__(self, test_chunk_size):
            self.chunk_size = test_chunk_size
            self.tmpfilename = 'tmpfilename'
            self.data = None
            self.filename = 'filename'
            self.data_len = self.chunk_size
            self.resume_len = 0
            self.open_mode = 'wb'
            self.stream = None
            self.block_size = 100 * 1024 * 1024
            self.start_time = time.time()
    # Define a class to emulate

# Generated at 2022-06-22 07:06:47.462341
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """test scenario:
        - simulate a download failing because of network error in the middle.
        - simulate a download failing because of network error after all data has been received.
        - simulate a download failing because of content-length mismatch after all data has been received.
        - simulate a download failing because of not being able to open the file for writing
        - simulate a download failing because of not being able to write the file data
        - simulate a download exceeding a minimum filesize limit
        - simulate a download exceeding a maximum filesize limit

        a number of different filesizes (1, 50, etc.) is tested for all scenarios.
        the filesize is chosen large enough to cover all code path for the `best_block_size` method.
    """
    import sys
    import tempfile
    import threading
    import time
    import unittest

    from io import BytesIO


# Generated at 2022-06-22 07:06:59.577320
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test HTTP
    #
    # Test file (with more than one chunk)
    http_test_file = 'http://releases.ubuntu.com/12.04/ubuntu-12.04-desktop-i386.iso.torrent'
    http_test_data = b'23456789ABCDEF'
    # Checksum (only first chunk)
    http_test_checksum = '596af0c0d228aac7870aee58f753626e4c4f9ba3'

    try:
        import hashlib

        sha1 = hashlib.sha1
    except ImportError:
        import sha
        sha1 = sha.new

    # Download the file

# Generated at 2022-06-22 07:07:08.781193
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert True
# class HttpFD(FileDownloader)
# @staticmethod def _parse_filesize(s):
# @staticmethod def _parse_filesize_str(s):
# def report_destination(self, filename):
# def report_progress_dl(self, downloaded_bytes, total_bytes):
# def report_speed(self, speed):
# def report_resuming_byte(self, resume_len):
# def report_retry(self, error, count, retries):
# def to_screen(self, s, skip_eol=False):
# def _hook_progress(self, status):
# def _prepare_and_start_download(self, filename, info_dict):
# def _make_file(self, filename, info_dict):
# def _make_dir(self, filename, info

# Generated at 2022-06-22 07:07:14.534501
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def side_effect(instance):
        return None
    # First test: No resuming and no rate limiting
    params = { 'noresizebuffer': True, 'test': True }
    ydl = FakeYDL()
    hf = HttpFD(ydl, params)
    # Constructor should set rate limit to zero
    assert hf.speed_limit == 0
    # Test download
    hf._test_download(url='http://test.test/file.bin',
                      content_length_match=None,
                      chunk_size_match=None)
    # Test download with test file size

# Generated at 2022-06-22 07:07:27.071172
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    class TestFD(HttpFD):
        def __init__(self, blocks, params={}):
            self.blocks = blocks
            super(TestFD, self).__init__(params)

        def download(self, url, filename, info_dict):
            return self.real_download(url, filename, info_dict)

    # Test 1. Single block
    assert TestFD([b'123']).download('foo', '-', {}) == True
    assert sys.stdout.getvalue() == b'123'

    # Test 2. Two blocks
    assert TestFD([b'123', b'45678']).download('foo', '-', {}) == True
    assert sys.stdout.getvalue() == b'12345678'

    # Test 3. Max block size

# Generated at 2022-06-22 07:07:38.016492
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL:
        def __init__(self, result):
            self.result = result
        def trouble(self, *args, **kargs):
            raise Exception(self.result)
        def trouble_http_413(self):
            raise compat_urllib_error.HTTPError('',413,'',None,None)
        def report_error(self, *args, **kargs):
            print(*args, **kargs)
        def urlopen(self, req):
            if req.get_full_url() == 'http://example.com/redirect':
                class FakeResponse:
                    def __init__(self, headers):
                        self.headers = headers
                    def info(self):
                        return self.headers
                    def read(self, bytes):
                        return b''

# Generated at 2022-06-22 07:07:47.000327
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Small test to check if HttpFD is working (downloading a file)
    http_fd = HttpFD(params={'continuedl': True})
    try:
        http_fd.download('http://releases.ubuntu.com/12.04.2/ubuntu-12.04.2-desktop-amd64.iso.torrent', 'test.torrent')
    except:
        traceback.print_exc()
    http_fd.to_screen('Test finished')

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:07:58.184949
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO

    class DummyOpener(object):
        def open(self, req):
            self.req = req
            # return a BytesIO
            return BytesIO(b'hi')

    o = DummyOpener()
    url = 'http://lolcat.com/'
    opts = {'verbose': False, 'quiet': False, 'nooverwrites': False}
    fd = HttpFD(o, url, test=True, params=opts)
    assert fd.real_url == url
    assert fd.info.get('url') == url
    assert fd.info.get('http_headers') is None

    opts = {'verbose': True, 'quiet': True, 'nooverwrites': True}

# Generated at 2022-06-22 07:09:08.448036
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test HttpFD constructor
    from .compat import urljoin
    url = 'http://127.0.0.1/video.mp4'
    partial_url = urljoin(url, '%(partial)s')
    chunk_size = 10
    num_segments = 5
    dl = HttpFD(None, {
        'url': url,
        'format': '1',
        'noprogress': True,
        'ratelimit': 1,
        'retries': 0,
        'continuedl': True,
        })
    dl.add_info_extractor(['http'])
    ie = HttpIE()

# Generated at 2022-06-22 07:09:21.130375
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestHttpFD(HttpFD):
        def __init__(self):
            HttpFD.__init__(self, {}, None, None)

        def report_error(self, msg):
            print('ERROR: ' + msg)
        def report_retry(self, source_error, count, max_retries):
            print('ERROR: ' + str(source_error))
            print('RETRY %s/%s' % (count, max_retries))
        def report_destination(self, filename):
            print('DESTINATION: ' + filename)
        def undo_temp_name(self, tmpfilename):
            return tmpfilename
        def best_block_size(self, elapsed_time, bytes_downloaded):
            return int(bytes_downloaded / (elapsed_time + .1))

# Generated at 2022-06-22 07:09:23.425706
# Unit test for constructor of class HttpFD
def test_HttpFD():
    hfd = HttpFD(None, {})
    assert hfd is not None


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:09:35.612290
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # pass
    from .extractor.youtube import YoutubeIE
    from .utils import mismatched_dummy_class
    assert mismatched_dummy_class.__name__ != YoutubeIE.__name__
    downloader = YoutubeIE()
    downloader._print_std_error = lambda x: None
    http_fd = HttpFD(downloader, {})

    # Testing 1 file download
    test_video_id = 'BaW_jenozKc'
    test_video_url = 'https://www.youtube.com/watch?v=%s' % test_video_id
    test_filename = 'test_video.%s.mp4' % test_video_id
    old_stdout = sys.stdout
    sys.stdout = StringIO()

# Generated at 2022-06-22 07:09:47.692179
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Tests downloader.py's HttpFD.real_download method.
    As HttpFD.real_download calls HttpFD._hook_progress and is closely coupled with YoutubeDL's state,
    we are unable to test it completely.
    """
    import tempfile

    fd, temppath = tempfile.mkstemp(prefix='test_HttpFD_real_download-')
    os.close(fd)

# Generated at 2022-06-22 07:09:58.121848
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # define arguments for a download of _TEST_FILE_SIZE at _TEST_DEFAULT_SPEED
    arr = [
        '--test',
        '--quiet',
        '--socket-timeout', '1',
        '--waitretry', '1',
        '--min-filesize', '200',
        '--max-filesize', '400',
        '--retries', '10',
        '--test-def-speed', str(_TEST_DEFAULT_SPEED),
        '--test-file-size', str(_TEST_FILE_SIZE),
    ]
    # create paris object with arguments
    params = Params(arr)

    # create download context object to hold block size and connection parameters

# Generated at 2022-06-22 07:10:10.141799
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys

    from .extractor import get_info_extractor

    # HACK: inject test parameter into params of YoutubeIE
    ie = get_info_extractor('Youtube', downloader=None)
    ie.params['test'] = True
    ie.add_info_extractor(get_info_extractor('Generic'))

    def test_download(url, expected_filesize):
        # HACK: prevent from printing messages by to_screen
        old_stderr = sys.stderr
        sys.stderr = open(os.devnull, 'w')
        params = {
            'outtmpl': '%(id)s_%(ext)s',
            'format': 'worst',
            'quiet': True,
            'noprogress': True,
        }
        fd = Http

# Generated at 2022-06-22 07:10:20.903992
# Unit test for constructor of class HttpFD
def test_HttpFD():
    data = 'abcdefghijklmnop'
    f = io.BytesIO(data)
    info = {
        'Content-Type': 'text/plain',
        'Content-Length': len(data),
    }
    info['Content-Location'] = info['Content-Disposition'] = info['Content-Description'] = info['Accept-Ranges'] = 'unknown'

    h = HttpFD(f, info, 'http://example.com/random')
    assert h.name == 'http://example.com/random'
    assert h.mode == 'rb'
    assert h.read() == data
    try:
        h.write('test')
        assert False
    except OSError:
        pass
    h.close()



# Generated at 2022-06-22 07:10:31.416994
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    from .extractor.common import InfoExtractor

    class FakeYDL(YoutubeDL):
        def report_error(self, *args, **kargs):
            pass

    ie = InfoExtractor(FakeYDL())
    ie._downloader = HttpFD(ie._ydl, ie, params={})

    # Test constructor
    def test(size):
        ie._downloader.downsize(size)
        assert ie._downloader._size == size

    test(0)
    test(1)
    test(1024)
    test(2 * 1024)
    test(2 * 1024 + 1)
    test(10 * 1024 - 1)
    test(10 * 1024)
    test(10 * 1024 + 1)
    test(100 * 1024 - 1)
    test(100 * 1024)

# Generated at 2022-06-22 07:10:39.992264
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # For testing purposes we need a function that returns the requested portion of data of
    # file (or the whole file if no range was requested).
    def get_data(url, headers):
        req = compat_urllib_request.Request(url, headers=dict(headers))
        range_m = re.search(r'bytes=(\d+)-(\d+)?', req.get_header('Range', ''))
        if range_m:
            range_start = int(range_m.group(1))
            range_end = int_or_none(range_m.group(2))
        else:
            range_start = 0
            range_end = None
        f = io.open('tests/test.mp4', 'rb')
        f.seek(range_start)