

# Generated at 2022-06-22 07:03:57.972922
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys

    class MockYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen_lock = threading.Lock()

        def to_screen(self, s):
            with self.to_screen_lock:
                print(s)
                sys.stdout.flush()

        def trouble(self, s, tb=None):
            self.to_screen('ERROR: ' + s)
            if tb is not None:
                if isinstance(tb, compat_basestring):
                    self.to_screen(tb)
                else:
                    import traceback
                    self.to_screen(traceback.format_exc(tb))
            sys.exit(1)


# Generated at 2022-06-22 07:04:11.358980
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = YoutubeDL()
    ydl_opts = {
        'nooverwrites': True,
        'retries': 10,
        'continuedl': True,
        'noresizebuffer': True,
        'test': True,
    }
    fd = HttpFD(ydl, ydl_opts)

    # test with headers={'Accept-Encoding': 'gzip'}
    url = 'https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/README.md'
    tmpfilename = fd.prepare_filename('README.md')
    info = {
        'id': 'README.md',
        'url': url,
    }
    # create empty file
    tmp_fd = open(tmpfilename, 'wb')
    tmp_

# Generated at 2022-06-22 07:04:24.570226
# Unit test for constructor of class HttpFD
def test_HttpFD():
    bytes = b'h\xe9ll\xf8 w\xf8rld! bl\xe9'
    start = time.time()
    real = real_download(bytes)

    class MyHTTPDownloader(YoutubeDLHttpRequest):
        def __init__(self):
            self.data = iter(bytes)
            YoutubeDLHttpRequest.__init__(self)

        def read(self, bytes_=2**16):
            return bytes(next(self.data), 'latin-1')

    req = MyHTTPDownloader()
    req.add_header('Content-length', len(bytes))
    fd = HttpFD(req, None, {'noprogress': True, 'continuedl': True})
    meta = fd.get_metadata()


# Generated at 2022-06-22 07:04:38.116840
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import json
    import os.path
    import tempfile
    import urllib.request
    import urllib.error
    from sys import stdout
    from unittest.mock import patch, Mock

    def assert_download(test_scenario, exp_filename=None, exp_file=None, exp_info={}, **fd_params):
        if exp_filename is None:
            exp_filename = test_scenario['filename']
        # Initialize test framework
        # open_mock mimics open that may raise IOError or OSError
        open_mock = patch('io.open', Mock(side_effect=lambda *args, **kwargs: open(*args, **kwargs)))

        # read_mock mimics file.read
        # Depending of test scenario it may return specified amount of data


# Generated at 2022-06-22 07:04:42.304622
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test for real_download of class HttpFD is located in test_HttpFD_resume below.
    # TODO: check HttpFD._do_download_with_retry for errors
    return True


# Generated at 2022-06-22 07:04:54.412941
# Unit test for constructor of class HttpFD

# Generated at 2022-06-22 07:05:01.242632
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def gen_test_data(total_size, full_l = None, fragment_l = None, fragment_s = None):
        if fragment_l is not None:
            fragment_count = (total_size + fragment_l - 1) // fragment_l
        else:
            fragment_count = 1
        if full_l is not None:
            full_count = (total_size + full_l - 1) // full_l
        else:
            full_count = 0
        for i in range(fragment_count + full_count):
            fragment = i < fragment_count
            if fragment:
                size = fragment_s or fragment_l
            else:
                size = total_size - full_l * (full_count - 1)
            h = hashlib.sha1()

# Generated at 2022-06-22 07:05:11.397603
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def get_test_exceptions(downloader):
        class TestContentTooShortError(ContentTooShortError):
            def __init__(self, msg, klass, content_length, _bytes_downloaded):
                super(TestContentTooShortError, self).__init__(content_length, _bytes_downloaded)

                self.msg = msg
                self.klass = klass

            def __str__(self):
                return repr((self.msg, self.klass))

        def fail_download(self, *args, **kargs):
            exc_type, exc_value, tb = sys.exc_info()
            raise TestContentTooShortError('Download failed!', exc_type, None, None)

        def success_download(self, *args, **kargs):
            self.report_finish()
            self

# Generated at 2022-06-22 07:05:21.452968
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Data for testing:
    url = 'http://127.0.0.1:8080/files/myfile'
    filename = 'myfile'
    content_length = 1048576
    # headers
    headers = {'content-length': content_length}
    # args
    args = {
        'noprogress': True,
        'continuedl': True,
        'ratelimit': 100,
        'noresizebuffer': True,
        'retries': 5,
        'logger': YoutubeDL()._downloader.to_screen,
    }
    # Test open()
    fd = HttpFD(url, filename, headers, args)
    assert fd.name == 'myfile'
    assert fd.content_length == content_length
    assert fd.headers == headers
    assert f

# Generated at 2022-06-22 07:05:32.512487
# Unit test for constructor of class HttpFD
def test_HttpFD():

    http_fd = HttpFD(
        'http://127.0.0.1:8080/5MB.bin',
        params=dict(
            start_offset=0,
            chunk_size=2 ** 19,
            max_chunk_size=2 ** 22,
            ratelimit=10485760,
            min_filesize=2 ** 18,
            buffersize=2 ** 16))

    # Test property: filename
    assert 'http://127.0.0.1:8080/5MB.bin' == http_fd.filename

    # Test property: name
    assert 'http://127.0.0.1:8080/5MB.bin' == http_fd.name

    # Test property: isatty
    assert not http_fd.isatty()

    # Test property: closed

# Generated at 2022-06-22 07:06:19.442982
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """ Run a simple test of HttpFD. """
    import os
    import shutil
    import tempfile

    fd, filename = tempfile.mkstemp()
    os.write(fd, b'\x00\x01\x02\x03')
    os.close(fd)

    fd = HttpFD(filename, 0, 2)
    assert fd.read(2) == b'\x00\x01'
    assert fd.read(2) == b'\x02\x03'
    assert fd.read(2) == b''
    assert fd.size == 4

    fd = HttpFD(filename, 1, 2)
    assert fd.read(2) == b'\x01\x02'

# Generated at 2022-06-22 07:06:30.825497
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if sys.version_info >= (3, 0):
        return
    b = compat_etree_Element('b')
    b.attrib['href'] = 'foobar'
    def check(ctx, expect_size):
        assert ctx.filename == '-'
        assert ctx.tmpfilename == '-'
        assert ctx.stream is sys.stdout
        assert ctx.open_mode == 'wb'
        assert ctx.resume_len == 0
        assert ctx.data is None
        assert ctx.url is None
        assert ctx.data_len == expect_size
    check(HttpFD(b, 1024), 1024)
    check(HttpFD(b, None), None)
    b.attrib['href'] = 'foobar.mp4'
    check(HttpFD(b, None), None)

# Generated at 2022-06-22 07:06:43.850998
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import random
    import math
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import time

    def chunks(l, n):
        """ Yield successive n-sized chunks from l.
        """
        for i in xrange(0, len(l), n):
            yield l[i:i + n]

    def test_progressive_retrieval(fd, expected_data, chunk_size=None, initial_size=None, test_perf=True, **fd_kwargs):
        if initial_size is None:
            initial_size = fd.size
        else:
            initial_size = min(initial_size, fd.size)
        if chunk_size is None:
            chunk_size = initial_size

# Generated at 2022-06-22 07:06:53.714586
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import unittest
    import mock
    import os

    class TestHttpFD(HttpFD):
        _TEST_FILE_SIZE = 123

        def __init__(self):
            HttpFD.__init__(self, 'http://localhost/file', {'noprogress': True})
            self._hook_progress = mock.Mock()
            self.to_screen = mock.Mock()
            self.to_stderr = mock.Mock()

        def best_block_size(self, elapsed_time, bytes):
            return 5 if elapsed_time == 0 else bytes

    class TestHttpFDRealDownload(unittest.TestCase):
        def setUp(self):
            self.f = TestHttpFD()
            self.f.report_destination = mock.Mock()
            self.f.report

# Generated at 2022-06-22 07:06:59.984520
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    downloader = YoutubeDL(FakeYDL())
    fd = HttpFD(downloader, {'noprogress': True}, 'http://127.0.0.1:8080/5MiB', '-').setup()
    assert fd.real_download()
    assert fd.downloaded_bytes() == 5 * 1024 * 1024

# Generated at 2022-06-22 07:07:03.449313
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(None, {}, None)
    h.download({'url': 'http://www.youtube.com/watch?v=BaW_jenozKc', 'proxy': 'http://foo.bar'}, {}, None)


# Generated at 2022-06-22 07:07:16.287627
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import io
    import unittest
    from .utils import encodeFilename

    class Test(unittest.TestCase):
        def setUp(self):
            self.content = 'content'
            self.buffer = io.BytesIO(self.content.encode('utf-8'))
            self.buffer.fileno = lambda: -1  # mock a file with no fileno
            self.content_length = str(len(self.content))
            self.test_filename = encodeFilename('test')

        def test_constructor(self):
            h = HttpFD(self.buffer, self.content_length, self.test_filename)
            self.assertEqual(h.name, 'test')
            # h.read() would fail on python 2.x without the following line
            h.fileno = lambda: -1


# Generated at 2022-06-22 07:07:28.409424
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # We need to patch urlopen to prevent downloading the actual file and
    # also to control what is written in it
    buffer = io.BytesIO()
    def fake_urlopen_1(_):
        return object()  # Simulate the data stream
    def fake_urlopen_2(req):
        if req.get_full_url().endswith('/404'):
            raise compat_urllib_error.HTTPError(req.get_full_url(), 404, 'Not found', None, None)
        return buffer
    @contextlib.contextmanager
    def patch_urlopen():
        prev_urlopen = compat_urllib_request.urlopen
        compat_urllib_request.urlopen = fake_urlopen_1
        yield
        compat_urllib_request.urlopen = prev_urlopen
   

# Generated at 2022-06-22 07:07:39.439578
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test for method real_download of class HttpFD."""
    # Test is applied to the test case of this module
    # test_urlopen_progress()
    # Initialization of test variables
    class FakeYDL(object):
        def __init__(self):
            self.params = {}
        def to_screen(self, msg):
            pass
        def to_stderr(self, msg):
            pass
        def urlopen(self, *args, **kargs):
            return FakeURLOpen(args[0])
    fake_ydl = FakeYDL()
    url = 'http://127.0.0.1:8080/'
    filename = '-'
    info_dict = {}
    params = {'test': True}

# Generated at 2022-06-22 07:07:51.817074
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.example.com/')
    assert fd.status() == 200
    assert fd.geturl() == 'http://www.example.com/'
    assert fd.getcode() == 200
    assert fd.fileno() == -1
    assert fd.headers.getheader('content-type') == 'text/html'
    # The following must not raise an exception
    fd.read()
    fd.read(None)
    fd.read(4)
    # The following must not raise an error
    fd.close()
    # The following is not supported
    try:
        fd.readlines()
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-22 07:09:01.404893
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test for download in chunks
    def chunked_test(ctx):
        # Simulate connection loss after downloading one chunk
        if ctx.resume_len == 0 and ctx.data_len == ctx.chunk_size:
            raise RetryDownload(Exception('simulating connection loss'))
        # Simulate lack of connection after downloading one chunk
        if ctx.resume_len == 0 and ctx.data_len == ctx.chunk_size:
            raise compat_urllib_error.URLError('simulating lack of connection')
        # Simulate lack of connection when downloading the last chunk

# Generated at 2022-06-22 07:09:13.679132
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import random
    import shutil
    import tempfile
    import urllib.response
    import urllib.request
    import urllib.error
    import ssl
    import threading
    import unittest

    class ReadFromFD(object):
        def __init__(self, fd, amt):
            self.fd = fd
            self.amt = amt

        def read(self, block_size):
            if self.amt <= 0:
                return b''
            return os.read(self.fd, min(block_size, self.amt))

        def close(self):
            if self.fd is not None:
                os.close(self.fd)
                self.fd = None

    # external data
    DATA_SIZE_1 = 1024 * 1024 * 1  # 1 MB


# Generated at 2022-06-22 07:09:23.631920
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD(opts)

    def test_urlopen(request):
        # Just simulate the retrieve process of urllib2
        assert isinstance(request, compat_urllib_request.Request)
        data = compat_urllib_request.urlopen(request)
        if request.get_header('Range') is None:
            # Server don't support byte range query,
            # return the whole file
            return data
        # We do support byte range query, return only the first chunk
        range_hdr = 'bytes=0-%d' % (fd.params['test_chunksize'] - 1)
        # simulate the server, which returns the whole file with no Content-Range header
        # set despite of requested range (see
        # https://github.com/ytdl-org/youtube-dl/issues/

# Generated at 2022-06-22 07:09:35.799048
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test 1: Downloading
    fd = HttpFD(HttpFDTest.http_server.get_url(), {'noprogress': True, 'quiet': True}, {'test': 'testval'})
    assert isinstance(fd, HttpFD)
    # Test 2: Downloading with test option
    fd = HttpFD(HttpFDTest.http_server.get_url(), {'noprogress': True, 'quiet': True}, {'test': True})
    assert isinstance(fd, HttpFDTest)
    # Test 3: Not downloading
    fd = HttpFD(HttpFDTest.http_server.get_url(), {'noprogress': True, 'quiet': True})
    assert isinstance(fd, HttpFD)
    # Test 4: Not downloading with User-Agent option
    f

# Generated at 2022-06-22 07:09:47.848490
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Creates mock info dict
    info_dict = {'url': 'https://example.com/index.html',
                 'test': True,
                 'outtmpl': 'test_outtmpl-%(testid)s.html',
                 'testid': 'test_HttpFD_real_download',
                 'http_headers': {'Content-Length': 100}
                 }

    # Creates mock ytdl object
    class MockYdl(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, message):
            print(message)

        def to_stderr(self, message):
            raise NotImplementedError(message)

        def trouble(self, message, tb=None):
            raise NotImplementedError(message)


# Generated at 2022-06-22 07:09:55.201061
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Check that URL is correctly parsed
    try:
        HttpFD('http://host:port/path')
        assert False
    except ValueError as e:
        assert e.args[0] == 'Invalid URL: http://host:port/path'
    # Check that all required options are set
    try:
        HttpFD('')
        assert False
    except ValueError as e:
        assert e.args[0] == 'Missing URL'



# Generated at 2022-06-22 07:10:06.563382
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Data
    data = b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    # Precomputed md5 sum
    md5sum = 'd174ab98d277d9f5a5611c2c9f419d9f'
    # Stream size
    stream_size = len(data)

    # Test 1: Chunked download

# Generated at 2022-06-22 07:10:10.748887
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Set up
    ydl = YoutubeDL({})
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['verbose'] = True
    ydl.urlopen = urlopen

    hd = HttpFD(ydl)

    chunk_size = 102400 #100 KiB
    chunk_num = 2 # number of chunks to download
    test_file_size = chunk_size * chunk_num
    assert test_file_size == int(test_file_size)

    # Prepare test-server for serving random data
    data = os.urandom(test_file_size)
    test_server = SocketServer.TCPServer(('', -1),
        lambda *args: SingleTCPHandler(data, *args))

# Generated at 2022-06-22 07:10:22.266641
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from tempfile import NamedTemporaryFile
    s = 'foobar test'
    data_len = len(s)

    def handler(*args, **kargs):
        if args[0] == 'Status:':
            return
        if args[0].startswith('[download] Destination:'):
            return
        if args[0].startswith('[download] 100%'):
            tmpfile.seek(0)
            assert tmpfile.read() == s
            return


# Generated at 2022-06-22 07:10:33.016976
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def _test_http_fd(test_dict):
        hd = HttpFD(test_dict['ydl'], test_dict['url'], test_dict['params'])
        assert hd.ydl is test_dict['ydl']
        assert hd.url == test_dict['url']
        assert hd.params == test_dict['params']
        return hd
    # Test only non-empty constructor
    hd = _test_http_fd({
        'ydl': 'ydl',
        'url': 'url',
        'params': {
            'param1': 'value1',
            'param2': 'value2',
        }
    })
    assert hd.ydl is 'ydl'
    assert hd.url == 'url'