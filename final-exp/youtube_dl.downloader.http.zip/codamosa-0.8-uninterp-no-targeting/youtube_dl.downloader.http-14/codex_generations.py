

# Generated at 2022-06-22 07:03:55.169443
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # The file we are going to download
    url = 'https://github.com/rg3/youtube-dl/raw/master/README.md'
    # Arbitrary large number
    file_size = 12345678
    # One byte less than full file
    test_size = file_size - 1
    # A large number unlikely to be returned by real_download()
    max_size = 99999999

    # Mock up Results
    result = Results()
    result.filename = 'file.txt'
    result.tmpfilename = 'tmp.txt'
    result.info['size'] = file_size

    # Mock up FakeFD
    fd = HttpFD(result, progress_hooks=[])

    # Direct download of the whole file, without test mode

# Generated at 2022-06-22 07:04:04.046500
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test = HttpFD()

    # Test default constructor
    assert test.ydl is not None

    # Test constructor with param 'ydl'
    try:
        test2 = HttpFD(ydl=test.ydl)
        assert test2.ydl == test.ydl
    except Exception as err:
        assert False, 'Unexpected error raised: ' + str(err)

    # Test constructor with unknown param
    try:
        test2 = HttpFD(unknown_param='test')
        assert False, 'No error raised'
    except Exception as err:
        assert True

    # Test constructor with invalid param 'ydl'
    try:
        test2 = HttpFD(ydl=None)
        assert False, 'No error raised'
    except Exception as err:
        assert True

# Generated at 2022-06-22 07:04:16.690203
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading
    from socket import socket
    from queue import Queue

    from .utils import encodeFilename, prepend_extension

    class DummyHttpFD(HttpFD):
        def __init__(self, params, filename):
            self.params = params
            self.filename = filename
            self.outtmpl = '%(id)s'
            self.out_templates = [self.outtmpl]
            self.test_templates = []
            self.test_file_size = -1
            self.test_file_offset = None
            self.force_resume = False
            self.continue_dl = False
            self.next_url = None
            self.prefer_free_formats = False
            self._progress_hooks = []
            self.resume_len = 0
            self.total

# Generated at 2022-06-22 07:04:18.838914
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(HookableFD(None, lambda x:x))


# Generated at 2022-06-22 07:04:30.860400
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _monkey_patch(name):
        def decorator(func):
            setattr(HttpFD, name, func)
            return func
        return decorator

    @_monkey_patch('report_error')
    def report_error(self, msg, *args):
        print(msg % args)

    @_monkey_patch('report_retry')
    def report_retry(self, err, count, retries):
        print('%s/%s: %s' % (count, retries, err))

    @_monkey_patch('report_destination')
    def report_destination(self, filename):
        print('Destination: ' + filename)

    # @_monkey_patch('report_progress')
    # def report_progress(self, percent, data_len_str, speed, eta):
    #

# Generated at 2022-06-22 07:04:36.890851
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractors
    def test_real_download(
            ydl,
            url='http://releases.ubuntu.com/14.04/ubuntu-14.04-desktop-amd64.iso.torrent',
            filename='ubuntu-14.04-desktop-amd64.iso.torrent.tmp',
            tmpfilename=None,
            expected_content='d1:ad2:id20:Ubuntu14.04Desktop64i1e5:nodesl'):
        hfd = HttpFD(ydl, params={'nooverwrites': True})
        if tmpfilename is None:
            tmpfilename = filename

        assert hfd.real_download(url, filename, tmpfilename)

        with open(tmpfilename, 'rb') as f:
            assert f.read() == expected_content



# Generated at 2022-06-22 07:04:48.783303
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import socket
    import subprocess
    import sys
    import threading

    url = 'http://localhost:8808/gopherland.txt'
    # This URL returns 403 Forbidden unless User-Agent is set
    # Test that setting the user-agent works
    url2 = 'http://httpbin.org/get?test=test'

    t = threading.Thread(target=subprocess.call, args=([sys.executable, '-m', 'http.server', '8808']))
    t.daemon = True
    t.start()

    time.sleep(0.2)  # Wait for http server to start

    # Test basic construction of HttpFD
    http_fd = HttpFD(url, {'noprogress': True})
    http_header_dict = http_fd.headers
    data = http_

# Generated at 2022-06-22 07:04:57.168356
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Make sure that HttpFD is functioning properly."""

    # Test 1: Downloading a file and printing it in the standard output.
    test1_url = 'http://www.google.com/intl/en_ALL/images/logo.gif'
    test1_output = StringIO.StringIO()
    fd1 = HttpFD(urlopen(test1_url), None, test1_output)
    shutil.copyfileobj(fd1, sys.stdout)
    assert fd1.size == fd1.downloaded_bytes
    return True


# Generated at 2022-06-22 07:05:02.752928
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if sys.version_info[0] >= 3:
        return
    import socket
    import tempfile
    import test_utils
    import youtube_dl
    import youtube_dl.downloader.common

    s = socket.socket()
    s.bind(('localhost', 0))
    port = s.getsockname()[1]
    s.listen(5)
    s.settimeout(2)

    tmpfile = tempfile.mkstemp()[1]
    fd = youtube_dl.FileDownloader({}, {})
    fd.params['outtmpl'] = tmpfile
    fd.params['nooverwrites'] = False

    def accept_then_close_socket(s):
        try:
            s.accept()
        finally:
            s.close()

# Generated at 2022-06-22 07:05:13.567979
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Simulates download of a given string, then compares its md5 hash to
    # the desired one

    # TODO: test for 'noresizebuffer'

    import tempfile
    import os
    import hashlib

    # A string that we will simulate to download
    test_string = b'Hello World! 1234567890' * 1024 * 256

    # Desired md5 hash of test_string
    test_md5 = hashlib.md5(test_string).hexdigest()

    # Simulated chunks of data to return to HttpFD
    test_chunks = [test_string[i: i + 1024 * 512] for i in range(0, len(test_string), 1024 * 512)]

    # Simulated response headers
    test_headers = {
        'Content-Length': str(len(test_string)),
    }



# Generated at 2022-06-22 07:05:56.687128
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile

    params = {'nooverwrites': True, 'noprogress': True, 'quiet': True, 'sleep_interval': 1}

    # Test download of a non-chunked file with download-by-chunks support
    def test_download_by_chunks():
        chunk_size = 65536
        seek_start = 0
        seek_end = 100
        content_len = seek_end - seek_start + 1

        # Because of implementation of HttpFD.real_download, there's no way to implement download-by-chunks
        # using regular HTTP server. So instead a special HTTP server is implemented that supports download-by-chunks.
        # This server returns a random file with specified size (seek_end - seek_start).
        # Since HttpFD.real_download is a private method, and

# Generated at 2022-06-22 07:06:03.154848
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Testcase 1:
    # Test data size less than buffer
    import io
    import random
    import time
    # random.seed(2)
    DATA_LEN = 1024 * 1024
    # Simulated data blocks
    block_list = [
        compat_struct_pack(b'B', random.randint(0, 255))
        for _ in range(DATA_LEN)
    ]

    class DummyHeaders(object):
        def get(self, key, default=None):
            if key == 'content-length':
                return str(DATA_LEN)
            elif key == 'content-type':
                return 'application/octet-stream'

# Generated at 2022-06-22 07:06:15.881200
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Unit test for method HttpFD.real_download. HttpFD.real_download is
    responsible for deciding how to handle downloading of an HTTP(S) file.
    HttpFD.real_download method is the main method of class HttpFD.
    """
    class FakeYTDL(object):
        """A fake version of YDL class."""
        def __init__(self):
            """Constructor for fake YDL class."""
            self.progress_hooks = []

        @property
        def params(self):
            """Return search parameters."""
            return {
                'noprogress': True,
                'noresizebuffer': False,
                'retries': 0
            }


# Generated at 2022-06-22 07:06:28.223636
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import YoutubeIE
    import socket
    import struct
    import threading
    import tempfile
    import shutil
    from .compat import compat_http_server

    # TODO remove this hack
    YoutubeIE.extract_info = lambda s, *args, **kwargs: {
        'id': 'youtube-id',
        'title': 'youtube-title',
    }

    # creating a test server
    class TestServer(compat_http_server.HTTPServer, object):

        def __init__(self, *args, **kwargs):
            self._test_servers_condition = kwargs.pop('condition')
            super(TestServer, self).__init__(*args, **kwargs)

        def handle_error(self, request, client_address):
            self._test_servers_

# Generated at 2022-06-22 07:06:38.296881
# Unit test for constructor of class HttpFD
def test_HttpFD():
    (tmp, tmppath) = tempfile.mkstemp()
    os.close(tmp)

# Generated at 2022-06-22 07:06:46.985156
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test that HttpFD really works with control-chars in the URL
    class Dummy(object):
        def __init__(self):
            self.http_headers = {}
    ydl = Dummy()
    ydl.params = {
        'forceurl': True,
        'forcetitle': True,
        'forcedescription': True,
        'forcethumbnail': True,
        'forcefilename': True,
        'forcetitle': True,
        'forcejson': True,
        'simulate': True,
    }
    test_fd = HttpFD(
        ydl, {'url': '%01%02%03%04%05'}, {'skip_download': True})
    assert test_fd.real_url == '%01%02%03%04%05'
    assert test

# Generated at 2022-06-22 07:06:59.056551
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # With test data
    http_fd = HttpFD(
        'http://127.0.0.1:3128/asdfg', {
            'test_data_len': 10,
            'test_data_fallback': 'http://127.0.0.1:3128/abc',
        })
    info_dict = http_fd.get_info_dict()
    assert info_dict['protocol'] == 'http'
    assert info_dict['url'] == 'http://127.0.0.1:3128/asdfg'
    assert info_dict['filesize'] == 10
    assert info_dict['urlhandle'].url == 'http://127.0.0.1:3128/asdfg'
    assert http_fd.get_size() == 10
    assert http_fd.get_

# Generated at 2022-06-22 07:07:08.614239
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Tests the HttpFD constructor."""

    #
    # Mock class
    #
    class MockYDL(object):

        def __init__(self):
            self.http_headers = {}

        def to_screen(self, msg):
            pass

        def to_stdout(self, msg):
            pass

        def to_stderr(self, msg):
            pass

        def trouble(self, msg, tb=None):
            pass

        def report_error(self, msg, tb=None, exc_info=None, lvl=None):
            pass

        def report_warning(self, msg):
            pass

        def slow_down(self, start_time, now, byte_counter):
            pass


    class MockIE(object):

        def __init__(self):
            pass

       

# Generated at 2022-06-22 07:07:21.872917
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test for method HttpFD.real_download"""
    from .compat import compat_http_client
    from .utils import download_chunks, sanitize_open

    url = 'https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/README.md'
    chunks = download_chunks(
        url, headers={'Range': 'bytes=0-100'}, outtmpl='-',
        chunksize=1, ratelimit=None, test=True
    )
    assert sum(map(len, chunks)) == 101
    assert all(c in b'abcdefghijklmnopqrstuvwxyz0123456789-\n' for c in b''.join(chunks))


# Generated at 2022-06-22 07:07:33.189938
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import threading

    HOST = 'localhost'
    PORT = 8000
    FILE_PATH = '/testfile.dat'

    def run_test_server():
        import testcode.testserver
        config = {
            'host': HOST,
            'port': PORT,
        }
        srv = testcode.testserver.TestServer(config)
        srv.run()

    test_server_thread = threading.Thread(target=run_test_server)
    test_server_thread.daemon = True
    test_server_thread.start()


# Generated at 2022-06-22 07:08:45.700314
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL():
        """Fake class for testing HttpFD._real_download()"""
        def report_error(self, *a, **k):
            pass
        def report_warning(self, *a, **k):
            pass
        def report_destination(self, *a, **k):
            pass
        def to_screen(self, *a, **k):
            pass
        def to_stderr(self, *a, **k):
            pass
        def trouble(self, *a, **k):
            pass
        def urlopen(self, url_req):
            return url_req

    class FakeInfoDict():
        """Fake class for testing HttpFD._real_download()"""
        def __init__(self, sz):
            self.sz = sz

# Generated at 2022-06-22 07:08:50.574830
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # set up
    not_existing_file = 'http://not-existing.file'

    # test
    fd = HttpFD(not_existing_file, {'noprogress': True})

    # tear down
    del fd


# Generated at 2022-06-22 07:09:00.491139
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import unittest

    assert sys.version_info >= (2, 6)

    from . import YoutubeDL

    class HttpFdTest(unittest.TestCase):
        def setUp(self):
            self.fd = HttpFD(YoutubeDL(), {'nooverwrites': False})
            self.fd._hook_progress = lambda d: None
            self.fd.to_screen = lambda s: None  # Do not print
            self.fd.to_stderr = lambda s: None  # Do not print
            self.fd.report_error = lambda s: None  # Do not print
            self.fd.report_warning = lambda s: None  # Do not print
            self.fd.report_retry = lambda s: None  # Do not print


# Generated at 2022-06-22 07:09:12.783343
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = DummyYDL()
    ydl.params.update(
        {'nooverwrites': True, 'continuedl': False, 'noprogress': True,
         'quiet': True, 'ratelimit': None, 'retries': 1, 'noresizebuffer': True,
         'prefer_insecure': False, 'prefer_ffmpeg': False, 'logger': ydl})
    downer = HttpFD(ydl)
    downer._verbose_print = False  # disable verbose print
    downer.real_download('http://127.0.0.1/500', None, None)
    downer.real_download('http://127.0.0.1/503', None, None)

# Generated at 2022-06-22 07:09:14.113712
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for constructor of class HttpFD
    assert isinstance(HttpFD(None, None, {}), FileDownloader)

# Generated at 2022-06-22 07:09:23.893866
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .compat import mock
    from .utils import PreparedExclusiveFile
    from io import BytesIO
    from tempfile import SpooledTemporaryFile
    from .YoutubeDL import MAX_DOWNLOAD_SIZE
    from .extractor.generic import get_cachedir
    from .downloader.common import ContentTooShortError
    from .downloader.external import ExternalFD
    from .downloader.http import HttpFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashFD
    # Test setup
    downloaded_file = SpooledTemporaryFile()

# Generated at 2022-06-22 07:09:35.143229
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile, shutil, random, os
    stream = HttpFD(None, {'noprogress': True})
    dst = os.path.join(tempfile.gettempdir(), 'test_HttpFD.test')
    try:
        os.unlink(dst)
    except OSError:
        pass

# Generated at 2022-06-22 07:09:47.112353
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Runs a simple unit test for HttpFD.
    """

    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    # 1. Test with an honest server

# Generated at 2022-06-22 07:09:57.805726
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestException(Exception):
        pass

    class TestFD(object):
        max_retries = 3
        retries = 0
        fragment_retries = 0

        @staticmethod
        def slow_down(start, now, byte_counter):
            pass

        @staticmethod
        def best_block_size(elapsed_time, byte_counter):
            return 10

        @staticmethod
        def calc_speed(start, now, byte_counter):
            return 10

        @staticmethod
        def calc_eta(start, now, data_len, byte_counter):
            return 10

        @staticmethod
        def report_error(msg):
            pass

        @staticmethod
        def report_retry(exc, count, max_tries):
            pass


# Generated at 2022-06-22 07:10:08.445986
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL(DummyYDL())
    loc = 'http://127.0.0.1:8080/'
    hfd = HttpFD(ydl, loc)
    assert hfd.loc == loc
    assert hfd.length == None
    assert hfd.name == 'youtube-dl test video'
    assert hfd.ydl == ydl
    assert hfd.status == None
    assert hfd.filename == hfd.name + '.f4v'
    assert hfd.basename == 'youtube-dl test video.f4v'
    assert hfd.temp_name == hfd.name + '.f4v.part'
    assert not hfd.test



# Generated at 2022-06-22 07:13:01.978080
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # _BEGIN_UNIT_TEST
    # Test for HttpFD constructor
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    info_dict = ydl.extract_info(
        'http://releases.ubuntu.com/precise/ubuntu-12.04-preinstalled-desktop-armhf+ac100.img.xz', download=False)
    print(info_dict)
    assert info_dict['_type'] == 'http_dash_segments'
    assert info_dict['path'] == 'ubuntu-12.04-preinstalled-desktop-armhf+ac100.img.xz'
    assert info_dict['protocol'] == 'http_dash_segments'

# Generated at 2022-06-22 07:13:13.599798
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DummyYoutubeDL():
        def __init__(self, is_test):
            self.is_test = is_test
            self.params = {
                'retries': 10,
                'buffersize': '2M',
            }
            self.to_stderr = lambda s: sys.stderr.write(s + '\n')
            self.to_screen = lambda s: sys.stdout.write(s + '\n')
            self.report_error = self.to_stderr
            self.report_destination = lambda s: None
            self.report_retry = lambda e, c, t: None
            self.report_file_already_downloaded = lambda s: None
            self.report_unable_to_resume = lambda: None
            self.report_res