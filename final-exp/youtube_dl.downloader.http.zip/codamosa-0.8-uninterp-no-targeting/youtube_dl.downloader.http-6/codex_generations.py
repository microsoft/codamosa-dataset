

# Generated at 2022-06-22 07:03:51.369594
# Unit test for constructor of class HttpFD
def test_HttpFD():
    https_url = 'https://upload.wikimedia.org/wikipedia/commons/7/72/IPhone_Internals.jpg'
    with YoutubeDL(YoutubeDL.params) as ydl:
        # test http
        fd = HttpFD(
            ydl, https_url, {'http_chunk_size': 1048576}, 'rb+', 'https://example.org/'
        )
        assert fd.can_resume()
        fd.close()
        fd = HttpFD(ydl, https_url, {'http_chunk_size': 1048576}, 'rb+')
        assert fd.can_resume()
        fd.close()

        # test https

# Generated at 2022-06-22 07:04:01.661739
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # This test is not waiting for timeout.
    # It is failing if a connection could not be established.
    socket.setdefaulttimeout(60)
    from .downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['noprogress'] = True
    ydl.params['logger'] = YoutubeDL().create_std_logger('test_logger')
    url = 'http://test.testdownloader.com/test.dat'
    hd = HttpFD(ydl, url, {'test': 'test'})
    assert hd.url == url.partition('//')[2]
    assert hd.test() == 'testtest'

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:04:13.196028
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from io import BytesIO
    import http.server
    import threading
    import urllib.parse
    import socketserver
    import time

    # Runs HTTP server for testing HttpFD.real_download()
    class TestHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
        def do_GET(self):
            if self.path == '/test_filesize_xattr':
                # Test that writing of filesize xattr is performed when
                # `test:xattr_set_filesize` query parameter is set
                if 'test:xattr_set_filesize' not in self.headers:
                    self.send_response(400)
                    self.send_header('Content-Type', 'text/plain')
                    self.end_headers()
                    self.wfile.write(b'filesize xattr must be set')

# Generated at 2022-06-22 07:04:16.575091
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def open_url(url):
        return HttpFD(url, {'noprogress': True})
    run_fd_test(open_url)



# Generated at 2022-06-22 07:04:28.933705
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil
    import re
    import sys
    import os

    from .compat import (
        compat_urllib_request, compat_urllib_error, compat_urlparse,
        compat_http_server,
    )

    from .utils import (
        encodeFilename,
        format_bytes,
        format_seconds,
        sanitize_open,
    )

    from .extractor import get_info_extractor

    from .jsinterp import JSInterpreter

    class MockServer(compat_http_server.HTTPServer):
        """ Minimal HTTP Server that supports a GET method """

        def finish_content(self, code, content_type, body):
            self.send_response(code)
            self.send_header('Content-type', content_type)
            self

# Generated at 2022-06-22 07:04:30.732353
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return HttpFD(None, params={'quiet': True}, info_dict={})

# Generated at 2022-06-22 07:04:44.285317
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test HttpFD._real_download()
    from youtube_dl.utils import encodeFilename, sanitize_open

    # test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    test_url = 'http://www.youtube.com/get_video_info?&video_id=BaW_jenozKc&el=detailpage&ps=default&eurl=&gl=US&hl=en'
    # test_url = 'https://r8---sn-p5qlsnss.googlevideo.com/videoplayback?expire=1449119401&sver=3&fexp=9408710%2C9416126%2C9416891%2C9418153%2C9420452%2C9422596%2C94

# Generated at 2022-06-22 07:04:56.019880
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import TextIOWrapper

    from .downloader import SameFileError
    from .extractor.common import InfoExtractor
    from .postprocessor import embedthumbnail
    from .utils import encode_data_uri

    # Test with a custom http_headers dict:
    http_headers = {'User-Agent': 'Test'}
    http_fd = HttpFD(
        InfoExtractor(), 'http://example.com/video.mp4',
        http_headers=http_headers)
    assert http_fd.ydl.headers == http_headers

    # HTTP
    http_fd = HttpFD(
        InfoExtractor(), 'http://example.com/video.mp4')
    assert http_fd.url == 'http://example.com/video.mp4'

# Generated at 2022-06-22 07:05:09.380739
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    # Create the dir where to save the downloaded file
    download_dir = '__downloads__'
    if not os.path.isdir(download_dir):
        os.mkdir(download_dir)

    # Download a small mp3 file (5 MB)
    file_url = 'http://www.villagegeek.net/downloads/misc/test5M.mp3'
    # file_url = 'http://www.villagegeek.net/downloads/misc/test1G.mp3'

    # Create a YDL object

# Generated at 2022-06-22 07:05:21.196940
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create an instance of HttpFD
    h = HttpFD(None, {'nooverwrites': True, 'continuedl': True,
                      'continuedl_threshold': 0, 'ratelimit': 200000,
                      'retries': 10, 'fragment_retries': 10, 'fragment_size': 52428800,
                      'buffersize': 16384, 'noresizebuffer': True,
                      'test': True, 'min_filesize': 100, 'max_filesize': 100000,
                      'skip_unavailable_fragments': True, 'playlist_items': [1, 2, 3, 4],
                      'playlist_start': 3, 'playlist_end': 4},
                     None, None, None)

    # Assert parameters are correctly set for this instance
    assert not h

# Generated at 2022-06-22 07:05:54.692651
# Unit test for constructor of class HttpFD
def test_HttpFD(): # pylint: disable=W0613
    """Unit test for constructor of class HttpFD."""
    fd = HttpFD(None, None, None)
    assert fd.read(None) == ''
    fd.close()



# Generated at 2022-06-22 07:06:05.570328
# Unit test for constructor of class HttpFD

# Generated at 2022-06-22 07:06:17.416860
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .compat import urlparse, compat_HTTPError, compat_urllib_error
    from .utils import encodeFilename

    #
    # Mocked urlopen
    #
    class MockResponse(object):
        def __init__(self, content_length, info_props=None, reason=None, headers={}):
            self._fieldnames = ['url', 'code', 'msg', 'hdrs', 'fp']
            self._content_length = content_length
            self._info_props = info_props or {}
            self._reason = reason
            self._headers = headers

        def info(self):
            info = httplib.HTTPMessage(StringIO(''))
            if self._content_length is not None:
                info.addheader('Content-Length', str(self._content_length))
           

# Generated at 2022-06-22 07:06:18.331511
# Unit test for constructor of class HttpFD
def test_HttpFD():
    return HttpFD().test()

# Generated at 2022-06-22 07:06:30.439522
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import get_info_extractor

    # Test basic functionality
    ie = get_info_extractor('Youtube', downloader=FakeYoutubeDL())
    ie.extract('BgAlQuqzl8o')
    ie['url'] = 'http://www.youtube.com/get_video_info?&video_id=BaW_jenozKc&el=detailpage&ps=default&eurl=&gl=US&hl=en'
    ie.extract('BaW_jenozKc')

    # Test handly available options

# Generated at 2022-06-22 07:06:43.327199
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create a file-like object that consumes the data written to it
    class Consumer:
        def write(self, data):
            pass

    # Create a file descriptor which returns the Consumer object on open()
    class FD:
        def __init__(self, name, mode):
            pass
        def __enter__(self):
            return Consumer()
        def __exit__(self, *args):
            pass

    # Create a HttpFD object for testing purposes
    filename = "consumer://"
    test_hfd = HttpFD(FD, filename, {})

    # Test simple write() function
    data = "test"
    test_hfd.write(data)

    # Test write() function with a different type for data
    data = bytes(data, "UTF-8")
    test_hfd.write(data)

   

# Generated at 2022-06-22 07:06:53.476635
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Test the constructor of HttpFD
    """
    from .retry import RetryDownload
    from .downloader import DownloadError
    from .common import ContentTooShortError

    # Test the case of success
    try:
        fd = HttpFD(
            'http://example.com',
            params={'test_option': 'test_value'},
            retry=RetryDownload(3, errors=(IOError,)),
            headers={'User-Agent': 'unit-test'},
            hook=None
        )
    except DownloadError:
        raise AssertionError('Unexpected DownloadError instance')


# Generated at 2022-06-22 07:07:02.774409
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class FileSizeSetter:
        def __init__(self, filesize=None):
            self.filesize = filesize
        def set_filesize(self, filesize):
            self.filesize = filesize
    fss = FileSizeSetter()
    def on_progress(info):
        if 'total_bytes' in info:
            fss.set_filesize(info['total_bytes'])

    req = compat_urllib_request.Request('http://127.0.0.1:12345/test.dat')

    # Test unsupported scheme
    data = compat_urllib_request.urlopen(req)
    h = HttpFD(data, 'test.dat', {'test': True}, on_progress)
    assert h.handle is None
    assert h.filesize is None

    # Test

# Generated at 2022-06-22 07:07:13.696710
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Make sure that HttpFD class constructor works as expected."""

    class FakeYDL(object):
        def __init__(self):
            self.params = {'test': True}

    fd = HttpFD(FakeYDL(), {'url': 'http://127.0.0.1/foo.bar'}, {'test': True})
    assert fd.ydl is not None
    assert fd.ydl.params['test']
    assert fd.info_dict == {}
    assert fd.url == 'http://127.0.0.1/foo.bar'
    assert not fd.continued_dl
    assert fd.params['test']



# Generated at 2022-06-22 07:07:26.297926
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    for mode in [ 'td', 'tb', 'b' ]:
        stream = io.BytesIO()
        def stream_read(n):
            stream.seek(0)
            return stream.read(n)
        def stream_write(v):
            stream.seek(0)
            stream.write(v)
        stream.read = stream_read
        stream.write = stream_write
        # test file with known md5
        test_data = b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
        chunk_size = 16
        stream.write(test_data)
        # original test data size
        test_data_len = len(test_data)
        # lets simulate download of odd sized file (93939

# Generated at 2022-06-22 07:08:33.537483
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from _ytdl_http_client import HttpClient

    def test_read_block(self, size=-1):
        h = open(os.path.join(os.path.dirname(__file__), 'HttpFD.test_read_block'), 'rb')
        data = h.read(size)
        h.close()
        return data

    h = HttpFD('http://localhost/', test_read_block, {}, {'test': 'value'})

    assert h.get_headers() == {
        'User-Agent': std_headers['user-agent'],
        'test': 'value',
    }

    assert h.get_url() == 'http://localhost/'
    assert not h.isclosed()
    assert h.headers['test'] == 'value'
    assert h.read(4)

# Generated at 2022-06-22 07:08:45.805554
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Few basic tests
    # Encoding
    assert(Derp().real_download(dict(url='http://google.com', downloader='foo',
                                     filename='\xe1\xe9\xed\xf3\xfa.mp4')) is False)
    assert(Derp().real_download(dict(url='http://google.com', downloader='foo',
                                     filename='abc')) is False)
    # Test file length and seek
    assert(Derp().real_download(dict(url='http://google.com', downloader='foo',
                                     filename='abc')) is False)
    assert(Derp().real_download(dict(url='http://google.com', downloader='foo',
                                     filename='abc')) is False)
    # Test live downloading

# Generated at 2022-06-22 07:08:57.261035
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    stream, tmpfilename = sanitize_open('-', 'wb')
    assert stream
    assert tmpfilename == '-'
    stream.write(b'a')

    fd = HttpFD()
    fd.report_resuming_byte = lambda x: None
    fd.report_retry = lambda x, y, z: None
    fd.report_destination = lambda x: None
    fd.to_screen = lambda x: None
    fd.to_stderr = lambda x: None
    fd.report_error = lambda x: None
    fd.report_unable_to_resume = lambda: None
    fd.report_file_already_downloaded = lambda x: None
    fd._hook_progress = lambda x: None

# Generated at 2022-06-22 07:09:03.833492
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:09:16.159157
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # code copied from __main__.py

    def get_filepath(filename):
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    print('Testing method real_download of class HttpFD...')
    # name of video file to be downloaded (located in the same directory as this file)
    FILENAME = 'http_basic_auth.mp4'
    # temp file name
    TMP_FILENAME = 'http_basic_auth.tmp'

    # set parameters

# Generated at 2022-06-22 07:09:27.873896
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if sys.hexversion < 0x2060000:
        # Python 2.5 bug http://bugs.python.org/issue3905
        return
    import tempfile, shutil, os, time


# Generated at 2022-06-22 07:09:38.640240
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # This function does not test the actual download part, it tests that the
    # _real_download method performs the appropriate number of retries, and
    # that it handles various socket errors appropriately.
    select = compat_select.select
    urlopen = compat_urllib_request.urlopen

    # select() used in HttpFD
    class FakeSocket(object):
        def fileno(self):
            return -1

    class FakeTime(object):
        def time(self):
            return 0

        def sleep(self, _):
            pass

    class FakeHeadRequest(object):
        def __init__(self, headers):
            self.headers = headers

        def get_full_url(self):
            return 'url'


# Generated at 2022-06-22 07:09:50.608042
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    # Test stream
    test_stream = io.BytesIO()
    test_stream.name = 'test_stream'
    test_stream.mode = 'wb'
    test_stream.write(b'a' * 10)
    test_stream.write(b'\x00')
    test_stream.write(b'b' * 30)
    test_stream.mode = 'rb'
    fd = HttpFD(test_stream, 10, 20)
    print('Test stream name: %s' % fd.name)
    print('Test stream mode: %s' % fd.mode)
    assert fd.read(10) == b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 07:10:02.509828
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    ydl = FakeYDL()
    ydl.params['continuedl'] = False
    ydl.params['format'] = 'bestvideo+bestaudio'
    fd = HttpFD(ydl, {
                'url': 'http://127.0.0.1/video.mp4',
        'http_headers': {'User-Agent': 'test'},
        'test': True,
    })
    ok = fd.real_download()
    assert ok
    assert fd.urlhandle.geturl() == 'http://127.0.0.1/video.mp4'
    assert fd.urlhandle.get_method() == 'GET'
    assert fd.urlhandle.get_header('User-Agent') == 'test'
    assert fd.urlhandle.read() == b'video'
   

# Generated at 2022-06-22 07:10:10.777527
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    class MockFD(object):
        def __init__(self):
            self.encoding = sys.stdout.encoding
            self.isatty = sys.stdout.isatty()
    fd = HttpFD(MockFD(), params={
        'usenetrc': False,
        'username': None,
        'password': None,
        'twofactor': None,
        'videopassword': None,
        'verbose': True,
        'quiet': False,
    })

# Generated at 2022-06-22 07:12:50.415687
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://localhost/')
    assert fd.url == 'http://localhost/'
    assert fd.headers == {}
    assert fd.filename is None
    assert fd.test is False
    assert fd._TEST_FILE_SIZE == 1024 * 256

    # Test with unicode URL and filename
    fd = HttpFD(u'http://localhost/привет', u'файл')
    assert isinstance(fd.url, compat_str)
    assert isinstance(fd.filename, compat_str)

    # Test with unicode URL and filename in non-ascii directory
    dirname = u'директория'

# Generated at 2022-06-22 07:13:00.896413
# Unit test for method real_download of class HttpFD