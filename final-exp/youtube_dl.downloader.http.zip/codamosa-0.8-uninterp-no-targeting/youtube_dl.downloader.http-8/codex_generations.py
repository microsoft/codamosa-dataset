

# Generated at 2022-06-22 07:03:58.002887
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def test(self, *args, **kwargs):
        self.to_screen('TESTING FUNCTION')
        try:
            ret = self.real_download(*args, **kwargs)
        except Exception as err:
            self.to_screen('[out]', str(err))
            raise
        self.to_screen('[out]', ret)
        self.to_screen('[out]', 'END TEST')
        return ret

    HttpFD.real_download = types.MethodType(test, HttpFD())
    HttpFD.__init__(HttpFD(), params={})

# HttpFD.real_download = types.MethodType(test_HttpFD_real_download, HttpFD())
HttpFD.__init__(HttpFD(), params={})

DEBUG = True
my_dl_op

# Generated at 2022-06-22 07:04:03.500276
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params = { 'noprogress': True, 'quiet': True }
    test = HttpFD(params)
    assert test.params == params


# Generated at 2022-06-22 07:04:14.187958
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile

    tempdir = tempfile.mkdtemp('.test_youtube_dl_HttpFD')

    # construct HttpFD
    from .FileDownloader import FileDownloader
    fd = HttpFD(FileDownloader({}), {'outtmpl': tempdir + os.sep + '%(id)s.%(ext)s'}, {'id': 'testid', 'ext': 'mp4'})

    # test read
    assert fd.read() == b"Test String"

    # test close
    fd.close()

    # test read after close
    assert fd.read() == b''

    # cleanup
    import shutil
    shutil.rmtree(tempdir)

if __name__ == '__main__':
    import doctest
    doctest.testmod()


# Generated at 2022-06-22 07:04:26.787526
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    # Setup test environment
    def urlopen(req):
        class FakeSocket(StringIO):
            def makefile(self, _mode, _other):
                return self

        self = FakeSocket('testing download')
        self.info = lambda: {'Content-Length': len('testing download')}
        self.geturl = lambda: req.get_full_url()
        return self

    # Test download

# Generated at 2022-06-22 07:04:40.363603
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys

    import ssl

    # The following code works only when running this test directly (python
    # downloader/http.py or python -m youtube_dl.downloader.http).
    # The reason is that HttpFD is in downloader.py but http.py can't import
    # it, because of the circular dependency.
    if __name__ == '__main__':
        sys.path.append('.')
        # In python3 http.py is a module, and it needs to be imported as
        # youtube_dl.downloader.http.
        import youtube_dl.downloader.http as http_module
        HttpFD = http_module.HttpFD

    # Download sample file via SSL

# Generated at 2022-06-22 07:04:53.249159
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # https://github.com/rg3/youtube-dl/issues/182
    # https://github.com/rg3/youtube-dl/issues/1716
    # https://github.com/rg3/youtube-dl/issues/1821
    import tempfile
    import shutil

    # The size of the test file
    testfile_size = 2 * 1024 * 1024 # 2 MiB
    test_proto_url = 'https'
    test_url = '%s://example.org/test' % test_proto_url

    # Test HTTP-headers

# Generated at 2022-06-22 07:05:00.562628
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO

    def get_info(name):
        return {
            'url': 'http://localhost/%s' % name
        }

    def get_urlh(name, info, fd):
        return compat_urllib_request.urlopen(compat_urllib_request.Request(info['url'], data=fd))

    def test_HttpFD_read_connection_reset(name):
        info = get_info(name)
        with open('README.md', 'rb') as f:
            fd = HttpFD(
                info, get_urlh,
                f, None, lambda s: s)
            data = fd.read(16 * 1024)
            assert len(data) == 16 * 1024
            data += fd.read()

# Generated at 2022-06-22 07:05:11.048426
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import subprocess
    from .utils import encodeFilename, encodeArgument

    def get_file_offset(filename):
        dev = os.stat(encodeFilename(filename)).st_dev
        out, _ = subprocess.Popen(
            ['hdparm', '--fibmap', filename],
            stdout=subprocess.PIPE).communicate()
        for line in out.decode('utf-8').splitlines():
            if line.startswith('/dev/'):
                # Check if file is on 'filename' device
                if os.stat(line.split()[0]).st_dev == dev:
                    return int(line.split()[1])
        # Raise an exception in case offset is not found (it would not be cached properly in this case)

# Generated at 2022-06-22 07:05:21.095746
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import socket
    import tempfile
    import urllib2
    import youtube_dl.utils

    url = 'https://upload.wikimedia.org/wikipedia/commons/d/dd/Wikipedia_article_-_Birdsfoot_trefoil.ogg'
    request = urllib2.Request(url)
    password_mgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
    opener = urllib2.build_opener(urllib2.HTTPBasicAuthHandler(password_mgr))
    urllib2.install_opener(opener)

    # Test HTTP GET
    _http_fd = HttpFD(url, request, False, None, None)
    assert _http_fd.real_url == url
    assert _http_fd.status == 200
    assert _http_fd.content_

# Generated at 2022-06-22 07:05:25.653616
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile

    # Read binary data
    fd, fname = tempfile.mkstemp(prefix='youtube-dl-test_')
    os.write(fd, b'\xa5' * 10000)
    os.close(fd)

    # Open test file using a constructor of class HttpFD
    hfd = HttpFD(fname, 0, 100)
    assert hfd.read(20) == b'\xa5' * 20

    # Try to read more than available
    assert hfd.read(20000) == b'\xa5' * 9980

    # Read and seek to a specific position
    hfd.seek(42)
    assert hfd.read(20) == b'\xa5' * 20

    # Read after seeking beyond the end of the file
    hfd.seek(10000)
   

# Generated at 2022-06-22 07:06:03.338811
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import shutil
    import re
    from .compat import compat_mock

    _TEST_FILE_SIZE = 100
    _CTX = {'tmpfilename': '-'}

    class MockUrlopen(object):
        def __init__(self, headers, data=None):
            self._headers = headers
            self._data = data
            self.req = None
            self.resp_headers = None

        def __call__(self, req):
            self.req = req
            self.resp_headers = self._headers
            return self

        def info(self):
            return self.resp_headers

        def read(self, sz):
            if self._data is None:
                return b'\x00' * sz
            d = self._data[:sz]
            self._data

# Generated at 2022-06-22 07:06:15.752781
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor.common import InfoExtractor
    from .utils import urlopen

    class DummyIE(InfoExtractor):
        IE_DESC = 'Dummy IE'

        def report_warning(self, message, video_id=None):
            pass

        def report_error(self, message, video_id=None, tb=None):
            pass

    def testdownload(ie_cls):
        """Tests the given InfoExtractor for all of its supported protocols"""
        ie = ie_cls(DummyIE, None)


# Generated at 2022-06-22 07:06:28.068165
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # No resuming
    h1 = HttpFD('http://localhost:8080/?file=File', None, {'nopart': True, 'continuedl': False})
    assert h1.filenumber == 0
    assert h1.tries == 0
    assert h1.retries == 10
    assert h1.endbyte == None
    assert h1.filename == 'File'
    assert h1.tmpfilename == 'File.part'
    assert not h1.continuedl
    assert not h1.noprogress
    assert h1.headers == {}

    # Resuming
    h2 = HttpFD('http://localhost:8080/?file=File', None, {'nopart': True, 'continuedl': True})
    assert h2.filenumber == 0
    assert h2.tries

# Generated at 2022-06-22 07:06:38.209931
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params = {
        'usenetrc': False,
        'username': 'user',
        'password': 'pass',
        'ap_mso': 'foo',
        'ap_username': 'bar',
        'nopart': True,
        'retries': 10,
        'continuedl': True,
        'nofort': False,
    }
    ydl = FakeYDL()
    df = HttpFD(ydl, params)
    assert df.ydl is ydl
    assert df.params is params
    assert df.continuedl is df.params['continuedl']
    assert df.retries is df.params['retries']

    params = {}
    df = HttpFD(ydl, params)
    assert df.params is params
    assert df.continuedl is True
   

# Generated at 2022-06-22 07:06:50.402680
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(FakeYDL(), {}, 'http://www.example.com/video.mp4')
    assert fd.url == 'http://www.example.com/video.mp4'
    assert fd.ydl is not None
    assert fd.params == {}
    assert fd.duration is None
    assert fd.start_time is None
    assert fd.tmpfilename == None
    assert fd.filename == None
    assert fd.name == 'http://www.example.com/video.mp4'
    assert not fd.closed
    assert repr(fd).startswith('<youtube_dl.postprocessor.HttpFD')
    fd.close()
    assert fd.closed


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:07:01.347471
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import re
    import shutil
    import sys
    import tempfile

    from http_utils import HttpFD
    from http_utils import sanitize_open
    from http_utils import sanitized_Request

    # Dummy subprocess module
    class DummySubprocess(object):
        PIPE = None
        Popen = None
        call = None
    # Dummy os module
    class DummyOS(object):
        path = os.path
        open = open
        remove = os.remove
        fsync = os.fsync
        utime = os.utime
        getcwd = os.getcwd
        chdir = os.chdir
        remove = os.remove
        rename = os.rename
        stat = os.stat
        environ = os.environ

# Generated at 2022-06-22 07:07:08.122875
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD(None, params={'noprogress': True})
    settings = {}
    info_dict = {}
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    test_ctx = HttpFD._DownloadContext(url, settings, info_dict)
    http_fd.real_download(test_ctx, '.')

test_HttpFD_real_download()


# Generated at 2022-06-22 07:07:21.284937
# Unit test for constructor of class HttpFD
def test_HttpFD():
    test_cases = [
        {'expected': 'http://example.com/abc', 'url': 'http://example.com/abc', 'data': None},
        {'expected': 'http://example.com/abc', 'url': 'http://example.com/abc', 'data': {'url': None}},
        {'expected': 'http://example.com/abc', 'url': 'http://example.com/abc', 'data': {'url': 'http://example.com/def'}},
    ]
    for test_case in test_cases:
        fd = HttpFD(test_case['url'], test_case['data'])
        assert fd.url == test_case['expected']
        fd.close()



# Generated at 2022-06-22 07:07:32.667711
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # This test is useful to find out why some servers give an empty response when a range header is given
    class FakeYDL(object):
        def __init__(self):
            self.params = {}
        def report_error(self, message, tb=None):
            self.message = message
            self.traceback = tb
        def report_retry(self, source_error, count, retries):
            pass
        def to_screen(self, msg):
            pass
        def to_stderr(self, msg):
            pass
        def slow_down(self, start, now, byte_counter):
            pass
        def best_block_size(self, elapsed_time, bytes_now):
            return 8192
        def calc_eta(self, start, now, total, completed):
            return None

# Generated at 2022-06-22 07:07:44.089920
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Run unit test for real_download method with one test file
    # downloaded several times, each time for different ranges.
    #
    # Required settings:
    #   'test' - name of test file to download,
    #            it must be placed in 'test_files' directory
    #            (for example 'test_files/test.mp4')
    #
    # Also, both settings 'noprogress' and 'xattr_set_filesize' are
    # required to be set to False for this unit test.
    settings = {
        'noprogress' : False,
        'test' : None,
        'noresizebuffer' : True,
        'logtostderr' : True,
        'xattr_set_filesize' : False,
        'quiet' : False,
    }

    #

# Generated at 2022-06-22 07:08:55.711439
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL()
    ydl.add_info_extractor(DummyIE())
    ydl.params['skip_download'] = True

    with open(os.path.join(TEST_OUTDIR, "test.mp4"), "wb") as f:
        hfd = HttpFD(ydl, {}, f)
        hfd.download('%s/test.mp4' % TEST_URL)

    assert os.path.exists(os.path.join(TEST_OUTDIR, "test.mp4"))
    assert os.path.getsize(os.path.join(TEST_OUTDIR, "test.mp4")) == 1000000

    os.unlink(os.path.join(TEST_OUTDIR, "test.mp4"))


# Generated at 2022-06-22 07:08:57.358471
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(sanitized_Request('http://google.com'), None, {})



# Generated at 2022-06-22 07:08:58.904605
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD(None, {})

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:09:11.461223
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    fd = HttpFD(None, { 'nooverwrites': True, 'continuedl': True })

    TEST_DATA = b'xyz'

    class MockServer(object):
        def __init__(self, port):
            self.port = port

        def start(self):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind(('localhost', self.port))
            s.listen(1)
            conn, _ = s.accept()
            conn.sendall(TEST_DATA)
            conn.close()
            s.close()

    server_port = 8998

    class MockYDL(object):
        def __init__(self, params):
            self.params = params

# Generated at 2022-06-22 07:09:23.435759
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Check correct use of constructor
    HttpFD(u'http://url', {}, None)
    HttpFD(u'http://url', {}, 0)
    HttpFD(u'http://url', {}, 1)
    HttpFD(u'http://url', {}, 'filename')
    HttpFD(u'http://url', {}, '-')
    HttpFD(u'http://url', {}, io.BytesIO())
    HttpFD(u'http://url', {}, io.BufferedReader(io.BytesIO()))
    HttpFD(u'http://url', {}, io.TextIOWrapper(io.BytesIO()))
    HttpFD(u'http://url', {}, io.BufferedReader(io.TextIOWrapper(io.BytesIO())))

    #

# Generated at 2022-06-22 07:09:31.889568
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD(None, {}, None)
    assert h.ydl is None
    assert h.params == {}

    class YDL:
        params = {}

    h = HttpFD(YDL(), {'noprogress':True}, None)
    assert h.ydl is YDL()
    assert h.params == {
        'quiet': True,
    }
    assert h.params is not YDL().params

# Generated at 2022-06-22 07:09:44.388241
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys, os, random, io
    from .extractor import get_info_extractor
    from .utils import encode_data_uri
    for ie in get_info_extractor(None):
        download = ie._downloader._do_download
        if download == HttpFD._do_download:
            break
    # Test file
    DATA_URI = 'data:text/plain,foobarbaz'
    # Test server
    class TestServerHandler(server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()

# Generated at 2022-06-22 07:09:46.069579
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(None, None, None, None, None, None).read() == b''



# Generated at 2022-06-22 07:09:56.323323
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _test_download(ctx):
        return HttpFD().real_download(ctx)

    # Test non-chunked download for non-existing file
    info_dict = {}
    ctx = _DynamicDownloadContext({'url': 'http://localhost:99999/non-existing-file.bin',
                                   'filename': 'tmp_non-existing-file.bin',
                                   'info_dict': info_dict,
                                   'test': True})
    assert not _test_download(ctx)

    # Test non-chunked download for existing file
    test_file_path = os.path.join(os.path.dirname(__file__), 'testfile.bin')
    tmp_output_file = 'tmp_testfile.bin'

# Generated at 2022-06-22 07:10:07.717410
# Unit test for constructor of class HttpFD
def test_HttpFD():
    try:
        os.remove('unittest1')
    except OSError:
        pass
    try:
        os.remove('unittest2')
    except OSError:
        pass
    fd1 = open('unittest1', 'wb')
    fd2 = open('unittest2', 'wb')
    fd1.write(b'abc')
    fd2.write(b'def')
    fd1.flush()
    fd2.flush()
    fd1.close()
    fd2.close()
    hfd = HttpFD(ydl=None, filename='unittest1', download_retry=False)
    eq_(b'abcdef', hfd.read())
    hfd.close()

# Generated at 2022-06-22 07:12:59.578889
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from types import CodeType
    from types import FunctionType
    import sys
    import types

    # Needed for testing the retry mechanism
    class RetryDownload(Exception):
        def __init__(self, cause):
            self.cause = cause
        def __str__(self):
            return str(self.cause)

    # Needed for testing the retry mechanism
    class NextFragment(Exception):
        pass

    # Needed for testing the retry mechanism
    class SucceedDownload(Exception):
        pass

    # Mocked class to make it possible to skip real download.
    #
    # We use global variables to make it possible to check
    # in unit test the results of real_download() through
    # the reason of different exceptions.
    #
    # On the same "pattern" we use the same global variables
    # to

# Generated at 2022-06-22 07:13:08.322075
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import filecmp
    import hashlib
    import tempfile
    import unittest

    class TestRealDownload(unittest.TestCase):
        URL = 'https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/version.py'
        TEST_FILE_SIZE = 1024
        TMP_FILENAME = tempfile.NamedTemporaryFile(prefix='ydl-test-').name

        def _test_real_download(self, test_file_size=None, test_resume=False):
            fd = HttpFD(self.URL)
            fd.is_test = True
            fd.params['noprogress'] = True
            fd.params['retries'] = 1
            fd.params['buffersize'] = 128
            fd.params