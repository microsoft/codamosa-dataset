

# Generated at 2022-06-22 07:03:56.804508
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestFD(HttpFD):
        def __init__(self, ydl, params):
            HttpFD.__init__(self, ydl, params)
            self.test_data = []

        def to_screen(self, s):
            self.test_data.append(s)

    ydl = DummyYDL()
    ydl.params = {'nooverwrites': True, 'continuedl': True,
                  'continuedl_retries': 10, 'noprogress': True,
                  'outtmpl': u'%(id)s-%(autonumber)s-%(height)s.%(ext)s',
                  'test': True, 'verbose': True, 'quiet': False}
    fd = TestFD(ydl, ydl.params)

    # Test that

# Generated at 2022-06-22 07:04:06.023593
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def abort(msg):
        raise RuntimeError(msg)
    params = {
        'nooverwrites': False,
        'format': 'best',
    }
    info_dict = {'ext': 'mp4'}
    url = 'https://test.test/test'
    q = queue.Queue()

# Generated at 2022-06-22 07:04:18.783891
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test without authentication
    http_fd = HttpFD(
        sanitized_Request('http://www.example.com'),
        # Test with non-ASCII username/password
        {'username': 'login', 'password': 'pass\xe3\x82\xa8\xe3\x83\x87'},
        {'test': lambda x: None})
    assert http_fd.urlh.get_full_url() == 'http://www.example.com'
    assert http_fd.real_url is None

    # Test with authentication

# Generated at 2022-06-22 07:04:30.458917
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors
    from .extractor.tests import get_testcases

    # Load all extractors (to register extractors)
    gen_extractors()

    # Parse all testcases
    for tc in get_testcases():
        for ie in gen_extractors(suitable=lambda ie: ie.IE_NAME in (tc.get('extractor'), tc.get('ie_key'))):
            try:
                ie.extract_info(tc['url'], download_mode=False)
                break
            except Exception as e:
                pass
        else:
            raise ValueError('Testcase %r has no working extractors' % tc)


if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:04:44.190867
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL()
    ydl.params['logger'] = MockLogger()
    ydl.params['noprogress'] = True

    url = "http://www.example.com/video.mp4"
    content_type = 'video/mp4'
    headers = {
        'Content-Type': content_type,
    }
    content_length = '1024'
    expected_content_range = 'bytes 0-1023/%s' % content_length
    ctx = {
        'url': url,
        'fp': BytesIO(),
        'headers': headers,
    }

    fd = HttpFD(ydl, ctx, 1024)

    assert fd.url == 'http://www.example.com/video.mp4'
    assert fd.headers['Content-Type']

# Generated at 2022-06-22 07:04:55.978692
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import socket
    from .utils import sanitize_open, encodeFilename, write_xattr
    # Setup a mock socket to return a pdf with the first 1048576 bytes
    # consisting of 'foo' and the rest 'bar'.
    #
    # Inspired by http://stackoverflow.com/a/16861406/35070
    data = ''.join(['f' for _ in range(0, 1048576)]) + ''.join(['b' for _ in range(0, 1234)])
    data = io.BytesIO(data)
    def recv_some(*args, **kwargs):
        return data.read(*args, **kwargs)
    def recv_all(*args, **kwargs):
        return data.read(*args, **kwargs)

# Generated at 2022-06-22 07:05:09.334453
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Prepare
    fd = HttpFD(FakeYDL(), {
        'continuedl': True,
        'nooverwrites': True,
        'noprogress': True,
        'quiet': True,
        'ratelimit': 200000,  # 200KB/s
    })
    # for the record:
    #   * open_mode = 'wb'
    #   * chunk_size = 0 (non-chunked download)
    #   * resume_len = 0
    #   * tmpfilename = '-' (stdout)
    #   * filename = '-' (stdout)
    #   * data = None
    #   * stream = None
    #   * data_len = None
    #   * block_size = 1024*8 (8KB)
    #   * has_range = False


# Generated at 2022-06-22 07:05:21.129957
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import warnings
    import os
    import tempfile
    import shutil
    import sys
    import threading
    import socket
    import time
    import math
    import hashlib
    import string
    import random

    def _random_string(N=10):
        return ''.join([random.choice(string.letters) for x in range(N)])

    def _timestamp():
        return math.floor(time.time())

    def _find_free_port(ip='127.0.0.1'):
        '''Returns a random free port number on localhost'''
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((ip, 0))
        addr, port = s.getsockname()
        s.close()
        return port

    # TOD

# Generated at 2022-06-22 07:05:25.691388
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import youtube_dl.FileDownloader
    class TestHttpFD(HttpFD):
        def report_error(self, desc):
            raise DownloadError(desc)
        def report_retry(self, desc, count, retries):
            pass
    test_downloader = youtube_dl.FileDownloader.FileDownloader({})
    test_downloader.ydl = FakeYDL()
    test_downloader.params = {
        'nooverwrites': True,
        'continuedl': True,
        'noprogress': True,
        'logger': test_downloader,
    }
    test_downloader.add_info_extractor(FakeInfoExtractor())

# Generated at 2022-06-22 07:05:35.861543
# Unit test for constructor of class HttpFD

# Generated at 2022-06-22 07:06:19.499829
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import io
    import requests

    data = b'abcdefghij'
    data_len = len(data)

    data_stream = io.BytesIO(data)
    h = requests.head('http://localhost/')
    hfd = HttpFD(data_stream, h.headers)

    assert hfd.read(5) == b'abcde'
    assert hfd.read(1) == b'f'
    assert hfd.read(None) == b'ghij'
    assert hfd.read() == b''

    assert hfd.tell() == data_len

    assert hfd.headers['Content-Length'] == str(data_len)

    assert hfd.read1(3) == b'abc'
    assert hfd.read1(2) == b'de'
    assert hfd.read

# Generated at 2022-06-22 07:06:27.360497
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test exception when no url
    try:
        HttpFD(None, {})
        assert False, 'Expected exception'
    except AssertionError:
        pass
    # Test without test option
    http_fd = HttpFD('http://www.google.com', {})
    # Test with test option
    http_fd = HttpFD('http://www.google.com', {'test': True})
    http_fd.test('http://www.google.com')


# Generated at 2022-06-22 07:06:37.697896
# Unit test for constructor of class HttpFD

# Generated at 2022-06-22 07:06:49.861569
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from io import BytesIO
    from collections import namedtuple
    from .utils import sanitize_open
    from .extractor.common import InfoExtractor

    # Can't run the test on AppVeyor (https://github.com/ytdl-org/youtube-dl/issues/5229)
    if 'APPVEYOR' in os.environ:
        return

    # Helper functions to configure test cases
    class FakeYDL:
        def __init__(self):
            self.params = {'ratelimit': 0}


# Generated at 2022-06-22 07:07:01.026595
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    # Test retries
    with open(os.path.join(os.path.dirname(__file__), '__init__.py'), 'rb') as fd:
        fd.readline()
        (filename, headers) = fd._test_real_download(
            {'retries': 10, 'fragment_retries': 10},
            'http://localhost:25555/__init__.py',
            {'Content-Length': '47'},
            None,
            None)
        assert not os.path.exists(filename)
        assert filename.endswith('.part')
        assert headers['Content-Length'] == '47'
        os.unlink(filename)
        # Test Content-Length sensitivity

# Generated at 2022-06-22 07:07:04.903673
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, param={'test_option': 'foobar'})
    assert hasattr(fd, 'test_option') and fd.test_option == 'foobar'



# Generated at 2022-06-22 07:07:17.823972
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """Test the constructor of HttpFD"""
    import argparse
    h = HttpFD()
    parser = argparse.ArgumentParser()
    h.add_progress_hooks(parser)
    (args, _) = parser.parse_known_args()

    # Test the default value of --test
    assert not args.test

    # Test unknown options
    try:
        parser.parse_args(['--unknown-option'])
    except SystemExit:
        pass
    else:
        assert False, 'Expected exit on unknown options'

    # Test failure on option without argument
    try:
        parser.parse_args(['--noprogress'])
    except SystemExit:
        pass
    else:
        assert False, 'Expected exit on incorrect options'

    # Test filename parsing

# Generated at 2022-06-22 07:07:29.775602
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:07:40.293922
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os

    # create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    filename = tmp_file.name
    tmp_file.close()

    # dummy class that mimics an info dict
    class Info:
        def __init__(self, length):
            self.length = length

    def urlopen(url, length):
        # dummy urlopen that returns a dummy file object
        class Response:
            def __init__(self, length):
                self.length = length

            def read(self, blksize):
                data = os.urandom(blksize)
                if self.length is not None:
                    self.length -= len(data)
                    if self.length < 0:
                        data = data[:self.length]
                return data


# Generated at 2022-06-22 07:07:53.257710
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import re
    import shutil
    import subprocess
    import tempfile
    import urllib

    temp_dir = tempfile.mkdtemp(prefix='youtube_dl_tests-')

    # Prepare a test web server
    server_proc = subprocess.Popen(['python', '-c', _TEST_WEBSERVER_SCRIPT],
        cwd=temp_dir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in iter(server_proc.stdout.readline, ''):
        if re.match(r'^Ready for requests', line):
            break

    # Test data

# Generated at 2022-06-22 07:08:55.277033
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # TODO
    pass


# Generated at 2022-06-22 07:09:03.690095
# Unit test for constructor of class HttpFD
def test_HttpFD():
    params = {'usenetrc': False}
    http_stdout_fd = HttpFD(params, None, '-')
    assert http_stdout_fd.download(None) == True
    assert http_stdout_fd.download(None) == None
    http_stdout_fd.report_retry('fake error', 2, 5)
    http_stdout_fd.report_retry('fake error', 5, 5)
    http_stdout_fd.report_finish()
    http_stdout_fd.report_unable_to_resume()
    http_stdout_fd.report_resuming_byte(1)
    http_stdout_fd.report_destination(None)
    http_stdout_fd.report_error('fake error')
    http_stdout_fd.to

# Generated at 2022-06-22 07:09:06.479019
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    assert None is HttpFD_real_download()
# Unit tests for method real_download of class HttpFD
# @unittest.skip

# Generated at 2022-06-22 07:09:18.878023
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import get_info_extractor
    from .extractor.common import InfoExtractor

    class FakeYDL(object):
        def __init__(self, params={}):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'simulate': True,
                'outtmpl': '-',
                'geo_bypass': False,
                'geo_verification_proxy': '',
                'max_filesize': None,
                'min_filesize': None,
            }
            self.params.update(params)
            self.to_screen = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None

        def urlopen(self, *args, **kargs):
            return

# Generated at 2022-06-22 07:09:20.970995
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(None, None, None)



# Generated at 2022-06-22 07:09:27.112100
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL({'simulate': True, 'quiet': True})
    fd = HttpFD(ydl, 'http://archive.org/download/ksnn_compilation_master_the_internet/ksnn_compilation_master_the_internet_512kb.mp4')
    assert fd.data_len is None or fd.data_len > 0
    assert len(fd.read(1000)) > 0


# Generated at 2022-06-22 07:09:38.402716
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def do_test(self, test_tmppath):
        # Test downloading a file
        data = b'Hello World!'
        test_data_len = len(data)
        urlh = FakeUrlOpenHandler(data)
        self.ydl = FakeYDL(urlopen_handler=urlh)
        test_url = 'http://fake_url/'
        test_filename = os.path.join(test_tmppath, 'file')
        test_tmpfilename = test_filename + '.part'
        test_ctx = FDContext(test_tmpfilename, {'url': test_url})
        self.assertTrue(self.real_download(test_ctx))
        self.assertEqual(urlh.requests[0], sanitized_Request(test_url))

# Generated at 2022-06-22 07:09:47.313337
# Unit test for constructor of class HttpFD
def test_HttpFD():
    ydl = YoutubeDL(params={'noprogress':True})
    # Fake sys.stdout.isatty() to get the progresshook working
    try:
        sys.stdout.isatty = lambda: True
        h = HttpFD(ydl, {}, None, '-')
        assert h.download(None)
        h = HttpFD(ydl, {}, None, '-')
        assert h.download(None)
    finally:
        del sys.stdout.isatty


# Generated at 2022-06-22 07:09:52.405239
# Unit test for constructor of class HttpFD
def test_HttpFD():
    assert HttpFD(
        'http://www.google.com/',
        {'http_chunk_size': 16 * 1024, 'http_connect_timeout': 5.0, 'http_proxy': '192.168.0.1:8080'}
    ).geturl() == 'http://www.google.com/'


# Generated at 2022-06-22 07:10:02.386899
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def hook(status):
        print('Hook called with %s' % status)

    fd = HttpFD()
    fd.params = {'noprogress': True}
    fd.add_progress_hook(hook)

    # Test "Content-Range" header handling
    res = fd.real_download(
        'https://github.com/rg3/youtube-dl/raw/master/README.md',
        {'test': True},
        '-',
        SubtitleFD(None, True),
        {'test_range': (0, fd._TEST_FILE_SIZE - 1)}
    )
    assert res
    fd.remove_progress_hook(hook)



# Generated at 2022-06-22 07:12:41.072897
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals

    def write_socket(data):
        """Simulates a socket"""
        if len(data) < block_size:
            return ''
        if len(data) > block_size:
            return data[block_size:]
        return None

    def read_socket(bytes_to_read):
        """Simulates a socket"""
        if download_size < file_size and bytes_to_read <= block_size:
            raise socket.timeout()
        data_chunks.append(bytes_to_read)
        if total_downloaded_bytes + bytes_to_read > file_size:
            # Read and return less bytes than requested
            bytes_to_read = file_size - total_downloaded_bytes

# Generated at 2022-06-22 07:12:52.640416
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.example.com/',
                {'test_param': 'test_val'},
                {'test_header': 'test_header_val'},
                u'filename',
                {'test_info': 'test_info_val'})

    assert fd.url == 'http://www.example.com/'
    assert fd.params['test_param'] == 'test_val'
    assert fd.headers['test_header'] == 'test_header_val'
    assert fd.filename == 'filename'
    assert fd.info['test_info'] == 'test_info_val'

    assert re.match(r'\w{8}\.part', fd.tmpfilename)
    assert fd.tmpfilename != fd.filename


# Generated at 2022-06-22 07:13:02.886338
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:13:09.635629
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class MyDownloader(HttpFD):
        def __init__(self):
            self.params = {
                'username': 'user',
                'password': 'pass',
            }
            HttpFD.__init__(self)

    myd = MyDownloader()
    assert myd.get_auth_header() == 'Basic dXNlcjpwYXNz'
    myd.params['username'] = 'user with spaces'
    myd.params['password'] = 'pass with spaces'
    assert myd.get_auth_header() == 'Basic dXNlciB3aXRoIHNwYWNlczpwYXNzIHdpdGggc3BhY2Vz'


# Open a local file or download it if it doesn't exist.
# Returns a file descriptor.
