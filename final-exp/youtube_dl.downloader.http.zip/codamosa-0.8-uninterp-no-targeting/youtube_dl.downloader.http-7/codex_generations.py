

# Generated at 2022-06-22 07:03:47.141091
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://127.0.0.1:1/', {
        'noprogress': True,
        'quiet': True,
        'test': True,
    })
    assert isinstance(fd, HttpFD)
    assert not fd.prog_bar


# Generated at 2022-06-22 07:03:52.279535
# Unit test for constructor of class HttpFD
def test_HttpFD():
    """
    Test if HttpFD constructor raises an exception if an incorrect
    parameter is passed.
    """
    # Wrong type of ytdl parameter
    assert_raises(TypeError, HttpFD, None, {})


# Generated at 2022-06-22 07:04:03.021615
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    import socket
    import tempfile
    import os.path

    class _FakeYDL(object):
        def __init__(self):
            self.params = {
                'nooverwrites': True,
            }

        def urlopen(self, request):
            class _FakeData(object):
                def __init__(self, headers):
                    self.headers = headers

                def info(self):
                    return self.headers

                def read(self, n):
                    return b'\0' * n
            expected_range = request.headers.get('Range', None)
            if expected_range is None:
                data_len = _TEST_FILE_SIZE
            elif expected_range == 'bytes=%d-' % (_TEST_FILE_SIZE // 2, ):
                data_len = _TEST_FILE_

# Generated at 2022-06-22 07:04:13.987426
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DownloadCtx(object):
        def __init__(self):
            self.filename = None
            self.tmpfilename = None
            self.stream = None
            self.block_size = 8192
            self.resume_len = 0
            self.data = None
            self.data_len = None
            self.is_resume = False
            self.open_mode = 'wb'
    class DummyYDL(object):
        def __init__(self):
            self._progress_hooks = []
        def add_progress_hook(self, progress_hook):
            self._progress_hooks.append(progress_hook)
        def to_stderr(self, msg):
            pass
        def to_screen(self, msg):
            pass
        def report_error(self, msg):
            print

# Generated at 2022-06-22 07:04:26.820086
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    http_fd = HttpFD()
    http_fd.params = {
        'format': 'bestaudio/best',
        'noplaylist': True,
        'nocheckcertificate': True,
        'ignoreerrors': False,
        'logtostderr': False,
        'quiet': True,
        'no_warnings': True,
        'outtmpl': '%(id)s.%(ext)s',
        'forceurl': True,
        'forcethumbnail': True,
        'forceduration': True,
        'simulate': True,
        'ratelimit': None,
        'retries': 10,
        'buffersize': 1024,
        'noresizebuffer': True,
        'test': True
    }

# Generated at 2022-06-22 07:04:31.411251
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, {'test': True}, None, {'test': True})
    assert fd.ydl is None
    assert fd.params is not None
    assert fd.info_dict is not None



# Generated at 2022-06-22 07:04:44.652463
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Run ``_real_download`` method with various block sizes and check
    it doesn't read more than the given number of bytes.

    """
    if not os.path.exists(TEST_FILE):
        pytest.skip('test file does not exist. Please download it from https://files.videolan.org/ytdl-test-files/test.ts')

# Generated at 2022-06-22 07:04:56.341209
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _test_real_download(ys, filename, use_limit=False, limit=0):
        def _test_hook(status):
            if status['status'] == 'finished':
                ys.assertTrue(status['total_bytes'] > 0)
                ys.assertEqual(status['total_bytes'], status['downloaded_bytes'])
                ys.assertTupleEqual(status['elapsed'].__class__, (float, ))
                ys.assertGreaterEqual(status['elapsed'], 0)
                ys.assertTrue(status['filename'])
                ys.assertEqual(status['tmpfilename'], '-')
            if status['status'] == 'downloading':
                ys.assertTrue(status['total_bytes'] > 0)
                ys.assertGreaterEqual

# Generated at 2022-06-22 07:05:09.640766
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import prepend_extension

    class MockIE(InfoExtractor):
        def __init__(self, downloader=None, tmpfilename='tmp'):
            super(MockIE, self).__init__(downloader)
            self.tmpfilename = tmpfilename

        def report_warning(self, message, video_id=None):
            return

        def _handle_download_error(self, video_id, context, e):
            raise

    def _test_download_retry_with_fragments(dl, ie):
        video_id = 'test'

        # Initialize download context
        dl.prepare_filename(ie, video_id)
        dl.params['outtmpl'] = prep

# Generated at 2022-06-22 07:05:17.516702
# Unit test for constructor of class HttpFD
def test_HttpFD():
    'Run a sanity check on HttpFD'
    url = 'http://www.google.com/index.html'
    h = HttpFD(url, {'logger': BaseLogger()})
    if not h.handle:
        sys.exit(1)
    if h.download_size is None:
        sys.exit(2)
    if h.download_size < 0:
        sys.exit(3)
    h.close()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:05:59.735502
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Fake urlopen
    class urlopenFake:
        def read(self, bytes):
            return b'a' * bytes
    class FakeYDL(object):
        def urlopen(self, *args, **kwargs):
            return urlopenFake()
    # Test #1: Use chunk_size
    params = {
        'noprogress': True,
        'continuedl': False,
        'logger': None,
        'test': True,
        'noresizebuffer': False,
        'prefer_insecure': False,
        'geo_verification_proxy': None,
        'bidi_workaround': False,
        'socket_timeout': None,
    }
    http_fd = HttpFD(FakeYDL(), 'http://example.org', params, '-')
    assert http_

# Generated at 2022-06-22 07:06:11.821783
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os.path
    import shutil
    import random
    import socket
    import time
    import http.client
    import threading
    import ssl
    import unittest
    import importlib.util
    import sys

    # In Python3, HTTPSHandler requests are wrapped in a socket,
    # which is problematic when we want to intercept and re-send the
    # request ourselves. This monkeypatching and the _get_connection
    # method below, taken from
    # https://stackoverflow.com/questions/26693207/
    def _monkeypatch_HTTPSConnection_get_context():
        if not hasattr(http.client.HTTPSConnection, '_get_context'):
            def _get_context(*args):
                context = ssl._create_unverified_context()
                context.check_hostname

# Generated at 2022-06-22 07:06:19.896890
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://httpbin.org/get')

    # Test setters of HttpFD class
    fd.setSize(10)
    fd.setHeaders([])
    fd.setOption('test', 'test')
    fd.setMetadata({})

    # Test methods of HttpFD class
    fd.read(1)
    fd.seek(0)
    fd.close()
    # Test readline method of HttpFD class
    assert fd.readline()



# Generated at 2022-06-22 07:06:31.063125
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if not youtube_dl.utils.htmlentity_transform:
        # Skip the test
        # (The tested code is unreachable with python2)
        return
    tf = HttpFD(_progress_hooks=[], params={})
    tf.real_download('http://www.youtube.com/watch?v=BaW_jenozKc', 'blah#☃')
    assert os.path.exists('blah#☃') and not os.path.exists('blah#☃#☃')
    os.remove('blah#☃')
    tf.real_download('http://www.youtube.com/watch?v=BaW_jenozKc', 'blah#☃#☃')
    assert os.path.exists('blah#☃#☃') and not os.path.ex

# Generated at 2022-06-22 07:06:44.071510
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import io
    import os
    import random
    import tempfile
    import unittest
    import urllib
    import urllib.request
    import urllib.parse
    import http.server

    try:
        import http.client as httplib
    except ImportError:
        import httplib

    # Copied from http.server.test

# Generated at 2022-06-22 07:06:56.041680
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # The constructor of HttpFD takes three arguements. A URL, a filename and a
    # boolean. These are used to determine if the file will be downloaded or
    # uploaded.
    #
    # If the filename is a dash ('-') and the boolean is true then the file is
    # written to standard output. The constructor does not check this. If a
    # filename is given and the boolean is false then a POST request is issued
    # to the server instead of a GET request.
    assert_equal(HttpFD('http://localhost:20000/', '-').url, 'http://localhost:20000/')
    assert_equal(HttpFD('http://localhost:20000/', '-', False).url, 'http://localhost:20000/')

    # When a filename is given and the boolean is true then a GET request will
    # be

# Generated at 2022-06-22 07:07:07.298464
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .compat import urlopen  # to test importing
    from .utils import encodeFilename  # to test importing

    class ContextManagerStub:
        def __init__(self, stream):
            self.stream = stream

        def __enter__(self):
            return self.stream

        def __exit__(self, exc_type, exc_value, traceback):
            return False  # don't swallow exceptions

    class OpenerDirector:
        def open(self, request):
            return ContextManagerStub(BytesIO(b'datadata'))

    class DummyYDL:
        params = {}
        http_header_dict = {}

        @staticmethod
        def to_screen(a):
            pass

        @staticmethod
        def to_stderr(a):
            pass


# Generated at 2022-06-22 07:07:20.718914
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import time
    import random
    import gc
    from retrying import RetryError

    class ProgressHook:
        def __init__(self):
            self.prev_status = None

        def __call__(self, status):
            if self.prev_status is None:
                if status['status'] == 'downloading' and status['elapsed'] == 0:
                    print('Test is not yet ready. Waiting for a few seconds to make test more reliable ...')
                    time.sleep(5)
                self.prev_status = status

# Generated at 2022-06-22 07:07:32.027603
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def open_testfile(filename):
        return open(encodeFilename(filename), 'rb')

    hd = HttpFD(FakeYDL({'nooverwrites': True, 'continuedl': True, 'quiet': True}), {'simulate': True})

    hd.report_destination = lambda *x: None
    hd.report_progress = lambda *x: None

    class test_context:
        data_len = None
        filename = 'test_filename'

    # Test downloading an entire file
    test_ctx = test_context()
    hd.real_download('http://127.0.0.1/dummy_file', test_ctx)

    # Test downloading a partial file
    test_ctx = test_context()

# Generated at 2022-06-22 07:07:43.565591
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import shutil
    import sys
    import tempfile

    # Generate a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test-')

    # Create the class
    hfd = HttpFD(FakeYDL(), dict())
    hfd.to_screen = lambda *args, **kargs: None
    hfd.to_stderr = lambda *args, **kargs: None
    hfd.report_error = lambda *args, **kargs: None
    hfd.report_retry = lambda *args, **kargs: None
    hfd.report_file_already_downloaded = lambda *args, **kargs: None
    hfd.report_destination = lambda *args, **kargs: None

# Generated at 2022-06-22 07:08:49.817976
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, None, None)
    assert fd.best_block_size(2.0, 1024 * 32) > 1024 * 32
    assert fd.best_block_size(2.0, 1024 * 64) < 1024 * 32

    fd = HttpFD('url', None, None)
    assert isinstance(fd.ydl, YoutubeDL)

    fd = HttpFD('url', None, {})
    assert isinstance(fd.ydl, YoutubeDL)



# Generated at 2022-06-22 07:08:59.895293
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test if file download works as expected
    dir = tempfile.mkdtemp()

# Generated at 2022-06-22 07:09:02.008339
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import doctest
    doctest.testmod()



# Generated at 2022-06-22 07:09:14.260797
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Open test.bin for reading and writing, delete it if it's there
    test_file = open('test.bin', 'wb+')
    # Write a copy of the first bytes of test.bin
    test_file.write(bytes.fromhex('000102030405060708090a0b0c0d0e0f'))
    # Get the file descriptor of test.bin as an integer
    test_fd = test_file.fileno()
    # Close the file descriptor (but leave test.bin open)
    test_file.close()
    # Reopen test.bin with the HttpFD class
    test_http_fd = HttpFD('test.bin', test_fd, 'w+b')
    # Write to test.bin

# Generated at 2022-06-22 07:09:23.918124
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def _get_http_fd(url):
        return HttpFD(
            url,
            {
                'noprogress': True,
                'quiet': True,
                'nocheckcertificate': True,
                'prefer_insecure': True,
                'logger': get_common_ydl_logger(),
            })

    def test_filehandle(url):
        stream = _get_http_fd(url)
        assert stream.fh is not None

    def test_read_block(url):
        stream = _get_http_fd(url)
        assert stream.read(10 * 1024 * 1024)  # ~ 10mb
        assert stream.read(1) == b''

    def test_seek_beginning(url):
        stream = _get_http_fd(url)
        assert stream

# Generated at 2022-06-22 07:09:28.734284
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def test_get_data(url, params, headers):
        return compat_urllib_request.addinfourl(
            io.BytesIO(b'a'*1+b'b'*2+b'c'*3+b'd'*4), {
                'Content-length': '10',
            }, url)
    class Info:
        def __init__(self, num):
            self.info = {
                'description': 'desc%s' % num,
                'title': 'title%s' % num,
            }
    ydl = FakeYDL({'simulate': True, 'quiet': True, 'logger': SimpleLogger()})
    fd1 = HttpFD(ydl, Info(1), 'http://a/', range_state=None)
    fd2 = HttpFD

# Generated at 2022-06-22 07:09:40.638204
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test code
    def test_real_download(downloader, params):
        # This is the only method that needs to be modified to
        # customize the HTTP downloader behaviour
        def write_data(self, data_block):
            assert data_block == b'some data'

        # Monkey-patch write_data to customize downloader behaviour
        old_write_data = downloader.write_data
        downloader.write_data = types.MethodType(write_data, downloader)

        # Invoke real_download to perform the actual download
        info = {'url': 'http://www.example.com/'}
        params['test'] = True
        downloader.real_download('http://www.example.com/', info, params)

        # Restore original write_data for the next test
        downloader.write_data = old

# Generated at 2022-06-22 07:09:52.507227
# Unit test for constructor of class HttpFD
def test_HttpFD():
    f = HttpFD('http://google.com/')
    assert f.url == 'http://google.com/'
    assert 'html' in f.headers['Content-Type']
    f.close()

    f = HttpFD('http://google.com/', {'User-Agent': 'IE'})
    assert f.headers['User-Agent'] == 'IE'
    f.close()

    f = HttpFD('http://www.google.com/google.pdf', {'Range': 'bytes=0-10'})
    assert f.url == 'http://www.google.com/google.pdf'
    assert f.headers['Content-Type'] == 'application/pdf'
    assert f.headers['Content-Length'] == '11'
    assert f.headers['Accept-Ranges'] == 'bytes'
    f

# Generated at 2022-06-22 07:10:04.145812
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD('http://example.com/', {'noprogress': True})
    info_dict = {}

    # Test headers
    http_fd.add_header('Accept', '*/*')
    http_fd.add_header('Connection', 'close')
    http_fd.add_header('User-Agent', std_headers['User-Agent'])
    http_fd.add_header('Range' , 'bytes=0-%d' % (test_file_size - 1))
    http_fd.test(test_file_size)

    # Test download
    filename = http_fd.prepare_filename(info_dict)
    http_fd.download(filename, info_dict)
    (tmpfilename, filename) = http_fd.takedown(filename, info_dict)

    # Compare files

# Generated at 2022-06-22 07:10:15.942235
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    class Info(object):
        pass
    for _ in range(4):
        info_dict = Info()

# Generated at 2022-06-22 07:13:02.673336
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_test_server = HttpServerThread()
    http_test_server.start()

    # download an object with a size divisible by _TEST_FILE_SIZE
    DOWNLOAD_LENGTH = HttpFD._TEST_FILE_SIZE * 10
    PROBE_SIZE = DOWNLOAD_LENGTH - 42
    assert PROBE_SIZE % HttpFD._TEST_FILE_SIZE == 0

    def _verify_downloaded_range(filename, offset, length):
        assert os.path.isfile(encodeFilename(filename))
        assert os.path.getsize(encodeFilename(filename)) == length
        assert open(encodeFilename(filename), 'rb').read() == b'\0' * offset + b'X' * length

    # Download whole file first

# Generated at 2022-06-22 07:13:09.591481
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test that Downloader.real_download downloads video files"""

    # This is a dummy object we can pass to HttpFD
    class DummyYDL(object):
        def __init__(self, params):
            self.params = params

        def to_screen(self, msg):
            # print(msg)
            pass

        def to_stderr(self, msg):
            # print(msg)
            pass

    class DummyFD(object):
        def __init__(self, url):
            import re
            self.url = url
            self.test = re.search(r'[&?]test_([0-9]+)[.]', url)
            assert self.test
            self.test = int(self.test.group(1))
            self.headers = {}

        def info(self):
            return