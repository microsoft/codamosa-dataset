

# Generated at 2022-06-22 07:03:51.369317
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys

    # At first we need an url with a redirect
    url = 'http://www.google.com'
    redirect_url = 'http://www.youtube.com'

    # Create the opener with the redirect handler
    opener = compat_urllib_request.build_opener(compat_urllib_request.HTTPRedirectHandler)
    # Install it
    compat_urllib_request.install_opener(opener)

    # Construct an InfoExtractor object to test the HttpFD constructor
    ie = InfoExtractor()
    ie.http_headers = {}
    # The http_headers['Referer'] will be set to url
    ie.http_headers['Referer'] = url

    # Create a fake params

# Generated at 2022-06-22 07:04:02.418191
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:04:06.643902
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Read from stdin
    http_fd = HttpFD('-', {'http_chunk_size': 4})
    stdin = http_fd.read()
    assert stdin == b'Test', 'Got wrong data from stdin'

# Generated at 2022-06-22 07:04:08.416805
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import test_http
    test_http.test_HttpFD(HttpFD)

# Generated at 2022-06-22 07:04:21.121025
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # test 1: download not modified file
    def test1():
        fd1 = HttpFD('http://localhost/file')
        fd2 = HttpFD('http://localhost/file')
        fd1.close()
        fd2.close()

    # test 2: download modified file
    def test2():
        fd1 = HttpFD('http://localhost/file')
        start_time = time.time()
        time.sleep(2.5)
        fd2 = HttpFD('http://localhost/file')
        fd1.close()
        fd2.close()
        assert time.time() - start_time > 2

    # test 3: download files with different etags
    def test3():
        fd1 = HttpFD('http://localhost/file1')
        fd2

# Generated at 2022-06-22 07:04:32.380517
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    import shutil
    import socket
    import thread
    import time
    import BaseHTTPServer
    import urllib

    # First we'll create a temporary directory
    tmpdir = tempfile.mkdtemp(prefix='youtubedl-test-httpd-')

    # We'll use a dummy socket so that we can control when it receives
    # data.
    sock = socket.socket()

    # Create the server, binding to localhost on port 9000
    server = BaseHTTPServer.HTTPServer(('localhost', 9000), BaseHTTPServer.BaseHTTPRequestHandler)

    # When the server recieves a GET request,
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(self.path[1:])
        self

# Generated at 2022-06-22 07:04:45.449784
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # We need to run the test only if xattr is available
    if not get_xattr_supported():
        raise unittest.SkipTest('xattr not supported')

    # Create a fake object to replace the object of class YoutubeDL
    class FakeYDL(object):
        def urlopen(self, request):
            return FakeUrllib2Response(request)

    class FakeUrllib2Response(object):

        def __init__(self, request):
            self.request = request
            self.headers = {
                'Content-Type': 'audio/mpeg',
                'Content-Length': str(2 ** 23),
                'Accept-Ranges': 'bytes',
                'Content-Range': 'bytes {}-{}/{}'.format(*get_range(request)),
            }


# Generated at 2022-06-22 07:04:56.926975
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    from io import BytesIO
    from datetime import datetime

    class FakeYDL(object):
        def urlopen(self, request):
            return BytesIO(b'foo')

        def to_screen(self, msg):
            pass

        def to_stderr(self, msg):
            pass

        def report_progress(self, **kwargs):
            pass

        def report_warning(self, msg):
            pass

        @property
        def params(self):
            return {'nooverwrites': True}

    class FakeFD(HttpFD):
        def __init__(self, *args):
            pass

        def try_rename(self, tmpfn, fn):
            pass

        def undo_temp_name(self, filename):
            return filename


# Generated at 2022-06-22 07:05:09.729653
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Test of method real_download of class HttpFD.
    """

    # Needed to initialize self.params
    class YDL(object):
        params = {}

    # Mock of class RetryDownload
    class RetryDownload(object):
        def __init__(self, source_error):
            self.source_error = source_error

    # Mock of class Request
    class Request(object):
        def __init__(self, url):
            self.url = url
            self.headers = {}

    hfd = HttpFD(YDL())

    # Create a temporary file
    temp_file_fd, temp_file_path = tempfile.mkstemp(prefix = 'test_HttpFD_real_download_')
    temp_file = os.fdopen(temp_file_fd, 'w')

    #

# Generated at 2022-06-22 07:05:21.520351
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import shutil
    import tempfile
    import urllib
    from ytdl.utils import *

    # Creating test data
    s = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    data = []
    for i in range(1000):
        chunk_length = random.randrange(1, 1024 + 1)
        data.append(s[i % len(s)] * chunk_length)
    test_filename = os.path.join(tempfile.gettempdir(), 'test_http_fd.dat')
    with open(test_filename, 'wb') as f:
        f.write(b''.join(data))

    # Testing

# Generated at 2022-06-22 07:06:04.718708
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    class HttpDownloader(object):
        def __init__(self):
            self.params = {
                'continuedl': True,
                'limitrate': 1048576,  # 1 MiB/s
                'nooverwrites': False,
                'noresizebuffer': False,
                'test': True,
                'socket_timeout': None,
            }
            self.to_screen = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None
            self._progress_hooks = []
            self._screen_file = io.StringIO()
            self._err_file = io.StringIO()
            self.filesystem_encoding = sys.getfilesystemencoding()
            self.report_destination = lambda *args, **kargs: None

# Generated at 2022-06-22 07:06:16.877523
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    self = HttpFD()
    self.params = {}
    self.report_retry = lambda msg1, num, max: None
    TOO_SMALL_SIZE = 5*1024*1024
    TOO_BIG_SIZE = 55*1024*1024
    # Create stream (simulated download)
    def create_stream(size):
        # To speed up tests, use small B's instead of megabytes
        stream = io.BytesIO(b'B' * size)
        # Also add Content-Length header to the download
        headers = compat_httplib_HTTPMessage()
        headers.add_header('Content-Length', str(size))
        data = compat_urllib_response.addinfourl(stream, headers, '')
        return data
    # Create an object in which to store download progress

# Generated at 2022-06-22 07:06:29.114546
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os.path
    import shutil
    import tempfile

    # Create a directory for test files
    tmp_dir = tempfile.mkdtemp()

    # Test the case where the file does not exist
    nonexistent_file = os.path.join(tmp_dir, 'nonexistent')
    h = HttpFD(nonexistent_file, {'continuedl': True})
    assert h.filename == nonexistent_file
    assert h.total_bytes is None

    # Test the case where the file exists
    f = open(os.path.join(tmp_dir, 'test'), 'w')
    test_file = f.name
    f.write('test' * 1000)
    f.close()
    h = HttpFD(test_file, {'continuedl': True})
    assert h.filename == test_

# Generated at 2022-06-22 07:06:38.777459
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Test HttpFD.real_download"""

    class DummyHttpFD(HttpFD):
        # Dummy methods
        def report_destination(self, filename):
            pass
        def to_screen(self, message, skip_eol=False):
            pass
        def to_stdout(self, message):
            pass
        def to_stderr(self, message):
            pass
        def undo_temp_name(self, tmpfilename):
            return tmpfilename

        def slow_down(self, start, now, down_bytes):
            pass

        def best_block_size(self, elapsed_time, bytes_downloaded):
            pass

        def calc_speed(self, start, now, bytes_downloaded):
            pass


# Generated at 2022-06-22 07:06:41.910959
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    f = HttpFD(BytesIO())
    assert f.offset == 0
    assert f.size == -1
    assert f.name is None


# Generated at 2022-06-22 07:06:54.133539
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import shutil
    import socket
    import subprocess
    import tempfile
    import time

    td = tempfile.mkdtemp()

# Generated at 2022-06-22 07:07:06.251101
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class MockYDL(object):
        def urlopen(self, *args, **kwargs):
            return compat_urllib_request.urlopen(*args, **kwargs)

    ydl = MockYDL()

    # Download file via HTTP
    def http_download(ctx, filename):
        fd = HttpFD(ydl, {'nooverwrites': True, 'continuedl': True}, ctx.params.get('test_socket_timeout', None))
        ctx.filename = fd._prepare_filename('test_file')
        assert ctx.filename == filename
        ctx.stream = open(encodeFilename(ctx.filename), 'wb')
        ctx.data = compat_urllib_request.urlopen('http://localhost:8808/test_file')

    # Test cases:
   

# Generated at 2022-06-22 07:07:19.493047
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create FakeYDL() object and a fake HTTP server (http.server.HTTPServer)
    ydl = FakeYDL()
    server = http.server.HTTPServer(('localhost', 0), http.server.SimpleHTTPRequestHandler)
    # Run the server in a parallel thread
    thread = threading.Thread(target=server.handle_request)
    thread.daemon = True
    thread.start()
    # Get server's socket address and use it for HTTP request
    address = server.socket.getsockname()
    http_request = 'GET / HTTP/1.1\r\nHost: %s:%s\r\n\r\n' % (address[0], address[1])
    # Send the request and read HTTP response
    host, port = address
    sock = socket.create_connection((host, port))

# Generated at 2022-06-22 07:07:21.817324
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(sanitized_Request('http://www.youtube.com/'))



# Generated at 2022-06-22 07:07:32.252958
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:08:43.315840
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(
        sanitized_Request('http://www.example.com/'),
        bytes_per_sec=64,
        now_fn=lambda: 1)

    def slow_read(n):
        buf = b''
        left = n
        while left > 0:
            buf += b'x'
            left -= 1
            time.sleep(1./64)
        return buf

    fd.read = slow_read
    start = time.time()
    assert fd.read(64) == b'x' * 64
    assert time.time()-start >= 1
    assert fd.read(64) == b'x' *64
    assert time.time()-start >= 2

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:08:54.850607
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Initialize class
    HFD = HttpFD()
    # Set up test variables
    # Sanity check
    assert not HFD._TESTING_REAL_DOWNLOAD
    # Url test (downloading)
    url = 'http://ipv4.download.thinkbroadband.com/5MB.zip'
    # Url test (not downloading)
    # url = 'https://vk.com/images/deactivated_400.png'  # in case of downloading
    # Filename test
    filename = 'test.txt'
    # Size test
    size = HFD._TEST_FILE_SIZE
    # Dump test
    dump = True
    # Chunk test
    chunk_size = 1024
    # Resume test
    test_resume = True
    # Stream test
    stream = False
    #

# Generated at 2022-06-22 07:09:02.795285
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # The "dummy" protocol handler works like the "http" one, but without
    # connecting to a real HTTP server
    # We first test that an HTTP download of a small file works
    assert download_https(
        'dummy://httpbin.org/bytes/1024', 'test.tmp')
    os.remove('test.tmp')

    # We then test that, if the server returns a smaller file than the one we
    # requested, the download is cancelled and an exception is thrown
    try:
        download_https(
            'dummy://httpbin.org/bytes/1025', 'test.tmp')
        raise AssertionError('ContentTooShortError expected')
    except ContentTooShortError:
        pass

    # We also test that if the server returns a larger file than we requested
    # (or if the server returns the correct size),

# Generated at 2022-06-22 07:09:15.051075
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """test_HttpFD_real_download"""
    from .YoutubeDLHttp import YoutubeDLHttp
    import StringIO
    from .utils import make_HTTPServer

    # Serve files for test
    for _, _, files in os.walk('test/files'):
        for f in files:
            if f.endswith('.mp4') or f.endswith('.flv') or f.endswith('.webm'):
                break
        else:
            continue
        server = make_HTTPServer()

        # Instantiate test object
        fd = HttpFD(
            YoutubeDLHttp(),
            'http://localhost:%d/%s' % (server.port, f),
            {'noprogress': True, 'outtmpl': '-'},
            f,
            {})

       

# Generated at 2022-06-22 07:09:26.910575
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """Tests whether HttpFD.real_download() works correctly."""
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import prepend_extension
    from .compat import compat_tempfile
    from .utils import format_bytes

    class _ServerHandler(BaseHTTPServer.BaseHTTPRequestHandler):
        server_version = 'test'
        protocol_version = 'HTTP/1.1'
        # Request handler to let the test server handle one request, then shutdown
        last_request_handled = False

        def log_request(self, *args):
            """Do not log requests, otherwise BaseServer.handle_request() fails with an
            error after handling the last request (see below)."""
            pass


# Generated at 2022-06-22 07:09:38.262150
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:09:50.606796
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import copy
    import socket
    from .utils import encodeFilename
    from .utils import write_xattr
    from .compat import StringIO
    from .compat import compat_http_client
    from .compat import compat_urllib_error

    try:
        from .compat import xattr
    except ImportError:
        xattr = None

    class _ContextManager_noop:
        def __init__(self, obj):
            self.obj = obj
        def __enter__(self):
            return self.obj
        def __exit__(self, *args):
            pass

    class FakeSocket:
        def __init__(self, fp):
            self._fp = fp
            self._data = None
            self._len = -1

        def makefile(self, mode):
            return self._

# Generated at 2022-06-22 07:10:02.547071
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import sanitize_open, decode_compat_str, encode_compat_str
    from .compat import tempfile
    dl = HttpFD()
    dl.params['noprogress'] = True
    url = 'http://localhost:8888/'
    count = 0
    content_length = 3 * dl._TEST_FILE_SIZE

    def my_open(path, mode):
        nonlocal count
        if mode != 'wb':
            return open(path, mode)
        count += 1
        return tempfile.SpooledTemporaryFile()

    def _open_url(url, headers=None, params=None, data=None, retries=None, redirect=False):
        assert not redirect
        if data is not None:
            method, data = data

# Generated at 2022-06-22 07:10:10.777233
# Unit test for constructor of class HttpFD
def test_HttpFD():

    # Test 1: Input data and check HttpFD object

    # Test 2: Compute length and check
    # Test 3: Read multiple blocks and check
    # Test 4: Seek and tell
    # Test 5: Seek beyond EOF

    ydl = YoutubeDL(YoutubeDL({'quiet': True}))
    h = HttpFD(ydl, None, {'url': 'http://ipv4.download.thinkbroadband.com/10MB.zip'})
    assert h.desc().startswith('http://ipv4.download.thinkbroadband.com/10MB.zip')
    assert h.size() == 10485760

    assert h.read(5) == b'PK\x03\x04'
    assert h.read(5) == b'\x14\x00\x00\x00'
   

# Generated at 2022-06-22 07:10:22.319127
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create test file
    fd = open(encodeFilename(TEST_FILE_NAME), 'wb')
    fd.write(b'abcdefghijklmnopqrstuvwxyz')
    fd.close()

    # Initialize HttpFD
    ydl = YoutubeDL()
    outtmpl = '%(tmpfilename)s'
    params = {
        'noprogress': True,
        'quiet': True,
        'retries': 0,
        'test': True
    }
    TestHttpFD = HttpFD(ydl, TEST_FILE_URL, params, outtmpl)

    # Test case 1: Test full download, 1 byte at time
    TestHttpFD.params['min_filesize'] = 1
    TestHttpFD.params['max_filesize'] = 1

# Generated at 2022-06-22 07:13:03.962441
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for constructor: HttpFD(url)
    http_fd1 = HttpFD(test_url)
    assert http_fd1.url == test_url
    assert not http_fd1.closed
    assert http_fd1.info() is None
    assert http_fd1.geturl() == test_url
    assert http_fd1.geturl() == test_url

    # Test for constructor: HttpFD(url, headers)
    http_fd2 = HttpFD(test_url, {'Range': 'bytes=0-1024'})
    assert http_fd2.url == test_url
    assert not http_fd2.closed
    assert re.findall(r'bytes\s*=\s*0-1024', http_fd2.info()['Content-Range'])
    assert http_fd2