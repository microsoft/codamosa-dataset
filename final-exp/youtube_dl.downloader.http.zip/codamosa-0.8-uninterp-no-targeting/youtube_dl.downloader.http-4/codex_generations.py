

# Generated at 2022-06-22 07:03:52.498151
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import socket
    import urllib2
    url = u'http://i.imgur.com/n5cnr.jpg'
    # Create a HTTP request that would handle redirects
    request = redirect_request(sanitized_Request(url))
    # Make a HEAD request to check if server is willing to send us data
    content_length = -1
    try:
        content_length = int(urllib2.urlopen(request).info().get('Content-length', -1))
    except (urllib2.HTTPError, urllib2.URLError, socket.timeout):
        pass
    assert content_length != -1
    # Get the actual download
    data = urllib2.urlopen(request)
    # Read all retrieved data and write it to stdout
    CHUNK = 16 * 1024
   

# Generated at 2022-06-22 07:04:03.148568
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    setUpModule()

    # Unit test for http_testserver.py
    class DummyServer():
        def __init__(self):
            self.idx = 0

        def handle(self, connection, dummy_address):
            data = connection.recv(1024)

            if re.search(br'POST', data):
                # Write response with custom body
                connection.sendall(('HTTP/1.1 200 OK\r\n' +
                                    'Content-Type: text/html\r\n' +
                                    '\r\n' +
                                    '<html><body>%d</body></html>' % self.idx).encode('utf-8'))
                self.idx += 1

# Generated at 2022-06-22 07:04:08.273489
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Open test
    http_info = urllib2.urlopen('http://www.youtube.com/')
    fd = HttpFD(http_info)
    assert fd.read() == http_info.read()
    fd.close()
    http_info.close()
    # Test for read() method
    http_info = urllib2.urlopen('http://www.youtube.com/')
    fd = HttpFD(http_info)
    assert fd.read(10) == http_info.read(10)
    http_info.close()
    assert fd.read() == ''
    fd.close()

# Test the incremental downloader

# Generated at 2022-06-22 07:04:21.009667
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test cases
    test_cases = [
        # (url, filename, info_dict, tmpfilename, expected_tmpfilename, params)
        ('https://host.com/path/to/file', '-', {}, '-', '-', {
            'noprogress': True, 'quiet': True, 'ratelimit': 1024,
            'retries': 1, 'test': True}),
        ('https://host.com/path/to/file', 'filename', {}, None, 'filename', {
            'noprogress': True, 'quiet': True, 'ratelimit': 1024,
            'retries': 1, 'test': True})
    ]

    # Test real_download method

# Generated at 2022-06-22 07:04:23.750804
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Check an invalid URL
    _ = HttpFD(None, {}, None, None, None)
    return

# Generated at 2022-06-22 07:04:31.165731
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test the max_bytes parameter
    fd = HttpFD(BytesIO(b'test'), max_bytes=2)
    assert fd.read(3) == b'te'
    assert fd.read(1) == b''
    assert fd.read(1) == b''

    # Test the absurl parameter
    fd = HttpFD(BytesIO(b'test'), absurl='https://foo.com/bar')
    assert fd.geturl() == 'https://foo.com/bar'


# Generated at 2022-06-22 07:04:42.247207
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import StringIO
    o = StringIO.StringIO()
    fd = HttpFD(o)
    assert fd.name is None
    assert fd.mode is None
    assert fd.closefd is None
    assert fd.closed is False
    assert repr(fd) == '<HttpFD proxy of %s>' % repr(o)
    fd.close()
    assert fd.closed is True
    fd.seek(0)
    fd.tell()
    fd.write('foo')
    assert fd.getvalue() == 'foo'

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:04:54.369004
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile
    import shutil
    from .extractor.common import google_docs_download, google_docs_url_repl

    def fetch_page(url):
        return 'hi'
    google_docs_download._fetch_page = fetch_page
    google_docs_download._get_proxies = lambda : {}
    tdir = tempfile.mkdtemp()
    gdd_url = google_docs_url_repl(r'https://docs.google.com/uc?id=some_id&export=download')
    goods_url = google_docs_url_repl(r'https://docs.google.com/uc?export=download&id=some_id')
    gdd_test_fn = os.path.join(tdir, 'test.txt')

# Generated at 2022-06-22 07:05:01.339206
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .retry import Retry
    fd = HttpFD(
        'http://localhost:81/',
        {'noprogress': True, 'retries': 10},
        'http://localhost:81/video.mp4',
        None,
        None,
        'video.mp4',
        Retry(10))
    assert not fd.test()
    assert fd.close()



# Generated at 2022-06-22 07:05:07.628964
# Unit test for constructor of class HttpFD
def test_HttpFD():
    httpfd = HttpFD(None, None)
    httpfd.report_warning('a warning')
    httpfd.report_error('an error')
    assert httpfd.try_rename('a', 'b') is None
    assert httpfd.try_utime('a', None) is None
    assert httpfd.best_block_size(100, 1000) == 1000

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:05:41.046777
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    HttpFD.real_download(None)

# test_HttpFD_real_download()


# This class represents a downloader object created for a single video.


# Generated at 2022-06-22 07:05:53.502678
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    fd = HttpFD(FakeYDL(), {'url': 'https://github.com/rg3/youtube-dl/blob/master/youtube_dl/__init__.py',
                            'test': True,
                            'test_handle': None,
                            'test_handle_close': True,
                            'test_handle_simulate_error': False,
                            'noprogress': False,
                            'continuedl': True,
                            'retries': 10,
                            'buffersize': 64,
                            'noresizebuffer': False,
                            'keepalive': True,
                            'updatetime': True,
                            })
    fd.real_download(lambda *_: None)
    assert os.path.isfile(fd.filename)


# Generated at 2022-06-22 07:05:55.457368
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.google.com')
    assert isinstance(fd, HttpFD)
    assert not fd.close()
    print('TEST OK')



# Generated at 2022-06-22 07:06:01.854867
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from .compat import compat_urllib_error
    from .utils import encode_data_uri
    from .extractor import YoutubeIE
    # Test number of bits in each character of Base64
    assert ((ord(compat_str('a')) << 2) >> 2) == ord(compat_str('a'))
    assert ((ord(compat_str('A')) << 2) >> 2) == ord(compat_str('A'))
    assert ((ord(compat_str('0')) << 2) >> 2) == ord(compat_str('0'))
    assert ((ord(compat_str('+')) << 2) >> 2) == ord(compat_str('+'))

# Generated at 2022-06-22 07:06:14.461218
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case 1 - no fallback for non-existing file
    try:
        fd = compat_urllib_request.urlopen('http://localhost:8080/')
    except compat_urllib_error.URLError:
        pass
    else:
        raise Exception('Failed to raise compat_urllib_error.URLError')

    # Test case 2 - fallback for non-existing file
    fd = compat_urllib_request.urlopen('http://localhost:8080/', 'rb', None, 3)

    # Test case 3 - fallback for existing file
    try:
        fd = compat_urllib_request.urlopen('http://localhost:8080/', 'rb', None, 3)
    except compat_urllib_error.URLError:
        fd

# Generated at 2022-06-22 07:06:26.766547
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    url = 'http://example.org/file'
    params = {
        'nooverwrites': True,
        'continuedl': True,
        'quiet': True,
    }
    info = {
        'name': 'file',
    }
    downloader = MockYDL(params)
    info_dict = {}

    # No server response
    ret = HttpFD._real_download(downloader, {}, info, info_dict, url, 'file', None, -1)
    assert ret is False

    # Test HTTP 206
    # The server must return Content-Range and Content-Length,
    # otherwise the client will think that all content has been downloaded.
    # That's because YouTubeDL downloads in 5 MB or so chunks (block_size),
    # and if the downloaded content is smaller than the requested chunk,
   

# Generated at 2022-06-22 07:06:29.211213
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .http_head_downloader import test
    test(HttpFD)

# this is a simplified version of the HttpFD class
# it downloads a single url to a file

# Generated at 2022-06-22 07:06:40.379559
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import os
    import shutil
    from io import BytesIO
    from collections import namedtuple
    import pytest
    from .http import HttpFD, HttpFDContext
    from .extractor import YoutubeDL
    from .utils import encodeFilename
    from .compat import USING_PYPY
    from .compat import compat_http_server
    from .compat import compat_urllib_request
    from .compat import pytest_check_output
    from .compat import compat_os_name
    from .compat import compat_HTTPError
    from .compat import compat_socket
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    import socket
    import tempfile

# Generated at 2022-06-22 07:06:52.700694
# Unit test for constructor of class HttpFD
def test_HttpFD():
    filename = 'test'
    # Make sure that SanitizeInvariantFilter adds an invariant part to the filename
    filter_raw_filename = HttpFD._SanitizeInvariantFilter().filter(filename)
    assert filter_raw_filename != filename

    # Call constructor with different 'sanitize' values
    http_fd = HttpFD(filename, {'nopart': True})
    assert http_fd._TEST_FILE_SIZE == 0
    assert http_fd.raw_filename == filename

    http_fd = HttpFD(filename, {})
    assert http_fd._TEST_FILE_SIZE > 0
    assert http_fd.raw_filename != filter_raw_filename
    assert filter_raw_filename in http_fd.raw_filename
    assert http_fd.sanitize is False
    assert http_

# Generated at 2022-06-22 07:07:02.421767
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # This unittest runs through the real_download method of class HttpFD
    # with the goal of finding bugs in the code.
    #
    # In order to do this, test_HttpFD_real_download()
    #   - creates a temporary directory,
    #   - initializes some test parameters,
    #   - initializes an instance of HttpFD,
    #   - calls real_download with the initialized instance,
    #   - checks the returned value,
    #   - checks the size of the file written,
    #   - checks that the temporary directory is empty and deletes it.
    import os
    import sys
    import shutil
    import random
    import tempfile
    import pytest
    from .extractor import get_info_extractor

# Generated at 2022-06-22 07:07:44.403377
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL(object):
        """A fake YoutubeDL object for testing."""

        def __init__(self, params):
            self.params = params.copy()
            self._progress_hooks = []
            self.downloaded_bytes = 0
            self.total_bytes = 0
            self.status = None
            self.tmpfilename = None
            self.filename = None
            self.speed = None
            self.elapsed = None

        def to_screen(self, msg):
            print(msg)

        def to_stderr(self, msg):
            print(msg)

        def report_error(self, msg):
            print(msg)

        def report_retry(self, err, count, retries):
            print('%s. Retry #%d' % (str(err), count))



# Generated at 2022-06-22 07:07:57.289756
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # This test is not made with @unittest.skipUnless because
    # we need to be sure that our test of the constructor is made
    # under the same conditions as when the user uses it.
    from .compat import compat_urlparse

    inst = HttpFD(
        urlresolver.HostedMediaFile('http://www.example.com/video.ext'),
        params={'nopart': True},
        filename='-',
        progress_hooks=[lambda n: n])
    # Test the sanity checks
    assert isinstance(inst.ydl, YoutubeDL), 'Wrong instance created'
    assert inst.params['nopart'] is True, 'Parameters are not passed correctly'
    assert inst.tmpfilename == '-', 'Temporary file name is not set correctly'
    parsed_url = compat_urlparse.urlsplit

# Generated at 2022-06-22 07:08:07.868897
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    filename = os.path.join(os.path.dirname(__file__), 'test.m4a')
    if os.path.exists(filename):
        os.unlink(filename)
    assert not os.path.exists(filename)
    hd = HttpFD(
        None, {'nooverwrites': True}, {'nooverwrites': True}, {'simulate': True}, None)
    hd.report_destination = lambda f: None
    hd.report_resuming_byte = lambda s: None
    hd.to_screen = lambda s, n: None
    hd.report_retry = lambda e, c, t: None
    hd.report_error = lambda msg: None

# Generated at 2022-06-22 07:08:13.227832
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, {'noprogress': True})
    assert_equal(fd.ydl, None)
    assert_equal(fd.params, {'noprogress': True})
    assert_equal(fd.info_dict, {})
    assert_equal(fd.tmpfilename, None)


# Generated at 2022-06-22 07:08:25.052801
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import platform
    import shutil
    import tempfile
    from .utils import PY3
    from contextlib import closing
    from .extractor import gen_extractors
    from .downloader import gen_downloaded_file_name
    from .FileDownloader import FileDownloader
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request

    # Testcases are
    # 1. Testcase for real_download() in which actual download is performed over HTTP
    # 2. Testcase for real_download() in which HTTP error is returned
    # 3. Testcase for real_download() in which download is performed using a file-like
    #    object (HTTP)
    # 4. Testcase for real_download() in which IOError is returned
    # 5. Testcase for

# Generated at 2022-06-22 07:08:26.977482
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(object(), object())



# Generated at 2022-06-22 07:08:36.072269
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test case when URL has no hostname
    fd = HttpFD('http:///%C3%B6%C3%A4%C3%BC%C3%9F', {'noprogress': True, 'retries': 0})
    assert fd.corrected_url == 'http:///%C3%B6%C3%A4%C3%BC%C3%9F'
    assert fd.real_url is None
    assert fd.status.get('http_status', None) is None
    assert fd.status.get('filename', None) is None
    assert fd.status.get('elapsed', None) is None
    assert fd.status.get('speed', None) is None
    assert fd.status.get('eta', None) is None

    # Test case

# Generated at 2022-06-22 07:08:44.937337
# Unit test for constructor of class HttpFD
def test_HttpFD():
    dummy_inst = YoutubeDL()
    for (args, kargs) in [
        # test int
        [('/dev/null', 'wb'), {'test': True}],
        # test str
        [('-', 'wb'), {'continuedl': True}],
        # test with optional parameters
        [('-', 'wb'), {'test': True, 'noprogress': True, 'ratelimit': 512000}],
            ]:
        fd = HttpFD(dummy_inst, *args, **kargs)
        fd.test()

# Generated at 2022-06-22 07:08:56.092113
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test for HttpFD for http protocol
    tpfd = HttpFD('http', None, 'www.example.com', '/index.html', {'iptc_keywords': ['k1', 'k2'], 'foo': 'bar'}, None)
    assert tpfd.proto == 'http' and tpfd.ipproto == 'tcp' and tpfd.host == 'www.example.com' and tpfd.port == 80 and tpfd.url == '/index.html'
    assert tpfd.test() == True
    assert tpfd.get_headers() == {'User-Agent': 'Test Agent', 'iptc_keywords': 'k1,k2', 'foo': 'bar'}

    # Test for HttpFD for https protocol

# Generated at 2022-06-22 07:09:01.040954
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, None, None, None)
    assert(fd.headers['User-Agent'] == std_headers['User-Agent'])
    assert(fd.proxy is None)
    fd = HttpFD(None, [], None, None)
    assert(fd.proxies[None] == [])
    fd = HttpFD(None, {}, None, None)
    assert(fd.proxies == {})


# Generated at 2022-06-22 07:10:01.603509
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.google.com/', {})
    assert(fd.url == 'http://www.google.com/')



# Generated at 2022-06-22 07:10:13.612857
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import httpretty
    from urllib.error import URLError, HTTPError
    from urllib.request import Request, build_opener, HTTPCookieProcessor
    try:
        from urllib.parse import unquote
    except ImportError:
        from urllib import unquote
    try:
        from io import BytesIO
    except ImportError:
        from io import StringIO as BytesIO

    from .compat import compat_urllib_request, compat_urllib_error, compat_urllib_parse_urlparse

    # Test custom opener
    class CustomOpener(object):
        # pylint: disable=no-init
        def __init__(self, *args, **kwargs):
            pass

        def open(self, request):
            return compat_urllib_request

# Generated at 2022-06-22 07:10:24.786963
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import time
    # Test 1: Simple, non-resume download
    result = HttpFD('http://releases.mozilla.org/pub/mozilla.org/firefox/releases/3.5.8/win32/en-US/Firefox%20Setup%203.5.8.exe', {}, {}, False).real_download(lambda x: None)
    if result is False:
        raise Exception('Simple, non-resume download failed!')

    # Test 2: Simple, resume download

# Generated at 2022-06-22 07:10:34.794509
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Base class for test failure exceptions
    class TestFailure(Exception):
        pass

    # Encapsulates all information needed to perform external test of real_download() method
    # of class HttpFD.
    class TestSpec:
        def __init__(self, url, tmp_file, expected_file, expected_chunks):
            self.url = url
            self.tmp_file = tmp_file
            self.expected_file = expected_file
            self.expected_chunks = expected_chunks

    # Encapsulates all data sent to real_download() method.
    class TestContext:
        def __init__(self, filename, tmpfilename, open_mode, start_time, data_len, resume_len,
                     chunk_size, block_size, stream, spec, is_resume):
            self.filename = filename
           

# Generated at 2022-06-22 07:10:46.805194
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import io
    import tempfile
    from .downloader import FragmentFD
    from .extractor import mk_extractor_classes
    from .utils import encodeFilename

    class Dummy:
        pass

    td = tempfile.mkdtemp()

# Generated at 2022-06-22 07:10:57.560823
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO

    # Test with BytesIO
    data = b'hello world'
    stream = BytesIO(data)
    stream.info = lambda: {'Content-length': len(data)}

    fd = HttpFD(stream, 'http://example.com/', 'wb')
    assert not fd.close()

    assert fd.read(5) == b'hello'
    assert fd.read(1) == b' '
    assert fd.read(5) == b'world'
    assert fd.read(1) == b''

    # Test with BytesIO
    stream = BytesIO()
    stream.info = lambda: {'Content-length': len(data)}

    fd = HttpFD(stream, 'http://example.com/', 'wb')

# Generated at 2022-06-22 07:11:06.914132
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import bs4
    import random
    import string
    import tempfile
    import xmlrpc.client
    import urllib.request
    import urllib.error
    import http.server
    import socketserver
    import threading
    import socket

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for m in range(length))
    # A simple http server whose contents are a concatenation of files that can be
    # passed in the url in the form '/f1/f2/f3'
    class ConcatHttpRequestHandler(http.server.SimpleHTTPRequestHandler):
        def translate_path(self, path):
            path = path.lstrip('/')
            if path.find('..') >= 0:
                return None

# Generated at 2022-06-22 07:11:11.600198
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Some test cases
    assert_raises_regex(IOError, 'failed to write data|not writable', real_download, 'http://www.youtube.com', {'noprogress': True, 'quiet': True, 'test': True}, 'ytdl://')



# Generated at 2022-06-22 07:11:16.133865
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # pylint: disable=too-many-locals
    import socket
    from ..utils import determine_ext
    from ..compat import compat_http_client
    from ..extractor import gen_extractors
    t0 = time.time()

# Generated at 2022-06-22 07:11:25.149637
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import os
    import pytest
    from tempfile import NamedTemporaryFile

    class TestFD(HttpFD):

        def __init__(self, *args, **kwargs):
            super(TestFD, self).__init__(*args, **kwargs)
            self._setup()

        def _prepare_url(self, url):
            return url

        def _setup(self):
            # We will use _TEST_FILE_SIZE constant from HttpFD class
            self.ydl = mock.MagicMock()
            self.params = {'test': True, 'noresizebuffer': False, 'buffersize': '1M', 'continuedl': True, 'ratelimit': 5000.0}
            self.to_screen = lambda msg: msg
            self.report_destination = lambda msg: msg
            self.report