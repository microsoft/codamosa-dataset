

# Generated at 2022-06-22 07:03:40.804706
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # TODO
    return


# unit test for best_block_size

# Generated at 2022-06-22 07:03:44.957886
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.google.com/', {'test': 'Test'})
    assert fd.test() == 'Test'
    with fd:
        pass
    print('HttpFD: OK')



# Generated at 2022-06-22 07:03:48.579549
# Unit test for constructor of class HttpFD
def test_HttpFD():
    h = HttpFD('http://localhost/foo', {'noprogress': True})
    assert h.url == 'http://localhost/foo'
    assert h.params['noprogress']


# Generated at 2022-06-22 07:03:59.894471
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import encode_data_uri
    from .utils import sanitize_open
    from .utils import is_html
    from .utils import DownloadError

    # Set up stubs
    class DummyYtdl:
        def __init__(self):
            self.to_screen_width = 78
            self.params = {
                'nooverwrites': True,
                'continuedl': False,
                # 'noprogress': False,
                'verbose': True,
                'quiet': False,
            }
            self.to_screen_lock = threading.Lock()
            self.to_stderr_lock = threading.Lock()
            self.reports_lock = threading.Lock()
            self.progress_hooks = []
            self.report_hooks = []

# Generated at 2022-06-22 07:04:11.578745
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import json
    import re
    import time
    import unittest
    import locale
    import shutil
    import tempfile
    import os
    import types
    import atexit
    import contextlib
    import sys
    import types
    import socket
    import inspect
    import Queue
    import threading
    import copy
    import xml.etree.ElementTree

    from .utils import DateRange

# Generated at 2022-06-22 07:04:24.735488
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from youtube_dl.utils import DownloadError
    import sys
    import os
    import tempfile
    import shutil
    import base64
    import socket
    import errno
    import select
    import threading
    import traceback

    class FakeYDL(object):

        def urlopen(self, request):
            def raise_on_data_block_size(func):
                def check_data_block_size(*args, **kargs):
                    if 'data_len' in inspect.getargspec(func).args:
                        # data_len is present
                        assert len(args) >= 3
                        assert 'data_len' in kargs
                        assert kargs['data_len'] is not None
                    return func(*args, **kargs)
                return check_data_block_size

# Generated at 2022-06-22 07:04:29.669748
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    h = HttpFD(None, 'rb', {})
    assert h.data is None

    h = HttpFD(BytesIO(b'my content'), 'rb', {})
    assert h.data.read() == b'my content'
    h.close()
    h.data.close()

    stdout = BytesIO()
    h = HttpFD(stdout, 'wb', {})
    h.write(b'my content')
    assert h.data.getvalue() == b'my content'
    h.close()
    h.data.close()


# Generated at 2022-06-22 07:04:43.692475
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test if method real_download can handle download errors
    def test_HttpFD_real_download_errors(ctx):
        # Test if method real_download can handle errors
        def test_HttpFD_real_download_errors_download(ctx):
            # Test if method real_download can handle errors when downloading
            def test_HttpFD_real_download_errors_download_data_block_socket_error(ctx):
                # Test if method real_download can handle socket_error when downloading data_block
                def test_HttpFD_real_download_errors_download_data_block_socket_error_errno_ECONNRESET(ctx):
                    # Test if method real_download can handle socket_error when downloading data_block and errno is ECONNRESET
                    ctx.filename = '-tmp'
                    ctx.stream = c

# Generated at 2022-06-22 07:04:48.911477
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import math
    import tempfile
    import random
    import shutil

    _TEST_FILE_SIZE = 100

    class FakeYDL:
        def __init__(self):
            self.to_screen_lock = threading.Lock()
            self.params = {}

        def to_screen(self, message):
            with self.to_screen_lock:
                print(message)

        def to_stderr(self, message):
            with self.to_screen_lock:
                print(message, file=sys.stderr)

        def trouble(self, message, tb):
            self.to_stderr(message + '\n' + tb)

        def report_warning(self, message):
            self.to_stderr(message)


# Generated at 2022-06-22 07:04:59.074326
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def text_of_file(filename):
        return open(encodeFilename(filename), 'rb').read().decode('utf-8')

    def assert_files_equal(filename1, filename2):
        assert text_of_file(filename1) == text_of_file(filename2)

    def assert_files_differ(filename1, filename2):
        assert text_of_file(filename1) != text_of_file(filename2)

    # Remove any old file
    try:
        os.remove(get_tmpfilename())
    except OSError:
        pass

    # Set up a test server
    # Part of the file that will be served
    file_content = '0123456789abcdefghijkl'

    class TestServer(SocketServer.TCPServer):
        allow_reuse_address

# Generated at 2022-06-22 07:05:43.239219
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    def _fake_download(ydl, ctx, test_file_size, params, info_dict, retries=1):
        # pylint: disable=unused-argument
        filename = ctx.tmpfilename if ctx.tmpfilename != '-' else ctx.filename
        if not ctx.resume_len:
            with open(filename, 'wb') as stream:
                stream.write(b'X' * test_file_size)
        else:
            while ctx.resume_len < test_file_size:
                ctx.resume_len += ctx.chunk_size

    # Replace real_download method by _fake_download
    HttpFD.real_download = _fake_download

    # Test without --test

# Generated at 2022-06-22 07:05:55.440700
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import test_http_server
    import os.path
    import tempfile
    import shutil
    import urllib
    tmp_dir = tempfile.mkdtemp()
    server_port = get_free_port()
    server_address = 'http://%s:%s' % (socket.gethostname(), server_port)
    server_url = server_address + '/test.dat'

    src_file = os.path.join(tmp_dir, 'test_file.dat')
    shutil.copy(__file__, src_file)

    server = test_http_server.TestHTTPServer(server_port, tmp_dir)
    server.start()

    test_size = os.path.getsize(src_file)
    ydl = FakeYDL()

# Generated at 2022-06-22 07:06:06.966193
# Unit test for method real_download of class HttpFD

# Generated at 2022-06-22 07:06:20.233930
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(FakeYDL(), 'http://www.example.com')
    assert fd.geturl() == 'http://www.example.com'
    assert fd.getheader('Content-Type') == 'text/html'
    assert fd.getheader('Content-Length') == '1470'

# Generated at 2022-06-22 07:06:31.230406
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test that download works correct and doesn't end up with an infinite loop after failing to resume
    fd = HttpFD(YoutubeDL())
    info_dict = {
        'url': 'http://httpbin.org/range/1024/2048',
        'title': u'Httpbin video',
        'player_url': 'http://httpbin.org/get/player',
        'thumbnail': 'http://httpbin.org/image',
        'ext': 'mp4',
        'protocol': 'm3u8',
        'http_headers': {'foo': 'bar'},
        'http_cookies': {'foo': 'bar'},
        'http_referer': 'http://httpbin.org/referer',
        'http_proxy': 'http://httpbin.org/proxy',
    }
   

# Generated at 2022-06-22 07:06:44.232643
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def t(url, expected):
        s = sanitize_url(url)
        real_expected = (s, os.path.basename(s))
        if expected != real_expected:
            raise Exception('Expected: %r, got %r for url %r' % (expected, real_expected, url))
        real_expected = (s, os.path.basename(s), s)
        if expected != real_expected:
            raise Exception('Expected: %r, got %r for url %r' % (expected, real_expected, url))
    t('http://www.youtube.com/watch?v=BaW_jenozKc', ('http://www.youtube.com/watch?v=BaW_jenozKc', 'watch?v=BaW_jenozKc'))

# Generated at 2022-06-22 07:06:53.745580
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import shutil
    tmp_dir = 'out'
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir)
    os.mkdir(tmp_dir)
    tmp_file = 'out/tmp'
    t = HttpFD(
        'http://localhost:8080/test.mp4',
        {'nooverwrites': True, 'continue_dl': True, 'noprogress': True},
        tmp_file)
    assert not t.test(1024)
    t.report_retry(socket.timeout('timed out'), 2, 5)
    t.report_error('An error occured')
    t.report_resuming_byte(1024)
    t.report_unable_to_resume()

# Generated at 2022-06-22 07:06:58.057965
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    return HttpFD.test_real_download(test_handle, {
        'test_handle': test_handle,
        'test_append': True,
        'test_read_block_size': 1,
        'test_max_blocks': 1
    })

# Generated at 2022-06-22 07:07:08.366221
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .compat import urlretrieve
    import os
    import sys
    import tempfile
    import socket

    test_urls = (
        'http://example.com/',
        'http://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest',
        'ftp://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest',
    )

# Generated at 2022-06-22 07:07:13.789413
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    buf = io.BytesIO()
    buf.name = 'buf'
    buf.seek(0)
    buf.close = lambda: None
    _ = HttpFD(buf, None, None)
    assert _.real_download(
        {'url': 'https://www.youtube.com/watch?v=BaW_jenozKc', 'player_url': 'https://www.youtube.com/watch?v=BaW_jenozKc', 'player_url_basename': 'BaW_jenozKc'},
        {'http_chunk_size': 100, 'test': True}
    )

# download method of HttpFD class

# Generated at 2022-06-22 07:08:23.871679
# Unit test for constructor of class HttpFD
def test_HttpFD():
    urlopen = compat_urllib_request.urlopen
    # Test cases with zero filesize
    def _read_zero(self, size=-1):
        return ''
    def _urlopen_zero(req):
        return type('DummyHttpZero', (object, ), {'info': lambda self: {'Content-Length': '0'}})()
    def _urlopen_zero_retry(req):
        return type('DummyHttpZeroRetry', (object, ), {'info': lambda self: {'Content-length': '0'}, 'getcode': lambda self: 503})()
    def _urlopen_zero_error(req):
        raise compat_urllib_error.URLError('')
    class DummyOpenerZero(object):
        def open(self, req):
            return _urlopen

# Generated at 2022-06-22 07:08:34.381510
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Prepare the test environment
    # Create the configuration
    ydl_opts = {
        'quiet': True,
        'outtmpl': '%(epoch)s',
        'nooverwrites': True,
        'retries': 0,
        'noprogress': True,
        'logger': MyLogger,
        'test': True,
    }
    # Create the downloader
    ydl = YoutubeDL(ydl_opts)
    info_dict = {}
    ydl.add_info_extractor(DummyIE(ydl, info_dict))
    ydl.add_default_info_extractors()
    # Mock the report methods. Just store the parameters, so we can assert them later
    report_mock = []

# Generated at 2022-06-22 07:08:46.890237
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import FileIO
    from .utils import prepend_extension

    # File-like object with programming mistakes
    class EvilFileIO(FileIO):
        # First read should return False to indicate EOF
        def read(self, size):
            self.read = super(EvilFileIO, self).read
            return True


# Generated at 2022-06-22 07:08:57.787109
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import tempfile
    import shutil
    import random

    test_dir = tempfile.mkdtemp()
    test_file_path = os.path.join(test_dir, 'a')
    print('Test output will be written to %s' % sys.stderr)
    print('Test file will be created at %s' % test_file_path)
    fd = HttpFD(None, params={'noprogress': True})
    test_string = b"This is a test string to ensure that the downloader is not broken"

# Generated at 2022-06-22 07:09:06.533025
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://127.0.0.1/test', {'testp': 'testv'}, {'testp': 'testv'}, False, False, None)
    assert fd.url_handle.get_full_url(True) == 'http://127.0.0.1/test?testp=testv'
    assert fd.url_handle.get_header('testp') == 'testv'
    assert fd.handle.fp.getheader('testp') == 'testv'
    assert fd.handle.fp.headers.get('testp') == 'testv'



# Generated at 2022-06-22 07:09:15.477412
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import prepare_filename
    from .downloader.http import HttpFD
    class MockIE(InfoExtractor):
        _TEST = {
            'url': 'http://server/file.mp4',
            'info_dict': {'id': 'file.mp4', 'ext': 'mp4'},
            'expected_warnings': ['HTTP Error 403: Forbidden'],
            'params': {
                'skip_download': True,
                'test': True,
            },
        }

        def _real_extract(self, url):
            headers = {'Content-length': 10240}

# Generated at 2022-06-22 07:09:27.330361
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a temporary test file
    temp_file = tempfile.NamedTemporaryFile()
    test_data = '1234567890'
    temp_file.write(test_data)
    temp_file.seek(0)

    # Prepare metadata
    test_url = 'http://unittest.test/test.flv'
    test_params = {
        'url': test_url,
        'nocheckcertificate': True,
        'http_headers': {
            'Referer': 'http://unittest.test/'
        },
        'http_chunk_size': None,
        'continuedl': True,
        'noresizebuffer': True,
    }

    # Prepare HttpFD object
    ydl = YoutubeDL()
    ydl.params['socket_timeout'] = 5.

# Generated at 2022-06-22 07:09:35.611621
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Create instance of class HttpFD
    h = HttpFD('http://www.google.com', {'noprogress': True}, None)
    # Simulate the necessary attributes
    h.chunk_size = h.params.get('chunksize', None)
    h.data = compat_urllib_response.addinfourl(BytesIO(b''), compat_httplib.HTTPMessage(StringIO('')), h.url)
    # Call test function
    return download(h, None)



# Generated at 2022-06-22 07:09:47.642245
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    stderr = BytesIO()
    fd = HttpFD(None, {}, None, None, lambda x: stderr.write(x.encode('utf-8')))
    # Init
    fd.prepare_conn_headers({})
    assert fd.chunk_size == fd.CHUNK_SIZE
    assert fd.open_mode == 'wb'
    assert fd.resume_len == 0
    assert fd.method == 'GET'
    assert fd.data is None
    assert fd.total_bytes is None
    assert fd.filename is None
    assert fd.tmpfilename == '-'
    assert fd.start_time is None
    assert fd.ctx.resume_chunk == 0

# Generated at 2022-06-22 07:09:58.096395
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class DummyYDL:
        def __init__(self):
            self.params = {
                'nooverwrites': False,
                'continuedl': False,
                'noprogress': False,
                'retries': 10,
                'test': True,
                'socket_timeout': None,
                'quiet': False,
                'noresizebuffer': False,
                'logger': Mock(spec_set=Logger),
            }

        urlopen = Mock(spec_set=compat_urllib_request.urlopen)

    ydl = DummyYDL()
    fd = HttpFD(ydl, {'url': 'http://ex.org'})
    fd.data = Mock(spec_set=compat_urllib_request.urlopen)

# Generated at 2022-06-22 07:12:44.307304
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # dummy parameters
    params = {
        'nooverwrites': True,
        'continuedl': False,
    }
    # dummy info dict
    info_dict = {}
    # dummy filename
    filename = 'dummy'
    # dummy report hook
    def hook(status, percent=None):
        print('\nHook called; status: %s, percent: %s\n' % (status, percent))
    hook_tested = False
    # dummy slow down function
    def slow_down(start, now, transferred):
        pass
    # dummy best block size function
    def best_block_size(elapsed_time, bytes_downloaded):
        return 1
    # dummy report error function
    def report_error(msg):
        print('\nError reported: %s\n' % msg)
   

# Generated at 2022-06-22 07:12:54.036515
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .extractor._real_extractors import YoutubeIE
    from .YoutubeDL import YoutubeDL

    
    class FakeInfoExtractor(InfoExtractor):
        _TEST = {
            'url': 'http://localhost/',
            'file': 'test.mp4',
            'info_dict': {'id': 'test'},
            'params': {
                'skip_download': True,
            }
        }

    def test_real_download(ydl, ie, params):
        try:
            ydl.process_ie_result(ie.extract(ie.url), download=False)
            filename = ie.downloaded_info_dict['url']
        except SystemExit:
            pass

# Generated at 2022-06-22 07:13:04.002251
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import datetime
    import tempfile
    import shutil
    import urllib2

    # Make a temp directory to store the test files
    tmpdir = tempfile.mkdtemp(prefix='youtube-dl-test-')
