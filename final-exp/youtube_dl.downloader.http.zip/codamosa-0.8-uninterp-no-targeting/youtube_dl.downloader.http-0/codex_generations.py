

# Generated at 2022-06-22 07:03:57.898239
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    """
    Make sure that the returned value of real_download is True for a
    single fragment download and for a multi fragment download.
    """
    
    import sys
    this_module = sys.modules[__name__]

    http_fd = FDwithoutDl(None, 'http')
    http_fd.to_screen = lambda *args: None # Suppress output
    
    
    # Test single download
    http_fd.real_download("https://www.youtube.com/watch?v=tJgnaJhY-Ls",
                          {'noprogress': True, 'quiet': True})
    
    # Test multi download

# Generated at 2022-06-22 07:04:11.359741
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class TestHFD(HttpFD):
        def __init__(self, params):
            self.params = params
            self.retries = params.get('retries', 3)
            self.fragment_retries = params.get('fragment_retries', 3)
            self.skip_fragments = params.get('skip_unavailable_fragments')
            self.continuedl = params.get('continue_dl', True)
            self.noprogress = params.get('noprogress', False)
            self.ratelimit = params.get('ratelimit', None)
            self.min_filesize = params.get('min_filesize', None)
            self.max_filesize = params.get('max_filesize', None)
            self.test = True

# Generated at 2022-06-22 07:04:17.566784
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .downloader import HttpFD, HttpQuietDownloader
    from .utils import sanitize_open
    from .compat import compat_urllib_parse_urlparse, compat_urllib_request_OpenerDirector, compat_urllib_parse_urlencode, compat_urllib_request_Request, compat_urllib_request, compat_urllib_error, compat_urllib_parse_unquote, compat_urlparse
    from .compat import compat_str

    def sanitize_open(self, filename, open_mode):
        f = sanitize_open(filename, open_mode)
        # Downloading to stdout should not be retried
        if filename == '-':
            self._do_retry = False
        return f


# Generated at 2022-06-22 07:04:28.666478
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class TestHttpDL(HttpFD):
        def __init__(self, ydl, params):
            super(TestHttpDL, self).__init__(ydl, params)

    params = {
        'noprogress': True,
        'continuedl': True,
        'quiet': True,
        'ratelimit': 1048576,
        'noresizebuffer': True,
        'test': True,
    }
    ydl = YoutubeDL(params)
    ydl.add_default_info_extractors()

    dl = TestHttpDL(ydl, params)
    dl.test()

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:04:42.616586
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class MyHttpFD(HttpFD):
        def __init__(self, ydl, params):
            super(MyHttpFD, self).__init__(ydl, params, progress_hooks=[])
            self.passed_info_dicts = []
            self.passed_progs = []

        def report_retry(self, source_error, count, retries):
            pass

        def report_error(self, msg):
            self._hook_progress({
                'status': 'error',
                'msg': msg,
            })

        def _hook_progress(self, info_dict):
            self.passed_info_dicts.append(info_dict)
            self.passed_progs.append(info_dict.get('downloaded_bytes', 0))


# Generated at 2022-06-22 07:04:53.606697
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test constructor of class HttpFD with max_reconnects=0
    fd = HttpFD(urlopen, 'http://www.youtube.com/', max_reconnects=0)
    try:
        fd.read(64 * 1024)
    except (compat_urllib_error.URLError, socket.error):
        pass
    else:
        assert False, 'Exception not raised'

    # Test constructor of class HttpFD with max_reconnects=1
    fd = HttpFD(urlopen, 'http://www.youtube.com/', max_reconnects=1)
    fd.read(64 * 1024)

# Unit tests for urlopen() function

# Generated at 2022-06-22 07:05:00.772633
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import copy
    httpfd = HttpFD(None)
    httpfd.http_headers = lambda *a, **k: {
        'Content-Length': (
            None
            if 'Content-Length' in k['extra_headers']
            else int(k['extra_headers']['Content-Range'][6:].split('-')[1]) + 1),
    }
    # no Content-Length, no Content-Range
    assert httpfd.real_download(
        DummyYDL({'ratelimit': None, 'noresizebuffer': True}),
        'http://example.com/foo.bar',
        {'test_param': 1},
        0,
        {},
    ) == (False, 'Did not get any data blocks')
    # no Content-Length, no Content-Range
    httpfd.report

# Generated at 2022-06-22 07:05:11.048693
# Unit test for constructor of class HttpFD
def test_HttpFD():
    getcwd = os.getcwd
    def getcwd_mock():
        cwd = getcwd()
        return cwd + '/'
    os.getcwd = getcwd_mock

    # Set up inputs
    url = 'http://example.com/file.mp4'
    tmpfilename = '-'
    info = {
        'http_headers': {},
        'url': url,
    }
    params = {
        'nooverwrites': True,
        'test': False,
    }
    progress_hooks = []

    # Get expected outputs

# Generated at 2022-06-22 07:05:21.060468
# Unit test for constructor of class HttpFD
def test_HttpFD():
    if sys.version_info >= (3, 0, 0):
        return
    fake_params = {
        'nocheckcertificate': False,
        'prefer_insecure': False,
    }
    fake_ydl = type('YoutubeDL', (object,), dict(params=fake_params))
    # Test with un-seekable stream
    fd = HttpFD(fake_ydl, 'https://httpbin.org/robots.txt', None, 'rb')
    assert 'Googlebot' in fd.read()
    assert 'Googlebot' in fd.readline()
    assert 'Googlebot' in fd.readlines()[0]
    assert 'Googlebot' in fd.read(5)
    assert 'Googlebot' in fd.readline(5)
    assert 'Googlebot'

# Generated at 2022-06-22 07:05:30.776843
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # assuming real_download() needs at least 50MiB of free space in current working directory
    if os.path.isdir('.install-lock') or os.path.isfile('.install-lock'):
        pytest.skip('Directory .install-lock exists, test not running')
    if os.path.isfile('README.md'):
        pytest.skip('File README.md exists, test not running')
    if os.statvfs('.').f_bfree * os.statvfs('.').f_bsize < 50 * 1024**2:
        pytest.skip('Not enough free space in current working directory')
    if os.environ.get('TRAVIS') == 'true':
        pytest.skip('Not running HttpFD test on Travis CI')


# Generated at 2022-06-22 07:06:15.515863
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import httpretty

    @contextmanager
    def patch_urlopen():
        with httpretty.all_requests_registred():
            httpretty.register_uri(httpretty.HEAD, 'http://example.com/foo',
                                   adding_headers={
                                       'Content-Length': '45',
                                       'Accept-Ranges': 'bytes',
                                   })
            httpretty.register_uri(httpretty.GET, 'http://example.com/foo',
                                   adding_headers={
                                       'Last-Modified': 'Sat, 06 Oct 2012 04:05:34 GMT',
                                       'Content-Length': '45',
                                       'Accept-Ranges': 'bytes',
                                   },
                                   body='\n'.join(map(compat_str, range(10))))
            yield

   

# Generated at 2022-06-22 07:06:27.865626
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD(None, 'http://www.example.com', 5, None)
    assert fd.status() == 5
    assert fd.geturl() == 'http://www.example.com'
    fd.close()

    fd = HttpFD(None, 'http://www.example.com', 500, None, None)
    assert fd.status() == 500
    fd.close()

    fd = HttpFD(None, 'http://www.example.com', 'redirect', 'http://www.go.com')
    assert fd.status() == 'redirect'
    assert fd.geturl() == 'http://www.go.com'
    assert fd.getcode() == 'redirect'
    fd.close()

    ch = compat_http_client.HT

# Generated at 2022-06-22 07:06:29.258143
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('http://www.google.com')



# Generated at 2022-06-22 07:06:40.497007
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Just a simple test to see HttpFD can download a file

    # Create test file
    fp, fp_name = tempfile.mkstemp(suffix='youtube-dl.test')
    fd = open(fp, 'wb')
    fd.write('testdata')
    fd.close()

    # Create HttpFD instance
    hfd = HttpFD('', {}, None)

    # Perform test (delete test file if it exists)
    success = False
    try:
        success = hfd.real_download(encodeFilename(fp_name), 'http://localhost:8080/' + os.path.basename(fp_name), {'noprogress': True}, is_test=True)
    finally:
        os.unlink(fp_name)

    if not success:
        raise

# Generated at 2022-06-22 07:06:52.801022
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    downloader = YouTubeDL(FakeYDL())
    downloader.params['noprogress'] = True  # Disable progress messages
    downloader.params['quiet'] = True  # Disable output messages
    downloader.params['simulate'] = True  # Don't download
    downloader.params['nooverwrites'] = True  # Don't overwrite output file
    downloader.params['outtmpl'] = u'%(id)s'  # Output template
    downloader.params['continuedl'] = True  # Enable continue mode
    downloader.params['noresizebuffer'] = True  # Disable block size adjustment

    import io
    linewise = lambda txt: io.BytesIO(txt.replace(b'\n', b'\r\n'))

    # Unexpected HTTP server response

# Generated at 2022-06-22 07:07:02.448298
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO, UnsupportedOperation
    from urllib.parse import urlencode
    from .utils import match_filter_func
    from .compat import parse_qsl

    POST_TEST_URL = 'http://localhost/posttest'
    TEST_DATA = {}

    def post_test_handler(s):
        print(s)
        env = s['env']
        res = s['res']
        body = BytesIO()
        res("200 OK", [("Content-Type", "text/plain")])
        if env.get('REQUEST_METHOD') == 'POST':
            if env.get('CONTENT_TYPE') == 'application/x-www-form-urlencoded':
                # content_length = int(env.get('CONTENT_LENGTH', '0'))
                body.write

# Generated at 2022-06-22 07:07:15.245220
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO
    f = HttpFD(BytesIO((u'a'.encode('ascii')) * 10), 10, None, None)

    # Read 0 to 9, nothing left to read
    assert 0 == f.read(0)
    assert (u'a'.encode('ascii')) * 9 == f.read(9)
    try:
        f.read(1)
    except IncompleteReadError as e:
        pass
    else:
        assert False

    # Read 0 to 9, nothing left to read
    f.seek(0, 0)
    assert 0 == f.read(0)
    assert (u'a'.encode('ascii')) * 9 == f.read(9)

# Generated at 2022-06-22 07:07:17.769487
# Unit test for constructor of class HttpFD
def test_HttpFD():
    http_fd = HttpFD('http://example.com/', {})
    http_fd.test()


# Generated at 2022-06-22 07:07:29.678594
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL(object):
        def __init__(self):
            self.progress_hooks = []
        
        def add_progress_hook(self, hook):
            self.progress_hooks.append(hook)
        
        def to_screen(self, message, skip_eol=False):
            pass
        
        def urlopen(self, request):
            class FakeStream(object):
                def __init__(self, data):
                    self.data = data
                
                def read(self, size):
                    if len(self.data) == 0: return b''
                    if size < 0: size = len(self.data)
                    ret = self.data[:size]
                    self.data = self.data[size:]
                    return ret
            

# Generated at 2022-06-22 07:07:40.293108
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Fake sys.stderr
    class FakeStdErr:
        def write(self, str):
            pass
    class FakeStdOut:
        def write(self, str):
            pass

    # Test 1
    fd = HttpFD(FakeStdErr(), {}, 'http://www.google.com/', None, '-', None, 'wb')
    assert not fd.close()
    assert fd.len is None
    assert fd.tell() == 0
    fd.write(b'foo')
    fd.close()

    # Test 2
    original_encodeFilename = fd.encodeFilename
    def _encodeFilename(s):
        if isinstance(s, bytes):
            return s
        return s.encode('ascii')
    fd.encode

# Generated at 2022-06-22 07:08:52.294235
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    hfd = HttpFD('foo')
    hfd.report_destination = Mock(return_value=None)
    hfd.report_error = Mock(return_value=None)
    hfd.report_retry = Mock(return_value=None)
    hfd.report_resuming_byte = Mock(return_value=None)
    hfd.report_unable_to_resume = Mock(return_value=None)
    hfd.report_file_already_downloaded = Mock(return_value=None)
    hfd._hook_progress = Mock(return_value=None)
    hfd.to_screen = Mock(return_value=None)
    hfd.to_stderr = Mock(return_value=None)

# Generated at 2022-06-22 07:09:01.521333
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor.generic import GenericIE
    from .downloader import HttpFD
    from .utils import encodeFilename

    # Create class for testing purposes
    class TestHttpFD(HttpFD):
        def __init__(self, *args, **kwargs):
            super(TestHttpFD, self).__init__(*args, **kwargs)
            self.test_result = False

        def slow_down(self, start, now, byte_counter):
            return


# Generated at 2022-06-22 07:09:13.786644
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test parameters
    TEST_FILENAME = 'test_file.tmp'
    TEST_DATA_LEN = 1764

    # Mock
    class DownloadCtx:
        chunk_size = 0
        data = None
        data_len = None
        filename = TEST_FILENAME
        tmpfilename = TEST_FILENAME + '.part'
        open_mode = 'wb'
        block_size = 2
        resume_len = 0
        start_time = 0
        stream = None
        is_resume = False
        has_range = False

    class HttpYDL:
        def to_screen(self, msg):
            print('TEST >> %s' % msg)

        def to_stderr(self, msg):
            print('TEST >> %s' % msg)


# Generated at 2022-06-22 07:09:23.785191
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys
    import os
    import re
    import tempfile
    import shutil

    try:
        from tools.encode import _encodeFilename
    except ImportError:
        def _encodeFilename(s):
            return s

    import youtube_dl
    from youtube_dl import HttpFD
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import write_xattr
    from youtube_dl.utils import XAttrUnavailableError
    from youtube_dl.compat import ContentTooShortError
    from youtube_dl.compat import sanitize_open
    from youtube_dl.version import __version__
    from youtube_dl.utils import match_filter_func



# Generated at 2022-06-22 07:09:35.871777
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import sys
    import tempfile
    import shutil
    from .compat import compat_urllib_request

    # Create temporary directory
    tmpdir = tempfile.mkdtemp(prefix='youtube-dl-test_')

    # Constructor test
    tfn = os.path.join(tmpdir, 'testvid.flv')
    try:
        hd = HttpFD(tfn, {}, None, None)
    except Exception as e:
        print('Constructor of class HttpFD failed with %s' % repr(e))
        sys.exit(1)

    # Get test video

# Generated at 2022-06-22 07:09:38.551565
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD(sanitize_open('-', 'w'), None, 'http://127.0.0.1/')

# Unit tests for HttpFD.__reduce__

# Generated at 2022-06-22 07:09:50.605034
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class TestHttpFD(HttpFD):
        def __init__(self, ydl, params, info_dict):
            super(TestHttpFD, self).__init__(ydl, params, info_dict)
            self.downloaded = 0
            self.expected = 0
            self.elapsed = 0

        def report_progress(self, prog_dict):
            self.downloaded = prog_dict.get('downloaded_bytes', 0)
            self.expected = prog_dict.get('total_bytes', 0)
            self.speed = prog_dict.get('speed', 0)
            self.elapsed = prog_dict.get('elapsed', 0)

    # Test constructor with an URL
    url = 'http://127.0.0.1:8080/test_file'
    test_ydl = YoutubeDL({})

# Generated at 2022-06-22 07:10:02.509642
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test setup
    # Test data
    url = 'https://github.com/rg3/youtube-dl/raw/master/README.md'
    # Test-specific parameters
    params = {
        'buffersize': 32,
        'noresizebuffer': True,
        'retries': 5,
        'test': True
    }
    # Test-specific hooks
    def test_hook(*args, **kwargs): pass
    hooks = {
        'progress': test_hook,
        'download_start': test_hook,
        'download_end': test_hook,
        'download_max_bitrate': test_hook,
    }
    # Generate YouTubeDL object
    ydl = YoutubeDL(params)
    # Patch DummyYDL.report_* methods

# Generated at 2022-06-22 07:10:07.478966
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Constructor without url
    fd = HttpFD(None)

    # Constructor with url
    fd = HttpFD('http://www.example.org')
    fd = HttpFD('http://www.example.org', {'test': 'yes'})


# Generated at 2022-06-22 07:10:13.612351
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    opt = dict(simulate=True)
    with open_for_writing('./foo', False, opt) as outf:
        fd = HttpFD('http://localhost:38001/bytes/%d/%d' % (my_test_file_size, my_test_file_size), opt, outf)
        fd.real_download('./foo', None, None)


# Generated at 2022-06-22 07:13:01.282906
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Open a local file
    fd = HttpFD(None, {'noprogress': True, 'retries': 3}, sys.executable)
    fd.real_download(
        {'url': 'file:' + quote(sys.executable),
         'proxy': None,
         'http_headers': {},
         'test': True,
         'fragment_base_url': None,
         'playlist_index': None,
         'playlist': None})
    assert fd.tmpfilename == '-'
    assert fd.filename == sys.executable
    assert fd.data_len == os.path.getsize(sys.executable)
    assert fd.resume_len == 0
    assert fd.open_mode is None
    assert fd.stream is None
    # Download the

# Generated at 2022-06-22 07:13:09.005268
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    test_result = True
    # test returns boolean, true if test succeeds
    def test_result_val(val):
        nonlocal test_result
        test_result = test_result and val
    # test returns boolean, true if test succeeds
    def test_result_raise(f):
        nonlocal test_result
        try:
            f()
            test_result = False
        except:
            test_result = test_result
        else:
            test_result = False
    # test returns boolean, true if test succeeds
    def test_result_not_raise(f):
        nonlocal test_result
        try:
            f()
            test_result = test_result
        except:
            test_result = False

    # Unit testing for method real_download
    # Note that this method is called by the wrapper method download hence it