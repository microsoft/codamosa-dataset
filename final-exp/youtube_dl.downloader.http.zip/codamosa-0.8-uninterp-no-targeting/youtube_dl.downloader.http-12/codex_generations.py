

# Generated at 2022-06-22 07:03:55.814100
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Constructor and download
    fd = HttpFD(
        {'logger': DummyLogger()},
        'http://127.0.0.1:8086/HTTP%201.1%20104%20Connection%20Reset%20(with%20explicit%20range)/file_256k.dat',
        {
            'noprogress': True,
            'ratelimit': 512 * 1024,
        })
    success = fd.download()
    assert success
    assert fd.downloaded == 256 * 1024
    assert fd.name == 'file_256k.dat'
    assert fd.tmpfilename == 'file_256k.dat.part'
    assert os.path.isfile(encodeFilename(fd.tmpfilename))

# Generated at 2022-06-22 07:04:04.643690
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .extractor import gen_extractor
    from .utils import match_filter_func

    class Extractor(object):
        IE_DESC = 'test'
        IE_NAME = 'test'
        _TEST = {
            'url': 'http://example.com',
            'info_dict': {
                'id': 'test',
                'ext': 'mp4',
            },
        }

        def _real_extract(self, url):
            return {
                'id': self._TEST['info_dict']['id'],
                'url': url,
            }

    class MyHttpFD(HttpFD):
        def __init__(self, ydl, params, info_dict):
            super(MyHttpFD, self).__init__(ydl, params, info_dict)

# Generated at 2022-06-22 07:04:12.091865
# Unit test for constructor of class HttpFD
def test_HttpFD():
    def test(**kwargs):
        fd = HttpFD(**kwargs)
        for attr in ('url', 'filename', 'info_dict'):
            assert getattr(fd, attr) is kwargs[attr], '%s: %r != %r' % (attr, getattr(fd, attr), kwargs[attr])
        return fd
    return test

# Unit test HttpFD.get_headers()

# Generated at 2022-06-22 07:04:25.101245
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import threading
    from .utils import write_xattr
    from .extractor import get_suitable_extractor

    def video_info_hook(status):
        if status['status'] == 'finished':
            print('Done downloading, now converting ...')

    params = {
        'outtmpl': 'test_%(id)s.%(ext)s',
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'progress_hooks': [video_info_hook],
        'verbose': True,
        'logger': MyLogger(),
        'nooverwrites': False,
    }

    extractor = get

# Generated at 2022-06-22 07:04:39.169800
# Unit test for constructor of class HttpFD

# Generated at 2022-06-22 07:04:43.788026
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test scenario:
    #   - Open a test file for reading, write it to another file
    #     simultaneously and compare the results byte by byte.
    # Prerequisites:
    #   - Python 2.6 and 3.2 or above (bytes type)
    #   - OS-level file locking
    #   - Test file generated with
    #     dd if=/dev/urandom of=downloader_test_file bs=1024 count=13
    inst = HttpFD(open(encodeFilename('downloader_test_file'), 'rb'))
    # test read function
    #   - read exactly a file size
    read_func = inst.read
    write_func = open(encodeFilename('downloader_test_file2'), 'wb').write
    buf = read_func(13*1024)
    write_func(buf)

# Generated at 2022-06-22 07:04:55.642827
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import sys

    import pytest

    class TestFD(HttpFD):
        def __init__(self, result_file, *args, **kwargs):
            super(TestFD, self).__init__(*args, **kwargs)
            self.result_file = result_file

        def report_progress(self, *args, **kwargs):
            # print(args, kwargs)
            pass

        def report_warning(self, *args, **kwargs):
            # print(args, kwargs)
            pass

        def to_stderr(self, *args, **kwargs):
            # print(args, kwargs)
            pass

        def report_error(self, *args, **kwargs):
            # print(args, kwargs)
            pass


# Generated at 2022-06-22 07:05:07.086162
# Unit test for constructor of class HttpFD
def test_HttpFD():
    dl = FakeYDL()
    for test_params in [{'continuedl': True, 'noprogress': False, 'logger': dl}, {}]:
        hfd = HttpFD(dl, dl.params)

        url = 'http://127.0.0.1/blah'
        filename = '-'
        tmpfilename = '-temp'

        # Test progressive downloading
        hfd.test(
            url, filename, tmpfilename,
            dl_chunk_size = 10,
            download = True,
            test = True)

if __name__ == '__main__':
    test_HttpFD()

# Generated at 2022-06-22 07:05:18.168639
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import tempfile
    import sys
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_filename = os.path.join(tmp_dir, '-')
    tmp_fd = open(tmp_filename, 'wb')
    tmp_fd.write(b'foobarbaz')
    tmp_fd.close()

    test_file_size = 9
    http_fd = HttpFD(YoutubeDL('--test'))

# Generated at 2022-06-22 07:05:29.500869
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    class FakeYDL(object):
        def __init__(self, data):
            self.data = data
        def report_destination(self, *args, **kargs):
            pass
        def report_progress(self, *args, **kargs):
            pass
        def to_screen(self, *args, **kargs):
            pass
        def to_stderr(self, *args, **kargs):
            pass
        def trouble(self, *args, **kargs):
            pass
    s = '\n' + 'X' * 10 + '\n'
    data = (s * 0, s * 1, s * 4, s * 16, s * 64, s * 256, s * 1024)


# Generated at 2022-06-22 07:06:15.474950
# Unit test for constructor of class HttpFD
def test_HttpFD():
    url = 'http://www.google.com'
    params = None
    headers = {}
    test = bool(False)
    ydl = True
    filename = None
    http_test = HttpFD(url, params, headers, test, ydl, filename)
    assert http_test.url == 'http://www.google.com', 'url has to be equal to %s' % http_test.url
    assert http_test.params == None, 'params has to be equal to %s' % http_test.params
    assert http_test.headers == {}, 'headers has to be equal to %s' % http_test.headers
    assert http_test.test == False, 'test has to be equal to %s' % http_test.test

# Generated at 2022-06-22 07:06:27.811893
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Dry run (no file will be written)
    # download to a file
    http_fd = HttpFD(None, {'nooverwrites': False, 'continuedl': False, 'noprogress': True, 'ratelimit': None, 'retries': 5, 'buffersize': None, 'noresizebuffer': False, 'test': True, 'min_filesize': None, 'max_filesize': None, 'xattr_set_filesize': False, 'updatetime': False, 'sleep_interval': None})
    is_test = True
    info_dict = {'id': 'download_test', 'url': 'https://dl.dropboxusercontent.com/s/aoyrypxk3q7qkm6/download_test_video.mp4?dl=0'}
    ctx = Download

# Generated at 2022-06-22 07:06:37.988779
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    def _test_HttpFD_real_download_chunk_size(chunk_size):
        # Create fake data source with data_len bytes and serve it in
        # chunks of chunk_size bytes. Also create a fake destination file.
        data_len = 1000
        chunk_size = min(chunk_size, data_len)
        data = compat_str(chunk_size) * (data_len // chunk_size) + compat_str(data_len % chunk_size)

        class FakeSocket(io.BytesIO):
            def makefile(self, mode, bufsize):
                del mode, bufsize  # Unused
                return self


# Generated at 2022-06-22 07:06:50.136360
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Socket patching
    class FakeSocket():
        def __init__(self):
            self.read_called = 0

        def makefile(self):
            return io.BytesIO(b'content')

        def read(self, size):
            self.read_called += 1
            if self.read_called == 2:
                raise socket.timeout()
            return b'content'

        def settimeout(self, timeout):
            pass

    class FakeHTTPResponse():
        def __init__(self):
            self.info_called = 0

        def info(self):
            self.info_called += 1
            if self.info_called == 2:
                return {'Content-length': '1024'}
            return {'Content-length': '1024', 'Last-modified': 'today'}

    # HTTP Error

# Generated at 2022-06-22 07:07:01.221251
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Testing initialization
    test = HttpFD()

    test = HttpFD(params={'nooverwrites': True, 'continuedl': True})

    test = HttpFD(params={'noprogress': True})

    test = HttpFD(params={'logger': True})

    test = HttpFD(params={'cachedir': False})

    test = HttpFD(params={'progress_with_newline': True})

    # Prefer using 'test_suit' defined in __main__
    #if sys.version_info[0] < 3:
    #    import __builtin__
    #    sys.stdout = io.BytesIO()
    #else:
    #    import builtins
    #    sys.stdout = io.StringIO()


# Generated at 2022-06-22 07:07:09.843884
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import test

    inst = test.get_test_inst()

    # Check if opened file is empty
    test_empty_file = inst.open_testfile()
    assert test_empty_file.read() == b''
    test_empty_file.close()

    # Check if opened file is not empty
    test_non_empty_file = inst.open_testfile(non_empty_file=True)
    assert test_non_empty_file.read() != b''
    test_non_empty_file.close()



# Generated at 2022-06-22 07:07:22.919476
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from io import BytesIO

    def test(**kwargs):
        b = BytesIO(b'test data')
        b.close = lambda: None
        src_length = kwargs.pop('src_length', 4)
        b.length = src_length
        filename = kwargs.pop('filename', 'test.txt')
        h = HttpFD(b, filename, **kwargs)
        assert h.bytes_left() == src_length
        assert h.name == filename
        assert h.size() == src_length
        assert h.read(100) == b'test data'
        return h

    # Test that the number of bytes is automatically guessed
    h = test(test_handle=True)
    assert h.size() == 8


# Generated at 2022-06-22 07:07:34.044662
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Test values for download_video_url
    urls = ('https://example.com/media.mp4', 'https://example.com/media.mp4?foo=bar', 'https://example.com/video.webm?foo=bar')
    # Test that temp name is created
    for url in urls:
        ydl = YdlHttp(params={'format': 'best'})
        ydl.request = Mock(return_value=Mock(status=200, read=lambda n: n, headers={}))
        test_filename = 'test'
        temp_filename = ydl._downloader.temp_name(test_filename)

# Generated at 2022-06-22 07:07:42.105588
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    import doctest
    import os
    import shutil
    import sys
    import tempfile

    from .utils import prepend_extension

    from . import YoutubeDL
    from .postprocessor.ffmpeg import FFmpegMergerPP

    tmpdir = tempfile.mkdtemp()

    def get_tmpname(filename):
        return os.path.join(tmpdir, os.path.basename(filename))

    def canned_test(test, url, expected_filesize):
        sys.stdout.write('Testing %s, expecting file size %s ... ' % (url, expected_filesize))
        test_file = get_tmpname('test.flv')

# Generated at 2022-06-22 07:07:55.085625
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test with a local file
    test1_filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test1.flv')
    test1_data = open(test1_filename, 'rb').read()
    test1_data_len = len(test1_data)
    test1_url = 'file:' + test1_filename
    fd = HttpFD(test1_url, test1_data_len, test1_url)
    assert fd.get_size() == test1_data_len
    assert fd.read(1000) == test1_data[:1000]
    assert fd.read(1000) == test1_data[1000:2000]
    size = fd.get_size()
    assert fd.read() == test

# Generated at 2022-06-22 07:09:04.211977
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # This is similar to the implementation of ytdl.get_suitable_downloader
    # in extractor/common.py
    def _get_suitable_downloader(info_dict):
        downloader = HttpFD()
        params = {
            'nooverwrites': True,
            'continuedl': False,
            'noprogress': True,
            'quiet': True,
        }
        downloader.add_info_extractor(None)
        downloader.add_default_info_extractors()
        downloader.params = params
        downloader.prepare_filename(info_dict)
        return downloader


# Generated at 2022-06-22 07:09:05.353222
# Unit test for constructor of class HttpFD
def test_HttpFD():
    HttpFD(sock=None, headers={}, url='http://foo.bar/', params={})


# Generated at 2022-06-22 07:09:13.971189
# Unit test for constructor of class HttpFD
def test_HttpFD():
    from urllib2 import build_opener, install_opener
    opener = build_opener()
    install_opener(opener)

    urlopen_hooks = []
    def urlopen(request):
        klass = request.__class__
        if len(urlopen_hooks) > 0:
            return urlopen_hooks[0](request)
        return klass.urlopen(request)
    opener.open = urlopen

    def set_urlopen_hook(hook_func):
        urlopen_hooks[:] = [hook_func]

    class TestDownloadContextManager(DownloadContextManager):
        def __init__(self, params):
            DownloadContextManager.__init__(self, params)
            self.tmpfilename = 'tmp'
            self.stream = None
            self.resume_len

# Generated at 2022-06-22 07:09:23.850696
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    from .utils import prepend_extension
    from .utils import encodeFilename
    from .HTTPDownloader import HttpFD
    from .YoutubeDL import YoutubeDL
    from .FileDownloader import LimitFileDownloader
    from io import BytesIO
    from io import DEFAULT_BUFFER_SIZE
    from io import RawIOBase

    import unittest
    import unittest.mock

    socket_timeout = socket.timeout

    class Channel(object):
        """Channel simulating socket's sendall method."""
        def __init__(self, limit, chunk_size=DEFAULT_BUFFER_SIZE):
            """Channel constructor.

            limit -- maximum number of bytes that can be read from the channel at once
            chunk_size -- size of chunks when writing to the channel
            """
            self.limit = limit

# Generated at 2022-06-22 07:09:33.309456
# Unit test for constructor of class HttpFD
def test_HttpFD():
    fd = HttpFD('-')
    fd.headers = compat_urllib_request.Headers({'Content-Type': 'video/webm'})
    fd.name = 'http://localhost/~user/filename.webm'
    fd.real_url = 'http://localhost/~user/filename.webm'
    assert fd.size is None
    assert fd.read() == b''
    assert fd.tell() == 0
    assert fd.headers['Content-Type'] == 'video/webm'



# Generated at 2022-06-22 07:09:46.136456
# Unit test for constructor of class HttpFD
def test_HttpFD():
    class DummyYDL(object):
        def __init__(self, params={}):
            self.params = params

        def to_screen(self, msg):
            print(msg)

        def trouble(self, msg, tb=None):
            raise Exception(msg)

        def download_retry_hook(self, *args, **kargs):
            print('Retry')

        def report_error(self, msg, tb=None):
            raise Exception(msg)

    class MockSocket(object):
        def __init__(self, buf, timeout=None):
            self.buf = buf
            self.timeout = timeout

        def settimeout(self, timeout):
            self.timeout = timeout

        def recv(self, size):
            d = self.buf[:size]

# Generated at 2022-06-22 07:09:56.366687
# Unit test for constructor of class HttpFD
def test_HttpFD():
    # Test HttpFD
    info = {'url': 'http://www.example.com/test.html', 'http_headers': {'Foo': 'bar', 'hello': 'world'}}
    hd = UrlFD(info, Params())
    assert hd.url == 'http://www.example.com/test.html'
    assert hd.http_headers == {'Foo': 'bar', 'hello': 'world'}
    assert not hd.test()

    info = {'url': 'https://www.example.com/test.html', 'http_headers': {'Foo': 'bar', 'hello': 'world'}}
    hd = UrlFD(info, Params())
    assert hd.url == 'https://www.example.com/test.html'
    assert hd.http

# Generated at 2022-06-22 07:10:07.767445
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():

    def _progress_hook(status):
        print('%s: %s' % (status['filename'], status['_percent_str']))
        if not status['filename'].startswith('http'):
            assert os.path.exists(encodeFilename(status['filename']))
        if status['status'] == 'finished':
            f = open(encodeFilename(status['filename']), 'rb')
            content = f.read()
            f.close()
            assert len(content) == _TEST_FILE_SIZE, 'Downloaded file is incomplete'

    class myYDL(FakeYDL):
        def __init__(self):
            FakeYDL.__init__(self)

# Generated at 2022-06-22 07:10:19.301357
# Unit test for method real_download of class HttpFD
def test_HttpFD_real_download():
    # Create a temporary test video file
    video_content = u'\u00e4'.encode('utf-8') * (1 << 20)
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(video_content)
    tmp_file.close()

    # Create a test server
    test_server = TestServer()
    test_server.serve_content(video_content, headers={'Content-type': 'video/x-flv'})

    # Get the size of the test video file
    old_size = os.path.getsize(tmp_file.name)

    # Prepare the configuration
    config = YoutubeDL().params
    config['outtmpl'] = 'test_%(id)s_%(ext)s_test'
    config['continuedl']

# Generated at 2022-06-22 07:10:30.513957
# Unit test for constructor of class HttpFD
def test_HttpFD():
    import tempfile

    def write_and_close(fd, data):
        fd.write(data)
        fd.close()

    # Test HttpFD.get_handle() on normal file
    data = b'testing HttpFD'
    fd, tmpfilename = tempfile.mkstemp()
    os.close(fd)
    fd = open(tmpfilename, 'wb')
    fd.write(data)
    fd.close()
    hfd = HttpFD(tmpfilename, 'rb')
    assert hfd.get_handle() == tmpfilename
    hfd.close()

    # Test HttpFD.get_handle() on NamedTemporaryFile
    fd = compat_NamedTemporaryFile(delete=False)
    tmpfilename = fd.name