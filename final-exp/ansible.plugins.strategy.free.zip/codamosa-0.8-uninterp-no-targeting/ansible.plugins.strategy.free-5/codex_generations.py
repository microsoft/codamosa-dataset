

# Generated at 2022-06-21 07:19:38.680339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''

    import ansible.playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, Play(), None, None)

    assert StrategyModule(tqm)._host_pinned is False
    assert StrategyModule(tqm).display is not None

# Generated at 2022-06-21 07:19:39.919217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Unit test for constructor of class StrategyModule'''



# Generated at 2022-06-21 07:19:48.591984
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    display.set_verbosity(0)

# Generated at 2022-06-21 07:19:50.041853
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:19:56.020717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # test for init
    strategy_obj_mock = StrategyModule(tqm=None)
    assert strategy_obj_mock._host_pinned == False
    assert strategy_obj_mock._loaded_tasks == {}
    assert strategy_obj_mock._blocked_hosts == {}

# Generated at 2022-06-21 07:20:09.043571
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mock_tqm = Mock(spec=TaskQueueManager)
    mock_iterator = Mock(spec=HostState, get_hosts='get_hosts')
    mock_play_context = Mock(spec=PlayContext, serialize='serialize')
    s = StrategyModule(mock_tqm)
    call1 = call(mock_iterator, mock_play_context)
    call2 = call(mock_iterator, mock_play_context)
    call3 = call(mock_iterator, mock_play_context)
    mock_tqm.side_effect = [True, False, False]
    #Test case 1: Assert run method called with required parameter
    assert_equal(s._tqm, mock_tqm)
    assert_equal(s._host_pinned, False)
    assert_equal

# Generated at 2022-06-21 07:20:19.393436
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.task.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    # Create PlayContext
    play_context = PlayContext()

    # Create Play
    play = Play()

    # Create block and add task
    block = Block()
    task = Task()
    task.action = "shell"

# Generated at 2022-06-21 07:20:28.097931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create some mock objects.
    play = Play()
    play.name = "My play"
    play.playbook = "My playbook"

    block = Block()
    block.block  = [HandlerTaskInclude("My handler")]
    block.name   = "My block"
    block.parent = play

    task = Task()
    task.action = "My action"
    task.block  = "My block"
    task.name   = "My task"
    task.parent = play


# Generated at 2022-06-21 07:20:34.121592
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    free_strategy = StrategyModule(tqm)
    # Test case 1
    # NOTE: we do not need to test this method further as it calls several methods,
    #       so if above methods are unit tested then this method will be tested as well.
    return True


# Generated at 2022-06-21 07:20:34.999058
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:20:59.436362
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(tqm=None)
    result = strategy_module.run(iterator=None, play_context=None)
    assert result is False

# Generated at 2022-06-21 07:21:07.313157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm:
        def __init__(self):
            self.hostvars = {}
    class Play:
        def __init__(self):
            self.hosts = '1.1.1.1'
            self.name = 'Test Play'
    class Host:
        def __init__(self):
            self.name = '1.1.1.1'
            self.vars = {}
    class InventoryManager:
        def __init__(self):
            self.hosts = {'1.1.1.1' : Host()}

    class Options:
        def __init__(self):
            self.connection = 'local'
            self.module_path = '/test'
            self.forks = 5
            self.become = False
            self.become_method = 'su'

# Generated at 2022-06-21 07:21:14.403276
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    TASK_TUPLE = (True, {})

    mock_task = MagicMock(name="task")
    mock_task.action = "ping"
    mock_task.get_name.return_value = 'task1'
    mock_task.any_errors_fatal = False

    mock_host = MagicMock(name="host")
    mock_host.get_name.return_value = 'host'
    mock_host.run_state = 'done'

    mock_play_context = MagicMock(name='play_context')
    mock_play_context.verbosity = 0
    mock_play_context.check_mode = False

    mock_iterator = MagicMock(name='iterator')
    mock_iterator.hosts = ['host']
    mock_iterator._hosts = ['host']
    mock

# Generated at 2022-06-21 07:21:18.438376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.tqm
    tqm = ansible.tqm
    s = StrategyModule(tqm)
    assert s._host_pinned == False

# Generated at 2022-06-21 07:21:22.265048
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	assert True

# Generated at 2022-06-21 07:21:32.914625
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Reads all data from inventory file
    import yaml
    inv_data = yaml.load('''
    all:
      children:
      - group1:
          hosts:
          - test
          - test1
    ''')
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.strategy import StrategyBase
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
   

# Generated at 2022-06-21 07:21:44.512533
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=ansible.inventory.manager.InventoryManager(loader=None, sources='localhost,'),
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    iterator = ansible.playbook.play.PlayIterator(play=ansible.playbook.play.Play().load({}, variable_manager=None, loader=None), variable_manager=None, loader=None)
    play_context = ansible.playbook.play_context.PlayContext(play=ansible.playbook.play.Play().load({}, variable_manager=None, loader=None))
    strategymodule = StrategyModule(tqm)
    strategymodule.run(iterator, play_context)

# Runs the unit

# Generated at 2022-06-21 07:21:55.241555
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import unittest.mock as mock
    class MockOption(object):
        def __init__(self):
            self.connection = None
            self.module_path = None
            self.forks = None
            self.remote_user = None
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.verbosity = None
            self.check = None
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None

# Generated at 2022-06-21 07:21:56.300486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:21:58.995541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule

    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned == False

# Generated at 2022-06-21 07:22:55.282844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None
    )
    tqm._unreachable_hosts = []
    tqm._failed_hosts = []
    tqm._stats = None
    tqm._pending_results = []
    assert StrategyModule(tqm) is not None

# Generated at 2022-06-21 07:22:59.976713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(tqm=None, strategy=None)
    assert(test_StrategyModule._host_pinned == False)


# Generated at 2022-06-21 07:23:02.334736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = None
    strategy = StrategyModule(mock_tqm)
    assert strategy is not None


# Generated at 2022-06-21 07:23:10.997711
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # needed variables are initialized
    play_context = {}; iterator = {}; result = {}
    # instance of class StrategyBase and its run() method is called
    strategy_base_instance = StrategyBase(play_context); strategy_base_instance.run(iterator, play_context, result)
    # instance of class StrategyModule and its run() method is called
    strategy_module_instance = StrategyModule(play_context); strategy_module_instance.run(iterator, play_context)

# Generated at 2022-06-21 07:23:18.434080
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = MockTaskQueueManager()
    iterator = MockIterator(tqm)
    play_context = MockPlayContext()
    sut = StrategyModule(tqm)
    sut.run(iterator, play_context)
    sut.run(iterator, play_context)
    sut.run(iterator, play_context)

# Generated at 2022-06-21 07:23:21.542943
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

    ########################################################################################
    ####  BEGIN OF TESTS FOR class StrategyModule DEFINITION  ##############################
    ########################################################################################



# Generated at 2022-06-21 07:23:25.435524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None

# Generated at 2022-06-21 07:23:26.871369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.free
    obj = ansible.plugins.strategy.free.StrategyModule()
    assert obj is not None

# Generated at 2022-06-21 07:23:27.771623
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:23:36.278816
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class Host(object):
        def __init__(self):
            self.name='10.2.2.2'
            self.port=22
    
    class Tqm(object):
        def __init__(self):
            self.RUN_OK=1
            self._terminated=0
            self.send_callback='_'

    class Iterator(object):
        def __init__(self):
            self._play=1
            self.is_failed=lambda x: 0
            self.get_next_task_for_host=lambda x,y: (1,1)
            self.get_hosts_left=lambda x: [Host()]
            self.add_tasks=lambda w,x,y,z,a: print('add_tasks')


# Generated at 2022-06-21 07:25:39.515116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    print (StrategyModule(tqm))

# Unit test

# Generated at 2022-06-21 07:25:49.674931
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import os
    import sys
    import unittest
    from unittest.mock import MagicMock

    class AnsibleAction:
        pass

    class AnsibleActionModule:
        def __init__(self, action, name, path, module_args, max_args, module_vars=None):
            self.action = action
            self.name = name
            self.path = path
            self.module_args = module_args
            self.max_args = max_args
            self.module_vars = module_vars

        def get_action(self):
            return self.action


# Generated at 2022-06-21 07:25:54.925065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy._host_pinned
    assert strategy._blocked_hosts == {}
    assert strategy._flushed_hosts == {}

# Generated at 2022-06-21 07:25:57.480206
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    tqm = ""
    iterator = ""
    play_context = ""
    strategy_module = StrategyModule(tqm)
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-21 07:26:08.294851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create object StrategyModule, object Tqm, object PlayContext and object Runner.
    strategy_module = StrategyModule(tqm=None)

    # Check if object StrategyModule is not None
    assert strategy_module is not None

    # Check if object StrategyModule is instance of class StrategyModule
    assert isinstance(strategy_module, StrategyModule)

    # Check if the class attribute ALLOW_BASE_THROTTLING is False.
    assert strategy_module.ALLOW_BASE_THROTTLING is False

    # Check if the class attribute _host_pinned is False.
    assert strategy_module._host_pinned is False


# Generated at 2022-06-21 07:26:19.362610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-21 07:26:30.222899
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    args = dict(name='testStrategyModule', hosts=['localhost'])
    p = Play().load(dict(name='Ansible Play', hosts='all', tasks=[Task().load(dict(action='ping'))]), variable_manager=VariableManager(), loader=None)
    tqm = None

    # Test with tqm equals None
    try:
        strategy = StrategyModule(tqm)
        strategy.run(PlayIterator(p), PlayContext(**args))
    except Exception as e:
        assert True
    else:
        assert False, "Expected an exception"

    # Test with tqm equals True
    tqm = True
    try:
        strategy = StrategyModule(tqm)
        strategy.run(PlayIterator(p), PlayContext(**args))
    except Exception as e:
        assert True

# Generated at 2022-06-21 07:26:37.798824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create instance of class TaskQueueManager
    TQM = TaskQueueManager()

    # create instance of StrategyModule
    SM = StrategyModule(TQM)

    # Assertion to check value of variable "ALLOW_BASE_THROTTLING"
    assert SM.ALLOW_BASE_THROTTLING == False

    # Assertion to check that instance of StrategyModule is properly created
    assert SM != None



# Generated at 2022-06-21 07:26:41.517989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Init class
    pass

# Generated at 2022-06-21 07:26:43.107031
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True