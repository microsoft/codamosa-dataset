

# Generated at 2022-06-21 07:19:38.545320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-21 07:19:42.240598
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class Test_StrategyModule(StrategyModule):
        def _step():
            pass
        def _execute_meta():
            pass
        def _get_worker_threads():
            pass
        def _queue_task():
            pass
    obj = Test_StrategyModule()
    assert obj.run(None, None) == None

# Generated at 2022-06-21 07:19:51.860367
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	
    def test_run(self, iterator, play_context):
        '''
        The "free" strategy is a bit more complex, in that it allows tasks to
        be sent to hosts as quickly as they can be processed. This means that
        some hosts may finish very quickly if run tasks result in little or no
        work being done versus other systems.

        The algorithm used here also tries to be more "fair" when iterating
        through hosts by remembering the last host in the list to be given a task
        and starting the search from there as opposed to the top of the hosts
        list again, which would end up favoring hosts near the beginning of the
        list.
        '''

        # the last host to be given a task
        last_host = 0

        result = self._tqm.RUN_OK

        # start with all workers being counted as being free

# Generated at 2022-06-21 07:19:54.084441
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: validate method run of class StrategyModule
    pass

# Generated at 2022-06-21 07:20:02.875198
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # set up some constants
    # A dict with a single key ansible_connection, the value of which is ssh
    test_host_vars = {'ansible_connection': 'ssh'}
    # The name of the test host as a string
    test_hostname = 'test_host'
    # A dict with all the args needed to create a new host instance
    test_hostinfo = {'vars': test_host_vars, 'name': test_hostname}
    # A list with one host and its vars, the vars being a single item dict
    test_hosts = [test_hostinfo]
    # An instance of the Host class with the args provided in test_hostinfo
    test_host = Host(vars=test_host_vars, name=test_hostname)
    # A dict of all the args

# Generated at 2022-06-21 07:20:05.660107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Creation of StrategyModule object is not permitted.
    # Object of class StrategyModule is created internally.
    pass

# Generated at 2022-06-21 07:20:15.296974
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    MockTqm = Mock()
    MockTqm.delegate_to_host.return_value = True
    MockTqm.RUN_OK = True
    MockTqm._terminated = False
    MockTqm.run_handlers.return_value = True
    MockTqm.send_callback.return_value = True

    MockIterator = Mock()
    MockIterator._play = {'connection': 'smart', 'name': 'test_name', 'serial': 'serial_test'}
    MockIterator.get_next_task_for_host.return_value = (True, True)
    MockIterator.hosts = ['host_one', 'host_two']
    MockIterator.is_failed.return_value = False

    MockPlayContext = Mock()
    MockPlayContext.check_mode = False

   

# Generated at 2022-06-21 07:20:19.214623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:20:25.036969
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            test_param=dict(required=True, type='str')
        )
    )
    if module.params['test_param'] == 'one':
        module.exit_json(msg="good")
    else:
        module.fail_json(msg="bad input")


# Generated at 2022-06-21 07:20:33.840522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.tqm import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    import os
    import shutil
    import sys
    import yaml
    import json

    print("start class test StrategyModule ")

    # ansible的实例模块路径
   

# Generated at 2022-06-21 07:21:11.147025
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader, module_loader
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.color import colorize
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    strategy = StrategyModule

# Generated at 2022-06-21 07:21:17.369197
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_instance = TaskQueueManager(inventory=None, variable_manager=None, loader=None)
    strategyModule_instance = StrategyModule(tqm=tqm_instance)
    strategyModule_instance.run(iterator=None, play_context=None)

# Generated at 2022-06-21 07:21:24.717347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # create mock task executor
    task_executor = Mock()
    task_executor.get_name.return_value = 'localhost'
    task_executor.run.return_value = None


# Generated at 2022-06-21 07:21:25.377308
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO
    pass


# Generated at 2022-06-21 07:21:31.138045
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Construct module object
    # tqm =
    # play_context =
    # iterator =
    module = StrategyBase(tqm=tqm)

    # Construct input parameters
    # tqm =
    # play_context =
    # iterator =

    # Invoke method
    result = module.run(iterator=iterator, play_context=play_context)


# Generated at 2022-06-21 07:21:34.787962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Unit test for constructor of class StrategyModule. '''
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None


# Generated at 2022-06-21 07:21:35.877111
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:21:44.164156
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    '''
    #The "free" strategy is a bit more complex, in that it allows tasks to
    #be sent to hosts as quickly as they can be processed. This means that
    #some hosts may finish very quickly if run tasks result in little or no
    #work being done versus other systems.

    #The algorithm used here also tries to be more "fair" when iterating
    #through hosts by remembering the last host in the list to be given a task
    #and starting the search from there as opposed to the top of the hosts
    #list again, which would end up favoring hosts near the beginning of the
    #list.
    '''
    pass

# Generated at 2022-06-21 07:21:47.293100
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Testing StrategyModule.run")


if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-21 07:21:51.220363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert isinstance(s, StrategyBase)

if __name__ == '__main__': #pragma: no cover
    test_StrategyModule()

# Generated at 2022-06-21 07:22:52.645489
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class Tqm(object):
        class Run(object):
            RUN_OK = "ok"
        def _process_pending_results(self, iterator):
            return list()
        def _wait_on_pending_results(self, iterator):
            return list()
        def send_callback(self, name, task, is_conditional=False):
            pass
    class Iterator(object):
        def __init__(self, play):
            self._play = play
            self._failed_hosts = dict()
        def is_failed(self, host):
            return False
        def add_tasks(self, host, block):
            pass
        def get_next_task_for_host(self, host, peek=False):
            return None, None

# Generated at 2022-06-21 07:23:06.985102
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    class Host:
        def __init__(self):
            self.name = 'localhost'

    class MockStrategyModule(StrategyModule):
        def __init__(self):
            self._hosts_cache = {}
            self._workers = []
            self._bl

# Generated at 2022-06-21 07:23:13.849833
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Creation of mock objects
    tqm = MagicMock()
    tqm.__class__ = MagicMock
    tqm.RUN_OK.__class__ = MagicMock
    tqm.v2_playbook_on_no_hosts_remaining.__class__ = MagicMock
    iterator = MagicMock()
    play_context = MagicMock()
    # Calling of the tested method
    StrategyModule(tqm).run(iterator, play_context)

# Generated at 2022-06-21 07:23:17.795051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Mock objects
    tqm = object()

    # Construct on test object of class StrategyModule
    test_object = StrategyModule(tqm)

    assert test_object.ALLOW_BASE_THROTTLING == False
    assert test_object._host_pinned == False
    assert test_object._tqm == tqm

# Generated at 2022-06-21 07:23:19.188371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False


# Generated at 2022-06-21 07:23:19.811353
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:23:24.323663
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # set up parameters for constructor
    tqm = mock.Mock()

    # instantiate
    myS = StrategyModule(tqm)
    assert isinstance(myS, object)

    # set up parameters for function
    iterator = mock.Mock()
    play_context = mock.Mock()

    # call function
    assert myS.run(iterator, play_context) == myS._tqm.RUN_OK


# Generated at 2022-06-21 07:23:25.985880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, type)

# Generated at 2022-06-21 07:23:26.928575
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:23:28.383548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned is False

# Generated at 2022-06-21 07:25:41.026869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.display import Display
    import sys
    import unittest

    class FakeTaskResult:
        def __init__(self, result=None):
            self.result = result

    class FakeRunner:
        def __init__(self, result):
            self.result = result

    class FakeRunnerModule:
        @classmethod
        def run(cls, *args):
            return FakeRunner(FakeTaskResult())

    class FakeLoaderModule:
        pass

    class FakeVariableManagerModule:
        pass

    class FakeTQMModule:
        def __init__(self, result):
            self.result = result
            self._workers = {'worker': None}
            self._pending_results = []
            self._terminated = False



# Generated at 2022-06-21 07:25:41.918509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:25:43.346487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyMod = StrategyModule()

# Generated at 2022-06-21 07:25:45.105255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() is not None

# Generated at 2022-06-21 07:25:46.292560
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  pass


 # Unit test for method __init__ of class StrategyModule

# Generated at 2022-06-21 07:25:58.640786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    StrategyModule(None)
    # Create inventory, variable_manager, loader, and play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 07:26:10.088779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # 
    # Create a new StrategyModule, which should return a new StrategyModule object
    #
    print("TEST: Create a new StrategyModule, which should return a new StrategyModule object")
    try:
        strategy_module = StrategyModule(None)
    except Exception as err:
        print("Failed to create a new StrategyModule object: %s" % err)
    else:
        print("Success")
    print("")
    
    #
    # Call run() method on the new StrategyModule object, which should return None
    #
    print("TEST: Call run() method on the new StrategyModule object (no iterator, play_context), which should return None")
    try:
        strategy_module.run(None, None)
    except Exception as err:
        print("Failed to call run() method: %s" % err)

# Generated at 2022-06-21 07:26:15.342259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testobj = StrategyModule(None)
    assert testobj is not None

# Generated at 2022-06-21 07:26:16.327588
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True
test_StrategyModule_run()

# Generated at 2022-06-21 07:26:18.359937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.__class__.__name__ == 'StrategyModule'
    assert strategy_module._host_pinned == False

