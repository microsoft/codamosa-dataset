

# Generated at 2022-06-21 07:19:30.066702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy
    assert not strategy._host_pinned

# Generated at 2022-06-21 07:19:39.750120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible_collections.notstdlib.moveitallout.tests.unit.mock.loader import DictDataLoader
    from ansible_collections.notstdlib.moveitallout.tests.unit.mock.vars import VariableManager
    from ansible_collections.notstdlib.moveitallout.tests.unit.mock.tqm import _InternalQueueManager
    tqm = _InternalQueueManager(None, None, None, loader=DictDataLoader())
    sm = StrategyModule(tqm)
    assert type(sm) is StrategyModule

# Generated at 2022-06-21 07:19:40.768444
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:19:49.116658
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Testing module StrategyModule with example rules
    # 1. test a valid input where module run's ansible.errors.AnsibleError never occurs.
    # 2. test a valid input where module run's ansible.errors.AnsibleError will occur.
    # 3. test an invalid input where module run's ansible.errors.AnsibleError will occur.
    # Test case 1: a valid input: iterator, play_context
    # Note: We need to do some how to create a global variable in order to pass the unit test.
    # Note: another way to pass the unit test is to mock the global variable. However, mocking global variable is complicated in python.
    global display
    display = Display()
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

# Generated at 2022-06-21 07:19:59.671404
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # mock
    mock_iterator = {
        'is_failed': lambda self, host: True
    }
    mock_play_context = {
        'ANY_ERRORS_FATAL': True
    }
    mock_tqm = {
        '_terminated': False,
        'send_callback': lambda self, callback, task, is_conditional=False: True,
        'RUN_OK': False
    }

# Generated at 2022-06-21 07:20:01.443045
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    test_instance = StrategyModule()

    assert test_instance

# Generated at 2022-06-21 07:20:04.695385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == False

# Generated at 2022-06-21 07:20:05.675123
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:20:06.535095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    #assert True

# Generated at 2022-06-21 07:20:13.363571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import os

    class TestStrategyModule(StrategyModule):
        def __init__(self, *args):
            super(TestStrategyModule, self).__init__(args)

    class TestOptions:
        connection = 'local'
        module_path = None
        forks = 10
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        private_key_file = C.DEFAULT_PRIVATE_KEY_FILE
        listhosts = None
        listt

# Generated at 2022-06-21 07:20:49.380656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import PlayBook
    from ansible.inventory import Inventory, Host, Group
    from six import StringIO

    host = Host(name='testhost')
    group = Group(name='testgroup')
    group.add_host(host)
    inventory = Inventory(loader=None)
    inventory.add_group(group)
    inventory.add_host(host)

    pb = PlayBook(
        playbook=StringIO(
            u'---\n'
            u'- hosts: testhost\n'
            u'  tasks:\n'
            u'    - fail: msg="faild on purpose"\n'
        ),
        inventory=inventory,
        callbacks=None,
        runner_callbacks=None,
        stats=None,
        passwords=None
    )
    pb._tq

# Generated at 2022-06-21 07:20:54.021320
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass # we don't really need tests for this method


    def get_hosts_left(self, iterator):

        return super(StrategyModule, self).get_hosts_left(iterator)

# Generated at 2022-06-21 07:20:59.447969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-21 07:21:00.897927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:21:03.719767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    print(strategy)

# Generated at 2022-06-21 07:21:08.879285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.free
    import ansible.plugins.strategy.linear

    assert issubclass(ansible.plugins.strategy.free.StrategyModule,
                        ansible.plugins.strategy.linear.StrategyModule) == True


# Generated at 2022-06-21 07:21:09.697237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:21:22.235957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    # Creation of object of the class Play
    loader = DataLoader()

# Generated at 2022-06-21 07:21:25.121928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('')


# Generated at 2022-06-21 07:21:33.938437
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def mock_send_callback(self, event, task, is_conditional=True):
        pass

    def mock_send_callback_strategy_on_start(self, playbook):
        self.playbook = playbook

    def mock_send_callback_playbook_on_play_start(self, play):
        pass

    def mock_send_callback_playbook_on_task_start(self, task, is_conditional=False):
        pass

    def mock_get_hosts_left(self, iterator):
        return {}

    def mock_get_next_task_for_host(self, host, peek=False):
        return (True, True)

    def mock_get_worker_for_host(self, host):
        return True


# Generated at 2022-06-21 07:22:33.521425
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create an instance of the class StrategyModule
    mod = StrategyModule(tqm=None)
    # create an instance of the class PlayContext
    play_context = PlayContext()
    # create an instance of the class Play
    play = Play()
    # create an instance of the class Host
    host = Host(name="unit-test-host")
    # create an instance of the class Host
    host2 = Host(name="unit-test-host2")
    # create an instance of the class Task
    task = Task()
    # create an instance of the class TaskResult
    taskresult = TaskResult(host=host)
    # create an instance of the class Task
    task2 = Task()
    # create an instance of the class TaskResult
    taskresult2 = TaskResult(host=host2)
    # create an instance of the class

# Generated at 2022-06-21 07:22:37.458733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    object = StrategyModule(1)
    assert object.tqm is 1
    assert object._blocked_hosts == {}
    assert object._workers == []
    assert object._notified_handlers == {}
    assert object._failed_hosts == {}
    assert object._flushed_hosts == {}
    assert object._tqm._stats.matrix == {}
    assert object._host_pinned is False

# Generated at 2022-06-21 07:22:47.496767
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Dummy class for use in test
    class DummyTQM():
        def __init__(self):
            self._terminated = False
            self.RUN_OK = True
            self.initialize = True
            self.v2_playbook_on_task_start = True
            self.v2_playbook_on_handler_task_start = True
            self.v2_playbook_on_play_start = True
            class DummyInventory():
                def __init__(self):
                    self.hosts = 4
            self.inventory = DummyInventory()
            self.workers = 5
            self.unreachable_hosts = False
            self.copy_testing = True
            self.add_runner = True


# Generated at 2022-06-21 07:22:48.856214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-21 07:22:49.488371
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:22:54.025993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTaskQueueManager(object):
        def __init__(self):
            self.RUN_OK = True

    taskqueue = TestTaskQueueManager()
    strategy = StrategyModule(taskqueue)
    assert getattr(strategy, "_host_pinned") == False

# Generated at 2022-06-21 07:23:01.573353
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # set up
    # mock class TQM
    class TQM(object):
        pass
    tqm = TQM()

    # mock class Iterator
    class Iterator(object):
        pass
    iterator = Iterator()

    # mock class PlayContext
    class PlayContext(object):
        pass
    play_context = PlayContext()

    # invoke function
    target = StrategyModule(tqm)
    result = target.run(iterator, play_context)

    # check result
    assert result is False

    # tear down



# Generated at 2022-06-21 07:23:04.045811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)


# Generated at 2022-06-21 07:23:04.966912
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:23:15.365434
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    
    # Instantiate a class object
    mock_StrategyBase = mock.Mock()
    mock_StrategyBase.ALLOW_BASE_THROTTLING = False
    to_return = mock.Mock()
    to_return.RUN_OK = 5
    mock_StrategyBase._tqm = to_return
    
    
    
    mock_tqm = mock.Mock()
    mock_iterator = mock.Mock()
    mock_play_context = mock.Mock()
    mock_tqm.RUN_OK = 5
    mock_iterator._play.max_fail_percentage = None
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    StrategyModule._host_pinned = False

# Generated at 2022-06-21 07:25:17.007212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule({
            '_tqm': None,
            '_fail_hosts': {},
            '_unreachable_hosts': {},
            '_workers_lock': None,
            '_workers': [],
            '_notified_handlers': {},
            '_blocked_hosts': {},
            '_satisfied_hosts': {},
            '_failed_hosts': {},
            '_skipped_hosts': {},
            '_conditional_hosts': {},
            '_tags': [],
            '_host_pinned': False
    })

# Generated at 2022-06-21 07:25:23.082068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy.get_hosts_left(iterator=None) == []
    assert strategy.get_next_task_lockfree(iterator=None, hosts=None, peek=False) == (None, None)

# Generated at 2022-06-21 07:25:29.814840
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import os
    import tempfile
    import shutil
    import unittest
    import hashlib
    import threading
    import re
    import json
    import collections
    import sys

    from mock import MagicMock
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-21 07:25:32.731216
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    s = StrategyModule()
    s.run()


# Generated at 2022-06-21 07:25:36.885215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test of class StrategyModule
    '''
    strategy_module = StrategyModule('tqm')
    strategy_module._host_pinned = True
    assert strategy_module._host_pinned == True, "Unit test for constructor of class StrategyModule failed!"


# Generated at 2022-06-21 07:25:41.151908
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = Ansible()
    p = Play()
    r = View()
    r.set_password('password')
    p.load(r)

# Generated at 2022-06-21 07:25:42.318120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert a
#Unit test for method of class StrategyModule

# Generated at 2022-06-21 07:25:46.933152
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ansible_module_run_test_passed = 0
    ansible_module_run_test_failed = 0
    # AnsibleModule.run will be tested with the following data sets and expected results
    return_values = [True, False]
    expected_results = [(True, False)]
    # Loop through the test data sets
    for return_value, expected_result in zip(return_values, expected_results):
        # Run the test
        #print("Testing AnsibleModule.run with return value " + return_value + " and expected result " + expected_result)
        results = StrategyModule.run(return_value)
        if results == expected_result and return_value == expected_result[0]:
            ansible_module_run_test_passed = ansible_module_run_test_passed + 1

# Generated at 2022-06-21 07:25:49.458028
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(tqm)
    strategy_module.run(iterator, play_context)



# Generated at 2022-06-21 07:25:58.300103
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

    # return self._tqm.RUN_OK
    # raise AnsibleError

    # raise AnsibleError

    # if (host_name not in self._blocked_hosts or not self._blocked_hosts[host_name]):

    # return self._tqm.RUN_OK
    # raise AnsibleError

    # raise AnsibleError

    # return self._tqm.RUN_OK
    # raise AnsibleError

    # raise AnsibleError

    # return self._tqm.RUN_OK
