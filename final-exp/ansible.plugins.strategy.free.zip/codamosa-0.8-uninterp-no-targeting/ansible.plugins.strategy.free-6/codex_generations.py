

# Generated at 2022-06-21 07:19:31.243569
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    err_msg = "AnsibleError: Using any_errors_fatal with the free strategy is not supported, as tasks are executed independently on each host"
    err_msg_1 = "AnsibleError: Using max_fail_percentage with the free strategy is not supported, as tasks are executed independently on each host"
    err_msg_2 = "AnsibleError: Using run_once with the free strategy is not currently supported. This task will still be executed for every host in the inventory list."
    err_msg_3 = "AnsibleError: The 'yum' module bypasses the host loop, which is currently not supported in the free strategy and would instead execute for every host in the inventory list."

# Generated at 2022-06-21 07:19:34.608592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, StrategyBase)
    strategy_obj = StrategyModule(tqm=None)
    assert strategy_obj._host_pinned == False


# Generated at 2022-06-21 07:19:37.044581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy is not None


# Generated at 2022-06-21 07:19:47.013873
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create dummy objects for variables of type object
    inventory = object()
    variable_manager = object()
    loader = object()
    options = object()
    passwords = object()
    display = object()
    tqm = object()

    # Create dummy object of type StrategyModule with above created dummy variables
    strategyModule = StrategyModule(tqm)

    # Creat dummy objects for variables of type bool
    is_new_play = True

    # Create dummy variables of type dict
    extra_vars = {"test": "ansible"}

    # Create dummy objects of type list
    playbooks = ["ansible.cfg"]

    # Create dummy object of type Options
    options = Options()

    # Create dummy object of type PlayContext
    play_context = PlayContext()

    # Create dummy object of type Play
    play = Play()

    # Create

# Generated at 2022-06-21 07:19:48.691658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    This is a unit test for the constructor of class StrategyModule.
    """
    s = StrategyModule("tqm")
    assert s._host_pinned == False

# Generated at 2022-06-21 07:19:53.238103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned, "Creating a new StrategyModule caused _host_pinned to not be set"


# Generated at 2022-06-21 07:19:56.979720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == False


# Generated at 2022-06-21 07:20:01.147942
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create Mock object
    tqm = Mock()
    # create instance
    strategy_module = StrategyModule(tqm)
    # create Mock object
    iterator = Mock()
    play_context = Mock()

    #  call method run
    strategy_module.run(iterator, play_context)



# Generated at 2022-06-21 07:20:01.947943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:20:11.316120
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-21 07:20:33.294772
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:20:40.240033
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # FIXME: This method only tests the case where there is no error is returned. 
    # We need to extend this method to test for all cases
    # FIXME: This test needs to be extended to check for the tasks returned.
    tqm = MockTaskQueueManager()
    strategyBase = StrategyBase(tqm)
    strategyModule = StrategyModule(tqm)
    iterator = MockIterator()
    play_context = MockPlayContext()
    strategyModule.run(iterator, play_context)


# Mock class for _Iterator

# Generated at 2022-06-21 07:20:50.063941
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    import ansible
    
    mock_tqm = mock.MagicMock()
    mock_iterator = mock.MagicMock()
    mock_play_context = mock.MagicMock()
    with mock.patch('ansible.plugins.strategy.free.StrategyBase.run'):
        strategy_module = StrategyModule(mock_tqm)
        result = strategy_module.run(mock_iterator, mock_play_context)
        ansible.plugins.strategy.free.StrategyBase.run.assert_called_with(strategy_module, mock_iterator, mock_play_context, result)
    assert result is strategy_module._tqm.RUN_OK

# Generated at 2022-06-21 07:21:02.645450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # initialization
   from ansible.playbook import Playbook
   from ansible.playbook.play import Play
   from ansible.playbook.task import Task
   from ansible.playbook.handler import Handler
   from ansible.inventory.manager import InventoryManager
   from ansible.vars.manager import VariableManager
   from ansible.parsing.dataloader import DataLoader
   from ansible.executor.task_queue_manager import TaskQueueManager
   from ansible.executor.playbook_executor import PlaybookExecutor

   # create a playbook
   playbooks = [Playbook.load("~/ansible/plays/test_custom_strategy_module.yml", variable_manager=VariableManager(), loader=DataLoader())]
   # create inventory manager, which will be passed to playbook executor
   inventory = InventoryManager

# Generated at 2022-06-21 07:21:03.730813
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:21:04.662031
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True

# Generated at 2022-06-21 07:21:13.461254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import strategy_loader

    strategy_loader.add_directory('./lib/ansible/plugins/strategy')
    context.CLIARGS = {'listhosts': True}

# Generated at 2022-06-21 07:21:15.043678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not None

# Generated at 2022-06-21 07:21:16.080070
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert False

# Generated at 2022-06-21 07:21:26.081496
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # When the function is called, then some parameters with default values are
    # changed by the function itself.
    # No need to test the values before the function call because they are not used
    # anyway.

    first_host = MagicMock(name='host 1')
    iterator = MagicMock(name='iterator')
    iterator.get_host_state.side_effect = [
        (0, 'First task on host 1'),
        (0, 'Second task on host 1'),
        (0, 'First task on host 2'),
        (0, 'Second task on host 2'),
        (0, 'Third task on host 2'),
        (0, 'First task on host 3'),
        (0, 'Second task on host 3'),
    ]

    play_context = MagicMock(name='play_context')

    strategy_obj = Strategy

# Generated at 2022-06-21 07:22:12.196951
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    myTqm = TaskQueueManager()
    myPlayContext = PlayContext()
    myIterator = PlayIterator()
    myStrategyModule = StrategyModule(myTqm)
    myStrategyModule.run(myIterator, myPlayContext)

# Generated at 2022-06-21 07:22:18.066046
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    original_host = C.DEFAULT_HOST_LIST
    original_basedir = C.DEFAULT_BASEDIR
    original_inventory = C.INVENTORY
    original_inventory_basedir = C.INVENTORY_BASEDIR
    original_inventory_script = C.INVENTORY_SCRIPT
    original_command_line_inventory = C.COMMAND_LINE_SKIP_TAGS
    original_remote_tmp = C.DEFAULT_REMOTE_TMP
    original_local_tmp = C.DEFAULT_LOCAL_TMP
    original_ansible_forks = C.DEFAULT_FORKS
    original_ansible_color = C.ANSIBLE_FORCE_COLOR

# Generated at 2022-06-21 07:22:23.546798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.tqm

    class TestStrategyModule(unittest.TestCase):
        def test_constructor(self):
            tqm = ansible.tqm.TaskQueueManager(
                inventory=None,
                variable_manager=None,
                loader=None,
                options=None,
                passwords=None,
                stdout_callback=None,
                run_tree=True,
                )
            strategy_module = StrategyModule(tqm)
            self.assertEqual(strategy_module._host_pinned, False)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 07:22:34.505637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import strategy_loader, connection_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a task manager
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources=["tests/hosts"]),
        variable_manager=VariableManager(loader=None),
        loader=None,
        passwords={},
        stdout_callback="null",
    )

    # Empty play

# Generated at 2022-06-21 07:22:36.030537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-21 07:22:46.977259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)

    play_context = PlayContext()
    inventory = InventoryManager(loader=DataLoader(), sources=u'localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    task1 = TaskInclude()


# Generated at 2022-06-21 07:22:50.068534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test to check constructor of class StrategyModule
    '''
    strategy = StrategyModule(None)
    assert not strategy._host_pinned

# Generated at 2022-06-21 07:22:54.791957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module != None

# Test 'run' method of class StrategyModule

# Generated at 2022-06-21 07:23:03.808245
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.errors import AnsibleError
    from plugins.strategy.free import StrategyModule
    from ansible.parsing.mod_args import ModuleArgsParser
    from collections import namedtuple
    try:
        # print("--- START test_StrategyModule_run ---")
        # print("--- END test_StrategyModule_run ---")
        pass
    except SystemExit:
        pass
    except:
        import traceback
        # print("An unhandled exception occurred while running the unit tests.")
        traceback.print_exc()

# Generated at 2022-06-21 07:23:10.427130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test for constructor of class StrategyModule
    :return:
    """
    strategy_mod = StrategyModule(None)
    assert(strategy_mod)
    assert(strategy_mod.ALLOW_BASE_THROTTLING == False)
    assert(strategy_mod._host_pinned == False)


# Generated at 2022-06-21 07:25:07.827566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Make the class available to other ansible modules

# Generated at 2022-06-21 07:25:13.288691
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create an instance of class StrategyModule
    strategy_module = StrategyModule(tqm)

    # if needed, create some test data for argument 'iterator'

# Generated at 2022-06-21 07:25:14.769384
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Test the return value of method run.
    '''
    pass



# Generated at 2022-06-21 07:25:27.573891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test for constructor of class StrategyModule
    """
    import sys
    import os

    test_dir = os.path.dirname(sys.modules[__name__].__file__)
    test_data_dir = os.path.join(test_dir, 'test_data')

    from ansible.errors import AnsibleError
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    try:
        StrategyModule({})
    except TypeError as e:
        assert("missing 1 required positional argument: 'tqm'" == str(e))


# Generated at 2022-06-21 07:25:39.474506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager
    from ansible.plugins.strategy.module import StrategyModule
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-21 07:25:46.585607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create mock objects
    mock_tqm = 'TEST_TQM'

    # Instantiate the class
    strategy_module = StrategyModule(mock_tqm)

    # Assert class attributes are initialized properly
    assert strategy_module._tqm == mock_tqm
    assert not strategy_module._host_pinned

# Generated at 2022-06-21 07:25:48.815540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    assert x


# Generated at 2022-06-21 07:25:54.004022
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_tqm = None

    test_strategy = StrategyModule(test_tqm)
    test_iterator = None
    test_play_context = None
    assert test_strategy.run(test_iterator, test_play_context) == None

# Generated at 2022-06-21 07:26:01.085252
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    
    StrategyModule_run_inst = StrategyModule(tqm)

    # test run with invalid parameter
    # this test should throw a TypeError
    StrategyModule.run(StrategyModule_run_inst, 1, play_context)

    # this test should throw a TypeError
    StrategyModule.run(StrategyModule_run_inst, iterator, 1)

    # test run with valid parameter
    # this test should pass
    StrategyModule.run(StrategyModule_run_inst, iterator, play_context)

    # test run with valid parameter
    # this test should pass
    StrategyModule.run(StrategyModule_run_inst, iterator, play_context)

    # this test should throw a AnsibleError
    StrategyModule.run(StrategyModule_run_inst, iterator, play_context)

# Generated at 2022-06-21 07:26:10.356597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # We need a fake tqm
    class FakeTQM(object):
        @staticmethod
        def _terminated():
            pass
        @staticmethod
        def _failed_hosts():
            pass
        @staticmethod
        def _unreachable_hosts():
            pass
        @staticmethod
        def _blocked_hosts():
            pass
        @staticmethod
        def _workers():
            pass
        @staticmethod
        def RUN_OK():
            pass
        @staticmethod
        def send_callback():
            pass
    fake_tqm = FakeTQM()

    sm = StrategyModule(fake_tqm)
    assert(sm._host_pinned == False)