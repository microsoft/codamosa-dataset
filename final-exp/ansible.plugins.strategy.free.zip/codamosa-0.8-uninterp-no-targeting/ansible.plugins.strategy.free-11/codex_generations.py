

# Generated at 2022-06-21 07:19:28.491313
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  # Test with unittest.
  pass

# Generated at 2022-06-21 07:19:31.641813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule("tqm")
    except:
        assert False


# Generated at 2022-06-21 07:19:34.316826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # just instantiate StrategyModule and make sure it doesn't throw errors
    strategy_module = StrategyModule(None)
    assert strategy_module is not None


# Generated at 2022-06-21 07:19:39.391150
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Create a new StrategyModule object
    # Test if the StrategyModule object is an instance of the StrategyModule class
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-21 07:19:46.582077
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import unittest.mock as mock
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.plugins import module_loader
    from ansible.module_utils.connection import Connection
    module_loader.add_directory('./mymodule')
    conn = Connection(module_name='mymodule.test')
    mock_tqm = mock.MagicMock()
    mock_iterator = mock.MagicMock()
    mock_play_context = mock.MagicMock()
    strategy = StrategyModule(mock_tqm)
    strategy.run(mock_iterator, mock_play_context)

# Generated at 2022-06-21 07:19:58.834363
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    class StrategyModule_fixture(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule_fixture, self).__init__(tqm)

    class Play_fixture(Play):
        def __init__(self, blocks, host_list, force_handlers):
            self.blocks = blocks
            self.hosts = host_list
            self.force_handlers = force_handlers


# Generated at 2022-06-21 07:20:01.296196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    pass

# Generated at 2022-06-21 07:20:02.196715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:20:04.202754
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('Test run()')

# Generated at 2022-06-21 07:20:05.702686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:20:28.800085
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("test_StrategyModule_run")

# Generated at 2022-06-21 07:20:31.109593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''Constructor of class StrategyModule'''
    strategy = StrategyModule(None)
    assert strategy is not None


# Generated at 2022-06-21 07:20:41.309292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    loader = DataLoader()
    host_list = [
        'localhost',
        'localhost',
        'localhost',
        'localhost'
    ]
    inventory = InventoryManager(loader=loader, sources='localhost,')
   

# Generated at 2022-06-21 07:20:42.559272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strategy = StrategyModule(None)
    assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-21 07:20:50.511709
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    class:
        StrategyModule
    method:
        run
    '''

    # Create a mock tqm
    tqm = Mock()

    # Create a strategy
    strategy = StrategyModule(tqm)

    # Create a mock iterator
    iterator = Mock()

    # Create a mock play_context
    play_context = Mock()

    # Assert method run return a boolean
    assert isinstance(strategy.run(iterator, play_context), bool)

    # Assert method run of tqm called with
    # correct parameters
    tqm.send_callback.assert_called_with('v2_playbook_on_no_hosts_remaining')

# Generated at 2022-06-21 07:20:56.333377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.ALLOW_BASE_THROTTLING == False

# Generated at 2022-06-21 07:21:01.752211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__bases__) == 1
    from ansible.plugins.strategy import StrategyBase
    assert StrategyModule.__bases__[0] == StrategyBase

# Generated at 2022-06-21 07:21:11.904390
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Tests StrategyModule.run()
    '''
    
    mock_tqm = MagicMock(spec=TaskQueueManager)

    # mock_iterator is a MagicMock with spec as _iterator
    mock_iterator = MagicMock(spec=_iterator)

    # class mock of a MagicMock with spec as PlayContext()
    play_mock_context_mock = MagicMock(
        spec=PlayContext,
        think_time=None,
    )

    mock_iterator._play.max_fail_percentage = 1

    strategy = StrategyModule(mock_tqm)

    strategy = MagicMock()

    strategy.run(mock_iterator, play_mock_context_mock)


# Generated at 2022-06-21 07:21:15.681346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    This tests the constructor of the class StrategyModule.
    """
    # create a class with a constructor
    strategy_module = StrategyModule(None)

# Generated at 2022-06-21 07:21:25.121761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.play import Play

# Generated at 2022-06-21 07:22:08.490279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    tqm = True
    x = StrategyModule(tqm)
    assert x


# Generated at 2022-06-21 07:22:09.872701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-21 07:22:13.934070
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            test = dict(required = False, type = "str", default="default")
        ),
        supports_check_mode = False
    )

    if module.params['test'] == "default":
        module.exit_json(msg="default")
    if module.params['test'] == "exception":
        raise Exception("Test Exception")

    module.exit_json(msg="failure")

# Generated at 2022-06-21 07:22:17.532796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == False
    assert strategy_module._wait_for_available_workers() == False


# Generated at 2022-06-21 07:22:18.020049
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:22:21.026490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm


# Test for function _filter_notified_failed_hosts

# Generated at 2022-06-21 07:22:33.521151
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup Test
    # Construct test object
    tqm = Mock()
    tqm.RUN_OK = 1
    tqm.send_callback = Mock()
    tqm._terminated = False
    tqm._unreachable_hosts = []
    tqm.get_active_connections = Mock()
    tqm.get_active_connection = Mock()
    tqm.terminate = Mock()
    tqm.send_callback = Mock()

    iterator = Mock()
    iterator._play = Mock()
    iterator._play.max_fail_percentage = None
    iterator._play.hosts = ['host1', 'host2']
    iterator.get_next_task_for_host = Mock(return_value=(1, 2))

# Generated at 2022-06-21 07:22:41.373302
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import logging
    import ansible.utils
    templar = ansible.utils.template.Templar()
    inventory = [{"hostname": "host1", "hostname": "host2", "hostname": "host3"}]
    host1 = ansible.vars.hostvars.HostVars(inventory[0], templar)
    host2 = ansible.vars.hostvars.HostVars(inventory[0], templar)
    host3 = ansible.vars.hostvars.HostVars(inventory[0], templar)
    print (host1.get_vars())
    print (host1.get_vars())
    print (host1.get_vars())
    task1 = ansible.playbook.task.Task()
    task2 = ansible.playbook

# Generated at 2022-06-21 07:22:42.651029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-21 07:22:45.860512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO make a real test
    strategy = StrategyModule(None)
    assert strategy is not None

# Generated at 2022-06-21 07:24:18.181203
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible import context
    from ansible.template import Templar
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError, AnsibleParserError

# Generated at 2022-06-21 07:24:23.728239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM():
        pass
    test_tqm = TestTQM()
    test_strategy = StrategyModule(test_tqm)
    print(test_strategy)
    assert isinstance(test_strategy, StrategyBase)

# Generated at 2022-06-21 07:24:26.133998
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-21 07:24:29.099828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None


# Generated at 2022-06-21 07:24:29.986479
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:24:36.534666
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:24:40.252496
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = AnsiblePlaybook()
    strategy_module = StrategyModule(tqm)
    strategy_module.run(iterator, play_context)
    return

# Generated at 2022-06-21 07:24:50.607822
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ###
    ### Set up mocks
    ###
    class MockPlayContext:
        hosts = ['host1']

    class MockTask:
        action = 'action1'

    class MockTask2:
        action = 'action2'

    class MockModule:
        class MockTask:
            BYPASS_HOST_LOOP = False

    class MockModule2:
        class MockTask:
            BYPASS_HOST_LOOP = True

    class MockActionModule:
        pass

    class MockActionModule2:
        BYPASS_HOST_LOOP = True

    class MockIterator:
        pass

    class MockTaskQueueManager:
        _terminated = False

        def _queue_task(self, host, task, task_vars, play_context):
            pass


# Generated at 2022-06-21 07:24:59.211120
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import unittest
    import ansible.module_utils.common.collections
    import ansible.plugins
    import ansible.plugins.loader
    import tempfile
    import json

    class AnsibleExitJson(Exception):
        def __init__(self, result, **kwargs):
            self.result = result

    class AnsibleFailJson(Exception):
        def __init__(self, result, **kwargs):
            self.result = result

    class MockModule:
        def __init__(self, ds=None, **kwargs):
            self.params = kwargs
            self.return_values = AnsibleExitJson(kwargs)

        def fail_json(self, *args, **kwargs):
            self.return_values = AnsibleFailJson(kwargs)


# Generated at 2022-06-21 07:25:08.071926
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # unit test
    class MockPlay(object): pass
    class MockTask(object): 
        def __init__(self):
            self.action='MockAction'
            self.task_name='task_name'
    class MockIterator(object): 
        def __init__(self):
            self._play=MockPlay()
            self._host_state={"host_name":MockHostState()}
            self.get_next_task_for_host=lambda a, b: (None, None)
    class MockHost(object):
        def __init__(self):
            self.name='host_name'
            self.get_name=lambda : 'host_name'
    class MockHostState(object):
        def __init__(self):
            self._events=[]
            self._has_trig

# Generated at 2022-06-21 07:29:10.803821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)
    assert sm.run is not None, "Constructor for StrategyModule should be defined"


# Generated at 2022-06-21 07:29:15.295855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a instance of class StrategyModule
    strategy_module = StrategyModule(None)

    # Check properties of the object
    assert strategy_module._host_pinned is False

    # Test run method
    assert strategy_module.run(None, None) is None