

# Generated at 2022-06-23 12:51:39.896151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == False

# Generated at 2022-06-23 12:51:41.643134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''

    strategy_module = StrategyModule()

# Generated at 2022-06-23 12:51:52.322599
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    import mock

    # TODO: use unittest.mock ?
    class MockedTaskQueueManager(object):
        class MockedRUN_OK(object):
            status = 'ok'

        RUN_OK = MockedRUN_OK()

    class MockLimit(object):
        def __init__(self):
            self.__names = []

        def get(self, name, value=None):
            self.__names.append(name)
            return value

    class TestStrategyModule(unittest.TestCase):
        @mock.patch('ansible.plugins.strategy.module.StrategyBase', spec=StrategyBase)
        def test_init(self, MockedStrategyBase):
            tqm = MockedTaskQueueManager()
            StrategyModule(tqm)


# Generated at 2022-06-23 12:51:54.353419
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule(tqm)
    strategyModule.run(iterator, play_context)

# Generated at 2022-06-23 12:52:01.773128
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	tqm = mock_tqm()
	iterator = mock_iterator(hosts = ['host1', 'host2'],
							 tasks = [['task1', 'task2'], ['task3']])
	play_context = mock_play_context()
	
	# Initialize a test instance of class StrategyModule
	s = StrategyModule(tqm)
	
	assert s.run(iterator, play_context) == tqm
	
	# Verify that the correct number of results is returned
	assert len(s._workers) == 2
	assert len(s._pending_results) == 3
	
	# Calls to method '_process_pending_results' should have been made

# Generated at 2022-06-23 12:52:03.297497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: How can I test this?
    assert StrategyModule is not None

# Generated at 2022-06-23 12:52:06.199742
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create the object
    # Run the method with required arguments:
    assert True

# Import all names in the Ansible plugin module
from ansible.plugins.strategy import *
# Import all names in the Ansible module
from ansible import *

# Generated at 2022-06-23 12:52:08.981801
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule

    my_test = StrategyModule(None)
    my_test.run(None, None)

    assert my_test._host_pinned == False

# Generated at 2022-06-23 12:52:17.003497
# Unit test for method run of class StrategyModule

# Generated at 2022-06-23 12:52:22.924403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock

    from ansible.plugins.strategy import StrategyModule

    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            self.mock_tqm = mock.MagicMock()
            self.test_instance = StrategyModule(self.mock_tqm)

        def test_init(self):
            # Test full constructor call
            self.assertEqual(self.test_instance.tqm, self.mock_tqm)
            self.assertEqual(self.test_instance._host_pinned, False)

    # Run unit tests
    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 12:52:25.833141
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    target_class = StrategyModule
    target_function = 'run'
    target_class_object = StrategyModule.run()
    assert target_class_object
    target_function_object = target_class.run(target_class_object)
    assert target_function_object
    target_function_object.assert_called_with()


# Generated at 2022-06-23 12:52:35.797679
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """
    Unit test for method `run` in class `StrategyModule`
    """
    # Create a mock of class `TaskQueueManager`
    tqm_instance = mock.MagicMock(spec=TaskQueueManager)
    tqm_instance.send_callback.return_value = None

    # Create an instance of class `StrategyModule`
    strategy_module_instance = StrategyModule(tqm=tqm_instance)

    # Mock the return value of method `__init__` of object `strategy_module_instance`
    strategy_module_instance._set_hosts_cache = mock.MagicMock(spec=StrategyBase._set_hosts_cache)
    strategy_module_instance._set_hosts_cache.return_value = None
    strategy_module_instance.get_hosts_left = mock

# Generated at 2022-06-23 12:52:44.995007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    def display_ok(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
        print('OK: %s' % msg)


# Generated at 2022-06-23 12:52:46.310491
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:52:53.350395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cat = StrategyModule(tqm="tqm")
    assert cat.tqm == "tqm"
    assert cat.get_hosts_left(iterator="iterator")
    cat.run(iterator="iterator", play_context="play_context")
    cat._set_hosts_cache(play="play")
    cat.add_tqm_variables(task_vars="task_vars", play="play")
    cat.update_active_connections(results="results")

# Generated at 2022-06-23 12:52:54.442556
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test for method run of class StrategyModule
    pass

# Generated at 2022-06-23 12:53:02.836646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    tqm = DictData()
    tqm.RUN_OK = 0
    tqm.get_socket_path = lambda : '/tmp'
    tqm._stats = DictData()
    tqm._stats.dark = dict()
    tqm._stats.processed = dict()
    tqm._tqm_variables = VariableManager(loader=None)
    tqm._terminated = False
    tqm._unreachable_hosts = dict()
    tq

# Generated at 2022-06-23 12:53:06.749082
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:53:08.660826
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule(tqm).run(iterator, play_context)

# Generated at 2022-06-23 12:53:15.989797
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible import context
    from ansible.executor import task_queue_manager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    import yaml
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule as StrategyModuleLinear
    from ansible.template import Templar
    from ansible.module_utils._text import to_text
    import os
    
    context.CLIARGS = namespace = argparse.Namespace()
    context.CLIARGS.listhosts = False
    context.CLIARGS.listtasks = False

# Generated at 2022-06-23 12:53:25.078221
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
 
    # In these tests we are mocking the plugins, this is a hack to get access to them.
    import ansible.plugins.strategy
    old_plugins = ansible.plugins.strategy.strategy_loader._modules
    ansible.plugins.strategy.strategy_loader._modules = {}
    for module in old_plugins:
        ansible.plugins.strategy.strategy_loader._modules[module] = old_plugins[module]

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 12:53:27.577705
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        print('In method run of class StrategyModule')
    except AttributeError as ae:
        print(ae)


# Generated at 2022-06-23 12:53:28.340810
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:53:29.690858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 12:53:38.088875
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.role
    import ansible.playbook.handlerblock
    import ansible.playbook.include

    tqm = mock.Mock()
    iterator = mock.Mock()
    play_context = mock.Mock()

    tqm.get_failed_hosts = mock.Mock(return_value=None)
    tqm.notified_handlers = mock.Mock(return_value=None)
    tqm.worker_pool = mock.Mock(return_value=None)
    tqm.send_callback = mock.Mock(return_value=None)
    tqm

# Generated at 2022-06-23 12:53:47.853557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.tqm import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.vars import VariableManager

    play_source =  dict(
            name = "Ansible Play 0",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )



# Generated at 2022-06-23 12:53:49.710405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module is not None

# Generated at 2022-06-23 12:53:59.755800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook
    import ansible.inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    pb = ansible.playbook.PlayBook(
            playbook="TestPlay",
            callbacks= ansible.playbook.PlayBookCallbacks(),
            runner_callbacks=ansible.playbook.PlayBookRunnerCallbacks(stats=ansible.playbook.AggregateStats()),
            inventory=ansible.inventory.Host("127.0.0.1"),
            variable_manager=ansible.playbook.PlayVariableManager(),
            loader=ansible.playbook.PlaybookFileLoader("TestPlay", "TestPlay")
            )

# Generated at 2022-06-23 12:54:00.705202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return

# Generated at 2022-06-23 12:54:11.526926
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from collections import namedtuple
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from copy import deepcopy
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.display import Display

    display = Display

# Generated at 2022-06-23 12:54:13.753002
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(tqm)
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-23 12:54:24.393182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    inventory.subset('all')
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

# Generated at 2022-06-23 12:54:25.429608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 12:54:30.336978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy._host_pinned == False
#
# # Unit test for function _filter_hosts
# def test__filter_hosts():
#     # TODO: Create unit test for function _filter_hosts
#     pass
#

# Generated at 2022-06-23 12:54:39.166547
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import __main__
    import os
    import sys

    try:
        from unittest.mock import patch
        from unittest.mock import MagicMock
    except ImportError:
        from mock import patch
        from mock import MagicMock

    from ansible.plugins.strategy import StrategyModule

    sys.modules['__main__'] = __main__

    from ansible.plugins.strategy import StrategyModule

    sys.modules['__main__'].ActionBase = object

    mock_loader = MagicMock(**{})

    mock_variable_manager = MagicMock(**{})

    mock_loader_path = '/a/b/c/d/e/f'
    mock_loader_path_exists = [True]

    def mock_exists(self):
        return mock_loader_path_ex

# Generated at 2022-06-23 12:54:39.778628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:54:41.290159
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    S_M = StrategyModule()

    S_M.run()

# Generated at 2022-06-23 12:54:48.558384
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    TASK = dict(action='setup')

    class TestHost:
        def __init__(self, test_host_name):
            self.name = test_host_name

        def get_name(self):
            return self.name

    class TestIterator:
        def __init__(self):
            self.hosts_left = ['host1', 'host2']

        def get_hosts_left(self):
            return self.hosts_left

        def is_failed(self, host):
            return True

        def get_next_task_for_host(self, host, peek=False):
            return (self.is_failed(host), TASK)

    host1 = TestHost('host1')
    host2 = TestHost('host2')
    hosts_left = [host1, host2]



# Generated at 2022-06-23 12:54:58.950401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator

    from units.mock.manager import MockManager
    from units.mock.loader import DictDataLoader
    from units.mock.plugins import ActionBase
    from units.mock.vars import VariableManager

    class TestModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            super(TestModule, self).run(tmp, task_vars)


    mock_loader = DictDataLoader({
        "test.yml": '''
        - hosts: localhost
          gather_facts: false
          connection: local
          tasks:
           - test_module: data={{ data }}
        ''',
    })

    mock_manager = Mock

# Generated at 2022-06-23 12:55:00.834501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert 1 == 1


# Generated at 2022-06-23 12:55:06.280682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a MockQueueManager and MockDisplay as we don't need everything in the queue manager and display to be fully functional
    class MockQueueManager:
        class MockDisplay:
            verbosity = 1
        display = MockDisplay()
    tqm = MockQueueManager()

    # Now we can instantiate the StrategyModule and call the run function
    strategy_module = StrategyModule(tqm)
    strategy_module.run(None, None)

# Generated at 2022-06-23 12:55:07.009720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:55:14.585822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert hasattr(strategy_module, '_flush_cache'), "Variable '_flush_cache' not initialized."
    assert hasattr(strategy_module, '_blocked_hosts'), "Variable '_blocked_hosts' not initialized."
    assert hasattr(strategy_module, '_host_pinned'), "Variable '_host_pinned' not initialized."

# Generated at 2022-06-23 12:55:16.285732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert type(module) == StrategyModule

# Generated at 2022-06-23 12:55:17.746527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:55:26.629881
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """
    StrategyBase.run(iterator, play_context)
    """
    # Instantiate a test instance of class StrategyModule
    test_strategyModule = StrategyModule(tqm)

    # Declare test values that should not be altered during testing
    test_iterator = iterator
    test_play_context = play_context

    # Declare test values that may be altered during testing
    test_result = True

    # Execute test function
    result = test_strategyModule.run(test_iterator, test_play_context)

    # Verify expectations
    assert result is test_result


# Generated at 2022-06-23 12:55:28.162806
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    pass

# Generated at 2022-06-23 12:55:35.726950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyModule


# Generated at 2022-06-23 12:55:45.550798
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    from ansible.playbook.iterator import TaskIterator
    from ansible.module_utils.connection import Connection
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    test_host = MagicMock(spec=InventoryManager, name='test_host')
    test_host.get_name.return_value = 'test_host'

    test_task = MagicMock(spec=TaskIterator, name='test_task')
    test_task.action = 'action'
    test_task.play

# Generated at 2022-06-23 12:55:55.120680
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    import ansible.errors
    mock_tqm = mock.MagicMock()
    mock_iterator = mock.MagicMock()
    mock_play_context = mock.MagicMock()

    host = mock.MagicMock()
    host.get_name.return_value = "localhost"
    mock_tqm.get_hosts.return_value = [host]
    mock_tqm.get_restart_mode.return_value = False
    mock_tqm.RUN_OK = True

    action_loader_mock = mock.MagicMock()
    mock_action = mock.MagicMock()
    action_loader_mock.get.return_value = mock_action

    getattr_mock = mock.MagicMock()
    getattr_mock.return_value

# Generated at 2022-06-23 12:55:56.522503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:55:57.259379
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:55:58.496549
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:55:59.210784
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:56:01.358960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:56:06.969841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test the constructor of class StrategyModule with no error
    '''
    tqm = MockTQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.get_hosts_left('hosts_left') == 'hosts_left'
    assert strategy_module.take_step('task', 'host_name') is None


# Generated at 2022-06-23 12:56:15.867434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  from ansible.playbook.play import Play
  from ansible.inventory.manager import InventoryManager
  from ansible.plugins.loader import action_loader
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.vars.manager import VariableManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.included_file import IncludedFile
  from ansible.executor.process.worker import WorkerProcess
  from ansible.executor.task_result import TaskResult
  from ansible.module_utils._text import to_text
  from ansible.utils.display import Display
  import tempfile
  import shutil
  import os

  TEST_DIR = tempfile.mkdtemp()

# Generated at 2022-06-23 12:56:17.278974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 12:56:18.126338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 12:56:21.174105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)

# unit test for method _filter_notified_hosts of class StrategyModule

# Generated at 2022-06-23 12:56:23.278987
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None
    strategyModule = StrategyModule(tqm)
    strategyModule.run(iterator, play_context)

# Generated at 2022-06-23 12:56:24.796663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=1)._tqm==1


# Generated at 2022-06-23 12:56:26.732523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, StrategyBase)
    print ("Test StrategyModule: constructor")


# Generated at 2022-06-23 12:56:36.979137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    play_source =  dict(
            name = "Ansible Play 1",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

# Generated at 2022-06-23 12:56:40.019437
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	"""
	StrategyModule: strategy which queues tasks in order by host, but does not wait for a host
	to finish before sending a task for the next
	"""

	pass

# Generated at 2022-06-23 12:56:49.066829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.executor.process.worker import WorkerProcess
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import strategy_loader
    from ansible.plugins.action import ActionBase

    class TestActionModule(ActionBase):

        def run(self, tmp=None, task_vars=None):
            self._supports_check_mode = False
            self._supports_async = True


# Generated at 2022-06-23 12:56:49.540189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:57:00.549218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager
    from ansible.inventory import inventory
    import ansible.parsing.dataloader
    import ansible.playbook
    import ansible.vars.manager
    import ansible.template
    import ansible.utils.display

    dl = ansible.parsing.dataloader.DataLoader()
    tqm = task_queue_manager.TaskQueueManager(
        inventory=inventory.Inventory(dl),
        variable_manager=ansible.vars.manager.VariableManager(loader=dl),
        loader=dl,
        options=None,
        passwords=None,
    )
    # pb = ansible.playbook.Playbook.load(playbook="ping.yml", variable_manager=ansible.vars.manager.VariableManager(

# Generated at 2022-06-23 12:57:10.183211
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	# Create a mock object to replace "ansible.plugins.strategy.ActionBase" class
	class MockTemplate(object):
		def __init__(self, loader, variables):
			pass

		def template(self, task_name, fail_on_undefined=False):
			# Return the task name space by space
			return task_name.split(" ")

	# Create a mock object to replace "ansible.plugins.loader.ActionModuleLoader" class
	class MockActionLoader(object):
		def __init__(self, class_only=True, collection_list=None):
			pass

	# Create a mock object to replace "ansible.plugins.ActionBase" class

# Generated at 2022-06-23 12:57:12.894684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        task_queue_manager = None
        strategy = StrategyModule(task_queue_manager)
        assert strategy is not None
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-23 12:57:16.402755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    test_tqm = None
    strategyModule_obj = StrategyModule(test_tqm)



# Generated at 2022-06-23 12:57:19.270403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #tqm = mock.Mock()
    #strategy_module = StrategyModule(tqm)
    return 0


# Generated at 2022-06-23 12:57:23.914754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Try with default values
    strategy_module = StrategyModule(None)
    assert strategy_module is not None

    # Try with values
    strategy_module = StrategyModule(True)
    assert strategy_module is not None


# Generated at 2022-06-23 12:57:35.098071
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    os.environ["ANSIBLE_FORCE_COLOR"] = "false"
    path = os.path.dirname(os.path.realpath(__file__)) + "/../../../lib/ansible/constants.py"
    module = imp.load_source('constants', path)
    module.DEFAULT_INTERNAL_POLL_INTERVAL = 0
    strategy_modle = StrategyModule(Tqm(None))
    action_loader.set_actions_cache({})
    strategy_modle.RUN_OK = True
    strategy_modle._tqm._terminated = False
    strategy_modle._workers = []
    strategy_modle._loader.get_basedir = MagicMock(return_value='')
    strategy_modle._blocked_hosts = {}
    strategy_modle

# Generated at 2022-06-23 12:57:45.992129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 12:57:55.377598
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    global_vars = dict(
        ansible_connection='network_cli',
        ansible_network_os='ios'
    )
    mock_module = 'ios_command'
    mock_task_args = dict(commands=['show version'])
    p = Play().load({}, variable_manager=VariableManager(), loader=DictDataLoader())
    t = Task().load(dict(action=dict(mock_module, args=mock_task_args), register='output'),
                    variable_manager=VariableManager(), loader=DictDataLoader())

# Generated at 2022-06-23 12:57:56.307203
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
# ==============================================================================


# ------------------------------------------------------------------------------

# Generated at 2022-06-23 12:57:58.971182
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  tqm = TQM()
  play_context = {}
  iterator = MockIterator()
  tqm._terminated = False
  strategy = StrategyModule(tqm)
  assert strategy.run(iterator, play_context) == False

# Generated at 2022-06-23 12:58:07.610105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Play, PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    p = Play()
    pc = PlayContext()
    i = InventoryManager(host_list='test/test_handler/test_inventory.py')
    t = TaskQueueManager(inventory=i, play=p, play_context=pc)
    s = StrategyModule(t)
    assert s

# Generated at 2022-06-23 12:58:09.739782
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy._tqm == tqm
    assert strategy._display == display

# Generated at 2022-06-23 12:58:10.849039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:58:11.755200
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    raise Exception('Not implemented')

# Generated at 2022-06-23 12:58:12.715503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 12:58:14.173303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 12:58:14.989641
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:58:16.323505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 12:58:17.449138
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:58:27.850914
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    TASK_NAME = 'Install stress package on ubuntu'
    TASK_MODULE = 'apt'
    TASK_ACTION = 'name=stress state=present'
    HOST_NAME = 'google.com'
    my_vars = {}
    my_vars['ansible_ssh_host'] = HOST_NAME
    my_vars['ansible_user'] = 'ansible'

    #init strategy
    tqm = None
    iterator = None
    play_context = None
    self = StrategyModule(tqm)

    #init hosts
    hosts = [Host(name=HOST_NAME, port=22)]
    iterator = TaskIterator(play=play, hosts=hosts, tasks=tasks, play_context=play_context)

    #init tasks

# Generated at 2022-06-23 12:58:37.660177
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    host_pinned = False
    workers_free = None
    results = None
    workers = list()
    for worker in workers:
        if worker:
            pass
        else:
            pass
        if worker.is_alive():
            pass
        else:
            pass
        if worker._task._uuid:
            pass
        else:
            pass
    work_to_do = WorkToDo()
    while work_to_do:
        if len(hosts_left) == 0:
            pass
        else:
            pass
        if self._host_pinned:
            if workers_free == 0:
                if work_to_do:
                    pass
                else:
                    pass
            else:
                pass
        else:
            pass
        results = self._process_pending_results(iterator)


# Generated at 2022-06-23 12:58:39.946608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert(strategy.name == 'free')
    assert(not strategy._host_pinned)

# Generated at 2022-06-23 12:58:43.394184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    print(strategy_module)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 12:58:45.051448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-23 12:58:50.245621
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # test for the method run of class StrategyModule
    ansible_queued_task_result = QueuedTaskResult()
    ansible_queued_task = QueuedTask()
    test_obj = StrategyModule(ansible_queued_task_result)
    test_obj.run(ansible_queued_task,'play_context')


# Generated at 2022-06-23 12:58:57.602579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.parsing.dataloader  import DataLoader
    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader
    data_loader = DictDataLoader({})
    inventory = InventoryManager(loader=data_loader, sources=["localhost"])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='echo "boo"')),
            ]
        )


# Generated at 2022-06-23 12:58:59.881155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    mod = StrategyModule(None)
    assert mod is not None

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:59:00.483814
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-23 12:59:06.772978
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    global Exception
    try:
        from unittest.mock import Mock, patch, call
    except ImportError as e:
        from mock import Mock, patch, call


    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.role

    play_context = PlayContext()
    play_context._tqm = Mock()
    play_context._tqm._terminated = False
    play_context._tqm._shared_loader_obj = Mock()

    play_context._tqm._unreachable_hosts = set()
    play_context._tqm._stats = Mock()

    play_context._tqm._workers = [1]
    play_context._tqm._current_worker = 1
    ################################

# Generated at 2022-06-23 12:59:16.235249
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.plugins.strategy import StrategyModule
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display
    display = Display()
    import collections
    
    mock_all = Sentinel()
    
    mock_task = Task()
    
    mock_block = Block()

    mock_iterator = mock_all

# Generated at 2022-06-23 12:59:21.160457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    my_StrategyModule = StrategyModule(None)
    assert isinstance(my_StrategyModule, StrategyModule)
    assert my_StrategyModule._host_pinned is False


# Generated at 2022-06-23 12:59:21.817995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 12:59:33.408212
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from collections import namedtuple
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host_vars = HostVars([], variable_manager=VariableManager())
    variable_manager = VariableManager(loader=DataLoader(), inventory=host_vars)
    play_context = namedtuple('play_context', ['remote_addr'])
    task_iterator = namedtuple('task_iterator', ['_play'])

# Generated at 2022-06-23 12:59:42.679080
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def mock_wait_on_pending_results(iterator):
        return "mock_results"

    display = Display()
    mock_iterator = MagicMock()
    mock_play_context = MagicMock()
    test_strategy_module = StrategyModule("mock_tqm")
    monkeypatch.setattr(test_strategy_module, "_wait_on_pending_results", mock_wait_on_pending_results)

    result = test_strategy_module.run(mock_iterator, mock_play_context)
    assert result == "mock_results"
    mock_play_context.check_conditional_blocks.assert_called_with("mock_results")
    test_strategy_module.run_handlers.assert_called_with(mock_iterator, mock_play_context)

# Generated at 2022-06-23 12:59:44.097032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == False

# Generated at 2022-06-23 12:59:50.731148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import PlaybookExecutor
    from ansible_collections.ansible.community.tests.unit.stubs.playbook_executor import ReturnData

    Options = ReturnData

    options = Options()
    fake_loader = "fake_loader"
    fake_variable_manager = "fake_variable_manager"
    fake_shared_loader_obj = "fake_shared_loader_obj"
    fake_play_context = "fake_play_context"

    p = PlaybookExecutor(playbooks=['playbook.yml'], inventory=['inventory'], loader=fake_loader,
                         variable_manager=fake_variable_manager,
                         shared_loader_obj=fake_shared_loader_obj,
                         options=options, passwords={}, play_context=fake_play_context)


# Generated at 2022-06-23 12:59:57.789408
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mock_self = Mock()
    mock_iterator = Mock()
    mock_play_context = Mock()
    mock_self._display.warning = Mock()
    mock_self._tqm.send_callback = Mock()
    mock_self.get_hosts_left = Mock(return_value=['some_hosts'])
    mock_self._tqm._terminated = False
    mock_self._host_pinned = False
    mock_self._set_hosts_cache = Mock(return_value=['hosts_cache'])
    mock_self._tqm.RUN_OK = True
    mock_self._workers = ['workers']
    mock_self._variable_manager.get_vars = Mock(return_value=['task_vars'])
    mock_self.add_tqm_vari

# Generated at 2022-06-23 13:00:07.881586
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_source =  dict(
        name = "Ansible Play 0",
        hosts = 'local',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World!'))),
            dict(action=dict(module='shell', args='ls'))
        ]
    )

# Generated at 2022-06-23 13:00:09.804277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)
    # TODO: write tests
    #assert False, "TODO: write tests"


# Generated at 2022-06-23 13:00:11.714213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strat = StrategyModule(tqm)

    assert strat._host_pinned == False

# Generated at 2022-06-23 13:00:20.536454
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = MockHost()
    host.set_name("localhost")
    host.set_address("127.0.0.1")
    play = MockPlay()
    play.set_name("test_play")
    play.set_connection("local")
    play.set_hosts(["localhost"])
    play.set_gather_facts(False)
    play.set_host(host)

    task = MockTask()
    task.set_name("test_task")
    task.set_connection("local")
    task.register_host(host)
    task.set_vars({"test_var":"test_value"})
    task.set_action("test_action")
    task.set_run_once(False)
    task.set_block("test_block")

# Generated at 2022-06-23 13:00:22.119453
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_object = StrategyModule()
    assert my_object is not None

# Generated at 2022-06-23 13:00:23.156957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:00:33.896200
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    display = Display()
    display.debug("It's test_StrategyModule_run method ")
    display.debug("It's test_StrategyModule_run method ",screensaver_control=True)
    display.debug("It's test_StrategyModule_run method ",truncate=True,wordwrap=True)
    display.display("It's test_StrategyModule_run method ","stderr",False)
    display.display("It's test_StrategyModule_run method ","stderr",False,True)
    display.display("It's test_StrategyModule_run method ","stdout",True)
    display.display("It's test_StrategyModule_run method ","stdout",True,False)
    display.display("It's test_StrategyModule_run method ","stdout",True,True)

# Generated at 2022-06-23 13:00:40.018481
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  # Setup
  from collections import namedtuple
  from ansible.errors import AnsibleError
  from ansible.template import Templar
  from ansible.vars import VariableManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.inventory import Inventory
  from ansible.playbook.play_context import PlayContext
  from ansible.executor.process.worker import WorkerProcess
  from ansible.plugins.callback import CallbackBase
  
  loader = DataLoader()
  variable_manager = VariableManager()
  variable_manager.extra_vars = {}
  inventory = Inventory(loader, variable_manager, 'localhost,')
  variable_manager.set_inventory(inventory)
  callback = CallbackBase()

# Generated at 2022-06-23 13:00:40.909805
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 13:00:41.542096
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass



# Generated at 2022-06-23 13:00:46.848561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude

    inc_file = TaskInclude(
        play=None,
        basedir=None,
        use_handlers=True,
        defname=None,
        loop=None,
        condition=None,
        loop_args=None
    )

    tqm = None

    StrategyModule(tqm)

# Generated at 2022-06-23 13:00:49.321341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTqm()
    strategyModule = StrategyModule(tqm)
    assert strategyModule


# Generated at 2022-06-23 13:00:58.674979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = ['test_host1', 'test_host2']
    host_list = list(map(lambda x: {'hostname': x}, host_list))
    host_list = list(map(lambda x: Host(x), host_list))
    play_context = PlayContext()
    workers = []
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 13:01:02.688336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm="tqm")
    assert strategy is not None, "Creating StrategyModule failed"

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:01:05.083113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakeTaskQueueManager()
    assert(isinstance(StrategyModule(tqm), StrategyModule))


# Generated at 2022-06-23 13:01:14.832245
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    h = Host("h1")
    h._name = "h1"
    p = Play()
    t = Task()
    p._task_counts = {'_total': 1, '_tasks': defaultdict(lambda: 1, {'t1': 1}), '_handlers': defaultdict(lambda: 0)}
    p._included_files = []
    p._handlers = {'t1': [t]}

    i = PlayIterator(p, None)
    i._play = p
    pc = PlayContext()
    tm = TaskManager(0, h, t, pc, None)
    tm._inventory = DictDataLoader({'h1': h})
    tm._variable_manager = VariableManager()
    tm._tracker = Tracker()
    tm._hostvars = {}
    t

# Generated at 2022-06-23 13:01:20.909748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    options = PlaybookExecutor.load_extra_vars(loader, options, passwords)
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-23 13:01:28.159867
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.utils.display import Display
    from ansible.plugins.strategy import StrategyBase

    display = Display()
    strategy_base = StrategyBase(None)
    strategy_module = StrategyModule(None)
    import unittest

    class TestStrategyModule(unittest.TestCase):

        def test_run(self):
            with self.assertRaises(AnsibleError):
                strategy_module.run(None, None)

    test_case = TestStrategyModule()
    test_case.test_run()

# Generated at 2022-06-23 13:01:32.690070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    sm = StrategyModule(tqm)
    assert sm.get_hosts_left([]) == []
    assert sm.get_hosts_remaining([]) == []
    assert sm.get_failed_hosts([]) == []


# Generated at 2022-06-23 13:01:33.323865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:01:41.011421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.strategy import StrategyBase
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess

    display = Display()

    loader