

# Generated at 2022-06-23 12:51:52.494047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    strategy = StrategyModule(TaskQueueManager())
    assert strategy._host_pinned is False

    # the first test below makes sure that the StrategyModule is returning the same
    # module_path as the default value in ansible.constants
    assert strategy.get_option('module_path') == C.DEFAULT_MODULE_PATH, 'Module path returned by StrategyModule is not the same as \
    the default module path in ansible.constants'
    # the second test below makes sure that the StrategyModule is correctly handling changing the
    # value of the module_path option
   

# Generated at 2022-06-23 12:52:00.507925
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class TestStrategyModule_run():
        def __init__(self, tqm):
            self.tqm = tqm

        def run(self, iterator, play_context):
            self.run_called = True

    class TestSelf():
        def __init__(self):
            self.tqm = TestStrategyModule_run(self)
            self.tqm.run_called = False

    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            self.original__init__ = StrategyModule.__init__

            # mock _init__ so we can use a fixed copy of self
            def _init__(self, tqm):
                self.instance = test_self

            StrategyModule.__init__ = _init__

            # fake __init__
           

# Generated at 2022-06-23 12:52:03.287907
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert(module)

# Generated at 2022-06-23 12:52:03.866682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 12:52:04.618140
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:52:13.675983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a manager for this task queue
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=VariableManager(),
        loader=DataLoader(),
        passwords=dict(),
    )

    # Create a playbook execution
    pe = PlaybookExecutor(
        playbooks=None,
        inventory=None,
        variable_manager=VariableManager(),
        loader=DataLoader(),
        passwords=dict(),
    )

    # Create a strategy module
    strategy_module = StrategyModule(tqm)

    assert strategy_module._host

# Generated at 2022-06-23 12:52:24.003341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    play_context = PlayContext()
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-23 12:52:24.520505
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ...

# Generated at 2022-06-23 12:52:25.906700
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Unit test for method run of class StrategyModule
    '''


# Generated at 2022-06-23 12:52:29.104221
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context = mock.Mock()
    iterator = (i for i in xrange(100) if i < 10)
    results = StrategyModule.run(play_context, iterator)
    assert results == True

# Generated at 2022-06-23 12:52:32.773639
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.utils.sentinel import Sentinel

    tqm = Sentinel("tqm")
    iterator = Sentinel("iterator")
    play_context = Sentinel("play_context")
    sm = StrategyModule(tqm)
    sm.run(iterator, play_context)

# Generated at 2022-06-23 12:52:36.164565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()

    s = StrategyModule(tqm)
    assert s is not None
    assert isinstance(s, StrategyModule)
    assert isinstance(s, StrategyBase)

# Generated at 2022-06-23 12:52:45.237569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self._terminated = False
        def send_callback(self, *args, **kwargs):
            pass
        def send_callback_queue(self, *args, **kwargs):
            pass
        def RUN_OK(self):
            pass
    class iterator:
        def __init__(self):
            self._play = None
        def get_hosts_left(self):
            pass
        def get_failed_hosts(self):
            pass
        def mark_host_failed(self):
            pass
        def get_next_task_for_host(self):
            pass
        def get_failed_hosts(self):
            pass
    class play_context:
        def __init__(self):
            pass

# Generated at 2022-06-23 12:52:51.403549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy_loader import StrategyModule #pylint: disable=unused-variable
    from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.executor.task_queue_manager import TaskQueueManager, _task_queue_terminated
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    tqm = TaskQueueManager(inventory=None, variable_manager=VariableManager(), loader=None, passwords=None, stdout_callback=None, run_tree=True)

# Generated at 2022-06-23 12:52:55.532115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     # Call function without params, should fail
    with pytest.raises(TypeError):
        StrategyModule()
    # Call function with valid param, should pass
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None

# Generated at 2022-06-23 12:53:02.475315
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import pytest
    import os
    import datetime
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,',)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 12:53:03.164616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 12:53:07.035525
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('Testing StrategyModule')
    print('  Testing function run')
    test_strategy_module = StrategyModule(None)
    test_strategy_module.run(None, None)

test_StrategyModule_run()

# Generated at 2022-06-23 12:53:09.506472
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(0)._host_pinned == False

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 12:53:12.271908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)

    assert strategy_module._host_pinned == False, "_host_pinned variable should be False"

# Generated at 2022-06-23 12:53:18.202758
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    fake_iterator = 'fake_iterator'
    fake_play_context = 'fake_play_context'
    fake_tqm = 'fake_tqm'
    t = StrategyModule(fake_tqm)
    t.run(fake_iterator, fake_play_context)

# Generated at 2022-06-23 12:53:27.217262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global_vars = {}
    play_context = {}
    connection_info = {}
    class TQM(object):
        def __init__(self):
            self.hostvars = global_vars
            self.connection_info = connection_info
    tqm = TQM()
    class Host():
        def __init__(self):
            self.name = 'testhost'
            self.vars = global_vars
    host = Host()
    strategy = StrategyModule(tqm)
    strategy.add_host(host)
    #class Action():
    #    def __init__(self):
    #        self.BYPASS_HOST_LOOP = False
    #class Role():
    #    def __init(self):
    #        self.has_run = False
    #        self

# Generated at 2022-06-23 12:53:31.421097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create an empty AnsibleTaskQueueManager() object.
    # TODO: Replace with a real object when implemented.
    tqm = None

    # Create an instance of StrategyModule.
    strategy_module = StrategyModule(tqm)

    # Make sure StrategyModule can be instantiated.
    assert strategy_module is not None


# Generated at 2022-06-23 12:53:35.360993
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mocked_tqm = MagicMock()
    mocked_iterator = MagicMock()
    mocked_play_context = MagicMock()
    StrategyModule(mocked_tqm).run(mocked_iterator, mocked_play_context)


# Generated at 2022-06-23 12:53:39.230948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.count == 0)
    obj1 = StrategyModule(1)
    assert(obj1.count == 1)
    obj2 = StrategyModule(2)
    assert(obj2.count == 2)


# Generated at 2022-06-23 12:53:49.588197
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.six import assertRegex
    from ansible.module_utils.six import assertCountEqual
    from collections import namedtuple
    from ansible.executor.task_queue_manager import TaskQueueManager
    import pytest

    # Set up

# Generated at 2022-06-23 12:53:51.765004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('')
    assert module is not None, "Failed to create StrategyModule instance."


# Generated at 2022-06-23 12:53:53.182621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy != None


# Generated at 2022-06-23 12:53:54.584246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")


# Generated at 2022-06-23 12:53:56.245238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(1)
    assert len(a._workers) == 1
    assert a._host_pinned == False

# Generated at 2022-06-23 12:54:02.025836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a simple, empty ansible plugin that can be used for testing
    # a member of a simple, empty ansible plugin that can be used for testing
    class TestActionModule(object):
        pass


        # Create an instance of the TestActionModule
    testActionModule = TestActionModule()

    print("Testing the StrategyModule constructor")
    strategyModule = StrategyModule(testActionModule)

# Generated at 2022-06-23 12:54:03.884315
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Unit test for method run of class StrategyModule
    '''
    pass

# Generated at 2022-06-23 12:54:04.606419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:54:07.650167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm
    assert not strategy._host_pinned


# Generated at 2022-06-23 12:54:15.404240
# Unit test for method run of class StrategyModule

# Generated at 2022-06-23 12:54:16.990552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule([])

# Generated at 2022-06-23 12:54:17.913668
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:54:20.291784
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Unit test for method run of class StrategyModule
    StrategyModule = AnsibleTesting
    # test for run
    assert True

# Generated at 2022-06-23 12:54:26.497453
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("test run")
    tqm = None  # tqm is not passed to the constructor in normal use
    the_class = StrategyModule(tqm)

    iterator = None
    play_context = {'host_list': []}
    result =  the_class.run(iterator, play_context)
    assert result == False

# Generated at 2022-06-23 12:54:27.022734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:54:27.838853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:54:37.503274
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    task_vars = dict()
    task_vars.update(dict(
        name="test_host",
        group_names=["test_group"],
        groups=dict(
            test_group=["test_host"]
        )
    ))

    task_vars = TaskVars(task_vars=task_vars)
    task = Task().load(dict(
        action="fake_action_1",
        any_errors_fatal=False,
        roles=[],
        vars_prompt=[],
        run_once=True
    ))

    host = Host(name="test_host").set_vars(task_vars)
    play_context = PlayContext()

    sm = StrategyModule(tqm=None)

# Generated at 2022-06-23 12:54:45.971748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.utils.display
    from ansible.plugins.strategy.free import *

    class TestClass(unittest.TestCase):
        def setUp(self):
            self.strategy_module_queue_task = StrategyModule._queue_task

        def test_module_strategy_queue_task(self):
            strategy_module_tqm = ansible.utils.display.Display()
            strategy_module = StrategyModule(strategy_module_tqm)
            self.assertEqual(strategy_module._host_pinned, False)

        def tearDown(self):
            StrategyModule._queue_task = self.strategy_module_queue_task

    unittest.main()

# Generated at 2022-06-23 12:54:55.349241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.vars import VarManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    loader = DataLoader()
    variable_manager = VariableManager()
    tqm = None
    play = Play()
    block = Block()
    block.vars = dict()
    vars = dict()
    _hosts = ['localhost', ]
    included_file = IncludedFile()
    # Consider that the block contains the following data
    block.vars = dict()
   

# Generated at 2022-06-23 12:55:05.193490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.tqm import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    display = Display()
    loader = DataLoader()
    play_context = PlayContext()
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=VariableManager(),
        loader=loader,
        passwords=dict(),
        stdout_callback=None,
    )
    strategyModule = StrategyModule(tqm)
    play = Play()

# Generated at 2022-06-23 12:55:06.385692
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:55:09.508832
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule(tqm)
    module.run(iterator, play_context)

# Generated at 2022-06-23 12:55:14.331556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strategy = StrategyModule(tqm=None)
    list1 = [1,2,3,4]
    host = 0
    assert strategy.get_hosts_left(list1)[host].get_name() == 1

# Generated at 2022-06-23 12:55:17.598845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' strategy_plugins/test_strategy_module.py:test_StrategyModule() '''
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == False

# Generated at 2022-06-23 12:55:18.416372
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True

# Generated at 2022-06-23 12:55:20.069669
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Instead for Unit test, create functional tests for this strategy
    pass
# unit test for class StrategyModule

# Generated at 2022-06-23 12:55:31.508900
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Set up test data for method run of class StrategyModule
    class TestVarsModule(object):
        def __init__(self):
            self.show_custom_stats = False
            self.run_additional_callbacks = False
            self.module_defaults = dict()
            self.gather_non_module_data = False
            self.basedir = None
            self.tree = None
            self.__container = dict()
            self.__options = dict()

        def get_vars(self, *args, **kwargs):
            return dict()

    class TestIteratorModule(object):
        def __init__(self):
            self._play = TestPlayModule()

        def get_next_task_for_host(self, *args, **kwargs):
            return None, None


# Generated at 2022-06-23 12:55:38.576407
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Arguments
    import ansible.plugins.strategy as test_strategy
    class MyActionBase(test_strategy.ActionBase):
        pass
    
    import ansible.plugins.action as test_action

# Generated at 2022-06-23 12:55:41.633389
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator = Iterator()
    play_context = PlayerContext()
    tqm = TaskQueueManager()
    strategy_Module = StrategyModule(tqm)
    strategy_Module.run(iterator, play_context)

# Generated at 2022-06-23 12:55:53.156131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.executor.process.worker import WorkerProcess

    # Create a module to access private variables
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)

        # Returns private variable _hosts_cache
        def get_hosts_cache(self):
            return self._hosts_cache

    # Create instances of Ansible objects
    loader = DataLoader()

# Generated at 2022-06-23 12:55:57.399907
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    display = Display()
    tqm = TaskQueueManager()
    iterator = None
    play_context = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.run(iterator, play_context) == True

# Generated at 2022-06-23 12:56:00.485786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    module = StrategyModule(None)
    assert module is not None

# Generated at 2022-06-23 12:56:02.158229
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(tqm=None) 
    # TODO: implement test

# Generated at 2022-06-23 12:56:12.180962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


    class Task:
        class _ds:
            pass

    task = Task()
    task._ds = task._ds()
    task._ds.action = 'command'

    play_context = PlayContext()
    variable_manager = VariableManager()


    module = StrategyModule(None)
    module._tqm = {}
    module._tqm.get_vars = lambda: {'error': 1}
    module._tqm.send_callback = lambda name, task, is_conditional: None
    module._tqm.RUN_OK = 1
    module

# Generated at 2022-06-23 12:56:22.426286
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play


# Generated at 2022-06-23 12:56:23.353396
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# class StrategyModule


# Generated at 2022-06-23 12:56:27.928535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, StrategyBase)
    assert StrategyModule.__name__ == 'StrategyModule'
    # Base class creates a WorkerProcess object using the passed task queue.
    # It also creates a results queue and a job counter.
    tqm = "test_tqm"
    StrategyModule(tqm)

# Generated at 2022-06-23 12:56:32.672029
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # DEBUG:
    # mock_tqm = MockTQM()
    # mock_tqm = MockTQM(hosts = {})
    mock_tqm = MockTQM(hosts = {
        'host1': MockTaskQueueManagerHost(name = 'host1', port = 22),
        'host2': MockTaskQueueManagerHost(name = 'host2', port = 22),
        })
    # iterator = MockIterator(play = mock_play)
    iterator = MockIterator()
    play_context = MockPlayContext()
    strategy = StrategyModule(tqm = mock_tqm)
    strategy.run(iterator = iterator, play_context = play_context)


# Generated at 2022-06-23 12:56:39.602135
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = Host('192.168.0.1')
    host1 = Host('192.168.0.2')
    host2 = Host('192.168.0.3')
    hosts = [host, host1, host2]
    play = Play().load(dict(name = 'test', hosts = 'all', gather_facts = 'no', tasks = [
        dict(action = dict(module = 'shell', args = 'whoami'))
    ]), variable_manager = VariableManager(), loader = DataLoader())
    iterator = TaskIterator(play)
    play_context = PlayContext()

# Generated at 2022-06-23 12:56:48.829693
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task as Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import yaml
    import json


# Generated at 2022-06-23 12:57:00.198418
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context = dict(
        become="nop",
        become_user="nop",
        become_method="nop",
        become_flags=[''],
        connection="nop",
        diff_mode="nop",
        forks=2,
        become_ask_pass=False,
        names=["nop", "nop"],
        passwords=["nop", "nop"],
        port=2,
        private_key_file="nop",
        remote_user="nop",
        extra_vars=[''],
        tags=["nop"],
        skip_tags=["nop"],
        start_at_task="nop",
        verbosity=2,
        check=False,
        diff=False,
    )
    strategy = StrategyModule(tqm)

# Generated at 2022-06-23 12:57:07.953514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def fake_get_worker(q, uuid):
        class FakeWorker(object):
            def __init__(self, uuid, task):
                self._task = task
                self._result = None
            def run(self):
                time.sleep(1)
                return self._task.action, None, None
        return FakeWorker(uuid, self._queue.get())

    def fake_get_new_thread(q, uuid):
        class FakeThread(object):
            def __init__(self, uuid):
                self.uuid = uuid
            def run(self):
                self.result = self._action, None, None
        return FakeThread(uuid)

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

# Generated at 2022-06-23 12:57:08.712379
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:57:13.334340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test of constructor
    loader, inventory, variable_manager = C.initialize_for_plugin_testing()
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords={},
    )
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-23 12:57:14.128177
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:57:22.897705
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from test.hosts import Host
    from test.units.plugins.loader import DictDataLoader
    from test.units.plugins.strategy import TestStrategyBase
    from ansible.utils.vars import combine_vars
    from ansible.plugin.loader import strategy_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from test.units.mock.vault import MockVaultLib
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.six import binary_type, text_type

    def _dict_to_unsafe_proxy(obj):
        if isinstance(obj, dict):
            for k, value in obj.items():
                if isinstance(value, binary_type):
                    value = to_

# Generated at 2022-06-23 12:57:24.766956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule.ALLOW_BASE_THROTTLING == False)
    return

# Generated at 2022-06-23 12:57:26.297358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

test_StrategyModule()

# Generated at 2022-06-23 12:57:29.065787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert(module != None)



# Generated at 2022-06-23 12:57:37.915265
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    f = open(os.path.join(os.path.dirname(__file__), "data/strategy_module_run.out"), "w")
    sys.stdout = f
    strategy_module = StrategyModule("tqm")
    strategy_module.run("iterator", "play_context")
    sys.stdout = sys.__stdout__
    f.close()
    f_actual = open(os.path.join(os.path.dirname(__file__), "data/strategy_module_run.out"), "r")
    f_expected = open(os.path.join(os.path.dirname(__file__), "data/strategy_module_run_expected.out"), "r")
    assert f_actual.read() == f_expected.read()
    f_actual.close()


# Generated at 2022-06-23 12:57:43.902486
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import unittest
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.included_file
    import ansible.playbook.block
    import ansible.utils.unsafe_proxy
    import ansible.vars.unsafe_proxy
    import ansible.parsing.dataloader
    import ansible.template.template
    import ansible.template.vars

    class Dummy(unittest.TestCase):
        class Iterator(object):
            def __init__(self):
                pass

            def get_next_task_for_host(self, host, peek=False):
                pass

            def mark_host_failed(self, host):
                pass

            def add_tasks(self, host, tasks):
                pass


# Generated at 2022-06-23 12:57:54.133513
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # (Iterator, PlayContext) -> RUN_OK
    # This method implements the default strategy for Ansible by looping over
    # the inventory host list and running the tasks on each host in sequence

    # The "free" strategy is a bit more complex, in that it allows tasks to
    # be sent to hosts as quickly as they can be processed. This means that
    # some hosts may finish very quickly if run tasks result in little or no
    # work being done versus other systems.

    # The algorithm used here also tries to be more "fair" when iterating
    # through hosts by remembering the last host in the list to be given a task
    # and starting the search from there as opposed to the top of the hosts
    # list again, which would end up favoring hosts near the beginning of the
    # list.
    pass

# Generated at 2022-06-23 12:57:56.889737
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_obj = StrategyModule(tqm)
    my_obj.run(iterator, play_context)
    pass

# Generated at 2022-06-23 12:57:59.732578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_module = "test_module"

    # get the target function to be tested
    strategyModuleObject = StrategyModule(ansible_module)

    # assert the object is an instance of the class
    assert isinstance(strategyModuleObject, StrategyModule)


# Generated at 2022-06-23 12:58:06.423972
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            inventory=dict(required=True, type='dict'),
            play_context=dict(required=True, type='dict'),
            new_stdin=dict(required=False, type='file')
        ),
        supports_check_mode=False
    )


# Generated at 2022-06-23 12:58:08.629022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_obj = StrategyModule(None)
    assert strategy_obj._host_pinned is False

# Generated at 2022-06-23 12:58:15.067076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars

    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import get_extra_vars
    from ansible.cli import CLI
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-23 12:58:26.786314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.loader import action_loader
    from ansible.playbook import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import ansible.playbook.task_include
    import ansible.playbook.role
    host = 'localhost'
    action_loader.add_directory('./lib/ansible/plugins/action')

# Generated at 2022-06-23 12:58:27.881188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 12:58:28.625514
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:58:32.299267
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    strategy = StrategyModule(TaskQueueManager(None))
    assert strategy
    assert strategy.__init__(TaskQueueManager(None))

# Generated at 2022-06-23 12:58:40.619050
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 12:58:50.178229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    loader = DataLoader()
    current_dir = os.getcwd()
    cwd = os.path.join(current_dir, 'test_workspace')
    pb_dir = os.path.join(cwd, 'pb')
    inv_dir = os.path.join(cwd, 'inv')
    private_key_file = os.path.join(cwd, 'test_key')

# Generated at 2022-06-23 12:58:50.741200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 12:58:52.504986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule

    # TODO: mock tqm and check that StrategyBase's constructor is called

# Generated at 2022-06-23 12:59:01.980738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class IteratorMockup():
        def get_hosts(self, pattern=None):
            return ['host1', 'host2']
    class PlayMockup():
        def __init__(self):
            self.connection = 'local'
            self.hosts = iter(['host1', 'host2'])
            self.handlers = []
            self.tasks = [{
                'action': 'setup',
                'name': 'Gathering Facts'
            }]

    class OptionsMockup():
        def __init__(self):
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.connection = 'ssh'
            self.module_path = None
            self.forks = 5
            self.remote_

# Generated at 2022-06-23 12:59:03.026740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:59:04.251098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:59:09.848316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import ansible.template
    import ansible.utils.display
    import ansible.vars.manager
    import ansible.plugins.loader
    import ansible.template
    import ansible.utils.display
    import ansible.vars.manager
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.inventory.host

    mySendMsg = ansible.template.AnsibleTemplate('', 0, True, False)
    myDisplay = ansible.utils.display.Display()
    myPlayContext = PlayContext()


# Generated at 2022-06-23 12:59:12.745802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None

# Generated at 2022-06-23 12:59:19.313647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins import action_loader

    class MockTaskIterator(object):
        def __init__(self, play):
            self._play = play

        def _iterator(self, hosts, tasks):
            class fake_iterator(object):
                def __init__(self):
                    self.hosts = hosts
                    self.tasks = tasks

            return fake_iterator()

        def get_next_task_for_host(self, host, peek=False):
            return (None, None)

        def is_failed(self, host):
            return True

    class MockPlay(object):
        def __init__(self, max_fail_percentage):
            self.max_fail_percentage = max_fail_percentage

    class MockLoader(object):
        def __init__(self, path):
            self.path

# Generated at 2022-06-23 12:59:20.200917
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:59:27.664971
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
   TASK = dict(action='debug', register='shell_out')
   TASK_NO_REGISTER = dict(action='debug', )
   HOST = dict(name='host1')
   RESULT_OK = dict(contacted={'host1': dict(invocation=dict(module_name='debug', module_args='var=var1'),
                                             module_args=dict(var='var1'),
                                             created_at=time.time(),
                                             task=TASK,
                                             changed=False)},
                   dark={},
                   _run_done=True)

# Generated at 2022-06-23 12:59:37.559606
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # --------------------------------------------------
    # setup
    # --------------------------------------------------
    os.path.isfile(self.host_file)
    if self.host_file.endswith(".yml") or self.host_file.endswith(".yaml"):
        with open(self.host_file, 'r') as stream:
            hosts = yaml.load(stream)
        all_groups = inventory.get_groups_dict(hosts)
        host_list = inventory.get_host_list(hosts)
    else:
        with open(self.host_file, 'r') as f_obj:
            host_list = [line.strip() for line in f_obj]
        all_groups = inventory.get_groups_dict_from_list(host_list)

# Generated at 2022-06-23 12:59:38.614987
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  pass

# Generated at 2022-06-23 12:59:42.415439
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Verify that QueueManager.send_callback is not called with a v2_playbook_on_no_hosts_remaining argument,
    #   when there are no hosts left, and the run method returns false (indicating a failure)
    pass # FIXME


# Generated at 2022-06-23 12:59:49.999535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars

    playbook_path = 'FreeStrategyModule.yml'
    host_list = './hosts'

    loader = DataLoader()
    passwords = dict()

    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    loader = DataLoader()

    play_context = PlayContext()

# Generated at 2022-06-23 12:59:52.839209
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO remove variables below
    display = Display()
    display.debug("In StrategyModule run")
    display.vvvv("In StrategyModule run")

# Generated at 2022-06-23 13:00:00.494544
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    import json
    import os
    import tempfile

    # Create play and task
    play_source = dict(
        name="Ansible Play",
        hosts="all",
        gather_facts="no",
        tasks=[
            dict(action=dict(module="shell", args="exit 1"), register="shell_out"),
            dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}")))
        ]
    )

# Generated at 2022-06-23 13:00:01.600494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="tqm")

# Generated at 2022-06-23 13:00:02.269317
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 13:00:08.197242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext(password=passwords, become_method='sudo', become_user='root', become_ask_pass=False, verbosity=4,
                               connection='ssh', check=None, diff=None, inventory=inventory)


# Generated at 2022-06-23 13:00:09.569562
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule(worker_pool=WorkerPool())

# Generated at 2022-06-23 13:00:10.805896
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategymodule = StrategyModule()
    assert strategymodule

# Generated at 2022-06-23 13:00:15.608204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.plugins.strategy.default import StrategyModule
    from ansible.plugins.strategy.subset import StrategyModule
    from ansible.plugins.strategy.debug import StrategyModule
    strategy = StrategyModule()
    assert strategy is not None

# Generated at 2022-06-23 13:00:17.670175
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TestTqm()
    assert False


# Generated at 2022-06-23 13:00:25.328689
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import ansible.plugins.loader
    ansible.plugins.loader.find_plugin = lambda _, x: x+'_plugin'
    import ansible.plugins.action
    ansible.plugins.action.ActionBase = type('ActionBase', (object,), {'BYPASS_HOST_LOOP': False})
    import ansible.plugins
    ansible.plugins.ActionBase = type('ActionBase', (object,), {'BYPASS_HOST_LOOP': False})
    import ansible.utils.display
    import ansible.template
    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-23 13:00:26.411989
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	# AssertionError: expected method to be called once but was called 0 times
	pass

# Generated at 2022-06-23 13:00:35.805603
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Dummy data before running method `run`
    hosts_cache = {}
    _hosts_cache = {}
    _hosts_cache_all = {}
    host_pinned = False
    result = {}
    work_to_do = True
    workers_free = 1
    play_context = {}
    iterator = {}
    role_failed = False
    role_name = ''
    role_result = {}
    role_tasks = {}
    add_tqm_variables = {}
    host_name = ''
    role_blocks = {}
    host_results = []
    workers = {}
    task_vars = {}
    throttle = 0
    same_tasks = 0
    action = {}
    run_once = {}
    task_name = ''
    step = {}
    take_step = {}


# Generated at 2022-06-23 13:00:38.507209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('TQM')
    assert isinstance(s, StrategyBase)
    assert isinstance(s, object)

# Generated at 2022-06-23 13:00:48.761310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.runner.action_plugins.setup

    mock_tqm = MagicMock()
    mock_tqm.RUN_OK = 0
    mock_tqm._terminated = False
    mock_tqm._unreachable_hosts = []
    mock_tqm._terminated = False
    mock_tqm._inventory = MagicMock(hosts=['host1', 'host2'])
    mock_tqm._workers = []
    mock_tqm.send_callback.return_value = True

    mock_play_context = MagicMock()

    mock_iterator = MagicMock()
    mock_iterator._play = MagicMock()
    mock_iterator.get_next_task_for_host.return_value = (0, None)
    mock_iterator.is_

# Generated at 2022-06-23 13:00:58.349524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.utils.vars import merge_hash

    context.CLIARGS = context.CLIARGS._replace(connection='local')
    context.CLIARGS = context.CLIARGS._replace(module_path=['/to/mymodules'])
    context.CLIARGS = context.CLIARGS._replace(forks=10)
    context.CLIARGS = context.CLIARGS._replace(become=False)
    context.CLIARGS = context.CLIARGS._replace(become_method='sudo')
    context.CLIARGS = context.CLIARGS._replace(become_user='root')
    context.CLIARGS = context.CLIARGS._replace(check=False)

# Generated at 2022-06-23 13:01:01.466159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.ALLOW_BASE_THROTTLING == False



# Generated at 2022-06-23 13:01:06.543927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy = StrategyModule(None)

    # Test for _filter_notified_failed_hosts
    assert strategy._filter_notified_failed_hosts(None, []) == []

    # test for _filter_notified_hosts
    assert strategy._filter_notified_hosts([]) == []

# Generated at 2022-06-23 13:01:16.874463
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialization
    tqm = mock.Mock()
    config = mock.Mock(tags=[], run_once=False)

    iterator = mock.Mock()
    iterator.is_failed.return_value = False

    play_context = mock.Mock(tags=[])
    play_context.tags = []
    play_context.run_once = False

    strategy = StrategyModule(tqm)
    strategy._worker_prc = mock.Mock()
    strategy._workers = [mock.Mock()]
    strategy._blocked_hosts = {'127.0.0.1': False}
    strategy._tqm.send_callback.return_value = False
    strategy._tqm._unreachable_hosts = []
    strategy._tqm._terminated = False

    # Test

# Generated at 2022-06-23 13:01:19.421516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy_module = StrategyModule(tqm=None)
    assert my_strategy_module.__class__.__name__ == "StrategyModule"


# Generated at 2022-06-23 13:01:21.743121
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    fd = open("test_StrategyModule_run.out", "w")
    result = StrategyModule.run(fd, fd)
    fd.close()
    return result

# Generated at 2022-06-23 13:01:32.312174
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Testing with correct values:
    # Check if it is correctly executed without any errors.
    # If not, it will raise an error
    import tempfile
    inventory = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    loader = ansible.inventory.manager.InventoryManager(loader=inventory, sources='localhost,')
    variable_manager.set_inventory(loader)
    playbook_path = tempfile.mkstemp()[1]
    display = ansible.utils.display.Display()
    variable_manager = ansible.vars.manager.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    passwords = {}
    tqm = None
    iterator = ansible.executor.task_queue_

# Generated at 2022-06-23 13:01:33.391735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:01:34.014119
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	pass

# Generated at 2022-06-23 13:01:40.633602
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.executor.task_result import TaskResult
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import copy

    result_blocked_hosts = {
        u'justatest.example.com': True
    }
    result_hosts_left = [
        {
            '_name': u'justatest.example.com',
            'host_name': u'justatest.example.com'
        }
    ]

# Generated at 2022-06-23 13:01:45.409805
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host1 = Mock()
    host2 = Mock()
    mocked_host = [host1, host2]

    tqm = Mock()
    strategy = StrategyModule(tqm)
    tqm._unreachable_hosts = set()

    iterator = Mock()
    iterator.hosts = mocked_host
    iterator._play.max_fail_percentage = None

    play_context = Mock()
    strategy.run(iterator, play_context)

    assert strategy.ALLOW_BASE_THROTTLING == False
    assert strategy._host_pinned == False