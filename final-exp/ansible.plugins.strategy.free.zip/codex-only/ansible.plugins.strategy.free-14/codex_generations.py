

# Generated at 2022-06-23 12:51:44.444143
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_StrategyModule = StrategyModule(tqm=None)
    mock_iterator = MagicMock(name='iterator')
    mock_play_context = MagicMock(name='play_context')
    assert my_StrategyModule.run(mock_iterator, mock_play_context) == False


# Generated at 2022-06-23 12:51:45.657732
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-23 12:51:57.127444
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Mock imports

    # Unittest imports
    from ansible_collections.testns.testcoll.plugins.module_utils.test_result import TestResult

    # Class to test
    from ansible_collections.testns.testcoll.plugins.strategy.free import StrategyModule

    class TestAction(object):
        def __init__(self, BYPASS_HOST_LOOP=False):
            self.BYPASS_HOST_LOOP = BYPASS_HOST_LOOP

    class TestTask(object):
        def __init__(self, action=None):
            self.action = action

    # Mocks
    import ansible_collections.testns.testcoll.plugins.strategy.free as free
    free._action_loader = TestAction(False)

    # Test objects

# Generated at 2022-06-23 12:52:05.986254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create fake tqm
    class FakeTQM(object):
        class FakeOptions(object):
            def __init__(self):
                self.retry_files_enabled = False
                self.retry_files_save_path = False
        def __init__(self):
            self.options = self.FakeOptions()
    fake_tqm = FakeTQM()

    # Create instance of StrategyModule
    strategy_module = StrategyModule(fake_tqm)

    # Test creation
    assert strategy_module._tqm == fake_tqm

    # Test ALLOW_BASE_THROTTLING
    assert strategy_module.ALLOW_BASE_THROTTLING == False


# Generated at 2022-06-23 12:52:07.134883
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True


# Generated at 2022-06-23 12:52:17.569794
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import unittest
    import mock
    from ansible.errors import AnsibleError
    
    get_hosts_display = "TASK [Gathering Facts] *********************************************************************************************************************************************************************************************************************************"
    get_hosts_result = "ok"
    host_name = "devopscloudautomation.ddns.net"
    host_name_1 = "test-devopscloudautomation-ddns-net"
    module_name = "setup"
    task_name = "Gathering Facts"
    task_path = "/etc/ansible/roles/tests/tasks/main.yml"
    module_args = "{\"gather_subset\": [], \"filter\": \"\", \"gather_timeout\": 10}"
    create_host = ['test-devopscloudautomation-ddns-net']


# Generated at 2022-06-23 12:52:19.688538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s is not None
    assert s.run is not None

# Generated at 2022-06-23 12:52:21.534752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule is not None

# Generated at 2022-06-23 12:52:32.292752
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import random
    import unittest
    try:
        from unittest.mock import patch, Mock, call
    except ImportError:
        from mock import patch, Mock, call

    class StrategyModuleTestCase(unittest.TestCase):

        @patch("ansible.plugins.strategy.free.StrategyModule._set_hosts_cache")
        def test_StrategyModule_run(self, mock_set_hosts_cache):
            # Instantiate the object
            # We do not test the inherited method
            tqm = Mock
            strategy_module = StrategyModule(tqm)
            # Test the returned value
            # The returned value is a tuple
            # The first attribute of the tuple is a Boolean
            # The second attribute of the tuple is a string
            # The third attribute of the tuple is a string
            #

# Generated at 2022-06-23 12:52:40.572596
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def test_get_hosts_left(self, *args, **kwargs):
        return ['test_host']

    @staticmethod
    def set_host_pinned(self, *args, **kwargs):
        self._host_pinned = True

    @staticmethod
    def _set_hosts_cache(self, play):
        self._hosts_cache = {'test_host': 'test_host'}

    @staticmethod
    def _execute_meta(self, task, play_context, iterator, target_host):
        pass

    @staticmethod
    def _take_step(self, task, host_name):
        pass

    @staticmethod
    def _queue_task(self, host, task, task_vars, play_context):
        pass


# Generated at 2022-06-23 12:52:41.354679
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:52:43.525749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    unit test for constructor
    '''
    strategy = StrategyModule('test')
    assert strategy is not None
    assert strategy._host_pinned == False

# Generated at 2022-06-23 12:52:54.689822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.playbook
    import ansible.plugins.loader as plugin_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    plugin_loader.add_directory("./plugins/strategy")
    

# Generated at 2022-06-23 12:52:55.860563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert(s != "")


# Generated at 2022-06-23 12:52:59.583087
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm=object
    s=StrategyModule(tqm)
    iterator=object
    play_context=object
    # ToDo: test actual values for method call.
    # Currently, it seems that the test is only checking if the method runs without crashing.
    assert s.run(iterator, play_context)==None

# Generated at 2022-06-23 12:53:10.002535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    try:
        from unittest import mock
    except ImportError:
        import mock

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Playbook
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.playbook.play_context import PlayContext

    host = Host("test_host")
    group = Group("test_group")
    group.add_host(host)

    # create sample task
    task = Task

# Generated at 2022-06-23 12:53:12.976079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm)
    s._tqm.send_callback = MagicMock()
    assert s._tqm.send_callback is not None
    s.run(iterator, play_context)

# Generated at 2022-06-23 12:53:20.696063
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = Mock()
    iterator = Mock()
    play_context = Mock()
    strategy_module = StrategyModule(tqm)
    strategy_module.run(iterator, play_context)


from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.playbook.play import Play
from ansible.playbook.play_iterator import PlayIterator
from ansible.playbook.block import Block
import ansible.plugins.strategy.linear
from ansible.executor.task_result import TaskResult


# Generated at 2022-06-23 12:53:27.643523
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """Unit test for run method of class StrategyModule
    """

    test_module = StrategyModule('test_tqm')
    
    test_module.display = 'test_display'

    test_module.get_hosts_left = Mock(return_value=["test_host_left"]) # mock the ansible return

    test_module._hosts_cache = "test_hosts"

    test_module._hosts_cache_all = "test_hosts"

    test_module._variable_manager = "test_variable_manager"

    test_module._loader = "test_loader"

    test_module.add_tqm_variables = Mock() # mock the ansible return

    test_module._blocked_hosts = []

    test_module._step = False

    test_module._tqm._un

# Generated at 2022-06-23 12:53:28.192410
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:53:29.548056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) != None


# Generated at 2022-06-23 12:53:36.390693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple

    FakeTqm = namedtuple('Tqm', ['RUN_OK'])
    tqm = FakeTqm(RUN_OK=1)

    strategy = StrategyModule(tqm)
    assert strategy.host_pinned is False and strategy.hosts_cache == {} and strategy.hosts_cache_all == {}
    assert strategy.blocked_hosts == {} and strategy.failed_hosts == []
    assert strategy.unreachable_hosts == {} and strategy.workers == [] and strategy.stats == {}

# Generated at 2022-06-23 12:53:46.546261
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = Host("host")
    host.name = "host"
    host.vars = dict()
    host.groups = []
    host.groups.append(Group("group"))
    host.groups[0].vars = dict()
    host.groups[0].name = "group"
    host.groups[0].groups = []

    host.groups[0].hosts.append(host)
    task = Task()
    task.action = 'debug'
    task.name = 'debug'
    task.tags = ["test"]
    task.host = host
    task.hosts = host
    task.vars = dict()
    play = Play()
    play.vars = dict()
    play.hosts = [host]
    play.hosts_pattern = {}
    play.hosts_pattern["pattern"]

# Generated at 2022-06-23 12:53:52.784559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars

    # setup test data

# Generated at 2022-06-23 12:54:03.536881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook import PlayBook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.vars.manager import VariableManager
    # create variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {'testhost': {'a': 1, 'b': 2}}}
    variable_manager.options_vars

# Generated at 2022-06-23 12:54:04.742115
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule()

# Generated at 2022-06-23 12:54:06.552377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(object()) # TaskQueueManager() is not available outside module
    assert module

# Generated at 2022-06-23 12:54:14.896606
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    import unittest
    tqm = mock.Mock()
    iterator = mock.Mock()
    play_context = mock.Mock()
    strategy = StrategyModule(tqm)
    strategy._tqm = mock.Mock()
    strategy._tqm._terminated = mock.Mock()
    strategy._tqm.send_callback = mock.Mock()
    strategy._tqm._unreachable_hosts = {}
    strategy._tqm.RUN_OK = mock.Mock()
    strategy._tqm.RUN_FAILED_HOSTS = mock.Mock()
    strategy._tqm.RUN_UNREACHABLE_HOSTS = mock.Mock()
    strategy._tqm.RUN_FAILED_BREAK_PLAY

# Generated at 2022-06-23 12:54:17.902359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None).__init__(tqm=None) is None

# Generated at 2022-06-23 12:54:21.636015
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  tqm = TQM()
  iterator = InMemoryInventory()
  play = Play()
  play_context = PlayContext()
  strategyModule = StrategyModule(tqm)
  strategyModule.run(iterator, play_context)

# Generated at 2022-06-23 12:54:25.183598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:54:35.400901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock ansible_playbook object to be passed to the StrategyModule
    class mock_playbook(object):
        def __init__(self):
            self.inventory = None
            self.set_inventory = None
            self.playbook = None
            self.callbacks = None
            self.loader = None
            self.variable_manager = None
            self.options = None
            self.host_list = None
            self.extra_vars = None
            self.passwords = None
            self.tqm = None

    result = mock_playbook()
    result.inventory = None
    result.set_inventory = None
    result.playbook = None
    result.callbacks = None
    result.loader = None
    result.variable_manager = None
    result.options = None
    result.host_list

# Generated at 2022-06-23 12:54:36.473465
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

# Generated at 2022-06-23 12:54:37.284338
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:54:38.029736
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:54:40.220832
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # ToDo: create test case
    pass



# Generated at 2022-06-23 12:54:41.060152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 12:54:43.533760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Get object instance of class StrategyModule
    st = StrategyModule(None)

    # Test successful instantiation
    assert isinstance(st, StrategyModule)

# Generated at 2022-06-23 12:54:50.336551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    strategyModule = StrategyModule(tqm)
    assert strategyModule is not None



# Generated at 2022-06-23 12:54:51.721200
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule.run()


# Generated at 2022-06-23 12:55:02.640559
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """ unit testing for method run in class StrategyModule """

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    tqm = MagicMock()
    strategy_mock = StrategyModule(tqm)

    iterator = MagicMock()
    play_context = MagicMock()

    strategy_mock.update_active_connections = MagicMock()

    strategy_mock._blocked_hosts = MagicMock()
    strategy_mock._flushed_hosts = MagicMock()
    strategy_mock._hosts_cache = MagicMock()
    strategy_mock._hosts_cache_all = MagicMock()
    strategy

# Generated at 2022-06-23 12:55:08.531819
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def run(self, iterator, play_context):
        # the last host to be given a task
        last_host = 0

        result = self._tqm.RUN_OK

        # start with all workers being counted as being free
        workers_free = len(self._workers)

        self._set_hosts_cache(iterator._play)

        if iterator._play.max_fail_percentage is not None:
            display.warning("Using max_fail_percentage with the free strategy is not supported, as tasks are executed independently on each host")

        work_to_do = True
        while work_to_do and not self._tqm._terminated:

            hosts_left = self.get_hosts_left(iterator)

            if len(hosts_left) == 0:
                self._tqm.send_callback

# Generated at 2022-06-23 12:55:09.452986
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:55:18.385861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Build Test Runner as a main program for Test Case.
if __name__ == "__main__":
    import unittest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class TestAnsibleModule(basic.AnsibleModule):
        pass

    class TestRunner(unittest.TestCase):
        def test_module_runner(self):
            print(__name__)
            print("  TestStrategyModule")
            test_module = TestAnsibleModule()
            test_strategy_module = StrategyModule()
            assert test_strategy_module is not None

    unittest.main()

# Generated at 2022-06-23 12:55:22.994969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None, None, None, None, None, None)
    strategy_module = StrategyModule(tqm)

    return strategy_module

# Generated at 2022-06-23 12:55:24.502008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned is False

# Generated at 2022-06-23 12:55:33.535505
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

    # TODO: Add unit test
    #last_host = 0

    #result = self._tqm.RUN_OK

    # start with all workers being counted as being free
    #workers_free = len(self._workers)

    #self._set_hosts_cache(iterator._play)

    #if iterator._play.max_fail_percentage is not None:
        #display.warning("Using max_fail_percentage with the free strategy is not supported, as tasks are executed independently on each host")

    #work_to_do = True
    #while work_to_do and not self._tqm._terminated:

        #hosts_left = self.get_hosts_left(iterator)

        #if len(hosts_left) == 0:
            #self._tqm.send_callback

# Generated at 2022-06-23 12:55:44.794908
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.plugins.loader import module_loader
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    module_loader.add_directory(extdirs.get_module_path())
    mock_host = Host()
    mock_task = Task()
    mock_task._role = None
    mock_task.action = 'ping'
    mock_task.loop = None
    mock_task.notify = []
    mock_task.when = None
    mock_task.dep_chain = None
    mock

# Generated at 2022-06-23 12:55:45.735833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    strategy = StrategyModule(object)
    assert strategy

# Generated at 2022-06-23 12:55:53.142314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.block import Task, Block
    from ansible.playbook.task import Task as Task_ds
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Setup test objects
    play_ds = dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )


# Generated at 2022-06-23 12:56:03.070981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils import plugin_docs
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

    options = plugin_docs.get_options_from_docstring(StrategyModule, verbose=False, tags=None, gather_subset=None, serialize_creditials=False)

    # set up the objects needed for the constructor call
    tqm = TaskQueueManager(playbook=None, inventory=None, variable_manager=None, loader=None, options=options)
    strategy = StrategyModule(tqm)
    assert strategy is not None

# Generated at 2022-06-23 12:56:03.702401
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:56:06.212879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == False

# Generated at 2022-06-23 12:56:10.109065
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #fixture
    strategy_module = StrategyModule()
    task_queue_manager = TaskQueueManager()
    play_context = 'context'
    iterator = 'iterator'
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-23 12:56:14.116297
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("test StrategyModule_run")
    tqm = test_TQM()
    test_StrategyModule(tqm)
    # test StrategyModule.run()
    assert True == False
# test_StrategyModule end

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:56:14.901266
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True

# Generated at 2022-06-23 12:56:23.765573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Play
    from ansible.playbook import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    myinventory = Inventory("/tmp/myinventory")
    myinventory.add_host(host="localhost", port=22)


# Generated at 2022-06-23 12:56:32.945641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    import os
    import json

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=[os.path.join(os.path.dirname(__file__), "test_strategy.inventory")])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()

# Generated at 2022-06-23 12:56:35.197681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Make sure the constructor doesn't throw any error
test_StrategyModule()

# Generated at 2022-06-23 12:56:36.319560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 12:56:41.402174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude

    task = TaskInclude()
    task._role = {"name": "test_role"}
    task.action = "test"

    strategy = StrategyModule()

    assert strategy.get_hosts_left(task) is None

# Generated at 2022-06-23 12:56:49.554461
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  # Testing with a default object
  # test_obj = StrategyModule(tqm)
  # Testing with an invalid object
  test_obj = None
  try:
    StrategyModule.run(test_obj)
  except Exception as e:
    assert "Object is None" in str(e)

  # Testing with a valid object
  class obj:
    def __init__(self):
      self.tqm = "tqm"
  
  test_obj = StrategyModule(obj())
  test_obj.worker_pids = {}
  test_obj.worker_procs = {}
  test_obj.finished_hosts = {}
  test_obj.blocked_hosts = {}
  test_obj.pending = {}
  test_obj.stats = {}
  test_obj.active_connections = {}

# Generated at 2022-06-23 12:56:51.973204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)

    assert strategy_module._host_pinned is False

# Unit test that _filter_notified_failed_hosts works

# Generated at 2022-06-23 12:56:55.323213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)

    assert strategy_module._tqm == tqm
    assert not strategy_module._host_pinned

# Generated at 2022-06-23 12:57:05.642621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 3
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess

    playbook = Playbook.load("/etc/ansible/roles/HPEOneView/tests/TestPlaybook.yml", variable_manager=None, loader=None)

    inventory = InventoryManager(loader=None, sources="localhost,")
    variable_manager = VariableManager(loader=None, inventory=inventory)

# Generated at 2022-06-23 12:57:06.229649
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule.run

# Generated at 2022-06-23 12:57:08.897280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    if module is None:
        assert False

    try:
        module.run(None, None)
    except NotImplementedError as e:
        assert True
    except:
        assert False

# Generated at 2022-06-23 12:57:09.738073
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:57:15.682566
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a fake class to mimic the object returned by calling StrategyBase(tqm), tqm is retrieved from the fixture in conftest.py
    class FakeTqm(object):
        def __init__(self):
            self._unreachable_hosts = {}
            self.stats = FakeStats()
            self.cleanup_callback = None
    # Create an object of class StrategyModule by passing the fake class object
    obj1 = StrategyModule(FakeTqm())
    # Create a fake class to mimic the object returned by calling StrategyBase(tqm), tqm is retrieved from the fixture in conftest.py
    class FakeIterator(object):
        def __init__(self):
            self._play = "Fake Play"
            self._play.handlers = []
            self._play.tasks = []
            self._

# Generated at 2022-06-23 12:57:17.607710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert(strategy_module != None)

# Generated at 2022-06-23 12:57:28.378397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()

# Generated at 2022-06-23 12:57:31.252656
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

    # end of test_StrategyModule_run

    # Unit test for method _filter_notified_hosts of class StrategyModule

# Generated at 2022-06-23 12:57:38.205917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=C.DEFAULT_HOST_LIST),
        variable_manager=VariableManager(),
        loader=DataLoader(),
    )
    strategy = StrategyModule(tqm)
    assert strategy.ALLOW_BASE_THROTTLING == False


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 12:57:40.436920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert (strategy._host_pinned is False)

# Generated at 2022-06-23 12:57:52.300758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    global _tqm
    _tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=C.DEFAULT_LOAD_CALLBACK_PLUGINS,
        run_tree=False,
        #we override the strategy here
        strategy='free'
    )
    _tqm._unreachable_hosts = dict()
    _tqm._workers = [()]
    _tqm._loader = None
    strategy = StrategyModule(_tqm)

# Testing
if __name__ == '__main__':
    print('*** Testing ansible.plugins.strategy.free ***')

# Generated at 2022-06-23 12:57:54.856007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule('tqm')
    assert test_StrategyModule


# Generated at 2022-06-23 12:58:03.809633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.tactic import LinearTactic
    from ansible.plugins.strategy import StrategyModule

    def get_tqm():
        strategy = LinearTactic(None)
        strategy.get_hosts_left = lambda x: x
        strategy.get_worker = lambda: None
        return strategy

    tactic = get_tqm()
    strategy = StrategyModule(tactic)
    assert strategy._tqm == tactic
    assert strategy._host_pinned == False
    assert strategy._hosts_cache == {}
    assert strategy._hosts_cache_all == {}
    assert strategy._blocked_hosts == {}
    assert strategy._flushed_hosts == {}
    assert strategy._workers == []
    assert strategy._loader == tactic._loader
    assert strategy._variable_manager == tactic._variable_manager

# Generated at 2022-06-23 12:58:10.719457
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-23 12:58:12.008435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing StrategyModule()')

# Unit tests for main()

# Generated at 2022-06-23 12:58:13.569606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm="tqm")
    assert s._host_pinned == False

# Generated at 2022-06-23 12:58:19.923071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager()
    loader = DataLoader()

    play_context = PlayContext()

# Generated at 2022-06-23 12:58:28.984205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    fake_loader = None # FIXME
    fake_variable_manager = None # FIXME
    fake_host_manager = None # FIXME


# Generated at 2022-06-23 12:58:30.175995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 12:58:34.224732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    fake_TQM_instance = FakeTQMModule(display)
    strategy_module = StrategyModule(fake_TQM_instance)
    assert strategy_module._host_pinned == False
    assert strategy_module._tqm == fake_TQM_instance


# Generated at 2022-06-23 12:58:35.802376
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # param: iterator:iterator, play_context:play_context
    # return: result:result
    pass

# Generated at 2022-06-23 12:58:36.511132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 12:58:37.426902
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-23 12:58:48.020230
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    pb = Playbook()
    loader = DataLoader()
    passwords = {'become_pass': '', 'conn_pass': ''}
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 12:58:50.566922
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy = StrategyModule()
    iterator = Iterator()
    play_context = PlayContext()
    strategy.run(iterator, play_context)



# Generated at 2022-06-23 12:58:57.977071
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''test_StrategyModule_run (ansible.plugins.strategy.free.StrategyModule)
    test run method of class StrategyModule
    '''

    # Setup Mock Objects
    tqm = MagicMock()
    iterator = MagicMock()
    play_context = MagicMock()
    strategy = StrategyModule(tqm=tqm)

    strategy._tqm._terminated = False
    strategy._tqm._shared_loader_obj = MagicMock()
    strategy._tqm._unreachable_hosts = []
    strategy._tqm._workers = []
    strategy._workers = []

    strategy._tqm._final_q = MagicMock()
    strategy._tqm._final_q.empty.return_value = False
    strategy._tqm._final_q.get

# Generated at 2022-06-23 12:59:00.206178
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(tqm={})
    assert not test_StrategyModule._host_pinned

# Unit tests for _filter_notified_failed_hosts() method

# Generated at 2022-06-23 12:59:01.783811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    assert callable(StrategyModule)

# Generated at 2022-06-23 12:59:04.990094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    tqm = MockTaskQueueManager()
    display = tqm.display
    StrategyModule(tqm)


# Generated at 2022-06-23 12:59:06.492418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule()
    assert mod is not None


# Generated at 2022-06-23 12:59:08.362782
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    x = StrategyModule()
    return x.run()

# Generated at 2022-06-23 12:59:17.797290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager as Executor
    from ansible.plugins.strategy import StrategyModule
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    loader = DataLoader()

# Generated at 2022-06-23 12:59:20.124335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert isinstance(s, StrategyModule)
    assert s._host_pinned == False

if __name__ == '__main__' :
    test_StrategyModule()

# Generated at 2022-06-23 12:59:27.617346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.plugins.loader as loader
    import ansible.plugins.strategy as strategy
    import sys
    import tempfile
    import yaml
    import json

    # Add 'ansible' to sys.path so we can build a fake TaskQueueManager
    sys.path.insert(1, '/usr/share/ansible')
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a fake class to

# Generated at 2022-06-23 12:59:30.944535
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager()
    strategymodule = StrategyModule(tqm)
    
    
    
    
    
    
    return strategymodule.run(iterator, play_context)

# Generated at 2022-06-23 12:59:31.694084
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-23 12:59:32.352134
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	pass


# Generated at 2022-06-23 12:59:34.657955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 3
    iterator = None
    play_context = None
    tqm = None

    s = StrategyModule(tqm)
    assert s != None

# Generated at 2022-06-23 12:59:45.114491
# Unit test for method run of class StrategyModule

# Generated at 2022-06-23 12:59:46.986901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__base__ == StrategyBase
    assert issubclass(StrategyModule, StrategyBase)

# Generated at 2022-06-23 12:59:47.775845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 12:59:48.767942
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert False



# Generated at 2022-06-23 12:59:56.120400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    tqm = TaskQueueManager(
        inventory=InventoryManager(
            hosts=[
                Host(name="example.com"),
                Host(name="example.org"),
                Host(name="example.net"),
            ]
        )
    )
    strategy = StrategyModule(tqm)
    assert strategy


# Generated at 2022-06-23 12:59:58.800721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == False


# Generated at 2022-06-23 13:00:08.655434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    import ansible.constants as C

    class Model():
        def __init__(self):
            pass

    class Play():
        def __init__(self):
            self.hosts = {'host1': None}

    class PlayContext():
        def __init__(self):
            self.__dict__ = {'network_os': 'network_os'}

    loader = DataLoader()

# Generated at 2022-06-23 13:00:10.107064
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy = StrategyModule(None)

# Generated at 2022-06-23 13:00:19.631615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    ), variable_manager=VariableManager(), loader=None)

    play_context = PlayContext()

# Generated at 2022-06-23 13:00:21.018305
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    hr = StrategyModule()
    hr.run()

# Generated at 2022-06-23 13:00:22.157934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')

# Generated at 2022-06-23 13:00:28.172410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a strategy
    strategy = StrategyModule(TaskQueueManager())

    # Check that the strategy is an instance of the StrategyBase class
    assert isinstance(strategy, StrategyBase)

    # Check that the strategy has a run method
    assert callable(strategy.run)

    # Initialize a playbook
    testPlayContext = PlayContext()

# Generated at 2022-06-23 13:00:38.207130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import __main__
    __main__.__dict__['_display'] = __display = unittest.mock.Mock()
    __main__.__dict__['_'] = __ = unittest.mock.Mock()
    import sys
    sys.modules['ansible.plugins.strategy'] = sys.modules['ansible.plugins.strategy'].strategy

    from ansible.plugins.strategy.module import StrategyModule
    from ansible.tqm import TaskQueueManager
    from ansible.template import Templar
    from ansible.playbook import Play
    from ansible.inventory.hosts import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 13:00:44.402553
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context = {'name': 'test_StrategyModule_run', 'connection': 'local', 'become': False, 'become_method': 'sudo', 'become_user': None, 'check_mode': False, 'diff': False}
    tqm = None
    iterator = None
    strategy_module = StrategyModule(tqm)
    result = strategy_module.run(iterator, play_context)

# Generated at 2022-06-23 13:00:45.021391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:00:54.306724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    def _create_play_context(connection, network_os):
        play_context = PlayContext()
        play_context.connection = connection
        play_context.network_os = network_os
        return play_context

    playbook = Playbook.load('/home/ansible/ansible/test/fixtures/ansible_test_playbook.yml', variable_manager=VariableManager(), loader=None)
    play = Play().load(playbook.get('playbooks')[0], variable_manager=VariableManager(), loader=None)
    play

# Generated at 2022-06-23 13:00:55.224302
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  pass


# Generated at 2022-06-23 13:01:01.161140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    import mock

    module_return_value = {}
    # the task below is contrived, and probably won't work
    task_list = [Task.load(dict(action=dict(module='ping'), register='ping_result'))]
    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play ",
        hosts='web',
        gather_facts='no',
        tasks=task_list
    )

    play = Play().load(play_source, variable_manager=None, loader=mock.Mock())
    iterator = play.get_iterator()


# Generated at 2022-06-23 13:01:04.120048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Call constructor
    test_class = StrategyModule(tqm=None)

    assert test_class.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-23 13:01:08.021051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule("test")
    assert test_StrategyModule.__class__.__name__ == 'StrategyModule'
    assert test_StrategyModule.__dict__.get("_host_pinned") is False

# Generated at 2022-06-23 13:01:17.447398
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  from ansible.playbook.task_include import TaskInclude
  from ansible.plugins import strategy_loader
  from ansible.template import Templar
  from ansible.utils.vars import combine_vars
  from ansible.vars import HostVars
  display = Display()
  TaskInclude.add_vars = add_vars

# Generated at 2022-06-23 13:01:19.713315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    strategy = StrategyModule(TaskQueueManager())
    assert strategy._host_pinned == False

# Generated at 2022-06-23 13:01:28.989442
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-23 13:01:31.794487
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    r = run_module(module_name='StrategyModule', module_args={}, check_mode=True, create_tmp_path=True)
    assert r['failed'] == True

# Generated at 2022-06-23 13:01:39.569865
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create a mock object that can stand in for the strategy target
    class TestStrategyModule(StrategyModule):
        # override the get_hosts_left function to stand-in for the target function
        def get_hosts_left(self, iterator):
            return [1,2,3]
    # we need a strategy module and are using a test class
    tqm = 1
    strategyModule = TestStrategyModule(tqm)

    # we need an iterator and a play_context
    class TestPlayContext:
        # override the get_hosts_left function to stand-in for the target function
        def __init__(self):
            self.max_fail_percentage = None
            self.remote_addr = None
            self.remote_user = None
            self.verbosity = None

# Generated at 2022-06-23 13:01:47.506976
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager(
                connection=None,
                module_name='setup',
                module_args=None,
                module_vars=None,
                play_context=None,
                loader=None,
                variable_manager=None,
                shared_loader_obj=None,
                db=None,
                )
    strategy = StrategyModule(
                tqm=tqm,
                connection_info=connection_info,
                )
    def get_hosts_left():
        return ['101', '102', '103']
    iterator._play = ['101', '102']
    iterator._play.max_fail_percentage = None
    def get_next_task_for_host(host, peek=False):
        return 1, 'task'
    iterator.get_next_task_for_host