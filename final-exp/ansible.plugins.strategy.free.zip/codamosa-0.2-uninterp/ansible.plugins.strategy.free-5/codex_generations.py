

# Generated at 2022-06-17 14:02:01.670450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 14:02:10.397277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 14:02:22.876849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_list import HandlerTaskList
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.process.worker import WorkerProcess

# Generated at 2022-06-17 14:02:25.787563
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a test StrategyModule object
    strategy_module = StrategyModule(tqm)

    # Call the run method of the object
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-17 14:02:26.834148
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:37.662074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-17 14:02:46.967181
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler_task_list import HandlerTaskList
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

# Generated at 2022-06-17 14:02:47.597453
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:49.698353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.ALLOW_BASE_THROTTLING == False
    assert StrategyModule._host_pinned == False

# Generated at 2022-06-17 14:02:50.671033
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:03:11.415367
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:12.112767
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:22.602009
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine

# Generated at 2022-06-17 14:03:30.169529
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the strategy_module
    strategy_module = StrategyModule(tqm)
    # Call the method run of the strategy_module
    strategy_module.run(iterator, play_context)
    # Check if the method run of the strategy_module was called
    assert strategy_module.run.called

# Generated at 2022-06-17 14:03:44.479201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars_files
    from ansible.utils.vars import load_options_vars_files
    from ansible.utils.vars import load_group_vars_files
    from ansible.utils.vars import load_host_vars_files

# Generated at 2022-06-17 14:03:56.546285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 14:03:57.720515
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:58.624005
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:00.582686
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:04:08.167792
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the tqm
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)
    # Check if the run method of the StrategyBase object was called
    StrategyBase.run.assert_called_with(strategy_module, iterator, play_context, False)

# Generated at 2022-06-17 14:04:54.322483
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)
    # Assert that the run method of the TQM object was called
    tqm.run.assert_called_with(iterator, play_context)

# Generated at 2022-06-17 14:04:55.274367
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: implement test
    pass


# Generated at 2022-06-17 14:05:05.980249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

# Generated at 2022-06-17 14:05:17.823489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule as StrategyModuleLinear
    from ansible.plugins.strategy.free import StrategyModule as StrategyModuleFree


# Generated at 2022-06-17 14:05:25.503934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a temporary directory to store the inventory
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create the inventory file

# Generated at 2022-06-17 14:05:26.320925
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:35.334519
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:05:36.992390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-17 14:05:47.141162
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a mock object for the host
    host = Mock()
    # Create a mock object for the task
    task = Mock()
    # Create a mock object for the task_vars
    task_vars = Mock()
    # Create a mock object for the templar
    templar = Mock()
    # Create a mock object for the action
    action = Mock()
    # Create a mock object for the results
    results = Mock()
    # Create a mock object for the included_files
    included_files = Mock()
    # Create a mock object for the new_blocks

# Generated at 2022-06-17 14:05:47.696331
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:23.637820
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the tqm
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a mock object for the host
    host = Mock()
    # Create a mock object for the task
    task = Mock()
    # Create a mock object for the task_vars
    task_vars = Mock()
    # Create a mock object for the templar
    templar = Mock()
    # Create a mock object for the action
    action = Mock()
    # Create a mock object for the worker
    worker = Mock()
    # Create a mock object for the results
    results = Mock()
    # Create a mock object for the included_file
    included_file = Mock()
   

# Generated at 2022-06-17 14:07:24.273565
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:32.271786
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class TQM
    tqm = Mock()
    # Create a mock object of class PlayContext
    play_context = Mock()
    # Create a mock object of class Iterator
    iterator = Mock()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Call the method run of class StrategyModule
    strategy_module.run(iterator, play_context)
    # Assert that the method run of class StrategyModule was called
    assert strategy_module.run.called
    # Assert that the method run of class StrategyModule was called with the correct arguments
    assert strategy_module.run.call_args == call(iterator, play_context)


# Generated at 2022-06-17 14:07:43.164387
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock task queue manager
    tqm = MockTaskQueueManager()
    # Create a mock iterator
    iterator = MockIterator()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a strategy module
    strategy_module = StrategyModule(tqm)
    # Call method run of class StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if the method run of class StrategyModule has been called
    assert strategy_module.run.called
    # Check if the method run of class StrategyModule has been called with the correct parameters
    assert strategy_module.run.call_args == call(iterator, play_context)


# Generated at 2022-06-17 14:07:43.752479
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:44.714688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-17 14:07:45.612352
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:56.904861
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test with no hosts
    tqm = MagicMock()
    tqm.send_callback.return_value = None
    tqm.RUN_OK = 'ok'
    tqm._terminated = False
    tqm._unreachable_hosts = []
    tqm.get_hosts_left.return_value = []
    tqm.send_callback.return_value = None

# Generated at 2022-06-17 14:08:07.213628
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:08:08.357787
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass