

# Generated at 2022-06-17 14:02:02.747323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 14:02:03.532762
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:04.279061
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:05.503595
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:02:07.003511
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:08.013725
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:20.592170
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 14:02:21.405205
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:22.077616
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:30.494611
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the AnsibleTaskQueueManager class
    tqm = mock.MagicMock()
    # Create a mock object for the AnsibleIterator class
    iterator = mock.MagicMock()
    # Create a mock object for the AnsiblePlayContext class
    play_context = mock.MagicMock()
    # Create an object for the StrategyModule class
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule class with the required arguments
    strategy_module.run(iterator, play_context)
    # Assert that the run method of the AnsibleTaskQueueManager class was called
    tqm.run.assert_called_with()
    # Assert that the run method of the AnsibleIterator class was called
    iterator.run.assert_called_with()
    # Assert that the run

# Generated at 2022-06-17 14:02:52.818181
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:02.236901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase

# Generated at 2022-06-17 14:03:02.916969
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:11.855939
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object
    tqm = Mock()
    # Create a mock object
    iterator = Mock()
    # Create a mock object
    play_context = Mock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call method run of class StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if method run of class StrategyModule was called
    assert strategy_module.run.called
    # Check if method run of class StrategyModule was called with the correct arguments
    assert strategy_module.run.call_args == call(iterator, play_context)


# Generated at 2022-06-17 14:03:13.342808
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Implement test
    pass


# Generated at 2022-06-17 14:03:24.631124
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 14:03:34.196667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.template import Templar


# Generated at 2022-06-17 14:03:46.605838
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the tqm
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a mock object for the host
    host = Mock()
    # Create a mock object for the task
    task = Mock()
    # Create a mock object for the task_vars
    task_vars = Mock()
    # Create a mock object for the action
    action = Mock()
    # Create a mock object for the templar
    templar = Mock()
    # Create a mock object for the worker
    worker = Mock()
    # Create a mock object for the results
    results = Mock()
    # Create a mock object for the included_files
    included_files = Mock()
   

# Generated at 2022-06-17 14:03:58.396389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_

# Generated at 2022-06-17 14:03:59.432985
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:51.404578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.utils.vars import combine

# Generated at 2022-06-17 14:04:53.887426
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Implement unit test for method run of class StrategyModule
    pass

# Generated at 2022-06-17 14:04:54.395193
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:01.215282
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create a mock object for the tqm
    tqm = Mock()

    # create a mock object for the iterator
    iterator = Mock()

    # create a mock object for the play_context
    play_context = Mock()

    # create a StrategyModule object
    strategy_module = StrategyModule(tqm)

    # call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)

    # check if the run method of the StrategyBase object was called
    assert StrategyBase.run.called

# Generated at 2022-06-17 14:05:08.083467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 14:05:20.625676
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess


# Generated at 2022-06-17 14:05:21.685431
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:22.580631
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:23.800058
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:24.621302
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:59.181878
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:00.038338
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:09.401101
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    import ansible.plugins.strategy.free as free
    import ansible.plugins.strategy.linear as linear
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug
    import ansible.plugins.strategy.debug as debug

# Generated at 2022-06-17 14:07:21.479230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.strategy import StrategyBase

# Generated at 2022-06-17 14:07:22.087407
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:31.451954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import load_command_line_vars
    from ansible.utils.vars import load_playbook_vars

# Generated at 2022-06-17 14:07:32.658045
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:44.381687
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = MagicMock()
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)
    # Assert that the run method of the TQM object was called
    tqm.run.assert_called_with()
    # Assert that the run method of the iterator object was called
    iterator.run.assert_called_with()
    # Assert that the run method of the play_context object was called
    play_context.run.assert_called_with()



# Generated at 2022-06-17 14:07:45.251580
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:47.387799
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Implement test for method run of class StrategyModule
    pass
