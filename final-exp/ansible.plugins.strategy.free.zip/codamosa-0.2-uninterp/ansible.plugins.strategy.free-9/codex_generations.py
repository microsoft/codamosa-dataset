

# Generated at 2022-06-17 14:02:00.816051
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    import unittest

    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            self.mock_tqm = mock.MagicMock()
            self.mock_iterator = mock.MagicMock()
            self.mock_play_context = mock.MagicMock()
            self.mock_tqm.RUN_OK = 'RUN_OK'
            self.mock_tqm._terminated = False
            self.mock_tqm.send_callback = mock.MagicMock()
            self.mock_tqm.send_callback.return_value = None
            self.mock_tqm._unreachable_hosts = []

# Generated at 2022-06-17 14:02:01.525798
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:10.205712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_task import HandlerTask
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 14:02:12.225711
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Implement unit test for method run of class StrategyModule
    pass

# Generated at 2022-06-17 14:02:13.262724
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:13.951104
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:25.657538
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class Play
    play = Play()
    # Create a mock object of class TaskQueueManager
    tqm = TaskQueueManager()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Create a mock object of class Host
    host = Host()
    # Create a mock object of class Iterator
    iterator = Iterator()
    # Create a mock object of class Task
    task = Task()
    # Create a mock object of class ActionBase
    action_base = ActionBase()
    # Create a mock object of class Role
    role = Role()
    # Create a mock object of class IncludedFile
    included_file = IncludedFile()
    # Create a mock object of class Block
   

# Generated at 2022-06-17 14:02:26.833670
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:28.000655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None

# Generated at 2022-06-17 14:02:39.184537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.template import Templar

# Generated at 2022-06-17 14:02:58.671089
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:59.291866
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:08.453548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 14:03:09.400890
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:20.608427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_task_vars

# Generated at 2022-06-17 14:03:21.106550
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:21.849394
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:32.199236
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import merge_extra_vars

# Generated at 2022-06-17 14:03:45.551033
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.strategy import StrategyBase

# Generated at 2022-06-17 14:03:57.649704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
   

# Generated at 2022-06-17 14:04:34.460776
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:45.588126
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the queue
    class MockQueue:
        def __init__(self):
            self.queue = []
        def put(self, item):
            self.queue.append(item)
        def get(self):
            return self.queue.pop(0)
        def empty(self):
            return len(self.queue) == 0
    # Create a mock object for the task queue manager
    class MockTaskQueueManager:
        def __init__(self):
            self.RUN_OK = 0
            self.terminated = False
            self.unreachable_hosts = []
            self.queue = MockQueue()
        def send_callback(self, callback, *args):
            pass
        def _terminated(self):
            return self.terminated
    # Create a mock object for the iterator
   

# Generated at 2022-06-17 14:04:55.136557
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the strategy
    strategy = StrategyModule(tqm)
    # Create a mock object for the strategy
    strategy.run(iterator, play_context)
    # Check if the method run of the strategy was called
    assert strategy.run.called
    # Check if the method run of the strategy was called with the correct parameters
    assert strategy.run.call_args == call(iterator, play_context)

# Generated at 2022-06-17 14:04:55.579877
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:58.632225
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)
    iterator = Iterator()
    play_context = PlayContext()
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-17 14:04:59.198068
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:06.677564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_method import BecomeMethod
    from ansible.playbook.helpers import load_list_of_blocks

# Generated at 2022-06-17 14:05:07.267982
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:08.304857
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:09.262865
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:37.666709
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the tqm
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)
    # Check if the run method of the tqm object was called
    assert tqm.run.called
    # Check if the run method of the iterator object was called
    assert iterator.run.called
    # Check if the run method of the play_context object was called
    assert play_context.run.called
    # Check if the run method of the StrategyBase object was called

# Generated at 2022-06-17 14:06:41.036820
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a test StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method
    strategy_module.run(iterator, play_context)
    # Check the result
    assert strategy_module.run(iterator, play_context) == True

# Generated at 2022-06-17 14:06:41.733286
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:42.667697
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:43.351588
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:44.062447
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:52.913486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 14:06:53.580072
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:54.404156
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:55.565485
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:09:59.016972
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:09:59.798254
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:10:00.564575
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:10:10.222828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_task_vars_files

# Generated at 2022-06-17 14:10:10.683430
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:10:11.801700
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:10:16.526854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    play

# Generated at 2022-06-17 14:10:17.096295
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:10:17.725713
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:10:18.355060
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass