

# Generated at 2022-06-17 14:01:53.216067
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:04.321323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-17 14:02:05.597436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-17 14:02:06.992417
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:08.213070
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Implement test
    pass


# Generated at 2022-06-17 14:02:09.153660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-17 14:02:09.790452
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:10.398070
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:13.251350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == False

# Generated at 2022-06-17 14:02:13.951215
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:46.463570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyModule


# Generated at 2022-06-17 14:02:47.074099
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:57.156055
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a mock object for the host
    host = Mock()
    # Create a mock object for the task
    task = Mock()
    # Create a mock object for the task_vars
    task_vars = Mock()
    # Create a mock object for the results
    results = Mock()
    # Create a mock object for the included_files
    included_files = Mock()
    # Create a mock object for the new_ir
    new_ir = Mock()
    # Create a mock object for the new_blocks
    new_blocks = Mock()
    # Create a mock object for the final_block
   

# Generated at 2022-06-17 14:02:57.709396
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:59.041142
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:05.128566
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class TQM
    tqm = TQM()
    # Create a mock object of class Iterator
    iterator = Iterator()
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Call the method run of class StrategyModule
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-17 14:03:06.987076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-17 14:03:08.493006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None

# Generated at 2022-06-17 14:03:09.449904
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:20.659252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy.free import StrategyModule

# Generated at 2022-06-17 14:04:05.044860
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:06.506503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:04:07.143758
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:15.306249
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the strategy_module
    strategy_module = StrategyModule(tqm)
    # Call the method run of class StrategyModule
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-17 14:04:16.015596
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:16.933606
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:17.616587
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:19.797928
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test with a valid iterator and play_context
    # TODO: Add test for this method
    pass

# Generated at 2022-06-17 14:04:20.488580
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:30.022131
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class StrategyBase
    strategy_base = StrategyBase(None)

    # Create a mock object of class Tqm

# Generated at 2022-06-17 14:06:08.563216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import load_command_line_vars
    from ansible.utils.vars import load_playbook_vars

# Generated at 2022-06-17 14:06:19.131319
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TaskQueueManager class
    tqm = MockTaskQueueManager()
    # Create a mock object for the PlayIterator class
    iterator = MockPlayIterator()
    # Create a mock object for the PlayContext class
    play_context = MockPlayContext()
    # Create a mock object for the StrategyModule class
    strategy_module = StrategyModule(tqm)
    # Call the method run of class StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if the method run of class StrategyModule has been called
    assert strategy_module.run.called
    # Check if the method run of class StrategyModule has been called with the right parameters
    strategy_module.run.assert_called_with(iterator, play_context)


# Generated at 2022-06-17 14:06:28.374751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

# Generated at 2022-06-17 14:06:38.125825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule as StrategyModuleLinear
    from ansible.plugins.strategy.free import StrategyModule as StrategyModuleFree


# Generated at 2022-06-17 14:06:38.684041
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:39.264448
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:39.865424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:06:40.488863
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:43.390751
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialize the class
    strategy_module = StrategyModule(tqm)
    # Call the method
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-17 14:06:50.517315
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = MagicMock()
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)
    # Assert that the method run of the TQM object was called
    tqm.run.assert_called_once_with()

# Generated at 2022-06-17 14:10:58.347631
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = MagicMock()
    tqm.RUN_OK = 0
    tqm.send_callback.return_value = None
    tqm._terminated = False
    tqm._unreachable_hosts = {}
    tqm._workers = []
    tqm.send_callback.return_value = None
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator.get_hosts_left.return_value = []
    iterator.get_next_task_for_host.return_value = (None, None)
    iterator.is_failed.return_value = False
    # Create a mock object for the

# Generated at 2022-06-17 14:11:08.513175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.filevars import FileVars

# Generated at 2022-06-17 14:11:17.202745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 14:11:17.679158
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:11:18.120718
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:11:18.698384
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:11:19.597525
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:11:30.737752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 14:11:43.710049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager