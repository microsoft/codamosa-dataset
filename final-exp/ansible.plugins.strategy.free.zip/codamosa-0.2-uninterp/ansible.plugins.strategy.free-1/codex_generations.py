

# Generated at 2022-06-17 14:01:49.902768
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:01.362298
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the strategy_base
    strategy_base = MagicMock()
    # Create a mock object for the strategy_base
    strategy_base.run = MagicMock()
    # Create a mock object for the strategy_base
    strategy_base.run.return_value = True
    # Create a mock object for the strategy_base
    strategy_base.run.return_value = True
    # Create a mock object for the strategy_base
    strategy_base.run.return_value = True
    # Create a mock object for the strategy_base
    strategy_base

# Generated at 2022-06-17 14:02:01.801963
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:02.539172
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:03.443057
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:04.236504
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:12.022637
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = MockTQM()

    # Create a mock object for the iterator
    iterator = MockIterator()

    # Create a mock object for the play_context
    play_context = MockPlayContext()

    # Create a mock object for the strategy
    strategy = StrategyModule(tqm)

    # Call the method run of the strategy with the mock objects
    strategy.run(iterator, play_context)

    # Assert that the method run of the strategy was called with the mock objects
    assert strategy.run.call_args == call(iterator, play_context)

    # Assert that the method run of the strategy was called once
    assert strategy.run.call_count == 1


# Generated at 2022-06-17 14:02:24.249194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 14:02:35.736516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory

# Generated at 2022-06-17 14:02:37.572384
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:12.255606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 14:03:13.354490
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:03:23.135710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 14:03:23.736054
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:24.858182
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:25.986956
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:27.163385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == False

# Generated at 2022-06-17 14:03:35.958025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task

# Generated at 2022-06-17 14:03:36.521653
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:42.965348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_

# Generated at 2022-06-17 14:04:30.355198
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:43.987353
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:04:44.506259
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:55.281560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display

# Generated at 2022-06-17 14:04:55.740916
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:56.223742
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:04.359721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy.linear import StrategyModule

    # Create a task
    task = Task()
    task._role = None
    task._uuid = 'dummy_uuid'
    task._block = Block()
    task._block

# Generated at 2022-06-17 14:05:04.986347
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:05.549301
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:05:06.099857
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:45.807787
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:53.904271
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class TQM
    tqm = Mock()
    # Create a mock object of class PlayContext
    play_context = Mock()
    # Create a mock object of class Iterator
    iterator = Mock()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Call the method run of class StrategyModule
    strategy_module.run(iterator, play_context)
    # Assert that method _set_hosts_cache of class StrategyModule was called
    assert strategy_module._set_hosts_cache.called
    # Assert that method get_hosts_left of class StrategyModule was called
    assert strategy_module.get_hosts_left.called
    # Assert that method _tqm.send_callback of class StrategyModule was called
    assert strategy_

# Generated at 2022-06-17 14:07:05.514456
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class TaskQueueManager
    tqm = mock.Mock()
    # Create a mock object of class PlaybookIterator
    iterator = mock.Mock()
    # Create a mock object of class PlayContext
    play_context = mock.Mock()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Call method run of class StrategyModule
    strategy_module.run(iterator, play_context)
    # Assert that method run of class StrategyModule was called
    assert strategy_module.run.called
    # Assert that method run of class StrategyModule was called with the correct arguments
    assert strategy_module.run.call_args == mock.call(iterator, play_context)

# Generated at 2022-06-17 14:07:06.258987
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:06.829903
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:19.342602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars_file
    from ansible.utils.vars import merge_extra_vars
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 14:07:19.973520
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:29.473110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 14:07:30.430549
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:31.401079
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass