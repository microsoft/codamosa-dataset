

# Generated at 2022-06-17 14:02:04.391987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 14:02:09.943718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 14:02:22.345614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

# Generated at 2022-06-17 14:02:27.984510
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class Tqm
    tqm = Tqm()
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class Iterator
    iterator = Iterator()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Call the method run of class StrategyModule
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-17 14:02:28.645932
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:36.253969
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = mock.MagicMock()
    # Create a mock object for the iterator
    iterator = mock.MagicMock()
    # Create a mock object for the play_context
    play_context = mock.MagicMock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)
    # Check if the run method of the TQM object was called
    assert tqm.run.called


# Generated at 2022-06-17 14:02:37.910937
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:38.609812
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:39.365919
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:02:40.066441
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:09.410686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 14:03:12.400519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test object of class StrategyModule
    strategy_module = StrategyModule(None)
    # Test the constructor of class StrategyModule
    assert strategy_module is not None

# Generated at 2022-06-17 14:03:13.107798
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:13.844115
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:15.016324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-17 14:03:25.397662
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the class TQM
    tqm = MagicMock()
    # Create a mock object for the class Iterator
    iterator = MagicMock()
    # Create a mock object for the class PlayContext
    play_context = MagicMock()
    # Create an instance of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Call the method run of class StrategyModule
    strategy_module.run(iterator, play_context)
    # Assert that the method run of class StrategyModule was called
    assert strategy_module.run.called
    # Assert that the method run of class StrategyModule was called with the correct parameters
    assert strategy_module.run.call_args == call(iterator, play_context)

# Generated at 2022-06-17 14:03:34.434917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 14:03:35.447035
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:03:37.727975
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Implement unit test for method run of class StrategyModule
    pass

# Generated at 2022-06-17 14:03:38.788749
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:26.621318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-17 14:04:37.539841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.plugins.strategy import StrategyBase
    from ansible.inventory.host import Host

# Generated at 2022-06-17 14:04:38.519689
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:39.465411
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:04:40.566250
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:04:41.158449
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True

# Generated at 2022-06-17 14:04:51.253338
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.strategy import StrategyBase
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase

# Generated at 2022-06-17 14:04:59.973969
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = MagicMock()
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)
    # Assert that the run method of the TQM has been called
    tqm.run.assert_called_once_with()

# Generated at 2022-06-17 14:05:07.148287
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a mock object for the host
    host = Mock()
    # Create a mock object for the task
    task = Mock()
    # Create a mock object for the task_vars
    task_vars = Mock()
    # Create a mock object for the templar
    templar = Mock()
    # Create a mock object for the action
    action = Mock()
    # Create a mock object for the results
    results = Mock()
    # Create a mock object for the included_files
    included_files = Mock()
    # Create a mock object for the new_ir

# Generated at 2022-06-17 14:05:19.943509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 14:06:44.977439
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:45.695587
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:46.393212
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:47.095507
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:06:54.614276
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:07:06.491868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import load_command_line_vars
    from ansible.utils.vars import merge_extra_vars

# Generated at 2022-06-17 14:07:18.892939
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:07:19.599471
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:20.192971
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:07:20.678155
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:11:03.176420
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class TaskQueueManager
    tqm = mock.create_autospec(TaskQueueManager)

    # Create a mock object of class Iterator
    iterator = mock.create_autospec(Iterator)

    # Create a mock object of class PlayContext
    play_context = mock.create_autospec(PlayContext)

    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm)

    # Call the method run of class StrategyModule
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-17 14:11:11.763531
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TaskQueueManager class
    tqm = mock.Mock()
    # Create a mock object for the Iterator class
    iterator = mock.Mock()
    # Create a mock object for the PlayContext class
    play_context = mock.Mock()
    # Create a mock object for the StrategyBase class
    strategy_base = mock.Mock()
    # Create a mock object for the StrategyModule class
    strategy_module = StrategyModule(tqm)
    # Create a mock object for the StrategyBase class
    strategy_base = mock.Mock()
    # Create a mock object for the StrategyBase class
    strategy_base = mock.Mock()
    # Create a mock object for the StrategyBase class
    strategy_base = mock.Mock()
    # Create a mock object for the StrategyBase class
    strategy

# Generated at 2022-06-17 14:11:12.395848
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:11:17.662223
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the TQM
    tqm = Mock()
    # Create a mock object for the iterator
    iterator = Mock()
    # Create a mock object for the play_context
    play_context = Mock()
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)
    # Call the run method of the StrategyModule object
    strategy_module.run(iterator, play_context)
    # Check if the run method of the TQM object was called
    tqm.run.assert_called_with()

# Generated at 2022-06-17 14:11:18.234118
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:11:18.809253
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-17 14:11:20.382327
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: implement test
    pass


# Generated at 2022-06-17 14:11:31.493286
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:11:33.474615
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:11:40.302714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.task_include import TaskInclude