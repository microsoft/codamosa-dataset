

# Generated at 2022-06-11 16:52:41.417099
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

    # Unit test for method get_hosts_left of class StrategyModule

# Generated at 2022-06-11 16:52:44.649104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-11 16:52:46.037399
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test setup
    # test_setup()
    pass

# Generated at 2022-06-11 16:52:46.750137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:52:58.708259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import module_loader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_inventory_file

    my_loader = DataLoader()
    my_inventory = InventoryManager(my_loader, sources=["playbook1"])

# Generated at 2022-06-11 16:53:00.997716
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_run =  StrategyModule()
    strategy_module_run.run()

# Generated at 2022-06-11 16:53:01.796188
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:53:10.497863
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    # create mock objects
    TQM = MagicMock()
    TQM.RUN_OK = "RUN_OK"
    TQM.send_callback.return_value = True
    iterator = MagicMock()
    play_context = MagicMock()

    # create object instance
    strategy_module = StrategyModule(TQM)

    # get results
    results = strategy_module.run(iterator, play_context)

    # check results
    assert results == "RUN_OK"


# Generated at 2022-06-11 16:53:19.845453
# Unit test for method run of class StrategyModule

# Generated at 2022-06-11 16:53:22.930221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test for constructor of class StrategyModule
    """
    strategy_module_obj = StrategyModule(None)
    assert None == strategy_module_obj._tqm



# Generated at 2022-06-11 16:53:47.361374
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-11 16:53:53.029220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def run(self):
        return True

    my_tqm = type('TaskQueueManager', (object,), {
        'RUN_OK': True,
        '_terminated': False,
        'send_callback': lambda self_: True,
        '_unreachable_hosts': [],
    })()

    sm = StrategyModule(my_tqm)
    sm.run = run
    sm.run(None, None)

# Generated at 2022-06-11 16:54:05.584737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # test needed for constructor
    _loader = DataLoader()
    _tqm = TaskQueueManager(
        inventory=InventoryManager(loader=_loader, sources=""),
        variable_manager=VariableManager(loader=_loader),
        loader=_loader,
        passwords={},
    )

# Generated at 2022-06-11 16:54:17.195236
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """
    This method tests StrategyModule class, which extends StrategyBase class.
    StrategyModule class is used to run tasks on multiple hosts parallelly.
    It defines run method which checks whether there are any hosts left and tasks to be executed or not.
    If there are no hosts left, playbook execution finishes.
    If there are no tasks to execute, it breaks the loop.
    """
    # Assign values to class variables
    include_tags = []
    exclude_tags = []
    only_tags = []
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from collections import named

# Generated at 2022-06-11 16:54:18.239035
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-11 16:54:27.744049
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from Units.mock import MagicMock
    from Units.mock import Subject, call

    iterator = MagicMock(spec=Subject)
    play_context = MagicMock(spec=Subject)


    s = StrategyModule(iterator)
    # Iterator object contains no items
    iterator._hosts_left = []
    s.run(iterator, play_context)
    assert [] == iterator._hosts_left
    # Executing the whole run() method
    iterator._hosts_left = [1, 2]
    iterator._play.max_fail_percentage = 273
    iterator._play.__getitem__ = MagicMock()
    iterator._play.__getitem__.side_effect = lambda x: iterator._play.max_fail_percentage if x == "max_fail_percentage" else None

# Generated at 2022-06-11 16:54:33.412168
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)

    assert strategy_module.run(iterator, play_context) == self._tqm.RUN_OK
    assert strategy_module.run(iterator, play_context) == self._wait_on_pending_results(iterator)



# Generated at 2022-06-11 16:54:34.128956
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:54:44.037901
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #Set up the test variables
    host = Host(name = 'localhost', port = 22)
    name = 'Test'
    port = 22
    run_once = False
    pack = ansible.playbook.pack.Pack()
    variable_manager = ansible.vars.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.VariableManager()
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources=[])
    variable_manager = ansible.vars.VariableManager(loader=loader, inventory=inventory)
    play_context = ansible.playbook.play_context.PlayContext(variable_manager=variable_manager, loader=loader)
    tqm = ansible.executor.task_queue_manager.Task

# Generated at 2022-06-11 16:54:52.019480
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  import ansible.plugins.strategy.free as free
  import tempfile
  import os
  import shutil
  import sys
  
  with tempfile.NamedTemporaryFile(mode='w+t') as tf:
    # Create sample data
    data = [
    '- name: sample',
    '  hosts: all',
    '  tasks:',
    '  - name: sample_task',
    '    command: touch test.txt'    
    ]
    tf.writelines(data)
    tf.seek(0)
    
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    
    # Create a file for stdout
    stdout_file = tempfile.mktemp()
    temp_stdout = sys.stdout

# Generated at 2022-06-11 16:56:01.110185
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = Mock()
    iterator = Mock()
    iterator.hosts = [Mock(), Mock(), Mock()]
    iterator.hosts[0].name = 'host1'
    iterator.hosts[1].name = 'host2'
    iterator.hosts[2].name = 'host3'
    iterator._play = Mock()
    iterator._play.max_fail_percentage = None
    play_context = Mock()
    iterator.get_next_task_for_host = Mock()
    iterator.get_next_task_for_host.return_value = (True, 'task1')
    iterator.is_failed = Mock()
    iterator.is_failed.return_value = False
    host_results = [Mock(), Mock(), Mock()]
    host_results[0]._host = 'host1'


# Generated at 2022-06-11 16:56:01.747756
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:56:12.274972
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.utils.vars as vars

    def get_loader():
        return DataLoader()

    def get_templar():
        return Templar(get_loader(), variables={'a': '1'})


# Generated at 2022-06-11 16:56:14.886684
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator = {}
    play_context = {}
    assert(StrategyModule.run(iterator, play_context)) == None

# Generated at 2022-06-11 16:56:17.119677
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-11 16:56:27.585522
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Imports ansible.plugins.strategy.free
    from ansible.plugins.strategy.free import StrategyModule
    # Mock AnsibleTemporaryFailure
    class AnsibleTemporaryFailure(Exception):
        def __init__(self, s):
            self.s = s
        def __str__(self):
            return self.s
    # mocking is not used
    # mock None
    # Mock object
    class Mock(object):
        @staticmethod
        def __init__(): pass
        @staticmethod
        def get_vars(play=None, host=None, task=None, _hosts=None, _hosts_all=None): return dict()
        @staticmethod
        def get_group_variables(group=None): return dict()

# Generated at 2022-06-11 16:56:38.933045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class ClassTqm:
        def __init__(self):
            self.stats = ClassStats()
            self.RUN_OK = 0
            self.RUN_UNKNOWN_ERROR = 0

    class ClassStats:
        def __init__(self):
            self.dark = {}

    class ClassStrategyModule(StrategyModule):
        def get_hosts_left(self, iterator):
            print('get_hosts_left')
            return []

        def _process_pending_results(self, iterator):
            print('_process_pending_results')
            return []

        def _wait_on_pending_results(self, iterator):
            print('_wait_on_pending_results')
            return []

    class ClassIterator:
        def __init__(self):
            self._play = Play

# Generated at 2022-06-11 16:56:40.346348
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import unittest
    pass


# Generated at 2022-06-11 16:56:46.143017
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from collections import namedtuple

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'listhosts', 'listtasks', 'listtags', 'syntax'])

# Generated at 2022-06-11 16:56:49.786009
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = Host()
    tqm = TaskQueueManager()
    iterator = TaskIterator()
    play_context = PlayContext()
    strategyModule = StrategyModule(tqm)
    strategyModule.run(iterator, play_context)

# Generated at 2022-06-11 16:59:18.931915
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # mock settings
    C.DEFAULT_INTERNAL_POLL_INTERVAL = None

    # mock objects
    class Host(object):
        def get_name(self):
            return 'host'

    class Task(object):
        def __init__(self, action, name, run_once, any_errors_fatal, throttle, _role, _ds, _role_metadata):
            self.action = action
            self.name = name
            self.run_once = run_once
            self.any_errors_fatal = any_errors_fatal
            self.throttle = throttle
            self._role = _role
            self._ds = _ds
            self._role_metadata = _role_metadata
        def get_name(self):
            return self.name


# Generated at 2022-06-11 16:59:29.323391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    import queue
    import unittest.mock
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-11 16:59:36.192153
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)
    sm._blocked_hosts = {}
    sm._host_pinned = True
    sm._tqm = TaskQueueManager()

# Generated at 2022-06-11 16:59:38.753856
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    obj = StrategyModule(tqm)
    obj.run(iterator, play_context)


# Generated at 2022-06-11 16:59:49.979023
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.vars import VariableManager
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.other.hardware import Hardware
    from ansible.module_utils.facts.other.selinux import SELinux
    from ansible.module_utils.facts.other.virtual import Virtual
    from ansible.module_utils.facts.other.virtual import Virtual
    from ansible.module_utils.facts.other.fips import FIPS
    from ansible.module_utils.facts.other.config_file import Config_File
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform

# Generated at 2022-06-11 16:59:53.055149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    MockPlay = namedtuple('MockPlay', ['name'])
    mock_manager = {}

    strategy_module = StrategyModule(mock_manager)
    assert isinstance(strategy_module, StrategyBase)
    assert strategy_module._host_pinned is False

# Generated at 2022-06-11 16:59:59.545665
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a strategy variable to call method run of class StrategyModule
    strategy_mod = StrategyModule(tqm)
    strategy_mod.run(iterator, play_context)


'''
    def __init__(self, tqm):
        super(StrategyModule, self).__init__(tqm)

        self._failed_hosts = {}
        self._pending_results = []
        self._workers = []
        self._blocked = []

        self._final_q = Queue()
        self._tqm.send_callback('v2_playbook_on_start')

    def _wait_on_pending_results(self, iterator):
        '''

# Generated at 2022-06-11 17:00:05.262623
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = MockHost()
    task = MockTask()
    play = MockPlay()
    iterator = MockIterator(play, {host: [task]})
    tqm = MockTQM()
    tqm._terminated = False

    sm = StrategyModule(tqm)
    sm._tqm._terminated = False
    sm.run(iterator, None)

    assert tqm._terminated is True
    assert iterator._iterator_ran is True

# Generated at 2022-06-11 17:00:05.904808
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule.run()

# Generated at 2022-06-11 17:00:10.842450
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # In this Unit test we are checking that the run() method of class StrategyModule
    # is working correctly.
    #
    # Check that results of method run() is not None and has the correct type:
    # Boolean
    #
    # Make sure that results is correct (using assert):
    #    - assert_equal() 
    #
    # Results should be equal to super(StrategyModule, self).run()
    pass