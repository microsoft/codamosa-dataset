

# Generated at 2022-06-11 16:52:47.591013
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager()
    strategy = StrategyModule(tqm)
    iterator = BasicTestIterator()
    play_context = PlayContext()
    strategy.run(iterator, play_context)

# Generated at 2022-06-11 16:52:50.669421
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None
    strategy_module = StrategyModule(tqm)
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-11 16:52:52.658567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(1)
    assert result.host_pinned is False

# Generated at 2022-06-11 16:53:02.257562
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

    # Selecting one or more hosts to move to the running queue
    # The get_hosts_left method will return the hosts in the unblocked host list.
    # This is an internal method and you should use either
    # the get_active_hosts or get_active_serialized_hosts methods
    # to get the hosts currently in the running queue.

    # All hosts start as unblocked and on the unblocked host list,
    # and when they are moved to the scheduled queue the
    # unblocked_hosts list is updated.
    # When all hosts are blocked, the running queue is empty,
    # and no more hosts are on the unblocked host list, the
    # run method will exit with a status of True.

    # If any hosts fail, the run method will exit with a status of False.
    #

# Generated at 2022-06-11 16:53:12.281229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.strategy import StrategyModule
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.inventory.manager
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.plugins.action
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.role_include
    import os


# Generated at 2022-06-11 16:53:17.878444
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # instantiate class object
    tqm = MockQueueManager()
    tqm.task_queue_manager()
    iterator = MockIterator()
    iterator.iterator()
    play_context = MockPlayContext()
    play_context.play_context()
    worker_strategy_module = StrategyModule(tqm)
    # method run is called
    worker_strategy_module.run(iterator, play_context)
# unit test for method _filter_notified_hosts of class StrategyModule

# Generated at 2022-06-11 16:53:20.832996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  strategymodule = StrategyModule(tqm)
  assert strategymodule._host_pinned == False


# Generated at 2022-06-11 16:53:22.526093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    This tests the constructor of the StrategyModule class
    """
    strategy = StrategyModule(None)
    assert(strategy)
    assert(strategy.get_hosts_left() == None)

# Generated at 2022-06-11 16:53:23.791389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print(StrategyModule)

# Generated at 2022-06-11 16:53:24.445928
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:53:47.916378
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #test_run_test

    #test_run_test

    #test_run_test

    #test_run_test

    #test_run_test
    pass

# Generated at 2022-06-11 16:53:48.551244
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True

# Generated at 2022-06-11 16:53:49.322526
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule([])

# Generated at 2022-06-11 16:53:56.321572
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    obj = StrategyModule()
    obj.tqm = obj._tqm = obj.tqm(loader=None, inventory=None, variable_manager=None, loader_plugin_manager=None, playbooks=None, passwords=None,
                                 stdout_callback=None, options=None, run_additional_callbacks=None, run_tree=None,
                                 datastore=None, shared_loader_obj=None, _unreachable_hosts=None, strategy='free')
    obj.run(iterator, play_context)
    return



# vim: set expandtab:

# Generated at 2022-06-11 16:53:58.302161
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = Mock()
    iterator = Mock()
    play_context = Mock()
    StrategyModule(tqm).run(iterator, play_context)


# Generated at 2022-06-11 16:53:59.216500
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:54:02.790026
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # set up test environment
    # test StrategyModule.run with no hosts in play (no iteration of the play)
    # test StrategyModule.run with hosts in play (iteration of the play)
    return

# Generated at 2022-06-11 16:54:03.512611
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  assert True

# Generated at 2022-06-11 16:54:10.506099
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.errors import AnsibleError
    from ansible import constants as C
    from ansible.playbook.included_file import IncludedFile
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.template import Templar
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display

    modul1 = AnsibleModule(
        argument_spec={
            'first': dict(type='str'),
            'second': dict(type='str', default="second"),
        }
    )

# Generated at 2022-06-11 16:54:12.224692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None


# Generated at 2022-06-11 16:54:59.736661
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager([])
    def get_hosts_left(self, iterator):
        hosts_left = [Host('127.0.0.1', port=22)]
        return hosts_left
    tqm.get_hosts_left = get_hosts_left
    # Create a class object
    strategyModule = StrategyModule(tqm)
    # Call the test function
    assert strategyModule.run(iterator=None,play_context=None) == True

# Generated at 2022-06-11 16:55:02.338102
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  tqm = "tqm"
  iterator = "iterator"
  play_context = "play_context"
  strategy = StrategyModule(tqm)
  strategy.run(iterator, play_context)
  # No return value.  Just testing that the code executes without raising an exception

# Generated at 2022-06-11 16:55:03.064246
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  raise NotImplementedError()

# Generated at 2022-06-11 16:55:04.703315
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
# class StrategyModule



# Generated at 2022-06-11 16:55:14.645449
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    import os.path
    # Test when there are no hosts
    playbook = Playbook.load("test_strategy_plugin.yml")
    hosts = []

# Generated at 2022-06-11 16:55:21.997649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import imp
    import os
    import collections
    import ansible.utils.ansible_module_common as amc
    import ansible.plugins.strategy.free as sf

    # Load the module defined in this file
    imp.load_source(os.path.basename(__file__), os.path.abspath(__file__))

    class MockTaskQueueManager(object):
        def __init__(self, tqm):
            self._terminated = False
            self.RUN_OK = False
            self.send_callback = None
            self._unreachable_hosts = dict()

    module_args = dict()

# Generated at 2022-06-11 16:55:28.506058
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # test with a mocked method which returns magicmock object
    mock_tqm = MagicMock(spec=TaskQueueManager)
    mock_iterator = MagicMock(spec=PlayIterator)
    mock_context = MagicMock(spec=PlayContext)

    StrategyModule(mock_tqm).run(mock_iterator, mock_context)
    mock_tqm.run.assert_called_with(mock_iterator, mock_context)


# Generated at 2022-06-11 16:55:29.348904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-11 16:55:39.269465
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.results import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from test.data.output.v2_output import v2_tasks_results
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    import json
    import os

    class TestPlaybookMP():
        def __init__(self):
            self.blocks = []
            self.role_names = []
            self.filter_properties = []
            self.handlers = []
            self.global_vars = []
            self.vars_prompt

# Generated at 2022-06-11 16:55:49.113766
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager(None, None, None, None, None)
    strategy_module = StrategyModule(tqm)
    print("Start StrategyModule.run() test")

    # test method run with no error
    print("Run test with no error")
    class mock_iterator:
        def __init__(self, play):
            return
        def get_next_task_for_host(self, host, peek=True):
            return (0, 0)
        def _get_next_task_lockstep(self):
            return
        def mark_host_failed(self, host):
            return
        def is_failed(self, host):
            return True
    class mock_play_context:
        def __init__(self):
            self.remote_user = 'root'
            self.port = 22


# Generated at 2022-06-11 16:57:31.602625
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mock = MagicMock()
    mock_dict = {}
    def mock_get_hosts_left(self,iterator):
        return []

    mock_dict['get_hosts_left'] = mock_get_hosts_left
    StrategyModule.__dict__ = mock_dict
    strategy_module = StrategyModule(mock)
    play_context = PlayContext()
    strategy_module.run(mock, play_context)
    assert strategy_module.run(mock, play_context) == False

# Generated at 2022-06-11 16:57:32.195108
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:57:36.438087
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.inventory.manager import InventoryManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.play import Play
  from ansible.plugins.loader import action_loader
  from ansible.plugins.loader import connection_loader
  from ansible.plugins.loader import module_loader
  from ansible.plugins.loader import strategy_loader
  from ansible.vars.manager import VariableManager
  import os
  import shutil
  import tempfile
  import pytest

# Generated at 2022-06-11 16:57:40.208822
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = mock.Mock()
    iterator = mock.Mock()
    play_context = mock.Mock()
    obj = ansible.plugins.strategy.StrategyModule(tqm)
    obj.run(iterator, play_context)
    assert len(iterator.method_calls) == 3

# Generated at 2022-06-11 16:57:41.729913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    s = StrategyModule(Display())

    assert s._host_pinned == False

# Generated at 2022-06-11 16:57:43.092314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Assert StrategyModule class is defined
    assert StrategyModule

# Generated at 2022-06-11 16:57:53.292384
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
        mock_tqm = Mock()
        mock_iterator = Mock()
        mock_play_context = Mock()

        test_object = StrategyModule(tqm = mock_tqm)


# Generated at 2022-06-11 16:57:56.649344
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_rv = StrategyModule.run(
        iterator, 
        play_context, 
        result, 
        self._tqm._terminated
    )
    return tqm_rv

# Generated at 2022-06-11 16:58:08.077959
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # mock
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.plugins.strategy import StrategyBase
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

# Generated at 2022-06-11 16:58:13.066878
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Parameter: tqm
    test_tqm = MockTaskQueueManager()

    # Parameter: iterator
    test_iterator = MockSequence()

    # Parameter: play_context
    test_play_context = MockPlayContext()

    module_strategies = StrategyModule(test_tqm)
    module_strategies.run(test_iterator, test_play_context)
