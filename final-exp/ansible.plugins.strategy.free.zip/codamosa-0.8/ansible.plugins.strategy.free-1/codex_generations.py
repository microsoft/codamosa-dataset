

# Generated at 2022-06-11 16:52:50.025088
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = Ansible.utils.plugins.dll.Dll.tqm()
    iterator = Ansible.utils.plugins.dll.Dll.iterator()
    play_context = Ansible.utils.plugins.dll.Dll.play_context()
    strategy_Module = Ansible.utils.plugins.strategy.StrategyModule.StrategyModule(tqm)
    strategy_Module.run(iterator, play_context)

# Generated at 2022-06-11 16:53:00.825719
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class Play():
        class max_fail_percentage():
            pass
    class Task():
        class action():
            pass
    class Action():
        class BYPASS_HOST_LOOP():
            pass
    class Iterator():
        class _play():
            hosts = []
            def get_hosts(self):
                return self.hosts
            def get_next_task_for_host(self):
                return (None, None)
            class _play():
                max_fail_percentage = None
        def mark_host_failed(self, host):
            pass
        class _play():
            class max_fail_percentage():
                pass
    class Templar():
        class template():
            pass
    class ModuleUtilsText():
        def to_text(*args, **kwargs):
            return '0'


# Generated at 2022-06-11 16:53:07.113137
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    params = {'play_context': 'play_context', 'iterator': 'iterator'}
    host = 'host'
    display.debug("next free host: %s" % host)
    tqm_instance = StrategyModule._tqm
    tqm_instance.RUN_OK = True
    assert StrategyModule._tqm.RUN_OK == StrategyModule.run('iterator', 'play_context')


# Generated at 2022-06-11 16:53:15.754585
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.module_utils.ansible_test_utils import AnsibleTestCase
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.plugins.strategy

    class test_StrategyModule(StrategyModule):

        def get_hosts_left(self, iterator):
            return MockHostsLeft

        def _variable_manager(self):
            return MockVariableManager

        def _copy_included_file(self):
            return MockCopyIncludedFile_ds

        def _load_included_file(self):
            return MockLoadIncludedFile

        def _worker_prc(self):
            return MockWorkerPrc_ds

        def _queue_task(self):
            return MockQueueTask_ds

        def _take_step(self):
            return MockTakeStep_ds

# Generated at 2022-06-11 16:53:27.281155
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="./test/ansible_hosts")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 16:53:30.946829
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule = strategies.__getattr__('StrategyModule')
    # Test to run class StrategyModule run method
    test = StrategyModule(tqm)
    results = test.run(iterator, play_context)
    assert results == False

# Generated at 2022-06-11 16:53:40.238649
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ACTION_META_DEFAULT_HOSTS = dict()
    ACTION_META_NO_HOSTS = dict(no_hosts=True)
    ACTION_META_HOST_LIST = dict(host_list=True)
    ACTION_META_ALL_HOSTS = dict(all_hosts=True)

    import sys
    import random
    import math
    import time
    import threading
    import socket
    import Queue
    import signal
    import errno
    import subprocess

    import __main__ as main

    import ansible
    import ansible.constants as C
    import ansible.errors as errors
    import ansible.inventory as inventory
    import ansible.playbook.play as play
    import ansible.playbook.play_context as play_context
    import ansible.play

# Generated at 2022-06-11 16:53:50.970555
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    display.debug("____________________CASE1: test_StrategyModule_run - START")
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os
    import tempfile
    import json

    play_context = PlayContext()
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.password = 'vagrant'
    play_context.connection = 'ssh'
    play_context

# Generated at 2022-06-11 16:53:59.317150
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader()),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='ssh',
                        module_path=None, forks=100, remote_user='vagrant', private_key_file=None, ssh_common_args=None,
                        ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None, become=False,
                        become_method=None, become_user=None, verbosity=None, check=False, start_at_task=None),
        passwords={},
    )
    strategy = StrategyModule(tqm)

# Generated at 2022-06-11 16:54:08.611516
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import types
    import unittest
    import ansible.module_utils
    import ansible.module_utils._text
    import ansible.module_utils.common.collections
    import ansible.parsing.dataloader
    import ansible.plugins.strategy.free

    template = ansible.parsing.dataloader.DataLoader()

    task = ansible.module_utils.common.collections.Mapping()

    action = ansible.plugins.action.ActionBase()

    display = ansible.module_utils.common.collections.Mapping()

    task_vars = ansible.module_utils.common.collections.Mapping()

    included_file = ansible.plugins.strategy.free.IncludedFile()

    new_ir = ansible.plugins.strategy.free.In

# Generated at 2022-06-11 16:54:30.084286
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:54:33.252462
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host1 = mock.Mock()
    strategy = StrategyModule(None)
    ret = strategy.run(host1,None)
    assert ret == False



# Generated at 2022-06-11 16:54:33.934786
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:54:34.840028
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:54:42.718969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class QueueManager:
        class inventory:
            class hosts:
                def __init__(self):
                    self.a = 'foo'
                    self.b = 'bar'
                    self.c = 'baz'

            @property
            def hosts(self):
                return self.hosts()

        class variable_manager:
            @property
            def extra_vars(self):
                return {'foo': 'bar'}

    queue_manager = QueueManager()
    strategy_module = StrategyModule(queue_manager)

    # Make sure the attributes are initialized.
    assert(strategy_module.BLOCKING_ERR_MSG == "to use the 'free' strategy, you must set serial: 1")
    assert(strategy_module._host_pinned == False)

# Generated at 2022-06-11 16:54:44.451223
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mod = StrategyModule(tqm)
    mod.run(iterator, play_context)

# Generated at 2022-06-11 16:54:52.247506
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = object()
    iterator = object()
    play_context = object()
    strategy_module = StrategyModule(tqm)
    strategy_module.run(iterator, play_context)
    assert strategy_module.ALLOW_BASE_THROTTLING == False
    assert strategy_module._host_pinned == False
    assert strategy_module._workers == []
    assert strategy_module._tasks_per_host == {}
    assert strategy_module._blocked_hosts == {}
    assert strategy_module._flushed_hosts == {}
    assert strategy_module._hosts_cache == []
    assert strategy_module._hosts_cache_all == {}
    assert strategy_module._step == {}
    assert strategy_module._pending_results == []
    assert strategy_module.context == {}
    assert strategy

# Generated at 2022-06-11 16:54:54.679190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.errors import AnsibleError

    try:
        tqm = TaskQueueManager()
        strategy_module = StrategyModule(tqm)
    except AnsibleError:
        raise AssertionError("Unexpected failure")


# Generated at 2022-06-11 16:54:55.611552
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  pass

# Generated at 2022-06-11 16:54:59.273728
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # setup mock objects
    tqm = Mock()
    iterator = Mock()
    iterator.hosts = "hosts"
    play_context = Mock()

    # create a StrategyModule object for testing
    strategyModule = StrategyModule(tqm)



# Generated at 2022-06-11 16:55:54.507169
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-11 16:55:55.056916
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:56:04.617140
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Additional imports for unit testing
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader
    import ansible.plugins.strategy.linear

    # Construct a Dummy Host
    class DummyHost:
        def __init__(self, name, hostvars=None):
            self._name = name
            self._hostvars = hostvars or {}


# Generated at 2022-06-11 16:56:14.066530
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_tqm = MagicMock()
    test_iterator = MagicMock()
    test_play_context = MagicMock()
    test_obj = StrategyModule(test_tqm)

    #test case:
    #test_tqm._terminated = False
    #test_iterator._play.max_fail_percentage is None
    #hosts_left has the size of > 0
    #host has the task to run
    #host_name is not in self._tqm._unreachable_hosts
    #_blocked_hosts[host_name] is False
    #action is not in C._ACTION_META
    #templar.template(task.name) passes without Exception
    #templar.template(task.run_once) is False
    #task._role._metadata is None

# Generated at 2022-06-11 16:56:25.702923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # first, try with a non-existing strategy
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.task_include as task_include
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.reserved import Reserved

    class Host():
        def __init__(self):
            self._play = None

    class Task():
        def __init__(self):
            self._play = None
            self._ds = None
            self._play = None
            self._

# Generated at 2022-06-11 16:56:26.352579
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:56:26.963336
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:56:38.637533
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager

    # Create an instance of a task queue manager.
    # This will create three queues for the executor, one for each category of host
    # (ungrouped, groups with and without the specified pattern)
    inventory = InventoryManager(loader=Loader(), sources='')
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play

# Generated at 2022-06-11 16:56:48.217213
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

# Generated at 2022-06-11 16:56:57.785237
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  from ansible.playbook.task_include import TaskInclude
  from ansible.playbook.task import Task
  from ansible.playbook.block import Block
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible.executor.playbook_executor import PlaybookExecutorOptions
  from ansible.playbook.play import Play
  from ansible.playbook.play_context import PlayContext
  from ansible.plugins.loader import action_loader
  from ansible.plugins.strategy import StrategyBase
  import os

  # Create

# Generated at 2022-06-11 16:59:13.953177
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    from ansible.plugins.host_pinned_to_all import HostPinnedToAll

    # create a mock object for the task queue manager class
    mock_tqm = mock.Mock(TaskQueueManager)
    mock_tqm.is_multiprocessing = False
    mock_tqm.send_callback = mock.Mock()

    # create a mock object for the action loader class
    mock_action_loader = mock.Mock(action_loader)

    # create a mock object for the Display class
    mock_display = mock.Mock(Display)

   

# Generated at 2022-06-11 16:59:20.470266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_source =  dict(
            name = "Ansible Play ",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )
    play = Play().load(play_source, variable_manager=None, loader=None)
    tqm = None

# Generated at 2022-06-11 16:59:30.917339
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    TASK_FLAG_NOOP = 1
    TASK_FLAG_UNREACHABLE = 2
    TASK_FLAG_FAILED = 4

    results = []

# Generated at 2022-06-11 16:59:32.737070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:59:33.962935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:59:35.192946
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-11 16:59:35.754191
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:59:44.029947
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            host = dict(required=True),
            username = dict(required=True),
            password = dict(required=True, no_log=True),
            state = dict(default='present', choices=['absent', 'present']),
        ),
        supports_check_mode = True
    )

    # Send the job to the machine
    response = module.method("POST")

    # handle the response
    if response.status_code not in (200, 201, 202):
        module.fail_json(msg="Request failed", status_code=response.status_code)

    result = {}


# Generated at 2022-06-11 16:59:54.815318
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import mock
    import copy

    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    #################################################################
    #
    #     Define some objects
    #
    #################################################################

    play_context = PlayContext()

    block = Block()
    block._parents = [Task(), ]
    block._role = None
    block._dep_chain = None
    block._name = ""
   

# Generated at 2022-06-11 17:00:02.245959
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Unit test for method run of class StrategyModule
    '''

    # $ python -m testtools.run  tests.unit.plugins.strategy.test_strategy_module.StrategyModuleTestCase.test_StrategyModule_run
    # $ python3 -m testtools.run tests.unit.plugins.strategy.test_strategy_module.StrategyModuleTestCase.test_StrategyModule_run
    pass

