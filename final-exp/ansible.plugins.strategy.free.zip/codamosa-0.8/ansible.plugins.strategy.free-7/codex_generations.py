

# Generated at 2022-06-11 16:52:52.028145
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Declare test data to use
    #test_data = ()
    #test_data = ({},)
    #test_data = ( {}, {}, {},)
    #test_data = ( {}, {},)
    #test_data = ( {},)
    test_data = ()

    # Use one test data to test
    for row in test_data:
        # Set up test data
        #row = {}
        #row = {},
        #row = {}, {}, {},
        #row = {}, {},
        #row = {},
        #row = ()

        # Test code
        print("dummy")

    # Use another test data to test

# Generated at 2022-06-11 16:53:01.806963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyBase:
        def __init__(self):
            self.host_success_count = {}
            self.host_failure_count = {}
            self.host_unreachable_count = {}
            self.task_ok_count = {}
            self.task_failed_count = {}
            self.task_skipped_count = {}
            self.task_unreachable_count = {}
            self.changed_count = {}

        def get_host_success_count(self):
            return self.host_success_count

        def get_host_failure_count(self):
            return self.host_failure_count

        def get_host_unreachable_count(self):
            return self.host_unreachable_count

        def get_task_ok_count(self):
            return

# Generated at 2022-06-11 16:53:08.410828
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    [StrategyModule] Ansible StrategyModule test case of method run
    '''
    print("Start to test strategy module run method.")
    tqm = None
    iterator = None
    play_context = None
    result = None
    module = StrategyModule(tqm)
    result = module.run(iterator, play_context)
    print("Test Result: %s" % result)
    print("End of test strategy module run method.")



# Generated at 2022-06-11 16:53:16.661633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.callback import  CallbackBase
    class Tqm():
        def __init__(self):
            self.loader = DataLoader

# Generated at 2022-06-11 16:53:28.298888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  from ansible.plugins.strategy.free import StrategyModule
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.vars import VariableManager
  from ansible.inventory import Inventory
  from ansible.parsing.dataloader import DataLoader
  import ansible.constants as C
  import ansible.cli.adhoc
  import io

  # Handle CLI options
  options = ansible.cli.adhoc.AdHocCLI.parse()

  # Create dataloder and variable manager
  variable_manager = VariableManager()
  loader = DataLoader()

  # Set global verbosity
  # variables['verbosity'] = C.DEFAULT_VERBOSITY

  # Create inventory and pass to variable manager

# Generated at 2022-06-11 16:53:38.468232
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Testing with a mock strategy which makes many calls to functions of strategy.strategy_base
    tqm = MockTqm()
    tqm.get_workers = MagicMock(return_value = [])
    strategy = StrategyModule(tqm)
    play_context = MockPlayContext()
    strategy._host_pinned = False


# Generated at 2022-06-11 16:53:39.294769
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:53:50.290060
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    lm = MockedLoaderModule()
    pm = MockedPluginManager()
    rc = MockedRunnerClass()

    m_options = MagicMock()
    # m_options.listtags = False
    # m_options.listtasks = False
    # m_options.listhosts = False
    # m_options.syntax = False
    # m_options.connection = 'smart'
    # m_options.module_path = None
    # m_options.forks = 5
    # m_options.remote_user = None
    # m_options.private_key_file = None
    # m_options.ssh_common_args = None
    # m_options.ssh_extra_args = None
    # m_options.sftp_extra_args = None
    # m_options.scp_extra

# Generated at 2022-06-11 16:53:55.435558
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = FakeTQM()
    sut = StrategyModule(tqm=tqm)
    iterator = FakeIterator(tqm=tqm)
    play_context = FakePlayContext()
    sut.run(iterator=iterator, play_context=play_context)
    assert tqm._got_hosts_left is True
    assert sut._host_pinned is True
# fake class for FakeTQM

# Generated at 2022-06-11 16:54:02.744665
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a StrategyModule object
    strategy_module = StrategyModule(tqm)

    assert strategy_module._load_included_file(included_file, iterator=iterator)
    assert strategy_module._copy_included_file(included_file)
    assert strategy_module._hosts_cache
    assert strategy_module._hosts_cache_all
    assert strategy_module._hosts_cache_group_count
    assert strategy_module._hosts_cache_groups
    assert strategy_module._hosts_cache_group_vars
    assert strategy_module._hosts_cache_host_vars
    assert strategy_module.get_hosts_left(iterator)
    assert strategy_module.add_tqm_variables(task_vars, play=iterator._play)
    assert strategy_module.get_variable

# Generated at 2022-06-11 16:54:29.009071
# Unit test for method run of class StrategyModule

# Generated at 2022-06-11 16:54:30.117211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)

# Generated at 2022-06-11 16:54:34.060782
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = Host('test_host')
    host.name = 'test_host'
    # test that the run method of class StrategyModule is called correctly
    strategy_module = StrategyModule(None)
    strategy_module.run(None, None)

# Generated at 2022-06-11 16:54:36.062880
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
# vim: set fileencoding=utf-8 ts=4 sw=4 tw=0 et :

# Generated at 2022-06-11 16:54:37.313233
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule.run(self)

# Generated at 2022-06-11 16:54:48.432838
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    display.verbosity = 3
    import sys
    import __builtin__
    setattr(__builtin__, 'open', lambda x: x)
    setattr(sys, 'argv', ["ansible-playbook", "-i", "ansible/tests/hosts", "-e", "@ansible/tests/host_vars", "ansible/tests/test_strategy_module.yml"])
    from ansible.cli import CLI
    cli = CLI()
    cli.parse()
    options = cli.options
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=options.inventory)

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook = Playbook.load(options.playbook[0], variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-11 16:54:49.082487
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:54:49.777014
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:54:51.862200
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    obj = StrategyModule()
    assert obj.run() is not None


# Generated at 2022-06-11 16:54:59.193705
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module1 = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str'),
            state = dict(default='present', choices=['absent', 'present', 'latest']),
            update_cache = dict(default=False, type='bool'),
            cache_valid_time = dict(default=0, type='int'),
        ),
        supports_check_mode = True,
    )

    module1.exit_json(changed = True, msg = "mock")    


# Generated at 2022-06-11 16:56:05.788494
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module_args = dict(
        gather_facts='no',
        vars=dict(
            foo='1'
        ),
        tasks=[
            dict(
                action=dict(
                    module='debug',
                    args=dict(
                        msg='bar'
                    )
                )
            )
        ]
    )

    host = Host(name='dummy', port=22)
    task = Task.load(module_args, None, None, None, load_vars=False)
    tqm = None
    loader = None
    variable_manager = VariableManager()
    play_context = PlayContext(None, {})

# Generated at 2022-06-11 16:56:14.804096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    playbook = Playbook.load(
        'test/integration/ansible_playbook/test_playbook.yml',
        variable_manager=VariableManager(),
        loader=None,
        options=None
    )
    tqm = PlaybookExecutor(
        playbooks=[playbook],
        inventory=InventoryManager(['localhost']),
        variable_manager=VariableManager(),
        loader=None,
        options=None,
        passwords={}
    )
    sm = StrategyModule(tqm)

    assert sm

# Generated at 2022-06-11 16:56:26.254658
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.includes import IncludeRole
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleError

# Generated at 2022-06-11 16:56:28.929779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()

# Generated at 2022-06-11 16:56:39.763380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.plugins.worker import WorkerProcess
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.iterator import TaskIterator
    import ansible.constants as C
    C.HOST_KEY_CHECKING = False
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )

# Generated at 2022-06-11 16:56:48.670938
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = dict(name='deploy', _terminated=False, send_callback=None)
    def mock_callback(thing, is_conditional=False):
        pass
    tqm['send_callback'] = mock_callback
    iterator = dict(_play=dict(max_fail_percent=None, max_fail_percentage=None, _handlers=[dict(_uuid='ID'), dict(_uuid='ID'), dict(_uuid='ID')], _tasks=[]), _max_fail_percentage=None, _run_state=None)

# Generated at 2022-06-11 16:56:56.578691
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TestableTaskQueueManager('inventory', 'playbook')
    play_context = PlayContext()
    play_context.network_os = 'ios'
    iterator = TaskIterator(play=Play().load(dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='raw', args='ls'))
        ])
    ),
        play_context=play_context,
        variable_manager=VariableManager(),
        loader=None)

    module = StrategyModule(tqm)
    module.run(iterator, play_context)

# Generated at 2022-06-11 16:56:59.209329
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test normal instantiation
    strategy_module = StrategyModule(tqm=None)

    assert strategy_module._host_pinned == False
# end of unit test

# Generated at 2022-06-11 16:57:00.766423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    s = StrategyModule()

    assert(s._host_pinned is False)

# Generated at 2022-06-11 16:57:02.685588
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of class StrategyModule which inherits from object
    strategy_module = StrategyModule()

    assert isinstance(strategy_module, object)

# Generated at 2022-06-11 16:59:10.438301
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  # create a task queue manager object
  tqm_obj = TaskQueueManager()

  # create strategy object
  strategy_obj = StrategyModule(tqm_obj)

  # ensure result is stored correctly
  assert strategy_obj.run(iterator, play_context) == self._wait_on_pending_results(iterator)
  assert super(StrategyModule, self).run(iterator, play_context, result) == self.run(iterator, play_context, result)

# Generated at 2022-06-11 16:59:12.155920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(object)
    assert strategy_module.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:59:13.991638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.ALLOW_BASE_THROTTLING == False
    assert strategy._host_pinned == False

# Generated at 2022-06-11 16:59:20.493297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")

    # create a tqm
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader,
                                 sources=['127.0.0.1,', 'localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 16:59:21.693310
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''Test the StrategyModule.run function'''
    pass



# Generated at 2022-06-11 16:59:22.869870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:59:23.441953
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 16:59:27.745388
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print()
    print("##### Begin unit test for method run of class StrategyModule #####")
    print('not implemented')
    print("##### End unit test for method run of class StrategyModule #####")

# Generated at 2022-06-11 16:59:35.166280
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    loader = '???'
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader, passwords={},stdout_callback='default', run_tree=False)

    strategy = StrategyModule(tqm)
    strategy.run('???',"")


# Generated at 2022-06-11 16:59:40.867101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    class MockTqm(object):
        pass
    tqm = MockTqm()
    sm = StrategyModule(tqm)
    assert tqm == sm._tqm
    assert not sm._host_pinned
    assert sm.ALLOW_BASE_THROTTLING is False
