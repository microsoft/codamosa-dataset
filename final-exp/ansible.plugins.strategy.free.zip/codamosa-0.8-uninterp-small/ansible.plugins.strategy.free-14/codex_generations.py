

# Generated at 2022-06-25 11:58:44.661349
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule('(AaK")x&5\x7fL')
    str_0 = 'UBIZi8CD[7H/*tqB +5T'
    bool_0 = False
    str_1 = 'v2_playbook_on_no_hosts_remaining'
    str_2 = 'v2_playbook_on_task_start'
    str_3 = 'UBIZi8CD[7H/*tqB +5T'
    str_4 = 'UBIZi8CD[7H/*tqB +5T'
    str_5 = 'UBIZi8CD[7H/*tqB +5T'
    str_6 = 'UBIZi8CD[7H/*tqB +5T'

# Generated at 2022-06-25 11:58:46.610104
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:58:51.735812
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'UBIZi8CD[7H/*tqB +5T'
    strategy_module_0 = StrategyModule(str_0)
    try:
        strategy_module_0.run()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:01.959690
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    ansible_playbook_0 = HostCollector()
    ansible_playbook_1 = InventoryManager(host_list='/etc/ansible/hosts')
    ansible_playbook_1.set_variable_manager(VariableManager())
    ansible_playbook_2 = DataLoader()
    ansible_playbook_3 = TaskQueueManager(inventory=ansible_playbook_1, variable_manager=ansible_playbook_1.get_variable_manager(), loader=ansible_playbook_2)
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 11:59:10.325240
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'UBIZi8CD[7H/*tqB +5T'
    iterator_0 = '`]Iphd`Y@3qk&8tNd) '
    play_context_0 = 'W8A~g{.F"0}w!kH$O8('
    strategy_module_0 = StrategyModule(str_0)
    exception_stack = None
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except Exception as e:
        exception_stack = e
    assert not exception_stack

# Test module with given test case

# Generated at 2022-06-25 11:59:12.735100
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    str_0 = 'Ymclr*v&zaHpW8C'
    int_0 = 25765
    str_1 = 'Kcfd@1%T^T&H'
    str_2 = '$(O4ff1x-s;=0G'
    test_case_0(strategy_module_0,str_0,int_0,str_1,str_2)

# Generated at 2022-06-25 11:59:16.473413
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Testing method run for class StrategyModule")
    str_0 = 'UBIZi8CD[7H/*tqB +5T'
    it_0 = None
    pc_0 = None
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run(it_0, pc_0)

# Generated at 2022-06-25 11:59:22.330779
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    # root_dir = os.path.join(current_path, '..', '..', '..')

    test_play_0 = Play()
    test_play_0._ds = {}
    test_play_0.get_variable_manager = test_StrategyModule_run.get_variable_manager_0
    test_task_0 = Task()
    test_task_0._role = None
    test_task_0.action = 'shell'
    test_task_0.name = 'Add new user'
    test_task_0.any_errors_fatal = False
    test_task_0.loop = None
    test_task_

# Generated at 2022-06-25 11:59:24.228347
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
    test_case_1()

# Unit test 1 for method run of class StrategyModule

# Generated at 2022-06-25 11:59:26.567218
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test: adding two tasks to strategy_module
    # Expected Result: task_1 and task_2 are in queue
    # assertEquals(actual, expected)

    test_case_0()

# Generated at 2022-06-25 11:59:54.130439
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass  # No such method


# Generated at 2022-06-25 12:00:02.337472
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
        # arrange
        hosts = [
            {
                'ansible_host': '10.10.10.1',
                'foo': 'bar'
            },
            {
                'ansible_host': '10.10.10.2',
                'foo': 'bar'
            },
            {
                'ansible_host': '10.10.10.3',
                'foo': 'bar'
            },
            {
                'ansible_host': '10.10.10.4',
                'foo': 'bar'
            },
        ]
        play_iterator = None
        play_context = None

        # act
        strategy_module = StrategyModule(play_iterator)
        strategy_module.run(play_iterator, play_context)

        # assert
        assert True


# Generated at 2022-06-25 12:00:04.053988
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None
    sut = StrategyModule(tqm)
    assert sut.run(iterator, play_context)



# Generated at 2022-06-25 12:00:06.113794
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager()
    tm = StrategyModule(tqm)
    tm.run()

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:10.562047
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = ansible_test.utils.TestAnsibleTqm()
    strategyModule = StrategyModule(tqm)


# Generated at 2022-06-25 12:00:16.612634
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:00:24.464617
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    inventory_0 = InventoryManager('/etc/ansible/hosts')
    success_num = 0
    failed_num = 0

# Generated at 2022-06-25 12:00:27.846850
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
    try:
        # init class
        print("[test_StrategyModule_run] start testing run()")
        #test_StrategyModule_run()
        print("\n")
    except Exception as e:
        print("[test_StrategyModule_run] Got exception:"+ str(e))


# Generated at 2022-06-25 12:00:28.470203
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:00:32.818670
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None
    strategy_module = StrategyModule(tqm)
    strategy_module.run(iterator, play_context)
# end of test_StrategyModule_run

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:02.931246
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule('o/Z')
    play_context_0 = None
    iterator_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:01:07.960126
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'UBIZi8CD[7H/*tqB +5T'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = None
    play_context_0 = None
    bool_0 = strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:01:09.603405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    print(strategy_module_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:01:14.251439
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # setup test
    # setup test
    str_0 = 'UBIZi8CD[7H/*tqB +5T'
    strategy_module_0 = StrategyModule(str_0)

    # test runner
    strategy_module_0.run(str_0, str_0)


# Generated at 2022-06-25 12:01:17.666337
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '+ 5T'
    strategy_module_0 = StrategyModule(str_0)
    host_results_0 = ()
    iterator_0 = None
    play_context_0 = None
    # strategy_module_0.run()

# Generated at 2022-06-25 12:01:21.826944
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'UBIZi8CD[7H/*tqB +5T'
    iterator_0 = 'UBIZi8CD[7H/*tqB +5T'
    play_context_0 = 'UBIZi8CD[7H/*tqB +5T'
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:23.377181
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:01:28.266041
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Run test for method run of class StrategyModule
    test_case_0()


if __name__ == '__main__':
    # Run test for method run of class StrategyModule
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:34.878947
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play


# Generated at 2022-06-25 12:01:39.097250
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Generate an instance of class StrategyModule to test method run
    strategy_module_0 = StrategyModule('d{ZaA?I:5$>X8nk|D`o')
    # Generate an instance of class object to test method run
    object_0 = object()
    # Generate an instance of class object to test method run
    object_1 = object()
    # Call method run of StrategyModule with arguments object_0, object_1
    assert strategy_module_0.run(object_0, object_1) == NotImplemented


# Generated at 2022-06-25 12:02:44.887894
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    global display
    global action_loader
    global strategy_module_0

    # start change to test coverage
    strategy_module_0_run_0()

    # end change to test coverage

# test method run of class StrategyModule under default condition

# Generated at 2022-06-25 12:02:47.234099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'UBIZi8CD[7H/*tqB +5T'
    strategy_module = StrategyModule(tqm)
    return True

# Generated at 2022-06-25 12:02:53.963672
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'q3H1jDk|>7vCI?;_QH7n'
    iterator_0 = iter([])
    play_context_0 = dict()
    try:
        strategy_module_0 = StrategyModule(str_0)
        strategy_module_0.run(iterator_0, play_context_0)
    except UnboundLocalError:
        print('unbound local error')
    else:
        print('no exception')

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:02:58.424653
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory

    playbook = Playbook()

    inventory = Inventory(None, '/home/sangah/Downloads/Ansible-2.2.2/test/test_included_vars_file/hosts')


    strategy_module_0 = StrategyModule(playbook)

    strategy_module_0.run(inventory, None)

test_case_0()
test_StrategyModule_run()

# Generated at 2022-06-25 12:03:02.609067
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert 0


# Generated at 2022-06-25 12:03:04.994549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print("Unit test for constructor of class StrategyModule: Success!")
    except:
        print("Unit test for constructor of class StrategyModule: Failed!")


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:10.554135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module_0 = StrategyModule('str_0')
    assert(strategy_module_0._tqm == 'str_0')
    assert(strategy_module_0._tqm.RUN_OK == 0)
    assert(strategy_module_0._workers == 0)



# Generated at 2022-06-25 12:03:13.811378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print('test case 0 failed.')

test_StrategyModule()

# Generated at 2022-06-25 12:03:22.194901
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:03:28.685548
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
    # Setup the test case
    play_context = None
    iterator = None
    strategy_module_0 = StrategyModule(None)
    # Execute the tested method
    result = strategy_module_0.run(iterator, play_context)
    # Verify the result
    assert(result == None)


# Generated at 2022-06-25 12:06:12.441498
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.vars.manager

    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:06:16.308149
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'pz_>Y4|4f0;]aX'
    iterator_0 = {}
    play_context_0 = {}
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:06:24.580103
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule(str_0)
    be_1 = iterator.get_next_task_for_host(last_host, new_blocks = False)
    assert iterator.get_value_for_host(host, _notify_handlers) == _notify_handlers
    assert iterator.get_value_for_host(host, fail_iteration) == fail_iteration
    assert iterator.is_failed(host) == True
    assert strategy_module_1.get_hosts_left(iterator) == hosts_left
    assert iterator.get_next_task_for_host(host) == (state, task)


# Generated at 2022-06-25 12:06:25.882725
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('\n===== test_StrategyModule_run =====')
    assert True == True


# Generated at 2022-06-25 12:06:29.777606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(end='\n')
    print('Executing ' + __file__)
    print('Testing constructor of class StrategyModule')
    print('Type help(test_StrategyModule) for more information')
    print('Type test_StrategyModule() for executing ' + __file__)
    print(end='\n')
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:06:35.036185
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule("l,}L\"[xM`S8%O]K@+p")
    iterator_0 = None
    play_context_0 = None
    test_value_0 = strategy_module_1.run(iterator_0, play_context_0)
    assert test_value_0 == None

# Generated at 2022-06-25 12:06:37.218602
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__=='__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:06:43.088198
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        str_0 = 'UBIZi8CD[7H/*tqB +5T'
        iterator_1 = str_0.iterkeys()
        play_context_1 = str_0.astype(int)
        strategy_module_0 = StrategyModule(str_0)
        result_1 = strategy_module_0.run(iterator_1, play_context_1)
    except Exception as e:
        assert False, 'Unhandled exception in StrategyModule.run : %s' % e


# Generated at 2022-06-25 12:06:43.827082
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-25 12:06:50.264066
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    result_0 = ''
    host_name_0 = 'localhost'
    templar_0 = Templar(host_name_0, result_0)
    play_context_0 = 'Ansibler'
    result_1 = ''
    result_2 = 'permission denied'
    result_3 = ''
    result_4 = 'Ansibler'
    iterator_0 = 'UBIZi8CD[7H/*tqB +5T'
    results_0 = []
    host_results_0 = []
    included_files_0 = []
    new_ir_0 = 'sample'
    new_blocks_0 = [{'when': 'always'}, {'when': 'always'}]
    new_block_0 = new_blocks_0[0]