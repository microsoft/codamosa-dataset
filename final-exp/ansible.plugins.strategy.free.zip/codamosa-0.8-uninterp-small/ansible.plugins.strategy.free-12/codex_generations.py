

# Generated at 2022-06-25 11:58:40.953215
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    iterator_0 = bytes_0
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    play_context_0 = bytes_0
    return_value_0 = strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 11:58:44.009789
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Initalize an instance of class StrategyModule
    strategy_module_0 = StrategyModule(None)

    # Call method run of class StrategyModule
    strategy_module_0.run(None, None)

# Import testcases :
import test_StrategyModule


# Generated at 2022-06-25 11:58:55.430709
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_1 = b'\x01\x1d\x1f\x1c\x08\x0c\x08\x13\x1e'
    iterator_0 = PlayIterator(bytes_1)
    bytes_2 = b'\x1b\x06\x16\x1e\x0c\x04\x08\x1b\x12'
    play_context_0 = PlayContext(bytes_2)
    strategy_module_0.run(iterator_0, play_context_0)
    assert bytes_0 == b'\x9f4\xc2hz\xf2\xc37\xf1'


# Generated at 2022-06-25 11:59:07.240730
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    class_0 = type('', (), {})
    class_0.name = 'any_errors_fatal'
    class_0.display_task = True
    class_0.action = 'GOTO'
    class_0.configuration = 'ad0f5a5c-9b7c-40f0-ac38-aabe6fda0e76'
    class_0.__dict__ = {'action': 'SET_FACT', 'failures_fatal': True}

# Generated at 2022-06-25 11:59:11.580815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as exc:
        assert False, "Exception raised in test_StrategyModule. " + str(exc)


if __name__ == '__main__':
    try:
        test_StrategyModule()
    except Exception as exc:
        print("Exception raised in test_StrategyModule.py. " + str(exc))
        print("Traceback: " + str(exc.__traceback__))

# Generated at 2022-06-25 11:59:19.086650
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xb5\x1d\xab\x8c\x87\xd6m\xbbi\x85\x87\xcf'
    strategy_module_0 = StrategyModule(bytes_0)
    int_0 = 0
    bytes_1 = b'z\xda\xdf\x96\x1c\x91\xd3\x96\x9aF\xa7\x10\xcd\xfc&\x8f\xea\xf0\xdb'
    int_1 = 3

# Generated at 2022-06-25 11:59:25.377580
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 11:59:29.290569
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    ansible_strategy_1 = strategy_module_1.run(iterator_0, play_context_0)
    print(ansible_strategy_1)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:34.140498
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Instantiate a mock AnsibleTQM instance
    ansibleTQM_mock = MockAnsibleTQM()

    # Instantiate a strategyModule with the mock AnsibleTQM instance
    strategyModule = StrategyModule(ansibleTQM_mock)

    # Create a mock AnsibleIterator that will return a host for current execution and then return none for the rest
    # of the execution to simulate that our hosts have finished execution
    ansibleIterator_mock = MockAnsibleIterator(True, False)

    # Create a mock AnsibleIterator that will return a host for current execution and then return none for the rest
    # of the execution to simulate that our hosts have finished execution
    ansibleIterator_mock = MockAnsibleIterator(True, False)

    # Create a mock AnsiblePlayContext

# Generated at 2022-06-25 11:59:36.768271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:00:13.080371
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
        strategy_module_0 = StrategyModule(bytes_0)
        iterator_0 = ActionModule(strategy_module_0)
        play_context_0 = object()
        fake_0 = strategy_module_0.run(iterator_0, play_context_0)

        # This will print out the value of fake_0, which will be None.
        print(fake_0)
    except Exception as e:
        print(e)

test_StrategyModule_run()

# Generated at 2022-06-25 12:00:13.846743
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:00:19.414726
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_1 = b'U\xf1\x8f\xc3\x89\xda\x9c\x1e\xe0'
    iterator_1 = Iterator(bytes_1)
    play_context_0 = PlayContext()
    local_vars_0 = {}
    local_vars_0['result'] = None
    result_1 = strategy_module_0.run(iterator_1, play_context_0)
    assert (result_1 == 0)

test_case_0()

# Generated at 2022-06-25 12:00:23.128756
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    play_context_0 = PlayContext()
    iterator_0 = HostsIterator(play_context_0)
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:00:25.225602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:27.181637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:00:28.403718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:00:35.919730
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)

    strategy_module_0_iterator = iterator
    strategy_module_0_play_context = play_context
    strategy_module_0.run(strategy_module_0_iterator, strategy_module_0_play_context)

#####################################################################################
# Unit tests for class strategy module
#####################################################################################

#test_case_0()

test_StrategyModule_run()

# Generated at 2022-06-25 12:00:41.085839
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(bytes_0)
    # iterator is an AnsibleIterator object, play_context is an AnsiblePlayContext object
    iterator = AnsibleIterator(bytes_0)
    play_context = AnsiblePlayContext(bytes_0)

    with pytest.raises(AnsibleError):
        strategy_module_0.run(iterator, play_context)

# Generated at 2022-06-25 12:00:52.045476
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #
    # Instantiation
    #
    byte_strategy_module_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(byte_strategy_module_0)

    #
    # Get the value of an element in an attribute of an object
    #
    #_loader = strategy_module_0._loader
    _hosts_cache = strategy_module_0._hosts_cache
    
    #
    # Call the method to test
    #
    # iterator = 
    # play_context = 
    # result = strategy_module_0.run(iterator = iterator, play_context = play_context)


# Testing
#
#
# Run the test case

test_case_0()
test_StrategyModule_run

# Generated at 2022-06-25 12:01:35.345497
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule(tqm)
    # Test with expected values
    iterator_1 = None
    play_context_1 = None
    result_1 = strategy_module_1.run(iterator=iterator_1, play_context=play_context_1)
    # Test with expected values
    iterator_2 = None
    play_context_2 = None
    result_2 = strategy_module_1.run(iterator=iterator_2, play_context=play_context_2)


# Generated at 2022-06-25 12:01:38.690182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:01:41.592317
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    print('Start: test_StrategyModule_run')
    print('End: test_StrategyModule_run')
    

# Generated at 2022-06-25 12:01:45.973496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy_module_0 = StrategyModule(tqm)


# Generated at 2022-06-25 12:01:56.752893
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:02:06.438090
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()

    play_context_0 = {
        'remote_addr': '10.10.10.10',
        'password': 'abc',
        'become_pass': 'abc',
        'port': 22,
        'connection': 'ssh',
        'timeout': 10,
        'private_key_file': '',
        'remote_user': 'xxx',
        'verbosity': 0,
        'become_method': 'sudo',
        'become': True,
        'become_user': 'root',
        'check': False
        }

    iterator_0 = {}

    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_

# Generated at 2022-06-25 12:02:15.535324
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    strategy_module_0 = StrategyModule()

    # run unit test
    try:
        strategy_module_0.run(iterator, play_context)
        print('Łącznie punktów w teście test_StrategyModule_run: ' + str(pkt))
    except:
        print('Niestety, ', sys.exc_info()[0], 'wystąpił błąd w test_StrategyModule_run')


# Generated at 2022-06-25 12:02:20.830460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()

# Generated at 2022-06-25 12:02:22.051697
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    assert strategy_module.run() == None


# Generated at 2022-06-25 12:02:23.566031
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()



# Generated at 2022-06-25 12:04:08.838378
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule()

    iterator_2 = iterator()
    play_context_2 = play_context()
    strategy_module_1.run(iterator_2, play_context_2)


# Generated at 2022-06-25 12:04:13.962760
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of the file module from the imported python module
    strategy_module = StrategyModule()

    # Create a mock PlayContext object
    # First, create a mock AnsibleOptions object to use for the PlayContext
    ansible_options_obj = AnsibleOptions()

    # Create the PlayContext mock object using the AnsibleOptions mock as input
    play_context_obj = PlayContext(ansible_options_obj)

    # Create a mock TaskResult object
    task_result_obj = TaskResult()

    # Create a mock Task object
    task_obj = Task()
    task_obj.name = 'do_something'

    # Create a mock Host object
    host_obj = Host()
    host_obj.name = 'localhost'
    host_obj.address = '127.0.0.1'

# Generated at 2022-06-25 12:04:17.446410
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = TaskQueueManager()
    iterator_0 = None
    play_context_0 = PlayContext()
    strategy_module_0 = StrategyModule(tqm_0)
    result_0 = strategy_module_0.run(iterator_0, play_context_0)
    # TODO assert result_0 == ?


# Generated at 2022-06-25 12:04:21.357053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()

# Generated at 2022-06-25 12:04:24.198603
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of class StrategyModule()
    strategy_module_1 = StrategyModule()

    # Check the function call
    assert strategy_module_1.run() == 'Function run of class StrategyModule called', 'The function run of class StrategyModule() is not called correctly'


# Generated at 2022-06-25 12:04:26.559201
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:28.209423
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    iterator = None
    play_context = None
    res = strategy_module.run(iterator, play_context)
    assert True



# Generated at 2022-06-25 12:04:30.389509
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()

    iterator = False
    play_context = False

    strategy_module.run(iterator, play_context)

    if False:
        pass
    elif True:
        pass
    else:
        pass


# Generated at 2022-06-25 12:04:35.402919
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TestQueueManager()
    iterator = TestIterator()
    play_context = TestPlayContext()
    strategy_module_run_0 = StrategyModule(tqm)
    strategy_module_run_0.run(iterator, play_context)


# Generated at 2022-06-25 12:04:36.440076
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:06:47.481314
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'

    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0._set_hosts_cache(bytes_0)
    strategy_module_0._queue_task(bytes_0, bytes_0, bytes_0, bytes_0)
    strategy_module_0._process_pending_results(bytes_0)
    strategy_module_0._wait_on_pending_results(bytes_0)

# Generated at 2022-06-25 12:06:48.218802
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:06:56.931205
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    dict_1 = {}
    dict_2 = {}
    bytes_1 = b'\x83\xe8\x0b\x06)\x95\x1d\xdc\x9f\x0b\x99\xf2\xad\xca\x93\xe5\x89'

# Generated at 2022-06-25 12:07:05.597310
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x03\xa0\x9b\xb3\x0e\x14\x82\xb4\xcd\xaf\xd1\x15\xb7\x0f\x06\x9c\xda\x94\x99\xbe\x1a\x1c\x0d\xad\xe4\xa0\xfa\x10j\xfd\x03\xc6'
    bytes_1 = b'\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00'
    strategy_module_0 = StrategyModule(bytes_0)
    int_0 = 42
    list_0 = ['h']

# Generated at 2022-06-25 12:07:09.327749
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = lambda x: (x > 7)
    play_context_0 = iterator_0
    strategy_module_0.run(iterator_0, play_context_0)

test_case_0()
test_StrategyModule_run()

# Generated at 2022-06-25 12:07:13.369282
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
        iterator = bytes_0
        play_context = bytes_0
        test_case_0()
        test_case_1()
    except Exception:
        if _e_var_0:
            raise _e_var_0
        else:
            raise Exception('exception 1')


# Generated at 2022-06-25 12:07:19.590627
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = ('Uz<\x1f\xd5$\xe0', b'\xd2\xcd\xac\xcd\xd9\x8c@\xdd\xad\x84\xe3P\x8a')
    play_context_0 = Object()

# Generated at 2022-06-25 12:07:20.220114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False


# Generated at 2022-06-25 12:07:29.540841
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x9f4\xc2hz\xf2\xc37\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
    dict_0 = dict()
    dict_0['_play'] = dict()
    dict_0['_play']['max_fail_percentage'] = None
    dict_0['_play']['hosts'] = set()
    dict_0['_play']['hosts'].add('\x92\xc1\xeb"uV\xdc\xbcw\x0f\x84\x8f\x1a\xb7\x10\r\x8a')

# Generated at 2022-06-25 12:07:31.254439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'_\xf1'
    strategy_module_0 = StrategyModule(bytes_0)
