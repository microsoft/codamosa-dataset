

# Generated at 2022-06-25 11:58:43.452224
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create arguments
    tqm = ansible.utils.module_docs.AnsibleModuleDocs("localhost", "ansible", "root", "127.0.0.1")
    iterator = ansible.playbook.play_iterator.PlayIterator("localhost", "ansible", "root", "127.0.0.1")
    play_context = ansible.playbook.play_context.PlayContext("localhost", "ansible", "root", "127.0.0.1")

    # Test controller
    strategy_module_0 = StrategyModule(tqm)
    test_case_0()

    # Execute method
    result = strategy_module_0.run(iterator, play_context)

    # Check result
    if not result:
        raise Exception("'run' method of 'StrategyModule' class returned an error")

# Generated at 2022-06-25 11:58:50.976909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule():')
    str_0 = '\ruE)'
    try:
        strategy_module_0 = StrategyModule(str_0)
    except Exception as e:
        print(e)
    print(strategy_module_0._host_pinned)
if __name__ == '__main__':
    test_case_0()
    # test_StrategyModule()

# Generated at 2022-06-25 11:58:56.321902
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 't1r^\rJ<'
    iterator_0 = str_0
    play_context_0 = ':u'
    strategy_module_0 = StrategyModule(None)
    int_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert int_0 == None

# Generated at 2022-06-25 11:58:57.258319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:00.290050
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    print("Running unit tests for module strategy_module")
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:05.608645
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(None)
    iterator_0 = None
    play_context_0 = None
    display.verbosity = 0
    assert strategy_module_0.run(iterator_0, play_context_0) == None

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:09.375215
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = test_case_0()
    play_context_0 = test_case_0()
    assert_raises(NotImplementedError, strategy_module_0.run(iterator_0, play_context_0))


# Generated at 2022-06-25 11:59:17.183439
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 11:59:24.579623
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_1 = 'v'
    play_context_1 = 't'
    iterator_0 = 'B'
    strategy_module_1 = StrategyModule(str_1)
    strategy_module_1.run(iterator_0, play_context_1)


if __name__ == '__main__':
    print('Running unit tests')
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:34.928920
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    str_1 = 'KV7vQ8'
    strategy_module_1 = StrategyModule(str_1)
    str_2 = 'bJRY,K'
    strategy_module_2 = StrategyModule(str_2)
    str_3 = 'hvcX'
    strategy_module_3 = StrategyModule(str_3)
    str_4 = 'V'
    strategy_module_4 = StrategyModule(str_4)
    str_5 = 'T1'
    strategy_module_5 = StrategyModule(str_5)
    str_6 = '\r-#e'
    strategy_module_6 = StrategyModule(str_6)
    str_7 = 'N|}'
    strategy

# Generated at 2022-06-25 12:00:41.164123
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Creating an instance of class StrategyModule with arguments
    strategy_module_0 = StrategyModule(str_0)

    # Testing method run of class StrategyModule
    strategy_module_0.run(iterator_0, play_context_0)

    # Asserting the equals test for class StrategyModule

# Generated at 2022-06-25 12:00:45.787887
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # First test case
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

if __name__ == '__main__':
    # Unit tests for StrategyModule
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:48.461726
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Not a proper test
    test_case_0()


# Generated at 2022-06-25 12:00:49.350643
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:00:52.324719
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    run_0 = lambda x: None
    run_0 = lambda x,y: None
    run_0 = lambda x,y,z: None
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

test_StrategyModule_run()

# Generated at 2022-06-25 12:00:54.303059
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:00.445362
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Arrange
    iterator_0 = InMemoryInventory()
    play_context_0 = PlayContext()
    playbook_results_0 = PlaybookResults(iterator_0)
    strategy_module_1 = StrategyModule(playbook_results_0)

    # Act
    result = strategy_module_1.run(iterator_0, play_context_0)

    # Assert
    assert result
    assert result is not None
    assert True


# Generated at 2022-06-25 12:01:05.819305
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '\ruE)'
    var_0 = StrategyModule(str_0)
    #var_0.run()

if __name__ == '__main__':
    #test_StrategyModule_run()
    #test_case_0()
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run()

# Generated at 2022-06-25 12:01:09.934810
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(None)
    # self._tqm._terminated = True
    iterator = None
    play_context = None
    strategy_module_0.run(iterator, play_context)



if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:20.115970
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    play_context_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:02:40.955344
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:02:49.998640
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    arg = [{'hosts': ['host_0'], 'name': 'notify', 'tasks': [{'name': 'task_0', 'action': 'task_action_0'}], 'handlers': [{'name': 'handler_0', 'action': 'handler_action_0'}]}]
    strategy_module_0 = StrategyModule('')
    strategy_module_0.run(arg[0], arg[0])
    new_arg = [{'hosts': ['host_1'], 'name': 'notify', 'tasks': [{'name': 'task_1', 'action': 'task_action_1'}], 'handlers': [{'name': 'handler_1', 'action': 'handler_action_1'}]}]

# Generated at 2022-06-25 12:02:52.945119
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    #test_case_0
    print("test 1")
    test_case_0()

test_StrategyModule_run()

# Generated at 2022-06-25 12:02:59.361347
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)

    task_0 = Task()
    block_0 = Block([task_0])
    block_0._role = None
    play_context_0 = PlayContext()
    assert strategy_module_0.run(block_0, play_context_0) is None
    # Verify that we are using the self._host_pinned correctly
    assert strategy_module_0._host_pinned

test_case_0()
test_StrategyModule_run()

# Generated at 2022-06-25 12:03:02.462400
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Case 0
    test_case_0()

# Generated at 2022-06-25 12:03:03.973967
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:03:08.724069
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 12:03:10.089021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:03:15.262200
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
   strategy_module_0 = StrategyModule('QDlFb!(n')
   iterator_0 = TestCase0(strategy_module_0)
   play_context_0 = TestCase0(strategy_module_0)
   results = strategy_module_0.run(iterator_0, play_context_0)
   print(results)


# Generated at 2022-06-25 12:03:20.443632
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    str_1 = '#'
    str_2 = '\r}/'
    strategy_module_0.run(str_1, str_2)


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:05:07.876487
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = '^c%}s'
    play_context_0 = '3q1Ef#6y'
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:05:11.621804
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("****Unit test case for StrategyModule::run")

    # No exception should be thrown
    try:
        test_case_0()
    except Exception as err:
        print("Test case 0 FAILED")

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 12:05:19.274523
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # test case 0
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = (strategy_module_0.true)[:]
    play_context_0 = (play_context_0.test)[:]
    try:
        testCase_0 = strategy_module_0.run(iterator_0, play_context_0)
    except Exception:
        testCase_0 = -1

    assert testCase_0 == 0


# test case 1
playbook = """
- hosts: localhost
  gather_facts: no
  connection: local
  tasks:
    - include_tasks: test.yml
            run_once: true
"""

test_case_1 = True
test_case_2 = True
test_case_3 = True
test

# Generated at 2022-06-25 12:05:20.012861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:05:22.064180
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    for (idx, arg_0) in enumerate(test_case_0()):
        strategy_module_0 = StrategyModule(arg_0)
        strategy_module_0.run()


# Generated at 2022-06-25 12:05:23.279937
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    x = StrategyModule(None)
    x.run(None, None)

# Basic unit testing for StrategyModule

# Generated at 2022-06-25 12:05:29.222169
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:05:30.501573
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print ('test_StrategyModule_run()')

    test_case_0()

# Run unit tests
test_StrategyModule_run()

# Generated at 2022-06-25 12:05:33.637699
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host_0 = Host('host_0')
    iterator_0 = HostIterator(host_0)
    play_context_0 = PlayContext()
    strategy_module_0 = StrategyModule('\ruE)')
    strategy_module_0.run(iterator_0, play_context_0)


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:05:35.936927
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_1 = None
    iterator_1 = None
    play_context_1 = None
    try:
        test_case_0()
        StrategyModule.run(strategy_module_0, iterator_1, play_context_1)
    except Exception as e:
        pass

# Generated at 2022-06-25 12:07:36.249507
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test method with arguments:
    # iterator (playbook iterator instance)
    # play_context (play context instance)
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    play_context_0 = object()
    playbook_iterator_0 = object()
    assert isinstance(strategy_module_0.run(playbook_iterator_0, play_context_0), bool, "module return value is bool type")

# Generated at 2022-06-25 12:07:38.806765
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = ''
    play_context_0 = ''
    strategy_module_0.run(iterator_0, play_context_0)



# Generated at 2022-06-25 12:07:40.013859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('str_0')
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------

# Generated at 2022-06-25 12:07:41.358776
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('Run Test for StrategyModule.run')
    test_case_0()


# Generated at 2022-06-25 12:07:44.896888
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = Bunch()
    iterator_0 = Bunch()
    play_context_0 = Bunch()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    strategy_module_0 = StrategyModule(tqm_0)
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:07:52.032845
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = [302, 'O', (0.0, 1.4444444444444444, 2.888888888888889), (0.0, 1.4444444444444444, 2.888888888888889)]

# Generated at 2022-06-25 12:07:54.460023
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        test_case_0()
        print("Unit test for method run of class StrategyModule: fail")
        return False
    except:
        print("Unit test for method run of class StrategyModule: pass")
        return True

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 12:07:57.110118
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    if not C.DEFAULT_INTERNAL_POLL_INTERVAL:
        C.DEFAULT_INTERNAL_POLL_INTERVAL = None
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:08:00.219582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except TypeError as e:
        print("Exception TypeError while testing class StrategyModule: {}".format(e))
    except Exception as e:
        print("Exception while testing class StrategyModule: {}".format(e))
    finally:
        print("Test case execution completed for class StrategyModule")

test_StrategyModule()

# Generated at 2022-06-25 12:08:09.776169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '\ruE)'
    strategy_module_0 = StrategyModule(str_0)
    assert(strategy_module_0.__dict__ == {'_blocked_hosts': {}, '_C': None, '_flushed_hosts': {}, '_host_pinned': False, '_hosts_cache': {}, '_hosts_cache_all': {}, '_loader': None, '_loop_count': 0, '_play_context': None, '_play_context_path': None, '_play_context_name': None, '_tqm': '\ruE)', '_tqm_variables': {}, '_variable_manager': None, '_workers': []})
    assert(strategy_module_0.__class__ == StrategyModule)