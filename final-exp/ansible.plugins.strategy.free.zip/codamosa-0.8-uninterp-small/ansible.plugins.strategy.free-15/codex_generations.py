

# Generated at 2022-06-25 11:58:42.410391
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    import os
    import yaml
    display = Display()
    connection_loader.getAllClasses()
    strategy_loader.getAllClasses()
    # Initializing task queue manager with all required parameters.
    # Initializing variable manager, which will

# Generated at 2022-06-25 11:58:43.296692
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 11:58:45.093692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)


# Generated at 2022-06-25 11:58:51.981345
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    iterator_0 = None
    play_context_0 = None
    ret_val_0 = strategy_module_1.run(iterator_0, play_context_0)
    assert ret_val_0 == True



# Generated at 2022-06-25 11:59:02.263967
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy.free import StrategyModule
    # Initializing test case
    strategy_module_0 = StrategyModule(None)
    # Defining template for mocked method get()
    def get_template(name, *args, **kwargs):
        if name == 'action':
            return action_loader.ActionModule
        elif name == 'strategy':
            return StrategyBase
        else:
            return ActionBase
    # Setting up mock for method get() of object loader
    loader_0 = mock.MagicMock(name='loader_0', spec=ActionLoader)
    loader_0.get = mock.MagicMock(side_effect=get_template, name='get')

# Generated at 2022-06-25 11:59:05.649584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pb_cas = create_playbook()
    # Create two players to play two games
    strategy_module_0 = StrategyModule(pb_cas)
    strategy_module_1 = StrategyModule(pb_cas)


# Generated at 2022-06-25 11:59:08.815938
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    iterator_0 = None
    play_context_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    return_value_0 = strategy_module_1.run(iterator_0, play_context_0)

# Generated at 2022-06-25 11:59:14.967782
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create test object
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)

    # Create test input
    strategy_module_run_iterator = None
    strategy_module_run_play_context = None
    # Invoke method
    try:
        result = strategy_module_1.run(strategy_module_run_iterator, strategy_module_run_play_context)
    except Exception as e:
        print('Method run in class StrategyModule threw an exception: ' + str(e))

test_StrategyModule_run()

test_case_0()

# Generated at 2022-06-25 11:59:16.728263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)


# Generated at 2022-06-25 11:59:18.312485
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    strategy_module_1.run()

# Generated at 2022-06-25 11:59:46.654095
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialize the class
    strategy_module_0 = StrategyModule(tqm)

    # Set expected values
    tqm._terminated = {}
    tqm._unreachable_hosts = {}
    tqm._failed_hosts = {}
    tqm._stats = {}
    tqm.send_callback('v2_playbook_on_stats')
    tqm.send_callback('v2_playbook_on_no_hosts_remaining')
    iterator._play.hosts = {}
    iterator._play.max_fail_percentage = {}
    iterator._seq = {}
    iterator.get_next_task_for_host(host)
    templar.template(task.throttle)
    task._role._metadata.allow_duplicates = {}
    task.any_

# Generated at 2022-06-25 11:59:47.570694
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass



# Generated at 2022-06-25 11:59:51.896720
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Test variables
    tqm_0 = object()
    play_context_0 = object()
    iterator_0 = object()

    # Unit test for class StrategyModule
    class StrategyModule_0(StrategyModule):
        def run(self, iterator, play_context):
            return True

    # Initialize with default values
    sm_0 = StrategyModule_0(tqm_0)
    # Run test
    assert sm_0.run(iterator_0, play_context_0) == True

# Generated at 2022-06-25 11:59:58.219086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm_0 = TestStrategyModule.tqm_0
    play_context_0 = TestStrategyModule.play_context_0
    iterator_0 = None

    # action: 'async: 10'
    # any_errors_fatal: False
    # become: True
    # become_method: 'sudo'
    # become_user: 'root'
    # become_user_method: 'sudo'
    # connection: 'smart'
    # delegate_to: localhost
    # environment: {}
    # environment_variable: {}
    # first_available_file: {}
    # force_handlers: False
    # handler: {}
    # ignore_errors: False
    # import_playbook: {}
    # include: {}
    # include_role: {}
    # include_tasks: {}


# Generated at 2022-06-25 12:00:05.707157
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 12:00:15.107270
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    display_0 = module_0.Display()
    it_0 = Iterator()
    pc_0 = PlayContext()
    tqm_0 = TaskQueueManager()
    sm_0 = StrategyModule(tqm_0)
    it_0._play = Play()
    it_0._play.max_fail_percentage = None
    sm_0._tqm._terminated = False
    sm_0._set_hosts_cache(it_0._play)
    hosts_left = sm_0.get_hosts_left(it_0)
    workers_free = len(sm_0._workers)
    last_host = 0
    work_to_do = True
    starting_host = last_host
    result = sm_0._tqm.RUN_OK

# Generated at 2022-06-25 12:00:21.030284
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(tqm=None)

    iterator = None
    play_context = None

    # Replace following method:
    # _set_hosts_cache(iterator._play)
    pass

    # Replace following method:
    # get_hosts_left(iterator)
    hosts_left = None
    len_hosts_left = None

    # Replace following method:
    # self._tqm.RUN_OK
    result_0 = True

    # Replace following method:
    # len(self._workers)
    workers_free = True

    # Replace following method:
    # self._tqm.send_callback('v2_playbook_on_no_hosts_remaining')
    pass

    # Replace following method:
    # self._tqm._terminated
    work

# Generated at 2022-06-25 12:00:29.899802
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = ModuleHost()
    host_name = host.get_name()
    host_0 = [host]
    size = len(host_0)
    iterator = ModuleIterator()
    play_context = ModulePlayContext()
    if host_name not in host._tqm._unreachable_hosts:
        for i in range(1):
            iterator.get_next_task_for_host(host, peek=1)
            size -= 1
            if size == 0:
                break
        if host_name not in host._blocked_hosts:
            action = ModuleActionLoader()
            task_vars = host.variables
            workers_free = len(host._workers) - 1
            host._blocked_hosts[host_name] = 1

# Generated at 2022-06-25 12:00:30.861158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:00:41.526562
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Import module to create instance of class
    from ansible.plugins.strategy.free import StrategyModule
    # Create instance of class
    runner_0 = StrategyModule()
    # Dummy function for first argument of function run
    def cb_factory(play, inventory, variable_manager, loader, options, passwords, stdout_callback, run_additional_callbacks, run_tree):
        pass
    # Dummy function for second argument of function run
    def check_host(host, ssh_conn):
        assert host == "host_name_0"
        assert ssh_conn == "ssh_conn_0"
        cmd = "cmd"
        success = True
        changed = False
        return cmd, success, changed
    runner_0.__init__(cb_factory)
    # Check result of function run
    assert runner_

# Generated at 2022-06-25 12:01:09.033583
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_mock = object()
    strategy_module = StrategyModule(strategy_mock)

    iterator_mock = object()
    play_context_mock = object()

    strategy_module.run(iterator_mock, play_context_mock)

# Generated at 2022-06-25 12:01:13.769678
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    strategy_module_0 = StrategyModule(tqm)
    iterator = None
    play_context = None
    strategy_module_0.run(iterator, play_context)
    # TODO: Write some tests

# Generated at 2022-06-25 12:01:16.656108
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    parm_1 = None
    parm_2 = None
    result = StrategyModule.run(parm_1,parm_2)
    return result


# Generated at 2022-06-25 12:01:20.327880
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    strategy_module_iterator = None
    strategy_module_play_context = None
    assert strategy_module_1.run(strategy_module_iterator, strategy_module_play_context) == False


# Generated at 2022-06-25 12:01:23.295532
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:01:29.700494
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(None)
    iterator = None
    play_context = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    strategy_module_1.run(iterator, play_context)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:33.074439
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = None
    iterator_0 = None
    play_context_0 = None
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    try:
        result_0 = strategy_module_1.run(iterator_0, play_context_0)
    except Exception as exception_0:
        print(exception_0)


test_case_0()
test_StrategyModule_run()

# Generated at 2022-06-25 12:01:36.966584
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    strategy_module_1 = strategy_module_0
    iterator = None
    play_context = None
    rc = strategy_module_1.run(iterator, play_context)
    assert isinstance(rc, bool)


# Generated at 2022-06-25 12:01:39.357708
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    
    iterator_0 = None
    play_context_0 = None
    strategy_module_1.run(iterator_0, play_context_0)
    
    


# Generated at 2022-06-25 12:01:48.851353
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import collections
    strategy_module_0 = None
    x = StrategyModule(strategy_module_0)
    iterator = collections.namedtuple('iterator', ['get_next_task_for_host', 'is_failed'])
    play_context = collections.namedtuple('play_context', ['module_defaults'])
    try:
        assert x.run(iterator, play_context) == x._tqm.RUN_OK
    except AssertionError as e:
        print(e)
        raise AssertionError

if __name__ == '__main__':
    test_case_0()
    #test_StrategyModule_run()

# Generated at 2022-06-25 12:02:54.742743
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host_name_0 = ''
    host_name_0 = host_name_0.encode('utf-8')
    host_name_1 = ''
    host_name_1 = host_name_1.encode('utf-8')
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_1.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:03:00.082497
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Need to add additional code here to test block and
    # worker_result are not None.
    # update_active_connections may need testing
    # as well since it appears to be used
    # to update a dictionary referenced by the class
    # variable _active_connections
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    iterator_0 = None
    play_context_0 = None
    str_return_0 = strategy_module_1.run(iterator_0, play_context_0)
    assert str_return_0 == None

# Generated at 2022-06-25 12:03:06.141845
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    iterator_0 = None
    play_context_0 = None
    assert isinstance(strategy_module_1.run(iterator_0, play_context_0), bool)
# Test case description:
# The run method of class StrategyModule returns a value of type bool when given the arguments iterator_0 (of type TaskIterator) and play_context_0 (of type PlayContext).
#   Description of the test case:
#   
#   Property:
#   
#   Precondition:
#   The test case assumes that the following preconditions are satisfied:
#   
#   Postcondition:
#   The test case makes certain that after executing the strategy_module_1.run(iterator_0, play_context_0) the value returned

# Generated at 2022-06-25 12:03:12.721986
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    var_18 = None
    iterator = var_18
    var_19 = None
    play_context = var_19
    strategy_module_1.run(iterator, play_context)


# Generated at 2022-06-25 12:03:15.140239
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_1.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:03:19.938738
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    iterator_2 = None
    play_context_3 = None
    result_7 = strategy_module_1.run(iterator_2, play_context_3)


# Generated at 2022-06-25 12:03:22.305214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for constructor of class StrategyModule")
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:23.088709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:03:26.836289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:03:34.433781
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Testing the run method of StrategyModule class
    # Test case 1
    # Constructor with argument
    strategy_module_0 = None
    iterator_0 = None
    play_context_0 = None
    assert StrategyModule(strategy_module_0) is not None
    # Test case 2
    # Constructor with argument
    strategy_module_1 = None
    assert StrategyModule(strategy_module_1) is not None
    # Test case 3
    # Constructor with argument
    strategy_module_2 = None
    assert StrategyModule(strategy_module_2) is not None
    # Test case 4
    # Constructor with argument
    strategy_module_3 = None
    iterator_1 = None
    play_context_1 = None

# Generated at 2022-06-25 12:06:14.786895
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Pass in a play_context.
    play_context = {}
    strategy_module_0 = StrategyModule(None)
    strategy_module_0.run(iterator, play_context)


if __name__ == "__main__":

    global test_iterator
    test_iterator = None

    try:
        test_case_0()
    except (TypeError, ValueError) as e:
        print(e)
        try:
            for frame in traceback.extract_tb(sys.exc_info()[2]):
                fname, lineno, fn, text = frame
                print("Error in %s on line %d" % (fname, lineno))
                print(str(text))
        except Exception:
            pass

# Generated at 2022-06-25 12:06:17.552978
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    play_context_0 = None
    iterator_0 = None
    try:
        result_0 = strategy_module_1.run(iterator_0, play_context_0)

    except Exception as exc0:
        print(exc0)


# Generated at 2022-06-25 12:06:22.409823
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    strategy_module_iterator_0 = None
    strategy_module_play_context_0 = None
    strategy_module_1.run(strategy_module_iterator_0, strategy_module_play_context_0)


# Generated at 2022-06-25 12:06:29.987632
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars import HostVars
    from ansible.vars.manager import extract_vars
    from ansible.vars.manager import merge_vars_files
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook import play
    from ansible.config.manager import ConfigManager
    from ansible.playbook.task import Task

# Generated at 2022-06-25 12:06:34.665590
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = None
    strategy_module_1 = StrategyModule(strategy_module_0)
    iterator_2 = None
    play_context_3 = None
    strategy_module_1.run(iterator_2, play_context_3)


# Generated at 2022-06-25 12:06:35.416832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:06:37.374004
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_runner_0 = TestRunner()
    result = test_runner_0.run()
    assert result



# Generated at 2022-06-25 12:06:43.418832
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = None
    iterator_1 = None
    play_context_1 = None
    strategy_module_2 = StrategyModule(strategy_module_1)
    strategy_module_2.run(iterator_1, play_context_1)

# Note: Changed return type of run() method in class StrategyModule
# to bool from None, since it is always returning False (in the
# first return statement) in the body of the method
# def test_main():
#     test_case_0()
# test_main()

# Generated at 2022-06-25 12:06:46.749030
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyBase()
    strategy_module_1 = StrategyModule(strategy_module_0)
    iterator = None
    play_context = None
    strategy_module_1_run_ret = strategy_module_1.run(iterator, play_context)
    return strategy_module_1_run_ret


# Generated at 2022-06-25 12:06:52.408174
# Unit test for method run of class StrategyModule