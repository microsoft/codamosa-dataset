

# Generated at 2022-06-25 11:58:35.271701
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Check whether the expected exceptions are raised by run function.
    pass

# Generated at 2022-06-25 11:58:39.088676
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = ()
    play_context_0 = ()
    return_value_0 = strategy_module_0.run(iterator_0, play_context_0)
    return return_value_0


# Generated at 2022-06-25 11:58:41.486266
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('')
    print('Test StrategyModule_run')
    print('==================')
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 11:58:50.909895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test 0:")
    test_case_0()
    print("Test 1:")
    test_case_0()
    print("Test 2:")
    test_case_0()
    print("Test 3:")
    test_case_0()
    print("Test 4:")
    test_case_0()
    print("Test 5:")
    test_case_0()
    print("Test 6:")
    test_case_0()

if __name__ == "__main__":
    print('Testing StrategyModule.py')
    print('\n')
    test_StrategyModule()

# Generated at 2022-06-25 11:58:53.936282
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run(iterator, play_context)

# Prove that we have covered all of the code
if test_StrategyModule_run() == None:
    test_case_0()

# Generated at 2022-06-25 11:58:56.051939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)
    assert type(strategy_module_0) == StrategyModule


# Generated at 2022-06-25 11:59:07.535807
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #str_0 = '['
    #strategy_module_0 = StrategyModule(str_0) 
    #worker_0 = Worker(strategy_module_0)
    pass

if __name__ == '__main__':
    import sys
    import os

    argv = sys.argv
    argc = len(argv)

    if argc < 2:
        print("Usage: python {0} <test-case-#>".format(argv[0]))
        exit(0)

    if(testcases[int(argv[1])]()):
        print("{0}: passed".format(argv[0]))
    else:
        print("{0}: failed".format(argv[0]))

    exit(0)

# Generated at 2022-06-25 11:59:08.995814
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:12.577961
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '{'
    strategy_module_0 = StrategyModule(str_0)
    str_1 = 'c'
    str_2 = 'v&'
    str_3 = '}'
    str_4 = 't(=S'
    strategy_module_0.run(str_1, str_2, str_3, str_4)

# Generated at 2022-06-25 11:59:15.999932
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '|'
    iterator_0 = str_0
    str_1 = 'O'
    play_context_0 = str_1
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 11:59:39.541491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0._host_pinned == False
    # no attributes setup
    # no methods tested
    # no purpose. Cannot instantiate strategy module unless a tqm is provided


# Generated at 2022-06-25 11:59:41.657303
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("-------------------------")
    print("Testing method 'run' of class 'StrategyModule':")
    print("-------------------------")
    print("Unsupported execution of run, as it needs a queue manager")

test_StrategyModule_run()

# Generated at 2022-06-25 11:59:42.572679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '['
    StrategyModule(str_0)


# Generated at 2022-06-25 11:59:43.463732
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

################################################################################
# Module


# Generated at 2022-06-25 11:59:45.902601
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        # test case 0
        test_case_0()
    except Exception as ex:
        print("[FAIL]\ttest_StrategyModule_run: ", ex)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:48.472450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)
    print(strategy_module_0)
    assert True


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:50.808932
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # test case 0:
    try:
        test_case_0()
    except Exception as e:
        assert False


# In[6]:


from ansible.plugins.strategy.linear import ActionQueueProcessor, StrategyModule


# Generated at 2022-06-25 11:59:54.493651
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #print("Testing StrategyModule.run - Case 0")
    test_case_0()


# Generated at 2022-06-25 11:59:55.785724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# test_StrategyModule()

# Generated at 2022-06-25 11:59:56.987810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:00:38.681278
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Test case 0 (valid):")
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:44.676303
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'F[*'
    strategy_module_0 = StrategyModule(str_0)
    try:
        iterator_0 = Iterator(strategy_module_0)
        play_context_0 = PlayContext()
        retval_0 = strategy_module_0.run(iterator_0, play_context_0)
    except Exception as e:
        print(e)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:45.393680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:00:55.001316
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # input parameter play_context
    play_context_0 = PlayContext()
    print(play_context_0)
    # input parameter iterator
    iterator_0 = PlayIterator()
    print(iterator_0)
    # object StrategyModule
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)
    print(strategy_module_0)
    # call method run of class StrategyModule
    print('')
    print('Test begin')
    print('Call method run of class StrategyModule')
    print('')
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    # test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:58.530798
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)
    #strategy_module_0.run()


# Generated at 2022-06-25 12:01:04.020837
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    if (len(sys.argv)) < 2:
        test_case_0()
    else:
        test_case = sys.argv[1]

        if test_case == 'test_case_0':
            test_case_0()


if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:08.354786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    from ansible.tqm import TaskQueueManager

    tqm = TaskQueueManager(None, None, None, None, None, None, None, None, None, None, None, None, None)
    x = StrategyModule(tqm)

# Generated at 2022-06-25 12:01:12.534011
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True
# ----------------------------------------------------------------------

# Generated at 2022-06-25 12:01:16.950319
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = str_0
    play_context_0 = str_0
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:01:19.243342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule('_tqm')
    assert(isinstance(strategy_module_1, StrategyModule))

# Generated at 2022-06-25 12:02:51.666405
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-25 12:02:54.741651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    str_0 = '_'
    try:
        strategy_module_0.run(str_0)
    except:
        pass


# Generated at 2022-06-25 12:02:55.438252
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:02:59.485054
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import ansible.module_utils.basic
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = ansible.module_utils.basic.AnsibleModule(str_0)
    play_context_0 = ansible.module_utils.basic.AnsibleModule(str_0)
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:03:02.982474
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 12:03:13.619290
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-25 12:03:18.100899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('')
    assert strategy_module_0 != None
    # TODO: more test cases
test_StrategyModule()


# Generated at 2022-06-25 12:03:22.403893
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initializing 'tqm' variable to a new object
    tqm = 'tqm'

    # Initializing 'iterator' variable to a new object
    iterator = 'iterator'

    # Initializing 'play_context' variable to a new object
    play_context = 'play_context'

    # Call to StrategyModule of class StrategyModule
    strategy_module = StrategyModule(tqm)
    
    # Call to run of class StrategyModule
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-25 12:03:24.897430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global str_0
    test_case_0()



# Generated at 2022-06-25 12:03:33.742490
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_1 = '['
    strategy_module_1 = StrategyModule(str_1)
    iterator_1 = '[iterator_1]'
    play_context_1 = "[play_context_1]"
    
    exception_thrown = False
    try:
        strategy_module_1.run(iterator_1, play_context_1)
    except Exception as e:
        if isinstance(e,AnsibleError):
            exception_thrown = True
            exception_message_1 = "Failed to convert the throttle value to an integer."
            exception_message_2 = "This task will still be executed for every host in the inventory list."
            exception_message_3 = "Using run_once with the free strategy is not currently supported."

# Generated at 2022-06-25 12:07:53.177339
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of class StrategyModule with the appropriate parameters
    #
    # Returns:
    # an instance of class StrategyModule
    #

    # Run the method run of StrategyModule with the appropriate parameters
    #
    # Returns: -
    #
    # Raises:
    # -
    #
    pass


# Generated at 2022-06-25 12:07:59.534475
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '['
    strategy_module_0 = StrategyModule(str_0)

    templar_0 = Templar(strategy_module_0._loader, 'N1')
    templar_0.available_variables = {}
    templar_0.template('<test_variable>', True)

    templar_1 = Templar(strategy_module_0._loader, 'N1')
    templar_1.available_vars = {}
    templar_1.template('<test_variable>', True)

    templar_2 = Templar(strategy_module_0._loader, 'N1')
    templar_2.available_vars = {}
    templar_2.template('<test_variable>', True)


# Generated at 2022-06-25 12:08:02.709640
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = ansible.plugins.strategy.strategy_module.StrategyModule(tqm)
    iterator = ansible.plugins.strategy.strategy_module.StrategyModule(iterator)
    play_context = ansible.plugins.strategy.strategy_module.StrategyModule(play_context)
    strategy_module_run_0 = tqm.run(iterator, play_context)

# Generated at 2022-06-25 12:08:09.124260
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialize iterator with bogus data
    iterator_0 = [{}, {}, {}, [], [], 'testing']
    # Initialize play_context with bogus data
    play_context_0 = [{}, {}, {}, [], [], 'testing']
    # Initialize StrategyModule instance
    StrategyModule_0 = StrategyModule({})
    # Execute the run method to test it
    StrategyModule_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    # Example of the StrategyModule class usage
    test_case_0()

# Generated at 2022-06-25 12:08:14.019582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Unit tests for the StrategyModule class
# python -m testtools.run strategy_module_spec.py
if __name__ == '__main__':
    import sys
    import testtools

    suite = testtools.TestSuite()
    suite.addTest(testtools.makeSuite(test_StrategyModule, 'test'))
    results = testtools.TextTestRunner(sys.stderr, verbosity=2).run(suite)
    sys.exit(not results.wasSuccessful())