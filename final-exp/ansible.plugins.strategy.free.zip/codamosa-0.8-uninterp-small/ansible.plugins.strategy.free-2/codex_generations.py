

# Generated at 2022-06-25 11:58:40.431295
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3187.4101
    strategy_module_0 = StrategyModule(float_0)
    host_name_0 = 'gBk'
    host_name_1 = 'gBk'
    iterator_0 = StrategyModule._filter_notified_failed_hosts(strategy_module_0, host_name_0, host_name_1)


# Generated at 2022-06-25 11:58:41.918794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:58:43.105960
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 11:58:44.622241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3187.4101
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 11:58:50.365232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3187.4101
    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 11:58:59.010877
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3006.0
    int_0 = -3006
    int_1 = 3856
    int_2 = 3856
    var_0 = "}i@^n9"
    var_1 = "1Gd<Z"
    var_2 = "2Df;V"
    var_3 = "h-cTf"
    var_4 = "|uV8W"
    var_5 = "C2zbd"
    var_6 = "v7Z[p:F"
    var_7 = "v>!_Cx"
    var_8 = "e4v4d"
    var_9 = "Yn&DQ"
    var_10 = "X9`Hc"
    var_11 = "$q:3m"

# Generated at 2022-06-25 11:59:10.532263
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1681.5670
    strategy_module_0 = StrategyModule(float_0)
    int_0 = -0.6341408
    int_1 = -171.1045
    int_2 = 858.9
    int_3 = -0.01652412
    int_4 = 0.99
    int_5 = -619.91
    int_6 = -77.8
    # Note: We are assuming that the _tqm.inventory, _tqm.playbook, and _tqm.stdout_callback values have been set to the following.
    #       _tqm.inventory  = InventoryManager(loader=self._loader, sources="localhost,")
    #       _tqm.playbook   = Playbook.load(play_path, variable_manager=self

# Generated at 2022-06-25 11:59:13.834907
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 3306.8755
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = list()
    play_context_0 = list()
    assert not strategy_module_0.run(iterator_0,play_context_0)

# Test for run method of class StrategyModule

# Generated at 2022-06-25 11:59:15.784986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise Exception('Test failed')

# Test that the constructor does not fail
test_StrategyModule()

# Generated at 2022-06-25 11:59:16.620772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 11:59:45.271180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    if (strategy_module_0.run == False):
        print("Unit test StrategyModule is failed")
    else:
        print("Unit test StrategyModule is passed")


# Generated at 2022-06-25 11:59:48.164001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    arg0 = 'float'
    arg1 = -3187.4101
    # Run the test
    test_case_0(arg0, arg1)

if __name__ == "__main__":
    # Run the unit test
    unittest.main()

# Generated at 2022-06-25 11:59:54.898229
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_1 = -0.80533
    mock_play_context = MagicMock()
    mock_iterator = MagicMock()
    strategy_module_1 = StrategyModule(float_1)
    strategy_module_1.run(mock_iterator, mock_play_context)

if __name__ == '__main__':
    from unittest import mock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:02.947122
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def test_case_run_0(inp_0, inp_1):
        # Iterator object
        iterator = inp_0
        # Context object (holds runtime data)
        play_context = inp_1
        class Iterator:
            def get_next_task_for_host(self):
                pass

        class PlayContext:
            def __init__(self):
                self.forks = 10
                self.remote_user = 'ansible'
                self.remote_addr = '192.168.56.101'
                self.password = 'ansible'
                self.module_path = None
                self.become = True
                self.become_method = 'sudo'
                self.become_user = 'root'
                self.become_pass = None
                self.become_

# Generated at 2022-06-25 12:00:12.583210
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3187.4101
    strategy_module_0 = StrategyModule(float_0)
    host_name_0 = strategy_module_0._tqm.get_option('remote_addr')
    str_0 = "http://%s"
    str_1 = str(str_0) % (str(host_name_0))
    display.debug('s_0 = ' + str(str_1))
    str_2 = str_1 + ':8484/'
    display.debug('s_1 = ' + str(str_2))
    str_3 = 'http://%s:8484/'
    str_4 = str(str_3) % (str(host_name_0))
    display.debug('s_2 = ' + str(str_4))
    str_5

# Generated at 2022-06-25 12:00:14.711684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Should be able to run these tests without an error
    test_case_0()
    print("Testing StrategyModule was completed successfully")


# Global code
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:00:15.677078
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # init test_case for StrategyModule.run
    test_case_0()

# Generated at 2022-06-25 12:00:17.937652
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 11.8
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = None
    play_context_1 = None
    strategy_module_0.run(iterator_0, play_context_1)


# Generated at 2022-06-25 12:00:23.832676
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -409.843
    strategy_module_0 = StrategyModule(float_0)
    float_1 = -1194.7498
    float_2 = -1783.5628
    iterator_0 = float_0.get_next_task_for_host(float_1, float_2)
    float_3 = -1907.9258
    result = strategy_module_0.run(iterator_0, float_3)
    assert isinstance(result, bool)
    assert result == False

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:26.001988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float())
    assert strategy_module_0 != None


# Generated at 2022-06-25 12:01:00.305499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:01:04.184361
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3187.4101
    strategy_module_0 = StrategyModule(float_0)
    play_context_0 = PlayContext()
    arraylist_0 = ArrayList()
    strategy_module_0.run(arraylist_0, play_context_0)


# Generated at 2022-06-25 12:01:07.282686
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 3700.4426
    StrategyModule.__init__(float_0)
    test_case_0()

test_StrategyModule_run()

# Generated at 2022-06-25 12:01:11.411512
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.errors import AnsibleError
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    display_0 = Display()
    handler_0 = Handler()
    iterator_0 = Templar(display_0)
    play_context_0 = VariableManager()
    exception_1 = AnsibleError()
    assert_equals(strategy_module_0.run(iterator_0, handler_0, play_context_0), exception_1)

# Generated at 2022-06-25 12:01:12.193754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:01:14.983754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# vim: syntax=python tabstop=4 expandtab
# vim: shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 12:01:19.853813
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Declare the arguments
    float_0 = -3187.4101
    strategy_module_0 = StrategyModule(float_0)
    iterator = mock()
    play_context = mock()

    # Create the return value
    boolean_0 = True

    # Call the method
    strategy_module_0.run(iterator, play_context)



# Generated at 2022-06-25 12:01:23.508470
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Prameters
    iterator = 0
    play_context = 0
    strategy_module_0 = StrategyModule(iterator)

# Generated at 2022-06-25 12:01:30.830017
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Start unit test
    print("Testing StrategyModule.run")

    # Define variables for testing
    float_0 = -3187.4101
    strategy_module_0 = StrategyModule(float_0)

    # Call test method
    strategy_module_0.run(float_0)

    # End unit test
    print("End of testing StrategyModule.run")

if __name__ == "__main__":
    # Run all test cases
    test_StrategyModule_run()
    test_case_0()

# Generated at 2022-06-25 12:01:33.004584
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3187.4101
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = strategy_module_0.run(iterator_0, play_context)


# Generated at 2022-06-25 12:02:24.499790
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 3700.4426
    float_1 = 8200.0
    float_2 = 4100.0
    float_3 = 800.0
    float_4 = 1500.0
    str_0 = '}n'
    str_1 = 'l.'
    str_2 = 'Css'
    long_0 = 3900
    long_1 = 1700
    int_0 = 9000
    int_1 = 6400
    str_3 = 'z]g'
    str_4 = 'AiG'
    str_5 = '}n'
    long_2 = 2100
    str_6 = 'l.'
    long_3 = 1700
    str_7 = 'Css'
    long_4 = 3200
    long_5 = 4300
    long_6 = 4000
    long_

# Generated at 2022-06-25 12:02:27.669489
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # test StrategyModule.run
    # TODO write a more realistic test for StrategyModule.run
    assert test_case_0() == None

# Generated at 2022-06-25 12:02:28.889043
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('*****Unit test for method run of class StrategyModule*****')
    
    

# Generated at 2022-06-25 12:02:39.375460
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import yaml
    from ansible.plugins.strategy import StrategyModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Load data from YAML file
    dataLoader = DataLoader()
    yaml_file = open("./yaml/strategy_module.yaml", 'r')
    test_data = yaml.load(yaml_file)
    list_0 = test_data.get('list_0')

# Generated at 2022-06-25 12:02:49.358779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = TaskQueueManager(inventory=InventoryManager(host_list=None, sources=None), variable_manager=VariableManager(), loader=DataLoader())
    str = StrategyModule(tqm_0)
    str.run((), PlayContext(become_method=None, become_user=None, check=False, diff=False, extra_vars=None, only_tags=None, run_once=False, skip_tags=None, tags=None))
    str.run((), play_context=PlayContext(become_method=None, become_user=None, check=False, diff=False, extra_vars=None, only_tags=None, run_once=False, skip_tags=None, tags=None))

# Generated at 2022-06-25 12:02:51.849718
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import ansible.plugins.strategy.free as free
    tqm = free.StrategyModule(None)
    tqm.run(None,None)


# Generated at 2022-06-25 12:02:53.989034
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tests = [
        test_case_0
    ]
    for test_case in tests:
        test_case()

# Generated at 2022-06-25 12:02:54.884623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule_instance = StrategyModule()


# Generated at 2022-06-25 12:03:01.589978
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Negative test case for:
    # The "free" strategy is a bit more complex, in that it allows tasks to
    # be sent to hosts as quickly as they can be processed. This means that
    # some hosts may finish very quickly if run tasks result in little or no
    # work being done versus other systems.
    float_0 = float(3700.4426)
    float_1 = float(float_0)
    float_2 = float(float_0)
    float_3 = float(float_0)
    float_4 = float(float_1)
    float_5 = float(float_1)
    float_6 = float(float_1)
    float_7 = float(float_1)
    float_8 = float(float_2)
    float_9 = float(float_2)
    float_10

# Generated at 2022-06-25 12:03:06.340270
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator = None 
    play_context = None 

    strategy_instance = StrategyModule( None )
    strategy_instance.run(iterator, play_context)

if __name__ == "__main__":
    import sys
    import os
    cmd_folder = os.path.realpath(os.path.abspath(os.path.split(inspect.getfile( inspect.currentframe() ))[0]))
    if cmd_folder not in sys.path:
        sys.path.insert(0, cmd_folder)
    from ansible.plugins.strategy import run
    from ansible.playbook.block import Block

    # check class ExistsModule exists
    strategy_instance = StrategyModule( None )

# Generated at 2022-06-25 12:04:10.624044
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = AnsibleQueueManager()
    iterator_0 = HostIterator("test_HostIterator.yml")
    play_context_0 = PlayContext()
    str_0 = StrategyModule.run(tqm_0, iterator_0, play_context_0)

# Generated at 2022-06-25 12:04:21.020675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None

    # create a test object of the class
    t_0 = StrategyModule(tqm)

    # set data attributes
    t_0.ALLOW_BASE_THROTTLING = True
    t_0._flushed_hosts = {'localhost': True}
    t_0._host_pinned = False
    t_0._hosts_cache = {}
    t_0._hosts_cache_all = {}
    t_0._hosts_max_fail_percentage = 70.38
    t_0._hosts_remaining = {}
    t_0._hosts_results = []
    t_0._has_tasks_for_host = {}
    t_0._iterator = 't_0._iterator'

# Generated at 2022-06-25 12:04:23.862479
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    
    tqm = Tqm()
    iterator = HostIterator()
    play_context = PlayContext()
    StrategyModule(tqm).run(iterator, play_context)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:24.647320
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:04:31.091225
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    print("test_StrategyModule_run")
    str0 = "timed out"
    str1 = "unreachable"
    str2 = "<class"
    str3 = "objects.py"
    str4 = "simple"
    str5 = "V2"
    str6 = "stats"
    str7 = "identifier"
    str8 = "tests"
    str9 = "result"
    str10 = "\"%s\""
    str11 = "v2_runner_retry"
    str12 = "v2_runner_on_failed"
    str13 = "v2_on_file_diff"
    str14 = "callback"
    str15 = "v2_on_any"
    str16 = "host"
    str17 = "to_text"

# Generated at 2022-06-25 12:04:35.431789
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:04:36.977821
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 3700.4426


# Generated at 2022-06-25 12:04:41.450366
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 3700.4426
    test_StrategyModule = StrategyModule()
    float_1 = float_0 / float_0 + float_0
    assert float_1 == float_0
    float_1 = float_0 / float_0 + float_0
    assert float_1 == float_0
    float_1 = float_0 / float_0 + float_0
    assert float_1 == float_0

# Generated at 2022-06-25 12:04:44.833267
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	play_context = None
	temp_0 = StrategyModule(None, None)
	temp_1 = temp_0.run(None, None)


# Generated at 2022-06-25 12:04:49.965464
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context = PlayContext()
    play_context.become_method = 'sudo'
    play_context.become_password = 'secret'
    play_context.become_user = 'root'
    play_context.forks = 4
    play_context.remote_addr = '127.0.0.3'
    play_context.remote_port = '22'
    play_context.timeout = 300
    play_context.user = 'root'
    play_context.vault_password = 'secret'
    strategymodule_obj = StrategyModule()
    strategymodule_obj.run()


# Generated at 2022-06-25 12:05:53.705147
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Testing StrategyModule_run")

    tqm = None
    iterator = None
    play_context = None

    module = StrategyModule(tqm)
    module.run(iterator, play_context)

# Unit test function

# Generated at 2022-06-25 12:05:54.764725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:06:03.634637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    action_loader = action_loader.ActionLoader(config=None, play=None)
    tqm = tqm.TaskQueueManager()

    # Case 1
    a = StrategyModule(tqm)
    assert a._host_pinned == False
    assert a.ALLOW_BASE_THROTTLING == False
    assert a._blocked_hosts == {}

    # Case 2
    a.set_remote_user('remote_user')
    a.set_shared_loader_obj(loader.Loader())
    a.set_private_key_file('private_key_file')
    a.set_callbacks(callbacks)
    a.set_inventory(inventory.Inventory())
    a.set_variable_manager(variable_manager.VariableManager())
    a.set_loader(loader.Loader())


# Generated at 2022-06-25 12:06:04.786210
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '+'
    float_0 = -40338.089


# Generated at 2022-06-25 12:06:12.214077
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    file_0 = open("D:\\train\\my_project\\ansible_test\\test_case0_file_content.txt")
    lines = file_0.readlines()
    lines[0] = lines[0].replace("\t", "").replace("\n", "")
    lines[1] = lines[1].replace("\t", "").replace("\n", "")
    lines[2] = lines[2].replace("\t", "").replace("\n", "")
    lines[3] = lines[3].replace("\t", "").replace("\n", "")
    lines[4] = lines[4].replace("\t", "").replace("\n", "")
    lines[5] = lines[5].replace("\t", "").replace("\n", "")
    lines[6]

# Generated at 2022-06-25 12:06:15.816987
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    par1 = None
    par2 = None
    par3 = None
    # Call the function
    ret = StrategyModule.run(par1, par2, par3)
    # Verify the results
    
    


# Generated at 2022-06-25 12:06:16.936064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:06:20.371609
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    iterator = None
    play_context = None

    # Call method
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-25 12:06:22.465105
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule_instance = StrategyModule(None)
    try:
        test_case_0()
    except:
        print('Test case 0 failed')

test_StrategyModule_run()

# Generated at 2022-06-25 12:06:29.832835
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = 0
    iterator = 0
    play_context = 0
    struct_0 = StrategyModule(tqm)
    struct_0.run(iterator, play_context)

if __name__ == '__main__':
    import ctypes
    import sys
    if sys.platform.startswith('linux'):
        try:
            x = 10
            x += 1
        except:
            print("Exception ERROR: ", sys.exc_info()[0])
        else:
            print("No exception")
            try:
                x = 10
                x /= 0
            except:
                print("Exception ERROR: ", sys.exc_info()[0])
            else:
                print("No exception")