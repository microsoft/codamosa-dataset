

# Generated at 2022-06-25 11:58:41.918687
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_1 = b'-\x8a\xa2\x0c\xcb\x06\x8a\xac\x0e\xadF\x18\xc1\x0e\x19_\x9b\x17\xeb'
    iterator_1 = Iterator(bytes_1)
    play_context_1 = PlayContext()
    strategy_module_0.run(iterator_1, play_context_1)

# Test code for StrategyModule class

# Generated at 2022-06-25 11:58:53.137780
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    dictionary_0 = dict()
    dictionary_1 = dict()
    dictionary_0['localhost'] = dictionary_1
    dictionary_1['play_context'] = 'play_context'
    dictionary_1['loader'] = 'loader'
    dictionary_1['variable_manager'] = 'variable_manager'
    dictionary_1['hostvars'] = dict()
    dictionary_1['hostvars']['localhost'] = 'hostvars'
    dictionary_1['hostvars']['localhost']['ansible_host'] = 'ansible_host'

# Generated at 2022-06-25 11:58:57.299613
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host_0 = Host(b'localhost')
    task_0 = Task()
    iterator_0 = TaskIterator(host_0, task_0)
    play_context_0 = PlayContext()
    strategy_module_1 = StrategyModule(iterator_0)
    strategy_module_1.run(iterator_0, play_context_0)


# Generated at 2022-06-25 11:59:08.772403
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)

    iterator_0 = None
    play_context_0 = None
    try:
        assert isinstance(strategy_module_0.run(iterator_0, play_context_0), bool), "'strategy_module_0.run(iterator_0, play_context_0)' should return bool"
        print("Test case passed!")
    except AssertionError:
        print("Test case failed!")

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:09.902049
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-25 11:59:10.743160
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 11:59:17.141634
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialize the class object
    strategy_module_0 = StrategyModule(bytearray(b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'))
    # Initialize the iterator
    iterator_0 = None
    # Initialize the play_context
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    import sys
    # Set the flag to indicate this is a unit test
    C.UNIT_TESTING = True

    # Turn on the unit test flag
    C.no_log = False
    # Run the unit test
    test_case_0()

    # Run the method unit test
    test_Str

# Generated at 2022-06-25 11:59:24.499576
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    assertion_state_0 = strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 11:59:30.220785
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:36.520264
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator_0 = Iterator()
    iterator_0._play = Play()
    iterator_0._play.hosts = ['127.0.0.1']
    strategy_module_0 = StrategyModule(iterator_0)
    strategy_module_0.run(iterator_0, iterator_0._play)


if __name__ == '__main__':
    test_case_0()
    # test_StrategyModule_run()

# Generated at 2022-06-25 12:00:11.442484
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_1 = b'\x9b\xee\x87\xec\xce\x03\xd1\x8d\xbb\xe9\xb9\x01'
    iterator_0 = bytes_1
    bytes_2 = b'\xbc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    play_context_0 = bytes_2
    # Call method run of class StrategyModule with arguments iterator_0 and play_context_0
    test_case_0()
    # No output

# Generated at 2022-06-25 12:00:14.996752
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator = None
    play_context = None
    int_0 = strategy_module_0.run(iterator, play_context)
    assert int_0 == None

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:18.469422
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = 0
    play_context_0 = 0
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:00:25.701566
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:00:29.197296
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator = None
    play_context = None

    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.set_loader(bytes_0)
    strategy_module_0.set_variable_manager(bytes_0)
    strategy_module_0.run(iterator, play_context)

# Generated at 2022-06-25 12:00:36.507163
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        bytes_0 = b'\xa5\x87\x11\x1d.v\x8c\xf9\xac\x12\xfb\xe8\xdc\xc1\x03'
        iterator_0 = StrategyModule(bytes_0)
        strategy_module_0 = StrategyModule(iterator_0)
        int_0 = 0
        play_context_0 = 0
        strategy_module_0.run(int_0, play_context_0)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 12:00:41.847829
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    dict_0 = dict()
    list_0 = list()
    list_1 = list()
    strategy_module_0.run(dict_0, list_0)
    strategy_module_0.run(dict_0, list_1)


# Generated at 2022-06-25 12:00:43.044178
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 12:00:51.507612
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test with dummy values
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    iterator_0 = lambda : None
    play_context_0 = lambda : None
    test_result = StrategyModule.run(bytes_0,iterator_0,play_context_0)
    success = True
    assert success, "Expected True, but got: " + str(success)


# Generated at 2022-06-25 12:00:53.410296
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create test case
    test_case_0()

# Test template for test_StrategyModule_run

# Generated at 2022-06-25 12:01:51.217346
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    iterator_0 = StrategyModule(bytes_0)
    iterator_1 = b'^\xbb\xd0\x15\xac\xdf\n\x82\xc3\x88\xd8\x1d\x1a\x05\xb6\xade\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.run(iterator_0, iterator_1)

if __name__ == '__main__':
    test_case_0()
    test

# Generated at 2022-06-25 12:01:56.440476
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b"\xf4\x9e\xa5A\xdf\x1b\xda\xc4\xa2Q\xdb\xd6\xfc]\x9e\x17\xfd\xbf\xbf\xe8,\x13\x1b\x88\x1f\xeb\xdc\xcc'\xd2\xee\xaaT\xdb\xb7\xfb\xc9"
    run_0 = StrategyModule(bytes_0)
    run_0.run(b'\xe3\xaa\xe1\xb3\x11\xbb\x02\xf8', b'\xc1')


# Generated at 2022-06-25 12:02:03.923711
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    return_value_0 = strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:02:06.535170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:02:14.492722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x80\x87@\x9b#c\xe2\x89\x14\xcf\xeb\x8b\xba'
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()
    print('unit test of StrategyModule class is done')

# Generated at 2022-06-25 12:02:15.231511
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-25 12:02:16.197423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:02:18.518539
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    iterator = bytes_0
    play_context = bytes_0
    ret = StrategyModule(bytes_0).run(iterator, play_context)
    assert ret is None


# Generated at 2022-06-25 12:02:20.943396
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # parameters for the test
    strategy_module_0 = StrategyModule('')
    iterator_0 = ''
    play_context_0 = ''
    
    # test method
    strategy_module_0.run(iterator_0, play_context_0)

    assert False

test_case_0()

# Generated at 2022-06-25 12:02:23.410882
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        test_case_0()
    except Exception as exc:
        print('Exception:')
        print(exc)

# Print function for method run of class StrategyModule

# Generated at 2022-06-25 12:04:39.675343
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xf3\x0b|\xb6\xba\xc3\x88\x9b\x0c~;\x02\xe7'
    iterator_0 = iterator_0 = [{'iterator': 1, 'group': 'all'}, {'iterator': 1, 'group': 'all'}, {'iterator': 1, 'group': 'all'}, {'iterator': 1, 'group': 'all'}, ]
    play_context_0 = play_context_0 = {'iterator': 1, 'group': 'all'}
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.run(iterator_0, play_context_0)

# unit test for method __init__ of class StrategyModule

# Generated at 2022-06-25 12:04:48.891670
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.plugins.strategy import linear
    from ansible.module_utils.six import PY3
    from ansible.plugins.strategy.linear import Iterator
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.plugins.strategy.linear import ResultProcessor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-25 12:04:50.889457
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(None)
    iterator = None
    play_context = None
    assert strategy_module_0.run(iterator, play_context) == None

# Generated at 2022-06-25 12:04:57.233277
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_0 = b'\xcb\xfa\x87\x0b\xb8\x07'
    iterator_0 = bytes_0
    play_context_0 = TestCase0.play_context_0
    strategy_module_0.run(iterator_0, play_context_0)
    strategy_module_0.run(iterator_0, play_context_0)
    strategy_module_0.run(iterator_0, play_context_0)
    strategy_module_0.run(iterator_0, play_context_0)
    strategy_module_0.run

# Generated at 2022-06-25 12:05:00.805697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)


strategy_module_0 = StrategyModule(None)
test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:05:03.691889
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = iterator_0 = {}
    play_context_0 = play_context_0 = {}
    assert isinstance(strategy_module_0.run(iterator_0, play_context_0), bool)


# Generated at 2022-06-25 12:05:07.060153
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # from ansible.plugins.strategy import StrategyModule
    import ansible.plugins.strategy

    StrategyModule_instances = ansible.plugins.strategy.StrategyModule.get_instances()
    if len(StrategyModule_instances) == 1:
        # method run of class StrategyModule
        StrategyModule_instance = StrategyModule_instances[0]
        StrategyModule_run_0(StrategyModule_instance)



# Generated at 2022-06-25 12:05:16.495607
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b',\x8a\x1c\xdb\xd3\x1a\xcb\x80\x92\xc7\xce\xbe\xbe}\xec\xa1\xad\x8e\x83\xfb\xa5\xd0\x8a\xa1\x0f\xe3'
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_1 = b'\xe2\xba\x98\xab\xe8\x9c\xdb\xb4\xe4\xfc\x0f\x99\xa5\xcb\x8b\x9b\x1b\x18\x8e\xc7\x99\x81\x0e\x8c'

# Generated at 2022-06-25 12:05:22.949462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xdc\xad\xd5\xa7><\x03\xe7\x8a\xc9\xbej\xdf'
    strategy_module_0 = StrategyModule(bytes_0)
    assert len(strategy_module_0._blocked_hosts) == 0
    assert len(strategy_module_0._flushed_hosts) == 0
    assert len(strategy_module_0._hosts_cache) == 0
    assert len(strategy_module_0._hosts_cache_all) == 0
    assert len(strategy_module_0._hosts_cache_fail) == 0
    assert len(strategy_module_0._hosts_cache_ok) == 0

# Generated at 2022-06-25 12:05:24.332939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception:
        raise AssertionError('Test failed')

print('Tests Passed')