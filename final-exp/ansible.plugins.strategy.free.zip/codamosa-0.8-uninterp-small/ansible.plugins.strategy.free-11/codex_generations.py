

# Generated at 2022-06-25 11:58:40.878580
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test case data
    test_case_data = [0]
    for i in range(len(test_case_data)):
        test_case_data[i] = test_case_0()

    # Assertion definition
    # Nothing to test

    # Test
    for test_case in test_case_data:
        print("start")
        #test_case.run()
        print("end")



# Generated at 2022-06-25 11:58:44.828001
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -520
    int_1 = -315
    play_context_0 = PlayContext(int_0, int_1)
    int_2 = -1178
    int_3 = 1158
    strategy_module_0 = StrategyModule(int_2)
    strategy_module_0.run(int_3, play_context_0)


# Generated at 2022-06-25 11:58:46.095554
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    target_0 = -935
    test_case_0()

# Generated at 2022-06-25 11:58:50.399715
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 11:58:51.449596
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 11:58:56.463924
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    List_0 = list((-10, -8, -4))
    iterator_0 = List_0
    play_context_0 = list((-10, -8, -4))
    strategy_module_0.run(iterator_0, play_context_0)


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:08.335435
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Variable(s) to be used for testing
    int_0 = -1433
    int_1 = -1505
    int_2 = -977
    int_3 = -1220
    int_4 = -326
    int_5 = -194
    int_6 = -923
    int_7 = -1763
    int_8 = -1626
    int_9 = -1399
    int_10 = -1571
    int_11 = -1961
    int_12 = -1398
    int_13 = -255
    int_14 = -1780
    int_15 = -23
    int_16 = -1137
    int_17 = -1909
    int_18 = -1668
    int_19 = -1719
    int_20 = -44
    int_

# Generated at 2022-06-25 11:59:11.443409
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    iterator_0 = -1433
    play_context_0 = -1433
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 11:59:15.124165
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Test run 0")
    int_0 = 1732
    iterator_0 = create_iterator_0()
    play_context_0 = create_play_context_0()
    strategy_module_0 = StrategyModule(int_0)
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 11:59:24.823271
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create mock object for PlayContext()
    play_context_0 = {}
    # Create mock object for Host()
    host_0 = {}
    # Create mock object for Host()
    host_1 = {}
    # Create mock object for Host()
    host_2 = {}
    # Create mock object for Host()
    host_3 = {}
    # Create mock object for Host()
    host_4 = {}
    # Create mock object for Host()
    host_5 = {}
    # Create mock object for Host()
    host_6 = {}
    # Create mock object for Host()
    host_7 = {}
    # Create mock object for Host()
    host_8 = {}
    # Create mock object for Host()
    host_9 = {}
    # Create mock object for Host()
    host_10 = {}
    # Create mock

# Generated at 2022-06-25 11:59:48.728528
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test without argument
    test_case_0()


# Generated at 2022-06-25 11:59:54.532298
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    host_0 = Host("host_0", "host_0")
    iterator_0 = HostIterator("host_0", "host_0", "host_0")
    play_context_0 = PlayContext("play_context_0", "play_context_0", "play_context_0")
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:00.878458
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    iterator_0 = C.HostInventory(strategy_module_0)
    play_context_0 = C.PlayContext()

    # Call method run of strategy_module_0
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except Exception:
        # Exception was raised, verify that it is a result of the expected action
        pass
    else:
        # No exception was raised, verify that the expected exception would have been raised
        assert False


# Generated at 2022-06-25 12:00:02.300747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:05.232463
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    iterator_0 = -1224
    play_context_0 = -1435
    assert strategy_module_0.run(iterator_0, play_context_0) == False


# Generated at 2022-06-25 12:00:06.211626
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# End of test for method run


# Generated at 2022-06-25 12:00:06.944187
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:00:13.236393
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    strategy_module_0.run(int_0, int_0)


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:17.965386
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Parameters for test case
    iterator_0 = None
    play_context_0 = None

    # Make sure you have unit tests or the code will not work
    test_case_0()
    # Check if the test case is working with these parameters
    try:
        strategy_module_0 = StrategyModule(iterator_0)
        strategy_module_0.run(iterator_0, play_context_0)
    except Exception as exception_0:
        print('An exception is raised.')
        raise exception_0
    else:
        print('The test case worked!')


# Generated at 2022-06-25 12:00:22.995687
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1144
    strategy_module_0 = StrategyModule(int_0)
    int_0 = -3094
    int_1 = -6436
    iterator_0 = Iterator(int_0, int_1)
    play_context_0 = None
    assert strategy_module_0.run(iterator_0, play_context_0) == False


# Generated at 2022-06-25 12:01:09.218984
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True
    # TODO: Create test
    # ds = dict()
    # assert strategy_module_0.run(iterator, play_context) == True


# Generated at 2022-06-25 12:01:17.132634
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Test: run")
    int_0 = -1358
    # From local variable
    strategy_module_0 = StrategyModule(int_0)
    # From local variable
    iterator_0 = _get_iterator()
    # From local variable
    play_context_0 = _get_play_context()
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:01:21.228126
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(int_0)
    int_0 = -1433
    iterator_0 = Iterator(int_0)
    play_context_0 = FakePlayContext()
    result = strategy_module_0.run(iterator_0, play_context_0)
    assert result == int_0
    return result

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:23.351423
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:01:28.850883
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    iterator_0 = 0
    play_context_0 = 0
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:01:32.432920
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    iterator_0 = None
    play_context_0 = None
    result = strategy_module_0.run(iterator_0, play_context_0)
    # Verify if the expected result is obtained
    if result != None:
        print('Test Failed')
    else:
        print('Test Passed')


# Generated at 2022-06-25 12:01:33.519169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:01:40.422630
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# End of test case 0 - StrategyModule.run

# End of testing StrategyModule
# End of testing StrategyBase
# End of testing StrategyPluginFactory

# Generated at 2022-06-25 12:01:49.998385
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = 873
    strategy_module_0 = StrategyModule(int_0)

test_dict = {}
test_dict['test_case_0'] = [test_case_0, True]
test_dict['test_StrategyModule_run'] = [test_StrategyModule_run, True]

if __name__ == '__main__':
    for key in test_dict:
        if test_dict[key][1]:
            test_dict[key][0]()
        else:
            try:
                test_dict[key][0]()
            except:
                print('Error in %s' % key)

# Generated at 2022-06-25 12:01:56.342837
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    StrategyModule_0 = StrategyModule(int_0)
    iterator_0 = iterator_0 = -1433
    play_context_0 = play_context_0 = -1433
    # strategy_module_0.run(iterator_0, play_context_0)


if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:03:57.211351
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_run_0 = StrategyModule(0)
    strategy_module_run_0.run(0, 0)

test_StrategyModule_run()

# Generated at 2022-06-25 12:04:00.923286
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:02.467277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert excinfo.type == TypeError

# Generated at 2022-06-25 12:04:03.863718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(1)
    assert(strategy_module_0._tqm == 1)


# Generated at 2022-06-25 12:04:09.002438
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.module_utils.common.collections import ImmutableDict

    int_0 = -1433
    strategy_module_0 = StrategyModule(int_0)
    # call method run
    strategy_module_0.run(-1433, -1433)


# Generated at 2022-06-25 12:04:09.776864
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #  FIXME: add code here
    pass


# Generated at 2022-06-25 12:04:19.573946
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = test_case_0()
    
description = """
The free strategy is a bit more complex, in that it allows tasks to
be sent to hosts as quickly as they can be processed. This means that
some hosts may finish very quickly if run tasks result in little or no
work being done versus other systems.

The algorithm used here also tries to be more "fair" when iterating
through hosts by remembering the last host in the list to be given a task
and starting the search from there as opposed to the top of the hosts
list again, which would end up favoring hosts near the beginning of the
list."""


# Generated at 2022-06-25 12:04:25.890814
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create test input data
    tqm_0 = -817
    strategy_module_0 = StrategyModule(tqm_0)
    iterator_0 = -933
    play_context_0 = -994
    # Execute the tested method
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:27.748849
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = 23
    iterator = 24
    play_context = 25
    strategy_module_0 = StrategyModule(tqm)
    try:
        result = strategy_module_0.run(iterator, play_context)
    except Exception:
        result = None
    assert result is None


# Generated at 2022-06-25 12:04:32.955739
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = -1433
    play_context_0 = PlayContext()
    iterator_0 = HostIterator(play_context_0)
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    # Exception thrown here
    #