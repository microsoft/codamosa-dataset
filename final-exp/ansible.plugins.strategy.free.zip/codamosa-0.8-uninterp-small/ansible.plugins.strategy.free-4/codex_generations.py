

# Generated at 2022-06-25 11:58:44.661383
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = []
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_28 = {}
    dict_

# Generated at 2022-06-25 11:58:50.633032
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    strategy_module_0 = StrategyModule(None)
    strategy_module_0 = StrategyModule(None)
    strategy_module_0 = StrategyModule(None)
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 11:58:53.408721
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    dict_0 = None
    dict_1 = None
    dict_0 = strategy_module_0.run(dict_0, dict_1)


# Generated at 2022-06-25 11:58:59.289927
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context = None
    iterator = None
    strategy_module_0 = StrategyModule(play_context)
    strategy_module_0.run(play_context, iterator)

if __name__ == "__main__":
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    play_context = None
    iterator = None
    strategy_module_0 = StrategyModule(play_context)
    strategy_module_0.run(play_context, iterator)

# Generated at 2022-06-25 11:59:02.008677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #pass
    test_case_0()



# Generated at 2022-06-25 11:59:04.100257
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("test case 1 - StrategyModule_run")
    tqm = None
    iterator = None
    play_context = None
    strategy_module_0 = StrategyModule(tqm)
    result = strategy_module_0.run(iterator, play_context)
    assert result == None

# Generated at 2022-06-25 11:59:12.152426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_test_case = [
        {
            'inputs' : [None],
            'assertIn' : ['AnsibleError'],
            'printIn' : ['AnsibleError']
        }
    ]

    for test_case in strategy_module_test_case:
        try:
            test_case_0(*test_case['inputs'])
        except Exception as e:
            if test_case['assertIn'] is '':
                print(e)
                # Unexpected Exception
                assert False
            elif test_case['assertIn'] not in str(type(e)):
                print(test_case['assertIn'], 'not in', e)
                # Unexpected Exception
                assert False
            # Expected Exception
            assert True

test_StrategyModule()

# Generated at 2022-06-25 11:59:13.702116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)


# Generated at 2022-06-25 11:59:15.642773
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    for i in range(0, 10):
        strategy_module_0.run(None, None)


# Generated at 2022-06-25 11:59:18.904982
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('Test run() of class StrategyModule')
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    strategy_module_0.run(None,None)


    #print(type(action_0))
    #print(action_0)

if __name__ == '__main__':
    print('Test')
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:42.591592
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_1 = list()
    pytest.raises(TypeError, StrategyModule(dict_1).run, dict_1, dict_1)

    dict_1 = {}
    pytest.raises(TypeError, StrategyModule(dict_1).run, dict_1, dict_1)

    # Test for exception handling of run method
    dict_1 = None
    x = StrategyModule(dict_1)
    pytest.raises(AttributeError, x.run, dict_1, dict_1)

# Generated at 2022-06-25 11:59:43.940918
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(None)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 11:59:45.656454
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator_0 = None
    play_context_0 = None
    strategy_module_0 = StrategyModule(dict)
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 11:59:46.762182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    test_case_0()


# Generated at 2022-06-25 11:59:48.700649
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    dict_1 = None
    dict_2 = None
    try:
        strategy_module_0.run(dict_1, dict_2)
    except:
        pass
    else:
        assert False


# Generated at 2022-06-25 11:59:50.485146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 11:59:51.750044
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 11:59:54.718380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    value_0 = test_case_0()
    return value_0

test_StrategyModule()

# Generated at 2022-06-25 11:59:59.169433
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = None
    iterator_0 = None
    play_context_0 = None
    strategy_module_0 = StrategyModule(dict_0)

    try:
        result = strategy_module_0.run(iterator_0, play_context_0)

        assert (result == None)
    except Exception as e:
        display.error("Error running run", e)
        raise



# Generated at 2022-06-25 12:00:00.676257
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

#
# End of strategy_plugins/__init__.py
#

# Generated at 2022-06-25 12:00:32.572091
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create strategy instance
    strategy_module_0 = StrategyModule(tqm)
    # declare variables
    iterator_1 = iterator
    play_context_1 = play_context
    # run the function tested
    strategy_module_0.run(iterator_1, play_context_1)


# Generated at 2022-06-25 12:00:34.283220
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()



# Generated at 2022-06-25 12:00:44.148608
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    import ansible.executor.task_queue_manager as module_0
    import ansible.plugins.loader as module_1
    import ansible.playbook.play as module_2
    import ansible.plugins.strategy as module_3
    import ansible.utils.vars as module_4
    import ansible.template as module_5
    import ansible.utils.display as module_6

    class Mock_StrategyModule:

        def __init__(self):
            pass

        def run(self):
            pass

        @staticmethod
        def get_hosts_left(iterator):
            return [iterator._play.get_hosts()[0], iterator._play.get_hosts()[1]]

        _tqm = module_0.TaskQueueManager()

# Generated at 2022-06-25 12:00:47.250322
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        display_0 = module_0.Display()
        iterator = "iterator"
        play_context = "play_context"
        strategy_module = ansible.plugins.strategy.StrategyModule(tqm="tqm")
        result = strategy_module.run(iterator, play_context)
        assert result == None
    except Exception as e:
        print(e)

# Generated at 2022-06-25 12:00:48.937338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display_1 = module_0.Display()

    templar_0 = Templar()
    hostname_0 = "localhost"
    worker_0 = WorkerModule(hostname_0, templar_0, display_1)


# Generated at 2022-06-25 12:00:51.841961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_case_0()
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, object), "The object is not as expected."
    assert strategy_module._host_pinned == False, "The object is not as expected."


# Generated at 2022-06-25 12:01:01.571758
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = None
    iterator_0 = None
    play_context_0 = None
    StrategyModule_rv_0 = None
    StrategyModule_rv_1 = None
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    try:
        StrategyModule_rv_0 = StrategyModule(tqm_0)
        StrategyModule_rv_0.run(iterator_0, play_context_0)
    except Exception as StrategyModule_ex_0:
        assert False
    if StrategyModule_rv_0:
        StrategyModule_rv_1 = StrategyModule_rv_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:01:05.138066
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	play_context = None
	iterator = None
	template = StrategyModule(play_context)
	try:
		template.run(iterator, play_context)
	except Exception as e:
		print(e)
		assert False
	else:
		assert True

# Generated at 2022-06-25 12:01:12.905081
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create an instance:
    tqm_0 = [ ]
    action_loader_0 = [ ]
    loader_0 = [ ]
    inventory_0 = [ ]
    variable_manager_0 = [ ]
    loader_1 = [ ]
    shared_loader_obj_0 = [ ]
    from collections import deque
    tqm_1 = deque(maxlen=None)
    tqm_1.append('a')
    tqm_1.append('a')
    tqm_1.append('b')
    tqm_1.append('a')
    tqm_1.append('c')
    tqm_1.append('a')
    tqm_1.append('a')
    tqm_1.append('a')

# Generated at 2022-06-25 12:01:17.058150
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    tqm = None

    # Test with quick exit
    iterator = None
    play_context = None

    ansible.plugins.strategy.StrategyModule.run(tqm, iterator, play_context)


# Generated at 2022-06-25 12:01:48.350766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = test_case_0()
    obj = StrategyModule(tqm_0)
    obj.run(iterator=test_case_0(), play_context=test_case_0())

test_StrategyModule()

# Generated at 2022-06-25 12:01:50.622906
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = object
    iterator_0 = object
    play_context_0 = object
    strategy = StrategyModule(tqm_0)
    strategy.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:01:52.488812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_playbook_iterator = None
    test_play_context = None
    test_strategy_module = StrategyModule(test_playbook_iterator)

# Generated at 2022-06-25 12:01:58.266844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = 1
    strategy_module_0 = StrategyModule(tqm_0)
    assert strategy_module_0.MAX_FAIL_PERCENTAGE == -1
    assert strategy_module_0.MAX_FAIL_PERCENTAGE_DISABLE == -1
    assert strategy_module_0.action_write_locks == {}
    assert strategy_module_0.active_connections == {}
    assert strategy_module_0.blocked_hosts == {}
    assert strategy_module_0.bucket_counters == {}
    assert strategy_module_0.flushed_hosts == {}
    assert strategy_module_0.get_connections == {}
    assert strategy_module_0.inventory == None
    assert strategy_module_0.iterator == None
    assert strategy_module_0.loader == None


# Generated at 2022-06-25 12:01:59.236536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule_0()


# Generated at 2022-06-25 12:02:07.095974
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Assert instance of Display 
    display_1 = Display()
    # Assert instance of Display 
    display_0 = Display()
    # Assert instance of Display 
    display_2 = Display()
    assert isinstance(display_0, Display)
    assert isinstance(display_1, Display)
    assert isinstance(display_2, Display)
    # Assert if attribute _tqm of instance display_0 is a instance of PlaybookExecutor
    assert isinstance(getattr(display_0, "_tqm", "null"), PlaybookExecutor)
    # Assert if attribute _tqm of instance display_1 is a instance of PlaybookExecutor
    assert isinstance(getattr(display_1, "_tqm", "null"), PlaybookExecutor)
    # Assert if attribute _tqm of instance

# Generated at 2022-06-25 12:02:10.845966
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    params = ()
    return_value = None
    return_value = StrategyModule.run(*params)
    assert return_value == None # This should be None because the method does not return a value.

# Generated at 2022-06-25 12:02:16.405484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = object()
    strategy_module_0 = StrategyModule(tqm_0)
    # Test attribute 'C' of class 'StrategyModule'
    assert hasattr(strategy_module_0, 'C')
    # Test attribute '_host_pinned' of class 'StrategyModule'
    assert hasattr(strategy_module_0, '_host_pinned')
    # Test method 'run' of class 'StrategyModule'
    assert hasattr(strategy_module_0, 'run')
    # Test method 'get_hosts_left' of class 'StrategyModule'
    assert hasattr(strategy_module_0, 'get_hosts_left')
    # Test method '_get_serialized_dict' of class 'StrategyModule'

# Generated at 2022-06-25 12:02:23.598454
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context_0 = mock.Mock()
    iterator_0 = mock.Mock()
    iterator_0._play.max_fail_percentage = None
    tqm_0 = mock.Mock()
    workers_free = mock.Mock()
    tqm_0._terminated = mock.MagicMock(return_value = False)
    last_host = mock.Mock()
    tqm_0.RUN_OK = mock.Mock()
    result = mock.Mock()
    hosts_left = mock.Mock()
    tqm_0.send_callback = mock.MagicMock()
    work_to_do = mock.MagicMock(return_value = False)
    play_context_0._display.debug = mock.MagicMock()
    iterator_0.register_

# Generated at 2022-06-25 12:02:31.814108
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	#
	# The "free" strategy is a bit more complex, in that it allows tasks to
	# be sent to hosts as quickly as they can be processed. This means that
	# some hosts may finish very quickly if run tasks result in little or no
	# work being done versus other systems.
	#
	# The algorithm used here also tries to be more "fair" when iterating
	# through hosts by remembering the last host in the list to be given a task
	# and starting the search from there as opposed to the top of the hosts
	# list again, which would end up favoring hosts near the beginning of the
	# list.
	#

	# set last_host to 0
	last_host = 0
	assert last_host == 0

	# set result to self._tqm.RUN_OK

# Generated at 2022-06-25 12:03:04.111070
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = MockTaskQueueManager()
    iterator_0 = Iterator()
    play_context_0 = PlayContext()
    test_object = StrategyModule(tqm_0)
    test_object.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:03:13.652308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = object()
    test_case_0()

    test_obj = StrategyModule(tqm_0)
    try:
        assert isinstance(test_obj, StrategyModule), "Expected an instance of class 'StrategyModule'"
        assert test_obj._host_pinned == False, "Expected an attribute value of False"
    except AssertionError as e:
        print("[FAILED] Expected an attribute value of False, but got " + str(test_obj._host_pinned))

# Generated at 2022-06-25 12:03:18.504400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = object()
    tqm_0._play = object()
    x_0 = StrategyModule(tqm_0)
    print(x_0._host_pinned)

# Generated at 2022-06-25 12:03:21.317460
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("running test case for run")
    assert False


# Generated at 2022-06-25 12:03:23.917783
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
    s_0 = ansible.plugins.strategy.StrategyModule.StrategyModule(tqm=tqm_0)
    s_0.run(iterator=iterator_0, play_context=play_context_0)


# Generated at 2022-06-25 12:03:28.608572
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_obj_0 = StrategyModule(object)

    iterator_0 = object

    play_context_0 = object

    strategy_module_obj_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:03:31.717308
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    runner = ansible.runner.Runner(
        pattern='*', forks=5, module_name='test', module_args='',
    )
    iterator = ansible.runner.Host.create_hosts(list('abcde'), 'all')
    play_context = ansible.playbook.PlayContext()

# Generated at 2022-06-25 12:03:32.516781
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True


# Generated at 2022-06-25 12:03:36.484715
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = StrategyModule.StrategyModule(tqm=None)
    iterator_0 = None
    play_context_0 = PlayContext(play=None, options=None, passwords=None, connection_user=None, connection_password=None, connection_port=None, connection_server=None)
    tqm_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:03:40.754091
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = AnsibleQueueManager()
    iterator = TaskIterator()
    play_context = AnsiblePlayContext()
    
    ansible_strategy_module_0 = StrategyModule(tqm)
    ansible_strategy_module_0.run(iterator, play_context)

# Generated at 2022-06-25 12:04:29.860296
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test for class StrategyModule with the argument tqm
    tqm = None
    strategy_module_0 = StrategyModule(tqm)
    iterator = None
    play_context = None
    strategy_module_0.run(iterator, play_context)

# Generated at 2022-06-25 12:04:37.869557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    assert not hasattr(strategy_module_0, '_host_pinned'), \
        'Expected not hasattr(_host_pinned), but found ' \
        'hasattr(_host_pinned)'
    assert hasattr(strategy_module_0, '_host_pinned'), \
        'Expected hasattr(_host_pinned), but found not ' \
        'hasattr(_host_pinned)'


# Generated at 2022-06-25 12:04:39.361303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:04:40.476206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Collect test cases into test suite

# Generated at 2022-06-25 12:04:49.565764
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # create a mock entities
    test_module_name = 'salt'
    test_module_args = 'ping'

    test_module = dict(
        name = test_module_name,
        args = test_module_args,
    )

    test_play_name = 'play.yml'

    test_play_hosts = ['localhost']

    test_play_roles = []

    test_play_vars = dict()

    test_play = dict(
        name = test_play_name,
        hosts = test_play_hosts,
        roles = test_play_roles,
        vars = test_play_vars,
    )

    test_playbook_name = 'playbook.yml'

    test_playbook_hosts = 'localhost'

    test_playbook = dict

# Generated at 2022-06-25 12:04:52.639733
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    iterator_0 = None
    play_context_0 = None
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except Exception:
        return False
    return True

# Testcase for StrategyModule

# Generated at 2022-06-25 12:04:55.421284
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    iterator_0 = None
    play_context_0 = None
    result_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert result_0 == False


# Generated at 2022-06-25 12:04:59.623418
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = {}
    dict_1 = {}
    strategy_module_0 = StrategyModule(dict_0)
    iterator_0 = [dict_1]
    play_context_0 = [dict_1]
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except AnsibleError as err:
        assert(err.message == "The strategy module requires an inventory to work with")

# Generated at 2022-06-25 12:05:02.177334
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initializing variables
    tqm = None
    iterator = None
    play_context = None
    # Invoking method
    result = strategy_module_0.run(iterator, play_context)
    # Verifying expected result
    assert result is None

# Generated at 2022-06-25 12:05:07.958063
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['ID'] = 'E'
    dict_2 = dict()
    dict_3 = dict()
    dict_3['B'] = dict_2
    dict_3['B']['C'] = dict_1
    dict_3['B']['C']['D'] = 'F'
    dict_3['B']['G'] = 'H'
    dict_0['A'] = dict_3
    strategy_module_0 = StrategyModule(dict_0)
    dict_0 = {'l': 3, 'v': [3, 4]}
    dict_1 = {'i': 4}
    dict_2 = {'k': 5}
    dict_3 = dict()
    dict_0['m'] = dict_3


# Generated at 2022-06-25 12:06:44.706852
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = {'_tasks_seen': 0}
    strategy_module_0 = StrategyModule(dict_0)
    dict_0 = {'_play': {'_id': 'x'}}
    iterator_0 = dict_0
    dict_0 = {'_play': {'_id': 'x'}}
    play_context_0 = dict_0
    strategy_module_0.run(iterator_0, play_context_0)

# Testing the class constructor

# Generated at 2022-06-25 12:06:46.060858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:06:51.900489
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)
    iterator_0 = None
    play_context_0 = None
    assert strategy_module_0.run(iterator_0, play_context_0) == None

if __name__ == "__main__":
    test_case_0()

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~
# ~~~ Purpose: Run all known tests
# ~~~
# ~~~ Warning: The tests are not complete.
# ~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Run unit test if executed as main script
if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:06:56.497072
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = {}
    list_0 = []
    set_0 = set(list_0)
    set_1 = set(list_0)
    set_1.add(set_0)
    tuple_0 = (set_1, )
    strategy_module_0 = StrategyModule(dict_0)
    iterator_0 = strategy_module_0.run(tuple_0, list_0)

# Generated at 2022-06-25 12:06:57.763186
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:07:02.050723
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialization of test variables
    tqm_0 = ''

    # Test execution
    strategy_module_0 = StrategyModule(tqm_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 12:07:05.819152
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    dict_0 = None
    strategy_module_0 = StrategyModule(dict_0)

    dict_1 = None
    dict_2 = None
    strategy_module_0.run(dict_1, dict_2)

# Test for method run of class StrategyModule

# Generated at 2022-06-25 12:07:08.094234
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None
    strategy_module_0 = StrategyModule(tqm)
    result = strategy_module_0.run(iterator, play_context)
    return result



# Generated at 2022-06-25 12:07:09.854111
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None
    assert strategy_module_0.run(iterator, play_context)


# Generated at 2022-06-25 12:07:11.500463
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = None
    iterator_0 = None
    play_context_0 = None
    strategy_module_0 = StrategyModule(tqm_0)
    strategy_module_0.run(iterator_0, play_context_0)