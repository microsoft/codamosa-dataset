

# Generated at 2022-06-25 11:58:40.165954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        float_0 = 46.8
        strategy_module_0 = StrategyModule(float_0)
        #assert False # TODO: implement your test here
    except Exception as ex:
        #print ex.message
        assert False

# Generated at 2022-06-25 11:58:43.195061
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    float_1 = ARG
    float_2 = ARG
    strategy_module_0.run(float_1, float_2)

test_case_0()

# Generated at 2022-06-25 11:58:54.391008
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    # test_case_0
    float_0 = -1144.0
    # test_case_0
    try:
        test_case_0()
        test_case_0()
    except Exception:
        pass
    test_case_0()
    test_case_0()
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_0
    # test_case_

# Generated at 2022-06-25 11:59:05.355771
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("")
    print("test_StrategyModule_run")
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    float_1 = -1144.0
    strategy_module_1 = StrategyModule(float_1)
    float_2 = -1144.0
    strategy_module_2 = StrategyModule(float_2)
    float_3 = -1144.0
    strategy_module_3 = StrategyModule(float_3)
    float_4 = -1144.0
    strategy_module_4 = StrategyModule(float_4)
    float_5 = -1144.0
    strategy_module_5 = StrategyModule(float_5)
    float_6 = -1144.0
    strategy_module_6 = StrategyModule(float_6)


# Generated at 2022-06-25 11:59:10.287289
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1271.0
    strategy_module_0 = StrategyModule(float_0)
    iterator_str = 'WSONV8bvWhm'
    iterator_0 = iterator_str
    play_context_dict = dict()
    play_context_0 = play_context_dict
    return_value_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert return_value_0 is None


# Generated at 2022-06-25 11:59:18.019285
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -67974.2572
    strategy_module_0 = StrategyModule(float_0)

    # Parameterize the play context with a specific limit/host
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'admin'
    play_context.remote_addr = None

    # Create a play for our strategy to run

# Generated at 2022-06-25 11:59:23.391791
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = 4
    float_0 = 348.8
    int_1 = 5
    float_1 = 0.8
    int_2 = 5
    float_2 = 0.4
    float_3 = -1220.0
    strategy_module_0 = StrategyModule(float_0)
    int_3 = 1
    int_4 = 1
    int_5 = 1
    int_6 = 0
    int_7 = 1
    int_8 = 1
    int_9 = 1
    int_10 = 1
    int_11 = 1
    int_12 = 1
    int_13 = 1
    int_14 = 1
    int_15 = 0
    int_16 = 1
    float_4 = -553.0
    float_5 = -1.0
    float_6 = 0.

# Generated at 2022-06-25 11:59:33.133458
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 8.02
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = None
    play_context_0 = None
    float_1 = float_0 # float_1 = float_0
    # float_1 = float_0
    # float_1 = float_0
    # float_1 = float_0
    # float_1 = float_0
    # float_1 = float_0
    # float_1 = float_0
    # float_1 = float_0
    # float_1 = float_0
    ret = strategy_module_0.run(iterator_0, play_context_0)
    print(ret)


if __name__ == "__main__":
    test_case_0()
    # test_StrategyModule_run()

# Generated at 2022-06-25 11:59:34.924921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    

# Generated at 2022-06-25 11:59:41.305828
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    dict_0 = dict()
    dict_0['_uuid'] = '0a0e7a53215e40be91840b6506b9f6e3'
    dict_0['_hosts'] = ['host1']
    dict_0['_ds'] = dict_0
    dict_0['_name'] = 'include_role'
    dict_0['name'] = 'include_role'
    dict_0['_parent'] = dict()
    dict_0['_role'] = dict()
    dict_0['_role']['_role_path'] = '/var/lib/awx/projects/_2__josh_awx_2_0__/roles/role1'
   

# Generated at 2022-06-25 12:00:14.598599
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True

# Generated at 2022-06-25 12:00:19.326862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)


test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:00:22.303753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    try:
        test_case_0()
    except TypeError as e:
        print("TypeError:", e)
    except Exception as e:
        print("Exception:", e)


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:00:28.005421
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Test with a mock object
    class strategy_module_0():
        def __init__(self):
            self.iterator = 0
            self.play_context = 0

    strategy_module_obj = strategy_module_0()
    strategy_module_obj.run()
    # TODO: The strategy_module_0.run() method doesn't return anything.  Ensure there is a test for the response or that the method does return something



# Generated at 2022-06-25 12:00:32.086475
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    iterator = None
    play_context = None
    strategy_module_0.run(iterator, play_context)
    pass

# Generated at 2022-06-25 12:00:38.804985
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 718.76
    test_case_strategy_module_0 = StrategyModule(float_0)
    float_1 = -320.69
    float_2 = -9.0
    float_3 = -424.82
    test_case_strategy_module_0.run(float_1, float_2, float_3)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:42.706772
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(None)
    bool_0 = False
    iterator_0 = iterator_0(None)
    assert bool_0 == strategy_module_0.run(iterator_0, None)


# Generated at 2022-06-25 12:00:45.981373
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = object()
    iterator = object()
    play_context = object()
    strategy_module_0 = StrategyModule(tqm)
    strategy_module_0.run(iterator, play_context)
    return

if (__name__ == '__main__'):
    for i in range(50):
        test_StrategyModule_run()

# Generated at 2022-06-25 12:00:49.918632
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -867.0
    strategy_module_0 = StrategyModule(float_1)
    strategy_module_0.run(iterator_0, play_context_1)

test_StrategyModule_run()

# Generated at 2022-06-25 12:00:52.844330
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = float(float(14))
    float_1 = float(float(11))
    float_2 = float(float(14))
    strategy_module_0 = StrategyModule(float_1)
    # Call method run of StrategyModule
    strategy_module_0.run(float_0, float_2)
    return


# Generated at 2022-06-25 12:01:34.693348
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test with float as first parameter
    float_0 = 100.0
    strategy_module_0 = StrategyModule(float_0)
    float_1 = 100.0
    iterator_0 = PlayIterator(float_1)
    float_2 = 100.0
    play_context_0 = PlayContext(float_2)
    result = strategy_module_0.run(iterator_0, play_context_0)
    assert result == False


# Generated at 2022-06-25 12:01:40.531593
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    float_0 = 789.0
    strategy_module_0 = StrategyModule(float_0)
    strategy_module_0.run(IncludedFile, IncludedFile)

# Generated at 2022-06-25 12:01:51.532105
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = StrategyModule(float_0)
    float_1 = -1144.0
    bool_0 = bool()
    bool_1 = bool(0)
    str_0 = str()
    int_0 = int()
    str_1 = str()
    int_1 = int()
    int_2 = int()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_

# Generated at 2022-06-25 12:01:52.071459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-25 12:01:52.990982
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class_0 = StrategyModule
    float_2 = -788.6
    class_0.run(float_2)

# Generated at 2022-06-25 12:01:58.998682
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Run the run method of StrategyModule with the following inputs
    iterator = play_context = None
    try:
        AnsibleModule(iterator, play_context)
    except:
        raise

if __name__ == "__main__":
    # for code coverage
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:59.755125
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:02:08.707142
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 6.0
    float_1 = -3.0
    float_2 = -4.0
    float_3 = -5.0
    float_4 = 6.0
    float_5 = 6.0
    float_6 = -5.0
    float_7 = 6.0
    float_8 = 6.0
    float_9 = -15.0
    float_10 = 6.0
    float_11 = 6.0
    float_12 = -15.0
    float_13 = -15.0
    float_14 = -3.0
    float_15 = 6.0
    float_16 = 6.0
    float_17 = 6.0
    float_18 = -15.0
    float_19 = 6.0
    float_20 = -15.0


# Generated at 2022-06-25 12:02:10.668940
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 2905.0
    strategy_module_0 = StrategyModule(float_0)
    float_1 = -435.0
    strategy_module_0.run(float_1, float_1)


# Generated at 2022-06-25 12:02:12.378752
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    list_0 = []
    list_1 = []
    strategy_module_0 = StrategyModule(list_0)
    strategy_module_0.run(list_1, 0)
    #assert_true(False)


# Generated at 2022-06-25 12:03:53.850364
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -194.0
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = [1, 2]
    play_context_0 = 3
    
    # Invoke method
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:03:56.562497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-25 12:04:02.525337
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    bool_0 = True
    int_0 = 0
    try:
        strategy_module_0.run(bool_0, int_0)
    except:
        print("Exception catched")

test_StrategyModule_run()

# Generated at 2022-06-25 12:04:05.233668
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = float_0
    play_context_0 = float_0
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:04:08.890254
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup test variables
    iterator = None
    play_context = None
    strategy_module_0 = StrategyModule(iterator)
    result = strategy_module_0.run(iterator, play_context)
    assert result == "result"

# Generated at 2022-06-25 12:04:09.776155
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 992.5
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:04:16.349561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -1144.0
    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:04:26.863486
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Test 1
    print("Test 1")
    float_0 = -1144.0
    StrategyModule_0 = StrategyModule(float_0)
    try:
        StrategyModule_0
    except Exception as exception_0:
        print("Exception: ", exception_0)

    # Test 2
    print("Test 2")
    float_0 = -1144.0
    StrategyModule_0 = StrategyModule(float_0)
    try:
        StrategyModule_0
    except Exception as exception_0:
        print("Exception: ", exception_0)

    # Test 3
    print("Test 3")
    float_0 = -1144.0
    StrategyModule_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:04:28.703289
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  hosts_left = (None,)
  play_context = dict()
  iterator = None
  strategy_module_0 = StrategyModule(hosts_left)
  result = strategy_module_0.run(iterator, play_context)



# Generated at 2022-06-25 12:04:33.430241
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -8.0
    StrategyModule_0 = StrategyModule(float_0)

    float_0 = 0.75
    int_0 = 5
    float_1 = float_0 * int_0
    list_0 = [float_0] + [float_1]
    float_2 = float_0 * float_1
    list_1 = [float_0, float_1] + [float_2]
    float_3 = float_0 * float_2 * float_1 * float_1
    list_2 = [float_0, float_1, float_2] + [float_3]
    float_4 = float_0 * float_3 * float_1 * float_0
    list_3 = [float_0, float_1, float_2, float_3] + [float_4]