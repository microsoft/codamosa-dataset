

# Generated at 2022-06-25 11:58:40.804002
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '6tLDX'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = iterator()
    play_context_0 = play_context()
    # Test method of class StrategyModule with arguments iterator_0 and play_context_0.
    # Test raises error of operation not supported?
    # Type error
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except TypeError:
        # Type error
        raise TypeError


# Generated at 2022-06-25 11:58:52.019501
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory
    import os
    import sys
    import tempfile
    tempdir = tempfile.gettempdir()
    fd, path = tempfile.mkstemp(suffix='.yml', prefix='ansible_test_StrategyModule_run_', dir=tempdir)
    os.close(fd)


# Generated at 2022-06-25 11:58:55.036654
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_1 = 'xKyg7'
    iterator_1 = str_1
    play_context_1 = str_1
    strategy_module_1  = StrategyModule(str_1)
    assert strategy_module_1.run(iterator_1, play_context_1) == None

# Generated at 2022-06-25 11:58:56.696688
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 11:59:08.593065
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context_0 = PlayContext(play=play_0, options=self._options, passwords=passwords_0, connection_user=connection_user_0, network_os=network_os_0, remote_addr=remote_addr_0, become_method=become_method_0, become_user=become_user_0, become_pass=become_pass_0, internal_connection=internal_connection_0, transport=transport_0, local_tmp=local_tmp_0, check=check_0, diff=diff_0, diff_peek=diff_peek_0, start_at_task=start_at_task_0)
    strategy_module_0 = StrategyModule(tqm)
    strategy_module_0.run(iterator, play_context_0)


# Generated at 2022-06-25 11:59:10.833771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6tLDX'
    strategy_module_0 = StrategyModule(str_0)
    # print 'Created strategy_module_0'


# Generated at 2022-06-25 11:59:11.917517
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 11:59:13.191948
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test case0
    test_case_0()

test_StrategyModule_run()

# Generated at 2022-06-25 11:59:16.256287
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '6tLDX'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = str_0
    play_context_0 = str_0
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 11:59:17.623586
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        # Two arguments
        test_case_0()
    except Exception as e:
        pass

# Generated at 2022-06-25 11:59:39.848977
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    program_module_0 = test_case_0()

# Generated at 2022-06-25 11:59:40.709819
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Call the function
    test_case_0()

# Unit tests for StrategyModule Class

# Generated at 2022-06-25 11:59:42.734771
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 11:59:43.416383
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 11:59:46.654653
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator_0 = Iterator()
    play_context_0 = PlayContext()
    test_case_0()
    test_StrategyModule_run()
    strategy_module_0 = StrategyModule(iterator_0)
    result_0 = strategy_module_0.run(iterator_0, play_context_0)

# Test Plan
# test_StrategyModule_run: test plan

# Generated at 2022-06-25 11:59:48.914912
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('Running test_StrategyModule_run...')
    test_case_0()
    print('Done!')

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:50.454552
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_2 = '6tLDX'
    strategy_module_1 = StrategyModule(str_2)


# Generated at 2022-06-25 11:59:53.147185
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("run")

    _t_0 = moduleTestTemplate()
    strategy_module_0 = StrategyModule(_t_0)

    strategy_module_0.run(None, None)



# Generated at 2022-06-25 12:00:01.524833
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    global play_context_0
    global iterator_0
    global strategy_module_0

    strategy_module_0 = StrategyModule(None)
    strategy_module_0._tqm = None
    strategy_module_0._inventory = None
    play_context_0 = PlayContext()
    play_context_0.become_method = 'None'
    strategy_module_0._workers = []
    strategy_module_0._blocked_hosts = {}
    strategy_module_0._flushed_hosts = {}
    strategy_module_0._stats = {}
    strategy_module_0._pending_results = {}
    strategy_module_0._cur_worker = -1
    play_context_0.new_stdin = 'None'
    play_context_0.become_pass = 'None'
   

# Generated at 2022-06-25 12:00:02.969862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:40.904166
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # test if run has following arguments: iterator, play_context
    str_1 = '6tLDX'
    strategy_module_1 = StrategyModule(str_1)
    int_1 = 123459
    play_context_1 = PlayContext()
    strategy_module_1.run(int_1, play_context_1)


# Generated at 2022-06-25 12:00:44.180090
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '6tLDX'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = '-L'
    play_context_0 = 'C(*9X'
    strategy_module_0.run(iterator_0, play_context_0)
    assert strategy_module_0._tqm is not None

# Generated at 2022-06-25 12:00:49.143115
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    strategy_module_2 = StrategyModule('0tLDX')
    strategy_module_2.run('/Goo0', 'L4bMo')


# Generated at 2022-06-25 12:00:54.297065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:00:58.035856
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        test_case_0()
    except Exception as err:
        print(err)

test_StrategyModule_run()

# Generated at 2022-06-25 12:01:05.423143
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Pass test_case_0 as argument to test method run
    test_StrategyModule_run_0()

    # Pass test_case_1 as argument to test method run
    test_StrategyModule_run_1()

    # Pass test_case_2 as argument to test method run
    test_StrategyModule_run_2()

    # Pass test_case_3 as argument to test method run
    test_StrategyModule_run_3()

    # Pass test_case_4 as argument to test method run
    test_StrategyModule_run_4()

# Generated at 2022-06-25 12:01:08.508166
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("test_StrategyModule_run:")
    test_case_0()
    print("pass")

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:12.779695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    try:
        test_case_0()
    except Exception as exc:
        assert False, exc


# Generated at 2022-06-25 12:01:17.532272
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '6tLDX'
    iterator_0 = 'fMAX'
    play_context_0 = '~h'
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:01:18.415335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:02:46.036205
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    name_0 = 'i5'
    _items, _block_name_to_block_map, _keywords, _vars, _handlers, _parent, task_include_meta, _role_params, _role_params_transformed, _role_vars, _role_path, _task_name, _included_file, _include_params, _role, task_args_template = str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0,

# Generated at 2022-06-25 12:02:54.105529
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # See if we can run the unit tests
    if sys.version_info < (3, ):
        yaml.constructor.Constructor.yaml_constructors[u'tag:yaml.org,2002:timestamp'] = AnsibleYamlDumper.timestamp_constructor
    else:
        yaml.constructor.RoundTripConstructor.yaml_constructors[u'tag:yaml.org,2002:timestamp'] = AnsibleYamlDumper.timestamp_constructor

    test_dir = os.path.dirname(os.path.realpath(__file__))
    data_dir = os.path.join(test_dir, '../data/timestamp_unit')

    # Test case 0
    # Run method run of class StrategyModule with arguments: iterator, play_context

# Generated at 2022-06-25 12:03:04.679036
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Using all arguments, name = 'strategy_module', loader = 'loader_0', variable_manager = 'variable_manager_0', host_list = 'host_list_0'
    # pylint: disable=unused-argument
    str_0 = 'n0Vc5'
    strategy_module_0 = StrategyModule(str_0)
    action_loader_0 = action_loader
    templar_0 = Templar('loader_0', 'variable_manager_0')
    # Using positional arguments
    iterator_0 = 'iterator_0'
    play_context_0 = 'play_context_0'
    # Using all keyword arguments
    kwargs = {
        'action_loader_0': action_loader_0,
        'templar_0': templar_0,
    }
    strategy_

# Generated at 2022-06-25 12:03:09.923036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # initialization
    str_0 = '6tLDX'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:03:14.217720
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    result = StrategyModule.run(StrategyModule, iterator, play_context)

    assert type(result) == bool, "Unexpected type of parameter result"

    assert result == False, "Unexpected value of parameter result"

# Generated at 2022-06-25 12:03:17.954418
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of the StrategyModule class
    strategy_module_0 = StrategyModule(str)

# Generated at 2022-06-25 12:03:23.179850
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '3qC8O'
    iterator_0 = Iterator(str_0)
    play_context_0 = PlayContext()
    result_0 = strategy_module_0.run(iterator_0, play_context_0)



if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:03:24.215102
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True


# Generated at 2022-06-25 12:03:27.815252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6tLDX'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:03:28.908622
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:05:32.151185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_case_0()
    print("No unit test is available for Class StrategyModule")


# Generated at 2022-06-25 12:05:36.450506
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context_0 = PlayContext()
    # Assigning some value to test_iterator of object play_context_0
    test_iterator = play_context_0.iterator
    # Assigning some value to iterator of type object
    iterator = test_iterator
    strategy_module_0 = StrategyModule(iterator)
    # Calling method run of class StrategyModule with arguments (iterator, play_context_0)
    test_case_0()
    print('Test: %s' % test_case_0.__name__)
    result = strategy_module_0.run(iterator, play_context_0)
    assert result.__class__ is bool
    print('Test: %s PASS' % test_case_0.__name__)

# Generated at 2022-06-25 12:05:37.068055
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:05:37.670430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:05:42.494328
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    tqm_0 = Tqm(0, 0, 0)
    iterator_0 = HostIterator(tqm_0, 0, 0, 0)
    strategy_module_0 = StrategyModule(0)
    play_context_0 = PlayContext(0,)
    assert strategy_module_0.run(iterator_0, play_context_0) == 0


# Generated at 2022-06-25 12:05:46.209813
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Mandatory params
    global str_0
    str_0 = '6tLDX'
    global iterator_0
    iterator_0 = 'nlEa9'
    global play_context_0
    play_context_0 = 'mi5U6'
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:05:48.122270
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    it_0 = None
    play_context_0 = None
    strategy_module_0 = init_StrategyModule()
    strategy_module_0.run(it_0, play_context_0)

# Initializes instance of class StrategyModule with values

# Generated at 2022-06-25 12:05:52.628598
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '6tLDX'
    # Test number of arguments and argument types
    args = {'iterator':'6tLDX', 'play_context': '6tLDX', }
    t = test_case_0()
    try:
        t.run(**args)
    except TypeError:
        pass
    except AttributeError:
        pass
    except ValueError:
        pass
    except AnsibleError:
        pass



if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:05:56.387111
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule('6tLDX')
    iterator_0 = '6tLDX'
    play_context_0 = '6tLDX'
    # Call method run of strategy_module_0
    return strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:05:57.913350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(12)
    assert strategy_module_0.tqm == 12

