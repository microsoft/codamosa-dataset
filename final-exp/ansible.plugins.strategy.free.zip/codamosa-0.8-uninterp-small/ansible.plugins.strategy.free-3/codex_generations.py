

# Generated at 2022-06-25 11:58:37.012802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:43.502868
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(strategy)
    iterator_0 = iterator
    play_context_0 = play_context
    # if the run method is defined..
    if getattr(strategy_module_0, "run", False) != False:
        # Run method of strategy_module_0 executes a sequence of statements using iterator_0 and play_context_0 objects.
        strategy_module_0.run(iterator_0, play_context_0)
    else:
        raise TypeError('method run("StrategyModule", "iterator", "play_context") element is not callable')

# Test case for method run of class StrategyModule

# Generated at 2022-06-25 11:58:45.026306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("test test_StrategyModule finished\n")

test_StrategyModule()

# Generated at 2022-06-25 11:58:46.652140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(str)
    assert strategy_module is not None


# Generated at 2022-06-25 11:58:55.475564
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = "n4z4XW7"
    # iterator is of type ansible.parsing.yaml.objects.AnsibleIterator
    iterator = AnsibleIterator(str_0)
    # play_context is of type ansible.playbook.play_context.PlayContext
    play_context = PlayContext(str_0)
    result = strategy_module_0.run(iterator, play_context)


if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:07.281039
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    string_0 = "h*$&&P'D5;t@:>t{p";
    string_1 = "vjNZ:'"
    string_2 = "5D5yl+S5{@>t{p";
    string_3 = "vjN";
    string_4 = "eQ`c%3>t{p";
    string_5 = "vjNZ:'"
    string_6 = "^;bf)$6_sU6:>t{p"
    string_7 = "L-&~wA,p=cW"
    string_8 = "D2fB9(,j)"
    string_9 = "W8nu.h]b$:>t{p";
    string_10 = "vjNZ:'"

# Generated at 2022-06-25 11:59:09.485434
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(None)
    assert_not_equal(strategy_module_0, None)


# Generated at 2022-06-25 11:59:17.286426
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialize test variables
    str_0 = "pZ9X"
    str_1 = "GB8y:'"
    str_2 = "FwPQ"
    str_3 = "o6U^"
    str_4 = "BR6G"
    int_0 = 100
    str_5 = "XU6[\U000350f1"
    int_1 = 1
    str_6 = "cxk]"
    str_7 = "m4B;"
    int_2 = 0
    str_8 = "pp;2\U0003f3a9"
    str_9 = "P!_y"
    int_3 = 2
    str_10 = "Z@G;"
    str_11 = "G7f<"
    str_12 = "oB;w"

# Generated at 2022-06-25 11:59:23.680039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    try:
        test_StrategyModule()
    except:
        print("Exception in user code:")
        print("-"*60)
        traceback.print_exc(file=sys.stdout)
        print("-"*60)

# Generated at 2022-06-25 11:59:33.383774
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:00:02.006951
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class Mock_StrategyBase(StrategyBase):
        # Instance
        def __init__(self, value):
            self.value = value
            # Class
        def run(self):
            return self.value
        @classmethod
        def other_run(cls, value):
            return cls(value)
    assert Mock_StrategyBase.other_run(666).run() == 666


# Generated at 2022-06-25 12:00:02.995786
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:00:04.053618
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_num = 0
    test_case_0()
    pass



# Generated at 2022-06-25 12:00:13.709078
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    as0 = ansible_2_1_1.action.AnsibleModule
    as1 = ansible_2_1_1.action.AnsibleModule(argument_spec={'test_param': dict(type='int', required=False)})
    as2 = ansible_2_1_1.action.AnsibleModule.add_file_common_args({'type': 'bool'})
    as3 = ansible_2_1_1.action.AnsibleModule(argument_spec={'test_param': dict(type='int', required=False)})
    as4 = ansible_2_1_1.action.AnsibleModule(argument_spec={'test_param': dict(type='int', required=False)})

# Generated at 2022-06-25 12:00:17.306529
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create test object
    str_0 = StrategyModule(tqm=None)

    # set up objects needed by method
    str_1 = 'q3pO1og'
    str_2 = 'hF9rIkG'
    # call method
    #assertEquals(str_0.run(iterator=str_1, play_context=str_2), )



# Generated at 2022-06-25 12:00:22.316766
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = 'host'
    task = 'task'
    task_vars = 'task_vars'
    play_context = 'play_context'

    tqm = 'tqm'

    test_obj = StrategyModule(tqm)
    test_obj.run(host, task, task_vars, play_context)


if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 12:00:25.493877
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule(None)
    strategyModule.run(None, None)


# Generated at 2022-06-25 12:00:34.445446
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # We are generating the expected results using the reference implementation output
    tqm = 'tqm'
    iterator_0 = {'hosts_left': ['host_0', 'host_1'], 'task_0': 'task_0'}
    play_context = {'host_0': {'network': 'VLAN10', 'uplink_port': 'Ethernet10'}, 'host_1': {'network': 'VLAN10', 'uplink_port': 'Ethernet10'}}
    # We have to replace the first parameter as it is a object
    # The test is successful

# Generated at 2022-06-25 12:00:35.881323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)

pass

# Generated at 2022-06-25 12:00:45.090687
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:01:13.201789
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Find a way to make this unit-testable.
    return

    # Initialize partially initialized class
    strategy = StrategyModule_run()

# Generated at 2022-06-25 12:01:14.506669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module_0 = StrategyModule()



# Generated at 2022-06-25 12:01:22.401608
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("testing _run() of class StrategyModule")
    print("test case 0")
    ansible.parsing.dataloader.DataLoader = MagicMock(return_value = test_case_0())
    assert StrategyModule.run(strategy_module, iterator, play_context) == expected_result_0


# Generated at 2022-06-25 12:01:23.542991
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:01:29.594223
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    s = StrategyModule()
    class theClass: pass
    tqm = theClass()
    i = theClass()
    play_context = theClass()
    play_context.any_errors_fatal = True
    s.run(i, play_context)

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:34.826468
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # first instance of class StrategyModule
    st_0 = StrategyModule()
    # second instance of class StrategyModule
    st_1 = StrategyModule()
    # third instance of class StrategyModule
    st_2 = StrategyModule()
    # fourth instance of class StrategyModule
    st_3 = StrategyModule()
    # fifth instance of class StrategyModule
    st_4 = StrategyModule()
    # sixth instance of class StrategyModule
    st_5 = StrategyModule()

    # call method run of object st_0
    st_0.run(iterator, play_context)
    st_0.run(iterator, play_context)
    st_0.run(iterator, play_context)
    st_0.run(iterator, play_context)
    st_0.run(iterator, play_context)

# Generated at 2022-06-25 12:01:40.434785
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    option_values = dict(
        connection='local',
        module_path=None,
        forks=100,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        listhosts=None,
        listtasks=None,
        listtags=None,
        syntax=None,
        start_at_task=None
    )
    loader = DataLoader()

# Generated at 2022-06-25 12:01:42.229386
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategymodule = StrategyModule()
    strategymodule.run(iterator = test_case_0, play_context = test_case_0)


# Generated at 2022-06-25 12:01:51.893033
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.plugins.strategy.free import StrategyModule
    test_StrategyModule_run_0()
    test_StrategyModule_run_1()
    test_StrategyModule_run_2()
    test_StrategyModule_run_3()
    test_StrategyModule_run_4()
    test_StrategyModule_run_5()
    test_StrategyModule_run_6()
    test_StrategyModule_run_7()
    test_StrategyModule_run_8()
    test_StrategyModule_run_9()
    test_StrategyModule_run_10()


# Generated at 2022-06-25 12:01:55.447024
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'n4z4XW7'
    obj_0 = StrategyModule(str_0)
    str_1 = 'n4z4XW7'
    str_2 = 'n4z4XW7'
    obj_0.run(str_1, str_2)
    obj_0.run(str_2)
    obj_0.run(str_1, str_1)


# Generated at 2022-06-25 12:02:40.592682
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:02:44.066055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategyModule = StrategyModule(None)

        assert strategyModule
        print('Pass test_StrategyModule')
    except:
        print('Failed test_StrategyModule')


# Generated at 2022-06-25 12:02:48.406823
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    iterator_0 = __import__('ansible.errors').AnsibleError()
    play_context_0 = __import__('ansible.template').template()
    assert strategy_module_0.run(iterator_0, play_context_0) == 0, "Return value of method run of class StrategyModule is incorrect"


# Generated at 2022-06-25 12:02:52.502309
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup
    tqm = None
    iterator = None
    play_context = None
    item = None

    # Invoke method
    results = StrategyModule.run(item, iterator, play_context)
    # Verify
    assert(results == None)


# Generated at 2022-06-25 12:02:57.304375
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # First create a StrategyModule object to manipulate it
    strategymodule_obj = StrategyModule()
    # Then use its member function
    # TODO: Need to implement test cases
    # test_case_0(strategymodule_obj)


# Generated at 2022-06-25 12:03:02.215236
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:03:12.759345
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #print(dir(StrategyModule))
    #args = {
    #    'iterator': iterator,
    #    'play_context': play_context
    #}
    #print(test_case_0.__globals__)
    #print(StrategyModule.__globals__)
    #print(globals())
    print(globals()['__file__'])
    print(globals()['__name__'])
    import os
    print(os.path.abspath(__file__))
    print(os.path.abspath(__file__))
    print(os.path.isfile(os.path.abspath(__file__)))
    #for v in globals():
    #    print(v)
    obj = StrategyModule('tqm')
   

# Generated at 2022-06-25 12:03:13.844589
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    d=StrategyModule([])
    d.run([],[])

# Generated at 2022-06-25 12:03:20.652651
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # AnsibleExitJson = test_case_0
    # AnsibleFailJson = test_case_1
    tqm = test_case_2
    # AnsibleShow = test_case_3
    iterator = test_case_4
    play_context = test_case_5

    # method test
    ans = StrategyModule(tqm).run(iterator, play_context)  # expected valid return
    

# Generated at 2022-06-25 12:03:25.307174
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule()

    strategyModule.run()

    strategyModule.run()

    strategyModule.run()

    strategyModule.run()

    strategyModule.run()

    strategyModule.run()

    strategyModule.run()

    strategyModule.run()

    strategyModule.run()

    strategyModule.run()


if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:44.672728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:04:47.403420
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # obj_class is the class which we want to test.
    obj_class = StrategyModule

    obj = obj_class()

    # debug.output_value(obj)

    test_case = test_case_0
    test_case()



# Generated at 2022-06-25 12:04:52.029420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm_base"
    sm = StrategyModule(tqm)
    return sm

# c = test_StrategyModule()
# c.run()
# print(c.__class__)
# print(c.__dict__)
# print(c.__doc__)
# print(c.__init__())
# print(c.__module__)
# print(c.__str__())
# print(1)

# print(test_case_0())

# Generated at 2022-06-25 12:04:53.159612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    print('strategy_module: ', strategy_module)


# Generated at 2022-06-25 12:04:55.349450
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy = StrategyModule()
    test_case_0()

# Entry point to execute the test cases from the CSV file
if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:56.305971
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True
    print("Test: test_StrategyModule_run")


# Generated at 2022-06-25 12:04:57.675833
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Test 0
    test_case_0()


if __name__ == '__main__':

    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:59.410776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global tqm
    tqm = test_case_0()
    obj = StrategyModule(tqm)
    assert(True) == (isinstance(obj, StrategyModule))

#test_StrategyModule()

# Generated at 2022-06-25 12:05:01.094774
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Unit test for method run of class StrategyModule
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:05:02.714367
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule(tqm)
    strategyModule.run(iterator, play_context)
    del strategyModule
    pass


# Generated at 2022-06-25 12:08:00.814784
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    context._init_global_context(loader=loader)
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-25 12:08:05.478568
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None
    obj = StrategyModule(tqm)
    try:
        obj.run(iterator, play_context)
    except Exception as e:
        print(e)

test_StrategyModule_run()

# Generated at 2022-06-25 12:08:09.633268
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  strategy_module = StrategyModule()
  if(strategy_module.__class__.__name__ != 'StrategyModule'):
    raise AssertionError('Test case run has failed')
  try:
    strategy_module.run(iterator, play_context)
  except:
    raise AssertionError('Test case run has failed')
 

# Generated at 2022-06-25 12:08:10.328627
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-25 12:08:11.431804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

#if __name__ == "__main__":
#    test_StrategyModule()

# Generated at 2022-06-25 12:08:18.146933
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = 'n4z4XW7'
    iterator = 'n4z4XW7'
    play_context = 'n4z4XW7'

    # call the method without arguments
    try:
        ret = StrategyModule(tqm).run(iterator, play_context)
        if ret != None:
            print("[+] function run of class StrategyModule: test 1 passed successfully")
        else:
            print("[-] function run of class StrategyModule: test 1 failed")
    except Exception as err:
        print("[-] function run of class StrategyModule: test 1 failed")

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()