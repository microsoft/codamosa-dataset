

# Generated at 2022-06-25 11:58:35.891947
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule()
    strategy_module_1.run()

# Generated at 2022-06-25 11:58:38.368038
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # AnsibleError is raised for the following calls
    test_case_0()

if __name__ == "_main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 11:58:39.894316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'c%'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 11:58:40.802112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:58:52.019741
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    import threading

    print("\n\nTest StrategyModule.run()")

    # test empty iterator
    def _t_iterator():
        yield []
        return

    t_iterator = _t_iterator()

    play_context_0 = PlayContext()

    strategy_module_0 = StrategyModule(t_iterator)
    strategy_module_0.run(play_context_0)

    play_context_0.module_name = "setup"
    play_context_0.task = ""
    play_context_0.host_name = ""
    play_context_0.task_name = ""
    play_context_0.host = ""

    strategy_module_0 = StrategyModule(t_iterator)
    strategy_module_0.run(play_context_0)

    # test with valid input

# Generated at 2022-06-25 11:58:56.578042
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator_0 = test_case_0()
    play_context_0 = test_case_0()
    StrategyModule_run_0 = strategy_module_0.run(iterator_0, play_context_0)
    print(StrategyModule_run_0)


# Generated at 2022-06-25 11:59:00.711156
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # setup
    str_0 = '#\x0c4_t(b:4".>8Um)'
    strategy_module_0 = StrategyModule(str_0)
    # execution
    test_case_0()


# Generated at 2022-06-25 11:59:08.593018
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a new StrategyModule object
    strategy_module_0 = StrategyModule()

    # Create a new object of class PlayContext
    play_context_0 = PlayContext()

    # Create a new object of class Host
    host_0 = Host('2^0%!s{!N"b')

    # Create a new object of class Iterator
    iterator_0 = Iterator(host_0, play_context_0)

    # Call method run of strategy_module_0
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 11:59:16.620476
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.strategy import StrategyBase
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    hosts = ['host_0']
    blocks = [Block('block_0')]
    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play 0",
        hosts='host_0',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='Hello World')))
        ]
    )

# Generated at 2022-06-25 11:59:17.859700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    time.sleep(0.1)
    assert True == True, "Testing constructor of class StrategyModule"


# Generated at 2022-06-25 11:59:54.572417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm test"
    strategymodule = StrategyModule(tqm)


# Generated at 2022-06-25 11:59:59.142090
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import datetime
    import time
    import mock

    tqm = mock.MagicMock()
    iterator = mock.MagicMock()
    play_context = mock.MagicMock()
    strategyModule = StrategyModule(tqm)
    startTime = time.time()
    ratio = 1
    # 60 loops
    loopTime = 3
    for i in range(60):
        #print("loop: {}, time: {}".format(i, time.time()-startTime))
        strategyModule.run(iterator, play_context)
        time.sleep(3)
        ratio -= 0.05
        if (ratio < 0.05):
            ratio = 0.05
        #mock.MagicMock.run(mock.MagicMock)
        #print("loop: {}, time: {}".format(i,

# Generated at 2022-06-25 12:00:00.319080
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
    return 0


# Generated at 2022-06-25 12:00:06.608496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display_0 = Display()
    constants_0 = C()

# Generated at 2022-06-25 12:00:07.755674
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 0.1

# Generated at 2022-06-25 12:00:10.265088
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:00:11.366503
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
   # Test run method
    float_0 = 0.1
    test_case = StrategyModule(float_0)

# Generated at 2022-06-25 12:00:12.079460
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 0.1


# Generated at 2022-06-25 12:00:12.990302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    test = test_case_0()
    return obj

# Generated at 2022-06-25 12:00:19.275563
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import sys
    import os
    import tempfile
    import shutil
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import callback_filter_loader

    plugins_path = os.path.abspath(os.path.join(os.path.curdir, 'plugins'))
    print(plugins_path)
    if plugins_path not in sys.path:
         sys.path.insert(0, plugins_path)

    temp_dir = tempfile.mkdtemp(prefix='tmp_sf_ansible')
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)

# Generated at 2022-06-25 12:00:56.342462
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    args = []
    kwargs = {}
    result = StrategyModule.run(*args, **kwargs)
    assert result == "Invalid number of arguments"


# Generated at 2022-06-25 12:00:58.987397
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Test run of method run of class StrategyModule")
    test_case_0()
    print("Completed test run of method run of class StrategyModule")


# Generated at 2022-06-25 12:01:03.309818
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None
    StrategyModule(tqm)
    try:
        StrategyModule.run(iterator, play_context)
    except (TypeError, ValueError) as e:
        print(e)


# Generated at 2022-06-25 12:01:11.879884
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:01:15.920138
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# main entry point to our program

# Generated at 2022-06-25 12:01:19.609812
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup of test data
    tqm = None
    iterator = None
    play_context = None
    # Test routine
    test_StrategyModule = StrategyModule(tqm)
    test_StrategyModule.run(iterator,play_context)
    # Verification
    assert None == None


# Generated at 2022-06-25 12:01:30.464295
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print()
    print("##### Begin unit test for StrategyModule::run #####")

    # Setup
    tqm = "tqm_1"
    iterator = "iterator_0"
    play_context = "play_context_0"
    strategyModule_inst = StrategyModule(tqm)
    strategyModule_inst.run(iterator, play_context)

    # Exercise
    # Nothing to exercise

    # Verify
    # Nothing to verify

    print("##### End unit test for StrategyModule::run #####")
    if float_0 == 0.1:
        print("passed test case of StrategyModule::run")
    else:
        print("failed test case of StrategyModule::run")
    print()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:01:31.123488
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-25 12:01:37.276652
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:01:37.730621
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-25 12:02:24.671284
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    original_module_dict = sys.modules
    try:
        sys.modules = {}
    except:
        pass
    x = StrategyModule('StrategyModule')
    try:
        if hasattr(x, 'run'):
            try:
                for line in traceback.format_stack():
                    print(line.strip())
                print('\n    x.run()\n')
                x.run()
            except: pass
    except: pass
    sys.modules = original_module_dict
    original_module_dict = None

test_case_0()
test_StrategyModule_run()

# Generated at 2022-06-25 12:02:27.324223
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # case 0
    # TODO
    pass


# Generated at 2022-06-25 12:02:29.028987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = '#\x0c4_t(b:4".>8Um)'
    strategy_module_0 = StrategyModule(str_1)


# Generated at 2022-06-25 12:02:33.762676
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Define the parameters of test case
    strategy_module_0 = StrategyModule(None)

    # Try to execute method run of StrategyModule
    try:
        # TODO: If it is possible to run this test case, remove the line below
        raise Exception('Test case not implemented')

        # TODO: if it is possible to define parameters of test case, please replace the line below
        try:
            strategy_module_0.run(None, None)
        except Exception as e:
            print('Caught exception: ' + str(e))

    except Exception as e:
        print('Caught exception: ' + str(e))


# Generated at 2022-06-25 12:02:35.260783
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:02:36.313254
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:02:40.220334
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert callable(StrategyModule.run)


# Generated at 2022-06-25 12:02:49.800201
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook_path = './test_case_files/test_playbook.yml'
    variable_manager = None
    loader = None
    inventory = None
    variable_manager = None
    loader = None

    tqm = None
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': 'webservers'}
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=playbook_path)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-25 12:02:54.851228
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '9I\x19c~\t=\x13\x1c'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = None
    play_context_0 = None
    ansible_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert ansible_0 == None


# Generated at 2022-06-25 12:02:55.509836
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True


# Generated at 2022-06-25 12:04:46.676457
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        assert test_StrategyModule_run.__name__ == 'test_StrategyModule_run'
    except:
        print('Failure: test_StrategyModule_run.')
        return

    # Create mock object for args, and set default values.
    args = type('', (), {})()
    args.ask_sudo_pass = False
    args.ask_su_pass = False
    args.ask_vault_pass = False
    args.become = False
    args.become_ask_pass = False
    args.become_method = 'sudo'
    args.become_user = 'root'
    args.check = False
    args.connection = 'smart'
    args.diff = False
    args.extra_vars = None
    args.flush_cache = False
    args.force

# Generated at 2022-06-25 12:04:51.044590
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Testing private method run of class StrategyModule
    # test_case_0
    str_0 = '#\x0c4_t(b:4".>8Um)'
    strategy_module_0 = StrategyModule(str_0)
    # TODO: Get a real iterator object here
    iterator_0 = object()
    play_context_0 = object()
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:04:55.545331
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '-o\x0831Lv'
    iterator_0 = '#\x0c4_t(b:4".>8Um)'
    play_context_0 = '0yG_q{x`'
    strategy_module_0 = StrategyModule(str_0)
    result_0 = strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:59.512345
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '#\x0c4_t(b:4".>8Um)'
    iter_0 = str_0
    pl_cx_0 = '-L'
    strategy_module_0 = StrategyModule(str_0)
    ret_0 = strategy_module_0.run(iter_0, pl_cx_0)
    assert ret_0 == False


# Generated at 2022-06-25 12:05:02.499216
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '#\x0c4_t(b:4".>8Um)'
    strategy_module_0 = StrategyModule(str_0)
    play_context_0 = dict()
    play_context_1 = dict()
    strategy_module_0.run(iterator=play_context_0, play_context=play_context_1)

# Generated at 2022-06-25 12:05:08.259293
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    args_0 = {'v2_playbook_on_no_hosts_remaining': dict(arg_0=None), 'is_conditional': False, 'action': dict(arg_0=None), '_host': dict(arg_0=None), '_ds': dict(arg_0=None, target='task', type='dict'), 'play': dict(target='iterator', type='playbook iterator'), 'iterator': dict(target='iterator', type='playbook iterator'), 'task': dict(arg_0=None), '_ansible_no_log': dict(arg_0=None), 'play_context': dict(arg_0=None, target='play_context', type='play_context')}
    strategy_module_0 = StrategyModule(args_0)

# Generated at 2022-06-25 12:05:09.855700
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    
    # Call method run of class StrategyModule
    
    pass


# Generated at 2022-06-25 12:05:11.129193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:05:14.289589
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  from ansible.plugins.strategy import StrategyBase
  # Init Test
  str_0 = StrategyBase.__init__(self)
  strategy_module_0 = StrategyModule(str_0)
  strategy_module_0.run()


# Generated at 2022-06-25 12:05:15.123935
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Mock dependencies and perform the test