

# Generated at 2022-06-25 11:58:36.937057
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:58:44.938536
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialization
    runner_0 = Runner(loader_0, inventory_0, variable_manager_0, None, None, None, play_context_0, None, None, None, None) # Placeholder
    connection_ids_0 = runner_0._get_connection_info()

    # Testing

# Generated at 2022-06-25 11:58:49.080982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(tuple())
    assert isinstance(strategy_module_1, StrategyModule)


# Generated at 2022-06-25 11:58:57.465357
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    print("Testing run of StrategyModule")
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)
    list_of_strings_0 = []
    list_of_strings_1 = []
    tuple_1 = (list_of_strings_0, list_of_strings_1)
    tuple_2 = (tuple_1, 'a')
    tuple_3 = (iterator_0, tuple_2)
    iterator_1 = tuple_3
    play_context_1 = None
    strategy_module_0.run(iterator_1, play_context_1)
    list_of_strings_2 = []
    list_of_strings

# Generated at 2022-06-25 11:59:03.935110
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator_0 = ()
    play_context_0 = ()
    expected_result_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert expected_result_0 is None, "Expected None, got {}".format(expected_result_0)


# Generated at 2022-06-25 11:59:07.283296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    assert (strategy_module_0 is not None)


# Generated at 2022-06-25 11:59:10.216865
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = DummyTqm()
    iterator_0 = MockIterator()
    play_context_0 = MockContext()
    strategy_module_0 = StrategyModule(tqm_0)
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 11:59:11.625533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)


# Generated at 2022-06-25 11:59:15.621694
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator_0 = tuple_0
    play_context_0 = tuple_0
    strategy_module_0.run(iterator_0, play_context_0)

try:
    import unittest2 as unittest
except ImportError:
    import unittest


# Generated at 2022-06-25 11:59:21.070860
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #
    # Vsetko v super vratime premennej result a vratime ho
    #
    verify_list_0 = []
    strategy_module_0 = StrategyModule(verify_list_0)
    verify_list_1 = []
    verify_str_0 = "0"
    verify_list_0.append((verify_str_0, verify_list_1))
    verify_str_1 = "1"
    verify_list_0.append((verify_str_1, verify_list_1))
    verify_str_2 = "2"
    verify_list_0.append((verify_str_2, verify_list_1))
    verify_str_3 = "3"
    verify_list_0.append((verify_str_3, verify_list_1))


# Generated at 2022-06-25 11:59:47.888821
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        iterator = None
        play_context = None
        try:
            var_1 = StrategyModule.run(iterator, play_context)
        except SystemExit as e:
            var_0 = e
        else:
            var_0 = None
    except Exception as e:
        var_0 = e

    assert var_0 == None


# Generated at 2022-06-25 11:59:50.239656
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    var_0 = StrategyModule()
    var_1 = None
    var_2 = None
    var_0.run(var_1, var_2)
    # expected:
    # assert result == expected_result


# Generated at 2022-06-25 11:59:56.955714
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 11:59:57.905786
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    var = None
    var_0 = None


# Generated at 2022-06-25 12:00:05.805769
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    ansible_playbook_0 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None

# Generated at 2022-06-25 12:00:15.148269
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Instantiate object of class StrategyModule with parameter 'tqm'
    obj = StrategyModule('tqm')
    # Call method run of object with parameter 'iterator', 'play_context'
    obj.run(var_0, var_0)

################################################################################
# Output of pydoc style documentation for above functions
################################################################################

# test_StrategyModule_run is aliased to test_case_0

# test_case_0()
#  
#  NAME
#     test_case_0
#  
#  DESCRIPTION
#     Unit test for method run of class StrategyModule
#  
#  PARAMETERS
#    None
#  
#  RETURN VALUE
#    None
#  
#  ERRORS
#    None
#  
#  EXAMPLES
#    None
#

# Generated at 2022-06-25 12:00:17.051894
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    var_0 = StrategyModule()
    var_1 = None
    var_2 = None
    var_0.run(var_1, var_2)


# Generated at 2022-06-25 12:00:20.047192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    pass


# Generated at 2022-06-25 12:00:27.181120
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Declare the class instance
    strategymodule = StrategyModule()

    # Assign parameter values
    iterator = None
    play_context = None

    try:
        # Call the method
        strategymodule.run(iterator, play_context)
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 12:00:28.195334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(var_0)
    assert strategy_module != None


# Generated at 2022-06-25 12:01:11.338848
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a new instance of the object under test
    obj = StrategyModule(None)
    # Convert the following call arguments to something mock can use
    var_0 = iter([1, 2, 3])
    play_context = Mock()
    try:
        test_result = obj.run(var_0, play_context)
    except:
        print("An exception has been raised.\n")
        raise

# perform the unit tests
test_StrategyModule_run()

# Generated at 2022-06-25 12:01:17.632270
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:01:19.745539
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    args = []
    arg_0 = []
    arg_1 = []
    ret = StrategyModule.run(args, arg_0, arg_1)
    assert (ret is None)


# Generated at 2022-06-25 12:01:20.983109
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule_instance = StrategyModule(None)

    test_case_0()

# Generated at 2022-06-25 12:01:23.105354
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-25 12:01:24.273050
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    var = StrategyModule(0)
    var.run(iterator, play_context)

# Generated at 2022-06-25 12:01:28.222394
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    var = StrategyModule(var_0)
    var.run(iterator, play_context)


# Generated at 2022-06-25 12:01:31.082903
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = None
    iterator = None
    play_context = None

    # Call the function to get the result
    #    result = StrategyModule(tqm).run(iterator, play_context)
    pass


# Generated at 2022-06-25 12:01:33.625955
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    var_0 = None
    var_0 = StrategyModule()
    try:
        var_1 = True
        var_1 = var_0.run(var_1)
        assert var_1 == True
    except Exception:
        raise

test_StrategyModule_run()

# Generated at 2022-06-25 12:01:44.421676
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Arguments :
    # 1 : iterator
    # 2 : play_context


    p1 = PlaybookExecutor("test/test_playbook_0.yaml")
    p1.run()
    for k, v in p1.tqm._unreachable_hosts.items():
        print(k)
        print(v)

    print("\n\n")

    f1 = AnsibleFile()
    f1.path = "test/test_playbook_0.yaml"
    f1.basedir = os.path.abspath("test")
    f1 = load_list_of_blocks(loader=None, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None,
                             loader_cache=None)

# Generated at 2022-06-25 12:02:40.429679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tuple_1 = ()
    strategy_module_1 = StrategyModule(tuple_1)
    assert strategy_module_1._host_pinned == False


# Generated at 2022-06-25 12:02:43.154016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)


# Generated at 2022-06-25 12:02:47.771984
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator_0 = _iterator()
    play_context_0 = _play_context()
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:02:48.627295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()



# Generated at 2022-06-25 12:02:51.039900
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # initialization
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator_0 = object()
    object_0 = object()
    play_context_0 = object()
    # calling run method
    result_run = strategy_module_0.run(iterator_0, play_context_0)
    # assertions   
    assert result_run == False

# Generated at 2022-06-25 12:02:59.142195
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Default values of parameters in the test case
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator_0 = None
    play_context_0 = None

    # Test case where all the parameters are their default values
    # Expected test result: 
    assert strategy_module_0.run(iterator_0, play_context_0) == None
    # Expected output: 
    print('')
    # Expected exception: 
    with pytest.raises(AssertionError):
        strategy_module_0.run(iterator_0, play_context_0)
    # Expected output: 
    print('')
    # Expected exception: 

# Generated at 2022-06-25 12:03:09.188958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    assert strategy_module_0.C.DEFAULT_INTERNAL_POLL_INTERVAL == 0.001
    assert strategy_module_0.display.verbosity == 0
    assert strategy_module_0.display.deprecated_warning == "DEPRECATED: "
    assert strategy_module_0.display.deprecated_version == None
    assert strategy_module_0.display.columns == None
    assert strategy_module_0.display.debug_enabled == False
    assert strategy_module_0._display == strategy_module_0.display
    assert strategy_module_0._tqm == tuple_0
    assert strategy_module_0.C.INTERNAL_ERROR_REPORT is None
    assert strategy_module_0.C

# Generated at 2022-06-25 12:03:17.448602
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    strategy_module_0._tqm = task_queue_manager_0 = TaskQueueManager(task_queue_manager_0)
    task_queue_manager_0._included_file_cache = included_file_0 = IncludedFile(included_file_0)
    strategy_module_0.result = bool()
    strategy_module_0.workers_free = int()
    strategy_module_0.host = host_0 = Host(host_0)
    host_0.name = str()
    str_0 = str()
    strategy_module_0.host_name = str_0
    included_file_0.module_name = str_0
    included_file_0._role_name = str_0
    included

# Generated at 2022-06-25 12:03:22.768960
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    tuple_1 = ()
    tuple_2 = ()
    result = strategy_module_0.run(tuple_1, tuple_2)
    assert result == None


# Generated at 2022-06-25 12:03:27.136993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)



# Generated at 2022-06-25 12:05:37.011967
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator_0 = _MagicMock()
    play_context_0 = _MagicMock()
    str_0 = strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:05:44.004087
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Setup fixture
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    seq_0 = []
    iterator_0 = iter(seq_0)
    seq_1 = []
    play_context_0 = iter(seq_1)

    # Invoke method
    result_0 = strategy_module_0.run(iterator_0, play_context_0)

    # Verify assert statements in method
    assert result_0 == None, "Assert: %s" % result_0

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:05:45.593081
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)

    assert not strategy_module_0.run(tuple_0)


# Generated at 2022-06-25 12:05:49.124004
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)

    list_0 = []
    play_context_0 = PlayContext()

    temp_0 = strategy_module_0.run(list_0, play_context_0)
    assert temp_0 == True


# Generated at 2022-06-25 12:05:51.363413
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator = None
    play_context = None
    result = strategy_module_0.run(iterator, play_context)


# Generated at 2022-06-25 12:05:54.549060
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tuple_1 = (1, 2, 3)
    strategy_module_1 = StrategyModule(tuple_1)
    class_1 = Named('Named', strategy_module_1)
    with pytest.raises(SystemExit) as excinfo:
        class_1.run()
    assert excinfo.type == SystemExit
    assert excinfo.value == 0


# Generated at 2022-06-25 12:05:57.422459
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Construct fixture
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)

    # Run fixture
    strategy_module_0.run(tuple_0, tuple_0)


# Generated at 2022-06-25 12:05:58.915348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert isinstance(s, StrategyBase)
    assert isinstance(s, StrategyModule)

# Generated at 2022-06-25 12:06:04.413575
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    global display
    # Init
    tuple_0 = ()
    strategy_module_0 = StrategyModule(tuple_0)
    iterator = None
    play_context = None
    strategy_module_0.run(iterator, play_context)
    global C
    C.DEFAULT_INTERNAL_POLL_INTERVAL = 0
    # AssertionError
    try:
        strategy_module_0.run(iterator, play_context)
    except AssertionError:
        pass


# Generated at 2022-06-25 12:06:07.977739
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # mock a playbook iterator
    playbook_iter = PlaybookIterator([])
    # mock a task queue manager
    task_queue_manager = TaskQueueManager()
    # mock play context
    play_context = dict()

    # instantiate the target class
    strategy_module_0 = StrategyModule(task_queue_manager)
    # call run
    strategy_module_0.run(playbook_iter, play_context)