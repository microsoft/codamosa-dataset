

# Generated at 2022-06-25 11:58:44.086202
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    strategy_module_0.get_hosts_left = lambda iterator: None
    strategy_module_0.add_tqm_variables = lambda task_vars, play: None
    strategy_module_0.update_active_connections = lambda results: None
    strategy_module_0._queue_task = lambda host, task, task_vars, play_context: None
    strategy_module_0._set_hosts_cache = lambda play: None
    strategy_module_0._tqm.send_callback = lambda callback, task, is_conditional: None
    strategy_module_0._step = False
    float_0 = float("nan")
    float_1 = 0
    strategy

# Generated at 2022-06-25 11:58:49.479138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.23659003401097411
    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 11:58:52.072910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -0.03806106679385184
    strategy_module_0 = StrategyModule(float_0)


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:02.354765
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    float_0 = -3.7439958107419424
    strategy_module_1 = StrategyModule(float_0)
    float_0 = -3.7439958107419424
    strategy_module_2 = StrategyModule(float_0)
    float_0 = -3.7439958107419424
    strategy_module_3 = StrategyModule(float_0)
    float_0 = -3.7439958107419424
    strategy_module_4 = StrategyModule(float_0)
    float_0 = -3.7439958107419424
    strategy_module_5 = StrategyModule(float_0)
    float_0

# Generated at 2022-06-25 11:59:12.066002
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -18.923401085924468
    dict_0 = dict()
    dict_0['changed'] = False
    dict_0['failed'] = False
    strategy_module_0 = StrategyModule(float_0)
    InventoryManager_0 = InventoryManager(loader=None, sources='127.0.0.1,')
    host_0 = InventoryManager_0.get_host("127.0.0.1")
    iterator_0 = HostIterator(inventory=dict_0, play=dict_0, play_context=dict_0, variable_manager=dict_0)
    iterator_0._hosts = [host_0]
    dict_1 = dict()
    dict_1['hosts'] = ['127.0.0.1']
    dict_1['gather_facts'] = 'smart'

# Generated at 2022-06-25 11:59:12.820617
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-25 11:59:17.076391
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = None
    play_context_0 = None
    exception_0 = Exception()
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-25 11:59:20.008676
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)

    int_0 = -1
    play_context_0 = None
    iterator_0 = 0
    strategy_module_0.run(iterator_0, play_context_0)

# Test suite for testing StrategyModule

# Generated at 2022-06-25 11:59:29.633823
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)

    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False
    assert  strategy_module_0.run() == False

# Generated at 2022-06-25 11:59:33.383169
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(None)


# Run the tests against the StrategyModule class

# Generated at 2022-06-25 11:59:56.493002
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 11:59:58.056537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:59.357372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:00:03.780777
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -0.9446707829898572
    strategy_module_0 = StrategyModule(float_0)

    ansible_fact_0 = MagicMock(spec=[])
    ansible_fact_0.keys.return_value = None
    ansible_fact_0.keys.return_value = None
    ansible_fact_0.keys.return_value = None
    ansible_fact_0.keys.return_value = None
    ansible_fact_0.keys.return_value = None
    ansible_fact_0.keys.return_value = None
    ansible_fact_0.keys.return_value = None
    ansible_fact_0.keys.return_value = None
    ansible_fact_0.keys.return_value = None

# Generated at 2022-06-25 12:00:12.612450
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_1 = -3.7439958107419424
    strategy_module_1 = StrategyModule(float_1)
    class_iterator_1 = object()
    class_play_context_1 = object()
    
    mock_run_1 = MagicMock(return_value=True)
    with patch.object(StrategyBase, "run", mock_run_1):
        strategy_module_1.run(class_iterator_1, class_play_context_1)
    mock_run_1.assert_called_once_with(strategy_module_1, class_iterator_1, class_play_context_1)


# Generated at 2022-06-25 12:00:16.079736
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    strategy_module_0._tqm = Test_run_class_0()
    strategy_module_0._tqm.send_callback = Test_run_class_1()
    strategy_module_0._tqm._terminated = True
    strategy_module_0.run(iterator=None, play_context=None)


# Generated at 2022-06-25 12:00:20.047945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3.7439958107419424
    try:
        test_case_0()
    except Exception as err:
        print("Exception thrown in test case 0: %s"%(err))


# Generated at 2022-06-25 12:00:27.853497
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:00:38.612356
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    # setup
    float_0 = 100.0
    strategy_module_0 = StrategyModule(float_0)
    strategy_module_1 = strategy_module_0
    float_1 = 1.0
    list_0 = [strategy_module_1, float_1]
    list_1 = [float_1, float_0]
    dict_0 = dict()
    dict_1 = dict()
    dict_0['hostvars'] = dict_1

# Generated at 2022-06-25 12:00:41.692300
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:31.506287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    return 0


# Generated at 2022-06-25 12:01:33.811355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3.972355663171877
    strategy_module_0 = StrategyModule(float_0)


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:01:36.544013
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = None
    play_context_0 = None
    result_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert result_0 == True

# Generated at 2022-06-25 12:01:44.547352
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        from ansible.plugins import module_loader
        from ansible.inventory.manager import InventoryManager
        from ansible.vars.manager import VariableManager
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager
    except:
        print("unable to import libraries for test_StrategyModule_run method")
        return


# Generated at 2022-06-25 12:01:53.308089
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Testing run")
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    play_context_0 = PlayContext()
    play_context_0.become = "su"
    play_context_0.become_method = "su"
    play_context_0.check_mode = "off"
    play_context_0.become_flags = "--help"
    play_context_0.remote_addr = "/z:{'uid': 'd'}"
    play_context_0.new_stdin = []
    play_context_0.remote_user = "kennel"
    play_context_0.connection = "local"
    play_context_0.verbosity = "verbose"
    play_context_0

# Generated at 2022-06-25 12:01:59.452716
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = TestCase_0_0()
    play_context_0 = TestCase_0_0()
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:02:05.892146
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:02:10.768931
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(3.7439958107419424)
    # TODO

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:02:11.950157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:02:15.876307
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_1 = -3.7439958107419424
    strategy_module_1 = StrategyModule(float_1)
    dict_0 = dict()
    obj_0 = object()
    strategy_module_1.run(dict_0, obj_0)

# Generated at 2022-06-25 12:04:26.783002
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 0.390737109941575
    iterator_0 = Iterator(float_0)
    play_context_0 = type('', (), {})()
    play_context_0.become_method = 'sudo'
    play_context_0.port = 1649
    play_context_0.become_user = 'root'
    play_context_0.password = 'g'
    test_0 = StrategyModule._StrategyModule__filter_notified_failed_hosts(iterator_0, iterator_0)
    test_1 = StrategyModule._StrategyModule__filter_notified_hosts(iterator_0)
    test_2 = StrategyModule.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:04:28.893628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0 is not None
    assert strategy_module_0._host_pinned is False


# Generated at 2022-06-25 12:04:34.326406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:04:36.972347
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_2 = StrategyModule(float_0)
    float_0 = -3.7439958107419424
    iterator_0 = Iterator(strategy_module_2, float_0)
    play_context_0 = PlayContext()
    play_context_0 = PlayContext(play_context_0)
    strategy_module_2.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:04:38.354482
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:04:47.468618
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock for class StrategyBase
    StrategyBase_mock = mock.Mock()
    # Instantiate a mock for class StrategyModule
    strategy_module_0 = StrategyModule(StrategyBase_mock)
    # Create a mock for class Iterator
    Iterator_mock = mock.Mock()
    # Create a mock for class PlayContext
    PlayContext_mock = mock.Mock()
    # Pass parameters as keyword arguments
    strategy_module_0.run(iterator = Iterator_mock, play_context = PlayContext_mock)
    # Check if StrategyBase.__init__() was called
    assert StrategyBase_mock.__init__.called == True
    # Check if StrategyBase.run() was called
    assert StrategyBase_mock.run.called == True


# Generated at 2022-06-25 12:04:51.557043
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 2.4761926356104444
    strategy_module_0 = StrategyModule(float_0)
    # test method
    print('Test method run of class StrategyModule')
    module_0 = Module(float_0, float_0)
    module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:04:54.619244
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 6.703323147827804
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = Iterator("dedication")
    play_context_0 = PlayContext("Unable to decrypt")
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:04:57.230986
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = -3.7439958107419424
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:04:58.723834
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()