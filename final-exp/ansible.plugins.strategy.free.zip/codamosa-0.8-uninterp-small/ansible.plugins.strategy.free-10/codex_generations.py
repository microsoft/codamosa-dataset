

# Generated at 2022-06-25 11:58:38.856510
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'Ah`^\r5k/u#g'
    iterator_0 = PlayIterator(str_0)
    play_context_0 = PlayContext()
    # Call the run method of the StrategyModule class
    strategy_module_0 = StrategyModule(str_0)
    result_0 = strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 11:58:40.985155
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert not test_case_0()
# End unit test for StrategyModule.run

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:58:52.225658
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager, TaskQueueManagerOptions

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources=['/Users/zhaohongda/Ansible-Code/repo/ansible/test/ansiballz/test_data/units/plugins/strategy/hosts'])

    variable_manager = VariableManager(loader=loader, inventory=hosts)

# Generated at 2022-06-25 11:58:55.230581
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    template_module = {'module': 'template', 'args': {'test': 1}}
    strategy = StrategyModule({'test': 1})
    result = strategy.run([], {}, template_module)
    assert result == {"task_results": [], "result": True}


# Generated at 2022-06-25 11:58:58.908340
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        test_case_0()
        assert(True)
    except AssertionError as e:
        print(e)
        assert(False)

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:07.789091
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert strategy_module_0.run(str_0,str_0), "strategy_module_0.run(str_0,str_0)"
    assert (strategy_module_0.run(int_1,dict_0) is False), "strategy_module_0.run(int_1,dict_0) is False"
    assert (strategy_module_0.run(dict_0,int_2) is False), "strategy_module_0.run(dict_0,int_2) is False"


# Generated at 2022-06-25 11:59:15.850091
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 11:59:16.466414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 11:59:22.455841
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host_results_0 = []
    strategy_module_0 = StrategyModule(host_results_0)
    play_context_0 = PlayContext()
    iterator_0 = HostIterator()
    strategy_module_0.run(iterator_0, play_context_0)

test_case_0()
#test_StrategyModule_run()

# Generated at 2022-06-25 11:59:26.141332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Running test for StrategyModule constructor")
    test_case_0()
    print("Test completed for StrategyModule constructor")


if __name__ == '__main__':
    try:
        test_StrategyModule()
    except:
        print("Test failed")
    else:
        print("Test completed successfully")

# Generated at 2022-06-25 11:59:51.811103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 11:59:54.051018
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 11:59:57.566187
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm_0 = None
    iterator_0 = None
    play_context_0 = None
    echo_0 = StrategyModule(tqm_0).run(iterator_0, play_context_0)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 11:59:58.568619
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:00:00.556315
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

#global variable __author__ will be redefined.
if __name__ == '__main__':
    __author__ = 'hongliang'
    import __main__
    print(__main__.__author__)
    test_StrategyModule_run()

# Generated at 2022-06-25 12:00:07.452175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # tqm is a TaskQueueManager
    tqm = task_queue_manager.TaskQueueManager()
    test_case_0()
    test_strategy_base.test_StrategyBase()
    test_run()
    test_get_hosts_left()
    test_update_host_state()
    test_update_active_connections()
    test_wait_on_pending_results()
    test_run_success()
    test_run_failed()
    test_filter_notified_failed_hosts()
    test_filter_notified_hosts()
    test_add_tqm_variables()
    test_get_name()
    test_get_type()
    test_run_subset()
    test_run_handlers()
    test_queue_task()
   

# Generated at 2022-06-25 12:00:09.115106
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = StrategyModule('ANSIBLE_STRATEGY_PLUGINS')
    str_0.run('ANSIBLE_Producer', 'ANSIBLE_Producer')

test_case_0()
test_StrategyModule_run()

# Generated at 2022-06-25 12:00:09.966403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:00:11.070514
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
# end of test_StrategyModule_run


# Generated at 2022-06-25 12:00:11.762425
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:01:01.630901
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = StrategyModule.run
    test_case_0()

test_StrategyModule_run()

# Generated at 2022-06-25 12:01:04.524091
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Unit test for method run of class StrategyModule")
    try:
        test_case_0()
    except:
        print('strategy_module_0.run(str_0,str_0) failed')


# Generated at 2022-06-25 12:01:06.074607
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:01:09.255382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        assert False, "Caught exception when testing for constructor of class StrategyModule. Error: {0}".format(str(e))
    assert True


# Generated at 2022-06-25 12:01:20.266612
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Positive test
    try:
        tmp = StrategyBase(str)
        tmp.run(str, str)
        tmp.run(str_0, str_0)
        tmp.run(str_1, str_1)
        tmp.run(str_2, str_2)

    except Exception as e:
        print(e)

    # Negative test
    try:
        tmp.run(str_1, str_0)
        tmp.run(str_1, str_1)
        tmp.run(str_2, str_0)
        tmp.run(str_2, str_1)
        tmp.run(str_2, str_2)

    except Exception as e:
        print(e)

    #tmp = StrategyBase(str)
    #tmp.run(str, str)
    #tmp

# Generated at 2022-06-25 12:01:22.977095
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# use the following code to run the test case
# if __name__ == '__main__':
#     test_StrategyModule_run()

# Generated at 2022-06-25 12:01:30.859392
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    test_params_0 = ['str_0','str_1']
    return_value_0 = 'str_0'
    try:
        return_value_1 = StrategyModule.run(*test_params_0)

        # Unit test for assert
        assert (return_value_0 == return_value_1)
    except AssertionError as e:
        print(e)
        raise
    except Exception as e:
        print(str(e))
        raise


if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:01:32.791883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create the empty object of the class
    obj_class = StrategyModule()

    # Test the type of object created
    assert type(obj_class) == StrategyModule


# Generated at 2022-06-25 12:01:33.780779
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Default case
    test_case_0()



# Generated at 2022-06-25 12:01:35.044286
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Test case 0
    print('Test case 0')
    print("Test with if")



# Generated at 2022-06-25 12:03:28.832045
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create instance of class StrategyModule
    strategy_module = StrategyModule()
    # Call run of strategy_module
    test_case_0()

# Create instance of class StrategyModule
strategy_module = StrategyModule()
# Call run of strategy_module

# Generated at 2022-06-25 12:03:30.543847
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = "test string"
    str_1 = "test string"
    print(test_case_0())



# Generated at 2022-06-25 12:03:31.959227
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:03:34.139603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = StrategyModule(str_0)
    assert_equals(str_0.str_0,str_0) and assert_equals(str_0.str_0,str_0)


# Generated at 2022-06-25 12:03:35.735404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:03:37.966901
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print(test_case_0.__doc__)
    test_case_0()

# Generated at 2022-06-25 12:03:42.955986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test: no exceptions are raised
    try:
        str_1 = StrategyModule('str_1')
    except:
        print('str_1: constructor failed')
        exit(1)
    
    # Test: exceptions are raised
    try:
        str_2 = StrategyModule(None)
    except:
        print('str_2: constructor passed')
    else:
        print('str_2: constructor failed to raise exceptions')
        exit(1)


# Generated at 2022-06-25 12:03:44.740822
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("***** start test_StrategyModule_run **********")
    test_case_0()
    print("***** end test_StrategyModule_run **********")

test_StrategyModule_run()

# Generated at 2022-06-25 12:03:45.470206
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    unittest.main()


# Generated at 2022-06-25 12:03:51.022175
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("\n---Test for StrategyModule.run---\n")
    argv = ["-i", "./inventory.ini", "--list-hosts", "./test_multiprocessing.yml"]
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    options = CLI.parse(args=argv[1:])
    loader = DataLoader()
    passwords = {}

# Generated at 2022-06-25 12:06:22.382165
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('\n----------------- Unit Test for StrategyModule.run() -----------------')
    test_case_0()
    print('---------------------- Unit Test for StrategyModule.run() ends -------------------------')


# Test for class StrategyModule


# Generated at 2022-06-25 12:06:27.649175
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'ds{xo'
    iterator_0 = [str_0, '^', '', '']
    play_context_0 = [str_0, iterator_0, 'q`n]+n6WH', '']

    strategy_module_0 = StrategyModule(str_0)
    result_0 = strategy_module_0.run(iterator_0, play_context_0)
    # self.assertEqual(result_0, expected_0)


# Generated at 2022-06-25 12:06:33.015631
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:06:36.668164
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = str()
    iterator_0 = Iterator(str_0)
    play_context_0 = PlayContext()
    strategy_module_0 = StrategyModule()
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:06:37.554423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:06:45.824175
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Perform unit test for method run of class StrategyModule
    # Setup of test class
    str_1 = 'Ah`^\r5k/u#g'
    strategy_module_1 = StrategyModule(str_1)
    iterator_2 = None
    play_context_2 = None
    # Invoke method
    run_1 = strategy_module_1.run(iterator_2, play_context_2)
    # Setup of test class
    str_3 = 'Ah`^\r5k/u#g'
    strategy_module_3 = StrategyModule(str_3)
    iterator_4 = None
    play_context_4 = None
    # Invoke method
    run_3 = strategy_module_3.run(iterator_4, play_context_4)

# Generated at 2022-06-25 12:06:49.350085
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mock_iterator = None
    mock_play_context = None
    mock___init__ = None
    mock___init__ = MagicMock(return_value=None)
    with patch.object(StrategyModule, '__init__', mock___init__):
        strategy_module_0 = StrategyModule(None)
        strategy_module_0.run(mock_iterator, mock_play_context)


# Generated at 2022-06-25 12:06:50.165679
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:06:57.810999
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'Ah`^\r5k/u#g'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = str_0
    # play_context_0 has type <class 'none'>
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)
    play_context_0 = play_context_0
    # iterator_0 has type <class 'none'>
    iterator_0 = None
    strategy_module_0.run(iterator_0, play_context_0)
    play_context_0 = play_context_0
    # iterator_0 has type <class 'none'>
    iterator_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:07:04.077862
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'Ah`^\r5k/u#g'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = None # TODO: initialise iterator_0 with a value to be tested
    play_context_0 = None # TODO: initialise play_context_0 with a value to be tested
    # TODO: initialise the 'expected' value here

    assert False == False # TODO: replace this assertion with a real test

# Run all tests