

# Generated at 2022-06-18 10:23:18.845595
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:23:23.154205
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format (LogFormatter)
    # This test is not very good.
    # It just makes sure that the method doesn't crash.
    # It doesn't check the output.
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("test", logging.INFO, "test.py", 42, "test", (), None))



# Generated at 2022-06-18 10:23:33.028975
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import io
    import unittest
    import tempfile
    import os
    import shutil
    import time
    import datetime
    import re
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io = io.StringIO()
            self.handler = logging.StreamHandler(self.io)
            self.handler.setFormatter(tornado.log.LogFormatter())
            self.logger = logging.getLogger()
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.log

# Generated at 2022-06-18 10:23:44.732766
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import time
    import unittest
    import warnings

    class MockLogRecord(object):
        def __init__(self, msg, levelno, exc_info):
            self.msg = msg
            self.levelno = levelno
            self.exc_info = exc_info

        def getMessage(self):
            return self.msg

    class TestLogFormatter(unittest.TestCase):
        def setUp(self):
            self.formatter = LogFormatter()

        def test_format(self):
            record = MockLogRecord("foo", logging.INFO, None)

# Generated at 2022-06-18 10:23:50.039972
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    from tornado.log import LogFormatter
    from tornado.escape import utf8
    from tornado.util import b
    from tornado.util import unicode_type
    from tornado.util import basestring_type
    from tornado.util import bytes_type
    from tornado.util import native_str
    from tornado.util import PY3
    import sys
    import io
    import unittest
    import time
    import datetime
    import re

    class TestHandler(logging.Handler):
        def __init__(self):
            logging.Handler.__init__(self)
            self.records = []  # type: List[Any]

        def emit(self, record):
            self.records.append(record)


# Generated at 2022-06-18 10:23:56.642065
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    from tornado.log import LogFormatter
    class LogFormatterTest(unittest.TestCase):
        def test_format(self):
            formatter = LogFormatter()
            record = logging.LogRecord(
                name="tornado.general",
                level=logging.INFO,
                pathname="/path/to/file.py",
                lineno=42,
                msg="test message",
                args=(),
                exc_info=None,
            )
            self.assertEqual(
                formatter.format(record),
                "[I 20070827 12:00:00 file.py:42] test message",
            )
    unittest.main()


# Generated at 2022-06-18 10:24:04.908257
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D 161201 00:00:00 file:42] test message"



# Generated at 2022-06-18 10:24:15.240542
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] test message"
    record.exc_info = sys.exc_info()
    assert formatter.format(record).startswith(
        "[I /path/to/file.py:42] test message\n    Exception: "
    )
    record.exc_info = None
    record.msg = "test\x00message"

# Generated at 2022-06-18 10:24:27.639525
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import unittest
    import tempfile
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tempdir, "test.log")
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"

# Generated at 2022-06-18 10:24:33.870349
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/Users/benjamin/anaconda3/lib/python3.7/site-packages/tornado/web.py",
        lineno=1689,
        msg="500 GET / (::1) 1.00ms",
        args=(),
        exc_info=None,
    )
    print(formatter.format(record))


# Generated at 2022-06-18 10:25:06.788179
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""



# Generated at 2022-06-18 10:25:13.555749
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(
        fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={
            logging.DEBUG: 4,
            logging.INFO: 2,
            logging.WARNING: 3,
            logging.ERROR: 1,
            logging.CRITICAL: 5,
        },
    )
    assert form

# Generated at 2022-06-18 10:25:22.796946
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

# Generated at 2022-06-18 10:25:24.183453
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:25:36.909646
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:25:49.148805
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, fmt="%(message)s")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors != {}

# Generated at 2022-06-18 10:25:57.213612
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    # test the constructor of LogFormatter
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    # test the constructor of LogFormatter with color support
    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    # test the constructor of LogFormatter with custom format

# Generated at 2022-06-18 10:26:08.712525
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:26:18.665035
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    assert LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT
    assert LogFormatter().datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert LogFormatter()._colors == LogFormatter.DEFAULT_COLORS
    assert LogFormatter()._normal == ""

    assert LogFormatter(color=False)._colors == {}
    assert LogFormatter(color=False)._normal == ""

    assert LogFormatter(color=True, colors={})._colors == {}
    assert LogFormatter(color=True, colors={})._normal == ""

    assert LogFormatter(color=True, colors={1: 2})._colors == {1: "\033[2;3%dm" % 2}

# Generated at 2022-06-18 10:26:28.920464
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(datefmt="%Y-%m-%d %H:%M:%S")
    assert formatter.datefmt == "%Y-%m-%d %H:%M:%S"

    formatter = LogFormatter(fmt="%(asctime)s %(message)s")
    assert formatter._fmt == "%(asctime)s %(message)s"


# Generated at 2022-06-18 10:26:50.317786
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import io
    import unittest
    from unittest import mock

    class TestLogFormatter(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()

        def test_format(self):
            self.handler.setFormatter(LogFormatter())
            self.logger.info("test")

# Generated at 2022-06-18 10:26:56.249309
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            sys.stderr = open(os.devnull, "w")
            self.log_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.log_dir, "test.log")
            self.log_file_prefix = os

# Generated at 2022-06-18 10:27:08.646244
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import sys
    import tempfile
    import unittest
    import warnings

    from tornado.log import app_log, gen_log

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            self.log_file = tempfile.NamedTemporaryFile(delete=False)
            self.log_filename = self.log_file.name
            self.log_file.close()

# Generated at 2022-06-18 10:27:20.967570
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(fmt="%(message)s")
    assert formatter._fmt == "%(message)s"

    formatter = LogFormatter(datefmt="%Y")

# Generated at 2022-06-18 10:27:22.805422
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)


# Generated at 2022-06-18 10:27:34.121325
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            self.log_file = tempfile.NamedTemporaryFile()
            self.log_name = self.log_file.name
            self.log_file.close()
            self

# Generated at 2022-06-18 10:27:46.353489
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2

# Generated at 2022-06-18 10:27:54.010104
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:28:05.060079
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:28:09.139816
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.Logger("test")
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    logger.debug("test")
    logger.info("test")
    logger.warning("test")
    logger.error("test")
    logger.critical("test")


# Generated at 2022-06-18 10:28:34.917741
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:28:46.929085
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipIf
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import mock
    from tornado.test.util import bind_unused_port
    from tornado.test.util import get_async_test_timeout
    from tornado.test.util import AsyncTestCase
    from tornado.test.util import async_test

# Generated at 2022-06-18 10:28:58.242863
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.log_to_stderr = False
            self.options.log_file_prefix = self.log_file
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 1
            self.options.logging = "debug"

# Generated at 2022-06-18 10:29:06.916934
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            self.log_file = tempfile.NamedTemporaryFile(delete=False)
            self.log_file.close()
            self.log_file_name = self.log_file.name
            self.log_file_

# Generated at 2022-06-18 10:29:16.959075
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:29:28.015792
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

# Generated at 2022-06-18 10:29:39.230644
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._

# Generated at 2022-06-18 10:29:47.219056
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import shutil
    import tempfile
    import time
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import PY3

    class LoggingTest(AsyncTestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.log_file = os.path.join(self.tmpdir, "test.log")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file
            self.options.log_to_stderr = False
            self.options.logging

# Generated at 2022-06-18 10:29:56.629791
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.DEBUG, "", 0, "", (), None)
    record.__dict__["message"] = "test"
    record.__dict__["asctime"] = "test"
    record.__dict__["color"] = "test"
    record.__dict__["end_color"] = "test"
    record.__dict__["exc_info"] = "test"
    record.__dict__["exc_text"] = "test"
    assert formatter.format(record) == "[D test test:0] test"


# Generated at 2022-06-18 10:30:07.808476
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")

# Generated at 2022-06-18 10:31:10.132779
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._colors == {}
    assert formatter._normal == "\033[0m"


# Generated at 2022-06-18 10:31:11.135076
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:31:20.863605
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:31:22.721795
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-18 10:31:33.661752
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipIfNoPTY
    from tornado.test.util import skipIf
    from tornado.test.util import expect_warnings
    from tornado.test.util import expect_deprecated_unicode_type
    from tornado.test.util import expect_deprecated_nonzero
    from tornado.test.util import expect_

# Generated at 2022-06-18 10:31:37.589053
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    # Test that the constructor of LogFormatter works with
    # logging.config.dictConfig
    LogFormatter(color=True)
    LogFormatter(color=False)
    LogFormatter(colors={})
    LogFormatter(colors={logging.DEBUG: 4})



# Generated at 2022-06-18 10:31:46.880300
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.logging = "info"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.info("test")
    tornado.log.app_log.warning("test")
    tornado.log.app_log.error("test")
    tornado.log.app_log.critical("test")
    tornado.log.app_log.debug("test")



# Generated at 2022-06-18 10:31:57.459262
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:32:08.011295
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    tornado.options.options.logging = "info"
    enable_pretty_logging()
    tornado.options.options.logging = "warning"
    enable_pretty_logging()
    tornado.options.options.logging = "error"
    enable_pretty_logging()

# Generated at 2022-06-18 10:32:17.113926
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT