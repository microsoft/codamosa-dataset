

# Generated at 2022-06-18 10:23:17.068917
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format (self, record)
    # of class LogFormatter
    # test for format
    formatter = LogFormatter()
    record = logging.makeLogRecord({'msg': 'test'})
    assert formatter.format(record) == '[I %s test] test' % record.asctime
    # test for format with color
    formatter = LogFormatter(color=True)
    record = logging.makeLogRecord({'msg': 'test'})
    assert formatter.format(record) == '[I %s test] test' % record.asctime
    # test for format with color and exc_info
    formatter = LogFormatter(color=True)
    record = logging.makeLogRecord({'msg': 'test', 'exc_info': True})

# Generated at 2022-06-18 10:23:27.239105
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """Test the constructor of class LogFormatter."""
    # Test with default values
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS

    # Test with custom values
    formatter = LogFormatter(
        fmt="%(color)s%(message)s%(end_color)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3},
    )

# Generated at 2022-06-18 10:23:32.043688
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.access",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D 421205 13:46:39 file:42] test message"


# Generated at 2022-06-18 10:23:38.803702
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""
    assert formatter.format(logging.LogRecord("tornado.general", logging.INFO, "", 0, "", (), None)) == "[I "
    assert formatter.format(logging.LogRecord("tornado.general", logging.INFO, "", 0, "", (), None)) == "[I "
    assert formatter.format(logging.LogRecord("tornado.general", logging.INFO, "", 0, "", (), None)) == "[I "

# Generated at 2022-06-18 10:23:50.907222
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_to_stderr = False
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    tornado.options.options.log_file_prefix = None
    tornado.options.options.log_to_stderr = True

# Generated at 2022-06-18 10:23:55.054033
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="",
        lineno=0,
        msg="test",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D %s tornado.general:0] test" % record.asctime



# Generated at 2022-06-18 10:24:08.262149
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import tornado.escape
    import tornado.util
    import tornado.log
    import tornado.options
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import tornado.iostream
    import tornado.tcpserver
    import tornado.gen
    import tornado.queues
    import tornado.stack_context
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.http1connection
    import tornado.http2connection
    import tornado.httputil
    import tornado.iostream
    import tornado.log
    import tornado.netutil
    import tornado.process

# Generated at 2022-06-18 10:24:11.706723
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""


# Generated at 2022-06-18 10:24:22.921166
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:24:33.404474
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for the case when color is enabled
    formatter = LogFormatter(color=True)
    record = logging.LogRecord(
        name="tornado.access",
        level=logging.INFO,
        pathname="some/path",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    # The exact formatting may change depending on color support,
    # so we just check that some key strings are in the right places.
    assert "[INFO" in formatter.format(record)
    assert "hello" in formatter.format(record)
    assert "some/path" in formatter.format(record)
    assert "line 42" in formatter.format(record)

    # test for the case when

# Generated at 2022-06-18 10:24:50.357500
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()
    LogFormatter(color=False)
    LogFormatter(color=True)
    LogFormatter(color=True, colors={logging.DEBUG: 1})
    LogFormatter(color=True, colors={logging.DEBUG: 1}, fmt="%(message)s")
    LogFormatter(color=True, colors={logging.DEBUG: 1}, fmt="%(message)s", datefmt="%Y")


# Generated at 2022-06-18 10:25:00.636438
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug("test")
    tornado.log.app_log.info("test")
    tornado.log.app_log.warning("test")
    tornado.log.app_log.error("test")
    tornado.log.app_log.critical("test")
   

# Generated at 2022-06-18 10:25:10.378427
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:25:15.240818
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS

# Generated at 2022-06-18 10:25:25.006925
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter

# Generated at 2022-06-18 10:25:32.151083
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="test",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %s tornado.general:0] test" % (
        record.asctime,
    )


# Generated at 2022-06-18 10:25:42.803799
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:25:53.436466
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import time
    import unittest

    class TestHandler(logging.handlers.MemoryHandler):
        def __init__(self, capacity, flushLevel, target):
            logging.handlers.MemoryHandler.__init__(self, capacity, flushLevel, target)
            self.setLevel(logging.NOTSET)

        def shouldFlush(self, record):
            return 1

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            self.test_logger = logging.getLogger("test_logger")
            self.test_logger.setLevel(logging.DEBUG)
            self.test_handler = TestHandler(10, logging.ERROR, sys.stdout)


# Generated at 2022-06-18 10:25:59.202007
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    tornado.options.options.logging = "info"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_

# Generated at 2022-06-18 10:26:10.634321
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings

    class TestLogFormatter(unittest.TestCase):
        def test_format(self):
            formatter = tornado.log.LogFormatter()
            record = logging.LogRecord("foo", logging.INFO, "/fake/path", 42, "bar", (), None)
            self.assertEqual(formatter.format(record), "[I /fake/path:42] bar")

    class TestEnablePrettyLogging(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options

# Generated at 2022-06-18 10:26:30.098729
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)
    assert isinstance(formatter._fmt, str)
    assert isinstance(formatter._colors, dict)
    assert isinstance(formatter._normal, str)


# Generated at 2022-06-18 10:26:41.201754
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            sys.stderr = open(os.devnull, "w")
            self.log_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 10:26:50.713552
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.log_dir, "test.log")
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            sys.stderr = sys.stdout = open(os.devnull, "w")

        def tearDown(self):
            sys.stderr = self.stderr
            sys.stdout = self.stdout
            shutil.rmtree(self.log_dir)


# Generated at 2022-06-18 10:27:01.981707
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""


# Generated at 2022-06-18 10:27:14.339103
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._

# Generated at 2022-06-18 10:27:26.750770
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log_file_prefix"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)

# Generated at 2022-06-18 10:27:37.646637
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:27:49.597225
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:28:01.842482
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = False
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging()
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 10:28:11.232539
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d %H:%M:%S"

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}

    form

# Generated at 2022-06-18 10:29:05.321405
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import tornado.escape
    import tornado.log
    import tornado.util
    import typing
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:29:15.373145
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tmpdir, "test.log")
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"
            self.options.log_rotate_

# Generated at 2022-06-18 10:29:25.073645
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(
        fmt="%(color)s%(message)s%(end_color)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3},
    )
    assert formatter._fmt == "%(color)s%(message)s%(end_color)s"

# Generated at 2022-06-18 10:29:36.315783
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}

    formatter = LogFormatter(color=True)
    assert formatter._colors != {}

    formatter = LogFormatter(color=True, colors={})
    assert formatter._colors == {}

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._colors == {logging.DEBUG: "\033[2;3%dm" % 1}



# Generated at 2022-06-18 10:29:44.838472
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._colors != {}
    assert formatter._normal != ""



# Generated at 2022-06-18 10:29:57.545919
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import tempfile
    import shutil
    import unittest
    import warnings
    import io
    import contextlib
    import re
    import functools
    import datetime
    import platform
    import subprocess
    import textwrap
    import threading
    from tornado.util import PY3
    from tornado.util import b
    from tornado.util import u
    from tornado.util import ObjectDict
    from tornado.util import exec_in
    from tornado.util import unicode_type
    from tornado.util import basestring_type
    from tornado.util import bytes_type
    from tornado.util import Configurable
    from tornado.util import import_object

# Generated at 2022-06-18 10:30:09.198988
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log

    tornado.options.define("logging", default="debug", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_to_stderr", default=False, help="log to stderr")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_rotate_when", default="S", help="log rotate when")
    tornado.options.define("log_rotate_interval", default=1, help="log rotate interval")
    tornado.options.define("log_file_max_size", default=100, help="log file max size")

# Generated at 2022-06-18 10:30:18.573085
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._normal == "\033[0m"



# Generated at 2022-06-18 10:30:28.890995
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="info", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_to_stderr", default=False, help="log to stderr")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100000, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="D", help="log rotate when")

# Generated at 2022-06-18 10:30:38.552864
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-18 10:32:11.398882
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:32:20.890844
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.log_file_prefix = os.path.join(self.tmpdir, "test_log")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file_prefix
            self.options.log_to_stderr = False
            self.options.log_rotate_mode = "time"
            self.options.log_rotate_when = "S"
            self.options.log_rotate_interval = 1

# Generated at 2022-06-18 10:32:30.054981
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)
    assert isinstance(logging.getLogger().handlers[1], logging.StreamHandler)

# Generated at 2022-06-18 10:32:37.446698
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:32:48.445228
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            self.log_file = tempfile.NamedTemporaryFile()
            self.log_name = self.log_file.name
            sys.stderr = open(os.devnull, "w")