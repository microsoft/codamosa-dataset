

# Generated at 2022-06-18 10:23:07.593800
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.DEBUG, "", 0, "", (), None)
    record.message = "test"
    record.asctime = "test"
    record.levelno = logging.DEBUG
    record.exc_info = None
    record.exc_text = None
    assert formatter.format(record) == "[D test tornado.access:0] test"


# Generated at 2022-06-18 10:23:17.874135
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I 20070827 22:59:26 file.py:42] hello"
    record.msg = "hello\nthere"
    assert formatter.format(record) == "[I 20070827 22:59:26 file.py:42] hello\n    there"
    record.exc_info = sys.exc_info()

# Generated at 2022-06-18 10:23:25.425964
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-18 10:23:30.782128
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:23:37.940979
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:23:50.076948
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:01.605286
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import unittest
    import tempfile
    import io
    import re
    import warnings
    import contextlib
    import functools
    import datetime
    import platform
    import subprocess
    import threading
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread

# Generated at 2022-06-18 10:24:05.540149
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:15.732831
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            sys.stderr = sys.stdout = open(os.devnull, "w")
            self.add

# Generated at 2022-06-18 10:24:28.082925
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("debug")
    gen_log.info("info")
    gen_log.warning("warning")
    gen_log.error("error")

# Generated at 2022-06-18 10:24:42.205557
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for the case when record.message is a string
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    formatter = LogFormatter()
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"
    # test for the case when record.message is a byte string

# Generated at 2022-06-18 10:24:54.385930
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:25:00.544325
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"


# Generated at 2022-06-18 10:25:10.377957
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for the case when record.message is a string
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="",
        lineno=0,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D %(asctime)s :0] test message"
    # test for the case when record.message is a unicode string

# Generated at 2022-06-18 10:25:19.988500
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", type=str)
    tornado.options.define("log_file_prefix", default=None, type=str)
    tornado.options.define("log_rotate_mode", default="size", type=str)
    tornado.options.define("log_rotate_when", default="S", type=str)
    tornado.options.define("log_rotate_interval", default=1, type=int)
    tornado.options.define("log_file_max_size", default=100, type=int)
    tornado.options.define("log_file_num_backups", default=10, type=int)
    tornado.options.define("log_to_stderr", default=None, type=bool)

# Generated at 2022-06-18 10:25:24.235098
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.general", logging.DEBUG, "", 0, "test", None, None
    )
    assert formatter.format(record) == "[D %s tornado.general:0] test" % (
        record.asctime,
    )



# Generated at 2022-06-18 10:25:36.910245
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, fmt="%(message)s")
    assert formatter._fmt == "%(message)s"

    formatter = LogFormatter(color=True, datefmt="%Y-%m-%d %H:%M:%S")
    assert formatter

# Generated at 2022-06-18 10:25:40.742700
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    from tornado.log import LogFormatter
    from tornado.log import access_log, app_log, gen_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import access_log, app_log, gen_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import access_log, app_log, gen_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _

# Generated at 2022-06-18 10:25:52.024253
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", type=str)
    tornado.options.define("log_file_prefix", default=None, type=str)
    tornado.options.define("log_rotate_mode", default="size", type=str)
    tornado.options.define("log_file_max_size", default=100, type=int)
    tornado.options.define("log_file_num_backups", default=10, type=int)
    tornado.options.define("log_rotate_when", default="D", type=str)
    tornado.options.define("log_rotate_interval", default=1, type=int)
    tornado.options.define("log_to_stderr", default=True, type=bool)

# Generated at 2022-06-18 10:26:03.472945
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.logging = "info"
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.info("test")
    tornado.log.access_log.info("test")
    tornado.log.gen_

# Generated at 2022-06-18 10:26:33.047958
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:26:33.984938
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-18 10:26:46.136882
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import time
    import unittest
    import warnings

    class TestHandler(logging.Handler):
        def __init__(self):
            logging.Handler.__init__(self)
            self.records = []  # type: List[Any]

        def emit(self, record):
            self.records.append(record)

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            self.handler = TestHandler()
            self.handler.setFormatter(LogFormatter())
            self.logger = logging.getLogger("tornado.test")
            self.logger.propagate = False
            self.logger.addHandler(self.handler)


# Generated at 2022-06-18 10:26:55.382386
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:27:07.548842
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:27:14.569689
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D 180101 00:00:00 file:42] hello"



# Generated at 2022-06-18 10:27:23.989729
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "info"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.info("test_enable_pretty_logging")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:27:35.377394
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import AsyncIOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback

# Generated at 2022-06-18 10:27:48.161632
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")
    app_log.debug("test")
    app_log.info("test")
    app_log.warning("test")
   

# Generated at 2022-06-18 10:28:00.194682
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    import io
    import functools
    import contextlib
    import threading
    import concurrent.futures
    import subprocess
    import platform
    import re
    import socket
    import errno
    import stat
    import signal
    import datetime
    import traceback
    import collections
    import weakref
    import gc
    import types
    import numbers
    import pickle
    import copy
    import inspect
    import abc
    import asyncio
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures._base

# Generated at 2022-06-18 10:28:42.061120
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file_prefix = os.path.join(self.temp_dir, "test_log")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file_prefix
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.logger = logging.getLogger()
            self.logger.setLevel(logging.DEBUG)
            self.logger.handlers = []
            self.logger

# Generated at 2022-06-18 10:28:50.946528
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d", color=False)
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == {}
    assert formatter.datefmt == "%Y-%m-%d"



# Generated at 2022-06-18 10:29:00.746676
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.logging = "debug"
            self.options.log_to_stderr = False
            self.options.log_file_prefix = self.log_file
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"
            self.options.log_rotate_

# Generated at 2022-06-18 10:29:06.689415
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()
    LogFormatter(color=False)
    LogFormatter(color=True)
    LogFormatter(color=True, colors={})
    LogFormatter(color=True, colors={logging.DEBUG: 1})
    LogFormatter(color=True, colors={logging.DEBUG: 1, logging.INFO: 2})
    LogFormatter(color=True, colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3})
    LogFormatter(color=True, colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 4})

# Generated at 2022-06-18 10:29:16.740119
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:29:27.747186
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="test",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I " + record.asctime + " ] test"
    record.levelno = logging.ERROR
    assert formatter.format(record) == "[E " + record.asctime + " ] test"
    record.levelno = logging.CRITICAL
    assert formatter.format(record) == "[C " + record.asctime + " ] test"
    record.levelno = logging.DEBUG

# Generated at 2022-06-18 10:29:38.638040
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:29:46.861236
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:56.226466
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:30:03.504482
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test that the LogFormatter class works as expected
    # Create a LogFormatter object
    formatter = LogFormatter()
    # Create a record object
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="",
        lineno=0,
        msg="",
        args=(),
        exc_info=None,
    )
    # Call the format method
    formatter.format(record)



# Generated at 2022-06-18 10:30:38.259997
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.stderr = sys.stderr
            self.stdout = sys.stdout

# Generated at 2022-06-18 10:30:49.809880
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import unittest
    import logging
    import logging.handlers
    import io
    import sys

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setFormatter(LogFormatter())
            self.logger = logging.getLogger("tornado.test")
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()

        def test_format(self):
            self.logger.info("test")

# Generated at 2022-06-18 10:30:58.372329
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:31:09.754919
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="S", help="log rotate when")
    tornado.options.define("log_rotate_interval", default=1, help="log rotate interval")

# Generated at 2022-06-18 10:31:16.136037
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"


# Generated at 2022-06-18 10:31:21.766601
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 2
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-18 10:31:33.087730
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:31:40.225950
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.logging = "debug"
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()


# Generated at 2022-06-18 10:31:41.021474
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:31:51.498587
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.log_file = os.path.join(
                self.get_dir(), "test.log"
            )  # type: Optional[str]
            self.log_file_prefix = os.path.join(
                self.get_dir(), "test"
            )  # type: Optional[str]
            self.log_file_max_size = 100
           

# Generated at 2022-06-18 10:32:50.612633
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")