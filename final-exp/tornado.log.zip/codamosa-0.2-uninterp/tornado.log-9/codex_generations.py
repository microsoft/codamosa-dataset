

# Generated at 2022-06-18 10:23:18.013771
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"



# Generated at 2022-06-18 10:23:22.332402
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT



# Generated at 2022-06-18 10:23:32.242248
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="info", help="logging level")
    tornado.options.define("log_file_prefix", default=None, help="log file")
    tornado.options.define("log_to_stderr", default=None, help="log to stderr")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="S", help="log rotate when")

# Generated at 2022-06-18 10:23:38.930295
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2

# Generated at 2022-06-18 10:23:51.033306
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import io
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import PY3

    class LoggingTest(AsyncTestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io = io.StringIO()
            self.handler = logging.StreamHandler(self.io)
            self.handler.setFormatter(tornado.log.LogFormatter())
            self.logger = logging.getLogger()
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)


# Generated at 2022-06-18 10:24:03.416251
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:14.662251
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:24:27.087979
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import time
    import logging
    import logging.handlers
    import tornado.log
    import tornado.ioloop
    import tornado.options
    import tornado.testing

    class TestHandler(logging.handlers.MemoryHandler):
        def shouldFlush(self, record: Any) -> bool:
            return False

    class LogFormatterTest(tornado.testing.AsyncTestCase):
        def setUp(self) -> None:
            super(LogFormatterTest, self).setUp()
            self.log_handler = TestHandler(capacity=100)
            self.log_handler.setFormatter(tornado.log.LogFormatter())
            self.logger = logging.getLogger()
            self.logger.addHandler(self.log_handler)


# Generated at 2022-06-18 10:24:36.085882
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:45.495044
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import colorama
    import curses
    import io
    import unittest
    import os
    import tempfile
    import time
    import threading
    import warnings
    import re

    class TestHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super(TestHandler, self).__init__(*args, **kwargs)
            self.records = []  # type: List[logging.LogRecord]

        def emit(self, record):
            self.records.append(record)

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            self.handler = TestHandler()

# Generated at 2022-06-18 10:25:04.033652
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:25:15.318766
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT


# Generated at 2022-06-18 10:25:25.058408
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS

# Generated at 2022-06-18 10:25:37.855758
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:25:49.768285
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:25:57.529647
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "none"
    enable_pretty_logging()
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    tornado.options.options.logging = "info"
    enable_pretty_logging()
    tornado.options.options.logging = "warning"
    enable_pretty_logging()
    tornado.options.options.logging = "error"
    enable_pretty_logging()
    tornado.options.options.logging = "critical"
    enable_pretty_logging()
    tornado.options.options.logging = "none"
    enable_pretty_logging()
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    tornado.options.options.logging

# Generated at 2022-06-18 10:26:08.964722
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    define("logging", default="none", help="logging level")
    define("log_file_prefix", default="", help="log file prefix")
    define("log_file_max_size", default=100, help="log file max size")
    define("log_file_num_backups", default=10, help="log file num backups")
    define("log_rotate_mode", default="size", help="log rotate mode")
    define("log_rotate_when", default="D", help="log rotate when")
    define("log_rotate_interval", default=1, help="log rotate interval")
    define("log_to_stderr", default=False, help="log to stderr")
    options.parse_command_line()
    enable

# Generated at 2022-06-18 10:26:18.862297
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS

# Generated at 2022-06-18 10:26:29.088259
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DE

# Generated at 2022-06-18 10:26:34.208136
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-18 10:27:20.493661
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_to_stderr", default=False, help="log to stderr")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_rotate_when", default="S", help="log rotate when")
    tornado.options.define("log_rotate_interval", default=1, help="log rotate interval")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")

# Generated at 2022-06-18 10:27:31.682610
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="debug", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100, help="max size of log file")
    tornado.options.define("log_file_num_backups", default=10, help="number of log file backups")
    tornado.options.define("log_rotate_when", default="D", help="log rotate when")
    tornado.options.define("log_rotate_interval", default=1, help="log rotate interval")

# Generated at 2022-06-18 10:27:43.540573
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:27:50.396226
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LogTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.log_file_prefix = os.path.join(self.tmpdir, "test_log")
            self.options = tornado.options.options
            self.options.log_to_stderr = False
            self.options.log_file_prefix = self.log_file_prefix
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"
            self.options.log

# Generated at 2022-06-18 10:28:02.638270
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tempdir, "test.log")
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3

# Generated at 2022-06-18 10:28:10.612682
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-18 10:28:17.506642
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import access_log
   

# Generated at 2022-06-18 10:28:23.985714
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="midnight", help="log rotate when")
    tornado.options.define("log_rotate_interval", default=1, help="log rotate interval")

# Generated at 2022-06-18 10:28:33.311326
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    from tornado.options import define, options
    define("logging", default="debug")
    define("log_file_prefix", default="")
    define("log_file_max_size", default=0)
    define("log_file_num_backups", default=0)
    define("log_rotate_mode", default="size")
    define("log_rotate_when", default="midnight")
    define("log_rotate_interval", default=1)
    define("log_to_stderr", default=False)
    tornado.options.parse_command_line()
    tornado.log.enable_pretty_logging(options)
    tornado.log.app_log.info("test")


# Generated at 2022-06-18 10:28:43.475631
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:29.200044
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:40.338328
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:47.790044
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:59.828533
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    from tornado.options import options, define, parse_command_line

    define("logging", default="debug")
    parse_command_line(["--logging=debug"])
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    define("logging", default="none")
    parse_command_line(["--logging=none"])
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == LogFormatter.DEFAULT_D

# Generated at 2022-06-18 10:30:11.370553
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:30:19.770163
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import time
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.log_path = self.get_log_path()
            self.options = tornado.options.options
            self.options.log_to_stderr = False
            self.options.log_file_prefix = self.log_path
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options

# Generated at 2022-06-18 10:30:20.606402
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:30:31.615911
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tempdir, "test.log")
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"

# Generated at 2022-06-18 10:30:43.120682
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.log_file_prefix = 'test.log'
    tornado.options.options.log_rotate_mode = 'size'
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.logging = 'debug'
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug('test')
    tornado.log.app_log.info('test')
    tornado.log.app_log.warning('test')
    tornado.log.app_log.error('test')
    tornado.log.app_log.critical('test')
    tornado.log.app_log.exception('test')

# Generated at 2022-06-18 10:30:54.194089
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import time
    import unittest
    from tornado.options import define, options
    define("logging", default="none", help="logging level", type=str)
    define("log_file_prefix", default="", help="log file prefix", type=str)
    define("log_rotate_mode", default="", help="log rotate mode", type=str)
    define("log_rotate_when", default="", help="log rotate when", type=str)
    define("log_rotate_interval", default=0, help="log rotate interval", type=int)

# Generated at 2022-06-18 10:32:52.877727
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")