

# Generated at 2022-06-18 10:23:11.525742
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", type=str, help="logging level")
    tornado.options.define("log_file_prefix", default="", type=str, help="log file prefix")
    tornado.options.define("log_to_stderr", default=False, type=bool, help="log to stderr")
    tornado.options.define("log_rotate_mode", default="size", type=str, help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100*1024*1024, type=int, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, type=int, help="log file num backups")

# Generated at 2022-06-18 10:23:20.912982
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:23:30.969685
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.access",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] hello"
    record.exc_info = sys.exc_info()
    assert formatter.format(record) == "[I /path/to/file.py:42] hello\n    Traceback (most recent call last):\n      File \"/path/to/file.py\", line 42, in <module>\n        hello\n    NameError: name 'hello' is not defined"

# Generated at 2022-06-18 10:23:38.092083
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:23:50.206777
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import time
    import unittest
    import warnings

    class TestHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super(TestHandler, self).__init__(*args, **kwargs)
            self.records = []  # type: List[logging.LogRecord]

        def emit(self, record: logging.LogRecord) -> None:
            self.records.append(record)

    class LogFormatterTest(unittest.TestCase):
        def setUp(self) -> None:
            self.logger = logging.getLogger()
            self.logger.setLevel(logging.DEBUG)
            self.handler = TestHandler()

# Generated at 2022-06-18 10:23:52.804633
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """
    >>> LogFormatter()  # doctest: +ELLIPSIS
    <tornado.log.LogFormatter object at 0x...>
    """
    pass



# Generated at 2022-06-18 10:24:05.719349
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import datetime
    import logging
    import sys
    import unittest

    class TestHandler(logging.Handler):
        def __init__(self):
            # type: () -> None
            logging.Handler.__init__(self)
            self.records = []  # type: Any

        def emit(self, record):
            # type: (Any) -> None
            self.records.append(record)

    class TestLogFormatter(LogFormatter):
        def __init__(self):
            # type: () -> None
            LogFormatter.__init__(self, color=False)


# Generated at 2022-06-18 10:24:15.851021
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={1: 1})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:24:28.169117
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = False
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging()
    assert len(logger.handlers) == 1

# Generated at 2022-06-18 10:24:34.259789
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"


# Generated at 2022-06-18 10:24:55.401233
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test that the format method of LogFormatter works correctly
    # Create a LogFormatter object
    formatter = LogFormatter()
    # Create a record
    record = logging.LogRecord(name="test", level=logging.DEBUG, pathname="test", lineno=1, msg="test", args=None, exc_info=None)
    # Call the format method
    formatter.format(record)
    # Check that the message is correct
    assert record.message == "test"
    # Check that the asctime is correct
    assert record.asctime == formatter.formatTime(record, formatter.datefmt)
    # Check that the color is correct
    assert record.color == formatter._colors[record.levelno]
    # Check that the end_color is correct
    assert record.end_color == form

# Generated at 2022-06-18 10:25:00.497542
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.access",
        logging.INFO,
        "/path/to/some/file.py",
        123,
        "message",
        None,
        None,
    )
    assert formatter.format(record) == "[I 1234567890 /path/to/some/file.py:123] message"



# Generated at 2022-06-18 10:25:10.338971
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:25:19.952881
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORM

# Generated at 2022-06-18 10:25:30.909333
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d %H:%M:%S"

    formatter = LogFormatter(color=False)

# Generated at 2022-06-18 10:25:43.766427
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import io
    import sys
    import time
    import datetime
    import threading
    import tornado.log
    import tornado.escape
    import tornado.util
    import tornado.options
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import tornado.iostream
    import tornado.tcpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.stack_context
    import tornado.testing
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.test.httpserver_test
    import tornado.test.routing_test
    import tornado

# Generated at 2022-06-18 10:25:54.180484
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:26:05.833184
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(
        fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={
            logging.DEBUG: 7,
            logging.INFO: 6,
            logging.WARNING: 4,
            logging.ERROR: 1,
            logging.CRITICAL: 5,
        },
    )

# Generated at 2022-06-18 10:26:16.474249
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter

# Generated at 2022-06-18 10:26:24.525664
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:26:49.228142
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT


# Generated at 2022-06-18 10:27:00.345154
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(
        fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3},
    )
    assert formatter.datefmt == "%Y-%m-%d %H:%M:%S"

# Generated at 2022-06-18 10:27:12.415528
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:27:20.599110
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s" % record.__dict__


# Generated at 2022-06-18 10:27:23.184937
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    # Test that the constructor of LogFormatter works
    formatter = LogFormatter()
    assert formatter is not None


# Generated at 2022-06-18 10:27:34.498428
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:27:47.521331
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:27:58.885335
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug("test")
    tornado.log.app_log.info("test")
    tornado.log.app_log.warning("test")
    tornado.log.app_log.error("test")
    tornado.log.app_log.critical("test")



# Generated at 2022-06-18 10:28:08.966890
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", type=str, help="logging")
    tornado.options.define("log_file_prefix", default="", type=str, help="log_file_prefix")
    tornado.options.define("log_rotate_mode", default="size", type=str, help="log_rotate_mode")
    tornado.options.define("log_file_max_size", default=100, type=int, help="log_file_max_size")
    tornado.options.define("log_file_num_backups", default=10, type=int, help="log_file_num_backups")
    tornado.options.define("log_rotate_when", default="S", type=str, help="log_rotate_when")


# Generated at 2022-06-18 10:28:11.455148
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D 161201 00:00:00 file:42] test message"


# Generated at 2022-06-18 10:28:30.350113
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.util import b
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setFormatter(tornado.log.LogFormatter())
            self.logger = logging.getLogger()
            self.logger.addHandler(self.handler)
            self.logger

# Generated at 2022-06-18 10:28:37.770656
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.options = tornado.options.options
            self.options.logging = "debug"
            self.options.log_to_stderr = False
            self.options.log_file_prefix = None
            self.options.log_file_max_size = None

# Generated at 2022-06-18 10:28:49.521345
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.old_log_file_prefix = tornado.options.options.log_file_prefix
            self.old_log_rotate_mode = tornado.options.options.log_rotate_mode
            self.old_log_rotate_when = tornado.options.options.log_rotate_when
            self.old_log_rotate_interval = tornado.options.options.log_rotate_interval


# Generated at 2022-06-18 10:29:00.151762
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:29:09.600953
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.parse_command_line(["--logging=debug"])
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug("test")
    tornado.log.app_log.info("test")
    tornado.log.app_log.warning("test")
    tornado.log.app_log.error("test")
    tornado.log.app_log.critical("test")
    tornado.log.app_log.exception("test")
    tornado.log.app_log.error("test", exc_info=True)
    tornado.log.app_log.error("test", exc_info=False)
    tornado.log.app_log.error("test", exc_info=None)

# Generated at 2022-06-18 10:29:11.049974
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:29:20.745551
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file prefix")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="S", help="log rotate when")
    tornado.options.define("log_rotate_interval", default=1, help="log rotate interval")

# Generated at 2022-06-18 10:29:28.597873
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "log_file_prefix"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-18 10:29:39.721952
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.util import b

    def get_log_file_name(log_file_prefix, log_rotate_mode, rotate_time):
        if log_rotate_mode == "time":
            return log_file_prefix + "." + rotate_time.strftime("%Y%m%d%H%M%S")
        else:
            return log_file_prefix


# Generated at 2022-06-18 10:29:47.492916
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_rotate_mode = "size"
            self.options.log_file_max_size = 100

# Generated at 2022-06-18 10:30:07.133421
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:30:17.044391
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:30:27.710440
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIf

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()

# Generated at 2022-06-18 10:30:28.340855
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:30:39.920299
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:30:50.942972
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipIfNoPymongo
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipIfNoIPv6
    from tornado.test.util import skipOnAppEngine
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoPymongo
    from tornado.test.util import skipIfNoIPv6

# Generated at 2022-06-18 10:30:59.099663
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class LoggingTest(AsyncTestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.tempdir = tempfile.mkdtemp()
            self.log_file_name = os.path.join(self.tempdir, "test.log")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file_name
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options

# Generated at 2022-06-18 10:31:00.226932
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-18 10:31:10.787930
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:31:16.820864
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I 180913 14:00:00 file.py:42] hello"


# Generated at 2022-06-18 10:31:36.653818
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)
    assert isinstance(logging.getLogger().handlers[1], logging.StreamHandler)

# Generated at 2022-06-18 10:31:46.170124
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")
    gen_log.exception("test")
    gen_log.error("test", exc_info=True)
    gen_log

# Generated at 2022-06-18 10:31:57.159100
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.stderr = sys.stderr
            sys.stderr = open(os.devnull, "w")

# Generated at 2022-06-18 10:32:01.142788
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS


# Generated at 2022-06-18 10:32:09.792756
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"
    record.exc_info = sys.exc_info()

# Generated at 2022-06-18 10:32:19.416182
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:32:28.448521
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:32:36.490612
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT


# Generated at 2022-06-18 10:32:47.654293
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    import logging
    import sys
    import unittest
    from tornado.log import LogFormatter
    from tornado.util import _unicode
    class TestHandler(logging.Handler):
        def __init__(self):
            logging.Handler.__init__(self)
            self.records = []  # type: List[logging.LogRecord]
        def emit(self, record):
            self.records.append(record)
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.handler = TestHandler()
            self.handler.setFormatter(LogFormatter())
            self.logger = logging.getLogger()
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)