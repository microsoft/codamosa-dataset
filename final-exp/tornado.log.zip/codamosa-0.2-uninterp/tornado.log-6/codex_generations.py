

# Generated at 2022-06-18 10:23:10.892712
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert formatter.DEFAULT_COLORS == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }



# Generated at 2022-06-18 10:23:20.609976
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:23:21.542435
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()

# Generated at 2022-06-18 10:23:31.494568
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from typing import Dict, Any, cast, Optional
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:23:36.197671
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"


# Generated at 2022-06-18 10:23:48.397695
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    import logging
    import unittest
    import warnings
    from tornado.log import LogFormatter
    from tornado.util import _unicode
    class TestLogFormatter(unittest.TestCase):
        def setUp(self):
            self.formatter = LogFormatter()
        def test_format(self):
            record = logging.LogRecord(
                "tornado.test",
                logging.INFO,
                "/fake/path",
                123,
                "message",
                None,
                None,
            )
            record.created = datetime.datetime(2012, 1, 1, 1, 1, 1, 1)
            self.assertEqual(
                self.formatter.format(record),
                "[I 010101 01:01:01 test:123] message",
            )
           

# Generated at 2022-06-18 10:23:55.580263
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d")
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter._fmt == "%(message)s"
    assert formatter.datefmt == "%Y-%m-%d"



# Generated at 2022-06-18 10:24:08.558664
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.log_file_prefix = os.path.join(self.dir, "test_log")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file_prefix
            self.options.log_to_stderr = False
            self.options.log_rotate_mode = "time"
            self.options.log_rotate_when = "S"

# Generated at 2022-06-18 10:24:17.781532
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            enable_pretty_logging()
            self.logger = logging.getLogger()


# Generated at 2022-06-18 10:24:30.139868
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:41.951525
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I 180101 00:00:00 file:42] hello"


# Generated at 2022-06-18 10:24:53.863266
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.INFO, "", 0, "", None, None)
    record.__dict__["message"] = "test message"
    record.__dict__["asctime"] = "test asctime"
    record.__dict__["color"] = "test color"
    record.__dict__["end_color"] = "test end_color"
    record.__dict__["exc_info"] = None
    record.__dict__["exc_text"] = None
    record.__dict__["levelname"] = "test levelname"
    record.__dict__["levelno"] = logging.INFO
    record.__dict__["lineno"] = 0
    record.__dict__["module"] = "test module"
    record.__dict__

# Generated at 2022-06-18 10:25:03.988252
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import datetime
    import unittest
    import tempfile
    import shutil
    import io
    import re
    import warnings
    import contextlib
    import functools
    import threading
    import socket
    import select
    import subprocess
    import multiprocessing
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process

# Generated at 2022-06-18 10:25:11.890818
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import access_log
   

# Generated at 2022-06-18 10:25:21.059864
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:25:32.342702
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:25:45.637145
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for normal case
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.access",
        logging.INFO,
        "tornado/log.py",
        42,
        "test message",
        None,
        None,
    )
    assert formatter.format(record) == "[I %s tornado/log.py:42] test message" % (
        record.asctime
    )
    # test for exception case
    record.exc_info = Exception("test exception")
    assert formatter.format(record) == "[I %s tornado/log.py:42] test message\n    test exception" % (  # noqa: E501
        record.asctime
    )



# Generated at 2022-06-18 10:25:55.249573
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:26:07.530353
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:26:17.719429
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""

    log_formatter = LogFormatter(color=False)
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""

    log_formatter = LogFormatter(color=True)
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""

    log_formatter = LogFormatter(colors={})

# Generated at 2022-06-18 10:26:47.687617
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.options import define, options, parse_command_line
    from tornado.log import enable_pretty_logging
    from tornado.log import LogFormatter
    from tornado.log import app_log, access_log, gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter

# Generated at 2022-06-18 10:26:57.918845
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:27:10.866836
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    from tornado.log import LogFormatter
    from tornado.log import gen_log
    from tornado.log import app_log
    from tornado.log import access_log
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import datetime
    import io
    import tempfile
    import unittest
    import warnings
    import re
    import socket
    import threading
    import subprocess
    import shutil
    import contextlib
    import platform
    import functools
    import asyncio
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.f

# Generated at 2022-06-18 10:27:20.254444
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""



# Generated at 2022-06-18 10:27:31.408046
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import unittest

    class TestLogging(unittest.TestCase):
        def setUp(self):
            # Create a temporary directory for log files
            self.log_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.log_dir, "test.log")
            self.log_file_prefix = os.path.join(self.log_dir, "test")
            self.log_file_max_size = 100
            self.log_file_num_backups = 3
            self.log_rotate_when = "S"
            self.log_rotate_interval = 1
            self

# Generated at 2022-06-18 10:27:43.654207
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:27:52.755902
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import sys
    import io
    import unittest
    import time
    import datetime
    import re
    import os
    import tempfile
    import shutil
    import warnings
    import contextlib
    import threading
    import multiprocessing
    import queue
    import socket
    import asyncore
    import asynchat
    import signal
    import subprocess
    import errno
    import select
    import pty
    import fcntl
    import struct
    import termios
    import tty
    import locale
    import atexit
    import weakref
    import gc
    import functools
    import traceback
    import textwrap
    import platform
    import abc
    import collections
    import numbers
    import hashlib

# Generated at 2022-06-18 10:28:04.460296
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import tornado.escape
    import tornado.util
    import tornado.log
    import tornado.options
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import tornado.iostream
    import tornado.stack_context
    import tornado.gen
    import tornado.concurrent
    import tornado.queues
    import tornado.ioloop
    import tornado.iostream
    import tornado.tcpserver
    import tornado.process
    import tornado.locks
    import tornado.netutil
    import tornado.stack_context
    import tornado.tcpclient
    import tornado.simple_httpclient
    import tornado.curl_httpclient


# Generated at 2022-06-18 10:28:13.054373
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3

# Generated at 2022-06-18 10:28:19.061792
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for the case when record.levelno is in self._colors
    # and record.exc_info is not None
    # and record.exc_text is not None
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.INFO, "", 1, "test", (), None)
    record.exc_info = None
    record.exc_text = "test"
    assert formatter.format(record) == "[I 0101 00:00:00 <string>:1] test"
    # test for the case when record.levelno is not in self._colors
    # and record.exc_info is None
    # and record.exc_text is None
    record.levelno = logging.DEBUG
    record.exc_info = None

# Generated at 2022-06-18 10:28:58.500735
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:29:04.746925
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt

# Generated at 2022-06-18 10:29:14.959874
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._

# Generated at 2022-06-18 10:29:24.674613
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:37.188141
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    tornado.log.app_log.debug("debug")
    tornado.log.app_log.info("info")

# Generated at 2022-06-18 10:29:38.267901
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:29:46.628301
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_rotate_when", default="S", help="log rotate when")
    tornado.options.define("log_rotate_interval", default=1, help="log rotate interval")
    tornado.options.define("log_file_max_size", default=100, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")

# Generated at 2022-06-18 10:29:47.887209
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-18 10:29:59.917798
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:30:11.503213
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    record.__dict__["asctime"] = "2019-01-01 00:00:00"
    record.__dict__["color"] = ""
    record.__dict__["end_color"] = ""
    record.__dict__["message"] = "test"
    record.__dict__["exc_info"] = None
    record.__dict__["exc_text"] = None
    assert formatter.format(record) == "[I 20190101 00:00:00 test.py:1] test"
    record.__dict__["exc_info"] = "test"

# Generated at 2022-06-18 10:31:30.678009
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:31:40.115275
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter

# Generated at 2022-06-18 10:31:49.657601
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import io
    import sys
    import time
    import datetime
    import threading
    import socket
    import os
    import re
    import warnings
    import traceback
    import contextlib
    import tempfile
    import shutil
    import unittest.mock
    import weakref
    import gc
    import pickle
    import locale
    import atexit
    import subprocess
    import platform
    import textwrap
    import struct
    import json
    import email.utils
    import email.mime.text
    import email.mime.multipart
    import email.mime.application
    import email.mime.message
    import email.mime.base
    import email.mime.audio

# Generated at 2022-06-18 10:32:01.630332
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import io
    import tempfile
    import shutil
    import threading
    import traceback
    import warnings
    import weakref
    import re
    import gc
    import contextlib
    import socket
    import pickle
    import struct
    import subprocess
    import platform
    import multiprocessing
    import multiprocessing.connection
    import multiprocessing.pool
    import multiprocessing.process
    import multiprocessing.synchronize
    import multiprocessing.util
    import multiprocessing.managers
    import multiprocessing.sharedctypes
    import multiprocessing.heap
    import multiprocessing.dummy
    import multiprocessing

# Generated at 2022-06-18 10:32:10.164038
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:32:19.893803
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)
    assert isinstance(logging.getLogger().handlers[1], logging.StreamHandler)

# Generated at 2022-06-18 10:32:29.112040
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:32:36.869772
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={logging.INFO: 1})
    assert formatter._colors == {logging.INFO: "\033[2;3%dm" % 1}

# Generated at 2022-06-18 10:32:48.050873
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")