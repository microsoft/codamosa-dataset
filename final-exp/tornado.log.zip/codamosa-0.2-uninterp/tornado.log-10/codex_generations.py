

# Generated at 2022-06-18 10:23:20.579581
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    define("logging", default="debug")
    define("log_file_prefix", default="tornado.log")
    define("log_file_max_size", default=100)
    define("log_file_num_backups", default=10)
    define("log_rotate_mode", default="size")
    define("log_rotate_when", default="S")
    define("log_rotate_interval", default=1)
    define("log_to_stderr", default=True)
    enable_pretty_logging()
    assert options.logging == "debug"
    assert options.log_file_prefix == "tornado.log"
    assert options.log_file_max_size == 100
    assert options.log_file_num

# Generated at 2022-06-18 10:23:30.618590
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import PY3
    from tornado.log import enable_pretty_logging, LogFormatter, app_log
    from tornado.options import define, options
    define("logging", default="info", help="log level", type=str)
    define("log_file_prefix", default="", help="log file")
    define("log_to_stderr", default=False, help="log to stderr", type=bool)
    define("log_rotate_mode", default="size", help="log rotate mode", type=str)

# Generated at 2022-06-18 10:23:37.849860
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "log.txt"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2

# Generated at 2022-06-18 10:23:38.782107
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-18 10:23:50.906869
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """
    >>> import logging
    >>> import logging.handlers
    >>> import tornado.log
    >>> import sys
    >>> logger = logging.getLogger()
    >>> logger.setLevel(logging.DEBUG)
    >>> handler = logging.StreamHandler(sys.stdout)
    >>> handler.setFormatter(tornado.log.LogFormatter())
    >>> logger.addHandler(handler)
    >>> logger.debug('debug message')
    [D ...] debug message
    >>> logger.info('info message')
    [I ...] info message
    >>> logger.warning('warning message')
    [W ...] warning message
    >>> logger.error('error message')
    [E ...] error message
    >>> logger.critical('critical message')
    [C ...] critical message
    """
    pass



# Generated at 2022-06-18 10:24:03.206784
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import ObjectDict
    from tornado.log import app_log, gen_log, access_log
    from tornado.log import enable_pretty_logging
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter

# Generated at 2022-06-18 10:24:10.545080
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] hello"



# Generated at 2022-06-18 10:24:18.573695
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d"

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}


# Generated at 2022-06-18 10:24:30.885839
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:24:38.146985
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    import logging
    import logging.handlers
    import sys
    import time
    import unittest
    import warnings
    import io
    import os
    import re
    import socket
    import threading
    import time
    import unittest
    import warnings
    import io
    import os
    import re
    import socket
    import threading
    import time
    import unittest
    import warnings
    import io
    import os
    import re
    import socket
    import threading
    import time
    import unittest
    import warnings
    import io
    import os
    import re
    import socket
    import threading
    import time


# Generated at 2022-06-18 10:25:01.670323
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:25:02.919396
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-18 10:25:11.413774
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for the case that the message is a string
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="test",
        args=None,
        exc_info=None,
    )
    formatter = LogFormatter()
    assert formatter.format(record) == "[I 0 tornado.general:0] test"

    # test for the case that the message is a byte string
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg=b"test",
        args=None,
        exc_info=None,
    )

# Generated at 2022-06-18 10:25:16.129303
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._colors == {}
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={1: 2})

# Generated at 2022-06-18 10:25:20.066128
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.DEBUG, "test.py", 1, "test", None, None)
    assert formatter.format(record) == "[D 170101 00:00:00 test.py:1] test"


# Generated at 2022-06-18 10:25:28.624472
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-18 10:25:42.161636
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""
    assert formatter.format(logging.LogRecord("tornado.test", logging.INFO, "", 0, "", (), None)) == "[I  "
    assert formatter.format(logging.LogRecord("tornado.test", logging.INFO, "", 0, "", (), None)) == "[I  "
    assert formatter.format(logging.LogRecord("tornado.test", logging.INFO, "", 0, "", (), None)) == "[I  "
    assert formatter

# Generated at 2022-06-18 10:25:52.965739
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.util import b

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            self.stderr_fd = sys.stderr.fileno()
            self.stdout_fd = sys.stdout.fileno()

# Generated at 2022-06-18 10:26:03.973295
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:26:12.815164
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        'name',
        logging.DEBUG,
        'pathname',
        1,
        'msg',
        None,
        None
    )
    record.__dict__['color'] = 'color'
    record.__dict__['end_color'] = 'end_color'
    record.__dict__['asctime'] = 'asctime'
    record.__dict__['message'] = 'message'
    assert formatter.format(record) == '[D asctime pathname:1] message'


# Generated at 2022-06-18 10:26:38.857488
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.INFO, "", 0, "", None, None)
    record.__dict__["color"] = "color"
    record.__dict__["end_color"] = "end_color"
    record.__dict__["asctime"] = "asctime"
    record.__dict__["message"] = "message"
    assert formatter.format(record) == "[I asctime :0] message"
    record.__dict__["exc_info"] = "exc_info"
    record.__dict__["exc_text"] = "exc_text"
    assert formatter.format(record) == "[I asctime :0] message\n    exc_text"

# Generated at 2022-06-18 10:26:49.704444
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:27:00.798880
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:27:12.792301
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d"

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}

    formatter = LogFormatter(colors={logging.DEBUG: 1})

# Generated at 2022-06-18 10:27:24.609151
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] test message"
    record.msg = "test message\nwith newline"
    assert formatter.format(record) == "[I /path/to/file.py:42] test message\n    with newline"
    record.exc_info = sys.exc_info()

# Generated at 2022-06-18 10:27:35.963516
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.util import b

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.stderr = sys.stderr
            sys.stderr = open(os.devnull, "w")
            self.addCleanup(setattr, sys, "stderr", self.stderr)
            self

# Generated at 2022-06-18 10:27:48.721096
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:28:01.010483
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:28:10.484377
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:28:17.304013
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:29:19.986188
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.options import define, options
    from tornado.log import enable_pretty_logging
    from tornado.log import LogFormatter
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import access_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import Log

# Generated at 2022-06-18 10:29:31.970664
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:29:42.324445
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.util import b
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIf
    from tornado.log import LogFormatter
    from tornado.log import enable_pretty_logging
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import app_log


# Generated at 2022-06-18 10:29:54.254350
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:30:05.808356
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:30:11.734768
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    logger = logging.getLogger()
    enable_pretty_logging(tornado.options.options, logger)
    assert logger.level == logging.DEBUG
    assert len(logger.handlers) == 2
    assert isinstance(logger.handlers[0], logging.handlers.RotatingFileHandler)

# Generated at 2022-06-18 10:30:17.127873
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I 170101 00:00:00 file:42] test message"


# Generated at 2022-06-18 10:30:27.791092
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    log_formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d")
    assert log_formatter._fmt == "%(message)s"
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""
    assert log_formatter.datefmt == "%Y-%m-%d"

    log_formatter = LogFormatter(color=False)
    assert log_

# Generated at 2022-06-18 10:30:39.247891
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("log_file_prefix", default="test.log")
    tornado.options.define("log_file_max_size", default=1024)
    tornado.options.define("log_file_num_backups", default=3)
    tornado.options.define("log_rotate_mode", default="size")
    tornado.options.define("log_rotate_when", default="D")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_to_stderr", default=True)
    tornado.options.parse_command_line()
    tornado.log.enable_pretty_logging()
    tornado.log.app_log

# Generated at 2022-06-18 10:30:50.406917
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:32:07.127108
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(
        fmt="%(color)s%(asctime)s%(end_color)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={logging.DEBUG: 1, logging.INFO: 2},
    )
    assert formatter._fmt == "%(color)s%(asctime)s%(end_color)s"
    assert formatter._colors == {logging.DEBUG: 1, logging.INFO: 2}
    assert formatter

# Generated at 2022-06-18 10:32:15.998499
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:32:24.498253
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS

# Generated at 2022-06-18 10:32:28.759191
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    enable_pretty_logging(options)

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-18 10:32:34.358517
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/home/ubuntu/tornado/tornado/log.py",
        lineno=8,
        msg="test",
        args=(),
        exc_info=None,
    )
    assert log_formatter.format(record) == "[D 180927 16:38:14 log:8] test"


# Generated at 2022-06-18 10:32:45.406691
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.log_file = tempfile.NamedTemporaryFile()
            self.log_file_name = self.log_file.name
            self.log_file.close()
            self.log_file_prefix = os.path.join(tempfile.gettempdir(), "test")
            self.log_file_max_size = 100
            self.log_file_num_backups = 3
            self.log_rotate_when = "S"
            self