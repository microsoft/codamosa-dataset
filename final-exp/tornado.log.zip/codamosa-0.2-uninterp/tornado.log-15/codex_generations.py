

# Generated at 2022-06-18 10:23:23.907510
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 5
    enable_pretty_logging()
    gen_log.debug("test_enable_pretty_logging")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:23:28.869318
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)
    assert isinstance(formatter._fmt, str)
    assert isinstance(formatter._colors, dict)
    assert isinstance(formatter._normal, str)


# Generated at 2022-06-18 10:23:33.069667
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.info("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:23:44.723071
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import unittest
    from tornado.test.util import unittest
    from tornado.options import define, options, parse_command_line
    from tornado.log import enable_pretty_logging
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode

# Generated at 2022-06-18 10:23:53.738917
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.log_dir, "test.log")
            self.stderr = sys.stderr
            sys.stderr = open(os.devnull, "w")

        def tearDown(self):
            sys.stderr = self.stderr
            shutil.rmtree(self.log_dir)


# Generated at 2022-06-18 10:24:05.558383
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d %H:%M:%S"



# Generated at 2022-06-18 10:24:07.374416
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "", 0, "", (), None)
    assert formatter.format(record) == "[I  1970-01-01 00:00:00 tornado.general:0]  "


# Generated at 2022-06-18 10:24:17.059009
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.logging = "info"
    enable_pretty_logging()
    assert logging.getLogger().level == logging.INFO
    assert len(logging.getLogger().handlers) == 1
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "S"

# Generated at 2022-06-18 10:24:26.212225
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.DEBUG, "", 0, "", (), None)
    record.__dict__["message"] = "test"
    record.__dict__["asctime"] = "test"
    record.__dict__["color"] = "test"
    record.__dict__["end_color"] = "test"
    record.__dict__["exc_info"] = "test"
    record.__dict__["exc_text"] = "test"
    formatter.format(record)


# Generated at 2022-06-18 10:24:35.492629
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:24:54.966804
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    from tornado.log import LogFormatter
    import unittest
    class LogFormatterTest(unittest.TestCase):
        def test_format(self):
            formatter = LogFormatter()
            record = logging.LogRecord(
                name="tornado.test",
                level=logging.INFO,
                pathname="/foo/bar/baz.py",
                lineno=42,
                msg="Test message",
                args=(),
                exc_info=None,
            )
            self.assertEqual(
                formatter.format(record),
                "[I 170101 00:00:00 baz:42] Test message",
            )
    unittest.main()


# Generated at 2022-06-18 10:24:55.900050
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:25:00.264963
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="",
        lineno=0,
        msg="test",
        args=(),
        exc_info=None,
    )
    formatter.format(record)


# Generated at 2022-06-18 10:25:12.243457
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:25:21.447796
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    # test the default value
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"
    # test the value after parse
    options.parse_command_line(["--logging=debug", "--log_to_stderr=True", "--log_file_prefix=test.log"])
   

# Generated at 2022-06-18 10:25:33.306955
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:25:40.048765
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    record = logging.LogRecord(
        "tornado.general",
        logging.INFO,
        "/home/ubuntu/tornado/tornado/log.py",
        42,
        "test message",
        None,
        None,
    )
    assert lf.format(record) == "[I 20170223 21:14:21 log:42] test message"



# Generated at 2022-06-18 10:25:51.157094
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:26:02.009711
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, fmt="%(message)s")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors != {}

# Generated at 2022-06-18 10:26:13.905577
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:26:31.333518
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import sys
    import io
    import time
    import datetime
    import threading

    class TestHandler(logging.Handler):
        def __init__(self):
            logging.Handler.__init__(self)
            self.records = []  # type: List[logging.LogRecord]

        def emit(self, record: logging.LogRecord) -> None:
            self.records.append(record)

    class TestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.handler = TestHandler()
            self.logger = logging.getLogger("test")
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)


# Generated at 2022-06-18 10:26:42.618106
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    tornado.options.options.logging = "info"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_

# Generated at 2022-06-18 10:26:46.271334
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import sys
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.debug("test")
    logger.info("test")
    logger.warning("test")
    logger.error("test")
    logger.critical("test")


# Generated at 2022-06-18 10:26:55.609778
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import tornado.escape
    import tornado.util
    import tornado.log
    import tornado.options
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import tornado.iostream
    import tornado.tcpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.stack_context
    import tornado.concurrent
    import tornado.queues
    import tornado.escape
    import tornado.httputil
    import tornado.http1connection
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
   

# Generated at 2022-06-18 10:27:07.784062
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter

# Generated at 2022-06-18 10:27:20.351487
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:27:31.550762
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:27:43.814723
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:27:52.840009
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:28:04.544891
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:28:23.815668
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] hello"



# Generated at 2022-06-18 10:28:33.470452
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:28:43.852282
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(
        fmt="%(color)s%(message)s%(end_color)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3},
    )
    assert formatter._fmt == "%(color)s%(message)s%(end_color)s"

# Generated at 2022-06-18 10:28:55.325238
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt == LogForm

# Generated at 2022-06-18 10:29:03.146498
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:29:13.098236
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

# Generated at 2022-06-18 10:29:22.943567
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:29:24.037218
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()

# Generated at 2022-06-18 10:29:36.476375
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:29:38.408994
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format (LogFormatter)
    # This method is currently not tested.
    pass



# Generated at 2022-06-18 10:30:11.968738
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for the case when record.levelno in self._colors
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.general", logging.DEBUG, "/home/user/tornado/tornado/log.py", 42, "test", None, None
    )
    record.levelno = logging.DEBUG
    record.color = formatter._colors[record.levelno]
    record.end_color = formatter._normal
    record.asctime = formatter.formatTime(record, formatter.datefmt)
    record.message = _safe_unicode(record.getMessage())
    formatted = formatter._fmt % record.__dict__

# Generated at 2022-06-18 10:30:20.205756
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d %H:%M:%S"

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}

    form

# Generated at 2022-06-18 10:30:31.204481
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import io
    import sys
    import time
    import datetime
    from tornado.log import LogFormatter
    from tornado.log import access_log, app_log, gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import _unicode
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter

# Generated at 2022-06-18 10:30:40.101431
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.INFO, "", 0, "", None, None)
    record.message = "test"
    record.asctime = "test"
    record.color = "test"
    record.end_color = "test"
    record.exc_info = None
    record.exc_text = None
    log_formatter.format(record)
    record.exc_info = "test"
    record.exc_text = "test"
    log_formatter.format(record)


# Generated at 2022-06-18 10:30:51.064354
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test that LogFormatter.format() works with unicode strings
    # and with byte strings.
    import logging
    import io
    import sys
    import unittest

    class TestLogFormatter(unittest.TestCase):
        def setUp(self):
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setFormatter(LogFormatter())
            self.logger = logging.getLogger("test")
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)

        def test_unicode(self):
            self.logger.warning("\u2713")
            self.assertIn("\u2713", self.stream.getvalue())



# Generated at 2022-06-18 10:30:59.150469
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import time
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tmpdir, "test_log")
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"
            self.options.log_to_stderr = False

# Generated at 2022-06-18 10:31:09.839167
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)
            self.log_file = os.path.join(self.test_dir, "test.log")
            self.options = tornado.options.options
            self.options.log_

# Generated at 2022-06-18 10:31:19.638887
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT


# Generated at 2022-06-18 10:31:30.210440
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:31:39.716504
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT