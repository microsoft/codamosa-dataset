

# Generated at 2022-06-18 10:23:10.121645
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/home/user/tornado/tornado/log.py",
        lineno=122,
        msg="test message",
        args=None,
        exc_info=None,
    )
    assert formatter.format(record) == "[D 160101 00:00:00 log:122] test message"


# Generated at 2022-06-18 10:23:10.968054
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:23:13.413345
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for colorama
    # test for curses
    pass



# Generated at 2022-06-18 10:23:22.613687
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name='tornado.access',
        level=logging.DEBUG,
        pathname='/home/ubuntu/tornado/tornado/log.py',
        lineno=74,
        msg='200 GET /static/favicon.ico (::1) 1.00ms',
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == '[D 171205 11:54:37 log:74] 200 GET /static/favicon.ico (::1) 1.00ms'

# Generated at 2022-06-18 10:23:32.515339
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.log_to_stderr = False
            self.options.log_file_prefix = self.log_file
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3

# Generated at 2022-06-18 10:23:43.876790
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:23:49.456172
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/home/user/tornado/tornado/log.py",
        lineno=100,
        msg="test",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D 100 log:100] test"



# Generated at 2022-06-18 10:23:56.757173
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:10.261206
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")

# Generated at 2022-06-18 10:24:18.449860
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.options = tornado.options.options
            self.options.logging = "debug"
            self.options.log_to_stderr = False
            self.options.log_file_prefix = None
            self.options.log_rotate_mode = "size"

# Generated at 2022-06-18 10:24:40.870067
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import tempfile
    import shutil

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            self.dirname = tempfile.mkdtemp()
            self.filename = os.path.join(self.dirname, "test.log")
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.stream = sys.stdout
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setFormatter(LogFormatter())
            self.logger.addHandler(self.handler)
            self.logger.propagate = False


# Generated at 2022-06-18 10:24:52.359354
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_file_prefix", default="test.log")
    tornado.options.define("log_rotate_mode", default="size")
    tornado.options.define("log_file_max_size", default=1024)
    tornado.options.define("log_file_num_backups", default=3)
    tornado.options.define("log_rotate_when", default="S")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.define("log_to_stderr", default=True)
    tornado.options.parse_command_line()
    tornado.log.enable_pretty_logging()
    tornado.log.app_log

# Generated at 2022-06-18 10:25:02.905015
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class TestEnablePrettyLogging(unittest.TestCase):
        def setUp(self):
            self.options = tornado.options.options
            self.options.logging = "debug"
            self.options.log_to_stderr = True
            self.options.log_file_prefix = None
            self.options.log_rotate_mode = "size"
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 5
            self.options.log_rotate_when = "S"
            self.options.log_rotate_

# Generated at 2022-06-18 10:25:11.423723
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d"

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}

    formatter = LogFormatter(colors={logging.DEBUG: 1})

# Generated at 2022-06-18 10:25:20.584757
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:25:27.103221
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.general", logging.DEBUG, "test.py", 42, "test message", None, None
    )
    assert formatter.format(record) == "[D test.py:42] test message"
    record.exc_info = True
    record.exc_text = "test exception"
    assert formatter.format(record) == "[D test.py:42] test message\n    test exception"



# Generated at 2022-06-18 10:25:40.320487
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:25:48.702219
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create a LogFormatter object
    formatter = LogFormatter()
    # Create a record
    record = logging.LogRecord(
        name='tornado.general',
        level=logging.DEBUG,
        pathname='/path/to/file',
        lineno=1,
        msg='test message',
        args=None,
        exc_info=None,
    )
    # Test the method
    assert formatter.format(record) == '[D 160927 13:21:58 <unknown>:1] test message'



# Generated at 2022-06-18 10:25:56.997597
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert logging.getLogger().handlers[0].__class__.__name__ == "RotatingFileHandler"
    assert logging.getLogger().handlers[1].__class__.__name__ == "StreamHandler"

# Generated at 2022-06-18 10:26:08.675501
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal != ""



# Generated at 2022-06-18 10:26:31.333488
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

# Generated at 2022-06-18 10:26:37.059229
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D 171204 12:00:00 file:42] test message"


# Generated at 2022-06-18 10:26:48.466311
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()
    logger = logging.getLogger()
    assert logger.level == logging.DEBUG
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.handlers.RotatingFileHandler)
    assert logger.handlers[0].maxBytes == 1024
    assert logger.handlers

# Generated at 2022-06-18 10:26:59.732117
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    # Test that LogFormatter constructor works with and without colorama
    global colorama
    colorama_save = colorama
    try:
        colorama = None
        formatter = LogFormatter()
        assert formatter._normal == ""
        assert formatter._colors == {}
        colorama = object()
        formatter = LogFormatter()
        assert formatter._normal == "\033[0m"
        assert formatter._colors == {
            logging.DEBUG: "\033[2;34m",
            logging.INFO: "\033[2;32m",
            logging.WARNING: "\033[2;33m",
            logging.ERROR: "\033[2;31m",
            logging.CRITICAL: "\033[2;35m",
        }
    finally:
        colorama = color

# Generated at 2022-06-18 10:27:10.307958
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-18 10:27:22.111178
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d %H:%M:%S"

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:27:31.321756
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Create a handler
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)

    # Create a formatter
    formatter = LogFormatter()
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Log some messages
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')
    logger.error('error message')
    logger.critical('critical message')


# Generated at 2022-06-18 10:27:43.540162
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import time
    import unittest
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from typing import Dict, Any, cast, Optional

# Generated at 2022-06-18 10:27:52.697808
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:28:04.415368
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:28:49.428823
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:29:00.078463
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:29:09.469099
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.info("test")
    gen_log.debug("test")
    gen_log.error("test")
    gen_log.warning("test")
    gen_log.critical("test")
    gen_log.exception("test")

if __name__ == "__main__":
    test_enable_pretty_log

# Generated at 2022-06-18 10:29:19.285905
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:31.261741
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.testing
    import logging
    import os
    import shutil
    import time
    import unittest

    class LogTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.testing.IOLoop()
            self.io_loop.make_current()
            self.log_dir = self.get_log_dir()
            self.log_file = os.path.join(self.log_dir, "test.log")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file
            self.options.log_to_stderr = False
            self.options.log_rotate_mode = "time"
            self.options.log_rotate

# Generated at 2022-06-18 10:29:41.722542
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._

# Generated at 2022-06-18 10:29:46.302162
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tmpdir, "test_log")
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_rotate_mode = "size"
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 5

# Generated at 2022-06-18 10:29:58.491889
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:30:10.356756
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal != ""



# Generated at 2022-06-18 10:30:19.224715
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipIfNoPty
    from tornado.test.util import skipIf
    from tornado.test.util import expect_warnings
    from tornado.test.util import expect_deprecated_unicode_type
    from tornado.test.util import expect_deprecated_nonzero
    from tornado.test.util import expect_

# Generated at 2022-06-18 10:31:59.448474
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tempdir, "test_log")
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"
            self.options.log_rotate_when = "S"
            self.options.log_rotate_interval = 1
            self.options.logging = "debug"


# Generated at 2022-06-18 10:32:09.494771
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIf
    from tornado.test.util import skipOnTravis
    from tornado.test.util import suppress_stderr
    from tornado.test.util import suppress_warnings
    from tornado.test.util import expect_warnings
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipIfNoPymongo
    from tornado.test.util import skipOnAppEngine
    from tornado.test.util import skipIfNoNetwork
    from tornado.test.util import skipBefore33

# Generated at 2022-06-18 10:32:19.096978
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest
    from tornado.options import define, options

    define("logging", default="debug")
    define("log_file_prefix", type=str, default=None)
    define("log_file_max_size", type=int, default=100)
    define("log_file_num_backups", type=int, default=5)
    define("log_rotate_mode", type=str, default="size")
    define("log_rotate_when", type=str, default="S")
    define("log_rotate_interval", type=int, default=1)
    define("log_to_stderr", type=bool, default=False)


# Generated at 2022-06-18 10:32:28.046078
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:32:36.245993
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipIfNoPty
    from tornado.test.util import skipIf
    from tornado.test.util import expect_warnings
    from tornado.test.util import expect_deprecation
    from tornado.test.util import expect_stderr
    from tornado.test.util import ignore_deprecation

# Generated at 2022-06-18 10:32:47.413663
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={1: 1})