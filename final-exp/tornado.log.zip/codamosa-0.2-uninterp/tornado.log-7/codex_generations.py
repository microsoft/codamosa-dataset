

# Generated at 2022-06-18 10:23:20.758778
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:23:21.666579
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:23:31.649628
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    import colorama
    import curses
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")
    # Unit test for method _stderr_supports_color of module tornado.log

# Generated at 2022-06-18 10:23:36.213783
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="",
        lineno=0,
        msg="test",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D 180101 00:00:00 :0] test"


# Generated at 2022-06-18 10:23:48.397380
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import sys
    import io
    import os
    import time
    import datetime
    import tornado.log
    import tornado.escape
    import tornado.util
    import tornado.options
    import tornado.log
    import tornado.escape
    import tornado.util
    import tornado.options
    import tornado.log
    import tornado.escape
    import tornado.util
    import tornado.options
    import tornado.log
    import tornado.escape
    import tornado.util
    import tornado.options
    import tornado.log
    import tornado.escape
    import tornado.util
    import tornado.options
    import tornado.log
    import tornado.escape
    import tornado.util
    import tornado.options
    import tornado.log
    import tornado.escape
    import tornado.util

# Generated at 2022-06-18 10:23:54.987779
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "./logs/test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:24:08.262658
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import PY3
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import is_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import is_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:24:17.627672
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.log_to_stderr = False
            self.options.log_file_prefix = self.log_file
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 1
            self.options.log_rotate_mode = "size"
            self.options.log_rotate_

# Generated at 2022-06-18 10:24:30.013106
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import unittest
    import tempfile
    import warnings
    from tornado.test.util import unittest

    class LogTest(unittest.TestCase):
        def setUp(self):
            super(LogTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.log_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.log_dir, "test.log")
            self.options = tornado.options.options
            self.options.log_to_stderr = None
            self.options

# Generated at 2022-06-18 10:24:36.364745
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "./log/test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.info("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:24:53.491500
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""
    assert formatter.format(logging.LogRecord("tornado.general", logging.DEBUG, "", 0, "", (), None)) == "[D 000101 00:00:00 tornado.general:0] \n    "


# Generated at 2022-06-18 10:25:03.707899
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    assert formatter.format(record) == "[I test.py:1] test"
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    record.exc_info = Exception("test")
    assert formatter.format(record) == "[I test.py:1] test\n    test"
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    record.exc_info = Exception("test")
    record.exc_text = "test"

# Generated at 2022-06-18 10:25:11.865362
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tempdir, "test.log")
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_rotate_mode = "time"
            self.options.log_rotate_when = "S"
            self.options.log_rotate_interval = 1

# Generated at 2022-06-18 10:25:16.473558
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:25:20.669481
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter._fmt, str)
    assert isinstance(formatter._colors, dict)
    assert isinstance(formatter._normal, str)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT



# Generated at 2022-06-18 10:25:30.371778
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:25:43.228784
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:25:53.793394
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import sys
    import io
    import time
    import datetime
    import os
    import tempfile
    import shutil
    import re
    import warnings
    import platform
    import subprocess
    import threading
    import multiprocessing
    import socket
    import select
    import unittest.mock
    import contextlib
    import traceback
    import gc
    import atexit
    import weakref
    import textwrap
    import functools
    import inspect
    import random
    import base64
    import struct
    import pickle
    import email
    import email.parser
    import email.message
    import email.policy
    import email.generator
    import email.utils
    import email.charset

# Generated at 2022-06-18 10:26:05.380954
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()
    LogFormatter(color=False)
    LogFormatter(color=True)
    LogFormatter(color=True, colors={})
    LogFormatter(color=True, colors={logging.DEBUG: 1})
    LogFormatter(color=True, colors={logging.DEBUG: 1, logging.INFO: 2})
    LogFormatter(color=True, colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3})
    LogFormatter(color=True, colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 4})

# Generated at 2022-06-18 10:26:16.039234
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(
        fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={logging.DEBUG: 7},
    )
    assert formatter._fmt == "%(color)s%(levelname)s%(end_color)s %(message)s"

# Generated at 2022-06-18 10:26:45.140274
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.options import define, options
    from tornado.log import enable_pretty_logging
    from tornado.log import LogFormatter
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import access_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import Log

# Generated at 2022-06-18 10:26:49.227000
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._colors != {}
    assert formatter._normal != ""


# Generated at 2022-06-18 10:27:00.345238
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == (
        "[D 170511 12:00:00 file:42] hello"
    )
    record.msg = "hello\nworld"
    assert formatter.format(record) == (
        "[D 170511 12:00:00 file:42] hello\n    world"
    )
    record.exc_info = sys.exc_info()

# Generated at 2022-06-18 10:27:12.417024
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter

# Generated at 2022-06-18 10:27:16.656917
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert formatter.DEFAULT_COLORS == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }



# Generated at 2022-06-18 10:27:29.003978
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:27:32.832464
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.options import options, define, parse_command_line
    define("logging", default="none", help="logging config")
    parse_command_line()
    if options.logging == "none":
        return
    LogFormatter()


# Generated at 2022-06-18 10:27:45.085834
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:27:53.475822
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:28:03.206285
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-18 10:28:40.051282
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:28:48.197613
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:28:55.876520
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-18 10:29:01.983561
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:10.817395
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-18 10:29:20.573723
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._normal == "\033[0m"


# Generated at 2022-06-18 10:29:32.580456
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mkstemp()
            self.log_file_name = self.log_file[1]
            self.log_file_fd = self.log_file[0]
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file_name
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self

# Generated at 2022-06-18 10:29:42.909407
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers
    import sys
    import os
    import tempfile
    import time
    import unittest
    import warnings
    import io
    import re
    import contextlib
    import datetime
    import functools
    import locale
    import platform
    import socket
    import struct
    import threading
    import traceback
    import weakref
    import xml.sax
    import xml.sax.handler
    import xml.sax.saxutils
    import xml.sax.xmlreader
    import xml.etree.ElementTree
    import xml.parsers.expat
    import xml.parsers.expat
    import xml.parsers.expat
    import xml.parsers.expat
    import xml.p

# Generated at 2022-06-18 10:29:55.451705
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.NamedTemporaryFile()
            self.log_file_name = self.log_file.name
            self.log_file.close()
            self.log_file_prefix = self.log_file_name + "."
            self.log_file_max_size = 100
            self.log_file_num_backups = 1
            self.log_rotate_when = "S"
            self.log_rotate_interval = 1
            self.log_rotate_

# Generated at 2022-06-18 10:30:06.691967
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipIfNoPty
    from tornado.test.util import skipIfNotOS
    from tornado.test.util import skipIf
    from tornado.test.util import skipUnless
    from tornado.test.util import expect_warnings
    from tornado.test.util import expect_deprecation

# Generated at 2022-06-18 10:31:18.859020
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug("test")
    tornado.log.app_log.info("test")
    tornado.log.app_log

# Generated at 2022-06-18 10:31:29.507856
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:31:39.056683
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import time
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.tmpdir = tempfile.mkdtemp()
            self.old_log_file_prefix = tornado.options.options.log_file_prefix
            self.old_log_rotate_mode = tornado.options.options.log_rotate_mode
            self.old_log_rotate_when = tornado.options.options.log_rotate_when
            self

# Generated at 2022-06-18 10:31:40.151711
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:31:40.929348
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)


# Generated at 2022-06-18 10:31:49.350146
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"
    assert formatter.formatTime(record) == "%y%m%d %H:%M:%S"
    assert formatter.formatException(record.exc_info) == ""



# Generated at 2022-06-18 10:32:01.350332
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_to_stderr", default=False, help="log to stderr")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100000, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="H", help="log rotate when")

# Generated at 2022-06-18 10:32:09.952406
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import io
    import sys
    import time
    import threading

    class TestHandler(logging.handlers.BufferingHandler):
        def __init__(self, capacity: int) -> None:
            logging.handlers.BufferingHandler.__init__(self, capacity)

        def shouldFlush(self, record: Any) -> bool:
            return False

        def emit(self, record: Any) -> None:
            self.buffer.append(record)

    class LogFormatterTest(unittest.TestCase):
        def setUp(self) -> None:
            self.log_stream = io.StringIO()
            self.handler = TestHandler(100)
            self.handler.setFormatter(LogFormatter())
            self.handler.set

# Generated at 2022-06-18 10:32:12.307450
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)


# Generated at 2022-06-18 10:32:13.137597
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()