

# Generated at 2022-06-18 10:23:15.204606
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    # Test that the constructor of LogFormatter works
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)



# Generated at 2022-06-18 10:23:25.420560
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    import logging
    import time
    import unittest

    class TestHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super(TestHandler, self).__init__(*args, **kwargs)
            self.records = []  # type: List[Any]

        def emit(self, record):
            self.records.append(record)

    class TestLogFormatter(LogFormatter):
        def formatTime(self, record, datefmt=None):
            return "TIME"

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            self.handler = TestHandler()
            self.handler.setFormatter(TestLogFormatter())
            self.logger = logging.getLogger()
            self.log

# Generated at 2022-06-18 10:23:34.150608
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:23:38.486234
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    formatter.format(record)
    assert record.message == "test"
    assert record.asctime == "test"
    assert record.color == ""
    assert record.end_color == ""


# Generated at 2022-06-18 10:23:50.250068
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._colors == {logging.DEBUG: "\033[2;34m"}
    assert formatter._normal == "\033[0m"



# Generated at 2022-06-18 10:24:01.768942
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:13.366627
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:26.166304
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            sys.stderr = sys.stdout = open(os.devnull, "w")
            self.log_file

# Generated at 2022-06-18 10:24:35.456858
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2

# Generated at 2022-06-18 10:24:43.802273
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
   

# Generated at 2022-06-18 10:25:11.266759
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file_name = os.path.join(self.temp_dir, "test.log")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file_name
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_rotate_mode = "time"
            self.options.log_rotate_when

# Generated at 2022-06-18 10:25:20.410930
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")
    gen_log.exception("test")
    gen_log.log(logging.DEBUG, "test")
    gen_log

# Generated at 2022-06-18 10:25:31.529375
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            self.log_file = tempfile.NamedTemporaryFile()
            self.log_file_name = self.log_file.name
            self.log_file.close()


# Generated at 2022-06-18 10:25:44.250605
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="S", help="log rotate when")
    tornado.options.define("log_rotate_interval", default=1, help="log rotate interval")

# Generated at 2022-06-18 10:25:45.804643
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:25:53.543008
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class LoggingTest(AsyncTestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.log_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.log_dir, "test.log")
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            sys.stderr = sys.stdout = open(os.devnull, "w")

        def tearDown(self):
            sys.stderr = self.st

# Generated at 2022-06-18 10:26:04.821730
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._colors == {}
    assert formatter._normal == "\033[0m"


# Generated at 2022-06-18 10:26:15.729978
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import shutil
    import time
    import unittest
    import tempfile
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import b
    from tornado.log import enable_pretty_logging, app_log, gen_log, access_log
    from tornado.options import define, options

    define("log_file_prefix", type=str, default=None)
    define("log_to_stderr", type=bool, default=None)
    define("logging", default="info")
    define("log_rotate_mode", type=str, default="size")
    define("log_rotate_when", type=str, default="S")

# Generated at 2022-06-18 10:26:23.470344
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.NamedTemporaryFile()
            self.log_file_name = self.log_file.name
            self.log_file.close()
            self.log_file_prefix = os.path.join(
                tempfile.gettempdir(), "tornado_test_log"
            )
            self.log_file_num_backups = 3
            self.log_file_max_size = 100
            self.log_rotate_mode = "size"
            self.log_

# Generated at 2022-06-18 10:26:32.915450
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:26:47.743923
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/home/user/tornado/tornado/log.py",
        lineno=100,
        msg="test",
        args=(),
        exc_info=None,
    )
    assert fmt.format(record) == (
        "\x1b[2;34m[D 160101 00:00:00 log:100]\x1b[0m test"
    )



# Generated at 2022-06-18 10:26:52.132765
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT


# Generated at 2022-06-18 10:27:04.558130
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmpdir, "test.log")
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            sys.stderr = sys.stdout = open(os.devnull, "w")

        def tearDown(self):
            sys.stderr = self.stderr

# Generated at 2022-06-18 10:27:13.164755
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create a mock record
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="log message",
        args=(),
        exc_info=None,
    )

    # Create a LogFormatter
    formatter = LogFormatter()

    # Call the method
    result = formatter.format(record)

    # Check the result
    assert result == "[I 20070809 22:59:59 file.py:42] log message"



# Generated at 2022-06-18 10:27:24.983778
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.NamedTemporaryFile()
            self.log_file_name = self.log_file.name
            self.log_file.close()
            self.log_file_prefix = os.path.join(
                tempfile.gettempdir(), "tornado_test_log"
            )
            self.log_file_num_backups = 3
            self.log_file_max_size = 100
            self.log_rotate_mode = "size"
            self.log_

# Generated at 2022-06-18 10:27:36.549717
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:27:38.073054
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:27:49.941061
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:28:02.267009
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:28:11.578706
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import tempfile
    import shutil
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import is_future
    from tornado.platform.asyncio import is_coroutine_function
    from tornado.platform.asyncio import is_coroutine
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:28:49.043806
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("log_file_prefix", default="test.log")
    tornado.options.define("log_file_max_size", default=1024)
    tornado.options.define("log_file_num_backups", default=2)
    tornado.options.define("log_rotate_mode", default="size")
    tornado.options.define("log_rotate_when", default="S")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_to_stderr", default=True)
    tornado.options.parse_command_line()
    tornado.log.enable_pretty_logging()

# Generated at 2022-06-18 10:28:59.768649
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    import io
    import contextlib
    import re
    import functools
    import datetime
    import platform
    import subprocess
    import threading
    import multiprocessing
    import concurrent.futures
    import typing
    from tornado.testing import AsyncTestCase, gen_test, ExpectLog, bind_unused_port
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.auto import set_close_exec
    from tornado.platform.posix import set_nonblocking
    from tornado.platform.select import SelectIOLoop

# Generated at 2022-06-18 10:29:05.905536
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.test.util import unittest

    class LogTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.log_file_prefix = os.path.join(self.tmpdir, "test_log")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file_prefix
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3

# Generated at 2022-06-18 10:29:15.997706
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d"

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""


# Generated at 2022-06-18 10:29:26.874209
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setFormatter(tornado.log.LogFormatter())
            self.logger = logging.getLogger()

# Generated at 2022-06-18 10:29:38.324649
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT


# Generated at 2022-06-18 10:29:46.689998
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:29:59.119386
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:30:05.302795
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:30:11.093235
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoCurses
    from tornado.test.util import skipIfNoColorama
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipOnTravis
    from tornado.test.util import expect_warnings
    from tornado.test.util import expect_deprecation
    from tornado.test.util import skipIfNoPymongo
    from tornado.test.util import skipIfNoPycurl
    from tornado.test.util import skipOnAppEngine

# Generated at 2022-06-18 10:31:01.367442
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:31:11.891912
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:31:18.689714
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter(color=False)
    assert LogFormatter(color=True)
    assert LogFormatter(color=True, colors={})
    assert LogFormatter(color=True, colors={logging.DEBUG: 1})
    assert LogFormatter(color=True, colors={logging.DEBUG: 1}, fmt="%(message)s")
    assert LogFormatter(color=True, colors={logging.DEBUG: 1}, fmt="%(message)s", datefmt="%Y")


# Generated at 2022-06-18 10:31:29.357596
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "none"
    tornado.options.options.log_file_prefix = "test_enable_pretty_logging"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.debug("test_enable_pretty_logging")
    logger.info("test_enable_pretty_logging")
    logger.warning("test_enable_pretty_logging")

# Generated at 2022-06-18 10:31:30.557086
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:31:40.008548
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")
    gen_log.exception("test")
    gen_log.log(logging.DEBUG, "test")
    gen_log

# Generated at 2022-06-18 10:31:49.546601
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:31:57.448786
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/home/user/tornado/tornado/stack_context.py",
        lineno=42,
        msg="Test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"


# Generated at 2022-06-18 10:32:03.854376
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-18 10:32:10.754347
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()