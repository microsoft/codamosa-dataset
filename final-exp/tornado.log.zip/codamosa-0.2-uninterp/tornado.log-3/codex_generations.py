

# Generated at 2022-06-18 10:23:07.005333
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for the case when the message is a string
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.access",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="test",
        args=None,
        exc_info=None,
    )
    assert formatter.format(record) == "[I " + record.asctime + " tornado.access:0] test"
    # test for the case when the message is a unicode string

# Generated at 2022-06-18 10:23:17.071237
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:23:27.198255
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter

# Generated at 2022-06-18 10:23:35.167093
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    class Record:
        def __init__(self, levelno: int, message: str, exc_info: Optional[Any] = None, exc_text: Optional[str] = None) -> None:
            self.levelno = levelno
            self.message = message
            self.exc_info = exc_info
            self.exc_text = exc_text
    record = Record(logging.DEBUG, "message")
    assert log_formatter.format(record) == "[D message] message"
    record = Record(logging.INFO, "message")
    assert log_formatter.format(record) == "[I message] message"
    record = Record(logging.WARNING, "message")
    assert log_formatter.format(record) == "[W message] message"

# Generated at 2022-06-18 10:23:47.351520
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    import time
    import logging
    import logging.handlers
    import tornado.log

    # Create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Create a file handler
    handler = logging.handlers.RotatingFileHandler('test.log', maxBytes=1024, backupCount=5)
    handler.setLevel(logging.DEBUG)

    # Create a formatter
    formatter = tornado.log.LogFormatter()
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Log some messages
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')
    logger.error('error message')

# Generated at 2022-06-18 10:23:55.483837
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:08.509326
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert logging.getLogger().handlers[0].__class__ == logging.handlers.RotatingFileHandler
    assert logging.get

# Generated at 2022-06-18 10:24:17.782237
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_file_prefix", default="logs/test.log")
    tornado.options.define("log_rotate_mode", default="time")
    tornado.options.define("log_rotate_when", default="D")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.define("log_file_num_backups", default=10)
    tornado.options.define("log_to_stderr", default=True)
    tornado.options.parse_command_line()
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug("test")

# Generated at 2022-06-18 10:24:18.741170
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:24:21.246083
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:24:34.217117
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import unittest

    class TestLogFormatter(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.log_file_prefix = os.path.join(self.tempdir, "test")
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file_prefix
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"
            self.options.log_rotate_when = "S"
            self

# Generated at 2022-06-18 10:24:42.179748
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"  # noqa: E501
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"  # noqa: E501

# Generated at 2022-06-18 10:24:54.385265
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.log import gen_log
    from tornado.options import define, options, parse_command_line
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.log_file_prefix = os.path.join(self.tmpdir, "test_log")
            define("log_file_prefix", self.log_file_prefix)
            define("log_file_max_size", 10)
            define("log_file_num_backups", 3)

# Generated at 2022-06-18 10:25:04.398888
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="debug", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file")
    tornado.options.define("log_to_stderr", default=False, help="log to stderr")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="S", help="log rotate when")

# Generated at 2022-06-18 10:25:12.486259
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()


# Generated at 2022-06-18 10:25:21.616935
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stderr = sys.stderr
            self.log_file = tempfile.NamedTemporaryFile()
            self.log_filename = self.log_file.name
            self.log_file.close()

# Generated at 2022-06-18 10:25:22.573945
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:25:34.220629
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:25:42.053967
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-18 10:25:52.882903
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import datetime
    import time
    import unittest
    from tornado.log import LogFormatter
    from tornado.testing import AsyncTestCase, LogTrapTestCase

    class LogFormatterTest(AsyncTestCase, LogTrapTestCase):
        def setUp(self):
            # type: () -> None
            super(LogFormatterTest, self).setUp()
            self.formatter = LogFormatter()
            self.record = logging.LogRecord(
                "tornado.test",
                logging.INFO,
                "/path/to/file.py",
                123,
                "message",
                None,
                None,
            )
            self.record.__dict__["my_key"] = "my_value"

# Generated at 2022-06-18 10:26:12.306842
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"
    record.msg = "hello\nworld"
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] hello\n    world"
    record.exc_info = sys.exc_info()

# Generated at 2022-06-18 10:26:13.907154
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:26:17.376825
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.DEBUG, "", 0, "", (), None)
    assert log_formatter.format(record) == "[D 0 tornado.general:0] "


# Generated at 2022-06-18 10:26:24.539405
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._

# Generated at 2022-06-18 10:26:33.533675
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.logging = "debug"
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug("test")
    tornado.log.app_log.info("test")
    tornado.log.app_log

# Generated at 2022-06-18 10:26:45.666354
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:26:53.242243
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug("test")
    tornado.log.app_log.info("test")
    tornado.log.app_log.warning("test")
    tornado.log.app_log.error("test")
    tornado.log.app_log.critical("test")
   

# Generated at 2022-06-18 10:27:00.457730
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] hello"



# Generated at 2022-06-18 10:27:06.972480
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    enable_pretty_logging()

# Generated at 2022-06-18 10:27:19.523532
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    define("logging", default="none", help="logging level", type=str)
    define("log_file_prefix", default="", help="log file prefix", type=str)
    define("log_rotate_mode", default="size", help="log rotate mode", type=str)
    define("log_file_max_size", default=100, help="log file max size", type=int)
    define("log_file_num_backups", default=10, help="log file num backups", type=int)
    define("log_rotate_when", default="D", help="log rotate when", type=str)
    define("log_rotate_interval", default=1, help="log rotate interval", type=int)

# Generated at 2022-06-18 10:27:53.429286
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:28:02.778186
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-18 10:28:11.984760
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import tornado.escape
    import tornado.util
    import typing
    import unittest
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    from typing import Dict, Any, cast, Optional
    class TestLogFormatter(unittest.TestCase):
        def test_LogFormatter(self):
            # LogFormatter.__init__
            log_formatter = LogFormatter()
            self.assertEqual(log_formatter._fmt, "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s")
           

# Generated at 2022-06-18 10:28:19.569936
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tempdir, "test.log")
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"

# Generated at 2022-06-18 10:28:27.128452
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:28:36.366793
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    from tornado.testing import AsyncTestCase, gen_test, main
    from tornado.util import PY3
    from tornado.log import app_log, gen_log, access_log
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import enable_pretty_logging
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogForm

# Generated at 2022-06-18 10:28:45.793973
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    class FakeLogRecord(object):
        def __init__(self, levelno, msg):
            self.levelno = levelno
            self.msg = msg

        def getMessage(self):
            return self.msg

    formatter = LogFormatter()
    for levelno, msg in [(logging.DEBUG, "debug"), (logging.INFO, "info")]:
        record = FakeLogRecord(levelno, msg)
        assert formatter.format(record) == "[%s] %s" % (msg.upper(), msg)



# Generated at 2022-06-18 10:28:57.222633
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.access",
        level=logging.DEBUG,
        pathname="/Users/foo/bar.py",
        lineno=42,
        msg="test",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D %(asctime)s bar:42] %(message)s"
    record.exc_info = sys.exc_info()

# Generated at 2022-06-18 10:29:03.590786
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test that LogFormatter.format() works with unicode messages
    # and non-ascii bytes.
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.test", logging.DEBUG, "foo.py", 42, u"\u1234", None, None)
    assert isinstance(formatter.format(record), unicode_type)
    record = logging.LogRecord("tornado.test", logging.DEBUG, "foo.py", 42, b"\xff", None, None)
    assert isinstance(formatter.format(record), unicode_type)
    record = logging.LogRecord("tornado.test", logging.DEBUG, "foo.py", 42, u"\u1234".encode("utf-8"), None, None)

# Generated at 2022-06-18 10:29:13.695883
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setFormatter(tornado.log.LogFormatter())
            self.logger = logging.getLogger()
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

# Generated at 2022-06-18 10:29:55.496114
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORM

# Generated at 2022-06-18 10:30:00.039356
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS

# Generated at 2022-06-18 10:30:03.051336
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # This method is not tested because it is not used in the code
    pass



# Generated at 2022-06-18 10:30:09.259169
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(
        fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={logging.DEBUG: 7},
    )
    assert formatter._fmt == "%(color)s%(levelname)s%(end_color)s %(message)s"
    assert formatter._colors == {logging.DEBUG: 7}


# Generated at 2022-06-18 10:30:18.534758
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import shutil
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = "test.log"
            self.log_file_prefix = "test"
            self.log_file_max_size = 100
            self.log_file_num_backups = 1
            self.log_rotate_when = "S"
            self.log_rotate_interval = 1
            self.log_rotate_mode = "size"
            self.log_to_stderr = False
            self.logging = "debug"
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log

# Generated at 2022-06-18 10:30:28.800370
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORM

# Generated at 2022-06-18 10:30:40.406399
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.tempdir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tempdir, "test.log")
            self.options = tornado.options.parse_config_file(
                os.path.join(os.path.dirname(__file__), "test/options_test.py")
            )
            self.options.log_file_prefix = self

# Generated at 2022-06-18 10:30:51.415601
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_file_prefix", default="")
    tornado.options.define("log_file_max_size", default=0)
    tornado.options.define("log_file_num_backups", default=0)
    tornado.options.define("log_rotate_mode", default="")
    tornado.options.define("log_rotate_when", default="")
    tornado.options.define("log_rotate_interval", default=0)
    tornado.options.define("log_to_stderr", default=False)
    tornado.options.parse_command_line()
    tornado.log.enable_pretty_logging()
    tornado.log.app_log.debug("test")

# Generated at 2022-06-18 10:30:58.047675
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:31:05.172796
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[D 180101 00:00:00 file:42] test message"



# Generated at 2022-06-18 10:32:26.219484
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] hello"



# Generated at 2022-06-18 10:32:34.824638
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("debug")
    gen_log.info("info")
    gen_log.warning("warning")
    gen_log.error("error")
    gen_log.critical("critical")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:32:46.167154
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   