

# Generated at 2022-06-18 10:23:15.201264
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for the case where record.message is a string
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s" % record.__dict__  # noqa: E501
    # test for the case where record.message is a byte string

# Generated at 2022-06-18 10:23:23.694630
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-18 10:23:33.495876
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = os.path.join(self.tmpdir, "test.log")
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_rotate_mode = "time"
            self.options.log_rotate_when = "S"
            self.options.log_rotate_interval = 1

# Generated at 2022-06-18 10:23:39.458682
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="test_log.py",
        lineno=1,
        msg="test",
        args=(),
        exc_info=None,
    )
    fmt.format(record)
    assert record.message == "test"
    assert record.asctime == "190101 00:00:00"
    assert record.color == ""
    assert record.end_color == ""



# Generated at 2022-06-18 10:23:51.531712
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:03.639113
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import datetime
    import time
    import unittest
    import warnings
    from tornado.log import LogFormatter
    from tornado.util import _unicode

    class TestRecord(object):
        def __init__(self, levelno, msg, args, exc_info=None):
            # type: (int, str, Any, Optional[Any]) -> None
            self.levelno = levelno
            self.msg = msg
            self.args = args
            self.exc_info = exc_info

        def getMessage(self):
            # type: () -> str
            return self.msg % self.args

    class TestException(Exception):
        pass

    class TestCase(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.form

# Generated at 2022-06-18 10:24:06.571617
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "log_file_prefix"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()

# Generated at 2022-06-18 10:24:16.470666
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:28.656163
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.info("test")
    gen_log.warning("test")
    gen_log.error("test")
    gen_log.critical("test")
    gen_log.exception("test")
    gen_log.error("test", exc_info=True)
    gen_log

# Generated at 2022-06-18 10:24:32.836857
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.DEBUG, "", 0, "", (), None)
    assert formatter.format(record) == "[D %s tornado.access:0] " % formatter.formatTime(record, formatter.datefmt)



# Generated at 2022-06-18 10:24:54.843940
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:25:00.982444
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.application",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="test message",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I %(asctime)s %(module)s:%(lineno)d] %(message)s"



# Generated at 2022-06-18 10:25:10.414526
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import access_log
   

# Generated at 2022-06-18 10:25:15.279901
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import tornado.escape
    import tornado.options
    import tornado.util
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log

# Generated at 2022-06-18 10:25:25.008481
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:25:37.814483
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for format
    import logging
    import logging.handlers
    import sys
    import time
    import unittest
    from tornado.log import LogFormatter
    from tornado.log import access_log, app_log, gen_log
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from typing import Dict, Any, cast, Optional
    # test for _stderr_supports_color
    # test for _safe_unicode
    # test for _unicode
    # test for unicode_type
    # test for basestring_type
    # test for Dict


# Generated at 2022-06-18 10:25:46.300097
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test the format method of the LogFormatter class
    # Arrange
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="",
        lineno=0,
        msg="",
        args=(),
        exc_info=None,
    )
    # Act
    result = formatter.format(record)
    # Assert
    assert result == "[D 000101 00:00:00 :0] "



# Generated at 2022-06-18 10:25:49.239550
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] hello"



# Generated at 2022-06-18 10:25:57.272123
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 1
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)
    assert logging.getLogger().handlers[0].maxBytes == 1024
    assert logging.getLogger().handlers[0].backupCount == 3

# Generated at 2022-06-18 10:26:08.713178
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")

# Generated at 2022-06-18 10:26:51.423791
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter
    from tornado.log import LogFormatter

# Generated at 2022-06-18 10:27:02.950979
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import unittest
    import tempfile
    import io
    import re
    import warnings
    import functools
    import contextlib
    import platform
    import subprocess
    import threading
    import concurrent.futures
    import asyncio
    import signal
    import socket
    import ssl
    import struct
    import errno
    import datetime
    import traceback
    import collections
    import weakref
    import pickle
    import gc
    import io
    import time
    import sys
    import os
    import unittest
    import tempfile
    import functools
    import contextlib
    import platform
    import subprocess


# Generated at 2022-06-18 10:27:04.720981
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:27:16.045748
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import time
    import unittest
    from tornado.test.util import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.log_file_prefix = self.log_file
            self.options.log_to_stderr = False
            self.options.logging = "debug"
            self.options.log_rotate_mode = "time"
            self.options.log_rotate_when = "S"
            self.options.log_rotate_interval = 1
            self

# Generated at 2022-06-18 10:27:25.852528
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    from tornado.log import LogFormatter
    from tornado.log import access_log, app_log, gen_log

    class LogFormatterTest(unittest.TestCase):
        def test_format(self):
            formatter = LogFormatter()
            record = logging.LogRecord(
                "tornado.general", logging.INFO, "/fake/path", 42, "test", None, None
            )
            self.assertEqual(
                formatter.format(record),
                "[I /fake/path:42] test",
            )

    unittest.main()


# Generated at 2022-06-18 10:27:31.910196
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I 20070827 20:59:57 file.py:42] hello"



# Generated at 2022-06-18 10:27:44.224917
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.options = tornado.options.options
            self.options.logging = "debug"
            self.options.log_to_stderr = False
            self.options.log_file_prefix = os.path.join(self.tmpdir, "test.log")
            self.options.log_rotate_mode = "time"
            self.options.log_rotate_when = "S"
            self.options.log_rotate_interval = 1

# Generated at 2022-06-18 10:27:45.984938
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    formatter.format(record)


# Generated at 2022-06-18 10:27:53.703178
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f._fmt == LogFormatter.DEFAULT_FORMAT
    assert f._colors == {}
    assert f._normal == ""

    f = LogFormatter(color=False)
    assert f._fmt == LogFormatter.DEFAULT_FORMAT
    assert f._colors == {}
    assert f._normal == ""

    f = LogFormatter(color=True)
    assert f._fmt == LogFormatter.DEFAULT_FORMAT
    assert f._colors != {}
    assert f._normal != ""

    f = LogFormatter(color=True, fmt="%(message)s")
    assert f._fmt == "%(message)s"
    assert f._colors != {}
    assert f._normal != ""



# Generated at 2022-06-18 10:27:58.873353
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format (line 437)
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.general", logging.INFO, "/fakepath", 42, "hello", None, None
    )
    assert formatter.format(record) == "[I /fakepath:42] hello"



# Generated at 2022-06-18 10:28:45.522249
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:28:57.004033
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal != ""



# Generated at 2022-06-18 10:29:03.355584
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("logging", default="info", help="Set the Python log level.")
    define("log_to_stderr", type=bool, default=None, help="Send log output to stderr (colorized if possible).")
    define("log_file_prefix", type=str, default=None, metavar="PATH", help="Path prefix for log files.")
    define("log_file_max_size", type=int, default=100 * 1000 * 1000, help="max size of log files before rollover")
    define("log_file_num_backups", type=int, default=10, help="number of log files to keep")

# Generated at 2022-06-18 10:29:13.492317
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:29:23.298803
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.util import b
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.log import app_log, gen_log, access_log, LogFormatter
    from tornado.log import enable_pretty_logging
    from tornado.options import define, options

    define("logging", default="info", help="logging level")
    define("log_file_prefix", default="test_log", help="log file")
    define("log_file_max_size", default=100, help="max size of log file")

# Generated at 2022-06-18 10:29:31.502117
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == (
        "[D 160420 12:00:00 file:42] hello"
    )



# Generated at 2022-06-18 10:29:41.942071
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.logging = "debug"
            self.options.log_file_prefix = self.log_file
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 3
            self.options.log_rotate_mode = "size"
            self.options.log_to_stderr = False
            self.options.log_rotate_when = "S"
            self.options.log_rotate_inter

# Generated at 2022-06-18 10:29:53.535441
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:29:55.109106
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()



# Generated at 2022-06-18 10:30:06.415729
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:32:23.869751
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._

# Generated at 2022-06-18 10:32:33.188651
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:32:38.598784
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-18 10:32:48.587963
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 2
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)
    assert isinstance(logging.getLogger().handlers[1], logging.StreamHandler)