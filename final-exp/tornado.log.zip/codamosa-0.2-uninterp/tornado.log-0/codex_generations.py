

# Generated at 2022-06-18 10:23:22.123966
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:23:32.043958
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == "[I /path/to/file.py:42] hello"
    record.msg = "hello\nworld"
    assert formatter.format(record) == "[I /path/to/file.py:42] hello\n    world"
    record.exc_info = sys.exc_info()

# Generated at 2022-06-18 10:23:42.385038
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import io
    import sys
    import time
    import datetime
    import threading
    import tornado.log
    import tornado.escape
    import tornado.options
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.tcpserver
    import tornado.locks
    import tornado.queues
    import tornado.httpclient
    import tornado.httputil
    import tornado.httpserver
    import tornado.httputil
    import tornado.escape
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
   

# Generated at 2022-06-18 10:23:44.563542
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-18 10:23:53.616503
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._col

# Generated at 2022-06-18 10:24:06.822995
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="hello",
        args=(),
        exc_info=None,
    )
    assert formatter.format(record) == (
        "[D 160101 00:00:00 file:42] hello"
    )
    record.msg = "hello\nworld"
    assert formatter.format(record) == (
        "[D 160101 00:00:00 file:42] hello\n    world"
    )
    record.exc_info = sys.exc_info()

# Generated at 2022-06-18 10:24:07.877128
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-18 10:24:17.371308
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import logging
    import logging.handlers
    import sys
    import time
    import unittest

    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type

    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None

    try:
        import curses
    except ImportError:
        curses = None  # type: ignore

    from typing import Dict, Any, cast, Optional

    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")


# Generated at 2022-06-18 10:24:29.794186
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:24:37.397455
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import os
    import shutil
    import sys
    import tempfile
    import time
    import unittest

    from tornado.log import app_log, gen_log, access_log

    def get_log_file_path(log_file_prefix):
        return log_file_prefix + "." + time.strftime("%Y%m%d")

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file_prefix = os.path.join(self.temp_dir, "test_log")
            self.log_file_path = get_log_file_path(self.log_file_prefix)
            self.options = tornado

# Generated at 2022-06-18 10:25:06.442724
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-18 10:25:13.394923
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.util import b

    class TestHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super(TestHandler, self).__init__(*args, **kwargs)
            self.records = []  # type: List[logging.LogRecord]

        def emit(self, record):
            self.records.append(record)

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.logger = logging.getLogger()
            self

# Generated at 2022-06-18 10:25:22.661777
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import tempfile
    import shutil
    import unittest
    import warnings
    from tornado.test.util import unittest

    class LogTest(unittest.TestCase):
        def setUp(self):
            super(LogTest, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.stderr = sys.stderr
            self.stdout = sys.stdout
            self.stderr_fd = sys.st

# Generated at 2022-06-18 10:25:34.718091
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:25:47.557193
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
   

# Generated at 2022-06-18 10:25:56.346805
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._fmt == LogFormatter.DEFAULT_FORM

# Generated at 2022-06-18 10:26:08.286828
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "./test_log"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()
    logger = logging.getLogger()
    logger.debug("test_enable_pretty_logging")

if __name__ == "__main__":
    test_enable_pretty_

# Generated at 2022-06-18 10:26:16.859252
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"



# Generated at 2022-06-18 10:26:24.189588
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 1
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)
    assert logging.getLogger().handlers[0].maxBytes == 100

# Generated at 2022-06-18 10:26:33.345606
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file prefix")
    tornado.options.define("log_to_stderr", default=False, help="log to stderr")
    tornado.options.define("log_rotate_mode", default="size", help="log rotate mode")
    tornado.options.define("log_file_max_size", default=100000, help="log file max size")
    tornado.options.define("log_file_num_backups", default=10, help="log file num backups")
    tornado.options.define("log_rotate_when", default="midnight", help="log rotate when")

# Generated at 2022-06-18 10:27:11.540748
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={})
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True, colors={1: 1})
    assert formatter._colors == {}
    assert form

# Generated at 2022-06-18 10:27:13.676058
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # This method is not tested because it is too complicated
    pass



# Generated at 2022-06-18 10:27:26.401703
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    import io
    import sys
    import time
    import threading
    import traceback
    import warnings
    import weakref
    import functools

    class LoggingTestCase(unittest.TestCase):
        """Test logging module functionality."""

        def setUp(self):
            self.root_logger = logging.getLogger("")
            self.root_logger.setLevel(logging.NOTSET)
            self.root_logger.handlers = []
            self.logger = logging.getLogger("testlogger")
            self.logger.handlers = []
            self.logger.propagate = False
            self.logger.setLevel(logging.NOTSET)
            self.logger.manager.emittedNo

# Generated at 2022-06-18 10:27:28.585322
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()

_default_log_handler = None  # type: Optional[logging.Handler]



# Generated at 2022-06-18 10:27:37.882931
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == "%Y-%m-%d"



# Generated at 2022-06-18 10:27:49.790066
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", default="none", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file prefix")
    tornado.options.define("log_file_max_size", default=0, help="max size of log files before rollover")
    tornado.options.define("log_file_num_backups", default=0, help="number of log files to keep")
    tornado.options.define("log_rotate_mode", default="size", help="when to rotate log files")
    tornado.options.define("log_rotate_when", default="D", help="how frequently to rotate log files")

# Generated at 2022-06-18 10:27:58.342886
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.DEBUG, "", 0, "", None, None)
    record.__dict__["message"] = "Test message"
    record.__dict__["asctime"] = "2018-01-01 00:00:00"
    record.__dict__["color"] = ""
    record.__dict__["end_color"] = ""
    assert formatter.format(record) == "[D 2018-01-01 00:00:00 :0] Test message"


# Generated at 2022-06-18 10:28:08.616119
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # test for issue #1055
    import logging
    import logging.handlers
    import sys
    import time
    import unittest


# Generated at 2022-06-18 10:28:16.060298
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
   

# Generated at 2022-06-18 10:28:23.125175
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={})
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.DEBUG: 4})
    assert formatter._normal == "\033[2;34m"

    formatter = LogForm

# Generated at 2022-06-18 10:28:52.841293
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="",
        lineno=0,
        msg="",
        args=None,
        exc_info=None,
    )
    log_formatter.format(record)



# Generated at 2022-06-18 10:29:00.258669
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""
    assert formatter.formatTime(None, "") == ""
    assert formatter.formatException(None) == ""
    assert formatter.format(None) == ""
    assert formatter.format(logging.LogRecord("", "", "", 0, "", None, None)) == ""



# Generated at 2022-06-18 10:29:09.769271
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import tornado.escape
    import tornado.util
    import tornado.log
    import tornado.options
    import tornado.ioloop
    import tornado.httpserver
    import tornado.web
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.stack_context
    import tornado.template
    import tornado.escape
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.locale
    import tornado.locks
    import tornado.netutil
    import tornado.options
    import tornado.process
    import tornado.queues
    import tornado.simple_httpclient
    import tornado.stack_context

# Generated at 2022-06-18 10:29:19.584434
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors != {}
    assert formatter._normal != ""

    formatter = LogFormatter(color=True, fmt="%(message)s")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors != {}

# Generated at 2022-06-18 10:29:31.548024
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 1
    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG
    assert len(logging.getLogger().handlers) == 1
    assert isinstance(logging.getLogger().handlers[0], logging.handlers.RotatingFileHandler)
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "S"

# Generated at 2022-06-18 10:29:41.986392
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-18 10:29:46.582360
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    print("test_enable_pretty_logging")
    print("test_enable_pretty_logging")
    print("test_enable_pretty_logging")
    print("test_enable_pretty_logging")
    print("test_enable_pretty_logging")
    print("test_enable_pretty_logging")

# Generated at 2022-06-18 10:29:59.118779
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    assert formatter.format(record) == "[I test.py:1] test"
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    record.exc_info = "test"
    assert formatter.format(record) == "[I test.py:1] test"
    record = logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "test", None, None)
    record.exc_info = "test"
    record.exc_text = "test"

# Generated at 2022-06-18 10:30:10.586444
# Unit test for method format of class LogFormatter

# Generated at 2022-06-18 10:30:19.356459
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import ObjectDict
    from tornado.log import enable_pretty_logging
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado

# Generated at 2022-06-18 10:31:53.513464
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import tempfile
    import os
    import shutil
    import time
    import unittest
    import sys
    import io
    import re
    import warnings
    import contextlib

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io = io.StringIO()
            self.handler = logging.StreamHandler(self.io)
            self.handler.setFormatter(tornado.log.LogFormatter())
            self.logger = logging.getLogger()
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()


# Generated at 2022-06-18 10:32:04.672023
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

# Generated at 2022-06-18 10:32:13.701096
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(
        fmt="%(color)s%(message)s%(end_color)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={logging.DEBUG: 1, logging.INFO: 2, logging.WARNING: 3},
    )
    assert formatter.datefmt == "%Y-%m-%d %H:%M:%S"

# Generated at 2022-06-18 10:32:23.024159
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import os
    import shutil
    import tempfile
    import time
    import unittest
    from tornado.options import define, options

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.old_loggers = dict(
                (name, logging.getLogger(name)) for name in ("tornado.access", "tornado.application", "tornado.general")
            )
            self.old_options = dict(options.items())
            self.tmpdir = tempfile.mkdtemp()
            self.stderr = io.StringIO()
            self

# Generated at 2022-06-18 10:32:25.617600
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()
    logger.handlers[0].setFormatter(LogFormatter())
    logger.debug("test")
    logger.info("test")
    logger.warning("test")
    logger.error("test")
    logger.critical("test")


# Generated at 2022-06-18 10:32:34.590025
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class LoggingTest(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.mktemp()
            self.options = tornado.options.options
            self.options.log_to_stderr = False
            self.options.log_file_prefix = self.log_file
            self.options.log_file_max_size = 100
            self.options.log_file_num_backups = 1
            self.options.log_rotate_mode = "size"
            self.options.log_rotate_when = "S"
            self.options.log

# Generated at 2022-06-18 10:32:45.720010
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import os
    import time
    import shutil
    import tempfile
    import unittest
    import warnings
    from tornado.util import b
    from tornado.log import LogFormatter
    from tornado.log import enable_pretty_logging
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.log import access_log
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import LogFormatter
    from tornado.log import _stderr_supports_color
    from tornado.log import _safe_unicode
    from tornado.log import Log