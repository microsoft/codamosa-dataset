

# Generated at 2022-06-24 08:43:34.754097
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class dictObj(object):
        def __init__(self, d: Dict[str, Any]):
            self.__dict__.update(d)
    rec = dictObj(
        {
            "levelno": logging.ERROR,
            "msg": "test",
            "args": (),
            "levelname": "ERROR",
            "pathname": "/foo/bar",
            "filename": "bar",
            "module": "foo",
            "funcName": "main",
            "lineno": 1,
            "asctime": "2017-12-15 22:00:04,348",
            "threadName": "MainThread",
            "created": 1513345604.348,
        }
    )

# Generated at 2022-06-24 08:43:40.680048
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, parse_config_file, options
    define("foo",default="bar")
    define("logging",default="info",help=("Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."),metavar="debug|info|warning|error|none")
    define("log_to_stderr",type=bool,default=None,help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."))

# Generated at 2022-06-24 08:43:43.691164
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.options
    define_logging_options()
    options.parse_config_file('test_tornado_log.conf')
    assert options.log_rotate_mode == 'size'
    assert options.logging == 'info'

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:43:52.581561
# Unit test for function define_logging_options
def test_define_logging_options():

    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print(options.logging);
    print(options.log_to_stderr);
    print(options.log_file_prefix);
    print(options.log_file_max_size);
    print(options.log_file_num_backups);
    print(options.log_rotate_when);
    print(options.log_rotate_interval);
    print(options.log_rotate_mode);


# Generated at 2022-06-24 08:43:56.597440
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: () -> None
    formatter = LogFormatter()
    # Make sure constructor does not fail
    assert True


# Generated at 2022-06-24 08:44:01.297970
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    opt = tornado.options.OptionParser()
    define_logging_options(opt)
    opt.parse_command_line(['-log_rotate_when','W3'])
    enable_pretty_logging(opt)
    print('unit test passed')

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:44:05.078465
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_fmt = LogFormatter()
    assert isinstance(log_fmt._fmt, str)
    assert isinstance(log_fmt._colors, dict)
    assert isinstance(log_fmt._normal, str)

# Generated at 2022-06-24 08:44:09.026650
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:44:16.979222
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    mydict = {'color': '', 'message': 'Hello world', 'end_color': ''}
    mydict.update({'levelname': 'INFO', 'asctime': 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST'})
    mydict.update({'module': 'tornado.testing', 'lineno': 100})
    mystring = lf.format(mydict)
    assert len(mystring) == 154



# Generated at 2022-06-24 08:44:25.281239
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    from tornado.log import LogFormatter, enable_pretty_logging, app_log, gen_log
    import logging
    import logging.handlers
    options.define("log_to_stderr", type=bool, default=True)
    enable_pretty_logging()
    app_log.error("Test enable_pretty_logging")
    enable_pretty_logging(options)
    app_log.error("Test enable_pretty_logging with options")
    enable_pretty_logging(options, gen_log)
    gen_log.error("Test enable_pretty_logging with options and logger")
    options.logging = "critical"
    options.log_file_prefix = "./test.log"
    options.log_file_num_backups = 10


# Generated at 2022-06-24 08:44:31.824856
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    logging_options = define_logging_options(options)

    options.parse_command_line(args=['-logging=none'])
    assert logging_options == None

    options.parse_command_line(args=['-log_to_stderr=False'])
    assert logging_options == False

# Generated at 2022-06-24 08:44:40.519029
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    fmt = LogFormatter()
    fmt = LogFormatter(color=True)
    fmt = LogFormatter(color=False)
    fmt = LogFormatter(colors={})
    fmt = LogFormatter(colors={logging.CRITICAL: 10})

    # Wrong logging level
    try:
        fmt = LogFormatter(colors={'not a real level': 10})  # type: ignore
        assert False, "Should have thrown ValueError"
    except ValueError:
        pass

    if curses is not None:
        try:
            fmt = LogFormatter(colors={logging.CRITICAL: 50})  # type: ignore
            assert False, "Should have thrown ValueError"
        except ValueError:
            pass



# Generated at 2022-06-24 08:44:47.073085
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    logging.basicConfig()
    l = logging.getLogger()
    l.setLevel(logging.DEBUG)

    # simple test
    f = LogFormatter()
    handlers = [logging.StreamHandler()]  # type: ignore
    for h in handlers:
        h.setLevel(logging.DEBUG)
        h.setFormatter(f)
        l.addHandler(h)
    l.info('error')

# Singleton formatter used by all request loggers
_default_formatter = LogFormatter()



# Generated at 2022-06-24 08:44:54.123522
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=0)
    enable_pretty_logging({'logging': 'none'})
    enable_pretty_logging({'logging': 'debug'})
    enable_pretty_logging({'logging': 'warning'})
    enable_pretty_logging({'logging': 'error'})
    enable_pretty_logging({'logging': 'critical'})
    enable_pretty_logging({'logging': 'info'})
    enable_pretty_logging({'logging': 'notset'})
    enable_pretty_logging({'logging': 'foo'})

# Generated at 2022-06-24 08:44:59.964093
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s%(levelname)s %(end_color)s %(message)s"
    f = LogFormatter(fmt=fmt, color=True)
    # Format an error record
    rec = logging.LogRecord(
        "foo", logging.ERROR, "/x", 1, "Hello %s", args=["World"], exc_info=1
    )
    assert "ERROR Hello World" in f.format(rec)

# Generated at 2022-06-24 08:45:04.008050
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    record = logging.LogRecord("test_LogFormatter", logging.DEBUG, pathname="foo.py", lineno=15, msg="msg", args=(), exc_info=None)
    record.funcName = "func"
    output = formatter.format(record)
    assert output == "[D 20001201 23:59:59 foo:15] func() msg"

    formatter = LogFormatter(color=False)
    output = formatter.format(record)
    assert output == "[D 20001201 23:59:59 foo:15] func() msg"



# Generated at 2022-06-24 08:45:10.417503
# Unit test for function define_logging_options
def test_define_logging_options():
    options = {}
    define_logging_options(options)
    options = {}
    define_logging_options(options)
    options = {}
    define_logging_options(options)


if __name__ == "__main__":
    test_define_logging_options()
    from tornado.log import gen_log as log
    log.warning("test")

# Generated at 2022-06-24 08:45:22.950808
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from io import StringIO
    from tornado.options import options, define
    from tornado.log import access_log, app_log, gen_log, LogFormatter

    logging_stringio = StringIO()
    define("log_to_stderr", type=bool)
    define("logging", default="debug")
    define("log_file_prefix", default=logging_stringio)
    gen_log.propagate = 0

    enable_pretty_logging()
    assert access_log.level == app_log.level == gen_log.level == logging.DEBUG
    assert options.log_to_stderr is True

    app_log.warning("test")
    gen_log.warning("testing")
    access_log.info("tested")
    assert logging_stringio.getvalue() == ""


# Generated at 2022-06-24 08:45:30.901282
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    class MockLogRecord:
        pass
    log = MockLogRecord()
    log.__dict__ = {
        "levelno": logging.INFO,
        "asctime": datetime.datetime(2020,9,18,17,30,20,123456),
        "module": "module",
        "lineno": 12,
        "message": "message"
    }
    log_formatter = LogFormatter() # noqa: F841
    assert log_formatter.format(log) == "[I 20200918 17:30:20 module:12] message"



# Generated at 2022-06-24 08:45:36.970753
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    from tornado.log import gen_log
    from tornado.options import define, options, parse_command_line
    import unittest
    import tempfile
    import os
    import re

    class LogFormatterTest(unittest.TestCase):
        """Unit tests for tornado.log.LogFormatter."""
        def setUp(self):
            define("log_file_prefix", type=str,
                default=os.path.join(tempfile.gettempdir(),
                    "tornado_test_log.txt"),
                help="Path prefix for log files")
            define("log_to_stderr", type=bool, default=True)
            define("logging", default="none")
            parse_command_line(['--logging=debug'])
            self.logger

# Generated at 2022-06-24 08:45:47.607985
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import unittest2
    from tornado.options import options

    options.logging = None
    options.parse_command_line([])

    class Test(unittest2.TestCase):
        def test_log(self):
            class MockLogRecord:
                def __init__(self, message):
                    self.__dict__["msg"] = message
                def __getattr__(self, name):
                    return self.__dict__[name]
                def __setattr__(self, name, value):
                    self.__dict__[name] = value

            logger = logging.getLogger("tornado.application")
            logger.setLevel(logging.DEBUG)
            self.assertTrue(LogFormatter())


# Generated at 2022-06-24 08:45:50.694539
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:45:55.445604
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log = logging.LogRecord(
        "tornado.test", logging.INFO, "/fakepath", 999, "Test Log", None, None
    )
    logf = LogFormatter()
    l = logf.format(log)
    assert l == "[I test_log_support.py:999] Test Log"

# Generated at 2022-06-24 08:46:07.671706
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    format = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = '%y%m%d %H:%M:%S'
    style = '%'
    color = True
    colors = {logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
            }
    fmt = LogFormatter(
        fmt=format,
        datefmt=datefmt,
        style=style,
        color=color,
        colors=colors,
    )
   

# Generated at 2022-06-24 08:46:17.346160
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf.DEFAULT_FORMAT == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa: E501
    assert lf.DEFAULT_DATE_FORMAT == '%y%m%d %H:%M:%S'
    assert lf.DEFAULT_COLORS == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }



# Generated at 2022-06-24 08:46:21.989032
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Get the expected value
    fm = LogFormatter()
    record = logging.LogRecord('name', logging.INFO, None, None, 'message', None, None)
    expexted_value = "[I  1970-01-01 01:00:00 name:0] message"
    # Get the actual value
    actual_value = fm.format(record)
    # Compare and assert
    assert actual_value == expexted_value
    # print(expexted_value)


# Generated at 2022-06-24 08:46:32.239678
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("logging", default="info", metavar="debug|info|warning|error|none")
    define("log_to_stderr", type=bool, default=None)
    define("log_file_prefix", type=str, default=None, metavar="PATH")
    define("log_file_max_size", type=int, default=100 * 1000 * 1000)
    define("log_file_num_backups", type=int, default=10)
    define("log_rotate_when", type=str, default="midnight")
    define("log_rotate_interval", type=int, default=1)
    define("log_rotate_mode", type=str, default="size")

# Generated at 2022-06-24 08:46:38.032221
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    class TestRecord(object):
        """An empty class."""
        pass

    record = TestRecord()
    assert isinstance(record, object)

    record.levelno = logging.INFO
    record.levelname = 'INFO'
    record.pathname = '/etc/passwd'
    record.filename = 'lib.py'
    record.module = 'lib'
    record.lineno = 1337
    record.funcName = 'my_func'
    record.created = 12581249
    record.asctime = 'asctime'
    record.msecs = 1337
    record.thread = 'thread'
    record.threadName = 'threadName'
    record.process = 1337
    record.processName = 'processName'
    record.message = 'message'



# Generated at 2022-06-24 08:46:49.636132
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    LogFormatter(
        fmt = fmt,
        datefmt = datefmt,
        style = "%",
        color = color,
        colors = colors
    )

_DEFAULT_LOG

# Generated at 2022-06-24 08:46:57.178540
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord(
        name="tornado.access",
        level=logging.DEBUG,
        pathname="/path/to/file.py",
        lineno=42,
        msg="logging a message",
        args=(),
        exc_info=None,
    )

    formatter = LogFormatter()
    output = formatter.format(record)
    assert output == "[D %s tornado.access:42] logging a message" % record.asctime

    # At least on Windows, the exception output includes the exception
    # type and exception value after the traceback.
    record.exc_info = (
        TypeError,
        TypeError("Oups"),
        None,
    )  # type: Optional[Any]
    output = formatter.format(record)

# Generated at 2022-06-24 08:47:00.628373
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print('You can only test this method in unit test mode. '
          'Please set the environment variable UT_MODE to value \'test\' '
          'and run the program again.')



# Generated at 2022-06-24 08:47:02.700285
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert isinstance(formatter, logging.Formatter)


# Generated at 2022-06-24 08:47:05.926093
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    c = LogFormatter()
    d = LogFormatter(color=False)
    assert c._colors
    assert not d._colors
    e = LogFormatter(colors={})
    assert not e._colors

# Generated at 2022-06-24 08:47:09.426252
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        enable_pretty_logging()
    except:
        assert False,"Enable Pretty Logging failed"
    assert True,"Enable Pretty Logging successful"

test_enable_pretty_logging()

# Generated at 2022-06-24 08:47:18.070240
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print('### Unit test for method format of class LogFormatter')
    logfmt1 = LogFormatter(LogFormatter.DEFAULT_FORMAT,
                           LogFormatter.DEFAULT_DATE_FORMAT,
                           style="%",
                           color=True,
                           colors=LogFormatter.DEFAULT_COLORS)
    logfmt2 = LogFormatter(LogFormatter.DEFAULT_FORMAT,
                           LogFormatter.DEFAULT_DATE_FORMAT,
                           style="%",
                           color=False,
                           colors=LogFormatter.DEFAULT_COLORS)

# Generated at 2022-06-24 08:47:28.987962
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest

    def setup_func(self):
        # type: () -> None
        self.log_fmt = LogFormatter()

    def test_LogFormatter_format(self):
        # type: () -> None
        """
        LogFormatter.format should not alter the message when there are no
        exceptions.
        """
        msg = "log with no exception"

        record = logging.LogRecord(
            "tornado.test.test_log",
            logging.DEBUG,
            "/path/to/nowhere",
            0,
            msg,
            None,
            None,
        )

        self.assertEqual(self.log_fmt.format(record), msg)


# Generated at 2022-06-24 08:47:36.504534
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.options
    define_logging_options(options)
    #tornado.options.parse_command_line(["--log_file_prefix=foo"])
    #tornado.options.parse_command_line("--logging=none".split())
    #tornado.options.parse_config_file("logging=none")
    #tornado.options.parse_command_line("--logging=info".split())
    #tornado.options.parse_config_file("logging=info")
    #tornado.options.parse_config_file("log_to_stderr=1")
    #tornado.options.parse_command_line("--log_to_stderr=0".split())
    #tornado.options.parse_config_file("log_

# Generated at 2022-06-24 08:47:47.085532
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    # The first argument for enable_pretty_logging() is not used in this test
    # case.
    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "log.txt"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1000
    options.log_file_num_backups = 3
    options.log_to_stderr = False
    logger = logging.getLogger()
    enable_pretty_logging(None, logger)
    assert logger.level == logging.DEBUG
    assert len(logger.handlers) == 1
    assert logger.handlers[0].__class__ == logging.handlers.RotatingFileHandler
    logger.handlers.pop()
    options

# Generated at 2022-06-24 08:47:54.510747
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Instanciate a logger
    logger = logging.getLogger("test_LogFormatter_format")
    logger.setLevel(logging.INFO)
    # Instanciate a logformatter, with color support
    formatter = LogFormatter(color=True)
    # Instanciate a Handler and add it to the logger
    stream = logging.StreamHandler()
    stream.setLevel(logging.INFO)
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    # Test a log message with a unicode string
    test_str = 'Je ne suis pas une « chaine de caractère » unicode'
    logger.info('Test for log message with a unicode string: %s', test_str)


_default_log_handler = None  # type: Optional[

# Generated at 2022-06-24 08:47:56.257757
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-24 08:48:02.943223
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Object:
        pass
    record = Object()
    record.__dict__ = dict(color='color', end_color='end_color')
    record.__dict__.update(dict(levelname='levelname', asctime='asctime', lineno='lineno', module='module'))
    record.message = 'message'
    log_formatter = LogFormatter()
    assert(log_formatter.format(record) == '[levelname asctime module:lineno] message')



# Generated at 2022-06-24 08:48:05.303727
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:48:16.064935
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    str1 = '^A'
    record = {
        'x': 'xx',
        'y': 'yy',
        'message': 'hello world',
        'asctime': 'Mon, 23 Jan 2017 23:55:55 GMT',
        'levelname': 'DEBUG',
        'funcName': 'test_LogFormatter_format',
        'module': 'test_log.py',
        'lineno': '28',
        'color': u'\u001b[00;31m',
        'end_color': ''
        }
    formatter = LogFormatter()
    assert formatter.format(record) == '[D Mon, 23 Jan 2017 23:55:55 GMT test_log.py:28] hello world'
    record['message'] = str1
    record['levelname'] = 'ERROR'
    assert form

# Generated at 2022-06-24 08:48:18.014038
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    define_logging_options(options)

# Generated at 2022-06-24 08:48:18.966269
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:48:21.470882
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    logger = logging.getLogger()
    tornado.options.enable_pretty_logging(logger=logger)

# Generated at 2022-06-24 08:48:32.247530
# Unit test for function define_logging_options
def test_define_logging_options():
    if sys.version_info[0] < 3:
        from io import BytesIO as StringIO
    else:
        from io import StringIO
    import tornado.options

    logging.getLogger().handlers = []
    old_stderr = sys.stderr

# Generated at 2022-06-24 08:48:42.320000
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, define, parse_command_line
    define("logging", default="info")
    parse_command_line(["--logging=none", "--help"])
    define("log_to_stderr", default=None, help=("test"))
    define("log_file_prefix", default=None, help=("test"))
    define("log_file_max_size", default=100 * 1000 * 1000)
    define("log_file_num_backups", default=10)
    define("log_rotate_when", default="midnight")
    define("log_rotate_interval", default=1)
    define("log_rotate_mode", default="size")
    

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 08:48:53.929517
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="test_logging.py",
        lineno=6,
        msg="test",
        args=None,
        exc_info=None,
    )
    print(formatter.format(record))
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="test_logging.py",
        lineno=6,
        msg="test",
        args=None,
        exc_info=None,
    )
    print(formatter.format(record))



# Generated at 2022-06-24 08:49:04.090983
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)
    assert tornado.options.options.log_to_stderr == None
    assert tornado.options.options.log_file_prefix == None
    assert tornado.options.options.log_file_max_size == 100 * 1000 * 1000
    assert tornado.options.options.log_file_num_backups == 10
    assert tornado.options.options.log_rotate_when == 'midnight'
    assert tornado.options.options.log_rotate_interval == 1
    assert tornado.options.options.log_rotate_mode == 'size'
# test_define_logging_options()

# Generated at 2022-06-24 08:49:05.214264
# Unit test for function define_logging_options
def test_define_logging_options():
    assert define_logging_options() == None


# Generated at 2022-06-24 08:49:08.030297
# Unit test for function define_logging_options
def test_define_logging_options():
    options_test=define_logging_options()

# Generated at 2022-06-24 08:49:09.118899
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:49:16.217198
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test, main
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.log import enable_pretty_logging

    enable_pretty_logging()

    class TestEnablePrettyLogging(AsyncTestCase):
        @gen_test
        def test_enable_pretty_logging(self):
            self.assertTrue(True)

    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    unittest.main()

# Generated at 2022-06-24 08:49:26.064789
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter._stderr_supports_color = lambda: False
    try:
        import unittest.mock
    except ImportError:
        import mock
    else:
        import unittest.mock as mock
    logging.LogRecord = unittest.mock.MagicMock
    lf = LogFormatter(
        '%(color)s%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s%(end_color)s',
        datefmt='%y%m%d %H:%M:%S'
    )
    lf.format(mock.Mock())



# Generated at 2022-06-24 08:49:33.055474
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == ""

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal != ""

    formatter = LogFormatter(color=False, fmt='%(foo)s %(bar)s', datefmt='%H:%M:%S')
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter._fmt == '%(foo)s %(bar)s'

# Generated at 2022-06-24 08:49:34.732717
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.Formatter()


# Generated at 2022-06-24 08:49:45.603754
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import getopt
    import tempfile
    import unittest
    import os
    import logging
    import sys
    import tornado.options

    class OptionsTestCase(unittest.TestCase):
        def test_logging(self):
            tmpdir = tempfile.mkdtemp(prefix="tornado_test")

# Generated at 2022-06-24 08:49:52.687145
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import time

    def test_logger_object():
        options = tornado.options.options
        options.logging = "debug"
        options.log_to_stderr = False
        options.log_file_prefix = "test_log"
        options.log_rotate_mode = "size"
        options.log_file_max_size = 1024
        options.log_file_num_backups = 3
        options.log_rotate_interval = 1
        options.log_rotate_when = "D"
        logger = logging.getLogger("tornado.test")
        tornado.log.enable_pretty_logging(options, logger)
        logger.debug("debug msg")
        logger.info("info msg")
        logger.warn("warn msg")

# Generated at 2022-06-24 08:49:57.820876
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:50:02.167639
# Unit test for function define_logging_options
def test_define_logging_options():
    tornado.options.enable_parse_known_args()
    define_logging_options()
    tornado.options.parse_command_line()

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:50:12.343115
# Unit test for function define_logging_options
def test_define_logging_options():
    class Options(object):
        def __init__(self) -> None:
            self.logging = "info"
            self.log_to_stderr = True
            self.log_file_prefix = "PATH"
            self.log_file_max_size = int(100 * 1000 * 1000) 
            self.log_file_num_backups = int(10)
            self.log_rotate_when = "midnight"
            self.log_rotate_interval = int(1)
            self.log_rotate_mode = "size"
    options = Options()
    define_logging_options(options)
    enable_pretty_logging(options)
    assert options.logging == "info"
    assert options.log_to_stderr == True
    assert options.log_file_

# Generated at 2022-06-24 08:50:14.166251
# Unit test for function define_logging_options
def test_define_logging_options():
    options = None
    define_logging_options(options)

# Generated at 2022-06-24 08:50:25.108350
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import unittest
    from tornado.testing import LogTrapTestCase

    class LogFormatterTestCase(unittest.TestCase, LogTrapTestCase):
        def test_default_case(self):
            formatter = LogFormatter()
            self.assertEqual(formatter._fmt, LogFormatter.DEFAULT_FORMAT)
            self.assertIsNone(formatter.datefmt)
            self.assertEqual(formatter._colors, LogFormatter.DEFAULT_COLORS)

        def test_custom_log_format(self):
            custom_format = "%(message)s"
            formatter = LogFormatter(fmt=custom_format)
            self.assertEqual(formatter._fmt, custom_format)
            self.assertIsNone(formatter.datefmt)
            self

# Generated at 2022-06-24 08:50:34.085176
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    opts = LogFormatter()
    opts.DEFAULT_FORMAT = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    opts.DEFAULT_DATE_FORMAT = "%y%m%d %H:%M:%S"
    opts.DEFAULT_COLORS = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    enable_pretty_logging()

# Generated at 2022-06-24 08:50:38.572411
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print(options.log_file_num_backups)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:50:50.025774
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """Unit tests for LogFormatter constructor."""
    assert LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT
    assert LogFormatter().datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    f = LogFormatter(
        fmt="%(levelno)d: %(asctime)s %(module)s %(funcName)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    assert f._fmt == "%(levelno)d: %(asctime)s %(module)s %(funcName)s %(message)s"  # noqa: E501
    assert f.datefmt == "%Y-%m-%d %H:%M:%S"



# Generated at 2022-06-24 08:51:00.517859
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class FakeLogRecord:
        def __init__(self, level, msg, args, exc_info, extra) -> None:
            self.levelno = level
            self.msg = msg
            self.args = args
            self.exc_info = exc_info
            self.__dict__.update(extra)

    def t(message, **kwargs):
        return message % kwargs

    def tdata(level, message, **kwargs):
        return level, t(message, **kwargs), (), None, kwargs

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    formatter = LogFormatter()

# Generated at 2022-06-24 08:51:08.819241
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from typing import Dict
    import tornado.options
    from tornado.options import define
    from tornado.options import options

# Generated at 2022-06-24 08:51:13.678234
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()

    assert formatter._colors[logging.WARNING] == "\033[2;33m"
    assert formatter._colors[logging.ERROR] == "\033[2;31m"
    assert formatter._colors[logging.CRITICAL] == "\033[2;35m"



# Generated at 2022-06-24 08:51:24.105510
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class TestLogFormatter(LogFormatter):
        def __init__(self, fmt: Optional[str] = None, datefmt: Optional[str] = None, style: Optional[str] = None, color: Optional[bool] = None, colors: Optional[Dict[int, int]] = None) -> None:
            super()
            self.fmt = fmt
            self.datefmt = datefmt
            self.style = style
            self.color = color
            self.colors = colors


# Generated at 2022-06-24 08:51:35.561932
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("logging", default="info", type=str)
    define("log_to_stderr", default=None, type=bool)
    define("log_file_prefix", default=None, type=str)
    define("log_file_max_size", default=100 * 1000 * 1000, type=int)
    define("log_file_num_backups", default=10, type=int)
    define("log_rotate_when", default="midnight", type=str)
    define("log_rotate_interval", default=1, type=int)
    define("log_rotate_mode", default="size", type=str)
    parse_command_line()

    logging.info("Hello World!")

# Generated at 2022-06-24 08:51:36.466101
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.warning("test")

# Generated at 2022-06-24 08:51:40.243309
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(fmt='123')
    LogFormatter(datefmt='123')
    LogFormatter(colors={})
    LogFormatter(color=False)
    LogFormatter(fmt='123', datefmt='123', colors={}, color=False)


# Generated at 2022-06-24 08:51:48.183119
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    
    options = tornado.options.options
    define_logging_options(options)
    assert "logging" in options.keys()
    assert "log_to_stderr" in options.keys()
    assert "log_file_prefix" in options.keys()
    assert "log_file_max_size" in options.keys()
    assert "log_file_num_backups" in options.keys()
    assert "log_rotate_when" in options.keys()
    assert "log_rotate_interval" in options.keys()

# Generated at 2022-06-24 08:52:00.482589
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(color=True, colors=colors)
    if curses is not None:
        fg_color = curses.tigetstr("setaf") or curses.tigetstr("setf") or b""

# Generated at 2022-06-24 08:52:04.767780
# Unit test for function define_logging_options
def test_define_logging_options():
    # 直接使用这个函数，返回值就是所有的参数列表，其实就是所有的打印的参数信息。
    print(define_logging_options(2))


if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:52:06.309482
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)

# Generated at 2022-06-24 08:52:17.924268
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    from tornado.log import LogFormatter
    from typing import Dict
    define_logging_options(tornado.options.options)
    assert tornado.options.options.logging == 'info'
    assert tornado.options.options.log_to_stderr == None
    assert tornado.options.options.log_file_prefix == None
    assert tornado.options.options.log_file_max_size == 100 * 1000 * 1000
    assert tornado.options.options.log_file_num_backups == 10
    assert tornado.options.options.log_rotate_when == "midnight"
    assert tornado.options.options.log_rotate_interval == 1
    assert tornado.options.options.log_rotate_mode == "size"

# Generated at 2022-06-24 08:52:20.963169
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    options=OptionParser()
    define_logging_options(options)
    options.parse_command_line()
    enable_pretty_logging(options)
    print(options.logging)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:52:22.083301
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-24 08:52:27.258833
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = "none"
    enable_pretty_logging()
    assert len(logging.getLogger().handlers) is 0

    tornado.options.options.logging = "info"
    enable_pretty_logging()
    assert len(logging.getLogger().handlers) is 1


# Generated at 2022-06-24 08:52:39.409519
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # This is dummy test, please see LogFormatter.__init__
    import sys
    import pprint

    # Python 2.7
    log_format = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    log_datefmt = "%y%m%d %H:%M:%S"
    log_style = "%"
    log_color = True
    log_colors = {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}

    try:
        import colorama
        colorama.init()  # Does not work in Jupyter Notebook
    except:
        pass

# Generated at 2022-06-24 08:52:49.575075
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFmter = LogFormatter()
    # Test inherit from logging.Formatter
    assert isinstance(logFmter,logging.Formatter)
    # Test for method format of the class LogFormatter
    # Test for the parent class method format
    import logging
    import logging.handlers
    record = logging.LogRecord("Test","20","filePath_1","10","logMessage_1","args","exc_info_tuple_1")
    logFmter = LogFormatter()
    # Test for the parent class method format
    assert logFmter.format(record) == "[Test 20 filePath_1:10] logMessage_1"
    logFmter.datefmt = "%Y-%m-%d %H:%M:%S"

# Generated at 2022-06-24 08:52:50.872110
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:52:52.406846
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    a = LogFormatter()
    assert a


# Generated at 2022-06-24 08:52:55.975855
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general","DEBUG","/tornado/log.py",82,formatter.DEFAULT_FORMAT,["a"],None)
    formatter.format(record)

# Generated at 2022-06-24 08:53:05.506160
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_command_line([])
    tornado.options.options.log_file_prefix = "./log"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.logging = "debug"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "M"
    tornado.options.options.log_rotate_interval = 1
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-24 08:53:07.246045
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    raise DeprecationWarning(
        "Test fails since not need to test in Tornado anymore"
    )



# Generated at 2022-06-24 08:53:08.555685
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:53:13.092374
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert hasattr(formatter, '_fmt')
    assert hasattr(formatter, '_colors')
    assert hasattr(formatter, '_normal')
    return formatter


# Generated at 2022-06-24 08:53:25.608601
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "./log/log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 10240
    tornado.options.options.log_file_num_backups = 3
    enable_pretty_logging()

    logger = logging.getLogger("test")

    for i in range(1000):
        logger.info("Test log info.")
        logger.error("Test log error.")
        logger.debug("Test log debug.")
        logger.warning("Test log warning.")


if __name__ == "__main__":
    test_enable_pretty_logging()