

# Generated at 2022-06-24 08:43:31.248997
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.log_to_stderr = True
    tornado.options.options.logging = "error"
    try:
        tornado.log.enable_pretty_logging()
    except Exception as e:
        print("Test case for function enable_pretty_logging failed. Error:",e)
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:43:41.242686
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=False)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=False, fmt="%(message)s", datefmt="%Y")
    assert formatter._fmt == "%(message)s"
    assert formatter._colors == {}
    assert formatter._normal == ""



# Generated at 2022-06-24 08:43:41.706584
# Unit test for function define_logging_options
def test_define_logging_options():
    pass

# Generated at 2022-06-24 08:43:47.050683
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_file_prefix", "log.txt")
    tornado.options.define("log_to_stderr", True)
    tornado.options.define("logging", "DEBUG")
    tornado.options.define("log_file_max_size", 100)
    tornado.options.define("log_file_num_backups", 1)
    tornado.options.define("log_rotate_mode", "size")
    tornado.options.define("log_rotate_when", '')
    tornado.options.define("log_rotate_interval", '')

    enable_pretty_logging()


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:43:55.666103
# Unit test for function define_logging_options
def test_define_logging_options():
    '''
        Definition:
            def define_logging_options(options: Optional[Any] = None) -> None:
                options.logging.upper()

                # When log_rotate_mode option is 'size'
                options.log_file_prefix = None
                options.log_file_max_size = 100 * 1000 * 1000
                options.log_file_num_backups = 10
                options.log_to_stderr = None

                # When log_rotate_mode option is 'time'
                options.log_rotate_when = 'midnight'
                options.log_rotate_interval = 1
    '''
    import tornado.options
    options = tornado.options.options

    options.logging = 'DE'
    assert options.logging.upper() == 'DEBUG'

    options.log

# Generated at 2022-06-24 08:44:04.697521
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class DummyRecord(object):
        __slots__ = ["__dict__"]

        def __init__(self) -> None:
            self.__dict__ = {}  # type: Dict[str, Any]

    def prepare_record(message: str, **kwargs: Any) -> Any:
        record = DummyRecord()
        record.message = message
        record.__dict__.update(kwargs)
        return record

    formatter = LogFormatter()
    record = prepare_record("foo")
    assert formatter.format(record) == "foo"
    record = prepare_record("foo", color="c1", end_color="ce1")
    assert formatter.format(record) == "foo"

# Generated at 2022-06-24 08:44:11.411735
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Record:
        pass
    r = Record()
    r.name = 'name'
    r.levelno = 1
    r.processName = 'processName'
    r.created = 100
    r.process = 'process'
    r.lineno = 1
    r.filename = 'filename'
    r.module = 'module'
    r.pathname = 'pathname'
    r.exc_info = 'exc_info'
    r.exc_text = 'exc_text'
    r.msecs = 1.23
    r.levelname = 'levelname'
    r.thread = 'thread'
    r.message = 'message'


# Generated at 2022-06-24 08:44:18.222847
# Unit test for function define_logging_options
def test_define_logging_options():
    """This unit test is mainly to prevent regressions and
    to ensure that the options are defined correctly.
    """
    import logging
    import io
    import os
    import time

    import tornado.options

    options = tornado.options.OptionParser()
    define_logging_options(options)

    # Testing options
    # Very low values for testing purposes.
    options.log_file_max_size = 1
    options.log_file_num_backups = 3
    options.log_rotate_when = "S"
    options.log_rotate_interval = 1

    # Parse these options
    opts = options.parse_config_file(
        os.path.join(os.path.dirname(__file__), "logging_options.conf")
    )

    # Log a message so we can test

# Generated at 2022-06-24 08:44:31.309287
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.testing import AsyncTestCase
    from tornado.testing import LogTrapTestCase
    from tornado.testing import gen_test
    from tornado.log import LogFormatter

    import logging
    import logging.config
    import logging.handlers
    import time

    # https://github.com/python/asyncio/issues/376
    import asyncio
    import concurrent.futures

    (
        r"""<Record: tornado.testing, 30, test_LogFormatter_format, test_logger.py, 38, \
(), {'color': '\x1b[0;32m', 'end_color': '\x1b[0m', 'levelname': 'INFO', 'asctime': \
'200426042000', 'message': 'test message'}>"
    """)


# Generated at 2022-06-24 08:44:40.779158
# Unit test for function define_logging_options
def test_define_logging_options():
    import logging.config
    import tornado.options

    class MyOptions(tornado.options.OptionParser):
        pass

    options = MyOptions()
    define_logging_options(options)
    options.parse_command_line(["--logging", "debug", "--log_file_prefix", "log_prefix"])
    logging.config.dictConfig(options.as_dict())

    assert_equals(
        options.logging,
        "debug",
        msg="define_logging_options should define --logging with default value info",
    )

    assert_equals(
        options.log_file_prefix,
        "log_prefix",
        msg="define_logging_options should define --log_file_prefix",
    )


# Generated at 2022-06-24 08:44:41.550901
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options=None)

# Generated at 2022-06-24 08:44:45.496687
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options()
    print('test_define_logging_options')
    print(tornado.options.options)
    print(tornado.options.options.log_rotate_mode)


# Generated at 2022-06-24 08:44:55.947360
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line, CommandLineError
    define("echo", default=None, help="echo the argument(s), space-separated.", type=str, multiple=True)
    define("port", default=8889, help="run on the given port", type=int)
    define("debug", default=False, help="run in debug mode", type=bool)
    define("log_file_prefix", type=str, help="path prefix of log files")
    define("log_file_max_size", type=int, help="max size of log files before rollover")
    define("log_file_num_backups", type=int, help="number of log files to keep")
    define("log_rotate_mode", type=str, help="The mode of rotating files(time or size)")
   

# Generated at 2022-06-24 08:45:01.496876
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter._colors == formatter.DEFAULT_COLORS
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT

    formatter2 = LogFormatter(formatter.DEFAULT_FORMAT, formatter.DEFAULT_DATE_FORMAT, "%", True, formatter.DEFAULT_COLORS)
    assert formatter2._fmt == formatter.DEFAULT_FORMAT
    assert formatter2._colors == formatter.DEFAULT_COLORS
    assert formatter2.datefmt == formatter.DEFAULT_DATE_FORMAT



# Generated at 2022-06-24 08:45:05.867070
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    define_logging_options(options)
    parser = OptionParser()
    define_logging_options(parser)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:45:06.828156
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert enable_pretty_logging is not None


# Generated at 2022-06-24 08:45:10.140017
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logf = LogFormatter()
    assert logf.datefmt == LogFormatter.DEFAULT_DATE_FORMAT


# Generated at 2022-06-24 08:45:22.857318
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # The constructor of LogFormatter has the following signature:
    # LogFormatter(fmt=DEFAULT_FORMAT, datefmt=DEFAULT_DATE_FORMAT,
    #              color=True, colors=DEFAULT_COLORS)
    # The following testcases have at least one testcase for each argument.

    # The signature is compatible with dictConfig(config), so we check that
    # too.

    # fmt
    default_format = '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'  # noqa: E501
    fmt = '%(message)s'
    formatter = LogFormatter(fmt=fmt)
    assert formatter._fmt == fmt

# Generated at 2022-06-24 08:45:32.547866
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """Test log function enable_pretty_logging."""
    import tornado.options
    logger = logging.getLogger()

# Generated at 2022-06-24 08:45:44.960179
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "test.log"
    options.log_file_max_size = 10
    options.log_rotate_mode = "size"
    options.log_rotate_when = "s"
    options.log_rotate_interval = 10
    options.log_file_num_backups = 1
    options.log_to_stderr = True
    import tornado.options
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, "DEBUG"))
    if options is None:
        import tornado.options

        options = tornado.options.options
    if options.logging is None or options.logging.lower() == "none":
        return

# Generated at 2022-06-24 08:45:53.169321
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    rec = logging.makeLogRecord({
            'name': 'root',
            'level': logging.INFO,
            'pathname': 'file.py',
            'lineno': 100,
            'msg': 'msg',
            'args': (),
            'exc_info': None,
            })
    assert f.format(rec) == '[I 170405 10:04:00 file.py:100] msg'



# Generated at 2022-06-24 08:46:01.380593
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    assert fmt.format(logging.LogRecord(
        "tornado.general", logging.INFO,
        "foo.py", 42, "Something bad", (), None, None)) == "[I 121031 22:46:39 foo:42] Something bad"  # noqa: E501
    assert fmt.format(logging.LogRecord(
        "tornado.general", logging.ERROR,
        "foo.py", 42, "Something bad", (), None, None)) == "[E 121031 22:46:39 foo:42] Something bad"  # noqa: E501



# Generated at 2022-06-24 08:46:03.026690
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-24 08:46:14.854862
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    def check_color(color: bool):
        fmtr = LogFormatter(color=color)
        record = logging.LogRecord(
            "name", logging.DEBUG, pathname=None, lineno=0, msg="msg", args=None, exc_info=None
        )
        text = fmtr.format(record)
        print(text)
        assert isinstance(text, str)
        assert text.endswith("msg")

    if curses:
        # curses.setupterm() must be called to initialize color support
        curses.setupterm()
        try:
            _stderr_supports_color()
            check_color(True)
            check_color(False)
        finally:
            curses.reset_shell_mode()

# Generated at 2022-06-24 08:46:18.602391
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord(
        name = 1, level = 1,
        pathname = 1, lineno = 1,
        msg = 1, args = 1,
        exc_info = 1, func = 1
    )
    lf = LogFormatter()
    res = lf.format(record)
    pass


# Generated at 2022-06-24 08:46:29.937732
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    from tornado.options import define, parse_command_line, options
    from tornado.httpserver import HTTPServer
    define("port", default=8000, metavar="PORT", help="server port")
    define("cwd", default=None, metavar="PATH", help="change working directory")
    
    define_logging_options(options)
    parse_command_line()
    tornado.options.parse_command_line()
    if options.cwd:
        os.chdir(options.cwd)
    app = Application([
            (r"/", IndexHandler),
        ])
    app = HTTPServer(app, xheaders=True)
    app.listen(options.port)
    IOLoop.current().start()

# Generated at 2022-06-24 08:46:36.963880
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord('tornado.access', logging.INFO, 'path', 0, '%s:%s', (), None, 'message')
    obj = LogFormatter()
    output = obj.format(record)
    assert output == '    \x1b[2;37m[I 180802 10:28:47 path:0]\x1b[0m message'
test_LogFormatter_format()



# Generated at 2022-06-24 08:46:41.458384
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(fmt="%(message))")
    LogFormatter(fmt="%(message)", datefmt="%Y-%m-%d", style="%")
    LogFormatter(datefmt="%Y-%m-%d", style="%", color=True, colors={})



# Generated at 2022-06-24 08:46:50.108100
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.logging = "warning"
    options.log_file_prefix = "test_enable_pretty_logging.log"
    enable_pretty_logging(options)
    logging.warning("test enable pretty logging")
    options.logging = "none"
    enable_pretty_logging(options)
    logging.warning("test enable pretty logging after set to none")


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:46:59.117141
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.parse_command_line(['--logging', 'error'])
    gen_log.debug('debug message')
    gen_log.info('info message')
    gen_log.warning('warning message')
    gen_log.error('error message')
    gen_log.critical('critical message')


if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:47:06.216997
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    input = {
        "color": None,
        "end_color": None,
        "levelname": "INFO",
        "asctime": "2020-08-27 17:00:01,208",
        "module": "",
        "lineno": 31,
        "message": "Hello world!"
    }
    formatter = LogFormatter()
    output = formatter.format(input)
    assert output == '[I 2020-08-27 17:00:01,208 : 31] Hello world!'

# Generated at 2022-06-24 08:47:16.348841
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    datefmt = "%Y-%m-%d %H:%M:%S"
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s' # noqa: E501
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt, color=True)
    info = {'levelname': 'error', 'path': 'tornado.py'}
    formatter.format = lambda record: record.getMessage()
    access_log.setLevel(logging.DEBUG)
    access_log.addHandler(get_logging_handler("test.log", formatter))

# Generated at 2022-06-24 08:47:18.459487
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)

# Generated at 2022-06-24 08:47:23.601633
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter._colors == formatter.DEFAULT_COLORS

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""


# Generated at 2022-06-24 08:47:28.890174
# Unit test for function define_logging_options
def test_define_logging_options():
    test_arg = "--log_rotate_mode=size"
    import tornado.options
    define_logging_options()
    tornado.options.parse_command_line([test_arg])
    assert tornado.options.options.log_rotate_mode == "size"


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:47:30.576516
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.parse_command_line()

# Generated at 2022-06-24 08:47:32.741278
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    l = LogFormatter()
    l.format('test')


# Generated at 2022-06-24 08:47:45.189323
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime

    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%m%d %H:%M:%S"
    style = "%"
    #color = True
    colors = {
        logging.DEBUG: 4,  # Blue
    }

    my_formatter = LogFormatter(fmt, datefmt, style, True, colors)

    # Test format the expection
    record = logging.LogRecord('test', logging.DEBUG, '/tmp/test.py', 22, 'test', {}, '')
    record.exc_info = True

# Generated at 2022-06-24 08:47:50.571373
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # enable_pretty_logging()
    enable_pretty_logging()
    gen_log.error("Hello world!")
    enable_pretty_logging(logger=gen_log)
    gen_log.error("Hello world!")

    # enable_pretty_logging()
    gen_log.error("Hello world!")
    enable_pretty_logging(logger=gen_log)
    gen_log.error("Hello world!")


# Generated at 2022-06-24 08:48:00.174460
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True)
    def test(record):
        return formatter.format(record)
    assert test(logging.LogRecord("name", 20, "/path", 1, "message", (), None)) == "[L 20 /path:1] message"
    assert test(logging.LogRecord("name", 20, "/path", 1, "message", (), None)) == "[L 20 /path:1] message"
    assert test(logging.LogRecord("name", 30, "/path", 1, "message", (), None)) == "[E 30 /path:1] message"
    assert test(logging.LogRecord("name", 40, "/path", 1, "message", (), None)) == "[C 40 /path:1] message"


# Generated at 2022-06-24 08:48:04.676226
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.LogRecord.__str__ = lambda x: ""  # type: ignore
    formatter = LogFormatter()
    f = formatter.format
    assert f(logging.LogRecord(
        "", logging.DEBUG, "", 0, "hello world", None, None, None)) == 'hello world'



# Generated at 2022-06-24 08:48:12.670841
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options,OptionParser,define
    parser = OptionParser()
    define_logging_options(options)
    parser.parse_args([])
    # Write functions to test options.logging,options.log_to_stderr,options.log_file_prefix,options.log_file_max_size,options.log_file_num_backups,options.log_rotate_when,options.log_rotate_interval,options.log_rotate_mode
    pass

# Generated at 2022-06-24 08:48:16.166227
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    _fmt = tornadolog.LogFormatter(color=False)
    assert isinstance(_fmt, tornadolog.LogFormatter)



# Generated at 2022-06-24 08:48:25.448929
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from mock import patch
    from tornado.options import options
    from tornado.log import logger

    assert len(logger.handlers) == 0
    with patch('tornado.options.options') as mock_options:
        with patch('logging.Logger.setLevel') as mock_setLevel:
            with patch('logging.Logger.addHandler') as mock_addHandler:
                mock_options.logging = 'DEBUG'
                mock_options.log_file_prefix = ''
                mock_options.log_rotate_mode = 'size'
                mock_options.log_file_max_size = 100
                mock_options.log_file_num_backups = 4
                mock_options.log_rotate_when = ''
                mock_options.log_rotate_interval = 1
                mock_options.log

# Generated at 2022-06-24 08:48:36.789855
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define(name="logging", default="DEBUG", help=None, type=None)
    define(name="log_file_prefix", default="mylogfile.log", help=None, type=None)
    define(name="log_to_stderr", default=True, help=None, type=None)
    define(name="log_rotate_mode", default="size", help=None, type=None)
    define(name="log_file_max_size", default=1024, help=None, type=None)
    define(name="log_file_num_backups", default=0, help=None, type=None)
    define(name="log_rotate_when", default="S", help=None, type=None)

# Generated at 2022-06-24 08:48:43.704974
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger("tornado.application")
    logger.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    # 
    logger.debug("test", extra={"custom": "custom"})
    # 
    record = logging.LogRecord("tornado.application", logging.DEBUG, "/home/wangkun/mygit/mypro/tornado-4.5.3/tornado/log.py", 451, "test", {}, None)
    out = formatter.format(record)
    assert out == "[D 171013 11:46:00 log:451] test"

# Generated at 2022-06-24 08:48:45.889371
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert formatter



# Generated at 2022-06-24 08:48:58.603271
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class DummyLogging:
        def __init__(self):
            self.logging = "info"
            self.log_file_prefix = "file_1"
            self.log_rotate_mode = "size"
            self.log_file_max_size = 100
            self.log_file_num_backups = 1
            self.log_rotate_when = "h"
            self.log_rotate_interval = 1
            self.log_to_stderr = False
        def setLevel(self,level):
            self.level = level
        def addHandler(self, handler):
            pass
    class DummyLogging2:
        def __init__(self):
            self.logging = "none"
            self.log_file_prefix = "file_2"

# Generated at 2022-06-24 08:49:05.732068
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(  # type: ignore
        fmt="%(color)s%(levelname)-8s%(end_color)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        },
    )


# Generated at 2022-06-24 08:49:09.068834
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()


# define basicConfig for compatibility with
# logging.config.dictConfig (which requires it).

# Generated at 2022-06-24 08:49:18.726566
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    from tornado.options import define, options, parse_command_line, parse_config_file
    define("config", default=None, help="path to config file", type=str, metavar="CONFIG")
    define("logging", default='info', help="Set the Python log level",
           metavar="debug|info|warning|error|none")
    define("log_to_stderr", default=True, help="Send log output to stderr (colorized if possible)",
           type=bool)
    define("log_file_prefix", default=None, help="path prefix for log file")
    define("log_file_max_size", default=50 * 1000 * 1000, help="max size of log files before rollover")

# Generated at 2022-06-24 08:49:26.375733
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger()  # root logger
    handler = logging.StreamHandler()
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")
    logger.exception("exception message")
    #assert False

if __name__ == "__main__":
    test_LogFormatter_format()

# Generated at 2022-06-24 08:49:33.297522
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import os
    import time
    import shutil
    options = tornado.options.options
    define_logging_options(options)
    options.enable_file_log = True
    options.log_file_prefix = os.path.join(
        os.path.dirname(__file__), "test_logging.dat"
    )
    options.log_file_max_size = 10
    # Set log_rotate_when to "S" for second
    options.log_rotate_when = "S"
    options.log_rotate_interval = 1
    options.log_file_num_backups = 3
    options.log_rotate_mode = "size"
    enable_pretty_logging(options)
    logfile = options.log_file_prefix
    num

# Generated at 2022-06-24 08:49:39.459510
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    from logging import DEBUG, LogRecord

    log_formatter = LogFormatter()

    try:
        log_formatter.format(LogRecord(name="test", level=DEBUG, pathname="", lineno=1, msg="", args=(), exc_info=0))
    except Exception:
        assert False

# Generated at 2022-06-24 08:49:42.009445
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter._normal, str)
    assert isinstance(formatter._colors, dict)

# Generated at 2022-06-24 08:49:51.174874
# Unit test for method format of class LogFormatter

# Generated at 2022-06-24 08:50:02.537894
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import os
    import shutil
    import tempfile

    from tornado.options import define, options

    define("logging", type=str, default="debug")
    define("log_to_stderr", type=bool, default=True)
    define("log_file_prefix", type=str)
    define("log_rotate_mode", type=str, default="time")
    define("log_rotate_when", type=str, default="H")
    define("log_rotate_interval", type=int, default=1)
    define("log_file_num_backups", type=int, default=5)
    define("log_file_max_size", type=int, default=100 * 1000 * 1000)
    log_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 08:50:12.637655
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log
    log_formatter = tornado.log.LogFormatter()
    assert log_formatter
    assert log_formatter._fmt == log_formatter.DEFAULT_FORMAT    
    assert log_formatter.datefmt == log_formatter.DEFAULT_DATE_FORMAT
    assert log_formatter.style == "%"
    assert log_formatter.color == True
    assert log_formatter.colors == log_formatter.DEFAULT_COLORS
    # Test the method format
    import logging
    log = logging.getLogger("tornado.general")
    log.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    formatter = LogFormatter()
    ch.setFormatter(formatter)
   

# Generated at 2022-06-24 08:50:18.580122
# Unit test for function define_logging_options
def test_define_logging_options():
    assert define_logging_options('info') == 'info'
    assert define_logging_options('debug') == 'debug'
    assert define_logging_options('none') == 'none'
    assert define_logging_options('warning') == 'warning'
    assert define_logging_options('error') == 'error'
    assert define_logging_options(None, None) == None



# Generated at 2022-06-24 08:50:30.109262
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    class MyOptions(tornado.options.OptionParser):
        def __init__(self):
            super().__init__()
            self.define("port", default=80)
        def get_options(self):
            return {a: b for a, b in self.items()}

    options = MyOptions()
    define_logging_options(options)
    options.parse_command_line(args=['--logging', 'debug'])
    options.parse_command_line(args=['--log_file_prefix', '/var/log/tornado', '--port', '8010'])

# Generated at 2022-06-24 08:50:31.899790
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # make sure the LogFormatter constructor doesn't raise any exceptions
    LogFormatter()


# Generated at 2022-06-24 08:50:39.715043
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    # Logger objects for internal tornado use
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None

    try:
        import curses
    except ImportError:
        curses = None  # type: ignore

    from typing import Dict, Any, cast, Optional

# Generated at 2022-06-24 08:50:51.007111
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def to_bytes(s):
        if isinstance(s, str):
            return s.encode('utf-8')
        else:
            return s

    fmt = '%(levelname)s: %(message)s'
    logging.basicConfig(level=logging.INFO, format=fmt)
    logger = logging.getLogger(__name__)
    logger.error(to_bytes('normal str'))
    logger.error(to_bytes('str with \uFFFD'))

    fmt = '%(levelname)s: %(message)s'
    formatter = LogFormatter(fmt=fmt)
    logging.basicConfig(level=logging.INFO, format=fmt, formatter=formatter)
    logger = logging.getLogger(__name__)

# Generated at 2022-06-24 08:50:55.655148
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter._fmt, str)
    assert isinstance(formatter._normal, str)
    assert isinstance(formatter._colors, dict)
    assert isinstance(formatter.datefmt, str)


# Generated at 2022-06-24 08:51:06.471903
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    logging.basicConfig(
        format="%(name)s %(asctime)s %(levelname)s: %(message)s",
        level=logging.DEBUG,
    )
    t = LogFormatter()

    # Exercise formatTime
    t.formatTime = lambda record, datefmt: "9"
    assert t.format(logging.LogRecord("a", logging.DEBUG, "1", 2, "3", None, None)) == "9 a DEBUG: 3"  # noqa: E501

    # Exercise formatMessage
    assert str(t).find("a DEBUG: 3") >= 0
    assert t.format(logging.LogRecord("a", logging.DEBUG, "1", 2, "b", None, None)) == "9 a DEBUG: b"  # noqa: E

# Generated at 2022-06-24 08:51:17.897811
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def _myassert(formatted: str, record: logging.LogRecord) -> None:
        record_dict = record.__dict__.copy()
        for k in record_dict:
            if k == "asctime":
                record_dict[k] = "%y%m%d %H:%M:%S"
            elif k.startswith("color"):
                record_dict[k] = ""
        expected = formatter._fmt % record_dict
        assert formatted == expected

    formatter = LogFormatter()
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="test.py",
        lineno=1,
        msg="test message",
        args=None,
        exc_info=None,
    )


# Generated at 2022-06-24 08:51:27.459308
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # pylint: disable=too-many-locals
    import io
    import logging
    import unittest
    import unittest.mock
    import warnings

    # logging.getLogger().addHandler(logging.StreamHandler())
    # logging.getLogger().handlers[0]
    # .setFormatter(LogFormatter())
    # logging.getLogger().setLevel(logging.DEBUG)
    # logging.getLogger("tornado.access").setLevel(logging.DEBUG)

    fh = io.StringIO()

    handler = logging.StreamHandler(fh)
    handler.setFormatter(LogFormatter())
    gen_log.addHandler(handler)
    gen_log.setLevel(logging.DEBUG)

    gen_log.info("info")

# Generated at 2022-06-24 08:51:29.285582
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: no cover
    assert LogFormatter(color=False)



# Generated at 2022-06-24 08:51:30.926893
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """Unit test for function enable_pretty_logging"""
    try:
        import tornado.options
    except ImportError:
        return
    options = tornado.options
    options.enable_pretty_logging()

# Generated at 2022-06-24 08:51:32.626584
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:51:35.231564
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    record = logging.LogRecord("name", "INFO", "filename", 1, "msg", None, None)
    formatted = formatter.format(record)
    assert "INFO" in formatted
    assert "msg" in formatted


# Generated at 2022-06-24 08:51:42.418172
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.application", logging.INFO, "tornado/log.py", 0, "message", (), None
    )
    assert formatter.format(record) == "[I " + record.asctime + " log:0] message"
    record = logging.LogRecord(
        "tornado.application", logging.ERROR, "tornado/log.py", 0, "message", (), None
    )
    assert formatter.format(record) == "[E " + record.asctime + " log:0] message"



# Generated at 2022-06-24 08:51:51.420767
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        logging = None
        log_file_prefix = None
        log_file_max_size = 1024*1024*10
        log_file_num_backups = None
        log_rotate_mode = "size"
        log_rotate_when = "midnight"
        log_rotate_interval = ""
        log_to_stderr = None

    options = Options()
    enable_pretty_logging(options)
    assert(options.logging == "none")
    assert(options.log_file_prefix == None)
    assert(options.log_file_max_size == 1024*1024*10)
    assert(options.log_file_num_backups == None)
    assert(options.log_rotate_mode == "size")

# Generated at 2022-06-24 08:52:02.991175
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """Test that LogFormatter() works without error."""
    # LogFormatter() produces a nameless style object.  It's
    # convenient to examine it, but don't otherwise rely on it.
    logger = logging.getLogger()
    formatters = logger.handlers[0].formatter._style._fmt
    LogFormatter(formatters)
    LogFormatter("%(color)s%(message)s%(end_color)s")
    LogFormatter("%(color)s%(message)s%(end_color)s", True)
    LogFormatter("%(color)s%(message)s%(end_color)s", False)
    LogFormatter("%(color)s%(message)s%(end_color)s", True, {})
    Log

# Generated at 2022-06-24 08:52:04.569849
# Unit test for function define_logging_options
def test_define_logging_options():
    o = {"a":1, "b":2}
    define_logging_options(o)
    define_logging_options()

# Generated at 2022-06-24 08:52:10.681428
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    import logging.config

    tornado.options.define("foo", type=int)

    logging.config.DictConfig({
            "version": 1,
            "formatters": {
                    "simple": {
                            "format": "[%(levelname)s] %(asctime)s %(module)s: %(message)s",
                    },
            },
            "handlers": {
                    "console": {
                            "class": "logging.StreamHandler",
                            "formatter": "simple",
                    },
            },
            "root": {
                    "level": "DEBUG",
                    "handlers": ["console"],
            },
    })


# Generated at 2022-06-24 08:52:14.017170
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging_test
    import tornado.options

    logging.getLogger().handlers = []
    tornado.options.options.logging = "warning"
    enable_pretty_logging()
    logger = logging.getLogger()
    assert logger.level == logging.WARNING
    enable_pretty_logging(logger=logging.getLogger())
    assert logger.level == logging.WARNING
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)

# Generated at 2022-06-24 08:52:15.048163
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()

# Generated at 2022-06-24 08:52:26.224876
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # check the format of the log file by formatting the log message
    # There are many records inside the log. We check a sample of them.
    formatter = LogFormatter()
    # message = "sample of log message"
    # # module = "tornado.general"
    # lineno = 0
    # date = "datetime.datetime(2020, 2, 29, 8, 36, 33, 564804)"
    # levelno = logging.ERROR
    # color = formatter._colors[levelno]
    # message = _safe_unicode(message)
    # # record.message = message
    # record.asctime = formatter.formatTime(record, formatter.datefmt)

    # if record.levelno in formatter._colors:
    #     record.color = formatter._colors[record.

# Generated at 2022-06-24 08:52:32.084868
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print("options:", options)
    print("options.logging:", options.logging)
    print("options.log_file_prefix:", options.log_file_prefix)


# Generated at 2022-06-24 08:52:42.225308
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import io

    # Enable color support
    class LogFormatter(LogFormatter):
        def __init__(self, fmt: str = LogFormatter.DEFAULT_FORMAT,
                     datefmt: str = LogFormatter.DEFAULT_DATE_FORMAT,
                     style: str = "%",
                     color: bool = True,
                     colors: Dict[int, int] = LogFormatter.DEFAULT_COLORS):
            pass

    logger = logging.getLogger(__name__)
    f = io.StringIO()
    handler = logging.StreamHandler(f)
    handler.setFormatter(LogFormatter())
    logger.handlers = []
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)


# Generated at 2022-06-24 08:52:50.744963
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Option:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        def __getattr__(self, item):
            if item.lower() == 'false':
                return False
            if item.lower() == 'true':
                return True
            return None

    logger = logging.getLogger()
    option = Option(logging='error', log_file_prefix='log.txt')
    enable_pretty_logging(option, logger)

    option = Option(logging='error', log_file_prefix='log.txt', log_rotate_mode='size')
    enable_pretty_logging(option, logger)


# Generated at 2022-06-24 08:53:02.096656
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter.converter == time.localtime
    assert formatter.datefmt == "%y%m%d %H:%M:%S"
    assert formatter.format == formatter.format(None)
    assert "%(color)s" in formatter.format
    assert formatter.format == LogFormatter.DEFAULT_FORMAT
    assert formatter.formatTime == formatter.formatTime(None, None)
    assert "%(color)s" in formatter.formatTime
    assert formatter.formatTime == "%s"
    assert formatter.formatException == formatter.formatException(None)
    assert formatter.formatException == logging.Formatter.formatException
    assert formatter.formatStack == formatter.format

# Generated at 2022-06-24 08:53:03.207801
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:53:10.790194
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter(fmt = LogFormatter.DEFAULT_FORMAT,
            datefmt = LogFormatter.DEFAULT_DATE_FORMAT,
            style = '%',
            color = False,
            colors = LogFormatter.DEFAULT_COLORS)
    record = logging.LogRecord("name", "WARNING", "pathname", 11, "msg",
            None, None)

    log_formatter.format(record)
    assert record.levelno == "WARNING"
    assert record.msg == "msg"
    assert record.asctime == " "
    assert record.color == ""
    assert record.end_color == ""
    assert record.message == "msg"


# Generated at 2022-06-24 08:53:21.735119
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("tornado.test")

    logger.info("test1")

    format = "%(color)s%(levelname)s %(end_color)s:%(message)s"
    formatter = LogFormatter(format)
    logger.handlers[0].setFormatter(formatter)

    logger.info("test2")

    from tornado.options import define, options, parse_command_line
    define("logging")
    parse_command_line(['--logging=none'])
    logger.info("test3")


# Generated at 2022-06-24 08:53:24.869699
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

# vim:ts=4:sw=4:et:

# Generated at 2022-06-24 08:53:31.349843
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)
    parser.parse_command_line(
        ["progname", "--logging", "debug", "--log_file_prefix", "path",
         "--log_file_max_size", "1000", "--log_file_num_backups", "1",
         "--log_rotate_when","S", "--log_rotate_interval","5",
         "--log_rotate_mode","size"])

if __name__ == '__main__':
    test_define_logging_options()