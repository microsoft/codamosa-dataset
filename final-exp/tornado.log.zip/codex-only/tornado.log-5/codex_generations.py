

# Generated at 2022-06-24 08:43:30.351059
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.log_file_prefix = "log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 4
    enable_pretty_logging()

# Generated at 2022-06-24 08:43:30.904260
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-24 08:43:39.421628
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log
    tornado.log.access_log.setLevel(logging.INFO)
    tornado.log.gen_log.setLevel(logging.INFO)
    tornado.log.app_log.setLevel(logging.INFO)

    tornado.log.access_log.info("Please also print hello")
    tornado.log.gen_log.info("Please also print hello")
    tornado.log.app_log.info("Please also print hello")
    # <NoFile>    INFO    Please also print hello
    # <NoFile>    INFO    Please also print hello
    # <NoFile>    INFO    Please also print hello



# Generated at 2022-06-24 08:43:46.497439
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """test function enable_pretty_logging"""
    from tornado.options import options, define, parse_config_file
    import tempfile
    options.logging="debug"
    options.log_file_prefix="D:\\test\\test.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 100000
    options.log_file_num_backups = 100
    options.log_to_stderr=False
    enable_pretty_logging()
    logging.error("test")

# Generated at 2022-06-24 08:43:57.808776
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    with LogFormatter(color=True) as formatter:
        pass
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert formatter.DEFAULT_COLORS is not None
    assert formatter.DEFAULT_COLORS[logging.DEBUG] == 4
    assert formatter.DEFAULT_COLORS[logging.INFO] == 2
    assert formatter.DEFAULT_COLORS[logging.WARNING] == 3

# Generated at 2022-06-24 08:44:00.661320
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define('logging', type=str)
    tornado.options.define('log_file_prefix', type=str)
    tornado.options.parse_config_file(["test.conf"])
    assert tornado.options.options.logging == 'none'
    assert tornado.options.options.log_file_prefix == 'application.log'

# Generated at 2022-06-24 08:44:09.677500
# Unit test for function define_logging_options
def test_define_logging_options():
    options = None
    define_logging_options(options)
    options.log_rotate_when = "S"
    define_logging_options(options)
    options.log_rotate_when = "M"
    define_logging_options(options)
    options.log_rotate_when = "H"
    define_logging_options(options)
    options.log_rotate_when = "D"
    define_logging_options(options)
    options.log_rotate_when = "W0"
    define_logging_options(options)
    options.log_rotate_when = "W1"
    define_logging_options(options)
    options.log_rotate_when = "W2"
    define_logging_options(options)
    options.log_

# Generated at 2022-06-24 08:44:21.675010
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Type ignore is necessary because the PyCharm stubs do not include
    # the style argument.
    f = LogFormatter(color=False, style="%").format(logging.LogRecord(None, None, None, None, None, None, None))  # type: ignore
    assert f == '[? ? ?:?] ?'
    f = LogFormatter(color=True, style="%").format(logging.LogRecord(None, None, None, None, None, None, None))  # type: ignore
    assert f == '[? ? ?:?] ?'
    f = LogFormatter(color=False, style="{").format(logging.LogRecord(None, None, None, None, None, None, None))  # type: ignore
    assert f == '[? ? ?:?] ?'

# Generated at 2022-06-24 08:44:32.575938
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    log_file_prefix = "/var/log/tornado.log"
    log_rotate_mode = "size"
    log_file_max_size = 128
    log_file_num_backups = 8
    log_rotate_when = "midnight"
    log_rotate_interval = 1

    class options:
        logging = "none"
        log_file_prefix = log_file_prefix
        log_rotate_mode = log_rotate_mode
        log_file_max_size = log_file_max_size
        log_file_num_backups = log_file_num_backups
        log_rotate_when = log_rotate_when
        log_rotate_interval = log_rotate_interval

    import tornado.options

    tornado.options.options = options

# Generated at 2022-06-24 08:44:38.306187
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    #TODO: this is useful that loggin options are added to the options object,
    #but we should also verify that they are passed as parameter to the function
    #enable_pretty_logging
    #print(options.__dict__)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:44:52.241267
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado import options
    import tornado
    import logging
    import sys
    # Test that log_file_max_size can be a human-readable string.
    options.define('log_file_max_size', '1K')
    options.define('log_file_num_backups', 1)
    options.define('log_to_stderr', True)
    # The test runs in the current directory, so create the log file there.
    options.define('log_file_prefix', 'test_tornado.log')
    options.define('logging', 'debug')
    enable_pretty_logging()
    tornado.options.parse_command_line()
    gen_log.warning('hi!')
    gen_log.warning('hi!')
    gen_log.warning('hi!')
    gen_log.warning

# Generated at 2022-06-24 08:44:57.221245
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Init the logger with attribute name 'foo'
    logger = logging.Logger('foo')
    # Init the handler with a dummy stream
    handler = logging.StreamHandler(sys.stdout)
    # Init log formatter
    log_formatter = LogFormatter()
    handler.setFormatter(log_formatter)
    # Add handler
    logger.addHandler(handler)

    # Log something
    logger.info('sometext')


# Generated at 2022-06-24 08:45:00.418937
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test = LogFormatter(color=True, fmt=None, datefmt=None, style=None)
    assert test.DEFAULT_DATE_FORMAT.__class__ == str
    assert test.DEFAULT_FORMAT.__class__ == str



# Generated at 2022-06-24 08:45:13.058979
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import time
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {}
    lf = LogFormatter(fmt, datefmt, style, color, colors)
    record = logging.LogRecord(name="abc", level=logging.WARNING, pathname="abc_pathname", lineno=1, msg="pre %(process)d post", args=(2, ), exc_info=None)  # noqa: E501

# Generated at 2022-06-24 08:45:20.165689
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    tornado.options.define("log_file_prefix", type=str, default=None, metavar="PATH",
                           help=("Path prefix for log files. "
                                 "Note that if you are running multiple tornado processes, "
                                 "log_file_prefix must be different for each of them (e.g. "
                                 "include the port number)"))
    pass

enable_pretty_logging()

# Generated at 2022-06-24 08:45:30.745988
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options._unparse_command_line([
        'tornado.options',
        '--logging', 'debug',
        '--log_file_prefix', './log.txt',
        '--log_rotate_mode', 'size',
        '--log_file_max_size', '1024',
        '--log_file_num_backups', '1',
        '--log_rotate_when', 'S',
        '--log_rotate_interval', '1',
        '--log_to_stderr',
    ])
    print(tornado.options.options.logging)  # debug
    print(tornado.options.options.log_file_prefix)  # ./log.txt
    print(tornado.options.options.log_rotate_mode)

# Generated at 2022-06-24 08:45:36.646606
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os

    logging.basicConfig()

    # test default log (console)
    tornado.options.parse_command_line()
    logger = logging.getLogger()
    assert (len(logger.handlers) == 1 and
            isinstance(logger.handlers[0], logging.StreamHandler))

    # test log to console with color
    tornado.options.parse_command_line([
        "--logging=debug"
    ])
    logger.setLevel(logging.DEBUG)
    assert (len(logger.handlers) == 1 and
            isinstance(logger.handlers[0], logging.StreamHandler))
    assert isinstance(logger.handlers[0].formatter, LogFormatter)

# Generated at 2022-06-24 08:45:37.843164
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print(LogFormatter().format())



# Generated at 2022-06-24 08:45:39.593278
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:45:46.768901
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.test",
        level=logging.DEBUG,
        pathname="/home/aboodhaj/Projects/tornado/demos/blog/handlers.py",
        lineno=17,
        msg="123",
        args=(),
        exc_info=None,
    )
    result = repr(formatter.format(record))
    assert result == repr("[D 170521 13:47:58 handlers:17] 123"), result

test_LogFormatter_format()



# Generated at 2022-06-24 08:45:49.749834
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()
test_define_logging_options()

# Generated at 2022-06-24 08:45:51.431671
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = LogFormatter()
    assert fmt._colors
    assert fmt._fmt
    assert fmt._normal
    assert fmt.datefmt



# Generated at 2022-06-24 08:45:54.633869
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    f = LogFormatter(color=True)
    f.format(logging.LogRecord('tornado.general', 35, __file__, 35, 'hello', None, None))

# Generated at 2022-06-24 08:46:06.650377
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import tornado.log
    import re
    import sys

    # This test does not check anything but an exception was thrown or not
    # at instantiation time of LogFormatter.

    # check using the default args
    fmt = LogFormatter()

    # check using a custom date format string
    fmt = LogFormatter(datefmt='%Y-%m-%d %H:%M:%S')

    # check using a custom log format string
    fmt = LogFormatter(fmt="%(levelname)s: %(message)s")

    # check using everything
    fmt = LogFormatter(
        fmt="%(levelname)s: %(message)s", datefmt='%Y-%m-%d %H:%M:%S')

    # check unsupported argument

# Generated at 2022-06-24 08:46:09.506406
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()

# Generated at 2022-06-24 08:46:18.144238
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    define("logging", default="WARNING")
    parse_command_line(["test_enable_pretty_logging.py", "--logging=DEBUG"])
    assert options.logging == "DEBUG"
    enable_pretty_logging(options)
    assert app_log.getEffectiveLevel() == logging.DEBUG

    options.logging = "INFO"
    enable_pretty_logging(options, app_log)
    assert app_log.getEffectiveLevel() == logging.INFO

    options.logging = "WARNING"
    enable_pretty_logging(options)
    assert app_log.getEffectiveLevel() == logging.WARNING
test_enable_pretty_logging()

# Generated at 2022-06-24 08:46:25.332730
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import os
    import sys
    import errno
    import signal
    import logging

    from tornado import escape
    from tornado import stack_context
    from tornado import testing
    from tornado.log import app_log

    class TestHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            logging.Handler.__init__(self, *args, **kwargs)
            self.records = []  # type: Any

        def emit(self, record):
            self.records.append(record)

    def record_stack(record):
        # type: (logging.LogRecord) -> None
        record.name = "test.name"
        record.funcName = "test.funcname"
        record.filename = __file__
        # fake out the line number

# Generated at 2022-06-24 08:46:31.383029
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Tests that the constructor doesn't explode
    LogFormatter()
    LogFormatter(
        fmt="%(color)s%(message)s%(end_color)s",
        datefmt="%H:%M:%S",
    )
    LogFormatter(
        fmt="%(color)s%(message)s%(end_color)s",
        datefmt="%H:%M:%S",
        color=False,
    )


# Generated at 2022-06-24 08:46:37.340161
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from datetime import datetime
    from unittest.mock import Mock
    record = Mock(
        asctime=datetime.now(),
        name="tornado.general",
        levelname="INFO",
        lineno=10,
        module="tornado.web",
        message="Test message",
    )
    logger = LogFormatter()
    logger.format(record)

# Generated at 2022-06-24 08:46:39.939516
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.parse_config_file("tornado.conf")


# Generated at 2022-06-24 08:46:45.903580
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define

    class test_dict(dict):
        def __init__(self, **kwargs: Any) -> None:
            super(test_dict, self).__init__(kwargs)

        def __getattr__(self, item: str) -> Any:
            try:
                return self[item]
            except KeyError:
                return None

    assert options.logging == "info"
    assert options.log_file_prefix == None
    assert options.log_to_stderr == None
    assert options.log_file_num_backups == 10
    # change color mode to True
    assert LogFormatter().color == True
    # change color mode to False
    assert LogFormatter(color=False).color == False
    # set options with custom values

# Generated at 2022-06-24 08:46:55.507922
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.formatTime = lambda *args: "date"

    def format(**kwargs):
        return formatter.format(LogRecord("", 0, "", 0, "", (), None, **kwargs))

    assert format(levelno=logging.INFO, msg="waiting") == "[I date ] waiting"
    assert format(levelno=logging.INFO, msg="\u2600") == "[I date ] \u2600"
    assert format(levelno=logging.ERROR, msg="fail") == "[E date ] fail"
    assert (
        format(levelno=logging.DEBUG, msg="go")
        == "[D date ] go"
    )  # note the space between ] and g


# Generated at 2022-06-24 08:47:04.944395
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(
        fmt="%(color)s%(levelname)-8s%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S"
    )
    log = logging.getLogger("tornado.test")
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    handler.setFormatter(formatter)
    log.setLevel(logging.DEBUG)

    log.info("info message")
    log.debug("debug message")
    log.warn("warning message")
    log.error("error message")
    log.critical("critical message")

# Generated at 2022-06-24 08:47:12.997329
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    class MockOption(tornado.options.Option):
        def __init__(self, name, default, type, help):
            self.name = name
            self.default = default
            self.type = type
            self.help = help
        def add_parse_callback(self, func):
            print(self.name)
            print(self.type)
            print(self.default)
            print(self.help)
        def define(self, n, d,t, h):
            self.n = n
            self.d = d
            self.t = t
            self.h = h
    class MockOptionParser(tornado.options.OptionParser):
        def __init__(self):
            self.dict = {}
        def define(self, *args):
            self.o = Mock

# Generated at 2022-06-24 08:47:14.978532
# Unit test for function define_logging_options
def test_define_logging_options():
    assert define_logging_options()==None

# Generated at 2022-06-24 08:47:26.347088
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from argparse import Namespace
    from unittest.mock import Mock
    # make sure that __init__() does not crash
    fmt = "xyz"
    datefmt = "abc"
    style = "???"
    color = False
    colors = {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, 
              logging.ERROR: 1, logging.CRITICAL: 5}
    LogFormatter(fmt=fmt, datefmt=datefmt, style=style, color=color, 
                 colors=colors)
    # check the case when style is '{'
    LogFormatter(style="{")
    # check the case when style is something unexpected
    try:
        LogFormatter(style=".")
        assert False
    except ValueError:
        pass
    #

# Generated at 2022-06-24 08:47:27.768146
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # TODO: implement this test
    pass


# Generated at 2022-06-24 08:47:29.528412
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)

# Generated at 2022-06-24 08:47:30.387190
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()  # type: ignore


# Generated at 2022-06-24 08:47:43.629006
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    from tornado.log import enable_pretty_logging, gen_log
    # parse_command_line(['--logging=none', '--log_to_stderr=False', '--log_file_prefix=./log/tornado'])
    parse_command_line(
        [
            "--logging=info",
            "--log_to_stderr=True",
            "--log_file_prefix=./log/tornado",
            "--log_file_max_size=50000",
            "--log_file_num_backups=5",
            "--log_rotate_when=midnight",
            "--log_rotate_interval=2",
        ]
    )

# Generated at 2022-06-24 08:47:49.145795
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    l1 = LogFormatter()
    assert isinstance(l1._colors, dict)
    assert l1._normal == ""
    l2 = LogFormatter(colors={1:1})
    assert isinstance(l2._colors, dict)
    assert l2._colors[1] == "\033[2;3%dm"%1
    assert l2._normal == "\033[0m"


# Generated at 2022-06-24 08:47:52.414942
# Unit test for function define_logging_options
def test_define_logging_options():
    options = {} #type: Any
    define_logging_options(options)
    #assert not hasattr(options, 'logging')
    assert hasattr(options, 'logging')

# Generated at 2022-06-24 08:47:55.814640
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter(color=False)
    info_str = f.format(logging.LogRecord("", logging.INFO, "", 1, "test_info", (), None))
    assert info_str == "[I 0001 test_info] test_info\n"

# Generated at 2022-06-24 08:47:58.056901
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()

# Generated at 2022-06-24 08:48:10.736811
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    options = tornado.options.options
    options.parse_command_line(
        args=["--logging", "none"])
    options.parse_command_line(
        args=["--log_file_prefix", "test.log"])
    options.parse_command_line(
        args=["--log_to_stderr"])
    options.parse_command_line(
        args=["--log_rotate_when", "M"])
    options.parse_command_line(
        args=["--log_rotate_interval", "1"])
    options.parse_command_line(
        args=["--log_rotate_mode", "time"])

# Generated at 2022-06-24 08:48:22.790105
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    from tornado.options import OptionError
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine

    class TestCase(AsyncTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
    
            self.option_parser = tornado.options.OptionParser()
            define_logging_options(self.option_parser)
            self.options = self.option_parser.parse_command_line(
                ['--logging', 'info', '--log_file_prefix', 'log', '--log_file_max_size', '100', '--log_file_num_backups', '10']
            )
            self.options.add_parse_callback(lambda: enable_pretty_logging(options))


# Generated at 2022-06-24 08:48:31.227858
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    data_fromat = logging.LogRecord("tornado.access", logging.DEBUG, "my_src.py", 123, "My message.\nThis is log message.", None, None)
    data_fromat.exc_info="NotImplementedError: file: /home/mukundhs/Programming/pythonProjects/tornado/tornado/log.py line: 36"
    assert LogFormatter().format(data_fromat) == "[D 123004 my_src.py:123] My message.\n    This is log message."

# Generated at 2022-06-24 08:48:35.396907
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()
    assert LogFormatter(color=False)
    assert LogFormatter(fmt='%(asctime)s %(message)s')
    assert LogFormatter(datefmt='%Y%m%d %H:%M:%S')



# Generated at 2022-06-24 08:48:37.575060
# Unit test for function define_logging_options
def test_define_logging_options():
    test_options = None
    define_logging_options(test_options)

test_define_logging_options()


# Generated at 2022-06-24 08:48:45.814200
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    from tornado.log import app_log

    options.logging = "info"
    options.log_file_prefix = "/path/to/logfile"
    options.log_to_stderr = True
    options.log_rotate_mode = "time"
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    options.log_file_num_backups = 5

    enable_pretty_logging(options, app_log)
    assert isinstance(app_log.handlers[0], logging.StreamHandler)

    default_formatter = (
        cast(logging.StreamHandler, app_log.handlers[0]).formatter
    )

# Generated at 2022-06-24 08:48:54.650807
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    assert fmt.fmt == fmt.DEFAULT_FORMAT
    assert fmt.datefmt == fmt.DEFAULT_DATE_FORMAT
    assert fmt.colors == fmt.DEFAULT_COLORS
    fmt = LogFormatter(
        "fmt", "datefmt", "%", True, fmt.DEFAULT_COLORS  # type: ignore
    )
    assert fmt.fmt == "fmt"
    assert fmt.datefmt == "datefmt"
    assert fmt.colors == fmt.DEFAULT_COLORS



# Generated at 2022-06-24 08:49:00.425413
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Use the default is_debug() implementation.  This means that log messages will
# be disabled by default at the INFO log level, but can be enabled at the
# DEBUG level if desired (or at the TRACE level to get all messages regardless
# of their log_function).
is_debug = None



# Generated at 2022-06-24 08:49:01.855820
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert isinstance(LogFormatter().datefmt, str)



# Generated at 2022-06-24 08:49:09.730734
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.options import options
    from tornado.log import LogFormatter
    from tornado.log import gen_log

    # suppress the MethodName logger that assertRaises() uses
    logging.getLogger("tornado.general").setLevel(logging.CRITICAL + 1)

    # Test that our patch of assertRaises works
    def bad_format(record):
        raise Exception("error in format")

    gen_log.info("")
    with gen_log.handlers[0].assertRaises("error in format"):
        gen_log.handlers[0].formatter.format = bad_format

    # Test that explicit messages and exceptions come out correctly

# Generated at 2022-06-24 08:49:17.041148
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    # Test for options.logging
    assert tornado.options.options.logging.lower() != "none"

    # Test for options.log_file_prefix
    assert tornado.options.options.log_file_prefix

    # Test for log_to_stderr
    assert tornado.options.options.log_to_stderr or \
        (tornado.options.options.log_to_stderr is None and not logger.handlers)

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:49:18.484425
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)

# Generated at 2022-06-24 08:49:19.548199
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()  # init

# Generated at 2022-06-24 08:49:28.811619
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = "%(color)s%(levelname)s %(asctime)s%(end_color)s - %(message)s"
    # fmt=fmt,datefmt=datefmt,style=style)
    assert LogFormatter(fmt)._fmt == fmt
    # LogFormatter(fmt,datefmt,style)
    assert LogFormatter(fmt, datefmt="%Y-%m-%d %H:%M:%S").datefmt == "%Y-%m-%d %H:%M:%S"
    # LogFormatter(fmt,datefmt,style)

# Generated at 2022-06-24 08:49:35.005009
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    from tornado.test.util import unittest
    class TestLoggingOptions(unittest.TestCase):
        def test_logging_options(self):
            parser = OptionParser()
            define_logging_options(parser)

# Generated at 2022-06-24 08:49:41.764094
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_record=logging.LogRecord(
        name="tornado.access",
        level=logging.ERROR,
        pathname="",
        lineno=0,
        msg="test",
        args=(),
        exc_info=None,
    )
    log_formatter=LogFormatter()
    assert log_formatter.format(log_record)=="[E 0 tornado.access:0] test"



# Generated at 2022-06-24 08:49:46.045160
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    with pytest.raises(ValueError):
        enable_pretty_logging({"log_rotate_mode":"test"},logger=None)
test_enable_pretty_logging()


# However, Tornado also uses python's standard logging package to print log
# messages. We add the following two methods to the tornado logger.


# Generated at 2022-06-24 08:49:51.208680
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    record = logging.makeLogRecord({"msg": "test", "levelno": logging.INFO})
    formatter.format(record)
    record = logging.makeLogRecord({"msg": "test", "levelno": logging.DEBUG})
    formatter.format(record)
    record = logging.makeLogRecord({"msg": "test", "levelno": logging.ERROR})
    formatter.format(record)
    record = logging.makeLogRecord({"msg": "test", "levelno": 666})
    formatter.format(record)



# Generated at 2022-06-24 08:50:02.642133
# Unit test for constructor of class LogFormatter

# Generated at 2022-06-24 08:50:03.769896
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:50:05.317122
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

enable_pretty_logging()

# Generated at 2022-06-24 08:50:07.479413
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
  log_fmt = LogFormatter()
  record = logging.LogRecord(name='name', level=0, pathname='pathname', lineno=1, msg='msg', args=(), exc_info=None, func=None)
  result = log_fmt.format(record)
  assert result != ""



# Generated at 2022-06-24 08:50:16.074831
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    config_dict = {
        'version': 1,
        'disable_existing_loggers': False,
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'stream': 'ext://sys.stdout',
                'formatter': 'colored'
            }
        },
        'loggers': {
            'tornado': {
                'level': 'DEBUG',
                'handlers': ['console'],
                'propagate': False
            }
        },
        'formatters': {
            'colored': {
                '()': 'tornado.log.LogFormatter'
            }
        }
    }
    logging.config.dictConfig(config_dict)
    logging.getLogger("tornado").debug("test")


# Generated at 2022-06-24 08:50:25.837889
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    assert options.logging == 'info'
    assert options.log_to_stderr == False
    assert options.log_file_prefix == "tornado.log"
    assert options.log_file_max_size == 100000000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"
    assert hasattr(options.add_parse_callback, "__call__")


# Generated at 2022-06-24 08:50:33.593362
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.options

    define_logging_options()
    options = tornado.options.options
    assert options.logging == 'info'
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100000000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

# Generated at 2022-06-24 08:50:44.035559
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_config_file, parse_command_line
    define("log_file_prefix", "test")
    define("log_file_max_size", 512)
    define("log_file_num_backups", 2)
    define("log_rotate_when", "midnight")
    define("log_rotate_interval", 1)
    define("log_rotate_mode", "size")
    define("log_to_stderr", False)
    define("logging", "warning")

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:50:45.365565
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    obj = LogFormatter()


# Generated at 2022-06-24 08:50:53.684475
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line

    define("log_to_stderr")
    define("log_file_prefix")
    define("log_file_max_size")
    define("log_file_num_backups")
    define("log_rotate_mode")
    define("log_rotate_when")
    define("log_rotate_interval")

    define_logging_options(options)

    options.logging = "info"
    options.log_to_stderr = True
    options.log_file_prefix = "/path/to/logfile"
    options.log_file_max_size = 100 * 1000 * 1000
    options.log_file_num_backups = 10

    options.log_rotate_mode = "size"
    options.log_

# Generated at 2022-06-24 08:50:58.652255
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    # Initialize the logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Set the format of the logger
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # Define file handler and set formatter
    # file_handler = logging.FileHandler('logs.log')
    # file_handler.setFormatter(formatter)
    # Create console handler and set level to debug
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)

    # Create formatter
    console_handler.setFormatter(f)
    # Add console handler to logger
    logger.addHandler(console_handler)
   

# Generated at 2022-06-24 08:51:06.523431
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():  # pragma: no cover
    import logging
    import tornado.log
    import unittest

    class TestRecord(object):
        def __init__(self, exc_info: Optional[Any] = None) -> None:
            self.msg = "This is a test message"
            self.args = ()
            self.exc_info = exc_info
            self.exc_text = None

        def getMessage(self) -> str:
            return self.msg

        def __str__(self) -> str:
            return self.msg

        def __repr__(self) -> str:
            return self.msg

    class TestLogger(logging.Logger):
        __qualname__ = "TestLogger"

        def findCaller(self) -> Any:
            return ("filename.py", 1234, "function")



# Generated at 2022-06-24 08:51:16.678654
# Unit test for constructor of class LogFormatter
def test_LogFormatter():    # pragma: no cover
    # no color
    lf = LogFormatter(color=False)
    assert lf.format(logging.LogRecord("test", logging.DEBUG, __file__, 42, "foo", (), None)) == "[DEBUG %(asctime)s test:42] foo"   # noqa: E501

    # color
    lf = LogFormatter(color=True)
    fmt = lf.format(logging.LogRecord("test", logging.DEBUG, __file__, 42, "foo", (), None))
    assert fmt.startswith("\033[2;34m[DEBUG ") and fmt.endswith("\033[0m foo\n    ")



# Generated at 2022-06-24 08:51:25.000660
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    import curses

    formatter = LogFormatter()
    class Record:
        def __init__(self, color: str, end_color: str):
            self.color = color
            self.end_color = end_color
        def __dict__(self) -> dict:
            return self.__dict__
    record = Record('[', ']')
    result = formatter.format(record)
    assert result is not None
    assert result.__eq__('[]')


# Generated at 2022-06-24 08:51:26.452556
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    a = LogFormatter()
    r=a.format('it works')
    assert r == "it works"


# Generated at 2022-06-24 08:51:38.667224
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line, parse_config_file

    define("logging", default="info", help="Set the Python log level.",
           metavar="debug|info|warning|error|none")
    define("log_to_stderr", type=bool, default=None, help="Send log output to "
                                                          "stderr (colorized "
                                                          "if possible). By "
                                                          "default use "
                                                          "stderr if "
                                                          "--log_file_prefix "
                                                          "is not "
                                                          "set and no other "
                                                          "logging is "
                                                          "configured.")

# Generated at 2022-06-24 08:51:39.659073
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging('size')

# Generated at 2022-06-24 08:51:49.330148
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    options.parse_config_file('test.conf')
    logging.info('test parse_config_file')
    # logging.warning('test parse_config_file')
    # logging.error('test parse_config_file')
    # logging.debug('test parse_config_file')
    # logging.fatal('test parse_config_file')
    # logging.critical('test parse_config_file')
    options.log_rotate_mode = 'time'
    enable_pretty_logging(options)

if __name__ == "__main__":
    # test_define_logging_options()
    pass

# Generated at 2022-06-24 08:51:58.458833
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, OptionParser

    parser = OptionParser()
    define_logging_options(parser)
    options.log_rotate_when = "S"
    options.log_rotate_interval = 2
    parser.parse_command_line(["-log_rotate_mode=time"])
    assert (options.log_rotate_mode == "size")
    options.log_rotate_when = "S"
    options.log_rotate_interval = 2

test_define_logging_options()

# Generated at 2022-06-24 08:52:05.488008
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_to_stderr = True
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    enable_pretty_logging()



# Generated at 2022-06-24 08:52:09.045711
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmtr = LogFormatter()
    fmtr.format(logging.LogRecord('', 0, '', 0, 10, '', (), None, None))
    assert True



# Generated at 2022-06-24 08:52:18.629508
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert type(formatter._fmt) == str
    assert type(formatter._colors) == dict
    assert not formatter._normal
    assert formatter._fmt == "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"  # noqa: E501
    assert formatter._colors == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }



# Generated at 2022-06-24 08:52:20.131452
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.info("test1")

# Generated at 2022-06-24 08:52:21.530664
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # log handler is created when called, so cannot test.
    pass

# Generated at 2022-06-24 08:52:30.285575
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # In unit test code, always disable color logging.
    # It's hard to detect in a cross-platform way and even
    # when correct, the output is often ugly in the unit test output
    # (especially because many of our unit tests capture stdout)
    options = LogOptions()
    options.logging = "none"
    enable_pretty_logging(options)
    output = []
    write_orig = sys.stderr.write
    try:
        sys.stderr.write = lambda x: output.append(x)
        logging.warning("foo")
        logging.warning("bar")
    finally:
        sys.stderr.write = write_orig
    self.assertEqual(output, [])

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-24 08:52:36.733831
# Unit test for function define_logging_options
def test_define_logging_options():
    class Options(object):
        def __init__(self, **kwargs):
            # type: (**Any) -> None
            self.__dict__ = kwargs

        def define(self, *args, **kwargs):
            pass

        def add_parse_callback(self, callback):
            pass

    options = Options()
    define_logging_options(options)
    assert options.logging == "info"

# Generated at 2022-06-24 08:52:40.901353
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log = logging.getLogger()
    logging.basicConfig(level=logging.DEBUG)
    handler = logging.StreamHandler()
    log.addHandler(handler)
    handler.setFormatter(LogFormatter())
    log.debug("test")



# Generated at 2022-06-24 08:52:44.347193
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    try:
        assert isinstance(f.format(logging.LogRecord("tornado.general", logging.DEBUG, "", 0, "", None, None)), str)
    except AssertionError:
        return False
    else:
        return True
print(test_LogFormatter_format())



# Generated at 2022-06-24 08:52:46.413686
# Unit test for function define_logging_options
def test_define_logging_options():
    enable_pretty_logging(options=None)
    define_logging_options(options=None)

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:52:55.033211
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    import tornado.options

    options = OptionParser()
    define_logging_options(options)
    options.parse_command_line(["--logging", "info"])
    print(options.logging)
    tornado.options.parse_command_line()
    print(options.log_rotate_when)
    define_logging_options(options)
    print(options.log_rotate_when)


if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:53:02.624883
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        colorama.init()
    except ImportError:
        pass
    logger = logging.getLogger("tornado.test")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    logger.addHandler(logging.StreamHandler())
    for method in ('debug', 'info', 'warning', 'error', 'critical'):
        getattr(logger, method)("test")
    logger.removeHandler(logger.handlers[0])



# Generated at 2022-06-24 08:53:04.811250
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)
    assert isinstance(formatter, LogFormatter)



# Generated at 2022-06-24 08:53:12.045557
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.log
    import tornado.options
    import tornado.testing

    class TestLogFormatter(tornado.log.LogFormatter):
        def __init__(self) -> None:
            super().__init__()
            self.formats = []  # type: Any

        def format(self, record: Any) -> str:
            self.formats.append(record)
            return super().format(record)

    class LoggingTest(tornado.testing.AsyncTestCase):
        # Named to ensure that its runner is detected by test-all.sh
        def test_logging(self) -> None:
            root_logger = logging.getLogger()
            test_handler = logging.StreamHandler()
            root_logger.addHandler(test_handler)
            options = tornado.options.options


# Generated at 2022-06-24 08:53:14.724698
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()


# Generated at 2022-06-24 08:53:25.035524
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    expected = (
        "[D 150610 17:15:40 mylogger:123]\033[2;34m foo\033[0m\n"
        "    \033[2;34m  bar\033[0m"
    )
    import logging
    from datetime import datetime
    formatter = LogFormatter()
    colorama.init()  # doctest: +SKIP
    formatter.format(logging.LogRecord(
        "mylogger", logging.DEBUG, "/fake/path", 123,
        "foo\n  bar", None, None)
    ) == expected

test_LogFormatter_format()


# Generated at 2022-06-24 08:53:27.167582
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define_logging_options()
    print(options)