

# Generated at 2022-06-24 08:43:30.672872
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from io import StringIO
    # StringIO objects have a closed attribute in Python 3
    try:
        assert StringIO().closed is None
    except AttributeError:
        pass
    assert LogFormatter().format(logging.LogRecord("tornado.access", logging.INFO, "x", -1, "x", (None, None, None), None)) == "[I x tornado.access:-1] x"
    assert LogFormatter().format(logging.LogRecord("tornado.access", logging.INFO, "\u00e9", -1, "x", (None, None, None), None)) == "[I x tornado.access:-1] \u00e9"

# Generated at 2022-06-24 08:43:32.586700
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:43:43.693324
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass
    # logging.basicConfig(level=logging.DEBUG, stream=out)
    # logger = logging.getLogger()
    # out = io.StringIO()
    # loghandler = logging.StreamHandler(out)
    # loghandler.setFormatter(LogFormatter())
    # logger.addHandler(loghandler)
    # logger.info("test logging")
    # msg = out.getvalue()
    # print(msg)
    # out = io.StringIO()
    # loghandler = logging.StreamHandler(out)
    # loghandler.setFormatter(LogFormatter())
    # logger.addHandler(loghandler)
    # logger.info("test logging")
    # msg = out.getvalue()
    # print(msg)



# Generated at 2022-06-24 08:43:48.116451
# Unit test for function define_logging_options
def test_define_logging_options():
    ''''''
    define_logging_options()
test_define_logging_options()

# Generated at 2022-06-24 08:43:49.065471
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()

# Generated at 2022-06-24 08:43:53.886186
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    logging.basicConfig()

    logging.debug("debug message")
    level = logging.getLogger().getEffectiveLevel()
    assert level == logging.DEBUG

    # check log_to_stderr
    tornado.options.define("log_to_stderr", type=bool, default=False)
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_file_prefix", type=str, default="application.log")

    tornado.options.parse_command_line()
    enable_pretty_logging()
    logging.debug("debug message")
    assert len(logging.getLogger().handlers) == 1

    tornado.options.define("log_to_stderr", type=bool, default=True)
    tornado.options.parse_command_line

# Generated at 2022-06-24 08:43:59.603230
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log = LogFormatter()
    assert(log.datefmt == LogFormatter.DEFAULT_DATE_FORMAT)
    log = LogFormatter(fmt = LogFormatter.DEFAULT_FORMAT)
    assert(log.datefmt == LogFormatter.DEFAULT_DATE_FORMAT)


# Generated at 2022-06-24 08:44:06.224855
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = ""
    tornado.options.options.log_to_stderr = True
    print("test_enable_pretty_logging - start")
    enable_pretty_logging()
    print("test_enable_pretty_logging - end")
    
test_enable_pretty_logging()

# Generated at 2022-06-24 08:44:10.999784
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    class record:
        def __init__(self):
            self.message = "test message"
            self.exc_info = None
            self.exc_text = None
    record.levelno = logging.ERROR
    print (log_formatter.format(record()))


# Generated at 2022-06-24 08:44:17.711823
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(
        fmt = "[%(levelname)s %(asctime)s %(module)s:%(lineno)d] %(message)s",
        datefmt = "%y%m%d %H:%M:%S",
    )
    assert isinstance(formatter, logging.Formatter)


# Generated at 2022-06-24 08:44:30.164263
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import unittest
    from unittest.mock import Mock

    mock_record = Mock()
    mock_record.message = 'testmessage'
    mock_record.asctime = 'testasctime'
    mock_record.levelno = logging.DEBUG
    mock_record.exc_info = None
    mock_record.exc_text = None
    mock_record.levelname = 'DEBUG'
    mock_record.lineno = '10'
    mock_record.module = 'test'
    logger = LogFormatter()
    result = logger.format(mock_record)
    assert result == '[D testasctime test:10] testmessage'



# Generated at 2022-06-24 08:44:38.922286
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    tornado.options.options.log_file_prefix ="/home/joe/new"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_max_size = 100*1000*1000
    tornado.options.options.log_file_num_backups = 10
    enable_pretty_logging(tornado.options.options,logger=logging.getLogger())

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:44:43.755562
# Unit test for function define_logging_options
def test_define_logging_options():
    options = None
    define_logging_options(options)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:44:53.117405
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define_logging_options
    from tornado.options import options
    from tornado.options import parse_command_line
    define_logging_options(options)
    parse_command_line(["--logging=debug"])
    # Num of handlers is 3 ,one is for file log, one is for console log,another is for tornado
    # Note that if you are running multiple tornado processes, log_file_prefix must be different for each of them (e.g. include the port number)
    assert len(logging.getLogger("tornado.application").handlers) == 3
    assert logging.getLogger("tornado.application").getEffectiveLevel() == 10

# Generated at 2022-06-24 08:45:03.505891
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name='name',
        level=logging.DEBUG,
        fn=None,
        lno=None,
        msg='',
        args=(),
        exc_info=None,
        func=None,
        extra=None,
    )

# Generated at 2022-06-24 08:45:08.611893
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
    # If the the options.log_rotate_mode value is not "size" or "time", the
    # ValueError should be raised.
    options.log_rotate_mode = "wrong"
    try:
        options.parse_command_line()
    except ValueError as e:
        assert str(e) == 'The value of log_rotate_mode option should be ' + '"size" or "time", not "wrong".'
    else:
        assert False
    options.log_rotate_mode = "time"
    # The options.log_rotate_interval value should be greater than 0.
    options.log_rotate_interval = 0

# Generated at 2022-06-24 08:45:16.864639
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    #from tornado.options import options, define
    #from tornado.log import app_log

    #define("logging", default="none")
    #define("log_file_prefix", default="t.log")
    #define("log_rotate_mode", default="time")
    #define("log_rotate_when", default="S")
    #define("log_rotate_interval", default=1)
    #define("log_file_num_backups", default=10)

    #enable_pretty_logging()
    #assert len(app_log.handlers) == 1
    #assert isinstance(app_log.handlers[0], logging.handlers.RotatingFileHandler)
    pass

# Generated at 2022-06-24 08:45:25.544122
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    from tornado.log import enable_pretty_logging, define_logging_options, gen_log
    define_logging_options(tornado.options.options)
    tornado.options.options.parse_command_line(["--help"])
    gen_log.setLevel(logging.DEBUG)
    gen_log.debug("This is a DEBUG message")
    enable_pretty_logging(tornado.options.options)
    gen_log.debug("This is a DEBUG message")

enable_pretty_logging()

# Generated at 2022-06-24 08:45:28.650715
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test for method format(...) of class LogFormatter
    # some code
    pass


# Generated at 2022-06-24 08:45:33.885230
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=logging.DEBUG,
                        format="%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s",
                        datefmt="%a, %d %b %Y %H:%M:%S",
                        filename="test.log",
                        filemode="w")
    logging.critical("critical message")
    logging.error("error message")
    logging.warning("warning message")
    logging.info("info message")
    logging.debug("debug message")
    logging.debug("test")

# Generated at 2022-06-24 08:45:39.968481
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
    # print(options) # 'log_file_prefix', 'log_to_stderr', 'logging'



__all__ = ["access_log", "app_log", "gen_log", "enable_pretty_logging"]

# Generated at 2022-06-24 08:45:42.739455
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.parse_config_file("./tornado.conf")


# Generated at 2022-06-24 08:45:50.806389
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    options.define(
        "log_to_stderr",
        type=bool,
        default=None,
        help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."
        ),
    )

# Generated at 2022-06-24 08:45:59.455970
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = None
    tornado.options.options.log_to_stderr = None
    tornado.options.options.logging = "debug"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 10485760
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    enable_pretty_logging()

# Generated at 2022-06-24 08:46:03.986606
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # prepare the test
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS

    test_log = logging.getLogger("test_logger")
    test_record = logging.LogRecord("tornado.general", logging.DEBUG, "./test", 1, "test_message", [], None)

    # test
    test_formatter = LogFormatter(fmt, datefmt, style, color, colors)
    assert(type(test_formatter.format(test_record)) == str)



# Generated at 2022-06-24 08:46:15.549687
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class StubLogRecord:
        pass

    formatter = LogFormatter()

    STUB_RECORD = StubLogRecord()
    STUB_RECORD.module = 'module'
    STUB_RECORD.lineno = 'lineno'
    STUB_RECORD.message = 'message'
    STUB_RECORD.levelname = 'levelname'
    STUB_RECORD.asctime = 'asctime'
    STUB_RECORD.color = 'color'
    STUB_RECORD.end_color = 'end_color'
    STUB_RECORD.exc_info = 'exc_info'

    assert formatter.format(STUB_RECORD) == '[levelname asctime module:lineno] message'


# Generated at 2022-06-24 08:46:26.918357
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import time
    from tornado.testing import AsyncHTTPTestCase

    class LogFormatterTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return self.application

        def test_default(self):
            self.application.settings['log_function'] = self.write_log
            self.http_client.fetch(self.get_url('/'))

            time.sleep(0.1)
            start = time.time()
            while not self.log_content:
                time.sleep(0.1)
                if time.time() - start > 5:
                    self.fail("didn't get any log entry")

            match = re.search('\[(.+)\]', self.log_content)
            self.assertIsNotNone(match)

# Generated at 2022-06-24 08:46:33.339050
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print(LogFormatter.__doc__)
    # Given
    logFormatter = LogFormatter()
    # When
    record = logging.LogRecord(
        name = 'test',
        level = logging.DEBUG,
        pathname = 'test',
        lineno = 1,
        msg = 'test',
        args = tuple(),
        exc_info = None,
    )
    result = logFormatter.format(record)
    # Then
    expected = (
        '[D 0-01-01 00:00:00 test:1] test'
    )
    assert result == expected


# Generated at 2022-06-24 08:46:35.142411
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:46:36.493848
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter


# Generated at 2022-06-24 08:46:40.876398
# Unit test for function define_logging_options
def test_define_logging_options():
    import unittest
    from tornado.options import OptionParser
    class Test_define_logging_options(unittest.TestCase):
        def test_1(self):
            op = OptionParser()
            define_logging_options(op)
        def test_2(self):
            define_logging_options()
    unittest.main()

# Generated at 2022-06-24 08:46:43.670027
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    enable_pretty_logging(dict(logging="INFO"))

# Generated at 2022-06-24 08:46:54.165968
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    from tornado.options import options
    op = OptionParser()
    define_logging_options(op)
    op.parse_command_line(args=["--logging", "none"])
    assert options.logging == "none"
    op.parse_command_line(args=["--logging", "info"])
    assert options.logging == "info"
    op.parse_command_line(args=["--log_to_stderr", "--logging", "info"])
    assert options.logging == "info"
    assert options.log_to_stderr == True
    op.parse_command_line(args=["--log_file_prefix", "log"])
    assert options.log_file_prefix == 'log'
    op.parse_command

# Generated at 2022-06-24 08:47:04.974789
# Unit test for function define_logging_options
def test_define_logging_options():
    # Ensure options is defined
    import tornado.options
    tornado.options.define("options", default=None)
    # Run the test
    define_logging_options()
    # Test successful


if __name__ == "__main__":
    import logging
    import sys
    import tornado.options

    test_define_logging_options()

    logging.info("foo %s %s %s", "a", "b", "c", exc_info=True)
    logging.info("bar")

    try:
        raise ValueError("some error")
    except ValueError:
        logging.error("invalid input", exc_info=True)

    tornado.options.parse_command_line()
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-24 08:47:12.997473
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define as define_options, options
    from tornado.log import define_logging_options

    define_logging_options()

    # test log_file_prefix
    define_options("log_file_prefix", type=str, default=None,
        help="test log_file_prefix")
    define_options("log_file_max_size", type=int, default=100 * 1000 *1000,
        help="test log_file_max_size")
    define_options("log_file_num_backups", type=int, default=10,
        help="test log_file_num_backups")
    define_options("log_rotate_when", type=str, default="midnight",
        help="test log_rotate_when")

# Generated at 2022-06-24 08:47:18.092055
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT
    assert formatter._colors == formatter.DEFAULT_COLORS

# Generated at 2022-06-24 08:47:22.131726
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True)
    record = logging.LogRecord(
        name="test",
        level=logging.WARNING,
        pathname="/path/to/tornado/logging_test.py",
        lineno=1,
        msg="test",
        args=None,
        exc_info=None,
    )
    s = formatter.format(record)
    assert s == "\x1b[0;33m[WARNING 20050820 14:06:40 logging_test:1]\x1b[0m test"
test_LogFormatter_format()



# Generated at 2022-06-24 08:47:26.138598
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado import escape
    from tornado.log import gen_log
    gen_log.setLevel(logging.DEBUG)
    gen_log.handlers = [logging.StreamHandler()]

    gen_log.debug("test debug")
    gen_log.info("test info")
    gen_log.warning("test warning")
    gen_log.error("test error")
    gen_log.critical("test critical")


# Generated at 2022-06-24 08:47:34.324737
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    class MockRecord(object):
        levelno = logging.DEBUG
        __dict__ = {
            "message": "message",
            "asctime": "2019-10-10 10:10:10",
            "color": 4,
            "end_color": " ",
            "exc_info": "exc_info",
            "exc_text": "exc_text"
        }
    record = MockRecord()
    # 替换了几个参数，然后调用了formatTime和formatException
    res = formatter.format(record)
    # print(res)

test_LogFormatter_format()



# Generated at 2022-06-24 08:47:46.067618
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.log import LogFormatter, access_log

    # create test logger
    log = logging.getLogger("test_log")
    log.setLevel(logging.DEBUG)
    # create test handler
    hdlr = logging.StreamHandler(sys.stderr)
    hdlr.setLevel(logging.DEBUG)
    # create test formatter
    fmt = LogFormatter()
    # add the handler and formatter
    hdlr.setFormatter(fmt)
    log.addHandler(hdlr)

    # test message in a utf-8
    log.debug("this is a test message with 我 中国人")
    # test message with a byte string

# Generated at 2022-06-24 08:47:46.978431
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass


# Generated at 2022-06-24 08:47:52.775473
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Option:
        logging = "ERROR"
        log_file_prefix = ""
        log_rotate_mode = "size"
        log_file_max_size = 0
        log_file_num_backups = 0
        log_rotate_when = ""
        log_rotate_interval = 0
        log_to_stderr = None

    options = Option()
    enable_pretty_logging(options)
    logger = logging.getLogger()
    logger.error("First error message")
    logger.warning("First warning message")


# Unit tests

# Generated at 2022-06-24 08:48:00.488954
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf._normal == ""
    assert len(lf._colors) == 5
    assert lf._colors[logging.DEBUG] == "\033[2;34m"
    assert lf._colors[logging.INFO] == "\033[2;32m"
    assert lf._colors[logging.WARNING] == "\033[2;33m"
    assert lf._colors[logging.ERROR] == "\033[2;31m"
    assert lf._colors[logging.CRITICAL] == "\033[2;35m"



# Generated at 2022-06-24 08:48:06.508571
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    import tornado.log
    logging.debug('xxxxx')
    tornado.options._options = None
    tornado.options._parse_command_line()
    tornado.log.enable_pretty_logging(tornado.options.options)
    logging.debug('aaaaa')

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:48:16.679748
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log = logging.getLogger("tornado.test_LogFormatter")
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler())
    # noinspection SpellCheckingInspection
    log.warn("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
             "N", "O", "P", "Q", "R", "S", "T")

# Generated at 2022-06-24 08:48:25.665957
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    parser = OptionParser()
    define_logging_options(parser)
    parser.parse_command_line(
        ["--logging=debug", "--log_file_prefix=./myapps", "--log_to_stderr=True"]
    )
    assert options.logging == "debug"
    assert options.log_file_prefix == "./myapps"
    assert options.log_to_stderr == True
    assert options.log_file_max_size == 100*1000*1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

# Generated at 2022-06-24 08:48:37.019964
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    import logging
    import sys

    stream = io.StringIO()
    stream_handler = logging.StreamHandler(stream)
    logging.basicConfig(
               level=logging.DEBUG, stream=stream,
               format='%(name)s:%(lineno)d:%(levelname)s: %(message)s')
    #logging.Formatter.__init__(self, datefmt=datefmt)
    #self._fmt = fmt

    #self._colors = {}  # type: Dict[int, str]
    #if color and _stderr_supports_color():
    if curses is not None:
        fg_color = curses.tigetstr("setaf") or curses.tigetstr("setf") or b""
        # Convert the terminal control characters from

# Generated at 2022-06-24 08:48:42.360618
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    logger = logging.getLogger('test_log')
    logger.setLevel(logging.DEBUG)
    formatter = LogFormatter(
        color=False,
    )
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    logger.info('test_log')


# Generated at 2022-06-24 08:48:55.362804
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    '''
    unit test for function enable_pretty_logging
    '''
    from tornado.testing import AsyncHTTPTestCase, AsyncHTTPClient, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line, \
        parse_config_file

    define(
        'logging',
        default='none',
        type=str,
        help='set logging level',
        metavar='logging')

    define(
        'log_file_prefix',
        default=None,
        type=str,
        help='Path prefix for log files. '
             'Note that if you are running multiple tornado processes, '
             'log_file_prefix must be different for each of them (e.g. '
             'include the port number)')


# Generated at 2022-06-24 08:49:00.592021
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define("log_file_num_backups", type=int, default=10, help="number of log files to keep")
    test_option = tornado.options.options
    assert test_option.log_file_num_backups == 10



# Generated at 2022-06-24 08:49:01.611986
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # TODO
    pass



# Generated at 2022-06-24 08:49:08.702966
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    op = tornado.options.OptionParser()
    define_logging_options(op)
    op.parse_config_file("./examples/httpclient/app.conf")
    print(op.logging)
    print(op.log_to_stderr)
    print(op.log_file_prefix)
    print(op.log_file_max_size)
    print(op.log_file_num_backups)
    print(op.log_rotate_when)
    print(op.log_rotate_interval)
    print(op.log_rotate_mode)


# test_define_logging_options()

# Generated at 2022-06-24 08:49:11.145181
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert enable_pretty_logging() == None

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:49:20.264654
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define
    from tornado.options import define_logging_options
    define("log_file_prefix", default="server.log")
    define("log_file_max_size", default=10*1000*1000)
    define("log_file_num_backups", default=2)
    define_logging_options()
    print("=======test_define_logging_options:After define_logging_options()================")
    print("options.log_file_prefix=",options.log_file_prefix)
    print("options.log_file_max_size=",options.log_file_max_size)
    print("options.log_file_num_backups=",options.log_file_num_backups)

# Generated at 2022-06-24 08:49:29.259056
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    # type: ignore
    class fake_record():
        def __init__(self,**kwargs):
            for key,value in kwargs.items():
                setattr(self,key,value)
            self.__dict__['__' + key + '__'] = value

    # case 1:
    # message is str
    record = fake_record(message='this is a str', levelno=1, exc_info=None, exc_text=None)
    record.asctime = formatter.formatTime(record, formatter.datefmt)
    if record.levelno in formatter._colors:
        record.color = formatter._colors[record.levelno]
        record.end_color = formatter._normal
    else:
        record.color = record.end

# Generated at 2022-06-24 08:49:33.848674
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    #logging = "none"
    logging = "warning"
    options = tornado.options.parse_command_line(
        [
            "--logging",
            logging,
            "--log-file-prefix",
            "dgutest.log",
            "--log_rotate_mode",
            "size",
            "--log_file_max_size",
            "20",
            "--log_file_num_backups",
            "3",
        ],
        final=True,
    )

    enable_pretty_logging(options)

# Generated at 2022-06-24 08:49:37.471168
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import tornado.log
    formatter=tornado.log.LogFormatter()
    logger=logging.getLogger(__name__)
    logger.log(logging.INFO, "Hello, world")

# Generated at 2022-06-24 08:49:38.852746
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    obj = LogFormatter()
    record = {"levelno": 0, "exc_text": 12, "asctime": "date", "end_color": "", "message": "msg"}
    obj.format(record)


# Generated at 2022-06-24 08:49:46.560186
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = 'debug'
    tornado.options.options.log_to_stderr = False
    tornado.options.options.log_file_prefix = 'test.log'
    tornado.options.options.log_rotate_mode = 'size'
    tornado.options.options.log_file_max_size = 1024*1024*1024
    tornado.options.options.log_file_num_backups = 1
    enable_pretty_logging()

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:49:50.525382
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    formatter = LogFormatter(color=True)

    test = True
    if test:
        handler.setFormatter(formatter)

    logger.error("test")
    logger.warning("test")


# Generated at 2022-06-24 08:49:51.973138
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options()
    tornado.options.parse_config_file("test/options_test.conf")

# Generated at 2022-06-24 08:49:58.860490
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.config

    # create logger
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = LogFormatter()

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    log.addHandler(ch)

    # 'application' code
    log.debug('debug message')
    log.info('info message')
    log.warn('warn message')
    log.error('error message')
    log.critical('critical message')

if __name__ == '__main__':
  test_LogFormatter_format()

# Generated at 2022-06-24 08:50:00.170524
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass


# Generated at 2022-06-24 08:50:01.286157
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-24 08:50:11.907707
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import options
    # Create a logger
    logger = logging.getLogger("test")
    options.logging = None
    logger.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    logger.addHandler(logging.StreamHandler(sys.stdout))
    # Create and test logging records
    class SampleRecord(object):
        def __init__(self):
            self.exc_info = None
            self.exc_text = None
            self.levelname = 'DEBUG'
            self.module = 'logging_test'
            self.lineno = 10
            self.name = 'test'
        def getMessage(self):
            return "Test message"
    print('Testing LogFormatter with default parameters:')
    record = SampleRecord()

# Generated at 2022-06-24 08:50:19.766471
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_dict = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    # 指定したフォーマットが正しく設定されているかをテストする

# Generated at 2022-06-24 08:50:21.590538
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:50:25.264781
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s")



# Generated at 2022-06-24 08:50:33.867523
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        enable_pretty_logging()
        logger = app_log = logging.getLogger("tornado.application")
        logger.warning("Test warning.")
        logger.error("Test error.")
        # get Logger object, name is 'tornado.application'
        logger_object = logging.getLogger("tornado.application")
        # get Logger object's children
        logger_children = logger_object.manager.loggerDict.keys()
        assert("tornado.application" in logger_children)
    except:
        assert False, "enable_pretty_logging ran with an error"
    else:
        assert True

# Generated at 2022-06-24 08:50:45.819511
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.ERROR)
    fmt = "%(levelname)s %(message)s"
    fmt2 = "%(color)s%(levelname)s%(end_color)s %(message)s"
    try:
        colorama.init()
    except AttributeError:
        pass
    datefmt = "%y-%m-%d %H:%M:%S"
    logger = logging.getLogger(__name__)

    def testformatter(prefix: str, fmt: str, datefmt: str, use_color: bool) -> None:
        formatter = LogFormatter(fmt=fmt, datefmt=datefmt, color=use_color)
        stream = logging.StreamHandler(None)
        # Use a dummy stream to filter out the log messages

# Generated at 2022-06-24 08:50:47.678754
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()


define_logging_options()

# Generated at 2022-06-24 08:50:49.976821
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        obj = LogFormatter()
    except Exception as e:
        assert False, e


# Generated at 2022-06-24 08:50:51.961485
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    enable_pretty_logging(None,logger)

# Generated at 2022-06-24 08:50:57.578908
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast
    options = tornado.options.options
    options.logging = "info"

# Generated at 2022-06-24 08:51:04.532654
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.root.handlers = []
    logging.basicConfig(level=logging.DEBUG)

    log_record = logging.LogRecord(
        name="tornado.access",
        level=0,
        pathname="",
        lineno=0,
        msg="",
        args=None,
        exc_info=None,
    )
    test_log_formatter = LogFormatter()
    test_log_formatter.format(log_record)

# Constant from io.py
b_suffixes = ["B", "K", "M", "G", "T", "P", "E", "Z", "Y"]

# Generated at 2022-06-24 08:51:16.417167
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    import io
    import logging
    import sys
    import unittest
    import unittest.mock

    class DictFormatter(LogFormatter):
        def __init__(
            self, fmt: str = None, datefmt: str = None, style: str = None
        ) -> None:
            LogFormatter.__init__(self, fmt, datefmt, style)
            self.usable_fmt = self._fmt

        def format(self, record: Any) -> str:
            output = LogFormatter.format(self, record)
            return output.split(" ")[-1]


# Generated at 2022-06-24 08:51:26.346543
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="",
        lineno=1,
        msg="Test log message",
        args=[],
        exc_info=None,
    )
    color = formatter._colors[logging.INFO]
    normal = formatter._normal
    assert formatter.format(record) == (
        f"{color}[I {record.asctime} -:1]{normal} Test log message"
    )
    # Bytestring tests
    record.msg = b"Test log message"

# Generated at 2022-06-24 08:51:32.250305
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    class record:
        levelno = 10
        exc_info = True
        exc_text = "hello"
        args = "hello"
        asctime = "world"
        message = "hello world"
    log_formatter.format(record)
    
    

# Generated at 2022-06-24 08:51:34.771266
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-24 08:51:41.546087
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import mock
    import unittest

    class FakeLogger(object):
        def __init__(self, name) -> None:
            self.name = name
            self.handlers = [mock.Mock()]
            self.handlers[0].setLevel.return_value = None
            self.handlers[0].setFormatter.return_value = None

    l = LogFormatter()
    l.format(FakeLogger("test"))
    l.formatTime(FakeLogger("test"), "")
    l.formatException(Exception())
    l.formatStack(Exception())
    # self.assertIsNotNone(LogFormatter.formatException.__doc__, "Please add docstring")



# Generated at 2022-06-24 08:51:45.226488
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    s = f.format(logging.LogRecord("", logging.DEBUG, "", 0, "test", (), None, ""))
    assert s.startswith("[D ")



# Generated at 2022-06-24 08:51:52.807558
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line(args = ['./test_tornado/program.py'])
    assert options.logging == 'info'
    assert options.log_to_stderr == None
    assert options.log_file_prefix == None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == 'midnight'
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == 'size'
    #options.parse_config_file('./test_tornado/config.conf')
    #assert options.logging == '

# Generated at 2022-06-24 08:52:01.620690
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Preset option value:
    options = Option()
    options.logging = "none"
    options.log_file_prefix = "/home/user/a.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 10
    options.log_rotate_when = "s"
    options.log_rotate_interval = 1
    options.log_to_stderr = False
    # Test function enable_pretty_logging:
    enable_pretty_logging(options)


# Generated at 2022-06-24 08:52:08.419592
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import access_log, gen_log
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    # add a null handler to raise exceptions if no other handlers are present
    log.addHandler(logging.NullHandler())
    # create filehandler
    fh = logging.FileHandler("test_LogFormatter_format.log")
    # iterate over list of loggers and add a file handler to each

# Generated at 2022-06-24 08:52:10.281006
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:52:19.819772
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lines = [
        "\xE2\x80\x99",  # unicode(smartquotes)
        "\n\n\n\n\n\n",  # newlines
        b"\xE2\x80\x99".decode("utf-8", "replace"),  # smartquotes translated to utf8
        b"\xe2\x80\x99",  # utf8 byte string
        b"\x99",  # garbage byte string
        "\xe2\x80\x99",  # A meaningless string
    ]
    msg = "".join(lines)

    record = logging.LogRecord(  # type: ignore
        "test", logging.INFO, "foo.py", 1, msg, None, None
    )

    # Test with no color

# Generated at 2022-06-24 08:52:20.582690
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
test_enable_pretty_logging()

# Generated at 2022-06-24 08:52:27.261659
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    import tornado.options
    parser = OptionParser()
    parser.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    parser.define(
        "log_to_stderr",
        type=bool,
        default=None,
        help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."
        ),
    )

# Generated at 2022-06-24 08:52:39.410056
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = logging.Formatter("%(asctime)s %(message)s", "%y%m%d")

    class TestRecord(object):
        def __init__(self):
            self.levelno = logging.DEBUG  # type: int
            self.message = "TEST MESSAGE"  # type: str

    record = TestRecord()

    lf = LogFormatter()
    assert lf.format(record) == "[D 20000101] TEST MESSAGE"
    lf = LogFormatter(datefmt="%H:%M:%S")
    assert lf.format(record) == "[D 00:00:00] TEST MESSAGE"
    lf = LogFormatter(color=False)

# Generated at 2022-06-24 08:52:49.575339
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log = LogFormatter()
    # Test the case we have color support
    log.color = True
    log._normal = ''
    log._colors = {
        logging.DEBUG: '',
        logging.INFO: '',
        logging.WARNING: '',
        logging.ERROR: '',
        logging.CRITICAL: '',
    }
    record = logging.LogRecord(
        name='tornado.application',
        level=logging.DEBUG,
        pathname='/path/to/tornado/options.py',
        lineno=62,
        msg='Test LogRecord',
        args=None,
        exc_info=None,
    )
    log.format(record)
    assert record.message == 'Test LogRecord'
    assert record.asctime == '20000101 00:00:00'

# Generated at 2022-06-24 08:52:58.900223
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class MockLogRecord(object):
        """A fake LogRecord."""

        def __init__(self) -> None:
            self.levelno = logging.DEBUG
            self.msg = u"Test message"

    def format_date_time(record: Any, datefmt: str) -> str:
        """Return fake date and time."""
        return "9/10/11 10:11:12"

    formatter = LogFormatter(color=False)
    formatter.formatTime = format_date_time
    assert formatter.format(MockLogRecord()) == "[D 9/10/11 10:11:12] Test message"



# Generated at 2022-06-24 08:53:09.156453
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    options.parse_command_line()

if __name__ == '__main__':
    test_define_logging_options()


# Copyright 2009 Facebook
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
#

# Generated at 2022-06-24 08:53:22.380082
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
  # Test normal case
  logger = logging.getLogger('logger')
  logger.setLevel(logging.DEBUG)
  handler = logging.StreamHandler(stream=sys.stdout)
  handler.setFormatter(LogFormatter(
        fmt='%(levelname)s %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))
  logger.addHandler(handler)
  logger.info("something info")
  logger.debug("something debug")
  logger.warning("something warn")
  logger.error("something error")
  logger.critical("something critical")

# Test json format case
  logger = logging.getLogger('json_logger')
  logger.setLevel(logging.DEBUG)