

# Generated at 2022-06-24 08:43:34.753858
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    x = LogFormatter()
    assert x._colors[logging.WARNING] == "\033[2;33m"
    assert x._normal == "\033[0m"
    assert x._fmt == LogFormatter.DEFAULT_FORMAT

# Reuse the class
LogFormatter = LogFormatter # type: ignore

# Singleton object that can be imported from other modules.
# Not using singleton pattern in order to keep __init__ from executing
# pylint: disable=invalid-name
default_log_formatter = LogFormatter()
default_log_formatter.converter = getattr(logging.Formatter, "_converter", None)

# Generated at 2022-06-24 08:43:37.764719
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert hasattr(formatter, 'format')

# The default log formatter to use for tornado.access
_default_access_log_formatter = LogFormatter(
    fmt="%(color)s%(levelname)s %(asctime)s %(message)s%(end_color)s"
)



# Generated at 2022-06-24 08:43:38.850131
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-24 08:43:44.730054
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.testing import AsyncTestCase, gen_test

    class TestHandler(tornado.options.OptionsParser):
        """Options handler with a few testable options."""

        def __init__(self) -> None:
            super(TestHandler, self).__init__()
            self.define(
                "log_file_prefix",
                type=str,
                default=None,
                metavar="PATH",
                help="Path prefix for log files. " "Note that if you are running multiple tornado processes, " "log_file_prefix must be different for each of them (e.g. " "include the port number)",
            )
            self.define(
                "log_to_stderr", type=bool, default=None, help="Log to stderr instead of files."
            )
           

# Generated at 2022-06-24 08:43:55.652764
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import inspect
    import sys
    import traceback
    formatter = LogFormatter()
    record = logging.makeLogRecord({})
    record.levelname = "INFO"
    record.levelno = logging.INFO
    record.name = "tornado.general"
    record.msg = "Test message"
    record.pathname = __file__
    record.lineno = inspect.currentframe().f_lineno - 1
    record.funcName = "test_LogFormatter_format"
    record.threadName = "MainThread"
    record.processName = "MainProcess"
    record.exc_info = sys.exc_info()
    record.exc_text = None
    record.stack_info = None
    record.asctime = formatter.formatTime(record, formatter.datefmt)

# Generated at 2022-06-24 08:43:59.864709
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.log
    import logging
    import tornado.options

    tornado.options.options.logging = "debug"
    tornado.options.options.log_to_stderr = True

    tornado.log.enable_pretty_logging()
    assert logging.getLogger().getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-24 08:44:09.603601
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado import options
    import unittest
    import logging
    import os
    logging.basicConfig(level=logging.DEBUG)
    class TestEnablePrettyLogging(unittest.TestCase):

        def setUp(self):
            try:
                os.remove("./tst-log")
            except:
                pass
            self.options = options.Options()
            self.options.log_file_prefix = "tst-log"
            self.options.logging = "debug"
            self.options.log_rotate_mode = "time"
            self.options.log_rotate_when = "D"
            self.options.log_rotate_interval = 1
            self.options.log_file_num_backups = 5
            self.options.log_to_stderr = False

# Generated at 2022-06-24 08:44:12.374952
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.log_file_prefix = "/tmp/test_log.log"
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:44:23.331225
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        from unittest import mock
    except ImportError:
        import mock  # type: ignore

    msg = "message"
    level = "info"
    mock_record = mock.Mock(
        **{
            "getMessage.return_value": msg,
            "levelno": logging.INFO,
            "asctime": "2018-08-29 06:38:54,804",
            "msecs": "804.850",
            "levelname": level,
            "name": "tornado.application",
            "exc_info": None,
        }
    )

    log_formatter = LogFormatter()
    # On Windows, colorama.init must be called before calling LogFormatter.format().
    # Otherwise, the output will be in white, not green.

# Generated at 2022-06-24 08:44:33.740947
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, parse_config_file
    options = OptionParser()
    define_logging_options(options)
    assert len(options.parse_command_line(["--logging", "warning"])) == 0
    assert len(options.parse_command_line(["--logging", "none"])) == 0
    assert len(options.parse_command_line(["--logging", "invalid"])) == 1

    f = "blah"
    assert enable_pretty_logging(options) is None
    enable_pretty_logging(options, logging.getLogger("x"))
    enable_pretty_logging(options, logging.getLogger("x.y"))

    options.parse_command_line(["--logging=debug"])
    options.log_file_prefix = f
    enable

# Generated at 2022-06-24 08:44:41.398729
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    # Verifies that __init__ works for its required parameters
    formatter = LogFormatter(color = False)
    # Verifies that __init__ works for its optional parameters
    formatter = LogFormatter(fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s",
        datefmt = "%Y%m%d %H:%M:%S",
        style = "%",
        color = True,
        colors={"tornado.general": 500,
                "tornado.application": 600})



# Generated at 2022-06-24 08:44:49.245708
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options._options
    options.parse_command_line(["--logging=debug", "--log_to_stderr=true",
                                "--log_file_prefix=./tornado.log", "--log_rotate_mode=size"])
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_rotate_mode)

# Generated at 2022-06-24 08:44:57.874403
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """some tests for LogFormatter.format
    """
    import unittest
    import datetime as dt
    import logging as log

    # Preparations
    class TestLogRecord():
        """a test record
        """
        def __init__(self, levelno: int):
            self.asctime = "{}".format(dt.datetime.now())
            self.levelno = levelno
            self.module = "testLogFormatter"
            self.lineno = "1"
            self.message = "test message"
            self.exc_info = Exception("Test Exception")
            self.color = ""
            self.end_color = ""


# Generated at 2022-06-24 08:45:03.490013
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG)

    formatter=LogFormatter()
    formatter2=LogFormatter(color=False)
    formatter3=LogFormatter(color=True, colors={42:1})
    record=logging.LogRecord
    record.name="test"
    record.message="test"
    record.lineno=1
    record.levelname="DEBUG"
    record.module="test"
    record.exc_info=None
    record.exc_text=None
    import time
    record.created=time.time()
    record.msecs=(record.created-int(record.created))*1000
    record.asctime=time.strftime("%y%m%d %H:%M:%S",time.localtime(record.created))

# Generated at 2022-06-24 08:45:04.914228
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options(options)
    print(options)


#test_define_logging_options()

# Generated at 2022-06-24 08:45:10.609701
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def refresh_globals():
        # Resets the LogFormatter object
        global logFormatter_inst
        logFormatter_inst = LogFormatter()

    def reset_globals():
        # Resets the LogFormatter object's varals
        logFormatter_inst.color = False

    def do_test(msg: str, expected: str) -> None:
        """
        The method to be tested (format in this case)
        """
        reset_globals()
        record = logging.LogRecord(
            name="tornado.application",
            level=logging.DEBUG,
            pathname="abc",
            lineno=1,
            msg=msg,
            args=None,
            exc_info=None,
        )
        actual = logFormatter_inst.format(record)

# Generated at 2022-06-24 08:45:13.601444
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    import logging
    import pprint
    record = logging.LogRecord('name', 'info', 'pathname', 100, 'msg', None, None)
    print(record)
    print(formatter.format(record))
    print(dir(record))
    print(dir(formatter))
    pprint.pprint(vars(record))
    pprint.pprint(vars(formatter))
#test_LogFormatter_format()
# tornado.options.parse_config_file('config.py')

# Generated at 2022-06-24 08:45:19.840549
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options.log_to_stderr = None
    options.log_file_prefix = 'log_file_prefix'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 1024
    options.log_file_num_backups = 5
    options.logging = 'debug'
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:45:30.508612
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert isinstance(f.format(logging.LogRecord('tornado.access', logging.INFO, '', 0,'', {}, None)), str) # noqa: E501

# aliases to make logging calls that don't depend on what
# logging_config['loggers'] is set to.  Note that the name is intentionally
# not the same as the module-level definition or the logger name, so that it
# is possible to configure them differently (e.g. to log fewer modules than
# "tornado" or to send warnings to a separate file).
access_log_logger = logging.getLogger("tornado.access")
gen_log_logger = logging.getLogger("tornado.general")
app_log_logger = logging.getLogger("tornado.application")

# define custom levels for

# Generated at 2022-06-24 08:45:31.781305
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert(log_formatter._colors == {})


# Generated at 2022-06-24 08:45:37.628309
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    from logging import Formatter as OFormatter, LogRecord
    from tornado.log import LogFormatter
    record = LogRecord(
        name='tornado.general',
        level=10,
        pathname='/tornado/gen_log.py',
        lineno=10,
        msg='Some message',
        args=[],
        exc_info=None,
        func=None
    )
    # Formatter will not get used, so we are not adding it
    # oformatter = OFormatter()
    # print(oformatter.format(record))
    record.msg = '{}'
    lformatter = LogFormatter()
    print(_stderr_supports_color())
    record.msecs = 0
    record.relativeCreated = 0

# Generated at 2022-06-24 08:45:41.618177
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    from tornado.options import define
    define("logging", default=None, type=str)
    options.logging = "INFO"
    enable_pretty_logging()

# Generated at 2022-06-24 08:45:48.781392
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    assert isinstance(fmt._fmt, str)
    assert fmt._fmt == LogFormatter.DEFAULT_FORMAT
    assert isinstance(fmt._colors, dict)
    assert not fmt._colors
    assert isinstance(fmt._normal, str)
    assert not fmt._normal
    assert isinstance(fmt.datefmt, str)
    assert fmt.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    fmt = logging.Formatter()
    assert isinstance(fmt.datefmt, str)
    assert not fmt.datefmt


# Generated at 2022-06-24 08:46:00.366502
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.ioloop
    tornado.options.define(
        "logging", default="info", help="logging level", type=str
    )
    tornado.options.define(
        "log_file_prefix",
        default=None,
        help=("Path prefix for log files. " "Note that if you are running multiple tornado processes, " "log_file_prefix must be different for each of them (e.g. include the port number)"),
        type=str,
    )

# Generated at 2022-06-24 08:46:00.774730
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-24 08:46:13.493698
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    用于测试方法 format 的返回值是否正确
    """
    formatter = LogFormatter()
    res = formatter.format(logging.LogRecord(name="tornado.general", level=logging.DEBUG, pathname="", lineno=1,
                                             msg="test", args=None, exc_info=None))
    assert res == "[D 01010000 00:00:00 <unknown>:1] test"
    res = formatter.format(logging.LogRecord(name="tornado.general", level=logging.ERROR, pathname="", lineno=1,
                                             msg="test", args=None, exc_info=None))

# Generated at 2022-06-24 08:46:17.984952
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('test')
    log_handler = logging.StreamHandler()
    log_formatter = LogFormatter()
    log_handler.setFormatter(log_formatter)
    logger.addHandler(log_handler)
    logger.setLevel(logging.DEBUG)
    logger.error('test error')
    assert logger.hasHandlers() is True
    assert 1 == 1


# Generated at 2022-06-24 08:46:30.486201
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Test(object):
        def test(self, str: str):
            try:
                if str != "logging error":
                    print(str)
                raise ValueError('ValueError')
            except:
                import sys
                import traceback
                exc_type, exc_value, exc_traceback = sys.exc_info()
                stacktrace = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
                stacktrace = stacktrace.splitlines()
                log_message = stacktrace[-1]
                return log_message

    test = Test()
    levelno = logging.ERROR
    lf = LogFormatter()

# Generated at 2022-06-24 08:46:40.337838
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter()
    record = logging.LogRecord(
        name="name",
        level=logging.DEBUG,
        pathname="pathname",
        lineno=1,
        msg="msg",
        args=None,
        exc_info=None,
    )
    record.getMessage = lambda: "message"
    record.asctime = "2020-03-03 00:00:00,000"

    record.color = logFormatter._colors[record.levelno]
    record.end_color = logFormatter._normal

    assert logFormatter.format(record) == "[D 2020-03-03 00:00:00,000 pathname:1] message"



# Generated at 2022-06-24 08:46:42.385813
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    import tornado.options
    import logging
    tornado.options.enable_pretty_logging()
    parse_command_line()
    gen_log.info('test')

# Generated at 2022-06-24 08:46:50.165455
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    d = dict()
    d['levelname'] = "DEBUG"
    d['asctime'] = "20180807 17:00:00"
    d['module'] = "study.__main__"
    d['lineno'] = 125
    d['message'] = "test log"
    r = logging.makeLogRecord(d)
    yes = LogFormatter().format(r)
    assert yes
    assert isinstance(yes, str)
    assert yes.startswith("[D")


# Generated at 2022-06-24 08:47:02.804156
# Unit test for function define_logging_options
def test_define_logging_options():
    """测试函数定义日志选项."""
    class TestOptions():
        """测试选项."""
        def __init__(self):
            self.__options = {}  # type: Dict[str, Any]

        def define(self, name: str, default: Any, help: str, metavar: str):
            """添加选项."""
            self.__options[name] = {"default": default, "help": help, "metavar": metavar}

        def define_bool(self, name: str, default: Any, help: str):
            """添加选项."""
            self.__options[name] = {"default": default, "help": help}



# Generated at 2022-06-24 08:47:03.558675
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass


# Generated at 2022-06-24 08:47:14.366423
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import options, define
    define("logging")
    define("log_file_prefix")
    define("log_file_num_backups")
    define("log_to_stderr")
    define("log_file_max_size")
    define("log_rotate_when")
    define("log_rotate_interval")
    define("log_rotate_mode")

    options.logging = "info"
    options.log_file_prefix = "tornado.log"
    options.log_file_num_backups = 10
    options.log_to_stderr = True
    options.log_file_max_size = 100
    options.log_rotate_when = "D"
    options.log_rotate_interval = 1
    options.log_rotate_

# Generated at 2022-06-24 08:47:19.410834
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="testLogName",
        level=20,
        pathname="testPathname",
        lineno=10,
        msg="testMessage",
        args="testArgs",
        exc_info=None,
    )
    formatter.format(record)



# Generated at 2022-06-24 08:47:30.234593
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line, parse_config_file
    from io import StringIO
    from logging import getLogger
    define("logging")

    # First, test the 'logging' argument
    for value, level in [('none', 'NOTSET'), ('debug', 'DEBUG'), ('info', 'INFO'), ('warning', 'WARNING'), ('error', 'ERROR')]:
        stdout = StringIO()
        setattr(options, 'log_to_stdout', False)
        logging = getLogger()
        logging.setLevel(level)
        options.logging = value
        try:
            enable_pretty_logging()
            assert logging.getEffectiveLevel() == getattr(logging, level)
        except:
            pass
        finally:
            logging.setLevel('NOTSET')
           

# Generated at 2022-06-24 08:47:43.442895
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    r = []
    r.append({
        'asctime': '191213 09:34:22 ',
        'color': '',
        'message': 'safe_unicode is running',
        'end_color': '',
        'levelname': 'INFO',
        'module': 'test_log',
        'lineno': 5
    })
    r.append({
        'asctime': '191213 09:34:22 ',
        'color': '',
        'message': 'safe_unicode is running',
        'end_color': '',
        'levelname': 'INFO',
        'module': 'test_log',
        'lineno': 5
    })

# Generated at 2022-06-24 08:47:45.547557
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    class LogFormatterTest(LogFormatter):
        pass
    LogFormatterTest(color = False)



# Generated at 2022-06-24 08:47:47.893317
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_rotate_mode = 'time'
    enable_pretty_logging(tornado.options.options, None)

# Generated at 2022-06-24 08:47:54.916462
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(
        fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    # NOTE: colorama 0.3.7 on Python 3.2 produces errors
    # during testing but seems to work fine in real use.
    # As far as I can tell, the problem is that the colorama
    # code sets up stderr with fileno=0, but the test framework
    # uses a StringIO object as stderr, and StringIO has no
    # fileno method.
    # Encoding problems

# Generated at 2022-06-24 08:48:04.265233
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    msg = "asdf"
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/path/to/file",
        lineno=42,
        msg=msg,
        args=None,
        exc_info=None,
    )
    color_fmt = tornado.log.LogFormatter(color=True, fmt="%(color)s%(msg)s%(end_color)s")
    colorless_fmt = tornado.log.LogFormatter(color=False, fmt="%(msg)s")
    assert color_fmt.format(record) == colorless_fmt.format(record) == msg + "  "

# Generated at 2022-06-24 08:48:09.051917
# Unit test for function define_logging_options
def test_define_logging_options():
    # test successfully
    options = type(
        "test_define_logging_options",
        (object,),
        {
         "define": define,
         "add_parse_callback": add_parse_callback,
        },
    )()

    define_logging_options(options)


# Generated at 2022-06-24 08:48:14.516709
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("test_LogFormatter", logging.DEBUG, "", 0, "", None, None))
    formatter.format(
        logging.LogRecord(
            "test_LogFormatter", logging.DEBUG, "", 0, "", None, None, exception=Exception()
        )
    )


# Generated at 2022-06-24 08:48:17.221718
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options as options
    try:
        import logging
    except ImportError:
        logging = None
    if logging:
        enable_pretty_logging(options.logging.lower() == "none")
        
test_enable_pretty_logging()

# Generated at 2022-06-24 08:48:25.991399
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    Unit test for method format of class LogFormatter
    """
    # Ensure that a basic message can be formatted
    lf = LogFormatter()
    record = logging.LogRecord("name", logging.DEBUG, "", 0, "message", (), None)  # noqa: E501
    assert lf.format(record) == "message"

    # An exception with a unicode message is treated correctly
    record = logging.LogRecord("name", logging.DEBUG, "", 0, "message", (), Exception("\xe4"))  # noqa: E501
    assert lf.format(record) == "message\n    Exception: \xe4"

    # An exception with a non-utf8 message is treated correctly
    record = logging.LogRecord("name", logging.DEBUG, "", 0, "message", (), Exception("Ä"))  #

# Generated at 2022-06-24 08:48:37.344424
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Unit test for method format of class LogFormatter
    # setup
    expected = r"[I 178304 20:57:51 test_log:18] \x1b[2;32mTEST\x1b[0m"
    log_format = "%(color)s%(message)s%(end_color)s"
    record = logging.LogRecord(
        name="test_log",
        level=logging.INFO,
        pathname="test_log.py",
        lineno=18,
        msg="TEST",
        args=None,
        exc_info=None,
    )
    # action
    formatter = LogFormatter(fmt=log_format)
    result = formatter.format(record)
    # assert
    assert result == expected



# Generated at 2022-06-24 08:48:45.703684
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import io
    import sys
    import logging
    import tornado.options
    import tempfile
    import contextlib
    import shutil

    # Construct a logger object to execute function
    class Logger(object):
        def __init__(self):
            self.level = 0
            self.handlers = []

    logger = Logger()

    # Test log_to_stderr is None and logger.handlers is empty
    enable_pretty_logging(options=tornado.options.options, logger=logger)
    try:
        assert len(logger.handlers) == 1
    except AssertionError as e:
        print(e)
        return False
    else:
        logger.handlers = []
        return True

    # Test log_to_stderr is True
    tornado.options.options.log

# Generated at 2022-06-24 08:48:47.465444
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter is not None

# Generated at 2022-06-24 08:48:51.775788
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    gen_log.debug("Test debug logging")
    gen_log.info("Test info logging")
    gen_log.warning("Test warning logging")
    gen_log.error("Test error logging")
    gen_log.critical("Test critical logging")


# Generated at 2022-06-24 08:49:03.674598
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    from tornado.log import app_log, access_log
    # test log_to_stderr option
    options.reset()
    define("log_to_stderr", type=bool)
    enable_pretty_logging()
    assert len(app_log.handlers) == 1
    assert len(access_log.handlers) == 1

    # test log_file_prefix option
    options.reset()
    define("log_file_prefix", type=str)
    enable_pretty_logging()
    assert len(app_log.handlers) == 0
    assert len(access_log.handlers) == 0
    app_log.error("hello world")
    access_log.error("hello world")

    options.reset()

# Generated at 2022-06-24 08:49:06.752956
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    f = LogFormatter()
    assert isinstance(f, LogFormatter)
    assert isinstance(f._fmt, str)
    assert isinstance(f._colors, dict)
    assert isinstance(f._normal, str)
    assert isinstance(f.DEFAULT_FORMAT, str)
    assert isinstance(f.DEFAULT_DATE_FORMAT, str)
    assert isinstance(f.DEFAULT_COLORS, dict)



# Generated at 2022-06-24 08:49:15.740256
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options
    tornado.options.logging = 'debug'
    tornado.options.log_file_prefix = 'D://log.txt'
    tornado.options.log_file_max_size = 10**10
    tornado.options.log_file_num_backups = 1
    tornado.options.log_rotate_when = 'D'
    tornado.options.log_rotate_interval = 1
    tornado.options.log_rotate_mode = 'size'
    tornado.options.log_to_stderr = False
    enable_pretty_logging(tornado.options)

test_enable_pretty_logging()

# Generated at 2022-06-24 08:49:21.426343
# Unit test for function define_logging_options
def test_define_logging_options():
    def parse_tornado_options():
        import tornado.options

        options = tornado.options.options
        define_logging_options(options)
        tornado.options.parse_command_line(['--logging=debug'])
        return options

    options_with_logging_debug = parse_tornado_options()

    assert options_with_logging_debug.logging == "debug"

    options_with_logging_none = parse_tornado_options()

    assert options_with_logging_none.logging == "none"

# Generated at 2022-06-24 08:49:26.144292
# Unit test for function define_logging_options
def test_define_logging_options():
    # late import to prevent cycle
    import tornado.options
    options = tornado.options.options
    define_logging_options()
    tornado.options.parse_config_file('example.conf')
    tornado.options.parse_command_line()
    

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:49:32.851529
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing
    import tornado.log
    test_options = tornado.options.options
    test_logger = tornado.log.app_log

    class TestLogging(tornado.testing.AsyncTestCase):
        def test_enable_pretty_logging(self):
            # test for default option
            self.assertEqual(logging.INFO, tornado.log.app_log.level)
            # test for set option
            test_options.logging = "debug"
            tornado.log.enable_pretty_logging(options=test_options, logger=test_logger)
            self.assertEqual(logging.DEBUG, tornado.log.app_log.level)
            # test for set option
            test_options.logging = "error"
            tornado.log.enable_pretty_

# Generated at 2022-06-24 08:49:44.569760
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options

    class Options(tornado.options.Options):
        def __init__(self):
            self.logging = "none"
            self.log_to_stderr = False
            self.log_file_prefix = "test.log"
            self.log_rotate_mode = "size"
            self.log_rotate_when = "midnight"
            self.log_rotate_interval = 1
            self.log_file_max_size = 100
            self.log_file_num_backups = 30
        def __contains__(self, k):
            return True

    opt = Options()
    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    access_log

# Generated at 2022-06-24 08:49:47.504602
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    from tornado.log import app_log, access_log
    enable_pretty_logging(options, app_log)
    enable_pretty_logging(options, access_log)

# test_enable_pretty_logging()

# Generated at 2022-06-24 08:49:52.278210
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define
    define("A", type=str, default=None)

    define_logging_options()
    # import tornado.options
    # options = tornado.options.options

    # options.parse_command_line(["", "--A", "abcd"])
    # print(options.A)

# Generated at 2022-06-24 08:49:55.059159
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.Logger("TEST", logging.WARNING)
    handler = logging.StreamHandler()
    logger.addHandler(handler)

    # no color
    handler.setFormatter(LogFormatter())
    logger.warning("no color")



# Generated at 2022-06-24 08:50:01.338851
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    ''' Test for LogFormatter Class method for format 
        We are testing the corner cases of this test case.
    '''
    # Testcase 1: If no color support is present.
    logging.Formatter.format(self, record)

    # Testcase 2: If the message is not a string.
    assert isinstance(message, basestring_type)
    
    # Testcase 3: If the message is not a instance of basestring. 
    # Testcase 4: If the exc_text is not present.
    if not record.exc_text:
        record.exc_text = ""
    
    # Testcase 5: If the exc_text is not present.
    if record.exc_text:
        lines = [formatted.rstrip()]

# Generated at 2022-06-24 08:50:11.996182
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import sys
    import time
    import traceback
    import unittest
    import warnings

    from tornado.log import LogFormatter

    class LogFormatterTest(unittest.TestCase):
        def test_format(self):
            formatter = LogFormatter()

            record = logging.makeLogRecord({"msg": "foo"})
            self.assertEqual(formatter.format(record), "foo")

            record = logging.makeLogRecord({"msg": "foo\x00bar"})
            self.assertEqual(formatter.format(record), repr("foo\x00bar"))

            record = logging.makeLogRecord({"msg": "foo\nbar"})
            self.assertEqual(formatter.format(record), "foo\n    bar")


# Generated at 2022-06-24 08:50:12.633568
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:50:23.966156
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # can't test if colorama is not aviable
    if colorama:
        colorama.init()
        # test if colorama is available
        formatter = LogFormatter(color=True)
        assert formatter._normal == "\033[0m"
        assert formatter._colors[logging.DEBUG] == "\033[2;34m"
        # test case when colorama is not available
        formatter = LogFormatter(color=False)
        assert formatter._normal == ""
        assert formatter._colors == {}
        # test other init arguments
        formatter = LogFormatter()

# Generated at 2022-06-24 08:50:25.445069
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf=LogFormatter()
    lf.format()
    return

# Generated at 2022-06-24 08:50:35.652536
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    name = "name"
    levelno = 1
    pathname = "pathname"
    lineno = 1
    msg = "msg"
    args = "args"
    exc_info = "exc_info"
    func = "func"
    sinfo = "sinfo"

    logger = logging.getLogger("tornado.general")
    logger.setLevel(logging.DEBUG)

    handler = logging.StreamHandler()
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.debug(msg, args)
    logger.info(msg, args)
    logger.warning(msg, args)
    logger.error(msg, args)
    logger.critical(msg, args)

test_LogFormatter_format()



# Generated at 2022-06-24 08:50:37.669927
# Unit test for function define_logging_options
def test_define_logging_options():
    options = None  # type: Any
    define_logging_options(options)


# Generated at 2022-06-24 08:50:42.308459
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class TestRecord(object):
        levelno = None
        message =None
        asctime = None
        exc_info = None
        exc_text = None
    log_formatter = LogFormatter()
    TestRecord.levelno = 20
    TestRecord.message = "hello world"
    TestRecord.asctime = ""
    TestRecord.exc_info = None
    TestRecord.exc_text = None
    assert log_formatter.format(TestRecord) == "[I 0000-00-00 00:00:00 :0] hello world"



# Generated at 2022-06-24 08:50:52.727246
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    t = LogFormatter()
    try:
        t.format(logging.LogRecord(
            "name",
            logging.INFO,
            "filename",
            1234,
            "message",
            [],
            None
        ))
    except Exception:
        assert False

    try:
        t.format(logging.LogRecord(
            "name",
            logging.INFO,
            "filename",
            1234,
            {"k", "v"},
            [],
            None
        ))
    except Exception:
        assert True

    t = LogFormatter(color=False)

# Generated at 2022-06-24 08:50:55.851318
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    opts = tornado.options.OptionParser()
    define_logging_options(opts)
    opts.parse_config_file("options_test.conf")

# Generated at 2022-06-24 08:51:06.508183
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        pass
    options = Options()
    options.logging = None
    logger = logging.getLogger()
    enable_pretty_logging(options, logger)
    assert len(logger.handlers) == 0
    options.logging = "none"
    enable_pretty_logging(options, logger)
    assert len(logger.handlers) == 0
    options.logging = "debug"
    options.log_file_prefix = "./test.log"
    options.log_file_max_size = 1024 * 1024 * 1024
    options.log_file_num_backups = 2
    options.log_rotate_mode = "time"
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    enable_pretty_log

# Generated at 2022-06-24 08:51:09.281362
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import app_log
    app_log.warning("test_LogFormatter_format")


# Generated at 2022-06-24 08:51:10.573251
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:51:20.795401
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class TestExceptionLogFormatter(LogFormatter):
        DEFAULT_FORMAT = "%(color)s %(levelname)s: %(message)s"

    def test_format():
        record = logging.makeLogRecord(
            {
                "name": "test_logging",
                "funcName": "test_format",
                "msg": "test %s %d",
                "args": ("foo", "bar"),
                "exc_info": (KeyError, KeyError("key"),
                             None),
            }
        )
        formatter = TestExceptionLogFormatter()
        assert formatter.format(record) == (
            " \x1b[31;01mERROR: test %s %d\n    KeyError: 'key'\x1b[0m"
        )



# Generated at 2022-06-24 08:51:23.552859
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options

    define_logging_options(options)

    # Test the logging options.
    assert options.logging is not None

# Generated at 2022-06-24 08:51:24.868847
# Unit test for function define_logging_options
def test_define_logging_options():
    options = Options()
    define_logging_options(options)
    pass

# Generated at 2022-06-24 08:51:33.722634
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger("tornado.test")
    logger.setLevel(logging.DEBUG)
    stream = logging.StreamHandler()
    formatter = LogFormatter()
    stream.setFormatter(formatter)
    logger.addHandler(stream)

    logger.debug("foo")
    logger.info("foo")
    logger.warning("foo")
    logger.error("foo")
    logger.critical("foo")

    logger.removeHandler(stream)
    stream.close()

if __name__ == '__main__':
  test_LogFormatter()


# Generated at 2022-06-24 08:51:41.869361
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define
    define("log_file_prefix", default="tornado.log")
    define("log_to_stderr", default=False)
    define("log_file_max_size", default=100)
    define("log_file_num_backups", default=10)
    define("log_rotate_mode", default="size")
    define("log_rotate_when", default="midnight")
    define("log_rotate_interval", default=1)
    # Throws exception because of invalid value of log_rotate_mode
    try:
        enable_pretty_logging()
    except ValueError as e:
        assert "value of log_rotate_mode" in str(e)
    # No exception because of valid values of log rotate mode
    # "size"
    enable_

# Generated at 2022-06-24 08:51:45.358590
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.application",
        level=logging.INFO,
        pathname="/path/name",
        lineno=1,
        msg="my message",
        args=(),
        exc_info=None,
    )
    s = formatter.format(record)



# Generated at 2022-06-24 08:51:46.028291
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:51:50.926739
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define("port", default=8888, type=int, help="The port to listen on.")
    tornado.options.parse_command_line(["--port", "8080"])
    define_logging_options()
    assert tornado.options.options.port == 8080

# Generated at 2022-06-24 08:51:56.864513
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.log
    # Clone the options and clear any previous defaults
    options = tornado.options.options.clone()
    options.clear()
    tornado.log.define_logging_options(options)
    options.parse_command_line()
    assert tornado.options.options.log_to_stderr

# Generated at 2022-06-24 08:52:06.027287
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    define("log_file_prefix", None)
    define("log_file_max_size", None)
    define("log_file_num_backups", None)
    define("logging", None)
    define("log_to_stderr", None)
    define("log_rotate_mode", None)
    define("log_rotate_when", None)
    define("log_rotate_interval", None)
    options.log_file_prefix = '/tmp/tornado_tests.log'
    options.log_file_num_backups = 3
    options.logging = 'debug'
    options.log_to_stderr = True
    options.log_rotate_mode = 'size'
    options.log_file_max

# Generated at 2022-06-24 08:52:16.516778
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import tornado.log
    import logging
    import logging.handlers
    tornado.log.LogFormatter()
    logging.getLogger("tornado.application")
    logging.handlers.HTTPHandler(host="127.0.0.1", url="")
    logging.handlers.RotatingFileHandler(filename="", maxBytes=1, backupCount=1)
    logging.handlers.TimedRotatingFileHandler(filename="", when="", interval=1, backupCount=1)
    logging.handlers.WatchedFileHandler(filename="")
    logging.handlers.BufferingHandler(capacity=1)

# Make '_' a no-op so we can scrape strings
_ = lambda x: x



# Generated at 2022-06-24 08:52:27.480894
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test a basic call with no options
    format_args: Any = None
    def _fake_get_logger(name):
        # Ensure that logging was configured correctly.
        assert name == "tornado.access"
        logger = MagicMock()
        format_args[0] = logger.setLevel.call_args[0][0]
        format_args[1] = logger.addHandler.call_args[0][0].formatter
        logger.setLevel.return_value = None
        logger.addHandler.return_value = None
        return logger
    orig_get_logger = logging.getLogger
    format_args = [None, None]  # type: Any
    logging.getLogger = _fake_get_logger

# Generated at 2022-06-24 08:52:39.619701
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.testing
    import functools
    import json
    import logging
    import os
    import unittest
    import urllib.parse
    import warnings

    logger = logging.getLogger()
    logging.getLogger('tornado').setLevel(logging.CRITICAL)

    # NOTE: This is a different file than the one used in the
    # test_logging_options unit test, so we don't have to futz
    # with the log_file_prefix, log_file_max_size,
    # and log_file_num_backups options.
    config_file = __file__.replace(".pyc", ".py")


# Generated at 2022-06-24 08:52:46.686133
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import pytest
    from pytest import raises
    from logging import INFO
    with raises(ValueError):
        LogFormatter(style="%w")
    LogFormatter(color=False)
    LogFormatter(color=True)
    LogFormatter(color=True, colors={INFO: 10})
    LogFormatter(color=True, colors={INFO: 10, logging.DEBUG: 11})
    LogFormatter(color=True, colors={INFO: 10, logging.DEBUG: 11, logging.ERROR: 12})
    LogFormatter(color=True, colors={INFO: 10, logging.DEBUG: 11, logging.ERROR: 12, logging.CRITICAL: 13})
    for style in ["%", "{", "["]:
        LogFormatter(style=style, color=False)
        LogFormatter(style=style, color=True)

# Generated at 2022-06-24 08:52:59.059991
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.Logger(__name__)
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = LogFormatter()
    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_LogFormatter_format()
    print('test of %s DONE' % __file__)

# Generated at 2022-06-24 08:53:00.696388
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

test_enable_pretty_logging()

# Generated at 2022-06-24 08:53:10.138177
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.DEBUG, "/home/azhang/projects/blog-tornado/tornado/log.py", 100, "", "", "")
    record.asctime = "20180910 00:00:00"
    record.color = ""
    record.end_color = ""
    record.exc_info = None
    record.exc_text = ""
    record.filename = ""
    record.funcName = "test_LogFormatter_format"
    record.getMessage()
    record.levelname = "DEBUG"
    record.levelno = logging.DEBUG
    record.lineno = 100
    record.module = "tornado.log"
    record.msecs = "00"
    record.msg = ""

# Generated at 2022-06-24 08:53:15.342569
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT
    assert LogFormatter().datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert LogFormatter(datefmt='%Y').datefmt == '%Y'



# Generated at 2022-06-24 08:53:21.313196
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    :return:
    """
    assert LogFormatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert LogFormatter._colors == {}



# Generated at 2022-06-24 08:53:23.191499
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None)
    enable_pretty_logging(None, None)

# Generated at 2022-06-24 08:53:24.677298
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()