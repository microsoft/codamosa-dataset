

# Generated at 2022-06-24 08:43:33.039254
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line

    define("logging", default="debug")
    define("log_file_prefix", default="")
    define("log_rotate_mode", default="size")
    define("log_file_max_size", default=1024)
    define("log_file_num_backups", default=0)
    define("log_rotate_when", default="")
    define("log_rotate_interval", default=0)
    define("log_to_stderr", default=True)

    parse_command_line()
    enable_pretty_logging()
    print("test")

# Generated at 2022-06-24 08:43:33.937626
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-24 08:43:45.204902
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    # define log-levels and colors
    logging.CRITICAL = 50
    logging.ERROR = 40
    logging.WARNING = 30
    logging.INFO = 20
    logging.DEBUG = 10
    logging.NOTSET = 0

    # define strings to log
    error_string = 'error_string'
    warning_string = 'warning_string'
    info_string = 'info_string'
    debug_string = 'debug_string'
    critical_string = 'critical_string'
    date_string = "date_string"

    # set colorama to false
    color = False

    # Create a fake LogFormatter
    formatter = LogFormatter(color=color)
    print("color: " + str(color))

    # Define a fake record

# Generated at 2022-06-24 08:43:45.785359
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    ...


# Generated at 2022-06-24 08:43:50.281198
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    obj = LogFormatter()
    assert obj._fmt == LogFormatter.DEFAULT_FORMAT
    assert obj.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert obj._colors == LogFormatter.DEFAULT_COLORS
    assert obj._normal

    obj = LogFormatter(fmt='%(color)s%(message)s%(end_color)s')
    assert obj._fmt == '%(color)s%(message)s%(end_color)s'

    obj = LogFormatter(colors={logging.DEBUG: 1})
    assert obj._colors == {logging.DEBUG: 1}


# Generated at 2022-06-24 08:43:51.932019
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
  logf = LogFormatter()
  record = logging.LogRecord('name', logging.DEBUG, 'pathname', 0, 'msg', (), None, None)
  ret = logf.format(record)
  pass

# Generated at 2022-06-24 08:43:56.302978
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """
    >>> formatter = LogFormatter()
    >>> formatter.format(1)

    """



# Generated at 2022-06-24 08:44:00.075754
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("name", logging.DEBUG, "filename", 0, "msg", None, None)
    assert formatter.format(record) == "[D %(asctime)s filename:0] %(message)s"

# Generated at 2022-06-24 08:44:03.533501
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf is not None

LogFormatter.test = test_LogFormatter


# Generated at 2022-06-24 08:44:07.407128
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    lf = LogFormatter(color=True)
    assert isinstance(lf, LogFormatter)
    lf = LogFormatter(color=False)
    assert isinstance(lf, LogFormatter)
    lf = LogFormatter()
    assert isinstance(lf, LogFormatter)



# Generated at 2022-06-24 08:44:16.168566
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
        ),
    )
    tornado.options.options.logging = "info"
    define_logging_options(tornado.options.options)
    assert tornado.options.options.logging == "info"
    assert tornado.options.options.log_to_stderr is None
    assert tornado.options.options.log_file_prefix is None
    assert tornado.options.options.log_file_max_size == 100 * 1000 * 1000
    assert tornado.options.options.log_file_num_backups == 10
    assert tornado.options.options.log_rotate_when == "midnight"

# Generated at 2022-06-24 08:44:27.927739
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #
    # Configuration
    #
    from io import StringIO
    import logging.handlers
    import tornado.log
    import tornado.options
    import sys


    # Encoding for bytes
    ENCODING = "utf-8"

    #
    # Test data
    #
    # Test strings
    STR_TEST = "Test"
    STR_TEST_TO_REPR = "Test\N{LATIN SMALL LETTER A WITH ACUTE}"
    STR_TEST_ENCODED = STR_TEST.encode(ENCODING)
    STR_TEST_TO_REPR_ENCODED = STR_TEST_TO_REPR.encode(ENCODING)
    # Test bytes
    BYTES_TEST = b"Test"
    BYTES_TEST_TO_

# Generated at 2022-06-24 08:44:38.352482
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import tornado.options
    import unittest.mock

    fmt = tornado.options.options.log_format
    datefmt = tornado.options.options.log_date_format

    class FakeHandle:
        def isatty(self) -> bool:
            return True

    formatter = LogFormatter(fmt, datefmt)
    assert isinstance(formatter, LogFormatter)

    msg = "Fake message"
    record = logging.makeLogRecord({"msg": msg})
    formatted = formatter.format(record)
    assert msg == formatted
    assert msg not in formatted, "Extra newline appended"

    fake_stdout = unittest.mock.Mock()
    # type: ignore
    sys.stdout = fake_stdout

# Generated at 2022-06-24 08:44:44.824295
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    m = LogFormatter()
    record = logging.LogRecord('name', logging.INFO, 'pathname', 0, 'msg', None, None)
    assert m.format(record) == '[I %(asctime)s pathname:0] msg'

# Generated at 2022-06-24 08:44:50.679098
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord('tornado.application', logging.DEBUG, '', 0, 'tornado.application Instance created at', None, None))
    formatter.format(logging.LogRecord('tornado.application', logging.DEBUG, '', 0, 'tornado.application Application has been initialized', None, None))



# Generated at 2022-06-24 08:44:57.687031
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert True == True # for pytest
    import logging
    import logging.handlers
    logger = logging.getLogger('tornado.access')
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    # create formatter
    formatter = LogFormatter()
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)
    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-24 08:45:01.335458
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import os
    logging.warning("test warning")
    # TODO: implement a function that cleans up the files by itself.
    os.remove("test_logs/tornado.test.test_log.test_enable_pretty_logging")
    print("test finished")


test_enable_pretty_logging()

# Generated at 2022-06-24 08:45:04.879441
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    record = logging.LogRecord("tornado.general", 20, "foo.py", 10, "bar",
                               ("baz",), None)
    record.time = 12345
    rec = f.format(record)
    assert rec == "[I 121019 00:00:12 foo:10] bar"


# Generated at 2022-06-24 08:45:06.309504
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert logging
    assert logging.handlers
    assert sys
    assert sys.stderr

# Generated at 2022-06-24 08:45:10.029329
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(None, None, None, None, None, {}, None)
    formatter.format(record)


# Generated at 2022-06-24 08:45:16.209425
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(color=False)

# Convert a logging level name to a number
_level_names = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
}


# Generated at 2022-06-24 08:45:21.229477
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define_logging_options(options)
    print(options._options)
    for name, value in options._options.items():
        print(name)
        print(value)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:45:22.022651
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert True

# Generated at 2022-06-24 08:45:30.468636
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    datetime.datetime.now()
    datetime.datetime.now().strftime('%H:%M:%S')
    fmt = logging.Formatter(format='%(asctime)s %(levelname)s %(message)s',
                            datefmt='%H:%M:%S')
    fmt.format(logging.LogRecord(name = 'test',
                                 level = logging.DEBUG,
                                 pathname = 'pathname',
                                 lineno = 1,
                                 msg = 'msg',
                                 args = (),
                                 exc_info = None))


# Generated at 2022-06-24 08:45:31.217705
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
  LogFormatter()


# Generated at 2022-06-24 08:45:40.713210
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Unit test for function enable_pretty_logging
    # TODO: need more test cases
    options = {}
    options["logging"] = "none"
    options["log_to_stderr"] = 0
    options["log_file_prefix"] = 0
    options["log_rotate_mode"] = 0
    options["log_file_max_size"] = 0
    options["log_file_num_backups"] = 0
    options["log_rotate_when"] = 0
    options["log_rotate_interval"] = 0
    enable_pretty_logging(options)



# Generated at 2022-06-24 08:45:49.588196
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define("logging", default="info",
                           help="Set the Python log level. If 'none', "
                                "tornado won't touch the logging configuration.",
                           metavar="debug|info|warning|error|none")
    tornado.options.define("log_to_stderr", type=bool, default=None,
                           help="Send log output to stderr (colorized if possible). "
                                "By default use stderr if --log_file_prefix is not set "
                                "and no other logging is configured.")

# Generated at 2022-06-24 08:45:55.573290
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    define("logging", default=None, help="logging level", type=str)
    define("log_file_prefix", default=None, help="log file prefix", type=str)
    define("log_file_max_size", default=100, help="log file max size", type=int)
    define("log_file_num_backups", default=10, help="log file num backups", type=int)
    define("log_rotate_mode", default="size", help="log rotate mode", type=str)
    define("log_rotate_when", default="D", help="log rotate when", type=str)
    define("log_rotate_interval", default=1, help="log rotate interval", type=int)

# Generated at 2022-06-24 08:45:57.794544
# Unit test for function define_logging_options
def test_define_logging_options():
    test_options = tornado.options.OptionParser()
    define_logging_options(test_options)
    print(test_options)


# Generated at 2022-06-24 08:46:10.586045
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        logging = "none"
        log_file_prefix = ""
        log_rotate_mode = "time"
        log_rotate_when = "D"
        log_rotate_interval = 1
        log_file_num_backups = 0
        log_to_stderr = None

    # test for no log file
    try:
        enable_pretty_logging(Options)
        assert False, "No exception was thrown"
    except ValueError:
        pass

    # test for no log file
    try:
        options = Options()
        options.log_file_prefix = "test"
        enable_pretty_logging(options)
        assert False, "No exception was thrown"
    except ValueError:
        pass

    # test for no log file

# Generated at 2022-06-24 08:46:11.340486
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert isinstance(f, logging.Formatter)

# Generated at 2022-06-24 08:46:15.427005
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Tests for method format (self, record: Any) -> str
    import unittest.mock
    record = unittest.mock.MagicMock()
    record.levelno = logging.DEBUG
    formatter = logging.Formatter()
    assert(formatter.format(record) == 'Unknown process-0 [DEBUG]')



# Generated at 2022-06-24 08:46:16.277248
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()



# Generated at 2022-06-24 08:46:17.140314
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()


# Generated at 2022-06-24 08:46:23.229213
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import datetime
    from tornado.log import gen_log

    class Record(object):
        levelno = logging.INFO
        name = "tornado.general"
        message = "foo"
        asctime = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

    if not _stderr_supports_color():
        Record.color = Record.end_color = ""
    else:
        Record.color = "\033[2;32m"
        Record.end_color = "\033[0m"

    lf = LogFormatter()
    gen_log.info("foo")
    assert lf.format(Record()).endswith("foo")

# Generated at 2022-06-24 08:46:27.677166
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass
    # formatter = LogFormatter()
    # message = "Test logging message"
    # record = logging.LogRecord("test", levelno=logging.DEBUG,
    #                            pathname="/path/to/module.py",
    #                            lineno=123, msg=message,
    #                            args=None, exc_info=None)
    # assert formatter.format(record) == "[D 20131124 13:30:14 /path/to/module.py:123] Test logging message"  # noqa: E501
    # record.exc_info = True
    # assert formatter.format(record) == "[D 20131124 13:30:14 /path/to/module.py:123] Test logging message\n    Traceback (most recent call last):\n    ValueError: 123"  # no

# Generated at 2022-06-24 08:46:30.685922
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        formatter = LogFormatter(datefmt='%Y-%m-%d')
        print(formatter)
        assert formatter
    except Exception as e:
        print(e)



# Generated at 2022-06-24 08:46:40.162532
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert isinstance(lf, logging.Formatter)  # Assert that LogFormatter is a subclass of logging.Formatter


# Table mapping logging levels to colors as foreground + background
# combinations.
COLORS = {
    logging.DEBUG: '\033[00;33m',  # bright yellow
    logging.INFO: '\033[00;32m',  # green
    logging.WARNING: '\033[01;33m',  # bright yellow
    logging.ERROR: '\033[01;31m',  # bright red
    logging.CRITICAL: '\033[07;31m',  # white on red bg
}



# Generated at 2022-06-24 08:46:42.468564
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    record = logging.LogRecord(
        'tornado.access', logging.WARNING, 'foo.py', 123, 'message',
        None, None
    )
    assert f.format(record) == '[W 123 foo.py:123] message'



# Generated at 2022-06-24 08:46:53.217449
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    assert(options.logging == "info")
    assert(options.log_to_stderr == None)
    assert(options.log_file_prefix == None)
    assert(options.log_file_max_size == 100000000)
    assert(options.log_file_num_backups == 10)
    assert(options.log_rotate_when == "midnight")
    assert(options.log_rotate_interval == 1)
    assert(options.log_rotate_mode == "size")
    assert(options.add_parse_callback(lambda: enable_pretty_logging(options)) == None)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:46:55.954934
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_to_stderr = True
    enable_pretty_logging(options)
    options.log_to_stderr = False
    enable_pretty_logging(options)



# Generated at 2022-06-24 08:47:06.206945
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = "10"
    tornado.options.options.log_file_num_backups = "3"
    tornado.options.options.log_to_stderr = "True"
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    tornado.log.app_log.debug("app_log: debug")
    tornado.log.app_log.info("app_log: info")
    tornado.log.app_log.warning("app_log: warning")
    tornado.log.app_log.error("app_log: error")

# Generated at 2022-06-24 08:47:16.349143
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import time
    import logging
    import tornado
    import tornado.options

    class MyStderrHandler(logging.StreamHandler):

        def __init__(self):
            logging.StreamHandler.__init__(self)
            self.msgs = []

        def emit(self, record):
            self.msgs.append(record.msg)

    handler = MyStderrHandler()
    logger = logging.getLogger("tornado.test")
    logger.addHandler(handler)
    logger.setLevel(tornado.options.options.logging)
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    # Test LogFormatter with logging.ERROR level
    options = tornado.options.options
    options.logging = "error"
    tornado.options.enable_pretty

# Generated at 2022-06-24 08:47:18.405501
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

if __name__ == "__main__":
    enable_pretty_logging()

# Generated at 2022-06-24 08:47:29.307917
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("log_rotate_mode", default="time")
    define("log_rotate_interval", default=1)
    define("log_rotate_when", default="midnight")
    define("log_file_num_backups", default=10)
    define("log_file_max_size", default=100)
    define("log_file_prefix", default=None)
    define("log_to_stderr", default=None)
    define("logging", default="none")
    define_logging_options()
    options.parse_command_line()

if __name__ == "__main__":
    test_define_logging_options()
    print(options.logging)
    print(options.log_to_stderr)

# Generated at 2022-06-24 08:47:42.184204
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class MyOptions:
        log_file_max_size = 1
        log_file_num_backups = 1
        log_file_prefix = "test"
    myoptions = MyOptions()

    my_log_formatter = LogFormatter()
    assert my_log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert my_log_formatter._colors == LogFormatter.DEFAULT_COLORS


# Generated at 2022-06-24 08:47:45.380283
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """Test for LogFormatter constructor."""
    LogFormatter()



# Generated at 2022-06-24 08:47:53.279147
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    assert options.logging=='info'
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups==10
    assert options.log_rotate_when == 'midnight'
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == 'size'

# Generated at 2022-06-24 08:47:55.300474
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.Formatter.__init__
    LogFormatter()
    LogFormatter(color=True)
    LogFormatter(colors={})



# Generated at 2022-06-24 08:47:58.640435
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()
    enable_pretty_logging(logger=None)

# Generated at 2022-06-24 08:48:00.662597
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        x = LogFormatter()
    except:
        pass

# Generated at 2022-06-24 08:48:02.266298
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    enable_pretty_logging()

# Generated at 2022-06-24 08:48:11.740315
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Record(object):
        pass

    msg = "something"

    record = Record()
    record.__dict__["message"] = msg
    record.__dict__["asctime"] = ""
    record.__dict__["levelno"] = 1
    record.__dict__["levelname"] = ""
    record.__dict__["module"] = ""
    record.__dict__["lineno"] = 0

    formatter = LogFormatter()
    assert formatter.format(record) == msg

    record.__dict__["levelno"] = 2
    assert formatter.format(record) != msg

# Generated at 2022-06-24 08:48:22.869491
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    # Test `formatter.format`
    record = logging.makeLogRecord({"msg": "hello world"})
    assert formatter.format(record) == "[I 20000101 00:00:00 00:00:00] hello world"
    record = logging.makeLogRecord({"msg": "\ngoodbye world\n"})
    assert formatter.format(record) == "[I 20000101 00:00:00 00:00:00] \n    goodbye world\n"
    record = logging.makeLogRecord({"msg": "hello world", "exc_info": True})
    assert formatter.format(record) == "[I 20000101 00:00:00 00:00:00] hello world"

# Generated at 2022-06-24 08:48:34.229336
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
   import tornado.options
   options = tornado.options.options
   #enable_pretty_logging(options)
   print(options.logging)
   print(options.log_file_prefix)
   print(options.log_rotate_mode)
   print(options.log_file_max_size)
   print(options.log_file_num_backups)
   print(options.log_rotate_when)
   print(options.log_rotate_interval)
   print(options.log_to_stderr)
   enable_pretty_logging(options)


#def main():
    #test_enable_pretty_logging()


#if __name__ == '__main__':
   # test_enable_pretty_logging()

# Generated at 2022-06-24 08:48:38.664649
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501



# Generated at 2022-06-24 08:48:39.944864
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)


# Generated at 2022-06-24 08:48:48.510737
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from io import StringIO

    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(LogFormatter())
    test_msg = 'this is a test'
    gen_log.addHandler(handler)
    gen_log.error(test_msg)
    handler.flush()
    stream.flush()
    stream.seek(0)
    assert stream.read() == "E %s\n" % test_msg


# Generated at 2022-06-24 08:48:49.532504
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
test_LogFormatter()



# Generated at 2022-06-24 08:48:53.876179
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = app_log
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    LOG_FORMAT = '%(asctime)s %(levelname)s %(message)s'
    formatter = LogFormatter(fmt=LOG_FORMAT, datefmt='%m/%d/%Y %I:%M:%S %p')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')

# Generated at 2022-06-24 08:49:05.473134
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("debug", default=True, help="enable debug mode")
    define("port", default=8888, help="run on the given port", type=int)
    define("logging", type=str, default="info")
    define("log_file_prefix", default='/var/log/tornado.log')
    define("log_to_stderr", default=True)
    define("log_file_max_size", default=100 * 1000 * 1000)
    define("log_file_num_backups", default=10)
    define("log_rotate_when", default='midnight')
    define("log_rotate_interval", default=1)
    define("log_rotate_mode", default="size")
    parse_command_line()

# Generated at 2022-06-24 08:49:09.350061
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import sys

    tornado.options.enable_pretty_logging(options=tornado.options.options)
    print(sys.stdout.isatty())

# Generated at 2022-06-24 08:49:19.100526
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options

    op = OptionParser()
    define_logging_options(options=op)

    args = [
        "--logging=DEBUG", "--log_to_stderr=True", "--log_file_prefix=/tmp/logging.log",
        "--log_file_max_size=10000000", "--log_file_num_backups=10",
        "--log_rotate_when=midnight", "--log_rotate_interval=1",
        "--log_rotate_mode=size",
    ]
    op.parse_args(args=args)
    assert options.logging == "DEBUG"
    assert options.log_to_stderr is True
    assert options.log_file_prefix == "/tmp/logging.log"
   

# Generated at 2022-06-24 08:49:26.126836
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)
    options = parser.parse_args()
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100000000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

# Generated at 2022-06-24 08:49:32.825980
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.log.enable_pretty_logging(options=tornado.options.options)

    tornado.options.options.parse_command_line()

    # 如果不指定options的话, 会使用默认的选项
    # 如果指定了options, 却不指定logging选项, 会使用默认的logging选项
    tornado.log.enable_pretty_logging()

    # 如果指定了options, 可以通过配置logging来覆盖默

# Generated at 2022-06-24 08:49:34.517911
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        enable_pretty_logging()
    except Exception as e:
        msg = "function enable_pretty_logging failed with exception: %s" % e
        raise ValueError(msg)

# Generated at 2022-06-24 08:49:42.909422
# Unit test for function define_logging_options
def test_define_logging_options():
    """testing function define_logging_options"""
    # Test cases
    # test case 1:
    # define_logging_options()

    # test case 2:
    # define_logging_options(options = None)
    # test case 3:
    # define_logging_options(options = None, logger = None)

    # test case 4:
    # define_logging_options(options = None, logger = logging.getLogger())

    # test case 5:
    # options = tornado.options
    # define_logging_options(options)
    pass

# Generated at 2022-06-24 08:49:48.754839
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger("test.logging")
    logger.setLevel(logging.DEBUG)
    result = LogFormatter().format(logging.LogRecord(
        "test.logging", logging.DEBUG, "/home/user/test.txt", 13, "message", None, None))
    assert result.strip() == "[D 131212 09:34:31 test:13] message"
    # Unit test for method _stderr_supports_color of class LogFormatter

# Generated at 2022-06-24 08:49:57.548744
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    import unittest
    import logging

    class MyTest(unittest.TestCase):
        def _test(self, methods, expected, *args):
            for method in methods:
                result = method(*args)
                self.assertEqual(result, expected)

        def test_LogFormatter_format(self):
            # I tested this on Windows and Linux.
            log_stream = io.StringIO()
            handler = logging.StreamHandler(log_stream)

            # test default formatter
            log_record = logging.LogRecord(
                name="test", level=logging.DEBUG, pathname="test", lineno=0, msg="test", args=[], exc_info=None
            )
            handler.handle(log_record)
            self.assertIn("[DEBUG", log_stream.getvalue())

# Generated at 2022-06-24 08:49:59.696858
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    t = formatter.format()
    assert t == None


# Generated at 2022-06-24 08:50:10.657415
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    def check_format(fmt: str, expected: str) -> Optional[str]:
        try:
            LogFormatter(fmt)
        except Exception as e:
            return str(e)
        else:
            return None

    assert check_format("%(message)", "%(message)") is None
    assert check_format("%(asctime)", "%(asctime)") is None
    assert check_format("%(message)s", None) == '%(message)s must be an integer.  Did you intend to use %(message)?'  # noqa: E501
    assert check_format("%(foo)s", "%(foo)s") is None
    assert check_format("%(message", None) == 'Unmatched %( in format %(message'

# Generated at 2022-06-24 08:50:14.906288
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # unit test for method format of class LogFormatter
    logger = logging.getLogger("tornado.general")
    logger.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    logger.addHandler(logging.StreamHandler(strm=sys.stdout))
    logger.info("test")


# Generated at 2022-06-24 08:50:17.466760
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    print(formatter)


# Define a context-aware Formatter class that can be used in a "with"
# statement.  Only the "with" block will be sent to stderr.  Without the
# context, the stderr handler is not removed, but it is a no-op.

# Generated at 2022-06-24 08:50:19.932134
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options = tornado.options.parse_command_line()
    enable_pretty_logging()

# Generated at 2022-06-24 08:50:31.319123
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.log
    import os

    tornado.options.options.logging='info'
    tornado.options.options.log_to_stderr=True
    tornado.options.options.log_file_prefix='/tmp/log'
    tornado.options.options.log_file_max_size=1000000
    tornado.options.options.log_file_num_backups=1
    tornado.options.options.log_rotate_when='s'
    tornado.options.options.log_rotate_interval=1
    tornado.options.options.log_rotate_mode='size'
    tornado.log.define_logging_options(tornado.options.options)
    tornado.log.enable_pretty_logging(options = tornado.options.options)
    gen_log.warning

# Generated at 2022-06-24 08:50:33.605238
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_command_line(['-logging=debug'])
    enable_pretty_logging()
    app_log.debug('hello')


__all__ = ["app_log", "gen_log", "access_log", "enable_pretty_logging"]

# Generated at 2022-06-24 08:50:36.346436
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line(args = ['--logging=debug'])
    assert(options.logging =="debug")

# Generated at 2022-06-24 08:50:41.541659
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_file_prefix = "log_file_prefix"
    options.logging = "debug"
    enable_pretty_logging(options)
    assert(options.log_file_prefix == "log_file_prefix")

# Generated at 2022-06-24 08:50:46.204501
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = tornado.log.gen_log.handlers.formatters
    try:
        fmt['tornado']
    except KeyError:
        pass
    logger = logging.getLogger('tornado')
    logger.debug('hello')
    logger.info('hello')
    logger.warning('hello')
    logger.error('hello')
    logger.critical('hello')

# Generated at 2022-06-24 08:50:52.914056
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Basically, we want to make sure that LogFormatter does something with
    # exc_info and exc_text, even if it doesn't have color support.
    class Record(object):
        exc_info = (None, None, None)
        exc_text = None
        levelno = logging.INFO
        message = "hello"
        __dict__ = {}  # required for format()

    formatter = LogFormatter()
    assert "hello" in formatter.format(Record())
    Record.exc_info = None
    Record.exc_text = "foo\nbar"
    assert "bar" in formatter.format(Record())



# Generated at 2022-06-24 08:50:55.119729
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    from tornado.log import access_log, app_log, gen_log
    logger = LogFormatter()
    logger.format(access_log)
    logger.format(app_log)
    logger.format(gen_log)
    


# Generated at 2022-06-24 08:51:05.726070
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    class Record(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs
    record = Record(args=[], exc_info=None, exc_text=None, filename='test_logging.py', funcName='test_LogFormatter_format',
                    levelname='INFO', lineno=306, module='test_logging', msg='', name='tornado.general', pathname='test_logging.py', process=14208,
                    processName='MainProcess', relativeCreated=173.96371030807495, msecs=963.7103080749512, msg='test_LogFormatter_format')
    f.format(record)


# Generated at 2022-06-24 08:51:10.628928
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """test enable_pretty_logging() function above.
    """

    # TODO: run tornado.options.parse_command_line() with mock command line
    # arguments, then check the output.

    return


# Generated at 2022-06-24 08:51:14.093632
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    logging.error("test_enable_pretty_logging")

# Generated at 2022-06-24 08:51:24.466162
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test different logging options
    options = dict()
    options['log_file_prefix'] = 'C:/test/test.log'
    options['log_rotate_mode'] = 'size'
    options['log_file_max_size'] = 2**20
    options['log_file_num_backups'] = 1
    options['log_rotate_when'] = 'S'
    options['log_rotate_interval'] = 1
    options['log_to_stderr'] = None
    enable_pretty_logging(options)

    options['log_file_prefix'] = ''
    options['log_rotate_mode'] = 'time'
    options['log_file_max_size'] = 2**20
    options['log_file_num_backups'] = 1

# Generated at 2022-06-24 08:51:29.234624
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()
    assert LogFormatter("")
    assert LogFormatter("", "")
    assert LogFormatter("", "", "")
    assert LogFormatter("", "", "", True)
    assert LogFormatter("", "", "", True, {})

test_LogFormatter()



# Generated at 2022-06-24 08:51:39.708287
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.log
    import tornado.options
    import logging
    import logging.handlers
    options = tornado.options.OptionParser()
    tornado.log.define_logging_options(options)
    options.parse_command_line('')
    logger = logging.getLogger()
    assert options.log_file_prefix == None
    assert options.log_to_stderr == None
    tornado.log.enable_pretty_logging(options, logger)
    assert isinstance(logger.handlers[0], logging.StreamHandler)
    options.parse_config_file("test.conf")
    assert options.log_file_prefix == "log/tutorial.log"
    assert options.log_to_stderr == "False"
    assert options.log_file_max_size == 10 * 1000 * 1000

# Generated at 2022-06-24 08:51:49.929868
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from typing import Dict, Union, Any
    # type:  Dict[Union[str, Any], Any]
    fake_record = {
        "exc_info": None,
        "exc_text": None,
        "levelno": 30,
        "message": "Bad message",
        "name": "tornado.test.test_log.test_LogFormatter",
    }

    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"

# Generated at 2022-06-24 08:52:01.935523
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.options

    # 1. Reset the flag
    options.reset()

    define_logging_options(options)
    # 2. Test the parameter value
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_mode == "size"
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1

    # 3. Init the paramter value
    options.logging = "debug"
    options.log_to_stderr = True
    options

# Generated at 2022-06-24 08:52:05.408268
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.options.reset()
    define_logging_options()
    tornado.options.parse_command_line(["--logging=debug"])
    assert options.logging == "debug"


# Generated at 2022-06-24 08:52:16.930485
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger('test_logger')
    logger.setLevel('INFO')

    # Check that our custom log formatter is acceptable to logging.config.dictConfig
    class DummyLoggerHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            self.logs = []  # type: List[str]
            logging.Handler.__init__(self, *args, **kwargs)
        def emit(self, record):
            self.logs.append(record.msg)

    h = DummyLoggerHandler()
    f = LogFormatter()
    h.setFormatter(f)
    logger.addHandler(h)
    logger.warn('test_message')

    assert h.logs == ['test_message']


# Generated at 2022-06-24 08:52:27.901603
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    class LogFormatterWrapper:

        def __init__(self, **kwargs):
            log_formatter = LogFormatter(**kwargs)
            # These are the instance variables that the tornado.log module
            # expects to find on its LogFormatter
            self._fmt = log_formatter._fmt
            self._colors = log_formatter._colors
            self._normal = log_formatter._normal
            # This is a method that the logging module calls
            self.format = log_formatter.format

    # Test LogFormatter's constructor given the parameters that the
    # configuration methods in the tornado.options module put in.
    log_formatter = LogFormatterWrapper(color=True)
    assert len(log_formatter._colors) > 0


# Generated at 2022-06-24 08:52:39.740704
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    from tornado.log import app_log, gen_log
    tornado.options.enable_pretty_logging(options=None)
    assert app_log.level == logging.INFO
    assert gen_log.level == logging.INFO

    tornado.options.enable_pretty_logging(options=None, logger=gen_log)
    assert app_log.level == logging.INFO
    assert gen_log.level == logging.INFO

    app_log.setLevel(logging.ERROR)
    gen_log.setLevel(logging.ERROR)

    tornado.options.enable_pretty_logging(options=None)
    assert app_log.level == logging.INFO
    assert gen_log.level == logging.INFO

    app_log.setLevel(logging.ERROR)
    gen_log

# Generated at 2022-06-24 08:52:46.783851
# Unit test for function define_logging_options
def test_define_logging_options():
    # see: https://pymotw.com/2/unittest/index.html#module-unittest
    from tornado.options import define, options
    from tornado.testing import AsyncTestCase, gen_test

    import unittest
    import os

    class TestLogConfig(AsyncTestCase):
        @gen_test
        async def test_init_options(self):
            (define_logging_options(options))

            self.assertEqual(options.logging, "info")
            self.assertEqual(options.log_to_stderr, None)
            self.assertEqual(options.log_file_prefix, None)
            self.assertEqual(options.log_file_max_size, 100 * 1000 * 1000)

# Generated at 2022-06-24 08:52:50.248559
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None)

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:53:01.623281
# Unit test for function define_logging_options
def test_define_logging_options():
    options = None
    log_rotate_when = "W2"
    log_rotate_interval = 3
    log_to_stderr = False
    options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    options.define(
        "log_to_stderr",
        type=bool,
        default=None,
        help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."
        ),
    )

# Generated at 2022-06-24 08:53:10.625491
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.logging = 'none'
    enable_pretty_logging()
    options.logging = 'debug'
    options.log_file_prefix = './test.log'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 5
    options.log_file_num_backups = 2
    options.log_rotate_when = 'midnight'
    options.log_rotate_interval = 0
    options.log_to_stderr = False
    enable_pretty_logging()
    options.log_to_stderr = True
    enable_pretty_logging()
    options.logging = 'none'
    options.log_file_prefix = None
    options.log_rotate_mode = None


# Generated at 2022-06-24 08:53:14.835082
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    assert logger is not None, "Logger is none"
    enable_pretty_logging(None, logger)
    assert logger.handlers is not None, "Logger has no handlers"

# Generated at 2022-06-24 08:53:24.782036
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, OptionParser
    import sys

    parser = OptionParser()
    define_logging_options(options)

    sys.argv = [sys.argv[0], "--logging=debug", '--log_file_prefix=./test',
                '--log_file_max_size=1000', '--log_file_num_backups=3',
                '--log_to_stderr=false']
    parser.parse_command_line()
    enable_pretty_logging(options)
    gen_log.info('test_define_logging_options')