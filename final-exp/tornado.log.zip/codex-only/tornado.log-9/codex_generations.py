

# Generated at 2022-06-24 08:43:31.329163
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_config_file("test/command_line_option_test.conf")
    assert options.log_rotate_mode == "size"
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_file_prefix == "log/tornado.log"
    assert options.log_file_max_size == 1024
    assert options.log_file_num_backups == 100

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:43:36.499486
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options

    options.logging = "debug"
    options.log_rotate_mode = "size"
    options.log_file_prefix = "D:\\test.txt"
    options.log_file_max_size = 10
    options.log_file_num_backups = 3
    options.log_to_stderr = False

    enable_pretty_logging(options)



# Generated at 2022-06-24 08:43:46.079780
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    args = [
        '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s'
        ' %(message)s',
        '%y%m%d %H:%M:%S',
        '%',
        True,
        {logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
        }
    ]
    LogFormatter(*args)



# Generated at 2022-06-24 08:43:57.270011
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class MockLogRecord(object):
        def __init__(self):
            self.msg = []
        def getMessage(self) -> Any:
            return self.msg
        def __setitem__(self, key: str, value: Any) -> Any:
            self.msg.append(key+":"+value)
        def __getitem__(self, key: str) -> Any:
            return self.msg
        def __contains__(self, item: Any) -> Any:
            return item in self.msg

    # Test case 1: empty message
    record = MockLogRecord()
    log_fmt = LogFormatter("test")
    log_fmt.format(record)
    assert record["getMessage"] == "[]"

    # Test case 2: normal message
    record = MockLogRecord()

# Generated at 2022-06-24 08:44:03.114660
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log = logging.getLogger("test")
    log.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    log.addHandler(handler)
    f = LogFormatter(fmt="%(message)s")
    handler.setFormatter(f)
    log.info("1")



# Generated at 2022-06-24 08:44:10.633593
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                        datefmt='%a, %d %b %Y %H:%M:%S',
                        filename='/tmp/myapp.log',
                        filemode='a+')
    import tornado.options

    tornado.options.define("log_file_prefix", default="/tmp/log_file_prefix.txt")
    tornado.options.define("logging", default="info")
    tornado.options.define("log_file_max_size", default=10)
    tornado.options.define("log_file_num_backups", default=2)

# Generated at 2022-06-24 08:44:22.295725
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.makeLogRecord({
        'name': 'tornado.application', 
        'msg': 'foo', 
        'args': (), 
        'levelno': 20, 
        'levelname': 'INFO', 
        'pathname': 'server.py', 
        'filename': 'server.py', 
        'module': 'server', 
        'lineno': 24, 
        'funcName': 'run', 
        'created': 1520968230.977018, 
        'msecs': 977.0176391601562, 
        'relativeCreated': 24.303896661758423, 
        'thread': 140735652927232, 
        'threadName': 'MainThread', 
        'processName': 'MainProcess', 
        'process': 1})

# Generated at 2022-06-24 08:44:26.220938
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    options.define('name', default='')
    options.define('other', default=None)
test_define_logging_options()

# Generated at 2022-06-24 08:44:37.268763
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()

    message = "foobar"
    record = logging.LogRecord(
        name="tornado.test",
        level=logging.DEBUG,
        fn="filename",
        lno=123,
        msg=message,
        args=(),
        exc_info=None,
    )
    # Test formatter with default args is working fine
    f.format(record)

    # No source line information
    record.fn, record.lno = None, None
    f.format(record)

    record.levelno = logging.INFO
    f.format(record)

    # Test encoding errors
    record.msg = b"\xed\xac\xed\xb2\xed\xbe\xed\xb5"
    f.format(record)



# Generated at 2022-06-24 08:44:42.054863
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = "DEBUG"
    options.log_file_prefix = "file_prefix"
    options.log_file_max_size = "log_file_max_size"
    options.log_file_num_backups = 1
    options.log_to_stderr = False
    options.log_rotate_mode = "size"
    assert enable_pretty_logging()

# Generated at 2022-06-24 08:44:44.097186
# Unit test for function define_logging_options
def test_define_logging_options():
  import tornado.options
  options = tornado.options.define_logging_options()



# Generated at 2022-06-24 08:44:53.010782
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): # type: () -> None  # noqa: F811
    from tornado import options
    from tornado import testing

    class DummyRecord(object):
        def __init__(self) -> None:
            self.message = "hello world"

    class TestLogFormatter(testing.AsyncTestCase):
        def setUp(self) -> None:
            super(TestLogFormatter, self).setUp()
            self.formatter = LogFormatter()

        def test_safe_unicode(self) -> None:
            record = DummyRecord()
            # this is not a very realistic example, but it gets the job done.
            record.message = "hello world!\x00\x01\x03\x04"

# Generated at 2022-06-24 08:44:56.273629
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)

# Generated at 2022-06-24 08:44:58.163552
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:45:03.726071
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import unittest
    import tempfile
    import os
    import os.path
    import logging

    class TestHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            self.log_record = None
            logging.Handler.__init__(self, *args, **kwargs)

        def emit(self, record):
            self.log_record = record

    # test that the LogFormatter adds color codes to the message
    h1 = TestHandler()
    fmt = "[%(color)s%(levelname)s%(end_color)s] %(message)s"
    h1.setFormatter(LogFormatter(fmt=fmt))
    logging.root.handlers[0] = h1
    logging.root.setLevel

# Generated at 2022-06-24 08:45:07.634558
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    new_logger = logging.getLogger("tornado.test")
    enable_pretty_logging(logger=new_logger)
    new_logger.info("test")


test_enable_pretty_logging()

# Generated at 2022-06-24 08:45:11.970086
# Unit test for function define_logging_options
def test_define_logging_options():
    options = Options()
    define_logging_options(options)
    print(True)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:45:12.910783
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:45:25.441799
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest

    def get_logger() -> logging.Logger:
        return logging.getLogger("test_logger")

    def get_options() -> Any:
        # type: () -> Any
        import tornado.options

        class Options(object):
            pass

        options = Options()
        options.log_file_prefix = None
        options.log_to_stderr = None
        options.log_rotate_mode = "time"
        options.log_rotate_when = "D"
        options.log_rotate_interval = 1
        options.log_file_num_backups = 5
        options.logging = "none"
        tornado.options.options = options
        return options


# Generated at 2022-06-24 08:45:33.589824
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class FakeLogRecord(object):
        def __init__(self, message: str, levelno: int, exc_info: Optional[Exception]) -> None:
            self.message = message
            self.levelno = levelno
            self.exc_info = exc_info

        def getMessage(self) -> str:
            return self.message

    import unittest
    import tornado
    import logging

    class LogFormatterTest(unittest.TestCase):
        def test_format(self):
            record = FakeLogRecord("hello", logging.INFO, None)
            formatter = LogFormatter()
            result = formatter.format(record)
            self.assertIn("hello", result)
            record.message = "hel\0lo"
            result = formatter.format(record)

# Generated at 2022-06-24 08:45:36.853422
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # enable_pretty_logging(options=None, logger=None) -> None
    enable_pretty_logging()


# Generated at 2022-06-24 08:45:44.096825
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert log_formatter.style == "%"
    assert log_formatter.color == True
    assert log_formatter._colors == LogFormatter.DEFAULT_COLORS
    assert log_formatter._normal == ""



# Generated at 2022-06-24 08:45:57.509701
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord('name', 'levelno', 'pathname', 'lineno',
            'msg', 'args', 'exc_info')
    assert LogFormatter().format(record) == \
        '[L asctime name:lineno] msg'
    record.levelno = logging.DEBUG
    assert LogFormatter().format(record) == \
        '[D asctime name:lineno] msg'
    record.levelno = logging.INFO
    assert LogFormatter().format(record) == \
        '[I asctime name:lineno] msg'
    record.levelno = logging.WARNING
    assert LogFormatter().format(record) == \
        '[W asctime name:lineno] msg'
    record.levelno = logging.ERROR

# Generated at 2022-06-24 08:46:10.282558
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = '%'
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt, style=style, color=color,
                             colors=colors)
    record = logging.LogRecord(name='tornado.access', level=logging.DEBUG,
                               pathname='/home/meng/code/Python-3.7.6/Lib/logging/__init__.py',
                               lineno=5, msg='test', args=None,
                               exc_info=None)
    formatter.format(record)
    assert hasattr(record, 'asctime')
   

# Generated at 2022-06-24 08:46:18.284632
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define('logging', default='info', help='test logging')
    define('log_to_stderr', type=bool, default=None, help='test log_to_stderr')
    define('log_file_prefix', type=str, default=None, metavar='PATH', help='test log_file_prefix')
    define('log_file_max_size', type=int, default=100 * 1000 * 1000, help='test log_file_max_size')
    define('log_file_num_backups', type=int, default=10, help='test log_file_num_backups')
    define('log_rotate_when', type=str, default='midnight', help='test log_rotate_when')

# Generated at 2022-06-24 08:46:25.420333
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    a = LogFormatter()
    test_dict = {}
    test_dict["module"] = "module_sample"
    test_dict["lineno"] = 1
    test_dict["__name__"] = "__name___sample"
    test_dict["levelno"] = 20
    test_dict["end_color"] = "end_color_sample"
    test_dict["args"] = []
    test_dict["pathname"] = "pathname_sample"
    test_dict["filename"] = "filename_sample"
    test_dict["process"] = "process_sample"
    test_dict["thread"] = "thread_sample"
    test_dict["processName"] = "processName_sample"
    test_dict["exc_info"] = "exc_info_sample"

# Generated at 2022-06-24 08:46:33.576738
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_to_stderr = 0
    options.log_file_prefix = None
    options.log_rotate_mode = ((None,))
    options.log_file_num_backups = ((None,))
    options.log_file_max_size = ((None,))
    options.log_rotate_when = ((None,))
    options.log_rotate_interval = ((None,))
    options.logging = ((None,))
    logger = None
    enable_pretty_logging(options, logger)

# Generated at 2022-06-24 08:46:37.525891
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    expected_fmt = "[%(levelname)s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    assert LogFormatter()._fmt == expected_fmt


# Generated at 2022-06-24 08:46:38.997771
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass
    #This method can not be tested because it is humanistic output

# Generated at 2022-06-24 08:46:50.713352
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    from tornado.log import app_log
    from tornado.log import gen_log
    import tornado.testing

    class TestHandler(logging.handlers.MemoryHandler):
        def __init__(self):
            # type: () -> None
            self.buffer = []  # type: List[Any]
            logging.handlers.MemoryHandler.__init__(self, capacity=0)

        def shouldFlush(self, record):
            # type: (Any) -> bool
            return True

        def emit(self, record):
            # type: (Any) -> None
            self.buffer.append(record.getMessage())


# Generated at 2022-06-24 08:47:03.456437
# Unit test for function define_logging_options
def test_define_logging_options():
    options = None
    #logging 
    options.define("logging",default="info",help="logging help",metavar="debug|info|warning|error|none")
    options.define("logging","info","logging help","debug|info|warning|error|none")
    print(options.logging)
    #log_to_stderr
    options.define("log_to_stderr",bool,default=None,help="Send log output to stderr (colorized if possible)")
    options.define("log_to_stderr",None,"Send log output to stderr (colorized if possible)")
    print(options.log_to_stderr)
    #log_file_prefix

# Generated at 2022-06-24 08:47:14.286101
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from .options import options

    options.logging = "debug"
    options.log_file_prefix = "file"
    options.log_rotate_mode = "time"
    options.log_rotate_when = "h"
    options.log_rotate_interval = 1
    options.log_file_num_backups = 2

    enable_pretty_logging(options)
    logger = logging.getLogger()
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)

    options.log_to_stderr = False
    enable_pretty_logging(options)
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)

    options.log_

# Generated at 2022-06-24 08:47:25.737535
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os
    import logging
    import shutil
    import time
    import sys
    import io

    dirname = os.path.join(os.path.dirname(__file__), 'test_logs')

    def quiet():
        # set both the root logger and the one tornado.gen_log uses
        # to a lower level
        logging.getLogger().setLevel(logging.CRITICAL + 1)
        logging.getLogger('tornado.general').setLevel(logging.CRITICAL + 1)

    class FakeOptionNamespace(object):
        pass

    def setUp():
        if os.path.exists(dirname):
            shutil.rmtree(dirname)
        os.makedirs(dirname)

    def tearDown():
        shutil.r

# Generated at 2022-06-24 08:47:34.547336
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, parse_command_line, options

    define(
        "log_file_prefix", type=str, default="", help="test configuration option"
    )
    define(
        "log_file_rotate_mode",
        type=str,
        default="size",
        help="test configuration option",
    )
    define(
        "log_file_max_size", type=int, default=100, help="test configuration option"
    )
    define(
        "log_file_num_backups",
        type=int,
        default=10,
        help="test configuration option",
    )
    define(
        "log_to_stderr",
        type=bool,
        default=True,
        help="test configuration option",
    )

# Generated at 2022-06-24 08:47:36.530608
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformatter = LogFormatter()

# Generated at 2022-06-24 08:47:38.786422
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("name", "info", None, None, "message", None, None)
    #print(formatter.format(record))
    #print(type(formatter.format(record)))
    assert type(formatter.format(record)) == str


# Generated at 2022-06-24 08:47:41.105687
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True)
    record = logging.LogRecord(
        "",
        logging.INFO,
        "",
        "",
        "msg",
        None,
        None,
        "test_LogFormatter",
    )
    result = formatter.format(record)
    assert type(result) == str



# Generated at 2022-06-24 08:47:43.775137
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert type(LogFormatter().format(logging.LogRecord("log1", logging.DEBUG, "t1", 20, "msg", None, None)) == str) # noqa: E501

# Generated at 2022-06-24 08:47:47.202241
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import parse_command_line, options
    parse_command_line(["--logging=warning"])
    enable_pretty_logging(options)
    assert options.logging == "warning"
    assert options.log_to_stderr == True

# Generated at 2022-06-24 08:47:49.670807
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.options.logging='info'

# Generated at 2022-06-24 08:47:56.540427
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    assert fmt._fmt == fmt.DEFAULT_FORMAT
    assert fmt._colors == fmt.DEFAULT_COLORS

    fmt = LogFormatter(color=False)
    assert fmt._colors == {}
    assert fmt._fmt == fmt.DEFAULT_FORMAT


# ColorizingStreamHandler is meant to replace logging.StreamHandler.
# It supports colorizing the output on a terminal that supports it.
# This code is heavily based on the code found in
# logging/__init__.py in the standard library.

# Generated at 2022-06-24 08:47:57.957872
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(logging.getLogger())

# Generated at 2022-06-24 08:48:07.113208
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define_logging_options
    from tornado.options import options
    define_logging_options(options)
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

# Generated at 2022-06-24 08:48:12.042593
# Unit test for function define_logging_options
def test_define_logging_options():
    try:
        import tornado.options

        options = tornado.options.options
    except ImportError:
        return
    define_logging_options()
    options.parse_config_file('logging_test.py')

test_define_logging_options()

# Generated at 2022-06-24 08:48:20.108405
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    #_stderr_supports_color
    assert _stderr_supports_color() == True
    #_safe_unicode
    assert _safe_unicode(b"a") == "a"
    #LogFormatter.__init__
    lf = LogFormatter()
    assert isinstance(lf, LogFormatter)
    #LogFormatter.format
    record = []
    assert LogFormatter().format(record) != ""
    #enable_pretty_logging
    assert enable_pretty_logging() == None

# Generated at 2022-06-24 08:48:21.373335
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:48:28.039627
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    logging.basicConfig(level=logging.INFO)
    tornado_log = logging.getLogger("tornado")
    tornado_log.propagate = False

    class Record(object):
        def __init__(self, msg: str, levelno: int) -> None:
            self.message = msg
            self.levelno = levelno
            self.__dict__.update(self.__class__.__dict__)

        def __setitem__(self, key: str, value: Any) -> None:
            self.__dict__[key] = value

    # Test format colors with curses support and colors enabled
    f = LogFormatter(color=True)
    tornado_log.handlers[0].setFormatter(f)
    tornado_log.info("test message")

# Generated at 2022-06-24 08:48:29.189631
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print(help(LogFormatter.format))



# Generated at 2022-06-24 08:48:35.981417
# Unit test for function define_logging_options
def test_define_logging_options():
    # This only tests whether tornado raises an error
    # when parsing a complete set of options.  It does not
    # test what happens if the options are used.
    import tornado.options
    options = tornado.options._Options()
    define_logging_options(options)
    options.parse_command_line(
        ["progname", "--logging=warning", "--log_to_stderr", "--log_file_prefix=/foo/bar"]
    )

# Generated at 2022-06-24 08:48:37.754721
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
if __name__=='__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:48:39.891081
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    assert options.logging == "info"
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:48:41.910220
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)


# Generated at 2022-06-24 08:48:49.553350
# Unit test for function define_logging_options
def test_define_logging_options():
    # When the --help option is present, define_logging_options() should be a no-op.
    import tornado.options

    options = tornado.options.OptionParser()
    with tornado.testing.unittest_case.ExpectLog(gen_log, "(?s).*"):
        define_logging_options(options)
        options.parse_command_line(["--help"])

# Generated at 2022-06-24 08:49:02.098015
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tempfile
    import os
    import logging
    import logging.handlers

    log_file = tempfile.NamedTemporaryFile(suffix=".log", delete=False)
    log_file.close()
    log_file_path = log_file.name
    tornado.options.parse_command_line([
        "--logging", "debug",
        "--log_file_prefix", log_file_path,
        "--log_to_stderr", "False",
    ])
    enable_pretty_logging()
    logging.debug("test message")
    logging.getLogger("tornado.access").debug("test message")
    with open(log_file_path, "r") as f:
        assert "test message" in f.read()

# Generated at 2022-06-24 08:49:03.107897
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-24 08:49:07.638581
# Unit test for function define_logging_options
def test_define_logging_options():
    # type: () -> None
    from tornado.options import define, options
    import logging

    define("logging", default="info", help="Set the Python log level.")
    _logger = logging.getLogger()
    _logger.setLevel(getattr(logging, options.logging.upper()))
    define_logging_options()
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:49:14.893691
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    '''
    >>> record = logging.makeLogRecord({'exc_text': 'INTERNALERROR'})
    >>> record.message = 'ERROR'
    >>> record.asctime = '19052018'
    >>> record.color = 'Blue'
    >>> record.end_color = ''
    >>> record.levelno = 10
    >>> logformatter = LogFormatter()
    >>> logformatter.format(record)
    '[D 19052018 :0] ERROR\n    INTERNALERROR'
    '''
    pass



# Generated at 2022-06-24 08:49:21.354994
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert isinstance(f, logging.Formatter)
    assert f._fmt == LogFormatter.DEFAULT_FORMAT
    assert f._colors == {}
    assert f._normal == ""
    f = LogFormatter(fmt="", datefmt="")
    assert f._fmt == ""
    assert f._colors == {}
    assert f._normal == ""



# Generated at 2022-06-24 08:49:30.073887
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_rotate_mode = "size"
    assert options.log_rotate_mode == "size"
    tornado.options.options.log_file_prefix = "out"
    assert options.log_file_prefix == "out"
    tornado.options.options.log_file_max_size = 1024
    assert options.log_file_max_size == 1024
    tornado.options.options.log_file_num_backups = 5
    assert options.log_file_num_backups == 5
    tornado.options.options.log_rotate_mode = "time"
    assert options.log_rotate_mode == "time"
    tornado.options.options.log_rotate_when = 'midnight'

# Generated at 2022-06-24 08:49:34.617894
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print(options)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:49:39.204711
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # noqa: F811
    formatter = LogFormatter()
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter._colors == formatter.DEFAULT_COLORS
    assert formatter._normal == ""
    if curses:
        assert formatter._normal == unicode_type(curses.tigetstr("sgr0"), "ascii")

# Generated at 2022-06-24 08:49:41.356683
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging(tornado.options.options)


# Generated at 2022-06-24 08:49:46.125130
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    import tornado.log
    import logging
    import logging.handlers
    import unittest
    define("rotate_log", default=True)
    define("log_rotate_mode", default="size")
    define("log_rotate_when", default="S")
    define("log_rotate_interval", default=1)
    define("log_file_prefix", default="tornado_log")
    define("log_file_max_size", default=1)
    define("log_file_num_backups", default=2)
    define("logging", default="INFO")
    enable_pretty_logging()
    logger = logging.getLogger()
    logger.info("test")
    logger.setLevel(logging.DEBUG)

# Generated at 2022-06-24 08:49:53.527725
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import unittest
    import tempfile
    import time
    import os
    import os.path
    import sys
    import logging
    import shutil

    def options_dict(**kwargs: Any) -> Dict[str, Any]:
        d = {
            "logging": "debug",
            "log_to_stderr": True,
            "log_file_prefix": None,
            "log_rotate_when": "midnight",
            "log_rotate_interval": 1,
            "log_rotate_mode": "time",
            "log_file_max_size": 1000000,
            "log_file_num_backups": 5,
        }
        d.update(kwargs)
        return d


# Generated at 2022-06-24 08:49:55.657189
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # This is the simpleton example of unit test
    logging.basicConfig(level=logging.DEBUG)
    enable_pretty_logging()

test_enable_pretty_logging()

# Generated at 2022-06-24 08:49:58.927042
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger("tornado.test")
    enable_pretty_logging(logger=logger)
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)



# Generated at 2022-06-24 08:50:00.671145
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f is not None



# Generated at 2022-06-24 08:50:11.466508
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    import logging
    import unittest
    import threading
    
    def get_next_seq():
        current_seq = None
        lock = threading.Lock()
        def inner():
            nonlocal current_seq
            with lock:
                if current_seq:
                    current_seq+=1
                else:
                    current_seq = 0
                return current_seq
        return inner
    
    next_seq = get_next_seq()
    
    def get_log_file_name(file_prefix):
        return "%s.%s.log"%(file_prefix,next_seq())
    
   

# Generated at 2022-06-24 08:50:12.024250
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None, None)

# Generated at 2022-06-24 08:50:15.456367
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    print(options.log_rotate_mode)


# Generated at 2022-06-24 08:50:26.761426
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmtr = LogFormatter()
    class A: pass
    a = A()
    a.levelno = 100
    a.message = "This is a string"
    a.asctime = "the_time"
    a.color = "red"
    a.end_color = "blue"
    a.exc_info = None
    a.exc_text = None
    print(fmtr.format(a))


# Generated at 2022-06-24 08:50:36.480617
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line, parse_config_file  # type: ignore

    define("log_file_prefix", type=str, default=None)
    define("log_rotate_mode", type=str, default="size")
    define(
        "log_rotate_when",
        type=str,
        default="S",
    )
    define("log_rotate_interval", type=int, default=1)
    define("log_file_num_backups", type=int, default=10)
    define("log_file_max_size", type=int, default=10485760)
    define("log_to_stderr", type=bool, default=False)
    define("logging", type=str, default="DEBUG")

# Generated at 2022-06-24 08:50:43.572520
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    DEFAULT_FORMAT = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    DEFAULT_DATE_FORMAT = "%y%m%d %H:%M:%S"
    DEFAULT_COLORS = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

# Generated at 2022-06-24 08:50:49.279438
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create a formatter
    try:
        formatter = LogFormatter()
        # Create a record
        record = logging.LogRecord('name', 'INFO', 'filename', 42, 'msg %s', ('foo',), 'exc_info')
        # Format the record
        result = formatter.format(record)
        assert result, 'The format method of the formatter doesn\'t work'
    except Exception as e:
        assert False, str(e)

# Generated at 2022-06-24 08:50:59.850369
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import sys
    from tornado.log import gen_log
    from tornado.options import options, parse_command_line, define

    options.log_to_stderr = True
    options.logging = 'debug'
    define('use_color', type=bool, default=False)

    parse_command_line(['--use_color=True'])

    formatter = LogFormatter(
        color=options.use_color,
        fmt='%(color)s%(levelname)s: %(asctime)s: %(message)s%(end_color)s'
    )

    stream_handler = logging.StreamHandler(sys.stderr)
    stream_handler.setFormatter(formatter)
    gen_log.addHandler(stream_handler)

    gen_log.info('Info message')


# Generated at 2022-06-24 08:51:08.240728
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    Test method format of class LogFormatter.
    """
    a = LogFormatter()
    rec = logging.LogRecord(
        name="Test_Formatter_Record",
        level=logging.DEBUG,
        pathname="/Users/kw/tornado-4.5.2/tornado/log.py",
        lineno=400,
        msg="Test the format function",
        args=None,
        exc_info=None,
    )
    print(a.format(rec))

    b = LogFormatter()

# Generated at 2022-06-24 08:51:12.889547
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_colorama = LogFormatter(color=True)
    assert bool(test_colorama._colors) == bool(colorama)
    assert bool(test_colorama._colors) == bool(curses)
    assert test_colorama._normal == "\033[0m"



# Generated at 2022-06-24 08:51:23.366566
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    options = tornado.options.options
    define_logging_options(options)
    options.logging = "debug"
    options.log_to_stderr = True
    options.log_file_prefix = "test.log"
    options.log_file_max_size = 1000000
    options.log_file_num_backups = 10
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    options.log_rotate_mode = "size"
    options.parse_command_line()
    class TestHandler(tornado.web.RequestHandler):
        def get(self):
            app_log.info("info")

# Generated at 2022-06-24 08:51:24.015415
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:51:35.750707
# Unit test for method format of class LogFormatter

# Generated at 2022-06-24 08:51:37.673981
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
test_define_logging_options()

# Generated at 2022-06-24 08:51:48.226610
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.DEBUG,
                               "/fake/test/path.py", 9, "does it work",
                               None, None, None)
    out = fmt.format(record)
    # print("out", out)
    assert out == "[D 0609 14:17:00 path.py:9] does it work"
    record.msg = 'msg\nmsg'
    out = fmt.format(record)
    # print("out", out)
    assert out == "[D 0609 14:17:00 path.py:9] msg\n    msg"
    record.msg = "\xc3\x82\xc2\xa2"
    out = fmt.format(record)
    # print("out", out)

# Generated at 2022-06-24 08:51:50.479518
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    log_formatter.format(logging.LogRecord("foo", logging.DEBUG, "/path/", 11,  "bar", (), None))



# Generated at 2022-06-24 08:51:57.075686
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == LogFormatter.DEFAULT_COLORS
    assert log_formatter._normal is not ""
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT


# Generated at 2022-06-24 08:52:00.847114
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LOG_FORMATTER = LogFormatter()
    assert LOG_FORMATTER._colors == {
        10: 4,
        20: 2,
        30: 3,
        40: 1,
        50: 5,
    }


# Generated at 2022-06-24 08:52:01.454926
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()


# Generated at 2022-06-24 08:52:08.330212
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    '''
    Test method for function enable_pretty_logging
    '''
    import tornado.options
    import logging
    # 1.logging is None
    logger = logging.getLogger()
    # 2.logging is not None, log_file_prefix is None
    logger.handlers = []
    logger.setLevel(20)
    # 2.1 logging is not None, log_file_prefix is not None,
    #     log_rotate_mode is not None, log_rotate_mode is size
    tornado.options.options.logging = "info"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_file_prefix = "test.log"

# Generated at 2022-06-24 08:52:17.658210
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.log import LogFormatter
    LogFormatter(
        fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
        datefmt='%y%m%d %H:%M:%S',
        color=True,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        }
    )



# Generated at 2022-06-24 08:52:28.346008
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(datefmt="%Y")
    assert formatter.datefmt == "%Y"
    assert formatter._colors == {}
    assert formatter._normal == ""

    formatter = LogFormatter(color=True)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._normal == "\033[0m"

    formatter = LogFormatter(color=True, colors={logging.INFO: 0})
    assert formatter.datefmt == LogFormatter

# Generated at 2022-06-24 08:52:31.870527
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter(color=True)  # type: ignore
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-24 08:52:36.598379
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    record = logging.LogRecord(name='tornado.general',lvl=10,pathname='/home/tornado/tornado/log.py',lineno=1,msg='some text',args=(),exc_info=None)
    formatter = LogFormatter()
    formatted = formatter.format(record)



# Generated at 2022-06-24 08:52:38.388397
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
#    options = tornado.options.options
    define_logging_options()

# Generated at 2022-06-24 08:52:49.268478
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import io

    class LogFormatterTestCase(unittest.TestCase):  # type: ignore
        def setUp(self) -> None:
            self.formatter = LogFormatter()
            self.stream = io.StringIO()  # type: ignore
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setFormatter(self.formatter)
            self.logger = logging.getLogger("foo")
            self.logger.addHandler(self.handler)

        def tearDown(self) -> None:
            self.logger.removeHandler(self.handler)
            self.handler.close()

        def test_format_plain(self) -> None:
            self.logger.setLevel(logging.INFO)

            self.logger

# Generated at 2022-06-24 08:52:53.486444
# Unit test for constructor of class LogFormatter

# Generated at 2022-06-24 08:52:56.241599
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #set up
    LogFormatter()
    #test
    test_format = LogFormatter.format
    #assert
    assert callable(test_format)


# Generated at 2022-06-24 08:53:07.587552
# Unit test for method format of class LogFormatter

# Generated at 2022-06-24 08:53:12.411421
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors[logging.INFO] == "\033[2;34m"
    assert formatter._normal == "\033[0m"



# Generated at 2022-06-24 08:53:25.506668
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    logger = logging.getLogger()
    options = tornado.options.options
    test_options = tornado.options.parse_command_line(
        [
            "--log_file_prefix",
            "test_log_file",
            "--logging",
            "error",
            "--log_rotate_mode",
            "size",
            "--log_file_max_size",
            "200",
            "--log_file_num_backups",
            "10",
            "--log-to-stderr",
            "0",
        ]
    )
    # Test the options with log-to-stderr=1
    test_options.log_to_stderr = True
    enable_pretty_logging(options=test_options)