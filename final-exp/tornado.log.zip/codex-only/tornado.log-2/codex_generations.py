

# Generated at 2022-06-24 08:43:31.746334
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_config_file
    define("logging", default="info", help=(
        "Set the Tornado log level. "
        "If 'none', tornado won't touch the logging configuration."
    ))
    define("log_to_stderr", type=bool, default=True, help=(
        "Send log output to stderr (colorized if possible). "
        "By default use stderr if --log_file_prefix is not set and "
        "no other logging is configured."
    ))
    define("log_file_prefix", type=str, default='logs/tornado.log', metavar="FILE",
           help="Path prefix for log files.")

# Generated at 2022-06-24 08:43:35.450777
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.general", logging.INFO, "/fake/path", 42, "foo", (), None, None
    )
    record.color = "\033[2;3%dm" % 2
    record.end_color = "\033[0m"
    assert formatter.format(record).endswith("foo")
    record.exc_info = True
    assert formatter.format(record).endswith("foo")



# Generated at 2022-06-24 08:43:46.754098
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    import shutil
    import time

    # options.log_file_prefix
    option_dict = {"logging": "info", "log_file_prefix": "t1.log"}
    tornado.options.define("logging", default=None, type=str)
    tornado.options.define("log_file_prefix", default=None, type=str)
    tornado.options.parse_command_line(args=[], final=False, config_file=option_dict)
    enable_pretty_logging()

    logging.info("test1")
    with open("t1.log", "r") as f:
        assert f.readline()[24:] == "INFO     test1\n"

    # options.log_rotate_mode

# Generated at 2022-06-24 08:43:50.219350
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import  define, options
    define("a", default=1)
    options.logging = 'info'
    options.log_to_stderr = True
    print(define_logging_options(options))
    print(options.a)


# Generated at 2022-06-24 08:44:00.434798
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformatter = LogFormatter()
    assert logformatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert logformatter._colors == LogFormatter.DEFAULT_COLORS
    assert logformatter._normal == "" and not logformatter._fmt == LogFormatter.DEFAULT_FORMAT

    logformatter = LogFormatter(fmt="Some format string", datefmt="Awesome date format string", color=False)
    assert logformatter.datefmt == "Awesome date format string"
    assert logformatter._normal == "" and not logformatter._colors
    assert logformatter._fmt == "Some format string"


# Generated at 2022-06-24 08:44:09.636004
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.log

    tornado.options.parse_command_line()
    test_option = tornado.options.options
    assert test_option.log_to_stderr is None
    test_option.log_to_stderr = True
    assert test_option.log_to_stderr is True

    tornado.log.enable_pretty_logging(test_option)
    assert test_option.log_file_max_size == 100 * 1000 * 1000
    assert test_option.log_file_num_backups == 10

    assert test_option.log_rotate_when == "midnight"
    assert test_option.log_rotate_interval == 1

    assert test_option.log_rotate_mode == "size"
    assert test_option.logging == "info"

# Generated at 2022-06-24 08:44:13.873512
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter(style="%")
    assert f.format(LogRecord("foo", logging.DEBUG, None, None, "msg", None, None)) == "[DEBUG %(asctime)s foo:None] msg"  # noqa: E501



# Generated at 2022-06-24 08:44:20.368461
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import options
    from tornado.log import gen_log

    # setup the logging module to handle color output
    options.logging = "warning"
    options.parse_command_line()

    gen_log.setLevel(logging.DEBUG)
    gen_log.debug("hello")

if __name__ == "__main__":
    test_LogFormatter_format()

# Generated at 2022-06-24 08:44:27.203636
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = 'test/test.log'
    tornado.options.options.log_to_stderr = True
    tornado.options.options.logging = 'debug'
    enable_pretty_logging(tornado.options.options)
    access_log.info('hello')

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:44:36.385288
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log
    import logging

    logger = logging.getLogger("LogFormatter")
    handler = logging.StreamHandler()
    fmt = tornado.log.LogFormatter(fmt=tornado.log.LogFormatter.DEFAULT_FORMAT,datefmt=tornado.log.LogFormatter.DEFAULT_DATE_FORMAT)
    handler.setFormatter(fmt)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")



# Generated at 2022-06-24 08:44:43.623548
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    import tornado.options
    import os
    
    import logging
    import tornado.options
    
    
    
    class DummyOptions(object):
        
        class Logging(object):
            def lower(x):
                return "none"
        
        logging = Logging()
        
        log_file_prefix = "aaa"
        log_file_max_size = 111
        log_file_num_backups = 222
        log_rotate_mode = "time"
        log_rotate_when = "midnight"
        log_rotate_interval = 1
        log_to_stderr = None
    
    logging.basicConfig()
    enable_pretty_logging(DummyOptions())
    a = logging.getLogger()

# Generated at 2022-06-24 08:44:46.080251
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformatter = LogFormatter()

# This is an alias used by our unittests when they may otherwise
# accidentally invoke the real one.
# pylint: disable=invalid-name

# Generated at 2022-06-24 08:44:55.159058
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    d = {'name':'test','id':11,'time':'2019-11-12 17:31:18'}
    log1 = logging.LogRecord(name="test",id=11,level=logging.INFO,
                          pathname="test.py", lineno='', msg="test_message",
                          args=None, exc_info=None, func='',datetime=d)
    log2 = logging.LogRecord(name="test",id=11,level=logging.ERROR,
                          pathname="test.py", lineno='', msg="test_message",
                          args=None, exc_info=None, func='',datetime=d)
    #test format INFO
    lf = LogFormatter()
    print(lf.format(log1))
    #test format ERROR

# Generated at 2022-06-24 08:44:57.580694
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)
    assert tornado.options.options.logging != None


# Generated at 2022-06-24 08:45:05.391558
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    class Options(object):
        def __init__(self) -> None:
            super().__init__()

            self.logging: str = "info"
            self.log_to_stderr = None
            self.log_file_prefix = None
            self.log_file_max_size = 100 * 1000 * 1000
            self.log_file_num_backups = 10
            self.log_rotate_when = "midnight"
            self.log_rotate_interval = 1
            self.log_rotate_mode = "size"
    options = Options()
    define_logging_options(options)
    tornado.options.add_parse_callback(lambda: enable_pretty_logging(options))


# Generated at 2022-06-24 08:45:16.061704
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, define, options
    define("a", type=int)
    define("b", type=int)
    define("c", type=int)
    define("d", type=int)
    define("e", type=int)
    define("f", type=int)
    define("g", type=int)
    define("logging", type=int)
    define("log_to_stderr", type=int)
    define("log_file_prefix", type=int)
    define("log_file_max_size", type=int)
    define("log_file_num_backups", type=int)
    define("log_rotate_when", type=int)
    define("log_rotate_interval", type=int)

# Generated at 2022-06-24 08:45:17.206549
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()



# Generated at 2022-06-24 08:45:23.001883
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options

    options.log_file_prefix = 'hello.log'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 1024
    options.log_file_num_backups = 20
    options.logging = 'error'

    enable_pretty_logging(options)

# Generated at 2022-06-24 08:45:25.291017
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    print(formatter)



# Generated at 2022-06-24 08:45:33.044600
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest

    class LogFormatterTest(unittest.TestCase):
        def test_record_message_is_not_modified(self):
            log_record = logging.LogRecord("my_name", 5, "filename", 1, "msg", (), None)
            # The following line is just for type checking.
            assert log_record.message == "msg"
            formatter = LogFormatter()
            expected = formatter.format(log_record)
            self.assertEqual(log_record.message, "msg")
            # expected is "[NOTSET filename:1] msg"
            self.assertEqual(expected[-4:], "msg ", "LogFormatter.format may change log_record.message.")

    unittest.main()

# Generated at 2022-06-24 08:45:35.146412
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger()
    log_handler = logging.StreamHandler()
    log_handler.setFormatter(LogFormatter(color=False))
    logger.addHandler(log_handler)

    logger.info(42)



# Generated at 2022-06-24 08:45:41.800931
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    parser = OptionParser()
    define_logging_options(options)
    parser.parse_command_line(["--logging", "debug", "--log_file_prefix", "test.log"])
    assert options.logging == "debug", options.logging
    assert options.log_file_prefix == "test.log", options.log_file_prefix

# Generated at 2022-06-24 08:45:42.538627
# Unit test for function define_logging_options
def test_define_logging_options():
  options = None
  define_logging_options(options)

# Generated at 2022-06-24 08:45:43.083358
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:45:50.981517
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.log import LogFormatter

    assert tornado.options.options.logging is None
    assert tornado.options.options.log_file_prefix is None
    enable_pretty_logging()
    assert tornado.options.options.logging == "warning"

    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "/dev/null"
    enable_pretty_logging()
    logger = logging.getLogger()
    # Make sure the root logger's level was set correctly
    assert logger.level == logging.DEBUG
    # Make sure there is a RotatingFileHandler with a LogFormatter attached
    # to the root logger
    found_rfh = False
    found_formatter = False

# Generated at 2022-06-24 08:45:53.853396
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define("mylogging", type=str, default="info", help=("test mylogging"))
    options = tornado.options.options
    options.parse_command_line()
    define_logging_options(options)
    assert(options.mylogging == "info")

# Generated at 2022-06-24 08:46:04.265342
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.options.logging = "info"
    tornado.options.options.log_file_prefix = "test_log.log"
    tornado.options.options.log_to_stderr = True
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "D" #D for day
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 30
    enable_pretty_logging()
    logger = logging.getLogger()
    logger.info("This is a test message to the log file.")


# Generated at 2022-06-24 08:46:15.792286
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # mock record
    record = {
        "asctime": "20191216554",
        "levelname":logging.WARNING,
        "module": "tornado.application",
        "lineno": 42,
        "message":"There may be something wrong with this code.",
        "exc_info": False,
        "exc_text": False,
        "thread": "DummyThread",
        "threadName": "DummyThread"
    }
    # mock self of method

# Generated at 2022-06-24 08:46:17.665283
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    option_parser = OptionParser()
    define_logging_options(option_parser)

# Generated at 2022-06-24 08:46:23.146173
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    import tornado.log
    import sys
    import logging
    logfile = 'log.out'
    fh = logging.FileHandler(logfile)
    fh.setLevel(logging.INFO)
    fh.setFormatter(lf)
    logger = logging.getLogger()
    logger.addHandler(fh)
    logger.setLevel(logging.INFO)
    logger.info('This is a test')
    logger.info('Another record')
    with open(logfile, 'r') as f:
        assert 'This is a test' in f.read()



# Generated at 2022-06-24 08:46:32.839286
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    class fake_option():
        def __init__(self):
            self.log_to_stderr = True
            self.logging = "debug"
            self.log_file_prefix = "/Users/feng/log/tornado.log"
            self.log_file_max_size = 100
            self.log_file_num_backups = 10
            self.log_rotate_interval = 2
            self.log_rotate_when = "d"
            self.log_rotate_mode = 'size'
    fakeopt = fake_option()
    tornado.options.options = fakeopt
    logger = logging.getLogger('test')
    enable_pretty_logging(options=fakeopt,logger=logger)
    logger.debug('test pretty logging')

#

# Generated at 2022-06-24 08:46:35.017067
# Unit test for function define_logging_options
def test_define_logging_options():
    assert enable_pretty_logging(LogFormatter(logging.options))

# Generated at 2022-06-24 08:46:46.169038
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    def set_options(logging, log_file_prefix, log_rotate_mode, log_rotate_when, log_rotate_interval, log_file_num_backups):
        options=type('', (), {"logging":logging, "log_file_prefix":log_file_prefix, "log_rotate_mode":log_rotate_mode, "log_rotate_when":log_rotate_when, "log_rotate_interval":log_rotate_interval, "log_file_num_backups":log_file_num_backups})
        return options
    options=set_options("warning",'log/tornado.log', 'size', 'W6', 1, 10)
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:46:51.732574
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter("[%(levelname)1.1s %(asctime)s %(module)s] %(message)s")

# Generated at 2022-06-24 08:47:03.929830
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import tornado.options
    from tornado.httputil import HTTPHeaders
    from tornado.template import DictLoader

    class FakeLogRecord:
        def __init__(self, levelno, message, args=None, exc_info=None):
            # type: (int, str, Any, Any) -> None
            self.levelno = levelno
            self.message = message
            self.args = args if args else {}
            self.exc_info = exc_info
            self.exc_text = None

        def getMessage(self):
            # type: () -> str
            if self.args:
                return self.message % self.args
            else:
                return self.message


# Generated at 2022-06-24 08:47:06.560369
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=logging.DEBUG)
    enable_pretty_logging()
    logging.info("test_enable_pretty_logging")


# Generated at 2022-06-24 08:47:16.504918
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    This test is not comprehensive, but it did reveal some
    interesting bugs at one point.
    """
    import logging
    import logging.handlers
    import logging.config

    f = LogFormatter()
    try:
        r = logging.LogRecord(
            "tornado.foo", logging.WARNING, None, 0, "hello %s", ("world",), None
        )
    except TypeError as e:
        # Try the version used in Python 2.5
        r = logging.LogRecord("tornado.foo", logging.WARNING, None, 0, "hello %s", ("world",), None, None)  # noqa: E501
    print(f.format(r))

# Generated at 2022-06-24 08:47:19.881283
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    color = curses is not None
    formatter = LogFormatter(color=color)
    assert formatter._normal == "" if not color else "\033[0m"

# A test for _safe_unicode

# Generated at 2022-06-24 08:47:22.857181
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:47:26.110644
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    formatted = log_formatter.format(logging.makeLogRecord({"message": "hello"}))
    assert isinstance(formatted, str), formatted

# Generated at 2022-06-24 08:47:27.113501
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print(LogFormatter())


# Generated at 2022-06-24 08:47:30.057407
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter("%(levelname)s %(message)s")

# A default LogFormatter to be used in lieu of the old Formatter
default_formatter = LogFormatter()


# Generated at 2022-06-24 08:47:37.110704
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    print(log_formatter)
    print(type(log_formatter))
    log_formatter2 = LogFormatter()
    print(log_formatter2)
    print(type(log_formatter2))
    assert log_formatter == log_formatter2
    log_formatter3 = LogFormatter(fmt= "testtime",
                                  format="testformat",
                                  style="teststyle",
                                  color="testcolor",
                                  colors="testcolors")
    print(log_formatter3)
    print(type(log_formatter3))
    assert log_formatter != log_formatter3


# A copy of Python 3.2's WeakSet class.  This is included in Tornado for
# Python 2 and Python 3.1 support.  It

# Generated at 2022-06-24 08:47:46.880776
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        'tornado',
        logging.DEBUG,
        'tornado/util.py',
        23,
        'mesage1',
        None,
        None,
    )
    assert formatter.format(record) == '\x1b[34m[D 2300000 0 tornado/util.py:23]\x1b[0m mesage1'
    record.exc_info = (1, 2, 3)
    record.exc_text = 'text'
    assert formatter.format(record) == '\x1b[34m[D 2300000 0 tornado/util.py:23]\x1b[0m mesage1\n    text'


# Generated at 2022-06-24 08:47:48.498680
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging()

# Unit tests for the `LogFormatter` class.

# Generated at 2022-06-24 08:47:53.838702
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    The logged string is not important, but we want to make sure the
    format() method doesn't throw an exception.
    """
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("foo", logging.DEBUG, None, None, "bar", (), None))  # noqa: E501



# Generated at 2022-06-24 08:47:57.806721
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        fmt = LogFormatter()
        assert fmt is not None
    except Exception:
        assert False


# Generated at 2022-06-24 08:48:10.305948
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.parse_config_file(os.path.join(os.path.dirname(__file__), "test_define_logging_options.conf"))
    # The function enable_pretty_logging will be called after parsing a config file
    options = tornado.options.options
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)
if __name__ == '__main__':
    import os
    test_define_

# Generated at 2022-06-24 08:48:14.760113
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornada.options
    options = tornado.options.options
    define_logging_options(options)


# Generated at 2022-06-24 08:48:24.410050
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    default_options = tornado.options.options
    log_to_stderr = default_options.log_to_stderr
    log_to_stderr_default = default_options.log_to_stderr is None
    log_file_prefix = default_options.log_file_prefix
    log_rotate_mode = default_options.log_rotate_mode
    log_file_max_size = default_options.log_file_max_size
    log_file_num_backups = default_options.log_file_num_backups
    log_rotate_when = default_options.log_rotate_when
    log_rotate_interval = default_options.log_rotate_interval


# Generated at 2022-06-24 08:48:31.904252
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()._fmt
    r = logging.makeLogRecord({'message': "[2017-11-21 16:03:10 +0800] - [error]  404 GET /path/to/file (::1) 127.0.0.1 - -"})
    assert LogFormatter().format(r) == "[E 2017-11-21 16:03:10] - [error]  404 GET /path/to/file (::1) 127.0.0.1 - -"


# Generated at 2022-06-24 08:48:32.554022
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  pass

# Generated at 2022-06-24 08:48:42.562354
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_class = LogFormatter()
    import tornado.stack_context
    import tornado.httputil
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.locks
    import tornado.web
    import tornado.escape
    import tornado.escape
    import tornado.util
    import tornado.web
    import tornado.options
    from tornado.httputil import HTTPServerRequest, HTTPFile
    from tornado.options import define, options, parse_command_line, parse_config_file
    from tornado.stack_context import StackContext, NullContext, ExceptionStackContext
    from tornado.iostream import IOStream, SSLIOStream
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPError
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop, Period

# Generated at 2022-06-24 08:48:43.974245
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()  # no exception



# Generated at 2022-06-24 08:48:57.341331
# Unit test for function define_logging_options
def test_define_logging_options():
    sys.argv = [sys.argv[0],
        "--logging=error", 
        "--log_to_stderr", 
        "--log_file_prefix=logs/tornado.log",
        "--log_file_max_size=100",
        "--log_file_num_backups=10",
        "--log_rotate_when=midnight",
        "--log_rotate_interval=1",
        "--log_rotate_mode=size",
    ]
    import tornado.options
    tornado.options.parse_command_line()
    # tornado.options.options.logging == "debug"
    # tornado.options.options.log_to_stderr == "True"
    # tornado.options.options.log_file_prefix == "logs

# Generated at 2022-06-24 08:48:58.941755
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf



# Generated at 2022-06-24 08:49:04.951105
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("foo")
    tornado.options.define("log_to_stderr", type=bool, default=True)
    tornado.options.define("bar")
    tornado.options.parse_command_line()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging()
    #print(logger)

# Generated at 2022-06-24 08:49:16.725641
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_options = {"log_to_stderr" : True, "log_rotate_mode" : "size", "log_file_prefix":"temp", "log_file_max_size":10, "log_file_num_backups":100, "log_rotate_when": "M", "log_rotate_interval": 3}
    if test_options["log_to_stderr"]:
        # Set up color if we are in a tty and curses is installed
        channel = logging.StreamHandler()
        channel.setFormatter(LogFormatter())
        logger.addHandler(channel)
        
    if options.log_file_prefix:
        rotate_mode = options.log_rotate_mode

# Generated at 2022-06-24 08:49:27.116436
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert log_formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert log_formatter.DEFAULT_COLORS == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }



# Generated at 2022-06-24 08:49:29.269013
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    import logging
    define_logging_options(options)
    options.parse_command_line()
    logging.warning("123")

# Generated at 2022-06-24 08:49:35.051836
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """Unit tests for LogFormatter constructor.

    In all cases, the LogFormatter instances are constructed but their
    output is not tested.
    """
    fmt = "%(color)s%(levelname)s%(end_color)s %(message)s"
    datefmt = "%Y-%m-%d"

    # Simple case.
    formatter = LogFormatter(color=True)
    assert formatter._normal == "\033[0m"

    # Explicit colors.
    colors = {logging.DEBUG: 7, logging.INFO: 4, logging.WARNING: 3}
    formatter = LogFormatter(colors=colors, color=True)
    assert formatter._normal == "\033[0m"

    # Explicit fmt, colors, and datefmt.
    formatter

# Generated at 2022-06-24 08:49:44.791968
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        from tornado.options import options, parse_command_line
        from tornado.log import app_log, access_log, gen_log, enable_pretty_logging
        parse_command_line(['--logging=debug',"--log_file_prefix=./log/tornado.log"])
        enable_pretty_logging()
        #app_log.error("testing error...")
        #gen_log.info("testing info...")
        #access_log.info("testing info...")
        #app_log.info("testing info...")
    except Exception as err:
        print(str(err))

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:49:45.959921
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f is not None


# Generated at 2022-06-24 08:49:53.046200
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # arrange
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color: bool = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(fmt, datefmt, style, color, colors)

# Generated at 2022-06-24 08:49:55.644987
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging()


# Generated at 2022-06-24 08:50:03.566230
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from pprint import pprint
    from tornado.log import gen_log

    gen_log.setLevel(logging.DEBUG)
    gen_log.addHandler(logging.StreamHandler())

    gen_log.debug("debug")
    gen_log.info("info")
    gen_log.warning("warning")
    gen_log.error("error")
    gen_log.critical("critical")

    try:
        1/0
    except:
        gen_log.exception("exception")

# Generated at 2022-06-24 08:50:13.392117
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    lf = LogFormatter()
    assert lf.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    lf = LogFormatter(datefmt='%Y-%m-%d')
    assert lf.datefmt == '%Y-%m-%d'
    assert lf._fmt == LogFormatter.DEFAULT_FORMAT
    lf = LogFormatter(fmt="%(message)s")
    assert lf._fmt == '%(message)s'
    lf = LogFormatter(color=False)
    assert not lf._colors
    assert not lf._normal
    lf = LogFormatter(colors={logging.DEBUG: 9})

# Generated at 2022-06-24 08:50:24.691190
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = logging.options
    rotate_mode = options.log_rotate_mode
    if rotate_mode == "size":
        channel = logging.handlers.RotatingFileHandler(
            filename=options.log_file_prefix,
            maxBytes=options.log_file_max_size,
            backupCount=options.log_file_num_backups,
            encoding="utf-8",
        )  # type: logging.Handler
    elif rotate_mode == "time":
        channel = logging.handlers.TimedRotatingFileHandler(
            filename=options.log_file_prefix,
            when=options.log_rotate_when,
            interval=options.log_rotate_interval,
            backupCount=options.log_file_num_backups,
            encoding="utf-8",
        )


# Generated at 2022-06-24 08:50:35.101234
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options  # type: ignore
    import io
    import sys
    import unittest
    import logging
    import logging.handlers

    class LoggingTest(unittest.TestCase):
        def setUp(self) -> None:
            self.original_stderr = sys.stderr
            sys.stderr = self.stderr = io.StringIO()

        def tearDown(self) -> None:
            logging.getLogger().handlers = []
            sys.stderr = self.original_stderr

    class PrettyLoggingTest(LoggingTest):
        def test_enable_pretty_logging_stdout_color(self) -> None:
            enable_pretty_logging(options=None)
            logging.info("hello")

# Generated at 2022-06-24 08:50:44.847677
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    assert options.log_rotate_mode == "size"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_when == "midnight"
    assert options.log_file_num_backups == 10
    assert options.log_file_prefix == None
    assert options.log_file_max_size == 100000000
    assert options.log_to_stderr == None
    assert options.logging == "info"

# Generated at 2022-06-24 08:50:53.343558
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, parse_command_line, options

    define("logging", default="info", help="Logging level", type=str)
    define("log_file_prefix", default="app.log", help="Log file name", type=str)
    define("log_file_max_size", default=100000, help="Max log file size", type=int)
    define("log_file_num_backups", default=10, help="Max log file backups", type=int)
    define("log_file_mode", default=0o600, help="Log file mode", type=int)
    define("log_rotate_mode", default="size", help="Log rotate mode", type=str)

# Generated at 2022-06-24 08:51:03.271536
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    logger.propagate = False
    logger.setLevel(logging.NOTSET)
    logger.handlers = []  # type: ignore

# Generated at 2022-06-24 08:51:06.681918
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    myoptions = tornado.options.OptionParser()
    define_logging_options(myoptions)
    myoptions.parse_command_line(["--logging=warning"])


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:51:18.170338
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass
    # import StringIO as StringIO
    # import logging
    # out = StringIO.StringIO()
    # handler = logging.StreamHandler(out)
    # handler.setFormatter(LogFormatter())
    # handler.setLevel(logging.DEBUG)
    # app_log.addHandler(handler)
    # app_log.setLevel(logging.DEBUG)
    # app_log.warn("testing %s", _unicode("\xe9"))
    # assert out.getvalue() == (u"[W 110421 22:01:16 test_log.py:31] "
    #                           u"testing \xe9\n"
    #                           u"    21021 179115416 tornado.py:2151] "
    #                           u"_DataLoaderCallable: Exception in callback "
    #

# Generated at 2022-06-24 08:51:27.686181
# Unit test for function define_logging_options
def test_define_logging_options():
    import logging
    options = define_logging_options()
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, options.logging.upper()))
    if options.log_file_prefix:
        rotate_mode = options.log_rotate_mode
        if rotate_mode == "size":
            channel = logging.handlers.RotatingFileHandler(
                filename=options.log_file_prefix,
                maxBytes=options.log_file_max_size,
                backupCount=options.log_file_num_backups,
                encoding="utf-8",
            )  # type: logging.Handler

# Generated at 2022-06-24 08:51:32.998449
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("log_file_prefix", type=str, default=None)
    tornado.options.define("log_file_max_size", type=int, default=100000)
    tornado.options.define("log_file_num_backups", type=int, default=10)
    tornado.options.define("log_rotate_when", type=str, default="S", metavar="S|M|H|D")
    tornado.options.define("log_rotate_interval", type=int, default=1)
    tornado.options.define("log_rotate_mode", type=str, default="size", metavar="size|time")
    tornado.options.define("logging", type=str, default="info")

# Generated at 2022-06-24 08:51:40.916996
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """ 
        Testing LogFormatter.__init__()
    """
    formatter = LogFormatter()
    assert formatter._normal == ""
    assert not formatter._colors
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert isinstance(formatter, logging.Formatter)
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT


# Generated at 2022-06-24 08:51:50.726229
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    '''Test for basic functionality of LogFormatter
    '''
    test_log_format = "%(levelname)s: %(lineno)d: %(funcName)s: %(message)s"
    logging.basicConfig(format=test_log_format)
    gen_log.debug("logging test")
    logging.basicConfig(format=test_log_format)
    gen_log.debug("logging test without color")
    gen_log.setLevel(logging.DEBUG)
    gen_log.debug("gen_log logging test without color")
    datefmt = "%y%m%d %H:%M:%S"
    fmt = "%(color)s[%(levelname)s %(lineno)s]%(end_color)s %(message)s"

    formatter = Log

# Generated at 2022-06-24 08:52:02.406010
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter

    class MyLogFormatter(LogFormatter):
        pass

    formatter = MyLogFormatter()
    class test(object):
        def __init__(self):

            pass

    record = test()
    record.levelno = 7
    record.exc_text = "some_text"
    record.message = "Some message"
    class TestRecord:
        def __init__(self,levelno:int,exc_text:str,message:str):
            self.levelno = levelno
            self.exc_text = exc_text
            self.message = message

    record = TestRecord(7,"some_text","Some message")
    result_formatter = formatter.format(record = record)

# Generated at 2022-06-24 08:52:05.292832
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    message = "This is a test"
    formatter = LogFormatter()
    message = formatter.format(message)
    print(message)
    assert len(message) > 0


# Generated at 2022-06-24 08:52:12.144172
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    with pytest.raises(ValueError):
        options.parse_command_line(['--log_rotate_mode=size'])
    with pytest.raises(ValueError):
        options.parse_command_line(['--log_rotate_mode=time'])

# Generated at 2022-06-24 08:52:20.229988
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    from tornado.log import gen_log
    logger=gen_log
    handler = logging.StreamHandler()
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    # 1. As-is string
    logger.debug("As-is string")
    # 2. Unicode
    logger.debug('Unicode: café')
    # 3. Byte string

# Generated at 2022-06-24 08:52:22.536282
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.LogFormatter()

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:52:26.308087
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(
        fmt="format %(message)s",
        datefmt="dateformat",
        style="style",
        color=True,
        colors={1: 2, 3: 4},
    )


# Generated at 2022-06-24 08:52:30.077836
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    # Colorama on Windows needs special initialization before use.
    if colorama is not None:
        colorama.init()
    LogFormatter()



# Generated at 2022-06-24 08:52:34.731928
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    assert fmt.DEFAULT_COLORS == {
        logging.DEBUG: 4,
        logging.INFO: 2,
        logging.WARNING: 3,
        logging.ERROR: 1,
        logging.CRITICAL: 5,
    }



# Generated at 2022-06-24 08:52:35.918134
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:52:41.377969
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformatter = LogFormatter()
    import logging
    rootlogger = logging.getLogger()
    rootlogger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logformatter
    ch.setFormatter(formatter)
    rootlogger.addHandler(ch)
    logging.info("Hello world")

# test_LogFormatter()

# Generated at 2022-06-24 08:52:50.497498
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    datefmt = "%H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 6,  # Cyan
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # red
        logging.CRITICAL: 5  # Magenta
    }
    log_formatter = LogFormatter(fmt=fmt, datefmt=datefmt, style=style, color=color, colors=colors)
    rec = logging.LogRecord('test_name', logging.INFO, __name__, 1, msg='test message', args=None, exc_info=None)
    log_

# Generated at 2022-06-24 08:52:52.889115
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        enable_pretty_logging() # will not raise exception
    except Exception:
        assert False, "test enable_pretty_logging failed"

# Generated at 2022-06-24 08:52:58.588085
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("logging", default="info",
           help="Set the Python log level. If 'none', tornado won't touch the logging configuration.",
           metavar="debug|info|warning|error|none")
    options.logging = "debug"
    define_logging_options(options)
test_define_logging_options()

# Generated at 2022-06-24 08:53:07.067546
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
    options.parse_command_line()
    assert "info" == options.logging
    assert None == options.log_to_stderr
    assert None == options.log_file_prefix
    assert 100 * 1000 * 1000 == options.log_file_max_size
    assert 10 == options.log_file_num_backups
    assert "midnight" == options.log_rotate_when
    assert 1 == options.log_rotate_interval
    assert "size" == options.log_rotate_mode

# Generated at 2022-06-24 08:53:07.997363
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass



# Generated at 2022-06-24 08:53:21.525850
# Unit test for function define_logging_options
def test_define_logging_options():
    class TestCase:
        options = None
        def define(self, name, **kwargs):
            TestCase.options.setdefault(name, kwargs)
        def add_parse_callback(self, callback):
            callback()
    TestCase.options = {}
    define_logging_options(TestCase())
    s = "default='info',metavar='debug|info|warning|error|none',help='Set the Python log level. If 'none', tornado won't touch the logging configuration.'"
    assert TestCase.options['logging']['default'] == 'info'
    assert TestCase.options['logging']['metavar'] == 'debug|info|warning|error|none'

# Generated at 2022-06-24 08:53:25.555121
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(fmt='%(asctime)s %(levelname)s %(message)s', datefmt='%y%m%d %H:%M:%S', style='%')
