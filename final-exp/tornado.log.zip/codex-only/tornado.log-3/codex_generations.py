

# Generated at 2022-06-24 08:43:34.712860
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options as options
    from tornado.log import app_log
    from tornado.options import define, parse_command_line

    define("logging", default="debug", help="")
    define("log_file_prefix", default=None, help="")
    define("log_rotate_mode", default="size", help="")
    define("log_file_max_size", default=100000, help="")
    define("log_rotate_interval", default=1, help="")
    define("log_rotate_when", default="D", help="")
    define("log_file_num_backups", default=10, help="")
    define("log_to_stderr", default=None, help="")
    parse_command_line()

# Generated at 2022-06-24 08:43:39.058189
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging

    tornado.options.options.log_to_stderr = False
    tornado.options.options.log_file_prefix = "/tmp/logtest"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1
    tornado.options.options.log_file_num_backups = 1000
    tornado.log.enable_pretty_logging()
    logger = logging.getLogger()
    logger.info("log message")

# Generated at 2022-06-24 08:43:44.980893
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser().parse_command_line()
    options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    options.define(
        "log_to_stderr",
        type=bool,
        default=None,
        help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."
        ),
    )

# Generated at 2022-06-24 08:43:49.862756
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    import tornado.options
    parser = OptionParser()
    define_logging_options(parser)
    assert tornado.options.options == parser.options
    assert "logging" in tornado.options.options
    assert "log_to_stderr" in tornado.options.options
    assert "log_file_prefix" in tornado.options.options
    assert "log_file_max_size" in tornado.options.options
    assert "log_file_num_backups" in tornado.options.options

test_define_logging_options()



# Generated at 2022-06-24 08:43:50.500857
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()



# Generated at 2022-06-24 08:43:51.264217
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    format = LogFormatter().format('test')
    assert format == '[test]\n'


# Generated at 2022-06-24 08:44:02.430198
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord('test', 0, None, 0, 'message', None, None)
    assert formatter.format(record) == "[0 test:0] message"
    assert formatter.formatTime(record, '%m-%d') == '00-01'
    record.exc_text = "exc\ntext"
    record.exc_info = [None]
    assert formatter.format(record) == "[0 test:0] message\n    exc\n    text"
    formatter = LogFormatter(fmt='%(levelname)s %(message)s')
    assert formatter.format(record) == "INFO message"
    formatter = LogFormatter(fmt='%(levelname)s %(message)s', color=False)
    assert formatter

# Generated at 2022-06-24 08:44:10.848068
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Record:
        def __init__(self, levelno, msg):
            self.levelno = levelno
            self.msg = msg
            self.exc_info = None
            self.exc_text = None

        def getMessage(self):
            return self.msg

    test_formatter = LogFormatter(color=False)
    record = Record(logging.INFO, "test_format")
    record.exc_info = "exc_info"
    record.exc_text = "exc_text"
    result = test_formatter.format(record)
    assert isinstance(result, str)
    record.exc_info = None
    record.exc_text = None
    result = test_formatter.format(record)
    assert isinstance(result, str)



# Generated at 2022-06-24 08:44:22.452189
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    def test(message, expected):
        record = logging.LogRecord('tornado.access', logging.INFO, '', 0, message, None, None)
        formated = f.format(record)
        if formated is not expected:
            raise Exception("for message:'" + message + "' expected:'" + expected + "' got:'" + formated + "'")
    test(
        'hello',
        '[I .:0] hello'
    )
    test(
        'hello\nworld',
        '[I .:0] hello\n    world'
    )
    test(
        'hello\nworld\n\nagain',
        '[I .:0] hello\n    world\n    \n    again'
    )

test_LogFormatter_format()



# Generated at 2022-06-24 08:44:25.913516
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    assert isinstance(fmt.format(logging.LogRecord("tornado.access", 20, "test.py", 10, "3.5", [], None)), str) == True

# Generated at 2022-06-24 08:44:33.983620
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    import time
    record = logging.LogRecord(
        name = "tornado.general",
        level = 10,
        pathname = "tornado/log.py",
        lineno = 134,
        msg = "this is a message",
        args = None,
        exc_info = None
    )
    record.msecs = time.time()
    record.created = time.time()
    record.thread = 24136
    record.process = 24136
    log_formatter.format(record)

# Generated at 2022-06-24 08:44:42.464919
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    options = tornado.options.options
    options.logging = ""
    options.log_to_stderr = True
    enable_pretty_logging()
    # Test for logger.setLevel
    logger = logging.getLogger()
    assert logger.getEffectiveLevel() == logging.NOTSET
    options = tornado.options.options
    options.logging = "info"
    enable_pretty_logging()
    # Test for logger.setLevel
    logger = logging.getLogger()
    assert logger.getEffectiveLevel() == logging.INFO
    # Test for default option values
    options.logging = "none"
    enable_pretty_logging()
    assert options.log_rotate_mode is None
    assert options.log_to_stderr is None
    assert options

# Generated at 2022-06-24 08:44:52.376107
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime

    log_msg = "This is a log message\n with a newline"
    record = logging.LogRecord(
        "name",
        20,
        "pathname",
        10,
        log_msg,
        None,
        None,
        "funcName",
    )
    record.created = 1506879478.3608302
    record.msecs = 360.83022260665894
    record.levelname = "INFO"
    f = LogFormatter()
    res = f.format(record)
    assert res == "[I 150819 11:44:38 pathname:10] This is a log message\n    with a newline"


# Generated at 2022-06-24 08:44:54.202482
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format("test") == str("[TEST %s %s:%d] %s" % ("", "", 0, "test"))

# Generated at 2022-06-24 08:44:56.790184
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print(options)

#test_define_logging_options()

# Generated at 2022-06-24 08:45:05.014083
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing
    import tornado.log

    class LoggingTest(tornado.testing.LogTrapTestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            tornado.options.define(
                "logging", default="info", type=str, help="Logging verbosity"
            )
            tornado.options.define(
                "log_file_prefix",
                default="",
                type=str,
                help="Path prefix for log files",
            )
            tornado.options.define(
                "log_rotate_mode",
                default="time",
                type=str,
                help="Log rotate mode",
            )

# Generated at 2022-06-24 08:45:13.889845
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create a log formatter 
    formatter = LogFormatter()
    # Create the actual log record 
    record = logging.LogRecord(
        'test',
        logging.DEBUG,
        '/path/to/file.py',
        1234,
        'an error occured',
        ['arg1', 'arg2'],
        exc_info=None)
    # get the log message
    logString = formatter.format(record)
    # Log Message should contain '[DEBUG '
    assert logString.find('[DEBUG ') != -1


# Generated at 2022-06-24 08:45:26.310403
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    formatter = LogFormatter()  # type: ignore
    class _Record(object):
        __slots__ = ("name", "levelno", "levelname", "msg", "args", "exc_info")

    def test(rec, msg):
        # type: (_Record, str) -> None
        assert formatter.format(rec) == msg

    test(
        _Record(
            "test", logging.INFO, "INFO", "test message", [], None
        ),
        "[I 180131 20:07:00 test:0] test message",
    )

# Generated at 2022-06-24 08:45:27.454802
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    Options = tornado.options.OptionParser()
    define_logging_options(Options)

# Generated at 2022-06-24 08:45:34.783328
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define("log_file_max_size", type=int, default=100 * 1000 * 1000, help="max size of log files before rollover",)
    tornado.options.parse_config_file("config3.py")
    #print tornado.options.options.logging
    print(tornado.options.options.log_file_prefix)
    #print tornado.options.options.log_file_max_size
    #print tornado.options.options.log_file_num_backups
    print(tornado.options.options.log_rotate_when)
    print(tornado.options.options.log_rotate_interval)
    print(tornado.options.options.log_rotate_mode)
    #tornado.options.options.log_to_stderr =

# Generated at 2022-06-24 08:45:46.161372
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord('tornado.access', logging.DEBUG, "../tornado/simple_httpclient.py", 81, "80.82.27.235", (), None, None, "GET /static/css/normalize.css HTTP/1.1", "200", "119", "https://www.tornadoweb.org/en/stable/", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36")
    formatter.format(record)
    assert record.message == 'GET /static/css/normalize.css HTTP/1.1'
    assert record.name == 'tornado.access'
    assert record.level == 20




# Generated at 2022-06-24 08:45:58.531110
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import logging_options
    from tornado.options import options, define
    define("logging", default="DEBUG", help="log level", type=str)
    define("log_file_prefix", default="./log/log", help="log file", type=str)
    define("log_to_stderr", default=True, help="log to stderr",type=bool)
    define("log_rotate_mode", default="size", help="log rotate mode",type=str)
    define("log_rotate_when", default="D", help="log rotate when",type=str)
    define("log_file_max_size", default="100", help=
    "log file max size",type=int)

# Generated at 2022-06-24 08:46:01.054606
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-24 08:46:02.292124
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter() is not None

# Generated at 2022-06-24 08:46:11.689776
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="test_LogFormatter_format",
        lineno=0,
        msg="test message",
        args=(),
        exc_info=None,
        func=None,
    )
    expect = "[I 19700101 00:00:00 test_LogFormatter_format:0] test message"
    assert log_formatter.format(record) == expect


# Generated at 2022-06-24 08:46:14.634334
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print(options)
    assert options.log_rotate_when == "midnight"
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:46:21.461585
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options()
    tornado.options.parse_command_line("--logging=info")
    tornado.options.parse_command_line("--log_to_stderr=True")
    tornado.options.parse_command_line("--log_file_prefix=test.log")
    tornado.options.parse_command_line("--log_file_max_size=10")
    tornado.options.parse_command_line("--log_file_num_backups=5")
    tornado.options.parse_command_line("--log_rotate_when=midnight")
    tornado.options.parse_command_line("--log_rotate_interval=1")
    tornado.options.parse_command_line("--log_rotate_mode=size")

# Generated at 2022-06-24 08:46:23.348775
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None

    LogFormatter()



# Generated at 2022-06-24 08:46:32.900211
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("logging", default="info", help="")
    define("log_to_stderr", default=None, help="")
    define("log_file_prefix", default=None, help="")
    define("log_file_max_size", default=100 * 1000 * 1000, help="")
    define("log_file_num_backups", default=10, help="")
    define("log_rotate_when", default="midnight", help="")
    define("log_rotate_interval", default=1, help="")
    define("log_rotate_mode", default="size", help="")
    options.add_parse_callback(lambda: enable_pretty_logging(options))

# Generated at 2022-06-24 08:46:34.317386
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass


# Generated at 2022-06-24 08:46:41.069488
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    from tornado.log import enable_pretty_logging, access_log, app_log, gen_log
    define("log_file_prefix", default='/tmp/tornado_logging')
    parse_command_line()
    enable_pretty_logging()
    access_log.info('hello world')
    app_log.info('hello world')
    gen_log.info('hello world')


# Many older patterns are defined here to allow auto-fixers to
# transform them to new-style calls.  The old-style methods are
# deprecated and will be removed in a future release.
# (deprecated in 3.2, removed in 5.0)

# Generated at 2022-06-24 08:46:52.814677
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert isinstance(f, logging.Formatter)
    # Basic formatting
    record = logging.makeLogRecord({'message': 'foo', 'asctime': 'bar'})
    assert f.format(record) == "[I bar foo]\n    "
    # Color
    record = logging.makeLogRecord(
        {'message': 'foo', 'asctime': 'bar', 'levelno': logging.WARNING}
    )
    assert f.format(record) == "\x1b[2;33m[W bar foo]\x1b[0m\n    "
    # Unicode
    record = logging.makeLogRecord({'message': '\u2603', 'asctime': 'bar'})

# Generated at 2022-06-24 08:47:04.214664
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options

    options = tornado.options.options
    options.logging = "none"
    enable_pretty_logging(options)
    options.logging = "debug"
    enable_pretty_logging(options)
    options.logging = "info"
    enable_pretty_logging(options)
    options.logging = "warning"
    enable_pretty_logging(options)
    options.logging = "error"
    enable_pretty_logging(options)
    options.logging = "critical"
    enable_pretty_logging(options)
    options.log_file_prefix = "./test_enable_pretty_logging.log"
    options.logging = "info"
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:47:08.790241
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # https://github.com/tornadoweb/tornado/blob/v6.0.3/tornado/log.py#L80
    from tornado.log import LogFormatter
    log_formatter = LogFormatter(color=True)
    log_formatter.format(LogFormatter.DEFAULT_COLORS) == LogFormatter.DEFAULT_COLORS
    log_formatter.format(LogFormatter.DEFAULT_FORMAT) == LogFormatter.DEFAULT_FORMAT
    log_formatter.format(LogFormatter.DEFAULT_DATE_FORMAT) == LogFormatter.DEFAULT_DATE_FORMAT
    log_formatter.format('fmt') == 'fmt'
    log_formatter.format('datefmt') == 'datefmt'
    log_formatter.format('color')

# Generated at 2022-06-24 08:47:17.630485
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class TestFormat(logging.Formatter):
        format_times = 0
        def format(self, record: Any) -> str:
            TestFormat.format_times += 1
            return super().format(record)
    logger = logging.getLogger('tornado')
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(TestFormat())
    logger.addHandler(handler)
    try:
        logger.error('this is error')
        assert TestFormat.format_times == 1
        def sub_gen_log():
            gen_log.info('this is info')
            assert TestFormat.format_times == 2
        sub_gen_log()
    finally:
        logger.hand

# Generated at 2022-06-24 08:47:28.658191
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log

    # Set up some dummy options
    class Options(object):
        log_file_prefix = 'test'
        log_to_stderr = True
        log_file_num_backups = 3
        log_file_max_size = 10
        log_rotate_mode = 'time'
        log_rotate_when = 'S'
        log_rotate_interval = 5

    tornado.options.define('log_file_prefix', default='test')
    tornado.options.define('log_to_stderr', default=True)
    tornado.options.define('log_file_num_backups', default=3)
    tornado.options.define('log_file_max_size', default=10)

# Generated at 2022-06-24 08:47:32.760199
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
    print(options.logging)


__all__ = ["access_log", "app_log", "gen_log", "enable_pretty_logging"]

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:47:42.532915
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(message)s')
    formatter = LogFormatter(color=True)
    log = logging.getLogger()
    lh = logging.StreamHandler(sys.stderr)
    lh.setFormatter(formatter)
    log.handlers = []  # Otherwise we get a ConsecutiveStreamHandlerError.
    log.addHandler(lh)
    log.warn("foo %s %s %s" % ("1", "2", "3"))


# Generated at 2022-06-24 08:47:53.055634
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = fake_options()
    enable_pretty_logging(options)
    logger = logging.getLogger()
    assert logger.getEffectiveLevel() == 30
    assert len(logger.handlers) == 1
    assert type(logger.handlers[0]) == logging.StreamHandler
    options.log_file_prefix = "../../test"
    enable_pretty_logging(options)
    assert len(logger.handlers) == 2
    assert type(logger.handlers[1]) == logging.handlers.RotatingFileHandler
    assert logger.handlers[1].maxBytes == 1024
    assert logger.handlers[1].backupCount == 3
    assert logger.handlers[1].encoding == "utf-8"
    assert logger.handlers[1].filename == "../../test"
    options

# Generated at 2022-06-24 08:48:04.785076
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    formatter = LogFormatter()
    record = logging.LogRecord(name = 'name', level = logging.DEBUG, pathname = 'pathname',
                              lineno = 1, msg = '%s', args = (3,), exc_info = 'exc_info', func = 'func')
    record.__dict__['asctime'] = 'asctime'
    record2 = logging.LogRecord(name = 'name', level = logging.DEBUG, pathname = 'pathname',
                              lineno = 1, msg = '%s', args = ('我',), exc_info = 'exc_info', func = 'func')
    record2.__dict__['asctime'] = 'asctime'
    record.__setattr__('color', 'color')
    record.__set

# Generated at 2022-06-24 08:48:12.041725
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        formatter = LogFormatter()
    except TypeError:
        formatter = LogFormatter(color=False)
    record = logging.makeLogRecord({'name': 'my_name', 'levelno': logging.INFO, 'msg': 'my_msg', 'args': 'my_args', 'module': 'my_module', 'lineno': 'my_lineno'})
    formatter.format(record)


# Generated at 2022-06-24 08:48:12.779327
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass


# Generated at 2022-06-24 08:48:20.999579
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    assert LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT
    assert LogFormatter().datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert LogFormatter(style='%').datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert LogFormatter()._colors == LogFormatter.DEFAULT_COLORS
    assert LogFormatter()._normal == ''
    assert LogFormatter(color=False)._normal == ''
    assert LogFormatter(color=True)._normal != ''



# Generated at 2022-06-24 08:48:26.772471
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    suffix = "%(asctime)s %(message)s"
    for i in range(4):
        t = logging.Formatter(suffix)
        f = LogFormatter(datefmt="%H:%M:%S")
        s = t.format(logging.LogRecord("tornado", logging.INFO, "myfile", 3, "Just Test", None, None))
        assert f.format(logging.LogRecord("tornado", logging.INFO, "myfile", 3, "Just Test", None, None)) == s
        suffix = "%(asctime)s %(message)s " + suffix

# Generated at 2022-06-24 08:48:27.920689
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()

# Generated at 2022-06-24 08:48:38.712190
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.log
    import tornado.options
    import logging
    import logging.handlers
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "./test_log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_when = "s"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = False
    tornado.log.enable_pretty_logging()
    logger = logging.getLogger()
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 08:48:46.601466
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = "none"
    enable_pretty_logging(options)
    assert options.logging.lower() == "none"
    options.logging = "debug"
    enable_pretty_logging(options)
    assert options.logging.lower() == "debug"
    options.log_file_prefix = "log_file_prefix"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 3
    enable_pretty_logging(options)
    assert options.log_file_prefix != "log_file_prefix"
    options.log_file_prefix = "log_file_prefix"

# Generated at 2022-06-24 08:48:53.017138
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.TestCase.__init__(self)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    log_format = """%(asctime)s [%(levelname)s] %(message)s"""
    formatter = LogFormatter(fmt=log_format)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    logger.info("Example log message.")
    logger.debug("Example log message.")
    logger.error("Example log message.")
    logger.critical("Example log message.")


# Generated at 2022-06-24 08:48:55.148111
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)

# Generated at 2022-06-24 08:48:58.715710
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert hasattr(LogFormatter(), '_fmt')
    assert hasattr(LogFormatter(), '_colors')
    assert hasattr(LogFormatter(), '_normal')


# Generated at 2022-06-24 08:49:08.153255
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options()
    #log_rotate_mode
    assert options['log_rotate_mode'] == "size"
    options.parse_command_line(['--log_rotate_mode=time'])
    assert options['log_rotate_mode'] == "time"
    options.parse_command_line(['--log_rotate_mode=size'])
    assert options['log_rotate_mode'] == "size"
    try:
        options.parse_command_line(['--log_rotate_mode=test'])
        assert False
    except ValueError:
        pass
    #log_rotate_when
    assert options['log_rotate_when'] == "midnight"

# Generated at 2022-06-24 08:49:18.077961
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    options = tornado.options.options
    options.define("logging", default="info", help=("Set the Python log level. If 'none', tornado won't touch the logging configuration."), metavar="debug|info|warning|error|none")
    options.define("log_to_stderr", type=bool, default=None, help=("Send log output to stderr (colorized if possible). By default use stderr if --log_file_prefix is not set and no other logging is configured."))
    options.define("log_file_prefix", type=str, default=None, metavar="PATH", help=("Path prefix for log files. Note that if you are running multiple tornado processes, log_file_prefix must be different for each of them (e.g. include the port number)"))
   

# Generated at 2022-06-24 08:49:26.861572
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    options = tornado.options.options
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000 
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == 'midnight'
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == 'size'
    sys.exit()

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:49:27.471943
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert True

# Generated at 2022-06-24 08:49:35.007026
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("name", default="", help="name")  # noqa
    assert options.name is None
    parse_command_line(["--name", "foo"])
    assert options.name == "foo"  # noqa

test_define_logging_options()

# vim:set ai et ts=4 sw=4 sts=4 fenc=utf-8:

# Generated at 2022-06-24 08:49:38.226425
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    define_logging_options(options)
    print(options)


test_define_logging_options()

# Generated at 2022-06-24 08:49:46.087235
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    import logging
    # Build a fake record
    record = logging.LogRecord(
        "tornado.test", logging.INFO, "fake.py", 42, "test log record", None, None
    )
    # Build a fake logging stream that returns the "log stream text"
    mock_stream = io.StringIO()
    mock_stream.getvalue = lambda: "log stream text"
    # Build a temporary LogFormatter
    formatter = LogFormatter(fmt="%(levelname)s")
    # Check format method
    assert formatter.format(record) == "INFO"

# Generated at 2022-06-24 08:49:48.307242
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    pass

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:49:52.362412
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    logging.basicConfig(level=logging.INFO)
    handler = logging.StreamHandler()
    handler.setFormatter(LogFormatter(color=True))
    access_log.addHandler(handler)
    access_log.info('test')


# Generated at 2022-06-24 08:49:53.254967
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-24 08:49:54.454859
# Unit test for function define_logging_options
def test_define_logging_options():
    """The function is useless."""
    define_logging_options()

# Generated at 2022-06-24 08:50:04.944015
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    formatter = LogFormatter()

    record = logging.LogRecord("test", logging.DEBUG, "base", 123, "test", (), None)
    print(formatter.format(record))
    print("\n")

    record.levelno = logging.INFO
    print(formatter.format(record))
    print("\n")

    record.levelno = logging.WARNING
    print(formatter.format(record))
    print("\n")

    record.levelno = logging.ERROR
    print(formatter.format(record))
    print("\n")

    record.levelno = logging.CRITICAL
    print(formatter.format(record))


# Generated at 2022-06-24 08:50:14.373689
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()  # type: ignore



# Generated at 2022-06-24 08:50:25.349306
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options=tornado.options.OptionParser()
    options.define(
        "logging",
        default="none",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    options.parse_command_line()
    print(options.logging)
    define_logging_options(options)

# If this file is placed at flat directory,
# then the following code can be used to test the function.
# if __name__ == '__main__':
#     test_define_logging_options()
# Else if this file is included as a module,
# the following code can be used to test the function.
# tornado.options.enable

# Generated at 2022-06-24 08:50:34.976389
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.enable_pretty_logging()
    assert logging.getLogger().handlers
    tornado.options.enable_pretty_logging()
    assert len(logging.getLogger().handlers) == 1

# pandas.io.sql.read_frame fakes a DBAPI2 connection,
# so to use it with our Connection you must use
# pandas.io.sql.read_frame(query, cnxn)
# see http://pandas.pydata.org/pandas-docs/stable/io.html#db-api-fallback
# and http://pandas.pydata.org/pandas-docs/stable/remote_data.html#remote-data-sql

# Generated at 2022-06-24 08:50:46.090743
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_config_file, parse_command_line

    define("log_to_stderr", type=int, default=1)
    define("log_file_prefix", type=str, default=None)
    define("log_file_max_size", type=int, default=100 * 1000 * 1000)
    define("log_file_num_backups", type=int, default=10)
    define("log_rotate_when", type=str, default="midnight")
    define("log_rotate_interval", type=int, default=1)

    define("log_rotate_mode", type=str, default="size")

    define("logging", type=str, default="info")
    define_logging_options()


# Generated at 2022-06-24 08:50:53.654292
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)
    parser.parse_command_line(["--logging=debug",
                               "--log_file_prefix=./log/test.log",
                               "--log_file_max_size=1024",
                               "--log_file_num_backups=5",
                               "--log_rotate_when=midnight",
                               "--log_rotate_interval=2",
                               "--log_rotate_mode=time",
                               "--log_to_stderr=1"])
    print(parser.parse_command_line())
    # test_define_logging_options()

# Generated at 2022-06-24 08:51:02.239711
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    import inspect
    import logging

    assert inspect.getargspec(tornado.log.LogFormatter.__init__).args == ['self', 'fmt', 'datefmt', 'style', 'color', 'colors'] # noqa: E501,E999
    tf = tornado.log.LogFormatter()
    assert tf.datefmt == '%y%m%d %H:%M:%S'
    assert tf.format(logging.LogRecord('abc', tornado.log.logging.ERROR, None, None, '123', None, None)) == '[E None:0] 123' # noqa: E501,E999


# Generated at 2022-06-24 08:51:03.121072
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    print(type(formatter))
    #print(help(formatter))



# Generated at 2022-06-24 08:51:07.869399
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    #import tornado.options
    import unittest
    import os
    import sys


# Generated at 2022-06-24 08:51:18.604938
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import time
    import logging
    import os
    import sys
    import signal
    import atexit

    log_file_prefix = "./test_log"
    # from tornado.log import LogFormatter
    define_logging_options(tornado.options.options)
    tornado.options.parse_command_line([
        "--log_file_prefix=" + log_file_prefix,
        "--log_to_stderr=False",
        "--log_file_num_backups=1",
        "--log_file_max_size=1"
    ])
    logging.info("test")

    # write log again and check the size of log file
    logging.info("test")
    file_size = os.path.getsize(log_file_prefix)
    assert file_

# Generated at 2022-06-24 08:51:24.511731
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    lr = logging.LogRecord(
        name = 'test',
        level = 10,
        pathname = 'test_path',
        lineno = 1,
        msg = 'test_message',
        args = ('a', 'b'),
        exc_info = True,
    )
    rv = lf.format(lr)
    assert isinstance(rv, str)

# Generated at 2022-06-24 08:51:36.450803
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os
    import time
    import logging
    import shutil
    import sys
    import re

    #for time rotate
    rotate_mode = "time"
    log_file_prefix = "testing/log/testing_log"
    log_rotate_when = "S"
    log_rotate_interval = 1
    log_to_stderr =  True
    log_file_max_size = 10485760
    log_file_num_backups = 10

    #for size rotate
    # rotate_mode = "size"
    # log_file_prefix = "log/testing_log"
    # log_rotate_when = "S"
    # log_rotate_interval = 1
    # log_to_stderr =  True
    # log_file

# Generated at 2022-06-24 08:51:42.415852
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    t = LogFormatter()
    logger.handlers = []
    logger.propagate = False
    logger.addHandler(logging.StreamHandler(sys.stderr))
    logger.error(u"test exception", exc_info=1)
    logger.error(u"test string")

# Singleton log formatter instance
formatter = LogFormatter()  # type: Any


# Generated at 2022-06-24 08:51:47.063628
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    assert options.logging == 'info'
    assert options.log_to_stderr == None
    assert options.log_file_prefix == None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when=="midnight"
    assert options.log_rotate_mode=="size"
    assert options.log_rotate_interval==1

test_define_logging_options()



# Copyright 2009 Facebook
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy

# Generated at 2022-06-24 08:51:48.728936
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)

# Generated at 2022-06-24 08:51:49.826962
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _stderr_supports_color()



# Generated at 2022-06-24 08:51:54.246480
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    logging.basicConfig(level=logging.DEBUG, format='%(levelname)s %(message)s')
    log = logging.getLogger()
    log.debug('TestLogFormatterTest')


# Generated at 2022-06-24 08:51:58.608982
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord("tornado.test", logging.DEBUG, "", 0, "", (), None)).startswith("[D ")

# Test for method _stderr_supports_color()

# Generated at 2022-06-24 08:52:06.790464
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, parse_command_line, parse_config_file
    parse_command_line(args=['test-test.py', '--logging=none',
                             '--log_to_stderr=true'])
    enable_pretty_logging()
    assert options.logging.lower() == "none"
    assert options.log_to_stderr is True
    options.log_to_stderr = None
    enable_pretty_logging()
    assert options.log_to_stderr != False
    assert options.log_file_prefix != ''
    options.log_file_prefix = ''
    enable_pretty_logging()
    assert options.log_file_prefix != ''
    options.log_rotate_mode = "some"

# Generated at 2022-06-24 08:52:12.613814
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("name", logging.DEBUG, None, None, "msg", None, None)
    record.__dict__["asctime"] = "asctime_value"
    record.__dict__["levelno"] = logging.DEBUG
    record.__dict__["color"] = ""
    record.__dict__["end_color"] = ""
    assert formatter.format(record) == "asctime_value - [DEBUG name:] msg"
    record.__dict__["levelno"] = logging.INFO  # green
    assert formatter.format(record) == "asctime_value - [INFO name:] msg"
    record.__dict__["levelno"] = logging.WARNING  # yellow

# Generated at 2022-06-24 08:52:18.834021
# Unit test for function define_logging_options
def test_define_logging_options():
    # The test needs to create OptionParser instance to pass to function
    # define_logging_options
    import tornado.options
    import cmdline
    options = tornado.options.OptionParser()
    define_logging_options(options)
    # Add this line to make sure the OptionParser instance will not raise error
    options.parse_command_line([])
    # The test needs to use the defined logging options
    # to make sure that other functions work well.
    cmdline.main()
test_define_logging_options()

# Generated at 2022-06-24 08:52:28.915474
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("log_to_stderr", type=bool)
    tornado.options.define("logging", default="info")
    tornado.options.define("log_file_prefix", default="")
    tornado.options.define("log_file_max_size", default=0)
    tornado.options.define("log_file_num_backups", default=0)
    tornado.options.define("log_rotate_mode", default="size")
    tornado.options.define("log_rotate_when", default="D")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.parse_command_line("--logging=warn --log_rotate_mode=time --log_to_stderr=1")
    enable_pretty_

# Generated at 2022-06-24 08:52:33.816345
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """Test that tests that the logging works.
    """
    # pylint: disable=too-many-locals,too-many-branches
    import tornado.options
    import tornado.testing
    import logging
    import sys
    import textwrap
    import unittest


    class LoggingTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(LoggingTest, self).setUp()
            self.io_loop = self.get_new_ioloop()
            tornado.options.enable_pretty_logging()

        def test_logging(self):
            stderr = sys.stderr

            def stderr_replacement(self, msg, kwargs):  # type: ignore
                self.stderr_chunks.append(msg)

            sys.stder

# Generated at 2022-06-24 08:52:43.286875
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    from tornado import options
    def test_parse():
        options.define('test_logging_options', default="info", help='test')
        options.define('test_log_to_stderr', type=bool, default=True, help='test')
        options.define('test_log_file_prefix', type=str, default='./logs/test.log', help='test')
        options.define('test_log_file_max_size', type=int, default=100 * 1000 * 1000, help='test')
        options.define('test_log_file_num_backups', type=int, default=10, help='test')
        options.define('test_log_rotate_when', type=str, default="midnight", help='test')

# Generated at 2022-06-24 08:52:46.755057
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter('%(levelname)s %(message)s')
    assert f.format(logging.makeLogRecord({'levelname': 'info'})) == 'info '


STATSD_LOG_FORMAT = "%(client_ip)s %(method)s %(path)s %(response_code)d %(body_bytes_sent)d - %(request_time)f"  # noqa: E501



# Generated at 2022-06-24 08:52:59.112888
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import sys
    import logging

    import logging

    logging.basicConfig(level=logging.DEBUG, stream=sys.stderr, format="%(message)s")
    logger = logging.getLogger()

    # Create a custom logger
    name = "mylogger"
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # Create handlers
    c_handler = logging.StreamHandler()
    f_handler = logging.FileHandler('file.log')
    c_handler.setLevel(logging.WARNING)
    f_handler.setLevel(logging.ERROR)

    # Create formatters and add it to handlers

# Generated at 2022-06-24 08:53:05.241492
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("tornado.test", logging.INFO, pathname="", lineno=1, msg="foo", args=(), exc_info=None))  # noqa: E501

# Deprecated alias
DefaultsFormatter = LogFormatter

# Start time for Torando applications.
_start_time = None  # type: Optional[float]



# Generated at 2022-06-24 08:53:13.495190
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = '%(color)s[%(levelname)1.1s ' + \
          '%(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = '%y%m%d %H:%M:%S'
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt)
    assert formatter._colors is not None
    assert formatter._normal == ''


# Generated at 2022-06-24 08:53:15.400167
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options=None, logger=None)

# Generated at 2022-06-24 08:53:27.022885
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    instance = LogFormatter()
    name = 'test'
    level = 1
    pathname = '~/tornado/test/test_log.py'
    lineno = 1
    msg = 'test message'
    args = None
    exc_info = None
    func = pathname
    sinfo = 'test_log.py'
    record = logging.LogRecord(name, level, pathname, lineno, msg, args, exc_info, func)
    # record.__init__(name, level, pathname, lineno, msg, args, exc_info, func)
    expect = instance.format(record)
    assert expect == '[1 1970-01-01 08:00:00 test_log.py:1] test message'