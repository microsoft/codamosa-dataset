

# Generated at 2022-06-24 08:43:24.004145
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()



# Generated at 2022-06-24 08:43:24.843127
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    pass


# Generated at 2022-06-24 08:43:30.555274
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Mock(object):
        pass
    logger = logging.getLogger('')
    logFormatter = LogFormatter()
    logger.setLevel(logging.DEBUG)
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(logFormatter)
    logger.addHandler(streamHandler)
    record = Mock()
    record.levelno = logging.DEBUG
    record.msg = 'test message'
    record.args = {}
    record.exc_info = None
    record.exc_text = None
    logger.handle(record)



# Generated at 2022-06-24 08:43:32.791261
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import random

    arg = random.choice(['fmt', 'datefmt', 'style', 'color', 'colors'])
    assert hasattr(LogFormatter(), arg)

# Generated at 2022-06-24 08:43:35.287756
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): # type: ignore
    LogFormatter(fmt="%(color)s%(message)s", datefmt=None, style="%", color=True, colors={})  # noqa: E501

# Generated at 2022-06-24 08:43:37.725250
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.format("hello") is not None



# Generated at 2022-06-24 08:43:39.635221
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.enable_pretty_logging()

# Generated at 2022-06-24 08:43:41.009229
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    tornado.options.Options()
    define_logging_options()

test_define_logging_options()

# Generated at 2022-06-24 08:43:46.840731
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log

    tornado.options.parse_config_file("new_tornado_options.cfg")
    tornado.log.enable_pretty_logging()

    # print(tornado.options.options.logging)
    # print(tornado.options.options.log_file_prefix)
    # print(tornado.options.options.log_file_max_size)
    # print(tornado.options.options.log_file_num_backups)
    # print(tornado.options.options.log_rotate_mode)
    # print(tornado.options.options.log_rotate_when)
    # print(tornado.options.options.log_rotate_interval)


if __name__ == "__main__":
    test_enable_pretty_logging

# Generated at 2022-06-24 08:43:58.196068
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("testing enable_pretty_logging")
    # Skip this test on Windows; it fails mysteriously even when we tell
    # logging to not use colorama.
    import sys
    if sys.platform == "win32":
        return
    # Also skip if colorama is installed but curses is not
    # (the two libraries interfere with each other)
    try:
        import colorama
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None
    if colorama is not None and curses is None:
        return
    # This module is imported so many times during testing that
    # the test can't be run twice in the same process
    if "_test_logging" in sys.modules:
        return
    from tornado.options import options, define, parse_command_line
   

# Generated at 2022-06-24 08:43:59.156350
# Unit test for function define_logging_options
def test_define_logging_options():
    options = dict()
    define_logging_options(options)

# Generated at 2022-06-24 08:44:00.230153
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    option = OptionParser()
    define_logging_options(option)

# Generated at 2022-06-24 08:44:02.124095
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:44:10.849100
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = logging.Formatter()
    record = logging.LogRecord("tornado.application", logging.DEBUG, "", 0, "", (), None, None)
    record.args = ()

    record.message = "This is a test."
    assert fmt.format(record) == "This is a test."
    record.message = "This is\na test."
    assert fmt.format(record) == "This is\n    a test."

    record.asctime = "0123456789"
    record.levelno = logging.ERROR
    record.name = "tornado.application"
    record.filename = "test.py"
    record.module = "test"
    record.lineno = 12
    record.funcName = "test_function"
    record.process = 999

# Generated at 2022-06-24 08:44:15.020618
# Unit test for function define_logging_options
def test_define_logging_options():
    """
    测试函数
    :return: 
    """
    import tornado.options

    tornado.options.parse_command_line()
    print(tornado.options.options)

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:44:18.165528
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)

# Generated at 2022-06-24 08:44:29.057129
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(
        fmt="%(color)s%(asctime)s:%(msecs)03d%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
    )
    record = logging.LogRecord(
        "tornado.test", logging.DEBUG, "/fakepath", 22, "message", None, None
    )
    message = formatter.format(record)
    assert message.endswith(" message")
    assert message.startswith("\033[")



# Generated at 2022-06-24 08:44:38.081071
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()

    assert f.datefmt == f.DEFAULT_DATE_FORMAT
    assert f.style == "%"
    assert f.color

    def test_colors():
        for k, v in f.DEFAULT_COLORS.items():
            assert f.colors[k] == curses.tigetstr("setaf") or curses.tigetstr("setf") or b""

    test_colors()

    f = LogFormatter(colors={logging.ERROR: 36})
    assert f.colors[logging.ERROR] == "\033[2;3%dm" % 36

    f = LogFormatter(color=False)
    assert not f.color



# Generated at 2022-06-24 08:44:44.167135
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    def assert_safe_unicode(s):
        assert isinstance(s, unicode_type)
        assert isinstance(formatter.format(_LogRecord(s)), unicode_type)
    assert_safe_unicode("abc")
    assert_safe_unicode("\xe2\x98\x83")
    assert_safe_unicode("\xff")
    assert_safe_unicode(b"abc")
    assert_safe_unicode(b"\xe2\x98\x83")
    assert_safe_unicode(b"\xff")
    assert_safe_unicode(u"\xe2\x98\x83")
    assert_safe_unicode(u"\uffff")



# Generated at 2022-06-24 08:44:52.412385
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.CRITICAL: 5,
        logging.ERROR: 1,
        logging.DEBUG: 4,
        logging.INFO: 2,
        logging.WARNING: 3,
    }  # type: Dict[int, int]
    LogFormatter(fmt, datefmt, style, color, colors)

# TODO: get rid of this function

# Generated at 2022-06-24 08:45:03.401678
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
    except ImportError as e:
        return
    logger = logging.getLogger()

    try:
        assert len(logger.handlers) == 0
        enable_pretty_logging(None, logger)
        assert len(logger.handlers) == 1
        enable_pretty_logging(None, logger)
        assert len(logger.handlers) == 1
    finally:
        logger.handlers = []


# Generated at 2022-06-24 08:45:15.265323
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    from time import time
    x = LogFormatter()
    # assert x.format(logging.LogRecord('tornado.access',1, '/Users/brandon/Code/tornado/tornado/log.py',173, "GET /favicon.ico HTTP/1.1","82.98.86.33:1341", "200", "7866", "http://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&ved=0CCwQFjAB&url=http%3A%2F%2Fwww.tornadoweb.org%2F&ei=r6rMUoaoKJSr0QWQ6IG4CA&usg=AFQjCNHhQ2M1-

# Generated at 2022-06-24 08:45:27.231093
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("logging",default="info",help=('Set the Python log level. If '
                                          '"none",tornado won\'t touch the '
                                          'logging configuration.'),
            metavar="debug|info|warning|error|none",
            type=str)
    define("log_to_stderr",
            type=bool,
            default=None,
            help=('Send log output to stderr(colorized if possible). '
                  'By default use stderr if log_file_prefix is not set and '
                  'no other logging is configured.'))

# Generated at 2022-06-24 08:45:31.197564
# Unit test for function define_logging_options
def test_define_logging_options():
    tornado.options.define("a", default="b", help="a")
    tornado.options.define("c", default="d", help="c")
    define_logging_options()
    tornado.options.parse_command_line()


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:45:34.258213
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(fmt="%(message)s")
    record = logging.LogRecord(
        "tornado.general", logging.INFO, "/", 1, "test %r %r", [], None
    )
    msg = formatter.format(record)
    assert msg == "test %r %r"



# Generated at 2022-06-24 08:45:39.415033
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_command_line(['--logging=none'])
    assert tornado.options.options.logging == 'none'
    tornado.options.parse_command_line(['--logging=debug'])
    assert tornado.options.options.logging == 'debug'
    tornado.options.parse_command_line(['--logging=info'])
    assert tornado.options.options.logging == 'info'
    tornado.options.parse_command_line(['--logging=warn'])
    assert tornado.options.options.logging == 'warn'
    tornado.options.parse_command_line(['--logging=warning'])
    assert tornado.options.options.logging == 'warning'

# Generated at 2022-06-24 08:45:48.747537
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options, logging
    class Options(object):
        log_file_prefix = './log/log'
        log_to_stderr = True
        logging = 'debug'
        log_rotate_mode = 'time'
        log_rotate_when = 'D'
        log_rotate_interval = 1
        log_file_num_backups = 5
        @classmethod
        def define(cls, name, default=None, type=None, group=None, metavar=None):
            try:
                setattr(cls, name, default)
            except:
                print("log: %s %s %s %s %s" % (name, default, type, group, metavar))
    tornado.options.options = Options
    enable_pretty_logging()


# Generated at 2022-06-24 08:45:54.972910
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define(
        "logging"
    )
    tornado.options.define(
        "log_to_stderr"
    )
    tornado.options.define(
        "log_file_prefix"
    )
    tornado.options.define(
        "log_file_max_size"
    )
    tornado.options.define(
        "log_file_num_backups"
    )
    tornado.options.define(
        "log_rotate_when"
    )
    tornado.options.define(
        "log_rotate_interval"
    )
    tornado.options.define(
        "log_rotate_mode"
    )
    define_logging_options()

# Generated at 2022-06-24 08:46:00.261989
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    tornado.options.define_logging_options()
    tornado.options.parse_config_file("logging.conf")

    logging.info("Loading log configuration from logging.conf")
    logging.info("Finished loading log configuration from logging.conf")

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:46:01.565319
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.Options()
    define_logging_options(options)

# Generated at 2022-06-24 08:46:05.465889
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = True
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 1
    enable_pretty_logging()
    enable_pretty_logging(tornado.options.options)
    enable_pretty_logging(tornado.options.options, tornado.options.options)

# enable type check of function enable_pretty_logging
test_enable_pretty_logging()

# Generated at 2022-06-24 08:46:12.445907
# Unit test for function define_logging_options
def test_define_logging_options():
    # import tornado.options
    # options = tornado.options.define_logging_options()

    # options = TornadoOptions()
    # for k,v in options.items():
    #     print(k,v)

    # options = TornadoOptions()
    import tornado.options

    options = tornado.options.define_logging_options(options)

    options.parse_command_line(["--logging=debug"])

    logging.error('test')

# Generated at 2022-06-24 08:46:18.948575
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionError, define, options
    logging_option = [
        "logging",
        "log_rotate_mode",
        "log_file_prefix",
        "log_to_stderr",
        "log_file_max_size",
        "log_file_num_backups",
        "log_rotate_when",
        "log_rotate_interval"
    ]
    options.clear()
    define_logging_options(options)
    for name in logging_option:
        try:
            define(name)
        except OptionError:
            pass
        else:
            raise Exception("option %s is not defined" % name)
    options.clear()

# Generated at 2022-06-24 08:46:22.797039
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    Test for method format of class LogFormatter
    """
    _log_formatter = LogFormatter()
    assert isinstance(_log_formatter, LogFormatter), "Incorrect Type"


# Generated at 2022-06-24 08:46:32.777815
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # usual case
    fmt = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "/test/path", 777, "test message", {}, None)
    expected = "[I 20080617 21:57:01 /test/path:777] test message"
    assert fmt.format(record) == expected

    # test message is unicode
    record = logging.LogRecord("tornado.general", logging.INFO, "/test/path", 777, u"test message", {}, None)
    assert fmt.format(record) == expected

    # test message is bytes
    record = logging.LogRecord("tornado.general", logging.INFO, "/test/path", 777, b"test message", {}, None)
    assert fmt.format(record) == expected

    # test message is invalid bytes

# Generated at 2022-06-24 08:46:38.906956
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print(options)
    config = "logging = debug"
    config_list = [config]
    tornado.options.parse_config_file(config_list)
    print("after parse config file")
    print(options.logging)
    

#test_define_logging_options()

# Generated at 2022-06-24 08:46:43.325732
# Unit test for function define_logging_options
def test_define_logging_options():
    options = parse_command_line(['--log_rotate_mode=time', '--log_file_prefix=test'])
    define_logging_options(options)
    enable_pretty_logging(options)
    
test_define_logging_options()

# Generated at 2022-06-24 08:46:44.129063
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert 1

# Generated at 2022-06-24 08:46:50.615803
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    define("log_rotate_mode", "size", str, "")
    define("log_file_prefix", "test", str, "")
    define("log_file_max_size", 1024, int, "")
    define("log_file_num_backups", 10, int, "")
    define("logging", "debug", str, "")
    enable_pretty_logging(options)
    return True

# Generated at 2022-06-24 08:46:58.122733
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter = LogFormatter(fmt="%(message)s")
    formatter = LogFormatter(datefmt=None)

# Alias for tornado.options.parse_command_line
options = None  # type: Optional[Any]

# Alias for tornado.options.define
define = None  # type: Optional[Any]



# Generated at 2022-06-24 08:47:01.478454
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # basic functionality
    LogFormatter()
    LogFormatter(color=False)
    LogFormatter(color=True)


# Generated at 2022-06-24 08:47:03.506644
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # TODO: check if the command line argument log_to_stderr is not set
    assert 1 == 1
    pass

# Generated at 2022-06-24 08:47:09.877147
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "./log/test_log"	
    options.log_rotate_mode = "size"
    options.log_file_max_size_KB = 1000
    options.log_file_num_backups = 3
    enable_pretty_logging()

test_enable_pretty_logging()

# Generated at 2022-06-24 08:47:12.799221
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # this will raise an exception if the LogFormatter format() is incorrect
    _ = LogFormatter()
    _ = LogFormatter(style="%")
    _ = LogFormatter(style="{")



# Generated at 2022-06-24 08:47:21.766128
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class FakeLogRecord:
        def __init__(self, levelno, msg) -> None:
            self.levelno = levelno
            self.msg = msg

        def getMessage(self) -> Any:
            return self.msg

    fmt = LogFormatter()
    assert fmt.format(FakeLogRecord(logging.INFO, "foo")) == "[I foo]"
    assert fmt.format(FakeLogRecord(logging.DEBUG, "foo%s") % ("bar",)) == "[D foo%s]"  # noqa: E501



# Generated at 2022-06-24 08:47:26.631349
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    datefmt = "%y%m%d %H:%M:%S"
    fmt = "%(color)s[%(levelname)s %(asctime)s]%(end_color)s %(message)s"
    fmtr = LogFormatter(fmt, datefmt=datefmt)
    assert fmtr.datefmt == datefmt
    assert fmtr._fmt == "%(color)s[%(levelname)s %(asctime)s]%(end_color)s %(message)s"  # noqa: E501



# Generated at 2022-06-24 08:47:35.131103
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    import tempfile
    import unittest


    class TestLogFormatter(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.formatter = LogFormatter()
            self.filename = tempfile.mktemp()

        def tearDown(self):
            # cleanup
            self.logger.handlers = []
            try:
                os.remove(self.filename)
            except OSError:
                pass

        def _test_name(self, format_, name):
            handler = logging.FileHandler(self.filename, mode='w')
            handler.setLevel(logging.DEBUG)
            handler

# Generated at 2022-06-24 08:47:46.459001
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.Formatter.format
    assert LogFormatter.DEFAULT_FORMAT
    assert LogFormatter.DEFAULT_DATE_FORMAT
    assert LogFormatter.DEFAULT_COLORS
    assert LogFormatter.DEFAULT_COLORS[logging.DEBUG]
    assert LogFormatter.DEFAULT_COLORS[logging.INFO]
    assert LogFormatter.DEFAULT_COLORS[logging.WARNING]
    assert LogFormatter.DEFAULT_COLORS[logging.ERROR]
    assert LogFormatter.DEFAULT_COLORS[logging.CRITICAL]



# Generated at 2022-06-24 08:47:54.103384
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define("logging1", default="info", help="", metavar="debug|info|warning|error|none")
    tornado.options.define("log_to_stderr1", type=bool, default=None, help="")
    tornado.options.define("log_file_prefix1", default=None, metavar="PATH", help="")
    tornado.options.define("log_file_max_size1", type=int, default=100 * 1000 * 1000, help="")
    tornado.options.define("log_file_num_backups1", type=int, default=10, help="")
    tornado.options.define("log_rotate_when1", type=str, default="midnight", help="")

# Generated at 2022-06-24 08:48:04.932899
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    class TestLogger(object):

        def _log(self, level, msg, *args, **kwargs):
            if "exc_info" in kwargs:
                exc = kwargs["exc_info"]
                if isinstance(exc, Exception):
                    logging.exception("hello")
                else:
                    logging.critical("world")
        debug = lambda self, msg, *args, **kwargs: self._log(0, msg, *args, **kwargs)  # noqa: E501
        info = lambda self, msg, *args, **kwargs: self._log(1, msg, *args, **kwargs)  # noqa: E501
        warning = lambda self, msg, *args, **kwargs: self._log(2, msg, *args, **kwargs)  # noqa

# Generated at 2022-06-24 08:48:15.849895
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, parse_command_line, parse_config_file, define
    define("foo", type=str, help="foo help", callback=None)
    define("bad_option", type=str, help="foo help", callback=None)
    define("logging", type=str, help="foo help", callback=None)
    define("log_to_stderr", type=bool, help="foo help", callback=None)
    define("log_file_prefix", type=str, help="foo help", callback=None)
    define("log_file_max_size", type=int, help="foo help", callback=None)
    define("log_file_num_backups", type=int, help="foo help", callback=None)

# Generated at 2022-06-24 08:48:19.359239
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("test_logging", type=str, help="Do this.")
    logging_options = define_logging_options(options)
    assert logging_options.test_logging == "info"

# Generated at 2022-06-24 08:48:20.814496
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()

# Generated at 2022-06-24 08:48:26.047031
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import doctest
    import logging

    class LogFormatterDocTest(unittest.TestCase):
        def test_doctests(self):
            doctest.run_docstring_examples(
                LogFormatter,
                {},
                module_relative=False,
                optionflags=doctest.ELLIPSIS,
            )

    unittest.main()



# Generated at 2022-06-24 08:48:27.487828
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()


# Generated at 2022-06-24 08:48:34.571805
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    assert hasattr(formatter, "format") is True
    record = cast(logging.LogRecord, logging.LogRecord(
        name="test-name",
        level=logging.DEBUG,
        pathname="logger.py",
        lineno=100,
        msg="hello %s",
        args=["world"],
        exc_info=None,
    ))
    assert formatter.format(record) == "[D 100 logger.py:100] hello world"

# Generated at 2022-06-24 08:48:44.031825
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tempfile
    import os
    import shutil
    """
    Create a temporary directory
    """

    tmp_dir = tempfile.mkdtemp()
    old_dir = os.getcwd()
    os.chdir(tmp_dir)

    """
    Create a log_file
    """
    log_file = os.path.join(tmp_dir, 'test')
    log_file = log_file + '%s' % '.log'

    """
    Create a LogFormatter
    """
    log_formatter = LogFormatter()

    """
    Create a LogFileHandler
    """
    log_file_handler = logging.FileHandler(log_file)
    log_file_handler.setFormatter(log_formatter)

    """
    Get the Root logger
    """


# Generated at 2022-06-24 08:48:48.837005
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    class fake_record:

        def getMessage(self) -> str:
            return "abc"

    record = fake_record()
    assert fmt.format(record) == "abc"


# Generated at 2022-06-24 08:49:01.417855
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): # pragma: no cover
    assert getattr(
        LogFormatter(), '_colors'
    ) == LogFormatter.DEFAULT_COLORS
    assert getattr(
        LogFormatter(color=False), '_colors'
    ) == {}
    assert getattr(
        LogFormatter(colors={}), '_colors'
    ) == {}
    assert getattr(
        LogFormatter(colors={logging.CRITICAL: 0}), '_colors'
    ) == {logging.CRITICAL: '\x1b[2;30m'}
    # colorama support
    from io import StringIO
    import colorama
    colorama.init()
    color_formatter = LogFormatter(color=True)
    handler = logging.StreamHandler(StringIO())
    handler.set

# Generated at 2022-06-24 08:49:08.063838
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert formatter.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}

# Generated at 2022-06-24 08:49:09.212468
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:49:18.989525
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    class MockRecord(object):
        def __init__(self, levelno, msg, exc_info=None, exc_text=None, **kwargs):
            self.levelno = levelno
            self.msg = msg
            self.exc_info = exc_info
            self.exc_text = exc_text
            for k, v in kwargs.items():
                setattr(self, k, v)

        def getMessage(self):
            return self.msg

    colorama.init(strip=False)
    record = MockRecord(
        logging.DEBUG,
        "hello world",
        lineno=1,
        module='log_test',
        asctime='2015-10-29 18:52:38',
    )
    formatter = LogFormatter(color=True)

# Generated at 2022-06-24 08:49:19.605116
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-24 08:49:21.663315
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    parser = OptionParser()
    define_logging_options(options=options)


# Generated at 2022-06-24 08:49:24.898931
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=logging.DEBUG)
    enable_pretty_logging()
    logging.debug("test log")
    
test_enable_pretty_logging()


# Generated at 2022-06-24 08:49:32.241416
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf._fmt == lf.DEFAULT_FORMAT
    assert lf._datefmt == lf.DEFAULT_DATE_FORMAT
    assert lf._colors == lf.DEFAULT_COLORS


# Generated at 2022-06-24 08:49:36.858284
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.parse_config_file('../src/config.conf')
    tornado.options.options.log_file_num_backups = 2


# Generated at 2022-06-24 08:49:43.520364
# Unit test for function define_logging_options
def test_define_logging_options():
    import argparse
    import tornado.options

    parser = argparse.ArgumentParser()
    # 注意，这个函数只能调用一次，需要重新实例化一个对象才可以
    tornado.options.define_logging_options(parser)
    print(parser.parse_args())

# Generated at 2022-06-24 08:49:47.228980
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    a = LogFormatter()
    assert a._colors != {}
    a = LogFormatter(color=False)
    assert a._colors == {}
    a = LogFormatter(colors={1: 2})
    assert a._colors == {1: 2}



# Generated at 2022-06-24 08:49:56.911827
# Unit test for constructor of class LogFormatter

# Generated at 2022-06-24 08:49:58.866089
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.logging = "warning"
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:50:08.534145
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger()
    logger1 = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    logger1.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    handler1 = logging.StreamHandler()
    handler1.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    handler1.setFormatter(formatter)
    logger.addHandler(handler)
    logger.error('test error')
    logger1.addHandler(handler1)
    logger1.error('test error')



# Generated at 2022-06-24 08:50:15.208990
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.Logger('test')
    streamhandler = logging.StreamHandler()
    formatter = LogFormatter(fmt='%(color)s%(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    streamhandler.setFormatter(formatter)
    logger.addHandler(streamhandler)
    logger.info('Test info')
    logger.warn('Test warning')
    logger.error('Test error')
    logger.critical('Test critical')


# Generated at 2022-06-24 08:50:20.127810
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.options
    tornado.options.options.log_file_prefix = "test_log_file"
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    gen_log.error("Test log message")

# Generated at 2022-06-24 08:50:25.546101
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    assert LogFormatter._stderr_supports_color() == False
    if colorama is not None:
        colorama.init()

    assert LogFormatter._stderr_supports_color() == True

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = LogFormatter()
    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warn message')
    logger.error('error message')


# Generated at 2022-06-24 08:50:31.900298
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log = logging.getLogger("tornado.test_LogFormatter")
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(open("output.txt","w")))
    log.debug("test debug")
    log.info("test info")
    log.warning("test warning")
    log.error("test error")
    log.critical("test critical")
test_LogFormatter_format()

# Generated at 2022-06-24 08:50:32.309822
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-24 08:50:36.137061
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    assert fmt.format({"message": 'message'}) == "message"
    assert fmt.format({"message": "message", "asctime": "2019"}) == "[2019] message"



# Generated at 2022-06-24 08:50:38.023074
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

from tornado.testing import unittest
from tornado.options import define, options


# Generated at 2022-06-24 08:50:44.536242
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.testing import AsyncTestCase

    class TestLogFormatter(AsyncTestCase):
        def test_LogFormatter(self):
            formatter = LogFormatter(color=True)
            self.assertTrue(isinstance(formatter, logging.Formatter))

    formatter = LogFormatter(color=True)
    self.assertTrue(isinstance(formatter, logging.Formatter))


# Generated at 2022-06-24 08:50:53.113277
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()

# Generated at 2022-06-24 08:51:03.115280
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, define, parse_command_line
    define("foo", default=1, help="unit test for define_logging_options")
    define("logging", default="warning", help="logging--loglevel")
    define("log_to_stderr", default=False, help="log_to_stderr")
    define("log_file_prefix", default="a.log", help="log_file_prefix")
    define("log_file_max_size", default=10, help="log_file_max_size")
    define("log_file_num_backups", default=3, help="log_file_num_backups")
    define("log_rotate_when", default="W1", help="log_rotate_when")

# Generated at 2022-06-24 08:51:07.498764
# Unit test for function define_logging_options
def test_define_logging_options():
    import sys
    import inspect
    from tornado.options import OptionParser
    op = OptionParser()
    define_logging_options(op)
    op.add_parse_callback(lambda: enable_pretty_logging(op))
    op.parse_command_line([__file__])
    op.parse_command_line([__file__, "--logging=debug", "--log_file_prefix=log.txt"])


# Generated at 2022-06-24 08:51:08.319177
# Unit test for function define_logging_options
def test_define_logging_options():
    pass



# Generated at 2022-06-24 08:51:13.315631
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, OptionParser
    # test for function define_logging_options
    define_logging_options()
    assert options.log_rotate_mode == "size"
    parser = OptionParser()
    define_logging_options(options=parser)
    assert options.log_rotate_mode == "size"


# Generated at 2022-06-24 08:51:23.740923
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter(color=True)
    # create a mock LogRecord
    from tornado.log import LogRecord
    import io
    class MockLogRecord(LogRecord):
        @property
        def exc_tb(self):
            return [2, 3]

    record = MockLogRecord()
    record.levelname = 'level'
    record.asctime = "asctime"
    record.levelno = 1
    record.name = "name"
    record.exc_info = "exc_info"
    record.lineno = 5
    record.funcName = "funcName"
    record.pathname = "pathname"
    record.message = "message"

    # create a mock LogRecord for

# Generated at 2022-06-24 08:51:24.415612
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    assert True

# Generated at 2022-06-24 08:51:27.465292
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == LogFormatter.DEFAULT_COLORS



# Generated at 2022-06-24 08:51:38.740555
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmtr = LogFormatter()
    import datetime
    rec = logging.LogRecord(
        name="a",
        level=logging.DEBUG,
        pathname="b",
        lineno=1,
        msg="c",
        args=None,
        exc_info=None,
        func=None
    )
    date = datetime.datetime.fromtimestamp(1.1)
    rec.created = 1.1
    rec.msecs = 1.1
    rec.relativeCreated = 1.1
    rec.thread = 1
    rec.threadName = "Thread-2"
    text = fmtr.format(rec)

# Generated at 2022-06-24 08:51:45.520678
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        formatter = LogFormatter()
        record = logging.LogRecord(
            "name",
            logging.DEBUG,
            "/mnt/f/Code/Tornado/tornado/log.py",
            123,
            "message",
            None,
            None,
        )
        result = formatter.format(record)
        assert result == "[D 120915 01:42:27 log:123] message"
    except Exception as e:
        print(e)

# Generated at 2022-06-24 08:51:52.933093
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(
        fmt="%(color)s%(levelname)s:%(name)s:%(message)s%(end_color)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    record = logging.makeLogRecord(
        {"msg": "foo", "levelname": "INFO", "name": "mylog"}
    )
    formatter.format(record)

    # Base case: no colors.
    formatter = LogFormatter()
    assert not formatter._colors
    assert formatter._normal == ""
    record = logging.makeLogRecord(
        {"msg": "foo", "levelname": "INFO", "name": "mylog"}
    )

# Generated at 2022-06-24 08:51:55.645341
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert len(formatter._colors) > 0
    assert formatter._normal is not None

# Generated at 2022-06-24 08:52:05.349659
# Unit test for function define_logging_options
def test_define_logging_options():
    tornado.options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    tornado.options.define(
        "log_to_stderr",
        type=bool,
        default=None,
        help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."
        ),
    )

# Generated at 2022-06-24 08:52:06.559621
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    L = LogFormatter()
    assert isinstance(L, logging.Formatter)

# Generated at 2022-06-24 08:52:15.199123
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

_skip_patterns = (
    r"^tornado\.access",
    r"^tornado\.application",
    r"^tornado\.general",
    r"^boto\.",
    r"^s3transfer\.utils",
    r"^botocore\.",
    r"^tornado\.queues",
    r"^concurrent\.futures",
)


# These filter classes should be completely covered by unit tests
# in the test_logging module.

# Generated at 2022-06-24 08:52:22.903767
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    test_log = logging.getLogger("tornado.testing")
    test_log.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    record = logging.LogRecord(
        "test_log", logging.DEBUG, None, None, "message", None, None
    )
    result = formatter.format(record)
    assert result == "[D %s test_log:None] message" % (
        datetime.now().strftime("%y%m%d %H:%M:%S")
    )
    info_record = logging.LogRecord(
        "test_log", logging.INFO, None, None, "another message", None, None
    )
    result1 = formatter.format(info_record)

# Generated at 2022-06-24 08:52:29.913584
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    record = logging.LogRecord('name', logging.WARNING, 'pathname',
        1, 'msg %s', ('arg',), None)
    expected = "[W 100123 17:26:55 pathname:1] msg arg"
    actual = f.format(record)
    assert expected == actual
    record = logging.LogRecord('name', logging.WARNING, 'pathname',
        1, 'msg %s', ('arg',), None)
    expected = "[W 100123 17:26:55 pathname:1] msg arg"
    actual = f.format(record)
    assert expected == actual



# Generated at 2022-06-24 08:52:31.398289
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()



# Generated at 2022-06-24 08:52:35.754804
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line(['--log_rotate_mode=time'])
    enable_pretty_logging(options)
# Unit test finished

# Generated at 2022-06-24 08:52:36.897168
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()


# Generated at 2022-06-24 08:52:45.075477
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Case 1, showcolor = True,
    # Case 2, showcolor = False
    # Case 3, with exception
    # Case 4, with exception and encoding problem
    # Case 5, with exception and ascii_str
    class MockRecord:
        def __init__(self, showcolor, exc, ascii_str):
            self.asctime = "12:00:00"
            self.name = "tornado.general"
            self.levelno = 30
            self.levelname = "INFO"
            self.message = ""
            self.asctime = ""
            self.color = ""
            self.end_color = ""
            self.module = ""
            self.lineno = 0

            self.showcolor = showcolor
            self.exc_info = exc
            self.exc_text = None



# Generated at 2022-06-24 08:52:56.241667
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import datetime
    now = datetime.datetime.now()
    assert len(LogFormatter().format(logging.LogRecord('name', 10, '/path/to/file', 10, 'test', None, None))) == 0
    assert len(LogFormatter().format(logging.LogRecord('name', 10, '/path/to/file', 10, 'test', None, None, pathname='/path/to/file2'))) == 0
    assert len(LogFormatter(datefmt='%Y%m%d %H:%M:%S').format(logging.LogRecord('name', 10, '/path/to/file', 10, 'test', None, None, pathname='/path/to/file2'))) == 0

# Generated at 2022-06-24 08:52:57.695833
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    enable_pretty_logging(logger=app_log)
    enable_pretty_logging(options=None, logger=app_log)

# Generated at 2022-06-24 08:53:08.579527
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.disable(logging.CRITICAL)
    import tornado.options
    from tornado.options import define, options
    define('logging',default=None,type=str,help='log level')
    define('log_file_prefix',default='logfile.txt',type=str,help='log file name')
    define('log_rotate_mode',default='time',type=str,help='log mode,time or size')
    define('log_rotate_when',default='MIDNIGHT',type=str,help='time of log rotate,S or M')
    define('log_rotate_interval',default=1,type=int,help='time of log rotate,in hour,default is 1 hour')

# Generated at 2022-06-24 08:53:14.032182
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.parse_command_line(['--logging=None'])
    enable_pretty_logging(options,logger=None)
    assert options.logging == 'None'

# Generated at 2022-06-24 08:53:26.751925
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application, RequestHandler
    import re
    import locale
    import os

    # The log formatter class used by Tornado.
    log_formatter_class = LogFormatter

    class LogHandler(RequestHandler):
        def get(self):

            # Set up colour if we are in a tty and curses is installed
            channel = logging.StreamHandler()
            channel.setFormatter(LogFormatter())
            app_log.addHandler(channel)
            # Test the default value of logging 
            # AssertionError: ('error', None) != ('info', 'info')
            # so the output is not info
            assert (options.logging, options.logging.lower()) != ('info', 'info')
            # Test the