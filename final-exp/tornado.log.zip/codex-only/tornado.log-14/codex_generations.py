

# Generated at 2022-06-24 08:43:27.867727
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    enable_pretty_logging(options = None, logger = None)

# Generated at 2022-06-24 08:43:29.799514
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:43:35.247736
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('test_format')
    handler = logging.StreamHandler()
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.info('test logging')

'''
    test message
    /home/vfasky/Desktop/Github/Tornado-6.0.3/tornado/log.py:334
'''


# Generated at 2022-06-24 08:43:46.580625
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord("tornado.general", logging.DEBUG, "/home/foo/bar.py", 42, "This is a debug message", [], None)) == "[D 160325 11:29:33 bar:42] This is a debug message"
    assert LogFormatter().format(logging.LogRecord("tornado.general", logging.INFO, "/home/foo/bar.py", 42, "This is a info message", [], None)) == "[I 160325 11:29:33 bar:42] This is a info message"

# Generated at 2022-06-24 08:43:48.819956
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
   
    assert LogFormatter.format(LogFormatter(),"[There's a string here ! %s]") == "[There's a string here ! %s]"


# Generated at 2022-06-24 08:44:00.313768
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()
    assert _stderr_supports_color() == True
    assert LogFormatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert LogFormatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert LogFormatter.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}  # noqa: E501

# Generated at 2022-06-24 08:44:09.635870
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("log_rotate_mode", "size", type=str)
    tornado.options.define("log_rotate_when", "midnight", type=str)
    tornado.options.define("log_rotate_interval", 1, type=int)
    tornado.options.define("log_file_prefix", "test.log", type=str)
    tornado.options.define("log_file_num_backups", 1, type=int)
    tornado.options.define("log_file_max_size", 100, type=int)
    tornado.options.define("logging", "debug", type=str)
    tornado.options.define("log_to_stderr", True, type=bool)
    enable_pretty_logging()
    tornado.options.options.log_

# Generated at 2022-06-24 08:44:12.878411
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.ERROR, "some_path", 123, "test", [], None)
    formatter.format(record)

# Generated at 2022-06-24 08:44:17.121686
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)
    args = [
        "appname",
        "--logging",
        "debug",
        "--log_to_stderr",
        "True",
        "--log_file_prefix",
        "prefix",
        "--log_file_max_size",
        "10000",
        "--log_file_num_backups",
        "5",
        "--log_rotate_when",
        "midnight",
        "--log_rotate_interval",
        "7",
        "--log_rotate_mode",
        "time",
    ]
    tornado.options.parse_command_line(args)
    assert tornado.options.options.logging == "debug"
    assert tornado.options

# Generated at 2022-06-24 08:44:23.903788
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options

    tornado.options.define('log_file_prefix', default='tornado.log')
    tornado.options.define('log_rotate_interval', default=60)

    enable_pretty_logging()


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:44:24.567012
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-24 08:44:30.985072
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    fmt = "%(levelname)s %(name)s %(message)s"
    fmted = f.format(logging.LogRecord("name", logging.DEBUG, "path", 123, fmt, (), None, None))
    assert fmted.startswith("DEBUG")
    assert fmt in fmted


# Generated at 2022-06-24 08:44:40.480919
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    '''
    Test for function enable_pretty_logging
    '''
    import tornado.options
    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "TestFilePath"
    options.log_file_max_size = 100
    options.log_rotate_mode = "size"
    options.log_file_num_backups = 5
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    options.log_to_stderr = True
    try:
        enable_pretty_logging(options, None)
    except:
        assert False
    options.log_rotate_mode = "TestFilePath"

# Generated at 2022-06-24 08:44:48.336182
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord(
        "tornado.access", logging.INFO, "test.py", 666, "Test message", None, None
    )
    log_formatter = LogFormatter()
    result = log_formatter.format(record)
    print(result)
    assert result == "[I 01010000 0 test.py:666] Test message"

if __name__ == "__main__":
    test_LogFormatter_format()

# Generated at 2022-06-24 08:44:52.852074
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options = tornado.options.OptionParser().parse_args()[0]
    logger = logging.getLogger()
    enable_pretty_logging(logger=logger, options=tornado.options.options)


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:45:03.436186
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.log import LogFormatter, access_log
    import time
    import logging
    import string
    import unittest
    import mock
    import sqlite3
    import datetime
    import random
    import string
    import io
    import pprint
    import json
    import functools
    import os
    import sys
    import logging
    import tornado
    import psycopg2
    import psycopg2.extras

    from tornado import gen
    from tornado.log import LogFormatter
    from tornado.escape import json_decode, json_encode, utf8
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.log import app_log
    from tornado.options import define, options

# Generated at 2022-06-24 08:45:14.722740
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    default_format = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    default_date_format = "%y%m%d %H:%M:%S"
    default_colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    tmp = LogFormatter()
    assert tmp._fmt == default_format
    assert tmp._colors == {}
    assert tmp._normal == ""

# Generated at 2022-06-24 08:45:26.774469
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    if options is None:
        # late import to prevent cycle
        import tornado.options

        options = tornado.options.options
    options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    options.define(
        "log_to_stderr",
        type=bool,
        default=None,
        help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."
        ),
    )
    options

# Generated at 2022-06-24 08:45:28.027230
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    assert options.logging == "info"

# Generated at 2022-06-24 08:45:30.286246
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("name", "level", "path", 1, "message", [], None)
    assert formatter.format(record) == record.message



# Generated at 2022-06-24 08:45:33.115328
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    app_log.debug("This is a debug message")
    app_log.info("This is an info message")
    app_log.warning("This is a warning message")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:45:45.576682
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("log_rotate_interval", type=int)
    tornado.options.define("logging", type=str)
    tornado.options.define("log_to_stderr", type=bool)

    # Test default
    options = tornado.options.parse_config_file("tests/options_test.conf")
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:45:49.844695
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():  # noqa: MC0001
    """Unit test for function enable_pretty_logging"""
    # TODO: Test me
    pass

# Generated at 2022-06-24 08:45:55.742821
# Unit test for function define_logging_options
def test_define_logging_options():
    import unittest
    import tornado.options

    class OptionsTest(unittest.TestCase):
        def test_logging_options(self):
            tornado.options.define_logging_options()
            options = tornado.options.options
            self.assertIsNotNone(options.log_rotate_mode)
    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-24 08:45:56.794946
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # TODO:
    pass

# Generated at 2022-06-24 08:46:09.448016
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        def __init__(self):
            self.logging = None
            self.log_file_prefix = None
            self.log_rotate_mode = None
            self.log_file_max_size = None
            self.log_file_num_backups = None
            self.log_rotate_when = None
            self.log_rotate_interval = None
            self.log_to_stderr = None
    # Test the function enable_pretty_logging
    # without exception raised
    options = Options()
    options.logging = "debug"
    options.log_file_prefix = "test.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 10

# Generated at 2022-06-24 08:46:16.483435
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    from logging import StreamHandler, Formatter, getLogger, DEBUG, INFO, ERROR, WARNING
    logger = getLogger()
    logger.setLevel(DEBUG)
    stream_handler = StreamHandler()
    test_formatter = LogFormatter()
    stream_handler.setFormatter(test_formatter)
    logger.addHandler(stream_handler)
    logger.debug('Test XXX DEBUG')
    logger.info('Test XXX INFO')
    logger.error('Test XXX ERROR')
    logger.warning('Test XXX WARNING')


# Generated at 2022-06-24 08:46:22.717934
# Unit test for function define_logging_options

# Generated at 2022-06-24 08:46:25.692482
# Unit test for function define_logging_options
def test_define_logging_options():
    try:
        enable_pretty_logging()
    except Exception as e:
        pass
    define_logging_options(None)

# Generated at 2022-06-24 08:46:33.922942
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import io
    from tornado.options import _TestParser
    from tornado.log import enable_pretty_logging
    import logging

    def new_output():
        return io.StringIO()

    old_stderr = sys.stderr
    old_stdout = sys.stdout

# Generated at 2022-06-24 08:46:35.595464
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt=LogFormatter()



# Generated at 2022-06-24 08:46:46.734809
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # set up a mock logger class
    class MockLogger(object):
        def __init__(self, level: int, message: str, exc_info: Optional[bool] = None) -> None:
            self.levelno = level
            self.message = message
            self.exc_info = exc_info


# Generated at 2022-06-24 08:46:50.664062
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:46:52.437426
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:46:58.345945
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level = logging.ERROR)
    f = LogFormatter()
    record = logging.LogRecord("name","debug",None,None,None,None,None,None,None,"message")
    assert f.format(record) == f.formatTime(record,"") + " [DEBUG] message"

# Generated at 2022-06-24 08:47:04.087886
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    define_logging_options(tornado.options.options)

# Generated at 2022-06-24 08:47:05.590829
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(logger=gen_log)

# Generated at 2022-06-24 08:47:11.828180
# Unit test for constructor of class LogFormatter
def test_LogFormatter():    
    log_handler =logging.StreamHandler()
    log_handler.setFormatter(LogFormatter())
    gen_log.addHandler(log_handler)
    gen_log.info("this is test")


# Aliases for Tornado-defined log levels
tornado = logging.DEBUG
tornado_warning = logging.INFO + 1
tornado_error = logging.INFO + 2
tornado_critical = logging.INFO + 3



# Generated at 2022-06-24 08:47:18.196921
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert not hasattr(formatter, "_normal")
    formatter = LogFormatter(color=True)
    assert hasattr(formatter, "_normal")
    assert formatter._normal != ""
    formatter = LogFormatter(color=True, colors={})
    assert formatter._normal == ""



# Generated at 2022-06-24 08:47:29.124993
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter(color=True).format(logging.LogRecord('tornado', logging.INFO, 'myfile.py', 123, 'My message', None, None)) == '[I 123 test_log:123] My message'
    assert LogFormatter(color=True).format(logging.LogRecord('tornado', logging.DEBUG, 'myfile.py', 123, 'My message', None, None)) == '[D 123 test_log:123] My message'

####################
## Logging options
####################

# Application log options
DEFAULT_LOG_FILENAME = "tornado.log"

# Generated at 2022-06-24 08:47:41.884260
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # test for method format in class LogFormatter
    # create a LogFormatter
    formatter = LogFormatter()
    # get a message from the loger
    log = logging.getLogger("tornado.access")
    # create a record
    record = log.makeRecord(
    name='tornado.access',
    level=20,
    pathname='',
    lineno=0,
    msg='test',
    args=(),
    exc_info=None,
    func='',
    sin_text=None,
    lno=None,
    exc_info=None,
    )
    msg = formatter.format(record)
    assert msg == ('[I %s tornado.access:0] test' % (record.asctime,))

    record.levelno = 40

# Generated at 2022-06-24 08:47:45.075762
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:47:49.873554
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    define_logging_options()
    tornado.options.parse_command_line()
    assert tornado.options.options.logging == "info"

if __name__ == '__main__':
    import tornado.options

    define_logging_options()
    tornado.options.parse_command_line()
    assert tornado.options.options.logging == "info"

# Generated at 2022-06-24 08:47:54.853402
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True)
    record = logging.LogRecord(
        'name',
        logging.DEBUG,
        pathname='/tornado/log.py',
        lineno=80,
        msg='my message',
        args=None,
        exc_info=None)
    formatter.format(record)


# Generated at 2022-06-24 08:48:01.197537
# Unit test for function define_logging_options
def test_define_logging_options():
    options = {}
    define_logging_options(options)
    options = {"logging":"info","log_to_stderr":None,"log_file_prefix":None,"log_file_max_size":100000000,"log_file_num_backups":10,"log_rotate_when":"midnight","log_rotate_interval":1,"log_rotate_mode":"size"}
    enable_pretty_logging(options)
    

test_define_logging_options()

# Generated at 2022-06-24 08:48:06.238229
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    record = logging.LogRecord(None, logging.WARNING, None, 3, "Hello world", None, None)
    # 通过模拟LogRecord的返回断言测试
    assert formatter.format(record) == "[W 3]: Hello world"



# Generated at 2022-06-24 08:48:06.897556
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass



# Generated at 2022-06-24 08:48:08.893247
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_config_file("")

test_enable_pretty_logging()

# Generated at 2022-06-24 08:48:11.264165
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    L = LogFormatter()  # type: ignore


# Generated at 2022-06-24 08:48:22.827407
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
#    from tornado.options import options
#    options.logging = None
#    options.log_to_stderr = True
    logging.basicConfig(level = logging.DEBUG,
            format = '%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
            datefmt = '%a, %d %b %Y %H:%M:%S',
            filename = 'myapp1.log',
            filemode = 'a'
            )
    logger = logging.getLogger()
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    console.setFormatter(formatter)
    logger.addHandler(console)
    logger.debug("debug.....")

# Generated at 2022-06-24 08:48:34.572000
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    g = LogFormatter('%(asctime)s %(module)s:%(lineno)d')
    assert g._fmt == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa: E501
    h = LogFormatter(color=False)
    i = LogFormatter('%(asctime)s %(module)s:%(lineno)d', color=False)

# Generated at 2022-06-24 08:48:44.026761
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.testing
    from tornado.log import LogFormatter
    from tornado.log import gen_log

    class LoggingTest(tornado.testing.AsyncTestCase):
        def test_logging_option(self):
            options = tornado.options.OptionParser().parse_args(
                ["--logging=debug", "--log_to_stderr=1"]
            )
            self.assertEqual(options.logging, "debug")
            self.assertEqual(options.log_to_stderr, True)
            self.assertEqual(options.log_file_prefix, None)

            options = tornado.options.OptionParser().parse_args(
                ["--logging=none"]
            )
            self.assertEqual(options.logging, "none")


# Generated at 2022-06-24 08:48:57.395717
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    logging.basicConfig(level=logging.DEBUG,
			format='%(asctime)s %(levelname)-8s ' +
			'[%(filename)s %(funcName)s %(lineno)d]' +
			' %(message)s',
			datefmt='%a %d %b %Y %H:%M:%S')
    log = logging.getLogger('test')
    log.debug('test', exc_info=True)
    log.info('test', exc_info=True)
    log.warning('test', exc_info=True)
    log.error('test', exc_info=True)
    log.critical('test', exc_info=True)


# Generated at 2022-06-24 08:49:07.376435
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("logging", default="DEBUG")
    tornado.options.define("log_file_prefix")

    enable_pretty_logging()
    assert logging.getLogger().level == logging.DEBUG

    tornado.options.options.logging = "INFO"
    tornado.options.options.log_file_prefix = "test"
    enable_pretty_logging()
    assert logging.getLogger().level == logging.INFO

    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()
    assert len(logging.getLogger().handlers) == 0

    enable_pretty_logging()
    assert len(logging.getLogger().handlers) == 1

# Generated at 2022-06-24 08:49:08.286918
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter.format()

# Generated at 2022-06-24 08:49:18.151262
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # 1) test default fmt
    log_format = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    log_date_format = "%Y-%m-%d %H:%M:%S"
    formatter = LogFormatter(log_format, log_date_format)
    record = logging.LogRecord("logger", logging.DEBUG, None, 123, "Message", [], None)
    assert formatter.format(record) == "[DBG   2018-10-30 22:16:00] Message"
    # 2) test user specified format
    formatter = LogFormatter("%(message)s", "")
    record = logging.LogRecord("logger", logging.WARNING, None, 123, "Message", [], None)

# Generated at 2022-06-24 08:49:22.040597
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    try:
        assert(isinstance(log_formatter._colors, dict))
    except AssertionError:
        print("Fail")
        exit(1) # Bail out
    print("Success")



# Generated at 2022-06-24 08:49:30.364465
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # case 1:
    # object has 'msg' attr, and it is type of str
    record = logging.LogRecord(
        name="tornado.general",
        level=10,
        pathname="",
        lineno=0,
        msg="This is a message",
        args=(),
        exc_info=None,
    )
    formatter = LogFormatter()
    formatter.format(record)
    # case 2:
    # object has 'msg' attr, and it is type of bytes
    record.msg = b"This is a message"
    formatter.format(record)
    # case 3:
    # object has no 'msg' attr
    del record.msg
    record.message = "This is a message"
    formatter.format(record)
    # case 4:
   

# Generated at 2022-06-24 08:49:42.537424
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """Unit test constructor of class LogFormatter"""
    log_format = "default"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    date_format = "%y%m%d %H:%M:%S"
    formatter = LogFormatter(log_format, date_format, "%", color, colors)
    assert formatter._fmt == "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"  # noqa: E501



# Generated at 2022-06-24 08:49:51.228635
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    opt = tornado.options.options
    #test case 1
    opt.logging = "none"
    enable_pretty_logging(opt)
    print("test case 1 passed")
    #test case 2
    opt.logging = "info"
    opt.log_file_prefix = "test2.log"
    opt.log_file_max_size = 5
    opt.log_file_num_backups = 2
    enable_pretty_logging(opt)
    print("test case 2 passed")
    #test case 3
    opt.log_rotate_mode = "time"
    opt.log_rotate_when = "D"
    opt.log_rotate_interval = 1
    enable_pretty_logging(opt)
    print("test case 3 passed")
    #

# Generated at 2022-06-24 08:49:55.986235
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    class logrecord:
        message = "Unit test"
        asctime = "1970-01-01 00:00:00"
        color = ''
        end_color = ''
    assert f.format(logrecord) == "[U 0001-01-01 00:00:00 :0] Unit test"


# Generated at 2022-06-24 08:50:06.976422
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """testing __init__ for class LogFormatter"""
    # testing the default constructor
    log_formatter = LogFormatter()
    assert log_formatter._colors == LogFormatter.DEFAULT_COLORS
    assert log_formatter._normal == ""

    # testing when curses is available
    curses.setupterm()
    if curses.tigetnum("colors") > 0:
        log_formatter = LogFormatter()
        assert len(log_formatter._colors) == 5
        assert len(log_formatter._normal) == 6
    else:
        # testing the default constructor
        log_formatter = LogFormatter()
        assert log_formatter._colors == LogFormatter.DEFAULT_COLORS
        assert log_formatter._normal == ""



# Generated at 2022-06-24 08:50:15.792379
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define
    from tornado.log import enable_pretty_logging, gen_log
    enable_pretty_logging(logging=None)
    gen_log.info("No logging!")
    enable_pretty_logging()
    gen_log.info("Logging!")

    # test parsing command line arguments
    define("test_logging", type=str, default="none", help=("test logging command line arguments"))
    enable_pretty_logging(options=None)
    gen_log.info("No logging!")
    enable_pretty_logging()
    gen_log.info("Logging!")
    # test parsing configuration filr arguments
    enable_pretty_logging(options=None)
    gen_log.info("No logging!")
    enable_pretty_logging()
    gen_log

# Generated at 2022-06-24 08:50:27.152530
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter()
    logFormatter._normal = "normal"
    logFormatter._colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    record = logging.LogRecord("name", logging.INFO, "pathname", 1, "msg")
    record.exc_info = (Exception, Exception(), None)
    record.exc_text = "testExcText"
    record.message = "testMessage"
    record.__dict__["args"] = None
    record.__dict__["asctime"] = "testAsctime"
    record.__dict__["color"] = ""
    record

# Generated at 2022-06-24 08:50:30.253940
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    t = logging.LogRecord(None, None, None, None, 'message', None, None)
    f.format(t)
    return f



# Generated at 2022-06-24 08:50:38.093446
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("mylog", default=None)
    define_logging_options()
    parse_command_line()
    print(options.mylog)
    print(options.logging)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)
    print(options.log_to_stderr)


if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:50:39.375310
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None, None)
    assert True


# Generated at 2022-06-24 08:50:41.542713
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:50:43.418462
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter() # type: LogFormatter

_default_log_handler = None  # type: Optional[logging.Handler]



# Generated at 2022-06-24 08:50:52.411693
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Defaults for `parse_command_line` and `parse_config_file`
LOGGING_FORMAT = (
    "%(color)s%(levelname)s%(end_color)s %(asctime)s [%(process)d] "
    "[%(filename)s:%(funcName)s:%(lineno)d] %(message)s"
)

# Generated at 2022-06-24 08:50:53.446041
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-24 08:51:00.853628
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    logger = logging.getLogger()
    #  Add custom handler
    logger.addHandler(logging.StreamHandler())
    #  Test when color support is disabled
    formatter = LogFormatter(color=False)
    assert formatter._normal == ""
    #  Test when colorama is not installed
    formatter = LogFormatter(color=True)
    assert formatter._normal == ""
    #  Test when colorama is installed
    formatter = LogFormatter(color=True)
    assert formatter._normal == "\033[0m"


# Generated at 2022-06-24 08:51:02.228767
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None)
test_enable_pretty_logging()

# Generated at 2022-06-24 08:51:07.000212
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options

    # Create a dummy options file
    tornado.options.options.logging = "none"
    tornado.options.options.log_file_prefix = ""
    tornado.options.options.log_file_max_size = 0
    tornado.options.options.log_file_num_backups = 0
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_to_stderr = False
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1

    # Call the function
    enable_pretty_logging()


# Direct tests for check_stderr_supports_color()

# Generated at 2022-06-24 08:51:17.364289
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    args = ["log_file_prefix=a.py","log_file_max_size=100","log_file_num_backups=10",
            "log_rotate_when=midnight","log_rotate_interval=1","log_rotate_mode=size"]
    tornado.options.parse_command_line(args=args)
    assert options.log_file_prefix == "a.py"
    assert options.log_file_max_size == 100
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

# Generated at 2022-06-24 08:51:20.315917
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("logging", type=str, default="none", help="one of none, debug, info, warning, error, or critical")
    options.parse_command_line()
    enable_pretty_logging()
    gen_log.info("info test")
    gen_log.error("error test")


# Generated at 2022-06-24 08:51:25.235558
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter(
        fmt=LogFormatter.DEFAULT_FORMAT,
        datefmt=LogFormatter.DEFAULT_DATE_FORMAT,
        style="%",
        color=True,
        colors=LogFormatter.DEFAULT_COLORS,
    )
    assert lf._normal

# initialize colorama
test_LogFormatter()



# Generated at 2022-06-24 08:51:37.416051
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest
    import tempfile
    import os
    import shutil
    import tornado.options

    class TempDirectoryTest(unittest.TestCase):
        def setUp(self) -> None:
            self.temp_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.temp_dir)

    class OptionsTest(TempDirectoryTest):
        def setUp(self) -> None:
            super(OptionsTest, self).setUp()
            self.addCleanup(tornado.options.reset)

            tornado.options.define("log_file_prefix", self.temp_dir + "/test_log")
            tornado.options.define("log_file_max_size", 100000)
            tornado.options.define("log_file_num_backups", 3)
           

# Generated at 2022-06-24 08:51:47.958988
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    DEFAULT_FORMAT1 = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    DEFAULT_DATE_FORMAT1 = "%y%m%d %H:%M:%S"
    DEFAULT_COLORS = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    lf = LogFormatter(DEFAULT_FORMAT1, DEFAULT_DATE_FORMAT1, colors=DEFAULT_COLORS)
    log_record

# Generated at 2022-06-24 08:51:59.277456
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    test_options = {
        "logging": "None",
        "log_to_stderr" : "True",
        "log_file_prefix" : "testlog.txt",
        "log_file_max_size" : "4096",
        "log_file_num_backups" : "3",
        "log_rotate_when" : "midnight",
        "log_rotate_interval" : "1",
        "log_rotate_mode" : "size"
    }

    from tornado.options import parse_command_line
    parse_command_line(test_options)

# Generated at 2022-06-24 08:52:04.441346
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    from io import StringIO
    import logging.config

    sio = StringIO()
    handler = logging.StreamHandler(sio)
    handler.setFormatter(LogFormatter(color=True))

    root = logging.getLogger()
    root.addHandler(handler)

    test_logger = logging.getLogger('test_LogFormatter_format')
    test_logger.info('test_LogFormatter_format')


# This can't be called from the module because LogFormatter
# isn't yet defined at import time.

# Generated at 2022-06-24 08:52:09.471110
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger("test")
    logger.level = logging.DEBUG

    handler = logging.StreamHandler()
    fmt = """
%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s
%(message)s
"""

    handler.setFormatter(LogFormatter(fmt=fmt))
    logger.addHandler(handler)
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")



# Generated at 2022-06-24 08:52:12.692354
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    enable_pretty_logging(options)
    assert len(logging.getLogger().handlers)==2

# Generated at 2022-06-24 08:52:23.767530
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options; from tornado.options import options
    from tornado.log import app_log, access_log, gen_log, enable_pretty_logging
    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("log_rotate_interval", type=int)
    tornado.options.define("logging", type=str)
    tornado.options.define("log_to_stderr", type=bool)
    # test default
    options.log

# Generated at 2022-06-24 08:52:35.968480
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tempfile
    import os.path
    import tornado.options

    fname = tempfile.mktemp(prefix='tornado_test')

# Generated at 2022-06-24 08:52:37.048308
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-24 08:52:38.049228
# Unit test for function define_logging_options
def test_define_logging_options():
    assert True  # for dummy


# Generated at 2022-06-24 08:52:43.976881
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from logging import StreamHandler, getLogger
    getLogger().handlers = []
    logger = getLogger()
    handler = StreamHandler()
    handler.setFormatter(LogFormatter())
    logger.addHandler(handler)
    logger.critical("Test")


# Generated at 2022-06-24 08:52:50.403346
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setFormatter(LogFormatter())
    logging.getLogger().addHandler(handler)
    logging.info("TEST INFO")
    logging.debug("TEST DEBUG")
    logging.warning("TEST WARNING")
    logging.error("TEST ERROR")

# test_LogFormatter_format()



# Generated at 2022-06-24 08:53:01.776054
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    # tornado.options.parse_command_line(['--logging=debug', '--log_file_prefix=./logs/test_log', '--log_to_stderr=False', '--log_rotate_mode=size'])
    tornado.options.parse_command_line()
    define_logging_options()
    # enable_pretty_logging()
    gen_log.warning("hello")
    gen_log.warning("hello")
    gen_log.warning("hello")
    gen_log.warning("hello")
    gen_log.warning("hello")
    gen_log.warning("hello")
    gen_log.warning("hello")
    gen_log.warning("hello")
    gen_log.warning("hello")

# Generated at 2022-06-24 08:53:07.157308
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    import tornado.util
    import tornado.log
    import tornado.platform.auto
    import tornado.platform.asyncio
    tornado.util.set_default_logging_class(tornado.log.AppLogFormatter)
    tornado.options._parse_command_line_args()
    tornado.log.enable_pretty_logging()


# Generated at 2022-06-24 08:53:20.920823
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line(['--logging=debug'])
    options.parse_command_line(['--log_to_stderr=true'])
    options.parse_command_line(['--log_file_prefix=./tornado.log'])
    options.parse_command_line(['--log_file_max_size=10*1000*1000'])
    options.parse_command_line(['--log_file_num_backups=2'])
    options.parse_command_line(['--log_rotate_when=H'])
    options.parse_command_line(['--log_rotate_interval=2'])

# Generated at 2022-06-24 08:53:30.663426
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    l = LogFormatter()
    r = logging.LogRecord("tornado.general", logging.DEBUG,
                          "/foo/bar/baz.py", 42, "flup", None, None)
    r.message = "The quick brown fox jumps over the lazy dog."
    r.levelname = "DEBUG"
    r.name = "tornado.general"
    r.asctime = "2015-08-03 18:05:16,282"
    r.pathname = "/foo/bar/baz.py"
    r.lineno = 42
    r.module = "foo"
    r.funcName = "bar"
    r.process = 666
    r.processName = "flub"
    r.thread = 42
    r.threadName = "flup"
    r.exc_info = None
