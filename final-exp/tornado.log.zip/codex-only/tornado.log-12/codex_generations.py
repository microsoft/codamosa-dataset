

# Generated at 2022-06-24 08:43:27.884979
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:43:28.911481
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    tornado.options.define_logging_options()

# Generated at 2022-06-24 08:43:32.747112
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.options

    try:
        options.port
    except tornado.options.Error:
        pass
    else:
        raise Exception("options.port should be undefined")
    define_logging_options(options)
    try:
        options.port
    except tornado.options.Error:
        raise Exception("options.port should be defined now")

if __name__ == "__main__":
    test_define_logging_options()
    print("test finished")

# Generated at 2022-06-24 08:43:43.883034
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def test_case(message: Any, expected: str) -> None:
        class FakeRecord(object):
            __slots__ = ["message", "levelno", "exc_text", "exc_info", "__dict__"]

            def __init__(
                self,
                message: Any,
                levelno: Optional[int] = None,
                exc_text: Optional[str] = None,
                exc_info: Optional[Any] = None,
            ) -> None:
                self.message = message
                self.levelno = levelno
                self.exc_text = exc_text
                self.exc_info = exc_info
                self.__dict__ = {}

        formatter = LogFormatter()
        record = FakeRecord(message)
        actual = formatter.format(record)
        print(actual, expected)

# Generated at 2022-06-24 08:43:46.090403
# Unit test for function define_logging_options
def test_define_logging_options():
    # (1) test exception
    from tornado.options import define, options, parse_command_line
    define("log_rotate_mode", type=str, default="time", help="The mode of rotating files(time or size)")
    parse_command_line()


# Generated at 2022-06-24 08:43:46.947092
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()
test_define_logging_options()

# Generated at 2022-06-24 08:43:58.335186
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import unittest
    import logging.config
    logging.config.dictConfig({
        'version': 1,
        'formatters': {
            'myformatter': {
                '()': LogFormatter,
                'format': '%(name)s : %(message)s',
                'color': True,
                'datefmt': '%m %d %H:%M:%S'
            }
        },
        'handlers': {
            'myhandler': {
                'class': 'logging.StreamHandler',
                'formatter': 'myformatter',
                'level': 'DEBUG'
            }
        },
        'root': {
            'level': 'DEBUG',
            'handlers': ['myhandler']
        }
    })
    logging.getLogger('foo').warning('Test')

# Generated at 2022-06-24 08:44:01.065670
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()

# Generated at 2022-06-24 08:44:02.802512
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    assert True


# Generated at 2022-06-24 08:44:10.444017
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import io
    import unittest
    import sys
    import io
    from tornado.log import LogFormatter, app_log
    from tornado.log import access_log

    class TestHandler(logging.StreamHandler):
        def __init__(self):
            super().__init__(io.StringIO())
            self.setFormatter(LogFormatter())

        def get_records(self):
            return self.stream.getvalue().split('\n')

    class LogFormatterTestCase(unittest.TestCase):
        def test_format(self):
            handler = TestHandler()
            app_log.addHandler(handler)
            app_log.warning('test warning')
            rec = handler.get_records()[0]

# Generated at 2022-06-24 08:44:22.193897
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    ##
    ## This test case is for testing the function enable_pretty_logging
    ## in module logging.
    #
    options.log_file_prefix = 'C:\\Users\\Administrator\\Desktop\\Tornado\\tornado_project\logs\\tornado.log'
    options.logging = 'debug'
    options.log_rotate_mode = 'time'
    options.log_rotate_when = 'S'
    options.log_rotate_interval = 1
    options.log_file_num_backups = 5
    options.log_to_stderr = True
    enable_pretty_logging()
    #
    ## This test case is for testing when to log something.
    #
    log_info = logging.getLogger("tornado.application")

# Generated at 2022-06-24 08:44:32.981758
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # noqa: F811, E501
    from tornado.util import ObjectDict as OD
    record = OD(message = "test %(hi)s")

# Generated at 2022-06-24 08:44:41.855426
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = tornado.options.options
    options.define("logging", None, str)
    options.define("log_file_prefix", None, str)
    options.define("log_to_stderr", None, str)
    options.define("log_rotate_mode", None, str)
    options.define("log_file_max_size", None, str)
    options.define("log_file_num_backups", None, str)
    options.define("log_rotate_when", None, str)
    options.define("log_rotate_interval", None, str)
    options.logging = "debug"
    options.log_file_prefix = "/var/log/tornado/test.log"
    options.log_to_stderr = True
    options.log_rotate_mode

# Generated at 2022-06-24 08:44:51.028347
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class R(object):
        pass

    r = R()
    r.message = "test"
    r.asctime = "now"
    r.levelno = logging.DEBUG
    r.__dict__ = {"message": "test", "asctime": "now", "levelno": logging.DEBUG}

    f = LogFormatter()
    assert f.format(r) == "[D now <unknown module>:0] test"

    # In test mode, we always get color
    f = LogFormatter(color=False)
    assert f.format(r) == "[D now <unknown module>:0] test"
    f = LogFormatter(color=True)
    assert f.format(r) == "\x1b[2;34m[D now <unknown module>:0]\x1b[0m test"

   

# Generated at 2022-06-24 08:44:52.402084
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    print(formatter)



# Generated at 2022-06-24 08:44:56.798318
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print(LogFormatter().format('\n'))

if __name__ == "__main__":
    test_LogFormatter_format()

# Generated at 2022-06-24 08:45:00.424204
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    g = LogFormatter(fmt="%(asctime)s")
    assert f._fmt == g._fmt
    assert f._colors == g._colors
    assert f._normal == g._normal
    assert f.datefmt == g.datefmt
    assert f is not g
    assert f is not LogFormatter()
    assert f.__class__ is LogFormatter



# Generated at 2022-06-24 08:45:13.052366
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.Logger.manager.loggerDict.clear()
    fmt = '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'
    datefmt = '%y%m%d %H:%M:%S'
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt, color=True, colors=colors)
    assert formatter
    assert formatter.datefmt == datefmt
    assert formatter._

# Generated at 2022-06-24 08:45:22.420466
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    if options is not None:
        define_logging_options(options)
        try:
            options.parse_command_line()
            print("test_define_logging_options!")
        except Exception as e:
            print(e.__traceback__)
            print(e.__cause__)
            print(e.__suppress_context__)
            print(e.__traceback__.tb_next)
            raise e
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:45:32.261712
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    class options_:
        def __init__(self) -> None:
            self.opts = dict()

        def define(self, name: str, type: Any = None, default: Any = None, help: Any = None, metavar: str = None) -> None:
            '''
            :param name:
            :param type:
            :param default:
            :param help:
            :param metavar:
            :return:
            '''
            opt = dict()
            opt['type'] = type
            opt['default'] = default
            opt['help'] = help
            opt['metavar'] = metavar
            self.opts[name] = opt

        def __getitem__(self, item: str) -> Any:
            return options_.dummy()

# Generated at 2022-06-24 08:45:33.756187
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging="none"
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-24 08:45:45.705348
# Unit test for function define_logging_options
def test_define_logging_options():
    # type: (Any) -> None
    from tornado.options import define, options, parse_command_line
    define("foo")
    define("bar")
    define("logging", type=str)
    define("log_to_stderr", type=str)
    define("log_file_prefix", type=str)
    define("log_file_max_size", type=str)
    define("log_file_num_backups", type=str)
    define("log_rotate_when",type=str)
    define("log_rotate_interval",type=str)
    define("log_rotate_mode",type=str)
    #print(options.foo)
    parse_command_line()
    print(options.foo)  # print --foo value

# Generated at 2022-06-24 08:45:58.388560
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    class _opts(object):
        logging = None
        log_file_prefix = "None"
        log_rotate_mode = "size"
        log_file_max_size = 1024
        log_file_num_backups = 5
        log_to_stderr = False
    enable_pretty_logging(_opts)
    assert len(logging.getLogger().handlers) == 0
    _opts.logging = "debug"
    _opts.log_file_prefix = "test.log"
    enable_pretty_logging(_opts)
    assert len(logging.getLogger().handlers) == 1
    _opts.log_to_stderr = True
    enable_pretty_logging(_opts)

# Generated at 2022-06-24 08:46:00.577067
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options=tornado.options.options
    define_logging_options(options)

# Generated at 2022-06-24 08:46:03.528943
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(datefmt='%H:%M:%S')
    assert isinstance(formatter, logging.Formatter)



# Generated at 2022-06-24 08:46:09.222371
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level = logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.info('info')
    logger.debug('debug')
    logger.error('error')

if __name__ == '__main__':
    test_LogFormatter_format()

# Generated at 2022-06-24 08:46:12.418058
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
    # assert options.log_rotate_when == "midnight"
    print(options)

# Generated at 2022-06-24 08:46:14.962201
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    opts = OptionParser()
    define_logging_options(options = opts)
    print(opts)
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:46:22.411155
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()

    fmt1 = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    fmt2 = "%(message)s"

    # Without color support
    formatter = LogFormatter(color=False, fmt=fmt1)
    assert formatter.format(logging.makeLogRecord({"msg": "hi"})) == "[I 20170101 00:00:00 test:0] hi"

    # With color support
    formatter = LogFormatter(color=True, fmt=fmt1)

# Generated at 2022-06-24 08:46:27.724324
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    op = tornado.options.OptionParser()
    define_logging_options(op)
    op.parse_command_line()
    # Repeat tests.
    define_logging_options(op)
    op.parse_command_line()
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:46:31.593673
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    string = '{0}'
    string = string.format(123)
    # string = string.format(_safe_unicode('as'))
    print(string)



# Generated at 2022-06-24 08:46:34.159459
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter=LogFormatter();
    log_formatter.format(record='',message='',exc_info='')

# Generated at 2022-06-24 08:46:44.060032
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    tornado.options.define("logging", default=None)
    tornado.options.define("log_file_prefix", default=None)
    tornado.options.define("log_rotate_mode", default=None)
    tornado.options.define("log_file_max_size", default=None)
    tornado.options.define("log_file_num_backups",default=None)
    tornado.options.define("log_rotate_when", default=None)
    tornado.options.define("log_rotate_interval",default=None)
    tornado.options.define("log_to_stderr", default=None)
    enable_pretty_logging()

# Generated at 2022-06-24 08:46:49.738918
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()

    # Check that class has right attributes
    assert lf.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert lf._fmt == LogFormatter.DEFAULT_FORMAT
    assert lf._colors == LogFormatter.DEFAULT_COLORS
    assert lf._normal == ''



# Generated at 2022-06-24 08:46:55.376406
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.log_file_prefix = "file_pre"
    options.log_file_num_backups = 5
    options.log_file_max_size = 2000
    options.log_to_stderr = True
    options.log_rotate_mode = "size"
    options.log_rotate_when = "M"
    options.log_rotate_interval = 10
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:47:05.846117
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import logging
    from pprint import pprint

    # Make a test logger
    logger = logging.getLogger("tornado.test")
    logger.setLevel(logging.DEBUG)

    # Make a handler that writes to a string (which we'll use later)
    import io
    out = io.StringIO()
    handler = logging.StreamHandler(out)

    # Make a formatter with the custom format
    formatter = LogFormatter(fmt="%(message)s")
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Log some stuff and print what's been logged
    logger.debug("Debug message")
    pprint(out.getvalue())

    # Clean up and check that everything was closed properly
    logger.removeHandler(handler)
   

# Generated at 2022-06-24 08:47:08.919812
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    l = LogFormatter()
    l.format(logging.LogRecord("test name", "test level", "test pathname", 99,
                               "test message", None, None))

# Generated at 2022-06-24 08:47:17.720095
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    import sys
    import logging
    import os
    import shutil
    import time
    logger = logging.getLogger()
    parser = OptionParser()
    define_logging_options(parser)
    parser.parse_command_line([
        "--logging=debug",
        "--log_to_stderr=False",
        "--log_file_prefix=log_file_prefix",
        "--log_file_num_backups=2",
        "--log_rotate_when=S",
        "--log_rotate_interval=1",
        "--log_rotate_mode=time"
    ])
    for i in range(0,10):
        logger.log(20,"message %s"%i)
    time.sleep(2)


# Generated at 2022-06-24 08:47:28.751235
# Unit test for function define_logging_options
def test_define_logging_options():
    # this methods didn't have unit test before, add one for it
    from tornado.options import OptionParser, options
    parser = OptionParser()
    define_logging_options(options)
    parser.parse_command_line(['--logging', 'debug', '--log_to_stderr', 'True',
                               '--log_file_prefix', '/log_file',
                               '--log_rotate_when', 'S',
                               '--log_rotate_mode', 'time'])
    assert options.logging == 'debug'
    assert options.log_to_stderr == True
    assert options.log_file_prefix == '/log_file'
    assert options.log_rotate_when == 'S'
    assert options.log_rotate_mode == 'time'

# Generated at 2022-06-24 08:47:34.979092
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    define("logging", type=str, default="warning")
    define("log_file_prefix", type=str, default="app.log")
    define("log_rotate_mode", type=str, default="size")
    define("log_rotate_when", type=str, default="S")
    define("log_rotate_interval", type=int, default=1)
    define("log_file_num_backups", type=int, default=10)

    enable_pretty_logging(options)

test_enable_pretty_logging()

# Generated at 2022-06-24 08:47:37.654261
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(options = tornado.options)

# Generated at 2022-06-24 08:47:47.821726
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options as options
    import tornado.log
    import logging
    import logging.handlers
    logger = logging.getLogger()
    handler1 = logging.StreamHandler()
    handler2 = logging.handlers.RotatingFileHandler(
        filename="log_file_prefix",
        maxBytes=1024,
        backupCount=11,
        encoding="utf-8"
    )
    handler3 = logging.handlers.TimedRotatingFileHandler(
        filename="log_file_prefix",
        when="log_rotate_when",
        interval=11,
        backupCount=11,
        encoding="utf-8",
    )

# Generated at 2022-06-24 08:47:54.895461
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    class Record:
        pass
    record = Record()
    record.getMessage = (lambda: 'one')
    record.message = ''
    record.asctime = ''
    record.color = None
    record.end_color = None
    record.exc_info = None
    record.exc_text = None
    record.levelno = 0
    record.__dict__ = {'color': None, 'end_color': None, 'message': 'one', 'asctime': '', 'levelno': 0}
    print(f.format(record))
    record = Record()
    record.getMessage = (lambda: u'one')
    record.message = ''
    record.asctime = ''
    record.color = None
    record.end_color = None
    record.exc

# Generated at 2022-06-24 08:47:56.874536
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()  # type: ignore

# Singleton configurator object - assigns configs as class attributes
_configurator = logging.config.Configurator()



# Generated at 2022-06-24 08:48:06.035292
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    record = logging.getLogger().makeRecord('tornado.general', logging.INFO, 'filename', None, 'message', {}, None)
    log_formatter = LogFormatter()
    assert isinstance(log_formatter.format(record), str)

# Generated at 2022-06-24 08:48:16.430997
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.testing
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log

    option1 = tornado.options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )

# Generated at 2022-06-24 08:48:20.824855
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    # Set up color if we are in a tty and curses is installed
    channel = logging.StreamHandler()
    channel.setFormatter(LogFormatter())
    logger.addHandler(channel)
    # Set up color if we are in a tty and curses is installed
    channel = logging.StreamHandler()
    channel.setFormatter(LogFormatter())
    logger.addHandler(channel)
    # Set up color if we are in a tty and curses is installed
    channel = logging.StreamHandler()
    channel.setFormatter(LogFormatter())
    logger.addHandler(channel)

# Generated at 2022-06-24 08:48:24.784322
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
        tornado.options.options.log_file_max_size = 1
        logger = logging.getLogger()
        enable_pretty_logging(tornado.options.options,logger)
        assert 1 == 1
    except:
        assert 1 == 0
test_enable_pretty_logging()

# Generated at 2022-06-24 08:48:36.266980
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import uuid
    formatter = LogFormatter(style='{')
    # make sure formatter handles exceptions
    record = logging.LogRecord(
            "myname", logging.ERROR, "/some/path", 42,
            "log message", [], None)
    record.exc_info = True
    record.exc_text = None
    record.message = Exception("message")
    record.asctime = uuid.uuid4()
    record.__dict__['1'] = 1
    record.__dict__['2'] = 2
    record.__dict__['3'] = 3
    record.__dict__['4'] = 4
    record.__dict__['5'] = 5
    record.__dict__['6'] = 6
    record.__dict__['7'] = 7
    record.__dict__['8']

# Generated at 2022-06-24 08:48:39.856669
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    x = LogFormatter()
    record = logging.LogRecord(name="test", level=logging.DEBUG, pathname="test.py", lineno=0, msg="msg", args=None, exc_info=None)
    assert x.format(record)


# Generated at 2022-06-24 08:48:46.421169
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import sys
    import io

    class TestLogFormatter(unittest.TestCase):
        def test_format(self):
            log = logging.getLogger(__name__)
            log.setLevel(10)
            handler = logging.StreamHandler(io.StringIO())
            formatter = LogFormatter()
            handler.setFormatter(formatter)
            log.addHandler(handler)
            log.info("[info]")
            log.debug("[debug]")
            log.warning("[warning]")
            log.error("[error]")
            log.critical("[critical]")
    unittest.main()



# Generated at 2022-06-24 08:48:51.725542
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    # print(options)
    # print(logging)
    # print(help(logging))
    # for name,value in globals().items():
    #     print("%s: %s"%(name,value))



test_define_logging_options()

# Generated at 2022-06-24 08:48:55.946199
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter: LogFormatter = LogFormatter()
    assert isinstance(log_formatter._fmt, str)
    assert isinstance(log_formatter._colors, dict)
    assert isinstance(log_formatter._normal, str)



# Generated at 2022-06-24 08:49:06.897892
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import datetime

    record = logging.LogRecord(name = "tornado.access", 
                               level = 20, 
                               pathname = "tornado/log.py", 
                               lineno = 346, 
                               msg = "200 GET /static/js/widgets.js (::1)", 
                               args = None, 
                               exc_info = None, 
                               func = "access_log_message")
    #record.__dict__ = {'args': None, 'created': 1480239082.862197, 'exc_info': None, 'filename': '/home/jt/PycharmProjects/tornado_test/tornado/log.py', 'funcName': 'access_log_message', 'levelname': 'INFO', 'levelno': 20, 'lineno

# Generated at 2022-06-24 08:49:15.076092
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado
        tornado.options.parse_command_line(["--logging=debug"])
    except ValueError:
        import tornado.options
        tornado.options.options = tornado.options.define("logging", "debug")
    enable_pretty_logging()

    import tornado.log
    tornado.log.app_log.debug("debug message")
    tornado.log.app_log.info("info message")
    tornado.log.app_log.warning("warning message")
    tornado.log.app_log.error("error message")
    tornado.log.app_log.critical("critical message")

# Generated at 2022-06-24 08:49:24.878599
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = LogFormatter()
    assert log_format.datefmt == log_format.DEFAULT_DATE_FORMAT
    log_format = LogFormatter(color=False)
    assert log_format.datefmt == log_format.DEFAULT_DATE_FORMAT
    log_format = LogFormatter(fmt="%(color)s%(levelname)s")
    assert log_format.datefmt == log_format.DEFAULT_DATE_FORMAT
    log_format = LogFormatter(fmt="%(color)s%(levelname)s", datefmt="%Y")
    assert log_format.datefmt == "%Y"


# Generated at 2022-06-24 08:49:26.421865
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    option_parser=tornado.options.OptionParser()
    tornado.log.define_logging_options(option_parser)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:49:31.241440
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # This function does not return anything

    import tornado.options

    tornado.options.options.logging = "INFO"
    tornado.options.options.log_file_prefix = True
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1048576
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = False
    # Calling enable_pretty_logging



# Generated at 2022-06-24 08:49:41.657973
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options

    define_logging_options()
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:49:46.458300
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG, format="%(message)s")
    logger = logging.getLogger()
    logger.handlers[0].setFormatter(LogFormatter())
    logger.error("hello")



# Generated at 2022-06-24 08:49:51.912790
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log

    tornado.options.options["logging"] = "debug"

    tornado.log.enable_pretty_logging(None, None)

    logging.debug("debug message")

    logging.info("info message")

    logging.warning("warning message")

    try:
        raise Exception("error message")
    except Exception:
        logging.exception("exception message")

    logging.critical("critical message")


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:49:54.434198
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()



if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:50:00.239878
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.parse_config_file("examples/logging_options.conf")
    tornado.options.parse_command_line("--log_rotate_mode=time")

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:50:03.020969
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.log
    tornado.log.enable_pretty_logging()
    gen_log.info("test")



# Generated at 2022-06-24 08:50:12.343193
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    parser = OptionParser()
    define_logging_options(options)
    args = ['--logging', 'info',
            '--log_to_stderr', 'True',
            '--log_file_prefix', 'path',
            '--log_file_max_size', '100',
            '--log_file_num_backups', '10',
            '--log_rotate_when', 'midnight',
            '--log_rotate_interval', '1',
            '--log_rotate_mode', 'size']
    parser.parse_command_line(args)


if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:50:15.338107
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    # TODO: Make this a unit test
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler())
    logger.debug("debug")
    logger.info("info")
    logger.warn("warn")
    logger.error("error")
    logger.critical("critical")



# Generated at 2022-06-24 08:50:26.617736
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import io
    import sys
    import logging
    from tornado.options import define, options, parse_command_line, Error
    from tornado.log import app_log

    def dummy_options():
        class DummyOptions:
            log_to_stderr = True
            log_file_prefix = ''
            log_file_max_size = 100
            log_file_num_backups = 10
            log_rotate_mode = 'size'
            log_rotate_when = 'H'
            log_rotate_interval = 1
            logging = 'debug'
            log_dir = './'
        return DummyOptions()

    enable_pretty_logging(options=dummy_options())

    assert len(app_log.handlers) == 1

# Generated at 2022-06-24 08:50:34.934388
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord("name", logging.INFO, "/dir/dir.py", 10, "text", None, None)
    logger_ = logging.getLogger("name")
    formatter = LogFormatter("%(message)s %(levelname)s %(module)s")
    logger_.setLevel(logging.INFO)
    logger_.addHandler(logging.StreamHandler())
    logger_.handlers[0].setFormatter(formatter)
    logger_.info("log %s", 10)
    #logger_.error(str(10/0))
    info('info')
    debug('debug')
    error('error')


# Generated at 2022-06-24 08:50:44.670564
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = {
        "logging": "debug",
        "log_file_prefix": None,
        "log_to_stderr": False,
        "log_rotate_mode": "size",
        "log_file_num_backups": 5,
        "log_file_max_size": 1024,
        "log_rotate_when": "midnight",
        "log_rotate_interval": 1,
    }
    enable_pretty_logging(options)
    logging.debug('hello world')
    logging.info('hello world')
    logging.warning('hello world')
    logging.error('hello world')
    logging.critical('hello world')

# Generated at 2022-06-24 08:50:50.024510
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.Logger('test_logger')
    logger.setLevel(logging.DEBUG)
    sh = logging.StreamHandler()
    sh.setLevel(logging.DEBUG)
    formatter = LogFormatter(datefmt='%H:%M:%S')
    sh.setFormatter(formatter)
    logger.handlers = []
    logger.addHandler(sh)
    logger.info("test")


# Generated at 2022-06-24 08:50:56.414588
# Unit test for constructor of class LogFormatter

# Generated at 2022-06-24 08:51:03.795436
# Unit test for function define_logging_options
def test_define_logging_options():
    # late import to prevent cycle
    import tornado.options

    options = tornado.options.options
    define_logging_options(options)

    print(options.log_file_max_size, options.log_file_num_backups, options.log_to_stderr, options.log_rotate_when, options.log_rotate_interval, options.log_rotate_mode)

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:51:13.499472
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG)
    # ==== case 1 ====
    # code
    handler = logging.StreamHandler()
    handler.setFormatter(LogFormatter())
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger = logging.getLogger('')
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.info('hello')
    # output
'''
[I 161210 11:54:11 log_test.py:18] hello
''' 
    # ==== case 2 ====
    # code

# Generated at 2022-06-24 08:51:18.605703
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord(
        name=None,
        level=logging.INFO,
        pathname=None,
        lineno=0,
        msg=None,
        args=None,
        exc_info=None,
    )
    lf = LogFormatter()
    assert lf.format(record=record) is not None



# Generated at 2022-06-24 08:51:20.490687
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_formatter = LogFormatter()
    assert test_formatter is not None


# Generated at 2022-06-24 08:51:29.293707
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing
    import logging
    import os
    from tornado.log import gen_log
    from tornado.platform.asyncio import AsyncIOMainLoop
    from .testing import AsyncTestCase

    AsyncIOMainLoop().install()

    class MyTestCase(AsyncTestCase):

        def setUp(self):
            super().setUp()
            logging.getLogger().handlers = []

        def test_enable_pretty_logging(self):
            tornado.testing.set_default_logging_level()

            # Exercise every log level
            for level in [
                logging.DEBUG,
                logging.INFO,
                logging.WARNING,
                logging.ERROR,
                logging.CRITICAL,
            ]:
                gen_log.log(level, "This is a test")

# Generated at 2022-06-24 08:51:35.974771
# Unit test for function define_logging_options
def test_define_logging_options():
    options = tornado.options._Options()
    define_logging_options(options)
    print('options = %s' % options)
    options.parse_command_line(['--log_file_prefix=abc', '--log_to_stderr=0'])
    print(options.log_file_prefix)
    print(options.log_to_stderr)

test_define_logging_options()

# Generated at 2022-06-24 08:51:38.337535
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:51:38.906734
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-24 08:51:49.330813
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import io
    import logging
    import unittest
    import unittest.mock

    # Ordinary case
    logger = logging.getLogger()
    with unittest.mock.patch('tornado.log.logging.handlers.RotatingFileHandler',
                             new=unittest.mock.Mock()) as mocked_handler:
        enable_pretty_logging(None, logger)
        mocked_handler.assert_called_once_with(
            filename=None,
            maxBytes=None,
            backupCount=None,
            encoding="utf-8",
        )

    # Missing log_rotate_mode
    options = type('Options', (object, ), {})()
    options.log_file_prefix = None
    options.log_rotate_mode = None
    options.log_file

# Generated at 2022-06-24 08:51:51.474714
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.Formatter.format
    logFormatter = LogFormatter()
    logFormatter.format()


# Generated at 2022-06-24 08:52:02.022132
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    a_formatter = LogFormatter()
    a_record = logging.LogRecord('name', logging.WARNING, 'pathname', 'lineno', 'msg', [], None)
    assert isinstance(a_formatter.format(a_record), str)
    a_formatter = LogFormatter(datefmt='%Y-%m-%d %H:%M:%S',fmt='%(name)s %(levelname)s %(message)s')
    a_record = logging.LogRecord('name', logging.WARNING, 'pathname', 'lineno', 'msg', [], None)
    assert isinstance(a_formatter.format(a_record), str)



# Generated at 2022-06-24 08:52:13.756910
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # 注意, 需要参数default_log_format
	default_log_format = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa
	f = LogFormatter(default_log_format, datefmt=None)
	record = logging.LogRecord(
		name=None,
		level=None,
		pathname=None,
		lineno=None,
		msg=None,
		args=None,
		exc_info=None,
		func='test'
	)
	ret = f.format(record)
	assert 'INFO' in ret

# Generated at 2022-06-24 08:52:22.080002
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt_str = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" # noqa: E501
    date_str = "%y%m%d %H:%M:%S"
    style_str = "%"
    colors_dict = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    lf = LogFormatter(fmt=fmt_str, datefmt=date_str, style=style_str, colors=colors_dict) # noqa: E

# Generated at 2022-06-24 08:52:30.538605
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test enable_pretty_logging function
    try:
        getattr(logging.handlers, "WatchedFileHandler")
    except AttributeError:
        # WatchedFileHandler was introduced in python 3.4
        return  # type: ignore
    import logging.config

    import tornado.options
    import tornado.test.util

    class MyOptions(object):
        def __init__(self) -> None:
            pass
    myoptions = MyOptions()
    myoptions.log_file_prefix = "test.log"
    myoptions.log_to_stderr = False
    myoptions.logging = "debug"
    myoptions.log_rotate_mode = "time"
    myoptions.log_rotate_when = "D"
    myoptions.log_rotate_interval = 1
    my

# Generated at 2022-06-24 08:52:41.296770
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    def unit_test():
        global options,logger;
        options = tornado.options.OptionParser();
        define_logging_options(options)
        # options = tornado.options.options
        options.parse_config_file("/home/pi/code/web/python/token_server/server.conf")
        # logger = logging.getLogger()
        # logger.setLevel(getattr(logging, "error".upper()))
        # # channel = logging.StreamHandler()
        # # channel.setFormatter(LogFormatter())
        # channel = logging.handlers.RotatingFileHandler(
        #     filename=options.log_file_prefix,
        #     maxBytes=options.log_file_max_size,
        #     backupCount=options.log_file

# Generated at 2022-06-24 08:52:50.471712
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, OptionParser

    # test function define_logging_options
    parser = OptionParser()
    define_logging_options(parser)
    parser.parse_command_line()
    assert options.logging == "info"
    assert options.log_to_stderr == None

# Generated at 2022-06-24 08:53:01.830571
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import io
    import sys

    # Mute tornado.access logs
    logging.getLogger("tornado.access").propagate = False

    # Assert that no logs are printed if logging is set to none
    with io.StringIO() as stream:
        sys.stderr = stream
        enable_pretty_logging(logging.getLogger(), None)
        app_log.info("info")
        assert stream.getvalue() == ""

    # Assert logs are printed if logging is set to something else
    with io.StringIO() as stream:
        sys.stderr = stream
        options = logging.getLogger()
        options.logging = "warning"
        enable_pretty_logging(options, None)
        app_log.info("info")
        assert stream.getvalue() != ""

# Generated at 2022-06-24 08:53:06.094004
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter()
    newRecord = logging.LogRecord("tornado.access", logging.DEBUG, "", 1, "Hello World!", (), None, "SafeUnicode")
    message = logFormatter.format(newRecord)
    print(message)


# Generated at 2022-06-24 08:53:10.197312
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)

    f = LogFormatter(color=False)
    for level in (logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL):
        record = logging.LogRecord("name", level, "test_file.py", 123, "msg", None, None)
        assert "color" not in f.format(record)



# Generated at 2022-06-24 08:53:16.461866
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    tornado.options.options=tornado.options.OptionParser()
    tornado.options.options.logging=logging
    logger=logging.getLogger()
    enable_pretty_logging(tornado.options.options,logger)
    assert logger.level==logging.ERROR

# Generated at 2022-06-24 08:53:21.129975
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    assert formatter.DEFAULT_DATE_FORMAT == '%y%m%d %H:%M:%S'
    assert formatter.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}
    assert formatter._colors == {}
    assert formatter._normal == ""
test_LogFormatter()


# Generated at 2022-06-24 08:53:23.038421
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(color=True)
    assert isinstance(log_formatter, logging.Formatter)

# Generated at 2022-06-24 08:53:29.533108
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.logging = "warning"
    options.log_file_prefix = "/tmp/log.txt"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 3
    options.log_to_stderr = True
    enable_pretty_logging(options)


if __name__ == "__main__":
    test_enable_pretty_logging()