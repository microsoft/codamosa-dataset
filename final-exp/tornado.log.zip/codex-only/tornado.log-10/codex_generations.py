

# Generated at 2022-06-24 08:43:26.943997
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-24 08:43:33.093913
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, parse_command_line
    options.logging = "info"
    options.log_to_stderr = True
    options.log_file_prefix = "/home/user/abc.txt"
    options.log_file_max_size = 100
    options.log_file_num_backups = 10
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    options.log_rotate_mode = "size"
    assert options.logging == "info"
    assert options.log_to_stderr == True
    assert options.log_file_prefix == "/home/user/abc.txt"
    assert options.log_file_max_size == 100
    assert options.log_file_num_backups == 10


# Generated at 2022-06-24 08:43:40.408200
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger(__name__)
    handler = logging.StreamHandler()
    formatter = LogFormatter(
        color=False, fmt="%(message)s (%(asctime)s)", datefmt="%Y-%m-%d %H:%M:%S"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.debug("Got it!")



# Generated at 2022-06-24 08:43:50.002341
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    # Case 1: no arguments
    tornado.log.enable_pretty_logging()
    assert(getattr(tornado.options.options, "logging") == "warning")
    logger = logging.getLogger()
    assert(logger.handlers[0].level == 30)
    assert(logger.handlers[0].formatter._fmt == tornado.log.LogFormatter.DEFAULT_FORMAT)
    # Case 2: options argument
    tornado.log.enable_pretty_logging(tornado.options.options)
    assert(getattr(tornado.options.options, "logging") == "warning")
    logger = logging.getLogger()
    assert(logger.handlers[0].level == 30)

# Generated at 2022-06-24 08:43:51.489281
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter();
    record = logging.makeLogRecord({"msg": "test"});
    assert fmt.format(record) == "[I  test ] test"

# Generated at 2022-06-24 08:43:52.745123
# Unit test for function define_logging_options
def test_define_logging_options():
    global options
    # options = define_logging_options()



# Generated at 2022-06-24 08:43:55.311521
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()  # no-error



# Generated at 2022-06-24 08:44:02.015448
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    assert LogFormatter(color=True).format(logging.LogRecord("x", "DEBUG", 'x.py', 9999, 'a', (), None, None)) == '\x1b[2;34m[D 9999 x.py:9999]\x1b[0m a'

CONSOLE_LOGGER_NAME = "tornado.general"

# Logger used for the tornado.access module.
# This one is configured separately from the above.
access_log = logging.getLogger("tornado.access")



# Generated at 2022-06-24 08:44:10.650824
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.options
    
    tornado.options.define("logging", default="debug", help="logging level")
    tornado.options.define("log_file_prefix", default="", help="log file prefix")
    tornado.options.define(
        "log_to_stderr",
        default=False,
        help="send log output to stderr (colorized if possible)",
    )
    tornado.options.define(
        "log_rotate_mode",
        default="size",
        help="rotate the log files on size or time",
    )
    tornado.options.define("log_rotate_when", default="midnight", help="how to rotate the log files")

# Generated at 2022-06-24 08:44:13.044317
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:44:18.252491
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    :param self: 
    :return: 
    """
    # check if the method works
    L = LogFormatter()  # type: ignore
    try:
        L.format()
    except:
        pass



# Generated at 2022-06-24 08:44:21.291784
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter=LogFormatter()
    import inspect
    class a:
        def __init__(self):
            self.message='message'
            self.asctime='asctime'
            self.levelno=1
            self.__dict__=self.__dict__
            self.__dict__['_LogFormatter__normal']=''
    record=a()
    inspect.getfile(LogFormatter)
    formatter.format(record)

# Generated at 2022-06-24 08:44:24.229541
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = ""
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    gen_log.debug("Test log.")

# Generated at 2022-06-24 08:44:35.545221
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    with LogFormatter(color=False) as f:
        assert f._fmt == f.DEFAULT_FORMAT
        assert f._colors == {}
        assert f._normal == ""
    with LogFormatter(color=True) as f:
        assert f._colors != {}
        assert f._normal != ""
    # Verify that the formatter does not blow up on unicode input:
    with LogFormatter(color=True) as f:
        f.format(logging.makeLogRecord({"msg": u"\u2713"}))
    # Verify that the formatter does not blow up on non-string input:
    with LogFormatter(color=True) as f:
        f.format(logging.makeLogRecord({"msg": object()}))



# Generated at 2022-06-24 08:44:43.232855
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """
    Test logging.addHandler
    Test logging.StreamHandler
    Test LogFormatter class
    Test logging.Logger.setLevel
    Test logging.handlers.RotatingFileHandler
    Test logging.handlers.TimedRotatingFileHandler
    """
    import tempfile
    import os
    from tornado.options import define, options
    define('logging', default="DEBUG", type=str)
    define('log_file_prefix', default="test_log", type=str)
    define('log_file_max_size', default=10000)
    define('log_file_num_backups', default=3)
    define('log_rotate_mode', default="size", type=str)
    define('log_rotate_when', default="D", type=str)

# Generated at 2022-06-24 08:44:43.736214
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert True


# Generated at 2022-06-24 08:44:54.946706
# Unit test for function define_logging_options
def test_define_logging_options():
    # late import to prevent cycle
    import tornado.options
    class MyType(object):
        def __init__(self):
            self.is_first=True
        def add_parse_callback(self, callback):
            self.callback=callback
        def define(self,key,default=None,help=None,metavar=None,type=None):
            if self.is_first:
                self.is_first=False
                self.assertEqual(key,"logging")
                self.assertEqual(default,"info")
                self.assertEqual(help,"Set the Python log level. If 'none', tornado won't touch the logging configuration.")
                self.assertEqual(metavar,"debug|info|warning|error|none")

# Generated at 2022-06-24 08:45:03.667303
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import sys
    
    if hasattr(sys,'gettrace') and sys.gettrace() != None: #This is a unit test
        log_file_prefix = 'test/test_log_file'
        log_rotate_mode = 'time'
        log_rotate_when = 'midnight'
        log_rotate_interval = 1
        log_file_num_backups = 7
        logging = 'debug'

        tornado.options.define("log_file_prefix",
                               log_file_prefix,
                               type=str)
        tornado.options.define("log_rotate_mode",
                               log_rotate_mode,
                               type=str)

# Generated at 2022-06-24 08:45:04.125951
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()

# Generated at 2022-06-24 08:45:15.395944
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import time
    import threading
    import json
    import io
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    rq = time.strftime('%Y%m%d%H%M%S', time.localtime(time.time()))
    log_path = os.path.dirname(os.getcwd()) + '/logs/'
    log_name = log_path + rq + '.log'
    logfile = log_name
    fh = logging.FileHandler(logfile, mode='w')
    fh.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    fh.setFormatter(formatter)
    logger.addHandler(fh)

# Generated at 2022-06-24 08:45:25.830031
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # sample record object
    class A:
        levelname = 'WARNING'
        message = 'test message'
        asctime = 'test asctime'
        module = 'test module'
        lineno = 1
        exc_info = None

    a = A()

    # sample fmt
    fmt = "%(color)s%(levelname)s%(end_color)s %(message)s"
    # we expect
    expected = "[W 01test module:1] test message"

    log_formatter = LogFormatter(fmt=fmt)
    actual = log_formatter.format(a)
    # compare
    assert actual == expected



# Generated at 2022-06-24 08:45:34.285521
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    date_format = "%y%m%d %H:%M:%S"
    formatter = LogFormatter(fmt=log_format, datefmt=date_format, style="%")
    assert formatter._fmt == log_format
    assert formatter._colors[logging.DEBUG] == "\033[2;34m"
    assert formatter._normal == "\033[0m"

# -----------------------------------------------------------------------------


# Generated at 2022-06-24 08:45:44.735127
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # This test does not actually test the pretty logging output.
    import tornado.options

    options=tornado.options.options
    options.log_file_num_backups=5
    options.log_file_prefix="file"
    options.log_rotate_mode="size"
    options.log_file_max_size=10
    options.log_rotate_when="d"
    options.log_rotate_interval=1
    options.log_to_stderr=None
    options.logging="INFO"
    enable_pretty_logging(options)

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:45:52.384714
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options

    opts = tornado.options.parse_command_line(["-logging=WARNING"])
    enable_pretty_logging(options=opts)
    logger = logging.getLogger()
    assert logger.level == logging.WARNING


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:45:53.866737
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.exception("TEST enable_pretty_logging")

# Generated at 2022-06-24 08:45:59.944205
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f.format(logging.LogRecord(
        'tornado.test', logging.DEBUG, None, 0, msg='test', args=(),
        exc_info=None)
    ) == '[DEBUG %s tornado.test:0] test' % f.formatTime(None)

# ------------------------------------------------------------------------------
# LoggingMixin defines a standard interface to configure logging for classes
# that wish to use it.

# Generated at 2022-06-24 08:46:04.971421
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log=LogFormatter()
    from logging import LogRecord
    from time import time
    record = LogRecord(name='foo',level=10,pathname='path',lineno=1,msg='msg',args=(),exc_info='exc_info',func='func')
    record.__dict__['message'] = 'message'
    record.__dict__['asctime'] = 'asctime'
    record.__dict__['color'] = 'color'
    record.__dict__['end_color'] = 'end_color'
    record.__dict__['exc_text'] = 'exc_text'
    record.asctime = log.formatTime(record,cast(str, log.datefmt))
    print(log.format(record))



# Generated at 2022-06-24 08:46:06.438089
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()


# Generated at 2022-06-24 08:46:16.815322
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    str_ = "this is a log string"

    # 1:
    record = logging.LogRecord(
        name='name',
        level='level',
        pathname='pathname',
        lineno=1,
        msg=str_,
        args=None,
        exc_info=None,
    ) # type: Any
    log_formatter = LogFormatter()
    result = log_formatter.format(record)
    assert result == '[0.0 00:00:00 :1] this is a log string'
    assert record.message == str_
    assert record.asctime == '00:00:00'

    # 2:

# Generated at 2022-06-24 08:46:28.817019
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import sys
    from tornado.log import LogFormatter
    from io import StringIO
    # must be set, otherwise logging goes to sys.stderr
    logger = logging.getLogger()
    logger.handlers = [logging.StreamHandler(stream=StringIO())]
    handler = logger.handlers[0]
    # force-add this handler to the same logger
    handler2 = logging.StreamHandler(stream=StringIO())
    handler2.setFormatter(LogFormatter())
    logger.addHandler(handler2)
    msg = 'test str'
    logger.info(msg)
    print(handler2.stream.getvalue())

# Generated at 2022-06-24 08:46:37.573013
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    print(f.format(logging.LogRecord("tornado.general", logging.INFO, None, 0, "test", None, None)))
    f2 = LogFormatter("%(asctime)s [%(levelname)s %(module)s:%(lineno)d] %(message)s")
    print(f2.format(logging.LogRecord("tornado.general", logging.INFO, None, 0, "test", None, None)))


# Generated at 2022-06-24 08:46:38.681080
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:46:47.636214
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # import tornado.options
    # options = tornado.options.options
    # options.log_file_prefix = "/tmp/a"
    # options.log_file_max_size = 1024*1024*1024
    # options.log_file_num_backups = 7
    # options.logging = "debug"
    # logger = logging.getLogger()
    # logger.setLevel(logging.DEBUG)
    # enable_pretty_logging(options, logger)
    # log_msg = "some message"
    # logger.debug(log_msg)
    # logger.info(log_msg)
    pass

# Generated at 2022-06-24 08:46:49.212513
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


test_enable_pretty_logging()

# Generated at 2022-06-24 08:46:54.449122
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=logging.INFO)
    #logging.addHandler(logging.NullHandler())
    enable_pretty_logging(None,logger=logging.getLogger(__name__))

    logging.warning("Warning")
    logging.info("Info")
    logging.error("Error")
    logging.critical("Critical")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:47:02.805309
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert (LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT)
    assert (LogFormatter().datefmt == LogFormatter.DEFAULT_DATE_FORMAT)
    assert (LogFormatter(datefmt="").datefmt == "")
    assert (LogFormatter(fmt="")._fmt == "")
    assert (LogFormatter(style="{")._fmt == LogFormatter.DEFAULT_FORMAT)
    assert (LogFormatter(color=False)._colors == {})


# Generated at 2022-06-24 08:47:05.116147
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", "DEBUG", "C:/Users/WangQD/Desktop/可爱猫.jpg", 2, "11", "111", "1111")
    res = log_formatter.format(record)
    print(res)
#test_LogFormatter_format()



# Generated at 2022-06-24 08:47:10.982214
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.parse_command_line(["--help"])
    enable_pretty_logging()
    gen_log.info("hello")
    gen_log.error("world")
    # gen_log.warning("abc")
if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:47:16.963478
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord(
        name='test', level=logging.DEBUG, pathname='none', lineno=0,
        msg='Hello, %s', args=('world',), exc_info=None, func=None)) == "[D 0 none:0] Hello, world"  # noqa: E501

# Generated at 2022-06-24 08:47:25.267081
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options

    define_logging_options(options)

    assert options.logging == "info"

    assert options.log_to_stderr == None

    assert options.log_file_prefix == None

    assert options.log_file_max_size == 10000000

    assert options.log_file_num_backups == 10

    assert options.log_rotate_when == "midnight"

    assert options.log_rotate_interval == 1

    assert options.log_rotate_mode == "size"


# Generated at 2022-06-24 08:47:30.101890
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    >>> import logging
    >>> logger = logging.getLogger('test')
    >>> logger.setLevel(logging.DEBUG)
    >>> stream = logging.StreamHandler()
    >>> stream.setFormatter(LogFormatter())
    >>> logger.addHandler(stream)
    >>> logger.info('Hello')
    [I ...] Hello
    """



# Generated at 2022-06-24 08:47:33.909433
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define('port', default=8080, help='run on the given port', type=int)
    define_logging_options()
    parse_command_line()
    print(options.port)
# test_define_logging_options()


# Generated at 2022-06-24 08:47:37.708665
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.define('test', type=str))
    print(tornado.options.options.as_dict())

# Generated at 2022-06-24 08:47:47.882824
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_formatter = LogFormatter()
    from tornado.options import options
    options.logging = "debug"

    fmt = log_formatter.format(logging.LogRecord('foo', logging.INFO, 'pathname', 1, 'msg', None, None))
    assert ' %(message)s' == fmt
    fmt = log_formatter.format(logging.LogRecord('foo', logging.WARN, 'pathname', 1, 'msg', None, None))
    assert ' %(message)s' == fmt
    fmt = log_formatter.format(logging.LogRecord('foo', logging.ERROR, 'pathname', 1, 'msg', None, None))
    assert ' %(message)s' == fmt

# Generated at 2022-06-24 08:47:50.915795
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord('tornado.application',
                                                   logging.ERROR,
                                                   'tornado/stack_context.py',
                                                   0,
                                                   '_clear_current: stack_context improperly nested', # noqa: E501
                                                   (),
                                                   None)) == '\x1b[31m[E 0 tornado/stack_context.py:0]\x1b[0m _clear_current: stack_context improperly nested'  # noqa: E501



# Generated at 2022-06-24 08:48:01.424852
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _FORMAT = LogFormatter.DEFAULT_FORMAT
    _NORMAL = LogFormatter.DEFAULT_COLORS[logging.INFO]
    _BOLD = _NORMAL + 1
    _BLACK, _RED, _GREEN, _YELLOW, _BLUE, _MAGENTA, _CYAN, _WHITE = range(30, 38)
    _BLACKBG, _REDBG, _GREENBG, _YELLOWBG, _BLUEBG, _MAGENTABG, _CYANBG, _WHITEBG = range(40, 48)
    # Check that the constructor succeeds under various scenarios.
    LogFormatter(color=True)
    LogFormatter(color=False)
    LogFormatter(color=True, colors={logging.INFO: _BOLD})

# Generated at 2022-06-24 08:48:04.214103
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)
    print(tornado.options.options.logging)


# Generated at 2022-06-24 08:48:15.348157
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    import logging
    import doctest
    logging.info("Doctest for function enable_pretty_logging")

    def test_logging(options_string: str, log_output: str, color: bool) -> None:
        """Run formatter tests with all of the given options.

        :arg str options_string: comma-separated list of options as passed to
            ``parse_command_line``
        :arg str log_output: expected output when logging a single
            message with level 'info'
        :arg bool color: expected value of the ``color`` argument to
            `LogFormatter`
        """
        parse_command_line(options_string.split())
        enable_pretty_logging()
        logger = logging.getLogger()
        logger.handlers

# Generated at 2022-06-24 08:48:19.069203
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test with all three log levels
    for level_no in [10, 20, 30, 40, 50]:
        record = type('record', (object,), {
            '__dict__': {"levelno": level_no, "message": "test"},
            'levelname': 'TestLevelName',
            'asctime': '2018-12-27T11:02:54.342391',
            'module': 'TestModule',
            'lineno': '1',
            '__str__': object.__str__,
        })()

        logger = LogFormatter()
        logger.format(record)


# Generated at 2022-06-24 08:48:27.788209
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter_default = LogFormatter()
    record_default = logging.makeLogRecord({"levelno": logging.INFO})
    formatter_default.format(record_default)
    record_default = logging.makeLogRecord({"levelno": logging.CRITICAL})
    formatter_default.format(record_default)

    formatter_custom = LogFormatter(fmt="%(message)s", datefmt="%m%d %H:%M",style="{")
    record_custom = logging.makeLogRecord({"levelno": logging.DEBUG, "message": "hello"})
    formatter_custom.format(record_custom)
    record_custom = logging.makeLogRecord({"levelno": logging.INFO, "message": "hello"})
    formatter_custom.format(record_custom)
    record

# Generated at 2022-06-24 08:48:38.574445
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado import options

    # If a color setting was passed in, we're testing that, otherwise the
    # test should pass for color or monochrome.
    force_color = options.options.log_color

    # Defaults
    formatter = LogFormatter()
    assert isinstance(formatter._fmt, str)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    if force_color is not None:
        assert formatter._colors == (
            (not force_color) and LogFormatter.DEFAULT_COLORS or {}
        )
    else:
        assert (
            formatter._colors == LogFormatter.DEFAULT_COLORS or formatter._colors == {}
        )
    if not force_color:
        assert formatter._normal == ""

# Generated at 2022-06-24 08:48:43.591591
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    log_record = logging.LogRecord(
        "tornado.application", logging.INFO, "/path/to/file.py", 123, "message", (), {}, None
    )
    expected_format = "[I xxxxx /path/to/file.py:123] message"
    actual_format = formatter.format(log_record)
    assert actual_format == expected_format



# Generated at 2022-06-24 08:48:53.556483
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    class FakeRecord:
        def getMessage(self,):
            return "abc"
        def __init__(self,):
            self.levelno = 1
        class FakeExcInfo(object):
            def __init__(self,):
                self.exc_text = "ab"
        class FakeLogRecord(object):
            def __init__(self,):
                self.exc_info = self.FakeExcInfo()
        exc_info = FakeExcInfo()
    assert formatter.format(FakeRecord()) == "[E 01010101 abc] ab"


# Generated at 2022-06-24 08:49:05.172321
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    def run_tornado_log_test(argv: Any) -> bool:
        import StringIO
        import tornado.options
        import unittest
        import shutil
        import os

        class LoggingTest(unittest.TestCase):
            def setUp(self) -> None:
                self.io = StringIO.StringIO()
                enable_pretty_logging(self.io, logging.INFO)

            def test_logger(self) -> None:
                logger = logging.getLogger()
                logger.info("info")
                logger.warn("warn")
                self.assertEqual(self.io.getvalue(), "")
                logger.setLevel(logging.DEBUG)
                logger.info("info")
                logger.debug("debug")
                logger.warn("warn")
                self.assertNotEqual

# Generated at 2022-06-24 08:49:15.784737
# Unit test for function define_logging_options
def test_define_logging_options():
        import tornado.options

        options = tornado.options.options
        options.logging =  "debug"
        options.log_to_stderr = False
        options.log_file_prefix = "log"
        options.log_file_max_size = 100 * 1000 * 1000
        options.log_file_num_backups = 10
        options.log_rotate_when = "midnight"
        options.log_rotate_interval =1
        options.log_rotate_mode = "size"
        options.add_parse_callback(lambda: enable_pretty_logging(options))


if __name__ == "__main__":
     test_define_logging_options()

# Generated at 2022-06-24 08:49:16.121925
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass


# Generated at 2022-06-24 08:49:17.862196
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:49:26.456367
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s%(levelname)s%(end_color)s %(message)s"
    fmt2 = "%(color)s%(asctime)s%(end_color)s %(message)s"
    formatter1 = LogFormatter(fmt)
    formatter2 = LogFormatter(fmt2)
    record = logging.makeLogRecord({"levelname": "MyLevelName", "msg": "some message"})
    assert formatter1.format(record) == "[MyLevelName] some message"
    assert formatter2.format(record) == "[%(asctime)s] some message"


# Generated at 2022-06-24 08:49:36.280213
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.process
    tornado.options.define("log_file_prefix", "test", str)
    tornado.options.define("log_rotate_mode", "size", str)
    tornado.options.define("log_file_max_size", 10485760, int)
    tornado.options.define("log_file_num_backups", 10, int)
    tornado.options.define("log_to_stderr", None, bool)
    options = tornado.options.parse_config_file("test.py")
    enable_pretty_logging(options)
    print("Success")

# Generated at 2022-06-24 08:49:46.602716
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    import datetime
    record = logging.LogRecord(
        'name', logging.INFO, 'pathname', 1, 'msg', None, None, None)
    record.asctime = datetime.datetime.utcnow()
    record.levelno = logging.WARNING
    record.levelname = 'WARNING'
    record.name = 'name'
    record.pathname = 'pathname'
    record.lineno = 1
    record.message = 'msg'
    record.exc_info = None
    record.exc_text = None
    record.color = ''
    record.end_color = ''
    record.module = 'module'
    record.funcName = 'funcName'

    actual = log_formatter.format(record)

# Generated at 2022-06-24 08:49:50.439572
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formater = LogFormatter()
    record = logging.LogRecord(name="test",level=1,pathname="",lineno=0,msg="",args=None,exc_info=None)
    formater.format(record)


# Generated at 2022-06-24 08:49:55.854579
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    options.parse_command_line()
    assert options.logging == "info"
    assert options.log_to_stderr == None
    assert options.log_file_prefix == None
    assert options.log_file_max_size == 100000000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-24 08:50:07.296961
# Unit test for function define_logging_options
def test_define_logging_options():
    class Options:
        def __init__(self) -> None:
            self.logging = "info"
            self.log_to_stderr = None
            self.log_file_prefix = "/tmp/test"
            self.log_file_max_size = 100 * 1000 * 1000
            self.log_file_num_backups = 10
            self.log_rotate_when = 'midnight'
            self.log_rotate_interval = 1
            self.log_rotate_mode = 'size'
            self.add_parse_callback = lambda: enable_pretty_logging(self)
    options = Options()
    define_logging_options(options)

# Generated at 2022-06-24 08:50:08.785901
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    a = LogFormatter()
    assert(a)

# Generated at 2022-06-24 08:50:12.363559
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():

    import tornado.options
    tornado.options.parse_command_line()
    logger = logging.getLogger()
    print(logger)
    enable_pretty_logging(logger=logger)
    logger.info('hello world')

test_enable_pretty_logging()

# Generated at 2022-06-24 08:50:23.626833
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
    except ImportError:
        return

    import tornado.testing
    import six
    import tempfile
    import time

    # suppress 'No handlers could be found for logger "tornado.general"' warning
    logging.getLogger("tornado.general").addHandler(logging.NullHandler())

    try:
        import curses
    except ImportError:
        curses = None

    if curses is None:
        enable_pretty_logging()
        logging.error("test")
        logging.info("test")
        assert True
    else:

        class LoggingTest(tornado.testing.AsyncTestCase):
            def test_logging(self):
                fd, log_file_name = tempfile.mkstemp()
                os.close(fd)

# Generated at 2022-06-24 08:50:31.997825
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    logging.Logger.manager.loggerDict.clear()
    formatter_dict = {
        "()": "tornado.log.LogFormatter",
        "color": True,
        "fmt": "%(levelname) %(message) %(color) %(end_color)",
        "datefmt": "%Y-%m-%d %H:%M:%S",
    }  # type: Dict[str, Any]
    logging.config.dictConfig({"formatters": {"__main__": formatter_dict}})



# Generated at 2022-06-24 08:50:32.381659
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging(): enable_pretty_logging()

# Generated at 2022-06-24 08:50:33.731512
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

test_enable_pretty_logging()

# Generated at 2022-06-24 08:50:43.714218
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.INFO, "/path/to/file", 111, "my message", (), None)
    result = formatter.format(record)
    assert result == "[I 20070806 20:13:29 path/to/file:111]    my message"
    formatter = LogFormatter(color=False)
    result = formatter.format(record)
    assert result == "[I 20070806 20:13:29 path/to/file:111]    my message"
    del logging.root.handlers[:]


# Generated at 2022-06-24 08:50:52.569568
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """
    test for function enable_pretty_logging
    """
    import tornado.options

    tornado.options.options.log_file_prefix = None
    tornado.options.options.log_file_max_size = None
    tornado.options.options.log_file_num_backups = None
    tornado.options.options.logging = None
    tornado.options.options.log_to_stderr = None
    tornado.options.options.log_rotate_mode = None
    tornado.options.options.log_rotate_when = None
    tornado.options.options.log_rotate_interval = None
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-24 08:51:01.132158
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter = LogFormatter("test_%(test)s_test", "%Y-%m-%d %H:%M:%S")
    formatter = LogFormatter("test_%(test)s_test", "%Y-%m-%d %H:%M:%S", style="{")
    formatter = LogFormatter("test_%(test)s_test", "%Y-%m-%d %H:%M:%S", color=False)
    formatter = LogFormatter("test_%(test)s_test", "%Y-%m-%d %H:%M:%S", colors={})



# Generated at 2022-06-24 08:51:06.681000
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('test_LogFormatter_format')
    logger.setLevel(logging.DEBUG)
    logHandler = logging.StreamHandler()
    logHandler.setFormatter(LogFormatter())
    logger.addHandler(logHandler)

    logger.debug('This is a test message')
    logger.info('This is a test message')
    logger.warning('This is a test message')
    logger.error('This is a test message')
    logger.critical('This is a test message')


# Generated at 2022-06-24 08:51:08.559462
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()


# Generated at 2022-06-24 08:51:18.731207
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    #Some of the tests below can only be run on Linux but they are always run on all operating
    #systems. This because we did not find a way to filter out unittest on Linux
    #pylint: disable=import-outside-toplevel
    import tornado.options
    import logging
    import logtest
    import os
    import shutil
    import time
    import tornado

# Generated at 2022-06-24 08:51:21.796531
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line()
    print(options.logging)

# Generated at 2022-06-24 08:51:25.704800
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 1000000000
    assert options.log_file_num_backups == 10

# Generated at 2022-06-24 08:51:29.715206
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    op = OptionParser()
    define_logging_options(options)
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)



# Generated at 2022-06-24 08:51:38.628867
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options_dummy_1 = {
        "logging": "info"
    }
    options_dummy_2 = {
        "logging": "info",
        "log_file_prefix": "log.txt",
        "log_file_max_size": 100,
        "log_file_num_backups": 10,
        "log_rotate_mode": "size",
        "log_rotate_when": "D",
        "log_rotate_interval": 1
    }

    enable_pretty_logging(options_dummy_1)
    enable_pretty_logging(options_dummy_2)

# Generated at 2022-06-24 08:51:48.436476
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("logging", type=str)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("log_rotate_interval", type=int)
    tornado.options.define("log_to_stderr", type=bool)
    tornado.options.parse_command_line()
    enable_pretty_logging()

# Generated at 2022-06-24 08:51:56.126268
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        options={"log_file_prefix":"text.txt",
        "log_rotate_mode":"size",
        "log_file_max_size":1024,
        "log_file_num_backups":3,
        "logging":"WARNING",
        "log_to_stderr":True
        }
        enable_pretty_logging(options)
    except Exception:
        print("Exception happens")

test_enable_pretty_logging()

# Generated at 2022-06-24 08:52:05.590198
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()
    assert logFormatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert logFormatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert logFormatter.DEFAULT_COLORS == {logging.DEBUG: 4,  # Blue
                                           logging.INFO: 2,  # Green
                                           logging.WARNING: 3,  # Yellow
                                           logging.ERROR: 1,  # Red
                                           logging.CRITICAL: 5,  # Magenta
                                           }
    assert logFormatter._

# Generated at 2022-06-24 08:52:15.633035
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("logging", default="debug")
    define("log_file_prefix", default="")
    define("log_rotate_mode", default="time")
    define("log_rotate_when", default="midnight")
    define("log_rotate_interval", default=1)
    define("log_file_num_backups", default=7)
    define("log_file_max_size", default=1)
    define("log_to_stderr", default=True)
    try:
        enable_pretty_logging()
    except Exception as e:
        print("Test cases failed:", e)

# Generated at 2022-06-24 08:52:17.018379
# Unit test for function define_logging_options
def test_define_logging_options():
    """
    test function define_logging_options()
    """
    pass

# Generated at 2022-06-24 08:52:27.144237
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()

    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    # include all the arguments and their default values
    formatter = LogFormatter(
        fmt=LogFormatter.DEFAULT_FORMAT,
        datefmt=LogFormatter.DEFAULT_DATE_FORMAT,
        style="%",
        color=True,
        colors=LogFormatter.DEFAULT_COLORS,
    )
    assert isinstance(formatter, logging.Formatter)
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT



# Generated at 2022-06-24 08:52:37.859578
# Unit test for function define_logging_options
def test_define_logging_options():
    class Options:
        def __init__(self):
            self.log_rotate_interval = 1
            self.log_rotate_when = "midnight"
            self.log_rotate_mode = "size"
            self.log_file_max_size = 1000000
            self.log_file_num_backups = 10
            self.log_file_prefix = "./path/prefix"
            self.log_to_stderr = True
            self.logging = "info"

        def define(self, *args: Any, **kwargs: Any) -> None:
            pass

    options = Options()
    define_logging_options(options)

# Generated at 2022-06-24 08:52:49.240705
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import parse_command_line
    from tornado.options import parse_config_file
    import tornado.options

    options = tornado.options.options
    define_logging_options(options)
    parse_command_line(["--log_file_prefix=".format(options.log_file_prefix)])
    parse_command_line(["--log_file_num_backups=".format(options.log_file_num_backups)])
    parse_command_line(["--log_rotate_mode=".format(options.log_rotate_mode)])
    parse_command_line(["--log_file_max_size=".format(options.log_file_max_size)])

# Generated at 2022-06-24 08:52:52.071417
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig()
    enable_pretty_logging()
    from tornado.log import app_log
    app_log.error("some message")

# Generated at 2022-06-24 08:53:03.419733
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("logging", default="None")
    define("log_file_prefix", default="test_log")
    define("log_rotate_mode", default="size")
    define("log_file_max_size", default=1024)
    define("log_file_num_backups", default=3)
    define("log_rotate_when", default="M")
    define("log_rotate_interval", default="1")
    define("log_to_stderr", default=True)
    enable_pretty_logging()


# Aliases for old log functions.  These used to be defined in
# `tornado.options`, but we want them to be available even without
# configuring logging through `tornado.options`.
# TODO(benjamin): Deprecate these and

# Generated at 2022-06-24 08:53:08.117819
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    options.clear()
    define("logging", default="info",
           help="Set the Python log level. If 'none', tornado won't touch the logging configuration.")
    parse_command_line(["test.py", "--logging=error"])
    assert options.logging == "error"

# Generated at 2022-06-24 08:53:14.441639
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.log import LogFormatter
    assert LogFormatter()

antec_log = None  # type: Optional[logging.Logger]  # Must be initialized

log_handler = None  # type: Optional[logging.Handler]  # Must be initialized
DEFAULT_LOG_FORMATTER = LogFormatter()


# Generated at 2022-06-24 08:53:27.076570
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    # test with color
    record = logging.LogRecord("", 1, "", 0, "", None, None)
    record.message = "test message"
    record.exc_info = ()
    record.levelno = logging.INFO
    lf.format(record)
    assert record.message == "test message"
    assert record.end_color == ""
    assert record.color == "\033[2;32m"
    assert record.asctime == ""
    assert record.exc_text == None

    # test without color
    if curses:
        lf1 = LogFormatter(color=False)
        record1 = logging.LogRecord("", 1, "", 0, "", None, None)
        record1.message = "test message"
        record1.exc_info = ()