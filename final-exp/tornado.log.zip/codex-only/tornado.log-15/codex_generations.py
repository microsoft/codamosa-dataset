

# Generated at 2022-06-24 08:43:29.071483
# Unit test for function define_logging_options
def test_define_logging_options():
    try:
        from tornado.options import OptionParser
    except ImportError:
        import sys
        import logging
        sys.stderr.write("SKIP: tornado.test.test_options " "(no tornado.options module)\n")
        logging.warning("No tornado.options module, skipping test_options")
        return

    parser = OptionParser()
    define_logging_options(parser)
    args = ["--help"]
    # expect no errors
    assert parser.parse_command_line(args) is None
    assert parser.parse_config_file("[options]") is None

# Generated at 2022-06-24 08:43:39.118472
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    with open('LogFormatter_format.txt', 'r') as f:
        context = f.read()
    with open('LogFormatter_format_out1.txt', 'r') as f:
        out1 = f.read()
    with open('LogFormatter_format_out2.txt', 'r') as f:
        out2 = f.read()
    import ast
    context = ast.literal_eval(context)

    lf = LogFormatter()
    result1 = lf.format(context[0])
    if result1 == out1.strip():
        print('Test 1 pass')
    result2 = lf.format(context[1])
    if result2 == out2.strip():
        print('Test 2 pass')

test_LogFormatter_format()

# end of file

# Generated at 2022-06-24 08:43:44.802600
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_file_prefix = "test.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 50
    options.log_file_num_backups = 10
    options.logging = "warning"
    enable_pretty_logging(options,logger = logging.getLogger())

# Generated at 2022-06-24 08:43:49.476823
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import gen_log
    from logging import StreamHandler

    s_handler = StreamHandler()
    s_handler.setFormatter(LogFormatter())
    gen_log.addHandler(s_handler)

    try:
        gen_log.error("Testing Error Logs")
    except Exception as e:
        print(e)
    finally:
        gen_log.removeHandler(s_handler)


# Generated at 2022-06-24 08:43:51.153243
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options()
    tornado.options.parse_command_line()

# Generated at 2022-06-24 08:43:59.010663
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options():
        logging = "info"
        log_file_prefix = "prefix.log"
        log_rotate_mode = "time"
        log_rotate_when = "s"
        log_rotate_interval = 1
        log_file_num_backups = 3
        log_to_stderr = True
    options = Options()
    enable_pretty_logging(options)

test_enable_pretty_logging()

# Generated at 2022-06-24 08:44:03.334731
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = 'none'
    enable_pretty_logging(tornado.options.options)
    tornado.options.options.logging = 'error'
    enable_pretty_logging(tornado.options.options)
    tornado.options.options.logging = 'info'
    enable_pretty_logging(tornado.options.options)
    

# Unit test

# Generated at 2022-06-24 08:44:10.751126
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import tornado.ioloop

    logging.basicConfig(level=logging.DEBUG)

    class FakeStream(object):
        def isatty(self):
            return False

    def test_fmt():
        for color in [True, False]:
            tf = tornado.test.LogTrapTestCase()
            logger = logging.getLogger()
            formatter = LogFormatter(color=color)
            sh = logging.StreamHandler(FakeStream())
            sh.setFormatter(formatter)
            logger.addHandler(sh)
            logger.info("test")
            logger.removeHandler(sh)
            if color:
                tf.assertTrue("\033" not in tf.get_log())
            else:
                tf.assertTrue("\033" in tf.get_log())
            io_loop = tornado.ioloop

# Generated at 2022-06-24 08:44:18.208167
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_file_prefix = 'test.log'
    options.logging = 'debug'
    enable_pretty_logging(options)
    logging.debug('debug message')
    logging.info('info message')
    logging.warning('warning message')
    logging.error('error message')
    logging.critical('critical message')


# Generated at 2022-06-24 08:44:21.123584
# Unit test for function define_logging_options
def test_define_logging_options():
    import sys
    import tornado.options
    d = dict(log_file_prefix='log_file_prefix', log_rotate_when='midnight', log_rotate_mode='size', log_file_num_backups=10, log_rotate_interval=1)
    tornado.options.parse_config_file(sys.argv, d)

# Main function for unit test

# Generated at 2022-06-24 08:44:30.782361
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    argv = [
        "--logging=debug",
        "--log_to_stderr=false",
        "--log_file_prefix=test.log",
        "--log_file_max_size=10",
        "--log_file_num_backups=20",
        "--log_rotate_when=midnight",
        "--log_rotate_interval=1",
        "--log_rotate_mode=size",
    ]
    # testing if parse_command_line can be executed without error
    tornado.options.parse_command_line(args=argv)
    # the output of the logging module can be parsed. Or else, we can't see if the configuration is right or not
    logging.info("test")

# Generated at 2022-06-24 08:44:39.995273
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_format = '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'  # noqa: E501
    date_format = '%y%m%d %H:%M:%S'
    style = '%'
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(log_format, date_format, style, color, colors)

    assert formatter._normal == ''



# Generated at 2022-06-24 08:44:44.355483
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig()
    logger = logging.getLogger()
    enable_pretty_logging(logger=logger)
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)
    assert isinstance(logger.handlers[0].formatter, LogFormatter)

# Generated at 2022-06-24 08:44:53.309703
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("logging", type=str, default=None, metavar="LOGGING")
    tornado.options.define("log_file_prefix", type=str, default='', metavar="LOG_FILE_PREFIX")
    tornado.options.define("log_rotate_mode", type=str, default='', metavar="LOG_ROTATE_MODE")
    tornado.options.define("log_file_max_size", type=int, default=20, metavar="LOG_FILE_MAX_SIZE")
    tornado.options.define("log_file_num_backups", type=int, default=8, metavar="LOG_FILE_NUM_BACKUPS")

# Generated at 2022-06-24 08:45:03.512969
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S"
    )
    record=logging.LogRecord(
            "name",
            logging.INFO,  # level
            pathname=None,
            lineno=1,
            msg="message",
            args=(),
            exc_info=None
        )
    if formatter.format(record) == "[I 20090101 00:00:00 name:1] message":
        print("Unit test for method format of class LogFormatter: success")

# Generated at 2022-06-24 08:45:07.825861
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_to_stderr=True
    tornado.options.options.log_file_prefix=None
    tornado.options.options.logging=None
    import os
    import sys
    import logging
    logger = logging.getLogger()
    if os.name == 'nt':
        try:
            import colorama

            colorama.init()
        except ImportError:
            pass
    enable_pretty_logging()
    logger.info("hello")

# Generated at 2022-06-24 08:45:17.305806
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_log_file = 'test_LogFormatter.tmp'
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler, Application
    from tornado.ioloop import IOLoop
    import os
    # unit test for LogFormatter
    class Handler(RequestHandler):
        def get(self):
            self.write('abc')
            # raise exception to test LogFormatter
            raise Exception('self_defined_exception')

    def test_LogFormatter_case():
        # init application
        app = Application([('/test_LogFormatter', Handler)])
        # set log file
        app.settings['log_file_prefix'] = test_log_file
        # set log_to_stderr False
        app.settings['log_to_stderr'] = False
        # make log_

# Generated at 2022-06-24 08:45:21.829103
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, define
    define("test1", default=None)
    define("test2")
    define("test3", default="hello")
    assert options.test1 is None
    assert options.test2 == ""
    assert options.test3 == "hello"
    define_logging_options()
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

test_define_logging

# Generated at 2022-06-24 08:45:28.984649
# Unit test for function define_logging_options
def test_define_logging_options():
    options.logging = 'debug'
    options.log_to_stderr = True
    options.log_file_prefix = None
    options.log_file_max_size = 100 * 1000 * 1000
    options.log_file_num_backups = 10
    options.log_rotate_when = 'midnight'
    options.log_rotate_interval = 1
    options.log_rotate_mode = 'size'
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:45:31.226605
# Unit test for function define_logging_options
def test_define_logging_options():
    """Unit test for function define_logging_options"""
    assert define_logging_options() is None

test_define_logging_options()

# Generated at 2022-06-24 08:45:43.247557
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers

    logger = logging.getLogger("tornado.test")
    logger.setLevel(logging.DEBUG)
    handler = logging.handlers.RotatingFileHandler("test.log")
    formatter = LogFormatter(color=False)
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    logger.warning("test")
    logger.debug("test")
    logger.info("test")



# Generated at 2022-06-24 08:45:46.592922
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.makeLogRecord({"message": "Hello, world!", "levelno": 1})
    orig_format = LogFormatter.format
    LogFormatter.format = lambda *args, **kwargs: orig_format(*args, **kwargs)
    try:
        assert LogFormatter().format(record).startswith(
            "["
            "\033[2;31m"
            "CRITICAL "
            "\033[0m"
            " "
            "\033[2;31m"
            "Hello, world!"
            "\033[0m"
        )
    finally:
        LogFormatter.format = orig_format



# Generated at 2022-06-24 08:45:56.405823
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    message = "my message"
    record = logging.LogRecord(
        "tornado.general", logging.WARN, "C:/fake/tornado/log.py", 42, message, (), None
    )
    message = "my message"
    record = logging.LogRecord(
        "tornado.general", logging.WARN, "C:/fake/tornado/log.py", 42, message, (), None
    )
    formatter = LogFormatter()
    message = formatter.format(record)
    assert message == "[W 01010010:50:11 log:42] my message"


# Generated at 2022-06-24 08:45:57.088223
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:45:59.942901
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.debug("test enable pretty logging")
    enable_pretty_logging()
    
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-24 08:46:12.793923
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        assert 1 == 2
    except Exception as e:
        record = logging.LogRecord("testing", 0, "", 0, "", None, None)
        record.exc_info = sys.exc_info()
        record.exc_text = None
        # this function provides own exception message
        #   so the original exception e (as record.exc_info) is not called
        #   in this case
        message = record.getMessage()
        print(message)
        assert isinstance(message, basestring_type)  # guaranteed by logging
        # Encoding notes:  The logging module prefers to work with character
        # strings, but only enforces that log messages are instances of
        # basestring.  In python 2, non-ascii bytestrings will make
        # their way through the logging framework until they blow up with

# Generated at 2022-06-24 08:46:13.661221
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:46:19.506104
# Unit test for function define_logging_options
def test_define_logging_options():
    """Tornado.logging.define_logging_options"""
    # late import to prevent cycle
    import tornado.options

    options = tornado.options.options
    options.logging = "info"
    options.log_to_stderr = True
    options.log_file_prefix = "../../tmp/logs/test"
    options.log_rotate_when = "D"
    options.log_rotate_interval = 1
    options.log_rotate_mode = "time"
    define_logging_options(options)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:46:22.001124
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    #print(options._options["logging"].help)
    #print (options._options.keys())

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:46:28.628687
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    logger = logging.getLogger()
    assert isinstance(logger.handlers[0].formatter, LogFormatter)
    logger.handlers[0].stream.write('[I 151106 00:44:24 test:6] "GET / HTTP/1.1" 200')
    logger.handlers[0].stream.write('\n')
    logger.handlers[0].stream.flush()



# Generated at 2022-06-24 08:46:34.258335
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        '', 20, '', 0, 
        'hello',
        None, None
    )
    result = formatter.format(record)
    assert result == "hello"


# Generated at 2022-06-24 08:46:41.694222
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    # 设置日志格式
    format = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    dateFormat = "%y%m%d %H:%M:%S"
    formatter = LogFormatter(format, dateFormat)
    # 设置日志信息
    record = logging.LogRecord("", 0, "", 0, "", ("do what", "?"), ())
    record.levelname = "INFO"
    record.asctime = datetime.datetime.now().strftime(dateFormat)
    record.module = "main"

# Generated at 2022-06-24 08:46:53.178785
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, define
    define("log_rotate_when", default="midnight", help=("specify the type of "
                                                       "TimedRotatingFileHandler interval "
                                                       "other options:('S', 'M', 'H', 'D', 'W0'-'W6')"), type=str)
    define("log_rotate_interval", default=1, help="The interval value of timed rotating", type=int)
    define("log_rotate_mode", default="size", help="The mode of rotating files(time or size)", type=str)
    define("log_file_num_backups", default=10, help="number of log files to keep", type=int)

# Generated at 2022-06-24 08:46:54.349948
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-24 08:47:04.001070
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    from tornado.options import define, options
    from tornado.log import gen_log

    define("logging", default="info")
    define("log_to_stderr", default=True)
    define("log_file_prefix", default=None)
    define("log_rotate_mode", default="time")
    define("log_rotate_when", default="D")
    define("log_rotate_interval", default=1)
    define("log_file_num_backups", default=10)
    define("log_file_max_size", default=1024)
    tornado.log.enable_pretty_logging(options)

# Generated at 2022-06-24 08:47:06.266707
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:47:10.981446
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    r = logging.makeLogRecord({"msg": "user@example.com"})
    assert formatter.format(r) == "[WARNING 20150802 16:39:32 _ _:_] user@example.com"  # noqa: E501



# Generated at 2022-06-24 08:47:12.095737
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-24 08:47:12.641326
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-24 08:47:19.552498
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    assert log_formatter.format(logging.LogRecord(
        'tornado.application',
        logging.DEBUG,
        filename=__file__,
        lineno=123,
        func='test_LogFormatter_format',
        msg='test message',
    )) == "[D 20191220 13:58:08 log.py:123] test message"



# Generated at 2022-06-24 08:47:20.450964
# Unit test for function define_logging_options
def test_define_logging_options():
    enable_pretty_logging()
    define_logging_options()

# Generated at 2022-06-24 08:47:22.107026
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    assert fmt._colors


# Generated at 2022-06-24 08:47:23.233117
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter()



# Generated at 2022-06-24 08:47:31.377943
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    print(tornado.options)
    options = tornado.options
    assert options.options.logging == 'info'
    assert options.options.log_to_stderr == None
    assert options.options.log_file_prefix == None
    assert options.options.log_file_max_size == 100 * 1000 * 1000
    assert options.options.log_file_num_backups == 10
    assert options.options.log_rotate_when == "midnight"
    assert options.options.log_rotate_interval == 1
    assert options.options.log_rotate_mode == "size"


# Generated at 2022-06-24 08:47:36.866162
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    define_logging_options(options)
    options.parse_command_line()

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-24 08:47:39.511829
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    tornado.options.define_logging_options()
    tornado.options.parse_command_line()



# Generated at 2022-06-24 08:47:49.914116
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    msg = '{"msg":"nomal message"}'
    record = logging.LogRecord("tornado.access", logging.INFO, "/home/meng/projects/logging_test/test.py", 9, msg, args=None, exc_info=None)
    res = lf.format(record)
    assert res == "[I 171013 01:15:39 test:9] {\"msg\":\"nomal message\"}"
    
    msg_utf8 = b'{"msg":"utf-8 encoding message"}'
    record = logging.LogRecord("tornado.access", logging.INFO, "/home/meng/projects/logging_test/test.py", 9, msg_utf8, args=None, exc_info=None)
    res = lf.format(record)

# Generated at 2022-06-24 08:47:52.316020
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()


# Generated at 2022-06-24 08:48:02.530926
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # test the basic instance of LogFormatter
    formatter = LogFormatter()
    record = logging.LogRecord("test_name", logging.INFO, "test_pathname", 20, "test_msg", None, None)
    assert formatter.format(record).startswith("[I ")

# class LogFormatter(logging.Formatter):
#     """Log formatter used in Tornado.
#
#     Key features of this formatter are:
#
#     * Color support when logging to a terminal that supports it.
#     * Timestamps on every log line.
#     * Robust against str/bytes encoding problems.
#
#     This formatter is enabled automatically by
#     `tornado.options.parse_command_line` or `tornado.options.parse_config_file`
#     (unless ``--log

# Generated at 2022-06-24 08:48:05.809488
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-24 08:48:16.348078
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    # Verify that ascii escapes are not present when colorama is not present
    colorama = sys.modules.get("colorama", object())
    if colorama is object():
        # Make sure colorama is not initialized, or LogFormatter
        # will assume that we have a color terminal.
        sys.modules["colorama"] = None

# Generated at 2022-06-24 08:48:25.479549
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    opts = tornado.options.options
    opts.log_file_prefix = "prefix"
    opts.log_file_max_size = 10000
    opts.log_file_num_backups = 12
    opts.log_rotate_when = "S"
    opts.log_rotate_interval = 10
    opts.log_to_stderr = False
    logger = logging.getLogger()
    enable_pretty_logging(opts, logger)

    assert isinstance(logger.handlers[0], logging.StreamHandler)
    assert isinstance(logger.handlers[1], logging.handlers.RotatingFileHandler)
    logger.handlers[0].close()
    logger.handlers[1].close()

    logger.handlers = []


# Generated at 2022-06-24 08:48:26.900414
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-24 08:48:29.407420
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log = LogFormatter()
    log.format("info")
    log.format("warn")
    log.format("error")


# Generated at 2022-06-24 08:48:33.361559
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter.DEFAULT_FORMAT
    assert isinstance(LogFormatter.DEFAULT_DATE_FORMAT, str)
    assert LogFormatter.DEFAULT_COLORS
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)



# Generated at 2022-06-24 08:48:43.146121
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # LogFormatter.__init__()
    def init(self):
        self._fmt = self.DEFAULT_FORMAT

    # LogFormatter.format()
    rec = logging.LogRecord("test", logging.DEBUG, "log.py", 123, "test", (), None)
    def format(self, record):
        try:
            message = record.getMessage()
            assert isinstance(message, basestring_type)
            record.message = _safe_unicode(message)
        except Exception as e:
            record.message = "Bad message (%r): %r" % (e, record.__dict__)

        record.asctime = self.formatTime(record, cast(str, self.datefmt))


# Generated at 2022-06-24 08:48:55.892890
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    with open("test_logging.txt", "w") as f:
        f.write("""[I 120120 00:00:00 module:1] test message
    Traceback (most recent call last):
      File "test_logging.txt", line 1, in <module>
    ValueError: Bad message (test message)""")
    with open("test_logging.txt") as f:
        str1 = f.read()
    with open("test_logging.txt", "w") as f:
        logFormatter = LogFormatter()
        record = logging.LogRecord("test_logging", logging.INFO, "test_logging.txt", 1, "test message", (), None, None)
        str2 = logFormatter.format(record)
        f.write(str2)

# Generated at 2022-06-24 08:49:03.056737
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="name",
        level=10,
        pathname="/some/path",
        lineno=42,
        msg="hello",
        args=None,
        exc_info="err",
    )
    record.msg = "hello"
    record.args = None
    record.exc_info = "err"

    assert formatter.format(record)


# Generated at 2022-06-24 08:49:10.429108
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    formatter = LogFormatter()
    # Logger name
    logger_name = 'test'
    # Logger level
    logger_level = 10
    # Logger message
    logger_message = 'test log message'
    # Logger exception
    logger_exception = 'test exception'
    logger_exc_info = ('test exc_info', 'test exc_info', 'test exc_info')
    logger_funcName = 'test_funcName'

    class _LogRecord(object):
        pass

    logger_record = _LogRecord()
    logger_record.__dict__['name'] = logger_name
    logger_record.__dict__['levelno'] = logger_level
    logger_record.__dict__['msg'] = logger_message
    logger_record.__dict__['exc_info'] = logger_exc_

# Generated at 2022-06-24 08:49:12.089180
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter

# Generated at 2022-06-24 08:49:22.625702
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()
    log_handler = logging.StreamHandler()
    log_handler.setLevel(logging.DEBUG)
    log_format = "%(asctime)s - %(levelname)s - %(message)s"
    log_date_format = "%m/%d/%Y %I:%M:%S %p"
    log_formatter = LogFormatter(fmt=log_format, datefmt=log_date_format)
    log_handler.setFormatter(log_formatter)
    logger.addHandler(log_handler)

    logger.warning("test output")



# Generated at 2022-06-24 08:49:23.580946
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass


# Generated at 2022-06-24 08:49:24.544506
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #todo: add test
    pass

# Generated at 2022-06-24 08:49:27.468478
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class DummyOption:
        pass
    d = DummyOption()
    d.log_file_prefix = None
    d.logging = "debug"
    d.log_to_stderr = True
    enable_pretty_logging(d)

# Generated at 2022-06-24 08:49:40.081147
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    parser = OptionParser()
    define_logging_options(parser.define_options)
    assert parser.options.logging == 'info'
    assert parser.options.log_file_prefix == None
    assert parser.options.log_file_max_size == 100000000
    assert parser.options.log_file_num_backups == 10
    assert parser.options.log_rotate_when == 'midnight'
    assert parser.options.log_rotate_interval == 1
    assert parser.options.log_rotate_mode == 'size'
    assert parser.options.log_to_stderr == True
    parser.parse_args(['--log_file_prefix','/var/log/tornado.log'])
    assert parser.options.log_file_prefix

# Generated at 2022-06-24 08:49:46.217034
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    color_formatter = LogFormatter()
    assert color_formatter._normal == ""
    assert color_formatter._colors == {}

    color_formatter = LogFormatter(color=False)
    assert color_formatter._normal == ""
    assert color_formatter._colors == {}

    color_formatter = LogFormatter(color=True)
    assert color_formatter._normal != ""
    assert color_formatter._colors != {}


# Generated at 2022-06-24 08:49:53.553045
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    tornado.options.parse_command_line(["--logging=DEBUG"])
    tornado.log.enable_pretty_logging(options=tornado.options.options)
    gen_log.warning("This is a test")
    assert gen_log.getEffectiveLevel() == logging.DEBUG
    gen_log.setLevel(logging.INFO)
    gen_log.warning("This is a test")
    assert gen_log.getEffectiveLevel() == logging.INFO
    tornado.options.parse_command_line()
    gen_log.warning("This is a test")
    assert gen_log.getEffectiveLevel() == logging.WARNING
    tornado.options.parse_command_line(["--logging=none"])

# Generated at 2022-06-24 08:49:56.791145
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.DEFAULT_FORMAT
    formatter.DEFAULT_DATE_FORMAT
    formatter.DEFAULT_COLORS



# Generated at 2022-06-24 08:49:58.753416
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = cast(Any,None)
    logger = None
    enable_pretty_logging(options, logger)

# Generated at 2022-06-24 08:50:08.834228
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.options

    options = tornado.options.options
    define_logging_options(options)
    options.logging = "info"
    options.log_to_stderr = True
    options.log_file_prefix = "mylog"
    options.log_file_max_size = 100 * 1000 * 1000
    options.log_file_num_backups = 10
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    options.log_rotate_mode = "size"
    enable_pretty_logging(options)
    #options.add_parse_callback(lambda: enable_pretty_logging(options))

# Generated at 2022-06-24 08:50:11.730992
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)
    tornado.options.parse_command_line()
    print("unit test ok")


test_define_logging_options()

# Generated at 2022-06-24 08:50:19.661061
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import time
    import sys

    # Example LogRecord
    record = logging.LogRecord(
        name="tornado.application",
        level=logging.WARNING,
        pathname="tornado/stack_context.py",
        lineno=185,
        msg="Exception in callback %r",
        args=("abc",),
        exc_info=None,
    )
    datefmt = "%y%m%d %H:%M:%S"
    record.created = time.time()
    record.msecs = record.created * 1000 % 1000

    # Example Formatter

# Generated at 2022-06-24 08:50:23.198714
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO, format="%(message)s")
        enable_pretty_logging()
        logging.info("info")
        logging.warning("warning")
        logging.error("error")
    else:
        logging.info("info")
        logging.warning("warning")
        logging.error("error")

if __name__ == '__main__':
	test_enable_pretty_logging()

# Generated at 2022-06-24 08:50:33.821481
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    tornado.options.parse_command_line(["--logging=INFO","--log_rotate_mode=size","--log_file_prefix=test.log","--log_to_stderr=False","--log_file_max_size=104857600","--log_file_num_backups=5"])
    enable_pretty_logging()
    logger = logging.getLogger("tornado.general")
    logger.setLevel(logging.DEBUG)
    print(logger.getEffectiveLevel())
    print(logger.handlers[0].get_name())
    print(logger.handlers[0].stream)
    print(logger.handlers[0].maxBytes)

# Generated at 2022-06-24 08:50:42.566528
# Unit test for function define_logging_options
def test_define_logging_options():

    import sys
    import tornado.options
    options = tornado.options.options

    define_logging_options(options)

    argv_backup = sys.argv
    try:
        sys.argv = ["test_command", "--logging=debug"]

        tornado.options.parse_command_line()

        assert options.logging == "debug"
    except Exception as e:
        print(str(e))
    finally:
        sys.argv = argv_backup

# Generated at 2022-06-24 08:50:51.640978
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter().format("hallo")

formatter = LogFormatter()
"""Default formatter used for Tornado log output.

This is a `tornado.log.LogFormatter` instance with the following
configuration:

 * ``color`` is true (ANSI color codes will be used when logging to a
   terminal that supports it)
 * ``datefmt`` is "%y%m%d %H:%M:%S" (the default used in zlog)
 * ``fmt`` is "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
"""

# Make sure access_log doesn't have a NullHandler
if not access_log.handlers:
    access_log.addHandler(logging.NullHandler())

# Make sure

# Generated at 2022-06-24 08:51:01.885778
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    import tornado.testing
    import tornado.util
    import logging
    import os
    import re
    # Create sub logger for test

    log_file_prefix="test.log"

    subLoger=logging.getLogger("test")
    define_logging_options(options)

    subLoger.info("unit test start")

    # Does tornado.options.define_logging_options call enable_pretty_logging?
    assert os.path.isfile(log_file_prefix)

    p=re.compile("\[I \d{8}\s\d{2}:\d{2}:\d{2} test:\d{3}\] unit test start")
    f=open(log_file_prefix,'r')
    res=f.read()
    f.close()

# Generated at 2022-06-24 08:51:05.794323
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import sys 
    logger = logging.getLogger()
    channel = logging.StreamHandler(sys.stdout)
    channel.setFormatter(LogFormatter())
    logger.addHandler(channel)
    logger.setLevel(logging.DEBUG)
    logger.info("Test")
test_enable_pretty_logging()

# Generated at 2022-06-24 08:51:14.510563
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class obj:
        __dict__ = {}

    formatter = LogFormatter()
    record = obj()
    record.__dict__ = {'msg': 'hello'}
    formatter.format(record)

    record = obj()
    record.__dict__ = {'msg': u'\u1234'}
    formatter.format(record)

    record = obj()
    record.__dict__ = {
        'exc_info': sys.exc_info(),
        'msg': 'hello'
    }
    formatter.format(record)


# Generated at 2022-06-24 08:51:24.868792
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    import logging
    import unittest
    import os
    import tempfile
    
    define("logging", default=None, help="logging level", type=str)
    
    define("log_file_prefix", type=str, help="log file")
    define("log_rotate_mode", type=str, help="log rotate mode")
    define("log_rotate_when", type=str, help="log rotate when")
    define("log_rotate_interval", type=int, help="log rotate interval")
    define("log_file_max_size", type=int, help="log file max size")
    define("log_file_num_backups", type=int, help="log file number backups")

# Generated at 2022-06-24 08:51:35.562234
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    assert (options.options.logging == "info")
    assert (options.options.log_to_stderr == None)
    assert (options.options.log_file_prefix == None)
    assert (options.options.log_file_max_size == 100000000)
    assert (options.options.log_file_num_backups == 10)
    assert (options.options.log_rotate_when == "midnight")
    assert (options.options.log_rotate_interval == 1)
    assert (options.options.log_rotate_mode == "size")
    
    

# Generated at 2022-06-24 08:51:45.772346
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    import time

    import unittest.mock

    now = time.time()


# Generated at 2022-06-24 08:51:50.232414
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    logging.basicConfig()
    logger = logging.getLogger()
    handler = logging.StreamHandler()
    handler.setFormatter(LogFormatter())
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.info("hello world")



# Generated at 2022-06-24 08:51:52.677517
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    return None
import unittest

# Generated at 2022-06-24 08:51:56.476057
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(logging="error")
    assert logging.getLogger().getLevel() == logging.ERROR
    

test_enable_pretty_logging()
import logging, random
import time



# Generated at 2022-06-24 08:52:05.779900
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.gen_test

    # TODO(benjamin): exctract from logging_test
    class Options(object):
        def __init__(
            self,
            logging,
            log_file_prefix,
            log_rotate_mode,
            log_rotate_when,
            log_rotate_interval,
            log_file_max_size,
            log_file_num_backups,
        ):
            self.logging = logging
            self.log_file_prefix = log_file_prefix
            self.log_rotate_mode = log_rotate_mode
            self.log_rotate_when = log_rotate_when
            self.log

# Generated at 2022-06-24 08:52:11.541461
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    options = tornado.options.options
    options.logging = "error" # type: ignore
    options.log_file_prefix = "./test_log" # type: ignore
    logger = logging.getLogger()
    enable_pretty_logging(options, logger)

# Generated at 2022-06-24 08:52:18.916532
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, define, options
    parser = OptionParser()
    define("name", type=str, default=None, help="version")
    parser.add_option("--version", dest="version", help="version")
    parser.add_option("--address", dest="address", help="address")
    define("",type=str,default=None,help="")
    define_logging_options()
    parser.parse_args()
    print(options.name)
    print(options.address)
    print(options.version)
# test_define_logging_options()

# Generated at 2022-06-24 08:52:19.825455
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()
    return True

# Generated at 2022-06-24 08:52:25.560729
# Unit test for method format of class LogFormatter

# Generated at 2022-06-24 08:52:37.907776
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    options=tornado.options.options
    def stub_getattr(name):
        return {'debug':logging.DEBUG,'info':logging.INFO,'warning':logging.WARNING,'error':logging.ERROR,'critical':logging.CRITICAL}[name]
    
    def stub_parse_command_line(options):
        options.logging="critical"
        options.log_file_prefix="stub.log"
        options.log_file_num_backups=123
        options.log_file_max_size=12345
        options.log_rotate_mode="size"
        options.log_rotate_when="size"
        options.log_rotate_interval=123
        options.log_to_stderr=None

    import unittest

# Generated at 2022-06-24 08:52:46.787389
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    import tornado.log

    options = tornado.options.options
    options.log_file_prefix = "./ttt"
    options.log_rotate_mode = "time"
    options.log_rotate_when = "S"
    options.log_rotate_interval = 86400
    options.log_file_num_backups = 10
    options.log_to_stderr = True
    tornado.log.enable_pretty_logging(options)

# Generated at 2022-06-24 08:52:50.663201
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.makeLogRecord({"msg": "", "levelno": logging.DEBUG})
    formatter.format(record)



# Generated at 2022-06-24 08:52:57.796557
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class test_options():
        pass
    options = test_options()
    options.logging = "debug"
    options.log_file_prefix = "/tmp/app"
    options.log_rotate_mode = "time"
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    options.log_file_num_backups = 30
    options.log_to_stderr = True
    enable_pretty_logging(options)

# Generated at 2022-06-24 08:53:08.616203
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class TestHandler(logging.Handler):
        def __init__(self, **kwargs):
            super(TestHandler, self).__init__(**kwargs)
            self.records = []  # type: List[Any]
        def emit(self, record):
            self.records.append(record)

# Generated at 2022-06-24 08:53:22.168764
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.options
    define_logging_options(options)
    # test the default value of all options
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)
    #options.parse_command_line()
    #print(options.log_to_stderr)
    #options.log_to_stderr = True
    #print(options.log_to_stderr)
    #print(