

# Generated at 2022-06-12 13:46:12.251536
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
   import logging
   import tornado.options
   import tornado.testing

   class OptionTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(OptionTest, self).setUp()
            tornado.options.define("log_file_prefix", None)
            tornado.options.define("log_to_stderr", None)
            tornado.options.define("logging", None)
            tornado.options.define("log_rotate_mode", "time")
            tornado.options.define("log_rotate_when", "S")
            tornado.options.define("log_rotate_interval", 1)
            tornado.options.define("log_file_num_backups", 5)
            # Large enough that a log file will be rotated on every write.

# Generated at 2022-06-12 13:46:21.353608
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.Logger("test")
    logger.handlers = [logging.StreamHandler(sys.stdout)]
    logger.propagate = False

    class Object(object):
        pass
    
    options = Object()
    options.logging = "debug"
    options.log_file_prefix = "log"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 5
    options.log_to_stderr = True
    options.log_rotate_mode = 2

    log_tornado_gen(logger, options, colorama)
    logger.debug("test")


# Generated at 2022-06-12 13:46:21.743341
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-12 13:46:27.120044
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.platform.auto import set_close_exec
    from tornado.testing import AsyncTestCase
    import io
    import sys
    import unittest.mock as mock
    from logging import LogRecord
    # The '%(levelname)s' format string produces some unicode
    # characters in Python 2
    if sys.version_info < (3,):
        fmt = "TEST: %(levelname)s %(message)s"
    else:
        fmt = "TEST: %(message)s"

    formatter = LogFormatter(fmt=fmt)
    record = LogRecord(
        "tornado.test", logging.WARNING, "tornado/test/test_log.py", 42, "hello", (), None
    )

    # add some attributes
    record.levelname = "WARNING"


# Generated at 2022-06-12 13:46:28.759243
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    a = LogFormatter()
    print(a)



# Generated at 2022-06-12 13:46:37.043805
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    class Record(object):
        def __init__(self, levelno: int, exc_info: Any) -> None:
            self.levelno = levelno
            self.exc_info = exc_info
        def getMessage(self) -> str:
            return 'test message'
        def __dict__(self) -> Dict[str, Any]:
            return {
                'levelname': 'INFO',
                'asctime': '2019-12-31',
                'module': 'abc',
                'lineno': 123,
            }
    record = Record(logging.INFO, None)
    log_formatter.format(record)



# Generated at 2022-06-12 13:46:39.840344
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fmt.format(logging.LogRecord('test', logging.DEBUG, './test.py', 23, 'Message test', None, None))

# Generated at 2022-06-12 13:46:46.138366
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = LogFormatter(color=True, fmt="%(color)s%(levelname)s%(end_color)s %(message)s") # noqa: E501
    formatter = logging.Formatter("test")
    assert fmt.datefmt == formatter.datefmt
    assert fmt._fmt == formatter._fmt

# Generated at 2022-06-12 13:46:56.367160
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # get a LogFormatter object to test
    formatter = LogFormatter()
    # Prepare a fake record
    class fake_record:
        def __init__(self, levelno):
            self.levelno = levelno
            # The next few lines are to generate real log messages
            # and add them to the fake record
            logging.basicConfig(filename='app_log.log', 
                    format='%(levelname)s:%(module)s:%(lineno)d: %(message)s', level=logging.DEBUG)
            self.msg = "Tornado is a Python web framework and asynchronous networking library"
            self.module = "LogFormatter"
            self.lineno = 124
            app_log.warning(self.msg);
            app_log.debug(self.msg);

# Generated at 2022-06-12 13:47:07.958772
# Unit test for function enable_pretty_logging

# Generated at 2022-06-12 13:47:20.083004
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

__test__ = {"test_enable_pretty_logging": test_enable_pretty_logging}  # type: Dict[str, Any]

# Generated at 2022-06-12 13:47:27.870859
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    time = 'time of record'
    levelname = 'info'
    module = 'module'
    line = '55'
    message = 'message'
    end_color = 'end_color'
    color = 'color'
    end_color = 'end_color'
    record = {
        'asctime': time,
        'levelname': levelname,
        'module': module,
        'lineno': line,
        'message': message,
        'color': color,
        'end_color': end_color
    }
    result = LogFormatter().format(record)
    assert result == '[%s %s %s:%s] %s' % (levelname, time, module, line, message)
    
    

    



# Generated at 2022-06-12 13:47:29.817183
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create and return a test suite
    import doctest
    return doctest.DocTestSuite()



# Generated at 2022-06-12 13:47:34.456736
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG)
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.gen", logging.DEBUG, filename='...', lineno=1, msg='message', args=None, exc_info=None)
    formatter.format(record)


# Generated at 2022-06-12 13:47:35.879398
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """Unit test for function enable_pretty_logging"""
    enable_pretty_logging()

# Generated at 2022-06-12 13:47:44.586479
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Simplified version of the test in Tornado.
    from io import StringIO
    from logging import StreamHandler

    # Set up logging.
    logger = logging.getLogger("tornado.test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = StreamHandler(stream)
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # If debug_log is defined, set it; this will cause all the log messages to
    # be written to the log instead of stdout, which makes the tests less
    # noisy.
    logger.debug("debug message")
    assert stream.getvalue().endswith("debug message\n")

    # This tests that unicode messages are handled correctly
    logger.info("\u1234")
   

# Generated at 2022-06-12 13:47:50.311315
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # mimicing what _safe_unicode does
    def safe_unicode(s):  # type: (str) -> str
        try:
            return unicode_type(s)
        except UnicodeDecodeError:
            return s
    def init_log_formatter(
        fmt,
        datefmt,
        style,
        color,
        colors=LogFormatter.DEFAULT_COLORS,
    ) -> LogFormatter:
        return LogFormatter(fmt, datefmt, style, color, colors)

# Generated at 2022-06-12 13:47:55.776444
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
    except ImportError:
        return
    tornado.options.define("logging", type=str)
    tornado.options.options.logging = "none"
    enable_pretty_logging()
    assert len(gen_log.handlers) == 0
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    assert gen_log.level == logging.DEBUG
    assert len(gen_log.handlers) == 1
    assert isinstance(gen_log.handlers[0], logging.StreamHandler)
    tornado.options.options.logging = "warning"
    enable_pretty_logging()
    assert gen_log.level == logging.WARNING
    assert len(gen_log.handlers) == 1

# Generated at 2022-06-12 13:48:05.285101
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #coding:utf-8
    """
    测试方法
    """
    # 定义一个Logger
    logger = logging.getLogger('MyLogger')
    # 设置Logger等级
    logger.setLevel(logging.DEBUG)
    # 创建一个handler，用于写入日志文件
    fh = FileHandler('test.log')
    # 再创建一个handler，用于输出到控制台
    ch = logging.StreamHandler()
    # 定义handler的输出格式

# Generated at 2022-06-12 13:48:14.964318
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = '%y%m%d %H:%M:%S'
    style = '%'
    color = True
    colors = { logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5 }  # noqa: E501

    logging.getLogger("tornado.access").addHandler(logging.NullHandler())
    logging.getLogger("tornado.application").addHandler(logging.NullHandler())
    logging.getLogger("tornado.general").addHandler(logging.NullHandler())

    log

# Generated at 2022-06-12 13:48:37.780763
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_formatter = LogFormatter(color=False, colors={})
    assert isinstance(log_formatter, LogFormatter)
    log_formatter = LogFormatter(color=False, colors={logging.DEBUG: 0})
    assert isinstance(log_formatter, LogFormatter)



# Generated at 2022-06-12 13:48:48.285447
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = app_log
    data = {
        'format': "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        'datefmt': "%y%m%d %H:%M:%S",
        'style': "%",
        'color': True,
        'colors': {
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        },
    }
    formatter = LogFormatter(**data)
    logger.setFormatter(formatter)
    a = data

# Generated at 2022-06-12 13:48:51.562394
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT


# Generated at 2022-06-12 13:48:59.555041
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter(
        fmt="%(asctime)s %(color)s%(levelname)1.1s%(end_color)s "
            "%(message)s",
        datefmt="%y%m%d %H:%M:%S")
    a=fmt.format(logging.makeLogRecord({'asctime': 1333863602.337, 'levelname': 'WARNING', 'message': 'test_LogFormatter_format_message'})) # noqa: E501
    print(a)

# Generated at 2022-06-12 13:49:01.434663
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(filename="test_log.log", level=logging.DEBUG,)
    enable_pretty_logging()
    logging.info("hello world")
# test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:07.899314
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/test/path",
        lineno=1,
        msg="test",
        args=(),
        exc_info=None,
    )
    formatter.format(record)
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.INFO,
        pathname="/test/path",
        lineno=1,
        msg="test",
        args=(),
        exc_info=Exception("error"),
    )
    formatter.format(record)



# Generated at 2022-06-12 13:49:13.849984
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    # Tornado options must be initialized before calling
    # `enable_pretty_logging()`
    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("log_rotate_interval", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("logging", type=str)
    tornado.options.define("log_to_stderr", type=bool)

# Generated at 2022-06-12 13:49:18.177932
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    def mock_formatTime(record, datefmt = None):
        return '1'
    def mock_formatException(record):
        return '2'
    formatter.formatTime = mock_formatTime
    formatter.formatException = mock_formatException
    class Record:
        def __init__(self):
            self.__dict__['exc_info'] = None
            self.__dict__['levelno'] = 1
            self.__dict__['message'] = 'test'
            self.__dict__['exc_text'] = None
        def __setattr__(self, key, value):
            self.__dict__[key] = value
        def getMessage(self):
            return 'test'
    record = Record()
    record.__dict__['exc_info'] = None

# Generated at 2022-06-12 13:49:30.461138
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import sys
    import tempfile
    options = tornado.options.options
    options.logging = "none"
    rotate_mode = "time"
    options.log_file_prefix = tempfile.mktemp()
    options.log_file_num_backups = 5
    if rotate_mode == "time":
        options.log_rotate_mode = "time"
        options.log_rotate_when = "H"
        options.log_rotate_interval = 10
    enable_pretty_logging()
    logger = logging.getLogger()
    assert len(logger.handlers) == 0
    options.logging = "error"
    enable_pretty_logging()
    logger = logging.getLogger()
    assert len(logger.handlers)

# Generated at 2022-06-12 13:49:41.808762
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    _stderr_supports_color()
    logger = logging.getLogger("test_class_LogFormatter")
    logger.setLevel(logging.DEBUG)
    # create console handler with a higher log level
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter and add it to the handlers
    formatter = LogFormatter(color=True)
    ch.setFormatter(formatter)
    # add the handlers to logger
    logger.addHandler(ch)
    logger.debug("test_debug_LogFormatter")
    logger.info("test_info_LogFormatter")
    logger.warning("test_warn_LogFormatter")
    logger.error("test_error_LogFormatter")
    logger.critical("test_critical_LogFormatter")

#

# Generated at 2022-06-12 13:50:17.419759
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    assert LogFormatter().format(
        logging.LogRecord(
            "foo",
            1,
            "test_LogFormatter",
            1,
            "hello %s",
            ("world",),
            None
        )
    ) == "[0 0001-01-01 00:00:00 test_LogFormatter:1] hello world"
    assert LogFormatter().format(
        logging.LogRecord(
            "foo",
            1,
            "test_LogFormatter",
            1,
            "hello %s",
            (b"world",),
            None
        )
    ) == "[0 0001-01-01 00:00:00 test_LogFormatter:1] hello world"



# Generated at 2022-06-12 13:50:23.487905
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import gen_log
    formatter = LogFormatter()
    record = logging.LogRecord("name", 1, "/var/log/messages", 1, "message", {}, None)
    assert formatter.format(record) == "[I 0101/000000 /var/log/messages:1] message"


# Generated at 2022-06-12 13:50:34.345330
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: no cover
    class DummyRecord(object):
        pass
    record = DummyRecord()
    record.name = "tornado.access"
    record.msg = "foo"
    record.args = ()
    record.module = "logging_tests"
    record.funcName = "wrapper"
    record.lineno = 42
    record.exc_info = None
    record.exc_text = None
    record.stack_info = None
    record.levelno = logging.INFO
    record.levelname = "INFO"
    record.created = 1589242419
    record.msecs = 691
    record.relativeCreated = 1423
    record.thread = 140735198466432
    record.process = 7861
    record.processName = "MainProcess"
    record.thread

# Generated at 2022-06-12 13:50:41.188901
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging.handlers
    import sys
    h = logging.handlers.SysLogHandler(address='/dev/log')
    fmt = h.formatter = LogFormatter(color=True)
    record = logging.LogRecord('tornado.app', logging.INFO,
                               None, None, 'hello',
                               None, None)
    rv = fmt.format(record)
    print(fmt)
    print(record)
    print(rv)

# Setup color if we are in a tty and curses is installed
color = False
if curses and sys.stderr.isatty():
    try:
        curses.setupterm()
        if curses.tigetnum("colors") > 0:
            color = True
    except Exception:
        pass

# test_LogFormatter_format()


# Generated at 2022-06-12 13:50:52.371904
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    a = logging.Formatter()
    b = a.datefmt
    a.format(b)
    LogFormatter(format = "default", datefmt = "%y%m%d %H:%M:%S", style = "%", color = True)
    LogFormatter(datefmt = "%y%m%d %H:%M:%S", style = "%", color = True)
    LogFormatter(format = "default", datefmt = "%y%m%d %H:%M:%S", color = True)
    LogFormatter(format = "default", datefmt = "%y%m%d %H:%M:%S", style = "%")
    LogFormatter()
    LogFormatter(format = "default")

# Generated at 2022-06-12 13:51:00.096624
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    output = """[INFO  test_LogFormatter:10] test log message
[DEBUG test_LogFormatter:11] debug log message
[ERROR test_LogFormatter:12] error log message
[CRITICAL test_LogFormatter:13] critical log message
[WARNING test_LogFormatter:14] message=warning log message"""

# Generated at 2022-06-12 13:51:10.192559
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.enable_pretty_logging()
    logger = logging.getLogger()
    assert logger.getEffectiveLevel() == logging.DEBUG
    assert len(logger.handlers) == 1
    assert logger.handlers[0].stream.name == '<stderr>'

    tornado.options.options.logging = 'INFO'
    tornado.options.options.log_file_prefix = 'logs/app.log'
    tornado.options.enable_pretty_logging()
    assert logger.getEffectiveLevel() == logging.INFO
    assert len(logger.handlers) == 2
    assert logger.handlers[0].stream.name == 'logs/app.log'

# Generated at 2022-06-12 13:51:16.698171
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """
    >>> test_LogFormatter()
    """
    logger = logging.getLogger('test')
    new_formatter = LogFormatter()
    handler = logging.StreamHandler()
    handler.setFormatter(new_formatter)
    logger.addHandler(handler)
    logger.warn('test')


# Generated at 2022-06-12 13:51:17.681489
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:51:26.602664
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import pytest

    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "test datefmt"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }


    # test 'color' and 'end_color' in fmt will be blank, if color not supported

# Generated at 2022-06-12 13:51:52.049470
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s", datefmt="%m%d %H:%M:%S")  # noqa: E501
    LogFormatter(fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s", datefmt="%m%d %H:%M:%S", style="%")  # noqa: E501

# Generated at 2022-06-12 13:51:55.342526
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # the function enable_pretty_logging has no return value,
    # but this is to test if it can run without error.
    import tornado.options

    options = tornado.options.options
    options.logging = "none"
    options.log_file_prefix = ""
    logging.basicConfig(level=logging.DEBUG)
    enable_pretty_logging(options)



# Generated at 2022-06-12 13:52:01.200943
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = 'WARNING'

    class test_logger(logging.Logger):
        def __init__(self, *args):
            self.setLevel(logging.WARNING)

    test_log = test_logger('test')
    try:
        enable_pretty_logging(tornado.options.options, test_log)
        assert test_log.level == logging.WARNING
    except:
        print('Tests failed!')

# Unit tests for class LogFormatter

# Generated at 2022-06-12 13:52:07.252914
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class LogRecordClass:
        def __init__(self) -> None:
            self.message = "test get message"
            self.asctime = "test asctime"
            self.color = "test color"
            self.end_color = "test end color"
        def getMessage(self) -> str:
            return self.message
    
    log = LogFormatter()
    log_record = LogRecordClass()
    test = log.format(log_record)
    assert(test == '[I 0 test asctime :0] test get message')
    
test_LogFormatter_format()



# Generated at 2022-06-12 13:52:08.258250
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    enable_pretty_logging()

# Generated at 2022-06-12 13:52:09.986026
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import parse_command_line, define, options as OPTIONS
    parse_command_line()
    app_log.debug("hello world")


# Generated at 2022-06-12 13:52:21.693784
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado import options
    options.options.logging = None
    options.options.log_file_prefix = None
    options.options.log_rotate_mode = "size"
    options.options.log_file_max_size = 1
    options.options.log_file_num_backups = 1
    options.options.log_rotate_when = None
    options.options.log_rotate_interval = 1
    options.options.log_to_stderr = None
    logger = logging.getLogger()
    assert logger.handlers == []
    enable_pretty_logging()
    assert logger.handlers
    assert logger.handlers[0].formatter.DEFAULT_FORMAT
    assert logger.handlers[0].formatter.DEFAULT_DATE_FORMAT
    assert logger.hand

# Generated at 2022-06-12 13:52:27.839026
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter(color=True, fmt="[%(asctime)s] %(message)s")
    record = logging.LogRecord('tornado.general', logging.DEBUG,
        pathname=None, lineno=None, msg='log message', args=None, exc_info=None)
    # log message should not be modified by format()
    assert formatter.format(record) == "[%(asctime)s] log message"
    record.message = '!' * 1000
    formatter.format(record)  # should not raise an exception



# Generated at 2022-06-12 13:52:38.377504
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("log_to_stderr", default=None)
    tornado.options.define("log_file_prefix", default="helloworld.log")
    tornado.options.define("log_rotate_mode", default="size")
    tornado.options.define("log_file_max_size", default=100)
    tornado.options.define("log_file_num_backups", default=1)
    tornado.options.define("logging", default='debug')
    tornado.log.enable_pretty_logging(logger=tornado.log.app_log)
    tornado.log.app_log.info('testing')
test_enable_pretty_logging()

# Generated at 2022-06-12 13:52:41.730231
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_formatter = LogFormatter()
    assert log_formatter
    # pylint: disable=protected-access
    assert log_formatter._colors
    assert log_formatter._normal



# Generated at 2022-06-12 13:53:14.136222
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class record():
        def __init__(self):
            self.levelno = logging.DEBUG
            self.message = "hello"
            self.getMessage = lambda: self.message
            self.exc_info = None
        def __getattr__(self, x):
            return None
    formatter = LogFormatter()
    assert formatter.format(record()) == "[D hello]\n"


# Generated at 2022-06-12 13:53:14.715063
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-12 13:53:16.938090
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    logging.info("Hi")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:53:26.139825
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    logger = logging.getLogger("tornado.test")
    logger.propagate = False

    formatter = LogFormatter()
    fh = logging.StreamHandler()
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    logger.setLevel(logging.DEBUG)

    logger.debug("test")
    logger.warning("test")

    # test unicode
    logger.debug(u"\u82b1")
    logger.error(u"\u82b1")

# Based on http://stackoverflow.com/questions/384076/how-can-i-color-python-logging-output
# Thanks to e4c5 for the code.



# Generated at 2022-06-12 13:53:29.108949
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log

    d = dict(x='x')
    frm = tornado.log.LogFormatter()

    # Check if format is correct
    frm.format(d)    # should not raise an exception


# Generated at 2022-06-12 13:53:30.298382
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert isinstance(f, LogFormatter)

# Generated at 2022-06-12 13:53:31.237914
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:53:36.253687
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        import curses
    except ImportError:
        return
    formatter = LogFormatter()
    assert isinstance(formatter._colors, dict)
    assert formatter._normal == unicode_type(curses.tigetstr("sgr0"), "ascii")



# Generated at 2022-06-12 13:53:44.512989
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging, tornado.options
    tornado.options.options.log_file_prefix = '1.log'
    tornado.options.options.log_rotate_mode = 'size'
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.logging = 'info'
    logging.basicConfig()
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    log.debug("This is a debug message.")
    log.info("This is an info message.")
    log.warning("This is a warning message.")
    log.error("This is an error message.")
    log.critical("This is a critical message.")

if __name__ == "__main__":
    test_enable

# Generated at 2022-06-12 13:53:46.325689
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options=None)

