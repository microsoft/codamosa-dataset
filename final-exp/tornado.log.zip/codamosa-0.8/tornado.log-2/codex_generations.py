

# Generated at 2022-06-12 13:46:10.052896
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:46:11.249342
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass
                       


# Generated at 2022-06-12 13:46:22.069103
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import access_log, app_log, gen_log, LogFormatter
    from tornado.httpclient import HTTPRequest, AsyncHTTPClient, HTTPError
    from tornado.web import RequestHandler, Application, url
    from tornado.ioloop import IOLoop
    import logging
    import sys
    import xml.etree.ElementTree as ET
    import xml.dom.minidom as minidom

    class MainHandler(RequestHandler):
        def get(self):
            app_log.info('info')
            app_log.warning('warning')
            app_log.error('error')
            app_log.critical('critical')

    class TestLogFormatter(LogFormatter):
        def format(self, record: Any) -> str:
            message = record.getMessage()

# Generated at 2022-06-12 13:46:24.376971
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Arrange
    formatter = LogFormatter()
    record = {}
    # Act
    actual = formatter.format(record)
    # Assert
    assert actual == '[None None None:None] Unknown message ({}): {}'


# Generated at 2022-06-12 13:46:30.892477
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: no cover
    class DummyLogRecord:
        pass
    formatter = LogFormatter()
    record = DummyLogRecord()
    record.name = "tornado.general.test"
    record.msg = "testing %s"
    record.args = ("abc",)
    record.exc_info = None
    record.levelno = logging.DEBUG
    record.levelname = logging.getLevelName(record.levelno)
    record.pathname = None
    record.filename = None
    record.module = "test_log"
    record.lineno = 1
    record.funcName = "test"
    record.created = 1
    record.msecs = 1
    record.relativeCreated = 1
    record.process = 1
    record.thread = 1
    record.processName = "Process"

# Generated at 2022-06-12 13:46:37.270486
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    class LogFormatter(logging.Formatter):
        def __init__(self):
            self._colors = {
				logging.DEBUG: "Blue",
				logging.INFO: "Green",
				logging.WARNING: "Yellow",
				logging.ERROR: "Red",
				logging.CRITICAL: "Magenta",
            }
		
    f = LogFormatter()
    g = f.format('a')
    return (g == 'a')

# Generated at 2022-06-12 13:46:49.210435
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    class Record:
        def __init__(self, msg: str = "", levelno: int = 0) -> None:
            self.msg = msg
            self.levelno = levelno

        def getMessage(self) -> str:
            return self.msg

    record = Record('msg')

    log_formatter = LogFormatter()
    assert log_formatter.format(record) == '[DEBU msg] '
    assert log_formatter.format(record) == '[DEBU msg] '
    assert log_formatter.format(record) == '[DEBU msg] '

    log_formatter = LogFormatter(fmt="%(color)s%(message)s%(end_color)s")
    assert log_formatter.format(record) == 'msg'

# Generated at 2022-06-12 13:46:58.347934
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger("tornado_test")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    logger.handlers = []

    stderr = logging.StreamHandler()
    stderr.setLevel(logging.DEBUG)
    logger.addHandler(stderr)

    # set up color if we are in a tty and curses is installed
    color = False
    if curses and sys.stderr.isatty():
        try:
            curses.setupterm()
            if curses.tigetnum("colors") > 0:
                color = True
        except:
            pass
    if color:
        color_formatter = LogFormatter(fmt="%(color)s%(message)s%(end_color)s")
        stderr.setForm

# Generated at 2022-06-12 13:47:04.306780
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print("test_LogFormatter_format")
    import io
    import logging
    import types

    # Capture the logging output.
    save_handler = app_log.handlers[:]
    save_level = app_log.level
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    app_log.handlers[:] = [handler]
    app_log.setLevel(logging.DEBUG)

    # Output a sequence of log lines.
    app_log.info("info")
    app_log.warning("warning")
    app_log.debug("debug")
    app_log.error("error")

# Generated at 2022-06-12 13:47:11.212830
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    """
    >>> from __future__ import unicode_literals
    >>> from tornado.log import LogFormatter
    >>> f=LogFormatter()
    >>> print('[D G thelogger: 1] the message')
    [D G thelogger: 1] the message
    >>> print(f.format(logging.LogRecord('thelogger', logging.DEBUG, '', 1, 'the message', (), None)))
    [D G thelogger: 1] the message
    """

if not logging.getLogger().handlers:
    # Logging has not been configured.  Add a default NullHandler.
    logging.getLogger().addHandler(logging.NullHandler())



# Generated at 2022-06-12 13:47:23.046378
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado import logging
    options = tornado.options.options
    options.logging = "none"
    enable_pretty_logging(options)
    options.logging = None
    enable_pretty_logging(options)

# Generated at 2022-06-12 13:47:30.114015
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import inspect
    import os
    import sys

    sourceFile = inspect.getfile(LogFormatter)
    absFilePath = os.path.abspath(sourceFile)
    fileDir = os.path.dirname(absFilePath)
    parentDir = os.path.dirname(fileDir)
    sys.path.insert(0, parentDir)
    from tornado.log import LogFormatter, access_log, app_log, gen_log

    log = LogFormatter()
    access_log.info("test message")
    app_log.info("test message")
    gen_log.info("test message")
    app_log.info("test error", exc_info=True)
    # self.assertEqual('1', '1')
    # self.assertEqual(response.status_code, 200)
   

# Generated at 2022-06-12 13:47:32.724983
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._colors == {}
    assert LogFormatter(color=False)._colors == {}
    assert LogFormatter(color=True)._colors != {}


# Generated at 2022-06-12 13:47:38.656042
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formater= LogFormatter()
    class LogRecord:
        pass
    lr= LogRecord()
    lr.message="hello"
    lr.levelno=0
    lr.asctime=str(20171227)
    lr.color=""
    lr.end_color=""
    print(log_formater.format(lr))

# logging.Handler Derived class

# Generated at 2022-06-12 13:47:42.631037
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter(
        datefmt=LogFormatter.DEFAULT_DATE_FORMAT,
        fmt=LogFormatter.DEFAULT_FORMAT,
        style="%",
        color=True,
        colors={
            logging.ERROR: 1,
            logging.DEBUG: 4,
            logging.CRITICAL: 5,
            logging.WARNING: 3,
            logging.INFO: 2,
        },
    )


# predefined log formatters
DEFAULT_LOGGING_FORMAT = "%(color)s%(levelname)s%(end_color)s %(message)s"


# Generated at 2022-06-12 13:47:53.982932
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """
    Run unit test for function `enable_pretty_logging`
    """
    class Options(object):
        """Mock class for tornado options"""
        logging = "debug"
        log_file_prefix = None
        log_to_stderr = False
        log_rotate_mode = None
        log_file_max_size = None
        log_file_num_backups = None
        log_rotate_when = None
        log_rotate_interval = None

    enable_pretty_logging(Options())

    access_log.info("info message")
    app_log.error("error message")


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:48:04.181808
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    logger = logging.getLogger(__name__)
    handler = logging.StreamHandler()
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.setLevel(logging.DEBUG)
    logger.debug("Test of DEBUG level")
    logger.setLevel(logging.INFO)
    logger.info("Test of INFO level")
    logger.setLevel(logging.WARNING)
    logger.warning("Test of WARNING level")
    logger.setLevel(logging.ERROR)
    logger.error("Test of ERROR level")
    logger.setLevel(logging.CRITICAL)
    logger.critical("Test of CRITICAL level")



# Generated at 2022-06-12 13:48:05.752825
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:48:15.186381
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
 
    logRecord = logging.LogRecord(
        name='foo',
        level=logging.DEBUG,
        fn='foo.py',
        lno=1,
        msg='bar',
        args=(),
        exc_info=None)
    logRecord.created = datetime.datetime(2017, 10, 26, 22, 58, 40, 653000)
    logRecord.msecs = 653
    logRecord.relativeCreated = 653000
    logRecord.thread = 140733698860288
    logRecord.threadName = 'MainThread'
    logRecord.process = 1463
    logRecord.processName = 'MainProcess'
    logRecord.module = 'foo'
    logRecord.filename = 'foo.py'
    logRecord.funcName = '<module>'


# Generated at 2022-06-12 13:48:17.822090
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class TestLogFormatter(LogFormatter):
        pass
    TestLogFormatter()

if __name__ == "__main__":
    test_LogFormatter()

# Generated at 2022-06-12 13:48:48.147660
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    tornado.options.define('log_file_prefix', type=str)
    tornado.options.define('log_rotate_mode', type=str)
    tornado.options.define('log_file_max_size', type=int)
    tornado.options.define('log_file_num_backups', type=int)
    tornado.options.define('log_rotate_when', type=str)
    tornado.options.define('log_rotate_interval', type=int)
    tornado.options.define('log_to_stderr', type=str)
    tornado.options.define('logging', type=str)
    tornado.options.define('logfile', type=str)
    tornado.options.parse_command

# Generated at 2022-06-12 13:48:49.393780
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter is not None


# Generated at 2022-06-12 13:48:59.288540
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import logging
    import logging.handlers
    if sys.version_info >= (3,):
        fmt = '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'
    else:
        fmt = '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'
    dummy_handler = logging.handlers.SocketHandler('localhost', 12345)
    formatter = LogFormatter(fmt=fmt)
    assert formatter._fmt == fmt
    dummy_handler.setFormatter(formatter)


# Generated at 2022-06-12 13:49:06.109513
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): # type: () -> None
    fmt = "%(color)s%(levelname)s%(end_color)s %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt)
    assert formatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" # noqa: E501



# Generated at 2022-06-12 13:49:12.617246
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class MockLoggingHandler(logging.Handler):
        def handle(self, record):
            pass

        def emit(self, record):
            pass

        def createLock(self):
            self.lock = None

    handler = MockLoggingHandler()
    handler.setFormatter(LogFormatter())
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.debug("test")



# Generated at 2022-06-12 13:49:18.835758
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test that LogFormatter.format() works for all available record attributes.
    # This test fails if LogFormatter.format() raises an exception.
    formatter = LogFormatter()
    import datetime
    import time

    # all fields of a LogRecord are filled with dummy values
    level = 1
    now = datetime.datetime.now()
    now_tuple = now.timetuple()
    now_seconds = time.mktime(now_tuple)
    now_microseconds = now.microsecond
    record = logging.LogRecord(
        name="name",
        level=level,
        pathname="/path/to/file",
        lineno=1,
        msg="message",
        args=(),
        exc_info=None,
    )

    record.created = now_seconds
    record.msec

# Generated at 2022-06-12 13:49:30.943564
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import *
    x = LogFormatter()
    assert x.format(logging.LogRecord(
        name="tornado.general",
        level=logging.ERROR,
        msg="%s",
        args=("string",),
        exc_info=None,
    )) == "\033[2;31m[E %(asctime)s :0]\033[0m %(message)s"
    assert x.format(logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        msg="%s",
        args=("string",),
        exc_info=None,
    )) == "\033[2;34m[D %(asctime)s :0]\033[0m %(message)s"

# Generated at 2022-06-12 13:49:39.326780
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "/var/log/demo.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1000000
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.logging = "info"
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:45.469270
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._colors == {
        logging.DEBUG: "",
        logging.INFO: "",
        logging.WARNING: "",
        logging.ERROR: "",
        logging.CRITICAL: "",
    }

    if curses is None:
        assert LogFormatter(color=False)._colors == {
            logging.DEBUG: "",
            logging.INFO: "",
            logging.WARNING: "",
            logging.ERROR: "",
            logging.CRITICAL: "",
        }

# Generated at 2022-06-12 13:49:48.290593
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    define_logging_options(options)
    options.parse_command_line(['-log_file_prefix=/tmp/test', '-logging=error'])

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-12 13:50:39.139598
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert isinstance(LogFormatter.DEFAULT_FORMAT, str)
    assert isinstance(LogFormatter.DEFAULT_DATE_FORMAT, str)
    assert isinstance(LogFormatter.DEFAULT_COLORS, dict)


# Generated at 2022-06-12 13:50:42.443195
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter(color=True)
    assert fmt._colors.__len__() == 5
    assert fmt._normal == "\033[0m"

# Generated at 2022-06-12 13:50:47.049110
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: no cover
    formatter = LogFormatter()
    assert formatter._colors == formatter.DEFAULT_COLORS
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT



# Generated at 2022-06-12 13:50:47.980904
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    enable_pretty_logging()

# Generated at 2022-06-12 13:50:48.983485
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-12 13:50:56.027127
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """Test method format of class LogFormatter"""
    try:
        raise Exception('a')
    except Exception as e:
        exc_info = sys.exc_info()

    record = logging.LogRecord(
        name='name', level=logging.DEBUG, pathname='pathname',
        lineno=1, msg='msg', args=(), exc_info=exc_info, func='func'
    )

    lf = LogFormatter()
    s = lf.format(record)
    print(s)

    clean = lf.clean(s)
    print(clean)



# Generated at 2022-06-12 13:50:57.190484
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter



# Generated at 2022-06-12 13:50:58.648394
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options,logger)


# Generated at 2022-06-12 13:51:10.107706
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig()
    formatter = LogFormatter('%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s')
    log_record = logging.LogRecord('name','DEBUG','','','','','','','','','','','','','','','','','','','')
    log_record.name = 'name'
    log_record.levelname = 'DEBUG'
    log_record.lineno = 'lineno'
    
    format1 = formatter.format(log_record)
    format2 = formatter.format(log_record)
    assert format1 == format2
    assert isinstance(format1,str)


# Generated at 2022-06-12 13:51:22.061250
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest

    import tornado.log

    class TestLogFormatter(LogFormatter):
        def __init__(self) -> None:
            super().__init__(
                fmt="%(color)s%(levelname)1.1s%(end_color)s %(message)s",
                datefmt=None,  # use default
            )

    log = logging.getLogger("test_log")  # type: logging.Logger
    log.setLevel(logging.DEBUG)
    test_formatter = TestLogFormatter()
    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setFormatter(test_formatter)
    log.addHandler(stderr_handler)
    log.info("test message")

# Generated at 2022-06-12 13:52:59.407889
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="test.py",
        lineno=10,
        msg="test message",
        args=None,
        exc_info=None,
    )
    # format after set time
    formatter.formatTime(record, formatter.datefmt)
    # format after set message
    record.getMessage()
    formatter.format(record)
    
    
    
    
    
    

# Generated at 2022-06-12 13:53:11.331527
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import os
    import json
    import tempfile
    import tornado.options
    import tornado.log
    import unittest
    import tornado

    def get_dict_logger():
        log_file = tempfile.NamedTemporaryFile()
        logger = logging.getLogger()
        logger.propagate = False
        logger.setLevel(logging.DEBUG)
        channel = logging.FileHandler(log_file.name)
        channel.setFormatter(LogFormatter(color=False))
        logger.addHandler(channel)
        return log_file, logger

    def get_json_logger():
        log_file = tempfile.NamedTemporaryFile()
        logger = logging.getLogger()
        logger.propagate = False
        logger.setLevel(logging.DEBUG)
        channel = logging.Stream

# Generated at 2022-06-12 13:53:15.477138
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options=_Options()
    tornado.options.options.logging = "none"
    assert enable_pretty_logging() is None 
    tornado.options.options.logging="debug"
    assert enable_pretty_logging() is None



# Generated at 2022-06-12 13:53:16.359289
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    unittest.main()

# Generated at 2022-06-12 13:53:16.905993
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass


# Generated at 2022-06-12 13:53:18.081145
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-12 13:53:25.139786
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f.DEFAULT_FORMAT == "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    assert f.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert f.DEFAULT_COLORS == { logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3,
        logging.ERROR: 1, logging.CRITICAL: 5 }



# Generated at 2022-06-12 13:53:34.060286
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lg = LogFormatter(color=True)
    record = logging.LogRecord('name', logging.INFO, None, None, 'msg', None, None)
    res = lg.format(record)
    assert res == '[I 20100103 21:30:43 name:0] msg'
    record = logging.LogRecord('name', logging.INFO, None, None, 'msg', None, Exception('err'))
    res = lg.format(record)
    assert res == '[I 20100103 21:30:43 name:0] msg\n    Exception: err'
    record = logging.LogRecord('name', logging.CRITICAL, None, None, 'msg', None, Exception('err'))
    res = lg.format(record)

# Generated at 2022-06-12 13:53:36.467175
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformat = LogFormatter()
    assert logformat is not None

# Generated at 2022-06-12 13:53:44.686844
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():

    from tornado.options import options, define, parse_config_file
    import os
    define("logging", default='info')
    define("log_file_prefix", default=None)
    define("log_rotate_mode", default='time')
    define("log_rotate_when", default='MIDNIGHT')
    define("log_rotate_interval", default=1)
    define("log_file_max_size", default=104857600)
    define("log_file_num_backups", default=5)
    define("log_to_stderr", default=True)
