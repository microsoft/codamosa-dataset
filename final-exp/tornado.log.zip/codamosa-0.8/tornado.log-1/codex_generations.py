

# Generated at 2022-06-12 13:46:10.155806
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    ''' Unit test for method format of class LogFormatter'''
    import sys
    import logging
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    logger.info('First message.')
    logger.info('Second message.')
    logger.info('Third message.')
    logger.info('Last message.')


# Generated at 2022-06-12 13:46:18.465322
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger("")
    logger.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    stream_handler = logging.StreamHandler(sys.stderr)
    stream_handler.setLevel(logging.DEBUG)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    logger.debug("test")
    logger.info("test")
    logger.warning("test")
    logger.error("test")
    logger.critical("test")


# Generated at 2022-06-12 13:46:23.692650
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: no cover
    import time
    import logging
    import warnings
    import io
    from unittest.mock import patch

    # Ensure that warning messages from LogFormatter get ignored
    patch("tornado.log.LogFormatter.formatTime").side_effect = warnings.warn
    # Mock stdout in order to check the output of LogFormatter
    stdout = io.StringIO()
    handler = logging.StreamHandler(stdout)
    log_formatter = LogFormatter()
    handler.setFormatter(log_formatter)
    handler.setLevel(logging.DEBUG)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logger.info("test")
    logger.warning("WARNING")
    logger.error("ERROR")


# Generated at 2022-06-12 13:46:27.582175
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
  log_formatter = LogFormatter()
  assert log_formatter.format("test") == "test"

# Generated at 2022-06-12 13:46:35.348223
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter(color=False, fmt="%(message)s%(end_color)s")
    lf._fmt = '--%(message)s--'
    lf._colors = {0: '1', 1: '2'}
    record = logging.LogRecord(name='foo', level=10, pathname='/xx', lineno=1, msg='bar', args=None, exc_info=None)
    assert lf.format(record) == '--bar--'
    lf._colors = {10: '1', 1: '2'}
    lf._normal = '3'
    assert lf.format(record) == '1--bar--3'



# Generated at 2022-06-12 13:46:47.317798
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass
#     parser = ArgumentParser()
#     parser.add_argument("--color", "-c", action="store_true")
#     parser.add_argument("--format", "-f", default=LogFormatter.DEFAULT_FORMAT)
#     args = parser.parse_args()

#     formatter = LogFormatter(color=args.color, fmt=args.format)
#     stream = StringIO()
#     record = logging.makeLogRecord({"msg": "hello", "levelno": logging.DEBUG})
#     formatter.format(record)
#     stream.write(record._full_message)
#     record = logging.makeLogRecord({"msg": "world", "levelno": logging.WARNING})
#     formatter.format(record)
#     stream.write(record._full_message)
#    

# Generated at 2022-06-12 13:46:56.578456
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os
    os.mkdir("./log_file_prefix")
    tornado.options.options.log_file_prefix="./log_file_prefix/p"
    tornado.options.options.log_rotate_mode="size"
    tornado.options.options.log_file_num_backups=2
    tornado.options.options.log_file_max_size=1024*1024
    tornado.options.options.log_rotate_when="M"
    tornado.options.options.log_rotate_interval=9
    tornado.options.options.logging="DEBUG"
    enable_pretty_logging()
    os.rmdir("./log_file_prefix")

# Generated at 2022-06-12 13:47:08.191865
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Basic test
    sut = LogFormatter()
    record = logging.LogRecord(
        'tornado.general', logging.DEBUG, '/Users/me/Code/Tornado/tornado/log.py',
        163, 'message', (), None)
    actual = sut.format(record)
    assert actual == '[D 161215 12:04:12 log:163] message', "value={}".format(actual)
    # Testing with utf-8
    record = logging.LogRecord(
        'tornado.general', logging.DEBUG, '/Users/me/Code/Tornado/tornado/log.py',
        163, 'message', (), None)
    record.message = u'\u0403'
    actual = sut.format(record)

# Generated at 2022-06-12 13:47:15.266820
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    if hasattr(enable_pretty_logging, "called"):
        print("test_enable_pretty_logging() was called multiple times, which "
              "could have unpredictable results. Make sure you are only "
              "calling it from the main thread.")
        return
    enable_pretty_logging.called = True

    import tempfile

    import tornado.options
    from tornado import concurrent

    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_rotate_when", type=str)

# Generated at 2022-06-12 13:47:24.943878
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type:(...) -> None
    # pylint: disable=missing-docstring,too-many-locals,too-many-branches,too-many-statements
    try:
        import curses
    except ImportError:
        return  # if the platform does not have curses, this test is skipped
    try:
        curses.color_content(1)
        has_color_support = True
    except curses.error:
        has_color_support = False

    fm = LogFormatter(color=True)
    assert fm._normal == "\x1b[0m"
    assert fm._colors == LogFormatter.DEFAULT_COLORS

    fm = LogFormatter(color=False)
    assert fm._normal == ""
    assert fm._colors == {}


# Generated at 2022-06-12 13:47:46.859102
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "/tmp/test"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 7
    tornado.options.options.log_to_stderr = True

    # run function
    enable_pretty_logging()


# Generated at 2022-06-12 13:47:50.893887
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord('tornado.access', logging.DEBUG, '', 0, 'test_record_message', None, None)
    record.asctime = 'error asctime'
    record.color = '\033[0m'
    record.end_color = '\033[0m'
    record.exc_info = None
    record.exc_text = 'error'
    record.levelname = 'error levelname'
    record.lineno = 1
    record.module = 'error module'
    record.message = 'error'
    record.name = 'record name'
    record.pathname = 'pathname'
    record.process = 0
    record.processName = 'process name'
    record.relativeCreated = 0
    record.thread = 'thread'

# Generated at 2022-06-12 13:47:55.310351
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(test)s"
    assert LogFormatter(fmt).format(logging.LogRecord('test', 10, 'file', 0, 'test', '', '', '')) == 'test'
# The above is an unit test, you can uncomment it by replacing the '#' with ' ' in the file
# Almost all the functions in this file need to add unit test


# Generated at 2022-06-12 13:47:58.444622
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter is not None


# Generated at 2022-06-12 13:48:00.810493
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Application is not configured to log.
# Probably tornado application isn't even imported.
# Do nothing
logging.setLoggerClass(logging.NullHandler)

# Generated at 2022-06-12 13:48:11.334154
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Excercise the exception case
    formatter = LogFormatter()

    class DummyLogRecord(object):
        pass

    record = DummyLogRecord()
    record.__dict__ = {
        "asctime": "asctime",
        "levelno": 1,
        "message": 1,
        "exc_text": "exc_text",
    }
    record.exc_info = (1, 1, 1)

    formatter.format(record)
    print("Won't reach here when an exception raised")



# Generated at 2022-06-12 13:48:19.747810
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import tornado.log
    import logging

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)

    formatter = tornado.log.LogFormatter()
    handler.setFormatter(formatter)

    logger.addHandler(handler)

    logger.debug("debug log")
    logger.info("info log")
    logger.warn("warn log")
    logger.error("error log")
    logger.critical("critical log")



# Generated at 2022-06-12 13:48:23.660758
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._colors == {}
    # Initialize colorama.
    if colorama is not None:
        colorama.init()
    assert LogFormatter()._colors != {}


# Generated at 2022-06-12 13:48:25.125836
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:48:34.703558
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    # Test whether function enable_pretty_logging can work correctly
    # when logging is none
    options.logging = 'none'
    try:
        enable_pretty_logging()
    except Exception as e:
        enable_pretty_logging(options,logging.getLogger('tornado.test'))
    # Test whether function enable_pretty_logging can work correctly
    # when logging is debug
    options.logging = 'debug'
    options.log_file_prefix = 'test.log'
    try:
        enable_pretty_logging()
    except Exception as e:
        enable_pretty_logging(options,logging.getLogger('tornado.test'))
    # Test whether function enable_pretty_logging can work correctly
    # when log_rotate_mode

# Generated at 2022-06-12 13:48:45.230544
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf._fmt == lf.DEFAULT_FORMAT
    assert lf.datefmt == lf.DEFAULT_DATE_FORMAT
    assert lf._colors == lf.DEFAULT_COLORS
    assert lf._normal == ""



# Generated at 2022-06-12 13:48:50.604270
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_logger = logging.getLogger(__name__)
    test_logger.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    formatter = LogFormatter()
    ch.setFormatter(formatter)
    test_logger.addHandler(ch)
    test_logger.info("hello, world")


# Generated at 2022-06-12 13:49:01.803880
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
	from tornado.options import options, define, parse_command_line
	define("logging", default="none", type=str, help="what log level to use")
	parse_command_line(["--logging=none"])
	enable_pretty_logging(options)
	
	try:
		raise Exception("fake exception")
	except:
		record = logging.makeLogRecord({
					"msg" : "hello",
					"exc_info" : sys.exc_info(),
					})

# Generated at 2022-06-12 13:49:05.247330
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    # mock the function
    tornado.options._parse_command_line = lambda: None
    tornado.options.options = tornado.options.define("test_options", logging="none")
    enable_pretty_logging()
    assert True

# Generated at 2022-06-12 13:49:11.677951
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    test_opt = tornado.options._OptionParser()
    test_opt.add_option("--log-file-prefix", default="", type="string")
    test_opt.add_option("--log-to-stderr", default=1, type="int")
    test_opt.parse_config_file('test_logging.conf')
    enable_pretty_logging(test_opt)

# Generated at 2022-06-12 13:49:13.003747
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    try:
        assert True
        pass
    except:
        raise


# Generated at 2022-06-12 13:49:15.461162
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.logging = 'debug'
    options.log_file_prefix = './log'
    options.log_rotate_mode = 'time'
    options.log_rotate_when = 'H'
    options.log_rotate_interval = 1
    options.log_file_num_backups = 3

    enable_pretty_logging()


test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:24.999211
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    logger = logging.getLogger()
    lf = LogFormatter()
    rec = logging.makeLogRecord({"msg": "Hello", "levelname": "DEBUG"})
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    assert lf.format(rec).startswith("\x1b[2;34m[DEBUG ")
    assert lf.format(rec).endswith("Hello\x1b[0m\n")



# Generated at 2022-06-12 13:49:33.723721
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class R(object):
        def __init__(self) -> None:
            self.__dict__ = {}
    
    f = LogFormatter()
    r = R()
    r.asctime = "asctimevalue"
    r.exc_text = "exctextvalue"
    r.levelno = 1
    r.message = "messagevalue"
    r.module = "modulevalue"
    r.lineno = 1
    
    r.__dict__['levelno'] = 1
    f.format(r)
    assert f._colors[1] == "\033[2;31m"
    assert f._normal == "\033[0m"
    
    
    r.__dict__['levelno'] = 2
    f.format(r)

# Generated at 2022-06-12 13:49:36.550176
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.log_file_prefix = "log/tornado.log"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "MIDNIGHT"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 1
    enable_pretty_logging()

# Generated at 2022-06-12 13:49:59.680054
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    L_format = LogFormatter()
    record = logging.LogRecord("tornado.application","",
        "", 123, "test", None, None)
    L_format.format(record)

# This is a hack to get the class LogFormatter into the namespace of the
# generated sphinx documentation. Make sure, if you change this, that the
# namespace remains correct.
__all__ = ["LogFormatter"]

# A little bit of magic to make it possible to create a RecordStreamHandler
# with a simple constructor call, but still allow it to be configured via
# dictConfig or logging.conf. This is needed since dictConfig requires the
# constructor arguments to be immutable, and
# logging.handlers.RotatingFileHandler.__init__() unfortunately doesn't use
# an immutable object for the default "mode" argument.

# Generated at 2022-06-12 13:50:05.432540
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        LogFormatter()
    except Exception:
        pass
    try:
        LogFormatter(fmt="", datefmt="")
    except Exception:
        pass
    try:
        LogFormatter(color=True, colors={logging.DEBUG: 4, logging.CRITICAL: 5})
    except Exception:
        pass

_TO_UNICODE_TYPES = (bytes, type(None))



# Generated at 2022-06-12 13:50:08.537694
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    text = 'Hello'
    lf = LogFormatter()
    record = logging.LogRecord(None, logging.INFO, None, None, text, None, None)
    assert lf.format(record) == text


# Generated at 2022-06-12 13:50:09.939529
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  try:
    enable_pretty_logging()
  except:
    1/0

# Generated at 2022-06-12 13:50:10.451239
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-12 13:50:11.762058
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging(tornado.options.options,logger=logging.root)

# Generated at 2022-06-12 13:50:24.421912
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "DEBUG"
    tornado.options.options.log_file_prefix = "log_file_prefix"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024*1024*1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True
    logger = logging.getLogger()
    #test size mode
    enable_pretty_logging(tornado.options.options,logger)

# Generated at 2022-06-12 13:50:35.019330
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    from tornado.options import define, parse_command_line
    define("logging", default="debug", help="logging level", type=str)
    define("log_file_prefix", default="/tmp/tornado.log", help="log file", type=str)
    define("log_file_max_size", default=1000000000, help="max log size", type=int)
    define("log_file_num_backups", default=5, help="num log backup", type=int)
    define("log_rotate_mode", default="time", help="Field to use for rotating log files", type=str)
    define("log_rotate_when", default="midnight", help="Field to use for rotating log files", type=str)

# Generated at 2022-06-12 13:50:38.125986
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(datefmt='%Y-%m-%d %H:%M:%S')
    record = logging.LogRecord(
        name='logger name',
        level=logging.DEBUG,
        pathname='path/to/file',
        lineno=1,
        msg='msg',
        args=None,
        exc_info=None,
    )
    result = formatter.format(record)
    assert result == "[D msg] ", result



# Generated at 2022-06-12 13:50:40.324139
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-12 13:50:56.418521
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger("TEST")
    log_handler = logging.StreamHandler()
    formatter = LogFormatter()
    log_handler.setFormatter(formatter)
    logger.addHandler(log_handler)
    logger.setLevel(logging.DEBUG)
    logger.error("test")

#------------------------------------------------------------------------------


# Generated at 2022-06-12 13:50:59.739163
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    assert LogFormatter
    assert LogFormatter.DEFAULT_FORMAT
    assert LogFormatter.DEFAULT_DATE_FORMAT
    assert LogFormatter.DEFAULT_COLORS



# Generated at 2022-06-12 13:51:06.377109
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # try:
    #     raise ValueError("Bad message")
    # except ValueError as e:
    #     message = e
    #     record = logging.LogRecord("name", "level", "path", "lineno", "msg", args, "exc_info")  # noqa: E501
    #     record.exc_info = sys.exc_info()
    #     # record.message = message
    #     pass
    pass


# Generated at 2022-06-12 13:51:09.643141
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    res = formatter.format(logging.LogRecord('', '', '', 0, '', (), None, None))
    assert res == '(None) - - [00] -'

# Generated at 2022-06-12 13:51:19.406144
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # create a Logger object
    logger = logging.getLogger("test_logger")

    # set level of logger to INFO
    logger.setLevel(logging.INFO)

    # create a Handler object
    handler = logging.StreamHandler()

    # create a Formatter object
    formatter = LogFormatter()

    # combine formatter and handler
    handler.setFormatter(formatter)

    # add the handler to the logger object
    logger.addHandler(handler)

    logger.error("test error!")


# define the customized class to support 'bind_host' and 'bind_port'

# Generated at 2022-06-12 13:51:23.867888
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logf = LogFormatter()
    record = logging.LogRecord("test_logger", logging.DEBUG, "test_file", 1, "test_msg", None, None)
    try:
        ret = logf.format(record)
        assert ret.startswith("[D")
    except Exception as e:
        pass
    record = logging.LogRecord("test_logger", logging.DEBUG, "test_file", 1, 24, None, None)
    try:
        ret = logf.format(record)
        assert ret.startswith("[D")
    except Exception as e:
        pass



# Generated at 2022-06-12 13:51:25.515230
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    config = {"format": "%(message)s"}
    formatter = LogFormatter(**config)  # type: ignore
    assert formatter._fmt == "%(message)s"



# Generated at 2022-06-12 13:51:26.695064
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 13:51:38.021167
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options._parse_command_line([])

    tornado.options.define("log_file_prefix", "test.log", str)
    tornado.options.define("log_to_stderr", True, bool)
    tornado.options.define("logging", "debug", str)
    tornado.options.define("log_file_max_size", 100000000, int)
    tornado.options.define("log_file_num_backups", 7, int)
    tornado.options.define("log_rotate_mode", "size")
    tornado.options.define("log_rotate_when", "D", str)
    tornado.options.define("log_rotate_interval", 1, int)

    a = enable_pretty_logging()
    assert a is None

# Generated at 2022-06-12 13:51:46.709263
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os
    import io
    import shutil
    import sys
    import time
    import unittest

    # TODO: Add test for colorama

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger()
            self.formatter = LogFormatter()
            self.logger.addHandler(logging.NullHandler())

        def test_format(self):
            self.logger.handlers[0].setFormatter(self.formatter)
            self.logger.warn("test %s %s", "a", "b")

    class LogOptions(tornado.options.Options):
        def __init__(self):
            super(LogOptions, self).__init__()

# Generated at 2022-06-12 13:52:22.978588
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert isinstance(lf._normal, str)
    assert isinstance(lf._colors, dict)


# Generated at 2022-06-12 13:52:26.479214
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    a = LogFormatter()
    assert("[%(levelname)1.1s" in a._fmt)
    assert("%(color)s" in a._fmt)
    assert("%(end_color)s %(message)s" in a._fmt)


# Generated at 2022-06-12 13:52:37.594009
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from io import StringIO

    stream = StringIO()
    logger = logging.getLogger()
    logger.handlers = []
    logger.addHandler(
        logging.StreamHandler(
            stream=stream
        )
    )
    fmt = "%(asctime)s\n%(message)s\n%(color)s%(levelname)s%(end_color)s"
    datefmt = "%Y-%m-%dT%H:%M:%SZ"

    # set up formatter

# Generated at 2022-06-12 13:52:42.248445
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test the option defaults
    import tornado.options
    options = tornado.options.define("logfile", type=str, group="Logging")
    tornado.options.define("logging", default="debug", group="Logging")
    tornado.options.define("log_to_stderr", type=bool, group="Logging")
    tornado.options.define("log_file_prefix", type=str, group="Logging")
    tornado.options.define(
        "log_rotate_mode", type=str, group="Logging", default="time"
    )
    tornado.options.define(
        "log_rotate_when", type=str, group="Logging", default="d"
    )

# Generated at 2022-06-12 13:52:44.358380
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord(
        'foo', logging.INFO, None, None, 'bar', None, None))


# Generated at 2022-06-12 13:52:54.962522
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define('log_to_stderr', default=False)
    define('logging', default='NOTSET')
    define('log_file_prefix', default=None)
    define('log_rotate_mode', default='size')
    define('log_rotate_when', default='midnight')
    define('log_rotate_interval', default=1)
    define('log_file_num_backups', default=0)
    define('log_file_max_size', default=0)
    enable_pretty_logging()
    def gen_log_message():
        gen_log.info("Testing log")
        gen_log.debug("Testing debug")
        gen_log.error("Testing error")
        gen_log.warning("Testing warning")
    # Test unitt

# Generated at 2022-06-12 13:53:07.575773
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = {}
    record['name'] = 'tornado.general'
    record['levelno'] = 10
    record['levelname'] = 'DEBUG'
    record['pathname'] = 'test.py'
    record['lineno'] = 2
    record['msg'] = 'test!'
    record['args'] = 'test!'
    record['exc_info'] = None
    record['funcName'] = 'test'
    record['created'] = 12.5
    record['msecs'] = 14.5
    record['relativeCreated'] = 10.5
    record['thread'] = 'thread'
    record['processName'] = 'processName'
    record['process'] = 'process'
    record['message'] = 'message'
    result = formatter.format(record)

# Generated at 2022-06-12 13:53:14.748933
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.formatTime(logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "msg", None, None))
    try:
        formatter.format(logging.LogRecord("tornado.general", logging.INFO, "test.py", 1, "msg", None, None))
    except Exception as e:
        raise ValueError("Failed test, LogFormatter.format() failed with exception %s " % e)

# Generated at 2022-06-12 13:53:18.834299
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    formatter = LogFormatter(datefmt='%Y-%m-%d')
    assert formatter.datefmt == '%Y-%m-%d'



# Generated at 2022-06-12 13:53:19.413376
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert True

# Generated at 2022-06-12 13:53:53.760546
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import inspect
    import logging
    import datetime
    import os

    def get_logger(name: str, level: int = logging.DEBUG) -> logging.Logger:
        logger = logging.getLogger(name)
        logger.setLevel(level)
        return logger

    def is_bytes_or_unicode(s: Any) -> bool:
        return isinstance(s, bytes) or isinstance(s, unicode_type)

    def is_bytes(s: Any) -> bool:
        return isinstance(s, bytes)

    def is_unicode(s: Any) -> bool:
        return isinstance(s, unicode_type)

    def is_native_str(s: Any) -> bool:
        return isinstance(s, str)


# Generated at 2022-06-12 13:53:58.069970
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger("tornado.test")
    logger.setLevel(logging.DEBUG)

    formatter = LogFormatter()
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    logger.info("1")  # type: ignore



# Generated at 2022-06-12 13:54:04.622160
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    
    import tornado.options
    import tornado.log
    
    tornado.options.options.log_to_stderr=True
    tornado.options.options.logging='debug'
    tornado.log.enable_pretty_logging()
    gen_log.debug('Test: Enable pretty logging')
    
    
    
    print('Unit test of tornado.log.enable_pretty_logging completed')
    
if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:54:05.510087
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _stderr_supports_color()


# Generated at 2022-06-12 13:54:15.961006
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

    formatter = LogFormatter(datefmt="%Y")
    assert formatter.datefmt == "%Y"
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

    formatter = LogFormatter(datefmt="%Y", fmt="%(message)s")
    assert formatter.datefmt == "%Y"
    assert formatter._fmt == "%(message)s"

    formatter = LogFormatter(fmt="%(message)s")
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == "%(message)s"


# Generated at 2022-06-12 13:54:24.048464
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert len(formatter._colors) == 5
    assert formatter._normal == ""
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

    colorama.init()
    formatter = LogFormatter()
    assert len(formatter._colors) == 5
    assert formatter._normal == "\033[0m"
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT

    curses = None
    formatter = LogFormatter()
    assert len(formatter._colors) == 5
    assert formatter._normal == ""
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT



# Generated at 2022-06-12 13:54:28.016759
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.enable_pretty_logging()
    logging.warning("warning")
    logging.error("error")
    logging.info("info")
    logging.debug("debug")


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:54:30.627670
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Constructor should accept a few different parameters.
    formatter = LogFormatter(fmt="%(message)s", datefmt="%Y-%m-%d")



# Generated at 2022-06-12 13:54:32.101909
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options,gen_log)
    gen_log.warning('test')

# Generated at 2022-06-12 13:54:34.721360
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(datefmt="%Y-%m-%d %H:%M:%S", style="{")


# Generated at 2022-06-12 13:55:41.460903
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()