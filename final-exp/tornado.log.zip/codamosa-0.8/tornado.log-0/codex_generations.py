

# Generated at 2022-06-12 13:46:07.598620
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    gen_log.info("test info log")
    gen_log.error("test error log")
    gen_log.warning("test warning log")

test_enable_pretty_logging()

# Generated at 2022-06-12 13:46:08.555870
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:46:15.454357
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    import io
    import logging
    import logging.handlers
    import struct
    import threading
    import unittest
    from unittest import mock

    from tornado.escape import native_str
    from tornado.log import LogFormatter
    from tornado import testing
    from tornado.util import b, bytes_type

    from typing import Any, Union

    @testing.gen_test(timeout=testing.DEFAULT_IO_LOOP_TIMEOUT)
    async def main():
        # type: () -> None
        async def tcp_echo_client():
            # type: () -> None
            await stream.write(b("hello"))
            msg = await stream.read_until(b("\n"))
            assert msg == b("hello\n")
            stream.close()

        port = unused_port()

# Generated at 2022-06-12 13:46:19.037335
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_fmt = LogFormatter()

_TO_UNICODE_TYPES = (unicode_type, type(None))

_safe_unicode = _safe_unicode



# Generated at 2022-06-12 13:46:24.258214
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    lf = LogFormatter(datefmt="%Y-%m-%d")
    assert lf.datefmt == "%Y-%m-%d"
    lf = LogFormatter(datefmt="")
    assert lf.datefmt == ""
    lf = LogFormatter(datefmt=None)
    assert lf.datefmt == ""



# Generated at 2022-06-12 13:46:28.188731
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Use as you would use enable_pretty_logging()
    enable_pretty_logging(logger=gen_log)



# Generated at 2022-06-12 13:46:37.879542
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create the object
    log_formatter = LogFormatter()

    # Simulate a logging.LogRecord object
    class LogRecord(object):
        pass
    record = LogRecord()
    record.message = u"Hello"
    record.name = "LogRecord name"
    record.levelno = logging.DEBUG

# Generated at 2022-06-12 13:46:39.020684
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-12 13:46:50.164680
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import inspect

    def make_record(levelno, message: str) -> logging.LogRecord:
        record = logging.LogRecord(
            "",
            levelno,
            inspect.getsourcefile(inspect.currentframe()),
            inspect.currentframe().f_lineno,
            message,
            None,
            None
        )
        return record
    
    if _stderr_supports_color():
        formatter = LogFormatter()
        message = "test"
        record = make_record(logging.INFO, message)
        formatted = formatter.format(record)
        print(formatted)
        assert message in formatted
    else:
        pass
    
    
    
    

# define the custom "Level"
logging.UNUSED_LEVEL = logging.DEBUG + 5
logging

# Generated at 2022-06-12 13:46:59.032987
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("log_rotate_mode", type=str, default="size", group="log")
    tornado.options.define("log_file_prefix", type=str, default="", group="log")
    tornado.options.define("log_file_max_size", type=str, default=0, group="log")
    tornado.options.define("log_file_num_backups", type=str, default=0, group="log")
    tornado.options.define("log_rotate_when", type=str, default="midnight", group="log")
    tornado.options.define("log_rotate_interval", type=str, default=1, group="log")
    tornado.options.options.log_rotate_mode = "size"
    tornado.options

# Generated at 2022-06-12 13:47:29.212892
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()
test_define_logging_options()

# Generated at 2022-06-12 13:47:39.801182
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()

if __name__ == "__main__":
    test_define_logging_options()
# Copyright 2011 Facebook, Inc.
# Copyright 2014 Institute of Cyber-Systems & Control
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License

# Generated at 2022-06-12 13:47:41.654050
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("logging", default=None, help="logging level")
    enable_pretty_logging()

# Generated at 2022-06-12 13:47:42.505403
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:47:52.410277
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    >>> import logging
    >>> logger = logging.getLogger('tornado.test')
    >>> logger.setLevel(logging.DEBUG)
    >>> f = LogFormatter()
    >>> logger.handlers = []
    >>> handler = logging.StreamHandler()
    >>> handler.setLevel(logging.DEBUG)
    >>> handler.setFormatter(f)
    >>> logger.addHandler(handler)
    >>> logger.info("foo")
    [I 1015 13:10:09 tornado.test:42] foo
    """
    pass


# Generated at 2022-06-12 13:47:57.803967
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    colors = {logging.DEBUG: 2}
    log_formatter = LogFormatter(fmt, colors=colors)
    formated_record = log_formatter.format(logging.makeLogRecord({"msg": "test"}))
    assert formated_record == "[D 1970-01-01 00:00:00 root:0] test"



# Generated at 2022-06-12 13:48:02.380503
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.Formatter()
    logging.LogRecord("", "", "", 0, "", (), None)
    log_formatter = LogFormatter()
    assert isinstance(log_formatter.format(""), str)
    assert isinstance(log_formatter.format(logging.LogRecord("", "", "", 0, "", (), None)), str)


# Generated at 2022-06-12 13:48:14.286103
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from datetime import datetime
    import logging
    import threading
    
    class LogFormatterTest(threading.Thread):
        def __init__(self, name, test_formatter):
            threading.Thread.__init__(self)
            self.name = name
            self.test_formatter = test_formatter
        def run(self):
            self.test_formatter.format(logging.LogRecord(self.name, 40, '', 0, self.name, None, None))
    test_formatter = LogFormatter(color=False)
    
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    thread1 = LogFormatterTest( "thread1", test_formatter)
    thread2 = LogFormatterTest( "thread2", test_formatter)

# Generated at 2022-06-12 13:48:17.221985
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    #assert logger.getEffectiveLevel() == logging.INFO
    assert logger.getEffectiveLevel() == 20

# Generated at 2022-06-12 13:48:27.355613
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    tfmt = LogFormatter()
    m = logging.LogRecord("tornado.test", logging.INFO, None, 1, "test message", None, None)
    msg = tfmt.format(m)
    assert msg.startswith("[I")
    m.msg = "test\ntest message"
    msg = tfmt.format(m)
    assert "test\n    test message" in msg

    import datetime
    tfmt = LogFormatter(datefmt="%y%m%d %H:%M")
    m.asctime = datetime.datetime.fromtimestamp(10000).strftime(tfmt.datefmt)
    msg = tfmt.format(m)
    assert msg.startswith("[I 10000 ")



# Generated at 2022-06-12 13:48:47.849155
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    #logging.basicConfig()
    enable_pretty_logging()
    logging.error('test')

# Generated at 2022-06-12 13:48:51.561955
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = LogFormatter(color=False)
    assert fmt._fmt == LogFormatter.DEFAULT_FORMAT
    assert fmt._datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert fmt._colors == {}
    assert fmt._normal == ""
    assert not fmt.datefmt
    assert repr(fmt)



# Generated at 2022-06-12 13:48:53.861167
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    tf_formatter = LogFormatter()
    assert tf_formatter
    assert tf_formatter is not None


# Generated at 2022-06-12 13:49:04.522844
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    import sys
    from io import StringIO
    output = StringIO()
    formatter.format(logging.LogRecord("tornado.general", logging.INFO, "/foo", 12345, "hello, %s", (), None))  # type: ignore
    with output:
        formatter.format(logging.LogRecord("tornado.access", logging.INFO, "/foo", 12345, "hello, %s", (), None))  # type: ignore
        formatter.format(logging.LogRecord("tornado.access", logging.WARNING, "/foo", 12345, "hello, %s", (), None))  # type: ignore

# Generated at 2022-06-12 13:49:05.388428
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:49:15.185848
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado import options, util
    import tempfile
    import os
    import shutil
    from tornado.options import define, options
    from tornado.log import enable_pretty_logging
    import logging

    define("log_file_prefix", type=str,
           default=os.path.join(tempfile.mkdtemp(), 'log_file_prefix.log'),
           help="Path prefix for log files")

    define("logging", default="info", help="log level")

    define("log_rotate_mode", type=str, default="size", help="time or size")

    define("log_rotate_when", type=str, default="midnight", help="time of rotation")

    define("log_rotate_interval", type=int, default=1, help="rotate per day")


# Generated at 2022-06-12 13:49:28.278253
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import threading

    logfmt = LogFormatter()
    logfmt.format(
        logging.LogRecord(
            name="test",
            level=logging.DEBUG,
            pathname="/path/to/test.py",
            lineno=10,
            msg=1,
            args=None,
            exc_info=None,
            func="test_function",
            sinfo=None,
        )
    ) == "[D 01/01/01 00:00:00 test:10] 1"

# Generated at 2022-06-12 13:49:32.843733
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # type: () -> None
    channel = logging.StreamHandler()
    channel.setFormatter(LogFormatter())
    access_log.addHandler(channel)
    assert access_log.getEffectiveLevel() == logging.NOTSET
    app_log.addHandler(channel)
    assert app_log.getEffectiveLevel() == logging.NOTSET
    gen_log.addHandler(channel)
    assert gen_log.getEffectiveLevel() == logging.NOTSET

# Generated at 2022-06-12 13:49:35.637366
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    obj = enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:38.195622
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger("tornado.test")
    logger.propagate = False
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warn message")
    logger.error("error message")
    logger.critical("critical message")

test_LogFormatter_format()

# Generated at 2022-06-12 13:50:29.818824
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class CustomLogFormatter(LogFormatter):
        pass
    CustomLogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        style="%",
        color=True,
        colors={
            logging.DEBUG: 4,
            logging.INFO: 2,
            logging.WARNING: 3,
            logging.ERROR: 1,
            logging.CRITICAL: 5,
        }
    )



# Generated at 2022-06-12 13:50:38.679439
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter(fmt='%(asctime)s %(message)s',
                      datefmt='%Y-%m-%d %H:%M:%S')
    lr = logging.LogRecord(
        name='tornado.access',
        level=logging.DEBUG,
        pathname='/Users/guang/Documents/project/pytornado/tornado/stack_context.py',
        lineno=105,
        msg='%s',
        args=('hello',),
        exc_info=None,
        func=None)

    lf.format(lr)
    print(lr.message)


# Make a new LogFormatter with a default date format.
# This is to allow a consistent date format across Python versions
# (datetime.datetime.isoformat() is not supported

# Generated at 2022-06-12 13:50:45.019454
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger()
    assert isinstance(logger.handlers, list) and len(logger.handlers) == 1
    ch = logger.handlers[0]
    assert isinstance(ch, logging.StreamHandler)
    fm = ch.formatter
    assert isinstance(fm, LogFormatter)
    assert fm._colors



# Generated at 2022-06-12 13:50:46.617823
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:50:56.224055
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test logging function as a normal function
    import tornado.options
    tornado.options.options.log_to_stderr = "1"
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "logging_file_prefix"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_rotate_interval = 1
    enable_pretty_logging()
    # Test logging function as a normal function
    gen_log.debug("This is a debug message.")

# Generated at 2022-06-12 13:51:00.352371
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(color=False)
    LogFormatter(colors={})
    LogFormatter(fmt="hello %(foo)s")
    LogFormatter(datefmt="%Y")



# Generated at 2022-06-12 13:51:11.091550
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf._colors[logging.DEBUG] == "\033[2;37m"
    assert lf._colors[logging.INFO] == "\033[2;32m"
    assert lf._colors[logging.WARNING] == "\033[2;33m"
    assert lf._colors[logging.ERROR] == "\033[2;31m"
    assert lf._colors[logging.CRITICAL] == "\033[2;35m"
    assert lf._normal == "\033[0m"
    assert lf._fmt == "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"  # noqa: E501


# Generated at 2022-06-12 13:51:15.499431
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options
    tornado.options.define("logging", default="debug", help="")
    tornado.options.define("log_file_prefix", default=None, help="")
    tornado.options.define("log_to_stderr", default=None, help="")
    tornado.options.define("log_file_max_size", default=100000, help="")
    tornado.options.define("log_file_num_backups", default=10, help="")
    tornado.options.define("log_rotate_mode", default="time", help="")
    tornado.options.define("log_rotate_when", default="D", help="")
    tornado.options.define("log_rotate_interval", default=1, help="")

    enable_pretty_logging()

   

# Generated at 2022-06-12 13:51:20.032986
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._fmt == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa
    assert (
        LogFormatter().DEFAULT_DATE_FORMAT
        == "%y%m%d %H:%M:%S"
    )  # noqa
    assert LogFormatter()._colors[3] == "\033[2;33m"
    assert LogFormatter()._normal == "\033[0m"



# Generated at 2022-06-12 13:51:21.709831
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)  # noqa: F841
    assert formatter is not None

# Generated at 2022-06-12 13:52:25.321865
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.handlers = [logging.StreamHandler()]
    formatter = LogFormatter()
    logger.handlers[0].setFormatter(formatter)
    logger.debug("test")
    logger.warning("test")



# Generated at 2022-06-12 13:52:26.533657
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._colors == {}

# Generated at 2022-06-12 13:52:29.961611
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)
    assert isinstance(formatter, logging.Formatter)

    formatter = LogFormatter(color=False)
    assert isinstance(formatter, logging.Formatter)



# Generated at 2022-06-12 13:52:32.334882
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_command_line()
    import tornado.log
    tornado.log.access_log.error('test')

# Generated at 2022-06-12 13:52:33.398577
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:52:37.540321
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter
    # Make sure it's still possible to pass a format string
    formatter = LogFormatter("%(foo)s")
    assert formatter



# Generated at 2022-06-12 13:52:39.536153
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter(color=False)
    f = LogFormatter(color=True)



# Generated at 2022-06-12 13:52:47.325703
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.log
    tornado.options._parse_command_line([])
    tornado.log.define_logging_options(tornado.options.options)
    for k, v in {
        "logfile": None,
        "log_rotate_when": "midnight",
        "log_to_stderr": None,
        "log_rotate_interval": 1,
        "logging": "info",
        "log_rotate_mode": "size",
        "log_file_num_backups": 10,
        "log_file_prefix": None,
        "log_file_max_size": 100000000,
    }.items():
        assert tornado.options.options.as_dict().get(k) == v



# Generated at 2022-06-12 13:52:59.114146
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define('logging', default=None, help='logging level', type=str)
    define('log_file_prefix', default=None, help='log file prefix', type=str)
    define('log_file_max_size', default=100, help='log file max size', type=int)
    define('log_rotate_mode', default='', help='log rotate mode', type=str)
    define('log_rotate_when', default='', help='log rotate when', type=str)
    define('log_rotate_interval', default=1, help='log rotate interval',
           type=int)
    define('log_file_num_backups', default=0, help='log file num backups',
           type=int)

# Generated at 2022-06-12 13:53:07.029511
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    start_time = datetime.datetime.now()
    result = enable_pretty_logging()
    end_time =  datetime.datetime.now()
    print('enable_pretty_logging', result, 'it takes', (end_time - start_time).total_seconds()*1000.0, 'milliseconds')
# Unit test
if __name__ == "__main__":
    print('start unit test')
    test_enable_pretty_logging()
    print('end unit test')

# Generated at 2022-06-12 13:55:18.704407
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "none"
    enable_pretty_logging()
    tornado.options.options.logging = "info"
    enable_pretty_logging()

# Generated at 2022-06-12 13:55:27.956221
# Unit test for function enable_pretty_logging

# Generated at 2022-06-12 13:55:36.840704
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from typing import List, Dict, Any

    def gen_formatter(
        fmt: Optional[str] = None,
        datefmt: Optional[str] = None,
        style: Optional[str] = None,
        color: Optional[bool] = None,
        colors: Optional[Dict[int, int]] = None,
    ) -> LogFormatter:
        # type: (...) -> LogFormatter
        fmt = fmt or LogFormatter.DEFAULT_FORMAT
        datefmt = datefmt or LogFormatter.DEFAULT_DATE_FORMAT
        style = style or "%"
        color = color or True
        colors = colors or LogFormatter.DEFAULT_COLORS

# Generated at 2022-06-12 13:55:45.098989
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  options = Any
  logger = Optional[logging.Logger]
  def enable_pretty_logging(
    options = None, logger = None
  ) -> None:
    """Turns on formatted logging output as configured.

    This is called automatically by `tornado.options.parse_command_line`
    and `tornado.options.parse_config_file`.
    """
    if options is None:
        import tornado.options

        options = tornado.options.options
    if options.logging is None or options.logging.lower() == "none":
        return
    if logger is None:
        logger = logging.getLogger()
    logger.setLevel(getattr(logging, options.logging.upper()))
    if options.log_file_prefix:
        rotate_mode = options.log_rotate_mode

# Generated at 2022-06-12 13:55:49.189313
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.enable_pretty_logging()
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "./log/test.log"
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_file_max_size = 1000
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.enable_pretty_logging()