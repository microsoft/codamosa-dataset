

# Generated at 2022-06-12 13:46:22.924501
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Init, set global log level
    from tornado import options

    options.parse_command_line(["--log_level_name=ERROR"])
    log = LogFormatter()
    import logging

    r = logging.LogRecord("tornado.general", logging.ERROR, "log_file_path", 0, "message", None, None)  # noqa: E501
    r.__dict__["message"] = "message"
    r.__dict__["asctime"] = "20191205 17:11:45"
    r.__dict__["color"] = "color"
    r.__dict__["end_color"] = "color_end"
    r.__dict__["name"] = "instance_name"
    r.__dict__["funcName"] = "function_name"

# Generated at 2022-06-12 13:46:34.424596
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options

    define("log_to_stderr", type=bool, default=True)
    enable_pretty_logging()
    logger = logging.getLogger()
    assert len(logger.handlers) == 1, len(logger.handlers)
    formatter = type(logger.handlers[0].formatter)
    assert formatter is LogFormatter, formatter
    assert logger.level == logging.INFO, logger.level
    logger.info("test")

    define("log_to_stderr", type=bool, default=False)
    define("log_file_prefix", default="test-log")
    enable_pretty_logging()
    logger = logging.getLogger()
    assert len(logger.handlers) == 1, len(logger.handlers)

# Generated at 2022-06-12 13:46:36.155131
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-12 13:46:37.043121
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:46:45.150731
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # import tornado
    # options = tornado.options.options
    # options.logging = 'INFO'
    # options.log_file_prefix = 'file.log'
    # options.log_file_max_size = 1024000
    # options.log_file_num_backups = 5
    # enable_pretty_logging()
    # logger = logging.getLogger()
    # logger.info('aa')
    pass

# Generated at 2022-06-12 13:46:53.053407
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options

    
    tornado.options.define("log_to_stderr", None)
    tornado.options.define("logging", "none")
    tornado.options.define("log_rotate_mode", "time")
    tornado.options.define("log_rotate_when", "D")
    tornado.options.define("log_rotate_interval", "1")
    tornado.options.define("log_file_num_backups", 5)
    tornado.options.define("log_file_max_size", 100)
    tornado.options.define("log_file_prefix", "test.log")
    tornado.options.parse_command_line()
    
    
    enable_pretty_logging()
    return True

# Generated at 2022-06-12 13:47:00.061478
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter(datefmt='%1', colors={1: 10})
    assert lf
    assert lf._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert lf._colors == {1: '\033[2;3%dm' % 10}
    assert lf._normal == "\033[0m"

    lf.format(logging.LogRecord('a', 2, 'b', 3, 'c', 4, 5))



# Generated at 2022-06-12 13:47:05.634488
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.Logger('test.format')
    f = LogFormatter()
    r = logging.makeLogRecord({'msg': 'test'})
    logger.addHandler(logging.StreamHandler())
    logger.handlers[0].setFormatter(f)
    logger.error(r)
    logger.error(r, exc_info=True)


# Generated at 2022-06-12 13:47:07.454822
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter(color=True,colors={"DEBUG":4})



# Generated at 2022-06-12 13:47:17.372739
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    datefmt = "%y%m%d %H:%M:%S"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    LogFormatter(fmt, datefmt, color, colors)


# Generated at 2022-06-12 13:47:36.942302
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options as options

    options.define(
        "log_rotate_mode",
        type=str,
        help='mode for rotating the log file, "size" or "time"',
        default="size",
    )
    options.define(
        "log_rotate_when",
        type=str,
        help=('specify the type of TimedRotatingFileHandler interval '),
        default="H",
    )
    options.define(
        "log_rotate_interval",
        type=int,
        help=('The interval value of timed rotating'),
        default=24,
    )
    options.define(
        "log_file_prefix",
        type=str,
        help=('Filename prefix for log files.'),
        default="log/myapp.log",
    )


# Generated at 2022-06-12 13:47:39.884856
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf1 = LogFormatter()
    record = lf1.format(logging.error("Bad message (%r): %r" % (1, 2)))
    print(record)

# Generated at 2022-06-12 13:47:44.950032
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    record = logging.LogRecord(name="tornado.general",
                               level=logging.DEBUG,
                               pathname="",
                               lineno=0,
                               msg="TestLogFormatter",
                               args=None,
                               exc_info=None)
    formatted = lf.format(record)
    assert(formatted != "")
    assert(formatted == "[D 160722 16:40:52 - root:0] TestLogFormatter")



# Generated at 2022-06-12 13:47:47.534387
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test 1
    formatter = LogFormatter()
    try:
        formatter.format(None)
    except Exception as e:
        print(e)



# Generated at 2022-06-12 13:47:48.130470
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    (LogFormatter())


# Generated at 2022-06-12 13:47:48.522635
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-12 13:47:54.239132
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import os, sys
    import logging
    from logformatter.logformatter import LogFormatter
    os.system("cls")
    LOG_FMT = "%(levelname)s\t%(asctime)s %(filename)s:%(lineno)d * %(thread)d %(message)s"
    DATE_FMT = '%m-%d %H:%M:%S'
    formatter = LogFormatter(fmt=LOG_FMT, datefmt=DATE_FMT)

    record = logging.LogRecord(
        name='tornado.access',
        level=logging.INFO,
        pathname='',
        lineno=0,
        msg='abcdefg',
        args=(),
        exc_info=None)
    

# Generated at 2022-06-12 13:48:01.144743
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    import datetime
    record = logging.LogRecord(
        "test_LogFormatter_format",
        1,
        "null",
        2,
        "test_LogFormatter_format",
        None,
        None,
        )
    record.created = datetime.datetime.now()
    record.msecs = 1
    print(formatter.format(record))


# Generated at 2022-06-12 13:48:13.941968
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    import __main__
    import shutil
    import os
    import tornado.options
    import threading
    import logging.handlers
    import glob
    import time
    import tempfile
    from tornado.util import PY3
    from io import open

    options = tornado.options.Options()
    remove_files = []

    def cleanup():
        for f in remove_files:
            if os.path.isdir(f):
                shutil.rmtree(f)

# Generated at 2022-06-12 13:48:23.038921
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import access_log, app_log, gen_log
    import logging
    import sys

    logger = logging.getLogger('tornado.access')
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to info
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    # create formatter
    formatter = LogFormatter()
    # add formatter to ch
    handler.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(handler)
    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')
    logger.error('error message')
    logger.critical('critical message')
test_LogFormatter_format()
    




# Generated at 2022-06-12 13:48:33.381785
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    Constructor of class LogFormatter doesn't work.
    """
    formatter=LogFormatter(color=True)
    assert formatter is not None


# Generated at 2022-06-12 13:48:43.751359
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    class Options(object):
        def __init__(self):
            self.logging = "debug"
            self.log_file_prefix = None
            self.log_to_stderr = None
            self.log_rotate_mode = "size"
            self.log_rotate_when = None
            self.log_rotate_interval = None
            self.log_file_max_size = None
            self.log_file_num_backups = None

    tornado.options.options = Options()
    enable_pretty_logging(tornado.options.options)
    gen_log.info("This function is OK")


test_enable_pretty_logging()

# Generated at 2022-06-12 13:48:53.401110
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import re
    import os
    import sys
    import io
    import logging
    import logging.config

    class LogFormatterTestCase(unittest.TestCase):
        def setUp(self):
            self.log_fmt = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
            if os.environ.get('TEST_FORMAT_LOGS') == '1':
                logging.basicConfig(stream=sys.stdout, level=logging.DEBUG, format=self.log_fmt)
            else:
                logging.basicConfig(stream=io.StringIO(), level=logging.CRITICAL)

# Generated at 2022-06-12 13:49:04.246443
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter(fmt='%(color)s%(message)s%(end_color)s')
    assert lf.level_map == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    assert lf._normal == ''
    lf = LogFormatter(color=False)
    assert lf.level_map == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    assert l

# Generated at 2022-06-12 13:49:14.323203
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import sys
    import io

    def test():
        class MyLogFormatter(tornado.log.LogFormatter):

            def __init__(self, fmt: str = "", *args: Any, **kwargs: Any) -> None:
                tornado.log.LogFormatter.__init__(self, fmt, *args, **kwargs)

            def format(self, record: Any) -> str:
                record.custom_value = "very custom"
                return super().format(record)

        opts = tornado.options.Options()
        opts.logging = "debug"
        opts.log_file_prefix = "test.log"
        opts.log_file_max_size = 37
        opts.log_file_num_backups = 3
       

# Generated at 2022-06-12 13:49:18.573317
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    now = datetime.datetime.now()
    logRecord = logging.LogRecord(levelname = 'INFO',
                                  levelno = 20,
                                  pathname = None,
                                  lineno = None,
                                  msg = 'test log message',
                                  args = None,
                                  exc_info = None)
    logFormatter = LogFormatter()
    logFormatter.formatTime = lambda rec: str(now)
    assert logFormatter.format(logRecord) == '[I ' + str(now) + ' :] test log message'



# Generated at 2022-06-12 13:49:25.927081
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.logging = 'none'
    enable_pretty_logging()
    options.logging = 'debug'
    # options.log_file_prefix = 'tornado.log'
    options.log_to_stderr = True
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:34.213511
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logger", default=tornado.log.app_log)
    tornado.options.define("logging", default="info")
    tornado.options.define("log_file_prefix", default=None)
    tornado.options.define("log_rotate_mode", default="size")
    tornado.options.define("log_file_max_size", default=20)
    tornado.options.define("log_file_num_backups", default=1)
    tornado.options.define("log_rotate_when", default=None)
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.define("log_to_stderr",default=True)
    from tornado.log import app_log
    enable_

# Generated at 2022-06-12 13:49:43.009371
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Create a mock options type to use for the test
    class Options:
        def __init__(self) -> None:
            self.logging = "info"
            self.log_file_prefix = "test.log"
            self.log_rotate_mode = "size"
            self.log_file_max_size = 100000
            self.log_file_num_backups = 10
            self.log_rotate_when = "midnight"
            self.log_rotate_interval = 1
            self.log_to_stderr = False

    # Create a mock logger type to use for the test
    class Logger:
        def __init__(self) -> None:
            self.handlers = []

        def setLevel(self, level: str) -> None:
            pass


# Generated at 2022-06-12 13:49:47.153879
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord(
        name=None, level=None, pathname=None, lineno=None,
        msg=None, args=None, exc_info=None)
    record.message = 'this is a test'
    record.asctime = 'this is a test'
    record.color = 'this is a test'
    record.end_color = 'this is a test'
    record.__dict__['this is a test'] = 'this is a test'
    lf = LogFormatter(None, None)
    assert lf.format(record) == ''



# Generated at 2022-06-12 13:49:59.598285
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    from tornado.log import enable_pretty_logging, app_log
    enable_pretty_logging(options, app_log)
    app_log.info("info")
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:50:04.482399
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from TornadoWeb import log
    from TornadoWeb.options import define, options, parse_command_line
    define("logging", default="none", help="logging level")
    parse_command_line()
    enable_pretty_logging(options=options)
    log.info('test_log1')
    log.error('test_log2')

# Generated at 2022-06-12 13:50:06.994559
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger('Test')
    enable_pretty_logging(None,logger)


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:50:08.058455
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-12 13:50:09.253381
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> bool
    try:
        LogFormatter()
        return True
    except:
        return False


# Generated at 2022-06-12 13:50:10.092731
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()



# Generated at 2022-06-12 13:50:13.516771
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger()
    fm = LogFormatter()
    ch = logging.StreamHandler()
    ch.setFormatter(fm)
    logger.addHandler(ch)
    logger.setLevel(logging.INFO)
    logger.info("info")
    logger.error("error")
    logger.warning("warning")
    logger.debug("debug")


# Generated at 2022-06-12 13:50:26.241034
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    msg = [
        {
            "message": "Testing message"
        },
        {
            "message": "Testing\nmessage\n",
            "exc_text":
                "message\n",
        },
        {
            "message": "Testing\nmessage\n",
            "exc_text":
                "message\n",
            "exc_info": "info",
        },
        {
            "message": "Testing\nmessage\n",
            "exc_text":
                "message\n",
            "exc_info": "info",
            "levelno": 4,
        },
    ]


# Generated at 2022-06-12 13:50:26.843341
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter

# Generated at 2022-06-12 13:50:36.643796
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.Formatter = LogFormatter

    # type: Optional[Dict[str, Any]]
    options = {'logging': None}
    access_log.setLevel(options)
    access_log.setFormatter()
    access_log.debug(message, *args, **kwargs)
    access_log.info(message, *args, **kwargs)
    access_log.warning(message, *args, **kwargs)
    access_log.error(message, *args, **kwargs)
    access_log.critical(message, *args, **kwargs)
    access_log.log(level, message, *args, **kwargs)

    message = "message"
    args = ("args",)
    kwargs = {"kwargs": "kwargs"}

# Generated at 2022-06-12 13:51:09.254254
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger=logging.getLogger()
    logger.setLevel(logging.DEBUG)
    options = None
    enable_pretty_logging(options,logger)
    access_log.info("test_enable_pretty_logging")
    app_log.info("test_enable_pretty_logging")
    gen_log.info("test_enable_pretty_logging")

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:51:10.906258
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter is not None



# Generated at 2022-06-12 13:51:14.385116
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()  # type: ignore
    assert lf, "failed to create LogFormatter()"


# define a Handler class which writes formatted logging records to disk files

# Generated at 2022-06-12 13:51:24.529287
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    from tornado.log import access_log, app_log, gen_log
    import logging
    import time
    import timeit
    # Set the global options
    options.log_file_prefix = "test.log"
    options.log_file_max_size = 10
    options.log_file_num_backups = 5
    options.log_rotate_mode = "size"
    # Set the logging level of three loggers
    gen_log.setLevel("DEBUG")
    app_log.setLevel("DEBUG")
    access_log.setLevel("DEBUG")
    # Test only enable logging to the file
    enable_pretty_logging(options)
    # Call the log_to_stderr method
    gen_log.info("This is general log")
    gen_log.error

# Generated at 2022-06-12 13:51:31.706247
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    log_formatter = LogFormatter(log_format, datefmt="%Y-%m-%d %H:%M")
    record = logging.LogRecord(
        "tornado.application", logging.INFO, "", 0, "test log", None, None
    )
    assert log_formatter.format(record) == "\x1b[32mINFO     \x1b[0m test log"



# Generated at 2022-06-12 13:51:41.893533
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test init
    fmt ="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(fmt, datefmt, style, color, colors)

    # Test format

# Generated at 2022-06-12 13:51:44.269907
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert formatter
    formatter = LogFormatter(color=True)
    assert formatter


# Generated at 2022-06-12 13:51:46.602743
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.format(logging.makeLogRecord({"msg": "foo"}))
    formatter.format(logging.makeLogRecord({"msg": u"bar"}))



# Generated at 2022-06-12 13:51:51.562981
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # unit test
    options = type('options', (), {})()
    options.logging = None
    options.log_file_prefix = None
    options.log_rotate_mode = "size"
    options.log_file_max_size = 100
    options.log_file_num_backups = 5
    options.log_to_stderr = None
    logger = logging.getLogger()
    enable_pretty_logging(options, logger)

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:51:54.516100
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: (...) -> None
    """Test LogFormatter constructor."""
    LogFormatter(color=False)
    LogFormatter(color=True)
    LogFormatter(color=True, fmt="%(color)s%(levelname)s%(end_color)s %(message)s")



# Generated at 2022-06-12 13:52:40.431381
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado import testing, options
    from io import StringIO
    io = StringIO()
    options.options.log_to_stderr = False
    options.options.log_file_prefix = io
    try:
        enable_pretty_logging(options.options)
        logger = logging.getLogger()
        logger.info("test message")
        assert io.getvalue() == "test message\n"
    finally:
        options.options.reset()



# Generated at 2022-06-12 13:52:45.450397
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "./logs/test_log.txt"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 5
    tornado.options.options.log_file_num_backups = 20
    enable_pretty_logging()
    logging.info("test_enable_pretty_logging")
# test_enable_pretty_logging()

# Generated at 2022-06-12 13:52:56.634719
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import app_log, LogFormatter
    def my_addFilter(f):
        app_log.addFilter(f)
    class my_Filter(logging.Filter):
        def filter(self, record):
            return True
    my_f = logging.Filter()
    my_f = my_Filter()
    my_addFilter(my_f)
    def my_debug(self,msg):
        app_log.debug(msg)
    class my_Thread(object):
        def __init__(self):
            self.ident = '123'
    class my_LogRecord(object):
        def __init__(self,name,level,fn,lno,msg,args,exc_info,func=None,extra=None):
            self.name = name
            self.levelno = level
           

# Generated at 2022-06-12 13:52:59.644204
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    Test if LogFormatter can be instantiated with only True as input.
    """
    LogFormatter(True)



# Generated at 2022-06-12 13:53:01.745346
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import tornado.options
    tornado.options.parse_config_file("test_tornado.conf")
    logger = logging.getLogger("tornado.test")
    logger.error("msg1")
    logger.error("msg2", exc_info=True)



# Generated at 2022-06-12 13:53:07.347064
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: no cover
    import os
    import sys

    fmt = "%(color)s%(asctime)s %(message)s"
    formatter = LogFormatter(fmt, color=True)

    stream = sys.stdout
    formatter.formatTime(None, None)
    stream.write("\n")



# Generated at 2022-06-12 13:53:14.877646
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        import colorama
    except ImportError:  # pragma: no cover
        # Without colorama, this test would be skipped anyway.
        pass
    else:
        colorama.init()
    formatter = LogFormatter(color=True)
    assert formatter.format(logging.LogRecord("tornado.test", logging.DEBUG, "foo", 0, "this is a test", None, None))  # noqa: E501
    # TODO(benjamin): check the output format of this string

# Generated at 2022-06-12 13:53:20.175964
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = tornado.options.options
    options.logging = "info"
    options.log_file_prefix = "Logging.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 10
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    enable_pretty_logging(options, logger)

if __name__ == "__main__":
    test_enable_pretty_logging()
    print("Test Completed")

# Generated at 2022-06-12 13:53:22.224154
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()  # no arguments
    LogFormatter()  # no arguments



# Generated at 2022-06-12 13:53:31.365080
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger()
    # general test
    lf = LogFormatter()
    assert lf.formatTime(None) == ""

    # test color support
    lf = LogFormatter()
    lf._colors[20] = "test"
    lf._colors[30] = "test"
    lf._colors[40] = "test"
    lf._colors[50] = "test"
    lf._normal = "test"

    # when record.level not in self._colors
    record = logging.LogRecord(
        "name",
        30,
        __file__,
        10,
        "test",
        ["a"],  # args
        {},  # exc_info
    )
    assert "test" not in lf.format(record)
