

# Generated at 2022-06-12 13:46:05.966759
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass

# Generated at 2022-06-12 13:46:10.565834
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import define, options, parse_command_line
    define('logging', default='debug')
    define('log_file_prefix', default='/tmp/tornado.log')
    define('log_to_stderr', default=False)
    parse_command_line()
    import logging
    app_log = logging.getLogger("tornado.application")
    app_log.debug("test1")



# Generated at 2022-06-12 13:46:20.651151
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(datefmt='%H:%M:%S',fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s', style='%')
    assert log_formatter._fmt == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    assert log_formatter.datefmt == '%H:%M:%S'
    assert log_formatter.style == '%'


# Generated at 2022-06-12 13:46:26.119128
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Setup
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(fmt, datefmt, style, color, colors)

# Generated at 2022-06-12 13:46:32.386880
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class LogRecord(object):
        pass
    record = LogRecord()
    record.__dict__ = {"levelno": 1}
    formatter = LogFormatter(datefmt="%y%m%d %H:%M:%S")
    record.exc_info = True
    record.exc_text = "Test str"
    record.message = "Test message"
    assert isinstance(formatter.format(record), str)
    record.exc_info = False
    assert isinstance(formatter.format(record), str)


# Generated at 2022-06-12 13:46:40.513386
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test LogFormatter.format
    logging.basicConfig()
    r1 = logging.LogRecord(
        "name",
        logging.DEBUG,
        None,
        0,
        "0",
        (),
        None,
        "aaaa",
        exc_info=None
    )
    r2 = logging.LogRecord(
        "name",
        logging.DEBUG,
        None,
        0,
        "0",
        (),
        None,
        "bbbb",
        exc_info=Instance(Exception)
    )
    r3 = logging.LogRecord(
        "name",
        logging.INFO,
        None,
        0,
        "0",
        (),
        None,
        "cccc",
        exc_info=None
    )

# Generated at 2022-06-12 13:46:45.718241
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    datefmt = LogFormatter()._style._fmt
    fmt = LogFormatter.DEFAULT_FORMAT
    formatter = LogFormatter(fmt, datefmt)

    assert formatter._fmt == fmt
    assert formatter._style._fmt == datefmt



# Generated at 2022-06-12 13:46:54.250304
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    define("logging", default="info")
    define("log_file_prefix", default="test.log")
    define("log_rotate_mode", default="time")
    define("log_rotate_when", default="S")
    define("log_rotate_interval", default=1)
    define("log_file_max_size", default=1)
    define("log_file_num_backups", default=1)
    parse_command_line(["--logging","info"])
    enable_pretty_logging(options)
    assert options.log_file_prefix == "test.log"
    assert options.log_rotate_mode == "time"
    assert options.log_rotate_when == "S"

# Generated at 2022-06-12 13:46:58.243152
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger('test')
    log = LogFormatter()
    record = logger.makeRecord('test', logging.DEBUG, 'none', 1, "test")
    message = log.format(record)
    assert message.find("\n    ") == -1



# Generated at 2022-06-12 13:47:00.973549
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    '''
    Test case for LogFormatter constructor
    '''
    formatter = LogFormatter(color=True)
    assert formatter._normal == "\033[0m"


# Generated at 2022-06-12 13:47:19.997359
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    logging.getLogger().setLevel(logging.DEBUG)
    tornado.testing.gen_test(main)()



# Generated at 2022-06-12 13:47:24.508390
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter(True, "%(message)s")
    LogFormatter(fmt="%(message)s")
    LogFormatter(color=True)
    LogFormatter(color=True, colors={})
    LogFormatter(color=True, colors={1: 1})
    LogFormatter(color=True, colors={logging.INFO: 1})



# Generated at 2022-06-12 13:47:25.486341
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:47:26.266209
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # TODO(omar): Implement it
    pass

# Generated at 2022-06-12 13:47:30.354534
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter("%(asctime)s").format(
        logging.LogRecord("foo", "debug", __file__, 1, "msg", (), None, None)
    ) != None


# Generated at 2022-06-12 13:47:38.302868
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest
    import tornado.testing
    import tornado.options
    import tornado.log

    class UtilTest(tornado.testing.AsyncTestCase):
        def test_logging_options(self):
            tornado.options.parse_command_line(["-logging=debug"])
            tornado.log.access_log.setLevel(logging.DEBUG)
            tornado.log.enable_pretty_logging()
            tornado.log.gen_log.error("Test message")
            tornado.log.access_log.error("Test message")
    unittest.main()

# Generated at 2022-06-12 13:47:39.220235
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:47:46.738302
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import datetime
    from tornado.log import gen_log

    # set to False when our formatters are ready to support str.format()
    use_str_format = True

    if use_str_format:
        fmt = "%(color)s%(asctime)s%(end_color)s %(message)s"
        colorama.init()
        tfmt = "%H:%M:%S"
        log_formatter = LogFormatter(fmt=fmt, datefmt=tfmt, color=True)
    else:
        fmt = "%%(color)s%%(asctime)s%%(end_color)s %%(message)s"
        colorama.init()
        tfmt = "%H:%M:%S"

# Generated at 2022-06-12 13:47:54.756489
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    a = LogFormatter(fmt="%(color)s%(levelname)s%(end_color)s %(message)s", color=False)
    assert a._normal == ""
    assert repr(a) == repr(a._fmt)

    b = LogFormatter(fmt="%(color)s%(levelname)s%(end_color)s %(message)s", color=True)
    assert curses or colorama
    assert b._normal != ""
    assert repr(b) == repr(b._fmt)


# Use a custom class to get colorization on Windows (colorama.ansitowin32)

# Generated at 2022-06-12 13:47:55.701178
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:48:20.206998
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    add_logging_file_option()
    add_logging_rotate_options()
    add_logging_options()
    add_logging_file_option()
    add_logging_rotate_options()
    add_logging_options()


# Generated at 2022-06-12 13:48:30.930490
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        # create a temp file
        import tempfile
        tf = tempfile.NamedTemporaryFile()
        filename = tf.name
    except:
        etype, value, tb = sys.exc_info()
        traceback.print_exception(etype, value, tb)
        sys.exit(1)
    #
    import tornado.options
    tornado.options.options.log_file_prefix = filename
    tornado.options.options.log_to_stderr = False
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    #
    gen_log.debug("This is debug")
    gen_log.info("This is info")
    # remove the temp file
    tf.close()

# Generated at 2022-06-12 13:48:38.853715
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  import tornado.options
  from tornado.options import options
  from tornado.options import define
  from tornado.log import app_log
  from tornado.log import gen_log
  from tornado.log import access_log
  define("logging", default="none",
         help=("Set the Python log level. If 'none', tornado won't touch the "
               "logging configuration."),
         metavar="debug|info|warning|error|none")
  define("log_file_prefix", type=str, default=None, metavar="PATH",
         help=("Path prefix for log files. "
               "Note that if you are running multiple tornado processes, "
               "log_file_prefix must be different for each of them (e.g. "
               "include the port number)"))

# Generated at 2022-06-12 13:48:48.765934
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Set up dummy command-line options
    class DummyOptions(object):
        log_file_prefix = "test_filename"
        log_file_max_size = 10485760
        log_file_num_backups = 20
        log_to_stderr = True
        log_rotate_mode = "time"
        log_rotate_when = "midnight"
        log_rotate_interval = 1
        logging = "debug"
    dummy_options = DummyOptions()

    # test logging mode is 'size'
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, dummy_options.logging.upper()))
    rotate_mode = dummy_options.log_rotate_mode

# Generated at 2022-06-12 13:48:54.910549
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging('None')
    #log = logging.getLogger()
    #log.setLevel(logging.DEBUG)
    #ch = logging.StreamHandler()
    #ch.setLevel(logging.DEBUG)
    #formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    #ch.setFormatter(formatter)
    #log.addHandler(ch)

# Generated at 2022-06-12 13:49:05.251537
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line(["--logging=debug","--log_file_prefix=test"])
    assert tornado.options.options.logging == "debug"
    assert tornado.options.options.log_file_prefix == "test"
    assert tornado.options.options.log_file_max_size == 100000000
    assert tornado.options.options.log_file_num_backups == 10
    assert tornado.options.options.log_rotate_when == "midnight"
    assert tornado.options.options.log_rotate_interval == 1
    assert tornado.options.options.log_rotate_mode == "size"
    assert not tornado.options.options.log_to_stderr

# Generated at 2022-06-12 13:49:15.118960
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado
    import tornado.options

    def parse_command_line():
        tornado.options.parse_command_line()

    def parse_config_file():
        tornado.options.parse_config_file()


# Generated at 2022-06-12 13:49:26.808972
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = ''
    tornado.options.options.log_file_prefix = ''
    tornado.options.options.log_file_max_size = 0
    tornado.options.options.log_file_num_backups = 0
    tornado.options.options.log_rotate_mode = ''
    tornado.options.options.log_rotate_when = ''
    tornado.options.options.log_rotate_interval = 0
    tornado.options.options.log_to_stderr = False
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging(tornado.options.options, logger)

# Generated at 2022-06-12 13:49:27.432800
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass



# Generated at 2022-06-12 13:49:34.344845
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # noqa: F811
    # test LogFormatter.__init__()
    # Since the constructor of LogFormatter is a bit dense,
    # this is a unit test for it.
    fmt = "%(color)s%(message)s%(end_color)s"
    datefmt = ""
    # logging.DEBUG -> 2: green
    formatter = LogFormatter(fmt, datefmt, color=True)
    level = logging.DEBUG
    record = logging.LogRecord(
        "test", level, None, None, "test", None, None
    )
    result = formatter.format(record)
    assert u"\033[2;32mtest\033[0m" == result

# Generated at 2022-06-12 13:50:15.206074
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    import logging, logging.config
    logging.basicConfig(level=logging.DEBUG)
    rootLogger = logging.getLogger()
    lf = LogFormatter(rootLogger.handlers[0].formatter._fmt)
    assert lf.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert lf.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"

# Generated at 2022-06-12 13:50:23.335855
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class FakeOptions(object):
        logging = 'debug'
        log_file_prefix = 'logs/log'
        log_rotate_mode = 'size'
        log_file_max_size = 100
        log_file_num_backups = 5
        log_to_stderr = True
        log_rotate_when = 'D'
        log_rotate_interval = 1
    enable_pretty_logging(FakeOptions())



# Generated at 2022-06-12 13:50:29.388943
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    from tornado.log import LogFormatter
    lf = LogFormatter()
    for level in [0, 10, 20, 30, 40, 50]:
        lf.format(logging.makeLogRecord({"levelno": level}))
    lf.format(logging.makeLogRecord({"levelno": 50, "exc_info": 1}))



# Generated at 2022-06-12 13:50:38.374572
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class TestOptions:
        pass
    options = TestOptions
    options.logging = None
    options.log_file_prefix = None
    options.log_file_max_size = 1024 * 1024
    options.log_file_num_backups = 2
    options.log_to_stderr = False
    enable_pretty_logging(options)

    options.log_file_prefix = "log/access.log"
    options.log_rotate_mode = "size"
    logger = logging.getLogger()
    enable_pretty_logging(options)
    logger.info('test')
    enable_pretty_logging(options, logger)
    logger.info('test')

    options.logging = "debug"
    options.log_rotate_mode = "time"
    logger = logging.getLog

# Generated at 2022-06-12 13:50:50.630126
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class FakeLogger(object):
        def __init__(self) -> None:
            self.messages = []

        def log(self, lvl, msg, *args, **kwargs):
            self.messages.append(msg)

    logger = FakeLogger()
    formatter = LogFormatter()
    formatter.format = LogFormatter.format
    handler = logging.StreamHandler()
    handler.emit = lambda record: None  # type: ignore
    handler.setFormatter = lambda format: formatter
    handler.setLevel = lambda lvl: None  # type: ignore
    handler.handle = lambda record: logger.log(record.levelno, record.msg)  # type: ignore
    logging.root.addHandler(handler)

    logger.log(logging.DEBUG, "test %d", 1)
    logger

# Generated at 2022-06-12 13:50:51.575443
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert enable_pretty_logging(), None



# Generated at 2022-06-12 13:50:57.558896
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # noqa: F811
    formatter = LogFormatter()
    formatter2 = LogFormatter(datefmt="%Y-%m-%d %H:%M:%S")
    formatter3 = LogFormatter(fmt="%(asctime)s %(message)s")
    formatter4 = LogFormatter(color=False)
    formatter5 = LogFormatter(colors={logging.DEBUG: 31})
    # no assertion, construction should just work



# Generated at 2022-06-12 13:51:00.671577
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()

# A helper class for unittest, this class is not intended to be used in production

# Generated at 2022-06-12 13:51:11.307313
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define, Error
    import logging
    import logging.handlers
    logger = logging.getLogger()
    logger.setLevel(logging.CRITICAL)
    # Test the case with logging level set to None
    options.logging = None
    enable_pretty_logging(options,logger)
    # Test the case with logging level set to "none"
    options.logging = "none"
    enable_pretty_logging(options,logger)
    # Test the case with logging level set to "debug"
    options.logging = "debug"
    enable_pretty_logging(options,logger)
    # Test the case with logging level set to "info"
    options.logging = "info"
    enable_pretty_logging(options,logger)
    # Test the

# Generated at 2022-06-12 13:51:12.127358
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-12 13:51:55.525161
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    from logging import Logger, LogRecord
    formatter = LogFormatter()
    record = LogRecord(name="test", level=10, pathname="a", lineno=2, msg="msg", args=(1,), exc_info=1)
    assert "msg" == formatter.format(record)
    record.message = "this is test"
    record.asctime = formatter.formatTime(record, formatter.datefmt)
    assert "[D" in formatter.format(record)
    record.args = None
    assert "[D" in formatter.format(record)
    record.args = ()
    record.exc_text = "exc_text"
    assert "exc_text" in formatter.format(record)

# Generated at 2022-06-12 13:52:01.102508
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing

    class OptionsTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(OptionsTest, self).setUp()
            self.config = {
                "logging": "warning",
                "log_file_prefix": self.get_temp_file("logging_test"),
                "log_to_stderr": False,
            }


if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:52:05.594043
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "test_file"
    tornado.options.options.log_file_max_size = 100*1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.logging = "info"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "d"
    tornado.options.options.log_rotate_interval = 1
    enable_pretty_logging()

# Generated at 2022-06-12 13:52:11.306115
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()

    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter._normal == ""
    assert formatter._colors == {}
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT
    assert formatter.style == "%"

    formatter = LogFormatter(
        fmt="foo", datefmt="bar", color=False, colors={1: 4, 2: 42}
    )

    assert formatter._fmt == "foo"
    assert formatter._normal == ""
    assert formatter._colors == {}
    assert formatter.datefmt == "bar"
    assert formatter.style == "%"



# Generated at 2022-06-12 13:52:15.292556
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    stream = logging.StreamHandler()
    fmt = LogFormatter()
    stream.setFormatter(fmt)
    record = logging.makeLogRecord({"msg": "foo", "levelno": 0})
    assert stream.format(record) == "[D 1970-01-01 00:00:00 root:0] foo"



# Generated at 2022-06-12 13:52:26.402876
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    # Sometimes unittest.main() is called without command line arguments,
    # in which case parse_command_line runs with default logging settings
    # (which is not a pretty log setup).  Since tests can modify
    # options.log_to_stderr, it can be confusing to try to print a log message
    # and have it go to stdout instead of stderr.  So just force the
    # log_to_stderr option in this case.
    if not tornado.options.options.log_to_stderr:
        tornado.options.options.log_to_stderr = True
        tornado.log._stderr_supports_color = lambda: True
        tornado.log.enable_pretty_logging()
        tornado.options.options.log_to_

# Generated at 2022-06-12 13:52:31.995796
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import define
    from tornado.options import parse_command_line
    define("log_file_prefix", type=str, default='foo.log')  # type: ignore
    parse_command_line()

    formatter = LogFormatter()
    text = formatter.format(logging.getLogger("tornado.access").warning("foo"))
    print(text)

# Generated at 2022-06-12 13:52:38.277229
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """Unit test for constructor of class LogFormatter."""
    x = LogFormatter()
    assert x.datefmt == x.DEFAULT_DATE_FORMAT
    assert x._colors == x.DEFAULT_COLORS
    assert x._normal == (
        "\033[0m"
        if _stderr_supports_color()
        else ""
    )



# Generated at 2022-06-12 13:52:46.621304
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  # Create an empty options object
  class Empty(object):
    pass
  options = Empty()
  # Set log_to_stderr to None, so that the logging handlers 
  # isn't changed
  options.log_to_stderr = None
  # Set logging level
  options.logging = "debug"
  # Load the enable_pretty_logging function
  enable_pretty_logging(options=options, logger=logging.getLogger())
  # If logging level is set to debug, output should be of the form:
  # [D yymmdd hh:mm:ss module:lineno]
  logging.debug("Test enable_pretty_logging")
  # Set logging level
  options.logging = "info"
  # Load the enable_pretty_logging function
  enable_pretty_logging

# Generated at 2022-06-12 13:52:48.230705
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options=options, logger=logger)

# Generated at 2022-06-12 13:53:54.630420
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.escape
    tornado.options.options.logging=10
    tornado.options.options.log_file_prefix=None
    tornado.options.options.log_file_num_backups=10


# Generated at 2022-06-12 13:54:00.591135
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    tornado.options.define('log_file_prefix',default='')
    tornado.options.define('log_file_max_size',default='d')
    tornado.options.define('log_file_num_backups',default=3)
    tornado.options.define('log_rotate_mode',default='size')
    tornado.options.define('log_rotate_when',default='midnight')
    tornado.options.define('log_rotate_interval',default=1)
    tornado.options.define('logging',default='none')
    tornado.options.define('log_to_stderr',default=None)
    
    enable_pretty_logging()

# Generated at 2022-06-12 13:54:06.001678
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_config_file
    import logging

    define("logging", default="info")
    define("log_file_prefix", default=None)
    define("log_to_stderr", default=None)
    define("log_rotate_mode", default="time")
    define("log_rotate_when", default="D")
    define("log_rotate_interval", default=1)
    define("log_file_num_backups", default=10)
    define("log_file_max_size", default=100 * 1000 * 1000)

    config = """
    [logging]
    log_file_prefix=test.log
    """
    parse_config_file(config.splitlines())
    enable_pretty_logging(options)

    # test the logger


# Generated at 2022-06-12 13:54:11.811353
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(levelname)s %(message) %(asctime)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    color = True
    colors = {logging.DEBUG: 4, logging.INFO: 2, logging.CRITICAL: 5}
    logFormatter = LogFormatter(fmt, datefmt, color, colors)


# Generated at 2022-06-12 13:54:21.089640
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter = LogFormatter(fmt='%(color)s%(message)s%(end_color)s', datefmt='%Y-%m-%d %H:%M:%S')
    formatter = LogFormatter(fmt='%(asctime)s %(color)s%(message)s%(end_color)s', datefmt='%Y-%m-%d %H:%M:%S')
    formatter = LogFormatter(fmt='%(asctime)s %(color)s%(message)s%(end_color)s')

# Generated at 2022-06-12 13:54:30.629298
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options  # noqa
    tornado.options.define("log_to_stderr", type=bool)
    tornado.options.define("logging", default="info", type=str)
    tornado.options.define("log_file_prefix", default="test.log", type=str)
    # rotate_mode: size or time
    tornado.options.define("log_rotate_mode", default="size", type=str)
    tornado.options.define("log_file_max_size", default=104857600, type=int)
    tornado.options.define("log_rotate_when", default="midnight", type=str)
    tornado.options.define("log_rotate_interval", default=1, type=int)

# Generated at 2022-06-12 13:54:41.036145
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os
    import shutil
    import tempfile

    def get_log_paths(tmp_dir: str) -> str:
        log_file_prefix = os.path.join(tmp_dir, "test_log")
        return log_file_prefix + ".log"

    def verify_log_files(
        tmp_dir: str,
        log_file_prefix: str,
        log_file_max_size: int,
        log_file_num_backups: int,
    ) -> None:
        log_paths = [log_file_prefix + ".log"] + [
            "%s.%d.log" % (log_file_prefix, i) for i in range(1, log_file_num_backups)
        ]

# Generated at 2022-06-12 13:54:45.502209
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if colorama is None:
        return
    colorama.init()
    try:
        c1 = LogFormatter("%(message)s", color=True)._colors
        c2 = LogFormatter("%(message)s", color=False)._colors
        assert c1 is not None
        assert c2 is None
    finally:
        colorama.deinit()


# Generated at 2022-06-12 13:54:47.896150
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert(len(formatter._colors) > 0)
    assert(formatter._normal == "\033[0m")
    formatter = LogFormatter(color=False)
    assert(len(formatter._colors) == 0)
    assert(formatter._normal == "")



# Generated at 2022-06-12 13:54:58.422856
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    If a byte string makes it this far, convert it to unicode to
    ensure it will make it out to the logs.  Use repr() as a fallback
    to ensure that all byte strings can be converted successfully,
    but don't do it by default so we don't add extra quotes to ascii
    bytestrings.  This is a bit of a hacky place to do this, but
    it's worth it since the encoding errors that would otherwise
    result are so useless (and tornado is fond of using utf8-encoded
    byte strings wherever possible).
    """
    logger = logging.getLogger()
    ch= logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(ch)