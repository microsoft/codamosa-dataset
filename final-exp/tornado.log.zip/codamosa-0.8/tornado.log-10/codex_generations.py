

# Generated at 2022-06-12 13:46:08.641128
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord(name='test', level=logging.INFO, pathname=__file__, lineno=23,
                                                   msg='test', args=(), exc_info=None)) == '[I 23 <stdin>:23] test\n    '


# Generated at 2022-06-12 13:46:15.477632
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class TestRecord(object):
        __slots__ = ["levelno", "msg", "args", "exc_info", "exc_text"]

        def __init__(self, 
            levelno: int,
            msg: str,
            args: tuple,
            exc_info: tuple,
            exc_text: str
            ) -> None:
            self.levelno = levelno
            self.msg = msg
            self.args = args
            self.exc_info = exc_info
            self.exc_text = exc_text

        def getMessage(self) -> Any:
            return self.msg

        def __equals__(self, other: "TestRecord") -> bool:
            return self.levelno == other.levelno and\
                self.msg == other.msg and\
                self.args == other.args

# Generated at 2022-06-12 13:46:22.737220
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    opts = tornado.options.options
    opts.logging = 'none'
    opts.log_file_prefix = 'log_file'
    opts.log_rotate_mode = 'time'
    opts.log_rotate_when = 's'
    opts.log_rotate_interval = 1
    opts.log_file_num_backups = 1
    opts.update_log_rotate_mode = 'time'
    opts.log_to_stderr = True
    enable_pretty_logging(opts)

# Generated at 2022-06-12 13:46:28.008751
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(fmt="%(hello)s", datefmt="%m/%d/%y")



# Generated at 2022-06-12 13:46:36.352742
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado import web
    from tornado.options import parse_command_line, options, define

    define('logging', default='warning')
    parse_command_line()

    def get_app():
        class MyHandler(web.RequestHandler):
            def get(self):
                self.write('hello')

        return web.Application([(r'/', MyHandler)])

    # Run an app and print the log message via LogFormatter
    # use `--logging=warning` to get a WARNING level message
    # in the console which is colored by `colorama`
    app = get_app()
    app.listen(8888)
    app.listen(8889)
    app.listen(8890)


if __name__ == '__main__':
    test_LogFormatter_format()

# Generated at 2022-06-12 13:46:38.038187
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format() == None


# Generated at 2022-06-12 13:46:39.336356
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    test_options = tornado.options.define_logging_options(options)
    assert test_options is not None, "test_define_logging_options is still empty"

# Generated at 2022-06-12 13:46:44.913311
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_formatter = LogFormatter()
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT


# Generated at 2022-06-12 13:46:49.727376
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log = LogFormatter()
    log.format(logging.LogRecord(
        't1', logging.INFO, None, 0, 'info message', None, None))
    log.format(logging.LogRecord(
        't2', logging.ERROR, None, 0, 'error message', None, None))

# A colorized logging formatter for use on a terminal
ColorizedLogFormatter = LogFormatter



# Generated at 2022-06-12 13:46:58.679567
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--logging',
        default=None,
        help="set log level")

    parser.add_argument(
        '--log-file-prefix',
        default=None,
        help="path prefix for log files")

    parser.add_argument(
        '--log-file-max-size',
        default=None,
        type=int,
        help="max size of log files before rollover")

    parser.add_argument(
        '--log-file-num-backups',
        default=None,
        type=int,
        help="number of log files to keep")


# Generated at 2022-06-12 13:47:13.710354
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter(color=True)
    _stderr_supports_color
    assert False


# Generated at 2022-06-12 13:47:16.076338
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_options = logging.getLogger()
    test_options.logging = "debug"
    enable_pretty_logging(options=test_options)

# Generated at 2022-06-12 13:47:20.041397
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert hasattr(formatter, 'DEFAULT_FORMAT')
    assert hasattr(formatter, 'DEFAULT_DATE_FORMAT')
    assert hasattr(formatter, 'DEFAULT_COLORS')



# Generated at 2022-06-12 13:47:27.838582
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    message = "There is no money, only credit!"
    # Object to test with
    lf = LogFormatter()
    # Replacing the format function of lf by our test function
    lf.format = LogFormatter.format.__wrapped__  # type: ignore
    # Creating object with the necessary fields
    record = logging.LogRecord("tornado.access", logging.INFO, "/home/user/", 2, "There is no money, only credit!", None, None)
    # Catching the output
    test_out = lf.format(record)
    # Our desired output
    desired_out = f"[I {record.asctime} {record.pathname}:1] {message}"
    # The unit test
    assert test_out == desired_out


# Generated at 2022-06-12 13:47:38.654516
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.testing import AsyncTestCase, LogTrapTestCase, gen_test

    class LogFormatterTest(AsyncTestCase, LogTrapTestCase):
        @gen_test
        def test_custom_log_formatter(self):
            formatter = LogFormatter(
                fmt="%(color)s%(asctime)s%(end_color)s%(message)s",
                datefmt="%H:%M:%S",
            )
            # fmt not contains levelname, so test without it
            self.log_trap.capture(name="tornado.access")
            access_log.info("foo")
            self.assertEqual(self.log_trap.wait(timeout=1), "00:00:00foo\n")
            self.log_trap.clear()
            # fmt

# Generated at 2022-06-12 13:47:46.330987
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    _stderr_supports_color = LogFormatter._stderr_supports_color
    class FakeOpt(object):
        color = True
    # set argv
    sys.argv = ['startservice', '--color=true']
    formatter = LogFormatter(fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    log = logging.getLogger(__name__)
    formatter.formatException = lambda exc_info: 'exception description'

# Generated at 2022-06-12 13:47:55.944284
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Test(object):
        pass

    test = Test()
    test.exc_info = None

# Generated at 2022-06-12 13:47:59.699796
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.log_to_stderr = None  # type: ignore
    enable_pretty_logging(options=options, logger=gen_log)

# Generated at 2022-06-12 13:48:06.747307
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(datefmt="%Y-%m-%d %H:%M:%S", color=True)
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" # noqa: E501
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" # noqa: E501

# Generated at 2022-06-12 13:48:10.897681
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest

    class LogFormatterTest(unittest.TestCase):
        def test_format(self):
            class Record(object):
                levelno = logging.DEBUG
                color = ''
                end_color = ''
                message = 'test'
                asctime = 'now'

            formatter = LogFormatter()
            formatted = formatter.format(Record)
            self.assertEqual(formatted, "[D now <unknown>:0] test")

            record = Record()
            record.message = "Unicode " + unichr(40960) + " and bytes"
            record.levelno = logging.INFO
            formatted = formatter.format(record)
            self.assertEqual(formatted, "[I now <unknown>:0] Unicode \uA000 and bytes")  # noqa: E501



# Generated at 2022-06-12 13:48:38.026697
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = {
        "log_to_stderr": True,
        "logging": "INFO",
        "log_file_prefix": "test_logs/tornado_test.log",
        "log_file_max_size": 100000,
        "log_file_num_backups": 3,
        "log_rotate_mode": "time",
        "log_rotate_when": "M",
        "log_rotate_interval": 1
    }

    enable_pretty_logging(options)
    tornado.options.options.log_to_stderr = True
    tornado.options.options.logging = "INFO"
    enable_pretty_logging()


if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:48:48.287115
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    # Test method LogFormatter.format(s) of class LogFormatter

    # Create LogFormatter object
    log_formatter = LogFormatter()

    # Create a new logger
    logger = logging.getLogger(__name__)

    # Set the log format and make sure the format is set correctly
    logger.setLevel(logging.INFO)
    msg_format = '%(asctime)s\t%(message)s'
    formatter = logging.Formatter(msg_format)
    log_formatter.datefmt = formatter.datefmt
    assert log_formatter.datefmt == formatter.datefmt

    # Create a console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)
    console_handler.set

# Generated at 2022-06-12 13:48:50.822692
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()     # type: ignore

# The interface of tornado.log is deprecated.  These functions
# are defined both here and in the new log module to minimize
# breakage for applications that import one or the other.



# Generated at 2022-06-12 13:49:00.841569
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test

    define('logging', default=None)
    options.logging = 'DEBUG'
    options.log_to_stderr = True
    options.log_file_prefix = None
    options.log_rotate_mode = 'size'
    options.log_rotate_when = None
    options.log_rotate_interval = None
    options.log_file_max_size = 0
    options.log_file_num_backups = 0

    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    enable_pretty_logging()

# Generated at 2022-06-12 13:49:08.419025
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():  # noqa: F811
    # type: () -> None
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase

    class Handler(logging.Handler):
        def __init__(self) -> None:
            self.records = []  # type: List[Any]
            logging.Handler.__init__(self)

        def emit(self, record: Any) -> None:
            self.records.append(record)

    class F(LogFormatter):
        def formatException(self, exc_info):
            return "xyz"

    h = Handler()
    f = F()
    h.setFormatter(f)
    logging.getLogger("tornado.foo").addHandler(h)
    logger = logging.getLogger("tornado.foo")

# Generated at 2022-06-12 13:49:13.892921
# Unit test for function define_logging_options
def test_define_logging_options():
    # deferred import for performance
    import tornado.options
    define_logging_options()
    assert tornado.options.options.logging == 'info'
    assert tornado.options.options.log_to_stderr == None
    assert tornado.options.options.log_file_prefix == None
    assert tornado.options.options.log_file_max_size == 100 * 1000 * 1000
    assert tornado.options.options.log_file_num_backups == 10
    assert tornado.options.options.log_rotate_when == 'midnight'
    assert tornado.options.options.log_rotate_interval == 1
    assert tornado.options.options.log_rotate_mode == 'size'
test_define_logging_options()

# Generated at 2022-06-12 13:49:23.737986
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging

    logger = logging.getLogger()
    handler = logging.StreamHandler()
    handler.setFormatter(LogFormatter())
    logger.addHandler(handler)

    logger.setLevel(logging.DEBUG)
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

# end of class LogFormatter

# The following configuration is equivalent to the previous simple_logging.
# In real world usage, error_log and access_log would point to their
# respective files.

# Generated at 2022-06-12 13:49:25.055623
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    return LogFormatter()


# Generated at 2022-06-12 13:49:25.771301
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-12 13:49:31.422022
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=True)
    assert formatter._colors != {}
    assert formatter._normal != ""



# Generated at 2022-06-12 13:50:07.946360
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Initialize the LogFormatter
    LogFormatter()
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    # Initialize the console log handler
    console_log_handler = logging.StreamHandler()
    console_log_handler.setLevel(logging.DEBUG)
    console_log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    console_log_formatter = logging.Formatter(console_log_format)
    console_log_handler.setFormatter(console_log_formatter)
    log.addHandler(console_log_handler)
    log.info("Test !")



# Generated at 2022-06-12 13:50:10.509877
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)
    if not _stderr_supports_color():
        assert len(formatter._colors) == 0
        assert formatter._normal == ""


# Generated at 2022-06-12 13:50:16.584924
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = r"test.log"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = True

    logger = logging.getLogger()
    logger.setLevel("DEBUG")

    logger.debug("test1")
    logger.info("test2")
    logger.warning("test3")
    logger.error("test4")

# Generated at 2022-06-12 13:50:21.046062
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("", 0, "", 0, "", (), None))
    formatter.format(logging.LogRecord("", 0, "", 0, "", (), None))



# Generated at 2022-06-12 13:50:25.682042
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Some constants for using the thread pool with the logging module.
_log_callback_args = None  # type: Optional[Any]
_log_callback_args_lock = None  # type: Any

# The implementation of the thread pool task.

# Generated at 2022-06-12 13:50:35.928487
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    logger = logging.getLogger()
    enable_pretty_logging(logger=logger)
    tornado.options.define(
        "logging", default=None, help="logging level", type=str
    )
    tornado.options.define(
        "log_file_prefix", default=None, help="log file prefix", type=str
    )
    tornado.options.define(
        "log_rotate_mode",
        default="size",
        help='"size" or "time"',
        type=str,
        group="Logging",
    )

# Generated at 2022-06-12 13:50:44.090589
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fm = LogFormatter()
    assert fm._colors == {
        logging.DEBUG: "\033[2;34m",
        logging.INFO: "\033[2;32m",
        logging.WARNING: "\033[2;33m",
        logging.ERROR: "\033[2;31m",
        logging.CRITICAL: "\033[2;35m",
    }
    fm = LogFormatter(color=False)
    assert fm._normal == ""
    assert fm._colors == {}



# Generated at 2022-06-12 13:50:54.513612
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Arrange
    r = logging.LogRecord
    r.name = "logger_name"
    r.msg = 'test_msg'
    r.args = [1,2]
    r.exc_info = "exc"
    r.levelname = "LEVELNAME"
    r.levelno = 666
    r.pathname = "path"
    r.filename = "file"
    r.module = "module"
    r.lineno = "lineno"
    r.funcName = "funcname"
    r.created = "12:34:56"
    r.msecs = "632"
    r.relativeCreated = "654321"
    r.thread = "thread"
    r.threadName = "threadName"
    r.processName = "pName"

# Generated at 2022-06-12 13:50:56.171472
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """Test method format of class LogFormatter"""
    # TODO: more



# Generated at 2022-06-12 13:50:58.555783
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """logging.Formatter.format(record)"""
    log_formatter = LogFormatter()
    print(log_formatter.format(1))


# Generated at 2022-06-12 13:51:27.730616
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformatter = LogFormatter()
    assert logformatter is not None



# Generated at 2022-06-12 13:51:30.976731
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class chLogFormatter(logging.Formatter):
        def format(self, record: Any) -> str:
            return 'A'
    logf = chLogFormatter()
    print(logf.format(1))



# Generated at 2022-06-12 13:51:31.952902
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    pass



# Generated at 2022-06-12 13:51:40.173391
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import sys
    try:
        from StringIO import StringIO  # type: ignore
    except ImportError:
        from io import StringIO  # type: ignore

    logging.basicConfig()
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.NOTSET)
    console_handler = logging.StreamHandler(sys.stdout)
    formatter = LogFormatter()
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    root_logger.critical("critical")
    console_handler.close()

# Generated at 2022-06-12 13:51:41.752752
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # mypy error: Instance of "LogFormatter" has no attribute "__init__".
    assert isinstance(LogFormatter(), logging.Formatter)


# Generated at 2022-06-12 13:51:42.629535
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:51:48.473182
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    rec = logging.makeLogRecord({
        'message': 'test', 'asctime': 0, 'levelno': logging.CRITICAL, 'module':
        'foo', 'lineno': 42, 'funcname': 'bar',
    })
    f.format(rec)
    assert rec.message == 'test'
    assert rec.asctime == 0
    assert rec.levelno == logging.CRITICAL
    assert rec.module == 'foo'
    assert rec.lineno == 42
    assert rec.funcname == 'bar'



# Generated at 2022-06-12 13:51:55.751286
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest
    import pathlib
    import os
    import tornado.options

    class TestHandler(tornado.options.ErrorHandler):
        def __init__(self):
            self.errors = []  # type: list[logging.LogRecord]

        def __call__(self, record: logging.LogRecord) -> None:
            self.errors.append(record)

    class LoggingTest(unittest.TestCase):
        def setUp(self) -> None:
            # Most tests assume color support.
            LogFormatter._stderr_supports_color = lambda: True
            self.test_dir = pathlib.Path(self.get_temp_dir())
            self.log_file_name = str(self.test_dir / "test-log.txt")

# Generated at 2022-06-12 13:52:03.545811
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger("tornado.application")
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logFormatter = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    )
    handler.setFormatter(logFormatter)

    logger.debug("test debug")
    logger.critical("test critical")

    logFormatter.datefmt = "%y%m%d %H:%M:%S"
    logFormatter.format()

    logFormatter.formatTime()

    logFormatter.formatException()

    logger.debug("tests debug")

# Generated at 2022-06-12 13:52:04.397021
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert True


# Generated at 2022-06-12 13:52:44.789622
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)

# Instruct the logging module to call our custom str() implementation
# for exceptions.  Tornado will use this to ensure that errors in
# asynchronous operations don't appear to come from the logging module.
logging.setLogRecordFactory(lambda *args: LogRecord(*args))

# Define a custom logger class that buffers log records and sends them to
# the logging subsystem in a separate thread.  This prevents I/O blocks from
# delaying request handling on the main thread, and makes it safe to log from
# asynchronous callbacks.  This is critical for logging the output of
# asynchronous HTTP clients, otherwise the client's log messages could be
# interleaved with those of the server.
#
# Unfortunately, python's standard logging module is poorly designed and
# difficult to extend.  It is easier to roll a simple logging system than to


# Generated at 2022-06-12 13:52:53.083074
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """
    import tornado.options
    tornado.options.options.log_file_prefix = "log.txt"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "H"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.logging = "warn"
    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()
    """
    pass

# Generated at 2022-06-12 13:52:55.280552
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    l = LogFormatter()
    l.format(logging.LogRecord("", 0, "", 0, "", (), None, None))


# Generated at 2022-06-12 13:53:07.937939
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    d = {logging.ERROR: 1, logging.CRITICAL: 5}
    LogFormatter(colors=d)

numeric_level = getattr(logging, "DEBUG", None)  # type: Optional[int]
if not isinstance(numeric_level, int):
    raise TypeError("Expected int, got {}".format(type(numeric_level)))

# Define a NullHandler for the root logger. This allows modules to use the
# Tornado logger without explicitly creating a TornadoHandler. This is
# useful for modules that don't have access to Tornado settings.
logging.getLogger().addHandler(logging.NullHandler())

# Define our TornadoHandler, which subclasses StreamHandler.
# This is the default handler for all tornado loggers, so it is
# immediately available to all modules in the tornado package.

# Generated at 2022-06-12 13:53:13.697305
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.log import gen_log

    log = LogFormatter(color=True, fmt="%(color)s%(levelname)s:%(end_color)s %(message)s")
    gen_log.addHandler(logging.StreamHandler())
    gen_log.setFormatter(log)
    gen_log.warning("test")



# Generated at 2022-06-12 13:53:14.307839
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()


# Generated at 2022-06-12 13:53:24.321915
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    # test without color
    class Record:
        def __init__(self):
            self.levelno = logging.INFO

    record = Record()
    record.levelno = logging.INFO
    record.message = "Hello"
    record.color = ""
    record.end_color = ""
    record.asctime = ""
    assert f.format(record) == "[I  ] Hello"
    # test with color
    f = LogFormatter()
    record = Record()
    record.levelno = logging.CRITICAL
    record.message = "Hello"
    record.color = "\033[2;31m"
    record.end_color = "\033[0m"
    record.asctime = ""

# Generated at 2022-06-12 13:53:33.505232
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()

    assert formatter.DEFAULT_FORMAT == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    assert formatter.DEFAULT_DATE_FORMAT == '%y%m%d %H:%M:%S'
    assert formatter.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}
    assert formatter._colors == {}
    assert formatter._normal == ''
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter.datefmt == formatter.DEFAULT_D

# Generated at 2022-06-12 13:53:43.093762
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    l = LogFormatter(color=True)
    l = LogFormatter(color=False)
    l = LogFormatter(color=True, colors={})
    l = LogFormatter(color=True, fmt="%(message)s")
    l = LogFormatter(color=True,
                     colors={logging.CRITICAL: 9, logging.ERROR: 1})
    l = LogFormatter(color=True,
                     colors={logging.CRITICAL: 9, logging.ERROR: 1,
                             logging.INFO: 2})
    l = LogFormatter(color=True,
                     colors={logging.CRITICAL: 9, logging.ERROR: 1,
                             logging.INFO: 2, logging.WARNING: 3})

# Generated at 2022-06-12 13:53:47.274148
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log = LogFormatter().format(logging.LogRecord(
        name="tornado.access",
        level=logging.ERROR,
        pathname="/home/roberto/repositories/tornado/tornado/gen.py",
        lineno=30,
        msg='test message',
        args=(),
        exc_info=None
    ))
    assert log == "[E 121228 15:09:04 gen:30] test message"


# Generated at 2022-06-12 13:54:30.504706
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # noqa: F811
    import unittest
    import logging
    import logging.handlers
    import io

    class LogFormatterConstructorTest(unittest.TestCase):
        def test_default(self) -> None:
            formatter = LogFormatter()
            self.assertTrue(isinstance(formatter, LogFormatter))

            r = logging.LogRecord("", logging.DEBUG, None, None, "", None, None)
            r.asctime = "asctime"
            r.relativeCreated = 1.2
            r.levelname = "DEBUG"
            r.message = "message"
            s = formatter.format(r)
            expect = (
                "[D asctime :] message\n"
                "    "
            )
            self.assertEqual(expect, s)

# Generated at 2022-06-12 13:54:40.920939
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest
    import tornado.options

    class ParseTest(unittest.TestCase):
        def setUp(self):
            from tornado.options import define

            define("log_file_prefix", type=str, default=None)
            define("log_to_stderr", type=bool, default=None)
            define("logging", type=str, default="info")
            define("log_rotate_mode", type=str, default="size")
            define("log_rotate_when", type=str, default="midnight")
            define("log_file_max_size", type=int, default=104857600)  # 100mb
            define("log_file_num_backups", type=int, default=100)

# Generated at 2022-06-12 13:54:44.877328
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options(object):
        def __init__(self, logging: str = "debug", log_to_stderr: bool = False):
            self.logging = logging
            self.log_to_stderr = log_to_stderr
    enable_pretty_logging(Options())
    print(app_log)
    print(access_log)
    print(gen_log)


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:54:49.856671
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import tornado.locale
    from tornado.testing import AsyncTestCase, LogTrapTestCase, gen_test
    from tornado.template import Template
    from tornado.util import u

    class LogFormatterTest(AsyncTestCase, LogTrapTestCase):
        def do_test(
            self,
            fmt: str,
            datefmt: str,
            record: Dict[str, Any],
            expected: str,
            expected_full: str = None,
        ) -> None:
            formatter = LogFormatter(fmt=fmt, datefmt=datefmt)
            result = formatter.format(record)
            if expected_full is not None:
                self.assertEqual(result, expected_full)

# Generated at 2022-06-12 13:54:52.214943
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf # noqa: B004


# Generated at 2022-06-12 13:55:03.027400
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.test",
        logging.DEBUG,
        "/fake/path",
        666,
        "message",
        {},
        None,
    )
    # default case
    message = formatter.format(record)
    if colorama:
        assert message == "[D 100101 00:00:00 test:666] message"
    else:
        assert message == "[D 100101 00:00:00 test:666] \x1b[34mmessage\x1b[0m"
    record.exc_info = "info"
    record.exc_text = "text"
    message = formatter.format(record)

# Generated at 2022-06-12 13:55:03.574917
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-12 13:55:04.883954
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert enable_pretty_logging.__doc__ is not None

# Generated at 2022-06-12 13:55:06.497725
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-12 13:55:17.486291
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    from tornado.options import options
    from tornado.log import enable_pretty_logging
    import os
    import os.path
    import time
    def test_size():
        options.log_rotate_mode="size"
        options.log_file_max_size=2
        options.log_file_prefix="./test_files/test_size_log.txt"
        logger = logging.getLogger()
        enable_pretty_logging(options,logger)
        cnt=1
        while 1:
            logging.info(str(cnt)+"a"*(cnt%5+1))
            cnt+=1
            time.sleep(0.5)
            file_number=0