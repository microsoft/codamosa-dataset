

# Generated at 2022-06-12 13:46:08.868517
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    L = LogFormatter()
    L.formatTime(None,None)
    L.formatException(None)
    record = logging.LogRecord('name', logging.DEBUG, 'pathname', 0, 'msg', None, None)
    L.format(record)
    
    

# Generated at 2022-06-12 13:46:11.397991
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None, gen_log)
    try:
        gen_log.info("testing Tornado pretty log")
    except:
        pass


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:46:14.824423
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    assert type(f.format({'message': 'x', 'asctime': 'x'})) == str



# Generated at 2022-06-12 13:46:20.528067
# Unit test for function define_logging_options
def test_define_logging_options():
    if 'tornado' in sys.modules: del sys.modules['tornado']
    import tornado.options
    from tornado.options import define, parse_command_line
    define(
        "check_logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    define(
        "check_log_to_stderr",
        type=bool,
        default=None,
        help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."
        ),
    )

# Generated at 2022-06-12 13:46:28.221173
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import logging
    assert isinstance(
        LogFormatter(), logging.Formatter
    )  # type: ignore # https://github.com/python/mypy/issues/1424
    assert isinstance(
        LogFormatter(fmt="%(color)s"), logging.Formatter
    )  # type: ignore # https://github.com/python/mypy/issues/1424
    assert isinstance(
        LogFormatter(datefmt="%(color)s"), logging.Formatter
    )  # type: ignore # https://github.com/python/mypy/issues/1424
    assert isinstance(
        LogFormatter(style="%"), logging.Formatter
    )  # type: ignore # https://github.com/python/mypy/issues/1424

# Generated at 2022-06-12 13:46:37.053499
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Record(object):
        def __init__(self):
            self.message = "message"
            self.exc_info = None
            self.levelno = logging.DEBUG
            self.exc_text = None

    fmt = "%(message)s"
    datefmt = "datefmt"
    style = "%"
    color = True
    colors = {logging.DEBUG: 4}

    logFormatter = LogFormatter(fmt, datefmt, style, color, colors)
    # Format the message
    formatted = logFormatter.format(Record())
    expected = "[D 0001-01-01 00:00:00 :0] message"
    assert formatted == expected


# Generated at 2022-06-12 13:46:49.089095
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import unittest

    class TestPrettyLogging(unittest.TestCase):
        def test_enable_pretty_logging(self):
            # Ensure that the logging level is at the default (info)
            self.assertEqual(logging.getLogger().level, logging.INFO)

            # Ensure that color is enabled by default
            self.assertEqual(tornado.log.gen_log.handlers[0].formatter._normal, "\033[0m")

            # Ensure that enable_pretty_logging() can set debugging as well
            tornado.options.enable_pretty_logging(options=tornado.options.options, logger=tornado.log.gen_log)
            self.assertEqual(tornado.log.gen_log.level, logging.DEBUG)


# Generated at 2022-06-12 13:46:49.938867
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-12 13:46:58.858279
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class LogFormatter_test(LogFormatter):
        DEFAULT_COLORS = {
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        }
    logformat = LogFormatter_test()
    record = logging.LogRecord("tornado.access", logging.DEBUG, "test.py", 1024, "test", (), None)
    record.name = "tornado.access"
    record.levelname = "debug"
    record.getMessage = lambda: "test"
    record.filename = "test.py"
    record.lineno = 1024
    record.module = "test"
    record.msg = "test"
    assert log

# Generated at 2022-06-12 13:47:09.709508
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # need to create a logging.LogRecord
    record = logging.LogRecord(
        name="tornado",
        level=logging.CRITICAL,
        pathname="test_logging.py",
        lineno=100,
        msg="test message",
        args=(),
        exc_info=None,
    )
    from tornado.log import LogFormatter
    formatter = LogFormatter()
    assert (
        formatter.format(record)
        == "[C 100 test_logging.py] test message\n"
        "    \033[0m"
    )
    
    # when level is not in the _colors of this class

# Generated at 2022-06-12 13:48:04.406736
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log

    tornado.options.define("logging", default="info", help="logging level", type=str)
    tornado.options.define("log_file_prefix", default='/tmp/test_tornado_log', help="log file name prefix", type=str)
    tornado.options.define("log_file_max_size", default=100, help="max size of log file", type=int)
    tornado.options.define("log_file_num_backups", default=10, help="number of log files to keep", type=int)
    tornado.options.define("log_rotate_mode", default='size', help='log rotate mode, size/time', type=str)

# Generated at 2022-06-12 13:48:14.648765
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # We don't test everything here, but if enable_pretty_logging fails to
    # set up logging at all, it will raise an exception that will fail the
    # test.
    enable_pretty_logging()
    logger = logging.getLogger()
    logger.info('test message')
    import tornado.options
    logger = logging.getLogger()
    old_level = logger.level
    tornado.options.parse_command_line(["--logging=debug"])
    assert logger.level == logging.DEBUG
    logger.setLevel(old_level)
    tornado.options.parse_command_line([])
# https://github.com/tornadoweb/tornado/blob/master/tornado/log.py

# -------------------------
# asynctask.py
# -------------------------


# Generated at 2022-06-12 13:48:23.132750
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    import logging

    define("log_rotate_mode", "time")
    define("log_rotate_interval", "10s")
    define("log_rotate_when", "S")
    define("log_file_num_backups", "1")
    define("log_to_stderr", "True")
    enable_pretty_logging(options)
    assert type(logging.getLogger().handlers[0])==logging.StreamHandler
    define("log_file_prefix", "./log_file_prefix")
    enable_pretty_logging(options)
    assert type(logging.getLogger().handlers[0])==logging.handlers.TimedRotatingFileHandler
    define("log_rotate_mode", "size")
    enable_

# Generated at 2022-06-12 13:48:25.354954
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

_default_log_handler: Optional[logging.Handler] = None



# Generated at 2022-06-12 13:48:33.251816
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger('test')
    # Make sure the constructor (and initialization of _color) work
    f = LogFormatter()
    assert f._color is not None
    # Make sure the formatter at least does *something*
    logger.handlers = []
    handler = logging.StreamHandler(stream=None)
    handler.setFormatter(f)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.info('test')
    assert len(logger.handlers) == 1
    logger.removeHandler(handler)
    assert len(logger.handlers) == 0



# Generated at 2022-06-12 13:48:34.476188
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Add your own test here
    assert False


# Generated at 2022-06-12 13:48:41.091783
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import time
    import sys, os
    def check_init(options=None):
        if not options:
            import tornado.options
            options = tornado.options.options
        if options.logging is None or options.logging.lower() == "none":
            return
        logger = logging.getLogger()
        logger.setLevel(getattr(logging, options.logging.upper()))
        if options.log_file_prefix:
            rotate_mode = options.log_rotate_mode

# Generated at 2022-06-12 13:48:49.664257
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Create a logger object
    import logging
    logger = logging.getLogger("tornado.test")

    # Log a message
    logger.error("Look at this cool example")
    # Logging to a File
    import logging
    logger = logging.getLogger("tornado.test")
    fhandler = logging.FileHandler("test.log")
    formatter = logging.Formatter("%(asctime)s %(levelname)-8s %(message)s")
    fhandler.setFormatter(formatter)
    logger.addHandler(fhandler)
    logger.setLevel(logging.INFO)
    logger.info("lkj")


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:00.972681
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import time
    import tornado.options
    import logging
    import datetime
    import os
    import shutil
    # create a temp file
    f = open("tempfile", "w")
    print("Hello World!", file=f)
    f.close()
    # test logging.CRITICAL level
    tornado.options.options.log_to_stderr = True
    tornado.options.options.log_file_prefix = "tempfile"
    tornado.options.options.log_file_max_size = 1
    tornado.options.options.log_file_num_backups = 2
    tornado.options.options.logging = "CRITICAL"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "S"

# Generated at 2022-06-12 13:49:01.933649
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert True
test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:23.738026
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(
        fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
        datefmt='%y%m%d %H:%M:%S',
        style='%',
        color=True,
        colors={logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5},
    )
    print('formatter._fmt =', formatter._fmt)


# Generated at 2022-06-12 13:49:33.183356
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Some of the methods in LogFormatter are difficult to test
    # effectively at the unit test level, due to their dependence on
    # an external terminal emulator.  This test ensures that at least
    # a few different ways of calling the formatter yield the expected
    # result.
    # There may be better test cases that can be added here.
    import time
    import unittest
    from tornado.test.util import skipIfNoExec

    @skipIfNoExec
    def test_with_shell(self):
        date = time.strftime("%y%m%d %H:%M:%S", time.localtime(self.now))
        logger = logging.getLogger("x")
        original_stderr = sys.stderr
        sys.stderr = StringIO()
        logger.warning("hello")
       

# Generated at 2022-06-12 13:49:35.681322
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    assert LogFormatter().datefmt == LogFormatter.DEFAULT_DATE_FORMAT


# Generated at 2022-06-12 13:49:43.159358
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    from tornado.options import OptionParser
    from tornado.log import gen_log
    parser = OptionParser()
    logging_group = parser.add_option_group("Logging options")
    tornado.options.add_logging_options(logging_group)
    options, args = parser.parse_args(['--logging=DEBUG'])
    enable_pretty_logging()
    gen_log.debug("sample debug")
    gen_log.info("sample info")
    gen_log.warning("sample warning")
    gen_log.error("sample error")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:44.001080
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:49:47.255127
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    enable_pretty_logging(options=None)
    enable_pretty_logging(logger=gen_log)
    enable_pretty_logging(options=None, logger=gen_log)

# Generated at 2022-06-12 13:49:50.678037
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    res = LogFormatter(fmt = "%(message)s", datefmt = "%y%m%d %H:%M:%S", color = True, colors=LogFormatter.DEFAULT_COLORS)
    assert type(res) == LogFormatter


# Generated at 2022-06-12 13:49:51.515250
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:50:03.060716
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    class Record(object):
        def __init__(self, **kwargs: Any) -> None:
            for k, v in kwargs.items():
                setattr(self, k, v)

    record = Record(
        name="tornado.application",
        filename="/path/to/tornado/web.py",
        funcname="test_LogFormatter",
        lineno=15,
        levelno=20,
        levelname="INFO",
        asctime="2016-09-05 10:02:56,123",
        message="Debug message",
        color="",
        end_color="",
        exc_info=None,
        exc_text=None,
    )  # type: Record
    formatter.format(record)



# Generated at 2022-06-12 13:50:04.333208
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter


# Generated at 2022-06-12 13:50:29.947878
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()



# Generated at 2022-06-12 13:50:32.048181
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:50:39.641512
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define
    
    define("logging", default="debug")  # noqa
    define("log_file_prefix", default=None)  # noqa
    define("log_to_stderr", default=True)  # noqa

    enable_pretty_logging()
    access_log.setLevel(logging.WARNING)
    app_log.setLevel(logging.WARNING)
    gen_log.setLevel(logging.WARNING)

    self.assertTrue(app_log.isEnabledFor(logging.WARNING))
    self.assertFalse(app_log.isEnabledFor(logging.INFO))

    app_log.info("info")
    app_log.warning("warning")
    app_log.error("error")

# Generated at 2022-06-12 13:50:45.588543
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    instance = LogFormatter()
    assert isinstance(instance.format(None), str)
    assert isinstance(instance.format(logging.LogRecord(
        message='hi',
        levelno=1,
        filename='foo.py',
        lineno=1,
        name='bar.baz')
    ), str)



# Generated at 2022-06-12 13:50:46.594684
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print('testing LogFormatter')



# Generated at 2022-06-12 13:50:48.299087
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    Formatter = LogFormatter(color = True, datefmt="%d")
    # Pass test if no exception
    group

# Generated at 2022-06-12 13:50:56.389646
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    with open("test_logging.log", "w") as f:
        handler = logging.StreamHandler(f)
        handler.setFormatter(LogFormatter())
        gen_log.addHandler(handler)
        gen_log.setLevel(logging.INFO)
        gen_log.info("1")
    with open("test_logging.log", "r") as f:
        s = f.read()
    expected = (
        "INFO "
        + gen_log.findCaller()[0].replace("\\", "/").split("tornado/")[1]
        + ":1] 1\n"
    )
    return expected == s


# Generated at 2022-06-12 13:51:02.656546
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    ''' Unit test for function enable_pretty_logging in logging.py '''
    import tornado.options
    import StringIO
    class Options(object):
        logging = 'debug'
        log_file_prefix = ''
        log_to_stderr = True
        log
    options = Options()
    logger = logging.getLogger()
    enable_pretty_logging(options, logger)

# Generated at 2022-06-12 13:51:12.600809
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

# Generated at 2022-06-12 13:51:14.032124
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()  # this should pass



# Generated at 2022-06-12 13:52:21.386712
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("Unit test for function enable_pretty_logging")

# Generated at 2022-06-12 13:52:23.554897
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("testing enable_pretty_logging")
    enable_pretty_logging()
    #assert 
    
    
test_enable_pretty_logging()

# Generated at 2022-06-12 13:52:26.362465
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)
    assert formatter._colors
    assert formatter._normal

    formatter = LogFormatter(color=False)
    assert not formatter._colors
    assert not formatter._normal




# Generated at 2022-06-12 13:52:36.596279
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import io
    stream=io.StringIO()
    h=logging.StreamHandler(stream)
    f=LogFormatter('[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s',
            datefmt='%y%m%d %H:%M:%S')
    h.setFormatter(f)
    logging.basicConfig(level=logging.DEBUG, handlers=[h])
    log = logging.getLogger()

    stream.seek(0)
    log.info('test')
    #print(stream.getvalue())
    assert stream.getvalue().endswith('test\n')
    #from IPython import embed
    #embed()

# Generated at 2022-06-12 13:52:45.947174
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter(color=False)

    test_msg = "test_LogFormatter"
    record = logging.LogRecord("tornado.test", logging.DEBUG, "", 6, test_msg, [], None)
    self.assertEqual(
        fmt.format(record),
        '[D %(asctime)s tornado.test:6] %(message)s' % dict(asctime=record.asctime, message=test_msg),  # noqa: E501
    )

    record = logging.LogRecord(
        "tornado.test", logging.WARNING, "", 6, test_msg, [], None
    )

# Generated at 2022-06-12 13:52:47.235108
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = LogFormatter()


# Generated at 2022-06-12 13:52:58.644402
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter(color=False)
    assert f._normal == ""
    assert f._colors == {}

    colorama.init()
    try:
        f = LogFormatter(color=True)
        assert f._normal == "\033[0m"
        assert f._colors == {
            logging.DEBUG: "\033[2;36m",
            logging.INFO: "\033[2;32m",
            logging.WARNING: "\033[2;33m",
            logging.ERROR: "\033[2;31m",
            logging.CRITICAL: "\033[2;35m",
        }
    finally:
        colorama.deinit()

    f = LogFormatter()
    assert f._normal == "\033[0m"

# Generated at 2022-06-12 13:53:10.411089
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        def dummy_options():
            return type('', (object,), {
                'logging': 'WARNING',
                'log_file_prefix': 'my_log',
                'log_rotate_mode': 'size',
                'log_file_max_size': 100,
                'log_file_num_backups': 3,
                'log_to_stderr': False,
            })
        logger = logging.getLogger()
        enable_pretty_logging(dummy_options(), logger)
        assert len(logger.handlers) == 1
        assert isinstance(logger.handlers[0], logging.handlers.RotatingFileHandler)
    finally:
        for handler in logger.handlers:
            logger.removeHandler(handler)

# Generated at 2022-06-12 13:53:19.324513
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # §§attr(res, "message") = _safe_unicode(message)
    # ${res.message}
    # ${res.asctime}
    # ${res.color}
    # ${res.end_color}
    # (${res.exc_info})
    # (${res.exc_text})
    lf = LogFormatter(datefmt='%y%m%d %H:%M:%S')
    from tornado.httputil import HTTPServerRequest
    import time

# Generated at 2022-06-12 13:53:20.966882
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-12 13:55:14.369830
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None, None)

# Generated at 2022-06-12 13:55:16.293941
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-12 13:55:18.389526
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(fmt = '%(asctime)s %(message)s')
    print(formatter)

test_LogFormatter()


# Generated at 2022-06-12 13:55:23.444552
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.ioloop
    import logging
    import logging.config
    import random
    import time
    import os
    from tornado.options import define, options
    define("log_file_prefix", "logs/log-")
    define("log_to_stderr", default=False)
    define("logging", default="info")
    define("log_file_max_size", default=1047576)
    define("log_file_num_backups", default=1)
    define("log_rotate_mode", default="size")
    define("log_rotate_when", default="W6")
    define("log_rotate_interval", default=1)
    tornado.options.parse_command_line()

# Generated at 2022-06-12 13:55:31.786662
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert True
    if _stderr_supports_color():
        assert isinstance(lf._colors.get(logging.INFO), str)
        assert isinstance(lf._colors.get(logging.ERROR), str)
        assert isinstance(lf._normal, str)
    else:
        assert lf._colors.get(logging.INFO) is None
        assert lf._colors.get(logging.ERROR) is None
        assert lf._normal == ""



# Generated at 2022-06-12 13:55:32.616102
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:55:38.699403
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import logging.config

    def test(**kwargs):
        logging.config.dictConfig(
            {"version": 1, "formatters": {"colored": {"()": LogFormatter, **kwargs}}}
        )
        logging.debug("test")
        logging.info("test")
        logging.warning("test")
        logging.error("test")
        logging.critical("test")

    test()
    test(color=False)
    test(color=True, colors={logging.DEBUG: 7})



# Generated at 2022-06-12 13:55:46.505674
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define(
        "logging",
        default="none",
        type=str,
        help=("Set the Python log level. If 'none', tornado won't touch the " "logging configuration."),
    )
    tornado.options.define(
        "log_to_stderr",
        default=False,
        type=bool,
        help="Send log output to stderr (colorized if possible).",
    )
    tornado.options.define(
        "log_file_prefix",
        default=None,
        type=str,
        help=("Path prefix for log files. " "Note that if you are running multiple tornado processes, " "log_file_prefix must be different for each of them (e.g. " "include the port number)."),
    )