

# Generated at 2022-06-12 13:46:13.348112
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    opt = tornado.options.options
    opt.logging = None
    enable_pretty_logging()
    opt.logging = "none"
    enable_pretty_logging()
    opt.logging = "debug"
    enable_pretty_logging()
    opt.logging = "INFO"
    enable_pretty_logging()
    opt.logging = "WARNING"
    enable_pretty_logging()
    opt.logging = "error"
    enable_pretty_logging()
    opt.logging = "CRITICAL"
    enable_pretty_logging()
    opt.logging = "info"
    enable_pretty_logging(opt)
    logger = logging.getLogger()
    logger.setLevel(logging.CRITICAL)
    enable_pretty_log

# Generated at 2022-06-12 13:46:15.114672
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()


# Generated at 2022-06-12 13:46:21.102051
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class TestHandler(logging.NullHandler):
        def emit(self, record: Any) -> None:
            pass

    logger = logging.getLogger("test.test_tornado")
    logger.setLevel(logging.WARN)
    handler = TestHandler()
    logger.addHandler(handler)
    handler.setFormatter(LogFormatter())
    logger.warn("Test warn")
    logger.error("Test error")
    logger.critical("Test critical")



# Generated at 2022-06-12 13:46:25.059717
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    lf = LogFormatter(datefmt = "AAAAAA %Y %m %d %H:%M:%S.%f %Z %z %j %U %W %c %x %X")
    d1 = datetime.datetime(2018, 6, 12, 1, 2, 3, 456)
    print(lf.formatTime(d1, "AAAAAA %Y %m %d %H:%M:%S.%f %Z %z %j %U %W %c %x %X"))



# Generated at 2022-06-12 13:46:33.717894
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log
    tornado.log._STDERR_SUPPORTS_COLOR = True
    tornado.log.use_stderr = True
    # The logger name is 'tornado.application', so if a log message is emitted,
    # it will be logged by the root logger and its handler.
    root_logger = logging.getLogger()
    root_logger.addHandler(logging.StreamHandler())
    root_logger.setLevel(logging.DEBUG)
    app_log.debug("Debug message")
    app_log.info("Info message")
    app_log.warning("Warning message")
    app_log.error("Error message")
    app_log.critical("Critical message")



# Generated at 2022-06-12 13:46:41.468204
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # fmt: off
    lf = LogFormatter(color=False, fmt="%(color)s%(levelname)s %(message)s%(end_color)s")
    assert 'WARNING test' == lf.format(logging.makeLogRecord({
        "levelno": logging.WARNING,
        "msg": "test",
    }))

    lf = LogFormatter(color=True, fmt="%(color)s%(levelname)s %(message)s%(end_color)s")
    assert '\x1b[2;37mWARNING \x1b[0mtest' == lf.format(logging.makeLogRecord({
        "levelno": logging.WARNING,
        "msg": "test",
    }))
    # fmt: on



# Generated at 2022-06-12 13:46:51.527891
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    # print(formatter.format({'levelname':'w', 'name':'none', 'msg':'aaaaaaa','lineno':10}))
    # print(help(logging.LogRecord))
    #https://docs.python.org/3.6/library/logging.html
    #help(logging.LogRecord.__init__)
    record = logging.LogRecord(
        'test', level=logging.INFO, pathname='test.py', lineno=10, msg='first message', args=(),
        exc_info=None, func='testfunc')
    record.name = 'tset'
    record.levelname = 'i'
    record.msg = 'first message'
    record.lineno = 10
    # print(formatter.format(record))




# Generated at 2022-06-12 13:46:58.986492
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import curses
    import colorama
    curses.setupterm()
    if curses.tigetnum("colors") > 0:
        colorama.init()
    formatter = LogFormatter()
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.handlers = []
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.debug("test message")

# Generated at 2022-06-12 13:46:59.958814
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    t = LogFormatter()
    assert t


# Generated at 2022-06-12 13:47:05.122301
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord(
        'test', logging.INFO, '/Users/foo/bar/baz.py',
        100, 'This is a test, %s', ('foo',), None, None)) == \
        "[I 120927 12:05:34 baz:100] This is a test, foo"



# Generated at 2022-06-12 13:47:27.613373
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import time
    import json


# Generated at 2022-06-12 13:47:32.499869
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert hasattr(formatter, "datefmt")
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT



# Generated at 2022-06-12 13:47:42.467511
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import time
    
    tornado.options.enable_parse_known_args()
    tornado.options.define("logging", type=str, help="logging level")
    tornado.options.define("log_to_stderr", type=bool, help="log to stderr")
    tornado.options.define("log_file_prefix", type=str,
                           help="log file name prefix")
    tornado.options.define("log_file_max_size", type=int, default=100*1000*1000,
                           help="max size of log file to roll over")
    tornado.options.define("log_file_num_backups", type=int, default=10,
                           help="number of log files to keep")

# Generated at 2022-06-12 13:47:43.271205
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:47:54.755461
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options = tornado.options.define('logging', type=str, help='type of logging', multiple=False, group='Application')
    tornado.options.options.logging='debug'
    tornado.options.options.log_file_prefix='./test.log'
    tornado.options.options.log_rotate_mode = 'size'
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    tornado.options.options.log_rotate_when = 'midnight'
    tornado.options.options.log_rotate_interval = 1
    logger = logging.getLogger()
    enable_pretty_logging()


# Generated at 2022-06-12 13:47:58.693037
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    This method does not have external calls
    """
    temp_log_formatter = LogFormatter()
    assert temp_log_formatter


# Generated at 2022-06-12 13:48:04.372994
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    TestBase().get_logger("test_enable_pretty_logging")
    test_logger=logging.getLogger("test_enable_pretty_logging")
    test_logger.debug("Start debug test_enable_pretty_logging")
    test_logger.info("Start info test_enable_pretty_logging")
    test_logger.warning("Start warning test_enable_pretty_logging")
    test_logger.error("Start error test_enable_pretty_logging")
    test_logger.critical("Start critical test_enable_pretty_logging")

# Generated at 2022-06-12 13:48:11.543029
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    args = []
    args = ['--log_file_prefix=/tmp/fi', '--log_rotate_mode=size', '--logging=debug']
    import tornado.options
    settings = tornado.options.parse_command_line(args)
    print(settings)
    enable_pretty_logging(settings)
    gen_log.info('test_enable_pretty_logging')

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:48:22.089395
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    print("Unit test for function enable_pretty_logging")
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"
    assert "test" == "test"

# Generated at 2022-06-12 13:48:26.716187
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('root')
    logger.setLevel(logging.INFO)
    formatter = LogFormatter()
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.info('hello,this is a info')



# Generated at 2022-06-12 13:48:46.023561
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class DummyLogRecord(object):
        pass
    record = DummyLogRecord()
    record.levelno = logging.DEBUG
    record.msg = "foo"
    record.args = ()
    record.exc_info = ""
    record.exc_text = ""
    formatter = LogFormatter()
    formatter.format(record)
    formatter.formatTime(record, formatter.datefmt)
    if hasattr(formatter, "_fmt"):
        formatter._fmt
    if hasattr(formatter, "_colors"):
        formatter._colors
    if hasattr(formatter, "_normal"):
        formatter._normal
    if hasattr(formatter, "formatException"):
        formatter.formatException(record)



# Generated at 2022-06-12 13:48:52.342430
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    old_stderr = sys.stderr
    try:
        sys.stderr = open("./output.txt", "w")
        formatter = LogFormatter()
        record = logging.LogRecord("tornado.test", logging.INFO, "./test.py", 10, "Test", [], None)
        record.message = "test"
        assert formatter._normal == ""
        assert len(formatter._colors) == 5
        assert formatter.format(record) == "[I test.py:10] test"
    finally:
        sys.stderr = old_stderr


# Generated at 2022-06-12 13:48:56.658480
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.INFO)
    LogFormatter(fmt="%(levelname)s %(message)s")
    logging.info("test")

MAIL_MAX_RECORDS = 100



# Generated at 2022-06-12 13:49:06.075899
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """Unit test for function enable_pretty_logging"""
    from tornado.options import options

    options.logging = "none"
    enable_pretty_logging(options, access_log)

    options.logging = "debug"
    options.log_file_prefix = "test.log"
    options.log_file_max_size = 1
    options.log_file_num_backups = 3
    options.log_rotate_mode = "size"
    enable_pretty_logging(options, access_log)

    options.log_rotate_mode = "time"
    options.log_rotate_when = "D"
    options.log_rotate_interval = 1
    enable_pretty_logging(options, access_log)

    options.log_rotate_mode = "error"
   

# Generated at 2022-06-12 13:49:15.528272
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define
    from tornado.options import options
    from tornado.escape import json_encode
    define("log_file_prefix", default="log/log")
    define("log_rotate_mode", default="size")
    define("log_file_max_size", default=100)
    define("log_file_num_backups", default=10)
    define("logging", default="None")
    define("log_to_stderr", default="None")
    log_options_dict = {'log_rotate_mode': 'size', 'log_file_prefix': 'log/log', 'log_file_num_backups': 10, 'log_file_max_size': 100, 'logging': 'None', 'log_to_stderr': 'None'}

    enable_pretty_log

# Generated at 2022-06-12 13:49:25.055256
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    define('log_file_prefix', type=str, default='/tmp/tornado_test.log')
    define("logging", default="debug")
    define("log_file_max_size", default=100000)
    define("log_file_num_backups", default=10)
    define("log_to_stderr", default=False)
    parse_command_line()
    enable_pretty_logging()
    gen_log.debug("test")

# Generated at 2022-06-12 13:49:29.558787
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    assert formatter.format(logging.LogRecord("tornado.general", logging.INFO, "foo.py", 42, "hello %s", (), None, None)) == "[I 20070809 09:33:10 foo.py:42] hello %s"


# Generated at 2022-06-12 13:49:40.685842
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import io
    class DummyStream:
        def __init__(self):
            self.io = io.StringIO()
        def write(self, s: str) -> None:
            self.io.write(s)
        def getvalue(self) -> str:
            return self.io.getvalue()

    d = DummyStream()
    logging.basicConfig(stream=d)
    logger = logging.getLogger('tornado.test_LogFormatter')
    logger.setLevel(logging.DEBUG)
    logger.warning('foo')
    actual = d.getvalue()
    assert actual.startswith('[W')
    assert 'foo' in actual
    assert actual.endswith('\n')

# This function is here rather than in logging.py so that tornado.options
# doesn't have a hard

# Generated at 2022-06-12 13:49:43.308354
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()  # type: ignore
    assert isinstance(formatter, LogFormatter)
    assert isinstance(formatter._colors, dict)
    assert isinstance(formatter._normal, str)
    assert isinstance(formatter._fmt, str)
    assert isinstance(formatter.datefmt, str)



# Generated at 2022-06-12 13:49:53.047628
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(
        fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
        datefmt='%y%m%d %H:%M:%S',
        style='%',
        color=True,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        }
    )
    assert isinstance(log_formatter, LogFormatter)

# Logger classes to support configuring logging in `tornado.options`.


# Generated at 2022-06-12 13:50:18.744785
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord(
        name='foo',
        level=logging.CRITICAL,
        pathname='/foo',
        lineno=20,
        msg='foo',
        args=None,
        exc_info=None
    ))
    # => '[C 20 /foo:20] foo'
    # XXX: how to test a rare case LogFormatter().format(...)


# Generated at 2022-06-12 13:50:30.891512
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:50:37.637800
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest.mock as mock

    logger = logging.getLogger("unittest_logger")
    handler = logging.StreamHandler()
    logger.addHandler(handler)

    class Record:
        @staticmethod
        def getMessage():
            raise Exception("error")

    # Patch Record to mock getMessage
    with mock.patch("logging.LogRecord.getMessage", side_effect=Record.getMessage):
        f = LogFormatter()
        try:
            print(f.format(Record()))
        except Exception:
            print("Got Exception")



# Generated at 2022-06-12 13:50:49.772185
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter
    assert type(formatter._fmt) is str
    assert type(formatter._colors) is dict
    assert formatter._colors == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    assert formatter._normal == ""
    # test format
    # This is a test record
    record = logging.LogRecord("name", logging.WARNING, "pathname", 1, "msg", [], None)  # noqa: E501
    assert formatter.format(record) == "[W 010101 00:00:00 pathname:1] This is a test record"

# Generated at 2022-06-12 13:50:51.521569
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    LogFormatter()


# Generated at 2022-06-12 13:50:53.848592
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import gc
    logger = logging.getLogger()
    logFormatter = logging.Formatter()
    logFormatter.format(logger)
    gc.collect()



# Generated at 2022-06-12 13:50:57.422776
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s %(levelname)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


# Generated at 2022-06-12 13:51:04.063221
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger_name='test'
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)

    stream_handler = logging.StreamHandler()
    formatter = LogFormatter()
    stream_handler.setFormatter(formatter)

    logger.addHandler(stream_handler)
    logger.info('log formatter test')



# Generated at 2022-06-12 13:51:09.972371
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # The public _fmt attribute
    assert isinstance(LogFormatter()._fmt, str)

    # The private _colors attribute
    #: Dict[int, str]
    assert isinstance(LogFormatter()._colors, dict)
    #: str
    assert isinstance(LogFormatter()._normal, str)
    #: bool
    assert isinstance(_stderr_supports_color(), bool)


# Generated at 2022-06-12 13:51:21.939737
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers
    import sys
    import inspect

    test_flags = tornado.options.define('test_logging', default=None, type=int, help='test_logging')
    test_flags.add(tornado.options.define('logging', default="none", help='test_logging'))
    test_flags.add(tornado.options.define('log_file_prefix', default="./test_logs/test_logging.log", help='test_logging'))
    test_flags.add(tornado.options.define('log_rotate_mode', default=None, type=str, help='test_logging'))

# Generated at 2022-06-12 13:52:00.490648
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import time
    import unittest
    import datetime
    time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    class TestCase(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_A(self):
            # Create a custom logger
            logger = logging.getLogger(__name__)
            # Create handlers
            c_handler = logging.StreamHandler()
            c_handler.setLevel(logging.DEBUG)
            #f_handler = logging.FileHandler('file.log')
            #f_handler.setLevel(logging.ERROR)
            # Create formatters and add it to handlers

# Generated at 2022-06-12 13:52:02.985034
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._normal == ""



# Generated at 2022-06-12 13:52:08.494415
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f is not None
    f = LogFormatter(fmt="%(color) %(end_color) %(message)")
    assert f is not None
    f = LogFormatter(fmt="%(color) %(end_color) %(message)", colors={0: 2})
    assert f is not None
    f = LogFormatter(fmt="%(color) %(end_color) %(message)", colors={0: 2}, datefmt="%H")
    assert f is not None
    f = LogFormatter(fmt="%(color) %(end_color) %(message)", colors={0: 2}, style="%", datefmt="%H")
    assert f is not None

# Generated at 2022-06-12 13:52:19.339725
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = '%(color)s%(levelname)-8s %(asctime)s %(module)s:%(lineno)d%(end_color)s %(message)s'  # noqa: E501
    datefmt = '%y%m%d %H:%M:%S'
    style = '%'
    color = True
    colors = {
         logging.DEBUG: 4,
         logging.INFO: 2,
         logging.WARNING: 3,
         logging.ERROR: 1,
         logging.CRITICAL: 5,
    }
    formatter = LogFormatter(fmt, datefmt, style, color, colors)

# Generated at 2022-06-12 13:52:28.211910
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Record(object):
        def __init__(self, msg, levelno, exc_info, exc_text):
            self.msg = msg
            self.levelno = levelno
            self.exc_info = exc_info
            self.exc_text = exc_text

        def getMessage(self):
            return self.msg

        @property
        def __dict__(self):
            return {
                "message": "",
                "asctime": "",
                "levelname": "",
                "module": "",
                "lineno": "",
            }

    record = Record(b"abc", logging.INFO, None, None)
    LogFormatter().format(record)
    assert record.message == "abc"


# Generated at 2022-06-12 13:52:39.632155
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class LogRecord(object):
        """A fabricated LogRecord.

        If a real LogRecord had been used, the exc_text would be a unicode
        string, and the message would be a unicode string.  We want to test a
        situation where isinstance(exc_text, bytes) is true.
        """

        def __init__(self) -> None:
            self.message = b"b'\xc3\xbc'"
            self.exc_info = None
            self.exc_text = b"b'\xc3\xbc'"
            self.args = ()
            self.levelname: Optional[str] = None
            self.levelno: Optional[int] = None
            self.pathname = None
            self.filename = None
            self.module = None
            self.lineno = None
            self.func

# Generated at 2022-06-12 13:52:40.620632
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.error("hello world")
    logging.error("test")


test_enable_pretty_logging()

# Generated at 2022-06-12 13:52:42.924344
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmtr = LogFormatter(colors={logging.DEBUG: 4})  # Not using a string typed arg
    assert isinstance(fmtr, LogFormatter)



# Generated at 2022-06-12 13:52:44.554673
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()
    assert isinstance(logFormatter, LogFormatter)


# Generated at 2022-06-12 13:52:47.926783
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass

    # one-time init so that tests that don't use the
    # initialized config logging don't throw errors
    access_log.disabled = True
    app_log.disabled = True
    gen_log.disabled = True



# Generated at 2022-06-12 13:53:38.131845
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    msg1 = "A message"
    logging.basicConfig(level=logging.INFO)
    formater = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, None, 0, msg1, [], None)
    output = formater.format(record)
    print(output)
    assert msg1 in output
    msg2 = "A multilines message\nline2"
    record = logging.LogRecord("tornado.general", logging.INFO, None, 0, msg2, [], None)
    output = formater.format(record)
    print(output)
    assert msg2 in output
    assert output.endswith("    line2")

# The interface to this function is an implementation detail and may
# change without notice.
# pylint: disable=invalid-name


# Generated at 2022-06-12 13:53:41.725131
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('test')
    stream = logging.StreamHandler()
    formatter = LogFormatter()
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    logger.warning('this is a test')
# end test_LogFormatter_format


# Generated at 2022-06-12 13:53:42.636961
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()


# Generated at 2022-06-12 13:53:49.011471
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatters = {
        "foo": {
            "()": LogFormatter,
            "fmt": "%(message)s",
        },
        "bar": {
            "()": LogFormatter,
            "fmt": "%(message)s",
            "datefmt": "%s",
        },
        "baz": {
            "()": LogFormatter,
            "fmt": "%(message)s",
            "datefmt": "%s",
            "color": False,
        },
        "bat": {
            "()": LogFormatter,
            "fmt": "%(message)s",
            "datefmt": "%s",
            "color": True,
            "colors": {"WARNING": 1},
        },
    }



# Generated at 2022-06-12 13:53:54.436517
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import os
    import shutil
    import tempfile
    import tornado.options

    # The tests use the root logger.
    logger = logging.getLogger()
    root_handlers = logger.handlers[:]

    for method in (logger.debug, logger.info, logger.warning, logger.error, logger.critical):
        method("test")


# Generated at 2022-06-12 13:54:04.358912
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    log_formatter = LogFormatter()

    record = logging.LogRecord(
        name="test",
        level=logging.DEBUG,
        pathname="test.py",
        lineno=1,
        msg="this is a test",
        args=(),
        exc_info=None,
    )
    assert log_formatter.format(record) == "this is a test"
    record.msg = "this is a test %r"
    assert log_formatter.format(record) == "this is a test %r"
    record.msg = ""
    record.exc_info = "value"
    assert "Bad message (TypeError" in log_formatter.format(record)
    record.exc_info = None
    record.args = (1,)
    record.exc_

# Generated at 2022-06-12 13:54:06.565500
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = None
    logger = None
    enable_pretty_logging(options,logger)


test_enable_pretty_logging()

# Generated at 2022-06-12 13:54:16.783294
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Foo(object):
        def __getattr__(self, key):
            return lambda: key
    class LogRecord(object):
        def __init__(self, levelno):
            self.levelno = levelno
            self.__dict__["lineno"] = 100
            self.__dict__["module"] = "mymodule"
            self.__dict__["args"] = ("arg1", "arg2")
        def __getattr__(self, key):
            try:
                return self.__dict__[key]
            except KeyError:
                raise AttributeError("unknown attribute %s" % key)
        def getMessage(self):
            return "message"
            #return "message with %d %s" % (self.args)

    formatter = LogFormatter()

# Generated at 2022-06-12 13:54:17.696423
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:54:23.067448
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "/tmp/test.log"
    options.log_rotate_mode = "time"
    options.log_rotate_when = "S"
    options.log_rotate_interval = 1
    options.log_file_num_backups = 5
    enable_pretty_logging(options)