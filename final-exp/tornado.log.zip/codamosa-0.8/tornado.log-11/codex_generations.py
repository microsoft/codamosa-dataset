

# Generated at 2022-06-12 13:46:10.950175
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # call the method under test
    a = LogFormatter()
    b = a.format('record')
    # real test
    assert b == ''

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-12 13:46:21.684873
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    lf = LogFormatter(fmt)
    lf.datefmt = '%y%m%d %H:%M:%S'
    log = logging.getLogger('test')
    log.setLevel(logging.DEBUG)
    msg = 'test asctime and message'
    record = logging.LogRecord(log.name, logging.DEBUG, '', 0, msg, args=None, exc_info=None, func=None)
    assert lf.format(record) == '[D 20190806 16:33:13 test:0] test asctime and message'

# Generated at 2022-06-12 13:46:22.088177
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-12 13:46:33.756132
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()

# Generated at 2022-06-12 13:46:39.810345
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Create a mock options and set logging value to info
    options = mock.Mock()
    options.logging = "info"
    # Create a mock logger
    logger = mock.Mock()
    logger.setLevel.return_value = logging.INFO
    # Call function
    enable_pretty_logging(options, logger)
    # Check the setLevel method was called
    assert logger.setLevel.called

# Test that the enable_pretty_logging method raises an exception when
# the log_rotate_mode is none of the values accepted by this method

# Generated at 2022-06-12 13:46:42.800900
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT
    assert LogFormatter().datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert LogFormatter(fmt="aaa", datefmt="zzz")._fmt == "aaa"
    assert LogFormatter(fmt="aaa", datefmt="zzz").datefmt == "zzz"



# Generated at 2022-06-12 13:46:45.216849
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # TODO: Add unit tests to test_log
    formatter = LogFormatter()
    record = logging.LogRecord(
        'name',
        logging.DEBUG,
        pathname='path',
        lineno=0,
        msg='message',
        args=(),
        exc_info=None,
    )
    assert formatter.format(record)



# Generated at 2022-06-12 13:46:47.275219
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_fmt = LogFormatter()
    assert isinstance(log_fmt, LogFormatter)



# Generated at 2022-06-12 13:46:50.112117
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, object)


# Generated at 2022-06-12 13:46:57.783722
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(datefmt="%y%m%d %H:%M:%S")
    assert isinstance(formatter._fmt, str)
    assert formatter._colors == {}
    assert formatter.datefmt == "%y%m%d %H:%M:%S"

# Default color scheme for our logging
DEFAULT_LOGGING_COLORS = {
    logging.DEBUG: 4,  # Blue
    logging.INFO: 2,  # Green
    logging.WARNING: 3,  # Yellow
    logging.ERROR: 1,  # Red
    logging.CRITICAL: 5,  # Magenta
}



# Generated at 2022-06-12 13:47:21.229040
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter('%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
                                '%y%m%d %H:%M:%S',
                                '%',
                                True,
                                {
                                    logging.DEBUG: 4,  # Blue
                                    logging.INFO: 2,  # Green
                                    logging.WARNING: 3,  # Yellow
                                    logging.ERROR: 1,  # Red
                                    logging.CRITICAL: 5,  # Magenta
                                })
    assert logFormatter is not None


# Generated at 2022-06-12 13:47:23.086089
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter, logging.Formatter)


# Generated at 2022-06-12 13:47:30.164293
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    
    
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    
    from typing import Dict, Any, cast, Optional
    
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")
    
    

# Generated at 2022-06-12 13:47:32.757510
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Record():
        def __init__(self,value):
            (self.asctime,self.levelno,self.message,self.exc_info,self.exc_text) = value
    record = Record(('asctime','levelno','message','exc_info','exc_text'))
    loger = LogFormatter()
    print(loger.format(record))

# Generated at 2022-06-12 13:47:39.001374
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(
        fmt="%(color)s%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d%(end_color)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    assert isinstance(log_formatter, logging.Formatter)



# Generated at 2022-06-12 13:47:43.091518
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(datefmt='%Y-%m-%d %H:%M:%S.%f')
    LogFormatter(fmt='%(message)s')
    LogFormatter(style='$')
    LogFormatter(colors={1:1, 2:2})
    LogFormatter(color=False)


# Generated at 2022-06-12 13:47:48.880887
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "name", logging.INFO, '/path/to/module.py', 1, 'test', None, None
    )
    out = formatter.format(record)
    assert out == "[I 20200929 14:25:30 module:1] test"


# Generated at 2022-06-12 13:47:59.324146
# Unit test for function define_logging_options
def test_define_logging_options():
    # 验证argparse.parse_args()返回值
    from tornado.options import define, options
    define('logging', type=str, help='the python log level')
    define('log_to_stderr', type=bool, default=None, help='send log to stderr')
    define('log_file_prefix', type=str, default=None, help='path prefix for log files')
    define('log_file_max_size', type=int, default=20, help='max size of log files before rollover')
    define('log_file_num_backups', type=int, default=10, help='number of log files to keep')

# Generated at 2022-06-12 13:48:00.937301
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter, logging.Formatter)



# Generated at 2022-06-12 13:48:04.188979
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:48:12.559619
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("", "", "", 1, "hi", (), None, None))


# Generated at 2022-06-12 13:48:22.892094
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # noqa: F811
    class dummy(object):
        pass

    record = dummy()  # type: Any
    record.foo = "bar"
    record.message = "message"
    record.exc_text = "exc_text"
    record.__dict__ = {"foo": "bar"}
    record.__class__.__dict__ = {"foo": "bar"}

    fmt = "%(foo)s\n%(message)s\n%(exc_text)s\n%(__dict__)s\n%(__class__)s"

    formatter = LogFormatter(fmt=fmt, color=False)

    formatted = formatter.format(record=record)

# Generated at 2022-06-12 13:48:33.122383
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(style="%")
    class fakerecord:
        pass
    record = fakerecord()
    # if ``fmt`` is not set, it should use the default
    formatter._fmt = LogFormatter.DEFAULT_FORMAT
    record.method = "GET"
    record.uri = "/nonexist"
    record.version = "HTTP/1.0"
    record.status = "200"
    record.remote_ip = "127.0.0.1"
    record.request_time = 56.0
    record.message = "foo"
    record.end_color = ""
    record.asctime = "asctime"
    record.color = "color"
    record.levelno = logging.INFO
    record.__dict__["lineno"] = 1

# Generated at 2022-06-12 13:48:37.873662
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(fmt="%(color)s:%(end_color)s", datefmt="%y%m%d %H:%M:%S")

# Make the access log a default handler for tornado.access
access_log.addHandler(logging.NullHandler())



# Generated at 2022-06-12 13:48:40.722581
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.format(record=logging.LogRecord(None, None, None, None, None, None, None))



# Generated at 2022-06-12 13:48:50.492070
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_format = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    log_datefmt = "%Y-%m-%d %H:%M:%S"
    log_color = True
    log_colors = {logging.DEBUG: 4,
                  logging.INFO: 2,
                  logging.WARNING: 3,
                  logging.ERROR: 1,
                  logging.CRITICAL: 5,
                  }
    formatter = LogFormatter(fmt=log_format, datefmt=log_datefmt,
                             style="%", color=log_color, colors=log_colors)
    record = logging.LogRecord(
        '__main__', logging.INFO,
        __file__, None, "message", None, None
    )
   

# Generated at 2022-06-12 13:48:53.002952
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    # make sure it builds without errors
    formatter.format(logging.LogRecord("", logging.INFO, "", 0, ""))

# Generated at 2022-06-12 13:49:03.882850
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = MockOptions()
    logger = logging.getLogger()
    enable_pretty_logging(options,logger)
    assert logger.level == logging.DEBUG
    assert logger.handlers[0].__class__.__name__=='RotatingFileHandler'
    assert logger.handlers[0].maxBytes == 4 * 1024 * 1024
    assert logger.handlers[0].backupCount == 10
    assert logger.handlers[0].encoding == "utf-8"
    assert logger.handlers[1].__class__.__name__=='StreamHandler'
    assert logger.handlers[1].formatter.__class__.__name__=='LogFormatter'
    assert logger.handlers[1].formatter.datefmt == '%y%m%d %H:%M:%S'

# Generated at 2022-06-12 13:49:05.210682
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter is not None

# Generated at 2022-06-12 13:49:15.082318
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    lf = LogFormatter()
    class Record:
        pass
    record = Record()

# Generated at 2022-06-12 13:49:23.420090
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.log_file_prefix = None
    tornado.log.enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-12 13:49:29.001587
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define
    # Set up color if we are in a tty and curses is installed
    define("log_file_prefix", type=str, default=None)
    define("log_file_max_size", type=int, default=100 * 2 ** 20)
    define("log_file_num_backups", type=int, default=10)
    define("log_rotate_mode", type=str, default="size")
    define("log_rotate_when", type=str, default="midnight")
    define("log_rotate_interval", type=int, default=1)
    define("log_to_stderr", type=bool, default=None)
    enable_pretty_logging()

# Generated at 2022-06-12 13:49:29.866633
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()


# Generated at 2022-06-12 13:49:38.343456
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = "%(color)s%(levelname)1.1s %(message)s%(end_color)s"
    f = LogFormatter(fmt)
    import logging
    lr = logging.LogRecord('name', logging.ERROR, pathname='path', lineno=1,
                           msg='msg', args=None, exc_info=None)
    assert f.format(lr) == "\x1b[2;31merr msg\x1b[0m"



# Generated at 2022-06-12 13:49:45.594785
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    loggers = [access_log, app_log, gen_log]
    for logger in loggers:
        logger.handlers = []
        handler = logging.StreamHandler(stream=None)
        handler.setFormatter(LogFormatter())
        logger.addHandler(handler)

    for logger in loggers:
        logger.debug("hello")
        logger.warning("warning")
        logger.info("info")
        logger.error("error")


# A singleton LogFormatter instance used by Tornado's default logging setup
# (applied by parse_command_line and parse_config_file).  We disable
# colorization by default on Windows.
# Note that colorization is not automatically enabled on Windows
# just by importing this module; applications must do it explicitly.

# Generated at 2022-06-12 13:49:54.821771
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    # Create a test logger and handler.
    log = logging.getLogger("tornado.test")
    log.setLevel(logging.DEBUG)

    sio = BytesIO()
    handler = logging.StreamHandler(sio)
    # Install the TornadoLogFormatter as the formatter for the handler.
    handler.setFormatter(LogFormatter())
    # Associate the handler with the test logger.
    log.addHandler(handler)

    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")

    out = sio.getvalue()
    assert b"[D" in out
    assert b"[I" in out
    assert b"[W" in out
    assert b"[E" in out

# Generated at 2022-06-12 13:50:05.685080
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test that the logger color code is added
    formatter = LogFormatter()
    record = logging.makeLogRecord({"msg": "foo"})
    colored = formatter.format(record)
    assert colored.startswith(record.color)
    assert colored.endswith(record.end_color)

    # Test that the logger color code is not added
    formatter = LogFormatter(color=False)
    record = logging.makeLogRecord({"msg": "foo"})
    colored = formatter.format(record)
    assert not colored.startswith(record.color)
    assert not colored.endswith(record.end_color)

    # Test that the logger color code is added to logger with exception
    formatter = LogFormatter()

# Generated at 2022-06-12 13:50:13.457006
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.disable(logging.NOTSET)
    options = set_config("test/test_config.conf")
    options.parse_command_line([])
    enable_pretty_logging(options)
    record = logging.makeLogRecord({'msg': 'test'})
    record.name = 'test'
    record.levelno = logging.DEBUG
    access_log.handle(record)
    app_log.handle(record)
    gen_log.handle(record)
    record.levelno = logging.INFO
    access_log.handle(record)
    app_log.handle(record)
    gen_log.handle(record)
    record.levelno = logging.WARNING
    access_log.handle(record)
    app_log.handle(record)
    gen_log.handle(record)

# Generated at 2022-06-12 13:50:17.283724
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if hasattr(logging.StreamHandler, "_formatter"):
        assert isinstance(logging.StreamHandler._formatter, LogFormatter)
        assert isinstance(logging.StreamHandler._formatter, logging.Formatter)



# Generated at 2022-06-12 13:50:29.596165
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    import unittest
    
    def check_log_file(log_file_name):
        import os
        import glob
        import time
        
        assert os.path.isfile(log_file_name)
        
        time.sleep(0.1)
        os.system('touch -t 201103021459.59 '+log_file_name)
        time.sleep(0.1)
        
        os.system('touch -t 201103021459.59 '+log_file_name)
        assert len(glob.glob(log_file_name+"*")) == 1
        
        os.system('touch -t 201103021459.59 '+log_file_name)

# Generated at 2022-06-12 13:50:37.246797
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("Test option not yet implemented")

# Generated at 2022-06-12 13:50:49.227763
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import Options
    options = Options()
    options.logging = "none"
    options.log_file_prefix = None
    logger = logging.getLogger()
    import logging.handlers
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging(options, logger)
    assert len(list(filter(lambda x: isinstance(x, logging.handlers.RotatingFileHandler), logger.handlers))) == 0
    assert len(list(filter(lambda x: isinstance(x, logging.handlers.TimedRotatingFileHandler), logger.handlers))) == 0
    assert len(list(filter(lambda x: isinstance(x, logging.StreamHandler), logger.handlers))) == 1
    options.logging = "debug"

# Generated at 2022-06-12 13:50:57.784964
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fm = LogFormatter(fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s")  # noqa: E501
    for i in range(0, 100):
        import random
        import logging
        record = logging.LogRecord("hello", logging.DEBUG, "/random/filename/", i, random.choice("abcdefghijklmnopqrstuvwxyz"), null, null)  # noqa: E501
        record.exc_text = "exception text"
        fm.format(record)
    


# Generated at 2022-06-12 13:51:09.738867
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import os
    import tornado.options
    import shutil

    class OptionTest(tornado.options.Options):
        define = tornado.options.define
        define("logging", type=str, help="logging")
        define("log_file_prefix", type=str, help="log_file_prefix")
        define("log_rotate_mode", type=str, help="log_rotate_mode")
        define("log_file_max_size", type=int, help="log_file_max_size")
        define("log_file_num_backups", type=int, help="log_file_num_backups")
        define("log_rotate_when", type=str, help="log_rotate_when")

# Generated at 2022-06-12 13:51:21.705258
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    clf_dict = {'format': '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s', 'datefmt': '%y%m%d %H:%M:%S', 'style': '%', 'color': True}
    lf = LogFormatter(**clf_dict)

# Generated at 2022-06-12 13:51:22.253135
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()  # type: ignore

# Generated at 2022-06-12 13:51:24.200104
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.makeLogRecord({"args": ()})
    formatter.format(record)



# Generated at 2022-06-12 13:51:24.799893
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(color=True)



# Generated at 2022-06-12 13:51:27.468962
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.options.logging = "none"
    tornado.log.enable_pretty_logging()
    tornado.options.options.logging = "warn"
    tornado.log.enable_pretty_logging()
# See also test_log.py

# Generated at 2022-06-12 13:51:29.962711
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    from tornado.options import define, options, parse_command_line
    # test default logger
    enable_pretty_logging()

# Generated at 2022-06-12 13:51:43.695079
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter(datefmt="%H:%M:%S")
    record = logging.LogRecord("test", 30, "localhost", 1 , "test_message", None, None)
    assert f.format(record) == "[05:00:30 localhost:1] test_message"



# Generated at 2022-06-12 13:51:45.112711
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    o = LogFormatter()
    # import inspect
    # assert False, inspect.getargspec(o.__init__)

# Generated at 2022-06-12 13:51:49.580352
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    ## Only for coverage
    import tornado.options
    import logging
    import sys
    sys.argv = ["test.py", '--logging=none']
    tornado.options.parse_command_line()
    assert logging.getLogger().level == logging.NOTSET 
    # This will leave the handler in place
    enable_pretty_logging()
    # This will remove and replace it
    enable_pretty_logging()
    assert logging.getLogger().level == logging.INFO

# Generated at 2022-06-12 13:51:56.348973
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.log_file_prefix = "hoge"
    enable_pretty_logging()
    gen_log.info("hoge")
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 1
    enable_pretty_logging()
    gen_log.info("hoge")
    tornado.options.options.log_rotate_mode = "hoge"

# Generated at 2022-06-12 13:51:56.916513
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:52:04.676631
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass


# Utility functions for use by applications built on top of Tornado

# See http://en.wikipedia.org/wiki/ANSI_escape_code#Colors_and_Styles
# and http://pueblo.sourceforge.net/doc/manual/ansi_color_codes.html
# for information about ANSI color codes

# Generated at 2022-06-12 13:52:12.988793
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.stack_context
    import tornado.ioloop

    import logging, sys

    class MockHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            self.records = []
            logging.Handler.__init__(self, *args, **kwargs)
        def emit(self, record):
            self.records.append(record)

    # Remember the log_to_stderr default, and set it back when we're done
    prev_log_to_stderr = tornado.options.options.log_to_stderr
    tornado.options.define("log_to_stderr", type=bool, default=True)

# Generated at 2022-06-12 13:52:24.327569
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    output = LogFormatter(color=False)
    assert not hasattr(output, '_colors'), "_colors should not exist"
    assert not hasattr(output, '_normal'), "_normal should not exist"
    assert not hasattr(output, 'format')

    output = LogFormatter(color=True, colors={}, fmt="%(message)s")
    assert hasattr(output, '_colors'), "_colors should exist"
    assert hasattr(output, '_normal'), "_normal should exist"
    assert isinstance(output._normal, str), "_normal should be a string"
    assert isinstance(output._colors, dict), "_colors should be a dict"
    assert hasattr(output, 'format')

    output = LogFormatter(color=False, colors={}, fmt="%(message)s")

# Generated at 2022-06-12 13:52:29.743605
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print("test_LogFormatter_format")
    logger_msg = "logger_msg"
    exception_type = "exception_type"
    exception_msg = "exception_msg"
    record = logging.LogRecord(
        "name",
        logging.INFO,
        "path",
        100,
        logger_msg,
        None,
        None,
    )
    record.exc_info = (exception_type, exception_msg)
    formatter = LogFormatter()
    formated_msg = formatter.format(record)
    print(formated_msg)



# Generated at 2022-06-12 13:52:41.012566
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.options import define, options
    from pathlib import Path
    from io import StringIO
    import time

    options.log_to_stderr = False
    options.log_file_prefix = Path(__file__).parent.parent / 'tornado' / 'test' / 'data' / 'test_logging.log'  # noqa: E501
    options.logging = "fixed"

    log = logging.getLogger()
    log.addHandler(logging.StreamHandler())
    log.setLevel(logging.DEBUG)
    log.error("This is an error")
    gen_log.error("This is an error")
    print(
        "This is an error"
    )  # this line is not logged in specified log file, since it is not routed via logging module

# Generated at 2022-06-12 13:53:02.456120
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """Test enable_pretty_logging function"""
    enable_pretty_logging(
        {"logging": "INFO", "log_file_prefix": "log", "log_rotate_mode": "size"}, None
    )
    gen_log.info("test_enable_pretty_logging")


if __name__ == "__main__":

    test_enable_pretty_logging()

# Generated at 2022-06-12 13:53:13.785476
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    
    import tornado.log
    import logging
    import logging.config
    import tornado.ioloop
    import time


# Generated at 2022-06-12 13:53:15.046980
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging = enable_pretty_logging()
    assert logging is None

# Generated at 2022-06-12 13:53:17.296597
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  pass

if __name__ == "__main__":
  import tornado.options
  tornado.options.parse_command_line()
  test_enable_pretty_logging()

# Generated at 2022-06-12 13:53:26.989579
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    date_fmt = formatter.datefmt
    msg_fmt = formatter.formatMessage
    class FakeRecord():
        '''
        Verifies that we can add a custom record to the class
        '''
        def __init__(self, record):
            '''
            Constructor
            '''
            self.record = record
        def getMessage(self):
            '''
            Getter for the message in the record
            '''
            return self.record
        def __dict__(self):
            '''
            Returns the string in the record
            '''
            return self.record
    # TODO: add some tests.

# Generated at 2022-06-12 13:53:31.524299
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    consoleHandler = logging.StreamHandler()
    logger.addHandler(consoleHandler)
    logFormatter = LogFormatter()
    consoleHandler.setFormatter(logFormatter)
    logger.info("test")


# Generated at 2022-06-12 13:53:40.761985
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    lf = LogFormatter(fmt, datefmt, style, color, colors)



# Generated at 2022-06-12 13:53:47.975225
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # init
    obj = LogFormatter()
    # call
    record1 = logging.LogRecord('name1', 'level', 'pathname', 'lineno', 'msg', args, 'exc_info')
    retval1 = obj.format(record1)
    record2 = logging.LogRecord('name2', 'level', 'pathname', 'lineno', 'msg', args, 'exc_info')
    record2.exc_info = True
    record2.exc_text = 'exc_text'
    retval2 = obj.format(record2)

    # check
    assert retval1 == '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'

# Generated at 2022-06-12 13:53:50.105491
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(
        logging.LogRecord("tornado.application", logging.DEBUG, "", 0, "msg1", (), None)
    ) == "[D " + "xxxx-xx-xx xx:xx:xx tornado.application:xxx] msg1"

# Generated at 2022-06-12 13:54:00.112905
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "test_log.txt"
    options.log_rotate_mode = "time"
    options.log_rotate_when = "d"
    options.log_rotate_interval = 1
    options.log_file_num_backups = 3
    enable_pretty_logging(options)
    gen_log.debug("test_enable_pretty_logging")
    assert os.path.isfile("test_log.txt")
    os.remove("test_log.txt")
import os
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:54:47.112561
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import options

    options.logging = "warning"
    test_formatter = LogFormatter()
    logging.getLogger("test").setLevel(logging.DEBUG)
    test_logger = logging.getLogger("test")
    test_logger.debug("test debug message")
    logging.error("test error message")
    try:
        raise IndexError("test error 2")
    except IndexError:
        test_logger.error("test error message 2", exc_info=True)
    result = test_formatter.format(test_logger.handlers[0].records[0])
    assert result == "[D 100605 14:56:23 test:1] test debug message"
    result = test_formatter.format(test_logger.handlers[0].records[1])


# Generated at 2022-06-12 13:54:53.249103
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Print the format of formatter.
    fmt = LogFormatter()._fmt
    print(fmt)
    print(fmt.strip() % {"color": "",
                         "end_color": "",
                         "levelname": "LEVELNAME",
                         "asctime": "ASCTIME",
                         "module": "MODULE",
                         "lineno": 1,
                         "message": "MESSAGE"})



# Generated at 2022-06-12 13:55:04.255535
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    d = '0123456789'
    df = d[:2] + ':' + d[2:4] + ':' + d[4:]
    x = LogFormatter(color=True)
    assert 'INFO ' + df + x.end_color + '  - ' == x.format({
        'color': x.color,
        'end_color': x.end_color,
        'levelname': 'INFO',
        'asctime': d,
        'message': '-',
    })
    x = LogFormatter(color=False)

# Generated at 2022-06-12 13:55:14.930028
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("logging", default="debug")
    define("log_file_prefix", default="test_log.txt")
    define("log_rotate_mode", default="time")
    define("log_file_num_backups", default=5)
    define("log_file_max_size", default=10*1024*1024)
    define("log_rotate_when", default="MIDNIGHT")
    define("log_rotate_interval", default=1)
    define("log_to_stderr", default=True)
    print(options.logging)
    print(options.log_file_prefix)
    print(options.log_rotate_mode)
    print(options.log_file_num_backups)

# Generated at 2022-06-12 13:55:24.289591
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import json
    import tornado.log
    from tornado.testing import AsyncTestCase, LogTrapTestCase, gen_test
    from tornado import testing

    tornado.log.logging = cast(Any, testing.mock_logging())
    from tornado.log import app_log

    class TestCase(AsyncTestCase, LogTrapTestCase):
        def setUp(self) -> None:
            super().setUp()
            self.formatter = LogFormatter()
            self.orig_supports_color = tornado.log.supports_color
            tornado.log.supports_color = lambda: True
            self.addCleanup(setattr, tornado.log, "supports_color", self.orig_supports_color)

        @gen_test
        def test_exception(self) -> None:
            app_log

# Generated at 2022-06-12 13:55:25.476778
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # This is only here to get coverage on this class constructor
    LogFormatter()



# Generated at 2022-06-12 13:55:25.998946
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-12 13:55:28.612205
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig()
    enable_pretty_logging()
    logging.getLogger().setLevel(logging.DEBUG)
    gen_log.info('test')

# Generated at 2022-06-12 13:55:36.991528
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    x = datetime.datetime.now() #type: ignore
    msg = 'Hello world'
    print(LogFormatter().format(logging.LogRecord('name', logging.ERROR, '', '', msg, None, None)))
    print(LogFormatter().format(logging.LogRecord('name', logging.INFO, '', '', msg, None, None)))
    print(LogFormatter().format(logging.LogRecord('name', logging.WARNING, '', '', msg, None, None)))
    print(LogFormatter().format(logging.LogRecord('name', logging.CRITICAL, '', '', msg, None, None)))
    print(LogFormatter().format(logging.LogRecord('name', logging.DEBUG, '', '', msg, None, None)))

# Generated at 2022-06-12 13:55:45.241352
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("log_file_prefix", default='~/logs/tornado.log', help='Path prefix for log files')
    define("log_to_stderr", default=True, help='Send log output to stderr instead of files')
    define('log_rotate_mode', default='time', help='time or size')
    define('log_rotate_when', default='midnight', help='midnight or s')
    define('log_rotate_interval', default=1, help='1')
    define('log_file_num_backups', default=10, help='10')
    define('log_file_max_size', default=1024 * 1024 * 128, help='Max size of log files before rollover')

    enable_pretty_logging()