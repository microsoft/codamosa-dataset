

# Generated at 2022-06-12 13:46:10.275143
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
        formatのテスト
    """
    class FakeRecord(object):
        def __init__(self):
            self.__dict__ = {"message": "test_message","asctime": "asctime", "levelno": logging.INFO,
                        "color": "color", "end_color": "end_color", "exc_info": "exc_info",
                        "exc_text": "exc_text"}
    class AvoidException(LogFormatter):
        def __init__(self):
            pass
    test_log_formatter = AvoidException()
    test_log_formatter.format(FakeRecord())
    print("test_LogFormatter_format: OK")



# Generated at 2022-06-12 13:46:11.572472
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter.format("hello", "world") == "hello"



# Generated at 2022-06-12 13:46:20.441970
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter: LogFormatter = LogFormatter()
    record = logging.LogRecord('tornado.access', logging.INFO, __file__, 42, 'hello', [], None)
    record_str = formatter.format(record)
    assert 'hello' in record_str
    assert 'INFO' in record_str

    record = logging.LogRecord('tornado.application', logging.ERROR, __file__, 42, 'hello', [], None)
    record_str = formatter.format(record)
    assert 'hello' in record_str
    assert 'ERROR' in record_str


# Generated at 2022-06-12 13:46:27.933168
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    # examine if all options can be accepted.
    tornado.options.parse_command_line("--logging=debug".split())
    tornado.options.define("log_file_prefix", "a", str)
    tornado.options.define("log_rotate_mode", "size", str)
    tornado.options.define("log_file_max_size", 1, int)
    tornado.options.define("log_file_num_backups", 2, int)
    tornado.options.define("log_rotate_when", "midnight", str)
    tornado.options.define("log_rotate_interval", 1, int)
    tornado.options.define("log_to_stderr", True, bool)
    enable_pretty_logging()

# Generated at 2022-06-12 13:46:34.246688
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.options.log_file_prefix = "logfile.txt"
    tornado.options.options.log_file_num_backups = 0
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_rotate_interval = 1
    enable_pretty_logging(tornado.options.options)
    logging.warning("warning msg")

# Generated at 2022-06-12 13:46:41.634793
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing

    class BaseLoggingTest(tornado.testing.LogTrapTestCase):
        # required by LogTrapTestCase
        def setUp(self):
            super(BaseLoggingTest, self).setUp()

    # Note that the following tests merely exercise the code path,
    # they do not test output.

    class NoneLoggingTest(BaseLoggingTest):
        def test_none(self):
            tornado.options.define("logging", default=None, help=None)
            tornado.options.parse_command_line(["--logging=none"])
            self.assertFalse(logging.getLogger().handlers)


# Generated at 2022-06-12 13:46:51.627926
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options
    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "./tornado.log"
    options.log_rotate_mode = "size"
    options.log_to_stderr = None
    options.log_file_max_size = 1024
    options.log_file_num_backups = 10
    enable_pretty_logging(options)
    access_log.debug("Tornado debug log")
    app_log.info("Tornado info log")
    gen_log.warning("Tornado warning log")
    gen_log.error("Tornado error log")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:46:55.137118
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(logger = access_log)
    enable_pretty_logging(logger = app_log)
    enable_pretty_logging(logger = gen_log)

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:47:02.092785
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("logging", None, str)
    tornado.options.define("log_rotate_mode", "size", str)
    tornado.options.define(
        "log_file_prefix",
        None,
        str,
        "Path prefix for log files. "
        "Note that if you are running multiple tornado processes, "
        "log_file_prefix must be different for each of them (e.g. "
        "include the port number)",
    )
    tornado.options.define("log_file_max_size", 100000000, int)
    tornado.options.define("log_file_num_backups", 10, int)
    tornado.options.define("log_to_stderr", True, bool)

# Generated at 2022-06-12 13:47:10.206367
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = 'debug'
    tornado.options.options.log_file_prefix = 'log.txt'
    tornado.options.options.log_rotate_mode = 'time'
    tornado.options.options.log_rotate_when = 'midnight'
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-12 13:47:37.306069
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)
    record = logging.LogRecord("test", logging.DEBUG, "", 0, "", None, None)
    assert formatter.format(record).endswith("test\033[0m")



# Generated at 2022-06-12 13:47:41.208260
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger("test")
    logger.setLevel(logging.INFO)
    log_handler = logging.StreamHandler()
    log_handler.formatter = LogFormatter()
    logger.addHandler(log_handler)
    logger.info("test")


# Generated at 2022-06-12 13:47:42.116431
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  assert enable_pretty_logging() == None

# Generated at 2022-06-12 13:47:44.652948
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(color=True, datefmt="%H:%M:%S")
    assert log_formatter._colors
    assert log_formatter._normal

test_LogFormatter()


# Generated at 2022-06-12 13:47:54.752115
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG,
                        format='%(name)s [%(levelname)s] %(message)s',
                        filename='test_LogFormatter_format.log',
                        filemode='w')

    # define a Handler
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    # set a format which is simpler for console use

# Generated at 2022-06-12 13:48:02.627511
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()  # make sure there are handlers
    root_logger = logging.getLogger()
    stream_handler = logging.StreamHandler()
    root_logger.addHandler(stream_handler)

    formatter = LogFormatter()
    stream_handler.setFormatter(formatter)

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    logger.debug("foo")
    logger.info("foo")
    logger.warning("foo")
    logger.error("foo")
    logger.critical("foo")



# Generated at 2022-06-12 13:48:14.322253
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    import sys
    import unittest
    import random

    msg = "Soporific!"

    # Set up our logging formatters
    formatter = LogFormatter()
    stream = sys.stderr

    # Set up our logging levels
    levels = []
    levels.append(logging.DEBUG)
    levels.append(logging.INFO)
    levels.append(logging.WARNING)
    levels.append(logging.ERROR)
    levels.append(logging.CRITICAL)

    # Test each of our logging levels
    for level in levels:
        record = logging.LogRecord(name="foo", level=level, pathname=None, lineno=0, msg=msg, args=None, exc_info=None)
        record.name = "foo"
        record.msg

# Generated at 2022-06-12 13:48:18.123150
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(color=True)  # 确保构造函数能成功执行


# Prevent the access log from being buffered.
#
# Access logs may contain sensitive information (user names and passwords)
# and we don't want to risk losing this information if the process crashes
# or is killed abruptly.

# Generated at 2022-06-12 13:48:19.209390
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-12 13:48:22.072457
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord("", 0, __file__, 0, "", (), None, None)).endswith('\n') # noqa: E501



# Generated at 2022-06-12 13:49:14.294170
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("logging", type=str)
    # tornado.options.define("log_file_prefix", type=str)
    # tornado.options.define("log_rotate_mode", type=str)
    # tornado.options.define("log_file_max_size", type=int)
    # tornado.options.define("log_file_num_backups", type=int)
    # tornado.options.define("log_rotate_when", type=str)
    # tornado.options.define("log_rotate_interval", type=int)
    # tornado.options.define("log_to_stderr", type=str)

    enable_pretty_logging(options=None, logger=None)

# Generated at 2022-06-12 13:49:22.201640
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    a = LogFormatter(datefmt='%y%m%d %H:%M:%S', fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s')
    b = logging.Formatter(datefmt='%y%m%d %H:%M:%S')
    c = logging.Formatter()


# Generated at 2022-06-12 13:49:30.901913
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter()
    # test record has no color attribute
    record = logging.LogRecord("name", logging.INFO, __file__, 10,
            "message", None, None)
    assert logFormatter.format(record) == "[I 000101 0:00:00 test_log.py:10] message"

    # test record has color attribute
    record.color = "color"
    record.end_color = "reset color"
    assert logFormatter.format(record) == "[I 000101 0:00:00 test_log.py:10] message"


# Generated at 2022-06-12 13:49:39.284663
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define, parse_config_file, parse_command_line

    options=options
    define=define
    parse_config_file=parse_config_file
    parse_command_line=parse_command_line
    define("logging", default="none", help="logging level")
    define("logging1", default="none", help="logging level")
    parse_config_file("config_file")
    enable_pretty_logging()
    parse_command_line()
    print("hi")

# Generated at 2022-06-12 13:49:46.156062
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import mock
    import logging.handlers
    import tornado.options
    import unittest

    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "/tmp/foo.log"
    options.log_rotate_mode = "time"
    options.log_rotate_when = "D"
    options.log_rotate_interval = 1
    options.log_file_num_backups = 5
    logger = mock.Mock(spec=logging.Logger)
    with mock.patch.object(
        logging.handlers.TimedRotatingFileHandler, "__init__"
    ) as mock_handler:
        enable_pretty_logging(options, logger)

# Generated at 2022-06-12 13:49:46.715746
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass



# Generated at 2022-06-12 13:49:56.200412
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest
    from tornado.options import options as opt, define, Error

    # test an invalid log_rotate_mode value
    define("log_rotate_mode", None, str)
    define("log_file_prefix", None, str)
    define("log_file_max_size", None, int)
    define("log_file_num_backups", None, int)
    define("log_rotate_when", None, str)
    define("log_rotate_interval", None, int)
    define("log_to_stderr", None, bool)
    opt.logging = "error"


# Generated at 2022-06-12 13:50:04.521406
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import pytest
    with pytest.raises(TypeError, match='__init__'):
        log_fmt = LogFormatter()
    log_fmt = LogFormatter(color=True)
    assert isinstance(log_fmt, LogFormatter)
    assert log_fmt._colors[logging.CRITICAL] == "\x1b[2;35m"
    assert log_fmt._normal == "\x1b[0m"
    log_fmt = LogFormatter(color=False)
    assert log_fmt._colors == {}



# Generated at 2022-06-12 13:50:12.464846
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    import sys
    import unittest
    
    class LogFormatterTestCase(unittest.TestCase):
      def test_LogFormatter(self):
          logger = logging.getLogger()
          logger.handlers = []
          stream = io.StringIO()
          logger.addHandler(logging.StreamHandler(stream))
          logger.setLevel(logging.DEBUG)
          formatter = LogFormatter()
          handler = logging.StreamHandler()
          handler.setFormatter(formatter)
          logger.addHandler(handler)
        
          logger.info('info message')
          value = stream.getvalue()
          newvalue = "info message\n"
          self.assertEqual(str(value), newvalue)
    
    if __name__ == '__main__':
        unittest

# Generated at 2022-06-12 13:50:20.492943
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig()
    f = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "filename", 0, "Message", [], None)
    record.exc_info = "Exception"
    f.format(record)
    record.levelname = 'WARNING'
    f.format(record)
    record.levelname = 'ERROR'
    f.format(record)
    record.levelname = 'CRITICAL'
    f.format(record)


# Generated at 2022-06-12 13:50:54.196684
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Record:
        def __init__(self, levelno: int = logging.INFO, message: str = ""):
            self.levelno = levelno
            self.exc_text = ""
            self.message = message
    record = Record()
    formatter = LogFormatter()
    formatter.format(record)
    record = Record(logging.WARNING, "")
    formatter.format(record)
    record = Record(logging.ERROR, "")
    formatter.format(record)
    record = Record(logging.CRITICAL, "")
    formatter.format(record)



# Generated at 2022-06-12 13:50:56.377873
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore

    a = LogFormatter()
    b = LogFormatter("%(message)s")

# Generated at 2022-06-12 13:51:07.927387
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    with open('test_log.txt', 'w') as f:
        f.write('test')
        test_logging_options = type('logging_options', (object,), {})
        test_logging_options.logging = 'DEBUG'
        test_logging_options.log_to_stderr = True
        test_logging_options.log_file_prefix = 'test_log.txt'
        test_logging_options.log_rotate_mode = 'time'
        test_logging_options.log_rotate_when = 'midnight'
        test_logging_options.log_rotate_interval = 1
        test_logging_options.log_file_max_size = 100
        test_logging_options.log_file_num_backups = 10
        enable_

# Generated at 2022-06-12 13:51:13.051724
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f._colors  # pylint: disable=protected-access
    assert f._fmt  # pylint: disable=protected-access
    assert f._normal  # pylint: disable=protected-access
    f = LogFormatter(datefmt="%A %m %d %H:%M:%S %Y")
    assert f.datefmt == "%A %m %d %H:%M:%S %Y"



# Generated at 2022-06-12 13:51:14.105963
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()

# Generated at 2022-06-12 13:51:21.048804
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.logging = "warning"
    options.log_file_prefix = "log/x"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 10
    options.log_file_num_backups = 2
    options.log_to_stderr = True

    enable_pretty_logging()


test_enable_pretty_logging()

# Generated at 2022-06-12 13:51:28.220443
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import sys
    import tornado.gen
    import tornado.ioloop
    import tornado.web
    from tornado.options import options, define, parse_command_line

    define("port", default=8888, help="run on the given port", type=int)
    define("logging", default="debug", help="run on the given port", type=str)
    define("log_file_prefix", default="log.txt", help="run on the given port", type=str)
    define("log_rotate_mode", default="time", help="run on the given port", type=str)
    define("log_rotate_when", default="M", help="run on the given port", type=str)
    define("log_rotate_interval", default=1, help="run on the given port", type=int)

# Generated at 2022-06-12 13:51:38.500009
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    import tornado
    import sys
    import tornado.escape
    import tornado.util
    import os
    # Enable pretty logging
    tornado.options.logging = 'debug'
    tornado.options.log_file_prefix = 'tornado.log'
    tornado.options.log_file_max_size = 1000000
    tornado.options.log_rotate_mode = 'size'
    tornado.options.log_file_num_backups = 2
    tornado.options.log_to_stderr = True
    tornado.enable_pretty_logging()

    # Write log
    gen_log.info('gen_log info')
    app_log.info('app_log info')
    access_log.info('access_log info')

    # Check rotate

# Generated at 2022-06-12 13:51:40.967238
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _ = LogFormatter(
        color=False, fmt="%(foo)s", datefmt="%h", colors={0: 0}, style="%"
    )



# Generated at 2022-06-12 13:51:46.778387
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options as opts
    from tornado.options import OptionParser
    from logging import DEBUG, INFO, WARNING
    define("logging", "info", help="test_define_logging_options")
    assert opts.logging == "info", "test_define_logging_options fail"
    define("log_to_stderr", False, help="test_define_logging_options")
    assert opts.log_to_stderr is False, "test_define_logging_options fail"
    opts.logging = "warning"
    opts.log_to_stderr = True
    enable_pretty_logging(opts)
    assert opts.log_to_stderr is True, "test_define_logging_options fail"
    assert opts.logging

# Generated at 2022-06-12 13:53:01.014172
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    record = logging.LogRecord("name", logging.ERROR, None, 0, "message", [], None)
    assert formatter.format(record)

    formatter = LogFormatter(color=False)
    record = logging.LogRecord("name", logging.ERROR, None, 0, "message", [], None)
    assert formatter.format(record)

    # Test that the end of the line is cleared.
    formatter = LogFormatter(color=True)
    record = logging.LogRecord("name", logging.ERROR, None, 0, "message", [], None)
    line = formatter.format(record)
    if line[-1] == "\n":
        line = line[:-1]
    assert line.endswith(formatter._normal)



# Generated at 2022-06-12 13:53:13.155922
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class MockLogRecord:
        pass

    mock_record = MockLogRecord()
    mock_record.__dict__ = {
        "color": [],
        "end_color": [],
        "message": "test message",
        "levelno": logging.INFO,
        "asctime": "2016-12-19 20:55:31",
        "module": "test",
        "lineno": 1,
        "levelname": "INFO",
        "exc_info": None,
        "exc_text": None,
    }
    formatter = LogFormatter(color=True)
    format_result = formatter.format(mock_record)
    assert format_result == "[I 20161219 20:55:31 test:1] test message"


# Generated at 2022-06-12 13:53:13.818923
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:53:14.219505
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()

# Generated at 2022-06-12 13:53:21.234791
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    format = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = '%y%m%d %H:%M:%S'
    style = '%'
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    record = logging.getLogger("tornado.general")
    record.levelno = logging.DEBUG
    record.getMessage = lambda: "message"


# Generated at 2022-06-12 13:53:27.316991
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    assert f.format("a") == "    a"
    assert f.format("a\n") == "a\n"
    assert f.format("a") == "    a"
    assert f.format("a") == "    a"
    try:
        raise ValueError("a")
    except:
        assert f.format("a") == "a"
        assert f.format("a\n") == "a\n"



# Generated at 2022-06-12 13:53:29.923995
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    obj = LogFormatter("[%(levelname)s %(asctime)s %(module)s:%(lineno)d] %(message)s")
    #obj.format("...")


# Generated at 2022-06-12 13:53:32.200706
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT



# Generated at 2022-06-12 13:53:33.360426
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-12 13:53:42.969198
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tempfile
    temp_dir = tempfile.gettempdir()
    test_log_file_prefix = temp_dir + '/tornado_test.log'
    # test logging option
    tornado.options.define(
        'logging',
        default='warning',
        type=str,
        help=('Set the Python log level. If '
              '"none", tornado won\'t touch the logging configuration.')
    )
    # test log_file_prefix option