

# Generated at 2022-06-12 13:46:04.035163
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    assert logging.getLogger().getLevel() == logging.DEBUG

# Generated at 2022-06-12 13:46:11.935066
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import io
    import sys
    import tempfile
    import unittest
    from typing import Any, Union, TextIO
    from unittest.mock import patch
    from tornado.log import LogFormatter, access_log, gen_log, app_log, _stderr_supports_color  # noqa: E501
    from tornado.options import define, options

    define('logging', default=None)
    define('log_to_stderr', default=None)
    define('log_file_prefix', default=None)
    define('log_file_max_size', default=None)
    define('log_file_num_backups', default=None)
    define('log_rotate_mode', default=None)
    define('log_rotate_when', default=None)

# Generated at 2022-06-12 13:46:18.465552
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord(
        name="test", level=logging.DEBUG, pathname="test.py", lineno=3,
        msg="test message", args=None, exc_info=None
    )

    formatter = LogFormatter()
    assert formatter.format(record) == "[D 161011 23:13 test:3] test message"

# Generated at 2022-06-12 13:46:26.774493
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    define("log_file_prefix")
    define("log_rotate_mode")
    define("log_file_max_size")
    define("log_file_num_backups")
    define("log_rotate_when")
    define("log_rotate_interval")
    define("logging", type=str, default='none')
    define("log_to_stderr", type=bool, default=None)
    logging.getLogger().handlers=[]
    def testcase1():
        options.log_file_prefix = None
        options.logging = 'DEBUG'
        enable_pretty_logging()
        assert logging.getLogger().level == 10
        assert len(logging.getLogger().handlers) == 1
       

# Generated at 2022-06-12 13:46:35.584942
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG)
    stream = logging.StreamHandler()
    stream_formatter = LogFormatter()
    stream.setFormatter(stream_formatter)
    logging.getLogger().addHandler(stream)
    access_log.debug('Access: %s', 'some access info')
    app_log.debug('Application: %s', 'some application info')
    gen_log.debug('General: %s', 'some general info')
    access_log.debug('Access: %s', 'some access info')
    app_log.debug('Application: %s', 'some application info')
    gen_log.debug('General: %s', 'some general info')
    access_log.debug('Access: %s', 'some access info')

# Generated at 2022-06-12 13:46:39.411265
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    expected = "[0 0] "
    assert str(expected) == f.format(logging.LogRecord("name", logging.INFO, "pathname", 10, "msg", (), None))


# Generated at 2022-06-12 13:46:40.402019
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-12 13:46:50.921152
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    # Ignore
    tornado.options.options.logging = "none"
    enable_pretty_logging()
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    tornado.options.options.log_file_prefix = "tt"
    enable_pretty_logging()
    tornado.options.options.logging = "none"
    enable_pretty_logging()
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    tornado.options.options.log_file_prefix = "tt"
    enable_pretty_logging()
    tornado.options.options.log_rotate_mode = "time"
    enable_pretty_logging()
    tornado.options.options.log_rotate_when = "D"


# Generated at 2022-06-12 13:46:59.593980
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    import logging
    import tornado.escape
    import tornado.log
    import unittest
    class LogFormatterTestCase(unittest.TestCase):
        def setUp(self):
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
        def tearDown(self):
            self.handler.close()
        def test_format(self):
            # Add a message and check the output.
            record = LogFormatterTestCase.create_record(
                "message", logging.WARNING, "module", "func", 10
            )
            self.handler.handle(record)
            self.assertEqual(self.stream.getvalue(), "message\n")

# Generated at 2022-06-12 13:47:03.222872
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    import logging
    record = logging.makeLogRecord({})
    record.message = 'test'
    record.levelno = 10
    log_formatter.format(record)


# Generated at 2022-06-12 13:47:11.917998
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert isinstance(LogFormatter().format(logging.LogRecord("foo", 1, "foo.py", 10, "hi", None, None)), str)


# Generated at 2022-06-12 13:47:16.986227
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord('tornado.general', logging.DEBUG, 'test_file', 
        4, 'log message', (), None)

    result = formatter.format(record)
    assert result == "[D test_file:4] log message"


# Generated at 2022-06-12 13:47:24.241308
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options=tornado.options.options
    options.logging = "none"
    options.log_file_prefix = ""
    options.log_file_max_size = ""
    options.log_file_num_backups = ""
    options.log_rotate_mode = ""
    options.log_rotate_when = ""
    options.log_rotate_interval = ""
    options.log_to_stderr = ""
    logger=logging.getLogger()
    enable_pretty_logging(options, logger)

# Generated at 2022-06-12 13:47:27.509507
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.debug('Unit test for function enable_pretty_logging')
    sys.argv.extend(['--logging=debug', '--log_to_stderr'])
    enable_pretty_logging()
    logging.debug('Unit test for function enable_pretty_logging')


# Generated at 2022-06-12 13:47:28.915951
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:47:39.469904
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # fmt: off
    import logging
    import logging.handlers
    import sys
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    # Initialization with colorama
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(logging.WARNING)
    handler.setFormatter(LogFormatter())
    logger.handlers=[]
    logger.addHandler(handler)
    # Logging test
    logger.debug("test %s %s %s", "python", "hello", "world")
    logger.critical("test %s %s %s", "python", "hello", "world", exc_info=True)
    # fmt: on
    # Initialization without colorama
    handler = logging.StreamHandler(sys.stderr)

# Generated at 2022-06-12 13:47:46.944659
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    a = LogFormatter(color=False)
    logging.root.handlers = []
    logging.basicConfig(datefmt="%H:%M:%S", format="%(message)s")
    log = logging.getLogger("")
    for h in log.handlers:
        log.removeHandler(h)  # type: ignore

    h = logging.StreamHandler()
    h.setFormatter(a)
    log.addHandler(h)
    log.setLevel(logging.DEBUG)

    log.debug("msg")
    log.info("msg")
    log.warning("msg")
    log.error("msg")
    log.critical("msg")

    # warnings

# Generated at 2022-06-12 13:47:56.230216
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    fullName = os.path.dirname(os.path.abspath(__file__)) + '/temp/logtest.txt'
    if os.path.exists(fullName):
        os.remove(fullName)
    class MyArgumentParser(tornado.options.ArgumentParser):
        def __init__(self, params: str = '') -> None:
            super(MyArgumentParser, self).__init__()
            self.params = params
        def error(self, message: str) -> None:
            print(message)

# Generated at 2022-06-12 13:48:05.501685
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    lf = LogFormatter()
    test_str = '"%(name)s" %(levelno)s %(message)s'
    record = logging.LogRecord(name="test", levelno=1, pathname="", lineno=1,
                               msg="hello %s", args=("world",), exc_info=None)
    # Test format exception
    frm_record = lf.format(record)
    assert frm_record.replace("\n", "\n    ") == '"test" 1 hello %s'
    # Test format with color
    lf = LogFormatter(color=True)
    frm_record = lf.format(record)
    assert frm_record.replace("\n", "\n    ") == '"test" 1 hello %s'



# Generated at 2022-06-12 13:48:11.116618
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #Create a record
    record = logging.LogRecord("name","INFO","path",1,"msg",[],None)
    #Get the message as string
    print(record)
    #Test the format()
    logformatter = LogFormatter()
    print(logformatter.format(record))

# A logging handler that writes formatted logging records to a stream.

# Generated at 2022-06-12 13:48:29.189489
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter("","")

options = {}  # type: Dict[str, Any]


# Generated at 2022-06-12 13:48:31.242426
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    """Unit test for constructor of class LogFormatter"""
    assert LogFormatter()._normal == ""



# Generated at 2022-06-12 13:48:39.074835
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define, parse_config_file

    define("log_to_stderr", type=bool)
    define("log_file_prefix", type=str)
    define("log_file_max_size", type=int)
    define("log_file_num_backups", type=int)
    define("log_rotate_mode", type=str)
    define("log_rotate_when", type=str)
    define("log_rotate_interval", type=int)
    parse_config_file("file.cfg")
    assert options.log_to_stderr is True
    assert options.log_file_prefix == "file.cfg"
    assert options.log_file_max_size == 1234
    assert options.log_file_num_backups == 1

# Generated at 2022-06-12 13:48:48.637867
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter: LogFormatter
    formatter = LogFormatter(colors={logging.DEBUG: 4})
    assert isinstance(formatter._colors[logging.DEBUG], str)
    assert formatter._colors[logging.DEBUG] == "\x1b[2;3%dm" % 4
    assert isinstance(formatter._normal, str)
    assert formatter._normal == "\x1b[0m"
    assert isinstance(formatter._fmt, str)
    assert formatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501



# Generated at 2022-06-12 13:48:51.425802
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.logging = "debug"
    enable_pretty_logging(options)
    logger = logging.getLogger()
    logger.debug("data")
    logger.info("data")
    logger.warning("data")
    logger.error("data")
    logger.critical("data")


# Generated at 2022-06-12 13:49:02.587693
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    import tornado.testing
    import os
    import shutil
    import tempfile
    import time
    tornadotests = os.path.dirname(tornado.testing.__file__)
    # In python 2.x, unittest.TestCase.assertRegexpMatches is
    # assertRegexpMatches, not assertRegex.  Sigh.
    try:
        assertRegex = tornado.testing.TestCase.assertRegexpMatches
    except AttributeError:
        assertRegex = tornado.testing.TestCase.assertRegex
    class LogTest(tornado.testing.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 13:49:04.001102
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print(enable_pretty_logging.__doc__)

# Generated at 2022-06-12 13:49:11.845313
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if not _stderr_supports_color():
        return
    logging.root.handlers[0].setFormatter(LogFormatter())
    # Test debug
    logging.debug("DEBUG")
    # Test info
    logging.info("INFO")
    # Test warning
    logging.warning("WARNING")
    # Test error
    logging.error("ERROR")
    # Test critical
    logging.critical("CRITICAL")
    # Test an exception
    try:
        1 / 0
    except ZeroDivisionError:
        logging.exception("ZERO DIVISION")



# Generated at 2022-06-12 13:49:13.060529
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("python", default=1)
    enable_pretty_logging(options, logger=None)
    pass


# Generated at 2022-06-12 13:49:17.129720
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True, fmt="%(message)s")
    record = logging.makeLogRecord({'msg': 'foo', 'levelno': logging.INFO})
    assert formatter.format(record) == "\033[2;32mfoo\033[0m"
    record = logging.makeLogRecord({'msg': 'foo', 'levelno': logging.WARNING})
    assert formatter.format(record) == "\033[2;33mfoo\033[0m"
    record = logging.makeLogRecord({'msg': 'foo', 'levelno': logging.ERROR})
    assert formatter.format(record) == "\033[2;31mfoo\033[0m"
    record = logging.makeLogRecord({'msg': 'foo', 'levelno': logging.CRITICAL})

# Generated at 2022-06-12 13:50:00.371535
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Dummy arguments for exportability
    formatter = LogFormatter()
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT

#
# Set up color if we are in a tty and curses is installed
#

if (
    _stderr_supports_color()
    and curses
    and hasattr(sys.stderr, "isatty")
    and sys.stderr.isatty()
):
    # If curses is installed, use it to color the warnings.
    # Otherwise they'll just be plain.
    _formatter = LogFormatter()

# Generated at 2022-06-12 13:50:03.624715
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options
    options = tornado.options.parse_command_line
    tornado.options.parse_config_file()


# Generated at 2022-06-12 13:50:06.476513
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(colors={
        logging.DEBUG: 2,
        logging.INFO: 3,
        logging.WARNING: 4,
        logging.ERROR: 5,
        logging.CRITICAL: 6,
    })


# Generated at 2022-06-12 13:50:13.934261
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test the function enable_pretty_logging
    import tornado.options
    tornado.options.options.logging = None
    enable_pretty_logging(options=tornado.options.options)
    tornado.options.options.logging = "WARNING"
    enable_pretty_logging(options=tornado.options.options)
    tornado.options.options.log_rotate_mode = "size"
    enable_pretty_logging(options=tornado.options.options)
    tornado.options.options.log_rotate_mode = "time"
    enable_pretty_logging(options=tornado.options.options)
    tornado.options.options.log_rotate_mode = "notsizeortime"

# Generated at 2022-06-12 13:50:14.946750
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()



# Generated at 2022-06-12 13:50:27.666643
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

# Generated at 2022-06-12 13:50:33.597802
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    msg = "this is an info message"
    record = logging.LogRecord( "name", logging.INFO, None, None, msg, None, None )
    assert formatter.format( record ) == msg

# Replaces the default formatter with a colored version
# that has been available since Tornado 4.1: for comparison purposes, the old formatter
# showed escaped control characters and the new one doesn't.

# Generated at 2022-06-12 13:50:40.354397
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    Below uses the same logic as unit test in the tornado
    """
    # Test the default format
    lf = LogFormatter()
    now = datetime.datetime.utcnow()
    record = logging.LogRecord(
        "test",
        logging.DEBUG,
        "c:\\test\\file.py",
        1,
        "test message",
        None,
        None,
        None,
        None,
    )
    record.asctime = now
    record.created = now.timestamp()
    expected = "[D {0} test:1] test message".format(
        now.strftime(lf.DEFAULT_DATE_FORMAT)
    )
    assert lf.format(record) == expected

# Generated at 2022-06-12 13:50:43.345823
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass # TODO: write a unit test for function enable_pretty_logging


_defaults = dict(
    log_file_prefix=None,
    log_to_stderr=None,
    log_rotate_mode="size",
    log_rotate_when="midnight",
    log_rotate_interval=1,
    log_file_num_backups=10,
    log_file_max_size=1024 * 1024 * 100,
)



# Generated at 2022-06-12 13:50:52.552350
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging ="error"
    tornado.options.options.log_file_prefix="/tmp/test.log"
    tornado.options.options.log_rotate_mode="size"
    tornado.options.options.log_file_max_size=1024
    tornado.options.options.log_file_num_backups=1
    tornado.options.options.log_rotate_when="D"
    tornado.options.options.log_rotate_interval=1
    tornado.options.options.log_to_stderr=False
    enable_pretty_logging()
    gen_log.debug("test tiger")

# Generated at 2022-06-12 13:52:27.946499
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()


# Generated at 2022-06-12 13:52:38.898725
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()
    assert LogFormatter(style="%")
    assert LogFormatter(style="{")
    assert LogFormatter(fmt="%(color)s%(levelname)s%(end_color)s %(message)s")
    assert LogFormatter(datefmt="%Y-%m-%d %H:%M:%S")
    assert LogFormatter(color=True)
    assert LogFormatter(color=False)
    assert LogFormatter(colors={
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    })



# Generated at 2022-06-12 13:52:40.386437
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert isinstance(LogFormatter(), LogFormatter)


# Generated at 2022-06-12 13:52:47.835934
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    from io import StringIO
    import unittest
    import logging
    import os

    define("logging", default=None, type=str)
    define("log_to_stderr", default=None, type=bool)
    define("log_file_prefix", default=None, type=str)
    define("log_file_max_size", default=100000, type=int)
    define("log_file_num_backups", default=10, type=int)
    define("log_rotate_mode", default="size", type=str)
    define("log_rotate_when", default="MIDNIGHT", type=str)
    define("log_rotate_interval", default=1, type=int)


# Generated at 2022-06-12 13:52:48.690957
# Unit test for function define_logging_options
def test_define_logging_options():
    try:
        define_logging_options()
    except Exception:
        pass

# Generated at 2022-06-12 13:53:00.831039
# Unit test for method format of class LogFormatter

# Generated at 2022-06-12 13:53:12.934760
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        # Set the locale to a locale that doesn't support UTF-8 (as
        # confirmed by locale -a). With the C locale, this test should
        # pass even on non-Mac OS X systems.
        import locale

        locale.setlocale(locale.LC_ALL, "en_US")
    except Exception:
        gen_log.warning("Could not set locale; some error handling tests may fail")

    def fake_unicode():
        import sys

        setattr(sys, "_called_from_test", True)
        return bytes("\xe9", "latin-1")

    import logging

    from tornado.log import access_log, app_log, gen_log

    class FakeLogRecord(object):
        def __init__(self, message, levelno):
            self.message = message

# Generated at 2022-06-12 13:53:13.871740
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert enable_pretty_logging()

# Generated at 2022-06-12 13:53:15.133669
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)

# Generated at 2022-06-12 13:53:17.980323
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    logging.info(__file__)



if __name__ == "__main__":
    test_enable_pretty_logging()