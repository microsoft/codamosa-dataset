

# Generated at 2022-06-12 13:46:03.178384
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-12 13:46:11.406925
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("logging", type=str, default=None)
    tornado.options.define("logging_none", type=str, default="none")
    tornado.options.define("logging_info", type=str, default="info")
    tornado.options.define("logging_debug", type=str, default="debug")
    tornado.options.define("log_file_prefix", type=str, default="/tmp/myapp.log")
    tornado.options.define("log_file_max_size", type=int, default=100000)
    tornado.options.define("log_file_num_backups", type=int, default=10)
    tornado.options.define("log_rotate_mode", type=str, default="size")

# Generated at 2022-06-12 13:46:22.286856
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    datefmt = "%Y-%m-%d %H:%M:%S"
    my_formatter = LogFormatter(datefmt=datefmt)
    log_record = logging.LogRecord("name", logging.INFO, "pathname", 1, "msg", (), "exc_info", func="")
    log_record.args = ()
    log_record.exc_info = ""
    log_record.filename = "pathname"
    log_record.levelname = "INFO"
    log_record.lineno = 1
    log_record.module = "pathname"
    log_record.msg = "msg"
    log_record.name = "name"
    log_record.pathname = "pathname"
    log_record.process = 0
    log_record.processName = "MainProcess"

# Generated at 2022-06-12 13:46:29.379548
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class FakeLogRecord:
        pass

    record = FakeLogRecord()
    record.__dict__ = {
        "asctime": "2007-07-04 14:03:02,492",
        "message": "A message",
        "color": "",
        "end_color": "\033[0m",
        "levelname": "INFO",
        "module": "logging_test",
        "lineno": 1,
    }
    f = LogFormatter()
    assert f.format(record) == "[I 07-04 14:03:02 logging_test:1] A message"

    f = LogFormatter(datefmt="%B %d, %Y %H:%M:%S", fmt="%(color)s%(levelname)s:%(end_color)s %(message)s")

# Generated at 2022-06-12 13:46:38.336212
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():

    import logging

    from tornado import options  # type: ignore
    from tornado.log import gen_log  # type: ignore

    options.define("log_file_prefix", type=str, default="")
    options.define("logging", type=str, default="info")
    options.define("log_file_max_size", type=int, default=1024 * 1024 * 16)
    options.define("log_file_num_backups", type=int, default=5)
    options.define("log_rotate_mode", type=str, default="size")
    options.define("log_to_stderr", type=bool, default=True)
    options.define("log_rotate_when", type=str, default="D")

# Generated at 2022-06-12 13:46:49.768066
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tempfile

    log_file = tempfile.NamedTemporaryFile("w", delete=False)
    logging.basicConfig(filename=log_file.name, level=logging.DEBUG)

    gen_log.info("hello")

    import json
    import re

    # Read contents of file
    with open(log_file.name, "r") as f:
        data = f.read()

    # Extract time and log message
    time = re.findall(r"\[\d\d\d\d\d\d \d\d:\d\d:\d\d\]", data)[0]
    msg = re.findall(r"\] .+", data)[0]
    msg = msg.lstrip("] ")

    # Convert message contents into a dict

# Generated at 2022-06-12 13:46:50.686842
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter()


# Generated at 2022-06-12 13:46:52.734806
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter) is True, "formatter check"



# Generated at 2022-06-12 13:46:54.427602
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()  # no exception

_default_log_formatter = LogFormatter()



# Generated at 2022-06-12 13:47:01.166285
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define
    import logging
    import os
    log_path = "/tmp/test_enable_pretty_logging.txt"
    define("logging", default="none", help="")
    define("log_file_prefix", default=log_path, help="")
    define("log_rotate_mode", default="", help="")
    enable_pretty_logging()
    assert os.path.exists(log_path)
    os.remove(log_path)

# Generated at 2022-06-12 13:47:20.922889
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        assert True
    except:
        print("test LogFormatter_format() failed.")
test_LogFormatter_format.__doc__ = LogFormatter.format.__doc__


# Generated at 2022-06-12 13:47:22.145993
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

test_enable_pretty_logging()

# Generated at 2022-06-12 13:47:29.549016
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class TestHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super(TestHandler, self).__init__(*args, **kwargs)
            self.event = None  # type: Optional[logging.LogRecord]

        def emit(self, record: logging.LogRecord) -> None:
            self.event = record

    handler = TestHandler()
    formatter = LogFormatter()
    handler.setFormatter(formatter)

    logger = logging.getLogger()
    logger.addHandler(handler)

    logger.error(u"\N{SNOWMAN}")
    logger.exception(u"\N{SNOWMAN}")

    assert handler.event.message == u"\N{SNOWMAN}"
    assert handler.event.exc_info[1].args

# Generated at 2022-06-12 13:47:31.406011
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.log.enable_pretty_logging()


# Generated at 2022-06-12 13:47:41.533888
# Unit test for method format of class LogFormatter

# Generated at 2022-06-12 13:47:44.648400
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    class mock_record:
        def __init__(self, message: Optional[str] = None) -> None:
            self.message = message
    assert formatter.format(mock_record("Test message")) == 'Test message'
    assert (
        formatter.format(
            mock_record(
                "Test message\n"
                "Test message\n"
                "Test message"
            )
        )
        == 'Test message\n    Test message\n    Test message'
    )


# Generated at 2022-06-12 13:47:48.730024
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    logger = logging.getLogger('tornado.test')
    # set parser to set up environment
    parser = tornado.options.OptionParser()
    parser.add_option('--logging', '-l', default=None,
                      help=('set logging level '
                            '[debug|info|warning|error|none], default is debug'))
    parser.add_option('--log_file_prefix','-f',default='/tmp/tornado.log',
                      help='set log file name')
    parser.add_option('--log_to_stderr','-s', default=False,
                      help='log to console', action='store_true')
    # parse the command line
    options, remains = parser.parse_args()

    # enable logging
   

# Generated at 2022-06-12 13:47:49.681015
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()

# Generated at 2022-06-12 13:47:52.986636
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    for lvl in range(50):
        default_fmt = f.format(logging.LogRecord("test", lvl, "foo", 1, "test", (), None, None))
        print(default_fmt)
        assert default_fmt  # should be "set"

# break up the LogFormatter import
del logging, logging.handlers, curses, colorama



# Generated at 2022-06-12 13:47:54.238850
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass


__all__ = ["access_log", "app_log", "gen_log", "LogFormatter", "enable_pretty_logging"]

# Generated at 2022-06-12 13:48:16.836427
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define

    define(
        "log_to_stderr", type=bool, default=True,
    )

    gen_log.debug(
        "test"
    )  # Emit some log messages to silence messages about not configuring the root logger. 

    enable_pretty_logging()

    gen_log.debug(
        "test"
    )

    assert True

# Generated at 2022-06-12 13:48:18.303749
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: () -> None
    log_formatter = LogFormatter()


# Generated at 2022-06-12 13:48:29.144145
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import warnings
    import logging
    # logging.basicConfig：简单的配置日志
    # 如果没有配置日志，那么默认的日志器的日志级别是warning
    # 如果debug()方法被调用，但是日志器的级别比debug高，则不会输出
    # 如果设置日志级别，但是没有设置处理器

# Generated at 2022-06-12 13:48:31.923586
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Use custom LogFormatter by default
_defaults = {
    "log_to_stderr": True,
    "logging": "debug",
}



# Generated at 2022-06-12 13:48:38.531280
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import time

    logging.getLogger().setLevel(logging.INFO)
    logging.getLogger().handlers = []
    logger = logging.getLogger()
    logFormatter = LogFormatter()
    fileHandler = logging.FileHandler("test_LogFormatter_format.log")
    fileHandler.setFormatter(logFormatter)
    logger.addHandler(fileHandler)

    logger.info(
        "This is a test log message at %s", time.strftime("%Y-%m-%d %H:%M:%S")
    )


if __name__ == "__main__":
    test_LogFormatter_format()

# Generated at 2022-06-12 13:48:46.615151
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    class LogFormatterTest(unittest.TestCase):
        def test_format(self):
            formatter = LogFormatter(color=True)
            msg = formatter.format(logging.LogRecord("tornado.application","DEBUG","/home/unkn/PycharmProjects/tornado/tornado/app.py",21,"substr(key,1)"))
            self.assertEqual(msg, '\x1b[34m[D 100516 13:59:47 app:21]\x1b[0m substr(key,1)')
    unittest.main()



# Generated at 2022-06-12 13:48:52.533077
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter()
    class LogRecord(object):
        def __init__(self, message: str, levelno: int, exc_info: Optional[BaseException] = None) -> None:
            self.message = message
            self.levelno = levelno
            self.exc_info = exc_info
            self.asctime = ""
            self.color = ""
            self.end_color = ""
            self.exc_text = ""
    record = LogRecord(message="this is a test message", levelno=1)
    logFormatter.format(record)



# Generated at 2022-06-12 13:48:54.225008
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_formatter = LogFormatter()


# Generated at 2022-06-12 13:49:03.221472
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    formatter = LogFormatter(fmt=fmt)
    record = logging.LogRecord("tornado.application", logging.DEBUG, "foo.py", 100, "Hurrah", [], None)  # noqa: E501
    f = formatter.format(record)
    assert f == "[\x1b[34mD 100205 15:36:40 tornado\x1b[0m] Hurrah"

# Generated at 2022-06-12 13:49:10.064050
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    parser = tornado.options.OptionParser()
    define_logging_options(parser)
    # Valid log_rotate_mode
    parser.parse_command_line(
        [
            '--logging=debug',
            '--log_to_stderr=True',
            '--log_file_prefix=example.log',
            '--log_file_max_size=50',
            '--log_file_num_backups=5',
            '--log_rotate_when=midnight',
            '--log_rotate_interval=1',
            '--log_rotate_mode=time',
        ]
    )
    assert tornado.options.options.log_to_stderr
    assert tornado.options.options.log_file_prefix == 'example.log'

# Generated at 2022-06-12 13:49:48.434405
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    This method tests format method of LogFormatter class
    """
    # Declaring varables
    input_data = {
        "asctime": "asctime",
        "message": "some_message",
        "levelno": "levelno",
        "module": "module",
        "lineno": "lineno"
    }
    # Invoking constructor of class LogFormatter
    date_format = "%y%m%d %H:%M:%S"
    log_formatter_ins = LogFormatter(datefmt=date_format)
    # Invoking format method of class LogFormatter
    output_data = log_formatter_ins.format(input_data)
    # Comparing expected and output value
    assert output_data == "[l asctime module:lineno] some_message"


# Generated at 2022-06-12 13:49:58.727719
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import io
    import logging

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Provide some known color codes.
    COLORS = {
        logging.DEBUG: "grey",
        logging.INFO: "white",
        logging.WARNING: "yellow",
        logging.ERROR: "red",
        logging.CRITICAL: "magenta",
    }
    # Create a mock stderr with a known colorama-style string.
    # (bytes in this case because colorama will do the encode
    # for us).
    COLOR_STRING = b"\x1b[%dm"
    STDERR = io.BytesIO()
    STDERR.isatty = lambda: True
    STDERR.fileno = lambda: 2

    # Try instantiating as we normally would.
    logging

# Generated at 2022-06-12 13:50:08.429205
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.ioloop
    import time
    import os
    import sys
    import logging
    from uuid import uuid1
    from shutil import rmtree

    current_path = os.path.dirname(__file__)
    test_dir = os.path.join(current_path, 'log_dir')
    test_log_file_prefix = os.path.join(test_dir, "test.log")
    test_log_file = test_log_file_prefix + ".20160902"
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    sys.argv = ['', "--logging=debug", "--log_file_prefix", test_log_file_prefix]

# Generated at 2022-06-12 13:50:15.141142
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = None
    options.log_file_prefix = None
    options.log_file_max_size = None
    options.log_file_num_backups = None
    options.log_rotate_mode = None
    options.log_rotate_when = None
    options.log_rotate_interval = None
    options.log_to_stderr = None
    logger = logging.getLogger()
    assert logger.level == logging.NOTSET
    enable_pretty_logging()
    assert logger.level == logging.NOTSET
    assert len(logger.handlers) == 0
    options.logging = "debug"
    enable_pretty_logging()
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 13:50:27.891073
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    L=LogFormatter()
    assert L._fmt == L.DEFAULT_FORMAT
    assert L._colors == {}
    assert L._normal == ''
    try:
        L.format(None)
        assert False, "Should not be reached"
    except Exception as e:
        assert str(e) == "an integer is required"
    # These tests are only valid when the default formatter
    # is used. The default formatter uses a default format
    # that includes the message and the module name.
    lr=logging.LogRecord(None,logging.INFO,__file__,12,
                         'This is a test message',None,None)
    assert L.format(lr)=="[I 20190713 17:33:31 main:12] This is a test message"
    lr.lineno=999


# Generated at 2022-06-12 13:50:37.424849
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Record(object):
        def __init__(self,levelno:int,exc_info:str=None,exc_text:str=None):
            self.levelno = levelno
            self.exc_info = exc_info
            self.exc_text = exc_text
            self.__dict__ = {
                "levelname": "levelname",
                "asctime": "asctime",
                "module": "module",
                "lineno": "lineno",
                "message": "message"
            }
    global log_fmt
    log_fmt = LogFormatter()
    print("test_LogFormatter_format - start")
    print("test_case A")
    record = Record(12,exc_text="exception text")
    msg = log_fmt.format(record)
   

# Generated at 2022-06-12 13:50:44.876725
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = 'debug'
    options.log_file_prefix = 'log.txt'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 0
    options.log_file_num_backups = 1
    enable_pretty_logging(options)

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:50:49.770293
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(datefmt="%Y")
    logrecord = logging.LogRecord("name", logging.INFO, "/home", 12, "msg", [], None)
    formatted = formatter.format(logrecord)
    assert formatted.startswith("INFO") and formatted.endswith("msg")



# Generated at 2022-06-12 13:50:53.668916
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._colors == {}
    assert LogFormatter(color=False)._colors == {}
    LogFormatter()
    LogFormatter(color=False)
    LogFormatter(color=None)
test_LogFormatter()



# Generated at 2022-06-12 13:50:59.879911
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(
        color=True,
        fmt="%(color)s%(asctime)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    # make sure colorama can be init (will throw exception otherwise)
    try:
        import colorama
        colorama.init()
    except ImportError:
        pass
    # just call it, to make sure the constructor does not raise Exception
    formatter.format(logging.LogRecord("test", logging.DEBUG, "test.py", 99, "msg", None, None))


# Generated at 2022-06-12 13:53:11.016533
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """ Test the function enable_pretty_logging"""
    enable_pretty_logging()

# Generated at 2022-06-12 13:53:19.613391
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime

    FMT = '[%(levelname)1.1s [%(asctime)s] %(module)s:%(lineno)d] %(message)s'
    formatter = LogFormatter(FMT)

    # just check that it doesn't raise an exception...
    formatter.format("test")

    # try a few known inputs
    formatter.format(
        logging.LogRecord("foo", logging.DEBUG, __file__, 42, "test", None, None)
    )
    formatter.format(logging.LogRecord("foo", logging.DEBUG, __file__, 42, "", None, None))

# Generated at 2022-06-12 13:53:25.965070
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_formatter = LogFormatter()
    assert log_formatter._fmt == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa: E501
    assert log_formatter._normal == ''
    assert log_formatter._colors == {}



# Generated at 2022-06-12 13:53:26.914313
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert enable_pretty_logging(options = None , logger = None) == None

# Generated at 2022-06-12 13:53:34.301532
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("log_file_prefix", "test_logfile.log", type=str)
    tornado.options.define("log_to_stderr", True, type=bool)
    tornado.options.define("log_rotate_mode", "time", type=str)
    tornado.options.define("log_file_num_backups", 3, type=int)
    tornado.options.define("logging", "debug", type=str)
    tornado.options.parse_command_line()
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:53:42.463267
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    验证 日志格式化类
    """
    #日志级别数据
    #logging.DEBUG: 4,  # Blue
    #logging.INFO: 2,  # Green
    #logging.WARNING: 3,  # Yellow
    #logging.ERROR: 1,  # Red
    #logging.CRITICAL: 5,  # Magenta


    #构建 日志格式化对象
    formatter = LogFormatter(fmt=LogFormatter.DEFAULT_FORMAT,datefmt=LogFormatter.DEFAULT_DATE_FORMAT,style= "%",color= True,colors=LogFormatter.DEFAULT_COLORS)
   

# Generated at 2022-06-12 13:53:49.867848
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    formatter = LogFormatter(datefmt="test")
    assert formatter.datefmt == "test"
    formatter = LogFormatter(fmt="%(message)s", datefmt="%d %m %y")
    assert formatter.datefmt == "%d %m %y"
    assert formatter._fmt == "%(message)s"
    formatter = LogFormatter(fmt="", datefmt="")
    assert formatter._fmt == ""



# Generated at 2022-06-12 13:53:58.111587
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

_debug = gen_log.debug
_info = gen_log.info
_warning = gen_log.warning
_error = gen_log.error
_critical = gen_log.critical

debug = gen_log.debug
info = gen_log.info
warning = gen_log.warning
error = gen_log.error
critical = gen_log.critical

try:
    # PEP-302 defines "__spec__" in Python 3
    __spec__ = type(sys)().__spec__
except AttributeError:
    pass

# Generated at 2022-06-12 13:54:08.628211
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    from tornado.options import define_logging_options
    from tornado.options import options
    option=OptionParser()
    define_logging_options(option)
    options.parse_command_line()
    options.logging="info"
    options.log_to_stderr=True
    options.log_file_prefix="D:/software/tornado-5.1.1/tornado-5.1.1/log/app.log"
    options.log_file_num_backups=10
    options.log_file_max_size=100*1000*1000
    options.log_rotate_when="midnight"
    options.log_rotate_interval=1
    options.log_rotate_mode="size"
    #options.add_parse_callback(

# Generated at 2022-06-12 13:54:16.214002
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter(color=True)
    assert fmt.datefmt == fmt.DEFAULT_DATE_FORMAT
    assert fmt._fmt == fmt.DEFAULT_FORMAT

    fmt = LogFormatter(color=True, datefmt="foo")
    assert fmt.datefmt == "foo"
    assert fmt._fmt == fmt.DEFAULT_FORMAT

    fmt = LogFormatter(color=True, fmt="%(message)s")
    assert fmt.datefmt == fmt.DEFAULT_DATE_FORMAT
    assert fmt._fmt == "%(message)s"

