

# Generated at 2022-06-12 13:46:03.177626
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert True



# Generated at 2022-06-12 13:46:11.458456
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    define("logging", default="debug")
    define("log_file_prefix", default="test.log")
    define("log_file_max_size", default=1000)
    define("log_file_num_backups", default=5)
    define("log_rotate_mode", default="size")
    define("log_rotate_when", default="D")
    define("log_rotate_interval", default=10)
    define("log_to_stderr", default=False)
    parse_command_line()
    enable_pretty_logging()
    with pytest.raises(ValueError):
        define("log_rotate_mode", default="time1")
        parse_command_line()
        enable_pretty_logging()

# Generated at 2022-06-12 13:46:22.325579
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    a = LogFormatter()
    record = logging.LogRecord("tornado.access","INFO","/tmp","1","[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s","a",None)
    record.module = "test"
    record.lineno = 1
    record.levelname = "INFO"
    record.asctime = "2020-10-16 18:10"
    record.message = "hello"
    newline = "\n"
    a.format(record)
    assert record.message == "hello"
    assert record.asctime == "2020-10-16 18:10"
    record.message = "\x80"
    record.asctime = "\x80"
    a.format(record)
   

# Generated at 2022-06-12 13:46:23.038911
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-12 13:46:27.100637
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """Test case for constructor
    """
    formatter = LogFormatter()

# Generated at 2022-06-12 13:46:28.716260
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter


# Generated at 2022-06-12 13:46:37.913122
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """
    Verify the enable_pretty_logging function
    """
    import tornado.options
    import logging
    import os.path
    tornado.options.options.log_to_stderr = False
    logger = logging.getLogger()
    enable_pretty_logging(tornado.options.options, logger)
    assert logger.level == 20
    assert len(logger.handlers) == 1
    assert type(logger.handlers[0]) == logging.StreamHandler
    assert type(logger.handlers[0].formatter) == LogFormatter
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging(tornado.options.options, logger)
    assert logger.level == 20
    assert len(logger.handlers) == 1

# Generated at 2022-06-12 13:46:39.455828
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:46:40.403394
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass



# Generated at 2022-06-12 13:46:46.330172
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log
    import json
    log_formatter = LogFormatter()
    print(
        json.dumps(
            tornado.log.LogFormatter.__init__.__annotations__,
            indent=4,
            sort_keys=True,
        )
    )
    return log_formatter



# Generated at 2022-06-12 13:47:05.370860
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:47:16.942406
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # testing with locale
    import locale
    locale.setlocale(locale.LC_ALL, "")
    # testing empty str
    test_str_1 = ""
    # testing ascii str
    test_str_2 = "hello"
    # testing non-ascii str
    test_str_3 = "你好"
    # tesing str with non-ascii characters
    test_str_4 = "日本語"
    # testing str with \n
    test_str_5 = "hello\nhi"
    # testing str with both non-ascii and \n
    test_str_6 = "hello\n日本語"
    # testing empty bytes
    test_bytes_1 = b""
    # testing ascii bytes
    test_bytes

# Generated at 2022-06-12 13:47:26.462197
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # test variables
    base_msg = "This is a test for {0}."
    prefix = "[DEBUG 0904123456 foo:101]"
    formatter = LogFormatter(
        "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]"
    )

    # test passing on logging.LogRecord
    log_record = logging.LogRecord(
        name="foo",
        level=1,
        pathname="bar",
        lineno=101,
        msg=base_msg.format("logging.LogRecord"),
        args=None,
        exc_info=None,
    )
    res = formatter.format(log_record)

# Generated at 2022-06-12 13:47:38.302947
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  import tornado
  import tornado.options
  import tornado.log
  tornado.options.define("logging", default="none", help="logging level")
  tornado.options.define("log_file_prefix", default="/tmp", help="log file")
  tornado.options.define("log_file_max_size", default=100, help="log file max size")
  tornado.options.define("log_file_num_backups", default=10, help="log file num")
  tornado.options.define("log_rotate_mode", default="size", help="log file rotate mode")
  tornado.options.define("log_rotate_when", default="S", help="log file rotate when")
  tornado.options.define("log_rotate_interval", default=1, help="log file rotate interval")
  tornado.options.define

# Generated at 2022-06-12 13:47:42.660977
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = "%(color)s%(levelname)1.1s %(asctime)s.%(msecs)03d %(module)s %(lineno)d%(end_color)s - %(message)s"  # noqa: E501
    date_format = "%Y-%m-%d %H:%M:%S"
    log_formatter = LogFormatter(color=True, fmt=log_format, datefmt=date_format)

# Generated at 2022-06-12 13:47:48.149590
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    logger = logging.Logger(name="test", level=logging.INFO)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    logger.info("test message")

# Generated at 2022-06-12 13:47:56.164303
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(
        fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
        datefmt = '%Y-%m-%d %H:%M:%S',
        style = '%',
        color=True,
        colors = {logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
        }
    )


# Generated at 2022-06-12 13:48:05.430304
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import io

    class LogHandler(logging.StreamHandler):
        def __init__(self):
            logging.StreamHandler.__init__(self, io.StringIO())
            # Make it go to stdout
            self.stream = sys.stdout

    logger = logging.getLogger("test_logging")

    # Test without color
    logger.handlers = []  # Clear old handlers
    logger.addHandler(LogHandler())
    logger.propagate = False
    logger.setLevel(logging.DEBUG)
    logger.info("test")

    # Test with color
    logger.handlers = []  # Clear old handlers
    handler = LogHandler()
    handler.setFormatter(LogFormatter(color=True))
    logger.addHandler(handler)
    logger.propagate = False

# Generated at 2022-06-12 13:48:12.078109
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# To use colorized log output,
# replace "enable_pretty_logging()" with "enable_pretty_logging(True)".
#
# If you use "--log_file_prefix=foo" on the command line,
# or otherwise configure tornado.options.options.log_file_prefix,
# you can call enable_pretty_logging without the argument to have it
# use the same log file.
#
# enable_pretty_logging()

# Generated at 2022-06-12 13:48:14.226846
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-12 13:48:44.161446
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): # type: () -> None
    with open('test_LogFormatter.log', 'w') as f:
        formatter = LogFormatter(color=True, fmt="%(color)s%(levelname)s%(end_color)s %(message)s") # noqa: E501
        handler = logging.StreamHandler(f)
        handler.setFormatter(formatter)
        gen_log.addHandler(handler)
    gen_log.info('Testing')
    gen_log.warning('Testing')
    gen_log.error('Testing')



# Generated at 2022-06-12 13:48:49.312650
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = LogFormatter()  # Configurable defaults.
    assert fmt._fmt == LogFormatter.DEFAULT_FORMAT
    fmt.datefmt == LogFormatter.DEFAULT_DATE_FORMAT


# Generated at 2022-06-12 13:49:00.612802
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
	from tornado.options import define, options
	define("logging", default="info",
		   help="log level", type=str)
	define("log_file_prefix", default=None,
		   help="Path prefix for log files. "
				"Note that if you are running multiple tornado processes, "
				"log_file_prefix must be different for each of them (e.g. "
				"include the port number)")
	define("log_to_stderr", default=False,
		   help="Send log output to stderr (colorized if possible). "
				"By default use stderr if --log_file_prefix is not set and "
				"no other logging is configured.")

# Generated at 2022-06-12 13:49:08.276222
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.web
    tornado.options.define('port', 8080)
    tornado.options.define('log_to_stderr', True)
    tornado.options.define('logging', 'none')
    tornado.options.define('log_file_prefix', 'lab.log')
    tornado.options.define('log_file_max_size', 1000000)
    tornado.options.define('log_file_num_backups', 3)
    tornado.options.define('log_rotate_mode', 'size')
    tornado.options.define('log_rotate_when', 'midnight')
    tornado.options.define('log_rotate_interval', 1)
    tornado.options.parse_command_line()
    enable_pretty_logging()


# Generated at 2022-06-12 13:49:10.426409
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger("test_tornado")
    enable_pretty_logging(logger=logger)
    logger.info("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:12.698380
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter("%(levelname)s %(name)s") # type: ignore
    formatter.format



# Generated at 2022-06-12 13:49:17.587200
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Record(object):
        def __init__(self, msg: str) -> None:
            self.__dict__.update(
                message=msg,
                asctime="2012-01-01 01:00:00",
                levelno=logging.DEBUG,
                __dict__={},
                exc_info=None,
            )
    # str
    msg = "msg"
    record = Record(msg)
    formatter = LogFormatter()
    assert formatter.format(record) == (
        "[DEBUG 2012-01-01 01:00:00 root:0] "
        "%s" % msg
    )
    # unicode
    msg = u"msg"
    urecord = Record(msg)

# Generated at 2022-06-12 13:49:29.953199
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    logging.basicConfig(level=logging.DEBUG)  # 初始化root 的日志级别
    tornado.options.define("logging", default=None, help="logging level", type=str)
    tornado.options.define("log_file_prefix", default=None, help="log file prefix", type=str)  # noqa: E501
    tornado.options.define("log_rotate_mode", default=None, help="log rotate mode", type=str)  # noqa: E501
    tornado.options.define("log_rotate_when", default=None, help="log rotate when", type=str)  # noqa: E501

# Generated at 2022-06-12 13:49:36.357408
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter("%(color)s%(message)s")
    LogFormatter("%(color)s%(message)s", color=False)
    LogFormatter("%(color)s%(message)s", color=True)
    LogFormatter("%(color)s%(message)s", color=None)



# Generated at 2022-06-12 13:49:42.607570
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def func_test_LogFormatter_format():
        import datetime
        now = datetime.datetime.now().strftime('%H:%M:%S.%f')
        record = logging.LogRecord(name='test', level=logging.DEBUG, fn='test.py', lno=10, msg='test message', args=None, exc_info=None)
        expected = f'[D {now} test:10] test message'
        actual = LogFormatter().format(record)
        assert expected == actual

    func_test_LogFormatter_format()



# Generated at 2022-06-12 13:50:30.807785
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing
    import logging
    import logging.handlers
    from tornado.testing import AsyncTestCase
    from tornado.util import basestring_type
    from tornado.log import LogFormatter, enable_pretty_logging, access_log, app_log

    class LogTest(AsyncTestCase):
        def setUp(self):

            self.io_loop = self.get_new_ioloop()
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setFormatter(LogFormatter())

            super(LogTest, self).setUp()

        def tearDown(self):
            self.io_loop.close()


# Generated at 2022-06-12 13:50:37.876865
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()

    # class LogFormatter
    assert isinstance(f, logging.Formatter)
    assert f._colors == {}
    assert f._normal == ""

    # def format(self, record: Any) -> str:
    r = logging.LogRecord(
        name="",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="",
        args=(),
        exc_info=None,
    )
    assert f.format(r) == "[I " + r.asctime + " ] " + r.getMessage()



# Generated at 2022-06-12 13:50:47.204127
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        logging_init = logging.shutdown
        logging.shutdown = lambda: None
        enable_pretty_logging()
    finally:
        logging.shutdown = logging_init
    enable_pretty_logging(None, logging.getLogger())
    enable_pretty_logging(None, logging.getLogger("tornado"))
    enable_pretty_logging(None, logging.getLogger("tornado.application"))


# deprecated alias for enable_pretty_logging.  This is not intended for
# public use.
use_pretty_logging = enable_pretty_logging

# Generated at 2022-06-12 13:50:54.613188
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: no cover
    from tornado import ioloop

    logging.getLogger().handlers[0].setFormatter(LogFormatter())
    # Prevent warning about colorama not being initialized
    LogFormatter.DEFAULT_COLORS = {}
    gen_log.warning("Test")
    gen_log.error("Test")

    loop = ioloop.IOLoop()
    loop.make_current()
    try:
        gen_log.info("Starting IOLoop")
        loop.start()
    finally:
        loop.close()



# Generated at 2022-06-12 13:51:01.044401
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        test_message = b'Bad message (\'%r\'): %r'
        test_record = type('_record', (object,), {"message": test_message, "__dict__": {}})
        test_record.__dict__ = {"exc_text": "Bad message", "exc_info": ("message from testing: ", 1, 2)}
        test_formatter = LogFormatter()
        result = test_formatter.format(test_record)
        assert(result.startswith("[E") or result.startswith("Bad message"))
    except Exception as e:
        print("My exception: ", e)
test_LogFormatter_format()

# test for method formatTime of class LogFormatter

# Generated at 2022-06-12 13:51:04.356423
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_object = LogFormatter()
    # assert isinstance(log_formatter_object.DEFAULT_FORMAT, str)
    # assert isinstance(log_formatter_object.DEFAULT_DATE_FORMAT, str)
    # assert isinstance(log_formatter_object.DEFAULT_COLORS, dict)
    # assert isinstance(log_formatter_object._colors, dict)
    # assert isinstance(log_formatter_object._normal, str)



# Generated at 2022-06-12 13:51:13.404892
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import OptionParser, define
    define("test", default="test", help="test help", type=str)
    from io import StringIO
    from StringIO import StringIO
    import sys, os
    import logging
    import unittest
    parser = OptionParser()
    parser.add_option("--logging", type="string", default="debug", help="logging help")
    parser.add_option("--log_file_prefix", type="string", default="test.log", help="logging file prefix help")
    parser.add_option("--log_rotate_mode", type="string", default="size", help="logging rotate help")
    parser.add_option("--log_file_max_size", type="int", default=100, help="logging file max size help")

# Generated at 2022-06-12 13:51:24.128371
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord("tornado.general", logging.INFO, "app_log", 2, "test_message", None, None)) == "[I %(asctime)s app_log:2] test_message"
    assert LogFormatter(fmt="%(color)s%(message)s%(end_color)s").format(logging.LogRecord("tornado.general", logging.INFO, "app_log", 2, "test_message", None, None)) == "test_message"
    assert "Failed" in LogFormatter().format(logging.LogRecord("tornado.general", logging.INFO, "app_log", 2, "test_message", None, ValueError))

# Generated at 2022-06-12 13:51:25.706552
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT

# end of class LogFormatter



# Generated at 2022-06-12 13:51:28.395003
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        logging = None
    enable_pretty_logging(Options)


# Generated at 2022-06-12 13:53:14.705300
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """Unit test for method format of class LogFormatter."""
    # Create a logger
    logger = logging.getLogger('__main__')
    logger.setLevel(logging.DEBUG)
    # Create a handler to write log
    fh = logging.FileHandler('test.log')
    # Create a formatter with color and format
    fmt = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    fmter = LogFormatter(fmt=fmt, color=True)
    fh.setFormatter(fmter)
    logger.addHandler(fh)
    # Log information
    logger.info('info')

if __name__ == '__main__':
    test_LogFormatter_format()

# Generated at 2022-06-12 13:53:24.718927
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    from tornado.log import enable_pretty_logging

    define("logging", default="info")
    define("log_to_stderr", default=True)
    define("log_file_prefix", default="test.log")
    define("log_file_max_size", default=10)
    define("log_file_num_backups", default=5)
    define("log_rotate_mode", default="size")
    define("log_rotate_when", default="D")
    define("log_rotate_interval", default=1)

    tornado.options.parse_command_line()
    assert options.log_to_stderr == True
    assert options.log_file_prefix == "test.log"
    assert options.log_

# Generated at 2022-06-12 13:53:29.428105
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import logging
    import logging.handlers

    logging.basicConfig()
    tornado.options.define("logging", default="none", help="logging type")
    tornado.options.define("log_to_stderr", default="none", help="log to stderr")
    tornado.options.define("log_file_prefix", default="none", help="log file prefix")
    tornado.options.define("log_rotate_mode", default="size", help="log_rotate_mode")
    tornado.options.define("log_file_max_size", default=1, type=int, help="log_file_max_size")

# Generated at 2022-06-12 13:53:39.476019
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # we require options to be set up
    import tornado.options

    tornado.options.define("logging", default="none")
    tornado.options.define("log_file_prefix", default="/tmp/")
    tornado.options.define("log_file_num_backups", default=0)
    tornado.options.define("log_file_max_size", default=10)
    tornado.options.define("log_rotate_mode", default="size")
    tornado.options.define("log_rotate_when", default="")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.define("log_to_stderr", default=True)

    enable_pretty_logging()
    assert len(logging.root.handlers) == 1
    assert logging.root.hand

# Generated at 2022-06-12 13:53:42.032919
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado
    from tornado.options import options
    options.log_to_stderr = True
    tornado.options.parse_command_line()

    gen_log.warning("This is a warning!")


# Generated at 2022-06-12 13:53:48.839607
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    cls = LogFormatter
    # test __init__()
    assert isinstance(cls.DEFAULT_FORMAT, str)
    assert isinstance(cls.DEFAULT_DATE_FORMAT, str)
    assert isinstance(cls.DEFAULT_COLORS, dict)
    # test _stderr_supports_color
    assert isinstance(_stderr_supports_color(), bool)
    # test _safe_unicode()
    s = "hello, world"*10
    assert _safe_unicode(s) == s
    assert isinstance(_safe_unicode(s), (str, unicode_type))
    s = 's\xe4\xeb\xe4\xec\xda\xc2'
    s = s.encode('latin1')
    assert _safe_unic

# Generated at 2022-06-12 13:53:49.556832
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter() is not None

# Generated at 2022-06-12 13:54:01.472595
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    import tornado.log
    tornado.options.options.logging = "none"
    # Set up color if we are in a tty and curses is installed
    logger = logging.getLogger()
    tornado.log.enable_pretty_logging(None, logger)
    logger.setLevel(logging.WARNING)
    assert len(logger.handlers) == 0
    tornado.options.options.logging = "info"
    tornado.log.enable_pretty_logging(None, logger)
    logger.setLevel(logging.WARNING)
    assert len(logger.handlers) == 1
    tornado.options.options.logging = "ERROR"
    logger.setLevel(logging.WARNING)
    tornado.log.enable_pretty_logging(None, logger)
   

# Generated at 2022-06-12 13:54:02.084689
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.Formatter()

# Generated at 2022-06-12 13:54:05.592549
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import pytest
    assert(LogFormatter().format(logging.LogRecord("name", "levelno", "pathname", "lineno", "msg", "args", "exc_info")) == "[L name:lineno] msg\n")

LogFormatter()
