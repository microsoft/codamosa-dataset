

# Generated at 2022-06-12 13:46:21.229286
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Default.
    formatter = LogFormatter()
    print(formatter._fmt)
    print(formatter._colors)
    print(formatter._normal)
    assert formatter._fmt == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa: E501
    assert formatter._colors == {}
    assert formatter._normal == ""

    # With color.
    formatter = LogFormatter(color=True)
    print(formatter._fmt)
    print(formatter._colors)
    print(formatter._normal)

# Generated at 2022-06-12 13:46:28.685168
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert formatter.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}
    assert formatter._normal == ""
    assert formatter._colors == {}

# Generated at 2022-06-12 13:46:30.664663
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()

# pylint: disable=redefined-outer-name

# Generated at 2022-06-12 13:46:31.352110
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:46:37.123865
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): 
    fmt = '%(test1)s  %(test2)s  %(test3)s  %(test4)s  %(test5)s  %(test6)s  %(test7)s'
    colors = {10: 0, 20: 1, 30: 2, 40: 3, 50: 4}
    formatter = LogFormatter(fmt, colors = colors)

    formatter.isEnabledFor(10)
    formatter.format(10)

# Generated at 2022-06-12 13:46:49.087964
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    lf = LogFormatter(color=False, style="%")
    lf = LogFormatter(datefmt="%y%m%d")
    lf = LogFormatter(logging.DEBUG, "%(color)s%(asctime)s %(foo)s%(end_color)s")
    logging.Formatter.formatTime.__qualname__
    assert lf.DEFAULT_FORMAT == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    # assert lf.DEFAULT_DATE_FORMAT == '%y%m%d %H:%M:%S'
    # assert lf.DE

# Generated at 2022-06-12 13:46:57.724078
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def init_logger(log_format='%(levelname)s %(message)s', stream=None, level=logging.DEBUG):
        logger = logging.getLogger('test')
        logger.setLevel(level)
        handler = logging.StreamHandler(stream)
        handler.setFormatter(LogFormatter(fmt=log_format))
        logger.addHandler(handler)
        return logger

    logger = init_logger(log_format='%(levelname)s %(message)s', stream=sys.stdout)
    logger.info('testing')
    logger = init_logger(log_format='%(levelname)s %(message)s', stream=sys.stderr, level=logging.ERROR)
    logger.info('testing')


# Generated at 2022-06-12 13:46:59.384441
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-12 13:47:06.576975
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
  o = LogFormatter()
  record = logging.LogRecord(
          "name",
          logging.DEBUG,
          "path",
          77,
          "msg",
          None,
          "exc_text")
  record.levelno = logging.DEBUG
  record.exc_info = None
  record.msg = "test_LogFormatter_format msg"
  record.exc_text = None
  ret = o.format(record)
  assert ret == "test_LogFormatter_format msg"


# Generated at 2022-06-12 13:47:17.911086
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=False)
    record = logging.LogRecord(
        name="mylog",
        level=logging.INFO,
        pathname="dummy.py",
        lineno=1,
        msg="dummy message",
        args=None,
        exc_info=None,
    )
    assert formatter.format(record) == "[I " + str(record.asctime) + " mylog:1] dummy message"
    record.levelno = logging.WARNING
    assert formatter.format(record) == "[W " + str(record.asctime) + " mylog:1] dummy message"
    record.levelno = logging.ERROR
    assert formatter.format(record) == "[E " + str(record.asctime) + " mylog:1] dummy message"


# Generated at 2022-06-12 13:47:59.652882
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()  # no error
    LogFormatter(color=False)  # no error



# Generated at 2022-06-12 13:48:06.725658
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    import logging
    import logging.handlers
    import os
    import sys
    import unittest
    import warnings

    class TestHandler(logging.handlers.BufferingHandler):
        def __init__(self, *args, **kwargs):
            self.watcher = kwargs.pop("watcher")
            logging.handlers.BufferingHandler.__init__(self, *args, **kwargs)

        def emit(self, record):
            self.watcher(self.format(record))
            self.buffer.append(record)


# Generated at 2022-06-12 13:48:10.852167
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    expected = "[1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    actual = LogFormatter().format(logging.makeLogRecord({"levelname": "1"}))
    assert expected == actual



# Generated at 2022-06-12 13:48:15.003613
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging(tornado.options.options)


# Singleton for default LogFormatter.
_default_formatter = None  # type: LogFormatter



# Generated at 2022-06-12 13:48:18.011263
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _fmt = LogFormatter()._fmt
    assert isinstance(_fmt, str)
    _colors = LogFormatter()._colors
    assert isinstance(_colors, dict)

# Generated at 2022-06-12 13:48:23.933473
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger("tornado.test_LogFormatter")
    logger.setLevel(logging.DEBUG)
    logger.error("hello, world")
    logger.exception("hello, world")
    cache = {}

    def handle(msg: str, kwargs: dict) -> None:
        cache["msg"] = msg
        cache["kwargs"] = kwargs

    logging.getLogger("tornado.test_LogFormatter").handle = handle
    logger.warn("%s %s", "hello", "world")
    assert cache["msg"] == "%s %s"
    assert cache["kwargs"] == {"args": ("hello", "world")}



# Generated at 2022-06-12 13:48:25.176275
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()  # no crash



# Generated at 2022-06-12 13:48:27.445037
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_LogFormatter.called += 1
    assert test_LogFormatter.called == 1

test_LogFormatter.called = 0


# Generated at 2022-06-12 13:48:34.627440
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert LogFormatter()._colors == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    assert LogFormatter()._normal == ""




# Generated at 2022-06-12 13:48:45.580523
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def run_test(
        fmt: Optional[str],
        datefmt: Optional[str],
        style: Optional[str],
        color: Optional[bool],
        colors: Optional[Dict[int, int]],
        msg: str,
    ) -> str:
        formatter = LogFormatter(
            fmt=fmt, datefmt=datefmt, style=style, color=color, colors=colors
        )
        record = logging.LogRecord("tornado.general", logging.INFO, "/foo/bar.py", 23, msg, {}, None)
        return formatter.format(record)

    assert run_test("", "", "%", True, {}, "hello world!") == "[I /foo/bar.py:23] hello world!"


# Generated at 2022-06-12 13:49:07.783196
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.testing
    import tornado.options
    import io

    class LoggingTest(tornado.testing.TestCase):
        def test_enable_pretty_logging(self):
            from tornado.options import define, options
            define("log_file_prefix", type=str, default="test.log")
            define("log_to_stderr", type=bool, default=False)
            define("log_file_max_size", type=int, default=100)
            define("log_file_num_backups", type=int, default=10)
            define("logging", default="debug")

            options.parse_command_line(args=["--log_file_prefix=test.log"])
            self.assertEqual(options.log_file_prefix, "test.log")

            enable_pretty_log

# Generated at 2022-06-12 13:49:09.082593
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-12 13:49:11.211148
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(fmt="%(color)s", datefmt="%Y-%m-%d %H:%M:%S", style="%", color=True, colors={})  # type: ignore
    assert True


# Generated at 2022-06-12 13:49:18.057630
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    #test_minimal_enable_pretty_logging()

    #test_enable_pretty_logging_rotate()
    #test_enable_pretty_logging_err()
    #test_enable_pretty_logging_rotate()
    #test_enable_pretty_logging_custom_logger()
    #test_colorlog()
    import tornado.options
    import logging
    import os

    class LogOptions(object):
        logging = "debug"
        log_file_prefix = os.path.join(
            os.path.dirname(__file__), "testdata", "foo.log"
        )

    old_logging_configured = logging.root.handlers

# Generated at 2022-06-12 13:49:30.375967
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os

    logger = logging.getLogger()
    options=tornado.options.options
    max_size=10
    options.log_rotate_mode="size"
    options.log_file_max_size=max_size
    options.log_file_num_backups=10
    options.log_file_prefix="log_rotate_test"
    file_name=options.log_file_prefix+'.log'
    logger.info("aaajsjsjsd")
    if os.path.isfile(file_name) and os.path.getsize(file_name)<max_size*1024*1024:
        print("the rotate_mode is size, and log file size is less than log_file_max_size")

# Generated at 2022-06-12 13:49:33.682655
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # TODO: implement
    assert False


# Generated at 2022-06-12 13:49:34.824344
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-12 13:49:36.493216
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:49:42.431337
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado import logging as tlogging
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    tlogging.enable_pretty_logging(options=None, logger=None)
    tlogging.enable_pretty_logging(options=None, logger=tlogging.app_log)
    tlogging.enable_pretty_logging(options=None, logger=tlogging.gen_log)
    tlogging.enable_pretty_logging(options=None, logger=tlogging.access_log)

# Generated at 2022-06-12 13:49:48.405169
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    logging.basicConfig()
    logger = logging.getLogger('testLogger')
    handler = logging.StreamHandler()
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    class TestLogFormatter(unittest.TestCase):
        def setUp(self):
            self.logger = logger
            
        def test_format(self):
            self.logger.debug('Test_debug')
            self.logger.info('Test_info')
            self.logger.warning('Test_warning')
            self.logger.error('Test_error')
            self.logger.critical('Test_critical')
    unittest.main()



# Generated at 2022-06-12 13:50:20.492174
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter.__init__(
        fmt="", datefmt="", style="%", color=True, colors={})

# Generated at 2022-06-12 13:50:23.150195
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    enable_pretty_logging(None,logger)
    print(logger.getEffectiveLevel())

# Generated at 2022-06-12 13:50:34.043179
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.web
    import tornado.ioloop

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")
            logging.info("Current log level is %s", logging.getLogger().level)

    application = tornado.web.Application([(r"/", MainHandler)])
    tornado.options.define("log_file_prefix", "tornado_test.log")
    tornado.options.define("log_to_stderr", False)
    tornado.options.define("log_rotate_mode", "time")
    tornado.options.define("log_rotate_when", "D")
    tornado.options.define("log_rotate_interval", 1)

# Generated at 2022-06-12 13:50:37.962070
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    color = _stderr_supports_color()
    formatter = LogFormatter(color = color)
    # message field of record is bytes
    record = logging.LogRecord(
        name = "tornado.access",
        level = logging.INFO,
        pathname = "test.py",
        lineno = 10,
        msg = b"\xe4\xb8\xad\xe6\x96\x87",
        args = (),
        exc_info = None
    )
    record.__dict__
    result = formatter.format(record)
    assert isinstance(result, str)


# Generated at 2022-06-12 13:50:49.235188
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # pylint: disable=protected-access
    _log_formatter = LogFormatter()
    assert isinstance(_log_formatter, logging.Formatter)
    assert _log_formatter._fmt == _log_formatter.DEFAULT_FORMAT
    assert _log_formatter._colors == {}
    assert _log_formatter._normal == ""

    _log_formatter = LogFormatter(fmt="fmt_test", datefmt="%Y", style="{")
    assert isinstance(_log_formatter, logging.Formatter)
    assert _log_formatter._fmt == "fmt_test"
    assert _log_formatter._colors == {}
    assert _log_formatter._normal == ""



# Generated at 2022-06-12 13:50:55.885614
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.root.setLevel(logging.CRITICAL)
    formatter = LogFormatter()
    formatter = LogFormatter(fmt="%(color)s%(levelname)s%(end_color)s")
    formatter = LogFormatter(color=False)
    formatter = LogFormatter(color=True)
    formatter = LogFormatter(datefmt="%Y%m%d")
    formatter = LogFormatter(style="$")
    formatter = LogFormatter(colors={logging.CRITICAL: 42})



# Generated at 2022-06-12 13:51:07.397620
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options, tornado.log
    tornado.options.define("log_file_prefix", type=str, default="C:\\Users\\user1\\Desktop\\tornado\\tornado_log.log")
    tornado.options.define("logging", type=str, default="info")
    tornado.options.define("log_file_max_size", type=int, default=100)
    tornado.options.define("log_file_num_backups", type=int, default=100)
    tornado.options.define("log_rotate_mode", type=str, default="size")
    tornado.options.define("log_rotate_when", type=str, default="w0")
    tornado.options.define("log_rotate_interval", type=int, default=1)

# Generated at 2022-06-12 13:51:14.297577
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import access_log
    import sys, io

    f = LogFormatter()
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    try:
        access_log.setLevel(20)
        access_log.info('This is a test string')
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-12 13:51:24.528971
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import tempfile
    import os
    # Test the function by parsing an argument line.
    with tempfile.TemporaryDirectory() as tmpdir:
        tornado.options.parse_command_line(
            ["--logging=warning", "--log_file_prefix=" + os.path.join(tmpdir, "tornado-test.log")]
        )
        enable_pretty_logging()
        # Make sure we got a file handler.
        assert isinstance(logging.getLogger().handlers[0], logging.FileHandler)
        # Make sure we don't get a stream handler.
        assert not isinstance(logging.getLogger().handlers[0], logging.StreamHandler)
        # Make sure a file was created.

# Generated at 2022-06-12 13:51:26.196887
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from unittest import TestCase

    class LogFormatterTest(TestCase):

        def test_LogFormatter(self):
            LogFormatter()

# Generated at 2022-06-12 13:52:38.742269
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.getLogger(__name__).info("Hallo Welt")
    assert __name__ == __name__
    #assert False, "help me with my assert"



# Generated at 2022-06-12 13:52:45.652940
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging(logger=logger)
    #logger.setLevel(logging.WARNING)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging(logger=logger)
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:52:51.122652
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import time, os
    import shutil
    # Create a temp working directory
    test_dir = os.path.join("./test_dir")
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)
    os.makedirs(test_dir)
    # Set up environment for testing Tornado option
    tornado.options.options.logging = "warning"
    tornado.options.options.log_to_stderr = True
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = os.path.getsize(__file__) + 1
    tornado.options.options.log_rotate_when = "S"

# Generated at 2022-06-12 13:52:56.635113
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=2, datefmt="a", colors={}, fmt="file_name")
    print(type(formatter))
    print(formatter._fmt)
    print(formatter.datefmt)
    print(formatter._colors)
    print(formatter._normal)
    print(formatter)


# Generated at 2022-06-12 13:53:00.921514
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s%(levelname)s%(end_color)s %(message)s"
    formatter = LogFormatter(fmt=fmt)
    assert formatter._fmt == fmt



# Generated at 2022-06-12 13:53:10.691079
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.logging = "debug"
    options.log_file_prefix = "tornado.log"
    options.log_rotate_mode = "time"
    options.log_rotate_when = "s"
    options.log_rotate_interval = 10
    options.log_file_num_backups = 10
    options.log_to_stderr = True
    logger = gen_log
    enable_pretty_logging(options, logger)
    logger.info("test log")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-12 13:53:19.473536
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class MockLogRecord(object):
        def __init__(self, msg: str) -> None:
            self.msg = msg
            self.levelno = logging.DEBUG
            self.exc_info = False
            self.exc_text = ""
        def getMessage(self) -> str:
            return self.msg

    # not color
    formatter = LogFormatter(color=False)
    record = MockLogRecord("test message")
    assert formatter.format(record) == "[D %(asctime)s %(module)s:%(lineno)d] test message"  # noqa: E501

    # color
    formatter = LogFormatter(color=True)
    record = MockLogRecord("test message")

# Generated at 2022-06-12 13:53:20.429230
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    assert LogFormatter()

# Generated at 2022-06-12 13:53:30.077840
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_log_file_prefix = "test_log.txt"
    test_log_rotate_mode = "size"
    test_log_file_max_size = 1024
    test_log_file_num_backups = 1
    test_log_rotate_when = "S"
    test_log_rotate_interval = 1
    test_log_to_stderr = True
    from tornado.options import options
    options.log_file_prefix = test_log_file_prefix
    options.log_rotate_mode = test_log_rotate_mode
    options.log_file_max_size = test_log_file_max_size
    options.log_file_num_backups = test_log_file_num_backups
    options.log_rotate_when = test_log

# Generated at 2022-06-12 13:53:31.718117
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

test_enable_pretty_logging()