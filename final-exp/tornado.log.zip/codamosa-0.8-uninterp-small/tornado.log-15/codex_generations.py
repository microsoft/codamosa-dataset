

# Generated at 2022-06-26 08:14:53.572594
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# Generated at 2022-06-26 08:14:55.183335
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()



# Generated at 2022-06-26 08:15:02.245349
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import sys

    # Create a basic logger object
    logger = logging.getLogger("TEST")
    logger.setLevel(logging.DEBUG)

    # Create a basic logging handler
    handler = logging.StreamHandler(sys.stdout)

    # Create a basic log formatter
    formatter = LogFormatter()

    # Add the logging handler and formatter to the logger
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Get the defined log formatter
    log_formatter = cast(LogFormatter, handler.formatter)

    # Write a log message
    logger.warning("this is a log message")


# Generated at 2022-06-26 08:15:07.429579
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.parse_command_line()
    enable_pretty_logging()
    app_log.info('%s', 'Hello, world!')

# Generated at 2022-06-26 08:15:12.894233
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_1 = LogFormatter()
    coerce_to_unicode_0 = log_formatter_1.format(None)
    coerce_to_unicode_1 = log_formatter_1.format(None)
    coerce_to_unicode_2 = log_formatter_1.format(None)


# Generated at 2022-06-26 08:15:18.020309
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("", 0, "", 0, "abc", {}, None)
    formatter.format(record)


# Generated at 2022-06-26 08:15:23.061048
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("logging", default=None, help="logging level")
    tornado.options.define("log_file_prefix", default=None, help="log file")

if __name__ == '__main__':
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:15:24.653798
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Check whether the output has been correctly logged.
    pass


# Generated at 2022-06-26 08:15:30.997191
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from logging import LogRecord
    from datetime import datetime
    import functools
    
    temp_datetime = datetime.now()
    
    record = LogRecord(name="name", level=logging.INFO, pathname="pathname", lineno=10, msg="msg", args=None, exc_info=None)
    record.created = temp_datetime.timestamp() # type: ignore
    record.msecs = temp_datetime.microsecond
    
    log_formatter = LogFormatter()
    
    log_formatter.format(record)

# Generated at 2022-06-26 08:15:38.864271
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.DEBUG, "", 0, "", (), None, None)
    ret_val = log_formatter_0.format(record)
    assert ret_val == "[DEBUG 0 tornado.access:0] "


# Generated at 2022-06-26 08:15:51.708764
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# To test the LogFormatter class, run this file with:
# python -m tornado.log
if __name__ == "__main__":
    test_LogFormatter()

# Generated at 2022-06-26 08:15:53.570098
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# Generated at 2022-06-26 08:15:54.956828
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Create object of class LogFormatter()
    test_case_0()

# Generated at 2022-06-26 08:16:08.964839
# Unit test for method format of class LogFormatter

# Generated at 2022-06-26 08:16:20.432924
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt="%y%m%d %H:%M:%S"
    style="%"
    color=True
    colors = {logging.DEBUG: 4,  # Blue
              logging.INFO: 2,  # Green
              logging.WARNING: 3,  # Yellow
              logging.ERROR: 1,  # Red
              logging.CRITICAL: 5,  # Magenta
    }
    log_formatter_0 = LogFormatter(fmt,datefmt,style,color,colors)


# Generated at 2022-06-26 08:16:22.002010
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_case_0()


# Generated at 2022-06-26 08:16:28.390894
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    fmt_0 = log_formatter_0._fmt
    assert fmt_0 == LogFormatter.DEFAULT_FORMAT
    datefmt_0 = log_formatter_0.datefmt
    assert datefmt_0 == LogFormatter.DEFAULT_DATE_FORMAT
    colors_0 = log_formatter_0._colors
    assert colors_0 == LogFormatter.DEFAULT_COLORS

    fmt_1 = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    datefmt_1 = "%y%m%d %H:%M:%S"

# Generated at 2022-06-26 08:16:33.353045
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    channel_0 = logging.StreamHandler()
    channel_0.setFormatter(LogFormatter())
    old_handlers = logging.getLogger().handlers
    logging.getLogger().handlers = []
    try:
        enable_pretty_logging()
        assert logging.getLogger().handlers == [channel_0]
    finally:
        logging.getLogger().handlers = old_handlers


# Generated at 2022-06-26 08:16:37.893766
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        log_formatter_0 = LogFormatter()
    except:
        print("LogFormatter() failed!")
        return 1
    return 0



# Generated at 2022-06-26 08:16:39.462223
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(logger=None)

# Generated at 2022-06-26 08:16:58.119002
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options
    options.logging = "DEBUG"
    options.log_file_prefix = ""
    enable_pretty_logging(options=options)

# Generated at 2022-06-26 08:17:07.475054
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = 'enable_pretty_logging.log'
    tornado.options.options.log_rotate_mode = 'time'
    tornado.options.options.log_rotate_when = 's'
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 3
    logger = logging.getLogger()
    enable_pretty_logging(logger = logger)
    logger.debug(message = 'debug')
    logger.info(message = 'info')
    logger.warning(message = 'warning')
    logger.error(message = 'error')
    logger.critical(message = 'critical')
    import time
   

# Generated at 2022-06-26 08:17:15.913961
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # create a log_formatter object
    log_formatter = LogFormatter()  
    # create a record object
    record = logging.LogRecord(
        name=__name__,
        level=logging.INFO,
        pathname=".",
        lineno=0,
        msg="hello world",
        args=None,
        exc_info=None,
    )
    s = log_formatter.format(record)
    assert isinstance(s, str)


# Generated at 2022-06-26 08:17:28.198513
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.logging = "WARN"
    enable_pretty_logging()
    logger = logging.getLogger()
    if len(logger.handlers) != 2:
        raise ValueError("Fail")
    if not isinstance(logger.handlers[0], logging.FileHandler):
        raise ValueError("Fail")
    if not isinstance(logger.handlers[1], logging.StreamHandler):
        raise ValueError("Fail")

# Generated at 2022-06-26 08:17:33.023134
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options

    options.log_to_stderr = True
    options.log_file_prefix = 'tornado.log'
    options.log_file_num_backups = 1 # 0: no backups to be made
    options.log_rotate_mode = 'time' # 'size': rotate by size, 'time': rotate by time
    options.log_rotate_when = 'D' # 'M'(Minute), 'H'(Hour), 'D'(Day), 'MIDNIGHT'(0:00)
    options.log_rotate_interval = 0 # rotate every x day for mode='D'
    options.log_file_max_size = 10000 # rotate if log size exceeds x bytes for mode='size'
    options.logging = 'debug' # 'debug', 'info',

# Generated at 2022-06-26 08:17:33.960166
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_LogFormatter_0()
    test_LogFormatter_1()

# constructor: 1 args

# Generated at 2022-06-26 08:17:39.574593
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, "DEBUG"))
    channel = logging.StreamHandler()
    channel.setFormatter(LogFormatter())
    logger.addHandler(channel)

    logger.info("This is INFO")
    logger.debug("This is DEBUG")
    logger.warning("This is WARNING")
    logger.error("This is ERROR")

if __name__ == '__main__':
    #test_enable_pretty_logging()
    test_case_0()

# Generated at 2022-06-26 08:17:41.698178
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-26 08:17:53.119408
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    class DummyOptions:
        log_file_prefix = "my_log.txt"
        log_rotate_mode = "time"
        log_rotate_when = "midnight"
        log_rotate_interval = 1
        log_file_num_backups = 5
        logging = "debug"
        log_to_stderr = True
    options = DummyOptions()
    assert options.log_file_prefix == "my_log.txt"
    assert options.log_rotate_mode == "time"
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_file_num_backups == 5
    assert options.logging == "debug"
    assert options.log_to_

# Generated at 2022-06-26 08:18:04.226592
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("logging", default="none")
    tornado.options.define("log_file_prefix", default="")
    tornado.options.define("log_rotate_mode", default="time")
    tornado.options.define("log_rotate_when", default="midnight")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.define("log_file_num_backups", default=10)
    tornado.options.define("log_file_max_size", default=1024 * 1024 * 2)
    tornado.options.define("log_to_stderr", default=None)

    logger_0 = logging.getLogger()
    
    enable_pretty_logging(logger=logger_0)
    pass



# Generated at 2022-06-26 08:18:50.895280
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord('0', '0', '0', 0, '0', '0', '0', '0')
    test_LogFormatter_format_assert(log_formatter_0, record_0)



# Generated at 2022-06-26 08:18:53.922148
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    # enable_pretty_logging()
    pass

# Generated at 2022-06-26 08:19:05.570344
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._colors == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    assert log_formatter._normal == ""

    colors2 = {logging.DEBUG: 4, logging.INFO: 2}
    log_formatter2 = LogFormatter(colors=colors2)
    assert log_formatter2._colors == colors2
    assert log_formatter2._normal == ""



# Generated at 2022-06-26 08:19:15.176751
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """Test for function enable_pretty_logging
    """
    class options:
        logging = 'none'
        log_file_prefix = 0
        log_rotate_mode = 'size'
        log_file_max_size = 100
        log_file_num_backups = 1
        log_to_stderr = 0
    logger = logging.getLogger()
    enable_pretty_logging(options, logger)

# Generated at 2022-06-26 08:19:28.928745
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter0 = LogFormatter()
    assert repr(formatter0) == '<tornado.log.LogFormatter object at 0x7f813dadd518>'
    assert isinstance(formatter0._normal, unicode_type)

    formatter1 = LogFormatter(fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
                            datefmt='%y%m%d %H:%M:%S', style='%', color=True, colors={10:4})
    assert repr(formatter1) == '<tornado.log.LogFormatter object at 0x7f813dadd518>'

# Generated at 2022-06-26 08:19:42.148774
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os
    from time import time
    options.log_file_prefix = "test/logging.%s" % time()
    options.log_file_max_size = 1024 * 1024
    options.log_file_num_backups = 5
    options.log_file_rotate_mode = "size"
    options.logging = "debug"
    if os.path.exists("test/logging.%s" % time()):
        os.remove("test/logging.%s" % time())
    enable_pretty_logging(options)
    app_log.info("test")
    if os.path.exists("test/logging.%s" % time()):
        os.remove("test/logging.%s" % time())

# Generated at 2022-06-26 08:19:42.886349
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-26 08:19:52.071435
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def test_logger_0(msg: str, *args: object, **kwargs: object) -> None:
        logging.Logger.info(app_log, msg, *args, **kwargs)
    test_logger_0("test_msg_0")

if __name__ == "__main__":
    test_case_0()
    test_LogFormatter_format()

# Generated at 2022-06-26 08:19:53.500487
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0();


# Generated at 2022-06-26 08:20:00.701843
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None)
    rotate_mode = "size"
    options = {
        'logging': 'debug',
        'log_file_prefix': 'test.log',
        'log_rotate_mode': rotate_mode,
    }
    options = type('options', (), options)
    # The value of log_rotate_mode option should be "size" or "time", not "size"
    try:
        enable_pretty_logging(options)
    except ValueError:
        pass

# Generated at 2022-06-26 08:20:28.777285
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test constructor with no args
    log_formatter_0 = LogFormatter()


# Generated at 2022-06-26 08:20:37.565047
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.log import LogFormatter

    import logging
    import logging.handlers

    log_formatter = LogFormatter()

    log_file = 'app.log'

    my_logger = logging.getLogger('MyLogger')
    my_logger.setLevel(logging.DEBUG)

    handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=2000, backupCount=5)

    # formatter
    handler.setFormatter(log_formatter)

    my_logger.addHandler(handler)

    my_logger.debug('debug message')
    my_logger.info('info message')
    my_logger.warning('warn message')
    my_logger.error('error message')
    my_logger.critical('critical message')

test_LogFormatter

# Generated at 2022-06-26 08:20:46.955952
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """
    Run: 
    mypy tornado.log
    to test typing of tornado.log.
    """
    import tornado.options

    # Set up options
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_to_stderr", default=True)
    tornado.options.define("log_file_prefix")
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_rotate_mode", default="size")
    tornado.options.define("log_rotate_when", default="H")
    tornado.options.define("log_rotate_interval", type=int)

    tornado.options.parse_command_line()

# Generated at 2022-06-26 08:20:54.632040
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter is not None

    log_formatter = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        style="%",
        color=False,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        },
    )
    assert log_formatter is not None

    log_form

# Generated at 2022-06-26 08:21:03.901981
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_1 = LogFormatter(fmt="format", datefmt="2018-11-19")
    # test that the private fields have been populated as expected
    fmt = log_formatter_1._fmt  # type: str
    assert fmt == "format"
    datefmt = log_formatter_1.datefmt  # type: str
    assert datefmt == "2018-11-19"


# Generated at 2022-06-26 08:21:10.349448
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    _logFormatter_0 = LogFormatter()
    # _logFormatter_0.format(None)


# Tornado's `.options` module (and the `parse_command_line` and
# `parse_config_file` functions) configures logging automatically using
# the following logic.  The defaults here are different from the
# defaults for the logging module, which is configured by
# `logging.basicConfig` (called from `tornado.options`).
#
# The default logging output (to stderr) is different from the logging
# module's default.  Tornado writes one line per log message, to better
# support log files that will be read by humans.  By contrast, the
# logging module's default format is better for machines (or people who
# are very familiar with python logging).
#
# Logging to a file makes sense, but logging

# Generated at 2022-06-26 08:21:10.911957
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()



# Generated at 2022-06-26 08:21:13.081034
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()



# Generated at 2022-06-26 08:21:14.632864
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()



# Generated at 2022-06-26 08:21:20.315665
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options = "tornado.options"
    tornado.options.options.logging = "INFO"
    tornado.options.options.log_file_prefix = "log_file_prefix"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = "log_file_max_size"
    tornado.options.options.log_file_num_backups = "log_file_num_backups"

    logger = logging.getLogger()
    enable_pretty_logging(tornado.options.options, logger)

if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:22:43.013134
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_format_data = {
        'levelno': 20,
        'color': '\x1b[24m',
        'asctime': '20190731 03:49:24',
        'end_color': '\x1b[0m',
        'message': 'Hello world',
        'module': '__main__',
        'filename': 'log.py',
        'lineno': 100,
    }
    log_formatter_0 = LogFormatter()
    log_formatter_0.format(log_format_data)


# Generated at 2022-06-26 08:22:49.223138
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options

    options.logging = 'debug'
    options.log_file_prefix = 'C:\\Users\\fei.ding\\Desktop\\logfile.txt'
    options.log_rototate_mode = 'time'
    options.log_rotate_interval = 'S'

    logger = logging.getLogger()
    enable_pretty_logging(options, logger)

    # log record instance
    record = logging.LogRecord('tornado.general','DEBUG',None,0,
                                'Debug message!',None,None,None)

    logger.handle(record)

# Generated at 2022-06-26 08:22:54.373577
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options

    # Enable debug level logging
    options.logging = "DEBUG"
    enable_pretty_logging(options)

    # Write a message to the log file
    app_log.debug("Unit test method test_enable_pretty_logging")


# Generated at 2022-06-26 08:23:01.350618
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    global log_formatter
    global x
    gen_log.info("Logging initialization:")
    log_formatter = LogFormatter()
    for x in range(0, 30):
        gen_log.info(
            "============================================================="
        )

# Generated at 2022-06-26 08:23:11.074835
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert _stderr_supports_color() == True
    assert LogFormatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert LogFormatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert LogFormatter.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}

    if True:
        log_formatter = LogFormatter()
        assert log_formatter != None
        assert isinstance(log_formatter, logging.Formatter)

        assert log_

# Generated at 2022-06-26 08:23:13.594414
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = 10
    enable_pretty_logging(options)

# Generated at 2022-06-26 08:23:15.868396
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter is not None


# Generated at 2022-06-26 08:23:25.810073
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options

    define("logging", default="None")
    define("log_file_prefix", default="./logs/test_enable_pretty_logging")
    print("options.logging = {}".format(options.logging))
    print("options.log_file_prefix = {}".format(options.log_file_prefix))
    enable_pretty_logging(options)


# Generated at 2022-06-26 08:23:30.734472
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    assert isinstance(log_formatter_0._colors, dict)
    assert isinstance(log_formatter_0, logging.Formatter)
    assert log_formatter_0._colors == {}
    assert log_formatter_0._normal == ""
    assert isinstance(log_formatter_0, LogFormatter)



# Generated at 2022-06-26 08:23:37.769584
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    assert log_formatter_0.datefmt == "%y%m%d %H:%M:%S"
    assert log_formatter_0._colors == {}
    assert log_formatter_0._normal == ""
    assert log_formatter_0.formatTime(None, '%y%m%d %H:%M:%S') == log_formatter_0._formatter.formatTime(None)
    assert log_formatter_0.formatException(Exception()) == log_formatter_0._formatter.formatException(Exception())
    assert log_formatter_0.formatMessage(None) == log_formatter_0._formatter.formatMessage(None)

    # Test for colorama
    colorama_0_init(None)
    log_