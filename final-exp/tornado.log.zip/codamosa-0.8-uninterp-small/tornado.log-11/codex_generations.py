

# Generated at 2022-06-26 08:15:02.321865
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    define_logging_options()
    logger = logging.getLogger('A')
    logger.setLevel(logging.DEBUG)
    class Record(object):
        def __init__(self) -> None:
            self.levelno = logging.DEBUG
            self.name = 'A'
            self.filename = 'test'
            self.pathname = 'test'
            self.module = 'test'
            self.funcName = 'test'
            self.lineno = 0
            self.created = 0.0
            self.asctime = '1'
            self.msecs = '1'
            self.message = 'hello'
    formatter = LogFormatter()
    record = Record()
    formatter.format(record)



# Generated at 2022-06-26 08:15:04.462463
# Unit test for function define_logging_options
def test_define_logging_options():
    test_case_0()

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-26 08:15:14.935913
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()

    assert lf.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" # noqa: E501
    assert lf.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert lf.DEFAULT_COLORS == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }


# Generated at 2022-06-26 08:15:20.295455
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord('name', 'INFO', 'pathname', 0, 'message', None, None)
    # TODO need coverage
    print(formatter.format(record))


# Generated at 2022-06-26 08:15:23.062747
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_LogFormatter_0()
    test_LogFormatter_1()
    test_LogFormatter_2()


# Generated at 2022-06-26 08:15:27.300703
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    color = True
    colors = {
        logging.DEBUG: 4 ,
        logging.INFO: 2,
        logging.WARNING: 3,
        logging.ERROR: 1,
        logging.CRITICAL: 5
    }
    fmt = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    formatter = LogFormatter(color=color, colors=colors, fmt=fmt, datefmt=datefmt)



# Generated at 2022-06-26 08:15:30.617026
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.makeLogRecord({"msg": "test"})
    formatter.format(record)



# Generated at 2022-06-26 08:15:39.667083
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_file_prefix", type=str, default="", help="")
    tornado.options.define("log_file_max_size", type=int, default=100, help="")
    tornado.options.define("log_file_num_backups", type=int, default=10, help="")
    tornado.options.define("log_to_stderr", type=bool, default=False, help="")
    tornado.options.define("logging", type=str, default="none", help="")
    tornado.options.define("log_rotate_mode", type=str, default="size", help="")
    tornado.options.define("log_rotate_when", type=str, default="midnight", help="")

# Generated at 2022-06-26 08:15:47.996832
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger("tornado.test")
    logger.setLevel(logging.DEBUG)
    lf = LogFormatter(color=True, fmt="%(color)s%(message)s%(end_color)s")
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(lf)
    logger.propagate = False
    logger.addHandler(ch)
    logger.info("info")
    logger.debug("debug")


# Generated at 2022-06-26 08:15:50.636700
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    enable_pretty_logging(options)


# Generated at 2022-06-26 08:16:05.403119
# Unit test for function define_logging_options
def test_define_logging_options():
    try:
        test_case_0()
    except Exception:
        import traceback
        err = traceback.format_exc()
        print(err)
test_define_logging_options()

# Generated at 2022-06-26 08:16:08.588050
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logf = LogFormatter()
    assert(logf._fmt == logf.DEFAULT_FORMAT)
    assert(logf._colors == {})
    assert(logf._normal == "")

# Generated at 2022-06-26 08:16:15.531686
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.parse_command_line()
    mr = tornado.log.enable_pretty_logging()
    print(mr)
    mr = tornado.options.options.logging
    print(mr)
    return



# Generated at 2022-06-26 08:16:20.966523
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(name="index", level = logging.ERROR, 
    pathname="/home/wuxinyu/tornado-4.5.3/tornado/log.py", lineno=21,
    msg="five", args=None, exc_info=None)
    print(log_formatter.format(record))


# Generated at 2022-06-26 08:16:22.690673
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()


# Generated at 2022-06-26 08:16:23.527811
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter != None


# Generated at 2022-06-26 08:16:31.080569
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # init a LogFormatter instance
    obj = LogFormatter()
    record = logging.LogRecord(
        name="name",
        level=logging.INFO,
        pathname="pathname",
        lineno=1,
        msg="msg",
        args=(),
        exc_info=None,
    )
    assert obj.format(record)=="[I 20190821 00:00:00 pathname:1] msg"


# Generated at 2022-06-26 08:16:41.198856
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()
    assert logFormatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s " \
                                "%(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert logFormatter._colors == {4: 4, 2: 2, 3: 3, 1: 1, 5: 5}
    assert logFormatter._normal == ""



# Generated at 2022-06-26 08:16:52.857808
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    assert fmt.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert fmt.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert fmt.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}


# Generated at 2022-06-26 08:17:03.454028
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = '%y%m%d %H:%M:%S'
    style = '%'
    color = False
    colors = {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}
    LF = LogFormatter(fmt, datefmt, style, color, colors)
    assert LF is not None
