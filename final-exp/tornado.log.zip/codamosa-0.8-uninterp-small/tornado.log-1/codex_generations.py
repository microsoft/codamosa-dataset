

# Generated at 2022-06-26 08:14:56.505969
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # LogFormatter(fmt=DEFAULT_FORMAT, datefmt=DEFAULT_DATE_FORMAT,
    # style='%', color=True, colors=DEFAULT_COLORS)
    logging_formatter = LogFormatter()

    # in default setting of LogFormatter,
    # logging.DEBUG is set to 4,  # Blue
    # so the corresponding color for record.levelno should be "\033[2;34m"
    record = logging.LogRecord('tornado.application', logging.DEBUG,
                               'N/A', -1, 'test', None, None)
    formatted_string = logging_formatter.format(record)

# Generated at 2022-06-26 08:14:58.985411
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:15:03.923206
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "{0}-{1}-{2}".format
    formatter = LogFormatter(fmt=fmt)
    record = logging.LogRecord(None, logging.DEBUG, "", 0, "aaaa", None, None)
    s = formatter.format(record)
    assert s == "aaaa"


# Generated at 2022-06-26 08:15:14.988083
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        class MyHandler(logging.Handler):
            def handle(self, record: Any) -> None:
                pass

            def emit(self, record: Any) -> int:
                return 0

            def createLock(self) -> Any:
                pass

        handler = MyHandler()
        handler.setLevel(0)
        handler.setFormatter(LogFormatter())
        access_log.handlers = []
        access_log.addHandler(handler)
        access_log.setLevel(0)
        access_log.debug("foo")
    except Exception as e:
        print("Exception test_LogFormatter_format: \n{}".format(e))


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-26 08:15:22.609087
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    print(lf)
    print(lf._colors)
    lf = LogFormatter(fmt="format", color=False)
    print(lf)
    print(lf._colors)
    lf = LogFormatter(fmt="format", color=True)
    print(lf)
    print(lf._colors)




# Generated at 2022-06-26 08:15:30.300377
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter

    record = logging.LogRecord(
        'tornado.general', logging.INFO,
        'C:\Python36\lib\site-packages\tornado\web.py',
        '2644', None, None, None,
        'An uncaught exception in %s',
        args=('tornado.access',), exc_info=None)
    formatter = LogFormatter()
    result = formatter.format(record)
    expected = '[I '\
               '20170828 18:35:41 tornado.web:2644] An uncaught exception in tornado.access'
    assert result == expected



# Generated at 2022-06-26 08:15:39.556239
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Create handlers
    c_handler = logging.StreamHandler()
    c_handler.setLevel(logging.DEBUG)

    # Create formatters and add it to handlers
    c_format = LogFormatter(fmt='%(color)s%(asctime)s %(levelname)s %(message)s%(end_color)s', datefmt='%d-%b-%y %H:%M:%S')
    c_handler.setFormatter(c_format)

    # Add handlers to the logger
    logger.addHandler(c_handler)

    logger.info('Success')
    logger.warning('Success')
    logger.error('Success')
    logger

# Generated at 2022-06-26 08:15:41.882807
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 08:15:47.247339
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    # Test setters and getters
    assert log_formatter._normal == ""
    log_formatter._fmt = "-----"
    assert log_formatter._fmt == "-----"
    log_formatter._colors = {} 
    assert log_formatter._colors == {}


# Generated at 2022-06-26 08:15:52.152836
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(fmt="test_fmt", datefmt="test_datefmt", style="test_style", color=True)  # noqa: E501
    log_formatter.format({})



# Generated at 2022-06-26 08:16:18.610152
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord(
        'test',
        logging.DEBUG,
        'n/a',
        0,
        'test_log',
        (),
        exc_info=None,
    )) == '[D test_log] test_log'


# Generated at 2022-06-26 08:16:21.692546
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    tfmt = LogFormatter()
    print(tfmt)
    print(tfmt.formatTime)


# Generated at 2022-06-26 08:16:33.578784
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    # test parse_command_line
    options = tornado.options.OptionParser().parse_command_line(
        ["--logging=debug", "--log_file_prefix=test.log"]
    )
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, options.logging.upper()))
    channel = logging.StreamHandler()
    channel.setFormatter(LogFormatter())
    logger.addHandler(channel)
    logger.critical("critical")

    stream = open("test.log").read()
    s = stream.split("\n")

    if s[-2].find("critical") >= 0:
        print("test_enable_pretty_logging() test_case_0 passed")

# Generated at 2022-06-26 08:16:46.949242
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # test case 0
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    logFormatter = LogFormatter(fmt=fmt, datefmt=datefmt, style=style, color=color, colors=colors)
    record = logging.LogRecord("tornado.access", logging.DEBUG, "/home/winty/workspace/pylearn/tornado-4.5.2/tornado/web.py", 30, "127.0.0.1 - - [04/Jul/2017 02:47:31] \"GET /favicon.ico HTTP/1.1\" 404 209", [], None)

    res = logFormatter.format

# Generated at 2022-06-26 08:16:52.777527
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    color = True
    log_formatter = LogFormatter(fmt, datefmt, colors=colors, color=color)



# Generated at 2022-06-26 08:16:54.363491
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logi = LogFormatter()



# Generated at 2022-06-26 08:17:01.280720
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    # set up console output
    console = logging.StreamHandler()
    formatter = LogFormatter()
    console.setFormatter(formatter)
    logger.addHandler(console)

    logger.error('test error')


# Generated at 2022-06-26 08:17:02.346094
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-26 08:17:16.669389
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test cases
    #   1. record.exc_text is None
    #   2. record.exc_text is str
    #   3. record.exc_text is unicode_type
    #   4. record.exc_text contains multiple lines.
    #   5. record.exc_text contains non-utf8 bytes.
    class TestRecord(object):
        def __init__(self):
            self.__dict__ = {}
        @property
        def exc_info(self):
            return None
    fmt = LogFormatter()
    # test case 1
    record = TestRecord()
    record.exc_text = None
    assert fmt.format(record) == ''

    # test case 2
    record.exc_text = 'a'
    assert fmt.format(record) == 'a'

    # test case 3

# Generated at 2022-06-26 08:17:21.648690
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    msg = "hello"
    record = logging.makeLogRecord({"message": msg})
    fmt = LogFormatter(fmt="%(message)s")
    assert fmt.format(record) == msg


# Generated at 2022-06-26 08:17:38.734313
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado import escape
    import io
    import sys

    buf = io.StringIO()
    stderr = sys.stderr
    try:
        # patch sys.stderr with our StringIO
        sys.stderr = buf

        enable_pretty_logging()
        gen_log.warning("I am a pretty log.")

        result = escape.native_str(buf.getvalue())

        if (result.find("I am a pretty log.") != -1):
            print("test_LogFormatter passed")
        else:
            print("test_LogFormatter failed")
    finally:
        # unpatch sys.stderr
        sys.stderr = stderr



# Generated at 2022-06-26 08:17:44.718761
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        style="%",
        color=True,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        })


# Generated at 2022-06-26 08:17:58.762071
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log
    import unittest
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import gen_log

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            gen_log.propagate = False
            gen_log.handlers = []
            access_log.propagate = False
            access_log.handlers = []
            self.gen_handler = logging.StreamHandler()
            gen_log.addHandler(self.gen_handler)
            self.access_handler = logging.StreamHandler()
            access_log.addHandler(self.access_handler)
            self.test_handler = logging.StreamHandler()
            self.test_logger = logging.getLogger("test_logger")
            self.test_

# Generated at 2022-06-26 08:18:12.461083
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # test args of LogFormatter
    os.environ['TZ'] = 'UTC'
    time.tzset()

    fmt = '%(color)s[%(levelname)-18s %(asctime)s %(module)s:%(lineno)d]%' \
          '(end_color)s %(message)s'
    datefmt = '%y%m%d %H:%M:%S'
    style = '%'
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    # test default args
    log_formatter = LogForm

# Generated at 2022-06-26 08:18:19.243836
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_record = FormatterLogRecord("test_msg")
    log_formatter = LogFormatter()
    assert log_formatter.format(log_record) == "[I 20000101 00:00:00 test_logger:0] test_msg\n    "


# Generated at 2022-06-26 08:18:20.109709
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:25.475868
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.ioloop
    import time
    try:
        tornado.ioloop.PeriodicCallback(test_case_0, 1000).start()
        tornado.ioloop.IOLoop.current().start()
    except KeyboardInterrupt:
        print("received ctrl + c ...")
    except Exception as e:
        print("Error: %s" % str(e))
    finally:
        tornado.ioloop.IOLoop.current().stop()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:29.621504
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.testing

    class OptionsTest(tornado.testing.AsyncTestCase):
        def test_define_logging_options(self):
            options = tornado.options.OptionParser()
            define_logging_options(options)
            options.parse_command_line(['--log_file_prefix', 'test_log.txt'])

    tornado.testing.main()

if __name__ == '__main__':
    test_case_0()
    test_define_logging_options()

# Generated at 2022-06-26 08:18:36.050729
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger_name = "test_LogFormatter_format"
    record = logging.LogRecord(
        logger_name,
        logging.INFO,
        pathname=None,
        lineno=1,
        msg="test message",
        args=None,
        exc_info=None,
    )
    log_formatter = LogFormatter()
    log_formatter.format(record)
    record.exc_info = "exceptions"
    log_formatter.format(record)


# Generated at 2022-06-26 08:18:38.009354
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()



# Generated at 2022-06-26 08:18:53.755493
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """Unit test for method format of class LogFormatter"""
    log_formatter_0 = LogFormatter()
    log_record_0 = logging.LogRecord(
        name="tornado.application",
        level=20,
        pathname="",
        lineno=0,
        msg="",
        args=None,
        exc_info=None,
    )
    print(log_formatter_0.format(log_record_0))

# Generated at 2022-06-26 08:19:05.502819
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    # Generate a log record
    log_record_0 = logging.LogRecord("logger_0", logging.DEBUG, "pathname_0", 42, "message_0", None, None)

    # Initialize log formatter
    log_formatter_0 = LogFormatter()

    # Call the method
    actual_result = log_formatter_0.format(log_record_0)

    # Check result
    expected_result = "[D  0101 00:00:00 root:42] message_0"
    assert actual_result == expected_result

if __name__ == "__main__":
    # Run the tests from the command line
    test_LogFormatter_format()

# Generated at 2022-06-26 08:19:10.363099
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    crt_log_record = log_formatter_0.format(runtime_test_case_0)
    # Put your test here
    assert True


# Generated at 2022-06-26 08:19:11.226285
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)


# Generated at 2022-06-26 08:19:22.485191
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test case 1:
    log_formatter_0 = LogFormatter()
    log_record_0 = logging.LogRecord(
        name = 'name_0',
        level = logging.DEBUG,
        pathname = 'pathname_0',
        lineno = 4,
        msg = 'msg_0',
        args = (),
        exc_info = (),
    )
    try:
        log_formatter_0.format(log_record_0)
    except Exception as e:
        print(
            'Exception caught when calling LogFormatter.format() to ' +
            'test case 1:\n', e
        )
    # Test case 2:
    log_formatter_0 = LogFormatter()

# Generated at 2022-06-26 08:19:31.062120
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if sys.platform == "win32":
        # colorama is required to support color on windows
        import colorama  # type: ignore
        colorama.init()
    logging.basicConfig(format="%(color)s%(levelname)s:%(end_color)s %(message)s")
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Messages are formatted, then sent to the log handler, then sent to the
    # logging infrastructure.
    #
    # Test the formatting with print messages
    msg = "test"
    logger.debug(msg)
    logger.info(msg)
    logger.warning(msg)
    logger.error(msg)
    logger.critical(msg)
    # Test the formatting with logging messages

# Generated at 2022-06-26 08:19:39.793902
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord(
        "tornado.access",
        logging.INFO,
        None,
        None,
        "home",
        dict(),
        None,
        None,
    )
    expected_0 = "[I home] home"
    actual_0 = log_formatter_0.format(record_0)
    assert actual_0 == expected_0


# Generated at 2022-06-26 08:19:51.983497
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.logging = "debug"
    options.log_file_prefix = "./"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 10
    options.log_file_num_backups = 3
    options.log_to_stderr = False
    enable_pretty_logging()


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:19:53.363578
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:20:00.427840
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "tornado.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 20000000
    options.log_file_num_backups = 10
    options.log_to_stderr = False
    # Calling enable_pretty_logging
    enable_pretty_logging()


# Generated at 2022-06-26 08:20:13.909955
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
        # options is a tornado.options.options object
        options = tornado.options.options
        print(type(options))
        print(options.keys())
        print(options.logging)
        # Use default values of the options object to construct a logger
        enable_pretty_logging(options)
    except Exception as e:
        print(e)


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:20:25.853201
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    log_formatter_1 = LogFormatter()
    if (not hasattr(log_formatter_1, '_fmt')):
        raise ValueError('_fmt not found in LogFormatter')
    log_formatter_1._fmt = log_formatter_0._fmt
    if (not hasattr(log_formatter_1, '_normal')):
        raise ValueError('_normal not found in LogFormatter')
    log_formatter_1._normal = log_formatter_0._normal
    if (not hasattr(log_formatter_1, '_colors')):
        raise ValueError('_colors not found in LogFormatter')
    log_formatter_1._colors = log_formatter_0._colors
    record_

# Generated at 2022-06-26 08:20:28.930583
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # With default args
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 08:20:31.089000
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test basic functionality of LogFormatter.format
    assert True


# Generated at 2022-06-26 08:20:38.945982
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    logger_0 = logging.getLogger()
    # test if function enable_pretty_logging accepts no parameter
    try:
        enable_pretty_logging()
    except Exception as e:
        raise ValueError("Expect: no exception; Actual: %s" % e)
    # test if function enable_pretty_logging accepts 1 parameters
    try:
        enable_pretty_logging(logger=logger_0)
    except Exception as e:
        raise ValueError("Expect: no exception; Actual: %s" % e)
    # test if function enable_pretty_logging accepts 2 parameters

# Generated at 2022-06-26 08:20:42.068768
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

if __name__ == '__main__':
    test_LogFormatter()

# Generated at 2022-06-26 08:20:44.247282
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """Test and show some features of LogFormatter.
    """
    log_formatter = LogFormatter()
    gen_log.debug("Testing Testing")

# test_LogFormatter()

# Generated at 2022-06-26 08:20:57.047036
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    from tornado.log import LogFormatter, access_log
    import tempfile

    with tempfile.TemporaryFile() as tmp:
        tf = logging.StreamHandler(tmp)
        log_formatter = LogFormatter()
        tf.setFormatter(log_formatter)
        access_log.addHandler(tf)
        access_log.setLevel(logging.DEBUG)
        access_log.warning("Warning message %s","test")
        tmp.seek(0)
        read_value = tmp.read().decode(encoding='utf-8')
        assert read_value.startswith(
            "\x1b[93m[W " + datetime.now().strftime('%y%m%d %H:%M:%S')
        ) is True
        assert read_

# Generated at 2022-06-26 08:21:08.288814
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    # Test case with class LogFormatter: When we directly give the parameter
    # 'message' as a Unicode value.
    log_formatter_1 = LogFormatter()
    record_1 = recordMock()
    record_1.msg = "„“"
    log_formatter_1.format(record_1)

    # Test case with class LogFormatter: When we directly give the parameter
    # 'message' as a Unicode value.
    log_formatter_2 = LogFormatter()
    record_2 = recordMock()
    record_2.msg = "ABC"
    log_formatter_2.format(record_2)

    # Test case with class LogFormatter: When 'message' is a Unicode value
    # and message.getMessage() throws an Exception.
    log_formatter_3 = LogForm

# Generated at 2022-06-26 08:21:15.257459
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test the case when the logging option is set to "none"
    import tornado.options
    import tornado.options
    tornado.options.options.logging = "none"
    enable_pretty_logging()

    # Test the case when the logging option is set to an invalid value
    tornado.options.options.logging = "invalid_value"
    try:
        enable_pretty_logging()
        assert False
    except ValueError:
        # Expected
        pass

    # Test the case when the logging option is not set to "none", and
    # log_to_stderr is set to False
    tornado.options.options.logging = "warning"
    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()


    # Test the case when the logging option is not

# Generated at 2022-06-26 08:21:40.386649
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Arrange
    # Act
    log_formatter_0 = LogFormatter()
    # Assert
    assert log_formatter_0 is not None
    assert log_formatter_0._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter_0.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert log_formatter_0._colors == LogFormatter.DEFAULT_COLORS
    assert log_formatter_0._normal == "\033[0m"


# Generated at 2022-06-26 08:21:43.768119
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    flag = False
    try:
        test_case_0()
    except:
        flag = False
    assert flag



# Generated at 2022-06-26 08:21:50.507475
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Construct a logger
    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.debug("Test debug")
    logger.info("Test info")
    logger.warning("Test warning")
    logger.error("Test error")


# Generated at 2022-06-26 08:22:03.147095
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord('a', 0, 'a', 0, 'a', (), (), None)
    record_0.levelname = 'a'
    record_0.filename = 'a'
    record_0.lineno = 0
    record_0.exc_info = None
    record_0.funcName = 'a'
    record_0.msg = 'a'
    record_0.args = ()
    record_0.exc_text = None
    record_0.module = 'a'
    record_0.name = 'a'
    record_0.pathname = 'a'
    record_0.process = 0
    record_0.processName = 'a'
    record_0.relativeCreated = 0

# Generated at 2022-06-26 08:22:05.400940
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:22:09.365405
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()


# Generated at 2022-06-26 08:22:13.201638
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = None
    enable_pretty_logging()
    tornado.options.options.logging = 'info'
    enable_pretty_logging()
    tornado.options.options.logging = 'debug'
    enable_pretty_logging()


# Generated at 2022-06-26 08:22:16.666830
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "DEBUG"
    enable_pretty_logging()


# Generated at 2022-06-26 08:22:25.706597
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    LogFormatter()
    # Check if the approriate exceptions are thrown
    error_message = (
        "The value of log_rotate_mode option should be "
        + '"size" or "time", not "%s".' % "abc"
    )
    try:
        tornado.options.parse_command_line(
            args=["--logging=critical", "--log_file_prefix=log.txt", "--log_rotate_mode=abc"]
        )
        enable_pretty_logging()
    except ValueError as err:
        assert str(err) == error_message

    tornado.options.parse_command_line(
        args=["--logging=critical", "--log_file_prefix=log.txt", "--log_rotate_mode=size"]
    )

# Generated at 2022-06-26 08:22:34.928274
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("logging", "", "", "str")
    tornado.options.define("log_file_prefix", None, "", "str")
    tornado.options.define("log_to_stderr", None, "", "bool")
    tornado.options.define("log_rotate_mode", "size", "", "str")
    tornado.options.define("log_rotate_when", "midnight", "", "str")
    tornado.options.define("log_rotate_interval", 1, "", "int")
    tornado.options.define("log_file_max_size", 104857600, "", "int")
    tornado.options.define("log_file_num_backups", 1000, "", "int")
    enable_pretty_logging()


# Generated at 2022-06-26 08:23:50.099407
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    opts = tornado.options.options
    opts.logging = "info"
    opts.log_file_prefix = "my_log_file"
    opts.log_rotate_mode = "size"
    opts.log_file_max_size = 5
    opts.log_file_num_backups = 2
    opts.log_to_stderr = False

    enable_pretty_logging()


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:23:52.846464
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

if __name__ == "__main__":
    test_LogFormatter()

# Generated at 2022-06-26 08:24:02.968154
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_file_prefix", default=None)
    tornado.options.define("log_rotate_mode", default=None)
    tornado.options.define("log_file_max_size", default=10000)
    tornado.options.define("log_file_num_backups", default=0)
    tornado.options.define("log_rotate_when", default="midnight")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.define("log_to_stderr", default=True)

    # test default
    enable_pretty_logging()

# Generated at 2022-06-26 08:24:12.636946
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options = tornado.options.define(
        "log_file_prefix", default=None, help="Path prefix for log files"
    )
    tornado.options.options = tornado.options.define(
        "log_to_stderr", default=False, help="Send log output to stderr (colorized if possible).  By default use stderr if --log_file_prefix is not set and no other logging is configured."
    )
    tornado.options.options = tornado.options.define(
        "log_rotate_mode",
        type=str,
        default="size",
        help='Log rotation mode, either "size" (rotate based on size of log file) or "time" (rotate based on time of day).',
    )

# Generated at 2022-06-26 08:24:14.031628
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:24:15.431754
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:24:16.868411
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass


# Generated at 2022-06-26 08:24:19.351628
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    print("test_enable_pretty_logging()")


# Generated at 2022-06-26 08:24:25.168125
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # global log_formatter_0
    # obj = LogFormatter()
    # func_ret0 = cast(str, obj.format(log_formatter_0))
    # assert func_ret0 is not None
    return


# Generated at 2022-06-26 08:24:27.406802
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()
