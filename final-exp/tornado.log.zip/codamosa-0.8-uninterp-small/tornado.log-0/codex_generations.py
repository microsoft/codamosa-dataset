

# Generated at 2022-06-26 08:14:58.717479
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    gen_log.warn("this is a test")

if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:14:59.629222
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-26 08:15:05.757826
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # testing of the formatter:
    console = logging.StreamHandler()
    console.setLevel(logging.ERROR)
    formatter = LogFormatter(color=True)
    console.setFormatter(formatter)
    logging.getLogger().addHandler(console)
    logging.getLogger().setLevel(logging.DEBUG)

    logging.critical('critical message')
    logging.error('error message')
    logging.warning('warning message')
    logging.info('info message')
    logging.debug('debug message')


# Generated at 2022-06-26 08:15:08.473493
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._colors == {} # Dict[int, str]


# Generated at 2022-06-26 08:15:13.781460
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = formatter = LogFormatter()
    record = logging.LogRecord("logger", logging.INFO, "test_file", 999, "this is test", None, None)
    try:
        result = fmt.format(record)
        print("result=", result)
    except Exception as e:
        print("Exception=", e)


# Generated at 2022-06-26 08:15:22.179634
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #access_log = logging.getLogger("tornado.access")
    #main_log = logging.getLogger("tornado.main")
    #gen_log = logging.getLogger("tornado.general")

    #access_log.error("error")
    #main_log.error("error")
    gen_log.error("error")
    return


# Generated at 2022-06-26 08:15:24.987013
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("test", logging.DEBUG, "myfile", 0, "my message", (), None, None))


# Generated at 2022-06-26 08:15:27.660542
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:15:29.095472
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()


# Generated at 2022-06-26 08:15:39.153687
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt, style=style, color=color, colors=colors) # noqa: E501


# Generated at 2022-06-26 08:16:05.262855
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from logging import StreamHandler
    from logging import WARNING

    handler = StreamHandler()
    fmt = get_logger_formatter()
    handler.setFormatter(fmt)

    logger = logging.getLogger('tornado.general')
    logger.addHandler(handler)
    logger.setLevel(WARNING)

    logger.warning('foo bar')


# Generated at 2022-06-26 08:16:10.205591
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(name=None, level=logging.INFO, pathname=None, lineno=None, msg='This is a message',
               args=None, exc_info=None)
    #fo = formatter.format(record)
    fo = formatter.format(record)
    print(fo)



# Generated at 2022-06-26 08:16:20.692713
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("\ntest_LogFormatter")
    fmt = LogFormatter.DEFAULT_FORMAT
    print("fmt = LogFormatter.DEFAULT_FORMAT = " + fmt)
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    print("datefmt = LogFormatter.DEFAULT_DATE_FORMAT = " + datefmt)
    style = "%"
    print("style = " + style)
    color = True
    print("color = " + str(color))
    colors = LogFormatter.DEFAULT_COLORS
    print("colors = LogFormatter.DEFAULT_COLORS = " + str(colors))
    logf = LogFormatter(fmt, datefmt, style, color, colors)
    assert(logf._fmt == fmt)

# Generated at 2022-06-26 08:16:21.373368
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()



# Generated at 2022-06-26 08:16:33.475928
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define
    define("logging", default="INFO", help="log level")
    define("log_file_prefix", default="tornado.log", help="log file")
    define("log_file_max_size", default=100000, help="max log size")
    define("log_file_num_backups", default=10, help="num log files")
    define("log_rotate_mode", default="size", help="log rotate by size or time")
    define("log_rotate_when", default="D", help="log rotate when by time")
    define("log_rotate_interval", default=1, help="log rotate when by time")
    define("log_to_stderr", default=False, help="log to std err")
    test_case_0()
    #gen_log

# Generated at 2022-06-26 08:16:37.977931
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # fmt, datefmt, style, color, colors
    formatter = LogFormatter("format", "datefmt", "%", True, {})
    assert formatter



# Generated at 2022-06-26 08:16:48.234939
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.log import access_log as _access_log
    from tornado.log import app_log as _app_log
    from tornado.log import gen_log as _gen_log

    for log in [_access_log, _app_log, _gen_log]:
        # Now you can see logs print in console
        log.debug('This is a debug message')
        log.info('This is a info message')
        log.warning('This is a warning message')
        log.error('This is a error message')
        log.critical('This is a critical message')

test_case_0()
test_enable_pretty_logging()

# Generated at 2022-06-26 08:16:52.244146
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = type("type", (object, ), {"logging": "debug", "log_file_prefix": '/tmp/log'})()
    enable_pretty_logging(options)



# Generated at 2022-06-26 08:16:57.177629
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    x = LogFormatter()
    assert x != None
    assert x._fmt ==  "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert x._normal == ''


# Generated at 2022-06-26 08:17:02.760762
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    colorama.init()
    tornado_log = LogFormatter(
        fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
        datefmt="%H:%M:%S"
    )


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:17:39.690946
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.makeLogRecord({"message": "test_message"})  # type: ignore
    # When message is not any type of string, it should use repr()
    assert formatter.format(record) == "[I 20130207 00:00:00 main:1] test_message"  # noqa: E501
    record = logging.makeLogRecord({"message": u"test_message"})  # type: ignore
    # When message is unicode, it should be decoded to utf-8
    assert formatter.format(record) == "[I 20130207 00:00:00 main:1] test_message"  # noqa: E501

# Generated at 2022-06-26 08:17:48.281860
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter()
    record = logging.LogRecord(name='', level=logging.DEBUG, pathname='', lineno=0,
      msg='', args=None, exc_info=None)

    # record.message = 'DEBUG [20200131 18:26:30 app_logger:70] test'
    logFormatter.format(record)


# Generated at 2022-06-26 08:17:53.737783
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test case 0: Call the function normally
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:04.341884
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)sthis is the message\n%(end_color)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    lf = LogFormatter(fmt, datefmt, style, color, colors)
    assert lf._fmt == fmt
    assert '\033[2;34m' in lf._colors[logging.DEBUG]

# Generated at 2022-06-26 08:18:14.713631
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(
        level=logging.DEBUG,
        format=LogFormatter.DEFAULT_FORMAT,
        datefmt=LogFormatter.DEFAULT_DATE_FORMAT,
        style="%",
        color=True,
        colors=LogFormatter.DEFAULT_COLORS,
    )
    # Set up color if we are in a tty and curses is installed
    #if (sys.stderr.isatty() and curses):
    #    # The curses module has some str/bytes confusion in
    #    # python3.  Until version 3.2.3, most methods return
    #    # bytes, but only accept strings.  In addition, we want to
    #    # output these strings with the logging module, which
    #    # works with unicode strings.  The explicit calls to
    #

# Generated at 2022-06-26 08:18:15.563710
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(object)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:18:26.386462
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    datefmt = "%Y-%m-%d %H:%M:%S"
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt, colors=colors)

# Generated at 2022-06-26 08:18:35.736710
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Setup the parameters of logging
    class Options:
        logging = "debug"

    options_obj = Options()
    options_obj.log_file_prefix = "log_file"
    options_obj.log_file_max_size = 100
    options_obj.log_file_num_backups = 10
    options_obj.log_rotate_mode = "size"
    options_obj.log_rotate_when = "D"
    options_obj.log_rotate_interval = 1
    options_obj.log_to_stderr = False

    # Run the function
    enable_pretty_logging(options=options_obj)

# Generated at 2022-06-26 08:18:40.250081
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # This is a dummy function to test the constructor of LogFormatter class
    # TODO

    print("Executing test_LogFormatter()")
    lf = LogFormatter()


# Generated at 2022-06-26 08:18:48.807500
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = '%y%m%d %H:%M:%S'
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    log_formatter = LogFormatter(fmt, datefmt, style, color, colors)


# Generated at 2022-06-26 08:19:30.633546
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

# -----------------------------------------------------------------------------
# Copyright 2015 Bloomberg Finance L.P.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------- END-OF-FILE -----------------------------------

# Generated at 2022-06-26 08:19:35.670848
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("test_LogFormatter")
    log_formatter = LogFormatter()
    print("log formatter: ", log_formatter)



# Generated at 2022-06-26 08:19:40.385929
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()
    print("Test test_enable_pretty_logging() done")

# Unit tests for the module

# Generated at 2022-06-26 08:19:47.963822
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Unit test
    print_test_info(enable_pretty_logging.__name__)
    test_case_0()

# Call main function
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:20:01.098095
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # test constructor 1
    LogFormatter()

    # test constructor 2
    LogFormatter(fmt="%(color)s%(levelname)s%(end_color)s %(message)s")
    LogFormatter(fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
            datefmt="%y%m%d%H%M%S")

    # test constructor 3
    LogFormatter(fmt="%(color)s%(levelname)s%(end_color)s %(message)s",
            datefmt="%y%m%d%H%M%S", style="%")

    # test constructor 4

# Generated at 2022-06-26 08:20:13.066083
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
    enable_pretty_logging()
    app_log.debug('debug message')
    app_log.info('info message')
    app_log.warning('warn message')
    app_log.error('error message')
    app_log.critical('critical message')
    try:
        raise AssertionError('raise AssertionError to log')
    except AssertionError:
        app_log.exception('exception message')

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:20:14.278132
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:20:15.710984
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:20:20.176038
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        test_case_0()
    except Exception as e:
        print(e)


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:20:32.802709
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    import time
    now = datetime.datetime.now()
    nowNum = time.mktime(now.timetuple())

    #for _ in range(10):
    #    fmt = logging.Formatter()
    fmt = LogFormatter()
    timestamp = time.time()
    fmt.formatTime(datetime.datetime.fromtimestamp(timestamp))
    record = logging.LogRecord("foo", logging.INFO, pathname="", lineno=1, 
            msg="bar", args=(), exc_info=None)
    record.created = timestamp
    record.msecs = 1
    record.levelno = logging.INFO
    record.asctime = fmt.formatTime(now)
    record.name = None
    record.process = None
    record.processName = None
    record

# Generated at 2022-06-26 08:20:53.122558
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    forma = LogFormatter()
    record = logging.LogRecord("test", 1, "test", 1, "test", "", "")
    forma.format(record)
    assert True



# Generated at 2022-06-26 08:20:59.502850
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    from log_utils import patch_logging
    from tornado.log import enable_pretty_logging, app_log, gen_log, access_log

    def test_format():
        enable_pretty_logging()
        app_log.info("app_log test")
        gen_log.info("gen_log test")
        access_log.info("access_log test")

    with patch_logging('tornado.access', 'info') as log:
        access_log.info("access_log test")
        assert log
        entry = log[0]
        assert entry.levelname == 'INFO'
        assert entry.name == 'tornado.access'
        assert entry.msg == 'access_log test'

    with patch_logging('tornado.application', 'info') as log:
        app_log

# Generated at 2022-06-26 08:21:07.260847
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import inspect
    import logging
    import tornado.options
    import tornado.options
    import os

    # Clear any previous logging configurations.
    tornado.options.options.logging = None
    logging.root.handlers = []

    # Logging configurations.
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.logging = "debug"
    enable_pretty_logging()

    # Check if "test.log" exists.
    assert os.path.isfile("test.log") == True

# Generated at 2022-06-26 08:21:09.357219
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0();


# Generated at 2022-06-26 08:21:18.957612
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers

    # set logging level
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # set log_to_stderr
    options = tornado.options.options
    options.log_to_stderr = True

    enable_pretty_logging(options)
    assert(len(logger.handlers) == 1)

    # set log_file_prefix
    options.log_file_prefix = "./log.txt"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 10
    options.log_file_num_backups = 1

    enable_pretty_logging(options)
    assert(len(logger.handlers) == 2)

# Generated at 2022-06-26 08:21:26.301577
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # gen_log.info("test_LogFormatter_format")
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", 20, "test/test_log.py", 100, "test_LogFormatter_format", [], None)
    message = formatter.format(record)
    print(message)


# Generated at 2022-06-26 08:21:32.645077
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    enable_pretty_logging()
    app_log.error("Error Message")
    app_log.debug("Debug Message")
    app_log.info("Info Message")
    app_log.warning("Warning Message")


# Generated at 2022-06-26 08:21:41.822770
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"

    datefmt = "%y%m%d %H:%M:%S"

    style = "%"

    color = True

    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    formatter = LogFormatter(fmt, datefmt, style, color, colors)

    record = logging.LogRecord("tornado.access", logging.DEBUG, "", 1, "", None, None)

# Generated at 2022-06-26 08:21:49.928919
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(
        fmt = LogFormatter.DEFAULT_FORMAT,
        datefmt = LogFormatter.DEFAULT_DATE_FORMAT,
        style = "%",
        color = True,
        colors = LogFormatter.DEFAULT_COLORS,
    )
    # unit test for method format
    log_formatter.format(logging.LogRecord("name", logging.DEBUG, "pathname", 1234, "msg", (), None))



# Generated at 2022-06-26 08:22:02.944144
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()
    print(type(logFormatter))
    # {
    # 'asctime': '2006-02-15 03:04:05',
    # 'created': 1161150245.469,
    # 'exc_info': (None, None, None),
    # 'exc_text': None,
    # 'filename': '../tornado/options.py',
    # 'funcName': 'parse_config_file',
    # 'levelname': 'INFO',
    # 'levelno': 20,
    # 'lineno': 513,
    # 'module': 'tornado.options',
    # 'msecs': 469.0,
    # 'message': 'Parsed from ../tornado/options.cfg: '
    #            "{'logging': 'debug'}",

# Generated at 2022-06-26 08:22:21.371728
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _logFormatter = LogFormatter()
    print("logFormatter = ",_logFormatter)


# Generated at 2022-06-26 08:22:32.073457
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'
    date_format = '%y%m%d %H:%M:%S'
    style = '%'

    lf = LogFormatter(fmt=log_format, datefmt=date_format, style=style)
    lf = LogFormatter(fmt=log_format, datefmt=date_format, style=style, color=True)
    lf = LogFormatter(fmt=log_format, datefmt=date_format, style=style, color=True, colors={})


# Generated at 2022-06-26 08:22:35.346178
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    print(formatter)
    assert formatter is not None



# Generated at 2022-06-26 08:22:42.119797
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()
    assert LogFormatter(fmt='test fmt')
    assert LogFormatter(datefmt='test datefmt')
    assert LogFormatter(style='test style')
    assert LogFormatter(color=True)
    assert LogFormatter(colors={})



# Generated at 2022-06-26 08:22:45.037107
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Case 0
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:22:54.293453
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger("tornado.general")
    test_case_0()
    assert len(logger.handlers) == 1

if __name__ == '__main__':
    import tornado.options
    tornado.options.define("log_to_stderr", type=bool)
    tornado.options.define("log_file_prefix", type=str)
    cat = logging.getLogger("tornado.general")
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:23:06.425324
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line

    define("port", default=80, type=int)
    define("logging", default="none", type=str)
    define("log_to_stderr", default=None, type=bool)
    define("log_file_prefix", default=None, type=str)
    define("log_file_max_size", default=100 * 1000 * 1000, type=int)
    define("log_file_num_backups", default=10, type=int)
    define("log_rotate_when", default="midnight", type=str)
    define("log_rotate_interval", default=1, type=int)
    define("log_rotate_mode", default="size", type=str)

    define_logging_options(options)
   

# Generated at 2022-06-26 08:23:13.519006
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        test_case_0()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        raise e
    logging.info("Test of enable_pretty_logging finished.")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:23:21.927173
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        # 1
        LogFormatter()
        
        # 2
        fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
        # datefmt = "%y%m%d %H:%M:%S"
        colors = { 
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        }
        LogFormatter(fmt, colors=colors)

    except Exception as e:
        assert 0, "Fail to init instance of LogFormatter."

#

# Generated at 2022-06-26 08:23:24.726131
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()
    logging.info("Testing logging by tornado")

test_enable_pretty_logging()

# Generated at 2022-06-26 08:23:59.079735
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    print('#1')
    test_case_0()

if __name__ == '__main__':
    print('Unit tests for logging.py')

    test_enable_pretty_logging()

# Generated at 2022-06-26 08:24:01.220794
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    print(formatter._fmt)
    print(formatter.datefmt)
    print(formatter._colors)
    print(formatter._normal)


# Generated at 2022-06-26 08:24:06.708992
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("test_enable_pretty_logging(): ")
    try:
        #test_case_0()
        test_case_1()
    except Exception as e:
        print(e)
        raise e


# Generated at 2022-06-26 08:24:11.952510
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name='tornado.general',
        level=logging.INFO,
        pathname='<unknown>',
        lineno=0,
        msg='this is an info log message',
        args=None,
        exc_info=None
    )
    res = formatter.format(record)
    print(f'[test_LogFormatter_format] LogFormatter.format() returned: {res}')


# Generated at 2022-06-26 08:24:21.861511
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS

    lf = LogFormatter(fmt, datefmt, style, color, colors)

    record = logging.LogRecord(
        name="tornado.application",
        level=logging.ERROR,
        pathname="/home/user/tornado/tornado/httputil.py",
        lineno=234,
        msg="This is a msg",
        args=(),
        exc_info=None,
    )

    record.msg = "This is a msg"


# Generated at 2022-06-26 08:24:23.164679
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()


# Generated at 2022-06-26 08:24:34.395290
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    #enable_pretty_logging()
    # test 1:  color = True, _stderr_supports_color() = True
    #  _colors must be non empty
    _colors = {"1": "1", "2": "2"}
    formatter = LogFormatter(color = True, colors = _colors)
    assert(len(formatter._colors) != 0)
    # test 2:  color = False, _stderr_supports_color() = True
    #  _colors must be empty
    _colors = {"1": "1", "2": "2"}
    formatter = LogFormatter(color = False, colors = _colors)
    assert(len(formatter._colors) == 0)
    # test 3:  color = True, _stderr_supports_

# Generated at 2022-06-26 08:24:38.046123
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()