

# Generated at 2022-06-26 08:15:07.308498
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,
        logging.INFO: 2,
        logging.WARNING: 3,
        logging.ERROR: 1,
        logging.CRITICAL: 5,
    }

# Generated at 2022-06-26 08:15:08.601610
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    enable_pretty_logging()


# Generated at 2022-06-26 08:15:10.395104
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()


# Generated at 2022-06-26 08:15:11.839563
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()


# Generated at 2022-06-26 08:15:24.480764
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.log import gen_log, LogFormatter
    gen_log.setLevel(logging.DEBUG)
    if True:
        formatter = LogFormatter()
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(logging.DEBUG)
        f = logging.Formatter(formatter._fmt, datefmt=formatter.datefmt)
        stream_handler.setFormatter(f)
        gen_log.addHandler(stream_handler)

        # code to test
        gen_log.debug("test")
        gen_log.info("test")
        gen_log.warning("test")
        gen_log.error("test")
        gen_log.critical("test")
    else:
        enable_pretty_logging()
        
        # code to test
        gen_log

# Generated at 2022-06-26 08:15:27.376431
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-26 08:15:38.552806
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = '%(asctime)s %(levelname)s: %(message)s'
    datefmt = '%Y-%m-%d %H:%M:%S'
    style = '%'
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    lf = LogFormatter(fmt, datefmt, style, color, colors)
    import datetime
    timestamp = datetime.datetime(2019, 5, 9, 11, 28, 31)

# Generated at 2022-06-26 08:15:42.743129
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    lf = LogFormatter(fmt, datefmt, style, color, colors)


# Generated at 2022-06-26 08:15:44.484542
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-26 08:15:48.284377
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter("xxx")
    print(log_formatter._fmt)
    # print(log_formatter.DEFAULT_FORMAT)
    # print(log_formatter.DEFAULT_DATE_FORMAT)
    # print(log_formatter.DEFAULT_COLORS)



# Generated at 2022-06-26 08:15:57.729310
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()


# Generated at 2022-06-26 08:16:02.552147
# Unit test for function define_logging_options
def test_define_logging_options():
    # Tornado's default option parser is used for test.
    import tornado.options

    tornado.options.define(name="vvv", default="", help="", type=str)
    define_logging_options()
    tornado.options.parse_command_line()
    print(tornado.options.options.vvv)
    print(tornado.options.options.logging)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-26 08:16:12.604147
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    from tornado.log import LogFormatter
    date = datetime.date.today()
    record = logging.LogRecord('tornado.general', logging.INFO, 'foo.py', 3,
                               'hello world', None, None)
    # 1. No pattern
    formatter = LogFormatter()
    result = formatter.format(record)
    assert result == 'hello world'
    # 2. Default pattern
    formatter = LogFormatter(datefmt='%d-%m-%Y')
    result = formatter.format(record)
    assert result == '[20%d-%m-%Y 00:00:00 foo:3] hello world' % date.year
    # 3. With color

# Generated at 2022-06-26 08:16:21.681931
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.log import access_log, app_log, gen_log
    import logging

    # As the output of logging is not direcly visible, but instead
    # is accessed by accessing the logger's handler and formatter,
    # we need to get those in order to get at the output.
    # In order to do this, we have to declare a logger, and add a
    # handler and formatter to it.
    log = logging.getLogger('enable_pretty_logging')
    log.setLevel(logging.DEBUG)
    # In order to check the output, we need a handler, e.g. a
    # logging.FileHandler, and a formatter, e.g. a logging.Formatter.
    handler = logging.FileHandler('test_log.txt')
    log.addHandler(handler)
    # log form

# Generated at 2022-06-26 08:16:33.551201
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)
    logger = access_log
    logger.setLevel(logging.INFO)
    logFormatter = LogFormatter(fmt=LogFormatter.DEFAULT_FORMAT, datefmt=LogFormatter.DEFAULT_DATE_FORMAT, style="%", color=True, colors=LogFormatter.DEFAULT_COLORS)
    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(logFormatter)
    logger.addHandler(consoleHandler)
    logger.info(logFormatter.DEFAULT_COLORS[logging.INFO])
    logger.warning(logFormatter.DEFAULT_COLORS[logging.WARNING])
    logger.error(logFormatter.DEFAULT_COLORS[logging.ERROR])


# Generated at 2022-06-26 08:16:34.839530
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    print('log_formatter: %s' % log_formatter)



# Generated at 2022-06-26 08:16:42.311767
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log = logging.getLogger("tornado.access")
    # setup log configuration
    logging.basicConfig()
    log.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler(sys.stdout)
    formatter = LogFormatter()
    stream_handler.setFormatter(formatter)
    log.addHandler(stream_handler)

    log.info("no_color")



# Generated at 2022-06-26 08:16:49.647137
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Debug mode
    logger = logging.getLogger('__name__')
    logger.setLevel(logging.DEBUG)
    fmt = LogFormatter()
    name = '__main__.test_LogFormatter_format'
    msg = 'Testing LogFormatter.format'
    logger.debug(msg)


# Generated at 2022-06-26 08:16:51.277847
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

# Generated at 2022-06-26 08:17:04.175315
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # test case 1: record contains no exc_info
    record = logging.LogRecord(
        "tornado.access", logging.INFO, "tornado.py", 32, "message",
        None, None, "myFun")
    record.levelno = logging.INFO
    obj = LogFormatter(datefmt="%Y-%m-%d %H:%M:%S.%f")
    ret = obj.format(record)
    assert ret == "[I 2018-12-25 18:08:33.000000 tornado.py:32] message"

    # test case 2: record contains exc_info
    record.levelno = logging.INFO
    record.exc_info = ["my info", "my info2"]
    ret = obj.format(record)

# Generated at 2022-06-26 08:17:54.371792
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import pickle
    import logging
    import logging.handlers
    import os


    class RecordFactory(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def getMessage(self):
            return self.msg

        def __getstate__(self):
            # for tests, we don't care about the actual message
            # so we just save a placeholder
            d = dict(self.__dict__)
            d["msg"] = "MESSAGE"
            return d

        def __setstate__(self, d):
            self.__dict__.update(d)


# Generated at 2022-06-26 08:17:55.897587
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

# Generated at 2022-06-26 08:18:03.675509
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Step 1: set up a formatter
    formatter = LogFormatter()

    # Step 2: create a dummy record to test the formatter
    record = logging.LogRecord(
        name = "tornado.application",
        level = logging.INFO,
        fn = "/var/local/tornado_demo_app.py",
        lno = 200,
        msg = "Starting up",
        args = [],
        exc_info = None
    )

    # Step 3: test the format() method of the formatter

# Generated at 2022-06-26 08:18:05.722040
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    for i in range(1000):
        enable_pretty_logging()

# Generated at 2022-06-26 08:18:06.249567
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Case 0
    test_case_0()

# Generated at 2022-06-26 08:18:07.850862
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("unit test for constructor of class LogFormatter")
    LogFormatter()
    print("passed")


# Generated at 2022-06-26 08:18:11.808083
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.info(test_case_0.__doc__)
    # logging.basicConfig()
    logging.debug("This is a debug message")
    logging.info("This is an info message")
    logging.warning("This is a warning message")
    logging.error("This is an error message")
    logging.critical("This is a critical message")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:15.786886
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    print("Log formatter %s" % log_formatter)
    assert 1 == 1


# Generated at 2022-06-26 08:18:16.759161
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass


# Generated at 2022-06-26 08:18:21.192678
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.DEBUG, "/", 1, "message", (), None)
    assert formatter.format(record) is not None


# Generated at 2022-06-26 08:18:38.570479
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_case_0()


# Generated at 2022-06-26 08:18:40.034740
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()


# Generated at 2022-06-26 08:18:48.746788
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    # Add a dummy record to the logger
    app_log.warning("This is a test warning message")
    # Retrieve the last record from the logger
    record = app_log.handlers[0].records[-1]
    # Now try to format the record using the formatter
    record_string = log_formatter.format(record)
    # Print the formatted record string
    print(record_string)

if __name__ == "__main__":
    # Add a handler to app_log that prints log messages to stdout
    # Then, set the log level of app_log to WARNING, which causes it to only
    # log messages that are WARNING level or above
    # Note the use of a lambda function here to create the StreamHandler with
    # a specific set of arguments
    app_

# Generated at 2022-06-26 08:18:56.672945
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._colors == {
        logging.DEBUG: '\x1b[2;34m',
        logging.INFO: '\x1b[2;32m',
        logging.WARNING: '\x1b[2;33m',
        logging.ERROR: '\x1b[2;31m',
        logging.CRITICAL: '\x1b[2;35m'
    }
    assert log_formatter._normal == '\x1b[0m'
    assert log_formatter.datefmt == ''


# Generated at 2022-06-26 08:19:04.383525
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    log_record_0 = logging.LogRecord(
        name="",
        level=10,
        pathname="",
        lineno=0,
        msg="",
        args=None,
        exc_info=None
    )
    str_0 = log_formatter_0.format(log_record_0)
    print(str_0)



# Generated at 2022-06-26 08:19:10.749984
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    logger = logging.getLogger()
    enable_pretty_logging(tornado.options.options, logger)


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:19:15.446798
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # import tornado.options
    # optionsObj = tornado.options
    # optionsObj.parse_command_line()
    enable_pretty_logging()
    print("Function enable_pretty_logging() test PASS.")


# Generated at 2022-06-26 08:19:29.084739
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import sys
    import datetime

    # Define the record for the test
    record = logging.LogRecord(name='',
                               level=0,
                               pathname='',
                               lineno=0,
                               msg='',
                               args=(),
                               exc_info=None,
                               func=None)
    record.name = ''
    record.levelname = ''
    record.pathname = ''
    record.lineno = 0
    record.msg = ''
    record.args = ()
    record.exc_info = (None,)
    record.exc_text = ''
    record.stack_info = None
    record.created = datetime.datetime(2018, 1, 1, 0, 0)
    record.msecs = 100.0
    record.relativeCreated = 0.0
   

# Generated at 2022-06-26 08:19:42.220778
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    Test constructor of class LogFormatter
    """
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

# Generated at 2022-06-26 08:19:48.959024
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_rotate_interval = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()

# Generated at 2022-06-26 08:20:10.355500
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        print ("Test of function 'enable_pretty_logging'")
        test_case_0()
        test_case_1()
    except:
        print ("Error: unable to start test for function 'enable_pretty_logging'")
    return


# Generated at 2022-06-26 08:20:16.162296
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    log_record_0 = logging.LogRecord('test_name_0', logging.WARNING, 'test_pathname_0', 124, 'test_message_0', None, None)
    log_formatter_0.format(log_record_0)



# Generated at 2022-06-26 08:20:17.658031
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:20:21.435218
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record = 3
    assert log_formatter_0.format(record) == '3'

# Generated at 2022-06-26 08:20:34.548602
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_1 = LogFormatter()
    log_formatter_2 = LogFormatter()
    log_record_1 = logging.LogRecord(
        "test_name",
        logging.DEBUG,
        "/home/bob/test.py",
        18,
        "test_msg",
        None,
        None,
    )
    log_record_2 = logging.LogRecord(
        "test_name",
        logging.DEBUG,
        "/home/bob/test.py",
        18,
        "test_msg",
        None,
        None,
    )
    assert log_formatter_1.format(log_record_1) == log_formatter_2.format(log_record_2)

if __name__ == "__main__":
    test_LogFormatter_

# Generated at 2022-06-26 08:20:46.119462
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    assert log_formatter_0._fmt == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa: E501
    assert log_formatter_0._colors == {}
    assert log_formatter_0._normal == ""

    log_formatter_1 = LogFormatter(color=False)
    assert log_formatter_1._colors == {}
    assert log_formatter_1._normal == ""

    log_formatter_2 = LogFormatter(color=True)
    assert log_formatter_2._colors != {}
    assert log_formatter_2._normal != ""

    log

# Generated at 2022-06-26 08:20:54.434148
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    #Test format of class LogFormatter
    try:
        record_0 = logging.LogRecord("name_0","level_0", "pathname_0", "lineno_0", "msg_0", None, None)
        log_formatter_0.format(record_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 08:21:07.262451
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter(fmt="[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s", datefmt="%y%m%d %H:%M:%S")  # noqa: E501
    log_formatter_1 = LogFormatter(fmt="[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s", datefmt="%y%m%d %H:%M:%S", style="%")  # noqa: E501

# Generated at 2022-06-26 08:21:16.451012
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    assert log_formatter_0._fmt == LogFormatter.DEFAULT_FORMAT
    assert cast(str, log_formatter_0.datefmt) == LogFormatter.DEFAULT_DATE_FORMAT
    assert cast(str, log_formatter_0._style) == "%"
    assert log_formatter_0._colors == LogFormatter.DEFAULT_COLORS
    assert log_formatter_0._normal == ""



# Generated at 2022-06-26 08:21:24.156236
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_to_stderr = True
    enable_pretty_logging(options)
    # Enable color mode
    app_log.debug("Test message")


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:22:06.797557
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test 1
    log_formatter_1 = LogFormatter()
    assert(isinstance(log_formatter_1, logging.Formatter))
    assert(log_formatter_1.datefmt == "%y%m%d %H:%M:%S")
    assert(log_formatter_1._colors == {})

    # Test 2
    log_formatter_2 = LogFormatter(datefmt = "%y%m%d %H:%M:%S")
    assert(isinstance(log_formatter_2, logging.Formatter))
    assert(log_formatter_2.datefmt == "%y%m%d %H:%M:%S")
    assert(log_formatter_2._colors == {})

    # Test 3
    log_formatter_3 = Log

# Generated at 2022-06-26 08:22:13.929792
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Constructor of class LogFormatter with no arguments
    log_formatter_0 = LogFormatter()
    assert log_formatter_0._fmt == LogFormatter.DEFAULT_FORMAT, "_fmt == DEFAULT_FORMAT"
    assert log_formatter_0._normal == "", "_normal == ''"
    assert log_formatter_0.datefmt == LogFormatter.DEFAULT_DATE_FORMAT, "datefmt == DEFAULT_DATE_FORMAT"
    # Constructor of class LogFormatter with all arguments
    log_formatter_1 = LogFormatter(fmt="", datefmt="", style="%", color=False, colors={})
    assert log_formatter_1._fmt == "", "_fmt == ''"

# Generated at 2022-06-26 08:22:18.113960
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    log_formatter_1 = LogFormatter(
        fmt=LogFormatter.DEFAULT_FORMAT,
        datefmt=LogFormatter.DEFAULT_DATE_FORMAT,
        style="%",
        color=True,
        colors=LogFormatter.DEFAULT_COLORS,
    )
    assert log_formatter_0 == log_formatter_1
    assert log_formatter_0 != None  # noqa
    assert repr(log_formatter_1) == repr(log_formatter_0)
    assert str(log_formatter_1) == str(log_formatter_0)
    assert "DEFAULT_FORMAT" in str(log_formatter_0)

# Generated at 2022-06-26 08:22:19.904154
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# Generated at 2022-06-26 08:22:21.905069
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter, LogFormatter)


# Generated at 2022-06-26 08:22:24.319040
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:22:34.651242
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    assert log_formatter_0.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert log_formatter_0.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert log_formatter_0.DEFAULT_COLORS == {
        logging.DEBUG: 4,
        logging.INFO: 2,
        logging.WARNING: 3,
        logging.ERROR: 1,
        logging.CRITICAL: 5,
    }
    assert "LogFormatter" in str(log_formatter_0)
    


# Generated at 2022-06-26 08:22:45.193312
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Set up logging parameters
    log_file_prefix = "test_log_file"
    log_rotate_mode = "size"
    log_file_max_size = 100
    log_file_num_backups = 5
    log_rotate_when = "D"
    log_rotate_interval = 1

    # Generate test data
    test_logger = logging.getLogger()
    test_logger.setLevel(logging.DEBUG)
    rotate_mode = log_rotate_mode
    if rotate_mode == "size":
        channel = logging.handlers.RotatingFileHandler(
            filename=log_file_prefix,
            maxBytes=log_file_max_size,
            backupCount=log_file_num_backups,
            encoding="utf-8",
        ) 

# Generated at 2022-06-26 08:22:47.521400
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# Generated at 2022-06-26 08:22:49.865335
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Add tests here.
    LogFormatter().format()


# Generated at 2022-06-26 08:23:56.832816
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:23:59.006833
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()


# Generated at 2022-06-26 08:24:01.903429
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    log_formatter_1 = LogFormatter()
    logger_0 = logging.getLogger()
    enable_pretty_logging(options = None, logger = logger_0)

# main for testing
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:24:09.342684
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=logging.DEBUG)
    for i in range(10):
        logging.error('logging error %d' % i)
    logging.error('logging error')
    print('=====================')
    logging.info('logging info')
    logging.debug('logging debug')

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:24:21.244669
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    from logging import LogRecord
    from tornado.util import ObjectDict
    record = LogRecord(name="log_formatter_0", 
                       level=20, 
                       pathname=None, 
                       lineno=0, 
                       msg="Warning", 
                       args=None, 
                       exc_info=None, 
                       func=None)
    record.__dict__ = ObjectDict()
    record.__dict__.message = "Warning"
    record.__dict__.asctime = "190811 14:40:31"
    record.__dict__.color = ""
    record.__dict__.end_color = ""
    log_formatter_0.format(record)


# Generated at 2022-06-26 08:24:33.857384
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """ Format a record using a format string."""
    log_formatter = LogFormatter()
    # Setup a log record 
    record = logging.LogRecord(
                name="tornado.access",
                level=logging.DEBUG,
                pathname="/tmp/test",
                lineno=10,
                msg="hello world",
                args=None,
                exc_info=None
            )

    record.__dict__['message'] = 'hello world'
    record.__dict__['levelname'] = 'DEBUG'
    record.__dict__['asctime'] = '20190322 18:48:12'
    record.__dict__['module'] = "test"
    record.__dict__['lineno'] = 10
    record.__dict__['end_color'] = ""

# Generated at 2022-06-26 08:24:44.144557
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {logging.DEBUG: 4,  # Blue
              logging.INFO: 2,  # Green
              logging.WARNING: 3,  # Yellow
              logging.ERROR: 1,  # Red
              logging.CRITICAL: 5,  # Magenta
              }
    log_formatter = LogFormatter(fmt, datefmt, style, color, colors)
    assert log_formatter._fmt == fmt