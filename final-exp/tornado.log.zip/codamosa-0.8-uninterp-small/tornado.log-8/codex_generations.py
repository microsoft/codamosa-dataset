

# Generated at 2022-06-26 08:15:00.218102
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()



# Generated at 2022-06-26 08:15:13.051825
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # If a byte string makes it this far, convert it to unicode to
    # ensure it will make it out to the logs.  Use repr() as a fallback
    # to ensure that all byte strings can be converted successfully,
    # but don't do it by default so we don't add extra quotes to ascii
    # bytestrings.  This is a bit of a hacky place to do this, but
    # it's worth it since the encoding errors that would otherwise
    # result are so useless (and tornado is fond of using utf8-encoded
    # byte strings wherever possible).
    # record.message = _safe_unicode(message)
    message = "Hello"
    assert _safe_unicode(message) == "Hello"
    message = "Hello"

# Generated at 2022-06-26 08:15:25.698000
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    t = LogFormatter()
    d = {'message': '', 'asctime': '', 'module': '', 'lineno': 0, 'funcName': '', 'levelname': '', 'levelno': 0, 'pathname': '', 'filename': '', 'process': 0, 'processName': '', 'thread': 0, 'threadName': ''}

    d['message'] = 'test'
    d['asctime'] = 'testtime'
    d['module'] = 'testmodule'
    d['lineno'] = 1
    d['funcName'] = 'testfuncName'
    d['levelname'] = 'testlevelname'
    d['levelno'] = 0
    d['pathname'] = 'testpathname'
    d['filename'] = 'testfile'
    d['process'] = 0
    d

# Generated at 2022-06-26 08:15:38.062646
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    

# Generated at 2022-06-26 08:15:47.844797
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.httputil import HTTPServerRequest
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPFile
    from tornado.httputil import parse_body_arguments
    from tornado.httputil import parse_multipart_form_data
    from tornado.httputil import parse_body_arguments_and_files
    from tornado.httputil import _parse_header
    import tornado.escape
    import tornado.util

    class TestRequest(HTTPServerRequest):
        def __init__(self, method: str, uri: str, headers: Optional[HTTPHeaders] = None) -> None:
            HTTPServerRequest.__init__(self, method, uri, headers=headers)

    request = TestRequest(method="GET", uri="/")

# Generated at 2022-06-26 08:15:49.323068
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-26 08:15:50.781203
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log = LogFormatter()



# Generated at 2022-06-26 08:16:01.679099
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    datefmt = "%H:%M:%S"
    style = "%"
    color = True
    colors = { 
        logging.DEBUG: 4,  
        logging.INFO: 2,  
        logging.WARNING: 3,  
        logging.ERROR: 1,  
        logging.CRITICAL: 5,  
    }
    formatter = LogFormatter(fmt, datefmt, style, color, colors)
    
    now = datetime.datetime.now()
    # now = datetime.datetime(2020, 1, 1, 15, 0, 0)
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
   

# Generated at 2022-06-26 08:16:10.363331
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("log_rotate_interval", type=int)
    tornado.options.define("logging", type=str)
    tornado.options.define("log_to_stderr", type=bool)

    # Config 1: size rotate mode
    #

    # Unit test for function enable_pretty_logging
    #
    tornado.options.parse_command_

# Generated at 2022-06-26 08:16:20.023769
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformatter = LogFormatter()
    assert logformatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert logformatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert logformatter.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}
    assert logformatter._colors == {}
    assert logformatter._normal == ""



# Generated at 2022-06-26 08:16:32.939716
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    define_logging_options()
    record = logging.LogRecord("tornado.access", logging.INFO, 
                               "/test/test_log.py", 5, "this is an access log", 
                               None, None, "test_log")
    formatter = LogFormatter()
    ret = formatter.format(record)
    print(ret)



# Generated at 2022-06-26 08:16:46.705260
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define, parse_command_line
    import tempfile
    import shutil


# Generated at 2022-06-26 08:16:48.322457
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    logger.debug('This is a logger debug message.')


# Generated at 2022-06-26 08:16:55.208847
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()

    # Bad message
    record = logging.LogRecord(name="test", level=logging.INFO, pathname="/test/test.py", lineno=10,
                               msg="test", args=None, exc_info=None)
    result = formatter.format(record)
    print(result)
    assert result == "[I 20180625 10:29:23 test:/test/test.py] test"


# CLI options to configure logging

# Generated at 2022-06-26 08:17:05.465895
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s%(levelname)s%(end_color)s %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt, style=style, color=color, colors=colors)
    formatter.format(logging.warning("hello, world"))


# Generated at 2022-06-26 08:17:17.667945
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options

    # Define logging option first
    define_logging_options()

    # reset logging
    reload(logging)
    logging.debug("Logging Test: Start")

    # Parse the command line and then enable logging
    # Usage: $python tornado/log.py --logging=debug --log_file_prefix=logs/a.log
    tornado.options.parse_command_line()
    enable_pretty_logging(options)

    logging.debug("Logging Test: a")
    logging.info("Logging Test: b")
    logging.warning("Logging Test: c")
    logging.error("Logging Test: e")
    logging.critical("Logging Test: f")
    logging.debug("Logging Test: End")

    # Configuration file test

# Generated at 2022-06-26 08:17:19.652413
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-26 08:17:28.181543
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter(
        fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt = "%y%m%d %H:%M:%S",
        color = True,
        colors = {
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        }
    )


# Generated at 2022-06-26 08:17:29.705691
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:17:35.075757
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(datefmt='%Y/%m/%d %H:%M:%S')
    assert formatter.datefmt == '%Y/%m/%d %H:%M:%S'



# Generated at 2022-06-26 08:18:02.958414
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    print("Type of log_formatter_0 is: ", type(log_formatter_0))
    print("Value of log_formatter_0 is: ", log_formatter_0)
    print("Format of log_formatter_0 is:",log_formatter_0.format)
    print("Dateformat of log_formatter_0 is:", log_formatter_0.datefmt)
    print("Log_formatter_0 colors are:", log_formatter_0._colors)
    print("Log_formatter_0 normal is:", log_formatter_0._normal)
    print("Log_formatter_0 fmt is:", log_formatter_0._fmt)

test_LogFormatter()
# end-def


# Generated at 2022-06-26 08:18:11.588990
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    class LogRecord():
        def __init__(self, msg):
            self.msg = msg
        def __getattr__(self, attr_name):
            if attr_name == "getMessage":
                return lambda: self.msg
            raise Exception("Attribute doesn't exist: " + attr_name)

    assert log_formatter.format(LogRecord("Hello")) == "[   INFO    Hello"


# Generated at 2022-06-26 08:18:24.413818
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os

    # Test this function with log_file_prefix option set
    tornado.options.options.log_file_prefix = "/tmp/test_file"
    tornado.options.options.log_to_stderr = True

    enable_pretty_logging()
    # Verify that the log file created is not empty
    assert os.stat("/tmp/test_file").st_size != 0

    # Test this function with log_to_stderr options set
    tornado.options.options.log_to_stderr = False

    enable_pretty_logging()
    assert os.stat("/tmp/test_file").st_size != 0

    # Test this function with logging level set to INFO
    tornado.options.options.logging = "INFO"

    enable_pretty_logging()
   

# Generated at 2022-06-26 08:18:36.272384
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    method_name            = 'format'
    unit_test_fail_count   = 0
    expected_value         = None
    actual_value           = None

    log_formatter_1 = LogFormatter()

    record_0 = logging.getLogger('record_0')
    record_0.name = 'record_0'

    record_0.msg = 'message'
    record_0.asctime = 'asctime'

    # log_formatter_1.format(record_1)

    if actual_value != expected_value:
        unit_test_fail_count += 1
        print('Method "' + method_name + '" test case 0 failed with an actual'\
            ' value of "' + actual_value + '" and an expected value of '\
            '"' + expected_value + '".')

   

# Generated at 2022-06-26 08:18:46.927442
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create an instance of CmdLineParser
    # log_formatter_0 = LogFormatter()
    # print(log_formatter_0)
    log_formatter_1 = LogFormatter()
    print(log_formatter_1)

    # record: Any
    record = logging.getLogger()
    print(record)


# Generated at 2022-06-26 08:18:48.288668
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:18:58.336974
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    class LogRecord(object):
        __slots__ = ('name', 'levelno', 'pathname', 'lineno', 'msg', 'args', 'exc_info', 'func', 'sin_time', 'created', 'msecs', 'relativeCreated', 'process', 'thread', 'processName', 'threadName')
        def __init__(self, levelno : int, msg : str) -> None:
            self.levelno = levelno
            self.msg = msg
            self.created = 0
            self.msecs = 0
            self.relativeCreated = 0
        def __str__(self) -> str:
            return '<LogRecord>'
        def __repr__(self) -> str:
            return 'LogRecord()'

# Generated at 2022-06-26 08:18:59.782567
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:19:05.009811
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options  = dict()
    options["logging"] = "warning"
    logger = logging.getLogger('tornado.application')

    enable_pretty_logging(options, logger)

    logger.warn('Test Warning')
    logger.error('Test Error')
    logger.critical('Test Critical')


# Generated at 2022-06-26 08:19:06.686898
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:20:00.677437
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    from tornado.log import LogFormatter
    from tornado.escape import to_unicode
    from tornado.escape import _unicode
    from tornado.util import unicode_type
    from tornado.util import basestring_type

    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None

    try:
        import curses
    except ImportError:
        curses = None  # type: ignore

    from typing import Dict, Any, cast, Optional


    # Logger objects for internal tornado use
    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")



# Generated at 2022-06-26 08:20:13.624920
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_1 = LogFormatter()
    record = logging.LogRecord(
        name = 'test',
        level = 10,
        pathname = "pathname",
        lineno = 1,
        msg = "msg",
        args = [1, 2, 3],
        # exc_info = sys.exc_info(),
        # func = "func",
        # sineno = 2,
        # created = 1.0,
        # msecs = 1.0,
        # relativeCreated = 1.0,
        # thread = object(),
        # threadName = "threadName",
        # processName = "processName",
        # process = 1,
    )
    out = log_formatter_1.format(record)


# Generated at 2022-06-26 08:20:16.162502
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        enable_pretty_logging()
    except ValueError:
        pass


# Generated at 2022-06-26 08:20:25.069918
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = "error"
    tornado.options.options.log_file_prefix = "log_formatter.log"
    enable_pretty_logging(tornado.options.options)
    access_log.debug("test_case_0 - access_log.debug")
    app_log.debug("test_case_0 - app_log.debug")
    gen_log.debug("test_case_0 - gen_log.debug")
    access_log.setLevel(logging.CRITICAL)
    app_log.setLevel(logging.CRITICAL)
    gen_log.setLevel(logging.CRITICAL)


if __name__ == "__main__":
    gen_log.debug("=== Start testing ===")
    test_enable_pretty_log

# Generated at 2022-06-26 08:20:33.023876
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_1: LogFormatter = LogFormatter(fmt="%(message)s")
    log_formatter_3: LogFormatter = LogFormatter(
        fmt="%(message)s", datefmt="%Y-%m-%d %H:%M:%S", style="%", color=False
    )


if __name__ == "__main__":
    test_LogFormatter()

# Generated at 2022-06-26 08:20:40.195658
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Disable logger
    enable_pretty_logging(None, None)
    # Enable logger with log_to_stderr = True
    enable_pretty_logging(None, None)
    # Enable logger with log_to_stderr = False
    enable_pretty_logging(None, None)

# Generated at 2022-06-26 08:20:46.145663
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import sys
    from tornado.escape import _unicode
    from tornado.util import unicode_type, basestring_type
    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None
    try:
        import curses
    except ImportError:
        curses = None  # type: ignore
    from typing import Dict, Any, cast, Optional
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 08:20:47.166892
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter, LogFormatter)


# Generated at 2022-06-26 08:20:54.855489
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Declaration of data struct Input
    class Input:
        fmt: str
        datefmt: str
        style: str
        color: bool
        colors: Dict[int, int]
    # Declaration of data struct Output

    # Call function under test
    log_formatter = LogFormatter()
    # Check the result of method format of class LogFormatter
    print(log_formatter.format(Input()))

# Generated at 2022-06-26 08:21:07.441306
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("env", default="default", help="Run environment")
    define("log_to_stderr", type=bool, default=False, help="Send log output to stderr")
    define("log_file_prefix", type=str, help="Path prefix for log files")
    define("log_file_max_size", type=int, default=100 * 1000 * 1000, help="Max size of log files before rollover")
    define("log_file_num_backups", type=int, default=10, help="Number of log files to keep")
    define("log_rotate_mode", type=str, default='size', help="Specifies when to rotate. size or time")

# Generated at 2022-06-26 08:21:37.279164
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None)


# Generated at 2022-06-26 08:21:50.686283
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.log_file_prefix = 'file_prefix'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 1234
    options.log_file_num_backups = 2    
    options.log_rotate_when = None
    options.log_rotate_interval = None
    options.log_to_stderr = False
    logger = logging.getLogger()

    log_formatter_0 = LogFormatter(color=False)

# Generated at 2022-06-26 08:22:01.693068
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    # By default, logging is disabled. To test that the log file prefix option
    # actually has an effect, we first have to enable logging by setting the
    # logging option.
    tornado.options.enable_parse_globally()
    tornado.options.define("logging", default="INFO")
    tornado.options.define("log_file_prefix", default=r"C:/tmp/tornado_log.txt")
    tornado.options.parse_command_line()
    enable_pretty_logging(tornado.options.options)
    access_log.info("Hello world")

# Generated at 2022-06-26 08:22:04.562080
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    enable_pretty_logging(None, logger)

# Generated at 2022-06-26 08:22:09.310444
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()



# Generated at 2022-06-26 08:22:11.436897
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    assert 1 == 1

# Run both unit tests

# Generated at 2022-06-26 08:22:21.285150
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    log_formatter_0 = LogFormatter(fmt=LogFormatter.DEFAULT_FORMAT, datefmt=LogFormatter.DEFAULT_DATE_FORMAT, style="%", color=True, colors={logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5})



# Generated at 2022-06-26 08:22:30.946709
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = {}
    record['levelno'] = logging.INFO
    record['getMessage'] = lambda: 'TEST'
    record['exc_info'] = None
    record['exc_text'] = None

    log_formatter_0 = LogFormatter()
    msg = log_formatter_0.format(record)
    print(msg)

# Generated at 2022-06-26 08:22:44.222318
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    opt_parser = tornado.options.OptionParser()
    opt_parser.add_option('-l', '--logging', type=str, default='debug')
    opt_parser.add_option('-p', '--log-file-prefix', type=str, default='/tmp/test_log.log')
    opt_parser.add_option('--log-rotate-mode', type=str, default='time')
    opt_parser.add_option('--log-rotate-when', type=str, default='midnight')
    opt_parser.add_option('--log-rotate-interval', type=int, default=1)
    opt_parser.add_option('--log-file-max-size', type=int, default=100)
    opt_parser.add_

# Generated at 2022-06-26 08:22:56.055976
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Set up
    log_formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="foo.py",
        lineno=1,
        msg="message",
        args=(),
        exc_info=None,
        func=None,
    )
    log_formatter.format(record)
    # Test
    assert record.message == _safe_unicode("message")
    assert record.asctime in record.__dict__
    assert record.color in record.__dict__
    assert record.end_color in record.__dict__
    # Clean up


if __name__ == "__main__":
    test_case_0()
    test_LogFormatter_format()
    print("Everything passed")

# Generated at 2022-06-26 08:24:09.343361
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    # Ensure that we don't create a default log_to_stderr handler if
    # options.log_to_stderr is false.
    tornado.options.options.log_to_stderr = False
    tornado.log.enable_pretty_logging()
    assert not len(tornado.log.gen_log.handlers)
    tornado.options.options.log_to_stderr = True
    tornado.log.enable_pretty_logging()
    assert len(tornado.log.gen_log.handlers)
    # Ensure that we don't add a second logging.StreamHandler if enable_pretty_logging
    # is called twice.
    tornado.log.enable_pretty_logging()

# Generated at 2022-06-26 08:24:21.431794
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options = tornado.options.define(
        "options", None, None, type=dict, help=None
    )
    tornado.options.options.logging = "none"
    tornado.options.options.log_file_prefix = ""

if __name__ == "__main__":
    import argparse
    import sys
    parser = argparse.ArgumentParser()

    parser.add_argument("function")
    parser.add_argument("--options", type=str, default="{}")
    args = parser.parse_args()

    print(f"args: {args}")
    sys.path.append(".")
    options = eval(args.options)

    logger = logging.getLogger()
    if args.function == "enable_pretty_logging":
        enable_

# Generated at 2022-06-26 08:24:33.930890
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "../../docs/LogFile.log"
    tornado.options.options.log_to_stderr = True

    enable_pretty_logging()

    log_formatter_0 = LogFormatter()

    record = logging.LogRecord(
        name="tornado.access",
        level=logging.INFO,
        pathname="/Users/wangfei/Documents/GitHub/Tornado-Typed/Demo/Demo_3/MyHandler.py",
        lineno=14,
        msg="Test_Enable_Pretty_Logging",
        args=(),
        exc_info=None,
        func="test_enable_pretty_logging",
    )
    log_formatter_0.format(record)
