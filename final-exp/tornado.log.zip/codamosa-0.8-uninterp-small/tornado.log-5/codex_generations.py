

# Generated at 2022-06-26 08:15:01.439242
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("test_LogFormatter")
    formatter = LogFormatter()
    print("formatter: " + str(formatter))



# Generated at 2022-06-26 08:15:15.108941
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("debug", default=False, type=bool)
    tornado.options.define(
        "logging", default="warning", type=str, help="Logging level",
    )
    tornado.options.define(
        "log_file_prefix",
        type=str,
        default=None,
        help="Path prefix for log files. "
        + "Note that if you are running multiple tornado processes, "
        + "log_file_prefix must be different for each of them (e.g. "
        + "include the port number)",
    )
    tornado.options.define(
        "log_rotate_mode",
        type=str,
        default="size",
        help='"size" or "time". Defaults to "size".',
    )
    tornado.options

# Generated at 2022-06-26 08:15:25.562056
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test LogFormatter.format by constructing the string returned from
    # the formatter, then parsing it.
    #
    # First, no decorator
    formatter = LogFormatter(color=False)
    msg = 'TEST'
    record = logging.LogRecord('tornado.test', logging.INFO, '/foo', 42, msg, None, None)  # noqa: E501
    formatted = formatter.format(record)
    print(formatted)


# Generated at 2022-06-26 08:15:29.465024
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    define_logging_options()

    # ...
    # TODO: Add test for LogFormatter.format
    # ...


# Generated at 2022-06-26 08:15:39.303189
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.define("log_file_max_size", type=int, default=10)
    tornado.options.options.define("log_file_prefix", type=str, default="./tornado.log/tornado.log")
    tornado.options.options.define("log_file_num_backups", type=int, default=10)
    tornado.options.options.define("log_file_backup_count", type=int, default=10)
    tornado.options.options.define("log_file_mode", type=str, default="a")
    tornado.options.options.define("log_file_encoding", type=str, default="utf-8")
    tornado.options.options.define("log_to_stderr", type=bool, default=True)
    tornado

# Generated at 2022-06-26 08:15:49.143726
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        style="%",
        color=True,
        colors={logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5},
    )
    formatter.format(logging.LogRecord("", "", "", "", "", "", "", "", "", "", "", "", "", ""))


# Generated at 2022-06-26 08:15:55.762041
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    from tornado.options import options

    options.logging = "error"  # type: ignore
    setup_logging(options)

    arr = [1, 2, "abcd"]
    try:
        print(arr[100])
    except Exception:
        pass

    logger = logging.getLogger("tornado.general")
    for i in range(0, 10):
        logger.error(str(i))


# Generated at 2022-06-26 08:16:02.852712
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    define_logging_options()
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())
    logger.info("this is a test")


# Generated at 2022-06-26 08:16:12.640326
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    options = {}
    options['log_file_prefix'] = './log.txt'
    options['log_to_stderr'] = True
    options['logging'] = 'debug'
    options['color'] = True
    options['colors'] = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    logging = define_logging_options(options)
    gen_log.debug("Debug message: %d", 100)
    gen_log.info("Info message: %d", 200)
    gen_log.warning("Warning message: %d", 300)

# Generated at 2022-06-26 08:16:13.593774
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()


# Generated at 2022-06-26 08:16:33.158445
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    print(">>>test_enable_pretty_logging begin()")
    print(">>>test_case_0")
    test_case_0()
    #_logging_options["logging"] = "DEBUG"
    #print(tornado.options.parse_command_line())
    #print(tornado.options.options)

    #print(logging.getLogger().handlers)
    #enable_pretty_logging()

    #print(logging.getLogger().handlers)
    print(">>>test_enable_pretty_logging end()")


_logging_options = {}  # type: Dict[str, Any]


# Generated at 2022-06-26 08:16:36.176387
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()

    message = "abc"
    record = logging.LogRecord(
        "tornado.general", logging.INFO, "", 1, message, None,[]
    )
    ret = formatter.format(record)
    print(ret)


# Generated at 2022-06-26 08:16:37.978404
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-26 08:16:42.483192
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(
        fmt=LogFormatter.DEFAULT_FORMAT,
        datefmt=LogFormatter.DEFAULT_DATE_FORMAT,
        style="%",
        color=True,
        colors=LogFormatter.DEFAULT_COLORS,
    )



# Generated at 2022-06-26 08:16:46.101693
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    assert (formatter.format("something") == "something")


# Generated at 2022-06-26 08:16:58.303319
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os
    import time

    # Test for log file rotation
    tornadocommandlineoptions = tornado.options.define("tornadocommandlineoptions",default="test command line options")
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 2
    os.environ["TORNADO_LOG_FILE_PREFIX"] = "test_logs/tornado.log"
    test_time = time.strftime("%Y%m%d",time.localtime())
    enable_pretty_logging()
    logger = logging.getLogger()
   

# Generated at 2022-06-26 08:17:03.318971
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    log_formatter = LogFormatter(color=color, colors=colors)
    assert log_formatter

    #Test if the log_formatter is an instance of LogFormatter
    assert isinstance(log_formatter, LogFormatter)



# Generated at 2022-06-26 08:17:15.016120
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter(color=True)
    from logging import LogRecord
    import datetime
    log_record=LogRecord(
        name="temperature",
        level=logging.ERROR,
        fn="temperature_recorder.py",
        lno=18,
        msg="temperature is too high",
        args=(),
        exc_info=None,
    )
    log_record.asctime=datetime.datetime.now().strftime(fmt.datefmt)
    print(fmt.format(log_record))


# Generated at 2022-06-26 08:17:25.322033
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_command_line()  # type: ignore
    enable_pretty_logging(
        options=tornado.options.options,
        logger=logging.getLogger(),
    )
    logger = logging.getLogger()
    logger.info("Test enable_pretty_logging")

if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:17:38.460423
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options

    define("port", default=8000, help="run on the given port", type=int)
    define("logging", default="debug", help="logging level")
    define("log_to_stderr", default=True, help="also log to stderr", type=bool)
    define("log_file_prefix", default="logfile", help="log file name prefix")
    define("log_file_max_size", default=10, help="maximum size of log file", type=float)
    define("log_file_num_backups", default=5, help="number of log files to keep", type=int)
    define("log_rotate_mode", default="none", help="rotate mode of log files", type=str)

# Generated at 2022-06-26 08:17:53.065602
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_format = LogFormatter()
    record = logging.LogRecord(
        name=None,
        level=logging.DEBUG,
        pathname=None,
        lineno=0,
        msg=None,
        args=None,
        exc_info=None,
    )
    print(log_format.format(record))
    record.levelno = logging.INFO
    print(log_format.format(record))
    print(
        "log_format.format(record)=" + log_format.format(record) + ", end"
    )



# Generated at 2022-06-26 08:17:54.957227
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert isinstance(f, logging.Formatter)


# Generated at 2022-06-26 08:18:03.541628
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" # noqa: E501
    assert log_formatter._colors == {
        10: 4,
        20: 2,
        30: 3,
        40: 1,
        50: 5
    }
    assert log_formatter._normal == ""

# Test case for _safe_unicode

# Generated at 2022-06-26 08:18:05.650889
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    define_logging_options()
    enable_pretty_logging()


# Generated at 2022-06-26 08:18:13.880964
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    author = "Matthew Ma, matthewma@outlook.com"
    header = "TEST CASE: tornado.options.enable_pretty_logging"
    print("\n{0}\n{1}\n{2}\n".format("=" * len(header), header, "=" * len(header)))
    import tornado.options
    tornado.options.enable_pretty_logging(options=None, logger=None)
    # Tear down logger

    print("\n{0}\n{1}\n{2}\n".format("=" * len(header), "DONE", "=" * len(header)))


# Generated at 2022-06-26 08:18:25.383917
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print("----- test_LogFormatter_format start -----")

    fmt_str = "%(color)s%(levelname)s%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"

    colors_dict = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    lf = LogFormatter(fmt=fmt_str, datefmt=datefmt, colors=colors_dict)

    r = logging.makeLogRecord({"levelname": "DEBUG", "message": "test_debug"})

# Generated at 2022-06-26 08:18:27.156063
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT


# Generated at 2022-06-26 08:18:28.750032
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-26 08:18:34.278900
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter().format(logging.LogRecord("tornado.access", logging.DEBUG, 'C:/Users/yunzhongke/PycharmProjects/crawler/tornado/web.py', 395, 'tornado.access:395 : %s',(),None,None))
    print(fmt)


# Generated at 2022-06-26 08:18:46.226558
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Enable pretty logging before options.parse_command_line/parse_config_file
    #
    # The following procedures will set options.logging,
    # options.log_file_prefix and options.log_to_stderr
    import tornado.options
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_to_stderr", default=False)
    tornado.options.define("log_file_prefix", default=r"d:\Tornado.log")
    tornado.options.parse_command_line([])
    enable_pretty_logging()

    # Enable pretty logging after options.parse_command_line/parse_config_file
    #
    # If we don't specify logging, log_file_prefix and log_to_stderr,
    # the default value will be

# Generated at 2022-06-26 08:19:07.653169
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # # test case 1
    # if options.logging is None or options.logging.lower() == "none":
    #     return
    options = namedtuple('options', 'logging,log_file_prefix')
    options.logging = None
    assert enable_pretty_logging(options) == None
    # # test case 2
    # if options.logging is None or options.logging.lower() == "none":
    #     return
    options = namedtuple('options', 'logging,log_file_prefix')
    options.logging = 'none'
    assert enable_pretty_logging(options) == None
    # # test case 3
    # if options.log_file_prefix:
    #     rotate_mode = options.log_rotate_mode
    #     if rotate_mode == "size

# Generated at 2022-06-26 08:19:17.559530
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(datefmt="%Y-%m-%d %H:%M")
    LogFormatter(fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s")
    LogFormatter(color=False)
    LogFormatter(colors={logging.DEBUG: 1, logging.INFO: 2})


if __name__ == "__main__":
    import os
    import sys
    import unittest

    support.run_unittest(__name__)

# Generated at 2022-06-26 08:19:18.733024
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    define_logging_options()
    enable_pretty_logging()
    print( "Are there any errors?" )


# Generated at 2022-06-26 08:19:28.258154
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Constructor args:
    # fmt, datefmt, style, color, colors
    fmt = "fmt"
    datefmt = "datefmt"
    style = "style"
    color = True
    colors = {}
    # Create an instance of LogFormatter
    lf = LogFormatter(fmt, datefmt, style, color, colors)
    # Check attributes of instance
    assert lf._fmt == fmt
    assert lf._colors == colors
    assert lf._normal == ""


# Generated at 2022-06-26 08:19:41.758088
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # fmt = 
    # "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s",
    # datefmt="%Y-%m-%d %H:%M:%S",
    # style='%', color=True):
    formatter = LogFormatter()
    
    # Access file
    log_file_access = 'access.log'
    # app_log = logging.getLogger("tornado.application")
    access_log.setLevel(logging.DEBUG)
    handler_access = logging.FileHandler(log_file_access)
    handler_access.setFormatter(formatter)
    access_log.addHandler(handler_access)
    
    # Application file

# Generated at 2022-06-26 08:19:42.777633
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    print(type(f))


# Generated at 2022-06-26 08:19:49.113549
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True, colors={}, fmt="")
    assert formatter._colors == {}
    assert formatter._normal == ""


# Generated at 2022-06-26 08:19:51.008330
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformat = LogFormatter()
    assert logformat != None


# Generated at 2022-06-26 08:20:01.597257
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.web
    import tornado.ioloop
    import tornado.options
    import tornado.escape

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    tornado.options.define("port", default=8888, help="run on the given port", type=int)
    tornado.options.define("log_file_prefix", default="./logs/tornado.log", type=str)
    tornado.options.define("log_rotate_mode", default="size", help="Log rotate mode for file logger", type=str)
    tornado.options.define("log_rotate_when", default="S", help="Log rotate mode for file logger", type=str)

# Generated at 2022-06-26 08:20:14.308882
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # The following show the default logging config
    enable_pretty_logging()

    # set logging level to warning
    def test_logging_warning():
        enable_pretty_logging(options={"logging": "warning"})

    # set logging level to debug
    def test_logging_debug():
        enable_pretty_logging(options={"logging": "debug"})

    # set logging level to debug and log_file_prefix
    # log_file_prefix must be a file path
    def test_logging_debug_log_file_prefix():
        enable_pretty_logging(
            options={
                "logging": "debug",
                "log_file_prefix": "tornado",
                "log_file_num_backups": 1,
            }
        )



# Generated at 2022-06-26 08:20:29.557206
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    formatter = LogFormatter(fmt, datefmt, color=False)
    assert type(formatter) == LogFormatter
    formatter = LogFormatter(fmt, datefmt, '%', True, { 4: 2, 3: 3, 1: 1 })
    assert type(formatter) == LogFormatter
    # assert formatter._colors == { 4: '\033[2;32m', 3: '\033[2;33m', 1: '\033[2;31m' }

# Generated at 2022-06-26 08:20:38.155075
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import logging
    import logging.config
    import tornado.options

    # We need to know if the logging system is configured before we
    # can set the log options.
    _logging_configured = logging.getLogger().handlers

    #--log_file_prefix=<path>  Path prefix for log files. Note that if you are running
    #                          multiple tornado processes, log_file_prefix must be
    #                          different for each of them (e.g. include the port number)
    #--log_to_stderr           Send log output to stderr (colorized if possible).
    #                          By default use stderr if --log_file_prefix is not set and
    #                          no other logging is configured.
    #--logging=debug|info|warning|error|none  Set the Python log level.

# Generated at 2022-06-26 08:20:39.581315
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:20:44.426743
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


DEFAULT_LOGGING_FORMAT = (
    "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
)



# Generated at 2022-06-26 08:20:51.548779
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    formatter = LogFormatter(fmt, datefmt, "%", color, colors)


# Generated at 2022-06-26 08:20:59.097886
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf=LogFormatter(color=False)
    #create a record
    record=logging.LogRecord('tornado.general','INFO','','0','','','','','','','','','','','','','')
    record.exc_info=None
    record.funcName=None
    record.lineno=0
    record.levelname='INFO'
    record.msg='A test for class LogFormatter'
    record.name='tornado.general'
    record.pathname='/etc/default'
    record.process=None
    record.processName=None
    record.relativeCreated=None
    record.thread=None
    record.threadName=None
    record.args=None
    record.module=None
    record.msecs=None
    #format a message

# Generated at 2022-06-26 08:21:08.953178
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    from datetime import datetime

    define("logging", default="debug", help="logging level")
    define("log_file_prefix", default="./tst.log", help="log file name")
    define("log_rotate_mode", default="time", help="log rotate mode")
    define("log_rotate_when", default="MIDNIGHT", help="log rotate when")
    define("log_rotate_interval", default=1, help="log rotate interval")
    define("log_file_num_backups", default=1, help="log file num of backups")
    options.parse_config_file("tornado_log.cfg")
    options.parse_command_line()
    # print("Test case 0 start!!! ", datetime.now().strftime("%Y

# Generated at 2022-06-26 08:21:13.447848
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter.DEFAULT_FORMAT

    logging.basicConfig(
        level=logging.DEBUG,
        format=fmt,
    )

    gen_log.critical("critical 1")


# Generated at 2022-06-26 08:21:26.701307
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import sys
    import os
    import os.path

    set_parsed_options = False

    if tornado.options.options is None:
        set_parsed_options = True
        tornado.options.define("logging", default="none", help="logging")
        options = tornado.options.parse_command_line()
    
    options = tornado.options.options

    options.logging = "debug"
    # Create new log file
    options.log_file_prefix = os.path.join(os.path.dirname(__file__), "logs/test_enable_pretty_logging")
    options.log_file_max_size = 1
    options.log_file_num_backups = 3
    options.log_to_stderr = False
    options.log

# Generated at 2022-06-26 08:21:37.110973
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert isinstance(lf, LogFormatter) is True
    assert lf._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    assert lf._normal == ""
    assert len(lf.DEFAULT_COLORS) == 5


# Generated at 2022-06-26 08:21:49.487726
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_log_formatter = LogFormatter()

    assert isinstance(test_log_formatter._fmt, str)
    assert isinstance(test_log_formatter._colors, dict)
    assert isinstance(test_log_formatter._normal, str)



# Generated at 2022-06-26 08:22:02.851313
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    test_datefmt = "%y%m%d %H:%M:%S"
    test_style = "%"
    test_color = True
    test_colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }


# Generated at 2022-06-26 08:22:07.401738
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter() # type: Optional[LogFormatter]
    print(lf)
    print(lf.DEFAULT_FORMAT)
    #assert False



# Generated at 2022-06-26 08:22:15.095097
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    color = False
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = "%"
    colors = LogFormatter.DEFAULT_COLORS

    logger = logging.getLogger("test")
    lf = LogFormatter(color, fmt, datefmt, style, colors)

    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    logger.info("Just a random test")
    logger.info("End of random test")


# Generated at 2022-06-26 08:22:25.162063
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter("%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
                      "%y%m%d %H:%M:%S",
                      "%",
                      True,
                      {
                          logging.DEBUG: 4,  # Blue
                          logging.INFO: 2,  # Green
                          logging.WARNING: 3,  # Yellow
                          logging.ERROR: 1,  # Red
                          logging.CRITICAL: 5,  # Magenta
                      })


# Generated at 2022-06-26 08:22:29.065636
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    colorama.init()  # type: ignore
    logging.config.dictConfig({"version": 1})
    logFormatter = LogFormatter()
    print(logFormatter)
    print(logFormatter._normal)

# Generated at 2022-06-26 08:22:32.084503
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line

    parse_command_line()
    enable_pretty_logging()
    logging.info("Test for function enable_pretty_logging.")



# Generated at 2022-06-26 08:22:37.266517
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmter = LogFormatter("%(color)s%(message)s test%(end_color)s")
    # str(fmter) is not important here, so just ignore it.
    assert True


# Generated at 2022-06-26 08:22:45.912521
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    Logging_options = Options
    opts = Logging_options()
    opts.log_file_prefix = 'xxx'
    opts.log_rotate_mode = 'time'
    opts.log_rotate_when = 'S'
    opts.log_rotate_interval = 1
    opts.log_file_num_backups = 5
    opts.logging = 'debug'

    enable_pretty_logging(opts, access_log)
    enable_pretty_logging(opts, app_log)
    enable_pretty_logging(opts, gen_log)

    for level in 'debug', 'info', 'warning', 'error', 'critical':
        getattr(access_log, level)('test_log_access')

# Generated at 2022-06-26 08:22:51.733832
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "/home/k1/log_files/tornado-test.log"
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_file_max_size = 1024 * 1024 * 1024
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_to_stderr = False

    enable_pretty_logging()


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging

# Generated at 2022-06-26 08:23:06.786084
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging()
    # The above is equivalent to the following:
    # logger = logging.getLogger()
    # logger.setLevel(getattr(logging, options.logging.upper()))
    # channel = logging.StreamHandler()
    # channel.setFormatter(LogFormatter())
    # logger.addHandler(channel)

    #The following code is used to add log handler for a file
    #fh = logging.FileHandler("spam.log")
    #logger.addHandler(fh)


# Generated at 2022-06-26 08:23:19.041665
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(formatter="%(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    formatter = LogFormatter(formatter="%(message)s")
    formatter = LogFormatter(datefmt="%Y-%m-%d %H:%M:%S")
    formatter = LogFormatter(formatter="%(message)s", datefmt="%Y-%m-%d %H:%M:%S", style="%", color=False, colors={1:2, 2: 3})

# Generated at 2022-06-26 08:23:31.034564
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    
    # test case 1
    record = logging.LogRecord(
        name = 'tornado.general',
        level = logging.DEBUG,
        pathname = 'D:\\Documents\\Python\\Python37\\lib\\site-packages\\tornado\\web.py',
        lineno = 679,
        msg = '200 POST / (::1) 1.46ms',
        args = (),
        exc_info = None,
        func = None
    )
    assert lf.format(record) == '[D 20190117 15:19:16 web:679] 200 POST / (::1) 1.46ms'

    # test case 2
    record.level = logging.INFO

# Generated at 2022-06-26 08:23:38.699039
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # create a record
    rec = logging.LogRecord(
        name = "tornado",
        level = logging.DEBUG,
        pathname = 'log_test.py',
        lineno = 11,
        msg = "test_msg",
        args = None,
        exc_info = None,
    )

    formatter = LogFormatter()
    formatter.format(rec)
    rec.getMessage()


# Generated at 2022-06-26 08:23:45.476736
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(format = '%(asctime)s %(message)s')

    logging.debug("hello debug")
    logging.info("hello info")
    logging.warning("hello warning")
    logging.error("hello error")


# Generated at 2022-06-26 08:23:48.109528
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_fcn = LogFormatter
    assert(test_fcn())
    
    

# Generated at 2022-06-26 08:23:58.283695
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    print("formatter =", formatter)
    print("formatter._fmt =", formatter._fmt)
    print("formatter._colors =", formatter._colors)
    print("formatter._normal =", formatter._normal)

test_case_0()
test_LogFormatter()

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-26 08:24:00.631919
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.enable_pretty_logging(logger="test_enable_pretty_logging")


# Generated at 2022-06-26 08:24:02.822101
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert isinstance(LogFormatter, object)


# Generated at 2022-06-26 08:24:05.040430
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf


# Generated at 2022-06-26 08:24:20.194129
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf._fmt == lf.DEFAULT_FORMAT
    assert lf._colors == {}
    assert lf._normal == ""

    lf2 = LogFormatter(color=False, colorama=True)
    assert lf2._normal == ""
    assert lf2._colors == {}


# Generated at 2022-06-26 08:24:23.963021
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    try:
        assert True
    except AssertionError:
        print("Exception occurred for function test_enable_pretty_logging")



# Generated at 2022-06-26 08:24:32.735052
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "[%(levelname)s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    datefmt = "%Y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    formatter = LogFormatter(fmt, datefmt, style, color, colors)
    assert formatter


# Generated at 2022-06-26 08:24:42.152964
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import unittest.mock
    from datetime import datetime


    mock_record = unittest.mock.Mock()
    mock_record.levelno = logging.DEBUG
    mock_record.getMessage.return_value = "test"
    mock_record.exc_info = None
    mock_record.exc_text = None
    mock_record.asctime = datetime.now()

    logger = LogFormatter()
    logger.format(mock_record)
