

# Generated at 2022-06-26 08:15:16.049707
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import options
    import logging
    logger = logging.getLogger()
    options.define_logging_options()
    parse_command_line_args = ["--log_file_prefix=aa.log",
                               "--logging=info",
                               "--log_file_max_size=100",
                               "--log_file_num_backups=3"]
    logger.setLevel(getattr(logging, "INFO"))
    tornado.options.parse_command_line(parse_command_line_args)
    enable_pretty_logging()
    logger = logging.getLogger()
    print(logger.handlers)


# Generated at 2022-06-26 08:15:24.513566
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Initilization
    record = logging.LogRecord(
        name="root", 
        level=logging.DEBUG,
        pathname="C:/Users/jimy/Desktop/python/tornado/tornado/web.py",
        lineno=32,
        msg="",
        args=None,
        exc_info=None,
    )
    log_formatter = LogFormatter()
    log_formatter.format(record)


# Utility function for suppress_error output.

# Generated at 2022-06-26 08:15:33.369983
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.application",
        level=logging.DEBUG,
        fn="<test.py>",
        lno=34,
        msg="",
        args=[],
        exc_info=None,  # noqa: B008
    )
    formatter.format(record)


# Generated at 2022-06-26 08:15:40.202311
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"



# Generated at 2022-06-26 08:15:45.686423
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    import tornado.options

    tornado.options.parse_command_line()
    enable_pretty_logging()
    app_log.info("test")

# Generated at 2022-06-26 08:15:59.731136
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print("===== enter test_LogFormatter_format")
    # Create a logger object.
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # Create handlers
    c_handler = logging.StreamHandler()
    f_handler = logging.FileHandler('file.log')
    c_handler.setLevel(logging.DEBUG)
    f_handler.setLevel(logging.DEBUG)
    # Create formatters and add it to handlers
    c_format = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
    f_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# Generated at 2022-06-26 08:16:08.648732
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    print(log_formatter)

    log_formatter = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        style="%",
        color=True,
        colors = LogFormatter.DEFAULT_COLORS
    )
    print(log_formatter)


# Generated at 2022-06-26 08:16:18.685354
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # logging.config.dictConfig(LOGGING)

    # To generate a set of at least 3 different logs
    for i in range(3):
        for l in [logging.DEBUG, logging.INFO, logging.ERROR]:
            gen_log.log(l, "GenLog: %d, %s", i, l)
        for l in [logging.DEBUG, logging.INFO, logging.ERROR]:
            app_log.log(l, "AppLog: %d, %s", i, l)
        for l in [logging.DEBUG, logging.INFO, logging.ERROR]:
            access_log.log(l, "AccessLog: %d, %s", i, l)
    print()


# Generated at 2022-06-26 08:16:32.388752
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print("start logformatter format test")
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    fmt_date = "%y%m%d %H:%M:%S"
    time_style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    myFormatter = LogFormatter(fmt, fmt_date, time_style, color,colors)

# Generated at 2022-06-26 08:16:39.740217
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter._fmt, str)
    assert isinstance(log_formatter._colors, dict)
    assert isinstance(log_formatter._normal, str)
    assert not log_formatter._colors
    return log_formatter


# Generated at 2022-06-26 08:16:57.635236
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # fmt, datefmt, style, color, colors
    lf = LogFormatter('%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s', '%y%m%d %H:%M:%S', '%', True, {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5,} )



# Generated at 2022-06-26 08:17:03.803043
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("test_enable_pretty_logging")

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    channel = logging.StreamHandler()
    channel.setFormatter(LogFormatter())
    logger.addHandler(channel)

    logging.debug("Test enable_pretty_logging(logger=logger)")
    enable_pretty_logging(logger=logger)


# Generated at 2022-06-26 08:17:17.126590
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    formatter = LogFormatter(fmt, datefmt, style, color, colors)

    # Test 1

# Generated at 2022-06-26 08:17:23.825624
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(
        fmt = LogFormatter.DEFAULT_FORMAT,
        datefmt = LogFormatter.DEFAULT_DATE_FORMAT,
        style = "%",
        color = True,
        colors = LogFormatter.DEFAULT_COLORS,
    )


# Generated at 2022-06-26 08:17:30.496767
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # create logger that prints to standard output
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = LogFormatter()
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)

    test_log = logging.getLogger("tornado.test.format")
    test_log.debug("test message")
    test_log.warning("test message")
    test_log.error("test message")
    test_log.critical("test message")

# def test_case_1():
#     define_logging_options()
#    

# Generated at 2022-06-26 08:17:39.994845
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class MyLogRecord:
        msg = "msg"
        args = {}
        levelname = "DEBUG"
        lineno = 23
        module = "test_log"
        funcName = None
        pathname = None
        filename = None
        exc_info = None
        exc_text = None
        stack_info = None
        created = None
        msecs = None
        relativeCreated = None
        thread = None
        threadName = None
        processName = None
        asctime = None
        color = None
        end_color = None
        levelno = None
        def getMessage(self) -> str:
            return self.msg

    with open("tmp.log", "w") as fp:
        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)

# Generated at 2022-06-26 08:17:52.509313
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    options = tornado.options.options
    options.logging = logging.INFO
    options.log_to_stderr = True
    #options.log_rotate_mode = 'size'
    options.log_rotate_mode = "time"
    #options.log_file_prefix = '/var/log/tornado/tornado.log'
    options.log_file_prefix = "tornado.log"
    options.log_file_max_size = 1024 * 1024 * 1024 * 1024
    options.log_file_num_backups = 5
    options.log_rotate_when = 'D'
    options.log_rotate_interval = 1
    enable_pretty_logging()

# Generated at 2022-06-26 08:17:54.129564
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:18:04.458479
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG,
                        format="%(levelname)s %(asctime)s %(filename)s %(funcName)s %(lineno)d %(message)s",
                        datefmt="%a %d %b %Y %H:%M:%S")
    stream_handler = logging.StreamHandler()
    formatter = LogFormatter(
        color=False,
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    )
    stream_handler.setFormatter(formatter)
    logging.getLogger().addHandler(stream_handler)



# Generated at 2022-06-26 08:18:14.739612
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    colorama.init(wrap=False)
    formatter = LogFormatter(color=True)
    # case 0
    record = logging.LogRecord('tornado', logging.DEBUG, 'tornado/test.py', 1, 'Test', (), None)
    assert formatter.format(record) == u'\x1b[2;34m[D 160920 14:49:59 test:1]\x1b[0m Test'
    # case 1
    record = logging.LogRecord('tornado', logging.INFO, 'tornado/test.py', 1, 'Test', (), None)
    assert formatter.format(record) == u'\x1b[2;32m[I 160920 14:49:59 test:1]\x1b[0m Test'
    # case 2
    record = logging.Log

# Generated at 2022-06-26 08:18:34.738418
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:18:45.455164
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = parse_command_line([
        "--logging=debug",
        "--log_file_prefix=test.log",
        "--log_to_stderr=1"
    ])
    enable_pretty_logging(options, access_log)
    enable_pretty_logging(options, app_log)
    enable_pretty_logging(options, gen_log)

    access_log.info("abc")
    app_log.info("abc")
    gen_log.info("abc")
    root = logging.getLogger()
    root.info("abc")
    root.debug("abc")

import tornado.options


# Generated at 2022-06-26 08:18:56.242867
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("Testing the constructor of class LogFormatter")
    logFmt = LogFormatter()
    print("LogFormatter() : ", logFmt)
    print("LogFormatter() DEFAULT_FORMAT: ", LogFormatter.DEFAULT_FORMAT)
    print("LogFormatter()._fmt :", logFmt._fmt)
    print("LogFormatter().DEFAULT_COLORS: ", LogFormatter.DEFAULT_COLORS)
    print("LogFormatter()._colors: ", logFmt._colors)
    assert(logFmt._fmt == LogFormatter.DEFAULT_FORMAT)
    print("\n")
    

# Generated at 2022-06-26 08:19:07.316342
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    import shutil
    import sys
    import time

    if "TRAVIS" in os.environ:
        raise unittest.SkipTest("pretty logging is incompatible with travis")

    options = tornado.options.options
    options.define("log_file_prefix", type=str, default="test_log.txt")
    options.define("log_file_num_backups", type=int, default=2)
    options.define("log_file_max_size", type=long, default=10 * 1000)
    options.define("log_rotate_mode", type=str, default="size")
    options.define("log_rotate_when", type=str, default="S")

# Generated at 2022-06-26 08:19:17.191523
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        style="%",
        color=True,
        colors={
            logging.DEBUG: 4,
            logging.INFO: 2,
            logging.WARNING: 3,
            logging.ERROR: 1,
            logging.CRITICAL: 5,
        },
    )


# Generated at 2022-06-26 08:19:22.926667
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    define_logging_options()
    tornado.options.parse_command_line()
    enable_pretty_logging()
    logging.info("Hello!")


# Generated at 2022-06-26 08:19:31.660541
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    fmt = LogFormatter(fmt="hi")
    fmt = LogFormatter(fmt="hi", datefmt="hi")
    fmt = LogFormatter(fmt="hi", datefmt="hi", style="hi")
    fmt = LogFormatter(fmt="hi", datefmt="hi", style="hi", color="hi")
    fmt = LogFormatter(fmt="hi", datefmt="hi", style="hi", color="hi", colors={})
    fmt = LogFormatter(fmt=None, datefmt="hi", style="hi", color="hi", colors={})


# Generated at 2022-06-26 08:19:35.377835
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:19:43.087281
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(fmt="<test>%(asctime)</test>")
    LogFormatter(datefmt="%Y%m%d")
    LogFormatter(style="%")
    LogFormatter(color=True)
    LogFormatter(colors={logging.DEBUG: 4})
    LogFormatter(fmt="<test>%(asctime)s</test>", datefmt="%Y%m%d", style="%", color=True, colors={logging.DEBUG: 4})



# Generated at 2022-06-26 08:19:52.203292
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter("1", "2", "3", True, {1: 2})
    assert logFormatter.format({
        'asctime': '1234',
        'levelno': 1,
        'message': 'message'
    }) == '\x1b[2;32m1\x1b[0m message'


# Generated at 2022-06-26 08:20:20.626833
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = 'DEBUG'
    options.log_file_prefix = 'test.log'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 10
    options.log_file_num_backups = 2
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    enable_pretty_logging()
    print(logger.handlers)

# Generated at 2022-06-26 08:20:29.430474
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    # First, let us test how the log message will be formatted when the
    # color flag is turned off. The instantiation of the logger object will
    # set the color flag to False.

    # Instantiate logger object. As the user did not provide the color flag
    # argument, the logger object will automatically turn off the color flag.
    # The color flag argument is set to True by default.
    lgfmt = LogFormatter()

    # Let us construct a log message for demonstration. In the real world, log
    # messages are typically constructed when the logging framework calls the
    # format function.
    record = logging.LogRecord("name", logging.DEBUG, "path", 1,
                               "message", None, None)
    # The log message will not be colored when the format function is called.

# Generated at 2022-06-26 08:20:39.518772
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    _formatter = LogFormatter(
        fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
        datefmt='%y%m%d %H:%M:%S'
    )
    _record = logging.LogRecord(
        'name', logging.INFO, 'pathname', 0, 'msg', args=None, exc_info=None, func=None
    )
    _formatter.format(_record)

    # Test if default value of fmt is valid
    _formatter = LogFormatter()
    _formatter.format(_record)


# Generated at 2022-06-26 08:20:44.102870
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    options = tornado.options.options
    options.logging = "info"

    logger = logging.getLogger()
    handler = logger.handlers[0]
    assert isinstance(handler, logging.StreamHandler)



# Generated at 2022-06-26 08:20:52.169287
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # (1) Generate a test log record
    record = logging.LogRecord("tornado.application", logging.DEBUG, "", 0, "", "", "")
    # (2) Initialize an instance of LogFormatter
    log_formatter = LogFormatter()
    # (3) Call format
    log_formatter.format(record)



# Generated at 2022-06-26 08:20:58.009308
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers

    LOG_FILE = 'test_log.out'
    formatter = LogFormatter()
    handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1048576, backupCount=5)
    handler.setFormatter(formatter)
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.NOTSET)

    logger.info('This is a test!')


# python log_test.py
# tail -f test_log.out

# Generated at 2022-06-26 08:21:08.615081
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define as define_option, options

    def define_logging_options():
        # logging_mixin.py
        define_option(
            "logging",
            default="info",
            metavar="debug|info|warning|error|none",
            help=("Set the Python log level. If 'none', tornado won't touch the "
                  "logging configuration."),
            callback=enable_pretty_logging)
        define_option(
            "log_file_prefix",
            metavar="PATH",
            help=("Path prefix for log files. "
                  "Note that if you are running multiple tornado processes, "
                  "log_file_prefix must be different for each of them (e.g. "
                  "include the port number)"))

# Generated at 2022-06-26 08:21:15.862998
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    define_logging_options()
    # fmt is default
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors != {}
    assert log_formatter._normal != ""
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert log_formatter._style == "%"

    # fmt is not default
    fmt = "test_fmt"
    log_formatter = LogFormatter(fmt)
    assert log_formatter._fmt == fmt
    assert log_formatter._colors != {}
    assert log_formatter._normal != ""
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert log_

# Generated at 2022-06-26 08:21:17.687527
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _log_formatter = LogFormatter()


# Generated at 2022-06-26 08:21:29.154061
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()

    import logging
    import logging.handlers
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                        datefmt='%m-%d %H:%M',
                        filename='myapp.log',
                        filemode='w')
    # define a Handler which writes INFO messages or higher to the sys.stderr
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    # set a format which is simpler for console use
    formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
    # tell the handler to use this format
    console.setFormatter(formatter)
   

# Generated at 2022-06-26 08:21:49.167857
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    enable_pretty_logging(logger=logger)

# Generated at 2022-06-26 08:21:54.204582
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    enable_pretty_logging(logger=logging.getLogger("tornado"))

# This function will be used by Strom.py to enable pretty logging.

# Generated at 2022-06-26 08:21:57.436115
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    log_formatter_0.format(None)

# Generated at 2022-06-26 08:22:02.519548
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()

    record_0 = logging.LogRecord(
        'tornado.access', logging.INFO, '/usr/local/lib/python3.6/tornado/log.py', 100, 'info', None, None)
    record_0.levelno = logging.INFO

    log_formatter_0.format(record_0)

# Generated at 2022-06-26 08:22:05.401339
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()

# Unit tests for class LogFormatter

# Generated at 2022-06-26 08:22:06.850070
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# Generated at 2022-06-26 08:22:17.376456
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import os
    import shutil
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def _options(**kwargs: Any) -> None:
        old = tornado.options.options.group_dict()
        try:
            tornado.options.define("logging", default=None, help=None, type=str)
            for k, v in kwargs.items():
                tornado.options.define(k, default=v, help=None, type=type(v))
            tornado.options.parse_command_line([])
            yield
        finally:
            tornado.options.options.clear()
            for k, v in old.items():
                tornado.options.options.add_parse_callback(k, v, None)


# Generated at 2022-06-26 08:22:25.880363
# Unit test for constructor of class LogFormatter

# Generated at 2022-06-26 08:22:34.988422
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create a log record
    record = logging.LogRecord("test_logger_name", logging.DEBUG, "", 0, "test msg", [], None)
    # Set color to false
    record.color = False
    # Set end_color to false
    record.end_color = False
    # Set datefmt to an empty string
    record.datefmt = ""
    # Set time to 0
    record.time = 0
    # Set created to 0
    record.created = 0
    # Set exc_info to None
    record.exc_info = None
    # Set exc_text to None
    record.exc_text = None

    # Get LogFormatter object
    log_formatter = LogFormatter()

    # Call the format method
    # This is just a skeleton test
    # TODO: Add more test vectors

# Generated at 2022-06-26 08:22:39.525853
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test 0
    log_formatter_0 = LogFormatter()
    return not hasattr(log_formatter_0, "format")


# Generated at 2022-06-26 08:23:33.381655
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options_0 = []
    logger_0 = []
    enable_pretty_logging(options=options_0, logger=logger_0)

# Generated at 2022-06-26 08:23:36.469179
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter, LogFormatter)

# Generated at 2022-06-26 08:23:40.670779
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)

if __name__ == "__main__":
    test_case_0()
    test_define_logging_options()

# Generated at 2022-06-26 08:23:45.117138
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("Testing constructor of class LogFormatter...")
    test_case_0()
    print("Passed\n")


# Generated at 2022-06-26 08:23:50.936797
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # prepare testing data
    import tornado.options
    # import tornado.options
    log_to_stderr = False
    log_file_prefix = "test.log"
    log_rotate_mode = "size"
    log_rotate_when = "D"
    log_rotate_interval = 1
    log_file_max_size = 52428800
    log_file_num_backups = 5
    logging_level = "DEBUG"
    # call function
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-26 08:23:53.646591
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert type(test_case_0()) == LogFormatter

test_case_1 = LogFormatter()

# Generated at 2022-06-26 08:23:57.922268
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        test_case_0()
    except NameError:
        return False
    except Exception:
        return False
    else:
        return True



# Generated at 2022-06-26 08:24:00.470181
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:24:11.355233
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    tests = [
        # Constructor of LogFormatter with arguments fmt, datefmt, style, color, colors
        # The call is_instance(LogFormatter, logging.Formatter) should be true
        (0, LogFormatter(), logging.Formatter, True),
        # The call LogFormatter().format should return a string
        (1, LogFormatter().format(None), str, True)
    ]
    for test_nr, result, expected, equal in tests:
        if isinstance(expected, type):
            result_ok = isinstance(result, expected)
        else:
            result_ok = result == expected
        assert result_ok == equal, "Test failed on test nr: {}".format(test_nr)


# Generated at 2022-06-26 08:24:18.806921
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_record = logging.LogRecord(
        name="some-name",
        level=10,
        pathname="/some",
        lineno=1,
        msg="some-message",
        args=(),
        exc_info=None,
    )
    log_formatter_0 = LogFormatter()
    log_formatter_0.format(test_record)