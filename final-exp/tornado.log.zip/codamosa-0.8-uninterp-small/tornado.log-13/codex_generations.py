

# Generated at 2022-06-26 08:14:57.593608
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    print(log_formatter._fmt)


# Generated at 2022-06-26 08:15:06.254914
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def test_module_0():
        # module 0
        logger = logging.getLogger("test0")
        logger.info('Hello world')
    test_module_0()

    def test_module_1():
        # module 1
        logger = logging.getLogger("test1")
        logger.info('Hello world')
    test_module_1()

    def test_module_2():
        # module 2
        logger = logging.getLogger("test2")
        logger.info('Hello world')
    test_module_2()

    def test_module_3():
        # module 3
        logger = logging.getLogger("test3")
        logger.info('Hello world')
    test_module_3()


# Generated at 2022-06-26 08:15:15.598498
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado
    import logging

    test_case_0()

    # Case 1: log_file_prefix is None, log_file_num_backups is not None
    options = tornado.options.options
    options.logging = "info"
    options.log_file_prefix = None
    options.log_rotate_mode = "size"
    options.log_file_max_size = 100
    options.log_file_num_backups = 5
    options.log_rotate_when = "S"
    options.log_rotate_interval = 1
    options.log_to_stderr = True
    logger = logging.getLogger()
    logger.info("hello")
    enable_pretty_logging(options, logger)
    handler = logger.handlers[0]

# Generated at 2022-06-26 08:15:26.214520
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(fmt = fmt,
                             datefmt = datefmt,
                             style = style,
                             color = color,
                             colors = colors)

# Generated at 2022-06-26 08:15:27.098963
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()


# Generated at 2022-06-26 08:15:28.660015
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-26 08:15:30.117646
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter.format()
    pass


# Generated at 2022-06-26 08:15:39.506464
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class DummyRecord(object):
        pass

    # Test 1
    fmt = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    datefmt = '%y%m%d %H:%M:%S'
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(fmt, datefmt, style, color, colors)

    record = DummyRecord()

# Generated at 2022-06-26 08:15:41.329127
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()


# Generated at 2022-06-26 08:15:48.720869
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    format_str = "%(asctime)s [%(levelname)s] %(message)s"
    datefmt = '%Y-%m-%d %H:%M:%S.%f'
    formatter = LogFormatter(format_str, datefmt)
    print(formatter)

    record = logging.makeLogRecord({})
    formatted = formatter.format(record)
    print(formatted)

    # use default format
    formatter = LogFormatter()
    formatted = formatter.format(record)
    print(formatted)



# Generated at 2022-06-26 08:16:07.619907
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("Enable logging")

    import tornado.options
    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("logging", type=str)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("log_rotate_interval", type=int)
    tornado.options.define("log_to_stderr", type=bool)

    tornado.options.options.log_file_prefix = "_tornado_test.log"
    tornado.options.options.log_file_max

# Generated at 2022-06-26 08:16:17.231763
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    enable_pretty_logging()
    print()
    print("Testing __init__(self, fmt=DEFAULT_FORMAT, datefmt=DEFAULT_DATE_FORMAT, style='%', color=True, colors=DEFAULT_COLORS)")
    print()
    print("Creating new LogFormatter")
    LogFormatter()
    print("LogFormatter created")
    print()


# Generated at 2022-06-26 08:16:21.978683
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    # tornado.format.LogFormatter object at 0x7f55366e5c88>
    fmt_instance = LogFormatter(
        fmt, datefmt, style, color, colors
    )
    return fmt_instance



# Generated at 2022-06-26 08:16:25.038718
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:16:26.589432
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

# Unit test

# Generated at 2022-06-26 08:16:35.162275
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("logging", default="none", type=str,
        help="The logging level")
    tornado.options.define("log_file_prefix", default=None, type=str,
        help="log file pathname prefix")
    tornado.options.define("log_file_max_size", type=int, default=50*1024*1024)
    tornado.options.define("log_file_num_backups", type=int, default=10)
    tornado.options.define("log_rotate_mode", type=str, default="size")
    tornado.options.define("log_rotate_when", type=str, default="D")
    tornado.options.define("log_rotate_interval", type=int, default=24)

# Generated at 2022-06-26 08:16:36.707528
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-26 08:16:38.458382
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-26 08:16:40.539144
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # just call it and see if it gives exceptions
    test_case_0()


# Generated at 2022-06-26 08:16:42.977246
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:17:03.065090
# Unit test for constructor of class LogFormatter

# Generated at 2022-06-26 08:17:15.177237
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    datefmt = '%Y-%m-%d %H:%M:%S'
    fmt = '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'
    formatter = LogFormatter(
        fmt=fmt,
        datefmt=datefmt,
        color=False,
        colors=None)
    assert formatter._fmt == fmt
    assert formatter.datefmt == datefmt
    assert formatter._colors == {}
    assert formatter._normal == ""


# Generated at 2022-06-26 08:17:27.867364
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if sys.platform.startswith('win'):
        assert _stderr_supports_color() is False
    else:
        assert _stderr_supports_color() is True

    color=True
    colors = LogFormatter.DEFAULT_COLORS
    # test case of curses is not present
    formatter = LogFormatter(color=color, colors=colors)
    assert isinstance(formatter, LogFormatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

# Generated at 2022-06-26 08:17:38.839280
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    opts = {"fmt": '%(levelname)s'}
    # opts['fmt'] = '%(levelname)s'
    fmt = "%(levelname)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        "DEBUG": 4,
        "INFO": 2,
        "WARNING": 3,
        "ERROR": 1,
        "CRITICAL": 5
    }
    LogFormatter(fmt, datefmt, style, color, colors)

    # check singleton
    LogFormatter(**opts)  # type: ignore
    LogFormatter(**opts)  # type: ignore



# Generated at 2022-06-26 08:17:43.441149
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    class Vars:
        def __init__(self):
            self.__dict__ = {"color":1, "end_color":2, "levelname":3, "asctime":4,"module":5,"lineno":6,"message":7}
    record = Vars()
    formatted = formatter.format(record)
    # Get unit test result
    assert formatted == "[3 4 5:6] 2 7"


# Generated at 2022-06-26 08:17:53.574666
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    # Basic event
    record = logging.LogRecord(
        "myname",
        logging.INFO,
        pathname=None,
        lineno=None,
        msg="This is a test",
        args=(),
        exc_info=None,
    )

# Generated at 2022-06-26 08:17:57.492692
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()
else:
    print("Test finished")

# Generated at 2022-06-26 08:18:05.402636
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.log import app_log
    from tornado.options import define, options

    define("log_file_prefix", default="test.log")
    options.parse_command_line()

    log_file = "%s.%s" % (options.log_file_prefix, "2012-04-30_18-41-28")
    # print(log_file)
    formatter = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        color=True
    )

    ll = logging.getLogger()
    ll.handlers = []
   

# Generated at 2022-06-26 08:18:15.005015
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import os
    import shutil

    if not os.path.exists('log'):
        os.mkdir('log')
    if not os.path.exists('log/test'):
        os.mkdir('log/test')

    fkey = 'log_file_prefix'
    rkey = 'log_rotate_mode'
    sskey = 'log_file_max_size'
    sikey = 'log_file_num_backups'
    tskey = 'log_rotate_when'
    tikey = 'log_rotate_interval'

    class log_options():
        def __init__(self):
            pass

    import tornado.options
    import time
    import datetime
    import calendar

    # test log_rotate_mode is size
    options = log_options()

# Generated at 2022-06-26 08:18:17.840424
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter


# Generated at 2022-06-26 08:18:28.312217
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:29.931701
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # No tracing for this function
    test_case_0()
    gen_log.critical("critical: I am a critical log")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:32.042341
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    enable_pretty_logging()
    enable_pretty_logging()
    enable_pretty_logging()


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:40.320110
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.getLogger("tornado.general").critical("critical")
    logging.getLogger("tornado.application").warning("warning")
    logging.getLogger("tornado.access").info("info")
    logging.getLogger("tornado.general").debug("debug")
    logging.getLogger("tornado.application").error("error")


# Generated at 2022-06-26 08:18:48.830752
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # create a logger
    logger = logging.getLogger(name='test')
    # set log level
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    #formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    formatter = LogFormatter(color=True)
    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')

# Generated at 2022-06-26 08:18:49.334376
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = LogFormatter()


# Generated at 2022-06-26 08:18:54.433486
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("============= Unit test for function enable_pretty_logging ==================")
    test_case_0()
    print("============= Unit test for function enable_pretty_logging ==================")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:19:00.656750
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter(datefmt="%Y-%m-%d")
    fmt.format(logging.LogRecord("tornado.general", logging.INFO, "unit test", 0, "Test", None, None))  # noqa: E501



# Generated at 2022-06-26 08:19:04.868605
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        test_case_0()
    except Exception as e:
        print("Error: %s" % str(e))
        raise

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:19:09.782736
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    gen_log.info("test_enable_pretty_logging OK")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:19:29.020780
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Get current formatter
    tf = LogFormatter()

    # Make up a record with a message
    tr = logging.LogRecord(name='foo', level=100, pathname="bar", lineno=0, msg="baz", args=(), exc_info=None)

    # Check method format 
    tf.format(tr)

    # Make up a record with a message and a stack trace
    tr_ex = logging.LogRecord(name='foo', level=100, pathname="bar", lineno=0, msg="baz", args=(), exc_info=(ZeroDivisionError(), object(), object()))

    # Check method format 
    tf.format(tr_ex)


# Generated at 2022-06-26 08:19:42.188487
# Unit test for constructor of class LogFormatter

# Generated at 2022-06-26 08:19:52.408884
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    def stderr_with_colorama() -> logging.StreamHandler:
        if colorama:
            # This is a big hack; colorama doesn't expose a way to use
            # its native implementation of StreamHandler, so we have
            # to set colors to empty strings and use its wrap_stream
            # function to replace sys.stderr with a wrapper that will
            # translate ANSI color codes back to Win32 console colors
            # during the test.
            colors = LogFormatter()._colors
            for key in colors:
                colors[key] = ""
            wrapped_stderr = colorama.initialise.wrap_stream(sys.stderr, strip=False)
            handler = logging.StreamHandler(wrapped_stderr)

# Generated at 2022-06-26 08:19:54.885123
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    enable_pretty_logging()
    # f = log_format
    # gen_log.info("info")



# Generated at 2022-06-26 08:20:03.215791
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    formatter = LogFormatter(fmt, datefmt, style, color, colors)
    assert formatter._fmt == fmt
    assert formatter.datefmt == datefmt
    assert formatter._normal == ""



# Generated at 2022-06-26 08:20:18.609932
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=False,fmt='haha%(message)s')
    formatter.datefmt = 'hehe'
    record = logging.LogRecord('name1', 'level1', 'pathname1', 1, 'msg1', 'args1', 'exc_info1')
    ret = formatter.format(record)
    assert ret == 'haha[level1 hehe name1:1] msg1'
    record.message = 'msg2'
    record.levelno = logging.ERROR
    ret = formatter.format(record)
    assert ret == 'haha[level1 hehe name1:1] ERROR msg2'
    record.levelno = logging.INFO
    ret = formatter.format(record)

# Generated at 2022-06-26 08:20:20.101102
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    x = LogFormatter()
    pass



# Generated at 2022-06-26 08:20:25.060221
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logfmt = LogFormatter()
    assert logfmt._fmt == LogFormatter.DEFAULT_FORMAT
    assert logfmt._colors == {}
    assert logfmt._normal == ""

    logfmt = LogFormatter(color=False)
    assert logfmt._colors == {}
    assert logfmt._normal == ""


# Generated at 2022-06-26 08:20:26.575509
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()


# Generated at 2022-06-26 08:20:34.904288
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # The default value for color is True
    assert LogFormatter()._colors == {}

    # When colorama is not present, should return an empty string
    assert LogFormatter(color=True)._normal == ""

    # When curses is not present, should return an empty string
    assert LogFormatter(color=True)._normal == ""

    # When curses is not present, should return an empty string
    assert LogFormatter(color=False)._normal == ""

    # When curses is not present, should return an empty string
    assert LogFormatter(color=False)._normal == ""



# Generated at 2022-06-26 08:20:56.933604
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httputil

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            raise ValueError("LOL")
            raise tornado.web.HTTPError(403)
        def post(self):
            self.write("Hello, world")
            logging.debug("debug")
            logging.info("info")
            logging.warning("warning")
            logging.error("error")
            logging.critical("critical")

    class TestApp(object):
        def __init__(self, address, port):
            # Use the tornado app to listen for the request
            self.url = "http://%s:%d/%s" % (address, port, "")

           

# Generated at 2022-06-26 08:21:08.239195
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # no log file
    enable_pretty_logging()
    import tornado.options as options
    logger = logging.getLogger()
    logging_level = getattr(logging, options.options.logging.upper())
    assert logging_level == logger.level
    # no log handler
    logger.handlers[0].flush()
    logger.handlers[0].close()
    logger.handlers = []
    enable_pretty_logging()
    assert isinstance(logger.handlers[0], logging.StreamHandler)
    # no log handler but log file
    logger.handlers[0].flush()
    logger.handlers[0].close()
    logger.handlers = []
    options.options.log_file_prefix = "unit_test.log"
    enable_pretty_logging()
    assert isinstance

# Generated at 2022-06-26 08:21:10.348030
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_fmt = LogFormatter()


# Generated at 2022-06-26 08:21:13.081344
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:21:26.392495
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Prepare data
    class Record:
        def __init__(self, message: str, levelno: int) -> None:
            self.message = message
            self.levelno = levelno

    records = [
        Record("message1", logging.DEBUG),
        Record("message2", logging.INFO),
        Record("message3", logging.WARNING),
        Record("message4", logging.ERROR),
        Record("message5", logging.CRITICAL),
    ]

    # Class to unit test

# Generated at 2022-06-26 08:21:28.538204
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:21:37.444827
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    test_case_0()
    tornado.options.options.log_to_stderr = True
    tornado.options.options.logging = "WARNING"
    test_case_0()
    tornado.options.options.logging = "INFO"
    test_case_0()

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:21:41.829032
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()
    logging.info("message")
    logging.debug("message")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:21:43.838827
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # test for no color support at all
    LogFormatter(color = False)



# Generated at 2022-06-26 08:21:53.165820
# Unit test for constructor of class LogFormatter

# Generated at 2022-06-26 08:22:03.118613
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-26 08:22:05.985606
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()


# Generated at 2022-06-26 08:22:08.501245
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger("tornado.general")
    enable_pretty_logging(None, logger)

# Generated at 2022-06-26 08:22:11.900207
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options

    define_logging_options(options)
    # unit test for options.define
    assert options.logging == "info"
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10

# Generated at 2022-06-26 08:22:24.321301
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print("Testing test_LogFormatter_format")
    # The unit test is based on the following log:
    # The log is generated by the following code.
    #
    # @unittest.skipIf(not hasattr(signal, "setitimer"),
    #                  "setitimer not found")
    # def test_timer(self):
    #     io_loop = IOLoop()
    #     io_loop.make_current()
    #     self.called = False
    #
    #     def f():
    #         self.called = True
    #         io_loop.stop()
    #
    #     # Schedule a callback from a signal handler
    #     signal.setitimer(signal.ITIMER_REAL, 0.01)
    #     io_loop._set_itimer_handler

# Generated at 2022-06-26 08:22:33.610065
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class mock_record:
        levelno = logging.DEBUG
        message = "test"
        asctime = "2019"
        exc_info = None
        exc_text = None

    log_formatter_0 = LogFormatter()
    log_formatter_0.format(mock_record)

# A dictionary mapping uppercase logging level names to functions
# like logging.error, logging.info, logging.warning, etc.
_NAME_TO_LEVEL = {
    "CRITICAL": logging.CRITICAL,
    "ERROR": logging.ERROR,
    "WARNING": logging.WARNING,
    "INFO": logging.INFO,
    "DEBUG": logging.DEBUG,
}



# Generated at 2022-06-26 08:22:36.639384
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    global log_formatter_0
    log_formatter_0 = LogFormatter()


# Generated at 2022-06-26 08:22:39.220247
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()  # should succeed


# Generated at 2022-06-26 08:22:46.247914
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    log_formatter = LogFormatter(fmt, datefmt)
    assert log_formatter is not None
    #
    log_formatter = LogFormatter(fmt, datefmt, style)
    assert log_formatter is not None
    #
    log_formatter = LogFormatter(fmt, datefmt, style, color)
    assert log_formatter is not None
    #
    log_formatter = LogFormatter(fmt, datefmt, style, color, colors)
    assert log_formatter is not None
    #
    log_formatter = LogForm

# Generated at 2022-06-26 08:22:47.736912
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()


# Generated at 2022-06-26 08:23:16.625730
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "DEBUG"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = False
    enable_pretty_logging()


# Generated at 2022-06-26 08:23:20.094283
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options_0 = None
    logger_0 = None
    enable_pretty_logging(options_0, logger_0)

# Generated at 2022-06-26 08:23:21.688241
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# Generated at 2022-06-26 08:23:30.166959
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record_0 = logging.LogRecord(
        name="name",
        level=0,
        pathname=None,
        lineno=0,
        msg=None,
        args=None,
        exc_info=None,
    )
    log_formatter_0 = LogFormatter()
    log_formatter_0.format(record=record_0)
    print ('test_LogFormatter_format passed')

    
if __name__ == "__main__":
    test_case_0()
    test_LogFormatter_format()

# Generated at 2022-06-26 08:23:41.175768
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.logging = "none"
    enable_pretty_logging()
    options.logging = "debug"
    enable_pretty_logging()
    options.logging = "info"
    enable_pretty_logging()
    options.logging = "warning"
    enable_pretty_logging()
    options.logging = "error"
    enable_pretty_logging()
    options.logging = "critical"
    enable_pretty_logging()
    options.logging = "invalid"
    try:
        enable_pretty_logging()
    except Exception:
        pass
    options.log_to_stderr = True
    options.log_file_prefix = "1"

# Generated at 2022-06-26 08:23:49.330154
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    class DebugOptions(object):
        pass
    options = DebugOptions()
    options.log_file_num_backups = 10
    options.log_file_max_size = 1
    tornado.options.options = options
    enable_pretty_logging(options)

if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:24:02.015964
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test case 0
    # this code is only for typing
    from unittest import mock, TestCase
    from tornado import options

    # create mocks
    options_mock = mock.Mock()
    logger = logging.getLogger()

    # set return values
    options_mock.logging = "INFO"
    options_mock.log_file_prefix = "app.log"
    options_mock.log_rotate_mode = "size"
    options_mock.log_file_max_size = 1024 * 1024 * 10
    options_mock.log_file_num_backups = 5
    options_mock.log_rotate_when = "midnight"
    options_mock.log_rotate_interval = 1

    # run target function

# Generated at 2022-06-26 08:24:02.838978
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Run all unit tests

# Generated at 2022-06-26 08:24:03.429266
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()



# Generated at 2022-06-26 08:24:04.897040
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

