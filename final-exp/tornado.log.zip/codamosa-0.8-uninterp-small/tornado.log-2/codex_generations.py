

# Generated at 2022-06-26 08:15:06.209465
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord(name = "tornado.application", level = logging.INFO, pathname = "", lineno = 0, msg = "HTTPClientConnectError:: errno: 110, strerror: Connection timed out", args = (), exc_info = None)
    record.levelno = logging.INFO
    record.asctime = "20190805 08:24:14"
    record.__dict__['color'] = "\033[0m"
    record.__dict__['end_color'] = "\033[0m"
    record_dict = {}
    record_dict['name'] = "tornado.application"
    record_dict['level'] = logging.INFO
    record_dict['pathname'] = ""
    record_dict['lineno'] = 0

# Generated at 2022-06-26 08:15:07.118818
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    pass


# Generated at 2022-06-26 08:15:14.573150
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    flt = 60.0
    define_logging_options()
    print("1")
    lf = LogFormatter()
    print("2")
    print(lf.DEFAULT_FORMAT)
    print("3")

    # record = logging.LogRecord("name", logging.INFO, "/project/tornado/log.py", 50, "formal", {}, None)
    # print(lf.format(record))
    # print(lf.format(record))
    # print(lf.format(record))
    # print(lf.format(record))

# Generated at 2022-06-26 08:15:25.965275
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("test_LogFormatter()")

    # test with default values - color set to true
    test_logFormatter = LogFormatter()
    assert (
        test_logFormatter.DEFAULT_FORMAT == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa: E501
    )
    assert test_logFormatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert test_logFormatter._fmt == test_logFormatter.DEFAULT_FORMAT
    assert test_logFormatter.datefmt == test_logFormatter.DEFAULT_DATE_FORMAT
    assert test_

# Generated at 2022-06-26 08:15:28.330559
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
        logging.info("test_enable_pretty_logging");


# Generated at 2022-06-26 08:15:41.638438
# Unit test for method format of class LogFormatter
def test_LogFormatter_format(): 
    fmt = LogFormatter.DEFAULT_FORMAT
    datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    formatter = LogFormatter(
        fmt = fmt,
        datefmt = datefmt,
        style = style,
        color = color,
        colors = colors,
    ) 
    record = logging.LogRecord(
        name = "tornado.application",
        level = logging.WARNING,
        pathname = "/Users/michael/svn/tornado/tornado/stack_context.py",
        lineno = 87,
        msg = "Exception raised in callback %r",
        args = ("b",),
        exc_info = True, 
    ) 

# Generated at 2022-06-26 08:15:43.961888
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    float_0 = 60.0
    define_logging_options()


# Generated at 2022-06-26 08:15:45.428614
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test = LogFormatter()


# Generated at 2022-06-26 08:15:48.822624
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    float_0 = 60.0
    define_logging_options()
    formatter = LogFormatter()
    record = logging.LogRecord(float_0,float_0,float_0,float_0,float_0)
    str_0 = formatter.format(record)


# Helper class to enable colorization of logging messages with
# ``colorama``.

# Generated at 2022-06-26 08:15:51.412052
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    float_0 = 60.0
    assert 0
    define_logging_options()


# Generated at 2022-06-26 08:16:10.759595
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import os, time, shutil
    try:
        enable_pretty_logging()
        enable_pretty_logging()
        print("unit test enable_pretty_logging: OK")
    except Exception as e:
        print("unit test enable_pretty_logging: FAIL")

if __name__ == "__main__":
    import sys
    import os
    import shutil
    import time
    test_enable_pretty_logging()
    ##############
    test_dir = "./test/test_log/test_parse_command_line/"
    tmp_dir = "/tmp/test_log"

# Generated at 2022-06-26 08:16:21.116624
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.getLogger().setLevel(logging.DEBUG)
    logfile = 'log.txt'
    logger = logging.getLogger()
    handler = logging.FileHandler(logfile)

# Generated at 2022-06-26 08:16:22.846365
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()



# Generated at 2022-06-26 08:16:27.232318
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lvl_colors = {logging.INFO: 2}
    fmt = LogFormatter(fmt='%(color)s', colors = lvl_colors)

    record = logging.LogRecord('tornado.access', level=logging.INFO, pathname='', lineno=0, msg='', args=None, exc_info=None)
    output = fmt.format(record)
    assert output == '\x1b[2m'

# Test for method _stderr_supports_color

# Generated at 2022-06-26 08:16:34.945138
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    format = "%(levelname)1.1s %(asctime)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    color = False
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    log_fmt = LogFormatter(
        fmt=format,
        datefmt=datefmt,
        color=color,
        colors=colors
    )
    print(f"{log_fmt._fmt}")


# Generated at 2022-06-26 08:16:38.059833
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    enable_pretty_logging()
    access_log.info("test LogFormatter_format")


# Generated at 2022-06-26 08:16:48.674007
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado
    import logging
    import os
    from tornado.testing import AsyncTestCase
    from tornado.log import access_log, app_log, gen_log

    class MyFormatter(tornado.log.LogFormatter):
        def __init__(self):
            tornado.log.LogFormatter.__init__(self, color=False)

    # Enable logging to stderr and set a formatter.
    channel = logging.StreamHandler()
    channel.setFormatter(MyFormatter())
    tornado.log.gen_log.addHandler(channel)

    print(logging.getLogger())

    # Basic usage
    app_log.warning("hello")
    app_log.error(tornado.template.Template("{{1+1}}"))
    app_

# Generated at 2022-06-26 08:16:50.362656
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

# Generated at 2022-06-26 08:17:03.212877
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    cur_fmt = LogFormatter.DEFAULT_FORMAT
    cur_datefmt = LogFormatter.DEFAULT_DATE_FORMAT
    cur_style = "%"
    cur_color = True
    cur_colors = LogFormatter.DEFAULT_COLORS
    # cur_colors is an immutable object, so its object id is invariant
    # we can test whether cur_colors is equal to the object returned by CurFormatter.__init__

    lf = LogFormatter()
    assert lf._fmt == cur_fmt
    assert lf._colors == cur_colors
    assert lf._normal == ""

    lf = LogFormatter("fmt", "datefmt", "%", True, cur_colors)
    assert lf._fmt == "fmt"
    assert lf._

# Generated at 2022-06-26 08:17:16.854726
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print('Testing constructor of class LogFormatter')
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}
    formatter = LogFormatter(fmt, datefmt, style, color, colors)
    # formatter._colors, formatter._normal, formatter._fmt
    assert formatter._colors
    assert formatter._normal

# Generated at 2022-06-26 08:17:39.954182
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():

    # test case 0
    test_case_0()
    app_log.debug("1")
    app_log.info("2")
    app_log.warning("3")
    app_log.error("4")
    app_log.critical("5")

    # test case 1
    # enable_pretty_logging(None)
    # app_log.debug("1")
    # app_log.info("2")
    # app_log.warning("3")
    # app_log.error("4")
    # app_log.critical("5")



# Generated at 2022-06-26 08:17:42.961102
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
#    LogFormatter()
    print("Unit test for LogFormatter")

# test_LogFormatter()



# Generated at 2022-06-26 08:17:49.483880
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    print('test_enable_pretty_logging')
    test_enable_pretty_logging()

    # Test case for LogFormatter
    print('test_case_0()')
    test_case_0()

# Generated at 2022-06-26 08:17:54.182157
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test the generated print information
    logging.info("test_enable_pretty_logging()")
    test_case_0()

# Unit test:
#    The main function for unit test.

# Generated at 2022-06-26 08:18:05.651824
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class _Test_Options(object):
        def __init__(self):
            self.logging = None
            self.log_file_prefix = 'x.log'
            self.log_rotate_mode = 'size'
            self.log_file_max_size = 1024
            self.log_file_num_backups = 1
            self.log_rotate_when = "midnight"
            self.log_rotate_interval = 1
            self.log_to_stderr = False
        def __getitem__(self,k):
            return self.k

    opt = _Test_Options()
    
    import tornado.options
    tornado.options.options = opt
    logger = logging.getLogger()

    enable_pretty_logging(opt, logger)
    logger.debug('test')

# Generated at 2022-06-26 08:18:08.112592
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    print("_colors:", log_formatter._colors)
    print("_normal:", log_formatter._normal)
    print("_fmt:", log_formatter._fmt)


# Generated at 2022-06-26 08:18:10.463949
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()
    test_case_1()

test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:23.964268
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert formatter._normal == ""
    assert formatter._colors == {}
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == formatter.DEFAULT_FORMAT

    formatter = LogFormatter(color=True)
    # If the terminal does not support color, _normal is the empty string
    assert formatter._normal != ""
    # _colors is a mapping of logging level to terminal color code
    assert isinstance(formatter._colors, dict)

    formatter = LogFormatter(color=False, fmt='fmt', datefmt='datefmt')
    assert formatter.datefmt == 'datefmt'
    assert formatter._fmt == 'fmt'



# Generated at 2022-06-26 08:18:32.448658
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True)
    record = logging.LogRecord('', 0, '', 0, 'warnmsg', None, None)
    record.levelno = logging.WARNING
    record.exc_text = "exc_text"
    # record.exc_info = None

    # print(formatter.format(record))
    # assert assertEqual(formatter.format(record), '')


# Generated at 2022-06-26 08:18:33.971457
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-26 08:19:17.685522
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()

    assert isinstance(lf._fmt, str)
    assert isinstance(lf._colors, dict)

    for key in lf._colors:
        assert isinstance(key, int)
        assert isinstance(lf._colors[key], str)

    assert isinstance(lf._normal, str)


# Generated at 2022-06-26 08:19:20.660783
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()._fmt
    text = "[I 20151227 07:42:28 my_logging:138] this is a test"
    code = fmt % {"levelname": "I", "asctime": "20151227 07:42:28", "module": "my_logging", "lineno": 138, 
        "message": "this is a test", "color": "", "end_color": ""}
    assert text == code


# Generated at 2022-06-26 08:19:28.019625
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_fmt = "%(levelname)s\t%(filename)s\t%(funcName)s\t%(message)s"
    test_date_fmt = "%m/%d/%Y %I:%M:%S %p"
    formatter = LogFormatter(test_fmt, test_date_fmt)
    app_log.debug("test_LogFormatter")


# Generated at 2022-06-26 08:19:36.854199
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    x = LogFormatter(color=True)
    record = logging.LogRecord(None, logging.DEBUG, None, 0, '', (), None)
    assert x.format(record) == '\x1b[2;34m[D %(asctime)s %(module)s:%(lineno)d]\x1b[0m %(message)s'


# Generated at 2022-06-26 08:19:44.407295
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    log_datefmt = "%y%m%d %H:%M:%S"

    log_fmt = LogFormatter(log_fmt, log_datefmt, True)
    # log_fmt.DEFAULT_FORMAT = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    # log_fmt.DEFAULT_DATE_FORMAT = "%y%m%

# Generated at 2022-06-26 08:19:54.369529
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from datetime import datetime

    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.application",
        level=logging.DEBUG,
        pathname="/path/to/logger.py",
        lineno=90,
        msg="foo",
        args=None,
        exc_info=None,
    )
    formatter.format(record)
    print(record.asctime, record.message)


# Generated at 2022-06-26 08:20:01.784772
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger("tornado.access")
    logger.handlers[0].setFormatter(LogFormatter())

    logger.debug("this is a test")
    logger.info("this is a test")
    logger.warning("this is a test")
    logger.error("this is a test")
    logger.critical("this is a test")


# Generated at 2022-06-26 08:20:14.395737
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt1 = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    fmt2 = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt1 = "%y%m%d %H:%M:%S"
    style1 = "%"
    color1 = True
    colors1 = LogFormatter.DEFAULT_COLORS

    log_formatter1 = LogFormatter(fmt1, datefmt1, style1, color1, colors1)



# Generated at 2022-06-26 08:20:18.758717
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter().format(logging.LogRecord("tornado.application", logging.INFO, "tornado.py", 0, "msg", args=(), exc_info=None))


# Generated at 2022-06-26 08:20:23.548286
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_case_0()
   # print(_stderr_supports_color())
   # formatter = LogFormatter()
   # message = "hello world"
   # logging.debug(message)

# Generated at 2022-06-26 08:21:13.447451
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    test = LogFormatter(fmt = log_format)
    assert test._fmt == log_format

    test = LogFormatter(datefmt = "%y%m%d %H:%M:%S")
    assert test.datefmt == "%y%m%d %H:%M:%S"


# Generated at 2022-06-26 08:21:26.701964
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # initialize the logging module first
    import logging
    logging.basicConfig(level=logging.DEBUG)
    # Now, call the function under test
    enable_pretty_logging()
    # Now, Test logging
    app_log.debug('app_log debug log')
    app_log.info('app_log info log')
    app_log.warning('app_log warning log')
    app_log.error('app_log error log')
    app_log.critical('app_log critical log')

    access_log.debug('access_log debug log')
    access_log.info('access_log info log')
    access_log.warning('access_log warning log')
    access_log.error('access_log error log')
    access_log.critical('access_log critical log')


# Generated at 2022-06-26 08:21:39.285159
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.DEBUG = 10
    logging.INFO = 20
    logging.WARNING = 30
    logging.ERROR = 40
    
    obj = LogFormatter()

    class TestObj(object):
        __dict__ = {'asctime': '2019-11-01', 'levelno': 20, 'message': 'test_message', 'module': 'test_module'}

    tObj = TestObj()
    tObj.lineno = 1

    assert obj.format(tObj) == '[I 2019-11-01 test_module:1] test_message'

if __name__ == "__main__":
    test_case_0()
    test_LogFormatter_format()

# Generated at 2022-06-26 08:21:51.350094
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    style = "%"
    color = True

    # generate customized LogFormatter 
    formatter = LogFormatter(fmt, datefmt, style, color)
    # create a logger by using the customized LogFormatter 
    logger = logging.getLogger("tornado.application")
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    logger.debug("debug message")
    logger.info("info message")

# Generated at 2022-06-26 08:21:54.906110
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        test_case_0()
    except Exception as e:
        print("Exception: ", e)
# test_enable_pretty_logging()

# Generated at 2022-06-26 08:21:56.670112
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()


# Generated at 2022-06-26 08:22:00.850500
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    L = LogFormatter()
    assert L.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert L._normal == "";
    assert L._colors == {}


# Generated at 2022-06-26 08:22:12.603758
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # The if/else statement is for testing in travis
    try:
        import tornado.options

        options = tornado.options.options
        logger = logging.getLogger()
    except:
        import tornado.options as options
        logger = logging.getLogger()
    options.logging = "INFO"
    options.log_file_prefix = "/tmp/temp.log"
    options.log_file_max_size = 1024*1024
    options.log_file_num_backups = 5
    options.log_to_stderr = False
    enable_pretty_logging()
    logging.info("info level log")
    logging.error("error level log")
    logging.warning("warning level log")
    logging.debug("debug level log")
    logging.critical("critical level log")

    options.log_rot

# Generated at 2022-06-26 08:22:17.747460
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter._normal == ""


# Generated at 2022-06-26 08:22:20.792338
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:23:32.683609
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

# Generated at 2022-06-26 08:23:34.933999
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    assert True


# Generated at 2022-06-26 08:23:42.503606
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    fmt = "[%(levelname) 1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    datefmt = "%y%m%d %H:%M:%S"

    formatter = LogFormatter(color=True, fmt=fmt, datefmt=datefmt)

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    logger.handlers = []
    logger.addHandler(stream_handler)

    # Color support on Windows versions that do not support ANSI color codes is enabled
    # by use of the colorama library. Applications that wish to use this must first
    # initialize colorama with a call to color

# Generated at 2022-06-26 08:23:47.159392
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:23:48.641692
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    print(lf)


# Generated at 2022-06-26 08:24:00.067428
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    colorama.init()
    log_formatter = LogFormatter()
    # message no color
    message = "hello world"
    record = {
        "message": message,
        "levelno": 10,
        }
    ans = log_formatter.format(record)
    print("ans:", ans)

    # message: with color
    message = "hello world"
    record = {
        "message": message,
        "levelno": logging.ERROR,
        }
    ans = log_formatter.format(record)
    print("ans:", ans)



# Generated at 2022-06-26 08:24:02.458793
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Arrange and Act
    test_case_0()


# Generated at 2022-06-26 08:24:05.241558
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:24:13.332178
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter.datefmt == '%y%m%d %H:%M:%S'
    assert log_formatter._fmt == '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    assert log_formatter._normal == ''
    assert log_formatter._colors == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }


# Generated at 2022-06-26 08:24:14.714438
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
