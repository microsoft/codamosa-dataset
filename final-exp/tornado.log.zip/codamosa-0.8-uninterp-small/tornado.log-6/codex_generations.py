

# Generated at 2022-06-26 08:14:52.986300
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()



# Generated at 2022-06-26 08:14:56.594996
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    define_logging_options()
    tornado.options.parse_command_line()
    logging.info("123")


# Generated at 2022-06-26 08:14:59.645240
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    handler = logging.StreamHandler()
    handler.setFormatter(LogFormatter())
    logging.getLogger().addHandler(handler)


# Generated at 2022-06-26 08:15:05.781978
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define

    define("log_to_stderr", type=bool, default=True)
    tornado.options.parse_command_line(["--log_to_stderr=False"])

    enable_pretty_logging()
    assert (not options.log_to_stderr)

    tornado.options.parse_command_line(["--log_to_stderr=True"])
    enable_pretty_logging()
    assert (options.log_to_stderr)


# Generated at 2022-06-26 08:15:07.426186
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:15:16.238324
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import sys
    import os
    import logging.config

    # Save the original stderr
    original_stderr = sys.stderr

    # Set up a file to receive the log output.
    file_path = "__tornado_test_log__"
    with open(file_path, "w") as f:
        f.write("")

    # Set up a stream to receive the log output.
    stream = open(file_path, "r")

    # Use the file as stderr
    sys.stderr = stream

    # Test the default format

# Generated at 2022-06-26 08:15:20.224327
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        LogFormatter()
    except Exception as e:
        assert False, "exception in constructor of class LogFormatter:\n" + str(e)


# Generated at 2022-06-26 08:15:30.412134
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger(__name__)
    logger.setLevel('DEBUG')

    # create console handler and set level to info
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)

    # create formatter
    formatter = LogFormatter(
        fmt="%(color)s%(levelname)s %(asctime)s - %(message)s",
        datefmt="%H:%M:%S")

    # add formatter to ch
    handler.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(handler)

    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warn message')
    logger.error('error message')

# Generated at 2022-06-26 08:15:33.072470
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert LogFormatter().format(logging.LogRecord("", "", "", 0, "", (), None))


# Generated at 2022-06-26 08:15:45.054319
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    logfmt = LogFormatter(fmt, datefmt)

    message = "Test Message"
    levelno = logging.DEBUG
    record = logging.LogRecord(
        name="Test",
        level=levelno,
        pathname="Test",
        lineno=99,
        msg=message,
        args=None,
        exc_info=None,
    )
    formatted = logfmt.format(record)
    print(formatted)


# Generated at 2022-06-26 08:16:09.048821
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    logger = logging.getLogger("test")

    # enable console logging
    options = tornado.options.options
    options.logging = logging.DEBUG
    enable_pretty_logging(options, logger)
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)
    assert logger.level == logging.DEBUG

    # enable file logging
    options.log_file_prefix = "test.log"
    options.log_file_num_backups = 10
    enable_pretty_logging(options, logger)
    assert len(logger.handlers) == 2
    assert isinstance(logger.handlers[1], logging.handlers.RotatingFileHandler)

    # disable logging

# Generated at 2022-06-26 08:16:20.900921
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    fmt = format_string()
    datefmt = "%Y-%m-%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    log_formatter = LogFormatter(
        fmt = fmt,
        datefmt = datefmt,
        style = style,
        color = color,
        colors = colors,
    ) 

    # logger = gen_log
    logger = logging.getLogger("tornado.general")
    #logger = logging.getLogger("root")

    logger.setLevel

# Generated at 2022-06-26 08:16:22.607198
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-26 08:16:29.337239
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_file_prefix = "test.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1024 * 1024 * 1024
    options.log_file_num_backups = 10
    options.logging = "debug"
    enable_pretty_logging()
    access_log.error("test_enable_pretty_logging function for error message")
    app_log.warning("test_enable_pretty_logging function for warning message")
    gen_log.info("test_enable_pretty_logging function for info message")
    gen_log.debug("test_enable_pretty_logging function for debug message")


# Generated at 2022-06-26 08:16:30.006012
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:16:43.841568
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options

    # This test assumes that logging is configured with
    # define_logging_options and enable_pretty_logging is called.
    # The two functions are separated so that custom command line parsing
    # can configure the logger instead of having enable_pretty_logging
    # overwrite some parameters (e.g.
    # https://github.com/facebook/tornado/pull/856).

    # enable_pretty_logging can be called with no arguments
    logger = logging.getLogger("tornado.test")
    logger.handlers = []
    enable_pretty_logging()
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)

    # enable_pretty_logging can be called with a logger
    logger = logging.getLog

# Generated at 2022-06-26 08:16:49.138131
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Initialize for the test
    class FakeLoggingFormatter(logging.Formatter):
        def format(self, record):
            return record

    logging.Formatter.__init__ = lambda x, y: None
    log_formatter = LogFormatter()
    record = FakeLoggingFormatter.format(log_formatter, record=True)

    assert(record)



# Generated at 2022-06-26 08:17:02.565278
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    obj = LogFormatter()
    record = logging.LogRecord(name = 'testlogger', level = logging.DEBUG, pathname = 'testpathname', lineno = 1, msg = 'test message', args = (), exc_info = None)
    ret = obj.format(record)
    assert ret == '[D 170105 19:01:00 testpathname:1] test message'

    # As there is no need for color, so set color to False
    obj = LogFormatter(color = False)
    record = logging.LogRecord(name = 'testlogger', level = logging.DEBUG, pathname = 'testpathname', lineno = 1, msg = 'test message', args = (), exc_info = None)
    ret = obj.format(record)

# Generated at 2022-06-26 08:17:15.634303
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    def main():
        import logging
        import the_beatiful_log
        import the_beautiful_option
        the_beautiful_option.define_logging_options()
        the_beautiful_option.parse_command_line(
            ['--log_file_prefix','my_log.txt','--logging=warning']
        )
        the_beatiful_log.enable_pretty_logging()
        logging.warning('Warning message')
        logging.error('Error message')
        try:
            raise Exception('An Exception')
        except:
            logging.error('Error while notifying event', exc_info=True)

    main()


# Generated at 2022-06-26 08:17:20.379020
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    define_logging_options()
    LogFormatter()
    LogFormatter(color=False)
    LogFormatter(colors={})


# Generated at 2022-06-26 08:17:37.980414
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(relativeCreated)d %(message)s",
        datefmt="%H:%M:%S",
    )
    logging.info("info message")
    logging.warning("warn message")
    logging.error("error message")
    logging.critical("crit message")
    formatter = LogFormatter()
    print(formatter.format(logging.getLogger("").handlers[0].formatter._fmt % {"relativeCreated": 123, "message":"info message"}))


# Generated at 2022-06-26 08:17:45.023159
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # 模拟命令行参数
    class Options:
        logging = 'debug'
        log_file_prefix = './log_file_prefix'
        log_rotate_mode = 'size'
        log_file_max_size = 2048  # 2k
        log_file_num_backups = 7
        log_to_stderr = True
    options = Options()
    enable_pretty_logging(options, None)
    # 日志测试
    logger = logging.getLogger()
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Unit test main

# Generated at 2022-06-26 08:17:59.512830
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        def __init__(self, logging, log_file_prefix, log_file_max_size, log_rotate_mode, log_rotate_when, log_rotate_interval, log_file_num_backups):
            self.logging = logging
            self.log_file_prefix = log_file_prefix
            self.log_file_max_size = log_file_max_size
            self.log_rotate_mode = log_rotate_mode
            self.log_rotate_when = log_rotate_when
            self.log_rotate_interval = log_rotate_interval
            self.log_file_num_backups = log_file_num_backups

# Generated at 2022-06-26 08:18:12.896012
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    print(options)
    options.log_file_prefix = 'log_file_prefix'
    options.logging = 'debug'
    options.log_file_max_size = 100
    options.log_file_num_backups = 2
    options.log_rotate_mode ='size'
    options.log_rotate_when = 'S'
    options.log_rotate_interval = 1
    logger = None
    enable_pretty_logging(options)
    access_log.debug('access log debug')
    access_log.info('access log info')
    access_log.warning('access log warning')
    access_log.error('access log error')
    access_log.critical('access log critical')

# Generated at 2022-06-26 08:18:19.712623
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter("%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s")
    return

test_case_0()
test_LogFormatter()

# Generated at 2022-06-26 08:18:22.913630
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_config_file("g:/workspace/lx/python/Mypython/tornado/tornado/test/test.py",final=False)
    enable_pretty_logging()


# Generated at 2022-06-26 08:18:31.343024
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    r"""
    >>> fmt = LogFormatter(color=True, fmt='%(color)s%(message)s%(end_color)s')
    >>> record = logging.makeLogRecord({'msg': 'mymessage'})
    >>> fmt.format(record)
    '\x1b[38;5;2mmymessage\x1b[0m'
    """



# Generated at 2022-06-26 08:18:44.441896
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test constructor
    log_formatter = LogFormatter(fmt = '%(asctime)s %(name)s %(levelname)s %(message)s',
        datefmt = '%Y-%m-%d %H:%M:%S')
    # Test fmt
    log_formatter.formatTime(record = None, datefmt = '%Y-%m-%d %H:%M:%S')
    # Test colors
    log_formatter._colors[1] = '\033[0m'
    log_formatter._colors[2] = '\033[2;3%dm'
    # Test _normal
    log_formatter._normal = "\033[0m"
    # Test datefmt

# Generated at 2022-06-26 08:18:54.283439
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # testing constructor
    fmt = "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"
    log_formatter = LogFormatter(color=False, fmt=fmt)
    assert log_formatter._normal == ""
    log_formatter = LogFormatter(color=True, fmt=fmt)
    assert log_formatter._normal == "\033[0m"



# Generated at 2022-06-26 08:19:06.744608
# Unit test for method format of class LogFormatter

# Generated at 2022-06-26 08:19:19.401181
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        import cStringIO as StringIO
    except ImportError:
        import StringIO
    buf = StringIO.StringIO()
    ch = logging.StreamHandler(buf)
    formatter = LogFormatter(color=False)
    ch.setFormatter(formatter)
    logger = logging.getLogger()
    logger.addHandler(ch)
    logger.setLevel(logging.DEBUG)
    logger.info("hello")
    logger.error("hello2")
    logger.removeHandler(ch)
    assert(buf.getvalue() == '[I 120921 15:24:43 _test:1] hello\n[E 120921 15:24:43 _test:2] hello2\n')

# Generated at 2022-06-26 08:19:26.722968
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord("test", 20, "file", 10, "test message", None, None)
    log_formatter = LogFormatter()
    try:
        log_formatter.format(record)
    except Exception as e:
        print("Exception: " + str(e))
        return False
    return True


# Generated at 2022-06-26 08:19:31.512012
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # unit_test_init_config()

    record = logging.LogRecord("name", logging.INFO, "filename_0", 23, "msg_0", None, None)

    log_formatter_0 = LogFormatter()
    res = log_formatter_0.format(record)

    assert res is None


# Generated at 2022-06-26 08:19:39.017048
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    assert log_formatter_0._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501



# Generated at 2022-06-26 08:19:40.064943
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:19:52.475139
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.log_to_stderr = False
    options.log_file_prefix = "/data/tmp/access.log"
    options.logging = "DEBUG"
    options.log_rotate_mode = "time"
    options.log_rotate_interval = 5
    options.log_rotate_when = "H"
    options.log_file_num_backups = 10

    enable_pretty_logging()

# test_enable_pretty_logging()

# Generated at 2022-06-26 08:20:03.189946
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_format = LogFormatter()

    # prepare parameters

# Generated at 2022-06-26 08:20:14.670215
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options as options
    #logging.basicConfig(level=logging.DEBUG)
    logging.basicConfig(level=logging.INFO)
    enable_pretty_logging()
    gen_log.info("Hello, {}, current_log_level: {}".format("world", gen_log.getEffectiveLevel()))
    gen_log.debug("Hello, {}, current_log_level: {}".format("world", gen_log.getEffectiveLevel()))
    gen_log.critical("Hello, {}, current_log_level: {}".format("world", gen_log.getEffectiveLevel()))
    gen_log.debug('%s before you %s', 'Look', 'leap!')
    options.options.logging = "error"
    enable_pretty_logging()

# Generated at 2022-06-26 08:20:25.612598
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # 'record': {<logging.LogRecord: DEBUG,root,3>}
    record = logging.LogRecord("DEBUG", "root", 3, 3, "", {}, None)
    log_formatter_0 = LogFormatter()
    # try to convert the object 'record' to a str type
    try:
        record = str(record)
    except:
        pass

    assert isinstance(record, str)
    record_str = record
    # call the method format of class LogFormatter
    ret_str = log_formatter_0.format(record)

    assert ret_str == record_str
    # ignore the error, which caused by the function called by the function
    # test_case_0()


# Generated at 2022-06-26 08:20:28.087498
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options=None, logger=None)

# Generated at 2022-06-26 08:20:46.145506
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import doctest
    from tornado.log import gen_log
    from tornado.log import LogFormatter
    from tornado.escape import _unicode
    from tornado import util

    class TestCase(unittest.TestCase):
        def test_format(self):
            r"""Tests for LogFormatter.format.

            Exposes the format method in a form that is compatible with the
            doctest module.
            """


# Generated at 2022-06-26 08:20:52.560971
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._colors == {
        logging.DEBUG: "\x1b[2;34m",
        logging.INFO: "\x1b[2;32m",
        logging.WARNING: "\x1b[2;33m",
        logging.ERROR: "\x1b[2;31m",
        logging.CRITICAL: "\x1b[2;35m",
    }
    assert log_formatter._normal == "\x1b[0m"
    assert (
        log_formatter._fmt
        == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    )

    log_formatter_

# Generated at 2022-06-26 08:20:59.357639
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

if __name__ == '__main__':
    import logging
    import logging.handlers

    logger = logging.getLogger('_')
    logger.setLevel(logging.DEBUG)
    fh = logging.FileHandler('_1.log')
    fh.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter0 = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    formatter1 = LogFormatter()
    fh.setFormatter(formatter0)
    ch.setFormatter(formatter1)
    logger.addHandler(fh)
    logger.addHandler(ch)

# Generated at 2022-06-26 08:21:04.274250
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    global log_formatter_0
    log_formatter_0 = LogFormatter()
    if log_formatter_0:
      log_formatter_0 = LogFormatter() # dummy assignment


# Generated at 2022-06-26 08:21:11.541414
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    log_record = logging.LogRecord(name=None, level=logging.INFO, pathname=None, lineno=None, msg="msg:%s", args=None, exc_info=None) 
    log_formatter.format(log_record)


# Generated at 2022-06-26 08:21:13.006610
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()



# Generated at 2022-06-26 08:21:17.539372
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "log"
    options.log_file_max_size = 10
    options.log_file_num_backups = 3
    logger = logging.getLogger()
    enable_pretty_logging(options, logger)

# Generated at 2022-06-26 08:21:19.167566
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# Generated at 2022-06-26 08:21:24.629914
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter.format(logging.LogRecord('name1', '20', 'filename1', 100, 'fmt1', None, 'exc_info1')), str)


# Generated at 2022-06-26 08:21:31.649442
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    log_formatter_1 = LogFormatter(fmt, datefmt, style, color, colors)

# Generated at 2022-06-26 08:21:54.550779
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord('name_0', 'level_0', 'pathname_0', 'lineno_0', 'msg_0', ('args_0', 1), ('exc_info_0',), 'func_0', 'sin_0', 'sout_0')
    log_formatter_0.format(record_0)
    record_1 = logging.LogRecord('name_0', 'level_0', 'pathname_0', 'lineno_0', 'msg_0', ('args_0', 1), ('exc_info_0',), 'func_0', 'sin_0', 'sout_0')
    log_formatter_0.format(record_1)

# Generated at 2022-06-26 08:21:57.828369
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

if __name__ == "__main__":
    test_LogFormatter()

# Generated at 2022-06-26 08:22:03.089092
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(
        name='tornado.access',
        level=10,
        pathname='/',
        lineno=1,
        msg='message',
        args=(),
        exc_info=None)
    # As of now, the following call to method format fails
    log_formatter.format(record)

# vim:set sw=4 ts=4 et:

# Generated at 2022-06-26 08:22:13.219426
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    # 1. options is None, default logging settings
    tornado.options.options.logging = "DEBUG"
    tornado.options.options.log_file_prefix = "log/tornado.log"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "MIDNIGHT"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 30
    tornado.options.options.log_to_stderr = None
    enable_pretty_logging()

    # 2. options is supplied, default logging settings
    tornado.options.options.logging = "DEBUG"

# Generated at 2022-06-26 08:22:15.209661
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        test_case_0()
    except:
        print("FAIL")
    else:
        print("PASS")


# Generated at 2022-06-26 08:22:17.402595
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 08:22:23.282635
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    # testcase instantiation
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord(None, logging.DEBUG, None, None, None, None, None)
    # invoke method format
    result = log_formatter_0.format(record_0)

    # verify assertions
    assert isinstance(result, str)


test_LogFormatter_format()


# Generated at 2022-06-26 08:22:27.068005
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("running test_LogFormatter")
    test_case_0()


# Generated at 2022-06-26 08:22:31.959538
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_1 = LogFormatter()
    err_msg = "LogFormatter.format: Numeric or string object expected"

    try:
        record = None
        log_formatter_1.format(record)
    except TypeError as e:
        assert (err_msg in str(e))


# Generated at 2022-06-26 08:22:35.192677
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Enable colored logging for Tornado access logs.
    enable_pretty_logging()


# Generated at 2022-06-26 08:23:10.292481
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()


# Generated at 2022-06-26 08:23:19.105122
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("start to test_LogFormatter")

    log_formatter_0 = LogFormatter()

    log_formatter_2 = LogFormatter(fmt="%(levelname)s: %(message)s")

    log_formatter_3 = LogFormatter(fmt="%(levelname)s: %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

    # print(log_formatter_0)
    # print(log_formatter_2)
    # print(log_formatter_3)
    print("test_LogFormatter pass")



# Generated at 2022-06-26 08:23:29.207012
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    def test_options_class():
        class Options(object):
            def __init__(self) -> None:
                self.logging = 'DEBUG'
                self.log_file_prefix = '/path/to/log'
                self.log_rotate_mode = 'size'
                self.log_file_max_size = 1024 * 1024 * 1024
                self.log_file_num_backups = 10
                self.log_rotate_when = 'D'
                self.log_rotate_interval = 1
        return Options()
    options = test_options_class()
    enable_pretty_logging(options)


# Generated at 2022-06-26 08:23:30.954853
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:23:32.886461
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Enable pretty logging.
    enable_pretty_logging()

# Generated at 2022-06-26 08:23:34.514191
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

# Generated at 2022-06-26 08:23:39.446638
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    log_record_0 = logging.LogRecord(name='foo', level=0, pathname='foo', lineno=0, msg='foo', 
		args=(), exc_info=None)
    log_formatter_0.format(log_record_0)


# Generated at 2022-06-26 08:23:51.031304
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.logging = None
    enable_pretty_logging()
    options.logging = "none"
    enable_pretty_logging()
    options.logging = "debug"
    enable_pretty_logging()
    options.log_file_prefix = "test_file_prefix"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 10
    enable_pretty_logging()
    options.log_rotate_mode = "time"
    enable_pretty_logging()
    options.log_to_stderr = False
    enable_pretty_logging()
    options.log_to_stderr = True
    enable_pretty

# Generated at 2022-06-26 08:23:58.356236
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord(name='', level=0, pathname='', lineno=0, msg='', args=[], exc_info=None)
    result = log_formatter_0.format(record_0)
    assert type(result) == unicode_type



# Generated at 2022-06-26 08:23:59.562396
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

