

# Generated at 2022-06-26 08:15:01.252240
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.makeLogRecord({"exc_info": True})
    print(formatter.format(record))

if __name__ == "__main__":
    test_LogFormatter_format()


# Generated at 2022-06-26 08:15:14.193350
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = LogFormatter()

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-26 08:15:16.807069
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()
    logFormatter.format(object())



# Generated at 2022-06-26 08:15:24.525310
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(datefmt=LogFormatter.DEFAULT_DATE_FORMAT)
    assert log_formatter is not None

    if _stderr_supports_color():
        assert len(log_formatter._colors) == len(log_formatter.DEFAULT_COLORS)

        for lvlno, code in log_formatter.DEFAULT_COLORS.items():
            assert log_formatter._colors[lvlno] is not None

    assert log_formatter._normal == ""



# Generated at 2022-06-26 08:15:36.957449
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    # fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(filename)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    # colors = {
    #     logging.DEBUG: 4,  # Blue
    #     logging.INFO: 2,  # Green
    #     logging.WARNING: 3

# Generated at 2022-06-26 08:15:38.467576
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass


# Generated at 2022-06-26 08:15:43.667517
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    color = LogFormatter.DEFAULT_COLORS
    log_fmt = LogFormatter(datefmt="%y%m%d %H:%M:%S",color=color)



# Generated at 2022-06-26 08:15:51.285432
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test case 0
    from tornado.util import Configurable
    log_fmt = "%(color)s%(asctime)s %(name)s %(end_color)s"
    date_fmt = '%H:%M:%S'
    style = '%'
    color = False
    colors = {
    }
    configurable = Configurable()
    logger_instance = logging.getLogger("tornado")
    logging_formatter = LogFormatter(fmt=log_fmt, datefmt=date_fmt, style=style, color=color, colors=colors)
    logger_instance.setLevel(20)
    logger_instance.addHandler(logging.StreamHandler(stream=sys.stdout))

# Generated at 2022-06-26 08:15:52.766569
# Unit test for function define_logging_options
def test_define_logging_options():
    test_case_0()


# Generated at 2022-06-26 08:16:03.559843
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    options.log_file_prefix = 'test_log_file.log'
    options.log_file_max_size = 1024
    options.log_file_num_backups = 1000
    options.log_rotate_mode = 'size'
    options.logging = 'DEBUG'
    enable_pretty_logging(options)

    for i in range(10):
        app_log.debug("Debug print " + str(i))
        app_log.info("Info print " + str(i))
        app_log.warning("Warning print " + str(i))
        app_log.error("Error print " + str(i))
        app_log.critical("Critical print " + str(i))


# Generated at 2022-06-26 08:16:23.650542
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Create a LogFormatter object, and check the default value of _fmt.
    log_formatter = LogFormatter()
    assert isinstance(log_formatter, LogFormatter)
    #assert log_formatter._fmt == "[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s"  # noqa: E501
    assert log_formatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    #assert isinstance(log_formatter._colors, dict)
    assert log_formatter._normal == ""

# Unit test

# Generated at 2022-06-26 08:16:25.748875
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 08:16:34.867008
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import json
    from tornado.log import gen_log, app_log, access_log
    from tornado.log import LogFormatter

    # create formatter
    log_formatter = LogFormatter()
    log_formatter_json = LogFormatter(
        fmt='{ "levelname": "%(levelname)s", "asctime": "%(asctime)s", "module": "%(module)s", "lineno": "%(lineno)d", "funcName": "%(funcName)s", "message": "%(message)s" }'
        # add other args if necessary
    )


# Generated at 2022-06-26 08:16:40.896675
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = log_options
    enable_pretty_logging(options)

if __name__ == '__main__':
    logging.info("Testing log_options")
    test_case_0()
    test_enable_pretty_logging()
    logging.info("Completed log_options")

# Generated at 2022-06-26 08:16:54.000937
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options

    # Set options.logging
    options.logging = 'info'
    options.log_file_prefix = './test.log'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 1024
    options.log_file_num_backups = 5
    options.log_to_stderr = True
    enable_pretty_logging(options)

    # Record a log
    gen_log.warning("This log is a test.")

if __name__ == '__main__':
    test_case_0()
    test_enable_pretty_logging()
    # gen_log.warning("This log is a test.")

# Generated at 2022-06-26 08:16:55.091450
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()



# Generated at 2022-06-26 08:17:01.751255
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""
    log_formatter = LogFormatter(color=False)
    assert log_formatter._colors == {}


# Generated at 2022-06-26 08:17:03.323611
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass


# Generated at 2022-06-26 08:17:13.547239
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.access",
        level=logging.INFO,
        pathname=None,
        lineno=None,
        msg="This is a test log record",
        args=None,
        exc_info=None,
    )
    format_record = log_formatter.format(record)
    print(format_record)



# Generated at 2022-06-26 08:17:15.843216
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    it = LogFormatter()
    assert it._fmt == it.DEFAULT_FORMAT
    assert it._colors == {}
    assert it._normal == ""



# Generated at 2022-06-26 08:17:39.027523
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class opts_0:
        logging = 'none'
    #enable_pretty_logging(options=opts_0)

    opts_1 = opts_0
    opts_1.logging = 'info'
    opts_1.log_file_prefix = 'todel'
    opts_1.log_rotate_mode = 'time'
    opts_1.log_rotate_when = 'D'
    opts_1.log_rotate_interval = 7
    opts_1.log_file_num_backups = 10
    opts_1.log_to_stderr = True
    enable_pretty_logging(options=opts_1)

# Generated at 2022-06-26 08:17:49.482345
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Assign
    log_formatter_1 = LogFormatter()
    record_1 = logging.LogRecord("tornado.general", 0, "fake_file_name", 1, "fake_message", [], None)
    record_1.exc_info = "test"

    # Act
    # Call method format of LogFormatter to generate log
    ret = log_formatter_1.format(record_1)

    # Assert
    # Check that the return value is not None
    assert ret is not None


# Generated at 2022-06-26 08:17:52.514365
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 08:18:03.854416
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.gen
    import tornado.ioloop
    import tornado.web
    from tornado.httpserver import HTTPServer
    from tornado.util import bytes_type
    from tornado.platform.asyncio import AsyncIOMainLoop
    import tornado.platform.asyncio 
    _log = logging.getLogger("tornado.application")

    _log.debug("Here is an error message.")
    _log.error("Here is an error message.")
    enable_pretty_logging()
    _log.debug("Here is an error message.")
    _log.error("Here is an error message.") 
    # setattr(tornado.options, "logging", "debug")
    # enable_pretty_logging()
    # _log.debug("Here is an error message.")
    # _log.error

# Generated at 2022-06-26 08:18:13.882271
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Record:
        def __init__(self):
            # type: () -> None
            self.__dict__ = {}  # type: Dict[str, Any]
            self.message = "Message"  # type: str
            self.asctime = "asctime"  # type: str
            self.levelno = logging.DEBUG  # type: int
            self.color = LogFormatter().DEFAULT_COLORS[logging.DEBUG]  # type: str
            self.end_color = ""  # type: str

    formatter = LogFormatter()
    record = Record()
    assert formatter.format(record) == "[D asctime :0] Message"


# Generated at 2022-06-26 08:18:17.675113
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

if __name__ == "__main__":
    test_LogFormatter()

# Generated at 2022-06-26 08:18:25.238561
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    msg = (
        'paths=["/Users/trevor/git/python/tornado/tornado/testing/"] pattern="test*.py"'
    )
    record = "..."
    try:
        LogFormatter.format(msg, record)
        assert True
    except Exception:
        assert False

    record = "..."
    msg = "Couldn't run $PYTHON -m tornado.testing {args}: [Errno 2] No such file or directory" # noqa: E501
    try:
        LogFormatter.format(msg, record)
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 08:18:36.535893
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    log_formatter_1 = LogFormatter(fmt="[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s", datefmt="%y%m%d %H:%M:%S")
    log_formatter_2 = LogFormatter(fmt="[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s", datefmt="%y%m%d %H:%M:%S", style="%")

# Generated at 2022-06-26 08:18:42.347561
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    access_log.info("testing info")
    app_log.info("testing app_log")
    gen_log.info("testing gen_log")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:55.984444
# Unit test for function enable_pretty_logging

# Generated at 2022-06-26 08:19:34.134602
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        def __init__(self):
            self.log_file_prefix: str = r"./log/test/test_log.log"
            self.log_rotate_mode: str = "size"
            self.log_file_max_size: int = 1024 * 1024 * 1024
            self.log_file_num_backups: int = 5
            self.logging: str = "info"
            self.log_to_stderr: bool = True

    options = Options()
    enable_pretty_logging(options)
    app_log.error("Someting wrong!")
    app_log.warn("I'm warning you!")
    app_log.info("Just tell you!")
    app_log.debug("You have seen nothing!")


# Generated at 2022-06-26 08:19:36.268194
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test for the __init__ with no parameters.
    test_case_0()

# Generated at 2022-06-26 08:19:44.281641
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import logging
    import logging.handlers
    
    # Create a LogRecords and insert a few entries.
    log_record_0 = logging.Logger('logger_0', logging.INFO)
    log_record_0.setLevel(logging.DEBUG)
    log_record_0.name = "logger_0"

    # Create a LogFormatter object and call method format of class LogFormatter
    log_formatter_0 = LogFormatter()
    # log_record_0.message has no value and will be decoded to unicode
    expected = '%r' % log_record_0.__dict__['message']

# Generated at 2022-06-26 08:20:00.370996
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    old_time_rotated_handler = logging.handlers.TimedRotatingFileHandler
    old_size_rotated_handler = logging.handlers.RotatingFileHandler

# Generated at 2022-06-26 08:20:01.772898
# Unit test for function enable_pretty_logging

# Generated at 2022-06-26 08:20:14.395901
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    log_formatter_1 = LogFormatter(
        fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa: E501
    )
    log_formatter_2 = LogFormatter(
        fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',  # noqa: E501
        datefmt='%y%m%d %H:%M:%S',
    )

# Generated at 2022-06-26 08:20:21.050912
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord(
        name="z2v7MjHf",
        level=logging.WARN,
        pathname="/OsX1X9As.py",
        lineno=37,
        msg="3x0xE8gp",
        args=None,
        exc_info=None,
    )
    record_0.msg = 3
    record_0.msg = 42
    record_0.msg = 4.55
    record_0.msg = "88"
    record_0.msg = "SFNrCo"
    record_0.msg = "fzmjMw"
    record_0.msg = "WKjYmD"
    record_0.msg = "Fe293O"
    record_0

# Generated at 2022-06-26 08:20:25.096588
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record_0 = logging.LogRecord("name",
                                 "DEBUG",
                                 "pathname",
                                 1,
                                 "msg",
                                 ("args", "kwargs"),
                                 None)
    log_formatter.format(record_0)


# Generated at 2022-06-26 08:20:36.153236
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        logging = "DEBUG"
        log_file_prefix = "test_prefix_debug"
        log_rotate_mode = "size"
        log_file_max_size = 20480000
        log_file_num_backups = 5
        log_to_stderr = False

    option_object = Options()
    logger = logging.getLogger()
    enable_pretty_logging(option_object, logger)
    option_object.log_file_prefix = "test_prefix_info"
    option_object.logging = "INFO"
    option_object.log_to_stderr = True
    enable_pretty_logging(option_object, logger)
    option_object.log_file_prefix = "test_prefix_warning"
    option_object.logging = "WARNING"


# Generated at 2022-06-26 08:20:40.897157
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        enable_pretty_logging(None)
    except:
        pass
    try:
        enable_pretty_logging(1)
    except:
        pass


# Generated at 2022-06-26 08:21:46.753975
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    log_formatter_format_0 = log_formatter.format(LogRecord())
    print(log_formatter_format_0)

# Generated at 2022-06-26 08:21:54.394404
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Enable logging
    import tornado.options
    tornado.options.options = tornado.options.define("log_to_stderr",default=True)
    tornado.options.options = tornado.options.define("log_file_prefix",default="log")
    tornado.options.options = tornado.options.define("log_rotate_mode",default="size")
    tornado.options.options = tornado.options.define("log_file_max_size",default=100000000)
    tornado.options.options = tornado.options.define("log_file_num_backups",default=5)
    tornado.options.options = tornado.options.define("log_rotate_when",default="midnight")
    tornado.options.options = tornado.options.define("log_rotate_interval",default=1)

# Generated at 2022-06-26 08:21:56.814473
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert isinstance(LogFormatter(), LogFormatter)



# Generated at 2022-06-26 08:22:04.645871
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter(color=True, datefmt="%y%m%d %H:%M:%S")
    assert log_formatter_0._colors == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    assert log_formatter_0._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501



# Generated at 2022-06-26 08:22:13.287239
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Initialize a LogFormatter object
    log_formatter_0 = LogFormatter()
    # Assign values for the argument
    record_obj = LogRecord('levelname', 'levelno', 'pathname', 'lineno', 'msg', 'args', 'exc_info')
    # Call method format of class LogFormatter with the argument
    log_formatter_0.format(record_obj)


# Generated at 2022-06-26 08:22:20.671189
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_1 = LogFormatter()


# Generated at 2022-06-26 08:22:32.021948
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    # TODO: import tornado.options and assign the value to options
    options = tornado.options.options

    # TODO: Set the attribute of options: logging as "none"
    setattr(options, "logging", "none")

    # TODO: Enable the pretty logging
    enable_pretty_logging(options)


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:22:44.522407
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
    except ImportError:
        return
    # Case 1: test with options object not passed
    try:
        enable_pretty_logging()
    except AttributeError:
        # AttributeError expected in this scenario
        pass
    except Exception:
        raise
    # Case 2: test with options object passed

# Generated at 2022-06-26 08:22:56.166673
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Create a Tornado options.Options object with
    # log_file_prefix = "./test_log_file"
    options_0 = tornado.options._OptionParser()
    options_0.define("log_file_prefix", default="./test_log_file")
    options_0.parse_command_line()

    # Enable logging
    enable_pretty_logging(options=options_0)
    # Write a test log
    logger = logging.getLogger()
    logger.info("TEST INFO")
    logger.error("TEST ERROR")

    # Ensure that test log file is created
    assert os.path.isfile("./test_log_file.log")
    # Remove test log file
    os.remove("./test_log_file.log")

    # Enable logging, with no log_file_prefix

# Generated at 2022-06-26 08:22:58.576901
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None)