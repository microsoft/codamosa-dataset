

# Generated at 2022-06-26 08:14:59.299587
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.Formatter.format(None, None)

if __name__ == "__main__":
    test_case_0()
    test_LogFormatter_format()

# Generated at 2022-06-26 08:15:00.086933
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()



# Generated at 2022-06-26 08:15:13.013475
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('tornado.access')
    logger.setLevel(logging.INFO)
    logger.propagate = False
    formatter = LogFormatter(color=True)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    message = 'hello world'
    record = logging.LogRecord(logger.name, logging.INFO, '/', 0, message, (), None, None)
    logger.info(message)
    try:
        raise RuntimeError('test')
    except RuntimeError:
        logger.exception('test exception')

# Generated at 2022-06-26 08:15:23.661019
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True)
    record = logging.LogRecord(
        "tornado.access",
        logging.INFO,
        "/home/user/project/tornado/tornado/log.py",
        133,
        "test",
        (),
        exc_info=None,
        func="test_case_0",
        sinfo=None,
        )
    assert formatter.format(record) == u"[I 150504 09:24:32 log:133] test"


# Generated at 2022-06-26 08:15:35.816033
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test case 1
    log1 = LogFormatter()

    assert log1._fmt == log1.DEFAULT_FORMAT
    assert log1._colors == log1.DEFAULT_COLORS
    assert log1._normal == ''

    # Test case 2
    log2 = LogFormatter(datefmt='%x', style='$')

    assert type(log2._fmt) is str

    # Test case 3
    log3 = LogFormatter(color=False)

    assert log3._normal == ''


formatter = LogFormatter(color=True)
enable_pretty_logging(logging.INFO)



# Generated at 2022-06-26 08:15:44.388414
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Configure the frontend logger to generate a log file alongside the test
    # executable.  The test runner will capture and mock out stdout, so this is
    # the only way to see log messages from the test.
    #tornado.options.options.logging = "debug"
    logger = logging.getLogger()
    #logging.basicConfig(file=os.path.join(
    #    os.path.dirname(__file__), "test.log"))
    formatter = LogFormatter()
    logger.setLevel(logging.WARNING)
    logger.handlers[0].setFormatter(formatter)
    logger.warning("Test message")



# Generated at 2022-06-26 08:15:45.190073
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:15:53.845115
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #test exceptions
    try:
        # now = datetime.datetime.today()
        # timestr = now.strftime("%y%m%d %H:%M:%S")
        # print("%s] %s" % (timestr, "record.message"))
        print("Exception: %r: %r" % ("message", "record.__dict__"))
    except Exception as e:
        print("Exception: %r: %r" % (e, "record.__dict__"))


# Generated at 2022-06-26 08:16:02.498571
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    with mock.patch("tornado.options.parse_command_line") as parse_command_line:
        options = mock.Mock()
        options.logging = "None"
        tornado.options.options = options
        enable_pretty_logging()
        parse_command_line.assert_not_called()

    with mock.patch("tornado.options.options") as options:
        options.logging = "debug"
        enable_pretty_logging()
        assert options.logging.upper() == "DEBUG"


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:16:12.606026
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import define, options
    from time import time

    define("logging", default="info", help="log level")
    options.parse_command_line()

    logger = logging.getLogger("test_LogFormatter_format")
    for i in range(0, 40):
        logger.info("logging.Formatter test")
        logger.warning("logging.Formatter test")
        logger.error("logging.Formatter test")
        logger.critical("logging.Formatter test")
        logger.debug("logging.Formatter test")
        logger.fatal("logging.Formatter test")
        logger.warning("logging.Formatter test")
        logger.error("logging.Formatter test")
        logger.critical("logging.Formatter test")

# Generated at 2022-06-26 08:16:38.459785
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]"
    fmt += "%(end_color)s %(message)s"
    lf = LogFormatter(fmt=fmt)
    assert lf._fmt == fmt
    assert lf._colors == {}
    assert lf._normal == ""

# Generated at 2022-06-26 08:16:48.809977
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Create instances for testing
    log_formatter = LogFormatter()
    fmt = "%(color)s %(end_color)s"
    datefmt = r"%09d"
    log_formatter2 = LogFormatter(fmt, datefmt)
    log_formatter3 = LogFormatter(fmt, color=False)

    # Test the class attributes
    print(log_formatter.DEFAULT_FORMAT)
    print(log_formatter.DEFAULT_DATE_FORMAT)
    print(log_formatter.DEFAULT_COLORS)

    # Test instance attributes
    print(log_formatter.datefmt)
    print(log_formatter2.datefmt)
    print(log_formatter._fmt)
    print(log_formatter2._fmt)
   

# Generated at 2022-06-26 08:16:50.523002
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()


# Generated at 2022-06-26 08:16:54.124389
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print(LogFormatter().format(logging.makeLogRecord({"level": logging.DEBUG, "msg": "foo"})))

if __name__ == "__main__":
    test_case_0()
    test_LogFormatter_format()



# Generated at 2022-06-26 08:16:55.698713
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()


# Generated at 2022-06-26 08:17:02.706994
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter(fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s', datefmt='%y%m%d %H:%M:%S')  # noqa: E501
    assert isinstance(f, LogFormatter)


# Generated at 2022-06-26 08:17:07.743728
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    # Unit test for function enable_pretty_logging
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:17:18.168470
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" # noqa: E501
    lf = LogFormatter(fmt=fmt, datefmt="%y%m%d %H:%M:%S", style="test", color=True, colors={1:1, 2:2, 3:3, 4:4, 5:5})

    import io
    import sys
    import io
    import logging
    import logging.handlers
    from contextlib import redirect_stdout

    # global f
    f = io.StringIO()
    print("Output of unit test for method format of class LogFormatter:")

# Generated at 2022-06-26 08:17:28.693035
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    lf = LogFormatter(fmt, datefmt, style, color, colors)
    message = 'message'
    record = logging.LogRecord(
        name='name',
        level=logging.DEBUG,
        pathname='pathname',
        lineno=1,
        msg=message,
        args=(),
        exc_info=None,
        func='func')
    l

# Generated at 2022-06-26 08:17:35.882651
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # test_case_0()

    test_LogFormatter_0()

    # test_LogFormatter_1()

    # test_LogFormatter_2()

# Test for constructor of class LogFormatter
#
# In this test we check that LogFormatter(fmt, datefmt) does not
# fail.

# Generated at 2022-06-26 08:17:54.134539
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:17:56.429084
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger("tornado.access")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    logger.warning("warning")


# Generated at 2022-06-26 08:18:08.441312
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    class LogRecord(object):
        def __init__(self):
            self.exc_info = None
            self.exc_text = None
            self.asctime = "2020/10/05"
            self.color = ""
            self.__dict__ = {'asctime': '2020/10/05'}

        def getMessage(self) -> str:
            return "[I 100302 103622 foo:23] hello world!"

    record = LogRecord()
    res = log_formatter.format(record)
    assert res == '[2020/10/05] [I 100302 103622 foo:23] hello world!'


# Generated at 2022-06-26 08:18:10.332940
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test case 0: use default arguments
    test_case_0()


# Generated at 2022-06-26 08:18:22.989007
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.options import define, options, parse_command_line
    define("log_file_prefix", type=str, default="")
    define("logging", default="")
    parse_command_line()
    options.log_file_prefix = "ttt"
    options.logging = "debug"
    options.parse_command_line()
    # test case1: logging is empty
    options.logging = ""
    options.parse_command_line()
    # test case2: it is not a console
    logging.root.handlers = []
    options.logging = "debug"
    options.log_file_prefix = "ttt"
    options.parse_command_line()


# Generated at 2022-06-26 08:18:28.603703
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _lf = LogFormatter()
    _lf.format(logging.getLogger().handlers[0].terminator)


_default_logging_handler = None  # type: Optional[logging.Handler]



# Generated at 2022-06-26 08:18:32.136535
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    # Unit tests for this module
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:33.634017
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:18:39.014368
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        test_case_0()
    except Exception:
        print("Test case 0 failed.")
        pass

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:48.424902
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_case_0()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                        datefmt='%a, %d %b %Y %H:%M:%S',
                        filename='logging.log',
                        filemode='w')

    #################################################################################################
    #定义一个StreamHandler，将INFO级别或更高的日志信息打印到标准错误，并将其添加到当前的日志处理

# Generated at 2022-06-26 08:19:03.825370
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    print(f.DEFAULT_FORMAT)



# Generated at 2022-06-26 08:19:08.255973
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # If `colorama` is not available, skip the test.
    if not colorama:
        return

    # Set terminal screen to 256 color mode.
    ncolors = 8
    # https://docs.python.org/2/library/curses.html#curses.setupterm
    #   Return value:
    #      OK:  success
    #      ERR: failure (curses not initialized)
    #      -1:  success, but no color terminal or initialized explicitly
    #           with `curses.initscr()`
    rc = curses.setupterm(cast(bytes, None), sys.__stdout__.fileno())
    assert (rc == -1 or rc == curses.OK)

    # When `rc` is `curses.OK`, get the number of colors.

# Generated at 2022-06-26 08:19:16.535929
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    # create a logging record
    record = logging.LogRecord(
        "tornado.general", logging.DEBUG, "logger.py", 38, "message", [], None
    )
    result = formatter.format(record)
    print(result)
    # '\033[0m' is the end of ANSI escape sequence
    assert result.endswith('\033[0m message\n')


# Generated at 2022-06-26 08:19:25.339585
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    r = logging.LogRecord("tornado.access", logging.INFO, None, None, "Hi")
    s = lf.format(r)
    print(s)
    r.exc_info = "This is an Exception raised in a log function"
    s = lf.format(r)
    print(s)


# Generated at 2022-06-26 08:19:26.554951
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass



# Generated at 2022-06-26 08:19:28.669641
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert _stderr_supports_color() == True


# Generated at 2022-06-26 08:19:30.824621
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter


# Generated at 2022-06-26 08:19:32.432886
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-26 08:19:42.778253
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # setup
    fmt = "%(color)s[%(levelname)s] %(asctime)s - %(message)s"
    datefmt = "%H:%M:%S"
    style = "%"
    color = False
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    log_formatter = LogFormatter(fmt, datefmt, style, color, colors)
    # test
    test_LogFormatter_0(log_formatter)


# Generated at 2022-06-26 08:19:44.302951
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()



# Generated at 2022-06-26 08:20:13.032335
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = 'error'
    options.log_file_prefix = 'output/log_file_prefix'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 1024
    options.log_file_num_backups = 10
    logger = logging.getLogger()
    enable_pretty_logging(options, logger)

if __name__ == '__main__':
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:20:25.363951
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("test LogFormatter constructor")
    log_formatter_0 = LogFormatter()
    log_formatter_1 = LogFormatter(datefmt="%Y-%m-%d")
    log_formatter_2 = LogFormatter(datefmt="%y%m%d %H:%M:%S")
    log_formatter_3 = LogFormatter(fmt="%(color)s")
    log_formatter_4 = LogFormatter(fmt=LogFormatter.DEFAULT_FORMAT)
    log_formatter_5 = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s]%(end_color)s %(message)s"
    )

# Generated at 2022-06-26 08:20:26.994251
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:20:28.778162
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:20:29.402094
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:20:38.051122
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    log_formatter_0 = LogFormatter(color=False)
    log_formatter_0 = LogFormatter(color=True)
    log_formatter_0 = LogFormatter(color=True, colors={})
    log_formatter_0 = LogFormatter(color=True, colors={logging.DEBUG: 1})
    log_formatter_0 = LogFormatter(color=True, colors={logging.INFO: 1})
    log_formatter_0 = LogFormatter(color=True, colors={logging.WARNING: 1})
    log_formatter_0 = LogFormatter(color=True, colors={logging.ERROR: 1})
    log_formatter_0 = LogFormatter(color=True, colors={logging.CRITICAL: 1})


# Generated at 2022-06-26 08:20:43.053005
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    define("logging", default="debug", help="Logging level", type=str)
    parse_config_file("config.py")
    enable_pretty_logging()


# Generated at 2022-06-26 08:20:43.812611
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert 1 == 1

# Generated at 2022-06-26 08:20:45.980368
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()



# Generated at 2022-06-26 08:20:49.658788
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:21:20.307360
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print('test_LogFormatter...')
    log_formatter_0 = LogFormatter()
    print(log_formatter_0)


# Generated at 2022-06-26 08:21:29.721317
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.log_to_stderr = True
    tornado.options.options.log_file_prefix = "log.txt"
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.logging = "DEBUG"
    enable_pretty_logging()


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:21:31.273992
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()



# Generated at 2022-06-26 08:21:41.523446
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "DEBUG"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_to_stderr = True
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_rotate_interval = 1
    try:
        enable_pretty_logging()
    except Exception as e:
        print(e.__class__.__name__)
        pass
    tornado.options.options.log_file_prefix = "test.log"

# Generated at 2022-06-26 08:21:48.613109
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord(name=None, level=-100,
            pathname=None, lineno=0,
            msg="%s", args=(10,),
            exc_info=None, func=None)
    log_formatter = LogFormatter()
    str = log_formatter.format(record)
    str

# Generated at 2022-06-26 08:22:01.261881
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_file_prefix", type=str, default="./log/mytest.log")
    tornado.options.options.log_file_prefix = "./log/mytest.log"
    tornado.options.options.logging = "ERROR"
    enable_pretty_logging()
    assert logging.getLogger().level == logging.ERROR
    assert len(logging.getLogger().handlers) == 1
    logging.getLogger().handlers[0].close()


if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:22:11.956413
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options
    old_level = options.logging
    old_file_prefix = options.log_file_prefix
    old_log_to_stderr = options.log_to_stderr

    options.logging = 'none'
    assert old_level != options.logging
    assert old_file_prefix != options.log_file_prefix
    assert old_log_to_stderr != options.log_to_stderr

    # Test for case 0.
    test_case_0()

step_counter = 0

#TODO: Fix this function to support function_name

# Generated at 2022-06-26 08:22:18.686555
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = logger.makeRecord(level=logging.DEBUG)
    # assert log_formatter_0.format(record_0) == "[D xxxx :xx]  "
    return


# Generated at 2022-06-26 08:22:22.049064
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("log_to_stderr", default=True, help="log to stderr", type=bool)
    enable_pretty_logging()

# Generated at 2022-06-26 08:22:32.907326
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line

    # Create a command line option for logging
    define("test_logging", "test", type=str, help="logging options")
    define("logging", None, type=str, help="logging options")
    define("log_file_prefix", type=str, help="the prefix for log file")
    define("log_rotate_mode", type=str, help="the mode for log rotate")
    define("log_file_max_size", type=str, help="the max size of log file")
    define("log_file_num_backups", type=str, help="the num of backups log file")
    define("log_rotate_when", type=str, help="the rotate time of log file")

# Generated at 2022-06-26 08:23:09.127941
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class fake_options:
        logging = "debug"
        log_file_prefix = None
        log_to_stderr = False

    enable_pretty_logging(fake_options)
    return

# Generated at 2022-06-26 08:23:18.083976
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_0 = LogFormatter()
    assert log_formatter_0 is not None, 'Test Failed: test_LogFormatter:0'
    assert log_formatter_0._fmt == LogFormatter.DEFAULT_FORMAT, 'Test Failed: test_LogFormatter:1'
    assert isinstance(log_formatter_0._colors, dict) is True, 'Test Failed: test_LogFormatter:2'
    assert isinstance(log_formatter_0._normal, str) is True, 'Test Failed: test_LogFormatter:2'



# Generated at 2022-06-26 08:23:28.598856
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        def __init__(self):
            self.log_file_prefix = None
            self.logging = 'DEBUG'
            self.log_file_max_size = 1024
            self.log_file_num_backups = 2
            self.log_file_prefix = "C:\log.txt"
            self.log_rotate_mode = 'time'
            self.log_rotate_when = 'D'
            self.log_rotate_interval = 1

    options_0 = Options()
    enable_pretty_logging(options = options_0)


# Generated at 2022-06-26 08:23:40.655438
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    log_record = logging.LogRecord('name','level','path','lineno','msg','args','exc_info','func','succeeded',None)
    log_record.levelno, log_record.__dict__ = 0, {}
    log_record.__dict__["color"] = log_formatter._colors[log_record.levelno]
    log_record.__dict__["end_color"] = ""
    log_record.asctime = log_formatter.formatTime(log_record, cast(str, log_formatter.datefmt))
    log_record.message = _safe_unicode(log_record.getMessage())

# Generated at 2022-06-26 08:23:48.597941
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter_1 = LogFormatter()
    print('test_LogFormatter')

    # Test of __init__(self, fmt=DEFAULT_FORMAT, datefmt=DEFAULT_DATE_FORMAT, style='%', col
    # or=True, colors=DEFAULT_COLORS)
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 08:23:52.104011
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter is not None


# Generated at 2022-06-26 08:24:02.769459
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    
    class Options(object):
        def __init__(self, **kwargs):
            for kw in kwargs:
                self.__dict__[kw] = kwargs[kw]
    
    test_options = Options(
        logging = None,
        log_file_prefix = None,
        log_to_stderr = None,
        log_rotate_mode = 'size',
        log_file_max_size = 100,
        log_file_num_backups = 10,
        log_rotate_when = 'H',
        log_rotate_interval = 1,
    )
    
    tornado.options.options = test_options
    
    enable_pretty_logging()

if __name__ == '__main__':
    test_case_0

# Generated at 2022-06-26 08:24:04.346904
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.OptionParser()

    define_logging_options(options)

    options.parse_config_file("test_logging.conf")

# Generated at 2022-06-26 08:24:07.080271
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test with no parameter
    enable_pretty_logging()

# Test with a simple parameter

# Generated at 2022-06-26 08:24:11.900934
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger_0 = logging.getLogger('tornado.general')
    logger_0.setLevel(logging.DEBUG)

    if not logger_0.handlers:
        enable_pretty_logging(None, logger_0)

    logger_0.debug('debug message')
    logger_0.info('info message')
    logger_0.warning('warning message')
    logger_0.error('error message')
    logger_0.critical('critical message')