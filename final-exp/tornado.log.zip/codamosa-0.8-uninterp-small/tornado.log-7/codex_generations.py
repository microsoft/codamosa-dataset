

# Generated at 2022-06-26 08:14:59.576581
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    define("logging", default="none", help="logging configuration", type=str)
    define("log_to_stderr", default=True, help="enable log to stderr", type=bool)
    define("log_file_prefix", default="", help="the log file prefix", type=str)
    options = options
    enable_pretty_logging(options)


# Generated at 2022-06-26 08:15:07.204504
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    str_0 = 'log_to_stderr'
    str_1 = 'logging'
    str_2 = 'color'
    str_3 = 'timestamp_format'
    str_4 = 'time'
    str_5 = 'format'
    str_6 = 'log_file_prefix'
    str_7 = 'log_rotate_mode'
    str_8 = 'size'
    str_9 = 'log_file_num_backups'
    int_0 = 3
    int_1 = 3
    int_2 = 3
    int_3 = 3
    int_4 = 3
    int_5 = 3
    int_6 = 3
    int_7 = 3
    float_0 = float(3)
    float_1 = float(3)


# Generated at 2022-06-26 08:15:15.090526
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    a = LogFormatter()
    b = LogFormatter("%(colors)")
    c = LogFormatter("%(colors)", "%(colors)")
    d = LogFormatter("%(colors)", "%(colors)", "%(colors)")
    e = LogFormatter("%(colors)", "%(colors)", "%(colors)", True)
    f = LogFormatter("%(colors)", "%(colors)", "%(colors)", False)
    g = LogFormatter("%(colors)", "%(colors)", "%(colors)", False, {True: 1, False: 2})


# Generated at 2022-06-26 08:15:23.695076
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    gen_log.info('Start test_LogFormatter_format')
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord('abc', 0, 'abc', 0, 'abc', None, None)
    log_formatter_0 = log_formatter_0.format(record_0)


if __name__ == '__main__':
    test_case_0()
    test_LogFormatter_format()

# Generated at 2022-06-26 08:15:27.015209
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
test_LogFormatter()


# Generated at 2022-06-26 08:15:35.673048
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    str_0 = '=6I|U6>'
    log_formatter_0 = LogFormatter(str_0, str_0)
    my_record = logging.LogRecord(str_0, 1, str_0, 1, str_0, {}, None)
    my_record.levelno = 1
    my_record.exc_info = "0"
    my_record.exc_text = str_0
    log_formatter_0.format(my_record)


# Generated at 2022-06-26 08:15:48.205625
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    if sys.version_info >= (3, 8):
        from unittest import mock
    else:
        import unittest.mock as mock

    kwargs = {"options": mock.Mock(), "logger": mock.Mock()}
    kwargs["options"].logging.upper.return_value = 'DEBUG'
    kwargs["options"].log_rotate_mode = 'size'
    kwargs["options"].log_file_prefix = ''
    kwargs["options"].log_file_max_size = 0
    kwargs["options"].log_file_num_backups = 0
    kwargs["options"].log_to_stderr = 'DEBUG'

    enable_pretty_logging(**kwargs)

# Generated at 2022-06-26 08:16:00.498015
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    str_0 = 's0'
    str_1 = 's1'
    dict_0 = {}
    record_type_0 = type("record_type", (), {'exc_text': [], 'levelno': dict_0, 'getMessage':lambda: str_0, 'message': str_1, 'exc_info': dict_0, 'asctime': str_1, '__dict__': dict_0})
    record_0 = record_type_0()

    log_formatter_0 = LogFormatter()
    log_formatter_0.datefmt = str_1
    log_formatter_0.format(record_0)

if __name__ == "__main__":
    test_LogFormatter_format()

# Generated at 2022-06-26 08:16:10.179333
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class LogRecord_0():
        levelno = None
        exc_info = None
        exc_text = None
        __dict__ = None
        asctime = None
        color = None
        end_color = None
        message = '2D]\x00\x00\x00\x00\x00\x00\x00'

    exception_0 = Exception()
    log_record_0 = LogRecord_0()
    exception_1 = Exception()
    try:
        log_formatter_0 = LogFormatter(str_0, str_0)
        log_formatter_0.format(log_record_0)
        raise exception_1
    except Exception as exception_2:
        exception_0 = exception_2
    assert exception_0 is exception_1


# Generated at 2022-06-26 08:16:16.599200
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    str_0 = 'l#18'
    log_formatter_0 = LogFormatter(str_0, str_0)
    log_formatter_0.format(str_0)
    str_0 = "Ix%Cv"
    log_formatter_0.format(str_0)


# Generated at 2022-06-26 08:16:34.374862
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    '''
    __init__(self, fmt: Optional[str] = None, datefmt: Optional[str] = None, style: str = '%')
    '''
    log_formatter_0 = LogFormatter()

    # Case 0: generate a Record format and format it
    # Case 0: generate a Record format and format it
    record_0 = logging.LogRecord(name = "test_name_0", level = logging.DEBUG, pathname = "test_pathname_0", lineno = 0, msg = "test_msg_0", args = None, exc_info = None)
    # record_0.message = _safe_unicode(message)
    record_0.asctime = log_formatter_0.formatTime(record_0, cast(str, log_formatter_0.datefmt))


# Generated at 2022-06-26 08:16:43.401636
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create a LogFormatter object
    # Use default arguments
    log_formatter_0 = LogFormatter()
    log_formatter_0.format(access_log)
    log_formatter_0.format(app_log)
    log_formatter_0.format(gen_log)

    # Define logging levels and color code
    level_color = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    # Define logging format

# Generated at 2022-06-26 08:16:48.450935
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test the constructor of LogFormatter
    log_formatter_0 = LogFormatter()
    assert log_formatter_0 is not None


# Generated at 2022-06-26 08:16:51.629634
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()
    logging.info("Unit test for constructor of LogFormatter")


# test for LogFormatter in tornado.log

# Generated at 2022-06-26 08:17:02.365213
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Enable logging
    enable_pretty_logging()

    # Test logging
    acc_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")
    acc_log.info("acc_log test")
    app_log.info("app_log test")
    gen_log.info("gen_log test")

if __name__ == "__main__":
    print("testing module logging.py")
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:17:07.665461
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter._colors, dict)
    assert isinstance(log_formatter._normal, str)


# Generated at 2022-06-26 08:17:18.142891
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    log_formatter_0 = LogFormatter(fmt,datefmt,style,color,colors)

    log_formatter_0.format(logging.debug)

# Generated at 2022-06-26 08:17:24.703216
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # default
    test_case_0()

for name in ["tornado.access", "tornado.application", "tornado.general"]:
    logging.getLogger(name).addHandler(logging.NullHandler())

if __name__ == "__main__":
    test_LogFormatter()

# Generated at 2022-06-26 08:17:26.640906
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options=tornado.options.options
    logger = logging.getLogger()
    enable_pretty_logging(options, logger)


# Generated at 2022-06-26 08:17:31.159191
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("Constructor test")
    print("\n")

    test_case_0()

    print("Constructor test successful")
    print("\n")


# Generated at 2022-06-26 08:17:42.259204
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = logging.LogRecord(name=None, level=0, pathname=None, lineno=0, msg=None,
                                 args=None, exc_info=None)
    result = log_formatter_0.format(record=record_0)
    print(result)



# Generated at 2022-06-26 08:17:49.004763
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options = tornado.options.define("logging", None, str)
    tornado.options.options.logging = 'debug'
    log_formatter = LogFormatter()
    enable_pretty_logging()

test_enable_pretty_logging()

# Generated at 2022-06-26 08:18:02.817205
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # If the logging option is none, the function should return directly
    arg_options = argparse.Namespace()
    arg_options.logging = "none"
    arg_options.log_file_prefix = None
    assert enable_pretty_logging(arg_options) == None

    # If log_file_prefix is not given, logging level should be set, but the handler should not be added
    arg_options = argparse.Namespace()
    arg_options.logging = "info"
    arg_options.log_file_prefix = None
    enable_pretty_logging(arg_options)
    logger = logging.getLogger()
    assert logger.level == 20
    assert len(logger.handlers) == 0

    # If log_rotate_mode is wrong, it should raise ValueError
    arg_options = arg

# Generated at 2022-06-26 08:18:14.193668
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    # pylint: disable=protected-access
    # pylint: disable=missing-docstring
    options = tornado.options.options
    logging_0 = logging.getLogger()
    # pylint: disable=no-member
    # pylint: disable=no-member
    # pylint: disable=no-member
    # pylint: disable=no-member
    # pylint: disable=no-member
    # pylint: disable=no-member
    # pylint: disable=no-member
    # pylint: disable=no-member
    # pylint: disable=no-member
    options.logging = None
    options.log_file_prefix = "option_0_log_file_prefix"
    options.log_rot

# Generated at 2022-06-26 08:18:17.355410
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Tested in test_case_0() element 1
    pass


# Generated at 2022-06-26 08:18:21.101282
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("logging", default="warning", metavar="LOGGING", help="logging")
    enable_pretty_logging()

# Generated at 2022-06-26 08:18:34.278704
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        style="%",
        color=True,
        colors={logging.DEBUG: 4,  # Blue
                logging.INFO: 2,  # Green
                logging.WARNING: 3,  # Yellow
                logging.ERROR: 1,  # Red
                logging.CRITICAL: 5,  # Magenta
               },
    )

test_LogFormatter()

# Generated at 2022-06-26 08:18:46.257006
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()

    record = logging.LogRecord(name=None, level=None, pathname=None, lineno=None,
        msg=None, args=None, exc_info=None)

    record.name = 'test'
    record.level = 'debug'
    record.pathname = '~/Downloads/test.log'
    record.lineno = 0
    record.msg = 'this is a log message'
    record.args = None
    record.exc_info = None

    try:
        message = record.getMessage()
        assert isinstance(message, basestring_type)
        record.message = _safe_unicode(message)
    except Exception as e:
        record.message = "Bad message (%r): %r" % (e, record.__dict__)



# Generated at 2022-06-26 08:18:57.667542
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tempfile
    import os

    options = tornado.options.options
    options.logging = "DEBUG"

    temp_log_file = tempfile.NamedTemporaryFile()
    options.log_file_prefix = temp_log_file.name

    enable_pretty_logging(options)

    gen_log.debug("DEBUG MSG")
    gen_log.info("INFO MSG")
    gen_log.warning("WARNING MSG")
    gen_log.error("ERROR MSG")
    gen_log.critical("CRITICAL MSG")

    with open(temp_log_file.name, "r") as f:
        logged_lines = [line.rstrip("\n") for line in f.readlines()]

    temp_log_file.close()

    print("sample log:")
    print

# Generated at 2022-06-26 08:19:07.727311
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Initialize logging system.
    from tornado.options import options, define, parse_command_line
    import argparse

    define(
        "logging",
        default="info",
        type=str,
        help=("Set the Python log level. If 'none', tornado won't touch the " "logging configuration."),
    )
    define(
        "log_to_stderr",
        default=None,
        type=bool,
        help=("Send log output to stderr (colorized if possible). " "By default use stderr if --log_file_prefix is not set and " "no other logging is configured."),
    )

# Generated at 2022-06-26 08:19:16.626727
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()

####################



# Generated at 2022-06-26 08:19:22.925897
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

test_case_0()
test_enable_pretty_logging()

__all__ = ["access_log", "app_log", "gen_log", "enable_pretty_logging"]

# Generated at 2022-06-26 08:19:31.165788
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger_0 = logging.getLogger()
    logger_0.setLevel(logging.DEBUG)
    options_0 = object()
    options_0.log_file_max_size = 100
    options_0.log_rotate_mode = "time"
    options_0.log_file_prefix = "/home/nbtest/tornado/tornado/test/test.log"
    options_0.logging = "debug"
    options_0.log_rotate_when = "d"
    options_0.log_file_num_backups = 7
    options_0.log_rotate_interval = 1
    options_0.log_to_stderr = True
    enable_pretty_logging(options=options_0, logger=logger_0)


# Generated at 2022-06-26 08:19:42.975876
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class options:
        logging = None
        log_file_prefix = None
        log_rotate_mode = None
        log_file_max_size = None
        log_file_num_backups = None
        log_to_stderr = None
    class logger:
        def setLevel(self, level):
            pass
        def addHandler(self, channel):
            pass
    enable_pretty_logging(options, logger)

    options.logging = "debug"
    enable_pretty_logging(options, logger)

    options.logging = "info"
    enable_pretty_logging(options, logger)

    options.logging = "warning"
    enable_pretty_logging(options, logger)

    options.logging = "error"
    enable_pretty_logging(options, logger)



# Generated at 2022-06-26 08:19:44.454780
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-26 08:19:47.538254
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert True

# Generated at 2022-06-26 08:19:50.015874
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()
    return 'unit_test_pass'



# Generated at 2022-06-26 08:20:01.318535
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    # Test with some default values
    log_formatter_1 = LogFormatter()
    assert log_formatter_1 is not None

    # Test with a valid date formatter
    date_formatter = "%y%m%d %H:%M:%S"
    log_formatter_2 = LogFormatter(datefmt=date_formatter)
    assert log_formatter_2 is not None
    assert log_formatter_2.datefmt == date_formatter

    # Test with a valid color
    color = True
    log_formatter_3 = LogFormatter(color=color)
    assert log_formatter_3 is not None
    assert isinstance(log_formatter_3.color, bool)
    assert log_formatter_3.color == color

    # Test with valid colors

# Generated at 2022-06-26 08:20:03.336738
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()



# Generated at 2022-06-26 08:20:14.692791
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test Parameter
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    # Bases: https://github.com/tornadoweb/tornado/blob/master/tornado/log.py
    # Test construct
    log_formatter = LogFormatter(fmt, datefmt, style, color)
    assert len(log_formatter._colors) == 5
    assert log_formatter._normal == "\033[0m"

    assert True

if __name__ == "__main__":
    test_LogForm

# Generated at 2022-06-26 08:20:36.215370
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = 'log_file_prefix'
    tornado.options.options.log_rotate_mode = 'size'
    tornado.options.options.log_file_max_size = 5
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.logging = 'debug'

    logger = logging.getLogger()
    enable_pretty_logging(logger=logger)

    logger.setLevel(logging.DEBUG)
    logger.debug('debug')


# Generated at 2022-06-26 08:20:37.501073
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    enable_pretty_logging(logger=logger)
    return


# Generated at 2022-06-26 08:20:42.748274
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    l.basicConfig(level=l.DEBUG)
    l.warn("%s: The quick brown fox jumps over the lazy dog.", log_formatter_0.format(log_formatter_0))

# Generated at 2022-06-26 08:20:56.481139
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class myRecord(object):
        pass

    # 选择有异常信息的record
    myrecord = myRecord()

# Generated at 2022-06-26 08:21:01.655379
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_to_stderr", type=bool)
    tornado.options.parse_command_line([])
    enable_pretty_logging()

# Generated at 2022-06-26 08:21:09.694877
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.options.logging = "DEBUG"
    tornado.options.options.log_file_prefix = "/tmp/file_prefix.log"
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    
    logger.info("This is an info message!")
    logger.warning("This is a warning message!")
    logger.error("This is an error message!")

    enable_pretty_logging()

    logger.info("This is an info message!")
    logger.warning("This is a warning message!")
    logger.error("This is an error message!")
    
if __name__ == "__main__":
    import logging
    import tornado.options
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:21:14.972542
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord("name", 10, "pathname", 1, "msg", None, None)
    result = log_formatter.format(record)
    assert result != None


# Generated at 2022-06-26 08:21:18.777290
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        log_formatter_0 = LogFormatter()
    except Exception as e:
        print('LogFormatter: constructor: Exception: {}'.format(e))
    else:
        pass
    # Convert the terminal control characters from
    # bytes to unicode strings for easier use with the
    # logging module.
    assert isinstance(log_formatter_0._colors, dict)
    assert isinstance(log_formatter_0._normal, str)



# Generated at 2022-06-26 08:21:26.221417
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import random
    import time
    random.seed(time.time())
    tornado.log.enable_pretty_logging(tornado.options.options)
    gen_log.debug(random.random())

if __name__ == "__main__":
    test_case_0()
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:21:39.284024
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # type: () -> None
    """Test enable_pretty_logging with fake options.
    
    """
    options = type("options", (object,), {"logging": "INFO",
                                          "log_file_prefix": "log.txt",
                                          "log_rotate_mode": "size",
                                          "log_file_max_size": 100,
                                          "log_file_num_backups": 10,
                                          "log_to_stderr": None})()
    enable_pretty_logging(options)
    logger = logging.getLogger()
    assert type(logger) == logging.RootLogger
    assert logger.level == logging.INFO

# Generated at 2022-06-26 08:22:24.433222
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # 1
    log_formatter_1 = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        style="%",
        color=True,
        colors={logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5},
    )
    # 2

# Generated at 2022-06-26 08:22:29.996381
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()
    record_0 = ''
    try:
        ret = log_formatter_0.format(record_0)
        print(ret)
    except Exception as e:
        print("Test LogFormatter format failed. %s" % e)

# Generated at 2022-06-26 08:22:35.885464
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # call function via constructor
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._normal == ""
    assert log_formatter._colors == {}

    # call function via subclass
    class S(LogFormatter):
        pass
    log_formatter_0 = S()
    assert log_formatter_0._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter_0._normal == ""
    assert log_formatter_0._colors == {}

    # call test_case_0
    test_case_0()



# Generated at 2022-06-26 08:22:37.972937
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter

# Generated at 2022-06-26 08:22:43.001203
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    test_case_0()


# Generated at 2022-06-26 08:22:44.882916
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_0 = LogFormatter()


# Generated at 2022-06-26 08:22:47.217663
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None)

# Generated at 2022-06-26 08:22:55.034583
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter_1 = LogFormatter()
    record = logging.LogRecord(
        name="tornado.general", level=logging.DEBUG, pathname=None, lineno=0, msg="", args=None, exc_info=None,
    )
    result = log_formatter_1.format(record)
    assert result == "[D 0:00:00 tornado.general:0] \n    ", "Expected ' [D 0:00:00 tornado.general:0] ', but got '%s'" % result

# Generated at 2022-06-26 08:23:05.993105
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options_0 = tornado.options.options
    options_0.logging = 'debug'
    enable_pretty_logging()
    logging.debug('test_enable_pretty_logging: This is a debug msg')
    logging.info('test_enable_pretty_logging: This is an info msg')
    logging.warning('test_enable_pretty_logging: This is a warning msg')
    logging.error('test_enable_pretty_logging: This is an error msg')
    logging.critical('test_enable_pretty_logging: This is a critical msg')

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-26 08:23:18.694155
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options:
        logging = None
        log_file_prefix = None
        log_rotate_mode = None
        log_file_max_size = None
        log_file_num_backups = None  # type: Any
        log_rotate_when = None
        log_rotate_interval = None
        log_to_stderr = None

    options = Options()
    options.logging = "warning"
    options.log_file_prefix = "./test_log_file"
    options.log_rotate_mode = "time"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 10
    options.log_rotate_when = "s"
    options.log_rotate_interval = 1
    options.log_to_st