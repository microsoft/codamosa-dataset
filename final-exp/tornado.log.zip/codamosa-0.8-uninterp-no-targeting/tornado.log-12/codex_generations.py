

# Generated at 2022-06-22 03:53:42.251386
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    import time
    import glob
    import os
    import shutil
    import tempfile
    import re
    options = tornado.options.define_logging_options(
        options=tornado.options.OptionParser()
    )

    options.define("port", default=8888, type=int)
    options.parse_command_line([])

    class MyHandler(logging.StreamHandler):
        def emit(self, record: Any) -> None:
            time.sleep(0.1)
            logging.StreamHandler.emit(self, record)

    logger = logging.getLogger("")
    logger.addHandler(MyHandler())
    logger.setLevel(logging.DEBUG)
    logging.getLogger("").debug("test1")
    from tornado.log import app_

# Generated at 2022-06-22 03:53:49.185419
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_command_line("--logging=INFO --log_to_stderr true".split())
    temp = logging.getLogger()
    assert temp.getEffectiveLevel() == logging.INFO
    assert len(temp.handlers[0]._name) == 0

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:53:58.210351
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("log_file_prefix", default="", type=str)
    define("log_to_stderr", default="", type=str)
    define("logging", default="", type=str)
    define("log_rotate_mode", default="", type=str)
    options.log_file_prefix = "abc.txt"
    options.log_file_num_backups = 1
    options.log_rotate_mode = "size"
    options.log_rotate_when = "1"
    options.log_rotate_interval = 1
    options.log_file_max_size = 1
    options.logging = "warning"
    options.log_to_stderr = True
    enable_pretty_logging(options)

# Generated at 2022-06-22 03:54:07.792678
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    formatter = LogFormatter(datefmt="%Y-%m-%d %H:%M:%S")
    test = {
        "asctime": "2015-11-21 21:22:23",
        "message": "test",
        "color": "test_color",
        "end_color": "test_end_color"
    }
    logging.LogRecord("test", 2, "", 10, "test", None, None)
    assert formatter.format(test) == "[.. 2015-11-21 21:22:23 ..:..] test"


# Generated at 2022-06-22 03:54:16.775537
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == \
        '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'
    assert formatter.DEFAULT_DATE_FORMAT == '%y%m%d %H:%M:%S'
    assert formatter.DEFAULT_COLORS == {
        logging.DEBUG: 4,
        logging.INFO: 2,
        logging.WARNING: 3,
        logging.ERROR: 1,
        logging.CRITICAL: 5,
    }


# Generated at 2022-06-22 03:54:20.909265
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class A():
        def __init__(self) -> None:
            # type: () -> None
            pass
        def getMessage(self) -> str:
            # type: () -> str
            return 'message'
    a = A()
    logf = LogFormatter()
    assert(logf.format(a) == '\x1b[4;37m[M 0101 00:00:00 <ipython-input-20-272e5f5c5df5>:4]\x1b[0m message')


# Generated at 2022-06-22 03:54:22.010909
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # tested in test_httpserver
    pass



# Generated at 2022-06-22 03:54:34.448986
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    formatter = LogFormatter()
    assert formatter._colors == {
        logging.DEBUG: "\033[2;34m",
        logging.INFO: "\033[2;32m",
        logging.WARNING: "\033[2;33m",
        logging.ERROR: "\033[2;31m",
        logging.CRITICAL: "\033[2;35m",
    }
    assert formatter._normal == "\033[0m"
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""
    assert formatter._fmt == LogFormatter.DEFAULT

# Generated at 2022-06-22 03:54:41.240510
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    logger = logging.getLogger()
    assert len(logger.handlers) == 0
    options = tornado.options.options
    options.logging = "info"
    options.log_to_stderr = False
    options.log_file_prefix = "test_enable_pretty_logging"
    options.log_file_max_size = 10
    options.log_file_num_backups = 1
    options.log_rotate_mode = "size"
    enable_pretty_logging(options)
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.handlers.RotatingFileHandler)

if __name__ == "__main__":
    test_enable_pretty

# Generated at 2022-06-22 03:54:45.749107
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with open('test.log', 'w'):
        pass
    handler = logging.FileHandler('test.log')
    handler.setFormatter(LogFormatter())
    logger.addHandler(handler)
    logger.info('fuck')



# Generated at 2022-06-22 03:54:57.710335
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = type("Options", (object,), {"logging": "debug"})()
    enable_pretty_logging(options)

# Generated at 2022-06-22 03:55:09.832835
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    from tornado.options import options
    #os.environ["log_file_prefix"] = 'test.log'
    options.logging = "none"
    options.log_file_prefix = None
    tornado.log.enable_pretty_logging(options)
    gen_log.info("test log file")
    assert not gen_log.handlers
    options.logging = "debug"
    options.log_file_prefix = 'test.log'
    options.log_rotate_when = 'midnight'
    options.log_rotate_interval = 1
    options.log_rotate_mode = 'time'
    tornado.log.enable_pretty_logging(options)
    gen_log.info("test log file")
    options.log_file_

# Generated at 2022-06-22 03:55:12.894324
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.parse_command_line()
    enable_pretty_logging(options)

# Generated at 2022-06-22 03:55:24.365630
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)
    options = parser.parse_args([])
    enable_pretty_logging(options)
    assert options.logging == 'info'
    assert options.log_to_stderr == None
    assert options.log_file_prefix == None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == 'midnight'
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == 'size'

# Generated at 2022-06-22 03:55:25.348066
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()



# Generated at 2022-06-22 03:55:25.946425
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass

# Generated at 2022-06-22 03:55:31.036876
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    logging_options = tornado.options.options
    define_logging_options(logging_options)
    logging_options.parse_command_line()
    print('log file location: %s' % logging_options.log_file_prefix)


#test_define_logging_options()

# Generated at 2022-06-22 03:55:31.790739
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-22 03:55:43.240534
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class A:
        pass
    a = A()
    a.msg = "hello"
    a.levelname = "INFO"
    a.levelno = 3
    a.name = "name ::"
    a.pathname = "path"
    a.lineno = 33
    a.funcName = "function name"
    a.process = 1
    a.processName = "processName"
    a.thread = 1
    a.threadName = "threadName"
    a.created = 1
    a.msecs = 1
    a.relativeCreated = 1
    a.asctime = "asctime"
    logger = logging.Logger("test")
    logger.addHandler(logging.StreamHandler())
    logger.info(a)

# Generated at 2022-06-22 03:55:45.423927
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter().format(logging.LogRecord("", logging.INFO, "", 0, "", (), None))


# Generated at 2022-06-22 03:56:06.202228
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger()
    logger.handlers = [logging.StreamHandler()]
    for is_color in [False, True]:
        fmt = LogFormatter(color=is_color)
        logger.info("Message without exception")
        try:
            raise Exception("Exception message")
        except Exception:
            logger.exception("Message")
        logger.info("Message with exception")

try:
    _default_log_colors = dict(
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        }
    )
except Exception:
    _default_log_colors = dict()


# Generated at 2022-06-22 03:56:07.636876
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()
test_define_logging_options()

# Generated at 2022-06-22 03:56:20.064810
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tempfile
    import os
    import errno
    import shutil
    import datetime
    try:
        os.mkdir("test_log")
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

# Generated at 2022-06-22 03:56:25.133869
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    options._options = {}
    options._parse_callbacks = []
    define_logging_options(options)
    assert len(options._options) == 9
    # Default value of log_rotate_mode is 'size'
    assert options.log_rotate_mode == 'size'

# Generated at 2022-06-22 03:56:26.175255
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 03:56:37.308267
# Unit test for function define_logging_options
def test_define_logging_options():
    import logging
    import tornado.options
    from tornado.options import define, options

    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)

    define_logging_options()
    define('debug', default=False, help='Set debug mode', type=bool)


    tornado.options.parse_command_line()
    options.logging = 'debug'
    enable_pretty_logging(options, logger)
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    # logger.critical('critical message')

# test_define_logging_options()

# Generated at 2022-06-22 03:56:43.613518
# Unit test for function define_logging_options
def test_define_logging_options():
    class TestOptionParser:
        pass
    options = TestOptionParser()
    define_logging_options(options)
    assert hasattr(options, 'logging')
    assert hasattr(options, 'log_to_stderr')
    assert hasattr(options, 'log_file_prefix')
    assert hasattr(options, 'log_file_max_size')
    assert hasattr(options, 'log_file_num_backups')
    assert hasattr(options, 'log_rotate_when')
    assert hasattr(options, 'log_rotate_interval')
    assert hasattr(options, 'log_rotate_mode')


# Generated at 2022-06-22 03:56:53.474471
# Unit test for function define_logging_options
def test_define_logging_options():
    import sys
    import tornado.options
    tornado.options.define("debug",type=bool)
    tornado.options.parse_command_line(["--debug"])
    define_logging_options()  
    #sys.argv.remove("--debug")
    tornado.options.parse_command_line(["--log_rotate_mode=time"])
    enable_pretty_logging()
    app_log.warning("app_log test")
    access_log.warning("access_log test")
    gen_log.warning("gen_log test")
    return 0


# Generated at 2022-06-22 03:56:54.191013
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-22 03:56:59.279589
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger(__name__)

    formatter = LogFormatter()
    assert formatter.format(logger.makeRecord(__name__, logging.INFO, "message", None, None)) == '[I ' + str(datetime.date.today()) + ' ' + __name__ + ':1] message'



# Generated at 2022-06-22 03:57:19.376259
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    if formatter is None:
        raise RuntimeError("test_LogFormatter function is None")



# Generated at 2022-06-22 03:57:31.045282
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado
    import tornado.options
    import logging
    from tornado.options import define, options
    define("logging", default="info",
    help="Logging level", metavar="debug|info|warning|error|none")
    define("log_file_prefix", default=None,
    help="Path prefix for log files")
    define("log_file_max_size", default=100000,
    help="max size of log files before rollover")
    define("log_file_num_backups", type=int, default=10,
    help="number of log files to keep")
    define("log_rotate_mode", default="size",
    help="Log rotate mode [size|time]")
    tornado.options.parse_command_line(None)

# Generated at 2022-06-22 03:57:42.624917
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line([])
    assert tornado.options.options.logging == "info"
    assert tornado.options.options.log_to_stderr is not None
    assert tornado.options.options.log_file_prefix is None
    assert tornado.options.options.log_file_num_backups == 10
    assert tornado.options.options.log_file_max_size == 100000000
    assert tornado.options.options.log_rotate_when == "midnight"
    assert tornado.options.options.log_rotate_interval == 1
test_define_logging_options()

# Generated at 2022-06-22 03:57:54.733915
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.options = object
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = "test"
    tornado.options.options.log_file_num_backups = "test"
    tornado.options.options.log_to_stderr = "test"
    logger = logging.getLogger()
    enable_pretty_logging(tornado.options.options, logger)
    logger.setLevel(getattr(logging, tornado.options.options.logging.upper()))
    assert logger.level == logging.DEBUG
    assert logger.filters == []
   

# Generated at 2022-06-22 03:58:01.239217
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    level = logging.DEBUG
    message = "Test Message"
    formatter = LogFormatter()
    class FakeRecord:
        __dict__ = {'levelno': 10, 'getMessage': lambda : message}
        def __init__(self, levelno: int, getMessage: Any) -> None:
            pass
    record = FakeRecord(10, lambda : message)
    assert formatter.format(record) == "[DEBUG test_log.py:0] Test Message"

# Generated at 2022-06-22 03:58:12.832476
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    from tornado import testing
    from tornado.log import gen_log
    from tornado.testing import LogTrapTestCase

    class EnablePrettyLoggingTest(LogTrapTestCase):
        def setUp(self):
            super().setUp()
            # reset logging state that may have been set by other tests
            tornado.options.define("logging", None, type=str)
            self.stderr = sys.stderr
            sys.stderr = open("/dev/null", "w")

        def tearDown(self):
            sys.stderr = self.stderr
            super().tearDown()

        def test_default(self):
            tornado.options.define("log_file_prefix", "test.log")
            fh = logging.FileHandler("test.log")
            self

# Generated at 2022-06-22 03:58:26.681270
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado
    tornado.options.parse_command_line(final=False)
    import os
    import time
    import random
    path_prefix = "/tmp/test.log"
    if os.path.exists(path_prefix):
        os.remove(path_prefix)
    if os.path.exists(path_prefix + ".1"):
        os.remove(path_prefix + ".1")
    gen_log.error("hello")
    gen_log.error("hello")
    gen_log.error("hello")
    gen_log.error("hello")
    gen_log.error("hello")
    gen_log.error("hello")
    gen_log.error("hello")
    assert os.path.exists(path_prefix)

# Generated at 2022-06-22 03:58:30.373519
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "test",
        logging.INFO,
        None,
        1,
        "hello %r",
        (),
        exc_info=(Exception, Exception("test"), None),
    )
    record.message = "hello %r"
    formatter.format(record)



# Generated at 2022-06-22 03:58:31.979704
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Basic structure of class is verified by other tests
    pass



# Generated at 2022-06-22 03:58:42.944956
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # with color
    logger = logging.getLogger()
    lf = LogFormatter(color=True)
    logger.handlers = [logging.StreamHandler()]
    logger.handlers[0].setFormatter(lf)
    logger.error("test")
    # without color
    logger = logging.getLogger()
    lf = LogFormatter(color=False)
    logger.handlers = [logging.StreamHandler()]
    logger.handlers[0].setFormatter(lf)
    logger.error("test")
if __name__ == '__main__':
    test_LogFormatter_format()
from typing import Callable

import logging
import logging.handlers
import os.path
import time

from tornado.util import ObjectDict

from .log import LogFormatter



# Generated at 2022-06-22 03:59:43.300694
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert isinstance(formatter, LogFormatter)
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert len(formatter._colors) == 0
    assert formatter._normal == ""
    assert formatter.style == "%"



# Generated at 2022-06-22 03:59:46.995284
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.enable_pretty_logging()
    tornado.options.options.log_file_prefix = "log.txt"
    tornado.options.enable_pretty_logging()



# Generated at 2022-06-22 03:59:59.889506
# Unit test for method format of class LogFormatter

# Generated at 2022-06-22 04:00:08.166897
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = 'debug'
    tornado.options.options.log_file_prefix = 'log'
    tornado.options.options.log_rotate_mode = 'size'
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging(tornado.options.options)
    assert logging.getLogger().level == logging.DEBUG

# Generated at 2022-06-22 04:00:17.915898
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    d = {
        "asctime": "2019-05-02 14:29:49,414",
        "color": "",
        "end_color": "",
        "funcName": "<module>",
        "levelname": "INFO",
        "levelno": 20,
        "module": "__main__",
        "message": "Hello, world!",
        "name": "tornado.general",
        "pathname": "__main__.py",
        "process": 25350,
        "processName": "MainProcess",
        "thread": 140577304843008,
        "threadName": "MainThread"
    }

# Generated at 2022-06-22 04:00:19.724882
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# The interface of this function is not stable and may change without warning
# in future releases.

# Generated at 2022-06-22 04:00:24.305249
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        class A:
            message = "Hello"
            levelno = logging.DEBUG
        LogFormatter().format(A())
    except Exception as e:
        assert False, "Exception=%r" % e
    assert True


# Generated at 2022-06-22 04:00:35.063124
# Unit test for method format of class LogFormatter

# Generated at 2022-06-22 04:00:36.328292
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    enable_pretty_logging(options)

# Generated at 2022-06-22 04:00:48.818687
# Unit test for function define_logging_options
def test_define_logging_options():
    print('test_define_logging_options ....')
    def my_callback(options: Any = None) -> None:
        if options is None:
            # late import to prevent cycle
            import tornado.options

            options = tornado.options.options
        if options.logging is None or options.logging.lower() == "none":
            print('logging level is none')
            return

    import tornado.options
    opt = tornado.options.OptionParser()
    # 定义日志存储路径
    opt.define("log_file_prefix", type=str, default='./log/testLogs.log', metavar="PATH", help=("Path prefix for log files."))
    # 解析日志存储路径
   

# Generated at 2022-06-22 04:01:50.121313
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = 'DEBUG'
    options.log_file_prefix = "test"
    options.log_to_stderr = False
    options.log_rotate_mode = "size"
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    options.log_file_num_backups = 10
    options.log_file_max_size = 1000
    enable_pretty_logging()

enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:02:01.888037
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = logging.Formatter()
    assert fmt.datefmt == None

    fmt = LogFormatter()
    assert fmt.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    fmt = LogFormatter(datefmt="%Y")
    assert fmt.datefmt == "%Y"

# Use custom LogFormatter to avoid go/pytype/issues/2129
BASIC_FORMAT = "%(color)s%(levelname)s:%(name)s:%(end_color)s %(message)s"

# Generated at 2022-06-22 04:02:10.488174
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    import time
    format_str = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    issue_time = datetime.datetime.fromtimestamp(time.time())
    expected_value = "[I "+issue_time.strftime("%y%m%d %H:%M:%S")+" Logger:1] test message"
    log_formatter = LogFormatter(format_str, "%y%m%d %H:%M:%S", "%", True, {'INFO':2})

# Generated at 2022-06-22 04:02:21.223206
# Unit test for function enable_pretty_logging

# Generated at 2022-06-22 04:02:24.919622
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options=tornado.options                      # type: ignore
    options.define("logging", type=str, default=None)

    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-22 04:02:26.485403
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)

# Generated at 2022-06-22 04:02:37.999633
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    logger = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(LogFormatter())
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.debug("test debug")
    logger.info("test info")
    logger.warning("test warning")
    logger.error("test error")
    logger.critical("test critical")
    handler.close()



# Generated at 2022-06-22 04:02:39.133556
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 04:02:40.802105
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter()


# Generated at 2022-06-22 04:02:48.973756
# Unit test for function define_logging_options
def test_define_logging_options():
    try:
        # late import to prevent cycle
        import tornado.options
    except ImportError:
        return
    options = tornado.options.options
    # Ensure that an OptionParser with default options accepts the logging flags.
    define_logging_options(options)
    tornado.options.parse_command_line([])
    # Ensure that an OptionParser with custom options accepts the logging flags.
    options = tornado.options.define("test_opt", default=1)
    define_logging_options(options)
    tornado.options.parse_command_line(["--test_opt", "2"])