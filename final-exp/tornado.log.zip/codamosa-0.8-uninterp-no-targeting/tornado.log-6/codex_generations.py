

# Generated at 2022-06-22 03:53:41.582329
# Unit test for function define_logging_options
def test_define_logging_options():
    pass

# Generated at 2022-06-22 03:53:53.769764
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        logger = logging.getLogger("SimpleLogger")
        logger.setLevel(logging.DEBUG)
        print("logger.setLevel(logging.DEBUG)")

        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.DEBUG)
        print("ch.setLevel(logging.DEBUG)")

        formatter = LogFormatter()
        ch.setFormatter(formatter)
        logger.addHandler(ch)

        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warn message")
        logger.error("error message")
        logger.critical("critical message")

    except (KeyboardInterrupt, SystemExit):
        raise
    except Exception as e:
        print("exception: {}".format(e))

# Unit

# Generated at 2022-06-22 03:54:06.657063
# Unit test for method format of class LogFormatter
def test_LogFormatter_format(): # pragma: no cover
    import unittest
    import tornado.log
    import logging

    class LogFormatterTest(unittest.TestCase):
        def test_format(self):
            record = logging.makeLogRecord(
                {
                    'name': 'tornado.general',
                    'level': logging.INFO,
                    'pathname': 'test.py',
                    'lineno': 42,
                    'msg': 'test message',
                    'args': (),
                    'exc_info': None,
                    'func': 'test_function',
                }
            )
            formatter = tornado.log.LogFormatter()
            output = formatter.format(record)
            self.assertTrue(output.startswith('[I'), output)
            self.assertTrue(output.endswith('test message'), output)
           

# Generated at 2022-06-22 03:54:15.888919
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)
    parser.parse_command_line()
    assert parser.options.logging == "info"
    assert parser.options.log_file_max_size == 100 * 1000 * 1000
    assert parser.options.log_rotate_mode == "size"
    assert parser.options.log_rotate_interval == 1
    assert parser.options.log_file_num_backups == 10
    assert parser.options.log_rotate_when == "midnight"
    assert parser.options.log_to_stderr == None

# Generated at 2022-06-22 03:54:21.840342
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter = LogFormatter("%(message)s")
    formatter = LogFormatter("%(message)s", "%Y-%m-%d")
    formatter = LogFormatter("%(message)s", "%Y-%m-%d", color=True)



# Generated at 2022-06-22 03:54:34.305845
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from nose import SkipTest
    from logging import StreamHandler
    from tempfile import TemporaryFile
    try:
        from curses import tigetstr, tparm, COLORS  # type: ignore
    except ImportError:
        raise SkipTest("curses not available")

    handler = StreamHandler(TemporaryFile())
    handler.setLevel(0)

    formatter = LogFormatter()
    handler.setFormatter(formatter)

    logger = logging.getLogger("tornado.test")
    logger.addHandler(handler)

    msg = "test"
    logger.error(msg)
    logger.warning(msg)
    logger.info(msg)
    logger.debug(msg)

    handler.stream.seek(0)
    res = handler.stream.read()
    handler.stream.close()
    return res


# Generated at 2022-06-22 03:54:34.978820
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass


# Generated at 2022-06-22 03:54:46.515256
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # unit tests for LogFormatter.format function
    # 1. test no exceptions in record.message
    logger = LogFormatter()
    record = logging.LogRecord("name", "level", None, 1, "message", None, None)
    assert logger.format(record) == "[L 10001001] message"
    # 2. test exception in record.message, exc_info=None
    record = logging.LogRecord("name", "level", None, 1, Exception("message"), None, None)

# Generated at 2022-06-22 03:54:59.317807
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, parse_config_file, options
    define("logging", default=None, help="Set the Python log level")
    define("log_to_stderr", default=None, help="Send log output to stderr")
    define("log_file_prefix", default=None, help="Path prefix for log files")
    define("log_file_max_size", default=100 * 1000 * 1000, help="Max size of log files")
    define("log_file_num_backups", default=10, help="Number of log files to keep")
    define("log_rotate_when", default="midnight", help="specify the type of TimedRotatingFileHandler interval")
    define("log_rotate_interval", default=1, help="The interval value of timed rotating")

# Generated at 2022-06-22 03:55:07.103635
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert '\033[0m' == LogFormatter()._normal
    assert LogFormatter()._datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT
    assert LogFormatter(datefmt='abc', fmt='123')._datefmt == 'abc'
    assert LogFormatter(datefmt='abc', fmt='123')._fmt == '123'
    assert LogFormatter(color=False)._normal == ''



# Generated at 2022-06-22 03:55:30.945902
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("log_file_prefix", type=str, default=None)
    define("logging", type=str, default=None)
    define("log_rotate_mode", type=str, default=None)
    define("log_to_stderr", type=bool, default=None)
    define("log_rotate_when", type=str, default=None)
    define("log_rotate_interval", type=int, default=None)
    define("log_file_max_size", type=int, default=None)
    define("log_file_num_backups", type=int, default=None)
    # TODO: The unit test for enable_pretty_logging module fails when the
    #       enable_pretty_logging function is invoked from
    #      

# Generated at 2022-06-22 03:55:42.954245
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("log_file_prefix", type=str, default="test")
    tornado.options.define(
        "log_file_max_size", type=int, default=1024 * 1024 * 1024 * 1
    )
    tornado.options.define("log_file_num_backups", type=int, default=10)
    tornado.options.define("log_rotate_mode", type=str, default="size")
    tornado.options.define("log_rotate_when", type=str, default="D")
    tornado.options.define("log_rotate_interval", type=int, default=1)
    tornado.options.define("logging", type=str, default="debug")

# Generated at 2022-06-22 03:55:53.700073
# Unit test for function define_logging_options
def test_define_logging_options():
    options.define("logging", default="info", help="test", metavar="debug|info|warning|error|none")
    options.define("log_to_stderr", type=bool, default=True, help="test")
    options.define("log_file_prefix", type=str, default=None, metavar="PATH", help="test")
    options.define("log_file_max_size", type=int, default=100 * 1000 * 1000, help="test")
    options.define("log_file_num_backups", type=int, default=10, help="test")
    options.define("log_rotate_when", type=str, default="midnight", help="test")
    options.define("log_rotate_interval", type=int, default=1, help="test")

# Generated at 2022-06-22 03:55:54.370642
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass

# Generated at 2022-06-22 03:56:01.843670
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=False)
    
    # from function _safe_unicode
    assert _safe_unicode("s") == "s"
    assert _safe_unicode(b"s") == "'s'"
    assert _safe_unicode(b"\xf3") == "'\xf3'"
    
    # test of method format of class LogFormatter 
    record = type('record', (object,), {"__dict__": {"message": "s"}})
    assert formatter.format(record) == 's'



# Generated at 2022-06-22 03:56:13.927101
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.testing
    from tornado.options import define, options

    define("logging", default=None)
    define("log_file_prefix", default="")
    define("log_to_stderr", default=None)
    define("log_rotate_mode", default="size")
    define("log_file_max_size", default=1024 * 1024 * 10)
    define("log_file_num_backups", default=10)
    define("log_rotate_when", default="midnight")
    define("log_rotate_interval", default=1)

    class TestLogging(tornado.testing.AsyncTestCase):

        def test_log_file_prefix_without_rotate_mode(self):
            options.log_file_prefix = "test"


# Generated at 2022-06-22 03:56:24.226898
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.web

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    def make_app():
        return tornado.web.Application([(r"/", MainHandler)])

    app = make_app()
    server = app.listen(0)
    client = tornado.httpclient.HTTPClient()
    client.fetch(
        "http://127.0.0.1:{}/".format(server.address[1]),
        raise_error=False,
        validate_cert=False,
    )
    client.close()
    server.stop()
    server.close()



# Generated at 2022-06-22 03:56:37.042255
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    from io import StringIO
    from unittest.mock import Mock
    formatter = LogFormatter()
    log_record = Mock()
    log_record.name = 'test_log'
    log_record.msg = 'test_msg'
    log_record.args = []
    log_record.levelname = 'DEBUG'
    log_record.levelno = logging.DEBUG
    log_record.pathname = '/path/to/log'
    log_record.filename = '/path/to/log'
    log_record.module = '__main__'
    log_record.lineno = 1000
    log_record.funcName = 'test_function'
    log_record.created = datetime(2020,1,1,1,0,0)
    log_record.m

# Generated at 2022-06-22 03:56:44.886521
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.log import access_log, app_log, gen_log

    class Options(object):
        log_file_prefix = None
        log_file_max_size = 100000000
        log_file_num_backups = 10
        log_rotate_mode = "size"
        log_rotate_when = "S"
        log_rotate_interval = 1
        log_to_stderr = False
        logging = "debug"

    options = Options()

    logging.getLogger().handlers = []
    access_log.handlers = []
    app_log.handlers = []
    gen_log.handlers = []

    # test that log_file_prefix is handled properly
    options.log_file_prefix = "/path/to/log/file"
    enable

# Generated at 2022-06-22 03:56:58.008763
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options  
   
    tornado.options.enable_pretty_logging()
    define_logging_options()
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.log_file_max_size = 10
    tornado.options.options.log_rotate_when = "H"
    tornado.options.options.log_rotate_interval = 2
    tornado.options.options.log_to_stderr = true
    tornado.options.options.log_rotate_mode = "time"
    tornado.options.options.log_file_prefix = ""
    tornado.options.options.logging = "warning"
    tornado.options.options.add_parse_callback(lambda: enable_pretty_logging(tornado.options.options))


# Generated at 2022-06-22 03:57:15.090472
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # log_format = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    # import logging
    # logger = logging.getLogger("tornado.access")
    # logger.propagate = False
    # logger.handlers = []
    # ch = logging.StreamHandler()
    # ch.setFormatter(LogFormatter(log_format))
    # logger.addHandler(ch)
    
    # logger.info("Message with INFO level")
    # logger.warning("Message with WARNING level")
    # logger.error("Message with ERROR level")
    # logger.critical("Message with CRITICAL level")

    pass



# Generated at 2022-06-22 03:57:22.614192
# Unit test for function define_logging_options
def test_define_logging_options():
    pass
    #tornado.options.options.define("log_to_stderr", type=bool, default=True, help="")
    #tornado.options.options.define("log_file_prefix", type=str, default=None, metavar="PATH", help="")
    #tornado.options.options.add_parse_callback(lambda: enable_pretty_logging())
    #tornado.options.parse_command_line()
    #gen_log.info("What's the fucking thing?")

# Generated at 2022-06-22 03:57:32.670563
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a stream handler, passing in our custom format string
    stream = logging.StreamHandler(sys.stdout)
    fmt = "%-25s | %-6s | %-50s"
    formatter = LogFormatter(fmt=fmt)
    stream.setFormatter(formatter)
    logger.addHandler(stream)

    # Log something to exercise the formatter
    logger.error('test')
    # We should probably see 'test' printed in the error color and surrounded
    # by square brackets


# Generated at 2022-06-22 03:57:44.976851
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    class MyLog:
        def getMessage(self):
            return "getMessage"
    log = MyLog()
    log.name = "name"
    log.module = "module"
    log.lineno = 1
    log.funcName = "funcName"
    log.created = 1519473031.5669515
    log.msecs = 566.9515
    log.levelname = "levelname"
    log.levelno = 30
    log.message = "message"
    log.asctime = "asctime"
    log.color = "_colors"
    log.end_color = "_normal"
    log.exc_info = None
    log.exc_text = None
    log.stack_info = None
    log.args = {}


# Generated at 2022-06-22 03:57:49.921167
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    formatter = LogFormatter(color=True, fmt='%(color)s%(levelname)s')
    handler.setFormatter(formatter)
    logger.info('foo')
    logger.debug('bar')
    logger.error('foo')
    logger.warning('bar')
    logger.critical('foo')



# Generated at 2022-06-22 03:57:51.180313
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()

# Generated at 2022-06-22 03:58:01.579862
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.options

    setattr(options, "log_file_prefix", "/tmp/tornado_test.log")
    setattr(options, "log_file_max_size", 1024)
    setattr(options, "log_file_num_backups", 3)
    setattr(options, "logging", "debug")
    setattr(options, "log_rotate_mode", "size")
    setattr(options, "log_rotate_when", "midnight")
    setattr(options, "log_rotate_interval", 1)
    setattr(options, "log_to_stderr", False)

    enable_pretty_logging()

# Generated at 2022-06-22 03:58:04.874802
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    print(options)

# Generated at 2022-06-22 03:58:12.361966
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "logs"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 10
    tornado.options.options.log_file_num_backups = 1
    assert tornado.options.options.log_rotate_mode == "size"
    assert tornado.options.options.log_file_max_size == 10
    assert tornado.options.options.log_file_num_backups == 1
    enable_pretty_logging()

# Generated at 2022-06-22 03:58:14.689712
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_to_stderr = True
    app_log.setLevel(logging.DEBUG)
    enable_pretty_logging(options)
    app_log.debug("Hello, world!")

# Generated at 2022-06-22 03:58:35.346637
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)

    from logging import LogRecord
    record = LogRecord("", 1, "test_LogFormatter_format", 1, "hello world!", (), None)
    assert isinstance(record, LogRecord)

    assert isinstance(formatter.format(record), str)



# Generated at 2022-06-22 03:58:44.417096
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    # arrange
    class Record:
        # Python 3 bytes is not a subtype of str.
        message = b"\xe6\xba\x90\xe4\xbb\xa3\xe4\xbb\xbb\xe5\x8a\xa1"
        levelno = logging.INFO
        record_dict = {
            "message": message,
            "levelno": levelno,
            "asctime": "123456"
        }

    record = Record()
    formatter = LogFormatter()

    # act
    result = formatter.format(record)

    # assert
    assert result == "[I 123456 <module>: 0] 源代任务"



# Generated at 2022-06-22 03:58:50.764952
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options, parse_config_file
    op = OptionParser()
    define_logging_options(op)
    parse_config_file("test", "logging=info")
    enable_pretty_logging(options)
    gen_log.info("test_enable_pretty_logging")

# Generated at 2022-06-22 03:58:52.855328
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f.datefmt == LogFormatter.DEFAULT_DATE_FORMAT



# Generated at 2022-06-22 03:58:59.400500
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    tester = LogFormatter()
    class LogRecord:
        def __init__(self, message, levelno, exc_info):
            self.message = message
            self.levelno = levelno
            self.exc_info = exc_info
    record1 = LogRecord("This is a log message", logging.DEBUG, None)
    record2 = LogRecord("Exception occurs", logging.ERROR, Exception("MyError"))
    print("record1:")
    print(tester.format(record1))
    print("record2:")
    print(tester.format(record2))

if __name__ == "__main__":
    test_LogFormatter_format()

# Generated at 2022-06-22 03:59:10.457596
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """mock the method of format and test it"""
    mock_self = UnittestMockLogFormatter()
    mock_record = UnittestMockLogRecord()

    mock_self._colors = {30: 40}
    mock_self._normal = 'normal'
    mock_record.levelno = 30
    mock_record.message = 'message'
    mock_record.asctime = 'asctime'
    mock_record.exc_info = 'exc_info'
    mock_record.exc_text = 'exc_text'

    res = mock_self.format(mock_record)
    assert res == '[W asctime :] message'

# Mock object for unittest

# Generated at 2022-06-22 03:59:12.196773
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()



# Generated at 2022-06-22 03:59:25.153145
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert isinstance(log_formatter, logging.Formatter)

if curses is None:
    log_colors = {}  # type: Dict[int, str]

# Generated at 2022-06-22 03:59:33.866078
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    # Assume that datefmt == "" has same behavior as not passing a datefmt arg
    formatter = LogFormatter(datefmt="")
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    # Check that passing a custom datefmt arg works
    formatter = LogFormatter(datefmt="%d %b %Y %H:%M:%S")
    assert formatter.datefmt == "%d %b %Y %H:%M:%S"



# Generated at 2022-06-22 03:59:46.807506
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("logging", type=str, help=("Set the Python log level."), metavar="debug|info|warning|error|none")
    parse_command_line(args=[])
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 04:00:22.801023
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    import logging
    import logging.handlers
    record = logging.LogRecord(
        "test_logger",
        logging.INFO,
        None,
        None,
        "test_message",
        None,
        None)
    assert formatter.format(record)

# Generated at 2022-06-22 04:00:35.288160
# Unit test for method format of class LogFormatter

# Generated at 2022-06-22 04:00:35.859070
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-22 04:00:48.259967
# Unit test for function define_logging_options
def test_define_logging_options():
    class Option():
        def __init__(self, item: str, value: Any) -> None:
            self.name = item
            self.value = value
            self.options = None
            self.option_dict = {}

        def define(
            self,
            name: str,
            default: Any,
            help: str,
            metavar: str = None,
            type: Any = None,
        ) -> None:
            self.options[name] = [default, help, metavar, type]
            self.option_dict[name] = default

        def add_parse_callback(self, f: Any) -> None:
            f()

    tornado.options.options = Option("logging", "info")
    define_logging_options(tornado.options.options)

# Generated at 2022-06-22 04:00:50.577582
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    logging.info("info_test")

# Generated at 2022-06-22 04:00:56.826885
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(name="test_name", level=0, pathname="", lineno=0, msg="message", args=None, exc_info=None)
    record.asctime = "asctime"
    record.exc_text = "exc_text"
    result = log_formatter.format(record)
    assert result == "[D asctime :0] message\n    exc_text"


# Generated at 2022-06-22 04:01:09.684678
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Record:
        message: str
        asctime: str
        color: str
        end_color: str
        exc_text: str

        def __init__(self, message: str) -> None:
            self.message = message
            self.asctime = "foo"
            self.color = "bar"
            self.end_color = "baz"
            self.exc_text = ""

    import logging
    import logging.handlers

    _bytes_stream = logging.handlers.MemoryHandler(100, target=logging.StreamHandler())
    _unicode_stream = logging.StreamHandler()
    _safe_unicode = lambda s: s.decode("ascii")
    formatter = LogFormatter()
    r = Record("foo")

# Generated at 2022-06-22 04:01:11.857178
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
    print(options)

# Generated at 2022-06-22 04:01:12.959350
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 04:01:24.876125
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    log_formatter = LogFormatter()
    record = logging.LogRecord("tornado.access", logging.INFO, "foo", 0, "test", [], None)
    log_formatter.format(record)

# Generated at 2022-06-22 04:02:49.617563
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("logging", type=str)
    tornado.options.define("log_to_stderr", type=bool)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_rotate_interval", type=int)
    logger = logging.getLogger()
    options = tornado.options.options
    options.log_file_prefix = "size"
    options.log_rotate_mode

# Generated at 2022-06-22 04:02:55.468243
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Install the custom log formatter at startup to ensure that it is always in use.
# It's important to do this early so that any Tornado-level log messages that
# happen before the caller has a chance to configure logging are still
# properly formatted.
_default_log_formatter = LogFormatter()
logging.root.handlers[0].setFormatter(_default_log_formatter)
del _default_log_formatter


# Generated at 2022-06-22 04:02:59.375904
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter(color=True)
    assert isinstance(formatter._colors, dict)
    assert isinstance(formatter._fmt, str)
    assert isinstance(formatter.datefmt, str)



# Generated at 2022-06-22 04:03:10.768070
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    from tornado.options import define
    define('logging', default='debug', metavar='DEBUG|INFO|WARNING|ERROR|CRITICAL',
            help='Set the Python log level')
    define('logging_conf', default=None, metavar='FILENAME',
            help='Python logging configuration file')
    define('log_to_stderr', type=bool, default=None, metavar='BOOL',
            help='Send log output to stderr (colorized if possible). '
            'Set to false to suppress all log output.')

# Generated at 2022-06-22 04:03:18.954299
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
  # verify default format
  fmt = LogFormatter.DEFAULT_FORMAT
  tmpl = [msg.strip() for msg in fmt.split('%(message)s')]
  # get color code
  ctxt = LogFormatter._colors[logging.INFO]
  # build log message
  msg1 = [tmpl[0], ctxt, tmpl[1], 'test msg', LogFormatter._normal, tmpl[2]]
  # build log message with exception
  msg2 = [tmpl[0], ctxt, tmpl[1], 'test msg', LogFormatter._normal, tmpl[2]]
  # build exception message
  exc_lines = ['test exception', 'test exception']
  # verify message format