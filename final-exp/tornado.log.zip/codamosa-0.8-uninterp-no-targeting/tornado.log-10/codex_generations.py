

# Generated at 2022-06-22 03:53:37.186312
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert True

# Generated at 2022-06-22 03:53:44.183489
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    from tornado_test.test_logging import assert_logs
    from tornado.util import ObjectDict
    import logging
    logger = logging.getLogger()
    def default_options():
        options.logging="none"
        options.log_file_prefix=""
        options.log_rotate_mode=""
        options.log_file_max_size=0
        options.log_file_num_backups=0
        options.log_rotate_when=""
        options.log_rotate_interval=0
        options.log_to_stderr=False
    default_options()
    enable_pretty_logging()
    logger.setLevel(logging.CRITICAL)
    logger.setLevel(logging.ERROR)

# Generated at 2022-06-22 03:53:53.401973
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # case 1: color support is not on
    logFormatterInstance = LogFormatter()
    class obj:
        pass
    record = obj()
    record.levelno = 10
    record.exc_info = Message("error")
    record.message = Message("Info")
    assert logFormatterInstance.format(record) == "[L 10 - error: Info]"
    # case 2: color support is on
    logFormatterInstance = LogFormatter(color = True)
    assert logFormatterInstance.format(record) == "\x1b[2;36m[L 10 - error: Info]\x1b[0m"

# Generated at 2022-06-22 03:54:02.964810
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
    except:
        pass
    else:
        from tornado.options import options
        options.logging = 'none'
        enable_pretty_logging(options)
        assert type(options) == tornado.options.OptionParser
        assert options.logging == 'none'

        options = None
        enable_pretty_logging(options)
        assert options == None

        logger = logging.getLogger()
        enable_pretty_logging(options, logger)
        assert type(logger) == logging.Logger
# Unit Testing End



# Generated at 2022-06-22 03:54:03.605367
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert True


# Generated at 2022-06-22 03:54:10.947184
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.options
    define_logging_options(options)
    assert(options.logging == "info")
    assert(options.log_to_stderr == None)
    assert(options.log_file_prefix == None)
    assert(options.log_file_max_size == 100 * 1000 * 1000)
    assert(options.log_file_num_backups == 10)
    assert(options.log_rotate_when == "midnight")
    assert(options.log_rotate_interval == 1)
    assert(options.log_rotate_mode == "size")


# Generated at 2022-06-22 03:54:16.626493
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmtr = LogFormatter()
    # type: Any
    assert fmtr.datefmt == fmtr.DEFAULT_DATE_FORMAT
    assert fmtr._colors == fmtr.DEFAULT_COLORS
    assert fmtr._normal == ("" if _stderr_supports_color() else "")
    assert fmtr._fmt == fmtr.DEFAULT_FORMAT


# Generated at 2022-06-22 03:54:29.809748
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # make sure that we can change the format
    formatter = LogFormatter(color=False, fmt='%(message)s')
    record = logging.LogRecord('tornado.test', logging.INFO, 'foo.py', 42,
                               'Hello, %s', ('World',), None)
    assert formatter.format(record).strip() == 'Hello, World'
    # make sure that color works
    formatter = LogFormatter(color=True, fmt='%(message)s')
    record = logging.LogRecord('tornado.test', logging.INFO, 'foo.py', 42,
                               'Hello, %s', ('World',), None)
    assert formatter.format(record).strip() == '\x1b[0mHello, World\x1b[0m'
    # make sure that we can change

# Generated at 2022-06-22 03:54:36.096837
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import os
    formatter = LogFormatter()
    logRecord = logging.LogRecord("test", logging.DEBUG, os.path.abspath(__file__), 10, "test %s", ("test",) , None, "test")
    formatter.format(logRecord)
    assert logRecord.message == _safe_unicode("test test")
    assert logRecord.asctime


# Generated at 2022-06-22 03:54:40.840089
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    stream = logging.StreamHandler()
    formatter = LogFormatter(color = True, colors = {})
    stream.setFormatter(formatter)

# end unit test for constructor of class LogFormatter



# Generated at 2022-06-22 03:54:57.393266
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logf = LogFormatter()
    assert logf._fmt == LogFormatter.DEFAULT_FORMAT
    assert logf._colors == LogFormatter.DEFAULT_COLORS

# test_LogFormatter()



# Generated at 2022-06-22 03:55:03.684234
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import pytest
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == LogFormatter.DEFAULT_COLORS
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT

    with pytest.raises(TypeError):
        LogFormatter(color="orange")


# Generated at 2022-06-22 03:55:12.115045
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    l = LogFormatter(fmt=fmt)
    class Record:
        def __getattr__(self, name):
            return lambda: None
        def __init__(self):
            self.asctime = "Jun 24 11:11:11"
            self.levelname = "INFO"
    record = Record()
    assert l.format(record) == "[Jun 24 11:11:11] INFO"


# Generated at 2022-06-22 03:55:15.494213
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter = LogFormatter(fmt="%(message)s", datefmt="%H:%M:%S")

# Generated at 2022-06-22 03:55:17.782275
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

__all__ = ["access_log", "app_log", "gen_log", "enable_pretty_logging"]

# Generated at 2022-06-22 03:55:31.091394
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, parse_command_line
    # Test of the function
    define('log_file_prefix', default='test.log')
    define('log_rotate_mode', default='size', help='The mode of rotating file')
    define('log_file_max_size', default='10240000', help='max size of log files before rollover')
    define('log_file_num_backups', default='10', help='number of log files to keep')
    define('log_rotate_when', default='midnight', help='specify the type of TimedRotatingFileHandler interval')
    define('log_rotate_interval', default='1', help='The interval value of timed rotating')
    enable_pretty_logging()

    # Test of the 'when'

# Generated at 2022-06-22 03:55:32.263474
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-22 03:55:34.226083
# Unit test for function define_logging_options
def test_define_logging_options():
    """Unit test for function define_logging_options."""
    define_logging_options()

# Generated at 2022-06-22 03:55:44.363668
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    >>> lf = LogFormatter(color=False)
    >>> lf.format(logging.LogRecord(__name__, logging.ERROR, None, 30, "c%d", (0xFF,), None))
    '[E 0122141421.87 test_log:30] c255'
    """

#
# If a handler does not require a special format, we use a
# specific formatter for this handler.
#
_DEFAULT_FORMATTER = LogFormatter()

SYSLOG_TAG = "tornado"
SYSLOG_FACILITY = logging.handlers.SysLogHandler.LOG_USER



# Generated at 2022-06-22 03:55:48.441058
# Unit test for function define_logging_options
def test_define_logging_options():
    class Options():
        def __init__(self):
            self.logging = 'info'
            self.log_to_stderr = None
            self.log_file_prefix = None
            self.log_file_max_size = 100 * 1000 * 1000
            self.log_file_num_backups = 10
            self.log_rotate_when = 'midnight'
            self.log_rotate_interval = 1
            self.log_rotate_mode = 'size'
            self.add_parse_callback = None
            self.parse_config_file = None

        def define(self, *args, **kwargs):
            pass
    options = Options()
    define_logging_options(options)
    print(options.logging)

test_define_logging_options()

# Generated at 2022-06-22 03:56:39.795934
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.log import app_log, access_log, gen_log
    old_app_log_level = app_log.level
    old_access_log_level = access_log.level
    old_gen_log_level = gen_log.level
    tornado.options.options.log_to_stderr = False
    tornado.options.options.log_file_prefix = ''
    tornado.options.options.log_rotate_mode = 'time'
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_max_size = 5
    tornado.options.options.log_file_num_backups = 5
    tornado.options.options.logging = 'debug'
    enable_pretty_logging()

# Generated at 2022-06-22 03:56:41.922716
# Unit test for function define_logging_options
def test_define_logging_options():
    # make sure it does not fail with None
    define_logging_options(None)
    


# Generated at 2022-06-22 03:56:43.112699
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)

# Generated at 2022-06-22 03:56:48.313607
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG,
        format='[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s' # noqa: E501
    )



# Generated at 2022-06-22 03:57:00.980901
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging

    tornado.options.define_logging_options()
    # with test
    options = tornado.options.options
    options.logging = "error"
    options.log_file_prefix = "abc"
    options.log_to_stderr = False
    options.log_file_max_size = 10
    options.log_file_num_backups = 2
    options.log_rotate_when = "midnight"
    options.log_rotate_interval = 1
    options.parse_command_line()
    output = logging.getLogger().handlers[0].stream.stream.name
    assert output == "abc"
    # without test
    options = tornado.options.options
    options.logging = "error"

# Generated at 2022-06-22 03:57:02.569807
# Unit test for function define_logging_options
def test_define_logging_options():
    options = None
    define_logging_options(options)

# Generated at 2022-06-22 03:57:14.077510
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("logging",default="info",help=("Set the Python log level."),metavar="debug|info|warning|error|none",)
    define("log_to_stderr",type=bool,default=None,help=("Send log output to stderr (colorized if possible). By default use stderr if --log_file_prefix is not set and no other logging is configured."),)
    define("log_file_prefix",type=str,default=None,metavar="PATH",help=("Path prefix for log files. Note that if you are running multiple tornado processes, log_file_prefix must be different for each of them (e.g. include the port number)"),)

# Generated at 2022-06-22 03:57:18.280095
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.parse_command_line()
    enable_pretty_logging()


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:57:26.759490
# Unit test for function define_logging_options
def test_define_logging_options():
    opts = define_logging_options()
    assert opts.logging == 'info'
    assert opts.log_to_stderr == None
    assert opts.log_file_prefix == None
    assert opts.log_file_max_size == 100000000
    assert opts.log_file_num_backups == 10
    assert opts.log_rotate_when == 'midnight'
    assert opts.log_rotate_interval == 1
    assert opts.log_rotate_mode == 'size'

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 03:57:37.085643
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():  # type: () -> None
    fmt = LogFormatter(color=True, fmt="%(color)s%(levelname)s%(end_color)s %(message)s")

    record = logging.LogRecord("tornado.test", logging.DEBUG, "/fake/path", 22, "foo", (), None)
    assert fmt.format(record) == "DEBUG foo"

    record.levelno = logging.ERROR
    assert fmt.format(record) == "\x1b[2;31mERROR\x1b[0m foo"

    record.exc_info = 1
    assert fmt.format(record) == "\x1b[2;31mERROR\x1b[0m foo"

    record.exc_text = "bar"

# Generated at 2022-06-22 03:58:35.649458
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """Tests LogFormatter constructor
    """
    import io
    import logging
    import logging.handlers
    import tornado
    import tornado.options

    options = tornado.options.options

    test_log_file = io.BytesIO()
    log_handler = logging.StreamHandler(stream=test_log_file)
    log_handler.setFormatter(LogFormatter())
    log_handler.setLevel(logging.DEBUG)
    gen_log.addHandler(log_handler)
    gen_log.setLevel(logging.DEBUG)
    gen_log.propagate = False


# Generated at 2022-06-22 03:58:37.416951
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert "color" in LogFormatter.__init__.__code__.co_varnames
    assert "colors" in LogFormatter.__init__.__code__.co_varnames



# Generated at 2022-06-22 03:58:43.151822
# Unit test for function define_logging_options
def test_define_logging_options():
    # This just tests that it runs. enable_pretty_logging is tested by
    # the test_logging_configurator instead.
    import tornado.options

    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line(["--logging=debug"])


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 03:58:48.517424
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    logging.basicConfig(level=logging.ERROR, format="%(levelname)s: %(message)s")
    logger = logging.getLogger("tornado.application")
    tornado_options = {
        "logging": "debug",
        "log_file_prefix": "./log/tornado.log",
        "log_file_max_size": 1024 * 1024 * 100,
        "log_file_num_backups": 5,
        "log_rotate_mode": "size",
        "log_rotate_when": "S",
        "log_rotate_interval": 1,
        "log_to_stderr": "True",
    }
    tornado.options.parse_config_file(tornado_options)
    enable_pretty_logging

# Generated at 2022-06-22 03:58:54.206477
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "tornado.access",
        logging.DEBUG,
        pathname=None,
        lineno=None,
        msg="test message",
        args=None,
        exc_info=None,
    )
    formatter.format(record)

# end of unit test for method format of class LogFormatter


# Generated at 2022-06-22 03:58:58.637901
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = object()
    options.logging = "info"
    options.log_file_prefix = "test_log.txt"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 100 
    options.log_file_num_backups = 10 
    options.log_to_stderr = False

    enable_pretty_logging(options)


# Generated at 2022-06-22 03:59:11.013238
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None

    formatter = LogFormatter()
    record = logging.makeLogRecord({
        'pathname': 'test.py', 'lineno': 10, 'msg': 'test', 'func': 'test_func',
        'process': 1, 'module': 'testmodule', 'processName': 'testprocess',
        'name': 'testname', 'thread': 1, 'threadName': 'testthread', 'exc_info': None,
        'levelname': 'DEBUG', 'args': [], 'exc_text': None, 'levelno': 10})
    log = formatter.format(record)
    assert log == ('[D %s testmodule:10] test' % (record.asctime))

# Generated at 2022-06-22 03:59:13.909737
# Unit test for function define_logging_options
def test_define_logging_options():
    logging.basicConfig(level=logging.DEBUG)
    define_logging_options()

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 03:59:27.658915
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    class R:
        pass
    r = R()
    r.__dict__ = {}
    r.message = ""
    r.asctime = ""
    r.levelno = 10
    r.color = ""
    r.end_color = ""
    # Empty
    r.__dict__ = {}
    # Empty
    r.message = ""
    r.asctime = f.formatTime(r, cast(str, f.datefmt))
    r.levelno = 10
    r.color = ""
    r.end_color = ""
    f.format(r)
    # Exception
    r.__dict__ = {}
    r.message = ""
    r.asctime = f.formatTime(r, cast(str, f.datefmt))
    r

# Generated at 2022-06-22 03:59:35.213579
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define
    from tornado.options import options
    from tornado.options import parse_command_line
    from tornado.options import parse_config_file
    import tempfile
    import os
    import os.path

    define_logging_options()

    define("test_log_rotate_interval", type=int, default=1)
    define("test_log_rotate_mode", type=str, default="size")


# Generated at 2022-06-22 04:00:09.340310
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    import unittest

    class MyFormatter(LogFormatter):
        fmt = (
            "%(asctime)s %(levelname)s: %(message)s"
            " (%(levelname)s %(message)s %(asctime)s)"
            " {%(asctime)s} {%(levelname)s} {%(message)s}"
            "%(other)s"
        )

    def stringio_handler():
        s = io.StringIO()
        handler = logging.handlers.TextHandler(s)
        handler.setFormatter(MyFormatter())
        return handler

    class LogFormatterTest(unittest.TestCase):
        def test_unicode(self):
            test_unicode = "lol\N{SNOWMAN}"
            # Make

# Generated at 2022-06-22 04:00:10.330538
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): # pragma: no cover
    logFormatter = LogFormatter()

# Generated at 2022-06-22 04:00:19.055702
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter, access_log, gen_log
    import logging
    import logging.handlers
    import sys
    
    # init
    LogFormatter_instance = LogFormatter()
    logger = logging.getLogger('LogFormatter.format')
    logger.propagate = False
    logger.handlers = []
    logger.setLevel(logging.DEBUG)
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(LogFormatter_instance)
    logger.addHandler(console)
    
    # begin test
    logger.debug("begin test")
    try:
        raise Exception("a test exception")
    except:
        gen_log.error("a test exception", exc_info=True)
        access_log.warning("access log test")
    # end test

# Generated at 2022-06-22 04:00:20.367899
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)

# Generated at 2022-06-22 04:00:29.112081
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True, fmt='%(color)s%(message)s')
    record = logging.LogRecord(
        name='foo',
        level=logging.DEBUG,
        pathname='foo.py',
        lineno=3,
        msg='test',
        args=(),
        exc_info=None
    )
    assert '\x1b[34mtest\x1b[0m' == formatter.format(record)


# Generated at 2022-06-22 04:00:34.600319
# Unit test for function define_logging_options
def test_define_logging_options():
    # Imported locally to avoid a cyclic import from
    # `logging.options` to `logging`, and then from `options`
    # to `logging`.
    from tornado.options import define, parse_config_file, parse_command_line, options

    define("logging")
    define("log_to_stderr")
    define("log_file_prefix")
    define("log_file_max_size")
    define("log_file_num_backups")
    define("log_rotate_when")
    define("log_rotate_interval")
    define("log_rotate_mode")
    parse_config_file("./test_logging.conf")
    parse_command_line()

    assert options.logging == "debug"

# Generated at 2022-06-22 04:00:46.792256
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.parse_config_file("test/options_test.conf")
    enable_pretty_logging(tornado.options.options)
    log_file_prefix = tornado.options.options.log_file_prefix
    log_file_max_size = tornado.options.options.log_file_max_size
    log_file_num_backups = tornado.options.options.log_file_num_backups
    log_rotate_mode = tornado.options.options.log_rotate_mode
    log_rotate_when = tornado.options.options.log_rotate_when
    log_rotate_interval = tornado.options.options.log_rotate_interval
    log_to_stderr = tornado.options.options.log_to_stderr


# Generated at 2022-06-22 04:00:50.763124
# Unit test for function define_logging_options
def test_define_logging_options():
    # type: () -> None
    """
    @return: None
    """
    try:
        import tornado.options
    except ImportError:
        return
    tornado.options.parse_command_line()

# Generated at 2022-06-22 04:00:58.148715
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    invalid_fmt = '%(color)s%(levelname)-8s%(end_color)s %(message)s'
    import logging
    import sys
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.INFO)
    formatter = LogFormatter(invalid_fmt)
    console.setFormatter(formatter)
    logger = logging.getLogger('')
    logger.addHandler(console)
    logger.setLevel(logging.INFO)
    logger.info('test')


# Generated at 2022-06-22 04:01:03.181755
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("log_rotate_mode",default=None)
    define("log_rotate_interval",default=None)
    define("log_rotate_when",default=None)
    define("log_file_num_backups",default=None)
    define("log_file_prefix",default=None)
    define("log_to_stderr",default=None)
    define("logging",default=None)
    parse_command_line("--logging=info --log_to_stderr 1 --log_file_prefix ./ --log_file_num_backups 10 --log_file_max_size 1024 --log_rotate_mode size --log_rotate_interval 100 --log_rotate_when S".split())

# Generated at 2022-06-22 04:02:01.394269
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._colors == LogFormatter.DEFAULT_COLORS



# Generated at 2022-06-22 04:02:03.840107
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert formatter._colors == {}
    assert formatter._normal == ""


# Generated at 2022-06-22 04:02:05.714770
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    assert True


# Generated at 2022-06-22 04:02:06.597498
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    '''
    
    '''



# Generated at 2022-06-22 04:02:07.749677
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()
    assert hasattr(options, "logging")

# Generated at 2022-06-22 04:02:11.258415
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    log_formatter = LogFormatter(colors=dict())  # type: ignore
    assert isinstance(log_formatter, LogFormatter)



# Generated at 2022-06-22 04:02:12.487394
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # TEST Constructor
    LogFormatter() # type: ignore



# Generated at 2022-06-22 04:02:13.364618
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_format = LogFormatter()


# Generated at 2022-06-22 04:02:21.712293
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.getLogger().setLevel(logging.DEBUG)
    logger = logging.getLogger('test_LogFormatter')
    fmt = LogFormatter(color=True)
    logger.handlers = []
    loghandler = logging.StreamHandler()
    loghandler.setFormatter(fmt)
    logger.addHandler(loghandler)
    logger.debug('test debug')
    logger.info('test info')
    logger.warning('test warning')
    logger.error('test error')
    logger.critical('test critical')



# Generated at 2022-06-22 04:02:32.582573
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # setup
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    # normal
    LogFormatter(fmt=fmt, datefmt=datefmt, style=style, color=color, colors=colors)

   