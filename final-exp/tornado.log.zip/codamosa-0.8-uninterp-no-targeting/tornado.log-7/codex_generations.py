

# Generated at 2022-06-22 03:53:41.762574
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-22 03:53:53.805666
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    from tornado.log import gen_log
    define("log_file_prefix", default="tornado.log", type=str)
    define("log_rotate_mode", default="size", type=str)
    define("log_file_max_size", default="20", type=int)
    define("log_file_num_backups", default="30", type=int)
    define("log_to_stderr", default=True, type=bool)
    define("logging", default="debug", type=str)
    define("log_rotate_when", default="D", type=str)
    define("log_rotate_interval", default="1", type=int)
    enable_pretty_logging()
    gen_log.debug("internal testing")

# Generated at 2022-06-22 03:54:03.258687
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "test.test_log", logging.INFO, "/path/to/fake/file", 42, "test message",
        None, None
    )
    # The format() method was last modified in PR#890. In order
    # to make sure it doesn't break again, we test the output
    # with the same values as in PR#890.
    assert (
        formatter.format(record)
        == "[I 20170203 22:31:59 test_log:42] test message"
    )



# Generated at 2022-06-22 03:54:07.341185
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import os

    LogFormatter(color=False)
    LogFormatter(color=True)
    LogFormatter(colors={})
    LogFormatter(colors={logging.DEBUG: 1})
    LogFormatter(style="%")



# Generated at 2022-06-22 03:54:17.531166
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.options import options
    options.logging = 'none'

    f = LogFormatter()
    assert f

    # add custom attribute
    setattr(f, 'custom_attribute', 'custom_value')

    # check class attribute
    assert f.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"

    # check custom attribute
    assert hasattr(f, 'custom_attribute')

    # check attribute
    assert hasattr(f, '_colors')
    assert hasattr(f, '_normal')
    assert hasattr(f, '_fmt')



# Generated at 2022-06-22 03:54:23.894475
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import io
    import sys
    sys.stdout = io.StringIO()
    log_record = logging.LogRecord("name", 0, "/", 0, "msg", [], None)
    log_formatter = LogFormatter()
    assert log_formatter.format(log_record) == "[0 1970/01/01 01:00:00 name:0] msg\n"



# Generated at 2022-06-22 03:54:27.651715
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import time
    import unittest
    import logging
    import logging.handlers
    from tornado.log import LogFormatter

    class StreamHandler(logging.StreamHandler):
        def emit(self, record: logging.LogRecord) -> None:
            if record.levelno <= logging.INFO:
                print(self.format(record))
                return
            self._stderr_handler.emit(record)

    class TestLogFormatter(unittest.TestCase):
        def setUp(self) -> None:
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            formatter = LogFormatter()
            handler = StreamHandler()
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)


# Generated at 2022-06-22 03:54:28.145017
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-22 03:54:36.224813
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    t = LogFormatter(datefmt='%y%m%d %H:%M:%S',colors={1:'a'})
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())
    logger.info("hello")
    logger.debug("hello")
    logger.warning("hello")
    logger.error("hello")
    logger.critical("hello")
    return
test_LogFormatter_format()

# Generated at 2022-06-22 03:54:41.815390
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define_logging_options
    define_logging_options()
    # import tornado.options as options
    # opts = options.options
    # print(opts.logging)
# test_define_logging_options()

# Generated at 2022-06-22 03:55:01.141256
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()
    LogFormatter(fmt = '%(levelname)s: %(message)s')
    LogFormatter(fmt = '%(levelname)s: %(message)s', color = False)
    LogFormatter(fmt = '%(levelname)s: %(message)s', color = True)
    LogFormatter(fmt = '%(levelname)s: %(message)s', color = True, colors = LogFormatter.DEFAULT_COLORS)
    LogFormatter(fmt = '%(levelname)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

# Generated at 2022-06-22 03:55:09.537825
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser, options
    op = OptionParser()
    define_logging_options(op)
    op.parse_command_line(["--logging=debug","--log_to_stderr=True","--log_rotate_mode=size","--log_file_prefix=log_file_prefix","--log_file_max_size=100","--log_file_num_backups=10"])
    print(options)

#test_define_logging_options()

# Generated at 2022-06-22 03:55:21.537677
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test LogFormatter constructor
    formatter = LogFormatter()
    assert formatter._colors == {
        10: 0,
        20: 31,
        30: 33,
        40: 91,
        50: 95,
    }
    assert formatter._normal == "\x1b[0m"
    assert formatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert formatter.datefmt == "%y%m%d %H:%M:%S"

    # Test _stderr_supports_color
    assert _stderr_supports_color()



# Generated at 2022-06-22 03:55:25.202933
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    print(options.log_file_num_backups)

# Generated at 2022-06-22 03:55:30.990572
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    )
    log_formatter.format(logging.makeLogRecord({"msg": "test"}))


# Generated at 2022-06-22 03:55:35.654460
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert isinstance(log_formatter._fmt, str)
    assert isinstance(log_formatter._colors, dict)
    assert isinstance(log_formatter._normal, str)
    assert isinstance(log_formatter.datefmt, str)



# Generated at 2022-06-22 03:55:47.602351
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import traceback
    import time
    import threading
    import random

    import tornado.log

    r"""
    This will test LogFormatter.format method which is a more complex
    method within tornado.log

    """
    log_format = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    date_format = "%y%m%d %H:%M:%S"
    colored_logger = tornado.log.LogFormatter(
        fmt=log_format, datefmt="%y%m%d %H:%M:%S"
    )
    uncolored_logger = tornado.log.LogFormatter

# Generated at 2022-06-22 03:55:58.589150
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import io, unittest

    class TestLogger(io.StringIO):
        def __init__(self):
            io.StringIO.__init__(self)
            self.level = logging.DEBUG
            self.logger = self
            self.has_warnings = False

        def warn(self, format, *args):
            self.has_warnings = True
            self.write("WARNING: " + (format % args) + "\n")

        def log(self, level, msg):
            if level >= self.level:
                self.write("%s\n" % msg)

        def _log(self, level, args, kwargs):
            self.emit(level, args, kwargs)


# Generated at 2022-06-22 03:56:09.563211
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    log_file = 'tornado_test.log'
    handler = logging.FileHandler(log_file)
    handler.setLevel(logging.DEBUG)
    formatter = LogFormatter(
        fmt="%(color)s%(levelname)1.1s %(asctime)s %(module)s(%(lineno)d) %(message)s%(end_color)s",
        datefmt="%y%m%d %H:%M:%S")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.info("test")
    logger.debug("can you see the color")
    logger.warning("warning")
    logger.critical("critical")

# Generated at 2022-06-22 03:56:12.136452
# Unit test for function define_logging_options
def test_define_logging_options():
    options = object()
    assert options is not None

test_define_logging_options()

# Generated at 2022-06-22 03:56:23.082821
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    assert lf.format(logging.LogRecord("foo", "DEBUG", None, None, "hello", None, None)) == "[D 000101 00:00:00 foo:0] hello"

# Generated at 2022-06-22 03:56:35.929267
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    from tornado.options import define, parse_command_line
    define("level","1")
    define("logging","info")
    define("log_to_stderr",None)
    define("log_file_prefix","path")
    define("log_file_max_size",100)
    define("log_file_num_backups",10)
    define("log_rotate_when","midnight")
    define("log_rotate_interval",1)
    define("log_rotate_mode","size")
    define_logging_options()
    assert options.log_to_stderr == True
    assert options.level == "1"
    assert options.logging == "info"
    assert options.log_file_prefix == "path"
    assert options.log_

# Generated at 2022-06-22 03:56:43.755182
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"

    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    level_name = "DEBUG"
    level_no = 10
    file_name = "__init__.py"
    line_number = 100
    msg = "log message"


# Generated at 2022-06-22 03:56:53.531517
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import tornado.template
    import logging
    try:
        fmt = tornado.template.Template(
            "{{record.asctime}} {{record.message}} {{record.levelname}}"
        )
        fmt.generate(record={
            "asctime": "2017-12-07 00:00:00",
            "message": "hello",
            "levelname": "info"
        })
    except Exception as e:
        fmt = None
    if not fmt:
        raise RuntimeError("template error")
    LogFormatter(fmt)


# Generated at 2022-06-22 03:56:55.684674
# Unit test for function define_logging_options
def test_define_logging_options():
    # there is no way to execute the main function body
    # the only way is to test the function definition
    return

# Generated at 2022-06-22 03:56:58.822691
# Unit test for function define_logging_options
def test_define_logging_options():
    #import tornado.options
    #options = tornado.options.options
    #options.define(
    #    "logging",
    #    default="info",
    #    help=(
    #        "Set the Python log level. If 'none', tornado won't touch the "
    #        "logging configuration."
    #    ),
    #    metavar="debug|info|warning|error|none",
    #)
    define_logging_options()
    assert(hasattr(options,'logging'))

# Generated at 2022-06-22 03:57:11.285139
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter

    from logging import StreamHandler
    from StringIO import StringIO
    import sys

    class Error(Exception):
        pass

    class TestFormatter(LogFormatter):
        def format(self, record: Any) -> str:
            if record.args == ("test",):
                raise Error("test")
            else:
                return cast(str, super(TestFormatter, self).format(record))

    # Test the unicode hooks by setting one of stderr's encoding
    # attributes to None, to cause a failure in the unicode conversion
    old_stderr = sys.stderr

# Generated at 2022-06-22 03:57:16.913149
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = {'levelname': 'DEBUG', 'asctime': '2020-06-20', 'module': 'abc', 'lineno': 123, 'message': 'hello, world'}
    print(formatter.format(record))
    record = {'levelname': 'ERROR', 'asctime': '2020-06-20', 'module': 'abc', 'lineno': 123, 'message': 'hello, world'}
    print(formatter.format(record))


# Generated at 2022-06-22 03:57:24.518550
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    class arg:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    args = arg(1,2, '07012014 13:19:58', 'tornado.general', 'test', 'hello world')
    args.levelno = logging.CRITICAL
    res = formatter.format(args)  
    assert res == u"\x1b[35m[CR 07012014 13:19:58 tornado.general:test]\x1b[0m hello world"

# Generated at 2022-06-22 03:57:30.643733
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)
    logRecord = logging.LogRecord("tornado.general", logging.INFO, "./log.py", 42, "Test Message", [], "")
    formatted = formatter.format(logRecord)
    assert isinstance(formatted, str)



# Generated at 2022-06-22 03:57:38.865176
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()



# Generated at 2022-06-22 03:57:44.198051
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logFormatter = LogFormatter()
    record = logging.LogRecord("tornado.general", 1, None, 1, "test message", None, None)
    record.exc_info = ("test exception info")
    print(logFormatter.format(record))


# Generated at 2022-06-22 03:57:51.210690
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()

# Install a log formatter for the tornado access_log
access_log.propagate = False
if not access_log.handlers:
    access_log.addHandler(logging.StreamHandler())
access_file_handler = logging.handlers.TimedRotatingFileHandler(
    filename="access.log", when="midnight", backupCount=7, encoding="utf-8"
)
access_log.addHandler(access_file_handler)
test_LogFormatter()
access_log.handlers[0].setFormatter(LogFormatter())
access_file_handler.setFormatter(LogFormatter())

# Install a log formatter for the tornado app_log
app_log.propagate = False

# Generated at 2022-06-22 03:57:53.413784
# Unit test for function define_logging_options
def test_define_logging_options():
    assert(define_logging_options())


# Generated at 2022-06-22 03:58:00.455781
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("logging", default="info", help="Set the Python log level.")
    parse_command_line(args=['--logging=info'])
    options.logging = 'info'
    define_logging_options(options)
    assert options.log_to_stderr == None
    #assert options.logging == None
    #assert options.log_to_stderr == None

# Generated at 2022-06-22 03:58:12.385295
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.logging = "DEBUG"
    options.log_to_stderr = None
    options.log_file_prefix = 'log_file.log'
    options.log_file_max_size = 1024 * 1024 * 1000
    options.log_rotate_mode = 'size'
    options.log_file_num_backups = 5
    options.log_rotate_when = 'D'
    options.log_rotate_interval = 1
    enable_pretty_logging()
    gen_log.info('test enable_pretty_logging')
    app_log.info('test enable_pretty_logging')
    access_log.info('test enable_pretty_logging')

test_enable_pretty_logging()

# Generated at 2022-06-22 03:58:24.127127
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    options.define(
        "log_file_num_backups2", type=int, default=20, help="number of log files to keep"
    )
    # test value
    assert options.log_file_num_backups2 == 20
    # test assign value
    options.log_file_num_backups2 = 30
    assert options.log_file_num_backups2 == 30
    # test delete value
    del options.log_file_num_backups2
    with pytest.raises(AttributeError):
        print(options.log_file_num_backups2)

# Generated at 2022-06-22 03:58:30.240096
# Unit test for function define_logging_options
def test_define_logging_options():
    """
    Function used to unit test function define_logging_options
    """
    try:
        define_logging_options()
        define_logging_options(options=None)
    except Exception:
        # test must fail
        assert False, "Runtime Exception occurred"
    else:
        # test must pass
        assert True, "No Runtime Exception occurred"


# Generated at 2022-06-22 03:58:41.740174
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # test the function
    from tornado.options import define, options
    from io import StringIO


# Generated at 2022-06-22 03:58:43.584043
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
rename_function(test_enable_pretty_logging, "test_enable_pretty_logging")

# Generated at 2022-06-22 03:58:58.543146
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    op = OptionParser()
    define_logging_options(op)
    options = op.parse_command_line(args=['--logging=warning'])
    assert options['logging'] == 'warning'
    assert options['log_file_prefix'] is None
    assert options['log_to_stderr'] is None
    assert options['log_file_max_size'] == 100000000
    assert options['log_file_num_backups'] == 10
    assert options['log_rotate_when'] == 'midnight'
    assert options['log_rotate_interval'] == 1
    assert options['log_rotate_mode'] == 'size'

test_define_logging_options()

# Generated at 2022-06-22 03:59:07.336312
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter(color=False)
    assert f.format(logging.makeLogRecord({"msg": "hello"})) == "hello"
    f = LogFormatter(color=True)
    assert (
        f.format(logging.makeLogRecord({"msg": "hello", "levelno": logging.DEBUG}))
        == "\x1b[2;34mhello\x1b[0m"
    )



# Generated at 2022-06-22 03:59:10.813687
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    print("\ndoing test of LogFormatter")
    fmter = LogFormatter()
    print(fmter._normal)
    print(fmter._colors)
    print(fmter.datefmt)
    print(fmter._fmt)
    print("done test of LogFormatter")



# Generated at 2022-06-22 03:59:21.361454
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test only interesting log formatter constructor cases
    LogFormatter(
        fmt=LogFormatter.DEFAULT_FORMAT,
        datefmt=LogFormatter.DEFAULT_DATE_FORMAT,
        style="%",
        color=True,
        colors=LogFormatter.DEFAULT_COLORS,
    )
    LogFormatter(
        fmt=LogFormatter.DEFAULT_FORMAT,
        datefmt=LogFormatter.DEFAULT_DATE_FORMAT,
        style="%",
        color=False,
        colors=LogFormatter.DEFAULT_COLORS,
    )



# Generated at 2022-06-22 03:59:25.010536
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Read the first line for the log message as a string
    with open("./log/test_enable_pretty_logging.log", "r") as log:
        str_log = log.readline()
    # Check if the log message contains the detected level
    if not str_log.__contains__('DEBUG'):
        raise ValueError("Custom log file is not written")

# Generated at 2022-06-22 03:59:31.380462
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        formatter = LogFormatter()
        record = logging.LogRecord("test", logging.INFO, "/some/path", 42, "test message", [], None)
        formatter.format(record)
    except Exception as e:
        print("LogFormatter does not work, should be fixed", e)
        assert False, "LogFormatter does not work, should be fixed"
    assert True, "LogFormatter works fine"



# Generated at 2022-06-22 03:59:38.231616
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    class Record(object):
        pass
    rec = Record()
    rec.message = "hello"
    rec.levelno = logging.DEBUG
    rec.asctime = ""
    rec.color = ""
    rec.end_color = ""
    assert formatter.format(rec) == "[D hello]", "running the test"
test_LogFormatter_format()


# Generated at 2022-06-22 03:59:49.370283
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from io import StringIO
    import logging
    from tornado import gen
    from tornado.ioloop import IOLoop
    import time

    @gen.coroutine
    def go():
        try:
            raise RuntimeError("crash")
        except:
            logging.exception("uncaught exception")

        yield gen.sleep(0.01)

    io = StringIO()
    log_handler = logging.StreamHandler(io)
    log_handler.setFormatter(LogFormatter())
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(log_handler)

    IOLoop.current().run_sync(go)
    print(io.getvalue())
    # test_LogFormatter_format()



# Generated at 2022-06-22 03:59:53.710662
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import options
    from tornado.log import gen_log
    options.logging = 'debug'
    
    gen_log.debug('Test Debug')
    gen_log.info('Test Info')
    gen_log.warning('Test Warning')
    gen_log.error('Test Error')
    gen_log.critical('Test Critical')

if __name__ == '__main__':
    test_LogFormatter_format()

# Generated at 2022-06-22 04:00:00.321844
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    import datetime
    time = datetime.datetime.now()
    record = logging.LogRecord("name", logging.INFO, "pathname", 1, "msg", None, None)
    record.created = time
    assert log_formatter.format(record)



# Generated at 2022-06-22 04:00:41.493216
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if curses is None:
        raise unittest.SkipTest("curses not found")

    class FakeLogRecord:
        def __init__(self, levelno, msg):
            self.levelno = levelno
            self.msg = msg

        def getMessage(self):
            return self.msg

    formatter = LogFormatter()

# Generated at 2022-06-22 04:00:51.177686
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    for color in [True, False]:
        for exc_info in [None, True]:
            for message in ["test", b"test", "你好"]:
                expected = "test"
                f = LogFormatter(color=color)
                record = logging.LogRecord(
                    "test",
                    level=logging.DEBUG,
                    pathname="test",
                    lineno=1,
                    msg=message,
                    args=[],
                    exc_info=None,
                )
                assert f.format(record) == expected



# Generated at 2022-06-22 04:00:53.183280
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type (Any) -> None
    """Verify that LogFormatter can be instantiated.

    This also serves as a test of `tornado.log.enable_pretty_logging`
    (via `test_log.test_main`).
    """
    LogFormatter()  # type: ignore



# Generated at 2022-06-22 04:00:58.056367
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
        import tornado.log
        import logging
        tornado.options.parse_command_line()
        tornado.log.enable_pretty_logging()
        logging.info("test message")
    except Exception as e:
        print("Error:", e)
    print("done")


# Generated at 2022-06-22 04:00:59.785575
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass


# Generated at 2022-06-22 04:01:01.910846
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_record = logging.LogRecord("name", logging.ERROR, "pathname", 1, "msg", None, None)
    formatter = LogFormatter()
    res = formatter.format(test_record)
    assert res == "[E 170101 00:00:00 <string>:1] msg"



# Generated at 2022-06-22 04:01:03.589950
# Unit test for function define_logging_options
def test_define_logging_options():
    try:
        define_logging_options()
    except:
        raise

# Generated at 2022-06-22 04:01:13.517559
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    rec = logging.LogRecord(
            name="name",
            level=logging.INFO,
            pathname=__file__,
            lineno=12,
            msg='msg',
            args=None,
            exc_info=None)
    rec.__dict__.update({
        'color': '\033[2;3m',
        'end_color': '\033[m'})
    fmt = LogFormatter()
    assert fmt.format(rec) == \
    '\033[2;32m[I 20140218 00:00:00 test_log.py:12]\033[m msg'



# Generated at 2022-06-22 04:01:14.748080
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 04:01:26.208510
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado
    import tornado.options
    import tornado.log
    import tornado.testing
    tornado.options.define("logging", default=None, help="logging configuration")
    tornado.options.define("log_to_stderr", default=None,
                           help="send log output to stderr")
    tornado.options.define("log_file_prefix", default=None,
                           help="Path prefix for log files")
    tornado.options.define("log_rotate_mode", default=None,
                           help="Rotate log mode")
    tornado.options.define("log_rotate_when", default=None,
                           help="Rotate log when")
    tornado.options.define("log_file_max_size", default=None,
                           help="Maximum size of log files before rollover")
    tornado

# Generated at 2022-06-22 04:02:05.238404
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    cast(LogFormatter, LogFormatter())

# Copied from Python 3.2+ standard library.  License: PSF
# See https://github.com/python/cpython/blob/3.2/LICENSE

# Generated at 2022-06-22 04:02:09.927618
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = object
    options.logging = 'warn'
    options.log_file_prefix = 'log_file_prefix'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 10
    options.log_file_num_backups = 3
    options.log_to_stderr = False
    enable_pretty_logging(options)


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:02:21.177107
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    def test(record):
        formatted = formatter.format(record)
        assert isinstance(formatted, str)

    # Smoke test
    test(logging.makeLogRecord(dict(message="")))

    # Record with exc_info
    try:
        raise Exception("boo")
    except Exception:
        test(logging.makeLogRecord(dict(exc_info=True, message="")))

    # Unicode message and unicode exception text
    try:
        raise Exception("\N{SNOWMAN}")
    except Exception:
        test(logging.makeLogRecord(dict(exc_info=True, message="\N{SNOWMAN}")))

    # Non-utf8 bytes message and exception text

# Generated at 2022-06-22 04:02:32.216856
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.log import access_log, app_log, gen_log

    options = tornado.options.options

    logger = logging.getLogger('test_logger')
    options.logging = "none"
    enable_pretty_logging(options,logger)
    assert logger.handlers == []

    options.logging = "debug"
    enable_pretty_logging(options, logger)
    assert logger.handlers == []

    options.log_to_stderr = True
    enable_pretty_logging(options, logger)
    assert logger.handlers != []

    options.log_file_prefix = "test"
    enable_pretty_logging(options, logger)
    assert logger.handlers != []


if __name__ == "__main__":
    test_enable

# Generated at 2022-06-22 04:02:36.526084
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    test_options.options.logging = 'none'
    enable_pretty_logging()
    assert not logging.getLogger().handlers
    test_options.options.logging = 'INFO'
    enable_pretty_logging()
    logging.debug('test1')



# Generated at 2022-06-22 04:02:48.557625
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""


# Generated at 2022-06-22 04:02:49.778042
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=True)
    assert formatter



# Generated at 2022-06-22 04:02:50.597350
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options=None)

# Generated at 2022-06-22 04:02:53.562478
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f._colors
    assert isinstance(f._colors[1], unicode_type)



# Generated at 2022-06-22 04:03:03.864299
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.testing import LogTrapTestCase as LogTrapCase
    from logging import getLogger
    import io

    class FormatTestCase(LogTrapCase):
        def setUp(self):
            LogTrapCase.setUp(self)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            log = getLogger("tornado.test")
            log.propagate = False
            log.setLevel(logging.DEBUG)
            log.addHandler(self.handler)

        def test_format(self):
            log = logging.getLogger("tornado.test")
            log.info("test%rtest")