

# Generated at 2022-06-22 03:53:43.184367
# Unit test for function define_logging_options
def test_define_logging_options():
    pass


define_logging_options()

# Generated at 2022-06-22 03:53:47.878444
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    options.reset()
    define_logging_options(options)
    options.help_func(options.help_struct)

# Generated at 2022-06-22 03:53:50.029671
# Unit test for function define_logging_options
def test_define_logging_options():
    # late import to prevent cycle
    import tornado.options
    define_logging_options(tornado.options.options)


define_logging_options()

# Generated at 2022-06-22 03:54:01.171058
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    import logging
    import time
    # The method format of LogFormatter takes takes a record
    # as input argument.
    # The class Record has many attributes.
    # The method format uses some of them.
    # They are taken as key-value pairs of a dictionary
    # in which the keys are the attribute names.

# Generated at 2022-06-22 03:54:14.058087
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # None of these tests should issue any warnings:
    formatter = LogFormatter()
    formatter = LogFormatter(datefmt="%Y-%m-%d")
    formatter = LogFormatter(colors={logging.DEBUG: 1})
    formatter = LogFormatter(color=False)
    formatter = LogFormatter(fmt="%(message)s")
    formatter = LogFormatter(fmt="%(asctime)s %(message)s", datefmt="%Y-%m-%d")

    # Make sure the LogFormatter constructor does not issue warnings if
    # logging is disabled.  This is important in case a user's code has
    # logging set up but then sets disable_existing_loggers to False.
    # This could lead to warnings being issued when the application
    # starts up

# Generated at 2022-06-22 03:54:27.478020
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import os
    import tornado.options
    import tornado.process
    from tornado.log import enable_pretty_logging

    tornado.options.parse_config_file(os.path.join(os.path.dirname(__file__), "test_logging.conf"))
    assert tornado.options.options.log_file_prefix == os.path.join(os.path.dirname(__file__), "test.log")
    assert tornado.options.options.log_to_stderr == False
    assert tornado.options.options.logging == "error"
    tornado.process.fork_processes(2, max_restarts=0)
    enable_pretty_logging()
    app_log.error("hello")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:54:31.283067
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" 
    assert f.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert f.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, 
                                logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL:5}

# Generated at 2022-06-22 03:54:36.182087
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = None
    tornado.options.options.log_to_stderr = True
    tornado.options.options.logging = None
    logging.basicConfig()
    enable_pretty_logging()
    if __name__ == '__main__':
        test_enable_pretty_logging()

# Generated at 2022-06-22 03:54:44.584691
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    from tornado.testing import AsyncTestCase
    from tornado.log import gen_log

    class TestLogFormatter(AsyncTestCase):  # type: ignore
        def test_strformatting(self):
            # type: () -> None
            o1 = LogFormatter()
            o2 = LogFormatter()
            self.assertEqual(o1, o2)
            self.assertIsInstance(o1, LogFormatter)

    test = TestLogFormatter()
    test.test_strformatting()



# Generated at 2022-06-22 03:54:46.204831
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    define_logging_options(OptionParser())

# Generated at 2022-06-22 03:55:07.354992
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    logFile = "tornado.log"
    tornado.options.options.log_file_prefix = logFile
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 2
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_to_stderr = True
    tornado.options.options.logging = "debug"
    enable_pretty_logging()
    import unittest
    import os

    class TestLogging(unittest.TestCase):
        def test_logs(self):
            gen_log.error("test error")
            gen_log.debug("test debug")
            self.assertTrue(os.path.exists(logFile))


# Generated at 2022-06-22 03:55:09.382780
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()

# Generated at 2022-06-22 03:55:17.021071
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    # --logging=debug
    define("logging", default="debug")
    define("log_file_prefix", default=None)
    define("log_to_stderr", default=False)
    enable_pretty_logging(options)
    # --log_file_prefix=info
    define("logging", None)
    define("log_file_prefix", default="info")
    define("log_to_stderr", default=False)
    enable_pretty_logging(options)

# Generated at 2022-06-22 03:55:20.963091
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    logger = logging.getLogger()
    options.logging = "debug"
    options.log_file_prefix = "test.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 1024
    options.log_file_num_backups = 5
    enable_pretty_logging(options,logger)

if __name__ == "__main__":
    test_enable_pretty_logging()

# vim:ts=4:sw=4:et:

# Generated at 2022-06-22 03:55:27.029179
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    opts = {
        "logging":"warning",
        "log_file_prefix":"file.logging",
        "log_rotate_mode":"size",
        "log_file_max_size":1,
        "log_file_num_backups":1,
        "log_to_stderr":True
    }
    enable_pretty_logging(opts)

# Generated at 2022-06-22 03:55:39.596334
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionError, OptionParser, options
    from tornado.testing import AsyncTestCase, LogTrapTestCase, gen_test
    options.log_to_stderr = None
    test_parser = OptionParser()
    define_logging_options(test_parser)
    try:
        test_parser.parse_command_line(["--logging=invalid"])
    except OptionError:
        pass
    else:
        self.fail("expected OptionError")
    try:
        test_parser.parse_command_line(["--log_file_prefix=foo", "--log_to_stderr"])
    except OptionError:
        pass
    else:
        self.fail("expected OptionError")


# Generated at 2022-06-22 03:55:40.703781
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-22 03:55:51.377422
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    
    try:
        tornado.options.parse_command_line()
    except:
        pass
    print(tornado.options.options)
    # options = tornado.options.options
    # options.define(
    #     "logging",
    #     default="debug",
    #     help=(
    #         "Set the Python log level. If 'none', tornado won't touch the "
    #         "logging configuration."
    #     ),
    #     metavar="debug|info|warning|error|none",
    # )
    # options.define(
    #     "log_to_stderr",
    #     type=bool,
    #     default=None,
    #     help=(
    #         "Send log output to stderr (colorized if possible). "


# Generated at 2022-06-22 03:55:54.682350
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    #assert not hasattr(options, 'logging'), "This unit test need be run alone!"
    define_logging_options(options)

test_define_logging_options()

# Generated at 2022-06-22 03:55:57.188037
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_fmt = LogFormatter()
    handler = logging.StreamHandler()
    handler.setFormatter(log_fmt)



# Generated at 2022-06-22 03:56:20.898956
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None, None)

# Generated at 2022-06-22 03:56:26.655509
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.makeLogRecord(
        {
            "message": "Hello World!",
            "levelno": logging.INFO,
            "asctime": "2020-03-12 21:23:30,333",
        }
    )
    logger = LogFormatter()
    assert logger.format(record) == "[I 2020-03-12 21:23:30,333 <unknown>:0] Hello World!"



# Generated at 2022-06-22 03:56:33.160506
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    s = 'a\nb\nc'
    record = logging.LogRecord(name=None, level=None, pathname=None, lineno=1, msg=s, args=None, exc_info=None)
    r = fmt.format(record)
    assert r == 'a\n    b\n    c'
# /Unit test for method format of class LogFormatter



# Generated at 2022-06-22 03:56:42.547541
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    from tornado.testing import AsyncTestCase, gen_test
    class Test(AsyncTestCase):
        def test_define_logging_options(self):
            options = OptionParser()
            define_logging_options(options)
            options.parse_command_line("--log_rotate_mode=size")
            self.assertEqual("size", options.log_rotate_mode)
            with self.assertRaises(ValueError):
                options.parse_command_line("--log_rotate_mode=test")
    test = Test()
    test.test_define_logging_options()
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 03:56:55.625429
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter(color=True)
    record = logging.LogRecord(
        name="tornado.general",
        level=logging.DEBUG,
        pathname="fake/path",
        lineno=9999,
        msg="test message",
        args=(),
        exc_info=None,
    )
    formatted = fmt.format(record)
    assert formatted == "[D " '\x1b[4;36m%(asctime)s ' "\x1b[0;36mfake/path:9999]\x1b[0m " '\x1b[4;36mtest message\x1b[0m\n    '

    fmt = LogFormatter(color=False)

# Generated at 2022-06-22 03:57:03.892350
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Unit test for method format of class LogFormatter

    import time
    import logging
    import locale

    f = LogFormatter()

    # convert to tuple to be python 3.5 compatible
    record = logging.makeLogRecord(dict(name="foo", level=logging.DEBUG, msg="bar"))
    assert f.format(record) == u"[D %s foo:0] bar" % time.strftime("%y%m%d %H:%M:%S")

    f = LogFormatter(color=False)
    assert f.format(record) == u"[D %s foo:0] bar" % time.strftime("%y%m%d %H:%M:%S")

    f = LogFormatter(color=True)
    record.levelno = logging.WARNING
    assert f.format(record)

# Generated at 2022-06-22 03:57:06.861428
# Unit test for function define_logging_options
def test_define_logging_options():
    fn = define_logging_options
    # Test function can run successfully
    assert fn() is None
    # Test function output match expectation
    # Test function is idempotent


# Generated at 2022-06-22 03:57:17.327332
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import define, options
    import logging

    # tornado.options.define()
    define("logging", default="debug", help=("Set the Python log level. If 'none', tornado won't touch the logging configuration."))
    define("log_to_stderr", type=bool, default=False, help=("Send log output to stderr (colorized if possible)."))
    define("log_file_prefix", type=str, default=None, help=("Path prefix for log files. Note that if you are running multiple tornado processes, log_file_prefix must be different for each of them (e.g. include the port number)."))
    define("log_file_max_size", type=int, default=100 * 1000 * 1000, help=("max size of log files before rollover"))

# Generated at 2022-06-22 03:57:27.187803
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    from tornado.options import OptionParser, define
    from tornado.testing import AsyncTestCase, gen_test

    class FuncTest(AsyncTestCase):
        def setUp(self):
            define("logging", type=str, default="info", help="Set the Python log level")
            define("log_to_stderr", type=bool, default=None, help="Send log output to stderr")
            define("log_file_prefix", type=str, default=None, help="Path prefix for log files")
            define("log_file_max_size", type=int, default=100, help="max size of log files before rollover")
            define("log_file_num_backups", type=int, default=10, help="number of log files to keep")

# Generated at 2022-06-22 03:57:30.026000
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    assert LogFormatter()  # type: ignore



# Generated at 2022-06-22 03:57:49.400638
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    try:
        fmt = LogFormatter()
    except Exception as e:
        assert False, f"LogFormatter() raised exception. {e}"


# Generated at 2022-06-22 03:57:53.412614
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    record = logging.LogRecord("name", 10, "pathname", 11, "msg", (), None)
    result = lf.format(record)
    print(result)



# Generated at 2022-06-22 03:57:55.203196
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)

# Generated at 2022-06-22 03:58:04.814198
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_record = logging.LogRecord('test_logger', logging.INFO, 'test_path', 1, 'test_msg', None, None)
    test_formatter = LogFormatter()
    assert test_formatter.format(test_record) == "[I test_path:1] test_msg"
    test_formatter = LogFormatter(color=False)
    assert test_formatter.format(test_record) == "[I test_path:1] test_msg"
    test_formatter = LogFormatter(color=True)
    assert test_formatter.format(test_record) == "[I test_path:1] test_msg"
    test_formatter = LogFormatter(color=True, colors={logging.INFO: 2, logging.DEBUG: 3, logging.CRITICAL: 5})
    assert test

# Generated at 2022-06-22 03:58:06.686022
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_msg = "testing log formatter"
    app_log.warning(log_msg)



# Generated at 2022-06-22 03:58:10.378686
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print(LogFormatter())
    # Unit test for method format of class LogFormatter
    #Unit test for method format of class LogFormatter

# Generated at 2022-06-22 03:58:22.625089
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import OptionParser, define, options

    define('logging', default='debug', help='Log file name')
    define('log_file_prefix', default='/var/log/tornado/tornado.log', help='Log file name')
    define('log_file_max_size', default=100000, help='max size of log files before rollover')
    define('log_to_stderr', default=False, help='Send log output to stderr (colorized if possible). By default use stderr if --log_file_prefix is not set and no other logging is configured.')
    define('log_file_num_backups', default=10, help='Number of log files to keep')
    define('log_rotate_mode', default='time', help='Log rotate mode')

# Generated at 2022-06-22 03:58:31.497459
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL

    # create logger
    logger = logging.getLogger("test")
    logger.setLevel(DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(DEBUG)

    # create formatter
    formatter = LogFormatter(fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    # 'application' code
    logger.debug("debug message")
    logger.info("info message")
    logger.warn("warn message")
    logger.error("error message")

# Generated at 2022-06-22 03:58:37.190716
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options, tornado.options
    options = tornado.options.options
    options.logging = "info"
    options.log_file_prefix = "test.log"
    options.log_rotate_mode = "size"
    options.log_to_stderr = True
    options.log_file_max_size = 1024
    options.log_file_num_backups = 2
    options.log_rotate_when = "S"
    options.log_rotate_interval = 1
    enable_pretty_logging()
    gen_log.info("test_enable_pretty_logging")

# Generated at 2022-06-22 03:58:46.143629
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # pylint: disable=redefined-outer-name
    # pylint: disable=import-outside-toplevel
    import tornado.options
    import logging.handlers

    def assert_defaults(handler: logging.Handler) -> None:
        f = handler.formatter
        assert isinstance(f, LogFormatter)
        assert f.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
        assert f.format == LogFormatter.DEFAULT_FORMAT
        assert f._colors == LogFormatter.DEFAULT_COLORS
        assert f._normal == ""
        assert len(f._colors) == len(LogFormatter.DEFAULT_COLORS)

    def assert_not_defaults(handler: logging.Handler) -> None:
        f = handler.formatter

# Generated at 2022-06-22 03:59:12.662565
# Unit test for function define_logging_options
def test_define_logging_options():
    logging_options = {
        "logging": "info",
        "log_to_stderr": False,
        "log_file_prefix": "",
        "log_file_max_size": 100 * 1000 * 1000,
        "log_file_num_backups": 10,
        "log_rotate_when": "midnight",
        "log_rotate_interval": 1,
        "log_rotate_mode": "size",
    }
    assert define_logging_options(logging_options) is None
    assert logging_options["logging"] == "info"
    assert logging_options["log_to_stderr"] == False
    assert logging_options["log_file_prefix"] == ""
    assert logging_options["log_file_max_size"] == 100 * 1000 * 1000
   

# Generated at 2022-06-22 03:59:14.360245
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter(fmt=LogFormatter.DEFAULT_FORMAT)

# Generated at 2022-06-22 03:59:20.954512
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "/c/apptest/test_log.py",
        20, "message", None, None)
    assert fmt.format(record) == "[I 20200915 00:00:00 test_log.py:20] message"

# Generated at 2022-06-22 03:59:31.980044
# Unit test for function define_logging_options
def test_define_logging_options():
    class FakeOptionParser():
        def __init__(self):
            self.logging = None
            self.log_to_stderr = None
            self.log_file_prefix = None
            self.log_file_max_size = None
            self.log_file_num_backups = None
            self.log_rotate_when = None
            self.log_rotate_interval = None
            self.log_rotate_mode = None

    opt = FakeOptionParser()
    define_logging_options(opt)
    assert opt.logging == "info"
    assert opt.log_to_stderr is None
    assert opt.log_file_prefix == None
    assert opt.log_file_max_size == 100 * 1000 * 1000

# Generated at 2022-06-22 03:59:44.420516
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    from tornado.options import define, options, parse_command_line
    define("logging", default="debug", help="logging configuration level")
    define("log_file_prefix", default="a.log", help="log file")
    define("log_file_max_size", default=10000, help="log file max size")
    define("log_file_num_backups", default=10, help="num of log file backups")
    define("log_rotate_mode", default="time", help="log rotate mode")
    define("log_rotate_when", default="midnigth", help="log rotate when")
    define("log_rotate_interval", default=1, help="log rotate interval")

# Generated at 2022-06-22 03:59:51.967895
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado
    import tornado.log
    import logging
    logText = "text"
    logger = logging.getLogger("tornado.general")
    logger.setLevel(logging.INFO)
    log_handler = logging.StreamHandler()
    formatter = tornado.log.LogFormatter()
    log_handler.setFormatter(formatter)
    logger.addHandler(log_handler)

    logger.info(logText)
    assert logText in formatter.format(logger)



# Generated at 2022-06-22 04:00:04.116309
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  # 测试使用的参数
  options = dict(
      logging='info',
      log_file_prefix='',
      log_rotate_mode='size',
      log_file_max_size=10,
      log_file_num_backups=10,
      log_to_stderr=None,
      log_rotate_when='S',
      log_rotate_interval=1,
  )
  # 测试函数
  enable_pretty_logging(options)
  # 测试结果
  logger = logging.getLogger()
  assert logger.level == logging.INFO



# Generated at 2022-06-22 04:00:04.847156
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-22 04:00:06.144859
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None

    pass


# Generated at 2022-06-22 04:00:16.932920
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #Test normal case when record.levelno in self._colors
    logger = LogFormatter()
    class TempClass:
        def __init__(self):
            self.msg = 'This is a test message'
            self.levelno = logging.DEBUG
            self.exc_info = None
            self.exc_text = None
            self.asctime = ""
            self.__dict__ = self

        def getMessage(self):
            return self.msg

    record = TempClass()
    expected = "[D " + record.asctime + " <console>:0] " + record.msg + "\n    "
    actual = logger.format(record)
    assert expected == actual

    #Test corruption case when record.levelno in self._colors
    record.getMessage = None

# Generated at 2022-06-22 04:01:28.998170
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import define, options, parse_command_line
    define("logging", default="info")
    parse_command_line()
    formatter = LogFormatter()
    import logging
    logger = logging.getLogger("test-logger")
    logger.info("info")
    record = logger.makeRecord(
        "test",
        logging.INFO,
        "fname",
        3,
        "info",
        None,
        None,
        "funcName",
    )
    record.message = "info"
    record.asctime = "20190222"
    record.color = ""
    record.end_color = ""
    result = formatter.format(record)
    assert result == "[I 20190222 test:3] info"


# Generated at 2022-06-22 04:01:40.677543
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    p = OptionParser()
    define_logging_options(p)
    p.parse_command_line(args=["--logging=warning"])
    p.parse_command_line(args=["--log_to_stderr=True"])
    p.parse_command_line(args=["--log_file_prefix=test"])
    p.parse_command_line(args=["--log_file_num_backups=20"])
    p.parse_command_line(args=["--log_file_max_size=2000"])
    p.parse_command_line(args=["--log_rotate_when=M"])
    p.parse_command_line(args=["--log_rotate_mode=time"])
    p.print_

# Generated at 2022-06-22 04:01:41.969990
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    t=LogFormatter()


# Generated at 2022-06-22 04:01:51.105703
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser

    options = OptionParser()
    for i in [
        "logging","log_to_stderr","log_file_prefix","log_file_max_size","log_file_num_backups"
        ,"log_rotate_when","log_rotate_interval","log_rotate_mode"]:
        assert hasattr(options,i) == False
    define_logging_options(options)
    for i in [
        "logging","log_to_stderr","log_file_prefix","log_file_max_size","log_file_num_backups"
        ,"log_rotate_when","log_rotate_interval","log_rotate_mode"]:
        assert hasattr(options,i) == True
    #options.parse_command_line()

# Generated at 2022-06-22 04:01:55.418211
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    lf = LogFormatter()
    assert isinstance(lf, logging.Formatter)
    assert lf._fmt == LogFormatter.DEFAULT_FORMAT
    assert lf._colors == LogFormatter.DEFAULT_COLORS


# Generated at 2022-06-22 04:01:58.050046
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  print("Executing test")
  logging.info("start")
  logging.debug("debug")
  logging.error("error")

# Generated at 2022-06-22 04:02:01.886264
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("foo", logging.WARNING, "path", 11, "msg", None, None))


# Generated at 2022-06-22 04:02:10.463152
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"

    # noinspection PyTypeChecker
    log_formatter = LogFormatter(
        fmt=fmt,
        datefmt=datefmt,
        style="%",
        color=True,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        },
    )

# Generated at 2022-06-22 04:02:11.940356
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Test if it can be constructed
    LogFormatter()



# Generated at 2022-06-22 04:02:21.093557
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    from tornado.options import define_logging_options
    define_logging_options(None)
    assert options.help_option is not None
    assert options.version_option is not None
    assert options.logging is not None
    assert options.log_to_stderr is not None
    assert options.log_file_prefix is not None
    assert options.log_file_max_size is not None
    assert options.log_file_num_backups is not None
    assert options.log_rotate_when is not None
    assert options.log_rotate_interval is not None
    assert options.log_rotate_mode is not None