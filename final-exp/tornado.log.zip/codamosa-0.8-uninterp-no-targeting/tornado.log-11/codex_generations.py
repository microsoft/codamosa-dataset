

# Generated at 2022-06-22 03:53:39.055103
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    tornado.options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )

test_define_logging_options()

# Generated at 2022-06-22 03:53:45.420263
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    from pathlib import Path
    from tempfile import TemporaryDirectory
    import tempfile
    try:
        from unittest import mock
    except ImportError:
        import mock
    # TODO: better test logging.handlers.RotatingFileHandler and logging.handlers.TimedRotatingFileHandler
    # mock logging.handlers.RotatingFileHandler.__init__
    mock.patch("logging.handlers.RotatingFileHandler.__init__", return_value=None).start()
    mock.patch("logging.handlers.TimedRotatingFileHandler.__init__", return_value=None).start()
    tornado.options.define('logging', default=None, help=None, type=None)

# Generated at 2022-06-22 03:53:49.089399
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: nocover
    formatter = LogFormatter()


    # When passing a dict to the constructor, colorama is ignored.
    formatter = LogFormatter(colors={1: 90})



# Generated at 2022-06-22 03:53:56.541486
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f.default_msec_format == "%s,%03d", f.default_msec_format
    assert f.default_time_format == "%Y-%m-%d %H:%M:%S", f.default_time_format

# Generated at 2022-06-22 03:54:08.938110
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import tornado.escape as escape
    import tornado.options as options
    import tornado.util as util
    # Try to see if the constructor LogFormatter is OK
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = LogFormatter.DEFAULT_COLORS
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt, style=style, color=color, colors=colors)  # noqa: E501
    # The formatter is an object of type LogFormatter,

# Generated at 2022-06-22 03:54:11.935582
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    logging_options = tornado.options.define_logging_options()
    tornado.options.log_to_stderr = True
    tornado.options.log_file_prefix = ""
    tornado.options.logging = "INFO"

# Generated at 2022-06-22 03:54:24.685682
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.testing

    class TestOption(tornado.options.OptionParser):
        pass

    options = TestOption()
    define_logging_options(options)

    # tornado.testing.main prints a warning if argv is not set,
    # so set it to an empty list.
    sys.argv = []


    def test_main():

        define_logging_options()
        # Options initialized on first access
        getattr(tornado.options.options, "logging")

        # Test verbose output
        tornado.options.options.logging = "debug"
        enable_pretty_logging()

        # Test warnings when no output configured
        tornado.options.options.logging = "warning"
        tornado.options.options.log_file_prefix = None
        tornado.options.options

# Generated at 2022-06-22 03:54:36.740154
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.options import options, define, parse_command_line
    import sys
    import os
    import time

    define("log_file", type=str)
    define("log_to_stderr", type=str)
    parse_command_line(['test_LogFormatter.py', '--logging=debug', '--log_to_stderr=True'])

    # Log to a file
    file_path = "/tmp/test_log_file_%d" % time.time()
    options.log_file = file_path
    options.parse_command_line([__file__, '--log_file=%s' % file_path])

    # Test colorama on windows
    if sys.platform == 'win32':
        import colorama
        colorama.init()

    # Test without color


# Generated at 2022-06-22 03:54:42.042226
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.options
    define_logging_options(options)
    options.parse_command_line()
    print(options.logging)

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-22 03:54:52.980758
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, parse_command_line
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.httpclient import AsyncHTTPClient
    from tornado import gen
    from tornado.web import Application, RequestHandler
    from tornado.httpserver import HTTPServer
    import json
    import time
    import os

    try:
        os.unlink("/tmp/debug.log")
    except:
        pass

    define_logging_options(options)

    class HelloHandler(RequestHandler):
        def get(self):
            self.write("hello")

    class LogHandler(RequestHandler):
        def get(self):
            with open("/tmp/debug.log", 'r') as f:
                log = f.read()
            self.write(log)


# Generated at 2022-06-22 03:55:10.223122
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        from io import BytesIO
    except ImportError:
        from tornado.test.io_loop import BytesIO  # type: ignore

    msg = "message"
    record = logging.LogRecord("name", logging.ERROR, "pathname", 1, msg, None, None)
    formatter = LogFormatter()
    formatted_msg = formatter.format(record)
    assert (msg + "\n    ") == formatted_msg
    record.exc_info = 1
    buf = BytesIO()
    try:
        sys.stderr = buf
        formatter.format(record)
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-22 03:55:22.584752
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler, Application

    class FormatterTestHandler(RequestHandler):
        def get(self):
            self.write("ok")

    class TestApplication(Application):
        def __init__(self, *args, **kwargs) -> None:
            super(TestApplication, self).__init__(
                [("/", FormatterTestHandler)], *args, **kwargs
            )

    class LogFormatterTest(AsyncHTTPTestCase):
        def get_app(self) -> TestApplication:
            return TestApplication(debug=True, log_function=app_log.warning)

        def test_format(self) -> None:
            try:
                raise Exception("error")
            except Exception:
                app_log.exception("Test")
            r = self

# Generated at 2022-06-22 03:55:25.842820
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter(datefmt="%Y")

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:55:37.595933
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    def log_record(level: int, msg: Optional[str] = None) -> Any:
        """Simulates a single log record."""
        record = logging.LogRecord("test", level, "/my/path/my/module.py", 42, msg, None, None)
        record.funcName = "__init__"
        return record

    formatter = LogFormatter()
    assert formatter.formatTime(None)
    assert formatter.formatTime(log_record(logging.DEBUG))
    assert formatter.formatTime(log_record(logging.DEBUG, "a"))

    formatter = LogFormatter(fmt="", datefmt="")
    assert formatter.formatTime(log_record(logging.WARNING))
    assert formatter.formatTime(log_record(logging.ERROR))
    assert formatter

# Generated at 2022-06-22 03:55:48.982839
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado
    tornado.options.options = tornado.options.OptionParser()
    define_logging_options(tornado.options.options)
    tornado.options.parse_command_line(['--logging=none', '--log_to_stderr=True', '--log_file_prefix=test.log', '--log_file_max_size=100*1000', '--log_file_num_backups=1', '--log_rotate_when=midnight', '--log_rotate_interval=1', '--log_rotate_mode=size'])
    import tornado.options
    print(tornado.options.options.logging)
    print(tornado.options.options.log_to_stderr)
    print(tornado.options.options.log_file_prefix)
    print

# Generated at 2022-06-22 03:56:00.062479
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    class A:
        def __init__(self):
            self._lines = []
        def info(self, msg):
            self._lines.append(msg)
    a = A()
    globals()['app_log'] = a
    globals()['gen_log'] = a
    globals()['access_log'] = a
    class B:
        def __init__(self):
            self.msg = "hello"
            self.levelno = logging.INFO
    for i in range(3):
        log = a.info
        record = B()
        log(lf.format(record))
    assert record.message == "hello"

# Define the NullHandler and add it to our logging hierarchy
# https://www.loggly.com/blog/python-logging-module

# Generated at 2022-06-22 03:56:08.323186
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options 
    options = tornado.options.options
    define_logging_options(options)
    print(options)
    print(options.logging)
    print(options.log_to_stderr)
    print(options.log_file_prefix)
    print(options.log_file_max_size)
    print(options.log_file_num_backups)
    print(options.log_rotate_when)
    print(options.log_rotate_interval)
    print(options.log_rotate_mode)



# Generated at 2022-06-22 03:56:14.661005
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.formatTime = lambda x, y: 'a_time'
    record = logging.LogRecord("tornado.general", logging.WARNING, "a_path", 10, "message", None, None) # noqa: E501
    result = formatter.format(record)
    assert result == '[W a_time a_path:10] message'



# Generated at 2022-06-22 03:56:17.061464
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    global options
    options = tornado.options.options
    tornado.options.define_logging_options(options)

# Generated at 2022-06-22 03:56:25.371847
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Create a LogFormatter object
    log_formatter = LogFormatter()

    # Create a log record
    record = logging.LogRecord(
        name='tornado.general',
        level=logging.FATAL,
        pathname='/path/to/file.py',
        lineno=3,
        msg='message text',
        args=(),
        exc_info=None
    )

    ## Format the log record for printing
    assert len(log_formatter.format(record)) > 0


# Generated at 2022-06-22 03:56:49.129896
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    import logging
    lg = logging.getLogger()
    lg.setLevel(logging.DEBUG)
    lg.addHandler(logging.StreamHandler())

# Generated at 2022-06-22 03:57:01.773928
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():

    def check_exception_messages(meth, *cases):
        # type: (str, *str) -> None
        """Check the text of exceptions raised by a method.

        The first argument is the method name, the remaining arguments are
        passed to the method and each should throw an exception.  The text
        of the exception is checked to ensure it matches the message passed
        to the method.
        """
        for c in cases:
            try:
                getattr(enable_pretty_logging, meth)(c)
            except Exception as e:
                assert e.args == (c,)

    def setup_mocks(mocks):
        # type: (Dict[str, Any]) -> None
        """Patch the mocks passed in and add the exit code to the opts mock."""

# Generated at 2022-06-22 03:57:02.633937
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass

# Generated at 2022-06-22 03:57:14.115076
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    test_format = "%(asctime)s %(levelname)s [%(threadName)s] %(message)s"
    fmtr = LogFormatter(
        fmt=test_format, color=False, datefmt="%Y-%m-%d %H:%M:%S",
    )
    msg = {
        "asctime": "2019-03-11 10:10:10",
        "levelname": "DEBUG",
        "module": "test_module",
        "lineno": "1001",
        "threadName": "test_thread",
        "message": "test_message",
    }
    assert fmtr.format(msg) == "2019-03-11 10:10:10 DEBUG [test_thread] test_message"



# Generated at 2022-06-22 03:57:21.850623
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #test_message is a string with non-ascii characters
    test_message = "⏳⚽⚽🎆🎇"
    test_record = logging.LogRecord("", logging.INFO, "random_path", -1, test_message, [], None)
    formatter = LogFormatter()
    formatter.format(test_record)
    print("Test 1 passed")

test_LogFormatter_format()


# Generated at 2022-06-22 03:57:32.568892
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    import datetime
    now = datetime.datetime.now()

# Generated at 2022-06-22 03:57:38.060185
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    
    define_logging_options(options)

    options.log_to_stderr = True
    enable_pretty_logging(options)
    options.log_to_stderr = False
    enable_pretty_logging(options)
    
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 03:57:48.914694
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    from tornado.log import access_log, app_log, gen_log, LogFormatter

    def test_log_level():
        class MyHandler(logging.Handler):
            def __init__(self):
                logging.Handler.__init__(self)
                self.records = []  # type: List[logging.LogRecord]

            def emit(self, record):
                self.records.append(record)

        define("logging", type=str)
        define("log_to_stderr", type=bool)
        define("log_file_prefix", type=str)
        define("log_file_max_size", type=int)
        define("log_file_num_backups", type=int)

# Generated at 2022-06-22 03:58:00.924093
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.testing import AsyncTestCase, LogTrapTestCase  
    import tornado.log
    import logging
    import logging.handlers
    logger = logging.getLogger()

    class TestBase(LogTrapTestCase, AsyncTestCase):
        def setUp(self):
            super(TestBase, self).setUp()
            self.io_loop = self.new_ioloop()
            self.addCleanup(self.io_loop.close)
            tornado.log.enable_pretty_logging()

    class Test(TestBase):
        def parse_command_line(self, argv):
            tornado.options.parse_command_line(argv)

        def test_enable_pretty_logging(self):
            self.assertFalse(logger.handlers)

# Generated at 2022-06-22 03:58:12.794998
# Unit test for method format of class LogFormatter

# Generated at 2022-06-22 03:58:22.674288
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    parse_command_line()
    enable_pretty_logging()

# Generated at 2022-06-22 03:58:31.068930
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.__init__(
        fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",  # noqa: E501
        datefmt="%y%m%d %H:%M:%S",
        style="%",
        color=True,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        }
    )



# Generated at 2022-06-22 03:58:34.962554
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter._colors == {}
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT



# Generated at 2022-06-22 03:58:44.886773
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    import datetime
    record = logging.LogRecord(
        name="test", level=logging.DEBUG, pathname="test", lineno=1,
        msg="test message", args=None, exc_info=None,
        func="test", sinfo=None
    )
    record.asctime = datetime.datetime(2003, 8, 4, 12, 53, 40)
    print(lf.format(record))


# Based on PEP-334 and a post by Kent Sibilev, this should support
# non-threaded and multithreaded use of logging.
#
# SafeConfigParser is renamed to ConfigParser in python 3, alias it.
try:
    import ConfigParser as configparser
except ImportError:
    import configparser  # type: ignore



# Generated at 2022-06-22 03:58:56.135575
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    from tornado.log import LogFormatter
    logging.Formatter.datetime = datetime.datetime(2000, 1, 1, 12, 0, 0)
    formatter = LogFormatter(fmt="%(asctime)s")
    assert "12:00:00" == formatter.format(logging.LogRecord(
        name="tornado.application", level=logging.INFO, pathname="??",
        lineno=0, msg="", args=None, exc_info=None))
    try:
        formatter.format(logging.LogRecord(
            name="tornado.application", level=logging.INFO,
            pathname="??", lineno=0, msg="", args=None, exc_info=None,
            func="error"))
    except:
        pass
    record

# Generated at 2022-06-22 03:59:01.515565
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    define_logging_options(options)
    options.logging = "debug"
    options.log_file_prefix = "test.log"
    options.log_to_stderr = True
    options.parse_command_line()
    

# Generated at 2022-06-22 03:59:12.035008
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define_logging_options(options)

    if not options.logging:
        raise Exception("logging must not be None")
    if not options.log_to_stderr:
        raise Exception("log_to_stderr must not be None")
    if not options.log_file_prefix:
        raise Exception("log_file_prefix must not be None")
    if not options.log_file_max_size:
        raise Exception("log_file_max_size must not be None")
    if not options.log_file_num_backups:
        raise Exception("log_file_num_backups must not be None")
    if not options.log_rotate_when:
        raise Exception("log_rotate_when must not be None")

# Generated at 2022-06-22 03:59:17.542692
# Unit test for function define_logging_options
def test_define_logging_options():
    class options:
        def __init__(self):
            self._options={}
            self._options['logging']='info'
        def define(self,name,value,**kwargs):
            self._options[name]=value

    define_logging_options(options())

# Generated at 2022-06-22 03:59:25.208187
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging.upper()
    tornado,options.options.log_file_prefix
    tornado.options.options.log_rotate_mode
    tornado.options.options.log_file_max_size
    tornado.options.options.log_file_num_backups
    tornado.options.options.log_to_stderr
    tornado.options.options.log_rotate_when
    tornado.options.options.log_rotate_interval

# Generated at 2022-06-22 03:59:34.145437
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    tornado.options.options.logging = "DEBUG"
    tornado.options.options.log_file_prefix = "./test.log"
    tornado.options.options.log_file_max_size = 200
    tornado.options.options.log_file_num_backups = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_rotate_when = "S"
    tornado.options.options.log_rotate_interval = 0
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    logger = logging.getLogger()
    logger.error("test")

test_enable_pretty_logging()

# Generated at 2022-06-22 03:59:41.293897
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()

# Generated at 2022-06-22 03:59:53.108276
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.options.log_rotate_when = 'S'
    tornado.options.options.log_rotate_interval = 6
    tornado.options.options.log_rotate_mode = 'size'
    tornado.options.options.log_file_num_backups = 7
    tornado.options.options.log_file_prefix = 'PATH'
    tornado.options.options.logging = 'debug'
    tornado.options.options.log_to_stderr = False
    tornado.options.options.log_file_max_size = 100 * 1000 * 1000
    assert tornado.options.options.log_rotate_when == 'S'
    assert tornado.options.options.log_rotate_interval == 6

# Generated at 2022-06-22 04:00:06.101950
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print("test start----------------------------------------------------------")

    #import logging
    #logging.basicConfig(filename="log.txt", level=logging.INFO)
    #logging.info("test")

    import os
    import sys
    import time

    import tornado.options
    import logging

    #tornado.options.define("test_test", default=0, type=int, metavar="TEST", help="")
    tornado.options.define("log_file_prefix", default=None, type=str, metavar="FILE", help="")
    tornado.options.define("log_rotate_mode", default="time", type=str, metavar="MODE", help="")
    tornado.options.define("log_rotate_when", default="W0", type=str, metavar="WHEN", help="")
    tornado

# Generated at 2022-06-22 04:00:16.899805
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # note: supposedly, we should be able to import these from the module
    # named 'tornado', but that module has not been imported in the file
    # when this function is called
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.options
    import tornado.log
    import tornado.options
    import tornado.log
    import tornado.log
    import tornado.options
    import tornado.log
    import tornado.log
    import tornado.options
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log
    import tornado.log


# Generated at 2022-06-22 04:00:29.891051
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    #define("logging", default='debug', help="log level", type=str)
    #define("log_to_stderr", default=True, help="", type=bool)
    #define("log_file_prefix", default=None, help="", type=str)
    #define("log_rotate_mode", default='time', help="", type=str)
    #define("log_rotate_when", default='D', help="", type=str) # S M H D
    #define("log_rotate_interval", default=1, help="", type=int)
    #define("log_file_max_size", default=100*1024*1024, help="", type=int)
    #define("log_file_num_backups",

# Generated at 2022-06-22 04:00:35.460451
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options()
    tornado.options.parse_command_line()
    # that the log level is set
    assert logging.getLogger().getEffectiveLevel() == logging.INFO
    # that the formatter is set
    assert logging.getLogger().handlers[0].formatter._fmt == LogFormatter.DEFAULT_FORMAT

# Generated at 2022-06-22 04:00:37.264316
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger("test")
    enable_pretty_logging(None, logger)

# Generated at 2022-06-22 04:00:39.286430
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    assert options.logging == "info"

# Generated at 2022-06-22 04:00:51.903197
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    mock_record = {}
    mock_record['name'] = 'foo'
    mock_record['msg'] = 'bar'
    mock_record['args'] = 'qux'
    mock_record['levelname'] = 'DEBUG'
    mock_record['levelno'] = logging.DEBUG
    mock_record['pathname'] = 'foo.py'
    mock_record['filename'] = 'foo.py'
    mock_record['module'] = 'foo'
    mock_record['exc_info'] = 'baz'
    mock_record['exc_text'] = 'qux'
    mock_record['stack_info'] = 'quux'
    mock_record['lineno'] = 1
    mock_record['funcName'] = 'foo'
    mock_record['created'] = 1.1

# Generated at 2022-06-22 04:01:03.493441
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado import options
    import logging, os

    if os.path.isfile("test_log.log"):
        os.remove("test_log.log")
    
    logger = logging.getLogger("test")
    options.define("log-file-prefix", default="test_log.log")
    options.options.log_to_stderr = False
    options.options.log_file_max_size = 1024
    options.options.log_rotate_mode = "size"
    options.options.log_rotate_when = "D"
    options.options.log_rotate_interval = 1
    options.options.log_file_num_backups = 10
    options.options.logging = "debug"
    enable_pretty_logging(options.options, logger)

# Generated at 2022-06-22 04:01:14.598050
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import parse_command_line
    from tornado.options import parse_config_file
    from tornado.options import define
    from tornado.options import parse_command_line
    define("log_file_prefix", type=str)
    define("log_rotate_when", type=str)
    parse_command_line(["--log_file_prefix=test", "--log_rotate_when=weekday"])
    assert options.log_file_prefix == "test"
    assert options.log_rotate_when == "weekday"


__all__ = [
    "LogFormatter",
    "access_log",
    "app_log",
    "enable_pretty_logging",
    "gen_log",
]

# Generated at 2022-06-22 04:01:26.095782
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Test that enable_pretty_logging creates a stream handler when no handler is
    # present.
    import logging
    import tornado.options

    logging.getLogger().handlers = []
    tornado.options.options.logging = "debug"
    enable_pretty_logging(tornado.options.options)
    assert len(logging.getLogger().handlers) == 1
    logging.getLogger().handlers = []

    # Test that enable_pretty_logging doesn't create a stream handler when there
    # already is one present.
    import logging
    import tornado.options

    logging.getLogger().handlers = [logging.StreamHandler()]
    tornado.options.options.logging = "debug"
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-22 04:01:27.783491
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None, None)

# Generated at 2022-06-22 04:01:29.222211
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert enable_pretty_logging() is None

# Generated at 2022-06-22 04:01:33.919385
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_to_stderr=True
    enable_pretty_logging()
    tornado.options.options.log_to_stderr=False
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:01:36.232451
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    print(options.parse_command_line())
    print(options)
test_define_logging_options()

# Generated at 2022-06-22 04:01:47.078501
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import time
    import logging
    import logging.handlers
    LogFormatter.DEFAULT_DATE_FORMAT = "%y%m%d %H:%M:%S"
    logger = logging.getLogger("tornado.access")
    logger.setLevel(logging.INFO)
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = LogFormatter()
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    logger.info("TEST")
    assert True



# Generated at 2022-06-22 04:01:53.151026
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: no cover
    x = LogFormatter()
    assert isinstance(x, logging.Formatter)
    x = LogFormatter(color=True)
    assert isinstance(x, logging.Formatter)
    x = LogFormatter(color=False)
    assert isinstance(x, logging.Formatter)
    x = LogFormatter(color=None)
    assert isinstance(x, logging.Formatter)
    x = LogFormatter(colors={})
    assert isinstance(x, logging.Formatter)
    try:
        x = LogFormatter(color="abc")
        raise Exception("should have raised an exception")  # pragma: no cover
    except TypeError:
        pass

# Generated at 2022-06-22 04:02:00.493503
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmtr = LogFormatter()
    try:
        # Test both styles of initializing
        fmtr2 = LogFormatter(color=False)
    except TypeError:
        fmtr2 = LogFormatter((None, '%', '%', False, {}))
    return fmtr, fmtr2



# Generated at 2022-06-22 04:02:01.499711
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)

test_define_logging_options()