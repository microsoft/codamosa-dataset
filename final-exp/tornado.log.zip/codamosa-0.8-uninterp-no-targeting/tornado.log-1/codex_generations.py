

# Generated at 2022-06-22 03:53:43.204078
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """
    Check the default constructor of class LogFormatter has the expected signature:
        LogFormatter(fmt="%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
                     datefmt="%y%m%d %H:%M:%S",
                     style="%",
                     color=True,
                     colors={logging.DEBUG: 4,  # Blue
                             logging.INFO: 2,  # Green
                             logging.WARNING: 3,  # Yellow
                             logging.ERROR: 1,  # Red
                             logging.CRITICAL: 5,  # Magenta
                            })
    """
    log_formatter = LogFormatter()

# Generated at 2022-06-22 03:53:54.407315
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from unittest import mock
    from tornado.log import access_log
    from tornado.testing import AsyncTestCase, gen_test
    import io

    class Test(AsyncTestCase):

        @gen_test
        async def test_access_log(self):
            # if logging is not configured, tornado logs to stderr
            # set stderr to a fake object so we can check the output
            with mock.patch("sys.stderr", new_callable=io.StringIO) as fake_stderr:
                access_log.info("Test message")

                self.assertEqual(fake_stderr.getvalue(), "Test message\n")
                # print(fake_stderr.getvalue())
    Test().test_access_log()



# Generated at 2022-06-22 03:54:07.287384
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """
    Function to unit test the function enable_pretty_logging()
    """
    import os

    import tornado.options
    import tornado.testing

    class EnablePrettyLoggingTest(tornado.testing.AsyncTestCase):
        def test_enable_pretty_logging(self) -> None:
            os.environ["TORNADO_LOGGING"] = "warning"
            os.environ["TORNADO_LOG_FILE_PREFIX"] = "test_EnablePrettyLoggingTest_log"
            os.environ["TORNADO_LOG_FILE_MAX_SIZE"] = "10000000"
            os.environ["TORNADO_LOG_FILE_NUM_BACKUPS"] = "1"
            os.environ["TORNADO_LOG_ROTATE_MODE"] = "size"


# Generated at 2022-06-22 03:54:18.036005
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    default_fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    test_fmt = "%(levelname)s %(message)s"
    default_date_fmt = "%y%m%d %H:%M:%S"
    test_date_fmt = "%m%d %H:%M:%S"
    default_style = "%"
    test_style = "{"
    default_color = True

# Generated at 2022-06-22 03:54:23.733497
# Unit test for function define_logging_options
def test_define_logging_options():
  class Options(object):
    def define(self, name, default, help, metavar=None):
      self.name = name
    def add_parse_callback(self, callback):
      pass
  options = Options()

  tornado.log.define_logging_options(options)
  assert(options.name == 'logging')

# Generated at 2022-06-22 03:54:35.886493
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing


    class OptionsTestCase(tornado.testing.LogTrapTestCase):
        def setUp(self):
            super(OptionsTestCase, self).setUp()
            self.options = tornado.options.options
            self.options.logging = None
            self.options.log_file_prefix = None
            self.options.log_to_stderr = None

        def test_log_to_stdout_default(self):
            # When there are no other logs, we get the default.
            self.options.parse_command_line(["progname"])
            gen_log.info("info")
            self.assertLogged("info")
            self.options.parse_command_line(["progname", "--logging=warning"])
            gen_log

# Generated at 2022-06-22 03:54:47.694239
# Unit test for function define_logging_options
def test_define_logging_options():
    """Unit test for function define_logging_options"""
    import tornado.options

    tornado.options.define("test_logging", default="info", metavar="debug|info|warning|error|none", help="Set the Python log level. If 'none', tornado won't touch the logging configuration.")
    tornado.options.define("test_log_to_stderr", type=bool, default=None, help="Send log output to stderr (colorized if possible). By default use stderr if --log_file_prefix is not set and no other logging is configured.")

# Generated at 2022-06-22 03:54:53.080880
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    enable_pretty_logging()
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:54:55.381508
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()  # type: ignore



# Generated at 2022-06-22 03:55:03.087858
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print("Running unit tests for method format of class LogFormatter...")
    print('VARIABLES')
    message = 'safdaf'
    record = {'message':message}
    print('message:', message)
    print('record:', record)
    print('SETUP FUNCTION')
    logging.Formatter.format(None, record)
    print('ASSERT')
    assert isinstance(record.get('message'), basestring_type)
    assert message == record.get('message')
    print('\n')

# Generated at 2022-06-22 03:55:23.380957
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.parse_config_file("./test_define_logging_options.conf")
    assert options.logging == "info"
    assert options.log_to_stderr == True
    assert options.log_file_prefix == "file_prefix"
    assert options.log_file_max_size == 1
    assert options.log_file_num_backups == 2
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 3
    assert options.log_rotate_mode == "size"

test_define_logging_options()

# Generated at 2022-06-22 03:55:35.460326
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.testing

    class OptionsTestCase(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(OptionsTestCase, self).setUp()
            tornado.options.define("logging", default="info", help="help")
            tornado.options.define("log_to_stderr", default=None, help="help")
            tornado.options.define("log_file_prefix", default=None, help="help")
            tornado.options.define(
                "log_file_max_size", default=100 * 1000 * 1000, help="help"
            )
            tornado.options.define("log_file_num_backups", default=10, help="help")
            tornado.options.define("log_rotate_when", default="midnight", help="help")
            tornado

# Generated at 2022-06-22 03:55:47.463029
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    log_fmt = LogFormatter(datefmt="%Y-%m-%d %H:%M:%S", fmt="%(color)s([32;40m%(levelno)s[0m - %(asctime)s) %(message)s")
    print(log_fmt.format(logging.LogRecord("tornado.access", 10, "__file__", 5, "hello world", 'args', None)))
    print(log_fmt.format(logging.LogRecord("tornado.application", 5, "__file__", 5, "hello world", 'args', None)))

# Generated at 2022-06-22 03:55:57.553006
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import options as opts
    from io import StringIO
    import logging
    import logging.config
    import sys
    import time

    opts.logging = "none"
    opts.log_file_prefix = None
    opts.log_to_stderr = True
    lfmt = LogFormatter()
    ch = logging.StreamHandler(StringIO())
    ch.setFormatter(lfmt)
    lgr = logging.getLogger("tornado.general")
    lgr.setLevel(logging.DEBUG)
    lgr.propagate = False
    lgr.addHandler(ch)
    lgr.info("info message")
    assert ch.stream.getvalue() == "info message\n"


# Generated at 2022-06-22 03:56:05.778536
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import sys
    import io
    options = tornado.options.options
    options.log_file_prefix = "./run_logs/log.txt"
    options.log_to_stderr = True
    enable_pretty_logging(options)
    logging.getLogger().info('Hello world!')
    logging.getLogger().debug('Debugging message.')
    
if __name__ == "__main__":
    test_enable_pretty_logging()


# Generated at 2022-06-22 03:56:17.017309
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # pylint: disable=missing-docstring
    import unittest
    import tornado.options
    import os
    import shutil

    def _rmtree(root: str) -> None:
        if os.path.exists(root):
            shutil.rmtree(root)

    class TestLogging(unittest.TestCase):
        log_root = os.path.join(os.path.dirname(__file__), "logs")
        test_path = os.path.join(log_root, "test_logging")

        @classmethod
        def setUpClass(cls) -> None:
            cls.test_path = os.path.join(cls.log_root, "test_logging")


# Generated at 2022-06-22 03:56:23.979926
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(asctime)s | %(levelname)s | %(filename)s | %(funcName)s | %(message)s"
    datefmt = "%Y/%m/%d %H:%M:%S"
    try:
        formatter = LogFormatter(fmt, datefmt, style=None)
    except Exception as e:
        print(e)



# Generated at 2022-06-22 03:56:28.458512
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    myformatter = LogFormatter()
    assert myformatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert myformatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert myformatter._colors == {}
    assert myformatter._normal == ""
    myformatter = LogFormatter("myfmt", "mydatefmt")
    assert myformatter.datefmt == "mydatefmt"
    assert myformatter._fmt == "myfmt"



# Generated at 2022-06-22 03:56:37.095451
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    from tornado.options import OptionParser, parse_command_line
    define_logging_options(options)
    for opt in options.as_dict():
        print(opt)
    parser = OptionParser()
    # Enable options defined above
    define_logging_options(parser)
    options.help = True
    parser.add_option("--help", action="store_true")
    options.logging = "error"
    parse_command_line()

# Generated at 2022-06-22 03:56:37.932049
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging(): 
    enable_pretty_logging()

# Generated at 2022-06-22 03:56:51.353339
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    record = logging.LogRecord(
        "tornado.application",
        logging.INFO,
        "/home/bear/tornado/tornado/log.py",
        157,
        "Bad message (%r): %r",
        (Exception(), {"message": "name 'bad' is not defined"}),
        None,
    )
    f.format(record)

# Generated at 2022-06-22 03:56:57.411230
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class LogFormatter(object):
        def __init__(self, fmt: str = "", datefmt: str = "", style: str = "") -> None:
            self._fmt = fmt
            self._datefmt = datefmt

    lf = LogFormatter("", "", "%")
    assert isinstance(lf, LogFormatter)



# Generated at 2022-06-22 03:57:09.379762
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("foo", default=42)
    define("bar", default=None)
    define_logging_options(options)
    assert options.foo == 42
    assert options.log_file_prefix is None
    assert options.log_to_stderr is None
    assert options.logging == "info"
    # NOTE: Temporary until the options module is refactored to allow
    # removing options.
    options.log_file_prefix = "/tmp/foo"
    options.log_to_stderr = False
    options.logging = "debug"
    enable_pretty_logging(options)
    assert options.log_file_prefix == "/tmp/foo"
    assert options.log_to_stderr is False
    assert options.logging == "debug"
   

# Generated at 2022-06-22 03:57:16.417929
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert log_formatter._normal == ""

    log_formatter = LogFormatter(color=False)
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert log_formatter._normal == ""



# Generated at 2022-06-22 03:57:18.325796
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, logging.Formatter)


# Generated at 2022-06-22 03:57:24.839137
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.log
    log = logging.getLogger("tornado.test")
    tornado.log.enable_pretty_logging()
    tornado_log = logging.getLogger("tornado.application")
    assert tornado_log.level == logging.INFO
    tornado_log.debug("test")
    tornado_log.warning("test")
    tornado_log.error("test")
    log.error("test")
    log.warning("test")
    log.debug("test")



# Generated at 2022-06-22 03:57:26.436360
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-22 03:57:38.465840
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()
    assert logFormatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert logFormatter._colors == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    assert logFormatter._normal == ""
    assert logFormatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"



# Generated at 2022-06-22 03:57:49.127928
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    import sys
    import logging
    class DummyHandler(object):
        def __init__(self):
            self.stream = sys.stdout
    handler = DummyHandler()
    formatter = LogFormatter()
    msg = "hello"
    log = logging.makeLogRecord({"msg":msg})
    assert formatter.format(log)
    log.stack_info = True
    assert formatter.format(log)
    log.exc_info = True
    assert formatter.format(log)
    assert formatter.formatTime(log)
    assert formatter.formatException(log.exc_info)
    log.exc_info = None
    log.exc_text = "dummy"
    assert formatter.formatException(log.exc_info)
    assert formatter.format

# Generated at 2022-06-22 03:57:53.659597
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.handlers[0].setFormatter(LogFormatter())
    logger.info("test")


# Generated at 2022-06-22 03:58:11.247215
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass



# Generated at 2022-06-22 03:58:17.055796
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # It requires Tornado to be installed.
    # pip install Tornado
    import tornado.options
    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("log_rotate_interval", type=int)
    tornado.options.define("log_to_stderr", type=bool)
    tornado.options.define("logging", type=str)
    # It requires log_file_prefix to be given.
    # tornado.options.options.log_file

# Generated at 2022-06-22 03:58:22.870861
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter()
    record = logging.LogRecord(
        'name',
        logging.DEBUG,
        None,
        0,
        'msg',
        None,
        None)
    record.color = 'color'
    record.end_color = 'end_color'
    fmt.format(record)


# Generated at 2022-06-22 03:58:26.722927
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    r = logging.LogRecord("foo", 0, "/foo/bar.py", 23, "a test",
                          args = (),
                          exc_info = None)
    assert isinstance(f.format(r), str)

# Generated at 2022-06-22 03:58:27.456146
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()

# Generated at 2022-06-22 03:58:33.232247
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Object(object):
        foo = 'bar'

    o = Object()

    formatter = LogFormatter()
    message = formatter.format(logging.makeLogRecord({'msg': o}))
    assert message == '%r' % o



# Generated at 2022-06-22 03:58:40.688857
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    tornado.options.parse_config_file("config.py")
    test = logging.getLogger()
    enable_pretty_logging(options, test)
    test.info("test message")
    test.warning("test message")
    test.error("test message")
    test.critical("test message")
# Unit test
if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:58:43.323201
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    if __name__ == '__main__':
        enable_pretty_logging()
        app_log.debug("hello world")
        app_log.warning("hello world")


# Generated at 2022-06-22 03:58:50.940384
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.OptionParser().parse_config_file("test.conf")
    print(options)
    assert options["log_rotate_mode"] == "size"
    assert options["log_rotate_when"] == "midnight"
    assert options["log_rotate_interval"] == 1


# Generated at 2022-06-22 03:58:59.168297
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
    # The following options are added to "options"
    assert options.logging.default == "info"
    assert options.log_to_stderr.default is None
    assert options.log_file_prefix.default is None
    assert options.log_file_max_size.default == 100 * 1000 * 1000
    assert options.log_file_num_backups.default == 10
    assert options.log_rotate_when.default == "midnight"
    assert options.log_rotate_interval.default == 1
    assert options.log_rotate_mode.default == "size"
    # assert options.log_to_stderr.help == (
    #     "Send log output to stderr (color

# Generated at 2022-06-22 03:59:09.239732
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    _options = tornado.options.options
    _options.logging = 'INFO'
    _options.log_file_prefix = '/tmp/log_file_prefix'
    _options.log_rotate_mode = 'size'
    _options.log_file_max_size = 100
    _options.log_file_num_backups = 4
    enable_pretty_logging()
    tornado.options.options = _options
    _options.logging = 'ERROR'
    _options.log_to_stderr = True
    _options.log_file_prefix = None
    enable_pretty_logging()


# Generated at 2022-06-22 03:59:11.513869
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass


# Generated at 2022-06-22 03:59:18.650307
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    # Make sure that LogFormatter constructor is compatible with
    # logging.config.dictConfig
    LogFormatter()
    LogFormatter(color=False)
    LogFormatter(fmt="foo")
    LogFormatter(datefmt="bar")
    LogFormatter(style="baz")
    LogFormatter(colors={})



# Generated at 2022-06-22 03:59:23.399670
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    # 'message' attribute of arg is guaranteed by logging module
    arg = logging.LogRecord("name", logging.WARN, "/dev/null", 1000, "message", (), None)
    result = formatter.format(arg)
    assert result.startswith(arg.asctime)



# Generated at 2022-06-22 03:59:27.717194
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    class record:
        def __init__(self):
            self.msg = "hello world!"
            self.args = None
            self.levelno = logging.INFO
    record.getMessage = lambda self: self.msg

# Generated at 2022-06-22 03:59:31.757545
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = LogFormatter()
    assert fmt

import types

# Monkey patches the standard logging module to configure requests logs
# to use color
old_factory = logging.getLogRecordFactory()



# Generated at 2022-06-22 03:59:34.989779
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.info("Hello, logger")

# Generated at 2022-06-22 03:59:47.509855
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("tornado.general", logging.INFO, "conf.py", 0, "info", None, None)
    assert formatter.format(record) == "[I 170216 10:57:29 conf:0] info"
    record = logging.LogRecord("tornado.general", logging.INFO, "conf.py", 0, "info", None, None)
    record.exc_info = Exception("Bad message")
    assert formatter.format(record) == "[I 170216 10:57:29 conf:0] info\n    Bad message"
    record = logging.LogRecord("tornado.general", logging.INFO, "conf.py", 0, "info", None, None)
    record.exc_info = Exception("Bad message")

# Generated at 2022-06-22 04:00:00.477459
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(color=False)
    assert formatter.format(logging.LogRecord("test", logging.INFO, "foo.py", 1, "test", None, None)) == "[I " + " ".join(logging.Formatter().formatTime().split()[:2]) + " foo.py:1] test"
    formatter = LogFormatter(color=True)
    assert formatter.format(logging.LogRecord("test", logging.INFO, "foo.py", 1, "test", None, None)) == "[\x1b[0m\x1b[00;32mI " + " ".join(logging.Formatter().formatTime().split()[:2]) + " foo.py:1\x1b[0m\x1b[00m] test"


# Generated at 2022-06-22 04:00:08.304426
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    def test1():
        options = type('options',(),{'log_file_prefix':'haha','logging':None,'log_to_stderr':True,'log_file_max_size':100,'log_file_num_backups':1,'log_rotate_mode':'time','log_rotate_when':'midnight','log_rotate_interval':1})()
        logger = logging.getLogger()
        enable_pretty_logging(options,logger)
        pass
    test1()
enable_pretty_logging()

# Generated at 2022-06-22 04:00:30.953695
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from logging import LogRecord
    from tornado.log import LogFormatter
    x = LogFormatter() # type: LogFormatter
    record = LogRecord(
    name = "name",
    level = 0,
    pathname = "pathname",
    lineno = 0,
    msg = "message",
    args = (),
    exc_info = None)
    record_str = x.format(record)
    assert isinstance(record_str, basestring_type)
    assert record_str == "message"



# Generated at 2022-06-22 04:00:41.997466
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options
    define("logging", default="debug", help="logging level", type=str)
    define("log_file_prefix", default="dummy.log", help="log file", type=str)
    define("log_file_num_backups", default=2, help="log file num_backups", type=int)
    define("log_rotate_mode", default="time", help="log file num_backups", type=str)
    define("log_file_max_size", default=2048, help="log file max_size", type=int)
    define("log_rotate_when", default="D", help="log file when", type=str)

# Generated at 2022-06-22 04:00:42.557621
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()

# Generated at 2022-06-22 04:00:55.543883
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define
    define('log_file_prefix', type=str)
    define('log_rotate_mode', type=str)
    define('log_file_max_size', type=int)
    define('log_file_num_backups', type=int)
    define('log_rotate_when', type=str)
    define('log_rotate_interval', type=int)
    define('logging', type=str)
    define('log_to_stderr', type=bool)
    try:
        tornado.options.parse_command_line()
        enable_pretty_logging(tornado.options.options, None)
        # Do something to generate exception
        tornado.escape.url_escape(None)
    except:
        assert True

# Generated at 2022-06-22 04:01:08.309926
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    import io
    from io import StringIO
    from contextlib import redirect_stdout
    import sys
    import tornado

    handler = logging.StreamHandler()
    handler.setFormatter(LogFormatter())
    handler.setLevel(10)
    logging.basicConfig(handlers=[handler])
    f = StringIO()
    with redirect_stdout(f):
        enable_pretty_logging(logger=None)

        logger = logging.getLogger()
        logger.setLevel(20)
        logger.handlers = []
        tornado.options.options.logging = 'info'
        tornado.options.options.log_file_prefix = 'test'
        tornado.options.options.log_rotate_mode = 'time'
        tornado.options.options.log_rotate

# Generated at 2022-06-22 04:01:17.492522
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # type: () -> None
    formatter = LogFormatter(color=True)
    msg = formatter.format(logging.LogRecord(
        'tornado.access', logging.ERROR, 'log_file_path', 80,
        'message', (), None,))
    assert 'message' in msg
    assert '\033' in msg

    formatter = LogFormatter(color=False)
    msg = formatter.format(logging.LogRecord(
        'tornado.access', logging.ERROR, 'log_file_path', 80,
        'message', (), None,))
    assert 'message' in msg
    assert '\033' not in msg



# Generated at 2022-06-22 04:01:25.930024
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # assert LogFormatter()
    # assert LogFormatter(None)
    assert LogFormatter("")
    assert LogFormatter("")
    # assert LogFormatter(datefmt=None)
    # assert LogFormatter(datefmt="")
    # assert LogFormatter(datefmt=None, fmt="")
    assert LogFormatter(datefmt="", fmt="")
    assert LogFormatter(
        datefmt="", fmt="", style="%", color=True, colors={logging.DEBUG: 4}
    )



# Generated at 2022-06-22 04:01:35.947134
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    tornado.options.options.logging = "WARNING"
    tornado.options.options.log_to_stderr=True
    # tornado.options.options.log_rotate_mode = 'size'
    # tornado.options.options.log_file_prefix="log_file_prefix"
    # tornado.options.options.log_file_max_size=1024
    # tornado.options.options.log_file_num_backups=3
    enable_pretty_logging()
    logging.warning("warning")



if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:01:39.256301
# Unit test for function define_logging_options
def test_define_logging_options():
    pass

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-22 04:01:47.677493
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
  try:
    import sys
    logger = logging.getLogger("testLog")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stderr)
    formatter = LogFormatter()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")
  except Exception as e:
    print("Exception: " + str(e))

# Generated at 2022-06-22 04:02:26.112979
# Unit test for function define_logging_options
def test_define_logging_options():
    options = dict()
    define_logging_options(options)
    print_options = [
        "logging",
        "log_to_stderr",
        "log_file_prefix",
        "log_file_max_size",
        "log_file_num_backups",
        "log_rotate_when",
        "log_rotate_interval",
        "log_rotate_mode",
    ]
    for name in print_options:
        print(name, options.get(name, None))

# Generated at 2022-06-22 04:02:37.118260
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Error handling
    import tornado.options
    options = tornado.options.options

# Generated at 2022-06-22 04:02:48.686353
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado
    tornado.options.parse_command_line()
    # value check
    argv = ["python", "--logging=info", "--log_to_stderr=True", \
            "--log_file_prefix=PATH", "--log_file_max_size=1000000000", \
            "--log_file_num_backups=10", "--log_rotate_when=midnight", \
            "--log_rotate_interval=1", "--log_rotate_mode=size"]
    tornado.options.parse_command_line(argv)
    # call check
    options = tornado.options.options
    define_logging_options(options)
    # pass

test_define_logging_options()



# Generated at 2022-06-22 04:02:50.146245
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Assert that LogFormatter.__init__ will accept the
    # default arguments.
    LogFormatter()


# Generated at 2022-06-22 04:02:51.169989
# Unit test for function define_logging_options
def test_define_logging_options():
    print(1)

# Generated at 2022-06-22 04:03:01.449684
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # See https://www.python.org/dev/peps/pep-0343/
    f = LogFormatter()  # type: ignore
    assert isinstance(f, LogFormatter)
    assert f._fmt == LogFormatter.DEFAULT_FORMAT
    assert f.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    colors = f._colors
    assert colors[logging.DEBUG] == "\033[2;34m"
    assert colors[logging.INFO] == "\033[2;32m"
    assert colors[logging.WARNING] == "\033[2;33m"
    assert colors[logging.ERROR] == "\033[2;31m"
    assert colors[logging.CRITICAL] == "\033[2;35m"

# Generated at 2022-06-22 04:03:03.944715
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter()
    assert isinstance(fmt, logging.Formatter)


# Generated at 2022-06-22 04:03:15.761950
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): # noqa: F811  # noqa
    class FakeRecord:
        pass

    fake_record = FakeRecord()
    log = LogFormatter(color=True)
    # Unit test for method "color"
    # TODO: Compare the results of this unit test with the results of the real code
    assert log._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert isinstance(log._colors, dict)
    assert log._normal == "\x1b[0m"  # noqa: E501

    # Unit test for method "format"
    # TODO: Compare the results of this unit test with the results of the real code
