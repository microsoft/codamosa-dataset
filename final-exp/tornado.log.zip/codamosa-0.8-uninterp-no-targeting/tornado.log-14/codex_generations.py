

# Generated at 2022-06-22 03:53:40.985335
# Unit test for function define_logging_options
def test_define_logging_options():
    test_options = Options()
    test_options.log_to_stderr = False
    test_options.log_file_prefix = "server.log"
    assert test_options.log_to_stderr == False
    assert test_options.log_file_prefix == "server.log"


# Generated at 2022-06-22 03:53:53.361006
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.application",
        level=20,
        pathname="/home/chenhonglin/python/tornado-4.2/tornado/log.py",
        lineno=351,
        msg="[I 151101 23:55:39 log:351] Request by: 127.0.0.1",  # type: ignore
        args=None,
        exc_info=None,
    )
    message = log_formatter.format(record)
    assert message == "\x1b[2;34m[I 151101 23:55:39 log:351]\x1b[0m Request by: 127.0.0.1"  # noqa: E501


# Generated at 2022-06-22 03:54:04.565204
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class FakeLogRecord(object):
        def __init__(self) -> None:
            self.levelno = 0
            self.args = ()
            self.exc_info = None
            self.exc_text = None
            self.__dict__ = {'color': '', 'message': 'test', 'end_color': ''}
    record = FakeLogRecord()
    logfmt = LogFormatter()
    assert logfmt.format(record) == '[D test:0]    test'
    logfmt = LogFormatter(fmt="%(blue)s%(red)s")
    assert logfmt.format(record) == '%(blue)s%(red)s'



# Generated at 2022-06-22 03:54:07.446854
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 03:54:12.958565
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()
    logger.handlers[0].setFormatter(
        LogFormatter()
    )  # type: ignore  # redefine attribute
    logger.error("Test error message for LogFormatter")



# Generated at 2022-06-22 03:54:26.098840
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, parse_command_line, options
    import tornado.ioloop

    define("logging", default="info", help="logging level")
    define("log_to_stderr", default=True, help="log to stderr")
    define("log_file_prefix", default=None, help="log file")
    define("log_file_max_size", default=100, help="log file max size")
    define("log_file_num_backups", default=5, help="log file num backups")
    define("log_rotate_mode", default="size", help="log rotate mode")
    define("log_rotate_when", default="S", help="log rotate when")
    define("log_rotate_interval", default=1, help="log rotate interval")

# Generated at 2022-06-22 03:54:33.046832
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter(fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s')
    record = logging.LogRecord("tornado.access", logging.DEBUG, "", 0, "", "", "")
    fmt.format(record)

# Generated at 2022-06-22 03:54:44.409078
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    # Arrange
    import tornado.options
    import logging,sys
    if sys.version_info < (3,):
        message = b'bytes message'
    else:
        message = 'unicode message'
    # Act
    tornado.options.options = tornado.options.define("logging", None, help=None, type=str, metavar=None)
    tornado.options.options.log_file_prefix = "log.txt"
    tornado.options.options.log_file_max_size = 10000000
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_num_backups = 10
    enable_pretty_logging() # type: ignore

    # Assert
    logging.basicConfig(level=logging.DEBUG)

# Generated at 2022-06-22 03:54:57.073112
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    import logging.handlers

    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line(["--logging=error", "--log_to_stderr=true"])
    # print(options.logging)
    assert options.logging == "error"
    assert options.log_to_stderr == True
    options.parse_command_line(["--log_file_prefix=logtest.txt"])
    # print(options.log_file_prefix)
    assert options.log_file_prefix == "logtest.txt"
    options.parse_command_line(["--log_file_max_size=123"])
    # print(options.log_file_max_size)
    assert options

# Generated at 2022-06-22 03:55:04.732041
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.options

    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_prefix = "test.log"
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 4
    tornado.options.options.log_to_stderr = "stderr"

    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-22 03:55:24.836484
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
 
    define("log_file_prefix", type=str, default="tornado.log")
    define("log_rotate_mode", type=str, default="time")
 
    define("log_rotate_when", default="MIDNIGHT")
    define("log_rotate_interval", type=int, default=1)
    define("log_file_num_backups", type=int, default=10)
 
    define("log_to_stderr", type=bool, default=True)
    define("logging", type=str, default="debug")
    #define("log_file_max_size", type=int, default=100 * 1000 * 1000)
    ##"log_file_prefix"   : "/tmp/myapp.log

# Generated at 2022-06-22 03:55:34.081003
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    define_logging_options(options)
    options.parse_command_line(["--log_rotate_mode","time"])
    options.parse_command_line(["--log_rotate_mode","size"])
    try:
        options.parse_command_line(["--log_rotate_mode","not_exists"])
    except ValueError as e:
        error_message = 'The value of log_rotate_mode option should be "size" or "time", not "not_exists".'
        assert e.args == (error_message,)

# Generated at 2022-06-22 03:55:46.170163
# Unit test for constructor of class LogFormatter
def test_LogFormatter(): # pragma: no cover
    import logging
    formatter = LogFormatter()
    # new style :(
    record = logging.LogRecord(
        "name", logging.DEBUG, None, 1, "message", (), None)
    logformat = formatter.format(record)
    assert logformat == (
        '\033[38;5;4m[D'
        ' '
        '1970-01-01 00:00:00,000 '
        '<logging>:1]\033[0m '
        'message')
    # new style w/ colorama
    record = logging.LogRecord(
        "name", logging.DEBUG, None, 1, "message", (), None)
    formatter = LogFormatter(color=True)
    logformat = formatter.format(record)

# Generated at 2022-06-22 03:55:48.056853
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    assert LogFormatter.__init__  # silence pyflakes



# Generated at 2022-06-22 03:55:49.026005
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-22 03:55:57.325399
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_rotate_mode", None)
    tornado.options.define("log_rotate_when", None)
    tornado.options.define("log_rotate_interval", None)
    tornado.options.define("log_file_prefix", None)
    tornado.options.define("log_file_max_size", None)
    tornado.options.define("log_file_num_backups", None)
    tornado.options.define("log_to_stderr", None)
    tornado.options.define("logging", None)
    enable_pretty_logging()

# Generated at 2022-06-22 03:56:05.922818
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging_options = {
        "logging": "none",
        "log_file_prefix": "C:\\Users\\user\\Desktop\\file.txt",
        "log_file_max_size": 10,
        "log_file_num_backups": 2,
        "log_rotate_mode": "time",
        "log_rotate_when": "M",
        "log_rotate_interval": 5,
        "log_to_stderr": True
    }
    enable_pretty_logging(options=logging_options)

# Generated at 2022-06-22 03:56:09.428666
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    class D: pass
    logfmt = LogFormatter()
    d = D()
    d.levelno = logging.INFO
    d.message = logging.INFO
    d.asctime = "asctime"
    d.color = ""
    d.end_color = ""
    logfmt.format(d)
    assert d.message == logging.INFO
    assert d.asctime == "asctime"
    assert d.color == ""
    assert d.end_color == ""



# Generated at 2022-06-22 03:56:15.661859
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
            "tornado.general",
            logging.WARNING,
            "testpath",
            123,
            "testmessage",
            [],
            None,
        )
    res = formatter.format(record)
    expected = ("[W 120102 17:46:00 testpath:123] testmessage")
    assert res == expected


# Generated at 2022-06-22 03:56:21.818332
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import pytest
    log_formatter = LogFormatter()
    record = logging.LogRecord(name="abc", level=20, pathname="path", lineno=11,
                            msg="test", args=None, exc_info=None)
    print(log_formatter.format(record))
test_LogFormatter_format()

# Generated at 2022-06-22 03:56:34.285055
# Unit test for function define_logging_options
def test_define_logging_options():
    #from tornado.options import options
    #options = None
    import tornado.options
    options = tornado.options.options
    options.set_default_suboptions("logging", {"log_to_stderr": True})
    define_logging_options(options)
    assert options.log_to_stderr == True
    assert options.logging == "info"
    assert type(options.log_rotate_interval) is int
    assert options.log_rotate_mode == "size"
    assert options.log_rotate_when == "midnight"
#test_define_logging_options()

# Generated at 2022-06-22 03:56:39.952339
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Can't really test what curses or colorama do, so just test the formatting
    formatter = LogFormatter()
    record = logging.makeLogRecord({"msg": "Hello world"})
    record.levelno = logging.INFO
    record.exc_text = "hi\nthere"
    assert formatter.format(record)  # type: ignore



# Generated at 2022-06-22 03:56:47.529652
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    pass
#    assert LogFormatter.DEFAULT_FORMAT
#    assert LogFormatter.DEFAULT_DATE_FORMAT
#    assert LogFormatter.DEFAULT_COLORS
#    assert LogFormatter()._fmt == LogFormatter.DEFAULT_FORMAT
#    assert LogFormatter().datefmt == LogFormatter.DEFAULT_DATE_FORMAT
#    assert LogFormatter()._colors == LogFormatter.DEFAULT_COLORS



# Generated at 2022-06-22 03:56:48.612519
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    pass


# Generated at 2022-06-22 03:56:56.062673
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    class MyFormatter(LogFormatter):
        pass

    formatter = MyFormatter()  # type: LogFormatter
    # pylint: disable=no-member
    assert formatter._colors == LogFormatter.DEFAULT_COLORS
    assert formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert formatter._normal == ""



# Generated at 2022-06-22 03:56:57.106768
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options)



# Generated at 2022-06-22 03:57:05.391392
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(name='test', level=logging.INFO, pathname='', lineno=0, msg='test message', args=None, exc_info=None)
    assert formatter.format(record) == '[I ... test:0] test message'
    record = logging.LogRecord(name='test', level=logging.ERROR, pathname='', lineno=0, msg='test message', args=None, exc_info=None)
    assert formatter.format(record) == '[E ... test:0] test message'



# Generated at 2022-06-22 03:57:13.510938
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    from tornado.log import define_logging_options

    op = tornado.options.OptionParser()
    define_logging_options(op)
    define_logging_options(tornado.options.options)
    op.parse_command_line(["--logging=warning", "--log_file_num_backups=5"])
    define_logging_options(tornado.options.options)
    op.parse_command_line(["--log_file_num_backups=6"])

# Generated at 2022-06-22 03:57:19.993395
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("name", logging.INFO, "pathname", 1, "msg", None, None)
    assert formatter.format(record) == "[I "+str(record.asctime)+" pathname:1] msg"

test_LogFormatter_format()



# Generated at 2022-06-22 03:57:27.337858
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options as options
    import tornado.ioloop as ioloop
    import tornado.web as web

    @web.stream_request_body
    class MainHandler(web.RequestHandler):
        def post(self):
            self.write("ok")

    def make_app():
        return web.Application([("/", MainHandler)])

    # test the logging
    application = make_app()
    application.listen(8888)
    options.parse_command_line()
    enable_pretty_logging()
    ioloop.IOLoop.current().start()

# Generated at 2022-06-22 03:57:36.281348
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    return 1


# Generated at 2022-06-22 03:57:47.721491
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_to_stderr", type=bool, default=None)
    tornado.options.define("log_file_prefix", type=str, default="")
    tornado.options.define("log_file_max_size", type=int, default=None)
    tornado.options.define("log_file_num_backups", type=int, default=None)
    tornado.options.define("log_rotate_mode", type=str, default=None)
    tornado.options.define("log_rotate_when", type=str, default=None)
    tornado.options.define("log_rotate_interval", type=int, default=None)

    logger = logging.getLogger()
    enable_pretty_logging(logger=logger)
    logger.info

# Generated at 2022-06-22 03:57:53.929437
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    _LogFormatter = LogFormatter()
    assert _LogFormatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert _LogFormatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert _LogFormatter._colors == {}
    assert _LogFormatter._normal == ""



# Generated at 2022-06-22 03:57:55.297733
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()


# Generated at 2022-06-22 03:57:56.278269
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    pass


# Generated at 2022-06-22 03:58:00.583159
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.LogRecord("", 0, "", 0, "", None, None)
    record.levelno = logging.INFO
    record.name = "tornado.application"
    log_formatter = LogFormatter()
    log_formatter.format(record)


# Generated at 2022-06-22 03:58:08.054277
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    lfmt = LogFormatter()
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(lfmt)
    logger.addHandler(stream_handler)
    msg = "this is a test"
    logger.info(msg)



# Generated at 2022-06-22 03:58:13.614605
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.formatException = lambda e: e
    record = logging.LogRecord("tornado.application", logging.ERROR, "/fake/path", 1234, "test", {}, None)
    record.exc_info = ()
    record.exc_text = "test exc"
    assert formatter.format(record) == "[E 010101 00:00:00 tornado.application:1234] test\n    test exc"  # noqa: E501


# Generated at 2022-06-22 03:58:26.854465
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import io
    import logging
    import sys
    original_stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()
        logging.basicConfig(level=logging.DEBUG)
        log = logging.getLogger()
        log.handlers[0].setFormatter(LogFormatter())
        log.error("Test Error")
        assert sys.stderr.getvalue() == "[E 100101 00:00:00 root:0] Test Error\n"
    finally:
        sys.stderr = original_stderr

# A color escape sequence is a terminal control escape sequence
# (as defined in https://en.wikipedia.org/wiki/ANSI_escape_code)
# that controls terminal colors.  This function adds OS-specific
# escapes to force the terminal to reset its

# Generated at 2022-06-22 03:58:37.948549
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import unittest
    import logging
    class TestLogFormatter(unittest.TestCase):
        def setUp(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            self.log_handler = logging.StreamHandler(stream=sys.stdout)
            self.logger = logger
        def test_LogFormatter(self):
            self.log_formatter = LogFormatter()
            self.log_handler.setFormatter(self.log_formatter)
            self.logger.addHandler(self.log_handler)
            self.logger.info("test")
    unittest.main()

# test_LogFormatter()


# Generated at 2022-06-22 03:58:53.466155
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.log
    tornado.options.define("log_file_prefix", type=str, default="log/tornado.log")
    tornado.options.define("logging", default="debug")
    from tornado.options import options, parse_command_line
    tornado.options.parse_command_line()
    # Use this log to test whether the setting is successful
    tornado.log.app_log.debug("test")
    tornado.log.access_log.debug("test")
    tornado.log.gen_log.debug("test")

# Generated at 2022-06-22 03:58:56.178748
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.parse_command_line()
    args = "--logging=debug --log_to_stderr=True --log_file_prefix /tmp/tornado"
    tornado.options.parse_command_line(args)
    define_logging_options()

# Generated at 2022-06-22 03:59:08.758276
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():

    # Setup a mock record
    record = logging.LogRecord('testLogger', logging.DEBUG, None, 1, 'test message', None, None)

    # Create a LogFormatter object
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True

# Generated at 2022-06-22 03:59:13.214774
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.testing
    tornado.log.enable_pretty_logging(None, "INFO", tornado.testing.LogFormatter)
    class Options(object):
        log_file_prefix=''

# Generated at 2022-06-22 03:59:27.146056
# Unit test for function define_logging_options
def test_define_logging_options():
    import sys
    import os
    import unittest
    import shutil
    import glob
    import time
    import pytest
    import tornado.options
    import tornado.testing
    import tornado.log
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    from tornado.options import options, OptionParser
    log_dir = './logs'
    rotating_file_path = os.path.join(log_dir, 'tornado.log')

    if(os.path.exists(log_dir)):
        shutil.rmtree(log_dir)
    os.mkdir(log_dir)
    @tornado.testing.gen_test(timeout=5)
    def test_logging_options_size():
        parser = OptionParser()
        tornado.log.define

# Generated at 2022-06-22 03:59:29.347312
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options=None,logger=None)
    #assert log_file_prefix is '-'


# Generated at 2022-06-22 03:59:39.837665
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter(
        fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
        datefmt='%y%m%d %H:%M:%S',
        style='%',
        color=True,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        },
    )



# Generated at 2022-06-22 03:59:40.815517
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print('func test_enable_pretty_logging')

# Generated at 2022-06-22 03:59:52.660488
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.log import LogFormatter, logging, gen_log
    
    # Test that the log output is colored
    gen_log.handlers = []
    enable_pretty_logging()
    assert(len(gen_log.handlers) > 0)
    assert(isinstance(gen_log.handlers[0].formatter, LogFormatter))
    
    # Test that the log output is file-based and not colored
    gen_log.handlers = []
    import tempfile
    tempdir = tempfile.mkdtemp()
    from tornado.options import options
    old_log_file = options.log_file_prefix
    options.log_file_prefix = "%s/test" % tempdir
    enable_pretty_logging()
    assert(len(gen_log.handlers) > 0)

# Generated at 2022-06-22 04:00:04.259482
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logf = LogFormatter(
        fmt="[%(color)s%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s",
        datefmt="%y%m%d %H:%M:%S",
        color=True,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        })
    assert logf is not None



# Generated at 2022-06-22 04:00:28.387471
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line, Error
    define("foo", type=int)
    define("bar", type=str)
    try:
        parse_command_line(["prog", "--foo=10", "--bar=20"])
    except Error:
        pass
    print(options.foo, options.bar, options.logging)
# test_define_logging_options()

# Generated at 2022-06-22 04:00:39.968326
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    formatter = LogFormatter(
        fmt, datefmt, style, color, colors
    )
    print(formatter.format(logging.DEBUG))



# Generated at 2022-06-22 04:00:44.186119
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter._colors == {}
    assert log_formatter._normal == ""



# Generated at 2022-06-22 04:00:56.249785
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("test_logging", type=str, default="none", help="help")
    define_logging_options()
    options.parse_config_file("test_define_logging_options.conf")
    print(options.logging)
    assert options.logging == "info"
    print(options.log_file_prefix)
    assert options.log_file_prefix == "./logs/tornado.log"
    print(options.log_file_num_backups)
    assert options.log_file_num_backups == 10
    print(options.log_rotate_when)
    assert options.log_rotate_when == "midnight"
import os

# Generated at 2022-06-22 04:01:08.937180
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_DATE_FORMAT is not None
    assert formatter
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert len(formatter._colors) == 5

    formatter = LogFormatter(color=False, colors={})
    assert formatter.DEFAULT_DATE_FORMAT is not None
    assert formatter
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert len(formatter._colors) == 0

    formatter = LogFormatter(color=True)
    assert formatter.DEFAULT_DATE_FORMAT is not None
    assert formatter
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert len(formatter._colors) == 5



# Generated at 2022-06-22 04:01:11.287008
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter._fmt, str)



# Generated at 2022-06-22 04:01:23.245320
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter(
        fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s', # noqa: E501
        datefmt = '%y%m%d %H:%M:%S',
        style = '%',
        color = True,
        colors = {logging.DEBUG: 4,  # Blue
                  logging.INFO: 2,  # Green
                  logging.WARNING: 3,  # Yellow
                  logging.ERROR: 1,  # Red
                  logging.CRITICAL: 5,  # Magenta
                }
    )

# Generated at 2022-06-22 04:01:26.054167
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    f = LogFormatter(color=True)
    assert f
    f = LogFormatter(color=False)
    assert f
    f = LogFormatter()
    assert f



# Generated at 2022-06-22 04:01:32.362937
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "./test_enable_pretty_logging.log"
    tornado.options.options.log_file_max_size = 10000000
    tornado.options.options.log_file_num_backups = 5
    enable_pretty_logging()


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:01:45.203728
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: () -> None
    formatter = LogFormatter()
    formatter._fmt = "%(message)s"
    formatter._colors = {10: "0;31"}  # DEBUG
    record = logging.LogRecord(
        name="test",
        level=10,  # DEBUG
        pathname="/path/to/test",
        lineno=1,
        msg="test message",
        args=(),
        exc_info=None,
    )
    actual = formatter.format(record)

    if not actual.startswith("\033[0;31m[D "):
        raise Exception("actual = %r" % actual)
    if not actual.endswith("]\033[0m test message"):
        raise Exception("actual = %r" % actual)

# These are imported here to

# Generated at 2022-06-22 04:02:23.600017
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """function to test the enable_pretty_logging function
    """
    import tornado.options
    tornado.options.options = tornado.options.parse_config_file("test_options.py")
    enable_pretty_logging(tornado.options.options)

test_enable_pretty_logging()

# Generated at 2022-06-22 04:02:30.571016
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # initalizing the LogFormatter object
    lf = LogFormatter("", "", "", True, {})
    # initalizing a record
    record = logging.LogRecord("name", 100, "pathname", 1, "msg", (), None)
    # checking that the correct output is returned
    out = lf.format(record)
    assert out == "[D 0101 00:00:00 name:1] msg"


# Generated at 2022-06-22 04:02:31.472460
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 04:02:32.239340
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-22 04:02:39.012190
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.makeLogRecord({
        'name': 'tornado.general',
        'levelno': logging.INFO,
        'msg': 'Hello world!',
        'args': '',
        'exc_info': None,
        'func': '',
        'pathname': __file__})
    result = formatter.format(record)
    assert result.endswith('Hello world!')



# Generated at 2022-06-22 04:02:47.588085
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    assert options.logging=='info'
    assert options.log_to_stderr==None
    assert options.log_file_prefix==None
    assert options.log_file_max_size==10**8
    assert options.log_file_num_backups==10
    assert options.log_rotate_when=='midnight'
    assert options.log_rotate_interval==1
    assert options.log_rotate_mode=='size'

test_define_logging_options()

# Generated at 2022-06-22 04:02:57.896992
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Record(object):
        def __init__(self):
            self.levelno = logging.DEBUG
            self.lineno = 99
            self.exc_info = None
            self.exc_text = "line2"
            self.stack_info = None
            self.msg = "message"
            self.args = None
            self.module = "module"

        def getMessage(self):
            return self.msg

    if _stderr_supports_color():
        f = LogFormatter()
        r = Record()
        assert '[DEBU 99 module:99] message\n    line2' == f.format(r)
        r.levelno = logging.ERROR
        r.msg = "error"
        assert '[ERRO 99 module:99] error\n    line2' == f.format(r)


# Generated at 2022-06-22 04:02:58.980312
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:03:10.300643
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import define, options

    define("log_to_stderr", False)
    options.log_file_prefix = "test_LogFormatter"

    # 参数少，需要补充 self.datefmt，所以调用必须以 self 修饰
    log_formatter = LogFormatter(fmt="[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s")
    # 设置log打印格式，这种格式比较简单，没有颜色

# Generated at 2022-06-22 04:03:14.794201
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import sys
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging(tornado.options.options)
    assert sys.stderr.isatty() == False
