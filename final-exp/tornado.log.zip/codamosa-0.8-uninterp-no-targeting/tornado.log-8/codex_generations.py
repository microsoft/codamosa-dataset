

# Generated at 2022-06-22 03:53:52.731507
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.root.setLevel(logging.DEBUG)
    log = logging.getLogger("tornado.test")
    color_enabled = _stderr_supports_color()
    for color in (False, True):
        log.debug("color_enabled = %s", color_enabled)
        formatter = LogFormatter(color = color)
        handler = logging.StreamHandler()
        handler.setFormatter(formatter)
        log.addHandler(handler)
        log.debug("debug message")
        log.info("info message")
        log.warning("warning message")
        log.error("error message")
        log.critical("critical message")



# Generated at 2022-06-22 03:54:03.647854
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado_options=tornado.options.options
    tornado_options.logging='error'
    tornado_options.log_file_prefix='/home/zhijie/logs/ccp.txt'
    tornado_options.log_rotate_mode = "size"
    tornado_options.log_file_max_size=100
    tornado_options.log_file_max_size=1
    tornado_options.log_file_num_backups=1
    tornado_options.log_to_stderr=False
    enable_pretty_logging()
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:54:14.191895
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG)
    class TestException(Exception):
        def __init__(self, message, errors):
            super(TestException, self).__init__(message)
            self._errors = errors

    exception = TestException("Error Message", "Errors")
    log = logging.getLogger("exception_example")

    try:
        raise exception
    except TestException:
        log.exception("Test message for exception:")

    try:
        raise TestException("Just an exception")
    except TestException:
        log.exception("Test message for exception:")
        
test_LogFormatter_format()


# Generated at 2022-06-22 03:54:27.478492
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.ioloop
    import tornado.web
    import tornado.wsgi

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            options.options.logging = 'debug'
            tornado.options.enable_pretty_logging()
            gen_log.debug('debug message')
            gen_log.info('info message')
            gen_log.warning('warning message')
            gen_log.error('error message')
            gen_log.critical('critical message')
            self.write('hello, world')

    app = tornado.web.Application([
        (r"/", MainHandler),
    ])

    http_server = tornado.httpserver.HTTPServer(app)
    http_server.listen(8887)


# Generated at 2022-06-22 03:54:30.415482
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado
    tornado.options.options.log_to_stderr=True
    enable_pretty_logging(tornado.options.options)

# Generated at 2022-06-22 03:54:43.023449
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Test 1: Create a LogFormatter instance and use the format() method
    # to format the log record.
    formatter = LogFormatter()
    record = logging.LogRecord(name="foo", level=logging.DEBUG, pathname="bar", lineno=1, msg="testing", args={}, exc_info=None) # noqa: E501
    res = formatter.format(record)
    assert res.startswith("[D")

    # Test 2: Create a LogFormatter instance, then set _colors to {}, and then call
    # the format method to format the log record, to test the code path
    # where _colors is set to {}
    formatter = LogFormatter()
    formatter._colors = {}

# Generated at 2022-06-22 03:54:46.469082
# Unit test for function define_logging_options
def test_define_logging_options():
    try:
        from tornado.options import define, options, parse_command_line
    except ImportError:
        pass
    define_logging_options(options)
    parse_command_line(args=[])
    print(options.logging)

# Generated at 2022-06-22 03:54:59.222075
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import pytest, tornado.options
    def test_enable_pretty_logging_size_mode():
        tornado.options.options.log_file_prefix = "/tmp/test_abc"
        tornado.options.options.log_file_max_size = 1
        tornado.options.options.log_file_num_backups = 1
        tornado.options.options.log_rotate_mode = "size"
        enable_pretty_logging()
    def test_enable_pretty_logging_time_mode():
        tornado.options.options.log_file_prefix = "/tmp/test_abc"
        tornado.options.options.log_file_num_backups = 1
        tornado.options.options.log_rotate_when = "S"
        tornado.options.options.log_rotate_interval = 1
       

# Generated at 2022-06-22 03:55:03.739760
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    try:
        enable_pretty_logging(logger=logger)
    except Exception as e:
        assert False, e
    try:
        enable_pretty_logging(None, logger=logger)
    except Exception as e:
        assert False, e

# Generated at 2022-06-22 03:55:16.077970
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = LogFormatter(datefmt="%H:%M:%S", color=False)
    record = logging.LogRecord("foo", logging.INFO, None, None, "bar", None, None)
    assert (
        fmt.format(record) == "[I 01:02:03 foo:0] bar"
    )  # type: ignore[attr-defined]
    record = logging.LogRecord("foo", logging.INFO, None, None, "bar", None, None)
    record.__dict__.update({"color": "foo", "end_color": "bar", "extra": "stuff"})
    assert (
        fmt.format(record) == "[I 01:02:03 foo:0] bar"
    )  # type: ignore[attr-defined]

# Generated at 2022-06-22 03:56:01.162199
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.OptionParser().parse_args([])
    define_logging_options(options)
    # Without any specified options, this should use stderr.
    enable_pretty_logging(options)

    # Now test options:
    for opts in [["--logging=none"], ["--log_to_stderr", "0"]]:
        options = tornado.options.OptionParser().parse_args(opts)
        define_logging_options(options)
        assert not options.log_to_stderr
        enable_pretty_logging(options)

    for opts in [["--log_to_stderr", "true"]]:
        options = tornado.options.OptionParser().parse_args(opts)
        define_logging_options(options)

# Generated at 2022-06-22 03:56:03.402791
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print(__name__)

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:56:15.027722
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.options
    import logging
    class ObjectForTest(object):
        def __init__(self, message=None, levelno=None):
            self.message = message
            self.levelno = levelno
    # Case1: normal
    logging.basicConfig(format='%(message)s')
    logFormatter = LogFormatter()
    assert logFormatter.format(ObjectForTest("hello", logging.ERROR)) == "hello"
    # Case2: wrong message
    logging.basicConfig(format='%(message)s')
    logFormatter2 = LogFormatter()
    assert logFormatter2.format(ObjectForTest(None, logging.ERROR)) == "Bad message (None): None"
    # Case3: wrong message but it has exc_text
    logging.basicConfig(format='%(message)s')

# Generated at 2022-06-22 03:56:20.266393
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord( '',level=1,pathname='',lineno=0,msg='',args=None,exc_info=None)
    assert isinstance(formatter.format(record), str)


# Generated at 2022-06-22 03:56:28.197613
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"

test_define_logging_options()

# Generated at 2022-06-22 03:56:29.986376
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    log_formatters = LogFormatter()

# Generated at 2022-06-22 03:56:41.138591
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class Options(object):
        """Simulate the tornado.options.options object."""

        def __init__(self, **kwargs: Any) -> None:
            for name in kwargs:
                setattr(self, name, kwargs[name])

    enable_pretty_logging(Options(logging=None))
    logging.debug("Test message")
    enable_pretty_logging(Options(logging="info"))
    logging.debug("Test message")
    enable_pretty_logging(Options(logging="debug"))
    logging.debug("Test message")
    enable_pretty_logging(Options(logging="debug", log_to_stderr=True))
    logging.debug("Test message")

# Generated at 2022-06-22 03:56:43.223153
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    enable_pretty_logging(None, logger)



# Generated at 2022-06-22 03:56:51.022567
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    record = logging.LogRecord(
        name='tornado.general',
        level=logging.DEBUG,
        pathname='/path/to/file',
        lineno=42,
        msg='hello world',
        args=None,
        exc_info=None,
    )
    assert formatter.format(record) == '[D 42 /path/to/file] hello world'



# Generated at 2022-06-22 03:56:57.956254
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"



# Generated at 2022-06-22 03:57:21.554586
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    expected = '[I 151255 2018-05-15 16:40:15 LogFormatter_test.py:3] test'

    LogFormatter().format(
        logging.LogRecord(
            'test',
            logging.INFO,
            'tornado.test.test_log.LogFormatter_test.py',
            '3',
            'test',
            (),
            None)) == expected


# Generated at 2022-06-22 03:57:29.172765
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    define(
        "logging",
        default="warn",
        help="Set the Python log level. If 'none', tornado won't touch the logging configuration.",  # noqa: E501
        type=str,
    )
    parse_command_line()
    enable_pretty_logging(options)
    gen_log.info("test 1")


if __name__ == '__main__':
    print(test_enable_pretty_logging())

# Generated at 2022-06-22 03:57:32.859564
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    try:
        tornado.options.define_logging_options()
    except:
        assert False
    logging.error('this is a test')


# Generated at 2022-06-22 03:57:45.155335
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter._colors == formatter.DEFAULT_COLORS
    
    formatter = LogFormatter(_fmt = "fmt", _datefmt = "datefmt", _style = "%")
    assert formatter._fmt == "fmt"
    assert formatter._colors == formatter.DEFAULT_COLORS
    
    formatter = LogFormatter(_fmt = "fmt", _datefmt = "datefmt", _style = "c%")
    assert formatter._fmt == "fmt"
    assert formatter._colors == formatter.DEFAULT_COLORS
    

# Generated at 2022-06-22 03:57:51.614290
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import tornado
    import os
    if os.path.exists("a.txt"):
        os.remove("a.txt")
    options = tornado.options.options
    options.logging = "none"
    enable_pretty_logging(options)
    assert logging.getLogger().level == logging.NOTSET

    options.logging = "debug"
    enable_pretty_logging(options)
    assert logging.getLogger().level == logging.DEBUG

    options.logging = "info"
    enable_pretty_logging(options)
    assert logging.getLogger().level == logging.INFO

    options.logging = "warning"
    enable_pretty_logging(options)
    assert logging.getLogger().level == logging.WARNING


# Generated at 2022-06-22 03:58:03.205471
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    logging_handler = logging.StreamHandler()
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(logging_handler)
    options.add_parse_callback(lambda: enable_pretty_logging(options))
    tornado.options.define_logging_options(options)
    options.parse_command_line(["--log_to_stderr=True"])
    assert logging_handler.formatter._normal == ""
    assert logging_handler.formatter._colors == {}
    options.parse_command_line(["--log_to_stderr=False"])
    assert logging_handler.formatter._normal == ""
    assert logging_handler.formatter._colors == {}
   

# Generated at 2022-06-22 03:58:11.082666
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter(datefmt="%Y-%m-%d", fmt='%(color)s[%(asctime)s]%(end_color)s%(message)s')
    class _LogRecord(object):
        pass
    record = _LogRecord()
    record.levelno = 1
    record.asctime = '2019-10-13'
    record.message = 'Some message'
    res = lf.format(record)
    assert res == '[\x1b[2;3m2019-10-13\x1b[0m]Some message'

# Generated at 2022-06-22 03:58:21.350893
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # fmt is set to None to avoid colorization of the test output
    formatter = LogFormatter(fmt=None)
    record = logging.makeLogRecord({
        'msg': 'test', 'asctime': 'test', 'color': 'test', 'end_color': 'test'})
    formatter._colors[logging.INFO] = 'test color'
    formatter._normal = 'test normal'
    msg = formatter.format(record)
    assert len(msg) > 0
    assert msg.startswith('[I')
    assert msg.endswith('test\n    ')



# Generated at 2022-06-22 03:58:27.407097
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Record:
        pass

    record = Record()
    record.levelno = 1
    record.exc_info = None
    record.getMessage = lambda: "abc"

    log_formatter = LogFormatter()
    log_formatter.format(record)
    assert record.message == "abc"
    assert not hasattr(record, "asctime")
    assert not hasattr(record, "exc_text")



# Generated at 2022-06-22 03:58:29.845326
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    formatter = LogFormatter()
    formatter.format(object)
    # TODO: log.error, log.warning
    raise NotImplementedError()


# Generated at 2022-06-22 03:59:12.687911
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class TestRecord(object):
        def __init__(self):
            self.levelno = logging.ERROR
            self.message = 'record.message'
            self.exc_info = 'record.exc_info'
            self.exc_text = 'record.exc_text'
        def getMessage(self):
            return self.message

    logger = logging.getLogger("tornado.test")
    lf = LogFormatter()
    r = TestRecord()
    lf.format(r)


# Generated at 2022-06-22 03:59:25.713864
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    #
    print(LogFormatter())
    print(LogFormatter.DEFAULT_FORMAT)
    print(LogFormatter.DEFAULT_DATE_FORMAT)
    print(LogFormatter.DEFAULT_COLORS)
    access_log.info('access_log.info')
    app_log.info('app_log.info')
    gen_log.info('gen_log.info')
    # [I 190102 07:00:18 web:34] access_log.info
    # [I 190102 07:00:18 web:40] app_log.info
    # [I 190102 07:00:18 web:46] gen_log.

# Generated at 2022-06-22 03:59:34.627010
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    
    tornado.options.define("logging", default = "none", help="log level", type = str)
    tornado.options.define("log_file_prefix", default = '', help="log file", type = str)
    tornado.options.define("log_rotation_mode", default = "time", help = "rotation mode", type = str)
    tornado.options.define("log_rotate_when", default = "D", help="when", type = str)
    tornado.options.define("log_rotate_interval", default = 1, help="rotation interval", type = int)
    tornado.options.define("log_file_num_backups", default = 30, help="backup count", type = int)

# Generated at 2022-06-22 03:59:40.350829
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.define("log_to_stderr", type=bool, default=None, help="...."))
    #define_logging_options(tornado.options.options) 这么写不行，变量tornado.options.options不存在

# Generated at 2022-06-22 03:59:52.063602
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.testing import AsyncTestCase, gen_test
    import tornado.options
    import tornado.log
    import tornado.ioloop
    import logging
    import time
    import os
    import tempfile
    import shutil
    import sys
    import gc
    import warnings

    # Test cases

    class LoggingTestCase(AsyncTestCase):
        # Base class for logging test cases
        # The actual tests will be implemented in subclass

        def setUp(self):
            super().setUp()
            self.options = tornado.options.Options()
            # The default log_file_prefix is tornado's own logging.py
            # which we don't want to overwrite.
            self.temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 04:00:04.912415
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    log = logging.getLogger("test")
    stream = logging.StreamHandler()
    stream.setFormatter(LogFormatter())
    log.addHandler(stream)

    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")
    try:
        """this line will raise an exception"""
        1 / 0
    except:
        log.exception("exception")

# define a Handler which writes INFO messages or higher to the sys.stderr
stderr_handler = logging.StreamHandler(sys.stderr)
stderr_handler.setFormatter(LogFormatter())
stderr_handler.setLevel(logging.INFO)



# Generated at 2022-06-22 04:00:05.884642
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 04:00:11.374154
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options()
    args = ["--logging=debug", "--log_file_prefix=test.log"]
    tornado.options.parse_command_line(args)
    assert options.logging == "debug"
    assert options.log_file_prefix == "test.log"

# Generated at 2022-06-22 04:00:19.555362
# Unit test for function define_logging_options
def test_define_logging_options():
   import tornado.options
   define_logging_options(tornado.options.options)
   tornado.options.options.log_file_prefix = 'test.log'
   tornado.options.options.parse_command_line()
   # check if set up
   assert access_log.hasHandlers()
   assert app_log.hasHandlers()
   assert gen_log.hasHandlers()
   # check handler is RotatingFileHandler and the filename is 'test.log'
   file_handler = cast(
                        logging.handlers.RotatingFileHandler,
                        access_log.handlers[0]
                       )
   filename = file_handler.baseFilename
   assert filename == 'test.log' or filename == 'test.log.1'
   # check message format like '[I 2020/09/10 18:10:44 test_log

# Generated at 2022-06-22 04:00:20.167456
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-22 04:01:06.694933
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger()
    logger.setLevel(logging.NOTSET)
    import io
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.NOTSET)
    handler.setFormatter(LogFormatter(color=True))
    logger.addHandler(handler)
    logger.debug("hello")
    logger.info("hello")
    logger.warning("hello")
    logger.error("hello")
    logger.critical("hello")


# Generated at 2022-06-22 04:01:16.849727
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    def _set_up():
        # set up
        import logging
        import time

        class TestFilter(logging.Filter):
            def filter(self, rec):
                rec.test = 'test'
                return True

        formatter = LogFormatter(color=False)  # type: ignore
        logger = logging.getLogger(__name__)

        logger.addFilter(TestFilter())
        logger.handlers[0].setFormatter(formatter)

    def test_format():
        # Execute
        _set_up()
        _log = logging.getLogger(__name__)
        _log.error("test1")
        _log.error("test2")

    test_format()


# Generated at 2022-06-22 04:01:27.765303
# Unit test for function define_logging_options
def test_define_logging_options():
    # noinspection PyUnresolvedReferences
    from tornado.options import define, options, parse_command_line

    define('--logging', type=str, help='set logging level')
    define('--log_to_stderr', type=bool, default=None,
           help='send log output to stderr (colorized if possible)')
    define('--log_file_prefix', type=str,
           help='path prefix for log files. '
                'Note that if you are running multiple tornado processes, '
                'log_file_prefix must be different for each of them (e.g. '
                'include the port number)')
    define('--log_file_max_size', type=int, default=100 * 1000 * 1000,
           help='max size of log files before rollover')

# Generated at 2022-06-22 04:01:29.947317
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None,None)

test_enable_pretty_logging()

# Generated at 2022-06-22 04:01:41.927208
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define("log_file_prefix", type=str, default="a.log")
    tornado.options.define("log_file_max_size", type=int, default=100)
    tornado.options.define("log_file_num_backups", type=int, default=1)
    tornado.options.define("log_rotate_mode", type=str, default="size")
    tornado.options.define("log_rotate_when", type=str, default="S")
    tornado.options.define("log_rotate_interval", type=int, default=1)

    tornado.options.parse_command_line(["--log_file_prefix=b.log"])
    enable_pretty_logging()


# Generated at 2022-06-22 04:01:51.080154
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.log
    import logging
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, "test.log")


# Generated at 2022-06-22 04:01:56.078276
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    fmt = LogFormatter()
    handler = logging.StreamHandler()
    handler.setFormatter(fmt)
    log.addHandler(handler)
    log.error('error')
    log.debug('debug')



# Generated at 2022-06-22 04:02:07.943487
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig()
    root = logging.getLogger()
    old_level = root.level
    root.setLevel(logging.DEBUG)

# Generated at 2022-06-22 04:02:08.737923
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-22 04:02:18.806112
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # TODO: Replace the mock class with a real one
    class Record:pass
    record = Record()
    record.__dict__ = {
        "levelno": "INFO",
        "asctime": "LOGTIME",
        "module": "LOGMODULE",
        "lineno": "LOGLINENO",
        "message": "LOGMESSAGE",
    }
    formatter = LogFormatter()
    out = formatter.format(record)
    assert out.startswith("[I LOGTIME LOGMODULE:LOGLINENO] ")
    assert out.endswith(" LOGMESSAGE")
