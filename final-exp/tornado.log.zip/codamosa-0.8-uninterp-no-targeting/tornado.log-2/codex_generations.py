

# Generated at 2022-06-22 03:53:44.625988
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
        import logging

        options = tornado.options.options
        options.logging = "debug"
        options.log_file_prefix = "./log_test.log"
        options.log_rotate_mode = "size"
        options.log_file_max_size = 100
        options.log_file_num_backups = 3
        options.log_to_stderr = True

        enable_pretty_logging(options, logging.getLogger())

        access_log.debug("access_log")
        app_log.debug("app_log")
        gen_log.debug("gen_log")

    except Exception as e:
        print(e)

# Generated at 2022-06-22 03:53:54.988241
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():

    import tornado_defer

    from tornado.options import options, define, parse_command_line, parse_config_file

    define("test", type = str, help = "testing")
    define("logging", type = str, help = "testing")
    define("log_file_prefix", type = str, help = "testing")
    define("log_to_stderr", type = str, help = "testing")
    define("log_rotate_mode", type = str, help = "testing")
    define("log_file_max_size", type = str, help = "testing")
    define("log_file_num_backups", type = str, help = "testing")
    define("log_rotate_interval", type = str, help = "testing")

# Generated at 2022-06-22 03:54:04.236766
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logformat = LogFormatter()
    assert logformat is not None
    assert logformat._colors == {
        logging.DEBUG: "\\x1b[2;34m",
        logging.INFO: "\\x1b[2;32m",
        logging.WARNING: "\\x1b[2;33m",
        logging.ERROR: "\\x1b[2;31m",
        logging.CRITICAL: "\\x1b[2;35m",
    }
    assert logformat._normal == "\\x1b[0m"



# Generated at 2022-06-22 03:54:12.502777
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    testFormatter = LogFormatter()
    class testRecord():
        def __init__(self):
            self.message = "test message"
            self.levelno = logging.INFO
            self.asctime = "test time"
            self.color = "<color>"
            self.end_color = "</color>"
    testRecord = testRecord()
    result = testFormatter.format(testRecord)
    assert result == "[I test time :] test message"


# Generated at 2022-06-22 03:54:20.127144
# Unit test for function define_logging_options
def test_define_logging_options():
    import logging
    import tornado.options

    tornado.options.define_logging_options()
    tornado.options.parse_command_line(["--logging=none", "--log_to_stderr=true"])

    logging.basicConfig(level=logging.DEBUG)
    root = logging.getLogger()
    assert any(
        isinstance(h, logging.StreamHandler) for h in root.handlers
    ), root.handlers
    assert not any(
        isinstance(h, logging.handlers.RotatingFileHandler) for h in root.handlers
    ), root.handlers

    tornado.options.define_logging_options()

# Generated at 2022-06-22 03:54:32.829279
# Unit test for function define_logging_options
def test_define_logging_options():
    # before Tornado 5.0.2 define_logging_options does nothing
    import tornado.options
    t_options = tornado.options.options
    define_logging_options(t_options) # define_logging_options by default use Tornado.options as options parameter
    # so it equals call:
    # define_logging_options(tornado.options.options)
    
    # after Tornado 5.0.2 define_logging_options should call enable_pretty_logging to format logging message
    # and add TimedRotatingFileHandler
    
    # test default settings
    t_options.logging = "debug"
    t_options.log_file_prefix = "test_tornado_logs/test_define_logging_options_size_debug.log"

# Generated at 2022-06-22 03:54:37.253787
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter(color=False)
    rec1 = logging.LogRecord("test_logger", logging.DEBUG, pathname="core.py", lineno=67,
                  msg="Test message", args=[], exc_info=None)

    fmt.format(rec1) == "[D 1454226509 core.py:67] Test message"



# Generated at 2022-06-22 03:54:48.389507
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_format = ('[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] '
                 + '%(message)s')
    date_format = '%y%m%d %H:%M:%S'
    formatter = LogFormatter(fmt=log_format, datefmt=date_format)
    formatter.format(logging.LogRecord('name', logging.INFO, 'filename', 1,
                                       'message', tuple(), None))


# Generated at 2022-06-22 03:54:50.224520
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()


# Generated at 2022-06-22 03:55:02.152096
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    测试用例
    """
    # 还没有完成
    # 这个是第一个测试用例
    logging.root.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    logging.root.handlers = [handler]
    lf = LogFormatter()
    logging.root.handlers = [handler]
    handler.setFormatter(lf)
    #logging.root.addHandler(handler)
    logging.debug('\n\r')
    logging.debug('test1')
    logging.info('test2')
    logging.debug('test3')
    logging.debug('\n\r')
    logging.debug('test4')

# Generated at 2022-06-22 03:55:15.839467
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import enable_pretty_logging
    enable_pretty_logging()
    app_log.info("test")


# Generated at 2022-06-22 03:55:21.643482
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if sys.platform.startswith("win") and colorama:
        # colorama is only capable of colorizing terminals on Windows,
        # not file handles.
        tf = logging.handlers.TimedRotatingFileHandler("test.log", "D")
        colorama.init(strip=False, wrap=False)
    else:
        tf = sys.stderr


# Generated at 2022-06-22 03:55:26.228121
# Unit test for function define_logging_options
def test_define_logging_options():
    pass


# Per-module logger caches.
# In python 2.7+, logging.getLogger takes a "name" argument and will
# make a best effort to produce stable loggers with non-empty names
# that are not dependent on the order of module imports.  Prior to
# 2.7, separate loggers were needed.
# try:
#     from logging import getLogger, setLoggerClass
# except ImportError:
#     # 2.6
#     from logging import getLogger as _getLogger, setLoggerClass
#     _loggers = {}
#     _srcfile = None
#     def getLogger(name=None):
#         if name is not None:
#             return _getLogger(name)
#         # Make sure that if two modules use the same name for their
#         # loggers, they get

# Generated at 2022-06-22 03:55:32.632569
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('test_name')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.NullHandler())
    fmt = LogFormatter()
    s = fmt.format(logger.makeRecord(name='test_name', pathname='', lineno=0, msg="test", args=None, exc_info=None))
    print(s)



# Generated at 2022-06-22 03:55:44.871836
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options, define
    import logging
    define('logging', default='none', help='logging level')
    define('log_to_stderr', default=True, help='log to stderr')
    define('log_file_prefix', default=__file__, help='log file name')
    define('log_file_max_size', default=256, help='max size of log file')
    define('log_file_num_backups', default=3, help='number of log files to backup')
    define('log_rotate_mode', default='size', help='log rotate mode')
    define('log_rotate_when', default='M', help='log rotate when')
    define('log_rotate_interval', default=1, help='log rotate  interval')
    enable_pretty_logging

# Generated at 2022-06-22 03:55:54.047859
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("logging", default="info", help="logging level")
    define("log_file_prefix", default="", help="log file")
    define("log_file_num_backups", default=3, help="log file")
    define("log_file_max_size", default=1024, help="log file")
    define("log_rotate_when", default="midnight", help="log file")
    define("log_rotate_interval", default=3, help="log file")
    define("log_to_stderr", default=True, help="log file")

    enable_pretty_logging(options)
    enable_pretty_logging()

# Generated at 2022-06-22 03:56:05.647702
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    from tornado.util import b
    import tempfile
    import locale
    import os

    define("logging", default="info", help="log level")
    define("log_to_stderr", default=False, help="log to stderr")
    define("log_file_prefix", default=None, help="log file")
    define("log_file_max_size", default=100 * 1000 * 1000, help="max log size")
    define("log_file_num_backups", default=10, help="number of log files to keep")
    define("log_rotate_mode", default="size", help="Log rotate mode")
    define("log_rotate_when", default="MIDNIGHT", help="Log rotate time interval")

# Generated at 2022-06-22 03:56:16.874588
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    tornado.options.define(
        "log_file_prefix", type=str, default="test.log", help=("The path prefix for log files")
    )
    tornado.options.define(
        "log_rotate_mode", type=str, default="size", help=("The mode for log rotate")
    )
    tornado.options.define(
        "log_to_stderr", type=bool, default=True, help=("Log to stderr")
    )
    tornado.options.options.logging = "debug"
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_rotate_when = "D"
    tornado.options.options.log_

# Generated at 2022-06-22 03:56:29.597984
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import os
    import tornado.options
    import tornado.log
    import time
    test_log_file_prefix = "test_logging"
    test_log_file_prefix_time = "test_logging_time"
    test_log_file_prefix2 = "test_logging2"
    test_log_file_prefix2_time = "test_logging2_time"
    test_log_file_prefix3 = "test_logging3"
    test_log_file_prefix3_time = "test_logging3_time"
    test_log_file_prefix4 = "test_logging4"
    test_log_file_prefix4_time = "test_logging4_time"

# Generated at 2022-06-22 03:56:40.910254
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado.log
    import logging
    import sys

    # create logger
    logger = logging.getLogger("logtest")
    logger.propagate = False
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler(stream=sys.stdout)
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = LogFormatter()

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    logger.debug('hello world!')
    logger.info('hello world!')
    logger.warning('hello world!')
    logger.error('hello world!')
    logger.critical('hello world!')



# Generated at 2022-06-22 03:57:11.787335
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.options.log_file_prefix = "/var/log/"
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_rotate_when = "midnight"
    tornado.options.options.log_rotate_interval = 3
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.logging = "error"
    tornado.options.options.log_to_stderr = True
    define_logging_options(tornado.options.options)

    def _test(name):
        option = tornado.options.options.group_dict("").get(name)

# Generated at 2022-06-22 03:57:24.338770
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import optparse
    import sys
    import os
    import io
    import shutil
    import time
    import datetime
    import tempfile

    class Error(Exception):
        pass

    class StderrStub(io.StringIO):
        def __init__(self) -> None:
            super(StderrStub, self).__init__()
            self.last = None  # type: Optional[str]

        def write(self, s: str) -> None:
            s = s.strip()
            if s:
                self.last = s
            super(StderrStub, self).write(s + "\n")

    stderr = StderrStub()
    sys.stderr = stderr


# Generated at 2022-06-22 03:57:37.031217
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """
    Test LogFormatter class
    """
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    style = "%"
    color = True  # type: bool
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    logFormatter = LogFormatter(fmt, datefmt, style, color, colors)



# Generated at 2022-06-22 03:57:45.856154
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("logging", default="debug")
    tornado.options.define("log_file_prefix", default="test.log")
    tornado.options.define("log_rotate_mode", default="time")
    tornado.options.define("log_rotate_when", default="D")
    tornado.options.define("log_rotate_interval", default=1)
    tornado.options.parse_command_line(args=["logging=debug"])
    enable_pretty_logging()

# Generated at 2022-06-22 03:57:49.810190
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Create a LogFormatter object
    formatter = LogFormatter()
    # Check to see if the format function was created
    assert hasattr(formatter, "format")


# Generated at 2022-06-22 03:57:53.875881
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord("", "", "", "", "", "", 1))
    print("test_LogFormatter_format pass")

# Generated at 2022-06-22 03:58:04.128901
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # type: ignore
    formatter = LogFormatter()
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert formatter._normal == ""
    assert formatter._colors == {}
    assert formatter.datefmt == formatter.DEFAULT_DATE_FORMAT
    formatter = LogFormatter(datefmt="%m%d")
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert formatter._fmt == formatter.DEFAULT_FORMAT

# Generated at 2022-06-22 03:58:08.588533
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    assert tornado.options.options.log_rotate_mode == "size"
    assert tornado.options.options.logging == "info"
    assert tornado.options.options.log_to_stderr is None
    assert tornado.options.options.log_file_prefix is None

# Generated at 2022-06-22 03:58:12.993261
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options

    options.logging = "info"
    enable_pretty_logging()

    options.log_file_prefix = "./tmp.txt"
    enable_pretty_logging()

    options.log_file_prefix = ""
    options.log_to_stderr = False
    enable_pretty_logging()

# Generated at 2022-06-22 03:58:26.811942
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import sys
    import argparse
    from tornado.log import gen_log

    class OptionsTest(tornado.options.Options):
        def __init__(self):
            super(OptionsTest, self).__init__()
            self.define("logging", type=str, default=None)
            self.define("log_to_stderr", type=bool, default=None)
            self.define(
                "log_file_prefix", type=str, default=sys.argv[0] + ".log"
            )
            self.define(
                "log_rotate_mode", type=str, default="time",
            )
            self.define(
                "log_rotate_when", type=str, default="midnight",
            )

# Generated at 2022-06-22 03:58:45.769747
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = "abcd %(levelname)s %(message)s"
    datefmt = "%d"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    log_handler = logging.StreamHandler()
    log_handler.setLevel(logging.DEBUG)
    log_handler.setFormatter(LogFormatter(fmt, datefmt, style, color, colors))

    logger.addHandler(log_handler)

# Generated at 2022-06-22 03:58:56.606022
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    tornado.options.define("log_file_prefix", type=str)
    tornado.options.define("log_file_num_backups", type=int)
    tornado.options.define("log_file_max_size", type=int)
    tornado.options.define("log_to_stderr", type=bool)
    tornado.options.define("log_rotate_mode", type=str)
    tornado.options.define("log_rotate_interval", type=int)
    tornado.options.define("log_rotate_when", type=str)
    tornado.options.define("logging", type=str)
    class Options:
        log_file_prefix = ''
        log_file_num_backups = 0

# Generated at 2022-06-22 03:59:09.218116
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import tornado
    import io
    import sys
    #     assert _stderr_supports_color()
    handler = logging.StreamHandler(stream=sys.stderr)
    # logger = logging.getLogger('tornado.app_log')
    # logger.addHandler(handler)
    # logger.setLevel(logging.DEBUG)

    #  handlers = [handler]
    #  logger = logging.getLogger()
    #  logger.setLevel(logging.DEBUG)
    #  logger.addHandler(handler)

    #  logger.setLevel(logging.DEBUG)
    #  logger.addHandler(handler)

    formatter = LogFormatter(color=_stderr_supports_color())
    handler.setFormatter(formatter)
    logger = tornado.app_log
    logger

# Generated at 2022-06-22 03:59:11.872923
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

test_define_logging_options()

# Generated at 2022-06-22 03:59:17.848369
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # format(record: Any) -> str
    log = logging.getLogger()
    log.info('test info')
    log.debug('test debug')
    log.warning('test warning')
    log.error('test error')
    log.critical('test critical')

# method formatTime

# Generated at 2022-06-22 03:59:29.870241
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # test case 1
    # fmt = 'a_%(color)s_b_%(end_color)s'
    fmt = 'a_%(color)s_b_%(end_color)s_%(module)s'
    datefmt = ''
    style = None
    color = True
    colors = {
         logging.DEBUG: 4,  # Blue
         logging.INFO: 2,  # Green
         logging.WARNING: 3,  # Yellow
         logging.ERROR: 1,  # Red
         logging.CRITICAL: 5,  # Magenta
    }
    logFormatter = LogFormatter(fmt, datefmt, style, color, colors)
    record=dict()
    record['levelno']=logging.DEBUG
    record['module']="moduleA"
    logFormatter.format

# Generated at 2022-06-22 03:59:42.585538
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import optparse
    tornado.options._Options.__init__ = lambda self: None

    tornado.options.define = lambda *args: None
    tornado.options.options.logging = "none"
    tornado.options.options.log_to_stderr = False
    tornado.options.options.log_file_prefix = "test"
    tornado.options.options.log_file_max_size = 1024
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_rotate_when = 'midnight'
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_rotate_mode = "size"

    tornado.options.enable_pretty_logging = lambda *args: None
    define_log

# Generated at 2022-06-22 03:59:52.062895
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options

    define("logging", default="DEBUG")
    define("log_file_prefix", default='test.log')
    define("log_file_max_size", default=1000)
    define("log_file_num_backups", default=20)
    define("log_to_stderr", default=True)
    define("log_rotate_mode", default='time')
    define("log_rotate_when", default='S')
    define("log_rotate_interval", default=1)

    enable_pretty_logging()
    gen_log.error("This is a test error log")


# Generated at 2022-06-22 03:59:53.201012
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()



# Generated at 2022-06-22 04:00:05.137218
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        LogFormatter().format(logging.LogRecord("test", logging.DEBUG,
                                                pathname="", lineno=0,
                                                msg="Hello, world!",
                                                args=(), exc_info=None))
    except Exception as e:
        self.fail("format() raised %r" % e)
    try:
        LogFormatter().format(logging.LogRecord("test", logging.DEBUG,
                                                pathname="", lineno=0,
                                                msg="Unicode: \u2603",
                                                args=(), exc_info=None))
    except Exception as e:
        self.fail("format() raised %r" % e)



# Generated at 2022-06-22 04:00:27.846769
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()
test_define_logging_options()

# Generated at 2022-06-22 04:00:34.883049
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    # Check that the options are present on the default instance
    _ = tornado.options.options.log_to_stderr

    # Check that the options are present on a new instance
    define_logging_options(tornado.options.OptionParser())

    # Ensure that we can parse the default options
    with tornado.testing.gen_test(timeout=5) as t:
        t.stop()

# Generated at 2022-06-22 04:00:47.088199
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    log_formatter = LogFormatter(fmt=fmt,datefmt=datefmt,style=style,color=color,colors=colors)
    log_

# Generated at 2022-06-22 04:00:52.131844
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # pylint: disable=unused-variable

    # If it is not a dict, it should cause an error
    try:
        LogFormatter(colors=set([1, 2]))  # type: ignore
        raise Exception  # It shouldn't pass
    except Exception:
        pass



# Generated at 2022-06-22 04:00:59.599633
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    
    options = tornado.options.OptionParser()
    define_logging_options(options)
    
    # test define function
    assert options.define.__name__ == "define"
    
    # test add_parse_callback function
    assert options.add_parse_callback.__name__ == "add_parse_callback"
    assert options.add_parse_callback.__defaults__[0].__name__ == "enable_pretty_logging"

# Generated at 2022-06-22 04:01:00.533387
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    LogFormatter()

# Generated at 2022-06-22 04:01:04.339750
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    define("logging", default="debug", help="test logging")
    parse_command_line(["--logging=debug"])
    define_logging_options(options)

# Generated at 2022-06-22 04:01:16.321767
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    import io
    import logging
    import logging.config
    import logging.handlers

    # Enable color support

# Generated at 2022-06-22 04:01:27.366768
# Unit test for function define_logging_options

# Generated at 2022-06-22 04:01:31.216757
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    assert f._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"


# Generated at 2022-06-22 04:02:41.305150
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """Testing method LogFormatter.format"""
    from tornado.log import LogFormatter
    from tornado.options import options

    options.logging = "debug"
    LogFormatter.DEFAULT_FORMAT = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    LogFormatter.DEFAULT_DATE_FORMAT = "%y%m%d %H:%M:%S"

# Generated at 2022-06-22 04:02:52.314324
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    logger = logging.getLogger()
    str_io = StringIO()
    handler = logging.StreamHandler(str_io)
    try:
        formatter = LogFormatter()
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        old_level = logger.level
        logger.setLevel(logging.DEBUG)

        logger.critical("this is critical")
        logger.error("this is error")
        logger.warn("this is warn")
        logger.info("this is info")
        logger.debug("this is debug")

        logger.setLevel(old_level)
        logger.removeHandler(handler)
    except Exception as e:
        logger.error(e)


# Generated at 2022-06-22 04:03:01.716192
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.log_file_prefix = "log.txt"
    tornado.options.options.logging = "info"
    enable_pretty_logging()
    logger = logging.getLogger()
    logger.setLevel(logging.ERROR)
    assert logging.ERROR == logger.level
    logger.error('Error')
    logger.setLevel(logging.WARNING)
    assert logging.WARNING == logger.level
    logger.warning('Warning')
    logger.setLevel(logging.INFO)
    assert logging.INFO == logger.level
    logger.info('Info')
    logger.setLevel(logging.DEBUG)
    assert logging.DEBUG == logger.level
    logger.debug('Debug')

test_enable_pretty_logging()

# Generated at 2022-06-22 04:03:04.889064
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    tornado.options.define_logging_options(tornado.options.options)

# init options for tornado
define_logging_options()

# Generated at 2022-06-22 04:03:14.699884
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True)
    string_1 = formatter.format(logging.LogRecord("myLogger", 10, "C:/temp", 19, "hello", (), None)) 
    assert string_1.startswith('\x1b[2;34m[')
    assert string_1.endswith('    hello\x1b[0m')
    assert 'myLogger' in string_1
    assert 'C:/temp' in string_1
    assert 'Line 19' in string_1
    assert 'hello' in string_1


# Generated at 2022-06-22 04:03:22.399602
# Unit test for function define_logging_options
def test_define_logging_options():
    sys_log_level = logging.getLogger().getEffectiveLevel()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    define_logging_options()
    # print(tornado.options.options)
    tornado.options.parse_command_line()

    try:
        logging.getLogger().handlers[0].stream.close()
    except Exception:
        pass

    logging.getLogger().setLevel(logging.NOTSET)

    try:
        logging.getLogger().handlers[0].stream.close()
    except Exception:
        pass

    logging.getLogger().setLevel(sys_log_level)

if __name__ == '__main__':
    test_define_logging_options()