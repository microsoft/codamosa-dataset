

# Generated at 2022-06-22 03:53:54.780710
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import Options, define

    define("log_file_prefix", default=None, type=str)
    define("log_file_max_size", default=100000, type=int)
    define("log_file_num_backups", default=10, type=int)
    define("log_rotate_mode", default="size", type=str)
    define("log_rotate_when", default="S", type=str)
    define("log_rotate_interval", default=1, type=int)
    define("log_to_stderr", default=False, type=bool)
    define("logging", default="info", type=str)
    options = Options()
    options.logging = "debug"
    options.log_file_prefix = "log_file"
    enable_pretty_

# Generated at 2022-06-22 03:54:04.610808
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class Record(object):
        __slots__ = [
            "message",
            "asctime",
            "color",
            "end_color",
            "__dict__",
            "__weakref__",
            "levelno",
        ]

        def __init__(self, **kwargs: Any) -> None:
            for name, value in kwargs.items():
                setattr(self, name, value)

    record1 = Record(message=123, levelno=1, exc_text="exc_text")
    logger = LogFormatter()
    logger.format(record1)



# Generated at 2022-06-22 03:54:16.290539
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import io
    import sys
    import unittest
    import unittest.mock
    import tempfile

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            # Disable output when running unit tests.
            self.out = sys.stdout
            sys.stdout = io.StringIO()

        def tearDown(self):
            sys.stdout = self.out

        def test_log_file_settings(self):
            class Options:
                logging = "INFO"
                log_file_prefix = self.get_temp_file_name()
                log_file_num_backups = 5
                log_file_max_size = 1024
                log_to_stderr = False
                log_rotate_mode = "time"
                log_rot

# Generated at 2022-06-22 03:54:29.433654
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #log_format = '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'
    #datefmt = '%y%m%d %H:%M:%S'
    formatter = LogFormatter(datefmt='%y%m%d %H:%M:%S')
    record = logging.LogRecord(name='test', level=logging.INFO, pathname='test_log.py', lineno=1, msg='test', args=None, exc_info=None)
    record.asctime = formatter.formatTime(record, formatter.datefmt)
    assert record.asctime == '190910 18:04:58'

# Generated at 2022-06-22 03:54:34.735733
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    define_logging_options()
    tornado.options.parse_command_line(["argv"], [])
    tornado.options.parse_command_line(
        ["argv", "--logging=none", "--help"], [], print_help=False
    )

# Generated at 2022-06-22 03:54:41.627815
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
        import tornado.log
        import os
        tornado.log.enable_pretty_logging('DEBUG')
    except Exception as e:
        print('Exception at line {} in function {}:'.format(sys.exc_info()[-1].tb_lineno, sys.exc_info()[0].__name__))
        print(e)
        sys.exit()



# Generated at 2022-06-22 03:54:52.402153
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime as dt
    import unittest
    from tornado.log import LogFormatter

    class Foo:

        def __init__(self, message, **kwargs):
            self.message = message
            for attr in kwargs:
                setattr(self, attr, kwargs[attr])

    _colorama_available = True
    try:
        from colorama import Fore
    except ImportError:
        _colorama_available = False
    if not hasattr(logging, "NullHandler"):
        class NullHandler(logging.Handler):
            def handle(self, record):
                pass
            def emit(self, record):
                pass
            def createLock(self):
                self.lock = None
    # def setUpClass(cls):

# Generated at 2022-06-22 03:54:57.870944
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.root.setLevel(logging.DEBUG)
    formatter = LogFormatter(color=False)
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    logging.root.addHandler(console)

    logging.root.debug('test')


# Generated at 2022-06-22 03:55:06.645298
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = "warn"
    options.log_file_prefix = "test.log"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 10000
    options.log_file_num_backups = 10
    options.log_to_stderr = True
    enable_pretty_logging(options)
    gen_log.warn("Warning Log")
    gen_log.error("Error Log")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:55:15.790521
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import tornado.escape
    from tornado.log import _stderr_supports_color, LogFormatter, enable_pretty_logging
    from tornado.util import unicode_type

    tornado.options.enable_pretty_logging()
    logger = logging.getLogger()
    for i in range(100):
        logger.info("test_enable_pretty_logging")
    logger.setLevel(logging.DEBUG)
    for i in range(100):
        logger.debug("test_enable_pretty_logging")

# Generated at 2022-06-22 03:56:15.133409
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    enable_pretty_logging(None)
    enable_pretty_logging(logger=logging.getLogger())

# Generated at 2022-06-22 03:56:27.159608
# Unit test for function define_logging_options
def test_define_logging_options():
    """Test define_logging_options"""
    from tornado.testing import AsyncTestCase, gen_test
    import tornado
    import tornado.options

    class DefineLoggingOptionsTest(AsyncTestCase):
        """DefineLoggingOptionsTest"""

        @gen_test(timeout=5)
        def test_define_logging(self):
            """test_define_logging"""
        # pylint: disable=E1101
            tornado.options.parse_command_line(['./example'])
            define_logging_options()
            self.assertEqual('info', tornado.options.options.logging)
            self.assertFalse(tornado.options.options.log_to_stderr)
            self.assertEqual('', tornado.options.options.log_file_prefix)
            self.assertEqual

# Generated at 2022-06-22 03:56:35.817367
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = "info"
    options.log_file_prefix = "/tmp/t"
    options.log_rotate_mode = "size"
    options.log_file_max_size = 100
    options.log_file_num_backups = 1
    enable_pretty_logging(options)
    logger = logging.getLogger()
    logger.debug("this is DEBUG message")

# Generated at 2022-06-22 03:56:43.687867
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # use all of the default parameters
    logFormatter = LogFormatter()
    assert logFormatter._colors == {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    assert logFormatter._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert logFormatter._normal == ""

    #should get different colors with different logging levels

# Generated at 2022-06-22 03:56:54.800133
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter
    assert formatter.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s" # noqa: E501
    assert formatter.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert issubclass(LogFormatter, logging.Formatter)

# This dict contains an instantiated LogFormatter for each key.
_formatter_cache = {}  # type: Dict[Any, LogFormatter]



# Generated at 2022-06-22 03:56:56.225160
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 03:57:03.756654
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    formatter.datefmt = "%Y-%m-%d"
    assert formatter.datefmt == "%Y-%m-%d"
    formatter.formatTime(logging.LogRecord("tornado.test", logging.INFO, "", 0, "", (), None))  # noqa: E501
    assert formatter.format(logging.LogRecord("tornado.test", logging.INFO, "", 0, "", (), None))  # noqa: E501



# Generated at 2022-06-22 03:57:14.624643
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    LogFormatter.DEFAULT_FORMAT
    LogFormatter.DEFAULT_DATE_FORMAT
    LogFormatter.DEFAULT_COLORS
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    # 创建一个handler，用于写入日志文件
    # fh = logging.FileHandler('test.log')
    fh = logging.StreamHandler()
    # 再创建一个handler，用于输出到控制台
    ch = logging.StreamHandler()
    formatter = LogFormatter(color=True)
    # 定义handler的输出格式formatter
    fh.set

# Generated at 2022-06-22 03:57:26.231174
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import datetime
    record = logging.LogRecord('name', logging.WARNING, __file__, 42, 'msg', None, None)
    record.asctime = '%s-%02d-%02d %02d:%02d:%02d' % (
        datetime.datetime.now().year,
        datetime.datetime.now().month,
        datetime.datetime.now().day,
        datetime.datetime.now().hour,
        datetime.datetime.now().minute,
        datetime.datetime.now().second,
    )
    testObj = LogFormatter('%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s')
   

# Generated at 2022-06-22 03:57:38.758606
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    f = LogFormatter()
    r = logging.LogRecord('name', logging.INFO, 'filename', 21,
            'message', [], None)
    assert isinstance(f.format(r), str)
    assert f.format(r) == '[I filename:21] message'
    r.exc_info = True
    assert f.format(r) == '[I filename:21] message\n    None'
    r.exc_info = False
    r.exc_text = 'None'
    assert f.format(r) == '[I filename:21] message\n    None'
    r.message = '\n'
    assert f.format(r) == '[I filename:21] \n    None'
    r.message = '\n\n\n'
    r.exc_text = '\nNone'

# Generated at 2022-06-22 03:58:02.229121
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    # logger.setLevel(logging.DEBUG)
    import tornado.options
    tornado.options.options=object
    tornado.options.options.log_file_prefix = ""
    tornado.options.options.logging = "debug"
    tornado.options.options.log_to_stderr = None
    tornado.options.options.log_file_num_backups = 10
    tornado.options.options.log_file_max_size = 100
    tornado.options.options.log_rotate_mode = "size"
    # tornado.options.options.log_rotate_when = None
    # tornado.options.options.log_rotate_interval = None
    enable_pretty_logging()

    # import tornado.options
    # tornado.options.options=object
   

# Generated at 2022-06-22 03:58:08.012288
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("logging", default="warning", help="", type=str)
    tornado.options.define("log_file_prefix", default="", help="", type=str)
    try:
        tornado.options.parse_command_line()
    except SystemExit:
        pass
    enable_pretty_logging()

# Generated at 2022-06-22 03:58:12.537672
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.process
    tornado.process._is_main_process = lambda: True
    enable_pretty_logging(tornado.options.options)
    tornado.options.parse_command_line()
    tornado.options.options.logging = 'None'
    enable_pretty_logging(tornado.options.options)



# Generated at 2022-06-22 03:58:17.681966
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import os
    import time
    import sys
    import shutil
    tornado.options.options.log_rotate_mode = "size"
    tornado.options.options.log_file_prefix = "test_rotate"
    tornado.options.options.log_rotate_when = 'S'
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_max_size = 1
    tornado.options.options.log_file_num_backups = 1
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Test size rotate
    enable_pretty_logging()
    gen_log.debug("test")
    gen_log.debug("test")

# Generated at 2022-06-22 03:58:24.173920
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging

    logging.basicConfig(format="%(levelname)s:%(message)s")

    logging.info("before")
    tornado.options.parse_command_line(["--logging=debug", "--log_to_stderr=1"])
    logging.info("after")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:58:35.883716
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    l = logging.getLogger()
    stderr_handler = l.handlers[0]
    assert stderr_handler.formatter._fmt == '[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d] %(message)s'  # noqa: E501
    logger = logging.getLogger("tornado.application")
    assert logger.level == logging.INFO
    options = {
        "log_rotate_mode": "size",
        "log_file_prefix": "",
        "log_file_max_size": "",
        "log_file_num_backups": 0,
        "logging": "warning",
        "log_to_stderr": True,
    }

# Generated at 2022-06-22 03:58:37.212558
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(options)

# Generated at 2022-06-22 03:58:48.247700
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line()
    options.parse_config_file("./test_tornado.conf")
    assert options.log_to_stderr == False
    assert options.log_file_prefix == "./test_tornado.log"
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_mode == "size"
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 03:58:57.793648
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_config_file
    import os
    if not os.path.exists('./test.conf'):
        print('test_define_logging_options skip')
        return
    options.clear()
    try:
        define_logging_options(options)
        parse_config_file('./test.conf')
    except Exception as e:
        print(repr(e))
        assert False
    assert options.logging == 'error'
    assert options.log_to_stderr
    assert options.log_file_prefix == '/tmp/tornado.log'
    assert options.log_file_max_size == 1000
    assert options.log_file_num_backups == 3
    assert options.log_rotate_when == 'midnight'

# Generated at 2022-06-22 03:59:09.420547
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.parse_config_file('logging_option.cfg')
    options.define_logging_options(options)
    assert options.logging == 'info'
    assert options.log_to_stderr == True
    assert options.log_file_prefix == 'test.log'
    assert options.log_file_max_size == 100 * 1000 * 1000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == 'midnight'
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == 'size'

test_define_logging_options()

# Generated at 2022-06-22 03:59:23.392909
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.getLogger('tornado.application').info('hello')
    LogFormatter()


# Generated at 2022-06-22 03:59:24.106474
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 03:59:34.116643
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter(color=False)
    assert lf._colors == {}
    assert lf._normal == ""
    assert lf._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501

    lf = LogFormatter()
    assert lf._colors == {}
    assert lf._normal == ""
    assert lf._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501

    # non color
    lf = LogForm

# Generated at 2022-06-22 03:59:37.905312
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)
    # import ipdb; ipdb.set_trace()

test_define_logging_options()

# Generated at 2022-06-22 03:59:49.414606
# Unit test for function define_logging_options
def test_define_logging_options():
    parser = options.OptionParser()
    tornado.options._add_logging_options(parser)
    options, args = parser.parse_args(['--log_to_stderr',
                                       '--log_file_prefix=log/',
                                       '--log_rotate_when=S',
                                       '--log_rotate_interval=1',
                                       '--log_rotate_mode=time',
                                       '--log_file_max_size=20',
                                       '--log_file_num_backups=5'])
    tornado.options._define_logging_options(options, parser)
    assert options.log_to_stderr
    assert options.log_file_prefix == "log/"
    assert options.log_rotate_when == "S"
    assert options.log_

# Generated at 2022-06-22 03:59:52.417771
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter._fmt, str)
    assert formatter._colors is not None
    assert isinstance(formatter._normal, str)
    assert formatter.datefmt is not None


# Generated at 2022-06-22 04:00:05.536721
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options
    define("foo")
    define("bar", default=1)
    define("baz", type=int)
    define("qux", type=int, multiple=True)
    define("quux", type=int, multiple=True, callback=lambda: None)
    define_logging_options(options)
    assert "logging" in options.defaults
    assert "log_to_stderr" in options.defaults
    assert "log_file_prefix" in options.defaults
    assert "log_file_max_size" in options.defaults
    assert "log_file_num_backups" in options.defaults
    assert "log_rotate_when" in options.defaults
    assert "log_rotate_interval" in options.defaults

# Generated at 2022-06-22 04:00:16.506226
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=False)
    record = logging.LogRecord("tornado.application", logging.ERROR,
                               __file__, None,
                               "Test message with '%(co_flags)s' in it",
                               (), "fake_cause", None)
    expected = ("Test message with '%(co_flags)s' in it")
    assert formatter.format(record) == expected
    record = logging.LogRecord("tornado.application", logging.ERROR,
                               __file__, None,
                               "Test message with '%%(co_flags)s' in it",
                               (), "fake_cause", None)
    assert formatter.format(record) == expected
    formatter = LogFormatter(color=True)
    assert formatter.format(record) == expected



# Generated at 2022-06-22 04:00:26.084517
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.Logger.root.handlers = []
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    formatter = LogFormatter()
    channel = logging.StreamHandler()
    channel.setFormatter(formatter)
    logger.addHandler(channel)

    logger.info("testing info")
    logger.debug("testing debug")
    logger.warning("testing warning")
    logger.error("testing error")
    logger.critical("testing critical")

    logger.addFilter(lambda r: r.levelno<= 30) # _log_record_template



# Generated at 2022-06-22 04:00:29.159940
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)

    import tornado.testing
    tornado.testing.main()

# Generated at 2022-06-22 04:00:47.418761
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.log_file_prefix = "logs/tornado"
    options.parse_command_line()

# Generated at 2022-06-22 04:00:55.483126
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.application",
        level=logging.DEBUG,
        pathname="test_logging.py",
        lineno=24,
        msg="test_message",
        args=(),
        exc_info=None,
    )
    formatted = log_formatter.format(record)
    assert formatted == "\x1b[34m[D test_logging.py:24]\x1b[0m test_message"



# Generated at 2022-06-22 04:00:59.866426
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert hasattr(LogFormatter(), '_colors')

# Default formatting for logging handlers.
_DEFAULT_LOGGING_FORMATTER = LogFormatter()

# Custom StreamHandler which supports color output on Windows.



# Generated at 2022-06-22 04:01:10.450113
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options, parse_config_file, \
                        parse_command_line, print_help, print_config
    options = options
    define_logging_options(options)
    parse_config_file("./test_tornado_logging.conf")
    parse_command_line(["--log_rotate_when=s","--log_file_max_size=1024"])
    print_config()
    print_help()
    options.print_help()
    options.print_config()
    options.log_rotate_when
    options.log_file_max_size
if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 04:01:15.993429
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    print("")
    print("Calling function test_LogFormatter_format.. ")
    print("")
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    log.addHandler(handler)
    handler.setFormatter(LogFormatter())
    log.info("info message")
    assert True

# Generated at 2022-06-22 04:01:25.272392
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import options
    options.log_to_stderr = True
    options.log_file_prefix = None
    options.log_file_max_size = 1024
    options.log_file_num_backups = 3
    options.log_rotate_mode = 'size'
    options.log_rotate_when = 'S'
    options.log_rotate_interval = 1
    options.logging = 'debug'
    enable_pretty_logging()
    
if __name__ == "__main__":
    test_enable_pretty_logging()
    print("Test Successful")

# Generated at 2022-06-22 04:01:27.863461
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  assert callable(enable_pretty_logging)

# Generated at 2022-06-22 04:01:40.009385
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import collections
    import logging
    LogRecord = collections.namedtuple(
        "LogRecord", "msg args exc_info exc_text levelno levelname name pathname lineno funcName"  # noqa: E501
    )
    asctime = "20181023 03:46:22"
    record = LogRecord(
        msg="hello, world!",
        args=(),
        exc_info=None,
        exc_text=None,
        levelno=logging.INFO,
        levelname="INFO",
        name="tornado.general",
        pathname="logging_test.py",
        lineno=14,
        funcName="test_LogFormatter_format",
    )
    formatter = LogFormatter()

# Generated at 2022-06-22 04:01:43.831868
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define

    define("logging", default="info", help="Set the Python log level.")
    options = define_logging_options()
    print(options)

test_define_logging_options()

# Generated at 2022-06-22 04:01:48.254564
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    
    opt = tornado.options.define('logging', 'none', None, None)
    tornado.options.parse_command_line()
    enable_pretty_logging(opt)
    gen_log.info("hello, world")
    
if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:02:09.291173
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    import os
    os.environ["ANSI_COLORS_DISABLED"] = "1"

    formatter = LogFormatter()
    assert formatter._normal == ""
    assert list(formatter._colors.values()) == []

    os.environ["ANSI_COLORS_DISABLED"] = ""

    formatter = LogFormatter()
    assert formatter._normal != ""
    assert list(formatter._colors.values()) != []

# Generated at 2022-06-22 04:02:21.096501
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import time
    import tornado.log
    import tornado.process
    from tornado.log import gen_log
    from datetime import timedelta
    _test_handler = logging.StreamHandler()
    _test_handler.setLevel(logging.DEBUG)
    log = logging.getLogger()
    log.propagate = False
    log.handlers = []
    log.setLevel(logging.DEBUG)
    log.addHandler(_test_handler)

    # Test exception
    class MyException(Exception):
        pass
    try:
        raise MyException('test exception')
    except Exception:
        gen_log.exception('exception')
    # Test multiline exception
    try:
        pass
    except:
        gen_log.exception('test multiline exception')
    # Test record of

# Generated at 2022-06-22 04:02:30.467330
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    define("logging", default=None)
    define("log_file_prefix", default="")
    define("log_file_max_size", default=None)
    define("log_file_num_backups", default=None)
    define("log_rotate_mode", default="None")
    define("log_rotate_when", default="None")
    define("log_rotate_interval", default="None")
    define("log_to_stderr", default=None)
    # ensure that logging gets configured even though logging.log is not called
    enable_pretty_logging()

# Generated at 2022-06-22 04:02:34.984780
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import unittest
    import tornado.options
    import tornado.log

    options = tornado.options.options

    class LoggingTest(unittest.TestCase):
        def test_enable_pretty_logging(self):
            tornado.log.enable_pretty_logging(options, logger=gen_log)

# Generated at 2022-06-22 04:02:47.171994
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options
    from tornado.log import app_log, access_log
    define('logging')
    options.logging = 'dEBUg'
    enable_pretty_logging()
    app_log.debug('debug')
    app_log.info('info')
    app_log.warn('warn')
    app_log.error('error')
    app_log.critical('critical')
    access_log.debug('debug')
    access_log.info('info')
    access_log.warn('warn')
    access_log.error('error')
    access_log.critical('critical')
    # assert app_log.level == 10
    # assert access_log.level == 10

if __name__=='__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:02:51.449585
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger('tornado.test_LogFormatter')
    logger.setLevel(logging.DEBUG)
    formatter = LogFormatter(color=False)
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.debug('This is a test message.')


# Generated at 2022-06-22 04:03:01.601819
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import datetime
    logging.basicConfig(filename='format.log', level=logging.DEBUG)
    dt_fmt = "%Y-%m-%d %H:%M:%S"
    fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    datefmt = dt_fmt
    formatter = LogFormatter(fmt=fmt, datefmt=datefmt, color=True)
    handler = logging.FileHandler(filename='format.log')
    handler.setFormatter(formatter)
    logger = logging.getLogger(__name__)
    logger.addHandler(handler)

# Generated at 2022-06-22 04:03:03.780804
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = {"logging": "none"}
    enable_pretty_logging(options)

# Generated at 2022-06-22 04:03:15.340232
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # We may have color, but nothing to write to (os.isatty() fails)
    color = LogFormatter.DEFAULT_COLORS.get(logging.DEBUG)
    if curses:  # type: ignore
        assert curses.tigetstr("setaf")
        assert curses.tigetstr("setf")

    # We have color support and a terminal
    class FakeStream(str):
        def isatty(self):
            return True
    try:
        del sys.stderr
        sys.stderr = FakeStream()  # type: ignore
    except Exception:
        pass

    formatter = LogFormatter()
    # Test the actual value
    assert color in formatter._colors

    # Test end_color was set
    assert formatter._normal



# Generated at 2022-06-22 04:03:20.626938
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None,logger)
    assert logger.setLevel(logging.DEBUG)
    enable_pretty_logging(options)
    assert options.log_to_stderr(False)
    
    
    # n.b. Colorama's implicit initialization causes a performance
    # regression that makes it unusable in most applications.
    channel.setFormatter(LogFormatter(color=False))
    logger.addHandler(channel)