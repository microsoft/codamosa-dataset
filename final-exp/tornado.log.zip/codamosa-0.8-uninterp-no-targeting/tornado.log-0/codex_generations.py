

# Generated at 2022-06-22 03:53:50.756371
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():

    logging.basicConfig()

    # make sure the log level is the same
    logger = logging.getLogger()
    logger.setLevel("INFO")
    assert logger.level == logging.INFO

    enable_pretty_logging(None, logger)
    assert logger.level == logging.INFO

# Generated at 2022-06-22 03:53:59.902132
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options as options
    except ImportError as e:
        print(e)
    options.define("log_file_max_size", 100)
    options.define("log_file_prefix", "hello")
    options.define("log_rotate_mode", "size")
    options.define("log_file_num_backups", 5)
    options.define("logging", "none")
    options.define("log_rotate_when", "s")
    options.define("log_rotate_interval", 1)
    options.define("log_to_stderr", True)
    enable_pretty_logging(options)

# Generated at 2022-06-22 03:54:04.557591
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.config = {'logging': 'None', 'log_file_prefix': True, 'log_rotate_mode': 'size', 'log_file_max_size': True, 'log_file_num_backups': True, 'log_to_stderr': True}
    enable_pretty_logging(logging, access_log)
    assert access_log.level == logging.INFO
    assert app_log.level == logging.INFO
    assert gen_log.level == logging.INFO


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:54:16.254722
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True, fmt='%(color)s%(levelname)s%(end_color)s %(asctime)s %(message)s')
    record = logging.LogRecord(level=logging.CRITICAL, message="test", args=None, exc_info=None, extra=None, name=None)
    assert formatter.format(record) == "\033[2;35mCRITICAL\033[0m test"
    record = logging.LogRecord(level=logging.CRITICAL, message=b"test", args=None, exc_info=None, extra=None, name=None)
    assert formatter.format(record) == "\033[2;35mCRITICAL\033[0m test"

# Generated at 2022-06-22 03:54:22.224138
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class obj(object):
        message = "_safe_unicode(message)"
        asctime = "self.formatTime(record, cast(str, self.datefmt))"
        levelno = 3
        __dict__={}
    lf = LogFormatter()
    lf.format(obj())


# Generated at 2022-06-22 03:54:34.628480
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import os
    tornado.options.define("logging", default=None, help="Logging level")
    tornado.options.define("log_to_stderr", default=None, help="Log to stderr")
    tornado.options.define("log_file_prefix", default=None, help="Log file prefix")
    if os.path.exists("test.log"):
        os.remove("test.log")
    tornado.options.parse_command_line(args=["--log_file_prefix=test.log"])
    tornado.log.enable_pretty_logging()
    tornado.options.options.log_to_stderr = False
    tornado.options.options.logging = "debug"
    tornado.log.access_log.debug("debug")


# Generated at 2022-06-22 03:54:46.163515
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter
    import logging
    import logging.handlers

    # logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = LogFormatter()
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)

    # 'application' code
    logger.debug("debug message")
    logger.info("info message")
    logger.warn("warn message")
    logger.error("error message")
    logger.critical("critical message")

# Generated at 2022-06-22 03:54:47.635673
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
   """
   testing enable_pretty_logging
   """
   return

# Generated at 2022-06-22 03:54:50.226054
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logformatter = LogFormatter();
# Test for function _stderr_supports_color

# Generated at 2022-06-22 03:54:58.456501
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = dict(
        logging = "warn",
        log_file_prefix = None,
        log_rotate_mode = "size",
        log_file_max_size = 2,
        log_file_num_backups = 3,
        log_rotate_when = "w",
        log_rotate_interval = 1,
        log_to_stderr = False,
    )
    enable_pretty_logging(options)
    enable_pretty_logging(None)


# Generated at 2022-06-22 03:55:24.882956
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lg = LogFormatter(color = False)
    assert len(lg.format(logging.LogRecord('test', logging.DEBUG, 'msg', 'fn', 'ln', 'msg', 'ar', None))) > 0
    assert len(lg.format(logging.LogRecord('test', logging.INFO, 'msg', 'fn', 'ln', 'msg', 'ar', None))) > 0
    assert len(lg.format(logging.LogRecord('test', logging.WARNING, 'msg', 'fn', 'ln', 'msg', 'ar', None))) > 0
    assert len(lg.format(logging.LogRecord('test', logging.ERROR, 'msg', 'fn', 'ln', 'msg', 'ar', None))) > 0

# Generated at 2022-06-22 03:55:25.888340
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert True


# Generated at 2022-06-22 03:55:38.428357
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    options = tornado.options.Options()
    define_logging_options(options)
    options.parse_command_line()
    enable_pretty_logging(options)
    # Check log rotate mode size
    logger = logging.getLogger()
    logger.info("Check log rotate mode size")
    logger.info("Check log rotate mode size")
    logger.info("Check log rotate mode size")
    logger.info("Check log rotate mode size")
    # Check log rotate mode time
    options.log_rotate_mode = "time"
    options.log_to_stderr = True
    options.log_file_prefix = "log/tornado_test_time.log"
    enable_pretty_logging(options)
    logger = logging.getLogger()

# Generated at 2022-06-22 03:55:49.239859
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """
    Test LogFormatter.format against an invalid message (contains a non-bytes and non-unicode string).
    """
    import logging
    import tornado.log
    from unittest import mock
    from io import StringIO
    from tornado import iostream
    stream=StringIO()
    handler=tornado.log.LogFormatter()
    formatter=logging.Formatter(
        fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt='%m/%d/%Y %I:%M:%S %p')
    handler.setFormatter(formatter)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

# Generated at 2022-06-22 03:56:00.329362
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.testing
    import logging

    class TestOptions(tornado.options.Options):
        def __init__(self):
            super(TestOptions, self).__init__()
            self.logging = "DEBUG"
            self.log_file_prefix = ""
            self.log_to_stderr = True
            self.log_rotate_mode = "time"
            self.log_rotate_when = "midnight"
            self.log_rotate_interval = 1
            self.log_file_num_backups = 5

    class EnablePrettyLoggingTest(tornado.testing.AsyncTestCase):
        def test_enable_pretty_logging(self):
            options = TestOptions()
            enable_pretty_logging(options)
            log_file_handler = logging

# Generated at 2022-06-22 03:56:02.016538
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)
    LogFormatter()
    assert 1 == 1



# Generated at 2022-06-22 03:56:11.970046
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    args = ["--logging=debug", "--log_to_stderr=false","--log_file_prefix=test.log",
            "--log_file_max_size=1024", "--log_file_num_backups=3",
            "--log_rotate_when=S", "--log_rotate_interval=10",
            "--log_rotate_mode=size"]
    options.parse_command_line(args)
    assert tornado.options.options.log_to_stderr == False

# Generated at 2022-06-22 03:56:23.927463
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    f = LogFormatter()
    fmt = f._fmt
    datefmt = f.datefmt
    colors = f._colors
    normal = f._normal

    # Default
    if fmt != LogFormatter.DEFAULT_FORMAT \
            or datefmt != LogFormatter.DEFAULT_DATE_FORMAT \
            or colors != LogFormatter.DEFAULT_COLORS \
            or normal != "\033[0m":
        raise Exception('LogFormatter DEFAULT_FORMAT dont match')

    # Not default
    f = LogFormatter(
        fmt='%(levelname)s %(asctime)s %(module)s:%(lineno)d %(message)s',
        datefmt='%y%m%d %H:%M:%S')

    fmt = f._fmt

# Generated at 2022-06-22 03:56:26.706957
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    formatter.format(logging.LogRecord('foo', logging.DEBUG, 'test.py', 1, '', None, None))


# Generated at 2022-06-22 03:56:39.454517
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options
    from tornado.log import LogFormatter
    from tornado.options import define, options
    define("log_to_stderr", type=bool, default=False)
    define("log_file_prefix", type=str, default=None)
    enable_pretty_logging(options)
    x = logging.getLogger().handlers[0]
    assert type(x.formatter) == LogFormatter
    logging.info("test")
    assert "test" in x.formatter.format(logging.getLogger().makeRecord(None, logging.INFO, "test")).strip()
    define("log_to_stderr", type=bool, default=True)
    define("log_file_prefix", type=str, default="/tmp/test.txt")
    enable_pretty_

# Generated at 2022-06-22 03:56:53.748025
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    assert len(logger.handlers) == 0
    enable_pretty_logging(options=None, logger=logger)
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)


if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:56:58.148621
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.enable_pretty_logging()

if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    test_enable_pretty_logging()
    logging.debug("debug")

# Generated at 2022-06-22 03:57:02.589537
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    fmt = "%(color)s%(levelname)1.1s %(asctime)s.%(msecs)03d %(module)s:%(lineno)d%(end_color)s %(message)s"  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    formatter = LogFormatter(fmt, datefmt)
    formatter = LogFormatter()



# Generated at 2022-06-22 03:57:14.078454
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import os
    import tempfile 
    fd0, file0 = tempfile.mkstemp()
    fmt = LogFormatter()
    assert fmt.format(logging.LogRecord("tornado.access", 1, "1", 2, "3",
        (None, "5", None), None)) == "[\x1b[2;37m1 \x1b[2;37m1:2]\x1b[0m 3"


if __name__ == "__main__":
    import sys
    import logging
    import os
    import tempfile
    fd0, file0 = tempfile.mkstemp()
    logging.basicConfig(level=logging.DEBUG, filename=file0, format="%(message)s")
    test_LogFormatter_format()
    f = open(file0)


# Generated at 2022-06-22 03:57:23.406541
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class M(object):
        def __init__(self, **props):
            self.__dict__.update(props)
    f = LogFormatter()
    assert f.format(M(msg="hi", levelname="WARN")) == "hi"
    assert f.format(M(msg="hi", levelname="WARN", color="blue")) == "hi"
    assert f.format(M(msg="hi", levelname="WARN", color="blue", end_color="end_blue")) == "hi"
    #
    f = LogFormatter(color=False)
    assert f.format(M(msg="hi", levelname="WARN")) == "hi"
    assert f.format(M(msg="hi", levelname="WARN", color="blue")) == "hi"

# Generated at 2022-06-22 03:57:29.964063
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(datefmt="%Y/%m/%d %H:%M:%S")
    record = logging.LogRecord('test', logging.INFO, 'test_file', 1, 'test', (), None, 'test_func')
    formatted = formatter.format(record)
    assert formatted[0:4] == '[I '



# Generated at 2022-06-22 03:57:32.265681
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    print(options)

test_define_logging_options()

# Generated at 2022-06-22 03:57:33.795965
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    options = logging.option


test_enable_pretty_logging()

# Generated at 2022-06-22 03:57:45.941841
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    """Unit test for method format of class LogFormatter"""
    #given
    formatter = LogFormatter()
    record = logging.LogRecord(
        name="tornado.access",
        level=logging.DEBUG,
        pathname="",
        lineno=0, msg="Test",
        args=(),
        exc_info=None,
    )
    #when
    formatted = formatter.format(record)
    #then
    assert formatted == '[D %s %s] Test' % (
            record.asctime.split(' ')[0], record.module)
    #given

# Generated at 2022-06-22 03:57:59.344711
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    print('test_enable_pretty_logging-------------------------------')
    import tornado.options
    tornado.options.options.logging = 'DEBUG'
    tornado.options.options.log_file_prefix = '/Users/wangrenguang/log/test.log'
    tornado.options.options.log_rotate_mode = 'size'
    tornado.options.options.log_file_max_size = 1000
    tornado.options.options.log_file_num_backups = 3
    print('enable_pretty_logging')
    enable_pretty_logging()
    print('app_log.debug')
    app_log.debug('app_log')
    print('app_log.error')
    app_log.error('app_log')
    print('app_log.info')

# Generated at 2022-06-22 03:58:12.575109
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # pylint: disable=protected-access
    log_formatter = LogFormatter()
    assert log_formatter._fmt == LogFormatter.DEFAULT_FORMAT
    assert log_formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert log_formatter._colors == LogFormatter.DEFAULT_COLORS
    assert log_formatter._normal == LogFormatter._normal



# Generated at 2022-06-22 03:58:20.288544
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # noqa: E501,F811
    # all we really want to test is that this compiles, since
    # it will be executed at import time
    logFormatter = LogFormatter(fmt="%(color)s%(levelname)s%(end_color)s %(message)s")
    return logFormatter


# Generated at 2022-06-22 03:58:30.219806
# Unit test for function define_logging_options
def test_define_logging_options():
    # First, check the default values:
    import tornado.options
    options = tornado.options.options
    assert options.logging == "info"
    assert options.log_to_stderr is None
    assert options.log_file_prefix is None
    assert options.log_file_max_size == 100000000
    assert options.log_file_num_backups == 10
    assert options.log_rotate_when == "midnight"
    assert options.log_rotate_interval == 1
    assert options.log_rotate_mode == "size"
    # Now create a new OptionParser and add the options to it
    new_parser = tornado.options.OptionParser()
    define_logging_options(new_parser)
    # There should be a callback attached to this parser.
    # It depends on options to be

# Generated at 2022-06-22 03:58:36.548861
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    '''
    测试方法 format 实例'''
    formatter = LogFormatter(color=True)
    record = logging.makeLogRecord(
        {"msg":"messg", "levelno":logging.DEBUG, "levelname":"ERROR", "color":True})
    print(formatter.format(record))

if __name__ == '__main__':
    test_LogFormatter_format()

# Generated at 2022-06-22 03:58:41.119221
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert lf._normal == ""
    assert lf._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert lf.datefmt == "%y%m%d %H:%M:%S"
    assert lf._colors == {}



# Generated at 2022-06-22 03:58:43.956097
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.OptionParser()
    define_logging_options(options)
    options.parse_command_line()

# Exposing logging methods to the application

# Generated at 2022-06-22 03:58:47.741644
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options(tornado.options.options)

# Generated at 2022-06-22 03:58:48.749480
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 03:58:51.543163
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logFormatter = LogFormatter()
    # the LogFormatter instance should not be None
    assert logFormatter is not None


# Generated at 2022-06-22 03:58:59.316640
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter(color=True)
    record = logging.LogRecord(
        name='tornado.access',
        level=20,
        # the following attrs are required
        pathname='',
        lineno=0,
        msg='',
        # args=None,
        exc_info=None,
    )
    result = formatter.format(record)
    assert result == '\x1b[0;36m[I 0000000000 :00]\x1b[0m '


# Suppress warnings about AccessLogFormatter's __init__ not being a method.
# (access_log was never a class, so it makes sense that it doesn't have a
# constructor).
# pylint: disable=no-init,old-style-class

# Generated at 2022-06-22 03:59:13.817502
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class FakeRecord(object):
        __slots__ = ["levelno", "message", "asctime", "exc_info", "exc_text"]

        def __init__(self, **kwargs: Any) -> None:
            self.__dict__.update(kwargs)

    def test(expected: Optional[str], **kwargs: Any) -> None:
        record = FakeRecord(**kwargs)
        formatter = LogFormatter()
        result = formatter.format(record)
        if result != expected:
            print("{!r} != {!r}".format(result, expected))
            raise AssertionError()

    # Simple message
    test("[I 0123456789] foo", message="foo")
    # Exception text with multiple lines

# Generated at 2022-06-22 03:59:25.022456
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    #logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger("test_LOG")
    log.warning("%d%%" "%")
    log.info("%d%%"%100)
    log.warning("%d-%d%%"%(100,200))
    log.warning("%s-%s%%"%"a","b")
    log.info("%s-%s%%"%("a","b"))
test_LogFormatter_format()

TornadoLogFormatter = LogFormatter
dictConfigClass = logging.config.dictConfig

# alias for backwards compatibility
LogFormatter = TornadoLogFormatter



# Generated at 2022-06-22 03:59:26.943069
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 03:59:29.870189
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    assert enable_pretty_logging(_options) is None
    assert enable_pretty_logging(_options) is None
    assert enable_pretty_logging(_options, _logger) is None



# Generated at 2022-06-22 03:59:33.723934
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.options
    define_logging_options(options)
    print(options.logging)

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-22 03:59:40.957939
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    class TesOptions:
        logging = "info"
        log_file_prefix = "log.txt"
        log_rotate_mode = "time"
        log_rotate_when = "S"
        log_rotate_interval = 1
        log_file_num_backups = 5
        log_to_stderr = False
    
    logger = logging.getLogger()
    enable_pretty_logging(TesOptions(), logger)

# Generated at 2022-06-22 03:59:52.802029
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.OptionParser()
    define_logging_options(options)

    options.parse_command_line(
        [
            "--logging",
            "info",
            "--log_to_stderr",
            "True",
            "--log_file_prefix",
            "/log/path",
            "--log_file_max_size",
            "10000000",
            "--log_file_num_backups",
            "11",
            "--log_rotate_when",
            "midnight",
            "--log_rotate_interval",
            "2",
            "--log_rotate_mode",
            "size",
        ]
    )
    # Ensure that options are parsed correctly

# Generated at 2022-06-22 03:59:56.206161
# Unit test for function define_logging_options
def test_define_logging_options():
    """
    Unit test for function define_logging_options
    """
    define_logging_options()
    logging.debug("hello")

# Generated at 2022-06-22 04:00:08.441212
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, logging
    import logging
    import sys
    import os
    import unittest
    import StringIO
    import tempfile

    def dummy_options():
        define("logging", "debug")
        define("log_to_stderr", 0)
        define("log_file_prefix", "")
        define("log_file_max_size", 100)
        define("log_file_num_backups", 0)
        define("log_rotate_mode", "time")
        define("log_rotate_when", "D")
        define("log_rotate_interval", 1)

    fileno, filename = tempfile.mkstemp()
    os.close(fileno)


# Generated at 2022-06-22 04:00:10.776565
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    # Just try to call the method, no further verification.

# Generated at 2022-06-22 04:00:25.341777
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)
    options = parser.parse_args()
    print(options.logging)



if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 04:00:36.761386
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.log import define_logging_options, gen_log
    from tornado.options import define, options, parse_command_line
    define("log_to_stderr", default=True)
    define("log_file_prefix", default="./test.log")
    define("log_file_max_size", default=10 * 1000 * 1000)
    define("log_file_num_backups", default=10)
    define("log_rotate_when", default="midnight")
    define("log_rotate_interval", default=1)
    define("log_rotate_mode", default="size")
    define_logging_options(options)
    parse_command_line()
    gen_log.error("1yyyyyyyyyyyyyyyyyyyyyyy")

# Generated at 2022-06-22 04:00:50.204714
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    from tornado.options import define, options
    define("logging", type=str, default="debug")
    define("log_file_prefix", type=str, default="log/tornado.log")
    define("log_to_stderr", type=bool, default=False)
    define("log_rotate_mode", type=str, default="size")
    define("log_file_max_size", type=int, default=100 * 1000 * 1000)
    define("log_file_num_backups", type=int, default=10)
    define("log_rotate_when", type=str, default="H")
    define("log_rotate_interval", type=int, default=1)
    enable_pretty_logging()
    logger = logging.getLog

# Generated at 2022-06-22 04:00:51.945370
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    
    tornado.options.define_logging_options()


# Generated at 2022-06-22 04:01:01.334089
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define("log_rotate_mode",default='size',help="The mode of rotating files(time or size)")
    tornado.options.parse_command_line("--log_rotate_mode time".split(" "))
    print("log_rotate_mode:"+tornado.options.options.log_rotate_mode)
    if ( tornado.options.options.log_rotate_mode != 'time'):
        print("test_define_logging_options failed")
    else:
        print("test_define_logging_options success")
# test_define_logging_options()

# Generated at 2022-06-22 04:01:13.518661
# Unit test for function define_logging_options
def test_define_logging_options():
    import  tornado.options
    options = tornado.options.define_logging_options
    options.define(
        "logging",
        default="info",
        help=(
            "Set the Python log level. If 'none', tornado won't touch the "
            "logging configuration."
        ),
        metavar="debug|info|warning|error|none",
    )
    options.define(
        "log_to_stderr",
        type=bool,
        default=None,
        help=(
            "Send log output to stderr (colorized if possible). "
            "By default use stderr if --log_file_prefix is not set and "
            "no other logging is configured."
        ),
    )

# Generated at 2022-06-22 04:01:16.861333
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter.__init__.__annotations__ == {
        "fmt": str,
        "datefmt": str,
        "style": str,
        "color": bool,
        "colors": Dict[int, int],
    }



# Generated at 2022-06-22 04:01:27.728770
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Remove env vars used by colorama to avoid color text output in tests
    import os
    from tornado.test.util import unittest

    env = os.environ
    for k in ["TERM", "ANSICON", "ConEmuANSI"]:
        if k in env:
            del env[k]

    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            self.log_record = logging.LogRecord(
                name="tornado.test",
                level=logging.DEBUG,
                pathname=None,
                lineno=None,
                msg="%(foo)s %(bar)s",
                args=None,
                exc_info=None,
            )
            self.log_record.foo = 1

# Generated at 2022-06-22 04:01:29.902527
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = "debug"
    enable_pretty_logging()

# Generated at 2022-06-22 04:01:41.883384
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
	import tornado.options
	import tornado.log
	tornado.options.define("logging", default="none", type=str,
                             metavar="level",
                             help="Logging level, one of none, " 
                             "debug, info, warning, error, or critical")
	tornado.options.define("log_to_stderr", type=bool, default=True,
                             help="log to stderr instead of files (ignored "
                             "if log_file_prefix is set)")
	tornado.options.define("log_file_prefix", type=str,
                             help="Path prefix for log files")
	tornado.options.define("log_file_max_size", type=int, default=1024,
                             help="max size of log files before rollover")
	tornado

# Generated at 2022-06-22 04:02:02.340907
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)

# Generated at 2022-06-22 04:02:06.597332
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        import tornado.options
        import tornado.log

        class options1(tornado.options.options):
            logging = None
        assert tornado.log.enable_pretty_logging(options1) == None
    except:
        return

# Generated at 2022-06-22 04:02:17.915382
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from datetime import datetime
    
    log_formatter = LogFormatter("%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s", "%y%m%d %H:%M:%S", "%")
    record = logging.LogRecord("name", logging.DEBUG, "/home/", 1, "message", args=(), exc_info=None, func="func")
    record.asctime = datetime.now()
    record.lineno = 3
    record.levelno = logging.DEBUG
    record.module = "module"
    record.message = "message"


# Generated at 2022-06-22 04:02:18.606435
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    assert True



# Generated at 2022-06-22 04:02:20.518306
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    from IPython import embed
    embed()
    formatter = LogFormatter()
    print(formatter)


# Generated at 2022-06-22 04:02:25.570360
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    gen_log.debug("DEBUG")
    gen_log.info("INFO")
    gen_log.warning("WARNING")
    gen_log.error("ERROR")
    gen_log.critical("CRITICAL")

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-22 04:02:30.369138
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    class Options(tornado.options.OptionParser):
        pass
    define_logging_options(Options())
    options = Options()
    options.parse_command_line()


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 04:02:31.974813
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    obj = LogFormatter()
    assert(isinstance(obj, LogFormatter))



# Generated at 2022-06-22 04:02:38.729739
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    class record:
        levelno = logging.INFO
        asctime = "date"
        exc_info = ""
        message = "message"
    record.__dict__ = {
        'levelno': logging.INFO,
        'asctime': 'date',
        'exc_info': '',
        'message': 'message'
    }
    lf.format(record)


# Generated at 2022-06-22 04:02:49.699469
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)

    # Test if options has been defined
    import tornado.options
    options = tornado.options.options
    option_names = options.keys()
    assert 'logging' in option_names
    assert 'log_to_stderr' in option_names
    assert 'log_file_prefix' in option_names
    assert 'log_file_max_size' in option_names
    assert 'log_file_num_backups' in option_names
    assert 'log_rotate_when' in option_names
    assert 'log_rotate_interval' in option_names
    assert 'log_rotate_mode' in option_names
