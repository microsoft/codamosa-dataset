

# Generated at 2022-06-22 03:53:30.503365
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    f = LogFormatter()
    h = logging.StreamHandler()
    h.setFormatter(f)
    logger.addHandler(h)
    logger.warn("this is a test")


# Generated at 2022-06-22 03:53:41.637821
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    _fmt = LogFormatter(color=False)
    assert _fmt.DEFAULT_FORMAT == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert _fmt.DEFAULT_DATE_FORMAT == "%y%m%d %H:%M:%S"
    assert _fmt.DEFAULT_COLORS == {logging.DEBUG: 4, logging.INFO: 2, logging.WARNING: 3, logging.ERROR: 1, logging.CRITICAL: 5}  # noqa: E501

# Generated at 2022-06-22 03:53:48.025622
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_command_line
    from tornado.options import OptionParser, LogFormatter
    options.logging='debug'
    options.log_to_stderr=True
    options.log_file_prefix='/home/log_file'
    options.log_file_max_size=100
    options.log_file_num_backups=10
    options.log_rotate_when='midnight'
    options.log_rotate_interval=1
    options.log_rotate_mode='size'
    # test the method enable_pretty_logging
    enable_pretty_logging = test_define_logging_options.__globals__.get('enable_pretty_logging')
    print(enable_pretty_logging)

# Generated at 2022-06-22 03:53:52.903429
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.logging = "debug"
    enable_pretty_logging(options)
    # import pdb; pdb.set_trace()
    logging.debug("this is a test")

if __name__ == '__main__':
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:54:05.476960
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options as options
    import tornado.log as log
    import logging as logging
    options.define("logging", default="none")
    options.parse_command_line()
    enable_pretty_logging(options.options)
    log.app_log.debug("testing debug")
    log.app_log.info("testing info")
    log.app_log.warning("testing warning")
    log.app_log.error("testing error")
    log.app_log.critical("testing critical")
    options.define("log_file_prefix", default="test_logging.log")
    options.parse_command_line()
    enable_pretty_logging(options.options)
    log.app_log.debug("testing debug")
    log.app_log.info("testing info")
    log.app_log

# Generated at 2022-06-22 03:54:16.870002
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # fmt: off
    class TestRecord(object):
        def __init__(self, message: str, levelname: str, lineno: Any) -> None:
            self.message = message
            self.levelname = levelname
            self.lineno = lineno
            self.module = "module"
            self.asctime = "asctime"
            self.levelno = logging.ERROR
            self.exc_info = None
            self.exc_text = None


# Generated at 2022-06-22 03:54:19.588919
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    lf = LogFormatter()
    record = logging.LogRecord(
        "tornado.general", logging.INFO, "tornado/ioloop.py", 87, "foo %r", (), None
    )
    print(lf.format(record))

# Generated at 2022-06-22 03:54:32.777057
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = "\n['%(message)s']"
    datefmt = "%H:%M:%S"
    style = "%"
    color = False
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }
    class LogRecord:
        levelno=10
        message="hello"
        asctime=13
        filename="test_LogFormatter_format"
        lineno=10
        module="test_LogFormatter_format"
    lr = LogRecord()

# Generated at 2022-06-22 03:54:40.030861
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    import argparse
    import doctest
    # The following is an example of disasterous use of the logging module
    # with the default settings.  It demonstrates "screams and shots in the
    # night":  http://www.logilab.org/card/do_not_use_the_standard_python_logging_module
    # It also has a sequence of bytes which will crash python logging if it
    # is not properly unicode-aware.

# Generated at 2022-06-22 03:54:40.666382
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()

# Generated at 2022-06-22 03:55:00.751160
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define
    define("logging", default="info", type=str)
    define("log_to_stderr", default=True, type=bool)
    define("log_file_prefix", default="tornado.log", type=str)
    define("log_file_max_size", default=100 * 1000 * 1000, type=int)
    define("log_file_num_backups", default=10, type=int)
    define("log_rotate_when", default="midnight", type=str)
    define("log_rotate_interval", default=1, type=int)
    define("log_rotate_mode", default="size", type=str)
    # Initialize the logger
    import tornado.options
    options = tornado.options.options
    logger = logging.getLogger()

# Generated at 2022-06-22 03:55:03.251009
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    assert tornado.options.options.logging == "info"

# Generated at 2022-06-22 03:55:08.073831
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()
    assert LogFormatter(colors={})
    assert LogFormatter(color=False)
    assert LogFormatter(style="{")
    assert LogFormatter(colors={}, style="{")
    assert LogFormatter(color=False, style="{")



# Generated at 2022-06-22 03:55:20.695773
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    options = tornado.options.options
    options.logging = "debug"
    options.log_file_prefix = "log"
    options.log_file_max_size = 100
    options.log_file_num_backups = 10
    options.log_rotate_mode = "size"
    options.log_rotate_when = "w"
    options.log_rotate_interval = 1
    options.log_to_stderr = None

    enable_pretty_logging()
    assert logging.getLogger().handlers[0].maxBytes == options.log_file_max_size

    options.log_rotate_mode = "time"
    enable_pretty_logging()
    assert logging.getLogger().handlers[0].when == options.log

# Generated at 2022-06-22 03:55:32.999730
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line, parse_config_file
    from tornado.log import LogFormatter, access_log, app_log, gen_log, _unicode
    import tornado.options
    import tornado.escape

    define(
        "log_to_stderr",
        type=bool,
        default=True,
        help="Send log output to stderr (colorized if possible).",
    )

# Generated at 2022-06-22 03:55:34.131345
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 03:55:46.216695
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.options import define, options

    define('logging', default='none')
    define('log_file_prefix', default=None)
    define('log_to_stderr', default=None)
    define('log_to_file', default=None)
    define('log_to_file', default=None)
    define('log_file_max_size', default=None)
    define('log_file_num_backups', default=None)

    logging.addLevelName('D', logging.DEBUG)
    logging.addLevelName('I', logging.INFO)
    logging.addLevelName('W', logging.WARNING)
    logging.addLevelName('E', logging.ERROR)
    logging.addLevelName('F', logging.FATAL)


# Generated at 2022-06-22 03:55:56.671998
# Unit test for function define_logging_options
def test_define_logging_options():
    # args = []
    # if len(sys.argv) > 1:
    #     args = sys.argv[1:]
    # print(args)
    # sys.argv = [sys.argv[0]]
    from tornado.options import define, parse_command_line
    define("opt1", type=str, default="opt1")
    define("opt2", type=str, default="opt2")
    define_logging_options()

# Generated at 2022-06-22 03:56:02.890444
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_format = '[%(levelname)s %(asctime)s %(module)s:%(lineno)d] %(message)s'
    date_format = "%y%m%d %H:%M:%S"
    style = "%"

    a = LogFormatter(fmt=log_format, datefmt=date_format, style=style)
    assert a


# Generated at 2022-06-22 03:56:14.474194
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    from tornado.options import define, options, parse_config_file
    import logging
    import logging.handlers
    import tempfile
    import glob
    import os

    define("logging",
           default="info",
           help=("Set the Python log level. If 'none', tornado won't touch the "
                 "logging configuration."),
           metavar="debug|info|warning|error|none")
    define("log_file_prefix",
           default=os.path.join(tempfile.gettempdir(), "tornado_test"),
           help=("Path prefix for log files. "
                 "Note that if you are running multiple tornado processes, "
                 "log_file_prefix must be different for each of them (e.g. "
                 "include the port number)"))

# Generated at 2022-06-22 03:56:29.462643
# Unit test for constructor of class LogFormatter
def test_LogFormatter():  # pragma: nocover
    formatter = LogFormatter(color=False)
    print("-" * 80)
    print(formatter.format(logging.makeLogRecord({"msg": "test"})))
    try:
        raise Exception("foo")
    except Exception:
        exc_info = sys.exc_info()
        print("-" * 80)
        print(formatter.format(logging.makeLogRecord({"msg": "test", "exc_info": exc_info})))  # noqa: E501

# Shortcut for use with logging.

# Generated at 2022-06-22 03:56:38.222156
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # Arrange
    def test_func():
        pass

    logger = logging.getLogger("TEST")
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(LogFormatter())
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Act
    logger.debug("Test")

    # Assert
    # Outputs an ANSI color-coded trace
    # i.e. [D 20181213 02:07:18 test_logging:12] Test



# Generated at 2022-06-22 03:56:48.806797
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    opt = tornado.options.OptionParser()
    define_logging_options(opt)
    opt.parse_command_line()
    print(tornado.options.options.log_rotate_mode)
    print(tornado.options.options.log_rotate_when)
    print(tornado.options.options.log_rotate_interval)
    print(tornado.options.options.logging)
    print(tornado.options.options.log_file_max_size)
    print(tornado.options.options.log_file_num_backups)

# Generated at 2022-06-22 03:56:54.389937
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log = ""

    def _test_formatter(fmt):
        logger = logging.getLogger("test")
        logger.setLevel(logging.DEBUG)
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(logging.DEBUG)
        formatter = LogFormatter(fmt)
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)
        return logger

    def test_format(fmt):
        global log
        logger = _test_formatter(fmt)
        try:
            logger.info("info %s %s", "info", "info")
            log = log.rstrip("\n")
            assert log == "[I 20180423 11:01:55 test:8] info info info"
        finally:
            logger.handlers

# Generated at 2022-06-22 03:57:05.974867
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    from tornado.options import define, options, parse_command_line
    import logging

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info('info message')

    define('logging', type=str, default=None)
    define('log_file_prefix', type=str, default=None)
    define('log_file_max_size', type=int, default=100)
    define('log_file_num_backups', type=int, default=3)
    define('log_rotate_mode', type=str, default='size')
    define('log_to_stderr', type=bool, default=True)
    define('log_rotate_when', type=str, default='D')

# Generated at 2022-06-22 03:57:16.673710
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    from tornado.log import LogFormatter
    tornado.options.define("logging", default="info", help="Set the Python log level", metavar="debug|info|warning|error")

    tornado.options.define("log_to_stderr", default=True, help="Send log output to stderr (colorized if possible). By default use stderr if --log_file_prefix is not set and no other logging is configured.")
    tornado.options.define("log_file_prefix", default=None, metavar="PATH", help="Path prefix for log files. Note that if you are running multiple tornado processes, log_file_prefix must be different for each of them (e.g. include the port number)")

# Generated at 2022-06-22 03:57:17.785518
# Unit test for function define_logging_options
def test_define_logging_options():
    pass



# Generated at 2022-06-22 03:57:21.080954
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s%(levelname)-8s%(end_color)s %(message)s"
    lf = LogFormatter(fmt=fmt)
    assert lf is not None


# Generated at 2022-06-22 03:57:26.805975
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(levelname)1.1s %(message)s",
        datefmt="%H:%M:%S",
    )
    # Test colorization
    logger = logging.getLogger()  # noqa
    log_handler = logging.StreamHandler()  # noqa
    log_handler.setFormatter(LogFormatter())



# Generated at 2022-06-22 03:57:30.937394
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    options = tornado.options.options
    define_logging_options(options)
# Test for function define_logging_options
test_define_logging_options()

# Generated at 2022-06-22 03:57:48.992481
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    test_fmt = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    test_datefmt = "%y%m%d %H:%M:%S"
    test_style = "%"
    test_color = True
    test_colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }


# Generated at 2022-06-22 03:58:00.664901
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Exercise datefmt argument (pylint: disable=missing-docstring)
    f = LogFormatter(datefmt="%x %X")
    assert f.formatTime(None, None) == ""

    f = LogFormatter(datefmt="%x %X")
    assert f.formatTime(None, "%x %X") == ""

    # Exercise fmt argument (pylint: disable=missing-docstring)
    record = logging.LogRecord("tornado.test", logging.INFO, "/fake/path", 42, "message", None, None)
    record.asctime = "asctime"
    f = LogFormatter(fmt="%(levelname)s %(message)s")
    assert f.format(record) == "INFO message\n"



# Generated at 2022-06-22 03:58:05.978566
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert formatter._fmt == formatter.DEFAULT_FORMAT
    assert formatter._colors == formatter.DEFAULT_COLORS


# Generated at 2022-06-22 03:58:11.334876
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)
    parser.parse_command_line(["--logging=debug", "--log_file_prefix=/tmp/log"])
    # parser.parse_command_line(["--logging=debug","--log_to_stderr=True"])

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 03:58:14.206781
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options

    options = tornado.options.Options()
    enable_pretty_logging(options)
    assert logging.getLevelName(logging.getLogger().level) == 'WARNING'
    assert hasattr(tornado.options.options, 'logging')


# For use in test cases

# Generated at 2022-06-22 03:58:17.778482
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()
    logging.info("test")

if __name__ == "__main__":
    test_enable_pretty_logging()

# Generated at 2022-06-22 03:58:27.072593
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    if not _stderr_supports_color():
        return
    log_format = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"
    formatter = LogFormatter(fmt=log_format)
    assert formatter._fmt == log_format
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._colors is not None
    assert formatter._normal is not None



# Generated at 2022-06-22 03:58:27.796286
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()



# Generated at 2022-06-22 03:58:36.591719
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import logging
    tornado.options.define_logging_options()
    tornado.options.parse_command_line()
    logger = logging.getLogger('mylogger')
    # print('logger level:',logger.getEffectiveLevel())
    logger.debug('Debug message')
    logger.info('Info message')
    logger.warning('Warning message')
    logger.error('Error message')

if __name__ == '__main__':
    test_define_logging_options()

# Generated at 2022-06-22 03:58:46.848376
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    class TestLogFormatter(unittest.TestCase):

        def setUp(self):
            self.logger = logging.getLogger("tornado.test.logformatter")
            self.handler = logging.StreamHandler()
            logger = self.logger
            handler = self.handler
            fmt = r"[%(asctime)s %(lineno)d] %(levelname)s: %(message)s"
            datefmt = r"%y%m%d %H:%M:%S"
            self.formatter = LogFormatter(fmt=fmt, datefmt=datefmt)
            handler.setFormatter(self.formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.NOTSET)
        # 构

# Generated at 2022-06-22 03:59:17.944868
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()
    enable_pretty_logging()

# Generated at 2022-06-22 03:59:29.914243
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.testing import AsyncTestCase, gen_test
    class TestCase(AsyncTestCase):
        @gen_test
        def test_LogFormatter_format(self):
            #%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s
            #[I 1407025305 hclient.py:164] Sending HTTP request: GET http://localhost:8888/hello?access_token=FE001
            formatter = logging.Formatter()
            #record.asctime = self.formatTime(record, '%y%m%d %H:%M:%S')
            #record.asctime = formatter.formatTime(record)
            #formatted = self._fmt % record.__dict__


# Generated at 2022-06-22 03:59:38.525172
# Unit test for function define_logging_options
def test_define_logging_options():
    import sys
    import logging
    import tornado.options
    import tornado.log
    sys.argv = [sys.argv[0], '--log_file_prefix=test']
    tornado.options.define_logging_options()
    tornado.options.parse_command_line()
    tornado.log.access_log.info('test log')
    logfile = open('test', 'r')
    assert(logfile.read()[10:-7] == 'test log')
    logfile.close()
    os.remove('test')

# Generated at 2022-06-22 03:59:50.145943
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.options.logging = 'info'
    tornado.options.options.log_file_prefix = 'test.log'
    tornado.options.options.log_rotate_mode = 'time'
    tornado.options.options.log_rotate_when = 'midnight'
    tornado.options.options.log_rotate_interval = 1
    tornado.options.options.log_file_num_backups = 1
    tornado.options.options.log_file_max_size = 10
    tornado.options.options.log_to_stderr = None
    logger = logging.getLogger()
    enable_pretty_logging(tornado.options.options, logger)
    import datetime
    now = datetime.datetime.now()

# Generated at 2022-06-22 03:59:53.682302
# Unit test for function define_logging_options
def test_define_logging_options():
    options=tornado.options.OptionParser()
    define_logging_options(options=options)
    options.parse_command_line(['--logging', 'info'])


# Generated at 2022-06-22 04:00:06.658466
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define("log_file_prefix", default="__test_log__", group="logging")
    tornado.options.define("log_to_stderr", default=True, group="logging")
    tornado.options.define("log_rotate_mode", default="test", group="logging")
    tornado.options.define("log_file_num_backups", default=0, group="logging")
    tornado.options.parse_command_line(["--log_rotate_mode=time"])
    tornado.options.parse_config_file("./src/logging/test_config")
    print(tornado.options.options.log_rotate_mode)
    enable_pretty_logging()

# Generated at 2022-06-22 04:00:08.576056
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    define_logging_options(OptionParser())

# Generated at 2022-06-22 04:00:15.278231
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    from tornado.log import LogFormatter, gen_log as logger
    logger.propagate = False
    logger.level = logging.DEBUG
    logger.handlers = []
    handler = logging.StreamHandler()
    formatter = LogFormatter(colors=False)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.debug('hello world')
    assert logger is gen_log



# Generated at 2022-06-22 04:00:16.209010
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-22 04:00:28.436487
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.httpserver
    tornado.options.define('logging', default='debug', help='test')
    tornado.options.define('log_file_prefix', default='test.log', help='test')
    tornado.options.define('log_rotate_mode', default='time', help='test')
    tornado.options.define('log_file_num_backups', default=100, help='test')
    tornado.options.define('log_rotate_when', default='midnight', help='test')
    tornado.options.define('log_rotate_interval', default=1, help='test')
    tornado.options.parse_command_line()
    handler = logging.StreamHandler()
    assert type(handler) == logging.StreamHandler
    enable_pretty_logging()

# Generated at 2022-06-22 04:01:14.408098
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    """Test for function enable_pretty_logging"""
    import json
    from tornado.testing import AsyncTestCase, gen_test, main
    from tornado import options

    from tornado import gen
    from tornado.testing import AsyncHTTPTestCase

    class MyTest(AsyncTestCase):
        @gen.coroutine
        def test_enable_pretty_logging(self):
            enable_pretty_logging()
            self.assertTrue(isinstance(options, object))
    if __name__ == "__main__":
        main()

# Generated at 2022-06-22 04:01:18.487792
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    try:
        enable_pretty_logging(None, None)
    except Exception as e:
        raise type(e)("test_enable_pretty_logging() raised an exception") from None


# Don't override unset options with new defaults:
if not options.logging:
    options.logging = "info"

# Generated at 2022-06-22 04:01:28.557898
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(
        filename="/dev/null",
        format="%(name)s.%(msecs)03d %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )
    logger = logging.getLogger("tornado.test.enable_pretty_logging")
    enable_pretty_logging()
    logger.info("test")
    enable_pretty_logging(
        logger=logger,
        options={"logging": "warning", "log_file_prefix": "test.py"},
    )
    logger.info("info")
    logger.warning("warning")
    try:
        raise RuntimeError("boo")
    except Exception:
        logger.exception("oops")



# Generated at 2022-06-22 04:01:40.241133
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import logging
    import logging.handlers
    import tornado.log

    from tornado.escape import _unicode

    try:
        import colorama  # type: ignore
    except ImportError:
        colorama = None

    try:
        import curses
    except ImportError:
        curses = None  # type: ignore

    access_log = logging.getLogger("tornado.access")
    app_log = logging.getLogger("tornado.application")
    gen_log = logging.getLogger("tornado.general")

    logger = logging.getLogger('tornado.application')

    handler = logging.StreamHandler()

# Generated at 2022-06-22 04:01:50.220242
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import sys
    from .test.util import unittest, suppress_stderr, ignore_deprecation

    logging.root.handlers = []
    logger = logging.getLogger()
    logger.setLevel(logging.CRITICAL)
    log_stream = StringIO()
    test_handler = logging.StreamHandler(stream=log_stream)
    test_handler.setFormatter(
        logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    )
    logger.addHandler(test_handler)
    enable_pretty_logging()
    gen_log.error("foo")
    # test that enable_pretty_logging doesn't add a second handler
    enable_pretty_logging()

# Generated at 2022-06-22 04:01:56.079552
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
  import tornado.options
  options = tornado.options.options
  options.logging = None
  options.log_file_prefix = "."
  options.log_rotate_mode = "size"
  options.log_file_max_size = 1024
  options.log_file_num_backups = 1
  logger = logging.getLogger()
  logger.setLevel(getattr(logging, options.logging.upper()))
  assert True

# Generated at 2022-06-22 04:02:07.940729
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():

    print('Testing function enable_pretty_logging')

    #from tornado.options import define, options
    import tornado.options
    import os.path, time

    define = tornado.options.define
    options = tornado.options.options

    define("logging", default="debug", help="Set to 'none' to disable logging")
    define(
        "log_to_stderr",
        type=bool,
        default=True,
        help="Send log output to stderr (colorized if possible). "
        "By default use stderr if --log_file_prefix is not set and "
        "no other logging is configured.",
    )

# Generated at 2022-06-22 04:02:19.606003
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options, parse_config_file
    import tempfile, os
    _, path = tempfile.mkstemp(dir=os.getcwd())
    define_logging_options()
    define("should_log_to_stderr", type=bool, default=True)
    define("should_log_to_file", type=bool, default=False)
    parse_config_file(path)
    enable_pretty_logging(options)
    assert options.log_to_stderr, "log_to_stderr must be True"

    fp = open(path, "w")
    fp.write("log_to_stderr = False\nshould_log_to_stderr = False")

# Generated at 2022-06-22 04:02:28.456595
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    for i in range(0,4):
        if i is 0:
            options = None
            logger = None
            try:
                enable_pretty_logging(options, logger)
            except ValueError as e:
                a = str(e)
                print ("\t Passed Exception")
            except Exception:
                print ("\t Failed Exception")
        if i is 1:
            options = None
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            try:
                enable_pretty_logging(options, logger)
            except ValueError as e:
                a = str(e)
                print ("\t Passed Exception")
            except Exception:
                print ("\t Failed Exception")
        if i is 2:
            options = "DEBUG"
            logger = logging.getLogger()
           

# Generated at 2022-06-22 04:02:32.016309
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    logging.basicConfig(level=logging.DEBUG)
    formatter = LogFormatter()
    logging.getLogger(__name__).debug("this should be blue")
    assert True
