

# Generated at 2022-06-22 03:54:00.391468
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    class Test: pass
    test = Test()
    test.__dict__ = {'levelno': 1, 'asctime': '2020', 'module': 'tornado',
                     'lineno': 123, 'color': '', 'end_color': ''}
    formater = LogFormatter()
    formater.format(test)


# Generated at 2022-06-22 03:54:07.077751
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    tornado.options.define_logging_options()
    tornado.options.options.parse_config_file("./test.cfg")
    tornado.options.options.log_file_max_size = 100 * 1000 * 1000
    tornado.options.options.add_parse_callback(lambda: enable_pretty_logging(tornado.options.options))

# Generated at 2022-06-22 03:54:09.460668
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options(tornado.options.options)

# Generated at 2022-06-22 03:54:15.775791
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import sys
    import datetime
    from tornado.log import app_log
    app_log.setLevel(logging.DEBUG)
    m = LogFormatter()
    rec = logging.LogRecord(
        'name', logging.DEBUG, 'test.py', 1, 'Message', (), None, None
    )
    m.format(rec)
    app_log.debug(rec)
LogFormatter.test_LogFormatter_format = test_LogFormatter_format


# Generated at 2022-06-22 03:54:28.717551
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    global _stderr_supports_color, _safe_unicode
    logger = logging.getLogger()
    def _stderr_supports_color():
        return True

    def _safe_unicode(s: Any) -> str:
        if isinstance(s, str):
            return s
        else:
            return repr(s)


# Generated at 2022-06-22 03:54:34.210081
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    try:
        tornado.options.define('log_rotate_mode', type=str, default='size',
                               help='The mode of rotating files(time or size)')
    except Exception as e:
        print(e)
        print("pass")


# Generated at 2022-06-22 03:54:45.748952
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    # Create the option parser
    parser = tornado.options.OptionParser()
    # Add the registration function
    define_logging_options(parser)
    args = ["--logging", "debug", "--log_rotate_mode", "time"]
    # Parse the arguments
    options = parser.parse_args(args=args)
    # Use the options
    enable_pretty_logging(options)
    tornado.options.options.logging = options.logging
    tornado.options.options.log_rotate_mode = options.log_rotate_mode
    assert tornado.options.options.logging == "debug"
    assert tornado.options.options.log_rotate_mode == "time"
    tornado.options.options.logging = "none"
    assert tornado.options.options.log

# Generated at 2022-06-22 03:54:46.793596
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-22 03:54:59.560560
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # Constructor without arguments
    formatter = LogFormatter()
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    # Constructor with arguments
    fmt = "%(color)s %(message)s"
    formatter = LogFormatter(fmt=fmt, color=True)
    assert formatter._normal == ""
    assert formatter._fmt == "%(color)s %(message)s"
    if colorama:
        # Constructor with colorama
        colorama.init()
        formatter = LogFormatter(fmt=fmt, color=True)
        assert formatter._normal == "\033[0m"
    else:
        formatter = LogFormatter(fmt=fmt, color=False)

# Generated at 2022-06-22 03:55:01.385159
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert isinstance(formatter, LogFormatter)


# Generated at 2022-06-22 03:55:14.998618
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging()

# Generated at 2022-06-22 03:55:18.292876
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord("name", "DEBUG", None, None, "message", None, None)
    formatted = formatter.format(record)
    assert formatted.endswith(" message")


# Generated at 2022-06-22 03:55:20.224959
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    define_logging_options()

# Generated at 2022-06-22 03:55:32.521878
# Unit test for function define_logging_options
def test_define_logging_options():
    """Unit test for function define_logging_options
    """
    try:
        import unittest
    except ImportError:
        raise ImportError("The unittest module is required to load tests")

    from tornado.options import OptionParser, options

    class TestCase(unittest.TestCase):
        def test_define_logging_options(self):
            parser = OptionParser()
            define_logging_options(parser)
            options.log_rotate_mode = "size"
            parser.parse_command_line(["--log_rotate_mode=time"])
            parser.parse_command_line(
                ["--log_to_stderr=True", "--log_file_prefix=log", "--logging=debug"]
            )
    unittest.main()



# Generated at 2022-06-22 03:55:42.811238
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG)
    import io
    import sys
    import time
    fmt = "%(asctime)s - %(message)s"
    f = io.StringIO()
    handler = logging.StreamHandler(f)
    handler.setFormatter(LogFormatter(fmt))
    logger = logging.getLogger()
    logger.addHandler(handler)

    logger.info('test1')
    out = f.getvalue()
    logger.removeHandler(handler)
    assert out == time.strftime("%y%m%d %H:%M:%S") + " - test1\n"
    f.close()


# Generated at 2022-06-22 03:55:44.272128
# Unit test for function define_logging_options
def test_define_logging_options():
    define_logging_options()

# Generated at 2022-06-22 03:55:45.283596
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    sut = LogFormatter()


# Generated at 2022-06-22 03:55:46.306738
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()



# Generated at 2022-06-22 03:55:54.048579
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    formatter = LogFormatter()
    assert issubclass(LogFormatter, logging.Formatter), "formatter should be logging.Formatter subclass"  # noqa: E501
    assert hasattr(formatter, "_fmt"), "formatter object should have attribute '_fmt'"  # noqa: E501
    assert hasattr(formatter, "_colors"), "formatter object should have attribute '_colors'"  # noqa: E501
    assert hasattr(formatter, "_normal"), "formatter object should have attribute '_normal'"  # noqa: E501


# Generated at 2022-06-22 03:55:56.356829
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options

    options = tornado.options.parse_command_line(["--logging=warning","--log_file_prefix=."])



# Generated at 2022-06-22 03:56:09.412199
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    formatter = LogFormatter()
    record = logging.LogRecord(
        "test",
        logging.INFO,
        "/path/to/file.py",
        22,
        "test message",
        None,
        None,
    )
    message = formatter.format(record)
    assert message == "[I 20170408 20:41:46 /path/to/file.py:22] test message"



# Generated at 2022-06-22 03:56:21.977197
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import unittest
    tornado.options.parse_command_line(
        ["--logging=info", "--log-rotate-mode=time"])
    enable_pretty_logging()
    logger = logging.getLogger()
    assert logger.level == logging.INFO
    with unittest.mock.patch('tornado.log.TimedRotatingFileHandler') as MOCK_TimedRotatingFileHandler:
        handler = MOCK_TimedRotatingFileHandler.return_value
        enable_pretty_logging()
        MOCK_TimedRotatingFileHandler.assert_called_once()
        assert handler.formatter.color == False
        assert handler.setFormatter.call_count == 1
        assert handler.when == 'D'
        assert handler.interval == 1

# Generated at 2022-06-22 03:56:32.389511
# Unit test for function define_logging_options
def test_define_logging_options():
    print("test_define_logging_options")
    class Options:
        def __init__(self):
            self.port = 8888
            self.log_file_prefix = "test_define_logging_options" + str(self.port)

        def define(self, name: str, **kwargs: Any) -> None:
            self.kwargs = kwargs
            print("\nname:%s" % name)
            print("kwargs: %s" % kwargs)

    options = Options()
    define_logging_options(options)
    assert isinstance(options.kwargs, dict)
    print("\nkwargs: %s" % options.kwargs)


# Generated at 2022-06-22 03:56:42.548703
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    options = tornado.options.options
    options.log_file_prefix = 'test_log_file_prefix'
    options.log_rotate_mode = 'size'
    options.log_file_max_size = 100
    options.log_file_num_backups = 3
    options.log_rotate_when = 'midnight'
    options.log_rotate_interval = 1
    options.log_to_stderr = None
    logger = logging.getLogger()
    enable_pretty_logging(options,logger)
    if logger.getEffectiveLevel()!= 30:
        assert False
    if logger.handlers[0].__class__.__name__!='RotatingFileHandler':
        assert False

# Generated at 2022-06-22 03:56:55.625060
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    log_record = logging.LogRecord(
        name='my.logger',
        level=logging.INFO,
        pathname='/some/path',
        lineno=1234,
        msg='hello world',
        args=(None, None),
        exc_info=None,
    )
    log_formatter = LogFormatter(
        fmt='%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s',
        datefmt='%y%m%d %H:%M:%S')
    log_formatter.format(log_record)
    out = "[I 0101 08:40:22 logger_test:1234] hello world"

# Generated at 2022-06-22 03:57:04.967139
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import pytest
    from io import StringIO
    io_stream = StringIO()
    logger = logging.Logger('test')
    logger.setLevel(10)
    handler = logging.StreamHandler(io_stream)
    handler.setFormatter(LogFormatter())
    logger.addHandler(handler)

    record = logging.LogRecord('test', 10, '%(message)s', (12,), '', '', '', 'test.py')
    record.__dict__['message'] = 'test message'
    logger.handle(record)
    assert io_stream.getvalue() == ''
    pytest.fail()


# Generated at 2022-06-22 03:57:09.722444
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    color_settings = {0: 1, 1: 2, 2: 3}
    formatter = LogFormatter(colors=color_settings, fmt="%(color)s%(levelname)s%(end_color)s")
    assert formatter._colors == {0: "\033[2;3%dm" % 1, 1: "\033[2;3%dm" % 2, 2: "\033[2;3%dm" % 3}
    assert formatter._normal == "\033[0m"
    assert formatter.datefmt == LogFormatter.DEFAULT_DATE_FORMAT
    assert formatter._fmt == "%(color)s%(levelname)s%(end_color)s"
    # test the format function

# Generated at 2022-06-22 03:57:12.674602
# Unit test for constructor of class LogFormatter
def test_LogFormatter():

    # default parameters
    fmter = LogFormatter()
    assert fmter._colors == {}

    # specifying colors as argument
    colors = {'INFO': 4}
    fmter = LogFormatter(colors=colors)
    assert fmter._colors == colors



# Generated at 2022-06-22 03:57:24.921218
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.Formatter.format = LogFormatter.format
    # Provides: test module
    # Required: none
    print('Provides: test module')
    print('Required: none')
    import unittest

    class LogFormatterTestCase(unittest.TestCase):
        def setUp(self):
            self.stream = sys.stdout = io.StringIO()
            self.date_format = '%Y-%m-%d %H:%M:%S'
            self.format = '[%(levelname)1.1s %(asctime)22s ' \
                          '%(module)15s:%(lineno)5d] %(message)s'
            self.logger = log.gen_log
            self.logger.setLevel(logging.DEBUG)


# Generated at 2022-06-22 03:57:34.456212
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    class DummyRecord(object):
        def __init__(self, msg: str, lvl: int) -> None:
            self.msg = msg
            self.lvl = lvl
        def getMessage(self) -> str:
            return self.msg
        def __getattr__(self, name: str) -> Any:
            return self.__dict__[name]
    def do_test(msg: str, log_level: int) -> None:
        record = DummyRecord(msg, log_level)
        formatter = LogFormatter()
        assert formatter.format(record) is not None
    do_test(str(b'xyz'), logging.ERROR)
    do_test('abc', logging.DEBUG)


# Generated at 2022-06-22 03:57:47.975561
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(format="%(levelname)s:%(message)s")
    import tornado.options
    import tornado.log
    tornado.log.enable_pretty_logging()
    logging.warning("This is a warning message")
    gen_log.error("This is a error message")
    app_log.debug("This is a debug message")
    gen_log.warning("This is a warning message")
    tornado.options.parse_command_line()
    # gen_log.debug("This is a debug message")

# Generated at 2022-06-22 03:57:58.927009
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(message)s")
    options = OptionParse()
    options.logging = "DEBUG"
    options.log_file_prefix ="test.log"
    option.log_file_max_size =5
    options.log_file_num_backups =10
    options.log_rotate_mode ="size"
    options.log_rotate_when ="MIDNIGHT"
    options.log_rotate_interval =1
    options.log_to_stderr =False
    enable_pretty_logging(options = options)
    logging.debug("Test logging")


# Generated at 2022-06-22 03:58:09.386924
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    import unittest
    import os
    import logging


    class LogFormatterTest(unittest.TestCase):
        def setUp(self):
            # In order to test that the formatter actually applies colorama
            # on Windows, we have to mess with logging's internal state.
            self.original_formatters = dict(logging._handlers)
            self.addCleanup(self._restore_logging_state)
            self.formatter = LogFormatter()

        def _restore_logging_state(self):
            logging._handlers = self.original_formatters

        def test_format(self):
            """Test that the formatter works in isolation"""

# Generated at 2022-06-22 03:58:10.562191
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()


# Generated at 2022-06-22 03:58:22.923614
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_case = [{
        "msg":"hi",
        "fmt":"[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]\n%(message)s",
        "expected": "[I 20180411 16:44:56 application:1]\nhi"
    },{
        "msg":"%",
        "fmt":"%s",
        "expected": "%s"
    }]
    for case in test_case:
        record = logging.LogRecord(
            "tornado.general", 
            logging.INFO, 
            "application", 
            1, 
            case["msg"], 
            None, 
            None
        )

# Generated at 2022-06-22 03:58:29.082807
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logger = logging.getLogger()
    formatter = LogFormatter()
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.WARNING)
    string = 'this is a test string'
    logger.warning(string)
    logger.removeHandler(handler)
    assert string in repr(formatter.format(logging.getLogger().handlers[0].stream.getvalue()))

# Generated at 2022-06-22 03:58:41.312148
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = '%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s'  # noqa: E501
    datefmt = "%y%m%d %H:%M:%S"
    style = "%"
    color = True
    colors = {
        logging.DEBUG: 4,  # Blue
        logging.INFO: 2,  # Green
        logging.WARNING: 3,  # Yellow
        logging.ERROR: 1,  # Red
        logging.CRITICAL: 5,  # Magenta
    }

# Generated at 2022-06-22 03:58:54.205317
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # We need a logger instance to initialize our formatter
    logger = logging.getLogger(__name__)
    # create a formatter
    formatter = LogFormatter(
        fmt="%(color)s%(levelname)1.1s %(message)s%(end_color)s",
        datefmt="%y%m%d %H:%M:%S",
        color=True,
        colors={
            logging.DEBUG: 4,  # Blue
            logging.INFO: 2,  # Green
            logging.WARNING: 3,  # Yellow
            logging.ERROR: 1,  # Red
            logging.CRITICAL: 5,  # Magenta
        })
    # and apply it to our logger
    logger.propagate = 0
    console = logging.StreamHandler()

# Generated at 2022-06-22 03:59:06.242392
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.ioloop
    import logging
    if __name__ == "__main__":
        tornado.options.define(
            "port", default=8888, help="run on the given port", type=int
        )
        tornado.options.define(
            "log_to_stderr",
            type=bool,
            default=None,
            help=(
                "Send log output to stderr (colorized if possible). "
                "By default use stderr if --log_file_prefix is not set and "
                "no other logging is configured."
            ),
        )

# Generated at 2022-06-22 03:59:07.893079
# Unit test for function define_logging_options
def test_define_logging_options():
    options = define_logging_options()
    print(options)


# Generated at 2022-06-22 03:59:22.656278
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    fmt = "%(color)s%(levelname)s%(end_color)s %(message)s"
    f = LogFormatter(fmt=fmt)
    # test for control char color
    assert f._colors[logging.DEBUG].startswith(u"\u001b[")
    assert f._colors[logging.DEBUG].endswith(u"m")
    # test for normal char
    assert isinstance(f._normal, unicode_type)



# Generated at 2022-06-22 03:59:31.115955
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    """Test for LogFormatter.__init__()"""
    f = LogFormatter(datefmt="%d-%y")
    assert f.datefmt == "%d-%y"
    assert f._fmt == "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"  # noqa: E501
    assert set(f._colors.keys()) == set(LogFormatter.DEFAULT_COLORS.keys())


# Generated at 2022-06-22 03:59:43.670897
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    logging.getLogger().handlers = []
    options=type('a',(object,),{'logging': 'warning','log_to_stderr':True,\
        'logging_rotate_when':'D','logging_rotate_interval':1,'log_file_num_backups':2,\
        'log_file_prefix':'a.log'})
    enable_pretty_logging(options)
    logging.getLogger().handlers = []

# Generated at 2022-06-22 03:59:46.933320
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    """
    >>> LogFormatter()._normal
    ''
    """
    assert LogFormatter()._normal == ""



# Generated at 2022-06-22 03:59:51.782314
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    test_logger = logging.Logger(name='test_logger')
    test_handler = logging.StreamHandler()
    test_formatter = LogFormatter()
    test_handler.setFormatter(test_formatter)
    test_logger.addHandler(test_handler)
    test_logger.warning('test warning')


# Generated at 2022-06-22 03:59:59.011850
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert LogFormatter()._normal == ""
    assert LogFormatter(color=False)._normal == ""
    assert LogFormatter(color=True)._normal == ""
    assert LogFormatter(color=True, colors={})._normal == ""
    assert LogFormatter(color=True, colors={1: 2})._normal != ""


# Test format function

# Generated at 2022-06-22 04:00:01.133656
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    for color in (False, True):
        for args in ([], ["%(message)s"], ["%(message)s %(asctime)s"]):
            for kwargs in ({}, {"fmt": "%(message)s"}): # Test different kwargs
                _LogFormatter(color, *args, **kwargs)

# Generated at 2022-06-22 04:00:10.164363
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    l = LogFormatter(color=True, colors={1: 2, 2: 3})
    assert len(l._colors) == 2
    assert l._normal == "\033[0m"

    l = LogFormatter(color=True)
    assert len(l._colors) == 5
    assert l._normal == "\033[0m"

    l = LogFormatter(color=False)
    assert len(l._colors) == 0
    assert l._normal == ""


if _stderr_supports_color():
    color_formatter = LogFormatter()
else:
    color_formatter = LogFormatter()



# Generated at 2022-06-22 04:00:11.590699
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    assert isinstance(LogFormatter()._fmt, str)


# Generated at 2022-06-22 04:00:14.788006
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()
    assert isinstance(lf._colors, dict)

test_LogFormatter()



# Generated at 2022-06-22 04:00:35.109043
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    def get_logger(name):
        return logging.getLogger(name)

    def get_logger_children(logger):
        return list(logger.manager.loggerDict.keys())

    def get_format_and_datefmt(log_formatter):
        return log_formatter._fmt, log_formatter.datefmt

    # the LogFormatter constructor sets the formatter on root
    logging.basicConfig(level=logging.WARN)
    assert not get_logger_children("")
    log_formatter = LogFormatter(color=False)
    assert get_logger_children("") == [""]

# Generated at 2022-06-22 04:00:45.604123
# Unit test for function define_logging_options
def test_define_logging_options():
  import tornado.options
  options = tornado.options.options
  define_logging_options(options)

  tornado.options.parse_config_file('./data/logging_test.conf')
  assert options.logging is 'none'
  assert options.log_to_stderr is False
  assert options.log_file_prefix is './log'
  assert options.log_file_max_size is 200000000 
  assert options.log_file_num_backups is 20
  assert options.log_rotate_when is 'midnight'
  assert options.log_rotate_interval is 1
  assert options.log_rotate_mode is 'size'

# Generated at 2022-06-22 04:00:46.741977
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    LogFormatter()  # no exception raised



# Generated at 2022-06-22 04:00:50.939486
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    parser = OptionParser()
    define_logging_options(parser)
    parser.parse_config_file("test/options_test")
    assert parser.logging == 'info'
    assert parser.log_to_stderr == True
    assert parser.log_file_prefix == "test_log"
    assert parser.log_file_max_size == 100
    assert parser.log_file_num_backups == 10
    assert parser.log_rotate_when == "midnight"
    assert parser.log_rotate_interval == 1
    assert parser.log_rotate_mode == "size"

# Generated at 2022-06-22 04:01:02.295169
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import logging.handlers
    tornado.options.options.log_to_stderr=True
    tornado.options.options.logging="DEBUG"
    enable_pretty_logging(options=tornado.options.options, logger=app_log)
    logger = app_log
    log_msg = logger.debug("debug message")
    print(log_msg)
    tornado.options.options.logging=logging.INFO
    enable_pretty_logging(options=tornado.options.options, logger=app_log)
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")
    tornado.options.options.log_to_stderr=False

# Generated at 2022-06-22 04:01:08.760528
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    record = logging.getLogger("tornado.access")
    fmt = LogFormatter(color=True, fmt="%(color)s%(levelname)s%(end_color)s %(message)s")
    record.setLevel(logging.DEBUG)
    record.msg = "&^*&$(*&^"
    color_msg = fmt.format(record)

# Generated at 2022-06-22 04:01:19.494927
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import tornado.log
    from tornado.testing import AsyncTestCase, LogTrapTestCase, main

    class EnablePrettyLoggingTest(AsyncTestCase, LogTrapTestCase):
        def test_enable_pretty_logging(self):
            tornado.log.enable_pretty_logging()
            self.log_helper.reset()
            logger = logging.getLogger("")
            logger.debug("string")
            self.assertEqual(len(self.log_helper.records), 1)
            self.assertTrue("string" in self.log_helper.records[0].msg)
            logger.info("string")
            self.assertEqual(len(self.log_helper.records), 2)

# Generated at 2022-06-22 04:01:29.356558
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    tornado.options.define(
        "log_to_stderr", type=bool, default=True)
    tornado.options.define(
        "log_rotate_mode", type=str, default="size")
    tornado.options.define(
        "log_file_prefix", type=str, default=None)
    tornado.options.define(
        "log_file_max_size", type=int, default=100)
    tornado.options.define(
        "log_file_num_backups", type=int, default=10)
    tornado.options.define(
        "log_rotate_when", type=str, default="S")
    tornado.options.define(
        "log_rotate_interval", type=int, default=1)
    tornado.options.parse_

# Generated at 2022-06-22 04:01:34.882351
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    # cast: ignore
    record = logging.LogRecord(
        name="tornado.test",
        level=logging.INFO,
        pathname="fakepath",
        lineno=1,
        msg="test",
        args=[],
        exc_info=None,
    )
    formatter = LogFormatter()
    formatter.format(record=record)
    return True



# Generated at 2022-06-22 04:01:42.274651
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fm = LogFormatter()

    record = logging.makeLogRecord({"msg":"message","exc_text": "exception"})
    assert fm.format(record) == "    message"

    record = logging.makeLogRecord({"msg": "message", "exc_info":True, "exc_text": "exception"}) # noqa: E501
    assert fm.format(record) == "    message\n    exception"



# Generated at 2022-06-22 04:01:59.242965
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    fmt = LogFormatter().format
    record = logging.LogRecord("tornado.general", logging.INFO,
                               "C:\\test.py", 42, "hello, world", None, None)
    assert fmt(record) == "[I 140213 22:43:18 test:42] hello, world"
    record.__dict__["exc_info"] = True
    record.__dict__["exc_text"] = "dummy exception"
    assert fmt(record) == (
        "[I 140213 22:43:18 test:42] hello, world\n"
        "    dummy exception"
    )



# Generated at 2022-06-22 04:02:00.506005
# Unit test for function define_logging_options
def test_define_logging_options():
    pass

# Generated at 2022-06-22 04:02:02.124336
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging()
    tornado.options._parse_command_line()

# Generated at 2022-06-22 04:02:07.437522
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    define_logging_options(options)
    assert isinstance(options.define, type(define_logging_options))
    assert isinstance(options.add_parse_callback, type(define_logging_options))

if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 04:02:15.076653
# Unit test for method format of class LogFormatter
def test_LogFormatter_format():
    logging.basicConfig(level=logging.DEBUG)
    formatter = LogFormatter()
    a=logging.getLogger("b")
    a.setLevel(logging.DEBUG)
    a.info("test_LogFormatter_format: INFO: ", exc_info=True)
    a=logging.getLogger("b")
    a.setLevel(logging.ERROR)
    a.info("test_LogFormatter_format: ERROR: ", exc_info=True)


# Generated at 2022-06-22 04:02:20.100788
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import options
    define_logging_options(options)
    # print(options.log_to_stderr)
    # print(options.logging)
    # print(options.log_file_prefix)
    # print(options.log_rotate_mode)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 04:02:25.815696
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import define, options

    define("option1")
    define("option3")
    define_logging_options(options)
    options.parse_command_line(args=["--option1", "1"])
    print(options)


if __name__ == "__main__":
    test_define_logging_options()

# Generated at 2022-06-22 04:02:34.531780
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    # type: () -> None
    formatter = LogFormatter()
    assert formatter._colors == {}

    formatter = LogFormatter(color=True)
    assert isinstance(formatter._colors, dict)

    formatter = LogFormatter(color=True, colors={})
    assert isinstance(formatter._colors, dict)

    formatter = LogFormatter(color=True, colors=None)
    assert isinstance(formatter._colors, dict)

    formatter = LogFormatter(color=True, colors={1: 1})
    assert isinstance(formatter._colors, dict)



# Generated at 2022-06-22 04:02:36.643980
# Unit test for function define_logging_options
def test_define_logging_options():
    import tornado.options
    import tornado.options
    tornado.options.define_logging_options(tornado.options.options)

# Generated at 2022-06-22 04:02:38.126896
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    enable_pretty_logging()

# Generated at 2022-06-22 04:02:47.343017
# Unit test for constructor of class LogFormatter
def test_LogFormatter():
    lf = LogFormatter()


# Generated at 2022-06-22 04:02:56.006211
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import logging
    import tornado.options

    options = tornado.options.options
    options.logging = "debug"
    enable_pretty_logging(options=options)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.debug(123)


# The `logging` module was refactored in Python 3.2, formerly the
# `logging.handlers.MemoryHandler` class was in the root `logging`
# module.
if sys.version_info >= (3, 2):
    MemoryHandler = logging.handlers.MemoryHandler  # type: ignore
else:
    MemoryHandler = logging.handlers.MemoryHandler  # type: ignore

# Generated at 2022-06-22 04:02:58.246653
# Unit test for function define_logging_options
def test_define_logging_options():
    from tornado.options import OptionParser
    options = OptionParser()
    define_logging_options(options)

# Generated at 2022-06-22 04:03:09.434888
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    import tornado.options
    import logging
    import warnings
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("tornado.test")
    assert logger.level == logging.INFO
    assert len(logger.handlers) == 1

    tornado.options.options.logging = "warning"
    tornado.options.options.log_to_stderr = True
    enable_pretty_logging()
    assert logger.level == logging.WARNING
    assert len(logger.handlers) == 2
    assert isinstance(logger.handlers[1], logging.StreamHandler)
    assert isinstance(logger.handlers[1].formatter, LogFormatter)


# Generated at 2022-06-22 04:03:10.771877
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    enable_pretty_logging(None)


test_enable_pretty_logging()

# Generated at 2022-06-22 04:03:18.953482
# Unit test for function enable_pretty_logging
def test_enable_pretty_logging():
    def fake_parse():
        return LogOptions()

    def fake_RotatingFileHandler(filename: str, mode: str, encoding: str):
        return "RotatingFileHandler"

    def fake_TimedRotatingFileHandler(
        filename: str, when: str, interval: int, backupCount: int, encoding: str
    ):
        return "TimedRotatingFileHandler"

    import logging
    from tornado.log import LogFormatter, LogOptions

    l = LogOptions()
    l.logging = "INFO"
    l.log_file_prefix = "prefix"
    l.log_rotate_mode = "size"
    l.log_file_max_size = 1024
    l.log_file_num_backups = 3
    l.log_to_stderr = False