

# Generated at 2022-06-24 08:56:35.981747
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.gen import coroutine
    from tornado.ioloop import IOLoop
    ioloop = IOLoop.instance()
    import time

    @coroutine
    def get_it():
        resolver = DefaultExecutorResolver()
        # def resolve(self, host: str,
        # port: int,
        # family: socket.AddressFamily = socket.AF_UNSPEC) -> Awaitable[List[Tuple[int, Any]]]:
        host = 'www.google.com'
        port = 80
        family = socket.AF_UNSPEC
        ip = yield resolver.resolve(host, port, family)
        print(ip)
        ioloop.stop()

    ioloop.add_callback(get_it)
    ioloop.start()



# Generated at 2022-06-24 08:56:37.963360
# Unit test for method close of class Resolver
def test_Resolver_close():
    a = Resolver()
    a.close()



# Generated at 2022-06-24 08:56:39.362115
# Unit test for function bind_sockets
def test_bind_sockets():
    class TestFunctions(object):
        def test_sockets(self):
            bind_sockets(80, reuse_port=True)
    ins = TestFunctions()
    ins.test_sockets()



# Generated at 2022-06-24 08:56:42.846298
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    try:
        import concurrent.futures
        raise NotImplementedError('executor constructor')
    except ImportError:
        pass
    try:
        raise NotImplementedError('executor constructor')
    except ImportError:
        pass
    try:
        raise NotImplementedError('executor constructor')
    except ImportError:
        pass
    raise NotImplementedError('executor constructor')


# Generated at 2022-06-24 08:56:47.578077
# Unit test for method close of class Resolver
def test_Resolver_close():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    AsyncIOMainLoop().install()

    resolver = Resolver()

    class TestResolver(Resolver):
        def resolve(self, host, port, family=socket.AF_UNSPEC):
            return None

    res = TestResolver()
    res.close()

    @gen_test
    def test():
        raise gen.Return(resolver.close())
    test()



# Generated at 2022-06-24 08:56:50.641365
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    # OverrideResolver.close
    # Unit test for method close of class OverrideResolver
    resolver = OverrideResolver(BlockingResolver(), {})
    resolver.resolve("example.com", 80)
    resolver.close()


# Generated at 2022-06-24 08:56:53.019366
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    assert_equal(
        OverrideResolver.__init__.__defaults__,
        (None,),
        msg='Wrong default args for the constructor of class OverrideResolver',
    )


# Generated at 2022-06-24 08:56:53.611634
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    pass



# Generated at 2022-06-24 08:56:56.722146
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    T = ThreadedResolver()
    T._threadpool = concurrent.futures.ThreadPoolExecutor(3)
    T._threadpool_pid = 3
    assert T._threadpool_pid == 3
    T.initialize(num_threads = 10)



# Generated at 2022-06-24 08:57:00.231026
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    results = resolver.resolve("localhost", 8080)
    assert results == [(2, ('127.0.0.1', 8080))]
    resolver.close()
    results = resolver.resolve("localhost", 8080)
    assert results == []


# Generated at 2022-06-24 08:57:09.377588
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():

    #execution_time = []
    #input_value = []
    times = 100

    # for i in range(0,times):
    #     now = timeit.default_timer()
    #     t = OverrideResolver().initialize(1,1)
    #     execution_time.append(timeit.default_timer() - now)
    #
    #     input_value.append(utils.generate_uni(i))

    #######################    ENCRYPT    #####################
    # utils.plotter(execution_time,input_value,'OverrideResolver_initialize','input_value','execution_time',True)

    #######################    DECRYPT    #####################
    # utils.plotter(execution_time,input_value,'OverrideResolver_initialize','input_value

# Generated at 2022-06-24 08:57:15.910850
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    from tornado import gen

    resolver = Resolver()
    mapping = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    OverrideResolver.initialize(OverrideResolver(), resolver, mapping)

    @gen.coroutine
    def main():
        results = yield resolver.resolve("example.com", 80)
        assert results == [
            (socket.AF_INET, ("127.0.1.1", 80)),
            (socket.AF_INET6, ("127.0.1.1", 80)),
        ]


# Generated at 2022-06-24 08:57:24.202653
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():

    # 指定要执行测试的类, 如果没有指定类，测试框架会根据名称查找测试类
    # 返回一个类，提供有关测试类的信息
    suite = unittest.TestLoader().loadTestsFromTestCase(TestResolver_resolve)

    # 获取当前时间，返回当前的时间，其精度为纳秒
    start_time = time

# Generated at 2022-06-24 08:57:25.281977
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    assert ExecutorResolver(executor = dummy_executor, close_executor = True)



# Generated at 2022-06-24 08:57:26.763914
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    _instance = Resolver()
    _instance.resolve('addr', 123, socket.AF_INET)



# Generated at 2022-06-24 08:57:28.192675
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    # This causes an exception to be raised if the specified method
    # does not exist.
    getattr(ThreadedResolver, 'initialize')



# Generated at 2022-06-24 08:57:33.859283
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    resolver = OverrideResolver(resolver=None, mapping={"hello": "world"})
    assert resolver.resolver is None
    assert resolver.mapping == {"hello": "world"}



# Generated at 2022-06-24 08:57:41.482949
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    certfile = '../ssl/server.crt'
    keyfile = '../ssl/server.key'
    ca_certs = '../ssl/ca.crt'
    ssl_options = dict(certfile=certfile,keyfile=keyfile,ca_certs=ca_certs)
    server_hostname = '127.0.0.1'
    ssl.wrap_socket(socket,ssl_options,server_hostname=server_hostname)


# Generated at 2022-06-24 08:57:42.422981
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    resolver = ThreadedResolver()


# Generated at 2022-06-24 08:57:47.905846
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    num_threads = 10
    ob = ThreadedResolver
    i = ob._create_threadpool(num_threads)
    if i is not None:
        return True
    else:
        return False
assert test_ThreadedResolver_initialize() == True



# Generated at 2022-06-24 08:57:54.182775
# Unit test for function bind_sockets
def test_bind_sockets():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
        server_sock.setblocking(False)
        server_sock.bind(("0.0.0.0", 12345))
        server_sock.listen(128)
        print (server_sock.getsockname())
        server_sock.close()

# test_bind_sockets()



# Generated at 2022-06-24 08:58:02.991865
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import functools
    # Tornado's own tests
    io_loop = IOLoop.current()
    io_loop.make_current()
    sock, port = bind_unix_socket(__file__ + ".sock")
    client_sockets = []  # type: List[socket.socket]

    def client():
        # A client that connects and then closes the connection
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        s.connect(("127.0.0.1", port))
        client_sockets.append(s)
        s.close()


# Generated at 2022-06-24 08:58:05.556754
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = None
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor=executor, close_executor=close_executor)


# Generated at 2022-06-24 08:58:11.226946
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import contextlib
    sock = None
    with contextlib.closing(bind_unix_socket(tempfile.mktemp())) as sock:
        assert sock.family == socket.AF_UNIX
        assert sock.type == socket.SOCK_STREAM
    os.remove(sock.getsockname())



# Generated at 2022-06-24 08:58:12.646768
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    oresolver = OverrideResolver("",{})


# Generated at 2022-06-24 08:58:18.612841
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # setup
    eresolver = ExecutorResolver(
        dummy_executor,
        True)

    # action
    eresolver.close()

    # assert
    assert not eresolver.close_executor



# Generated at 2022-06-24 08:58:20.460413
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    d = {
        'ssl_version': ssl.PROTOCOL_TLS_CLIENT
    }
    ssl_options_to_context(d)


# Generated at 2022-06-24 08:58:23.677617
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    print('test_ssl_wrap_socket')
    s = socket.socket()
    s.bind( ('127.0.0.1',8888) )
    s.listen(1)
    s = ssl_wrap_socket(s, 'dict')

# Generated at 2022-06-24 08:58:25.956279
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    resolver = DefaultExecutorResolver()
    assert isinstance(resolver, DefaultExecutorResolver)



# Generated at 2022-06-24 08:58:29.124695
# Unit test for method close of class Resolver
def test_Resolver_close():
    import asyncio
    loop = asyncio.get_event_loop()
    loop.run_until_complete(Resolver().close())
    loop.close()



# Generated at 2022-06-24 08:58:37.504411
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    mapping = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    resolver = OverrideResolver(resolver=mapping, mapping=mapping)
    assert resolver.resolve(host="localhost", port=1234) == [
        (socket.AF_INET, ("127.0.0.1", 1234))
    ]
    assert resolver.resolve(host="example.com", port=1234) == [
        (socket.AF_INET, ("127.0.1.1", 1234))
    ]

# Generated at 2022-06-24 08:58:39.158471
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    r = ExecutorResolver()
    r.initialize()
    return r

test_ExecutorResolver()



# Generated at 2022-06-24 08:58:47.261680
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    """
       Test if BlockingResolver constructor is called from dummy_executor
    """

    class ExecutorMock(concurrent.futures.Executor):
        def __init__(self):
            self.shutdown_called = False

        def submit(
            self, fn: Callable[..., Any], *args: Any, **kwargs: Any
        ) -> concurrent.futures.Future:
            return concurrent.futures.Future()

        def shutdown(self, wait: bool = True) -> None:
            self.shutdown_called = True

    executor = ExecutorMock()
    assert not executor.shutdown_called
    blocking_resolver = BlockingResolver()
    blocking_resolver.initialize(executor)
    blocking_resolver.close()
    assert executor.shutdown_

# Generated at 2022-06-24 08:58:55.372531
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    host = '127.0.0.1'
    port = 0
    family = socket.AF_UNSPEC
    loop = asyncio.get_event_loop()
    resolver = ExecutorResolver()
    result = loop.run_until_complete(resolver.resolve(host, port, family))
    assert result != None



# Generated at 2022-06-24 08:58:59.529590
# Unit test for function bind_sockets
def test_bind_sockets():
    sock = bind_sockets(8888, address="127.0.0.1")
    sock[0].close()



# Generated at 2022-06-24 08:59:09.578480
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado
    import os
    import sys
    import certifi
    import concurrent.futures
    import typing
    import ssl
    from tornado.netutil import ExecutorResolver
    from tornado.escape import utf8
    from concurrent.futures import Executor
    from tornado.iostream import IOStream, SSLIOStream
    from typing import Callable, Union, Any, Optional, Type, TypeVar, List, Tuple
    from tornado import concurrent

    class _Resolver:
        async def resolve(
            self, host: str, port: int, family: socket.AddressFamily = socket.AF_UNSPEC
        ) -> List[Tuple[int, Any]]:
            pass

    res = ExecutorResolver()
    await res.resolve(host="localhost", port=443)
# END



# Generated at 2022-06-24 08:59:18.625438
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import logging
    import tornado.log
    import logging
    import tornado.log
    # tornado.log.enable_pretty_logging()
    tornado.log.app_log.setLevel(logging.DEBUG)

    list_log=[]
    def echo_callback(connection, address):
        tornado.log.app_log.debug("accept")
        list_log.append("accept")
        connection.close()
        
    logging.debug("start server")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(False)
    sock.bind(("localhost", 0))
    port = sock.getsockname()[1]
    sock

# Generated at 2022-06-24 08:59:24.264316
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    num_threads = 10
    resolver = ThreadedResolver()
    resolver.initialize(num_threads)
    resolver._threadpool = "threadpool"
    resolver._threadpool_pid = 1
    assert resolver._threadpool == "threadpool"
    assert resolver._threadpool_pid == 1

# Generated at 2022-06-24 08:59:27.406983
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    resolver = OverrideResolver(
        resolver=None,
        mapping={
            "example.com": "127.0.1.1",
            ("login.example.com", 443): ("localhost", 1443),
            ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
        }
    )
    try:
        assert resolver
    except AssertionError:
        assert False


# Generated at 2022-06-24 08:59:35.131538
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.setblocking(False)
    sock.bind(("127.0.0.1", 0))
    sock.listen(1)
    port = sock.getsockname()[1]

    def connect():
        csock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        csock.connect(("127.0.0.1", port))
        return csock

    client = connect()
    callback_args = [None]  # type: List[Any]

    def callback(connection: socket.socket, address: Any) -> None:
        callback_args[0] = (connection, address)

    remove_handler = add_accept_handler(sock, callback)


# Generated at 2022-06-24 08:59:41.433960
# Unit test for constructor of class Resolver
def test_Resolver():
    assert issubclass(Resolver, Configurable)
    assert Resolver.configurable_base() == Resolver
    assert issubclass(Resolver.configurable_default(), Resolver)
    resolver = Resolver()
    assert isinstance(resolver, Resolver)
    resolver.close()



# Generated at 2022-06-24 08:59:42.313206
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    ThreadedResolver.initialize()
    return True
test_ThreadedResolver_initialize()



# Generated at 2022-06-24 08:59:44.536096
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/test.sock")
    os.remove("/test.sock")



# Generated at 2022-06-24 08:59:50.433548
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    name = 'OverrideResolver'
    # Expecting [None]
    test_close_resolver = OverrideResolver()
    resolver = mock.mock_open(read_data='data')
    test_close_resolver.resolver = resolver
    resolver.close.return_value = None
    assert test_close_resolver.close() == None
    resolver.close.assert_called_with()
    assert test_close_resolver.resolver == None


# Generated at 2022-06-24 08:59:53.441330
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = Resolver()
    oresolver = OverrideResolver(resolver, {})
    l = oresolver.resolve("", 0)
    assert l == []

test_OverrideResolver_resolve()


# Generated at 2022-06-24 08:59:56.633217
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    addrinfo = resolver.resolve('localhost', 80)
    print('addrinfo = {}'.format(addrinfo))
    resolver.close()
test_ExecutorResolver_resolve()



# Generated at 2022-06-24 08:59:58.635472
# Unit test for constructor of class Resolver
def test_Resolver():
    resolver1 = Resolver()
    print(isinstance(resolver1, Resolver))



# Generated at 2022-06-24 09:00:01.035938
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    obj = ExecutorResolver()
    obj.close()


# Generated at 2022-06-24 09:00:08.576372
# Unit test for function bind_sockets
def test_bind_sockets():
    def test_sockets(family):
        port = None
        if family == socket.AF_INET6:
            port = 0  # automatic port allocation
        sockets = bind_sockets(port, address=family, family=family)
        assert len(sockets) == 1
        assert sockets[0].getsockname()[0] == family
        sockets[0].close()

    if socket.has_ipv6:
        test_sockets(socket.AF_INET6)



# Generated at 2022-06-24 09:00:10.916078
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    for socket in sockets:
        socket.close()
test_bind_sockets()



# Generated at 2022-06-24 09:00:15.526606
# Unit test for constructor of class Resolver
def test_Resolver():
    resolver = Resolver()
    try:
        print(resolver)
    except NotImplementedError as e:
        print("This is a abstract class, exception: {0}".format(e))

if __name__ == "__main__":
    test_Resolver()

# Generated at 2022-06-24 09:00:20.573606
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    #Test with BlockingResolver
    br = BlockingResolver()
    print('Resolver.resolve() test:')
    res1 = br.resolve('www.google.com', 80)
    res2 = br.resolve('127.0.0.1', 80)
    print(res1)
    print(res2)

if __name__ == '__main__':
    test_Resolver_resolve()

# Generated at 2022-06-24 09:00:29.039450
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    import concurrent.futures
    import os
    import threading
    import tornado.platform.twisted
    resolver = ThreadedResolver()
    assert isinstance(resolver, ThreadedResolver)
    assert isinstance(ThreadedResolver.configurable_base(), type)
    assert isinstance(ThreadedResolver.configurable_default(), type)
    assert isinstance(resolver.initialize(10), NoneType)
    assert isinstance(resolver._threadpool, concurrent.futures.ThreadPoolExecutor)


# Generated at 2022-06-24 09:00:30.539480
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    obj = BlockingResolver()
    obj.initialize()

# Generated at 2022-06-24 09:00:37.043753
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # create resolver object
    resolver = OverrideResolver(resolver=Resolver, mapping={})
    # run resolve method on host and port
    resolver.resolve(host=str, port=int, family=socket.AddressFamily)



# Generated at 2022-06-24 09:00:38.598240
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    r = ExecutorResolver()
    assert r.executor == dummy_executor
    assert r.close_executor == False
    

# Generated at 2022-06-24 09:00:39.423067
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-24 09:00:42.321642
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = None
    close_executor = True
    self = ExecutorResolver()
    self.initialize(executor, close_executor)
    assert self.close_executor
    

# Generated at 2022-06-24 09:00:48.287060
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    resolver = Resolver()
    mapping = {"example.com": "127.0.1.1"}
    override_resolver = OverrideResolver(resolver,mapping)
    assert override_resolver.resolver == resolver
    assert override_resolver.mapping == mapping

# Generated at 2022-06-24 09:00:56.373568
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Create a server socket listening on a port
    import asyncio
    from tornado.testing import bind_unused_port

    res = bind_unused_port()
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("127.0.0.1", res[1]))
    sock.listen(backlog=5)

    add_accept_handler(sock, io_loop=asyncio.get_event_loop())



# Generated at 2022-06-24 09:00:57.896493
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    r = OverrideResolver()
    r.close()
    return True

# Generated at 2022-06-24 09:00:59.835120
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    a = BlockingResolver()


# Generated at 2022-06-24 09:01:09.424298
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # The arguments of the functions are passed in by the decorator @gen_test
    # The function cannot have any arguments.
    # The function is a co-routine.
    # The function yield the value returned by functions decorated with @gen.coroutine
    host = "127.0.0.1"
    port = 8888
    family = socket.AF_INET
    resolver = Resolver()
    #
    async def test():
        # The argument yield is a value returned by functions decorated with @gen.coroutine
        result = await resolver.resolve(host, port, family)
        with pytest.raises(NotImplementedError):
            print(result)
    return test()



# Generated at 2022-06-24 09:01:15.156732
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    #from tornado.platform import asyncioreactor
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    async def test():
        loop=AsyncIOMainLoop()
        loop.make_current()
        await to_asyncio_future(Resolver().resolve('www.baidu.com',80))
        
    loop.run_until_complete(test())
    loop.close()

    #asyncioreactor.install()
    #asyncio.get_event_loop().run_until_complete(test())
    
    



# Generated at 2022-06-24 09:01:18.142188
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    from tornado.netutil import ThreadedResolver
    resolver = ThreadedResolver()
    obj = OverrideResolver(resolver, {'a': '127.0.1.1'})
    obj.close()


# Generated at 2022-06-24 09:01:19.557099
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    resolver = ThreadedResolver(num_threads=42)
    assert resolver._threadpool is ThreadedResolver._threadpool
    resolver.close()  # no effect



# Generated at 2022-06-24 09:01:30.817255
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        'keyfile': 'test/test_tornado/data/test.key',
        'certfile': 'test/test_tornado/data/test.crt',
        'ca_certs': 'test/test_tornado/data/ca.crt',
        'cert_reqs': ssl.CERT_REQUIRED,
        'ssl_version': ssl.PROTOCOL_TLSv1,
        'ciphers': 'RSA+AES',
    }
    context = ssl_options_to_context(ssl_options)
    assert isinstance(context, ssl.SSLContext)
    assert ssl.PROTOCOL_TLSv1 == context.protocol
    assert context.check_hostname

# Generated at 2022-06-24 09:01:39.804775
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    class FakeExecutor:
        pass
    resolver = ExecutorResolver(executor=FakeExecutor, close_executor=True) # type: ignore
    assert isinstance(resolver.executor, FakeExecutor)
    assert resolver.close_executor

    resolver = ExecutorResolver(executor=FakeExecutor, close_executor=False) # type: ignore
    assert isinstance(resolver.executor, FakeExecutor)
    assert resolver.close_executor

    resolver = ExecutorResolver(executor=None, close_executor=True) # type: ignore
    assert not isinstance(resolver.executor, FakeExecutor)
    assert resolver.close_executor

    resolver = ExecutorResolver(executor=None, close_executor=False) # type: ignore

# Generated at 2022-06-24 09:01:43.625941
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    ioloop = IOLoop()
    resolver = ExecutorResolver()
    resolver.initialize()
    ioloop.run_sync(resolver.resolve, "localhost", 80)



# Generated at 2022-06-24 09:01:46.550773
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    ThreadedResolver._create_threadpool(10)
    print(concurrent.futures.ThreadPoolExecutor.__init__.__defaults__)
    ThreadedResolver._create_threadpool(num_threads=10)

test_ThreadedResolver_initialize()


# Generated at 2022-06-24 09:01:47.739942
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    DefaultExecutorResolver()


# Generated at 2022-06-24 09:01:48.775219
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    DefaultExecutorResolver()



# Generated at 2022-06-24 09:01:54.675051
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    try:
        # Instantiate an object from class DefaultExecutorResolver
        resolver = DefaultExecutorResolver()

        # Instantiate an object from class IOLoop
        loop = IOLoop.current()

        # Call method run_in_executor of class IOLoop
        result = await loop.run_in_executor(None, _resolve_addr, 'localhost', 80)
        # print(result)

    except Exception as e:
        logging.exception("An exception occurred in test_DefaultExecutorResolver()")



# Generated at 2022-06-24 09:01:55.501011
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    assert True



# Generated at 2022-06-24 09:02:05.466554
# Unit test for method close of class Resolver
def test_Resolver_close():
    try:
        from tornado.netutil import DefaultExecutorResolver
        from tornado import testing
        import socket
        import pytest

        test_toggle = False

        class MyResolver(DefaultExecutorResolver):
            def __init__(self):
                super().__init__()
                test_toggle

            def close(self):
                assert test_toggle

        @testing.gen_test
        async def test_close():
            resolver = MyResolver()
            await resolver.resolve('localhost', 80)
            resolver.close()

    except Exception as err:
        print(err)


# Generated at 2022-06-24 09:02:13.928383
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    def tester(resolver, mapping, host, port, family):
        if (host, port, family) in mapping:
            return mapping[(host, port, family)]
        elif (host, port) in mapping:
            return mapping[(host, port)]
        elif host in mapping:
            return (mapping[host], port)
        else:
            return (host, port, family)


    resolver = None
    mapping = {
            "example.com": "127.0.1.1",
            ("login.example.com", 443): ("localhost", 1443),
            ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
        }
    resolver = OverrideResolver(resolver, mapping)
    host = "example.com"

# Generated at 2022-06-24 09:02:18.594601
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
	a= Resolver()
	try:
		a.resolve("" , )
	except:
		pass
	else :
		raise Exception("Resolver.resolve exception raised")

# Generated at 2022-06-24 09:02:21.626158
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.netutil
    tornado.netutil.add_accept_handler

# For backwards compatibility
add_accept_handler.__test__ = False



# Generated at 2022-06-24 09:02:34.082995
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.selector import SelectorReactor
    from tornado.platform.twisted import TwistedIOLoop
    from tornado.platform.twisted import _TwistedResolver
    from tornado.platform.twisted import _TwistedResolver_close
    from tornado.platform.twisted import _TwistedResolver_resolve
    from tornado.platform.caresresolver import CaresResolver
    from tornado.platform.caresresolver import _CaresResolver_resolve
    from tornado.platform.caresresolver import _CaresResolver_close
    from tornado.platform._caresresolver import _CaresResolver
    from tornado.platform.asyncio import asyncio_resolver_instance


# Generated at 2022-06-24 09:02:41.381067
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
    context.verify_mode = ssl.CERT_REQUIRED
    context.check_hostname = True
    context.load_verify_locations('/etc/ssl/certs/ca-certificates.crt')
    context.load_cert_chain(
            certfile='/etc/ssl/certs/ca-certificates.crt',
            keyfile='/etc/ssl/private/ssl-cert-snakeoil.key')
    context.set_ciphers('ALL:!ADH:!LOW:!EXP:!MD5:@STRENGTH')
    context.set_ecdh_curve('prime256v1')

# Generated at 2022-06-24 09:02:43.884725
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    import concurrent.futures
    _ThreadedResolver = ThreadedResolver()



# Generated at 2022-06-24 09:02:49.842657
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    resolver = ExecutorResolver()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    resolver2 = ExecutorResolver(concurrent.futures.ThreadPoolExecutor(), False)
    assert resolver2.io_loop == IOLoop.current()
    assert not resolver2.executor == dummy_executor
    assert not resolver2.close_executor == False



# Generated at 2022-06-24 09:02:52.931365
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    class TestBlockingResolver(BlockingResolver):
        def __init__(self, x):
            super().__init__()
            self.x = x
    result = TestBlockingResolver(0).initialize()
    assert result is None


# Generated at 2022-06-24 09:02:59.228217
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import socket
    import tornado.httpserver
    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_unix_socket
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.testing import AsyncHTTPTestCase, AsyncTestCase, gen_test
    from tornado.web import RequestHandler, Application
    class SimpleHandler(RequestHandler):
        def get(self):
            self.write('hello world')
    class TestCase(AsyncHTTPTestCase):
        def get_app(self):
            return Application([('/', SimpleHandler)])
        def fetch(self, *args, **kwargs):
            return self.http_client.fetch(self.get_url(*args), **kwargs)

# Generated at 2022-06-24 09:03:02.261198
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888, address="localhost")
    print(sockets)

    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET)
    print(sockets)
#test_bind_sockets()



# Generated at 2022-06-24 09:03:06.962582
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    res = ExecutorResolver()
    res.initialize()
    res.initialize(None)
    res.initialize(None, True)
    res.initialize(dummy_executor)
    res.initialize(dummy_executor, True)


# Generated at 2022-06-24 09:03:09.660882
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    import concurrent.futures
    resolver = ExecutorResolver(concurrent.futures.ThreadPoolExecutor(4))
    return True
test_ExecutorResolver()


# Generated at 2022-06-24 09:03:15.586233
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    """This test tests the method resolve of class DefaultExecutorResolver"""
    loop = IOLoop.current()
    resolver = DefaultExecutorResolver()
    address = 'www.google.com'
    port = 80
    result = loop.run_sync(lambda: resolver.resolve(address, port))
    assert result, 'Should not be empty'
    (family, address) = result[0]
    assert family == socket.AF_INET, 'Should be AF_INET'


# Generated at 2022-06-24 09:03:23.910977
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado import gen
    from tornado.platform.asyncio import to_asyncio_future

    import asyncio
    

    loop = asyncio.get_event_loop()
    host = "localhost"
    port = 80
    family = socket.AF_UNSPEC
    resolver = DefaultExecutorResolver()
    future = to_asyncio_future(resolver.resolve(host, port, family))
    results = loop.run_until_complete(future)
    return results



# Generated at 2022-06-24 09:03:27.100331
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    override_resolver = OverrideResolver(resolver=Resolver(), mapping=dict())
    assert isinstance(override_resolver, Resolver)

# Generated at 2022-06-24 09:03:28.045698
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    blockingresolver = BlockingResolver()



# Generated at 2022-06-24 09:03:36.017231
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert(is_valid_ip("127.0.0.1") == True)
    assert(is_valid_ip("255.255.255.255") == True)
    assert(is_valid_ip("0.0.0.0") == True)
    assert(is_valid_ip("256.0.0.0") == False)
    assert(is_valid_ip("") == False)
    assert(is_valid_ip("a") == False)
    assert(is_valid_ip("1234") == False)
    assert(is_valid_ip("0x7f.0x0.0x0.0x1") == False)
    assert(is_valid_ip("10.0.0.0/8") == False)

# Generated at 2022-06-24 09:03:38.008363
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = dict(ssl_version=ssl.PROTOCOL_TLSv1)     
    context = ssl_options_to_context(ssl_options)
    assert type(context) == ssl.SSLContext
    assert context.protocol == ssl.PROTOCOL_TLSv1
    return True

# Generated at 2022-06-24 09:03:47.464379
# Unit test for constructor of class Resolver
def test_Resolver():
    from tornado.netutil import BlockingResolver
    resolver = Resolver()
    r = resolver.resolve("http://www.google.com", 80)
    assert r is not None
    r = resolver.resolve("http://www.google.com", 80, socket.AF_INET)
    assert r is not None

    resolver = BlockingResolver()
    r = resolver.resolve("http://www.google.com", 80)
    assert r is not None
    r = resolver.resolve("http://www.google.com", 80, socket.AF_INET)
    assert r is not None



# Generated at 2022-06-24 09:03:49.900597
# Unit test for function bind_sockets
def test_bind_sockets():
    """test the bind_sockets function to make sure it can create a listening socket"""
    sockets = bind_sockets(8888, address="localhost")
    assert sockets is not None


# Generated at 2022-06-24 09:03:53.392659
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = tornado.netutil.DefaultExecutorResolver()
    mapping = {("login.example.com", 443): ("localhost", 1443)}
    test = tornado.netutil.OverrideResolver(resolver, mapping)
    test.close()

# Generated at 2022-06-24 09:04:00.632724
# Unit test for function add_accept_handler
def test_add_accept_handler():
    """
    import socket
    import antpyn
    from antpyn.netutil import add_accept_handler

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.listen(123)
    remove = add_accept_handler(listener, lambda conn, addr: None)
    """
    pass



# Generated at 2022-06-24 09:04:04.495392
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    resolver = OverrideResolver(None, {})
    assert resolver is not None



# Generated at 2022-06-24 09:04:06.119191
# Unit test for function bind_sockets
def test_bind_sockets():
    assert bind_sockets(0, "localhost")



# Generated at 2022-06-24 09:04:07.229540
# Unit test for method close of class Resolver
def test_Resolver_close():
    r = DefaultExecutorResolver()
    r.close()


# Generated at 2022-06-24 09:04:15.180261
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    import asyncio

    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()

    ip = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(ip)
    # assert ip == [('www.baidu.com', 80)]

if __name__ == '__main__':
    test_DefaultExecutorResolver()



# Generated at 2022-06-24 09:04:23.364500
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    from tornado_py3.concurrent import futures
    from tornado_py3.platform.asyncio import to_asyncio_future
    from tornado_py3.platform.asyncio import to_tornado_future

    class DummyExecutor(concurrent.futures.Executor):
        def submit(self, fn: Callable, *args: Any, **kwargs: Any) -> Any:
            return to_asyncio_future(to_tornado_future(fn(*args, **kwargs)))

    executor = DummyExecutor()
    x = ExecutorResolver(executor=executor, close_executor=True)
    assert not x.close_executor
    assert x.executor is executor
    assert x.io_loop is IOLoop.current()
    x.close()


# Generated at 2022-06-24 09:04:32.898224
# Unit test for function bind_sockets
def test_bind_sockets():
    # find a non-privileged port
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.bind(('',0))
    port=s.getsockname()[1]
    s.close()

    # call bind_sockets with that port
    sockets = bind_sockets(port)
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect(('127.0.0.1',port))
    sockets[0].close()
    sockets[1].close()


# Generated at 2022-06-24 09:04:34.423149
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    class Cls:
        pass

    res = ExecutorResolver(Cls(), True)



# Generated at 2022-06-24 09:04:47.259045
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    resolver = OverrideResolver(resolver=tornado.platform.caresresolver.CaresResolver(), mapping={"example.com": "127.0.1.1"})
    resolver1 = OverrideResolver(resolver=tornado.platform.caresresolver.CaresResolver(), mapping={"login.example.com": "localhost"})
    resolver2 = OverrideResolver(resolver=tornado.platform.twisted.TwistedResolver(), mapping={"login.example.com": "::1"})
    resolver3 = OverrideResolver(resolver=tornado.platform.twisted.TwistedResolver(), mapping={"login.example.com": "localhost"})
    pass


# Generated at 2022-06-24 09:04:58.112171
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from tornado import gen
    #init Resolver instance
    resolver = Resolver(io_loop=IOLoop.current())
    #Define host and port
    host = "127.0.0.1"
    port = 9000
    #Resolve hostname
    resolved = resolver.resolve(host, port)
    #Test future.result

# Generated at 2022-06-24 09:04:59.851465
# Unit test for method close of class Resolver
def test_Resolver_close():
    resolver = Resolver()
    resolver.close()
    return resolver

# Generated at 2022-06-24 09:05:07.419720
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    import unittest
    class OverrideResolverTest(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_close(self):
            m = MagicMock()
            res = OverrideResolver(resolver = m, mapping = {})
            res.close()
            assert m.close.call_count == 1
    unittest.main()


# Generated at 2022-06-24 09:05:18.633873
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    host = "www.baidu.com"
    port = 80
    family = socket.AF_INET
    result = resolver.resolve(host, port, family)
    print(result)
    # generator = resolver.resolve(host, port, family).__await__()
    # print(generator)
    # print(generator.send(None))
    # print(generator.send(None))
    # return
    # print(result.__await__())
    # result = next(result.__await__())
    # print(result)
    # result = next(result.__await__())
   

# Generated at 2022-06-24 09:05:20.112620
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-24 09:05:27.803919
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    host = '127.0.0.1'
    port = 65011
    family = socket.AF_INET
    resolver = ExecutorResolver()
    resolver.initialize()
    resolver.initialize(dummy_executor, close_executor=False)
    result = resolver.executor
    resolver.resolve(host, port, family)
    rst = resolver.io_loop.run_sync(resolver.resolve, host, port, family)
    resolver.close()



# Generated at 2022-06-24 09:05:34.525617
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    assert issubclass(Resolver, Configurable)
    assert Resolver.resolve.__doc__
    assert Resolver.close.__doc__
    assert hasattr(Resolver, "configurable_base")
    assert hasattr(Resolver, "configurable_default")
    assert Resolver.configurable_base() == Resolver
    assert Resolver.configurable_default() == DefaultExecutorResolver

# Generated at 2022-06-24 09:05:35.287624
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options_to_context({})

# Generated at 2022-06-24 09:05:36.969484
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    tr = ThreadedResolver()
    assert type(tr) == ThreadedResolver

# Generated at 2022-06-24 09:05:40.632519
# Unit test for constructor of class Resolver
def test_Resolver():
    Resolver()


# Generated at 2022-06-24 09:05:42.677317
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    resolver = BlockingResolver()
    assert(resolver.executor)
    resolver.close()



# Generated at 2022-06-24 09:05:48.950164
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    """
    Unit test for the constructor of class ExecutorResolver
    """
    resolver = ExecutorResolver(executor=None, close_executor=True)
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.resolver_future == None

    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-24 09:05:54.197083
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
  '''
  runner = unittest.TextTestRunner()
  print(runner.run(unittest.makeSuite(Test_BlockingResolver)))
  '''
  try:
    BlockingResolver()
    return 0
  except:
    return 1


# Generated at 2022-06-24 09:05:54.906703
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    ThreadedResolver._create_threadpool(10)



# Generated at 2022-06-24 09:05:57.421433
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    import tornado.concurrent
    resolver = ExecutorResolver()
    assert isinstance(resolver.executor, tornado.concurrent.futures.ThreadPoolExecutor)


# Generated at 2022-06-24 09:06:01.971467
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = Resolver.configure('tornado.netutil.DefaultExecutorResolver')

# Generated at 2022-06-24 09:06:05.305157
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve("localhost", 80))

# Generated at 2022-06-24 09:06:08.051927
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    assert isinstance(BlockingResolver(), Resolver)



# Generated at 2022-06-24 09:06:13.106046
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = OverrideResolver()
    assert resolver.resolver is None
    assert resolver.mapping is None

    resolver.initialize(Resolver(), {})
    #resolver.close()


# Generated at 2022-06-24 09:06:15.576505
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    num_threads = 10
    threadpool = ThreadedResolver._create_threadpool(num_threads)
    assert isinstance(threadpool, concurrent.futures.ThreadPoolExecutor)
    assert threadpool.__class__ == concurrent.futures.ThreadPoolExecutor
    threadpool.shutdown()


# Generated at 2022-06-24 09:06:19.104544
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    executor = None
    resolver = ExecutorResolver(executor)



# Generated at 2022-06-24 09:06:20.987720
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    resolver = ThreadedResolver()
    resolver.initialize()
    pass



# Generated at 2022-06-24 09:06:26.147295
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = None
    close_executor = True

    if executor is not None:
        self.executor = executor
        self.close_executor = close_executor
    else:
        self.executor = dummy_executor
        self.close_executor = False

