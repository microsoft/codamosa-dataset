

# Generated at 2022-06-24 08:56:34.795716
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    resolver = DefaultExecutorResolver()
    overrideresolver = OverrideResolver(resolver, {'example.com':'127.0.1.1'})
    assert overrideresolver._initialized   # pylint: disable=protected-access
    assert overrideresolver.mapping.get('example.com') == '127.0.1.1'
    assert overrideresolver.mapping.get('example') == None
    assert overrideresolver._resolver is resolver
    overrideresolver.close()
    overrideresolver.resolver = None
    assert overrideresolver._resolver is None
    


# Generated at 2022-06-24 08:56:37.401270
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    assert resolver.resolve('example.com', 80, socket.AF_UNSPEC) is not None

# Generated at 2022-06-24 08:56:38.440975
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    resolver = BlockingResolver()
    assert resolver is not None


# Generated at 2022-06-24 08:56:39.453393
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    obj = BlockingResolver()
    obj.initialize()



# Generated at 2022-06-24 08:56:40.940591
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    # blockingresolver = BlockingResolver()
    # blockingresolver.initialize()
    _ = BlockingResolver()


# Generated at 2022-06-24 08:56:42.839717
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = OverrideResolver()
    assert hasattr(resolver, "close")
    assert callable(getattr(resolver, "close", None))

# Generated at 2022-06-24 08:56:43.614315
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket('/tmp/test.sock')


# Generated at 2022-06-24 08:56:50.144669
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    er = ExecutorResolver()
    assert er.io_loop == IOLoop.current()
    assert er.executor == dummy_executor
    assert er.close_executor == False

    exec = concurrent.futures.ThreadPoolExecutor(2)
    er2 = ExecutorResolver(exec)
    assert er2.io_loop == IOLoop.current()
    assert er2.executor == exec
    assert er2.close_executor == True


# Generated at 2022-06-24 08:56:56.267225
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    ts = ThreadedResolver() # create an instance of ThreadedResolver
    ts.initialize(num_threads=10) # initialize(num_threads=10) will call super().initialize(executor=threadpool, close_executor=False)
    assert ts.close_executor == False
    assert ts.executor == threadpool



# Generated at 2022-06-24 08:56:58.697098
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    resolver = ExecutorResolver(close_executor=False)
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False



# Generated at 2022-06-24 08:57:03.284425
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import concurrent.futures
    import argparse
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    # Set up the argument parser.
    parser = argparse.ArgumentParser(description="ExecutorResolver")

    parser.add_argument('--executor', type=executor, default=None, help="")

    parser.add_argument('--close_executor', type=bool, default=True, help="")

    args = parser.parse_args()
    e = ExecutorResolver(executor=args.executor, close_executor=args.close_executor)
    e.close()


# Generated at 2022-06-24 08:57:11.640704
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    s = socket.socket()
    s.bind(("", 0))
    s.listen(1)
    port = s.getsockname()[1]
    wrapped = ssl_wrap_socket(s, context)

    s2 = socket.socket()
    s2.connect(("localhost", port))
    s2 = ssl_wrap_socket(s2, context)
    s2.write(b"foo")
    print(s2.read(3))
    s2.write(b"bar")
    print(s2.read(3))
    s2.close()
    wrapped.close()

# Generated at 2022-06-24 08:57:20.594593
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    executor = concurrent.futures.Executor()
    resolver = BlockingResolver(executor)
    assert resolver.executor is executor
    assert resolver.close_executor is True
    resolver = BlockingResolver(executor, False)
    assert resolver.executor is executor
    assert resolver.close_executor is False
    resolver = BlockingResolver(close_executor=False)
    assert isinstance(resolver.executor, dummy_executor)
    assert resolver.close_executor is False



# Generated at 2022-06-24 08:57:22.854323
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    tr = ThreadedResolver()
    tr.initialize()

# Generated at 2022-06-24 08:57:27.202477
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    server_socket = socket.socket()
    server_socket.bind(('127.0.0.1', 0))
    server_socket.listen(5)
    server_port = server_socket.getsockname()[1]
    client_socket = socket.socket()
    client_socket.connect(('127.0.0.1', server_port))
    server_ssl_socket = ssl.wrap_socket(server_socket)
    client_ssl_socket = ssl.wrap_socket(client_socket)
    client_ssl_socket.close()
    server_ssl_socket.close()
    client_socket.close()
    server_socket.close()


# Generated at 2022-06-24 08:57:33.147825
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    #TODO: Investigate why these resolvers do not work in any cases
    #from tornado.platform.twisted import TwistedResolver
    #from tornado.platform.caresresolver import CaresResolver

    test_host = "localhost"
    test_port = 8080

    async def _test_async():

        loop = IOLoop.current()

        def _test_resolver(r: Resolver):
            assert isinstance(r.resolve(test_host, test_port), Future)

        for r in (DefaultExecutorResolver(),):
            _test_resolver(r)

# Generated at 2022-06-24 08:57:38.305798
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    from concurrent.futures import Executor
    from concurrent.futures.thread import ThreadPoolExecutor
    er = ExecutorResolver()
    er.initialize(executor = ThreadPoolExecutor(max_workers = 1))
    er.close()

# Generated at 2022-06-24 08:57:39.972892
# Unit test for constructor of class Resolver
def test_Resolver():
    r = Resolver()
    assert r.resolve("localhost", 80) is not None
    r.close()


# Generated at 2022-06-24 08:57:42.967909
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    resolver = Resolver()
    mapping = {}
    overrider = OverrideResolver(resolver, mapping)
    assert overrider.resolver == resolver
    assert overrider.mapping == mapping


# Generated at 2022-06-24 08:57:52.989657
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('localhost', 0))
    sock.listen(1)
    port = sock.getsockname()[1]

    remove_handler = add_accept_handler(sock, lambda c,a: c.close())

    s = AsyncSocket()
    s.connect(('localhost', port))
    s.write(b"1234")
    s.close()
    IOLoop.current().start()
    remove_handler()



# Generated at 2022-06-24 08:57:59.725495
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2) # Purpose: TLSv1_2 only
    cert_path = os.path.join(os.path.dirname(os.path.realpath(__file__)),"../tests/assets/ca.crt")
    key_path = os.path.join(os.path.dirname(os.path.realpath(__file__)),"../tests/assets/ca.key")
    context.load_cert_chain(cert_path, key_path)
    context.verify_mode = ssl.CERT_REQUIRED
    context.set_ciphers('TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256')
    context.check_hostname = True
    context.load_default

# Generated at 2022-06-24 08:58:05.828628
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()

    loop = asyncio.get_event_loop()
    resolver = ExecutorResolver(close_executor=False)

    def done(future):
        print(future.result())
        resolver.close()

    future = resolver.resolve('www.qq.com', '80')
    future.add_done_callback(done)
    future.set_result(loop.run_until_complete(future))


# Generated at 2022-06-24 08:58:14.141476
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    """
    Test whether the code can run through the constructor of class ExecutorResolver
    """
    r = ExecutorResolver()
    assert r.io_loop == IOLoop.current()
    assert r.executor is not None
    assert r.close_executor is True

    r_other = ExecutorResolver(executor=r.executor, close_executor=False)
    assert r_other.io_loop == IOLoop.current()
    assert r_other.executor is r.executor
    assert r_other.close_executor is False



# Generated at 2022-06-24 08:58:17.868236
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    print("start test_OverrideResolver_close")
    resolver = tornado.netutil.Resolver()
    resolver.close()


# Generated at 2022-06-24 08:58:22.261661
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio

    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    loop = asyncio.get_event_loop()
    try:
        loop.stop()
    finally:
        loop.close()
    return True



# Generated at 2022-06-24 08:58:29.983848
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    _resolver = Resolver()
    mapping = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    resolver = OverrideResolver(_resolver, mapping)
    resolver.close()
    # Unit test for method initialize of class OverrideResolver

# Generated at 2022-06-24 08:58:37.972750
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    ssl_options = dic
    if isinstance(ssl_options, ssl.SSLContext):
        return ssl_options
    assert isinstance(ssl_options, dict)
    assert all(k in _SSL_CONTEXT_KEYWORDS for k in ssl_options), ssl_options
    # Can't use create_default_context since this interface doesn't
    # tell us client vs server.
    context = ssl.SSLContext(ssl_options.get("ssl_version", ssl.PROTOCOL_SSLv23))
    if "certfile" in ssl_options:
        context.load_cert_chain(
            ssl_options["certfile"], ssl_options.get("keyfile", None)
        )
    if "cert_reqs" in ssl_options:
        context.verify_mode

# Generated at 2022-06-24 08:58:39.027144
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    result = ExecutorResolver()
    assert result



# Generated at 2022-06-24 08:58:41.433271
# Unit test for constructor of class Resolver
def test_Resolver():
    Resolver.configurable_base()
    Resolver.configurable_default()


if hasattr(socket, "AF_UNSPEC"):
    _resolver = Resolver()



# Generated at 2022-06-24 08:58:47.386367
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    import asyncio
    from tornado.concurrent import Future
    from tornado.platform.asyncio import to_asyncio_future
    from typing import Any
    from typing import Awaitable
    from typing import Callable
    from typing import Coroutine
    from typing import List
    from typing import Tuple


    class Resolver:
        def close(self) -> None:
            pass

    class TestResolver:
        def test_close(self) -> None:
            resolver = Resolver()
            mapping = {}
            inst = OverrideResolver(resolver, mapping)
            inst.close()
            resolver.close.assert_called_once_with()



# Generated at 2022-06-24 08:58:52.629304
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    """Construct an instance of BlockingResolver"""
    resolver = BlockingResolver()
    assert resolver is not None



# Generated at 2022-06-24 08:58:53.314091
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    executor = ExecutorResolver()


# Generated at 2022-06-24 08:58:55.472305
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    a = BlockingResolver(123, True)
    a.initialize()
    a.resolve("localhost", 8080)  # type: ignore
    assert a.executor is not None



# Generated at 2022-06-24 08:59:02.878471
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado.concurrent import Future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from unittest.mock import call, patch, Mock, PropertyMock
    import inspect
    import builtins
    import asyncio
    import concurrent
    builtins.__dict__['_get_asyncio_event_loop_policy'] = Mock()
    builtins.__dict__['_get_asyncio_event_loop'] = Mock()
    builtins.__dict__['_set_running_loop'] = Mock()
    builtins.__dict__['_test_has_event_loop'] = Mock()
    builtins.__dict__['_clear_running_loop'] = Mock()
    builtins.__dict__['_current_ioloop'] = Mock()

# Generated at 2022-06-24 08:59:10.807540
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    assert isinstance(ssl_wrap_socket(
        socket.socket(), ssl.create_default_context()
    ), ssl.SSLSocket) == True
    assert isinstance(ssl_wrap_socket(
        socket.socket(), ssl.create_default_context(), cert_reqs=ssl.CERT_NONE
    ), ssl.SSLSocket) == True
    assert isinstance(ssl_wrap_socket(
        socket.socket(), ssl.create_default_context(), cert_reqs=ssl.CERT_REQUIRED
    ), ssl.SSLSocket) == True
    assert isinstance(ssl_wrap_socket(
        socket.socket(), ssl.create_default_context(), cert_reqs=ssl.CERT_OPTIONAL
    ), ssl.SSLSocket) == True

# Generated at 2022-06-24 08:59:12.663837
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    assert DefaultExecutorResolver().resolve('localhost', 40000)


# Generated at 2022-06-24 08:59:19.993098
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    async def run():
        resolver = DefaultExecutorResolver()
        # This should be executed in a thread
        result = await resolver.resolve(host="localhost", port=80)
        print(result)
    asyncio.run(run())



# Generated at 2022-06-24 08:59:23.233052
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    ssl_options = {
        'certfile': 'cert/client.crt',
        'keyfile': 'cert/client.key',
        'cert_reqs': ssl.CERT_NONE,
        'ssl_version': ssl.PROTOCOL_TLSv1
    }
    context = ssl_options_to_context(ssl_options)
    assert context.verify_mode == ssl.CERT_NONE
    assert context.protocol == ssl.PROTOCOL_TLSv1

# copied from backports.ssl_match_hostname

# Generated at 2022-06-24 08:59:28.547479
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado
    import concurrent.futures
    import socket
    from tornado.httpclient import HTTPClient, HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.concurrent import Future
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import AsyncIOMainLoop
    # New style classes

    class TestResolver(Resolver):
        def initialize(self):
            pass
        def resolve(self, host, port, *args, **kwargs):
            return super(TestResolver, self).resolve(host, port, *args, **kwargs)
    # Test class

    class FooClass(object):
        x = 1
        y = 2
        def foo(self, z):
            return self

# Generated at 2022-06-24 08:59:30.091568
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    resolver = AsyncResolver()
    mapping = {"example.com": "127.0.1.1"}
    instance = OverrideResolver(resolver, mapping)
    assert instance

# Generated at 2022-06-24 08:59:41.376310
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import time

    tempdir = tempfile.mkdtemp()
    filename_a = os.path.join(tempdir, "a.socket")
    filename_b = os.path.join(tempdir, "b.socket")

# Generated at 2022-06-24 08:59:42.573157
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    assert True

# Generated at 2022-06-24 08:59:48.591423
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import tornado
    import tornado.gen
    import tornado.ioloop
    import tornado.netutil

    @tornado.gen.coroutine
    def f():
        resolver = tornado.netutil.Resolver()
        print(resolver.resolve('www.yahoo.com', 80))

    tornado.ioloop.IOLoop.current().run_sync(f)


# This is an abstract base class that must be extended in a subclass.
DefaultExecutorResolver = make_system_resolver()

# Generated at 2022-06-24 08:59:51.864581
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor=None
    close_executor=True
    executor = dummy_executor
    close_executor = False
    executor.shutdown()
    executor = None  


# Generated at 2022-06-24 08:59:52.576654
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    resolver = ThreadedResolver()
    assert resolver is not None


# Generated at 2022-06-24 08:59:58.609739
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version":ssl.PROTOCOL_TLSv1,
        "certfile":"/home/vagrant/Codes/dianyi-1/tornado/cert.pem",
        "keyfile":"/home/vagrant/Codes/dianyi-1/tornado/privkey.pem",
        "ca_certs":"/home/vagrant/Codes/dianyi-1/tornado/cert.pem",
        "cert_reqs":ssl.CERT_NONE,
        "ciphers": "HIGH"
    }
    context = ssl_options_to_context(ssl_options)
    print(context)

# Generated at 2022-06-24 09:00:03.709809
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
  test_ssl_options = {
    "ssl_version": ssl.PROTOCOL_TLSv1,
    "certfile": "certfile",
    "keyfile": "keyfile",
    "cert_reqs": ssl.CERT_OPTIONAL,
    "ca_certs": "ca_certs",
    "ciphers": "ciphers"
  }
  test_ssl_context = ssl_options_to_context(test_ssl_options)  
  assert test_ssl_context.protocol==ssl.PROTOCOL_TLSv1
  


# Generated at 2022-06-24 09:00:04.730369
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    r = BlockingResolver()

# Generated at 2022-06-24 09:00:13.421102
# Unit test for constructor of class Resolver
def test_Resolver():
    r = Resolver()
    print(r)
    r2 = Resolver.configure('tornado.netutil.BlockingResolver')
    print(r2)

# Asynchronous DNS Resolver using the `concurrent.futures` package.
# This is the default implementation in Tornado 4.0 and later.
#
# While this is relatively efficient for applications and frameworks
# that make only a few DNS requests, it does not scale very well to
# applications that make many requests.  For example, this implementation
# does not perform well for large web crawlers.  See the `ThreadedResolver`
# for a solution to this problem.



# Generated at 2022-06-24 09:00:15.981161
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    r = OverrideResolver()
    r.initialize(DefaultExecutorResolver(), {})
    r.close()

# Generated at 2022-06-24 09:00:19.034280
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = OverrideResolver(resolver=None, mapping={})
    assert resolver.resolver == None
    assert resolver.mapping == {}
    assert resolver.close() == None
test_OverrideResolver_close()

# Generated at 2022-06-24 09:00:30.330228
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import errno
    import logging
    from tornado.ioloop import IOLoop
    from tornado.util import Configurable, errno_from_exception
    from tornado.iostream import IOStream
    import traceback
    def handle_stream(stream, address):
        print("handle stream")
        stream.close()
        print("handle stream over")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.bind(("localhost", 8888))
    sock.listen(128)
    remove_handler = add_accept_handler(sock, handle_stream)
    def stop():
        remove_handler()
        io_loop.stop()
    io_loop.add_timeout(time.time()+1, stop)
    io_loop.start()

# Generated at 2022-06-24 09:00:32.065243
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    resolver = OverrideResolver()
    assert resolver.resolver is None
    assert resolver.mapping == {}



# Generated at 2022-06-24 09:00:43.687952
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import unittest
    sock_path = tempfile.mkstemp(prefix='tornado.')[1]
    os.remove(sock_path)
    sock = bind_unix_socket(sock_path)
    assert isinstance(sock, socket.socket)
    os.remove(sock_path)

if hasattr(socket, "AF_UNIX") or hasattr(socket, "AF_LOCAL"):

    def add_accept_handler(
        sock: socket.socket, callback: Callable[[Any], None], io_loop: IOLoop
    ) -> None:
        """Adds an `IOLoop` event handler to accept new connections on ``sock``."""

# Generated at 2022-06-24 09:00:46.108414
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    # Test only specific usecase    
    resolver = BlockingResolver()
    mapping = {"localhost": ["127.0.0.1"]}
    obj = OverrideResolver(resolver,mapping)
    assert obj.resolver == resolver
    assert obj.mapping == mapping

# Generated at 2022-06-24 09:00:50.974745
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_TLS,
        "ciphers": "DHE-RSA-AES256-SHA:DHE-DSS-AES256-SHA:AES256-SHA",
        "certfile": "/home/apps/tornado_test/mydomain.com.crt",
        "keyfile": "/home/apps/tornado_test/mydomain.com.key",
        "cert_reqs": ssl.CERT_OPTIONAL,
        "ca_certs": "/home/apps/tornado_test/mydomain.com.ca-bundle",
    }
    ssl_options = ssl_options_to_context(ssl_options)
    print(ssl_options)



# Generated at 2022-06-24 09:00:58.316228
# Unit test for function add_accept_handler
def test_add_accept_handler():
    port = 8888
    io_loop = IOLoop.current()
    sockets = bind_sockets(port)
    for sock in sockets:
        sock.close()
    sockets[0].bind(("localhost", port))
    sockets[0].listen(128)
    remove_handler = add_accept_handler(sockets[0])
    sock, address = sockets[0].accept()
    sock.close()
    remove_handler()



# Generated at 2022-06-24 09:01:05.728707
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    def result(arg1, arg2, arg3):
        resolver, mapping = arg1, arg2
        resolver.close()
        pass
    resolver = DefaultExecutorResolver()
    m = {'a': 10}
    resolver = OverrideResolver(resolver, m)
    result(resolver, m, 'ai')



# Generated at 2022-06-24 09:01:13.459215
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    import asyncio
    import concurrent
    executor = dummy_executor
    close_executor = True
    class MyBlockingResolver(BlockingResolver):
        def initialize(self, executor=executor, close_executor=close_executor) -> None:
            super(MyBlockingResolver, self).initialize(executor, close_executor)
    blocking_resolver = MyBlockingResolver()
    assert blocking_resolver.io_loop is None
    assert blocking_resolver.executor is executor
    assert blocking_resolver.close_executor is close_executor
    IOLoop.configure(IOLoop)

# Generated at 2022-06-24 09:01:16.773561
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    test_host = 'localhost'
    test_port = 8080
    default_executor_resolver = DefaultExecutorResolver()
    result = default_executor_resolver.resolve(test_host, test_port)
    print(result)


# Generated at 2022-06-24 09:01:26.077934
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    from tornado.testing import AsyncTestCase, gen_test

    class TestExecutorResolver(ExecutorResolver):
        def initialize(
            self,
            executor: Optional[concurrent.futures.Executor] = None,
            close_executor: bool = True,
        ) -> None:
            self.io_loop = IOLoop.current()
            if executor is not None:
                self.executor = executor
                self.close_executor = close_executor
            else:
                self.executor = dummy_executor
                self.close_executor = False

        def close(self) -> None:
            if self.close_executor:
                self.executor.shutdown()
            self.executor = None  # type: ignore


# Generated at 2022-06-24 09:01:31.890497
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = Resolver()

# Generated at 2022-06-24 09:01:42.428088
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import subprocess
    def test_handler(sock: socket.socket, address: Any) -> None:
        pass

    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    sock.listen(5)
    port = sock.getsockname()[1]
    remove = add_accept_handler(sock, test_handler)

    subprocess.check_call(["nc", "-z", "127.0.0.1", str(port)])
    remove()

    subprocess.check_call(["nc", "-z", "127.0.0.1", str(port)])
    remove()

    sock.close()



# Generated at 2022-06-24 09:01:47.790140
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 0))
    io_loop = IOLoop.current()
    sock.listen(io_loop.READ)
    add_accept_handler(sock, io_loop)


_POLL_TIMEOUT = 3600.0



# Generated at 2022-06-24 09:01:49.241482
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    pass
# ./test/test_ExecutorResolver.py



# Generated at 2022-06-24 09:02:00.833870
# Unit test for method close of class Resolver
def test_Resolver_close():
    import os
    import signal
    import subprocess
    import sys
    
    from tornado.gen import sleep
    from tornado import iostream
    from tornado.ioloop import IOLoop
    from tornado.process import Subprocess
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.testing import AsyncTestCase
    from tornado.testing import bind_unix_socket
    from tornado.testing import gen_test
    import asyncio
    
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()

# Generated at 2022-06-24 09:02:07.657440
# Unit test for constructor of class Resolver
def test_Resolver():
    """A test method for class Resolver"""
    assert issubclass(Resolver, Configurable)
    assert Resolver.configurable_base() == Resolver
    assert Resolver.configurable_default() == DefaultExecutorResolver
    # test init
    resolver = Resolver()
    assert hasattr(resolver, "resolve")
    assert hasattr(resolver, "close")

    # test resolve
    resolver_resolve = resolver.resolve("www.baidu.com", 80)
    assert isinstance(resolver_resolve, Future)
    # test close
    resolver.close()



# Generated at 2022-06-24 09:02:19.892096
# Unit test for constructor of class Resolver
def test_Resolver():
    a = Resolver()
    a.close()

if sys.platform == "darwin":

    class _Resolver(Resolver):
        """Resolves using the native macOS resolver APIs."""

        _RESOLVE_TIMEOUT = 5

        def resolve(
            self,
            host: str,
            port: int,
            family: socket.AddressFamily = socket.AF_UNSPEC,
        ) -> Awaitable[List[Tuple[int, Any]]]:
            assert isinstance(host, str)

# Generated at 2022-06-24 09:02:25.974911
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    import tornado,time
    x = tornado.netutil.OverrideResolver(
        resolver = DefaultExecutorResolver(),
        mapping = {"example.com": "127.0.1.1"}
    )
    def callback(i):
        print(i)
    ioloop = tornado.ioloop.IOLoop.current()
    ioloop.add_future(x.resolve("example.com", 80), callback)
    ioloop.start()


# Generated at 2022-06-24 09:02:27.540374
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    assert isinstance(ssl_options_to_context({}), ssl.SSLContext)



# Generated at 2022-06-24 09:02:28.959627
# Unit test for method close of class Resolver
def test_Resolver_close():
    r = Resolver()
    r.close()
    return



# Generated at 2022-06-24 09:02:37.260917
# Unit test for function is_valid_ip
def test_is_valid_ip():
    # Valid ipv4 and ipv6 addresses.
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("::1")

    # Invalid ipv4 and ipv6 addresses.
    assert not is_valid_ip("")
    assert not is_valid_ip("abc")
    assert not is_valid_ip(":::1")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:1")
    assert not is_valid_ip("[::1]")



# Generated at 2022-06-24 09:02:39.467375
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    pass

# Generated at 2022-06-24 09:02:43.386324
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.concurrent import Future

    Resolver.configure("tornado.netutil.BlockingResolver")
    future = Resolver.instance().resolve("127.0.0.1", 8888)
    log.info("future get result %s", future.result())



# Generated at 2022-06-24 09:02:47.086790
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    with concurrent.futures.ThreadPoolExecutor() as executor:
        resolver = ExecutorResolver(
            executor, close_executor=False
        )
        assert resolver.executor is not None
        resolver.close()
        assert resolver.executor is None



# Generated at 2022-06-24 09:02:57.250270
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    from typing import Any, Dict

    # type: (Dict[str, Any]) -> None

    # Check that ssl_options_to_context works with an empty dict.
    context = ssl_options_to_context({})
    assert context.check_hostname
    assert context.verify_mode == ssl.CERT_REQUIRED

    # Check that ssl_options_to_context works with a dict containing
    # common ssl_options keyword arguments.

# Generated at 2022-06-24 09:02:59.235818
# Unit test for constructor of class Resolver
def test_Resolver():
    resolver = Resolver()
    assert isinstance(resolver, Resolver)
    assert isinstance(resolver, Configurable)



# Generated at 2022-06-24 09:03:03.289958
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    # FIXME: the unit test is not complete
    #        just test if __init__ works
    resolver = BlockingResolver()
    mapping = {}
    OverrideResolver(resolver, mapping).resolve('localhost', 80)


# Generated at 2022-06-24 09:03:05.053653
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    assert(isinstance(DefaultExecutorResolver(), DefaultExecutorResolver))



# Generated at 2022-06-24 09:03:06.376540
# Unit test for function bind_sockets
def test_bind_sockets():
    assert len(bind_sockets(None)) in (1, 2)
    # TODO(bdarnell): more tests


# Generated at 2022-06-24 09:03:07.626603
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    resolver = ExecutorResolver(dummy_executor, False)
    resolver.close()


# Dummy executor for ExecutorResolver

# Generated at 2022-06-24 09:03:08.303768
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    assert True

# Generated at 2022-06-24 09:03:08.906535
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    resolver = DefaultExecutorResolver()



# Generated at 2022-06-24 09:03:10.767441
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ssock = ssl_wrap_socket(socket, {})
    ssock.close()

# Generated at 2022-06-24 09:03:13.842085
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver() # type: DefaultExecutorResolver
    result = resolver.resolve("google.com", 80, socket.AF_UNSPEC)
    print(result)
    pass
test_DefaultExecutorResolver_resolve()



# Generated at 2022-06-24 09:03:15.880820
# Unit test for constructor of class Resolver
def test_Resolver():
    DefaultExecutorResolver()
    BlockingResolver()
    ThreadedResolver()
    OverrideResolver()
    TornadoResolver()



# Generated at 2022-06-24 09:03:22.241066
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = None
    if isinstance(ssl_options, ssl.SSLContext):
        ssl_options = ssl_options.get_ssl_options()
    context = ssl_options_to_context(ssl_options or {})
    print (context)
test_ssl_options_to_context()


# Generated at 2022-06-24 09:03:29.605785
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    resolver = Resolver()
    test_host = 'google.com'
    test_port = 80
    result = resolver.resolve(host=test_host,port=test_port)
    print('type(result):',type(result))
    print('result is:',result)
    print('result.done() is:',result.done())
    result.add_done_callback(lambda p: print('p is:',p))
    tornado.ioloop.IOLoop.instance().start()
test_Resolver_resolve()


# Generated at 2022-06-24 09:03:37.085372
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import unittest

if hasattr(socket, "AF_UNIX"):
    def add_accept_unix_handler(
        sock: socket.socket, callback: Callable[[socket.socket, Any], None]
    ) -> Callable[[], None]:
        """Adds an `.IOLoop` event handler to accept new connections on ``sock``.

        Unix sockets do not provide an easy way to get the address of the
        other end, so only a single argument to the callback is provided.
        """
        return add_accept_handler(sock, lambda conn, addr: callback(conn))


# Generated at 2022-06-24 09:03:49.355774
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    resolver = DefaultExecutorResolver()
    assert(resolver)

@overload
async def resolve(
    host: str,
    port: int = None,
    family: socket.AddressFamily = socket.AF_UNSPEC,
) -> List[Tuple[int, Any]]:
    ...

@overload
async def resolve(
    host: str,
    port: int,
    family: socket.AddressFamily,
    callback: Callable[[List[Tuple[int, Any]]], None],
) -> None:
    ...



# Generated at 2022-06-24 09:03:53.000759
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    from tornado.platform.twisted import TwistedResolver
    from tornado.platform.asyncio import AsyncIOMainLoop
    tr = TwistedResolver()
    tr.initialize(resolver=None)
    tr.close()
    AsyncIOMainLoop().close()

# Generated at 2022-06-24 09:03:54.961214
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    # Initialize the BlockingResolver instance.
    resolver = BlockingResolver()
    return None

# Generated at 2022-06-24 09:04:01.795525
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    io_loop = IOLoop()
    with ExecutorResolver(executor="", io_loop=io_loop, close_executor="") as er:
        assert er.executor == ""
        assert er.io_loop == io_loop
        assert er.close_executor == ""
        assert er is not None



# Generated at 2022-06-24 09:04:11.629717
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    host = "example.com"
    port = 80
    family = socket.AF_UNSPEC
    # mock resolver.resolve method and return a value
    resolver.resolve = mock.MagicMock(return_value = [('192.168.1.3',32768)])
    assert resolver.resolve(host,port,family) is not None
    # mock resolver.resolve method and return None
    resolver.resolve = mock.MagicMock(return_value = None)
    assert resolver.resolve(host,port,family) is None


# Generated at 2022-06-24 09:04:13.937861
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    """
    Test case for method close of class OverrideResolver
    """
    pass



# Generated at 2022-06-24 09:04:15.889385
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) > 0



# Generated at 2022-06-24 09:04:21.988437
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    from tornado.ioloop import IOLoop
    import tornado.platform.asyncio
    if tornado.version_info < (6, 0):
        raise RuntimeError("not support tornado6.0")
    tornadolog.enable_pretty_logging()
    app = web.Application([(r"/(.*)", MainHandler)])
    app.listen(8888,address="127.0.0.1")
    ioloop = IOLoop.current()
    ioloop.run_forever()
    ioloop.close()


# Generated at 2022-06-24 09:04:23.835048
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    r = ThreadedResolver()
    r.initialize()


# Generated at 2022-06-24 09:04:26.225778
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    # TODO: fill in the tests
    resolver.close()



# Generated at 2022-06-24 09:04:31.862393
# Unit test for function is_valid_ip
def test_is_valid_ip():
    ip = "www.google.com"
    expect = is_valid_ip(ip)
    assert expect == False
    ip = "1.1.1.1"
    expect = is_valid_ip(ip)
    assert expect == True
test_is_valid_ip()



# Generated at 2022-06-24 09:04:35.873286
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    from tornado.netutil import DefaultExecutorResolver, ExecutorResolver
    def test_raise_NoResultError():
        resolver = DefaultExecutorResolver()
        try:
            resolver.close()
            assert True
        except NoResultError:
            assert False
        except:
            assert False

# Generated at 2022-06-24 09:04:48.024087
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    uut = Resolver.configure("tornado.netutil.OverrideResolver")
    resolver = BlockingResolver()
    uut.initialize(resolver, {"1.1.1.1": "2.2.2.2", "3.3.3.3": "4.4.4.4"})
    assert uut.resolve("1.1.1.1", 1) == resolver.resolve("2.2.2.2", 1)
    assert uut.resolve("2.2.2.2", 1) == resolver.resolve("2.2.2.2", 1)
    assert uut.resolve("3.3.3.3", 1) == resolver.resolve("4.4.4.4", 1)
    uut.close()
    resolver.close

# Generated at 2022-06-24 09:04:53.471578
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    context = ssl_options_to_context({
        'ssl_version': ssl.PROTOCOL_TLSv1,
        'certfile': 'fake_certfile',
        'keyfile': 'fake_keyfile',
        'cert_reqs': ssl.CERT_NONE,
        'ca_certs': 'fake_ca_certs',
        'ciphers': 'fake_ciphers'
    })
    context_from_ssl_options = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
    context_from_ssl_options.load_cert_chain('fake_certfile', 'fake_keyfile')
    context_from_ssl_options.verify_mode = ssl.CERT_NONE
    context_from_ssl_options.load_verify_

# Generated at 2022-06-24 09:05:06.532957
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    def test() -> None:
        import gevent
        import gevent.monkey
        from tornado.platform.asyncio import AsyncIOLoop
        from tornado.platform.futures import Future
        from concurrent.futures import ProcessPoolExecutor
        from concurrent.futures import ThreadPoolExecutor
        import tornado.netutil
        from concurrent.futures import Future
        from concurrent.futures import Executor
        from concurrent.futures import ThreadPoolExecutor
        from concurrent.futures import ProcessPoolExecutor
        from concurrent.futures import Executor
        from concurrent.futures._base import Executor


# Generated at 2022-06-24 09:05:09.720799
# Unit test for constructor of class Resolver
def test_Resolver():
    resolver = Resolver()
    assert isinstance(resolver, Resolver)
    assert isinstance(resolver, Configurable)


# Generated at 2022-06-24 09:05:11.905067
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    resolver = DefaultExecutorResolver()
    assert type(resolver) == DefaultExecutorResolver


# Generated at 2022-06-24 09:05:13.235013
# Unit test for constructor of class Resolver
def test_Resolver():
    Resolver()


# Generated at 2022-06-24 09:05:15.114450
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    resolver = ExecutorResolver(dummy_executor, True)
    resolver.close()


# Generated at 2022-06-24 09:05:19.517142
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado.testing import AsyncTestCase, gen_test
    
    class MyTest(AsyncTestCase):
        @gen_test
        def test_resolver(self):
            r = DefaultExecutorResolver()
            result = yield r.resolve('localhost', 5000, socket.AF_UNSPEC)
            self.assertIsNotNone(result)

# Generated at 2022-06-24 09:05:23.599132
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    # We're not testing in depth here because the unit test for the parent class already
    # covers this method.
    resolver = OverrideResolver()
    resolver.initialize(BlockingResolver(), {"hostname": "localhost",})
    resolver.resolve("hostname", 1024)



# Generated at 2022-06-24 09:05:25.415227
# Unit test for method close of class Resolver
def test_Resolver_close():
    resolver = Resolver()
    assert resolver


# Generated at 2022-06-24 09:05:25.817242
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    pass



# Generated at 2022-06-24 09:05:27.694486
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 09:05:39.427520
# Unit test for method close of class Resolver
def test_Resolver_close():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.ioloop import IOLoop
    import asyncio
    import platform

    async def test_asyncio_Resolver() -> None:
        if not hasattr(socket, "AF_UNSPEC"):
            raise unittest.SkipTest("AF_UNSPEC is not defined")

        loop = IOLoop()
        AsyncIOMainLoop().install()
        loop.make_current()

        r = Resolver()
        try:
            await r.resolve('google.com', 80)
        finally:
            r.close()

    ########################################################################


# Generated at 2022-06-24 09:05:46.936649
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    resolver = BlockingResolver()

if hasattr(concurrent.futures, "ThreadPoolExecutor"):

    class ThreadedResolver(ExecutorResolver):
        """`Resolver` implementation based on `concurrent.futures`.

        This implementation should be faster than `BlockingResolver`
        on CPython because it uses multiple threads.  However, it
        depends on `concurrent.futures`, which is not available on
        PyPy or on older versions of CPython.

        .. deprecated:: 5.0
           The default `Resolver` now uses `.IOLoop.run_in_executor`; use that instead
           of this class.
        """


# Generated at 2022-06-24 09:05:58.612898
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado import concurrent
    from concurrent import futures
    from concurrent.futures import Executor
    from concurrent.futures import Future
    from concurrent.futures import ThreadPoolExecutor
    from typing import Any
    from typing import Callable
    from typing import Optional
    from typing import Tuple
    import asyncio
    import concurrent.futures
    import concurrent.futures
    import functools
    import sys
    import tornado.ioloop
    import tornado.platform.asyncio
    import unittest
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import functools
    import tornado.concurrent
    import tornado.platform.asyncio
   

# Generated at 2022-06-24 09:06:00.531346
# Unit test for method close of class Resolver
def test_Resolver_close():
    pass


alias = TypeAlias(Callable[[socket.socket, Any], None])



# Generated at 2022-06-24 09:06:09.670894
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    mapping = {
        # Hostname to host or ip
        "example.com": "127.0.1.1",

        # Host+port to host+port
        ("login.example.com", 443): ("localhost", 1443),

        # Host+port+address family to host+port
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    orresolver = OverrideResolver()
    orresolver.initialize(DummyResolver(), mapping)
    orresolver.close()
    orresolver.resolve("example.com", 443)
    orresolver.resolve("login.example.com", 443)
    orresolver.resolve("login.example.com", 443, socket.AF_INET6)


# Generated at 2022-06-24 09:06:16.128032
# Unit test for function bind_sockets
def test_bind_sockets():
    # bind_sockets has no return value, but it should return a list of socket.socket
    # TODO: more test
    assert isinstance(bind_sockets(12345), list)
    assert type(bind_sockets(12345)) == list
    assert type(bind_sockets(12345)[0]) == socket.socket



# Generated at 2022-06-24 09:06:23.341904
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("")
    assert not is_valid_ip(b"")
    assert not is_valid_ip(b"\x00")
    assert not is_valid_ip(u"\u0001")



# Generated at 2022-06-24 09:06:31.261680
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.ioloop
    import tornado
    import io
    import sys
    import contextlib

    @contextlib.contextmanager
    def silence():
        with io.StringIO() as buf, contextlib.redirect_stdout(buf):
            yield buf

    #####################
    # Test if client_connected is True:
    test_host = "www.google.com"
    test_port = 80
    test_family = socket.AF_INET
    # Create the Resolver object
    resolver_obj = tornado.netutil.DefaultExecutorResolver()
    # Test that the object is a Resolver object
    assert isinstance(resolver_obj, tornado.netutil.Resolver), \
        "The object is not a Resolver object"
    # Test that the object can resolve the address