

# Generated at 2022-06-18 10:23:40.444223
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("www.google.com", 443))
    s = tornado.netutil.ssl_wrap_socket(s, ssl.PROTOCOL_SSLv23)
    s.send(b"GET / HTTP/1.0\r\n\r\n")
    print(s.recv(4096))
    s.close()


# Generated at 2022-06-18 10:23:45.076397
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    assert resolver.resolve("host", 80) is not None


# Generated at 2022-06-18 10:23:46.511247
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = OverrideResolver()
    resolver.close()
    assert True


# Generated at 2022-06-18 10:23:51.033135
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:24:03.523322
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_TLSv1,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_TLSv1
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname == False
    assert context.options == 0
    assert context.verify_flags == 0
    assert context.ciphers() == "ciphers"
    assert context

# Generated at 2022-06-18 10:24:14.787427
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(128)
            self.io_loop = IOLoop.current()
            self.stop_flag = threading.Event()
            self.accepted_count = 0

        def tearDown(self):
            self.stop_flag.set()
            self.io_loop.stop()
            self.sock.close()
            super(TestAddAcceptHandler, self).tearDown

# Generated at 2022-06-18 10:24:27.088588
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("127.0.0.1 ")
    assert not is_valid_ip("")
    assert not is_valid_ip(" ")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("localhost:80")
    assert not is_valid_ip("localhost ")

# Generated at 2022-06-18 10:24:30.227542
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    result = resolver.resolve('www.baidu.com', 80)
    print(result)


# Generated at 2022-06-18 10:24:33.791862
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    loop = IOLoop.current()
    resolver = DefaultExecutorResolver()
    result = loop.run_sync(lambda: resolver.resolve("www.google.com", 80))
    assert result == [(2, ('216.58.194.174', 80))]


# Generated at 2022-06-18 10:24:36.518816
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping=None)
    host = "example.com"
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)
    return


# Generated at 2022-06-18 10:24:58.318159
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping=None)
    host = "host"
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:25:10.050997
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()

# Generated at 2022-06-18 10:25:13.588052
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    host = "example.com"
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:25:17.088164
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:25:19.166246
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, None)
    assert resolver.resolve(None, None, None) is not None


# Generated at 2022-06-18 10:25:27.418932
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()

# Generated at 2022-06-18 10:25:29.362640
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:25:32.482384
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:25:40.157898
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def test():
        resolver = DefaultExecutorResolver()
        result = await resolver.resolve("www.google.com", 80)
        print(result)
    asyncio.get_event_loop().run_until_complete(test())



# Generated at 2022-06-18 10:25:44.197011
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    host = 'host'
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:26:36.351430
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:26:42.521995
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:26:51.100878
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("www.baidu.com", 443))
    ssl_socket = tornado.netutil.ssl_wrap_socket(s, ssl_options=None, server_hostname="www.baidu.com")
    ssl_socket.send(b"GET / HTTP/1.1\r\nHost: www.baidu.com\r\n\r\n")
    print(ssl_socket.recv(1024))
    ssl_socket.close()
    s.close()

# test_ssl_wrap_socket()


# Generated at 2022-06-18 10:26:52.341667
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-18 10:26:53.985776
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:26:56.776990
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("www.google.com", 80)
    assert result is not None


# Generated at 2022-06-18 10:27:09.769212
# Unit test for method initialize of class ExecutorResolver

# Generated at 2022-06-18 10:27:21.627363
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.thread = threading.Thread(target=self.run_loop)
            self.thread.daemon = True
            self.thread.start()

        def tearDown(self):
            self.stop()
            self.thread.join()
            self.sock.close()
            super(TestAddAcceptHandler, self).tearDown()


# Generated at 2022-06-18 10:27:27.738252
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    async def test():
        resolver = DefaultExecutorResolver()
        result = await resolver.resolve('www.baidu.com', 80)
        print(result)
    asyncio.run(test())

# Generated at 2022-06-18 10:27:29.189974
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()



# Generated at 2022-06-18 10:30:01.294005
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import os
    import socket
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unix_socket, gen_test
    from tornado.test.util import unittest
    from tornado.util import errno_from_exception
    from tornado.netutil import add_accept_handler
    class AddAcceptHandlerTest(AsyncTestCase):
        def setUp(self):
            super(AddAcceptHandlerTest, self).setUp()
            self.sock, self.port = bind_unix_socket('', 'test_add_accept_handler')
            self.addCleanup(os.remove, self.sock.getsockname())
            self.addCleanup(self.sock.close)
            self.connections = []

# Generated at 2022-06-18 10:30:12.803895
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.web import RequestHandler, Application
    import ssl
    import os
    import time
    import socket
    import logging
    import sys
    import json
    import threading
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio


# Generated at 2022-06-18 10:30:14.424855
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:30:18.686194
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.google.com', 80))
    print(result)



# Generated at 2022-06-18 10:30:24.741130
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    sock.listen(1)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()
    sock.close()
# test_add_accept_handler()



# Generated at 2022-06-18 10:30:36.565296
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("www.google.com", 80)
    assert result is not None
    assert isinstance(result, Awaitable)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
    assert isinstance(result, Future)
   

# Generated at 2022-06-18 10:30:38.558669
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # test_Resolver_resolve is the Resolver.resolve() method
    host = 'localhost'
    port = 80
    family = socket.AF_UNSPEC
    resolver = Resolver()
    result = resolver.resolve(host, port, family)
    print(result)


# Generated at 2022-06-18 10:30:41.566083
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:30:52.583705
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.netutil import bind_sockets, add_accept_handler
    from tornado.util import errno_from_exception
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    class AddAcceptHandlerTest(AsyncTestCase):
        def setUp(self):
            super(AddAcceptHandlerTest, self).setUp()
            self.sockets = bind_sockets(0)
            self.port = self.sockets[0].getsockname()[1]
            self.connections = []  # type: List[socket.socket]

# Generated at 2022-06-18 10:30:59.910938
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import socket
    import stat
    import errno
    import shutil
    import functools
    import contextlib
    import time

    def _test_unix_socket(path):
        sock = bind_unix_socket(path)
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.connect(path)
        client.close()
        sock.close()
        os.remove(path)

    def test_unix_socket_path_too_long():
        path = "/" + "a" * 100
        with pytest.raises(ValueError):
            _test_unix_socket(path)

    def test_unix_socket_path_empty():
        path = ""