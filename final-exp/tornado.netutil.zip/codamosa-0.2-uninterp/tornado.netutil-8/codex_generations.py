

# Generated at 2022-06-18 10:23:29.210476
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Test for method close(self)
    # of class ExecutorResolver
    resolver = ExecutorResolver()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:23:32.135042
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def test():
        resolver = DefaultExecutorResolver()
        result = await resolver.resolve("www.google.com", 80)
        print(result)
    asyncio.get_event_loop().run_until_complete(test())



# Generated at 2022-06-18 10:23:42.542921
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("[::1]")
    assert not is_valid_ip("[::1]:80")
    assert not is_valid_ip("[1:2:3:4:5:6:7:8]")

# Generated at 2022-06-18 10:23:47.175905
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor)
    resolver.close()
    assert resolver.executor == None
    assert resolver.close_executor == True



# Generated at 2022-06-18 10:23:48.888505
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:23:50.558221
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:23:55.018434
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:24:08.314718
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:24:11.072158
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("localhost", 80)
    assert result is not None


# Generated at 2022-06-18 10:24:22.661007
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import tempfile
    import shutil
    import socket
    import errno
    import stat
    import time
    import unittest
    import functools
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.auto import set_close_exec
    from tornado.netutil import bind_unix_socket
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.testing import bind_unix_socket_and_listen
    from tornado.testing import bind_unix_socket_and_listen_with_namespace
    from tornado.testing import bind_unix_socket_and_listen_with_namespace_and_cleanup
    from tornado.testing import bind_unix_socket_

# Generated at 2022-06-18 10:25:00.635787
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver = ExecutorResolver(executor, close_executor=True)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    assert resolver.io_loop == IOLoop.current()
    resolver.close()
    assert resolver.executor == None
    assert resolver.close_executor == True
    assert resolver.io_loop == IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver = ExecutorResolver(executor, close_executor=False)
    assert resolver.executor == executor
    assert resolver.close_executor == False
    assert resolver.io_loop

# Generated at 2022-06-18 10:25:10.414345
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado

# Generated at 2022-06-18 10:25:11.378959
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:25:16.173777
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    sock.listen(1)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()
    sock.close()


# Generated at 2022-06-18 10:25:26.011536
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import stat
    import socket
    import tempfile
    import unittest
    import errno
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.netutil import bind_unix_socket

    class BindUnixSocketTest(AsyncTestCase):
        def setUp(self):
            super(BindUnixSocketTest, self).setUp()
            self.sock_file = tempfile.mktemp()

        def tearDown(self):
            super(BindUnixSocketTest, self).tearDown()
            try:
                os.remove(self.sock_file)
            except OSError as e:
                if e.errno != errno.ENOENT:
                    raise

        @gen_test
        def test_bind_unix_socket(self):
            sock = bind_

# Generated at 2022-06-18 10:25:38.939815
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:25:50.714206
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import threading
    import time
    import unittest
    import urllib.parse
    import weakref
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:26:01.458221
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_NONE
    assert context.check_hostname == False
    assert context.options & ssl.OP_NO_COMPRESSION == ssl.OP_NO_COMPRESSION

# Generated at 2022-06-18 10:26:13.400929
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve("localhost", 8080))
    assert result == [(2, ('127.0.0.1', 8080))]
    result = loop.run_until_complete(resolver.resolve("localhost", 8080, socket.AF_INET))
    assert result == [(2, ('127.0.0.1', 8080))]
    result = loop.run_until_complete(resolver.resolve("localhost", 8080, socket.AF_INET6))

# Generated at 2022-06-18 10:26:21.916541
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:27:06.011782
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:27:15.771058
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 80) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)


# Generated at 2022-06-18 10:27:21.250901
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor


# Generated at 2022-06-18 10:27:32.505982
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, address="[::1]")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6

# Generated at 2022-06-18 10:27:44.856912
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    resolver.initialize(resolver, {'example.com': '127.0.1.1'})
    resolver.resolve('example.com', 80, socket.AF_INET)
    resolver.resolve('example.com', 80, socket.AF_INET6)
    resolver.resolve('example.com', 80)
    resolver.resolve('example.com', 80, socket.AF_INET6)
    resolver.resolve('example.com', 80, socket.AF_INET)
    resolver.resolve('example.com', 80)
    resolver.resolve('example.com', 80, socket.AF_INET)
    resolver.resolve('example.com', 80, socket.AF_INET6)
    resolver.res

# Generated at 2022-06-18 10:27:49.866381
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor)
    resolver.close()
    assert resolver.executor is None
    assert resolver.close_executor is True
    assert resolver.io_loop is IOLoop.current()


# Generated at 2022-06-18 10:27:53.462894
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:27:56.707413
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    resolver.resolve('localhost', 80)
    resolver.close()



# Generated at 2022-06-18 10:27:59.890552
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Test for method initialize( ... )
    # of class ExecutorResolver
    # This method is not tested, because it is a constructor.
    pass


# Generated at 2022-06-18 10:28:04.336377
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, None)
    host = "example.com"
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)
    resolver.resolve(host, port)
    resolver.resolve(host)


# Generated at 2022-06-18 10:28:36.058715
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:28:48.062432
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:28:48.871278
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()



# Generated at 2022-06-18 10:28:53.847339
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    result = loop.run_sync(lambda: resolver.resolve("www.google.com", 80))
    assert result == [(2, ('172.217.16.14', 80))]


# Generated at 2022-06-18 10:28:59.736671
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = Resolver()
    mapping = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    override_resolver = OverrideResolver(resolver, mapping)
    assert override_resolver.resolver == resolver
    assert override_resolver.mapping == mapping
    assert override_resolver.resolve("example.com", 80) == resolver.resolve("127.0.1.1", 80)
    assert override_resolver.resolve("login.example.com", 443) == resolver.resolve("localhost", 1443)

# Generated at 2022-06-18 10:29:02.520227
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # test_Resolver_resolve is the Resolver.resolve() method
    host = "www.google.com"
    port = 80
    family = socket.AF_INET
    resolver = Resolver()
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:29:07.146559
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/tmp/test_bind_unix_socket.sock")
    assert sock.family == socket.AF_UNIX
    assert sock.type == socket.SOCK_STREAM
    sock.close()
    os.remove("/tmp/test_bind_unix_socket.sock")



# Generated at 2022-06-18 10:29:17.178652
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncI

# Generated at 2022-06-18 10:29:21.504300
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver = ExecutorResolver(executor, close_executor=True)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:29:33.497890
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888

# Generated at 2022-06-18 10:30:31.330059
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping=None)
    host = "example.com"
    port = 80
    family = socket.AF_UNSPEC
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:30:42.846890
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:30:53.414622
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()
    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_IN

# Generated at 2022-06-18 10:30:58.485548
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket('/tmp/test.sock')
    assert sock.family == socket.AF_UNIX
    assert sock.type == socket.SOCK_STREAM
    assert sock.proto == 0
    assert sock.fileno() > 0
    assert sock.getsockname() == '/tmp/test.sock'
    assert sock.getpeername() == None
    sock.close()
    os.remove('/tmp/test.sock')


# Generated at 2022-06-18 10:31:01.156807
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("www.google.com", 80)
    assert result is not None


# Generated at 2022-06-18 10:31:03.380614
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:31:11.385534
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    executor = concurrent.futures.ThreadPoolExecutor(1)
    resolver.initialize(executor, True)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    resolver.close()
    assert resolver.executor == None
    executor.shutdown()


# Generated at 2022-06-18 10:31:19.826961
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 80) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)



# Generated at 2022-06-18 10:31:25.071993
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('localhost', 80))
    print(result)
    loop.close()


# Generated at 2022-06-18 10:31:27.225713
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    for sock in sockets:
        sock.close()


# Generated at 2022-06-18 10:32:35.048122
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = ExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(result)
    loop.close()

# Generated at 2022-06-18 10:32:40.413364
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Test case 1
    resolver = OverrideResolver()
    resolver.initialize(resolver, mapping={})
    host = "example.com"
    port = 443
    family = socket.AF_INET
    resolver.resolve(host, port, family)
    # Test case 2
    resolver = OverrideResolver()
    resolver.initialize(resolver, mapping={})
    host = "example.com"
    port = 443
    family = socket.AF_INET6
    resolver.resolve(host, port, family)
    # Test case 3
    resolver = OverrideResolver()
    resolver.initialize(resolver, mapping={})
    host = "example.com"
    port = 443
    family = socket.AF_UNSPEC

# Generated at 2022-06-18 10:32:49.821966
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest
    import tornado.testing
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.sock, self.port = tornado.testing.bind_unused_port()
            self.sock.listen(5)
            self.addCleanup(self.io_loop.close)