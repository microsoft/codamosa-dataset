

# Generated at 2022-06-18 10:24:03.572796
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.test.util import unittest

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.thread = threading.Thread(target=self.run_loop)
            self.thread.start()

        def tearDown(self):
            self.io_loop.add_callback(self.io_loop.stop)
            self.thread.join()
            super(TestAddAcceptHandler, self).tearDown()


# Generated at 2022-06-18 10:24:14.829371
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import stat
    import errno
    import socket
    import shutil
    import time

    def test_unix_socket(file, mode, backlog):
        sock = bind_unix_socket(file, mode, backlog)
        assert sock.fileno() >= 0
        assert sock.getsockname() == file
        sock.close()
        os.remove(file)

    def test_unix_socket_exception(file, mode, backlog):
        try:
            test_unix_socket(file, mode, backlog)
        except Exception as e:
            assert isinstance(e, ValueError)
            assert e.args[0] == "File %s exists and is not a socket" % file


# Generated at 2022-06-18 10:24:16.897278
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:24:22.870413
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("localhost", 0))
    sock.listen(1)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()


# Generated at 2022-06-18 10:24:29.556269
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    ioloop = tornado.ioloop.IOLoop.current()
    resolver = DefaultExecutorResolver()
    async def test():
        result = await resolver.resolve("www.google.com", 80)
        print(result)
    ioloop.run_sync(test)



# Generated at 2022-06-18 10:24:34.163058
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.auto
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.escape
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.auto
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.escape
    import tornado

# Generated at 2022-06-18 10:24:40.384682
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.util import b
    from tornado.netutil import add_accept_handler
    from tornado.platform.auto import set_close_exec
    from tornado.test.util import unittest

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sockets = []  # type: List[socket.socket]
            self.port = None  # type: Optional[int]
            self.server_sock, self.port = bind_unused_port()
            self.server_sock.listen(5)

# Generated at 2022-06-18 10:24:52.061203
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:25:02.686362
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import tornado.testing
    import tornado.ioloop
    import tornado.netutil
    import tornado.iostream
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.asyncio.asyncio_events
    import tornado.platform.asyncio.base
    import tornado.platform.asyncio.events
    import tornado.platform.asyncio.ioloop
    import tornado.platform.asyncio.tcp_server
    import tornado.platform.asyncio.tcp_client
    import tornado.platform.asyncio.udp_server
    import tornado.platform.asyncio.udp_client
    import tornado.platform.asyncio.utils
    import tornado.platform.asyncio.web
    import tornado

# Generated at 2022-06-18 10:25:13.997952
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.netutil_test
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:25:32.653820
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import functools
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select

# Generated at 2022-06-18 10:25:45.690175
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.util import b, bytes_type
    from tornado.netutil import add_accept_handler
    class AddAcceptHandlerTest(AsyncTestCase):
        def setUp(self):
            super(AddAcceptHandlerTest, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(5)
            self.server_thread = threading.Thread(target=self.server)
            self.server_thread.start()
            self.client_thread = threading.Thread(target=self.client)
            self.client_thread.start()
            self.client

# Generated at 2022-06-18 10:25:49.858877
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # Test the method resolve of class Resolver
    # Create a new Resolver object
    resolver = Resolver()
    # Test the method resolve
    resolver.resolve("www.google.com", 80)
    # Test the method close
    resolver.close()


# Generated at 2022-06-18 10:25:54.895099
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = Resolver()
    res = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(res)
    resolver.close()
    loop.close()


# Generated at 2022-06-18 10:26:06.712140
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6

# Generated at 2022-06-18 10:26:10.417794
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    resolver = ExecutorResolver()
    result = resolver.resolve('localhost', 8080)
    print(result)


# Generated at 2022-06-18 10:26:19.215589
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    executor = concurrent.futures.ThreadPoolExecutor(1)
    resolver.initialize(executor, False)
    assert resolver.executor == executor
    assert resolver.close_executor == False
    resolver.initialize(executor, True)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:26:20.191005
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:26:21.465893
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    resolver.resolve("www.google.com", 80)
    resolver.close()



# Generated at 2022-06-18 10:26:24.600635
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:26:38.477951
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    result = resolver.resolve("localhost", 8080)
    assert result is not None


# Generated at 2022-06-18 10:26:49.523560
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import errno
    import socket
    import stat
    import time
    import functools
    import unittest
    import shutil
    import threading
    import subprocess
    import signal
    import sys
    import io
    import contextlib
    import logging
    import atexit
    import warnings
    import concurrent.futures
    import multiprocessing
    import multiprocessing.process
    import multiprocessing.connection
    import multiprocessing.synchronize
    import multiprocessing.util
    import multiprocessing.heap
    import multiprocessing.managers
    import multiprocessing.pool
    import multiprocessing.sharedctypes
    import multiprocessing.reduction
    import multiprocessing.dummy
    import multip

# Generated at 2022-06-18 10:27:00.510303
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import socket
    import errno
    import stat
    import shutil
    import time
    import random
    import functools
    import threading
    import subprocess
    import unittest
    import tornado.testing
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado

# Generated at 2022-06-18 10:27:12.554299
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import socket
    import stat
    import errno
    import time
    import shutil
    import functools
    import unittest

    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test

    class UnixSocketTest(AsyncTestCase):
        def setUp(self):
            super(UnixSocketTest, self).setUp()
            self.dir = tempfile.mkdtemp()
            self.path = os.path.join(self.dir, "sock")

        def tearDown(self):
            super(UnixSocketTest, self).tearDown()
            shutil.rmtree(self.dir)

        def test_bind_unix_socket(self):
            sock = bind_unix_socket(self.path)
            self.assertE

# Generated at 2022-06-18 10:27:24.375526
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import asyncio
    import concurrent.futures
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:27:35.742076
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.epoll

# Generated at 2022-06-18 10:27:38.168319
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:27:50.020793
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    resolver.initialize(resolver, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 80) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)
    assert resolver.resolve("login.example.com", 80) == ("login.example.com", 80)
    assert resolver

# Generated at 2022-06-18 10:27:56.655821
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:28:07.167047
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="[::1]")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8

# Generated at 2022-06-18 10:28:20.557297
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    resolver = ExecutorResolver()
    result = resolver.resolve('localhost', 80)
    print(result)


# Generated at 2022-06-18 10:28:29.793969
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import shutil
    import os
    import stat
    import socket
    import errno
    import time
    import functools
    import threading
    import signal
    import subprocess
    import unittest

    def start_server(sock):
        sock.listen(128)
        conn, addr = sock.accept()
        conn.send(b"hello world\n")
        conn.close()

    def start_client(path):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(path)
        data = sock.recv(1024)
        sock.close()
        return data

    def start_server_thread(sock):
        thread = threading.Thread(target=start_server, args=(sock,))


# Generated at 2022-06-18 10:28:31.162174
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-18 10:28:38.378756
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:28:49.852663
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import functools
    import time
    import logging
    import threading
    import socket
    import os
    import sys
    import unittest
    import json
    import ssl
    import base64
    import hashlib
    import logging
    import tornado.platform.asyncio
    import asyncio
    import functools
    import time
    import threading
    import socket
    import os
    import sys
    import unittest
    import json
    import ssl
    import base64
    import hashlib
    import logging
    import tornado.platform.asyncio
    import asyncio
    import funct

# Generated at 2022-06-18 10:29:00.428732
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()
    executor = dummy_executor
    close_executor = False
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.executor == dummy_exec

# Generated at 2022-06-18 10:29:02.353344
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:29:12.552477
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:29:22.388002
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sock, self.client = socket.socketpair()
            self.client.setblocking(False)
            self.server = socket.socket()
            self.server.setblocking(False)
            self.server.bind(("127.0.0.1", 0))
            self.server.listen(5)
            self.port = self.server.getsockname()[1]
            self.thread_id = threading.get_ident()
            self.accepted = []  # type: List

# Generated at 2022-06-18 10:29:24.250465
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:29:42.450550
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest
    import tornado.testing

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sock, self.client = socket.socketpair()
            self.client.setblocking(False)
            self.server_thread = threading.Thread(target=self.server)
            self.server_thread.start()

        def tearDown(self):
            self.io_loop.remove_handler(self.client.fileno())
            self.io_loop.remove_handler(self.sock.fileno())
            self.client.close()
            self.sock.close()

# Generated at 2022-06-18 10:29:54.485983
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sockets = bind_sockets(0, "127.0.0.1")
            self.port = self.sockets[0].getsockname()[1]
            self.thread = threading.Thread(target=self.io_loop.start)
            self.thread.daemon = True
            self.thread.start()

        def tearDown(self):
            self.io_loop.add_callback(self.io_loop.stop)
            self.thread.join()


# Generated at 2022-06-18 10:29:57.191019
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = Resolver()
    result = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(result)
# test_Resolver_resolve()



# Generated at 2022-06-18 10:30:08.423802
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(128)
            self.server_thread = threading.Thread(target=self.server)
            self.server_thread.start()

        def tearDown(self):
            self.sock.close()
            self.server_thread.join()
            super(TestAddAcceptHandler, self).tearDown()


# Generated at 2022-06-18 10:30:18.223221
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import tornado.platform.asyncio
    import concurrent.futures
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver

# Generated at 2022-06-18 10:30:19.578858
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None



# Generated at 2022-06-18 10:30:30.522359
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import stat
    import errno
    import socket
    import time
    import unittest
    import threading

    class TestUnixSocket(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.mkdtemp()
            self.file = os.path.join(self.dir, "test.sock")

        def tearDown(self):
            os.remove(self.file)
            os.rmdir(self.dir)

        def test_bind_unix_socket(self):
            sock = bind_unix_socket(self.file)
            self.assertTrue(sock)
            self.assertTrue(os.path.exists(self.file))
            st = os.stat(self.file)

# Generated at 2022-06-18 10:30:32.683781
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # test_Resolver_resolve is the Resolver.resolve() method
    host = 'www.google.com'
    port = 80
    family = socket.AF_UNSPEC
    resolver = Resolver()
    resolver.resolve(host, port, family)



# Generated at 2022-06-18 10:30:33.912364
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve('localhost', 8080))


# Generated at 2022-06-18 10:30:37.749002
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/tmp/test.sock")
    assert sock.family == socket.AF_UNIX
    assert sock.type == socket.SOCK_STREAM
    sock.close()
    os.remove("/tmp/test.sock")



# Generated at 2022-06-18 10:31:02.295899
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_stream
    from tornado.platform.asyncio import to_tornado_stream
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:31:11.853325
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("127.0.0.1 ")
    assert not is_valid_ip(" 127.0.0.1")
    assert not is_valid_ip("127.0.0.1\n")
    assert not is_valid_ip("")
    assert not is_valid_ip(" ")



# Generated at 2022-06-18 10:31:16.992809
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:31:21.647362
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:31:32.322001
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()
    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()
    sockets = bind_sockets(8888, address="::1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close

# Generated at 2022-06-18 10:31:33.372020
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:31:35.476279
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Test that the method close of class ExecutorResolver works as expected
    resolver = ExecutorResolver()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:31:40.986616
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)
    resolver.resolve(host="", port=0, family=socket.AF_INET)
    resolver.resolve(host="", port=0, family=socket.AF_INET6)
    resolver.resolve(host="", port=0, family=socket.AF_UNIX)



# Generated at 2022-06-18 10:31:51.499141
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_sockets, add_accept_handler

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.io_loop = IOLoop()
            self.sockets = bind_sockets(0, '127.0.0.1')
            self.port = self.sockets[0].getsockname()[1]
            self.connections = []  # type: List[socket.socket]
            self.accepted = []  # type: List[socket.socket]
            self.lock = threading.Lock()

# Generated at 2022-06-18 10:31:53.420041
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:32:33.817463
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import os
    import time

    class EchoHandler(tornado.websocket.WebSocketHandler):
        def open(self):
            pass

        def on_message(self, message):
            self.write_message(message)

    class EchoServer(tornado.web.Application):
        def __init__(self):
            super().__init__([(r"/", EchoHandler)])

    class TestAddAcceptHandler(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return EchoServer()


# Generated at 2022-06-18 10:32:44.565491
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.auto import set_close_exec
    from tornado.testing import AsyncTestCase, bind_unix_socket

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.client = socket.socketpair()
            set_close_exec(self.sock.fileno())
            set_close_exec(self.client.fileno())
            self.sock.setblocking(False)
            self.client.setblocking(False)
            self.io_loop = IOLoop.current()