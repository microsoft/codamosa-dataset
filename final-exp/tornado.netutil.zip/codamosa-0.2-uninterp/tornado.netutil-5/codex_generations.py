

# Generated at 2022-06-18 10:23:34.913525
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, {})
    assert resolver.resolve("example.com", 80) is not None


# Generated at 2022-06-18 10:23:39.561546
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    resolver.initialize(resolver, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    resolver.resolve("example.com", 80)
    resolver.resolve("login.example.com", 443)
    resolver.resolve("login.example.com", 443, socket.AF_INET6)
    resolver.close()


# Generated at 2022-06-18 10:23:43.543095
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 80) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)


# Generated at 2022-06-18 10:23:45.469508
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # test_Resolver_resolve is the Resolver.resolve function.
    # It is injected in the Resolver class for unit testing.
    # It is not tested here.
    pass



# Generated at 2022-06-18 10:23:54.344866
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.256")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("")
    assert not is_valid_ip(" ")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("\x01")
    assert not is_valid_ip("\x7f")

# Generated at 2022-06-18 10:24:01.147559
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:24:03.200346
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:24:14.491976
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_IN

# Generated at 2022-06-18 10:24:16.908780
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:24:23.278521
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    sock.listen(1)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()


# Generated at 2022-06-18 10:24:49.433613
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("foo.bar")



# Generated at 2022-06-18 10:24:59.718446
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()

    sockets = bind_sockets(8888, family=socket.AF_INET6, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1

# Generated at 2022-06-18 10:25:11.814448
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_NONE
    assert context.check_hostname is False
    assert context.options & ssl.OP_NO_COMPRESSION == ssl.OP_NO_COMPRESSION
    assert context.certfile == "certfile"
   

# Generated at 2022-06-18 10:25:21.015738
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import functools
    import contextlib
    import time
    import threading
    import os
    import sys
    import logging
    import unittest
    import errno
    import ssl
    import tempfile
    import shutil
    import warnings
    import concurrent.futures
    import subprocess
    import io
    import gc
    import weakref
    import re
    import base64
    import struct
    import datetime
    import email.utils
    import json
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib

# Generated at 2022-06-18 10:25:23.080534
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None
    assert resolver.close_executor is True


# Generated at 2022-06-18 10:25:29.589806
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:25:30.599605
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve('www.google.com', 80)
    print(result)


# Generated at 2022-06-18 10:25:43.444642
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="::1")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888

# Generated at 2022-06-18 10:25:48.597038
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor


# Generated at 2022-06-18 10:25:56.178806
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("www.google.com", 443))
    s = tornado.netutil.ssl_wrap_socket(s, ssl.CERT_NONE)
    s.send(b"GET / HTTP/1.1\r\nHost: www.google.com\r\n\r\n")
    print(s.recv(1024))
    s.close()

if __name__ == "__main__":
    test_ssl_wrap_socket()

# Generated at 2022-06-18 10:26:21.778864
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.test.util import unittest

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(128)
            self.client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            self.client_sock.connect(("127.0.0.1", self.port))
            self.client_sock.send(b"hello")
            self.client_s

# Generated at 2022-06-18 10:26:31.545907
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.thread = threading.Thread(target=self.run_loop)
            self.thread.start()

        def tearDown(self):
            self.stop()
            self.thread.join()
            self.sock.close()
            super(TestAddAcceptHandler, self).tearDown()

        def run_loop(self):
            IOLoop().instance().start()


# Generated at 2022-06-18 10:26:37.853629
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = None
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.executor is not None
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:26:41.998227
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve("localhost", 80))
    loop.close()



# Generated at 2022-06-18 10:26:43.844604
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:26:52.427404
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.iostream
    import tornado.gen
    import socket
    import threading
    import time
    import os
    import signal
    import functools
    import contextlib
    import logging
    import unittest
    import warnings
    import errno
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures


# Generated at 2022-06-18 10:27:04.938290
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:27:08.559998
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/tmp/test_bind_unix_socket.sock")
    sock.close()
    os.remove("/tmp/test_bind_unix_socket.sock")



# Generated at 2022-06-18 10:27:15.725084
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = ExecutorResolver()
    resolver.initialize()
    result = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(result)
    resolver.close()
    loop.close()


# Generated at 2022-06-18 10:27:28.213962
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import socket
    import errno
    import stat
    import shutil
    import time
    import unittest
    import functools
    import threading
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.netutil import bind_unix_socket, add_accept_handler
    from tornado.platform.auto import set_close_exec
    from tornado.util import errno_from_exception
    from tornado import gen
    from tornado.testing import bind_unused_port
    from tornado.platform.auto import set_close_exec
    from tornado.util import errno_from_exception
    from tornado.testing import bind_unused_port
    from tornado.platform.auto import set_close_exec


# Generated at 2022-06-18 10:27:52.963868
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    host = "example.com"
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:27:57.592814
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Test for OverrideResolver.resolve
    resolver = OverrideResolver(None, None)
    host = "example.com"
    port = 80
    family = socket.AF_UNSPEC
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:28:08.007800
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost", reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888

# Generated at 2022-06-18 10:28:15.687718
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest, skipOnTravis
    from tornado.util import b
    from tornado.netutil import bind_sockets, add_accept_handler
    class AddAcceptHandlerTest(AsyncTestCase):
        def setUp(self):
            super(AddAcceptHandlerTest, self).setUp()
            self.sockets = bind_sockets(0)
            self.port = self.sockets[0].getsockname()[1]
            self.thread = threading.Thread(target=self.thread_func)
            self.thread.daemon = True
            self.thread.start()
            self.addCleanup

# Generated at 2022-06-18 10:28:17.058888
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:28:20.249129
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = None
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:28:21.981053
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    result = resolver.resolve('localhost', 8080)
    assert result is not None


# Generated at 2022-06-18 10:28:31.918502
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname == False
    assert context.load_default_certs == False
    assert context.options & ssl.OP_NO_SSLv2 == ssl.OP_NO_SSLv

# Generated at 2022-06-18 10:28:38.817698
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import socket
    import time
    import unittest

    class AddAcceptHandlerTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(AddAcceptHandlerTest, self).setUp()
            self.sock, self.client_sock = socket.socketpair()
            self.client_sock.setblocking(False)
            self.io_loop = self.new_ioloop()
            self.addCleanup(self.io_loop.close)
            self.addCleanup(self.sock.close)
            self.addCleanup(self.client_sock.close)
            self.addCleanup(self.io_loop.remove_handler, self.sock)


# Generated at 2022-06-18 10:28:49.899398
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    ssl_options = {
        "certfile": "/etc/ssl/certs/ca-certificates.crt",
        "keyfile": "/etc/ssl/certs/ca-certificates.crt",
        "cert_reqs": ssl.CERT_NONE,
        "ssl_version": ssl.PROTOCOL_TLSv1,
        "ca_certs": "/etc/ssl/certs/ca-certificates.crt",
        "ciphers": "HIGH:!aNULL:!MD5"
    }

# Generated at 2022-06-18 10:29:43.539700
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.gen_test
    import tornado.platform.auto
    import tornado.netutil
    import tornado.iostream
    import tornado.concurrent
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.pos

# Generated at 2022-06-18 10:29:48.102988
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", 0))
    s.listen(1)
    port = s.getsockname()[1]
    ssl_options = {
        "certfile": os.path.join(os.path.dirname(__file__), "test/test.crt"),
        "keyfile": os.path.join(os.path.dirname(__file__), "test/test.key"),
    }

# Generated at 2022-06-18 10:30:00.273711
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.websocket

    class EchoWebSocket(tornado.websocket.WebSocketHandler):
        def on_message(self, message):
            self.write_message(message)

    class EchoHandler(tornado.web.RequestHandler):
        def get(self):
            self.write(self.request.uri)

    def run_test(port):
        io_loop = tornado.ioloop.IOLoop.current()
        sockets = bind_sockets(port)
        remove_handlers = []
        for sock in sockets:
            remove_handlers.append(add_accept_handler(sock, io_loop.add_callback))

# Generated at 2022-06-18 10:30:11.759431
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    from tornado.netutil import bind_sockets, add_accept_handler
    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sockets = bind_sockets(0)
            self.port = self.sockets[0].getsockname()[1]
            self.thread = threading.Thread(target=self.run_loop)
            self.thread.start()
        def tearDown(self):
            self.stop()
            self.thread.join()

# Generated at 2022-06-18 10:30:17.496868
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import time
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def test():
        resolver = DefaultExecutorResolver()
        result = await resolver.resolve('www.baidu.com', 80)
        print(result)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()

# Generated at 2022-06-18 10:30:23.600051
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET)
    assert len(sockets) == 1

# Generated at 2022-06-18 10:30:36.167520
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("127.0.0.1:80:80")
    assert not is_valid_ip("127.0.0.1:80:80:80")
    assert not is_valid_ip("127.0.0.1:80:80:80:80")
    assert not is_valid_ip("127.0.0.1:80:80:80:80:80")
    assert not is_valid_ip

# Generated at 2022-06-18 10:30:37.790734
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:30:48.266667
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    ssl_options = {
        "certfile": "/etc/ssl/certs/ca-certificates.crt",
        "keyfile": "/etc/ssl/certs/ca-certificates.crt",
        "cert_reqs": ssl.CERT_NONE,
        "ssl_version": ssl.PROTOCOL_TLSv1,
        "ca_certs": "/etc/ssl/certs/ca-certificates.crt",
        "ciphers": None
    }
    ssl_sock = tornado.netutil.ssl_wrap_socket(s, ssl_options)

# Generated at 2022-06-18 10:30:57.988577
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import os.path
    import socket
    import stat
    import errno
    import time
    import functools
    import unittest

    def wait_for_file(path, timeout):
        deadline = time.time() + timeout
        while True:
            try:
                st = os.stat(path)
                if stat.S_ISSOCK(st.st_mode):
                    return
            except OSError as e:
                if errno_from_exception(e) != errno.ENOENT:
                    raise
            if time.time() >= deadline:
                raise Exception("timed out waiting for %s" % path)
            time.sleep(0.1)


# Generated at 2022-06-18 10:32:50.556671
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sockets = bind_sockets(0, "127.0.0.1")
            self.port = self.sockets[0].getsockname()[1]
            self.threads = []
            self.stop_time = None  # type: Optional[float]

        def tearDown(self):
            for s in self.sockets:
                s.close()
            for t in self.threads:
                t.join()
            if self.stop_time is not None:
                self