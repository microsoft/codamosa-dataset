

# Generated at 2022-06-18 10:23:25.343775
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(result)
    resolver.close()


# Generated at 2022-06-18 10:23:26.544123
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("www.google.com", 80)
    print(result)


# Generated at 2022-06-18 10:23:28.494362
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:23:34.143568
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="[::1]")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8

# Generated at 2022-06-18 10:23:35.353081
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:23:47.580265
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid_ip("127.0.0.1\x00")

# Generated at 2022-06-18 10:23:51.365077
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor

# Generated at 2022-06-18 10:24:03.573181
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert isinstance(context, ssl.SSLContext)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.load_default_certs() == None
    assert context.load_verify_locations("ca_certs") == None

# Generated at 2022-06-18 10:24:08.419139
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:24:09.300708
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:24:58.881552
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import unittest
    import functools
    import time
    import os
    import sys
    import threading
    import logging
    import json
    import uuid
    import random
    import string
    import time
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:25:06.153136
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("www.google.com", 443))
    s = tornado.netutil.ssl_wrap_socket(s, ssl.CERT_NONE)
    s.send(b"GET / HTTP/1.0\r\n\r\n")
    print(s.recv(1024))
    s.close()


# Generated at 2022-06-18 10:25:13.236874
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform.select
    import tornado.platform

# Generated at 2022-06-18 10:25:22.482051
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:25:25.777129
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve("www.google.com", 80))
    loop.close()

# Generated at 2022-06-18 10:25:27.133599
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:25:40.398637
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    assert resolver.executor is dummy_executor
    assert resolver.close_executor is False
    assert resolver.io_loop is IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor(1)
    resolver = ExecutorResolver(executor)
    assert resolver.executor is executor
    assert resolver.close_executor is True
    assert resolver.io_loop is IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor(1)
    resolver = ExecutorResolver(executor, close_executor=False)
    assert resolver.executor is executor
    assert resolver.close_executor is False
    assert resolver.io_loop is IOLoop.current()



# Generated at 2022-06-18 10:25:46.242257
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver = ExecutorResolver(executor=executor)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    resolver.close()
    executor.shutdown()


# Generated at 2022-06-18 10:25:48.250945
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None



# Generated at 2022-06-18 10:25:56.773965
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_TLSv1,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_TLSv1
    assert context.certfile == "certfile"
    assert context.keyfile == "keyfile"
    assert context.verify_mode == ssl.CERT_NONE
    assert context.ca_certs == "ca_certs"
    assert context.c

# Generated at 2022-06-18 10:26:19.215752
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.util import errno_from_exception
    from tornado.netutil import add_accept_handler, bind_sockets
    from tornado.platform.auto import set_close_exec
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoIPv6
    from tornado.test.util import skipIfNoPymemcache
    from tornado.test.util import skipIfNoUnixSocket
    from tornado.test.util import skipIfNoSSL
    from tornado.test.util import skip

# Generated at 2022-06-18 10:26:25.483063
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import tempfile
    import shutil
    import errno
    import socket
    import stat
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.auto import set_close_exec
    from tornado.netutil import bind_unix_socket, bind_sockets, add_accept_handler
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado import gen
    from tornado.util import errno_from_exception
    from tornado.test.util import unittest, skipIfNonUnix
    from tornado.test.util import skipIfNoIPv6
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoP

# Generated at 2022-06-18 10:26:26.519077
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:26:33.294725
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 80) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)



# Generated at 2022-06-18 10:26:45.431401
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import tempfile
    import socket
    import shutil
    import errno
    import stat
    import time
    import unittest
    import functools
    import threading
    import socketserver
    import contextlib
    import tornado.testing
    import tornado.platform.auto
    import tornado.netutil
    import tornado.iostream
    import tornado.process
    import tornado.ioloop
    import tornado.testing
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.asyncio


# Generated at 2022-06-18 10:26:53.353990
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    # Test that the function can convert a dictionary to a SSLContext
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert isinstance(context, ssl.SSLContext)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname is False
    assert context.options & ssl.OP

# Generated at 2022-06-18 10:27:06.062580
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    ssl_context = ssl_options_to_context(ssl_options)
    assert ssl_context.protocol == ssl.PROTOCOL_SSLv23
    assert ssl_context.verify_mode == ssl.CERT_REQUIRED
    assert ssl_context.check_hostname is False
    assert ssl_context.options & ssl.OP_NO_COMPRESSION

# Generated at 2022-06-18 10:27:10.762078
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:27:12.601623
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:27:24.422290
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket

    class EchoWebSocket(tornado.websocket.WebSocketHandler):
        def open(self):
            pass

        def on_message(self, message):
            self.write_message(message)

    class EchoHandler(tornado.web.RequestHandler):
        def get(self):
            self.write(self.request.uri)

    class EchoServer(Configurable):
        def __init__(self, io_loop=None):
            self.io_loop = io_loop or tornado.ioloop.IOLoop.current()
            self.sockets = {}  # type: Dict[socket.socket, Callable[[], None]]

        def listen(self, port, address=""):
            sockets

# Generated at 2022-06-18 10:27:48.884802
# Unit test for method resolve of class ExecutorResolver

# Generated at 2022-06-18 10:27:56.072277
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    asyncio.set_event_loop_policy(tornado.platform.asyncio.AnyThreadEventLoopPolicy())
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(result)


# Generated at 2022-06-18 10:27:58.004364
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:28:00.456375
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:28:10.097142
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname == False
    assert context.certfile == "certfile"
    assert context.keyfile == "keyfile"
    assert context.ca_certs == "ca_certs"

# Generated at 2022-06-18 10:28:13.219838
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def test():
        resolver = Resolver()
        result = await resolver.resolve('www.baidu.com', 80)
        print(result)
    asyncio.get_event_loop().run_until_complete(test())


# Generated at 2022-06-18 10:28:15.512033
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/tmp/test_bind_unix_socket.sock")
    sock.close()
    os.remove("/tmp/test_bind_unix_socket.sock")



# Generated at 2022-06-18 10:28:21.101228
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname == False
    assert context.options & ssl.OP_NO_COMPRESSION
    assert context.cert_store_stats()["x509_ca"] == 0
    assert context

# Generated at 2022-06-18 10:28:30.723849
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_IN

# Generated at 2022-06-18 10:28:34.916712
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    resolver = Resolver()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(resolver.resolve('www.google.com', 80))
    resolver.close()
    loop.close()


# Generated at 2022-06-18 10:29:04.804488
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    assert resolver.resolve(host="", port=0, family=socket.AF_UNSPEC) == NotImplemented



# Generated at 2022-06-18 10:29:09.469112
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:29:11.737489
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve('www.google.com', 80)
    print(result)


# Generated at 2022-06-18 10:29:18.933048
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    ioloop = tornado.ioloop.IOLoop.current()
    resolver = DefaultExecutorResolver()
    def test_resolve():
        result = ioloop.run_sync(resolver.resolve, "www.google.com", 80)
        print(result)
    ioloop.add_callback(test_resolve)
    ioloop.start()
# test_DefaultExecutorResolver_resolve()



# Generated at 2022-06-18 10:29:22.234522
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)
    # TODO: add test cases
    pass



# Generated at 2022-06-18 10:29:24.929595
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    resolver.resolve("localhost", 80)
    resolver.close()



# Generated at 2022-06-18 10:29:27.961871
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:29:39.229520
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    assert isinstance(ssl_options_to_context({}), ssl.SSLContext)
    assert isinstance(ssl_options_to_context(ssl.create_default_context()), ssl.SSLContext)
    assert isinstance(ssl_options_to_context({"ssl_version": ssl.PROTOCOL_TLSv1}), ssl.SSLContext)
    assert isinstance(ssl_options_to_context({"certfile": "foo.crt"}), ssl.SSLContext)
    assert isinstance(ssl_options_to_context({"cert_reqs": ssl.CERT_NONE}), ssl.SSLContext)
    assert isinstance(ssl_options_to_context({"ca_certs": "foo.crt"}), ssl.SSLContext)

# Generated at 2022-06-18 10:29:46.091862
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    executor = concurrent.futures.ThreadPoolExecutor()
    resolver.initialize(executor)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    resolver.initialize(executor, close_executor=False)
    assert resolver.executor == executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:29:48.278713
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, None)
    resolver.resolver = None
    resolver.mapping = None
    host = 'host'
    port = 0
    family = socket.AF_UNSPEC
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:30:18.763037
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unix_socket, gen_test
    from tornado.test.util import unittest

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unix_socket('', 'test_add_accept_handler')
            self.thread_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            self.thread_sock.connect(('localhost', self.port))
            self.thread_sock.setblocking(False)

# Generated at 2022-06-18 10:30:23.361249
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname == False
    assert context.options == 0
    assert context.load_default_certs == False
    assert context.verify_flags == 0
    assert context.verify_

# Generated at 2022-06-18 10:30:35.773742
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unix_socket, gen_test
    from tornado.util import errno_from_exception

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unix_socket('', 'test_add_accept_handler')
            self.addCleanup(self.sock.close)
            self.addCleanup(os.remove, self.sock.getsockname())
            self.accepted = []  # type: List[socket.socket]

# Generated at 2022-06-18 10:30:40.229926
# Unit test for method resolve of class Resolver

# Generated at 2022-06-18 10:30:45.944776
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def test():
        resolver = DefaultExecutorResolver()
        result = await resolver.resolve("www.baidu.com", 80)
        print(result)
    asyncio.run(test())


# Generated at 2022-06-18 10:30:56.147990
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].type == socket.SOCK_STREAM
    sockets[0].close()
    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    assert sockets[0].type == socket.SOCK_STREAM
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].type == socket.SOCK_STREAM
    sockets[0].close()
   

# Generated at 2022-06-18 10:30:57.635124
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:31:09.297522
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:31:14.409142
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == True


# Generated at 2022-06-18 10:31:17.034347
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/tmp/test_bind_unix_socket")
    sock.close()
    os.remove("/tmp/test_bind_unix_socket")


# Generated at 2022-06-18 10:32:23.433013
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.google.com', 80))
    print(result)


# Generated at 2022-06-18 10:32:27.267953
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/tmp/test_bind_unix_socket")
    assert sock.family == socket.AF_UNIX
    assert sock.type == socket.SOCK_STREAM
    sock.close()
    os.remove("/tmp/test_bind_unix_socket")



# Generated at 2022-06-18 10:32:35.865963
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:32:47.168296
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sock, self.client = socket.socketpair()
            self.client.setblocking(False)
            self.server = socket.socket()
            self.server.setblocking(False)
            self.server.bind(("127.0.0.1", 0))
            self.server.listen(5)
            self.port = self.server.getsockname()[1]

        def tearDown(self):
            self.io_loop.close(all_fds=True)


# Generated at 2022-06-18 10:32:53.838124
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import os
    import socket
    import time
    import unittest
    import functools
    import threading
    import tornado.testing
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_async