

# Generated at 2022-06-18 10:23:53.730861
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.google.com', 80))
    print(result)
    loop.close()


# Generated at 2022-06-18 10:23:55.743757
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = OverrideResolver(resolver=None, mapping=None)
    resolver.close()

# Generated at 2022-06-18 10:24:02.483932
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:24:06.451733
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/tmp/test_bind_unix_socket")
    sock.close()
    os.remove("/tmp/test_bind_unix_socket")



# Generated at 2022-06-18 10:24:10.545157
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, None)
    host = "example.com"
    port = 80
    family = socket.AF_UNSPEC
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:24:12.974118
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    resolver.resolve("localhost", 80)
    resolver.close()


# Generated at 2022-06-18 10:24:25.787095
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import time
    import threading
    import functools
    import os
    import sys
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_stream
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import is_future
    from tornado.platform.asyncio import is_

# Generated at 2022-06-18 10:24:30.393884
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping=None)
    resolver.resolve(host=None, port=None, family=None)
    resolver.resolve(host=None, port=None)
    resolver.resolve(host=None)


# Generated at 2022-06-18 10:24:37.870301
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid_ip("127.0.0.1\x00")
    assert not is_valid

# Generated at 2022-06-18 10:24:43.123538
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = Resolver()
    res = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(res)
    resolver.close()
    loop.close()


# Generated at 2022-06-18 10:24:58.021682
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('www.google.com', 443))
    s = ssl_wrap_socket(s, ssl.create_default_context())
    s.send(b'GET / HTTP/1.0\r\n\r\n')
    print(s.recv(8192))


# Generated at 2022-06-18 10:25:08.802275
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    ssl_options = {
        "certfile": "/etc/ssl/certs/ca-certificates.crt",
        "keyfile": "/etc/ssl/certs/ca-certificates.crt",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "/etc/ssl/certs/ca-certificates.crt",
        "ciphers": "HIGH:!aNULL:!MD5"
    }
    ssl_sock = tornado.netutil.ssl_wrap_socket(s, ssl_options)
    print(ssl_sock)

# Unit test

# Generated at 2022-06-18 10:25:12.904906
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = IOLoop.current().run_sync(lambda: resolver.resolve("localhost", 8080))
    assert result == [(2, ('127.0.0.1', 8080))]
    result = IOLoop.current().run_sync(lambda: resolver.resolve("localhost", 8080, socket.AF_INET6))
    assert result == [(10, ('::1', 8080, 0, 0))]



# Generated at 2022-06-18 10:25:22.163139
# Unit test for method resolve of class Resolver

# Generated at 2022-06-18 10:25:25.007532
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = Resolver()
    mapping = {}
    resolver_override = OverrideResolver(resolver, mapping)
    resolver_override.close()


# Generated at 2022-06-18 10:25:33.567455
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("127.0.0.1\x00")



# Generated at 2022-06-18 10:25:46.351683
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Test for method initialize(self, executor=None, close_executor=True)
    # Tests for the case where executor is None
    resolver = ExecutorResolver()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    # Tests for the case where executor is not None
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver = ExecutorResolver(executor=executor, close_executor=False)
    assert resolver.executor == executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    resolver.close()
    executor.shutdown()
# Unit

# Generated at 2022-06-18 10:25:47.379597
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:25:56.252939
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_torn

# Generated at 2022-06-18 10:26:08.199005
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sock, self.client = socket.socketpair()
            self.client.setblocking(False)
            self.server = socket.socket()
            self.server.setblocking(False)
            self.server.bind(("127.0.0.1", 0))
            self.server.listen(1)
            self.port = self.server.getsockname()[1]
            self.thread_started = threading.Event()
            self.thread_stopped = threading.Event()


# Generated at 2022-06-18 10:26:21.859006
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:26:27.562388
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 0))
    sock.listen(1)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()
    sock.close()


# Generated at 2022-06-18 10:26:32.194721
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:26:43.667929
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import shutil
    import os
    import stat
    import errno
    import socket
    import time
    import functools
    import threading
    import unittest
    import signal
    import subprocess
    import sys
    import contextlib
    import io
    import logging
    import re
    import warnings
    import atexit
    import pwd
    import grp
    import gc
    import weakref
    import traceback
    import types
    import inspect
    import platform
    import textwrap
    import random
    import string
    import base64
    import binascii
    import hashlib
    import hmac
    import struct
    import tempfile
    import shutil
    import os
    import stat
    import errno
    import socket
    import time
    import functools

# Generated at 2022-06-18 10:26:45.940952
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:26:55.065150
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.netutil_test
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select

# Generated at 2022-06-18 10:27:01.374870
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    print(loop.run_until_complete(resolver.resolve('www.baidu.com', 80)))
    resolver.close()
    loop.close()


# Generated at 2022-06-18 10:27:05.403610
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve('www.google.com', 80))
    loop.close()


# Generated at 2022-06-18 10:27:16.818660
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()

    sockets = bind_sockets(8888, family=socket.AF_INET6, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()

    sockets = bind_sockets(8888, family=socket.AF_INET6, reuse_port=True)

# Generated at 2022-06-18 10:27:29.191614
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.caresresolver
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.caresresolver

# Generated at 2022-06-18 10:27:47.980240
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("www.google.com", 80)
    assert result is not None
    assert len(result) > 0
    assert result[0][0] == socket.AF_INET
    assert result[0][1][0] == "172.217.3.174"
    assert result[0][1][1] == 80


# Generated at 2022-06-18 10:27:50.007521
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("localhost", 8080)
    assert result is not None



# Generated at 2022-06-18 10:28:02.358124
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:28:11.693396
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sock, self.client_sock = socket.socketpair()
            self.client_sock.setblocking(False)
            self.addCleanup(self.io_loop.close)
            self.addCleanup(self.sock.close)
            self.addCleanup(self.client_sock.close)
            self.accepted = False
            self.accept_handler = add_accept_handler(
                self.sock, self.handle_connection
            )


# Generated at 2022-06-18 10:28:15.264169
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:28:22.569800
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import socket
    import tempfile
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.netutil import bind_unix_socket

    class TestBindUnixSocket(AsyncTestCase):
        def setUp(self):
            super(TestBindUnixSocket, self).setUp()
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            super(TestBindUnixSocket, self).tearDown()
            os.rmdir(self.tmpdir)

        @gen_test
        def test_bind_unix_socket(self):
            file = os.path.join(self.tmpdir, 'test_bind_unix_socket')
            sock = bind_unix_socket(file)

# Generated at 2022-06-18 10:28:24.425694
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:28:26.513898
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    print(sockets)
    for sock in sockets:
        sock.close()
# test_bind_sockets()



# Generated at 2022-06-18 10:28:35.945109
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("")
    assert not is_valid_ip(" ")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("127.0.0.1 ")
    assert not is_valid_ip(" 127.0.0.1")
    assert not is_valid_ip("127.0.0.1 ")

# Generated at 2022-06-18 10:28:40.001648
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve('www.google.com', 80)
    print(result)


# Generated at 2022-06-18 10:29:01.983531
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unix_socket, gen_test

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.server_sock, self.client_sock = socket.socketpair()
            self.server_sock.setblocking(False)
            self.client_sock.setblocking(False)
            self.io_loop = IOLoop.current()
            self.accepted = []  # type: List[socket.socket]
            self.accept_handler = add_accept_handler(
                self.server_sock, self.accept_callback
            )

       

# Generated at 2022-06-18 10:29:12.294085
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    import tornado.testing
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.caresresolver
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.asyncioreactor
    import tornado.platform.twistedreactor
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.caresresolver
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
   

# Generated at 2022-06-18 10:29:13.439126
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    s = socket.socket()
    ssl_wrap_socket(s, {'ssl_version': ssl.PROTOCOL_TLSv1})


# Generated at 2022-06-18 10:29:23.252330
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest
    import tornado.testing

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.sock, self.client = socket.socketpair()
            self.client.setblocking(False)
            self.server_sock = socket.socket()
            self.server_sock.setblocking(False)
            self.server_sock.bind(("127.0.0.1", 0))
            self.server_sock.listen(1)
            self.server_port = self.server_sock.getsockname()

# Generated at 2022-06-18 10:29:35.607976
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()

# Generated at 2022-06-18 10:29:40.700850
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:29:42.815799
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    result = resolver.resolve('localhost', 80)
    assert result is not None


# Generated at 2022-06-18 10:29:44.309829
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:29:51.741220
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 0))
    sock.listen(1)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()
    sock.close()


# Generated at 2022-06-18 10:30:03.144286
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    result = resolver.resolve("localhost", 80)
    assert result is not None
    assert isinstance(result, Future)
    assert result.result() is not None
    assert isinstance(result.result(), list)
    assert len(result.result()) > 0
    assert isinstance(result.result()[0], tuple)
    assert len(result.result()[0]) == 2
    assert isinstance(result.result()[0][0], int)
    assert isinstance(result.result()[0][1], tuple)
    assert len(result.result()[0][1]) == 2
    assert isinstance(result.result()[0][1][0], str)
    assert isinstance(result.result()[0][1][1], int)


# Generated at 2022-06-18 10:30:22.742285
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:30:34.889076
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import os
    import time
    import threading
    import functools
    import logging
    import sys
    import signal
    import unittest
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:30:36.680202
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:30:41.898412
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = None
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:30:44.665268
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:30:55.026644
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import functools
    import logging
    import time
    import threading
    import tornado.netutil
    import tornado.iostream
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.select
    import tornado.platform.windows
    import tornado.process
    import tornado.stack_context
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util

# Generated at 2022-06-18 10:31:00.858073
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import socket
    import stat
    import tempfile
    import unittest
    import errno
    import functools
    import shutil
    import time
    import signal
    import subprocess
    import threading
    import concurrent.futures
    import tornado.netutil
    import tornado.testing
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.epoll

# Generated at 2022-06-18 10:31:11.508588
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import socket
    import time
    import logging
    import sys
    import os
    import unittest
    import functools
    import tornado.testing
    import tornado.gen
    import tornado.concurrent
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.netutil
    import tornado.iostream
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.ioloop
    import tornado.iostream
    import tornado.options
    import tornado.tcpserver
    import tornado.testing
    import tornado.test.httpclient_test

# Generated at 2022-06-18 10:31:21.279145
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import selectors
    import threading
    import time
    import socket
    import errno
    import unittest
    import tornado.testing
    import tornado.platform.auto
    import tornado.netutil
    import tornado.iostream
    import tornado.testing
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado

# Generated at 2022-06-18 10:31:23.205540
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None



# Generated at 2022-06-18 10:31:55.352895
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:32:02.209731
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:32:10.609820
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import threading
    import time
    import unittest
    import logging
    import sys
    import os
    import signal
    import functools
    import contextlib
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.fut

# Generated at 2022-06-18 10:32:20.007038
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()

# Generated at 2022-06-18 10:32:29.313222
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import shutil
    import os
    import stat
    import socket
    import errno
    import time
    import threading
    import subprocess
    import signal
    import atexit
    import functools
    import unittest
    import contextlib
    import sys
    import io
    import logging
    import logging.handlers
    import re
    import warnings
    import weakref
    import gc
    import ssl
    import base64
    import email.utils
    import urllib.parse
    import urllib.request
    import urllib.error
    import http.client
    import http.cookies
    import http.server
    import http.client
    import http.cookiejar
    import email.message
    import email.parser
    import email.policy
    import email.utils

# Generated at 2022-06-18 10:32:30.964313
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:32:38.027095
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import socket
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import unittest
    class OverrideResolverTest(tornado.testing.AsyncTestCase):
        def test_resolve(self):
            resolver = tornado.netutil.OverrideResolver(
                tornado.netutil.Resolver(),
                {"example.com": "127.0.1.1", ("login.example.com", 443): ("localhost", 1443), ("login.example.com", 443, socket.AF_INET6): ("::1", 1443)},
            )

# Generated at 2022-06-18 10:32:44.750064
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    ioloop = IOLoop.current()
    resolver = DefaultExecutorResolver()
    result = ioloop.run_sync(lambda: resolver.resolve('localhost', 80))
    assert result == [(2, ('127.0.0.1', 80))]



# Generated at 2022-06-18 10:32:49.704340
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    ssl_context = ssl_options_to_context(ssl_options)
    assert ssl_context.protocol == ssl.PROTOCOL_SSLv23
    assert ssl_context.verify_mode == ssl.CERT_REQUIRED
    assert ssl_context.check_hostname is False
    assert ssl_context.options & ssl.OP_NO_COMPRESSION

# Generated at 2022-06-18 10:32:54.564790
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "/path/to/certfile",
        "keyfile": "/path/to/keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "/path/to/ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname == False
    assert context.load_default_certs == False
    assert context.options == 0
    assert context.verify