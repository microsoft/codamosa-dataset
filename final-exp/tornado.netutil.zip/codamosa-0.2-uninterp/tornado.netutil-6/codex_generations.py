

# Generated at 2022-06-18 10:23:29.536721
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:23:35.279216
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio
    import socket
    import threading
    import time
    import logging
    import os
    import sys

    class EchoHandler(tornado.websocket.WebSocketHandler):
        def open(self):
            logging.info("WebSocket opened")

        def on_message(self, message):
            logging.info("WebSocket message: %s", message)
            self.write_message(message)

        def on_close(self):
            logging.info("WebSocket closed")


# Generated at 2022-06-18 10:23:41.068828
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import socket
    import tornado.platform.asyncio
    import tornado.netutil
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:23:45.218757
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve('www.google.com', 80)
    assert result is not None


# Generated at 2022-06-18 10:23:46.703890
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()



# Generated at 2022-06-18 10:23:55.080860
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:24:05.338830
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver.initialize(executor, True)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:24:09.920661
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:24:18.261287
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.thread = threading.Thread(target=self.run_loop)
            self.thread.start()

        def tearDown(self):
            self.io_loop.add_callback(self.io_loop.stop)
            self.thread.join()
            super(TestAddAcceptHandler, self).tearDown()

        def run_loop(self):
            self.io_loop = IOLoop()


# Generated at 2022-06-18 10:24:26.684507
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host='', port=0, family=socket.AF_UNSPEC)
    resolver.resolve(host='', port=0)
    resolver.resolve(host='')
    resolver.resolve(host='', port=0, family=socket.AF_INET)
    resolver.resolve(host='', port=0, family=socket.AF_INET6)



# Generated at 2022-06-18 10:24:59.253572
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:25:11.389683
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:25:13.423278
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    host = 'localhost'
    port = 80
    family = socket.AF_UNSPEC
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:25:22.750634
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context

    def test_handler(sock, fd, events):
        pass

    def test_add_accept_handler():
        sock, port = tornado.test.util.bind_unused_port()
        add_accept_handler(sock, test_handler)
        tornado.ioloop.IOLoop.current().start()

    def test_add_accept_handler_with_stack_context():
        sock, port = tornado.test.util.bind_unused_port()
        with tornado.test.stack_context.StackContext(lambda: None):
            add_accept_handler(sock, test_handler)
        tornado.ioloop.IOLoop.current().start()


# Generated at 2022-06-18 10:25:29.388210
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1

# Generated at 2022-06-18 10:25:38.612061
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    asyncio.set_event_loop(asyncio.new_event_loop())
    resolver = DefaultExecutorResolver()
    result = asyncio.get_event_loop().run_until_complete(resolver.resolve('localhost', 80))
    print(result)
    assert result == [(2, ('127.0.0.1', 80))]


# Generated at 2022-06-18 10:25:50.403798
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import stat
    import socket
    import errno
    import shutil
    import sys
    import time
    import unittest
    import functools
    import threading
    import subprocess
    import signal
    import logging
    import contextlib
    import io
    import selectors
    import pwd
    import grp
    import warnings
    import random
    import select
    import re
    import gc
    import weakref
    import platform
    import textwrap
    import base64
    import binascii
    import hashlib
    import hmac
    import struct
    import ssl
    import asyncio
    import concurrent.futures
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:25:53.433065
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:25:59.417878
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import socket
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = Resolver()
    res = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(res)
    resolver.close()
    loop.close()


# Generated at 2022-06-18 10:26:02.098796
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)



# Generated at 2022-06-18 10:26:23.197020
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver = ExecutorResolver(executor=executor)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    assert resolver.io_loop == IOLoop.current()
    resolver = ExecutorResolver(executor=executor, close_executor=False)
    assert resolver.executor == executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:26:32.778847
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import unittest

    class EchoWebSocket(tornado.websocket.WebSocketHandler):
        def on_message(self, message):
            self.write_message(message)

    class EchoHandler(tornado.web.RequestHandler):
        def get(self):
            self.write(self.request.uri)

    class Test(unittest.TestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()

# Generated at 2022-06-18 10:26:34.071531
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-18 10:26:46.235938
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_TLSv1,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_TLSv1
    assert context.certfile == "certfile"
    assert context.keyfile == "keyfile"
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.ca_certs == "ca_certs"
    assert context.ciphers()

# Generated at 2022-06-18 10:26:54.117362
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop is IOLoop.current()
    assert resolver.executor is dummy_executor
    assert resolver.close_executor is False
    executor = concurrent.futures.ThreadPoolExecutor(1)
    resolver.initialize(executor, False)
    assert resolver.executor is executor
    assert resolver.close_executor is False
    resolver.initialize(executor, True)
    assert resolver.executor is executor
    assert resolver.close_executor is True
    resolver.close()
    assert resolver.executor is None
    executor.shutdown()


# Generated at 2022-06-18 10:27:00.622221
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:27:12.700742
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Test that the method initialize of class ExecutorResolver works as expected
    resolver = ExecutorResolver()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    resolver.close()
    assert resolver.executor == None
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver = ExecutorResolver(executor=executor, close_executor=False)
    assert resolver.executor == executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    res

# Generated at 2022-06-18 10:27:14.981999
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:27:18.526339
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:27:26.851581
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)
    resolver.resolve(host="", port=0)
    resolver.resolve(host="", port=0, family=socket.AF_INET)
    resolver.resolve(host="", port=0, family=socket.AF_INET6)
    resolver.resolve(host="", port=0, family=socket.AF_UNIX)



# Generated at 2022-06-18 10:27:44.639636
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("localhost", 0))
    sock.listen(128)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()
    sock.close()


# Generated at 2022-06-18 10:27:53.297114
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.winscoket
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.winscoket
    import concurrent.f

# Generated at 2022-06-18 10:27:58.235849
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # test_Resolver_resolve is the Resolver.resolve() method
    host = 'www.google.com'
    port = 80
    family = socket.AF_UNSPEC
    resolver = Resolver()
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:28:04.370526
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(result)
    resolver.close()


# Generated at 2022-06-18 10:28:09.256208
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    res = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(res)


# Generated at 2022-06-18 10:28:10.902960
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:28:12.919518
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:28:18.983422
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unix_socket

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.client = socket.socketpair()
            self.client.setblocking(False)
            self.io_loop = IOLoop.current()
            self.io_loop.add_handler(
                self.client, self.handle_events, IOLoop.READ
            )
            self.addCleanup(self.io_loop.remove_handler, self.client)
            self.addCleanup(self.sock.close)

# Generated at 2022-06-18 10:28:24.643250
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:28:34.363103
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import tempfile
    import shutil
    import errno
    import stat
    import socket
    import time
    import unittest

    from tornado.testing import AsyncTestCase, gen_test

    class BindUnixSocketTest(AsyncTestCase):
        def setUp(self):
            super(BindUnixSocketTest, self).setUp()
            self.tmpdir = tempfile.mkdtemp()
            self.socket_path = os.path.join(self.tmpdir, "test.sock")

        def tearDown(self):
            super(BindUnixSocketTest, self).tearDown()
            shutil.rmtree(self.tmpdir)

        @gen_test
        def test_bind_unix_socket(self):
            sock = bind_unix_socket(self.socket_path)


# Generated at 2022-06-18 10:28:58.071135
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(
        resolver=DefaultExecutorResolver(),
        mapping={
            "example.com": "127.0.1.1",
            ("login.example.com", 443): ("localhost", 1443),
            ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
        },
    )
    assert resolver.resolve("example.com", 80) == [
        (socket.AF_INET, ("127.0.1.1", 80))
    ]
    assert resolver.resolve("login.example.com", 443) == [
        (socket.AF_INET, ("localhost", 1443))
    ]

# Generated at 2022-06-18 10:29:04.859085
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class AddAcceptHandlerTest(AsyncTestCase):
        def setUp(self):
            super(AddAcceptHandlerTest, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(5)
            self.connections = []  # type: List[socket.socket]
            self.accept_handler = add_accept_handler(
                self.sock, self.handle_connection
            )
            self.loop.add_callback(self.stop)
            self.wait()

        def tearDown(self):
            for c in self.connections:
                c.close()
           

# Generated at 2022-06-18 10:29:08.375884
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    host = "example.com"
    port = 443
    family = socket.AF_INET
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:29:10.795616
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("www.google.com", 443))
    s = ssl_wrap_socket(s, ssl.create_default_context())
    s.send(b"GET / HTTP/1.0\r\n\r\n")
    print(s.recv(1024))


# Generated at 2022-06-18 10:29:19.490387
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    resolver.initialize(resolver, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 80) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)



# Generated at 2022-06-18 10:29:21.154155
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:29:25.026600
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    async def test_resolve():
        resolver = DefaultExecutorResolver()
        result = await resolver.resolve("www.google.com", 80)
        print(result)
    IOLoop.current().run_sync(test_resolve)


# Generated at 2022-06-18 10:29:37.535838
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()

# Generated at 2022-06-18 10:29:46.221874
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket
    import time
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket
    import time
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket
    import time
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:29:58.401462
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:30:38.678879
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 80) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)



# Generated at 2022-06-18 10:30:50.325064
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import asyncio
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:30:51.297624
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # TODO: write unit test
    pass



# Generated at 2022-06-18 10:30:59.294626
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import functools
    import unittest
    import os
    import time
    import sys
    import logging
    import threading
    import json
    import ssl
    import subprocess
    import signal
    import traceback
    import re
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:31:02.295368
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, None)
    host = "example.com"
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:31:06.442724
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(resolver.resolve("www.google.com", 80))
    print(result)


# Generated at 2022-06-18 10:31:08.589173
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve('www.google.com', 80)
    print(result)


# Generated at 2022-06-18 10:31:14.034939
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:31:17.347156
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    host = "example.com"
    port = 80
    family = socket.AF_UNSPEC
    resolver.resolve(host, port, family)
    return True


# Generated at 2022-06-18 10:31:27.498686
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:32:31.951772
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.baidu.com', 80))
    print(result)
    resolver.close()
    loop.close()


# Generated at 2022-06-18 10:32:38.623444
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname == False
    assert context.load_default_certs == False
    assert context.options == 0
    assert context.verify_flags == 0
    assert context.cert_store

# Generated at 2022-06-18 10:32:40.976783
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:32:50.194269
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    import tornado.testing
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tornado.httputil
    import tornado.httpclient
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.asyncio