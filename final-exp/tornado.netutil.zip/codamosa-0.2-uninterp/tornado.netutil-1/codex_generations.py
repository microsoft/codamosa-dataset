

# Generated at 2022-06-18 10:23:18.931561
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "cert.pem",
        "keyfile": "key.pem",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca.pem",
        "ciphers": "cipher",
    }
    socket = socket.socket()
    ssl_wrap_socket(socket, ssl_options, server_hostname="localhost")



# Generated at 2022-06-18 10:23:21.941467
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:23:23.358928
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    # Test for method close( self )
    resolver = OverrideResolver(None, None)
    resolver.close()



# Generated at 2022-06-18 10:23:24.463292
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:23:29.833443
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 80) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)
    assert resolver.resolve("login.example.com", 80) == ("login.example.com", 80)

# Generated at 2022-06-18 10:23:38.562078
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("127.0.0.1 ")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("")
    assert not is_valid_ip(" ")
    assert not is_valid_ip("\x00")



# Generated at 2022-06-18 10:23:50.733572
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import unittest
    import tornado.testing
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.asyncioreactor
    import tornado.platform.twistedreactor
    import tornado.platform.selectreactor
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncioreactor
    import tornado.platform.twistedreactor
    import tornado.platform.selectreactor
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncioreactor


# Generated at 2022-06-18 10:24:02.817510
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()

# Generated at 2022-06-18 10:24:10.645555
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.netutil
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def test():
        resolver = tornado.netutil.DefaultExecutorResolver()
        result = await resolver.resolve('localhost', 80)
        print(result)
    asyncio.get_event_loop().run_until_complete(test())


# Generated at 2022-06-18 10:24:21.996420
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("www.google.com")
    assert not is_valid_ip("www.google.com:80")
    assert not is_valid_ip("www.google.com:80/")

# Generated at 2022-06-18 10:24:36.834650
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:24:38.452729
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:24:43.588447
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.netutil
    import functools
    import time
    import threading
    import unittest
    import warnings
    import weakref
    import os
    import errno
    import logging
    import contextlib
    import signal
    import socket
    import sys
    import time
    import unittest
    import weakref
    import warnings
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.web
    import tornado.websocket
    import tornado.wsgi

# Generated at 2022-06-18 10:24:55.854295
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest

    from tornado.ioloop import IOLoop

    def handle_connection(connection, address):
        connection.close()

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sock, self.port = bind_unused_port()
            self.remove_handler = add_accept_handler(self.sock, handle_connection)

        def tearDown(self):
            self.remove_handler()
            self.io_loop.close(all_fds=True)

        def test_add_accept_handler(self):
            def connect():
                connection = socket.socket()

# Generated at 2022-06-18 10:25:06.675213
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:25:17.181227
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, "127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, "localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_

# Generated at 2022-06-18 10:25:19.675068
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:25:26.534315
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Test that the executor is shut down when the resolver is closed.
    executor = concurrent.futures.ThreadPoolExecutor(1)
    resolver = ExecutorResolver(executor=executor)
    resolver.close()
    assert executor.shutdown.called

    # Test that the executor is not shut down when the resolver is closed
    # if close_executor is False.
    executor = concurrent.futures.ThreadPoolExecutor(1)
    resolver = ExecutorResolver(executor=executor, close_executor=False)
    resolver.close()
    assert not executor.shutdown.called



# Generated at 2022-06-18 10:25:32.431218
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    import tornado.testing
    import tornado.ioloop
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio
    import logging
    import sys
    import os
    import json
    import time
    import random
    import string
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio


# Generated at 2022-06-18 10:25:45.694706
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888

# Generated at 2022-06-18 10:26:12.873328
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert isinstance(context, ssl.SSLContext)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname is False
    assert context.options & ssl.OP_NO_COMPRESSION



# Generated at 2022-06-18 10:26:20.152034
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("127.0.0.1\x00")



# Generated at 2022-06-18 10:26:21.559830
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:26:22.857500
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:26:25.039330
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor)
    resolver.close()
    assert resolver.executor is None
    assert resolver.close_executor is True


# Generated at 2022-06-18 10:26:26.240802
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Test that the close method of ExecutorResolver works as expected
    resolver = ExecutorResolver()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:26:33.739144
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import concurrent.futures
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:26:45.898194
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    resolver = OverrideResolver(DefaultExecutorResolver(), {"example.com": "127.0.1.1"})
    result = resolver.resolve("example.com", 80)
    assert result == [
        (socket.AF_INET, ("127.0.1.1", 80)),
        (socket.AF_INET6, ("127.0.1.1", 80, 0, 0)),
    ]
    resolver = OverrideResolver(DefaultExecutorResolver(), {"example.com": "127.0.1.1"})
    result = resolver.resolve("example.com", 80, socket.AF_INET)

# Generated at 2022-06-18 10:26:54.619570
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6

# Generated at 2022-06-18 10:27:06.983369
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import socket
    import tempfile
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class BindUnixSocketTest(AsyncTestCase):
        def setUp(self):
            super(BindUnixSocketTest, self).setUp()
            self.sock_file = tempfile.mktemp()

        def tearDown(self):
            super(BindUnixSocketTest, self).tearDown()
            if os.path.exists(self.sock_file):
                os.remove(self.sock_file)

        @gen_test
        def test_bind_unix_socket(self):
            sock = bind_unix_socket(self.sock_file)
            self.assertTrue(os.path.exists(self.sock_file))
            sock.close

# Generated at 2022-06-18 10:27:31.955918
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()

# Generated at 2022-06-18 10:27:43.917142
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor()
    resolver.initialize(executor, True)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    assert resolver.io_loop == IOLoop.current()
    resolver.initialize(executor, False)
    assert resolver.executor == executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:27:51.793724
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    ssl_options = ssl.create_default_context(purpose=ssl.Purpose.SERVER_AUTH)
    ssl_options.check_hostname = False
    ssl_options.verify_mode = ssl.CERT_NONE
    s = tornado.netutil.ssl_wrap_socket(s, ssl_options)
    s.connect(('www.google.com', 443))
    s.send(b'GET / HTTP/1.1\r\nHost: www.google.com\r\n\r\n')
    print(s.recv(1024))
    s.close()
# test_ssl_wrap_

# Generated at 2022-06-18 10:27:57.800578
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:28:08.282107
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.testing
    import tornado.iostream
    import tornado.platform.asyncio
    import asyncio
    import functools
    import logging
    import time
    import os
    import sys
    import threading
    import unittest
    import uuid
    import json
    import ssl
    import base64
    import hashlib
    import hmac
    import urllib
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.request

# Generated at 2022-06-18 10:28:15.863850
# Unit test for method initialize of class ExecutorResolver

# Generated at 2022-06-18 10:28:20.953431
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Test for method resolve(...) of class OverrideResolver
    # OverrideResolver.resolve(...) is tested in test_Resolver_resolve
    # This test is for the mapping
    resolver = OverrideResolver(BlockingResolver(), {"example.com": "127.0.1.1"})
    assert resolver.resolve("example.com", 80) == [
        (socket.AF_INET, ("127.0.1.1", 80))
    ]



# Generated at 2022-06-18 10:28:26.002958
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    from tornado.netutil import ssl_wrap_socket
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    ssl_sock = ssl_wrap_socket(s, ssl.CERT_NONE)
    assert isinstance(ssl_sock, ssl.SSLSocket)
    ssl_sock.close()
    s.close()


# Generated at 2022-06-18 10:28:35.525629
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_stream
    from tornado.platform.asyncio import to_asyncio_sslcontext
    from tornado.platform.asyncio import to_asyncio_datagram_endpoint

# Generated at 2022-06-18 10:28:40.025306
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    # Test that ssl_options_to_context works on a dictionary
    # with all possible keys.
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert isinstance(context, ssl.SSLContext)
    # Test that ssl_options_to_context works on an SSLContext
    context = ssl_options_to_context(context)
    assert isinstance(context, ssl.SSLContext)



# Generated at 2022-06-18 10:29:32.345568
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, None)
    resolver.resolve("", 0)


# Generated at 2022-06-18 10:29:42.695189
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import tornado.testing
    import tornado.ioloop
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio
    import logging
    import os
    import sys
    import unittest
    import functools
    import json
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:29:54.978635
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import shutil
    import os
    import stat
    import socket
    import errno
    import functools
    import time

    def test_unix_socket(file, mode, backlog):
        sock = bind_unix_socket(file, mode, backlog)
        assert isinstance(sock, socket.socket)
        assert sock.getsockname() == file
        assert stat.S_IMODE(os.stat(file).st_mode) == mode
        sock.close()
        os.remove(file)

    def test_unix_socket_error(file, mode, backlog):
        try:
            test_unix_socket(file, mode, backlog)
        except Exception as e:
            assert isinstance(e, ValueError)

# Generated at 2022-06-18 10:30:06.367684
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import functools
    import socket
    import ssl
    import logging
    import os
    import sys
    import time
    import unittest
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop

# Generated at 2022-06-18 10:30:13.591619
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('www.google.com', 443))
    s = tornado.netutil.ssl_wrap_socket(s, ssl.PROTOCOL_SSLv23)
    s.sendall(b'GET / HTTP/1.0\r\n\r\n')
    print(s.recv(1024))
    s.close()


# Generated at 2022-06-18 10:30:15.025270
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:30:17.984479
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = IOLoop.current().run_sync(lambda: resolver.resolve("localhost", 8080))
    assert result == [(2, ('127.0.0.1', 8080))]


# Generated at 2022-06-18 10:30:22.722111
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    assert isinstance(ssl_options_to_context({}), ssl.SSLContext)
    assert isinstance(ssl_options_to_context(ssl.SSLContext(ssl.PROTOCOL_SSLv23)), ssl.SSLContext)
    assert isinstance(ssl_options_to_context({"ssl_version": ssl.PROTOCOL_SSLv23}), ssl.SSLContext)
    assert isinstance(ssl_options_to_context({"certfile": "foo.crt"}), ssl.SSLContext)
    assert isinstance(ssl_options_to_context({"cert_reqs": ssl.CERT_NONE}), ssl.SSLContext)
    assert isinstance(ssl_options_to_context({"ca_certs": "foo.crt"}), ssl.SSLContext)

# Generated at 2022-06-18 10:30:34.953904
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(DefaultExecutorResolver(), {'example.com': '127.0.1.1'})
    assert resolver.resolve('example.com', 80) == [
        (socket.AF_INET, ('127.0.1.1', 80))
    ]
    assert resolver.resolve('example.com', 80, socket.AF_INET6) == [
        (socket.AF_INET6, ('127.0.1.1', 80))
    ]
    assert resolver.resolve('example.com', 443) == [
        (socket.AF_INET, ('127.0.1.1', 443))
    ]

# Generated at 2022-06-18 10:30:37.199377
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:31:15.657773
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:31:25.509659
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import concurrent.futures
    import socket
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest

    class ExecutorResolverTest(AsyncTestCase):
        def setUp(self):
            super(ExecutorResolverTest, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.resolver = ExecutorResolver(self.executor)

        def tearDown(self):
            self.resolver.close()
            self.executor.shutdown()

# Generated at 2022-06-18 10:31:35.776916
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # This test is not run by default because it requires root privileges
    # to bind to port 0.
    import errno
    import functools
    import logging
    import os
    import signal
    import socket
    import threading
    import time
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test
    from tornado.util import errno_from_exception
    from tornado.netutil import add_accept_handler, bind_sockets
    from tornado.platform.auto import set_close_exec
    from tornado.platform.posix import set_nonblocking
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:31:40.115318
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # Test the method resolve of class Resolver
    # Create a Resolver object
    resolver = Resolver()
    # Call the method resolve of the object
    result = resolver.resolve('www.google.com', 80)
    # Check the result
    assert result == [], 'The result should be []'


# Generated at 2022-06-18 10:31:41.222989
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-18 10:31:51.785888
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_NONE
    assert context.check_hostname == False
    assert context.options & ssl.OP_NO_COMPRESSION == ssl.OP_NO_COMPRESSION
    assert context.options & ssl.OP_NO_

# Generated at 2022-06-18 10:32:03.059226
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.caresresolver

# Generated at 2022-06-18 10:32:11.147481
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted

# Generated at 2022-06-18 10:32:20.399112
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import tempfile
    import socket
    import errno
    import shutil
    import stat
    import time
    import unittest
    import functools
    import contextlib
    import threading
    import socketserver
    import tornado.ioloop
    import tornado.testing
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.twisted

# Generated at 2022-06-18 10:32:29.733248
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.ioloop
    import socket
    import time
    import threading
    import tornado.testing
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.twisted