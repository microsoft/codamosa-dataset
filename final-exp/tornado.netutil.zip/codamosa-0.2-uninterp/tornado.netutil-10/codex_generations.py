

# Generated at 2022-06-18 10:23:28.839576
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # OverrideResolver.resolve(self, host: str, port: int, family: socket.AddressFamily = socket.AF_UNSPEC) -> Awaitable[List[Tuple[int, Any]]]:
    resolver = OverrideResolver(None, None)
    host = "example.com"
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:23:31.008729
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    resolver.resolve("localhost", 80)
    resolver.close()


# Generated at 2022-06-18 10:23:40.708945
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket

    class EchoHandler(tornado.websocket.WebSocketHandler):
        def on_message(self, message):
            self.write_message(message)

    class EchoServer(object):
        def __init__(self, port):
            self.port = port
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.setblocking(False)
            self.sock.bind(("127.0.0.1", port))
            self.s

# Generated at 2022-06-18 10:23:52.064090
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import functools
    import time
    import threading
    import os
    import sys
    import unittest
    import warnings
    import weakref
    import concurrent.futures
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent

# Generated at 2022-06-18 10:23:53.646794
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:23:57.545560
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    host = "localhost"
    port = 8080
    family = socket.AF_UNSPEC
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:24:10.883402
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(5)
            self.loop = IOLoop()
            self.loop.make_current()
            self.connections = []
            self.addCleanup(self.loop.close)
            self.addCleanup(self.sock.close)
            self.remove_handler = add_accept_handler(
                self.sock, self.handle_connection
            )

       

# Generated at 2022-06-18 10:24:22.610140
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import functools
    import os
    import sys
    import time
    import unittest
    import warnings
    import logging
    import contextlib
    import io
    import pprint
    import re
    import shutil
    import tempfile
    import threading
    import traceback
    import types
    import unittest.mock
    import urllib.parse
    import uuid
    import weakref
    import zlib
    import base64
    import binascii
    import collections
    import datetime
   

# Generated at 2022-06-18 10:24:26.892402
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver = Resolver(), mapping = {})
    host = "www.google.com"
    port = 80
    family = socket.AF_INET
    resolver.resolve(host, port, family)
    return


# Generated at 2022-06-18 10:24:35.957410
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:25:09.517765
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time

    def handle_connection(connection, address):
        connection.close()

    def run_server():
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setblocking(False)
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.listen(128)
        remove_handler = add_accept_handler(sock, handle_connection)
        try:
            while True:
                time.sleep(3600)
        finally:
            remove_handler()
            sock.close()


# Generated at 2022-06-18 10:25:14.352709
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    resolver = DefaultExecutorResolver()
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(resolver.resolve("localhost", 8080))
    print(result)
    loop.close()


# Generated at 2022-06-18 10:25:23.590224
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import socket
    import tempfile
    import unittest

    from tornado.testing import AsyncTestCase, bind_unused_port

    class BindUnixSocketTest(AsyncTestCase):
        def setUp(self):
            super(BindUnixSocketTest, self).setUp()
            self.tmpdir = tempfile.mkdtemp()
            self.sock_path = os.path.join(self.tmpdir, "sock")

        def tearDown(self):
            super(BindUnixSocketTest, self).tearDown()
            os.remove(self.sock_path)
            os.rmdir(self.sock_path)

        def test_bind_unix_socket(self):
            sock = bind_unix_socket(self.sock_path)

# Generated at 2022-06-18 10:25:30.035681
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()

# Generated at 2022-06-18 10:25:32.955936
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("localhost", 8080)
    assert result is not None


# Generated at 2022-06-18 10:25:45.744006
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()

# Generated at 2022-06-18 10:25:48.801646
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    resolver = Resolver()
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(resolver.resolve('www.google.com', 80))
    print(result)



# Generated at 2022-06-18 10:25:57.079758
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import functools
    import contextlib
    import os
    import sys
    import signal
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:26:08.672185
# Unit test for method resolve of class DefaultExecutorResolver

# Generated at 2022-06-18 10:26:14.061765
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    sock.listen(5)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()


# Generated at 2022-06-18 10:26:38.161848
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import tempfile
    import errno
    import socket
    import shutil
    import stat
    import functools
    import contextlib
    import sys

    def _test_unix_socket(file, mode, backlog):
        sock = bind_unix_socket(file, mode, backlog)
        assert isinstance(sock, socket.socket)
        assert sock.family == socket.AF_UNIX
        assert sock.type == socket.SOCK_STREAM
        assert sock.getsockname() == file
        assert os.stat(file).st_mode & 0o777 == mode
        sock.close()
        os.remove(file)

    def test_unix_socket():
        with tempfile.TemporaryDirectory() as td:
            file = os.path.join(td, "test.sock")

# Generated at 2022-06-18 10:26:49.269242
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import socket
    import stat
    import errno
    import shutil
    import time
    import functools
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AsyncIOMainLoop

# Generated at 2022-06-18 10:26:51.071741
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, None)
    resolver.resolve(None, None)


# Generated at 2022-06-18 10:26:56.865790
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888

# Generated at 2022-06-18 10:27:00.125303
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("www.google.com", 80)
    assert result is not None


# Generated at 2022-06-18 10:27:03.057761
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve("localhost", 8080))


# Generated at 2022-06-18 10:27:15.258260
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    resolver.initialize(resolver, {'example.com': '127.0.1.1'})
    resolver.resolve('example.com', 80)
    resolver.resolve('example.com', 80, socket.AF_INET)
    resolver.resolve('example.com', 80, socket.AF_INET6)
    resolver.resolve('example.com', 80, socket.AF_UNSPEC)
    resolver.resolve('example.com', 80, socket.AF_UNIX)
    resolver.resolve('example.com', 80, socket.AF_APPLETALK)
    resolver.resolve('example.com', 80, socket.AF_PACKET)

# Generated at 2022-06-18 10:27:17.253390
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:27:21.298254
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection: socket.socket, address: Any) -> None:
        pass
    sock = socket.socket()
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()



# Generated at 2022-06-18 10:27:25.565947
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(128)
            self.io_loop = IOLoop.current()
            self.remove_handler = add_accept_handler(
                self.sock, self.handle_connection
            )

        def tearDown(self):
            super(TestAddAcceptHandler, self).tearDown()
            self.remove_handler()
            self.sock.close()


# Generated at 2022-06-18 10:27:44.745986
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    resolver = Resolver()
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(resolver.resolve("www.baidu.com", 80))
    print(result)


# Generated at 2022-06-18 10:27:48.465218
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve('localhost', 8080))
    loop.close()



# Generated at 2022-06-18 10:27:50.944236
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None
    assert resolver.close_executor is False



# Generated at 2022-06-18 10:28:03.253896
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import functools
    import sys
    import time
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.testing import AsyncTestCase
    from tornado.testing import bind_unused_port
    from tornado.testing import gen_test
    from tornado.testing import get_unused_port
    from tornado.testing import main
    from tornado.testing import run_on_executor
    from tornado.testing import skipIfNonUnix
    from tornado.testing import unittest

# Generated at 2022-06-18 10:28:05.918777
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping=None)
    resolver.resolve(host=None, port=None, family=None)


# Generated at 2022-06-18 10:28:14.284488
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unix_socket, gen_test

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unix_socket('', 'test_add_accept_handler')
            self.addCleanup(os.remove, self.sock.getsockname())
            self.client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            self.client_sock.connect(("localhost", self.port))
            self.client_sock.setblocking(False)
            self

# Generated at 2022-06-18 10:28:21.981154
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:28:31.918851
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="[::1]")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8

# Generated at 2022-06-18 10:28:34.736345
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    host = 'example.com'
    port = 80
    family = socket.AF_UNSPEC
    resolver.resolve(host, port, family)


# Generated at 2022-06-18 10:28:36.944503
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket(file="/tmp/test_bind_unix_socket.sock")
    sock.close()
    os.remove("/tmp/test_bind_unix_socket.sock")


# Generated at 2022-06-18 10:29:00.493462
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.util import b

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(128)
            self.loop = IOLoop()
            self.loop.make_current()
            self.remove_handler = add_accept_handler(
                self.sock, self.handle_connection
            )
            self.client_sock = None
            self.client_connected = threading.Event()
            self.client_disconnected

# Generated at 2022-06-18 10:29:04.983902
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:29:14.373823
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    executor = concurrent.futures.ThreadPoolExecutor()
    resolver.initialize(executor)
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == executor
    assert resolver.close_executor == True
    resolver.initialize(executor, False)
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:29:16.651610
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # type: () -> None
    """Unit test for method resolve of class Resolver"""
    # TODO: implement
    pass


# Generated at 2022-06-18 10:29:19.066522
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    resolver.resolve('www.google.com', 80)
    resolver.close()


# Generated at 2022-06-18 10:29:21.976923
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve("www.google.com", 80))



# Generated at 2022-06-18 10:29:33.956894
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("localhost")
    assert not is_valid_ip("")
    assert not is_valid_ip("\x00")
    assert not is_valid_ip("127.0.0.1.1")
    assert not is_valid_ip("127.0.0.1:80")
    assert not is_valid_ip("127.0.0.1:80:80")
    assert not is_valid_ip("127.0.0.1:80:80:80")
    assert not is_valid_ip("127.0.0.1:80:80:80:80")

# Generated at 2022-06-18 10:29:38.010648
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("/tmp/test_bind_unix_socket.sock")
    sock.close()
    os.remove("/tmp/test_bind_unix_socket.sock")


# Generated at 2022-06-18 10:29:40.480612
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888


# Generated at 2022-06-18 10:29:47.853013
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()



# Generated at 2022-06-18 10:30:12.845537
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado.testing
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado

# Generated at 2022-06-18 10:30:20.336463
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import socket
    import time
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:30:31.372625
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import tornado.testing
    import tornado.ioloop
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio

# Generated at 2022-06-18 10:30:34.490078
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Test for method resolve(...) of class OverrideResolver
    # This is a dummy test.
    assert True


# Generated at 2022-06-18 10:30:45.291428
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(0)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(0, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] != 0
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_

# Generated at 2022-06-18 10:30:49.938414
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor


# Generated at 2022-06-18 10:30:52.382614
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Test for method close(self)
    # of class ExecutorResolver
    # This class is tested in test_ThreadedResolver
    pass

# Generated at 2022-06-18 10:30:56.987226
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    resolver = DefaultExecutorResolver()
    loop = tornado.ioloop.IOLoop.current()
    loop.run_sync(lambda: resolver.resolve("www.google.com", 80))


# Generated at 2022-06-18 10:31:00.612606
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Test for method close(self)
    # of class ExecutorResolver
    resolver = ExecutorResolver()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:31:11.264338
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers",
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_NONE
    assert context.check_hostname is False
    assert context.options & ssl.OP_NO_COMPRESSION
    assert context.certfile == "certfile"
    assert context.keyfile == "keyfile"


# Generated at 2022-06-18 10:31:56.992324
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def main():
        resolver = Resolver()
        result = await resolver.resolve('www.baidu.com', 80)
        print(result)
    asyncio.get_event_loop().run_until_complete(main())


# Generated at 2022-06-18 10:32:07.559882
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6

# Generated at 2022-06-18 10:32:16.593758
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    from concurrent.futures import Executor
    from concurrent.futures import ThreadPoolExecutor
    from concurrent.futures import ProcessPoolExecutor
    from concurrent.futures import Future
    from concurrent.futures import Executor
    from concurrent.futures import ThreadPoolExecutor
    from concurrent.futures import ProcessPoolExecutor
    from concurrent.futures import Future
    from concurrent.futures import Executor
    from concurrent.futures import ThreadPoolExecutor
    from concurrent.futures import ProcessPoolExecutor
    from concurrent.futures import Future
    from concurrent.futures import Executor
    from concurrent.futures import ThreadPoolExecutor
    from concurrent.futures import ProcessPoolExecutor
    from concurrent.futures import Future
    from concurrent.futures import Executor


# Generated at 2022-06-18 10:32:25.132661
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import concurrent.futures
    import socket
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:32:34.398201
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert isinstance(context, ssl.SSLContext)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.options == 0
    assert context.check_hostname == False
    assert context.verify_flags == 0
   

# Generated at 2022-06-18 10:32:41.760504
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    resolver = DefaultExecutorResolver()
    async def test_resolve():
        print(await resolver.resolve('www.baidu.com', 80))
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_resolve())
    loop.close()


# Generated at 2022-06-18 10:32:50.497007
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888