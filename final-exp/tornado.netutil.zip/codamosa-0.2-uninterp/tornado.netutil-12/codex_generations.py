

# Generated at 2022-06-18 10:23:24.825404
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    asyncio.set_event_loop(asyncio.new_event_loop())
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("www.google.com", 80)
    print(result)
    tornado.ioloop.IOLoop.current().start()


# Generated at 2022-06-18 10:23:30.112993
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:23:35.678328
# Unit test for function bind_sockets
def test_bind_sockets():
    port = 8888
    address = "localhost"
    family = socket.AF_UNSPEC
    backlog = _DEFAULT_BACKLOG
    flags = None
    reuse_port = False
    sockets = bind_sockets(port, address, family, backlog, flags, reuse_port)
    for sock in sockets:
        print(sock)
        sock.close()

# test_bind_sockets()


# Generated at 2022-06-18 10:23:41.091436
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # type: () -> None
    """
    Test for method resolve of class Resolver
    """
    resolver = Resolver()
    host = "www.google.com"
    port = 80
    family = socket.AF_INET
    result = resolver.resolve(host, port, family)
    assert result is not None
    assert isinstance(result, Awaitable)
    assert isinstance(result, Future)
    assert isinstance(result.result(), list)
    assert isinstance(result.result()[0], tuple)
    assert isinstance(result.result()[0][0], int)
    assert isinstance(result.result()[0][1], tuple)
    assert isinstance(result.result()[0][1][0], str)

# Generated at 2022-06-18 10:23:52.133816
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.caresresolver
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:23:55.005614
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor)
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:24:08.262486
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", reuse_port=True)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888

# Generated at 2022-06-18 10:24:17.627553
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()
    sockets = bind_sockets(8888, family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_IN

# Generated at 2022-06-18 10:24:30.012143
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile
    import os
    import errno
    import socket
    import stat
    import shutil
    import time
    import functools
    import signal
    import subprocess
    import sys
    import threading
    import unittest
    import warnings
    import weakref
    import selectors
    import socketserver
    import contextlib
    import io
    import gc
    import re
    import base64
    import binascii
    import email.utils
    import email.message
    import email.parser
    import email.policy
    import email.generator
    import email.errors
    import email.headerregistry
    import email.header
    import email.charset
    import email.utils
    import email.base64mime
    import email.quoprimime
    import email.encod

# Generated at 2022-06-18 10:24:30.404518
# Unit test for function add_accept_handler
def test_add_accept_handler():
    pass



# Generated at 2022-06-18 10:24:53.027173
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    sock.listen(1)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()
    sock.close()


# Generated at 2022-06-18 10:25:03.415783
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import socket
    import time
    import unittest
    import tornado.ioloop
    import tornado.netutil
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.httpclient_test
    import tornado.web
    import tornado.websocket
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.kqueue
    import tornado.platform.epoll
    import tornado.platform.auto

# Generated at 2022-06-18 10:25:11.835369
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.thread = threading.Thread(target=self.thread_run)
            self.thread.daemon = True
            self.thread.start()
            self.addCleanup(self.sock.close)
            self.addCleanup(self.thread.join)

        def thread_run(self):
            time.sleep(0.1)

# Generated at 2022-06-18 10:25:13.295778
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    resolver.initialize()
    resolver.resolve("www.baidu.com", 80)
    resolver.close()


# Generated at 2022-06-18 10:25:22.574482
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_TLSv1,
        "certfile": "cert.pem",
        "keyfile": "key.pem",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "cacert.pem",
        "ciphers": "cipher",
    }
    context = ssl_options_to_context(ssl_options)
    assert isinstance(context, ssl.SSLContext)
    assert context.protocol == ssl.PROTOCOL_TLSv1
    assert context.certfile == "cert.pem"
    assert context.keyfile == "key.pem"
    assert context.verify_mode == ssl.CERT_

# Generated at 2022-06-18 10:25:29.328939
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import unittest

    from tornado.ioloop import IOLoop

    class TestAddAcceptHandler(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.sock, self.client_sock = socket.socketpair()
            self.client_sock.setblocking(False)
            self.server_sock = socket.socket()
            self.server_sock.setblocking(False)
            self.server_sock.bind(("127.0.0.1", 0))
            self.server_sock.listen(5)
            self.port = self.server_sock.getsockname()[1]
            self.event = thread

# Generated at 2022-06-18 10:25:42.909997
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest

    from tornado.ioloop import IOLoop

    def handle_connection(connection, address):
        connection.send(b"hello")
        connection.close()

    def client_thread(port):
        time.sleep(0.1)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        s.connect(("127.0.0.1", port))
        result = s.recv(5)
        s.close()
        return result

    class AddAcceptHandlerTest(unittest.TestCase):
        def test_add_accept_handler(self):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)

# Generated at 2022-06-18 10:25:47.604844
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    sock = sockets[0]
    assert sock.family == socket.AF_INET
    assert sock.getsockname()[1] == 8888
    sock.close()


# Generated at 2022-06-18 10:25:50.309740
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:25:57.821613
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.platform.asyncio
    import asyncio
    import functools
    import contextlib
    import time
    import os
    import sys
    import threading
    import unittest
    import warnings
    import weakref
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.fut

# Generated at 2022-06-18 10:26:15.905400
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:26:17.504871
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None


# Generated at 2022-06-18 10:26:24.399254
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    resolver.initialize(executor)
    assert resolver.executor == executor
    assert resolver.close_executor == True
    assert resolver.io_loop == IOLoop.current()
    resolver.initialize(executor, False)
    assert resolver.executor == executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()


# Generated at 2022-06-18 10:26:33.471960
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    import tornado.testing
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:26:45.238465
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    import tornado.netutil
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    ssl_options = {
        "certfile": "server.crt",
        "keyfile": "server.key",
        "cert_reqs": ssl.CERT_NONE,
        "ssl_version": ssl.PROTOCOL_TLSv1,
        "ca_certs": None,
        "ciphers": None
    }
    ssl_socket = tornado.netutil.ssl_wrap_socket(s, ssl_options)
    print(ssl_socket)

if __name__ == "__main__":
    test_ssl_wrap_socket()

# Generated at 2022-06-18 10:26:47.638141
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.close_executor == close_executor


# Generated at 2022-06-18 10:26:57.919442
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.client = socket.socketpair()
            self.sock.setblocking(False)
            self.client.setblocking(False)
            self.addCleanup(self.sock.close)
            self.addCleanup(self.client.close)
            self.addCleanup(self.io_loop.remove_handler, self.sock)
            self.addCleanup(self.io_loop.remove_handler, self.client)
            self.accepted = []  # type: List[socket.socket]
            self.accept_

# Generated at 2022-06-18 10:27:10.461426
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.bind(("127.0.0.1", 0))
    sock.listen(5)
    port = sock.getsockname()[1]
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    client.connect(("127.0.0.1", port))
    client.close()
    def accept_handler(connection, address):
        connection.close()
        remove_handler()
        io_loop.stop()
    remove_handler = add_accept_handler(sock, accept_handler)
    io_loop = IOLoop.current()
    io_loop.start()
    sock.close()



# Generated at 2022-06-18 10:27:12.367802
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:27:24.184547
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_TLSv1,
        "certfile": "cert.pem",
        "keyfile": "key.pem",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": "cacert.pem",
        "ciphers": "AES:!ADH:!LOW:!EXP:!MD5:@STRENGTH",
    }
    context = ssl_options_to_context(ssl_options)
    assert isinstance(context, ssl.SSLContext)
    assert context.protocol == ssl.PROTOCOL_TLSv1
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname is False

# Generated at 2022-06-18 10:28:34.774427
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    s = socket.socket()
    s.bind(('', 0))
    s.listen(1)
    port = s.getsockname()[1]
    ssl_options = {
        "certfile": "tests/test.crt",
        "keyfile": "tests/test.key",
        "ssl_version": ssl.PROTOCOL_TLSv1,
    }
    ssl_sock = ssl_wrap_socket(s, ssl_options)
    assert isinstance(ssl_sock, ssl.SSLSocket)
    ssl_sock.close()
    s.close()


# Generated at 2022-06-18 10:28:35.838714
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None


# Generated at 2022-06-18 10:28:47.838390
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET6
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET)
    assert len(sockets) == 1

# Generated at 2022-06-18 10:28:48.871287
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:28:59.598303
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET6)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()
    sockets = bind_sockets(8888, address="localhost", family=socket.AF_INET)
    assert len(sockets) == 1

# Generated at 2022-06-18 10:29:00.836637
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:29:10.769764
# Unit test for method resolve of class Resolver

# Generated at 2022-06-18 10:29:12.118728
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-18 10:29:18.182346
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    async def test():
        resolver = DefaultExecutorResolver()
        result = await resolver.resolve('www.baidu.com', 80)
        print(result)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()


# Generated at 2022-06-18 10:29:29.489379
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    assert context.protocol == ssl.PROTOCOL_SSLv23
    assert context.verify_mode == ssl.CERT_NONE
    assert context.check_hostname == False
    assert context.options & ssl.OP_NO_COMPRESSION
    assert context.certfile == "certfile"
    assert context.keyfile == "keyfile"


# Generated at 2022-06-18 10:30:13.592136
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    resolver = DefaultExecutorResolver()
    result = loop.run_until_complete(resolver.resolve('www.google.com', 80))
    print(result)


# Generated at 2022-06-18 10:30:21.348086
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.util import b

    class TestAddAcceptHandler(AsyncTestCase):
        def setUp(self):
            super(TestAddAcceptHandler, self).setUp()
            self.sock, self.port = bind_unused_port()
            self.sock.listen(5)
            self.accepted = []  # type: List[Tuple[socket.socket, Any]]
            self.accept_handler = add_accept_handler(
                self.sock, self.accepted.append
            )

        def tearDown(self):
            self.accept_handler()
            self.sock.close()
           

# Generated at 2022-06-18 10:30:26.236698
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False


# Generated at 2022-06-18 10:30:35.019629
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("www.baidu.com", 443))
    s = ssl_wrap_socket(s, ssl.create_default_context())
    s.sendall(b"GET / HTTP/1.1\r\nHost: www.baidu.com\r\n\r\n")
    print(s.recv(1024))
    s.close()
# test_ssl_wrap_socket()



# Generated at 2022-06-18 10:30:37.422912
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver=None, mapping={})
    resolver.resolve(host="", port=0, family=socket.AF_UNSPEC)


# Generated at 2022-06-18 10:30:41.892634
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:30:52.859611
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="localhost")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

    sockets = bind_sockets(8888, address="127.0.0.1")
    assert len(sockets) == 1
    assert sockets[0].family == socket.AF_INET
    assert sockets[0].getsockname()[1] == 8888
    sockets[0].close()

# Generated at 2022-06-18 10:30:55.032949
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-18 10:30:56.221216
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-18 10:30:58.673008
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Test for method close(self)
    # of class ExecutorResolver
    # This class is deprecated, so we don't test it.
    pass



# Generated at 2022-06-18 10:32:41.574224
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import socket
    import tempfile
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_unix_socket

    class UnixSocketTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.socket_path = os.path.join(self.tmpdir, "test.sock")

        def tearDown(self):
            os.remove(self.socket_path)
            os.rmdir(self.tmpdir)

        def test_unix_socket(self):
            sock = bind_unix_socket(self.socket_path)
            self.assertEqual(sock.getsockname(), self.socket_path)

# Generated at 2022-06-18 10:32:50.368477
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import unittest
    class EchoHandler(tornado.websocket.WebSocketHandler):
        def on_message(self, message):
            self.write_message(message)
    class EchoServer(tornado.web.Application):
        def __init__(self):
            super(EchoServer, self).__init__([(r"/", EchoHandler)])
            self.sock, self.port = bind_unix_socket(
                "/tmp/tornado-test-echo-%s" % id(self))
            add_accept_handler(self.sock, self.handle_connection)