

# Generated at 2022-06-12 13:46:47.837029
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Tornado 6.0
    # Unit test for method initialize of class ExecutorResolver
    resolver = ExecutorResolver()
    resolver.initialize(executor=None, close_executor=True)
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False


# Generated at 2022-06-12 13:46:53.193091
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    ssl_options_to_context({})
    ssl_options_to_context({"ssl_version": ssl.PROTOCOL_SSLv23})
    ssl_options_to_context({"ssl_version": ssl.PROTOCOL_SSLv23, "certfile": "foo"})
    ssl_options_to_context({"cert_reqs": ssl.CERT_NONE})
    ssl_options_to_context({"ca_certs": "foo"})
    ssl_options_to_context({"ciphers": "foo"})
    ssl_options_to_context({"ssl_version": ssl.PROTOCOL_SSLv23, "ciphers": "foo"})
    # bytes values are accepted too in python 3
    ssl

# Generated at 2022-06-12 13:47:01.104306
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.concurrent import Future
    import socket
    import tornado.testing
    # TODO: 不清楚这句啥意思
    DeferredResolver = (DefaultExecutorResolver if DefaultExecutorResolver is not None else object)
    # TODO: 不清楚这里随机数字干啥的
    class FakeResolver(DeferredResolver):
        def initialize(self):
            self.fetch_hosts = {}

        def resolve(self, host, port, family):
            if host in self.fetch_hosts:
                raise IOError("getaddrinfo failed")
            if host == 'fail.example.com':
                raise IOError("nxdomain")

# Generated at 2022-06-12 13:47:11.116583
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    mapping = {
       "example.com": "127.0.1.1",

       ("login.example.com", 443): ("localhost", 1443),

       ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    args={
        "host": "login.example.com",
        "port": 443,
        "family": socket.AF_INET6
    }
    resolver = Resolver()
    override_resolver = OverrideResolver(resolver, mapping)
    result = override_resolver.resolve(**args)
    [assert_equal("::1", result[0][1][0])]


# Generated at 2022-06-12 13:47:11.893300
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    pass



# Generated at 2022-06-12 13:47:14.141672
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    print("in class ExecutorResolver: def close")
    pass


# Generated at 2022-06-12 13:47:14.825313
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    pass

# Generated at 2022-06-12 13:47:22.935434
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    from tornado.ioloop import IOLoop
    from tornado.escape import to_unicode
    import json
    import tornado.platform.asyncio
    resolver = AsyncResolver()
    # Create a coroutine
    async def main():
        url = 'https://www.taobao.com/'
        async with ClientSession() as session:
            async with session.get(url) as response:
                response = await response.read()
                print('The type of response is {0}'.format(type(response)))
                print('The response is {0}'.format(response))
                response = to_unicode(response)
                #response = json.loads(response)
                return response

# Generated at 2022-06-12 13:47:25.531031
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import asyncio
    import tornado.ioloop
    import tornado.netutil
    loop = tornado.ioloop.IOLoop()
    loop.make_current()
    resolver = tornado.netutil.DefaultExecutorResolver()
    result = tornado.ioloop.IOLoop.current().run_sync(lambda:resolver.resolve("www.baidu.com",80))
    assert len(result) > 0
    loop.close()



# Generated at 2022-06-12 13:47:29.198100
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = OverrideResolver()
    resolver.resolver = None
    resolver.mapping = {'example.com': '127.0.1.1', ('login.example.com', 443): ('localhost', 1443), ('login.example.com', 443, socket.AF_INET6): (':1', 1443)}
    resolver.close()

    assert True

# Generated at 2022-06-12 13:47:57.245750
# Unit test for function add_accept_handler
def test_add_accept_handler():
    """测试 add_accept_handler 函数"""

    from tornado.httpserver import HTTPServer
    from tornado.netutil import ssl_wrap_socket
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.web import RequestHandler, Application, url
    from tornado.websocket import WebSocketHandler, WebSocketClosedError

    # 本测试用例没有检查服务器端发送的信息，只看客户端收到的信息是不是和发送的客户端一致
    message = "hello world!"
    web_sockets = []  # type:

# Generated at 2022-06-12 13:47:59.890622
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    executor = ThreadPoolExecutor(max_workers=3)
    resolver = ExecutorResolver(executor=executor)
    assert(len(loop.run_until_complete(resolver.resolve("google.com", 80))) > 0)
    executor.shutdown()
    del resolver



# Generated at 2022-06-12 13:48:07.669493
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    close_executor = True
    io_loop = IOLoop.current()
    resolver = ExecutorResolver(executor=executor, close_executor=close_executor)
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-12 13:48:14.839823
# Unit test for function bind_sockets
def test_bind_sockets():
    print("**** test_bind_sockets ****")

    # Test to make sure we can bind two sockets to one port
    port = 54321
    sockets = bind_sockets(port)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == port

    sockets = bind_sockets(port, reuse_port=True)
    assert len(sockets) == 2
    assert sockets[0].getsockname()[1] == port
    assert sockets[1].getsockname()[1] == port
    IOLoop.current().run_sync(lambda: IOLoop.current().close())


# Generated at 2022-06-12 13:48:17.179024
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8000)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8000



# Generated at 2022-06-12 13:48:20.430811
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    class TestExecutor(object):
        def shutdown(self):
            pass
    resolver = ExecutorResolver(executor=TestExecutor(), close_executor=True)
    resolver.close()
    assert resolver.executor is None



# Generated at 2022-06-12 13:48:23.518910
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = Resolver()
    mapping = dict()
    override_resolver = OverrideResolver(resolver, mapping)
    override_resolver.close()


# Generated at 2022-06-12 13:48:33.772857
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1',0))
    sock.listen(10)
    (host, port) = sock.getsockname()

    def client_sock():
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((host, port))
        return s

    def test_callback(connection, address):
        self.assertTrue(connection.fileno() > 0)
        self.assertEqual(address[0], '127.0.0.1')
        self.assertEqual(address[1], port)
        connection.close()

    client_sock()

# Generated at 2022-06-12 13:48:35.317355
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    assert isinstance(resolver.close(), None)

# Generated at 2022-06-12 13:48:44.159927
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    obj = OverrideResolver()
    assert isinstance(obj, Resolver)
    assert isinstance(obj, Configurable)
    mapping_dict = {}
    obj.initialize(BlockingResolver(), mapping_dict)
    assert obj.resolver == BlockingResolver()
    assert obj.mapping == mapping_dict

    obj.resolve("example.com", 443, socket.AF_INET)
    obj.resolve("login.example.com", 443)
    obj.resolve("login.example.com", 443, socket.AF_INET6)



# Generated at 2022-06-12 13:49:17.226419
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = Resolver()
    mapping = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    resolver = OverrideResolver(resolver, mapping)
    resolver.close()


_DEFAULT_RESOLVER = None  # type: Resolver



# Generated at 2022-06-12 13:49:29.737001
# Unit test for function bind_sockets
def test_bind_sockets():
    try:
        socket.AF_INET6 
    except:
        raise Exception('ipv6 not supported')

    # port scanner: since bind_sockets tests reuse of port, it is
    # useful to be able to run a test script while ports are still in
    # TIME_WAIT state.
    import eventlet
    eventlet.sleep(0.1)
    print('bind_sockets, port=80')
    assert bind_sockets(80)
    print('bind_sockets, port=8080')
    assert bind_sockets(8080)
    print('bind_sockets, port=0')
    # this should allocate a high-numbered port and then get that
    # same port again when it runs the second time.
    sockets = bind_sockets(0)

# Generated at 2022-06-12 13:49:31.848522
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver=Resolver()
    mapping={}
    ors=OverrideResolver(resolver,mapping)
    ors.close()
    assert True



# Generated at 2022-06-12 13:49:36.586039
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    loop = asyncio.get_event_loop()
    async def async_main():
        resolver = DefaultExecutorResolver()
        print(await resolver.resolve('localhost', 80))
    loop.run_until_complete(async_main())


# Generated at 2022-06-12 13:49:38.841889
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = Resolver()
    mapping = {}
    resolver = Resolver()
    mapping = {}
    _OverrideResolver__self = OverrideResolver()
    _OverrideResolver__self.close()
    _OverrideResolver__resolver = OverrideResolver()
    _OverrideResolver__resolver.close()



# Generated at 2022-06-12 13:49:41.474747
# Unit test for function bind_sockets
def test_bind_sockets():
    port = 10000
    sockets = bind_sockets(port, 'localhost', backlog=100)
    print(sockets)
    print(len(sockets))
#test_bind_sockets()


# Generated at 2022-06-12 13:49:44.370830
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    #Test case 1: Default implementation
    resolver = OverrideResolver()
    assert resolver.close() == None
    #Test case 2: Override implementation
    resolver = OverrideResolver()
    assert resolver.close(resolver, mapping) == None

unit_test_list.append(test_OverrideResolver_close)

# Generated at 2022-06-12 13:49:47.195987
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    host_port_family_tuple = ("a" , 1 , 1 )
    resolver = "Test"
    mapping = {
        host_port_family_tuple : ("b" , 2 , 2 )
        }
    r = OverrideResolver(resolver, mapping)
    r.close()
    return

# Generated at 2022-06-12 13:49:48.585151
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    try:
        d = ExecutorResolver(executor="executor", close_executor=True)
        print(d)
    except Exception as e:
        print(e)

# Generated at 2022-06-12 13:49:52.472951
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    '''
    This function runs unit test for method close of class ExecutorResolver
    '''
    def test_ExecutorResolver_close():
        resolver = ExecutorResolver()
        resolver.close()
    test_ExecutorResolver_close()
    return True



# Generated at 2022-06-12 13:50:19.665077
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    s = socket.socket()
    remove_handler = add_accept_handler(s,lambda connection, address: None)
    io_loop = IOLoop.current()
    io_loop.add_handler(s.fileno(), lambda fd, events: None, IOLoop.READ)
    OverrideResolver.configure("tornado.netutil.OverrideResolver", resolver=s, mapping={"a":"b"})
    io_loop.remove_handler(s.fileno())
    remove_handler()
    s.close()
    #assert False # TODO: implement your test here


# Generated at 2022-06-12 13:50:24.523730
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    def func():
        # Testing
        r = DefaultExecutorResolver()
        try:
            r.resolve("", 80, socket.AF_INET)
        except IOError as e:
            print(e.args[0])
        r.close()
    func()



# Generated at 2022-06-12 13:50:27.327782
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(resolver, mapping)
    assert resolver.resolve(host, port, family)

# Generated at 2022-06-12 13:50:35.434049
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado.netutil
    import concurrent.futures
    import socket
    import concurrent
    import logging
    import functools
    import tornado.gen
    def executor_test():
        ioloop = tornado.ioloop.IOLoop
        executor = concurrent.futures.ThreadPoolExecutor(5)
        resolver = tornado.netutil.ExecutorResolver(executor)
        future = resolver.resolve('localhost', 8080)
        ioloop.IOLoop.current().add_callback((lambda: 'Foo'))
        print(future)
    executor_test()

# Generated at 2022-06-12 13:50:47.093925
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    pass

    """
    Resolve a host.

    :param host: A string containing either a hostname or an IP address.
    :param port: The port number, passed as an `int`.
    :param family: The address family of the socket, either
        ``socket.AF_INET`` (default) or ``socket.AF_INET6``.
    :return: `.Future` whose result is a list of (family, address)
        pairs, where address is a tuple suitable to pass to
        `socket.connect <socket.socket.connect>` (i.e. a ``(host,
        port)`` pair for IPv4; additional fields may be present for
        IPv6).

    .. versionchanged:: 4.0
       Now returns a `.Future`.
    """



# Generated at 2022-06-12 13:50:56.499719
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    try:
        import ssl

    except ImportError:
        print("ssl module not found; skipping")
        return True


# Generated at 2022-06-12 13:51:07.357267
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("127.0.0.1", 0))
    sock.listen()

    def callback(*args: Any, **kwargs: Any) -> None:
        raise Exception("accepted unexpected connection")

    io_loop = IOLoop.current()

    remove_handler = add_accept_handler(sock, callback)
    try:
        io_loop.start()
    finally:
        remove_handler()
        io_loop.close(all_fds=True)
        sock.close()



# Generated at 2022-06-12 13:51:15.209201
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import os
    import sys
    import socket
    import threading
    import time
    
    hostname = os.uname()[1]
    port = 12345
    timeout = 2

    def start_test_server():
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind(("localhost", 12345))
        server.listen(5)
        return server

    def start_test_client():
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect(("localhost", 12345))
        return client

    def start_servers():
        test_server = start_test_server()
        add_accept_handler(test_server, accept_connection_handler)
        return test_server


# Generated at 2022-06-12 13:51:21.527340
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = sockets = bind_sockets(8888)
    sockets = sockets = bind_sockets(8888, address="127.0.0.1")
    sockets = sockets = bind_sockets(8888, address="0.0.0.0")
    sockets = sockets = bind_sockets(8888, address="::")
    sockets = sockets = bind_sockets(8888, address="::1")


# Generated at 2022-06-12 13:51:25.279383
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    test_sock_name = '/tmp/test_socket'
    test_sock = None
    try:
        test_sock = bind_unix_socket(test_sock_name)
        assert test_sock.family == socket.AF_UNIX
        assert test_sock.type == socket.SOCK_STREAM
    finally:
        if test_sock is not None:
            test_sock.close()
            os.unlink(test_sock_name)


# Generated at 2022-06-12 13:52:29.949903
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    assert (isinstance(Resolver().resolve("127.0.0.1",5000), tornado.concurrent.Future))

# Generated at 2022-06-12 13:52:41.185460
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import platform
    print(platform.python_version())
    if platform.python_version() >= "3.7":
        print(os.getpid())
        if os.getpid() == 1:
            return
        try:
            while True:
                import time
        except KeyboardInterrupt:
            pass
    
    class Server(object):
        def __init__(self, io_loop=None, ssl_options=None, **kwargs):
            self.io_loop = io_loop or IOLoop.current()

            self.ssl_options = ssl_options
            self.__dict__.update(**kwargs)

            self._initialized = False
            self._sockets = None  # type: List[socket.socket]
            self._socket_fds = set()  # type: set
            self._p

# Generated at 2022-06-12 13:52:45.102606
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert(is_valid_ip("192.168.1.1") == True)
    assert(is_valid_ip("192.168.1") == False)
    assert(is_valid_ip("::") == True)
    assert(is_valid_ip("::1") == True)
    assert(is_valid_ip("::192.168.1.1") == True)
    assert(is_valid_ip("::192.168.1") == False)
    assert(is_valid_ip("") == False)
    assert(is_valid_ip("\x00") == False)
test_is_valid_ip()

DEFAULT_MAX_BUFFER_SIZE = 104857600
DEFAULT_READ_CHUNK_SIZE = 4096



# Generated at 2022-06-12 13:52:49.937896
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado import platform
    assert platform.is_resolver_available()
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import tornado.platform.twisted
    tornado.platform.twisted.TwistedIOMainLoop().install()
    resolver = DefaultExecutorResolver()
    assert resolver is not None
    assert isinstance(resolver, DefaultExecutorResolver)
    assert isinstance(resolver, Resolver)
    # assert resolver.resolve('localhost', 80) is not None
    # assert resolver.resolve('127.0.0.1', 80) is not None
    # assert resolver.resolve('8.8

# Generated at 2022-06-12 13:53:02.204464
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {
        'ssl_version': ssl.PROTOCOL_TLSv1,
        'certfile': 'foo',
        'keyfile': 'bar',
        'cert_reqs': ssl.CERT_OPTIONAL,
        'ca_certs': 'baz',
        'ciphers': 'qux'
    }

    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
    ssl_context.load_cert_chain('foo', 'bar')
    ssl_context.verify_mode = ssl.CERT_OPTIONAL
    ssl_context.load_verify_locations('baz')
    ssl_context.set_ciphers('qux')

# Generated at 2022-06-12 13:53:04.700574
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    assert isinstance(DefaultExecutorResolver.resolve(None, 'localhost', 0), Awaitable)



# Generated at 2022-06-12 13:53:08.380013
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    from concurrent.futures import ThreadPoolExecutor
    ex = ThreadPoolExecutor(1)
    # self.executor.shutdown()
    ex.shutdown()
    # self.executor = None
    ex = None
    assert ex is None


# Generated at 2022-06-12 13:53:14.181011
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    try:
        host = 'localhost'
        port = 8080
        dres = DefaultExecutorResolver()
        asyncio.get_event_loop().run_until_complete(dres.resolve(host, port))
    except AssertionError as e:
        print('AssertionError:', e)
    else:
        print('resolve success')



# Generated at 2022-06-12 13:53:18.248300
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # The python socket object
    sock = socket.socket()
    # The callback function
    def callback(connection, address): print(connection, address)
    # The add_accept_handler
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()

# Generated at 2022-06-12 13:53:22.466140
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # Test data
    host = "www.baidu.com"
    port = 80
    family = socket.AF_INET

    # Check type 
    resolver = Resolver()
    assert isinstance(resolver.resolve(host, port, family), Future)


# Generated at 2022-06-12 13:53:58.044767
# Unit test for function bind_sockets
def test_bind_sockets():
    a = bind_sockets(8080)

# Generated at 2022-06-12 13:54:08.540584
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    test_file_name = 'test.sock'
    sock = bind_unix_socket('test.sock')
    os.remove(test_file_name)
    assert sock
    try:
        sock = bind_unix_socket(test_file_name)
        os.remove(test_file_name)
        assert sock
    except ValueError as e:
        assert e
    test_file = open(test_file_name, "w+")
    test_file.write('')
    try:
        sock = bind_unix_socket(test_file_name)
        os.remove(test_file_name)
        assert sock
    except ValueError as e:
        assert e
    os.remove(test_file_name)

# TODO: remove type: ignore comments once https://github.

# Generated at 2022-06-12 13:54:10.896255
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import tornado
    resolver = tornado.netutil.Resolver()
    print(resolver.resolve('www.baidu.com',80))


# Generated at 2022-06-12 13:54:14.907384
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    host = 'google.com'
    port = 80
    family = socket.AF_INET
    ip = resolver.resolve(host, port, family)
    print(ip)

if __name__ == '__main__':
    test_OverrideResolver_resolve()

# Generated at 2022-06-12 13:54:24.378239
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado.testing import gen_test
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio

    def test_func():
        import socket
        import time
        from tornado.ioloop import IOLoop
        from tornado.platform.asyncio import to_asyncio_future
        import asyncio

        async def test_resolve_ip_type(ip:str,af:int):
            # [1] get the result by calling resolve of DefaultExecutorResolver
            resolver = DefaultExecutorResolver()
            result = await resolver.resolve(ip,0,af)
            # [2] get the result by calling _resolve_addr directly
            result2 = _resolve_addr(ip,0,af)

# Generated at 2022-06-12 13:54:34.420233
# Unit test for function bind_sockets
def test_bind_sockets():
    import tempfile

    s = bind_sockets(0)
    assert len(s) == 1
    assert s[0].getsockname()[1] != 0
    s[0].close()

    # bind a specific port
    port = 8888
    s = bind_sockets(port)
    assert len(s) == 1
    assert s[0].getsockname()[1] == port
    s[0].close()

    # bind an ephemeral port with a specific address
    # this test is only relevant on IPv4 systems
    if not socket.has_ipv6:
        port = 8888
        s = bind_sockets(port, "127.0.0.1")
        assert len(s) == 1
        assert s[0].getsockname()()[1] == port

# Generated at 2022-06-12 13:54:43.638201
# Unit test for function add_accept_handler
def test_add_accept_handler():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('', 0))
    server_socket.listen(5)
    server_socket.setblocking(False)
    address = server_socket.getsockname()

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(address)
    client_socket.close()

    def on_accepted(connection, address):
        raise NotImplementedError()

    remove_accept_handler = add_accept_handler(server_socket, on_accepted)
    remove_accept_handler()



# Generated at 2022-06-12 13:54:51.637421
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado import gen
    import asyncio
    from concurrent.futures import ThreadPoolExecutor
    import socket
    import unittest

    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado import testing
    from tornado.testing import gen_test

    @gen.coroutine
    def a():
        print('a')

# Generated at 2022-06-12 13:54:54.700066
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    print(sockets)
    sockets = bind_sockets(8888)
    print(sockets)
# test_bind_sockets()


# Generated at 2022-06-12 13:55:03.744232
# Unit test for function is_valid_ip
def test_is_valid_ip():
    io_loop = IOLoop()
    io_loop.make_current()
    # Valid IP address
    assert is_valid_ip("8.8.8.8") == True
    assert is_valid_ip("2606:4700:4700::1111") == True
    # Invalid IP address
    assert is_valid_ip("localhost") == False
    assert is_valid_ip("") == False
    assert is_valid_ip(" ") == False
    assert is_valid_ip("8.8.8.8 \x00") == False
    io_loop.close(True)

# test_is_valid_ip()



# Generated at 2022-06-12 13:55:47.420817
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Create a resolver and insert the mapping.
    resolver = OverrideResolver(DefaultExecutorResolver(), {
        'example.com': '127.0.1.1',
        ('login.example.com', 443): ('localhost', 1443),
        ('login.example.com', 443, socket.AF_INET6): ("::1", 1443),
        ('example.com', 80, socket.AF_INET): ('127.0.2.2', 8080),
    })
    # Test set 1: Hostname to host or ip
    host, port, family = 'example.com', 80, socket.AF_INET
    result = resolver.resolve(host, port, family)