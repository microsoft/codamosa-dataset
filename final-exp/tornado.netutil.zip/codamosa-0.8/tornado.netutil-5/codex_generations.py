

# Generated at 2022-06-12 13:46:34.576807
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop

    loop = AsyncIOMainLoop()
    loop.make_current()

    import asyncio

    resolver = Resolver()
    mapping = {"www.baidu.com": "0.0.0.0", "www.google.com": "127.0.0.1"}
    override = OverrideResolver(resolver, mapping)
    # host: www.baidu.com
    # port: 0
    # family: socket.AddressFamily.AF_UNSPEC

    host = "www.baidu.com"
    port = 0
    family = socket.AddressFamily.AF_UNSPEC

    ans = override.resolve(host, port, family)
    loop.run_until_complete(ans)
    print(ans)

    #

# Generated at 2022-06-12 13:46:46.831630
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    # Create an instance of class DefaultExecutorResolver
    ip_resolver = DefaultExecutorResolver()
    # Test method resolve of class DefaultExecolver
    resolve_results = asyncio.get_event_loop().run_until_complete(
        ip_resolver.resolve("www.google.com", 80)
    )
    assert resolve_results == [
        (2, ("172.217.15.164", 80)), (30, ("::1", 80, 0, 0))
    ]
    resolve_results = asyncio.get_event_loop().run_until_complete(
        ip_resolver.resolve("www.google.com", 443)
    )

# Generated at 2022-06-12 13:46:51.495756
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=5)
    resolver = ExecutorResolver(executor,False)
    host = 'www.google.com'
    port = 80
    family = socket.AF_UNSPEC
    res = resolver.resolve(host,port,family)
    print("Resolve test result: ")
    print(res)

# Unit test class ExecutorResolver

# Generated at 2022-06-12 13:46:53.275879
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()

test_ExecutorResolver_close()


# Generated at 2022-06-12 13:46:54.578750
# Unit test for function bind_sockets
def test_bind_sockets():
    sock = bind_sockets(9000, address="localhost")


# Generated at 2022-06-12 13:46:58.786675
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    try:
        # Resolver.resolve is an abstract method, but
        # the abstractmethod decorator isn't available on python 2.5
        # so we have to check manually
        tornado.netutil.Resolver().resolve('', 0)
    except NotImplementedError:
        pass
    else:
        raise Exception("expected not implemented error")



# Generated at 2022-06-12 13:47:09.667105
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    @gen.coroutine
    def test_resolve():
        # if a callback is passed, it will be run with the result as an argument when it is complete
        addrinfo = yield Resolver().resolve("www.google.com", 80)
        print(addrinfo)
    # Resolve a hostname to a list of socket addresses. The socket addresses will be resolved in
    # round-robin order, except that results which fail to connect will be skipped for a short time.
    # Address may be a string representing a hostname or IP address, or a tuple
    # representing a raw address (e.g. ('10.0.0.1', 8080))
    # If the optional family parameter is set to socket.AF_INET the function will
    # resolve the hostname to an IPv4 address, and if it’s set to socket.AF_IN

# Generated at 2022-06-12 13:47:12.537746
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8000)
    for sock in sockets:
        print(sock)
        sock.close()

# Generated at 2022-06-12 13:47:21.743881
# Unit test for function is_valid_ip
def test_is_valid_ip():
	# Test empty string
	assert is_valid_ip("") == False
	# Test empty string, then test with "\x00"
	assert is_valid_ip("") == False
	# Test empty string, then test with "\x00"
	assert is_valid_ip("\x00") == False
	# Test with empty string and "\x00"
	assert is_valid_ip("\x00") == False
	# Test empty string, then test with "\x00"
	assert is_valid_ip("\x00") == False
	# Test with empty string and "\x00"
	assert is_valid_ip("\x00") == False
	# Test empty string, then test with "\x00"
	assert is_valid_ip("\x00") == False
	# Test with empty string and "\x00"

# Generated at 2022-06-12 13:47:26.712166
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1") == True, "valid ipv4"
    assert is_valid_ip("1.1.1.1") == True, "valid ipv4"
    assert is_valid_ip("localhost") == False, "invalid ipv4"
    assert is_valid_ip("256.1.1.1") == False, "invalid ipv4"
    assert is_valid_ip("::1") == True, "valid ipv6"
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334") == True, "valid ipv6"

# Generated at 2022-06-12 13:47:54.649077
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    import asyncio
    import sys
    import tornado
    import tornado.netutil
    import tornado.platform.asyncio
    asyncio.set_event_loop(None)
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    ev = asyncio.get_event_loop()
    print('TESTING OverrideResolver')
    resolver = tornado.netutil.Resolver()
    resolver.initialize()
    mapping = {
        'example.com': '127.0.1.1',
        ('login.example.com', 443): ('localhost', 1443),
        ('login.example.com', 443, socket.AF_INET6): ("::1", 1443)
    }
    override = tornado.netutil.OverrideResolver()
    override.initialize(resolver, mapping)

# Generated at 2022-06-12 13:47:57.913834
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve('localhost', 8080)
    print(result)



# Generated at 2022-06-12 13:48:04.644413
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(None, {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    assert resolver.resolve("example.com", 443) == "127.0.1.1"
    assert resolver.resolve("login.example.com", 443) == ("localhost", 1443)
    assert resolver.resolve("login.example.com", 443, socket.AF_INET6) == ("::1", 1443)

# Generated at 2022-06-12 13:48:14.746648
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    from concurrent.futures import Future
    from functools import partial
    from unittest.mock import patch
    from tornado.testing import AsyncTestCase
    from tornado.concurrent import Future as TornadoFuture
    from tornado.concurrent import run_on_executor
    import concurrent.futures
    import tornado.platform.asyncio
    loop = tornado.platform.asyncio.AsyncIOMainLoop()
    assert loop.is_running()
    def test(self):
        resolver = ExecutorResolver(concurrent.futures.ThreadPoolExecutor(5))
        assert isinstance(resolver, ExecutorResolver)
        assert isinstance(resolver, Resolver)
        assert isinstance(resolver, Configurable)
        assert resolver is not None
        assert resolver.executor is not None


# Generated at 2022-06-12 13:48:16.562942
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket('tmp')
    assert isinstance(sock, socket.socket)



# Generated at 2022-06-12 13:48:17.040163
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    pass


# Generated at 2022-06-12 13:48:20.022630
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    loop.run_sync(lambda: resolver.resolve("10.11.12.13",80))



# Generated at 2022-06-12 13:48:28.372031
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    global mapping
    global resolver
    global host
    global port
    global family
    mapping = {}
    resolver = {}
    host,port,family = 0,0,0
    if (host, port, family) in mapping:
        host, port = mapping[(host, port, family)]
    elif (host, port) in mapping:
        host, port = mapping[(host, port)]
    elif host in mapping:
        host = mapping[host]
    return resolver.resolve(host, port, family)

# Generated at 2022-06-12 13:48:36.972985
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import errno
    import os
    def test_accept_handler(sock, address):
        print("accept_handler " + str(address))
        sock.close()
    def test_remove_handler():
        print("remove_handler")
    #
    socket_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    socket_server.bind(("localhost", 5000))
    socket_server.listen(_DEFAULT_BACKLOG)
    remove_handler = add_accept_handler(socket_server, test_accept_handler)
    #
    socket_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


# Generated at 2022-06-12 13:48:42.945243
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket("")
    sock.close()
    os.remove("")

# Generated at 2022-06-12 13:49:11.046243
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():

    io_loop = IOLoop.current()
    executor = ThreadPoolExecutor(max_workers=4)
    close_executor = True
    print('executor:', executor)
    print('close_executor:', close_executor)
    print('io_loop:', io_loop)
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    if resolver.close_executor:
        resolver.executor.shutdown()
    resolver.executor = None
test_ExecutorResolver_initialize()


# Generated at 2022-06-12 13:49:13.255475
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888, "localhost")
    assert len(sockets) == 1
    assert sockets[0].getsockname()[1] == 8888

# Generated at 2022-06-12 13:49:17.679310
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    """
    TODO: Not sure to test asynchroneous methods
    """
    resolver = DefaultExecutorResolver()
    assert isinstance(resolver, DefaultExecutorResolver)
    addrinfo = resolver.resolve('127.0.0.1', 8888)
    assert isinstance(addrinfo, Awaitable)



# Generated at 2022-06-12 13:49:20.169064
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    _res = ExecutorResolver()
    _res.close()
    pass



# Generated at 2022-06-12 13:49:24.456523
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    host = 'www.google.com'
    port = 80
    family = socket.AF_UNSPEC
    defaultExecutorResolver = DefaultExecutorResolver()
    result = defaultExecutorResolver.resolve(host, port, family)



# Generated at 2022-06-12 13:49:32.497106
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # test for ExecutorResolver.resolve
    import unittest
    import socket
    import threading
    import concurrent.futures
    from typing import List, Tuple
    from .ioloop import IOLoop
    from . import netutil
    executor = concurrent.futures.ThreadPoolExecutor(4)
    resolver = netutil.ExecutorResolver(executor=executor)
    loop = IOLoop.current()
    host = 'localhost'
    port = 80
    family = socket.AF_UNSPEC
    loop.run_sync(lambda: resolver.resolve(host, port, family=family))
    loop.close()



# Generated at 2022-06-12 13:49:42.175664
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Open a socket to use.
    s = socket.socket()
    # Bind it to port 0, which will select a port for us.
    s.bind(("127.0.0.1", 0))
    # Get the port number.
    port = s.getsockname()[1]
    # Start listening
    s.listen(1)
    io_loop = IOLoop.current()

    # Define a callback
    def callback(connection, address):
        print("connection from " + str(address[0]) + " on port " + str(address[1]))
        connection.send(b"Hello World\n")
        connection.close()

    # Add the accept handler using our callback
    remove_handler = add_accept_handler(s, callback)

    # Connect to the socket.

# Generated at 2022-06-12 13:49:46.215020
# Unit test for function add_accept_handler
def test_add_accept_handler():
    port = 8888
    sock = bind_sockets(port)[0]
    res = []

    def accept_callback(connect, address):
        res.append(connect, address)

    add_accept_handler(sock,accept_callback)


# Generated at 2022-06-12 13:49:47.400471
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
	r = ExecutorResolver()
	r.close()

# Generated at 2022-06-12 13:49:56.361681
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    import tempfile

    # Ensure that the temporary file is deleted when the test
    # completes or fails.
    def cleanup(fn) -> None:
        try:
            os.remove(fn)
        except OSError:
            pass

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.connect(("localhost", 80))
    fd = sock.fileno()
    tempdir = tempfile.mkdtemp()
    fn = os.path.join(tempdir, "test_socket")
    try:
        cleanup(fn)
        sock = bind_unix_socket(fn)
    finally:
        cleanup(fn)
        cleanup(tempdir)



# Generated at 2022-06-12 13:50:33.210715
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("1.2.3.4")
    assert is_valid_ip("0.0.0.0")
    assert is_valid_ip("::")
    assert is_valid_ip("1::")
    assert is_valid_ip("1::2")
    assert is_valid_ip("fe80::1")
    assert is_valid_ip("fe80::1:2:3:4:5:6:7")
    assert not is_valid_ip("")
    assert not is_valid_ip("1.2.3")
    assert not is_valid_ip("1.2.3.4.5")
    assert not is_valid_ip("::1.2.3.4")

# Generated at 2022-06-12 13:50:34.852109
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    with pytest.raises(NotImplementedError):
        Resolver().resolve("", 0)



# Generated at 2022-06-12 13:50:38.660648
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((host, port))
    sock.listen(backlog)
    remove = add_accept_handler(sock, callback)
    remove()
    sock.close()



# Generated at 2022-06-12 13:50:47.629182
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Objeto a probar
    er = ExecutorResolver()
    # Valores de prueba para el método initialize
    i_1 = (concurrent.futures.ThreadPoolExecutor(max_workers=1), True)
    # Prueba para los valores de prueba para el método initialize
    er.initialize(*i_1)
    assert er.executor == i_1[0]
    assert er.close_executor == i_1[1]
    assert er.io_loop == IOLoop.current()

# Generated at 2022-06-12 13:50:52.303536
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    init_args = {
        "executor": "None",
        "close_executor": "True"
    }
    er = ExecutorResolver()
    er.initialize(**init_args)
    assert er.executor == dummy_executor
    assert er.close_executor == False

# Generated at 2022-06-12 13:50:59.786342
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # Create a IP socket object
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("", 0))
    host, port = s.getsockname()
    family = socket.AF_INET
    #this is the version for python 3
    resolver = ExecutorResolver()
    #if the argument is incorrect
    #assert resolver.resolve(host, port, family) is None
    #if the arguments are correct
    assert resolver.resolve(host, port, family) is not None
    #if there is no connection available
    assert resolver.resolve(host, 545454545, family) is None
    #if there is only one of the 2 arguments correct
    assert resolver.resolve(host, 545454545, family) is None


# Generated at 2022-06-12 13:51:04.469938
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():

    
    
    resolver = ExecutorResolver()
    resolver.initialize()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert not resolver.close_executor


# Generated at 2022-06-12 13:51:08.440977
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Verify that the method close has been properly implemented
    r = ExecutorResolver()
    r.close()
    assert r.io_loop == IOLoop.current()
    assert r.executor == dummy_executor
    assert r.close_executor == False



# Generated at 2022-06-12 13:51:15.845747
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    assert bind_unix_socket.__doc__ is not None


if os.name != "nt":
    import fcntl

    def set_close_exec(fd: int) -> None:
        flags = fcntl.fcntl(fd, fcntl.F_GETFD)
        fcntl.fcntl(fd, fcntl.F_SETFD, flags | fcntl.FD_CLOEXEC)


    def _set_nonblocking(fd: int) -> None:
        flags = fcntl.fcntl(fd, fcntl.F_GETFL, 0)
        fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

# Generated at 2022-06-12 13:51:19.401249
# Unit test for function is_valid_ip
def test_is_valid_ip():
    inputs = ["127.0.0.1", "0.0.0.0", "255.255.255.255", "fe80::11:22ff:fe33:4455", "::1", "1::2"]
    outputs = [True, True, True, True, True, True]
    for i in range(len(inputs)):
        assert(is_valid_ip(inputs[i]) == outputs[i])
test_is_valid_ip()



# Generated at 2022-06-12 13:52:38.899918
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import unittest
    from tornado import gen
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, bind_unix_socket, gen_test

    import socket
    import ssl

    def accept_loop(sock, callback):
        while True:
            connection, address = sock.accept()
            try:
                callback(connection, address)
            except Exception as e:
                print(e)
            finally:
                connection.close()

    class TestAddAcceptHandler(AsyncTestCase):
        def test_add_accept_handler(self):
            sock, port = bind_unix_socket('', 'test_add_accept_handler')
            self.addCleanup(os.remove, sock.getsockname())

# Generated at 2022-06-12 13:52:41.322398
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = None
    close_executer = True
    obj = Resolver()
    obj.initialize(executor, close_executer)
    assert obj.executor == dummy_executor
    assert obj.close_executor == False


# Generated at 2022-06-12 13:52:46.692613
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    class Resolver(object):

        def resolve(
            self, host: str, port: int, family: socket.AddressFamily = socket.AF_UNSPEC
        ) -> Awaitable[List[Tuple[int, Any]]]:
            return self.resolver.resolve(host, port, family)
    # Create a OverrideResolver
    a = OverrideResolver()
    assert a is not None



# Generated at 2022-06-12 13:52:58.111080
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.concurrent import Future
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    def display_result(res):
        print('result: \n{}'.format(res))
    def display_error(err):
        print('error: \n{}'.format(err))
    def display_done(fut):
        print('done: \n{}'.format(str(fut.done())))
    class Resolver1(Resolver):
        def resolve(self, host, port, family):
            fut = Future()
            fut.set_result([(0, ('192.168.0.1', 80, 0, 0))])
            return fut

# Generated at 2022-06-12 13:53:10.600713
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import concurrent.futures
    import pandas as pd
    from pandas._testing import assert_frame_equal
    import logging
    import os
    import pytest
    import sys
    import timeit
    from io import StringIO
    from datetime import datetime

    def test_ExecutorResolver_close_1():
        logging.info("Start test_ExecutorResolver_close")
        cwd = os.getcwd()
        os.chdir("tests")

# Generated at 2022-06-12 13:53:19.473690
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    def setUpModule():
        import tornado.platform.asyncio
        if hasattr(tornado.platform.asyncio, 'AsyncIOLoop'):
            warn_deprecated(
                "AsyncIOLoop is deprecated, use asyncio and the appropriate "
                "IOLoop implementation instead")
        tornado.platform.asyncio.AsyncIOMainLoop().install()

    def tearDownModule():
        from tornado.platform.asyncio import AsyncIOLoop

        if hasattr(AsyncIOLoop, "_instance"):
            AsyncIOLoop._instance.close(all_fds=True)

    def test_initialize():
        resolver = ExecutorResolver()
        self.assertIsNotNone(resolver.executor)
        self.assertTrue(resolver.close_executor)

# Generated at 2022-06-12 13:53:28.494892
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # This is not really a unit test. It is here to fix the docstring.
    #
    # Should the docstring of add_accept_handler change, it can be updated
    # with the following code:
    #
    # from tornado.netutil import bind_sockets, add_accept_handler
    #
    # def main() -> str:
    #     import doctest
    #
    #     return doctest.testmod().failed
    #
    # if __name__ == '__main__':
    #     import sys
    #
    #     sys.exit(main())
    sockets = bind_sockets(0)
    for sock in sockets:
        remove = add_accept_handler(sock, lambda sock, addr: None)



# Generated at 2022-06-12 13:53:30.409645
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    assert len(sockets) > 0
    for sock in sockets:
        sock.close()

# Generated at 2022-06-12 13:53:35.698901
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    assert not hasattr(resolver, 'executor')
    resolver.resolve('b.com', 80)
    assert hasattr(resolver, 'executor')
    resolver.close()
    assert hasattr(resolver, 'executor') and resolver.executor == None



# Generated at 2022-06-12 13:53:37.373712
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    """Test for method close of ExecutorResolver"""
    er = ExecutorResolver()
    er.close()


# Generated at 2022-06-12 13:54:48.018567
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    context = ssl_options_to_context(dict(
        certfile="cafile",
        keyfile="keyfile",
        cert_reqs=ssl.CERT_REQUIRED,
        ssl_version=ssl.PROTOCOL_SSLv3,
        ca_certs="cafile2",
        ciphers="ALL",
    ))
    assert isinstance(context, ssl.SSLContext)
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.protocol == ssl.PROTOCOL_SSLv3
    assert context.check_hostname
    assert context.verify_flags == ssl.VERIFY_DEFAULT
    assert context.options & ssl.OP_NO_COMPRESSION == ssl.OP_NO_COMPRESSION

# Generated at 2022-06-12 13:54:49.679338
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = resolver.resolve("www.google.com", 80)
    assert result



# Generated at 2022-06-12 13:55:00.975047
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado import platform, gen
    asyncio.set_event_loop(asyncio.new_event_loop())
    AsyncIOMainLoop().install()  
    resolver = DefaultExecutorResolver()
    host = 'localhost'
    port = 80
    family = socket.AF_INET
    rst = gen.coroutine(resolver.resolve)(host, port, family)
    assert await rst
    host = 'www.google.com'
    port = 80
    family = socket.AF_UNSPEC
    rst = gen.coroutine(resolver.resolve)(host, port, family)
    assert await rst
    host = ''
    port = 80
    family = socket.AF_UNSPEC

# Generated at 2022-06-12 13:55:09.802564
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    errmsg = 'initialize({}, {})'.format(executor, close_executor)
    res = ExecutorResolver()
    assert(isinstance(res, Resolver))
    assert(isinstance(res, DefaultExecutorResolver))
    assert(isinstance(res, ExecutorResolver))
    res.initialize(executor, close_executor)
    assert(res.executor == executor)
    assert(res.close_executor == close_executor)

# Generated at 2022-06-12 13:55:11.125233
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    '''
    ExecutorResolver().close()
    '''


# Generated at 2022-06-12 13:55:15.037468
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(port=0, address='127.0.0.1')
    print(sockets)
    sockaddr = sockets[0].getsockname()
    assert sockaddr[0] == '127.0.0.1'
    assert sockaddr[1] != 0



# Generated at 2022-06-12 13:55:20.716468
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    _executor = None
    _close_executor = True
    _io_loop = IOLoop.current()
    if _executor is not None:
        self.executor = _executor
        self.close_executor = _close_executor
    else:
        self.executor = dummy_executor
        self.close_executor = False
    if self.close_executor:
        self.executor.shutdown()
    self.executor = None  # type: ignore



# Generated at 2022-06-12 13:55:27.600889
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # test1
    resolver = ExecutorResolver()
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False

    # test2
    executor = concurrent.futures.ThreadPoolExecutor()
    resolver = ExecutorResolver(executor, False)
    assert resolver.io_loop == IOLoop.current()
    assert resolver.executor == executor
    assert resolver.close_executor == False



# Generated at 2022-06-12 13:55:33.201367
# Unit test for function bind_sockets
def test_bind_sockets():
    socket_tuple = bind_sockets(8888,address='127.0.0.1', family=socket.AF_INET, backlog=128)
    print(type(socket_tuple[0]))
    print(socket_tuple[0])
    socket_tuple[0].close()



# Generated at 2022-06-12 13:55:42.466679
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import types
    import socket
    import os
    import tornado.ioloop
    import tornado.netutil

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    port = tornado.netutil.bind_sockets(None, '127.0.0.1')[0].getsockname()[1]
    s.connect(('127.0.0.1', port))
    ioloop = tornado.ioloop.IOLoop.current()
    remove_handler = tornado.netutil.add_accept_handler(s, lambda c, a: c.close())
    assert isinstance(remove_handler, types.FunctionType)
    ioloop.add_timeout(ioloop.time() + 0.01, remove_handler)
    ioloop.start()
    assert not os