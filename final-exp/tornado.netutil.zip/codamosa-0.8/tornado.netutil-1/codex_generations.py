

# Generated at 2022-06-12 13:46:56.336571
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResolver(executor=None,close_executor=True)
    resolver.close()


# Generated at 2022-06-12 13:47:00.981508
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver('resolver', 'mapping')
    host = 'host'
    port = 80
    family = socket.AF_INET

    # calling this method should not raise exception
    resolver.resolve(host, port, family)
    resolver.close()

# Generated at 2022-06-12 13:47:12.801668
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # executor = dummy_executor
    # close_executor = False
    # resolver = ExecutorResolver(executor, close_executor)
    resolver = ExecutorResolver()
    assert resolver.executor is dummy_executor
    assert resolver.close_executor is False
    resolver.close()
    assert resolver.executor is None
    assert resolver.close_executor is False

if _has_futures:
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    class ThreadedResolver(Resolver):
        """Resolver implementation using a thread pool.

        .. deprecated:: 5.0
           The default `Resolver` now uses `.IOLoop.run_in_executor`; use that instead
           of this class.
        """

       

# Generated at 2022-06-12 13:47:21.093601
# Unit test for function bind_sockets
def test_bind_sockets():
    # 1. Test to bind all interfaces
    # 2. Test to bind with an address
    s = bind_sockets(8888)[0]
    host = s.getsockname()[0]
    assert host == "0.0.0.0" or host == "::"
    s = bind_sockets(8888, address="localhost")[0]
    host = s.getsockname()[0]
    assert host == "127.0.0.1"
    s = bind_sockets(8888, address="127.0.0.1")[0]
    host = s.getsockname()[0]
    assert host == "127.0.0.1"



# Generated at 2022-06-12 13:47:28.877389
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # OverrideResolver.resolve
    # This method is the primary interface you should use
    # It returns a Future whose result is a list of (family, address) pairs
    # If a callback is passed, it will be run with the result as an argument when it is complete

    # Check for normal case, if we pass host, port and family as parameters to resolve method
    # it returns a Future whose result is a list of (family, address) pairs.
    # Also check for callback call.
    resolver = OverrideResolver()
    host = 'www.google.com'
    port = 80
    family = socket.AF_PACKET
    # mock socket.getaddrinfo for test case

# Generated at 2022-06-12 13:47:39.469844
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    host = '127.0.0.1'
    port = 1
    family = socket.AF_INET
    #empty mapping
    mapping = {}
    resolver = DefaultExecutorResolver()
    override_resolver = OverrideResolver(resolver, mapping)
    result = override_resolver.resolve(host, port, family)
    assert result == resolver.resolve(host, port, family)
    #one mapping
    mapping = {'example.com':'127.0.1.1', 'dummy.com':'127.1.1.1'}
    resolver = DefaultExecutorResolver()
    override_resolver = OverrideResolver(resolver, mapping)
    result = override_resolver.resolve(host, port, family)

# Generated at 2022-06-12 13:47:41.961752
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    assert 0
if __name__ == "__main__":
    test_OverrideResolver_resolve()



# Generated at 2022-06-12 13:47:54.737972
# Unit test for function bind_sockets
def test_bind_sockets():
    import random
    import tempfile
    import unittest
    from tornado.platform.auto import set_close_exec

    try:
        import ssl  # type: ignore
    except ImportError:
        ssl = None

    class BindSocketsTest(unittest.TestCase):
        def setUp(self):
            # The test fixture must take care not to bind the same
            # port by accident.
            self.port = random.randint(1025, 65535)

        def test_tcp_sockets(self):
            sockets = bind_sockets(self.port)
            self.assertEqual(1, len(sockets))
            # make sure it's really listening
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)

# Generated at 2022-06-12 13:47:59.360233
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # mock resolver
    resolver = Resolver()

    # mock mapping
    mapping = {
        # Hostname to host or ip
        "example.com": "127.0.1.1",
        # Host+port to host+port
        ("login.example.com", 443): ("localhost", 1443),
        # Host+port+address family to host+port
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }

    # create an instance of OverrideResolver
    override_resolver = OverrideResolver(resolver, mapping)

    # define host and port
    host = "login.example.com"
    port = 443
    family = socket.AF_INET6

    # call method resolve of instance override_resolver
    result = override_res

# Generated at 2022-06-12 13:48:12.242158
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import time
    from tornado.concurrent import Future
    from tornado.platform.asyncio import AsyncIOMainLoop

    print("ExecutorResolver.resolve")
    def handle_add(future: Future) -> None:
        print(future.result())

    AsyncIOMainLoop().install()
    # init resolver
    executor = concurrent.futures.ThreadPoolExecutor(4)
    close_executor = False
    resolver = ExecutorResolver(executor, close_executor)

    host = "localhost"
    port = 80
    family = socket.AF_UNSPEC
    future = resolver.resolve(host, port, family)
    future.add_done_callback(handle_add)
    time.sleep(2)



# Generated at 2022-06-12 13:48:53.326609
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    #  def resolve(self, host, port, family=socket.AF_UNSPEC):
    # Tests if host and port are of correct types
    pass



# Generated at 2022-06-12 13:48:57.702572
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import asyncio
    async def test():
        a = ExecutorResolver()
        await a.close()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()



# Generated at 2022-06-12 13:49:06.673411
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import tornado.testing
    import socket
    sock, port = tornado.testing.bind_unused_port()
    sock.listen(1)
    called = [False]

    def handle_connection(conn, address):
        called[0] = True
        conn.close()
    remove_handler = add_accept_handler(sock, handle_connection)
    io_loop = IOLoop.current()

# Generated at 2022-06-12 13:49:14.431027
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    def _run_resolve(future, host, port, family):
        res = future.result()
        _run_resolve.result = res

    host = '127.0.0.1'
    port = 80
    family = socket.AF_INET
    re = Resolver()
    f = re.resolve(host, port, family)
    loop = IOLoop.current()
    loop.add_future(f, _run_resolve)
    loop.start()
    assert _run_resolve.result == [(2, ('127.0.0.1', 80))]
    re.close()



# Generated at 2022-06-12 13:49:20.740019
# Unit test for function add_accept_handler
def test_add_accept_handler():
    io_loop = IOLoop.current()
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    callback = lambda connection, address: print('connected with ', address)
    added_handler = add_accept_handler(sock, callback) 
    added_handler()


# Generated at 2022-06-12 13:49:25.502718
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    _resolver = OverrideResolver(resolver=None, mapping=None)
    host = "login.example.com"
    port = 443
    family = socket.AF_INET6
    assert (_resolver.resolve(host, port, family) == None)


# Generated at 2022-06-12 13:49:32.339241
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # create a new Resolver object and determine whether it is a instance of Resolver
    res = Resolver()
    assert isinstance(res, Resolver)
    # create a new ip address
    ip = '127.0.0.1'
    # create a callback function
    def callback_func(ip):
        print(ip)
    # call resolve method to resolve ip
    res.resolve(ip,0,family= socket.AF_INET)
    # check whether the result is a valid ip
    assert is_valid_ip(ip) == True


# Generated at 2022-06-12 13:49:35.591567
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def accept_handler(connection, address):
        pass
    sock = socket.socket()
    add_accept_handler(sock, accept_handler)

# Generated at 2022-06-12 13:49:38.375353
# Unit test for function add_accept_handler
def test_add_accept_handler():
    connect = None
    def callbackConnection(connection: socket.socket, address: str):
        connect = connection
    
# bind_unix_socket is mentioned only in add_accept_handler docs

# Generated at 2022-06-12 13:49:41.644380
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import concurrent.futures
    e = ExecutorResolver()
    e.initialize(executor=concurrent.futures.ThreadPoolExecutor(max_workers=1), close_executor=True)
    e.close()
    assert e.executor is None



# Generated at 2022-06-12 13:50:36.706392
# Unit test for function bind_sockets
def test_bind_sockets():
    s = bind_sockets(8998)
    print(s)
    # assert
    assert s is not None
# test_bind_sockets()

# The test timeouts below are intended to prevent hung tests due to
# bugs in this module.  Our test suite runs them all on a single
# thread, so they cannot run forever without hanging the whole suite.
# Timeouts are measured in seconds.

# HTTPConnectionTest uses the global event loop, so this timeout is
# effectively a limit on the time that test can run.
_GLOBAL_DEFAULT_TIMEOUT = 30

# On windows, we can trigger an ssl handshake timeout simply by
# stopping the openssl subprocess.  There doesn't seem to be a good
# way to interrupt an ssl handshake from python, so set a shorter
# timeout here.

# Generated at 2022-06-12 13:50:38.360794
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver = ExecutorResolver()
    executor_resolver.close()



# Generated at 2022-06-12 13:50:40.167740
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(1234)
    assert sockets[0]


# Generated at 2022-06-12 13:50:45.678569
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    future = asyncio.Future()
    def callback(arg1, arg2):
        future.set_result(None)
        return arg1, arg2

    assert(Resolver().resolve("192.168.0.1", 80, socket.AF_INET) == future)


# Generated at 2022-06-12 13:50:55.557041
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado.testing import AsyncTestCase, gen_test
    import asyncio
    import time
    #import logging
    #log_level = logging.DEBUG
    #logging.basicConfig(level=log_level, format='%(asctime)s [%(levelname)s] %(name)s: %(message)s')
    logger = logging.getLogger(__name__)

    class DefaultExecutorResolverTestCase(AsyncTestCase):
        def __init__(self, *args, **kwargs):
            self.resolver = DefaultExecutorResolver()
            super().__init__(*args, **kwargs)

        @gen_test(timeout=15.0)
        async def test_resolve_hostname(self):
            print('test_DefaultExecutorResolver_resolve')
            loop

# Generated at 2022-06-12 13:50:57.719741
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888, '127.0.0.1', socket.AF_INET)
    assert len(sockets) == 1


# Generated at 2022-06-12 13:51:02.751460
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    async def f():
        resolver = DefaultExecutorResolver()
        results = await resolver.resolve('google.com', 80)
        assert results == [(2, ('216.58.198.174', 80))]
    IOLoop.current().run_sync(f)


# Generated at 2022-06-12 13:51:07.486190
# Unit test for function add_accept_handler
def test_add_accept_handler():
    bind_sockets = bind_sockets(8888)
    add_accept_handler(bind_sockets[0], (lambda x, y: None))


# Global (process-wide) socket object used in `~.Resolver.thread_pool.shutdown`.
_global_sock = None



# Generated at 2022-06-12 13:51:11.380380
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    async def test():
        # to be tested
        resolver = DefaultExecutorResolver()
        # test
        result = await resolver.resolve("localhost", 443)
        # verify
        print("result = ", result)
    IOLoop.current().run_sync(test)


# Generated at 2022-06-12 13:51:22.662326
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import logging
    import time
    import os
    import socket
    import socket
    import ssl
    import errno
    import struct
    import errno
    import logging
    import socket
    import ssl
    import weakref
    import collections
    import functools
    import traceback
    import os
    import selectors
    import subprocess
    import os
    import platform
    import functools
    import typing
    import weakref
    import os
    import concurrent.futures
    import errno
    import os
    import socket
    import ssl
    import stat
    import typing
    import typing
    import functools
    import typing
    import concurrent.futures
    import typing
    import typing
    import typing
    import platform
    import io
    import typing
    import typing

# Generated at 2022-06-12 13:52:06.136427
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import sys
    import time
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import BaseAsyncIOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    try:  # Python 3.8+
        import asyncio
    except ImportError:
        import trollius as asyncio
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    r = ExecutorResolver()
    r.initialize(executor=None, close_executor=True)
    host = 'www.google.com'
    port = 80
    family = socket.AF_UNSPEC

# Generated at 2022-06-12 13:52:10.967660
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    host = "localhost"
    port = 8080
    address_family = socket.AF_UNSPEC
    expected_return_value = [(socket.AF_INET, ("127.0.0.1", 8080))]
    resolver = ExecutorResolver()
    return_value = await resolver.resolve(host, port, address_family)
    assert (
        return_value == expected_return_value
    ), "Expected return value of %s, but got %s" % (
        expected_return_value,
        return_value,
    )



# Generated at 2022-06-12 13:52:14.558914
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import concurrent.futures
    t = ExecutorResolver(concurrent.futures.ThreadPoolExecutor(thread_name_prefix="a"))
    t.close()
    t.close_executor == False
    t.executor == None



# Generated at 2022-06-12 13:52:17.484932
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    for sock in sockets:
        print(sock.getsockname())

# test_bind_sockets()



# Generated at 2022-06-12 13:52:20.650649
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = None
    resolover = ExecutorResolver(executor)
    # Assert None is returned
    executor is None
    # Assert resolover.executor is dummy_executor
    assert resolover.executor is dummy_executor
    # Assert resolover.close_executor is False



# Generated at 2022-06-12 13:52:22.256458
# Unit test for function add_accept_handler
def test_add_accept_handler():
    bind_port = None
    def accept_handler(fd, events):
        pass
    sock = bind_sockets(0)
    add_accept_handler(sock, accept_handler)


# Generated at 2022-06-12 13:52:23.790081
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    """
    Test for method initialize of class ExecutorResolver
    """
    print("Nothing to do")


# Generated at 2022-06-12 13:52:26.936703
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    executor = ExecutorResolver()
    executor.initialize(executor)
    assert executor.executor == executor
    assert executor.close_executor == True


# Generated at 2022-06-12 13:52:30.365206
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ssl_wrap_socket(socket, ssl.PROTOCOL_TLSv1)
    print('Test Success')


# Generated at 2022-06-12 13:52:38.067904
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Test case 1
    resolver = socket.socket
    mapping = {0: 1}
    OverrideResolver.resolve(resolver, mapping)
    # Test case 2
    resolver = socket.socket
    mapping = {0: 1}
    OverrideResolver.resolve(resolver, mapping, 0)
    # Test case 3
    resolver = socket.socket
    mapping = {0: 1}
    OverrideResolver.resolve(resolver, mapping, 0, 0)



# Generated at 2022-06-12 13:53:11.865674
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    r = ExecutorResolver()
    r.resolve("www.baidu.com",80)
    r.close()



# Generated at 2022-06-12 13:53:13.287987
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    print("START STOP")
    print("STOP STOP")


# Generated at 2022-06-12 13:53:16.609747
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_opts = dict(ssl_version=ssl.PROTOCOL_SSLv23, certfile='', keyfile='')
    assert isinstance(ssl_options_to_context(ssl_opts), ssl.SSLContext)
# EOF


# Generated at 2022-06-12 13:53:21.640598
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    assert isinstance(ssl_options_to_context({}), ssl.SSLContext)
    assert isinstance(
        ssl_options_to_context({"certfile": __file__}), ssl.SSLContext
    )
    assert isinstance(ssl_options_to_context(ssl.create_default_context()), ssl.SSLContext)



# Generated at 2022-06-12 13:53:30.783738
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import tornado.testing
    import tornado.platform.asyncio
    from tornado.test.util import unittest

    def setUpModule():
        tornado.platform.asyncio.AsyncIOMainLoop().install()

    class DefaultExecutorResolverTest(unittest.AsyncTestCase):
        def test_DefaultExecutorResolver(self):
            loop = tornado.ioloop.IOLoop.current()
            resolver = DefaultExecutorResolver()
            f = resolver.resolve('localhost', 80)
            def run():
                f.add_done_callback(self.stop)
            loop.add_callback(run)
            self.wait()
            result = f.result()
            
            self.assertTrue(result, [])
    
    tornado.testing.main()


# Generated at 2022-06-12 13:53:34.016761
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    host = 'localhost'
    port = 80
    family = socket.AF_INET
    # call the method
    res = Resolver().resolve(host, port, family)
    print("res: %s" % res)


# Generated at 2022-06-12 13:53:43.668377
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    assert ssl_wrap_socket.__doc__ is not None
    # Simple no-op test
    socket = socket.fromfd(0, socket.AF_INET, socket.SOCK_STREAM)
    ssl_socket = ssl_wrap_socket(socket, {})
    assert ssl_socket == socket

async def _test_ssl_wrap_socket():
    ssl_options = {
        "certfile": os.path.join(os.path.dirname(__file__), "test/test.crt"),
        "keyfile": os.path.join(os.path.dirname(__file__), "test/test.key"),
        "ssl_version": ssl.PROTOCOL_SSLv23
    }


# Generated at 2022-06-12 13:53:51.885637
# Unit test for function add_accept_handler
def test_add_accept_handler():
    client_stop_flag = [False]
    server_stop_flag = [False]
    send_bytes = b"Hello World!"
    server_running = [False]
    def send_to_server(sock : socket.socket) -> None:
        sock.send(send_bytes)
    def server(addr : str):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
        s.bind(addr)
        s.listen()
        server_running[0] = True
        while not server_stop_flag[0]:
            client_s, address = s.accept()
            client_s.setblocking(0)
            IOLoop.current().add

# Generated at 2022-06-12 13:53:55.109491
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    '''Test initialize() of class ExecutorResolver'''
    resolver = ExecutorResolver(None, True)
    resolver.initialize(dummy_executor, False)
    resolver.close()



# Generated at 2022-06-12 13:54:04.792135
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import concurrent.futures
    class MyExecutorResolver(ExecutorResolver):
        def initialize(self, executor: Optional[concurrent.futures.Executor] = None, close_executor: bool = True) -> None:
            self.io_loop = IOLoop.current()
            if executor is not None:
                self.executor = executor
                self.close_executor = close_executor
            else:
                self.executor = dummy_executor
                self.close_executor = False
    my_executor_resolver = MyExecutorResolver()
    my_executor_resolver.close()
    print("pass unit test for method close in MyExecutorResolver.")
test_ExecutorResolver_close()



# Generated at 2022-06-12 13:54:54.171515
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.netutil import BlockingResolver, ThreadedResolver, CaresResolver
    # Test for method resolve of class Resolver
    #self.assertEqual(False, True)
    # Test for method close of class Resolver
    #self.assertEqual(False, True)
    BlockingResolver().resolve('baidu.com',80) # 1
    ThreadedResolver().resolve('baidu.com',80) # 2
    CaresResolver().resolve('baidu.com',80) # 3


# Generated at 2022-06-12 13:55:05.142341
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import os
    from uuid import uuid4 as uuid
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.tcpserver import TCPServer
    from tornado.iostream import IOStream

    class TestTCPServer(TCPServer):
        def handle_stream(self, stream: IOStream, address: Tuple[str, int]):
            stream.read_until(b"\n", self.handle_line)

        def handle_line(self, line: bytes):
            self.received.append(line.decode("utf-8"))
            self.stream.write((line + b"\n").decode("utf-8").encode())


# Generated at 2022-06-12 13:55:16.224302
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor:concurrent.futures.Executor = None
    close_executor:bool = False
    resolver = ExecutorResolver()
    resolver.initialize(executor,close_executor)
    resolver.close()

if hasattr(concurrent.futures, "ThreadPoolExecutor"):
    ThreadPoolExecutor = concurrent.futures.ThreadPoolExecutor
    dummy_executor = concurrent.futures.ThreadPoolExecutor()


# Generated at 2022-06-12 13:55:20.778903
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    async def async_test():
        result = await DefaultExecutorResolver().resolve(
            "localhost", 80, socket.AF_INET
        )
        assert result == [(socket.AF_INET, ('127.0.0.1', 80))]
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(async_test())



# Generated at 2022-06-12 13:55:22.445266
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    assert isinstance(ssl_options_to_context({}), ssl.SSLContext)



# Generated at 2022-06-12 13:55:33.554605
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado.web import RequestHandler
    from tornado.ioloop import IOLoop
    from tornado.httpserver import HTTPServer
    from tornado.platform.asyncio import AsyncIOMainLoop

    resolver = Resolver.configure("tornado.netutil.DefaultExecutorResolver")
    override = {("example.com", 80): ("localhost", 8080)}
    resolver = OverrideResolver(resolver, override)
    Resolver.configure(resolver)

    class MainHandler(RequestHandler):
        def get(self):
            output = "ok"
            self.write(output)

    app = tornado.web.Application([(r"/", MainHandler),])
    server = HTTPServer(app)
    server.listen(8080)

    AsyncIOMainLoop().install()

# Generated at 2022-06-12 13:55:35.913213
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    r = Resolver()
    assert isinstance(r.resolve("baidu.com",80), _Future)


# Generated at 2022-06-12 13:55:44.493224
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.bind(("127.0.0.1", 0))
    sock.listen(5)
    port = sock.getsockname()[1]

    def accept_handler(connection, address):
        pass

    close_callback = add_accept_handler(sock, accept_handler)
