

# Generated at 2022-06-12 13:46:22.722690
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    results = asyncio.run(resolver.resolve('www.baidu.com', 80))
    print(results)
    assert results
    # print(results[0][0], results[0][1][0], results[0][1][1])
    # assert results[0][0] == socket.AF_INET
    # assert results[0][1][0] == '119.75.217.109'
    # assert results[0][1][1] == 80

    results = asyncio.run(resolver.resolve('www.baidu.com', 80, socket.AF_INET6))
    print(results)
    assert results
    # print(results[0][0], results[0][1][0], results[0][1][1])
    # assert

# Generated at 2022-06-12 13:46:27.111816
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    e=ExecutorResolver()
    e.initialize()


# Generated at 2022-06-12 13:46:35.767098
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    class Resolver(netutil.Resolver):
        async def resolve(self,host,port,family=socket.AF_UNSPEC):
            addr=socket.getaddrinfo(host,port,family)

# Generated at 2022-06-12 13:46:36.932283
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = OverrideResolver()
    resolver.close()

# Generated at 2022-06-12 13:46:49.089803
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    import asyncio
    from .resolver import AsyncResolver
    from .resolver import OverrideResolver
    from .resolver import IOLoopResolver
    from .resolver import DefaultExecutorResolver
    # Case 1
    obj = OverrideResolver(resolver=DefaultExecutorResolver())
    async def async_func():
        await obj.resolve('127.0.0.1', 8080)
    asyncio.run(async_func())
    # Case 2
    obj = OverrideResolver(resolver=DefaultExecutorResolver())
    async def async_func():
        await obj.resolve('127.0.0.1', 8080)
    asyncio.run(async_func())
    # Case 3
    obj = OverrideResolver(resolver=DefaultExecutorResolver())
   

# Generated at 2022-06-12 13:46:53.493425
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    from tornado.ioloop import IOLoop
    from tornado import concurrent

    es = concurrent.futures.ThreadPoolExecutor(4)
    esr = ExecutorResolver(es, True)
    esr.close()
    assert esr.executor is None
    assert es.is_shutdown() == True



# Generated at 2022-06-12 13:46:59.248598
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncunittest
    from datetime import datetime
    from datetime import timedelta

    # Given
    import urllib3
    import urllib3.util.timeout

    # When
    resolver = Resolver()
    # Then
    assert isinstance(resolver.resolve("www.google.com", 80), asyncio.Future)


# Generated at 2022-06-12 13:47:05.561184
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    host="www.baidu.com"
    port=80
    family=socket.AF_INET
    mapping={"www.baidu.com":"127.0.0.1"}
    print(OverrideResolver.resolve(mapping,host,port,family))
# this function is used to test the functionality of tornado.netutil.OverrideResolver
if __name__=="__main__":
    test_OverrideResolver_resolve()

# Generated at 2022-06-12 13:47:17.074696
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    import time
    import sys
    import os
    import threading
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    if not os.path.exists('file.txt'):
        f = open('file.txt','w')
        f.write('listen 8080\nlisten 80')
        f.close()
    def f_test(_host, _port, _family):
        return _resolve_addr(_host, _port, _family)
    resolver = DefaultExecutorResolver()
    assert isinstance(resolver, DefaultExecutorResolver)
    io_loop = IOLoop.current()
    t = threading.Thread(target=io_loop.start)


# Generated at 2022-06-12 13:47:26.496812
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    # Test the _get_resolver() function and OverrideResolver class
    # because they both use the __init__ method.
    # Since OverrideResolver class is an abstract class, we cannot create an
    # instance of it. The only way to test it is by instantiating one of its
    # subclasses, i.e. ThreadedResolver class.
    import concurrent.futures
    some_threadpool = concurrent.futures.ThreadPoolExecutor(1)
    some_resolver = ThreadedResolver()
    some_resolver.initialize(executor=some_threadpool, close_executor=False)

# Generated at 2022-06-12 13:47:59.399005
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    sock.listen(1)
    port = sock.getsockname()[1]
    result = [None]  # type: List[Any]
    errors = [False]  # type: List[bool]

    def callback(connection: socket.socket, address: Any) -> None:
        # A new connection has been made.  Announce it to the IOLoop
        # thread as well to make sure the IOLoop thread hasn't gone
        # away yet.
        result[0] = connection

    def finish() -> None:
        io_loop.remove_timeout(finish_timeout)
        remove_handler()

# Generated at 2022-06-12 13:48:04.823707
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    callback = lambda x: print(x)
    add_accept_handler(sock, callback)



# Generated at 2022-06-12 13:48:14.778234
# Unit test for function bind_sockets
def test_bind_sockets():
    # Bind on the same port for both IPv4 and IPv6
    sockets = bind_sockets(8888)
    host, port = sockets[0].getsockname()[:2]
    assert host == "0.0.0.0"
    assert port == 8888
    host, port = sockets[1].getsockname()[:2]
    assert host == "::"
    assert port == 8888
    for s in sockets:
        s.close()
    # Call again to try automatic port allocation
    sockets = bind_sockets(None)
    host, port = sockets[0].getsockname()[:2]
    assert host == "0.0.0.0"
    assert port != 0
    host, port = sockets[1].getsockname()[:2]
    assert host == "::"

# Generated at 2022-06-12 13:48:16.593622
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    os.close(sockets[0])
    pass


# Generated at 2022-06-12 13:48:26.170487
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(0, '')
    assert len(sockets) == len(socket.has_ipv6)
    for sock in sockets:
        sock.close()
    sockets = bind_sockets(0, '', reuse_port=True)
    assert len(sockets) == len(socket.has_ipv6)
    for sock in sockets:
        sock.close()
    try:
        save_has_ipv6 = socket.has_ipv6
        # Simulate that ipv6 is not supported
        socket.has_ipv6 = False
        sockets = bind_sockets(0, '')
        assert len(sockets) == 1
    finally:
        socket.has_ipv6 = save_has_ipv6
    sockets[0].close()



# Generated at 2022-06-12 13:48:27.469820
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = IOLoop.current().run_sync(lambda: resolver.resolve("localhost", 8080))
    assert result is not None


# Generated at 2022-06-12 13:48:31.627944
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    """
    Method to test the resolve method of OverrideResolver class
    """
    resolver=Resolver()
    mapping={
            "example.com": "127.0.1.1",
            ("login.example.com", 443): ("localhost", 1443),
            ("login.example.com", 443, socket.AF_INET6): ("::1", 1443)
           }
    test=OverrideResolver(resolver, mapping)
    test.resolve("example.com",80)
    test.resolve("login.example.com", 443, socket.AF_INET6)
    test.resolve("login.example.com", 443)


# Generated at 2022-06-12 13:48:36.147289
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    r = ExecutorResolver(executor=dummy_executor, close_executor=True)
    r.executor.shutdown = MagicMock()
    r.close()
    r.executor.shutdown.assert_called_once()
    assert r.executor is None



# Generated at 2022-06-12 13:48:47.252402
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    
    host = "localhost"
    port = 6666
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((host, port))
        s.listen(5)
        def server_accept(s, addr):
            with s:
                print(f"new client: addr: {addr}")
                data = s.recv(1024)
                print(f"receive data: {data}")
                s.sendall(data)
        server_accept_handler = add_accept_handler(s, server_accept)
        def client(host, port):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((host, port))
                print

# Generated at 2022-06-12 13:48:50.218030
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip(ip='1.1.1.1')
    assert not is_valid_ip(ip='1.1.1.256')
    assert not is_valid_ip(ip='1.1.1.1.1')

# Generated at 2022-06-12 13:49:25.915841
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    def wrap_socket(client_sock):
        return ssl_wrap_socket(
            client_sock,
            ssl_options={'keyfile': 'tests/test_server.pem', 'certfile': 'tests/test_server.crt', 'cert_reqs': ssl.CERT_NONE},
            server_hostname='www.google.com'
        )

    server = TCPServer(wrap_socket=wrap_socket)
    server.add_sockets([socket.socket()])
    print('server_hostname = {}'.format(server_hostname))
    print('server_hostname = {}'.format(wrap_socket))



# Generated at 2022-06-12 13:49:28.923269
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():

    resolver = ExecutorResolver()
    resolver.close()
    resolver.executor.shutdown()
    resolver.close_executor

# Generated at 2022-06-12 13:49:33.968209
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
   d = DefaultExecutorResolver()
   assert type(d.resolve('1.2.3.4', 80, socket.AF_UNSPEC)) == Future
   f = d.resolve('1.2.3.4', 80, socket.AF_UNSPEC)
   run_until_complete(f)
   assert f.result() == [(socket.AF_INET, ('1.2.3.4', 80))]

# Example for method resolve of class DefaultExecutorResolver
test_DefaultExecutorResolver_resolve()

# Generated at 2022-06-12 13:49:39.065478
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == False
    assert resolver.io_loop == IOLoop.current()



# Generated at 2022-06-12 13:49:44.204354
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    ss = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    context.load_cert_chain(
            '/home/khanh/Desktop/virtualbox_share/pro/tornado_pro/certs/server.crt',
            '/home/khanh/Desktop/virtualbox_share/pro/tornado_pro/certs/server.key'
    )
    ssl_sock = ssl_wrap_socket(
            ss, context
    )
    print(ssl_sock)



# Generated at 2022-06-12 13:49:49.849929
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # call the method to get future object
    # Create resolver
    resolver = Resolver()
    # Get the future
    future = resolver.resolve('www.baidu.com',80)
    # wait for the result
    # to get the result, call future.result() or future.result()
    result = future.result()
    # this result should be a list of tuple
    print(type(result),result)
    # the result is: [(<AddressFamily.AF_INET: 2>, ('220.181.38.150', 80))]
    # The 220.181.38.150 is the IP address of www.baidu.com
    # here we use the port 80



# Generated at 2022-06-12 13:49:52.046032
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = Resolver()
    mapping = {"example.com":"127.0.1.1"}
    t = OverrideResolver(resolver,mapping)
    assert(t.resolve("example.com",1,1) == resolver.resolve("127.0.1.1",1,1))



# Generated at 2022-06-12 13:49:56.018501
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import socket, ssl

    server_hostname = "yahoo.com"
    print(server_hostname)
    with socket.socket() as sock:
        sock.connect((server_hostname, 443))
        # SSL context
        context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
        # Wrap socket
        # Wrap socket (client-side)
        ssock = context.wrap_socket(sock, server_hostname=server_hostname)
        # Send an HTTP request
        ssock.write(b"GET / HTTP/1.0\n\n")
        # Receive response (1kB)
        data = ssock.read(1024)

    print((data))

# Generated at 2022-06-12 13:49:58.350908
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()



# Generated at 2022-06-12 13:50:02.174148
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # test tornado.netutil.Resolver.resolve implementation
    import tornado.ioloop
    async def test_resolve_callback(host, port, resolver, io_loop):
        print(await resolver.resolve(host, port), io_loop)

    io_loop = tornado.ioloop.IOLoop.current()
    resolver = tornado.netutil.Resolver()
    print(io_loop)
    print(resolver)
    io_loop.run_sync(functools.partial(test_resolve_callback, "www.baidu.com", 80, resolver, io_loop))



# Generated at 2022-06-12 13:50:28.485349
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    def mocked_runtime_error(*args,**kargs):
        raise RuntimeError()
    dummy_executor = Mock()
    dummy_executor.shutdown = mocked_runtime_error
    resolver = ExecutorResolver()
    resolver.executor = dummy_executor
    resolver.close_executor =True
    resolver.close()



# Generated at 2022-06-12 13:50:37.813902
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Note: The test cannot be executed as unit test
    # since IOLoop is not initialized.
    # Run the test in main function.

    import threading
    import time
    import tornado.testing
    import functools
    import logging
    import pprint
    
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOLoop().install()
    import asyncio
    asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())
    import zmq
    import zmq.asyncio
    import zmq_tornado

    def main():
        logging.basicConfig(level=logging.DEBUG)
        logging.getLogger('asyncio').setLevel(logging.INFO)

# Generated at 2022-06-12 13:50:40.449385
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    _resolve_addr = _resolve_addr('host', 8000)
    assert(_resolve_addr == [])



# Generated at 2022-06-12 13:50:43.948594
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import concurrent.futures
    import tornado.platform.asyncio
    c = tornado.platform.asyncio.AsyncIOLoop()
    d = ExecutorResolver()
    d.initialize(executor=concurrent.futures.ThreadPoolExecutor())
    d.close
    assert d.executor is None
    d = ExecutorResolver()
    d.initialize(executor=concurrent.futures.ThreadPoolExecutor(), close_executor=False)
    d.close()
    assert d.executor is not None
    # d.close()



# Generated at 2022-06-12 13:50:54.437683
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    # test if ssl.SSLContext won't be changed.
    ssl_options = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
    context = ssl_options_to_context(ssl_options)
    assert context is ssl_options

    # test for SSLContext.load_cert_chain func
    ssl_options = {}
    context = ssl_options_to_context(ssl_options)
    assert context.get_cert_store() is not None

    # test if ssl_options is None
    ssl_options = None
    context = ssl_options_to_context(ssl_options)  # type: ssl.SSLContext
    assert isinstance(context, ssl.SSLContext)
    assert context is not ssl_options

    # test if ssl_options contains illegal keys

# Generated at 2022-06-12 13:50:59.438129
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = ssl.SSLContext()
    assert isinstance(ssl_options_to_context(ssl_options), ssl.SSLContext)
    ssl_options.verify_mode = ssl.CERT_REQUIRED
    ssl_options.load_default_certs()
    ssl_options.load_verify_locations('/etc/ssl/certs/ca-certificates.crt')
    ssl_options.set_ciphers('DEFAULT')
    assert isinstance(ssl_options_to_context(ssl_options), ssl.SSLContext)


# For better testing

# Generated at 2022-06-12 13:51:01.823995
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()
    assert resolver.executor == None 



# Generated at 2022-06-12 13:51:04.568847
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    result = ExecutorResolver()
    result.close(close_executor=True)
    # Outcome: No error



# Generated at 2022-06-12 13:51:08.156181
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Test whether we can call accept_handler
    def accept_handler(sock: socket.socket, addr: str) -> None:
        pass
    # The return value from add_accept_handler is a function that unregisters
    # the handler added by add_accept_handler.
    urh = add_accept_handler()
    assert(urh != None)
    # Test whether we can call remove_handler defined in add_accept_handler
    urh()



# Generated at 2022-06-12 13:51:08.807472
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    pass



# Generated at 2022-06-12 13:51:32.331511
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import socket
    import functools
    import asyncio
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop

    print(type(AsyncIOMainLoop))
    # tornado.platform.asyncio.AsyncIOMainLoop()
    print(type(AsyncIOMainLoop.instance()))
    # tornado.platform.asyncio.AsyncIOMainLoop
    print(type(AsyncIOMainLoop.current()))
    # tornado.platform.asyncio.AsyncIOLoop

    # tornado.platform.asyncio.AsyncIOLoop()
    loop = asyncio.get_event_loop()
    print(type(loop))
    # <class 'asyncio.unix_events.Selector

# Generated at 2022-06-12 13:51:36.413146
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado import testing
    from tornado import gen
    from tornado.ioloop import IOLoop
    import socket

    async def run_resolve(host: str, port: int, family: socket.AddressFamily) -> List[Tuple[int, Any]]:
        result = await IOLoop.current().run_in_executor(
            None, _resolve_addr, host, port, family
        )
        return result

    test_host1 = 'www.google.com'
    test_port1 = 80
    test_family1 = socket.AF_UNSPEC
    
    test_host2 = '127.0.0.1'
    test_port2 = 8080
    test_family2 = socket.AF_INET
    
    test_host3 = '::1'
    test_port3 = 9000
   

# Generated at 2022-06-12 13:51:42.041499
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 10000))
    sock.listen(5)
    io_loop = IOLoop.current()
    io_loop.add_handler(sock,lambda *args: None, IOLoop.READ)
    io_loop.remove_handler(sock)


# Generated at 2022-06-12 13:51:43.844394
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    # Method is not implemented
    resolver.close()
    pass

# Generated at 2022-06-12 13:51:45.459696
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    host = 'python.org'
    port = 80
    print(DefaultExecutorResolver().resolve(host, port))
    print('done')


# Generated at 2022-06-12 13:51:50.797450
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    Resolver.configure('tornado.netutil.BlockingResolver')
    assert isinstance(Resolver.instance(), BlockingResolver)
    override_resolver = OverrideResolver(resolver=Resolver.instance(), mapping={})
    assert isinstance(override_resolver, OverrideResolver)
    assert isinstance(override_resolver.resolve('127.0.0.1', 80), Awaitable)


# Generated at 2022-06-12 13:51:52.220401
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()


# Generated at 2022-06-12 13:52:00.418000
# Unit test for function bind_sockets
def test_bind_sockets():

    old_locals = locals()

    port = 8000
    address = "localhost"
    family = socket.AF_UNSPEC
    backlog = 128
    flags = None
    reuse_port = False

    class _listening_sockets(list):

        def socket(self, z):
            return z

    sockets = _listening_sockets()
    sockets.socket = _listening_sockets.socket

    unique_addresses = set()

    bound_port = None

    timestamp = 1585778582

    socket = old_locals.get('socket', _global_socket)

    address_info = socket.getaddrinfo(address, port, family, socket.SOCK_STREAM, 0, flags)

    address_info = sorted(address_info, key=lambda x: x[0])


# Generated at 2022-06-12 13:52:06.172721
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # Unit test for method resolve of class Resolver
    resolver = DefaultExecutorResolver()
    addrinfo = resolver.resolve('10.208.192.159', 8888, socket.AF_INET)
    print(addrinfo)  # TODO - now it is a Future object
    addrinfo = resolver.resolve('10.208.192.159', 8888)
    print(addrinfo)
    print(resolver.__class__)  # <class 'tornado.netutil.DefaultExecutorResolver'>



# Generated at 2022-06-12 13:52:11.427561
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import tornado
    import concurrent
    import unittest
    result = ExecutorResolver().resolve('localhost', 8080)
    assert result == [(10, ('127.0.0.1', 8080)), (2, ('::1', 8080, 0, 0))], "Wrong value returned"
    class Test(unittest.TestCase):
        def test(self):
            self.assertEqual(result, [(10, ('127.0.0.1', 8080)), (2, ('::1', 8080, 0, 0))], "Wrong value returned")
    obj = Test()
    obj.test()
    pass

# Generated at 2022-06-12 13:52:46.135400
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResutor()
    resolver.close()



# Generated at 2022-06-12 13:52:51.530056
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
  resolver = ExecutorResolver()
  assert resolver.close_executor == None
  assert resolver.executor == None
  resolver.close_executor = True
  resolver.executor = dummy_executor
  resolver.close()
  assert resolver.close_executor == None
  assert resolver.executor == None


# Generated at 2022-06-12 13:52:54.595567
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    myResolver = ExecutorResolver()
    myResolver.initialize(executor = None, close_executor = True)
    return
test_ExecutorResolver_initialize()


# Generated at 2022-06-12 13:52:55.204885
# Unit test for function add_accept_handler
def test_add_accept_handler():
    pass



# Generated at 2022-06-12 13:53:06.358439
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado import gen
    from tornado.testing import AsyncTestCase, gen_test
    class TestOverrideResolver(AsyncTestCase):
        def setUp(self):
            super(TestOverrideResolver, self).setUp()
            self.resolver = OverrideResolver(resolver='',mapping={})

        @gen_test
        async def test_resolve(self):
            result = await self.resolver.resolve('', 0, socket.AF_UNSPEC)
            self.assertEqual(result, [])
    testcase = TestOverrideResolver()
    testcase.setUp()
    testcase.test_resolve()

 

# Generated at 2022-06-12 13:53:13.651489
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Shut down the executor
    es_close = ExecutorResolver()
    es_close.close()
    assert es_close.executor==None
    # The executor is not shut down
    es_noclose = ExecutorResolver(close_executor=False)
    es_noclose.close()
    assert es_noclose.executor!=None
    es_noclose.executor.shutdown()
    assert es_noclose.executor==None


# Generated at 2022-06-12 13:53:14.963830
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    assert(ExecutorResolver.initialize())


# Generated at 2022-06-12 13:53:21.629895
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import unittest
    import socket
    import os
    import stat
    import time
    import functools
    import errno
    import signal

    class TestBindUnixSocket(unittest.TestCase):
        def setUp(self):
            self.sock_filename = '/tmp/unix_socket'
            try:
                os.remove(self.sock_filename)
            except OSError as e:
                if e.errno != errno.ENOENT:
                    raise

        def tearDown(self):
            try:
                os.remove(self.sock_filename)
            except OSError as e:
                if e.errno != errno.ENOENT:
                    raise


# Generated at 2022-06-12 13:53:25.235411
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    s = ExecutorResolver()
    s.close()


if hasattr(concurrent.futures, "ThreadPoolExecutor"):
    dummy_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)



# Generated at 2022-06-12 13:53:34.180160
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Setting up
    resolver = Resolver()
    mapping = {
        # Hostname to host or ip
        "example.com": "127.0.1.1",

        # Host+port to host+port
        ("login.example.com", 443): ("localhost", 1443),

        # Host+port+address family to host+port
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    executor = ExecutorResolver()
    override = OverrideResolver(executor, mapping)
    # Unit test
    host, port, familly = "example.com", 80, socket.AF_INET
    assert mapping[(host, port, familly)] == override.resolve(host, port, familly)

# Generated at 2022-06-12 13:55:23.409400
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    import asyncio
    from tornado.iostream import StreamClosedError
    # functions for unit testing
    def test_func(loop):        
        try:
            resolver = ExecutorResolver()
            client = TCPClient()
            client.initialize(resolver)
            yield client.connect("localhost", 80)
            client.close()
            yield client.connect("localhost", 80)
        except StreamClosedError:
            resolver.close()
        except Exception as e:
            print(e)
    asyncio.run(test_func(IOLoop.current()))

# Generated at 2022-06-12 13:55:33.343044
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    from concurrent.futures import ThreadPoolExecutor
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine, Future

    with ThreadPoolExecutor(5) as executor:
        result = Future()
        executor.submit(result.set_result, None)
        resolver = ExecutorResolver(executor=executor, close_executor=False)
        loop = IOLoop.current()
        resolver.resolve("localhost", "80").add_done_callback(loop.stop)
        loop.start()
        assert result.done() is True
        resolver.close()
        assert resolver.executor is None
        assert result.done() is True





# Generated at 2022-06-12 13:55:42.584861
# Unit test for function bind_sockets
def test_bind_sockets():
    import random
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.log import gen_log
    import tornado
    import ssl

    class BindSocketsTest(AsyncTestCase):        
        def setUp(self):
            super(BindSocketsTest, self).setUp()
            self.port = random.randint(10000, 20000)
            self.sockets = bind_sockets(
                port=self.port,
                address="localhost",
                family=socket.AF_INET,
                backlog=128,
                flags=None,
                reuse_port=False,
            )
        def tearDown(self):
            super(BindSocketsTest, self).tearDown()
            for s in self.sockets:
                s.close()

# Generated at 2022-06-12 13:55:49.250495
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from unittest import mock
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future
    import time

    class TestResolver(Resolver):
        def __init__(self, family, expected_host, expected_port,
                     expected_family, result_fut):
            super().__init__()
            self.family = family
            self.expected_host = expected_host
            self.expected_port = expected_port
            self.expected_family = expected_family
            self.result_fut = result_fut

        def resolve(self, host, port, family):
            assert self.family == family, "family_1"
            assert self.expected_host == host, "host_1"
            assert self.expected_port == port, "port_1"