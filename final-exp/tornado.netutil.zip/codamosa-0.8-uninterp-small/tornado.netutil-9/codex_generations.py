

# Generated at 2022-06-26 08:28:37.415607
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    def resolver_resolve(
        self: DefaultExecutorResolver, host: str, port: int, family: socket.AddressFamily = socket.AF_UNSPEC
    ) -> List[Tuple[int, Any]]:
        result = self.resolve(host, port, family)
        return result

    executor_0 = DefaultExecutorResolver()
    resolver_resolve(executor_0, "host", 80, socket.AF_INET6)


# Generated at 2022-06-26 08:28:43.391120
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("0.0.0.0") == True
    assert is_valid_ip("1.1.1.1") == True
    assert is_valid_ip("255.255.255.255") == True
    assert is_valid_ip("256.256.256.256") == False
    assert is_valid_ip(" ") == False
    assert is_valid_ip("") == False
    assert is_valid_ip("::1") == True
    assert is_valid_ip("1111:1111:1111:1111:1111:1111:1111:1111") == True
    assert is_valid_ip("1111:1111:1111:1111:1111:1111:1111:1111:1") == False


# Generated at 2022-06-26 08:28:54.643916
# Unit test for function bind_sockets
def test_bind_sockets():
    test_port = 8888
    test_flags = socket.AI_NUMERICHOST | socket.AI_NUMERICSERV
    sockets = bind_sockets(test_port, family=socket.AF_INET6, flags=test_flags)
    for sock in sockets:
        # check port
        sock_port = sock.getsockname()[1]
        assert sock_port == test_port
        # check flags
        sock_family = sock.family
        assert sock_family == socket.AF_INET6
    print("Passed bind_socket test")


# Generated at 2022-06-26 08:28:57.189658
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sockets = bind_sockets(port=5555)
    #callback = add_accept_handler(sockets[0], None)
    callback = add_accept_handler(sockets[0], add_accept_handler)
    callback()


# Generated at 2022-06-26 08:29:03.392933
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    threaded_resolver_0 = ThreadedResolver()
    executor: Optional[concurrent.futures.Executor] = None
    close_executor = True
    threaded_resolver_0.initialize(executor, close_executor)


# Generated at 2022-06-26 08:29:13.318573
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Testing the way of using add_accept_handler
    # which is different from the official test case.
    # Because the official test case will not pass
    # in the current machine
    def testcase_handle_connection(connection: socket.socket, address: Any) -> None:
        print(connection)
        print(address)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("0.0.0.0", 0))
    sock.listen(128)
    remove_handler = add_accept_handler(sock, testcase_handle_connection)
    io_loop = IOLoop.current()
    io_loop.start()
    io_loop.remove_handler(sock)
    sock.close()

# Generated at 2022-06-26 08:29:23.798478
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    # Get a empty resolver 
    resolver = DefaultExecutorResolver()
    # Call its method resolve
    fut = resolver.resolve("localhost", "8080")
    # Get the result and print it
    result = IOLoop.current().run_sync(lambda: fut)
    print("DefaultExecutorResolver.resolve returns the info:", result)
    # result = [
    #     (2, ('127.0.0.1', 8080, 0, 0)), 
    #     (2, ('127.0.0.1', 8080, 0, 0)), 
    #     (10, (':1', 8080, 0, 0)), 
    #     (10, (':1', 8080, 0, 0))
    # ]
    # Also, we can see that the port is 8080, which

# Generated at 2022-06-26 08:29:26.376322
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    DefaultExecutorResolver_obj = DefaultExecutorResolver()
    host = "teflon.mit.edu"
    port = 7
    family = socket.AF_INET
    result = DefaultExecutorResolver_obj.resolve(host, port, family)
    print(list(result))
    # result: [(2, ('18.58.0.17', 7)), (10, ('2620:10a:8001::17', 7, 0, 0))]



# Generated at 2022-06-26 08:29:28.470401
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket('/tmp/test.sock')
    print(sock)


# Generated at 2022-06-26 08:29:29.427113
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()


# Generated at 2022-06-26 08:29:54.190707
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Example of using OverrideResolver
    resolver = OverrideResolver(resolver=ThreadedResolver(),
                                mapping={"google.com": "127.0.1.1"})
    # all connections to google.com will resolve to 127.0.1.1

#    Test case 0 (unit test for method __init__ of class ThreadedResolver)
#    ---------------------------------------------------------------------------
#    Purpose:
#        Test if it is possible to create a ThreadedResolver instance.
#    Pre-conditions:
#        :param None:
#    Post-conditions:
#        :return: None
#    Test procedure:
#        1. Create a ThreadedResolver instance
#        2. Verify that it was possible to create a ThreadedResolver instance

    threaded_resolver_0 = ThreadedResolver()

# Generated at 2022-06-26 08:29:56.064546
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    global threaded_resolver
    threaded_resolver = ThreadedResolver()



# Generated at 2022-06-26 08:30:02.150384
# Unit test for function bind_sockets
def test_bind_sockets():
    # test 1
    sockets = bind_sockets(8888)
    for sock in sockets:
        print("Sock: ", sock)
        print("Family: ", sock.family)
        print("Type: ", sock.type)
        print("Proto: ", sock.proto)
        print("Sockname: ", sock.getsockname())
        print("Sockaddr: ", sock.getsockaddr())


# Generated at 2022-06-26 08:30:07.508516
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Create a server connection
    io_loop_0 = IOLoop()
    io_loop_0.add_callback(test_add_accept_handler0)
    io_loop_0.start()
    print("Server finished")


# Generated at 2022-06-26 08:30:11.238284
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = ThreadPoolExecutor(1)
    resolver = ExecutorResolver()
    resolver.close()
    assert executor.shutdown == True
    assert resolver.executor == None


# Generated at 2022-06-26 08:30:15.434448
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    resolver = ExecutorResolver(executor=executor)
    resolver.close()



# Generated at 2022-06-26 08:30:18.923731
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()


# Generated at 2022-06-26 08:30:27.341994
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():

    defaultExecutorResolver = DefaultExecutorResolver()

    # host: www.google.com
    # port: 80
    # family: socket.AF_UNSPEC
    # expected result: [(10, ('172.217.160.14', 80)), (10, ('2607:f8b0:4007:808::200e', 80))]
    host = 'www.google.com'
    port = 80
    family = socket.AF_UNSPEC
    res = defaultExecutorResolver.resolve(host, port, family)
    result = [(10, ('172.217.160.14', 80)), (10, ('2607:f8b0:4007:808::200e', 80))]
    assert result == res

    # host: www.google.com
    # port: 80
    # family: socket.AF

# Generated at 2022-06-26 08:30:36.725815
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ThreadedResolver()
    resolver.close()


# Generated at 2022-06-26 08:30:42.029675
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    file_path = os.path.join(os.path.dirname(__file__), 'echo.sock')
    sock = bind_unix_socket(file_path)
    sock.close()
    os.remove(file_path)


# Generated at 2022-06-26 08:31:29.700160
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_shutdown_0 = ExecutorResolver(executor, close_executor=True)
    print("executor_shutdown_0.executor = ", executor_shutdown_0.executor)
    print("executor_shutdown_0.close_executor = ", executor_shutdown_0.close_executor)
    executor_shutdown_0.close()
    print("executor_shutdown_0.executor = ", executor_shutdown_0.executor)
    print("executor_shutdown_0.close_executor = ", executor_shutdown_0.close_executor)


# Generated at 2022-06-26 08:31:38.734256
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    executor_resolver_0 = ExecutorResolver()
    result = executor_resolver_0.resolve('', 0, socket.AF_UNSPEC)
    if (len(result) == 2):
        assert True
    else:
        assert False


# Generated at 2022-06-26 08:31:45.855181
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # Tested method: resolve
    class Test_ExecutorResolver(ExecutorResolver):
        def initialize(self, executor = None, close_executor = True):
            self.executor = executor
            self.close_executor = close_executor

    # default args
    def test_ExecutorResolver_resolve_0():
        tester = Test_ExecutorResolver()
        assert hasattr(tester, "resolve")
        try:
            tester.resolve(host="localhost", port=80)
        except OSError as e:
            assert e.strerror == "Name or service not known"

    # one optional args
    def test_ExecutorResolver_resolve_1():
        tester = Test_ExecutorResolver()

# Generated at 2022-06-26 08:31:47.882610
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    _size = 1024
    resolver = ExecutorResolver()
    _size_after = len(asyncio.all_tasks())
    assert _size_after == _size + 1

    resolver.close()
    _size_after = len(asyncio.all_tasks())
    assert _size_after == _size


# Generated at 2022-06-26 08:31:54.581860
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    # setup
    host0 ="www.google.com"
    port0 = 80
    # execution
    result0 = DefaultExecutorResolver().resolve(host0, port0)
    # verification
    assert type(result0) == Future
    res0 = asyncio.get_event_loop().run_until_complete(result0)
    print(res0)
    assert type(res0) == list
    # cleanup - none necessary

# Generated at 2022-06-26 08:31:59.576087
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_0 = ThreadPoolExecutor()
    executor_resolver = ExecutorResolver()
    executor_resolver.initialize(executor_0, True)


# Generated at 2022-06-26 08:32:04.245609
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    threaded_resolver_1 = ThreadedResolver(executor,close_executor)
    threaded_resolver_1.initialize()


# Generated at 2022-06-26 08:32:09.077466
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_0 = ThreadPoolExecutor()
    executor_resolver_0 = ExecutorResolver(executor_0)
    executor_resolver_0.close()
    pass


# Generated at 2022-06-26 08:32:14.311186
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    threaded_resolver = ThreadedResolver()
    try:
        threaded_resolver.close()
    except Exception as e:
        assert False, "Exception: %s" % str(e)



# Generated at 2022-06-26 08:32:16.063783
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # TODO: implement test for resolve of class OverrideResolver
    pass


# Generated at 2022-06-26 08:32:48.698991
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    er = ExecutorResolver()
    er.close()
    if er.executor is None:
        print("PASS", "test_ExecutorResolver_close")
    else:
        print("FAIL", "test_ExecutorResolver_close")


# Generated at 2022-06-26 08:32:55.192197
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    unix_socket_file = "/tmp/sockfile"
    sock = bind_unix_socket(unix_socket_file)
    sock.close()

test_case_0()
test_bind_unix_socket()

# Generated at 2022-06-26 08:32:59.502885
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    threaded_resolver = ThreadedResolver(_MAX_WORKERS = 10)
    bind_unix_socket("/tmp/qwerty")


# Generated at 2022-06-26 08:33:02.879556
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {}
    ssl_context = ssl_options_to_context(ssl_options)
    #if isinstance(ssl_context, ssl.SSLContext):
    #    print("ssl_options_to_context returned an SSLContext")


# Generated at 2022-06-26 08:33:11.460739
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    host = ''
    port = 0
    family = socket.AF_UNSPEC
    res = default_executor_resolver_0.resolve(host, port, family)
    assert res is not None

if __name__ == '__main__':
    test_case_0()
    # test_DefaultExecutorResolver_resolve()

# Generated at 2022-06-26 08:33:19.772619
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    from tornado.netutil import ssl_options_to_context
    ssl_ctx = ssl_options_to_context({'certfile': "cert.pem", "keyfile": "key.pem"})
    if not isinstance(ssl_ctx, ssl.SSLContext):
        raise TypeError


# Generated at 2022-06-26 08:33:28.046709
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # create a AF_INET, STREAM socket (TCP)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.setblocking(False)
    try:
        s.bind((socket.gethostname(), 8080))
    except socket.error as msg:
        print ('Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1])
        sys.exit()

    print ('Socket bind complete')
    # Start listening on socket
    s.listen(10)
    print ('Socket now listening')


# Generated at 2022-06-26 08:33:33.406843
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    port = get_port()
    resolver = ThreadedResolver()
    result = resolver.resolve('localhost', port)
    print(result)


# Generated at 2022-06-26 08:33:40.320678
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver_0 = ThreadedResolver()
    override_resolver_0 = OverrideResolver(resolver_0, {})
    host, port, family = "localhost", 48658, socket.AF_INET
    override_resolver_0.resolve(host, port, family)


# Generated at 2022-06-26 08:33:50.141362
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # print('# test_Resolver_resolve')
    resolver = ThreadedResolver()

    # test_Resolver_resolve_0
    # host = '127.0.0.1'
    # port = 8000
    # family = socket.AF_INET
    # print('host: ' + host)
    # print('port: ' + str(port))
    # print('family: socket.AF_INET')
    # try:
    #     result = resolver.resolve(host, port, family)
    #     print('result: ' + str(result))
    # except Exception as e:
    #     print('exception: ' + str(e))

    # test_Resolver_resolve_1
    # host = '127.0.0.1'
    # port = 8000
    #

# Generated at 2022-06-26 08:34:17.667856
# Unit test for function bind_sockets
def test_bind_sockets():
    # ipv4
    bind_sockets(9999)
    # ipv6
    bind_sockets(9999, "::")
    # ipv4 and ipv6
    bind_sockets(9999, None, socket.AF_UNSPEC)
    # invalid address
    try:
        bind_sockets(9999, "invaliddddd")
        assert False
    except socket.gaierror as e:
        import errno
        assert e.errno == errno.EAI_NONAME
    # valid address
    bind_sockets(9999, "localhost")


# Generated at 2022-06-26 08:34:23.751182
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    mapping = {}
    resolver = BlockingResolver()
    override_resolver = OverrideResolver(resolver, mapping)
    awaitable = override_resolver.resolve('test1.com', 443)
    assert awaitable is not None

# Generated at 2022-06-26 08:34:32.777043
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    # Init parameters
    server_hostname = "https://www.gimwc.org"
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "CERT_PATH",
        "keyfile": "KEY_PATH",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "CERT_PATH",
        "ciphers": "HIGH"
    }
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ssl_options = ssl_wrap_socket(client, ssl_options, server_hostname)
    client.close()


# Generated at 2022-06-26 08:34:38.272771
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    override_resolver_0 = OverrideResolver()
    # Call of method resolve of class OverrideResolver
    asyncio.get_event_loop().run_until_complete(override_resolver_0.resolve("", 0))


# Generated at 2022-06-26 08:34:50.134019
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    ip_correct = "192.168.1.1"
    host = "www.google.com"
    port = 80
    family = socket.AF_INET6
    result: List[Tuple[int, Any]] = resolver.resolve(host, port, family)
    print(f"result: {result}")
    for ele in result:
        ip = ele[1][0]
        print(f"ip: {ip}")
        if ip == ip_correct:
            print("test pass")
            return
    print("test fail")


# Generated at 2022-06-26 08:34:59.519950
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection: socket.socket, address: Any) -> None:
        print('Callback running')

    sockets = bind_sockets(port=0, address='localhost')
    remove_handler = add_accept_handler(sock=sockets[0], callback=callback)

    # IOLoop.current() returns a global instance that is already running
    IOLoop.current().start()


# Generated at 2022-06-26 08:35:03.583719
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    result = resolver.resolve('localhost',9999)
    # result = resolver.resolve('localhost',9999)
    print(result)
    print(type(result))

if __name__ == "__main__":
    # test_case_0()
    test_ExecutorResolver_resolve()

# Generated at 2022-06-26 08:35:12.795441
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    threaded_resolver_1 = ThreadedResolver()
    threaded_resolver_1.close()

    # IOError test case
    def test_case_1():
        threaded_resolver_2 = ThreadedResolver()
        threaded_resolver_2.close()
        threaded_resolver_2.resolve('127.0.0.1', 8080)
    test_case_1()


# Generated at 2022-06-26 08:35:24.570817
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip('192.168.1.1') is True
    assert is_valid_ip('192.168.1.x') is False
    assert is_valid_ip('192.168.1.1'.encode('utf8')) is True
    assert is_valid_ip('192.168.1.x'.encode('utf8')) is False
    assert is_valid_ip('192.168.1.1'.encode('utf8').decode('utf8')) is True
    assert is_valid_ip('192.168.1.x'.encode('utf8').decode('utf8')) is False


# Generated at 2022-06-26 08:35:28.523688
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    threaded_resolver_1 = ThreadedResolver()
    threaded_resolver_1.close()



# Generated at 2022-06-26 08:36:41.477481
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    return


# Generated at 2022-06-26 08:36:44.510591
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888, "www.baidu.com")
    for sock in sockets:
        print (sock)



# Generated at 2022-06-26 08:36:48.898644
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # override_resolver_0 = OverrideResolver()
    # assert override_resolver_0.resolve() == NotImplementedError
    pass



# Generated at 2022-06-26 08:36:55.880081
# Unit test for function bind_sockets
def test_bind_sockets():
    port = 8888
    address = 'localhost'
    family = socket.AF_UNSPEC
    backlog = _DEFAULT_BACKLOG

    # create listening sockets bound to the given port
    # and address, and return a list of socket objects
    sock_list = bind_sockets(
        port,
        address,
        family=family,
        backlog=backlog,
        flags=None,
        reuse_port=False,
    )

    for sock in sock_list:
        print(sock)
        sock.close()



# Generated at 2022-06-26 08:37:02.973274
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    from tornado import concurrent

    override_resolver_0 = OverrideResolver()
    override_resolver_0.mapping = dict()
    assert override_resolver_0.resolve('example.com', 80) == concurrent.futures.Future


# Generated at 2022-06-26 08:37:09.312838
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    print("Start test_DefaultExecutorResolver_resolve")
    host = "www.baidu.com"
    port = 80
    family = socket.AF_UNSPEC
    resolver = DefaultExecutorResolver()
    result = resolver.resolve(host, port, family)
    print(result)


# Generated at 2022-06-26 08:37:12.392956
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    sock.listen(5)
    def callback(connection, address):
        print(address)
    r = add_accept_handler(sock, callback)

if __name__ == "__main__":
    test_add_accept_handler()

# Generated at 2022-06-26 08:37:20.741660
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # test_set = TestSetResolver.create_test_set_resolver()
    def testFunction(self, host, port, family):
        expected_output = self.resolve(host, port, family)
        return expected_output

    resolver_0 = Resolver.configurable_default()
    resolver_0.configure(DefaultExecutorResolver)

    resolver_1 = Resolver()
    resolver_1.configure(BlockingResolver)
    resolver_1.configure(DefaultExecutorResolver)

    resolver_2 = Resolver()
    resolver_2.configure(ThreadedResolver)
    resolver_2.configure(DefaultExecutorResolver)

    resolver_3 = Resolver()
    resolver_3.configure(OverrideResolver)
    resolver_

# Generated at 2022-06-26 08:37:28.830008
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    from tornado import gen
    from tornado import ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    AsyncIOMainLoop().install()
    @gen.coroutine
    def test(resolver):
        results = yield resolver.resolve('www.baidu.com', 80)
        # for item in results:
        #     print(item)
    ioloop.IOLoop.current().run_sync(lambda: test(DefaultExecutorResolver()))


# Generated at 2022-06-26 08:37:41.013702
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    filename = "test_unix"

    # Test default mode
    sock = bind_unix_socket(filename)
    assert os.access(filename, os.R_OK)
    assert os.access(filename, os.W_OK)
    assert os.access(filename, os.X_OK)

    # Test overwrite mode
    sock = bind_unix_socket(filename, 0o777)
    assert os.access(filename, os.R_OK)
    assert os.access(filename, os.W_OK)
    assert os.access(filename, os.X_OK)

    # Test different mode
    sock = bind_unix_socket(filename, 0o400)
    assert os.access(filename, os.R_OK)
    assert not os.access(filename, os.W_OK)