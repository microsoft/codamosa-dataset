

# Generated at 2022-06-26 08:28:56.488596
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    ip = 'www.example.com'
    port = 80
    family = socket.AF_UNSPEC

    # First, test on resolver whose executor is not None
    executor = dummy_executor
    resolver = ExecutorResolver(executor=executor)
    result = resolver.resolve(ip, port, family)

    # Since the executor is dummy_executor, which is not runnable
    # The resolved result should be empty
    assert result == []

    # Now create a real executor
    executor = concurrent.futures.ThreadPoolExecutor()
    resolver = ExecutorResolver(executor=executor)
    # The resolver is using the new executor to run
    result = resolver.resolve(ip, port, family)
    # The result should not be empty
    assert result

# Generated at 2022-06-26 08:29:05.012853
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {'ssl_version': 1, 'certfile': 'certfile', 'cert_reqs': 2, 'ca_certs': 'ca_certs', 'ciphers': 'ciphers'}
    ssl_options_to_context(ssl_options)

# We can't use the in-memory cert file used by `mock.patch_ssl_module`
# because the server isn't running on localhost.
# TODO: it would be nice to have better support for testing SSL in
# unittests.

# Generated at 2022-06-26 08:29:18.293286
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = Resolver()
    mapping = {
        # Hostname to host or ip
        "example.com": "127.0.1.1",

        # Host+port to host+port
        ("login.example.com", 443): ("localhost", 1443),

        # Host+port+address family to host+port
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    host = "www.google.com"
    port = 80
    family = socket.AF_INET

    resolver_1 = OverrideResolver(resolver, mapping)
    resolver_1.resolve(host, port, family)


if __name__ == "__main__":
    test_OverrideResolver_resolve()

# Generated at 2022-06-26 08:29:29.910587
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    dict_0 = {
        'cert_reqs': None, \
        'ssl_version': 'YWQgY2VydCByZXF1aXJlZCBkZWZhdWx0', \
        'ca_certs': 'HVCSyI2qNqwWZEaNjkDse9R[', \
        'ciphers': 'CK/RJ^]*+,0vtYLME!6#1'
    }
    ret_0 = None
    try:
        ret_0 = ssl_options_to_context(dict_0)
    except Exception:
        print('unexpected exception:')
        raise

if __name__ == "__main__":
    test_case_0()
    test_ssl_options_to_context()

# Generated at 2022-06-26 08:29:31.870481
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    obj = OverrideResolver('localhost')
    port = 8080
    ip = obj.resolve('google.com', port)
    assert ip == ('localhost', 8080)


# Generated at 2022-06-26 08:29:33.503524
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    close_executor = True
    obj = ExecutorResolver(executor, close_executor)
    obj.close()


# Generated at 2022-06-26 08:29:35.202150
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    resolver.resolve(('',  0,  0))


# Generated at 2022-06-26 08:29:36.540907
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    obj_0 = ExecutorResolver()
    obj_0.close()


# Generated at 2022-06-26 08:29:42.238956
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_0 = dummy_executor 
    close_executor_0 = True
    resolver_0 = ExecutorResolver(executor_0, close_executor_0)
    resolver_0.close()


# Generated at 2022-06-26 08:29:47.290832
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    # Create a socket
    socket_0 = socket.socket()

    # Call function
    ssl_options = ssl.PROTOCOL_SSLv23
    result = ssl_wrap_socket(socket_0, ssl_options)

    # Print result
    print("Result: {}".format(result))

if __name__ == "__main__":
    test_case_0()
    test_ssl_wrap_socket()

# Generated at 2022-06-26 08:30:20.620185
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    import asyncio
    _loop = asyncio.get_event_loop()
    _loop.run_until_complete(test_AsyncTestCase_get_test_result_0())

async def test_AsyncTestCase_get_test_result_0():
    from unittest import TestCase
    from unittest.mock import Mock
    import typing

    class TestTypedDict(typing.TypedDict):
        a:  int

    class TestTypedDict2(typing.TypedDict):
        a:  int

    # example of class with TypedDict
    class Foo(object):
        def __init__(self, bar: TestTypedDict) -> None:
            self.bar = bar

    # example of class with TypedDict with the same name

# Generated at 2022-06-26 08:30:21.827830
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    pass


# Generated at 2022-06-26 08:30:27.854059
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = concurrent.futures.Executor()
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor) 
    resolver.initialize()


# Generated at 2022-06-26 08:30:31.913111
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    print("test_ExecutorResolver_resolve()")
    # Initialize the class to be tested
    # resolver = ExecutorResolver()
    bool_0 = True

# Generated at 2022-06-26 08:30:37.984692
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_0 = None
    close_executor_0 = True
    obj = ExecutorResolver()
    obj.initialize(executor_0, close_executor_0)
    assert isinstance(obj.executor, concurrent.futures.Executor) == True
    assert obj.close_executor == True

test_case_0()
test_ExecutorResolver_initialize()

# Generated at 2022-06-26 08:30:49.520288
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # "A dictionary mapping hostnames to addresses (or to lists of addresses).
    # "
    mapping = {None: None}
    # "A resolver object
    # "
    resolver = None
    # "Create a new Resolver that maps hostnames to other addresses.
    # "
    override_resolver = OverrideResolver(resolver, mapping)
    # "Add a mapping
    # "
    override_resolver.mapping["example.com"] = "127.0.1.1"
    # "Update a mapping.
    # "
    override_resolver.mapping["example.com"] = "127.0.1.2"
    # "Remove a mapping.
    # "
    override_resolver.mapping.pop("example.com", None)
    # "Delete a mapping.
    # "

# Generated at 2022-06-26 08:30:55.030076
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # OverrideResolver is a class variable
    obj_0 = OverrideResolver.__dict__['resolve']
    # obj_0 is callable
    bool_0 = isinstance(obj_0, collections.Callable)
    if bool_0 == True:
        # resolver is a class variable
        obj_0 = OverrideResolver.__dict__['resolve']
        # host is a class variable
        obj_0 = OverrideResolver.__dict__['resolve']
    test_case_0()


# Generated at 2022-06-26 08:31:00.593213
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    file = "afdsa"
    expected_output = "File afdsa exists and is not a socket"
    try:
        bind_unix_socket(file)
    except ValueError as e:
        if str(e) == expected_output:
            test_case_0()
        else:
            print("Expected output is: " + expected_output)
            assert False
    else:
        assert False



# Generated at 2022-06-26 08:31:05.474161
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    _0 = ExecutorResolver()
    _0.initialize(executor, close_executor)


# Generated at 2022-06-26 08:31:13.366718
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from unittest import mock
    resolver = Resolver()
    host = "localhost"
    port = 8080
    family = socket.AF_UNSPEC
    # issue-5041
    with mock.patch.object(resolver, "resolve") as m_resolve:
        m_resolve.return_value = [AsyncMock()]
        resolver.resolve(host, port, family)


# Generated at 2022-06-26 08:31:24.567549
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    pass


# Generated at 2022-06-26 08:31:27.739409
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.close()


# Generated at 2022-06-26 08:31:31.740400
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():

    # Test the method close of class ExecutorResolver.
    #
    # This method should raise NotImplementedError.
    executor_resolver_0 = ExecutorResolver()
    try:
        executor_resolver_0.close()
        assert False, "expected NotImplementedError"
    except NotImplementedError:
        pass


# Generated at 2022-06-26 08:31:38.405396
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert( is_valid_ip('192.168.0.1') == True)
    assert( is_valid_ip('xyz.com') == False)
    print ('is_valid_ip test case passed!')


# Generated at 2022-06-26 08:31:40.829671
# Unit test for function bind_sockets
def test_bind_sockets():
    # test cases
    #==========================
    bind_sockets(None)
    #==========================
    


# Generated at 2022-06-26 08:31:51.068979
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    host_0 = "google.com"
    port_0 = 80
    family_0 = socket.AF_UNSPEC
    loop_0 = tornado.platform.asyncio.AsyncIOLoop()
    loop_0.run_sync(lambda: default_executor_resolver_0.resolve(host_0, port_0, family_0))



# Generated at 2022-06-26 08:31:57.215562
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    default_executor_resolver_0 = DefaultExecutorResolver()
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()
    executor_resolver_0.initialize(executor=dummy_executor)
    executor_resolver_0.initialize(close_executor=True)
    executor_resolver_0.initialize(executor=dummy_executor, close_executor=True)


# Generated at 2022-06-26 08:32:04.407554
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # TODO: complete test case
    override_resolver = OverrideResolver(None, {
        'example.com': '127.0.1.1',
        ('login.example.com', 443): ('localhost', 1443),
        ('login.example.com', 443, socket.AF_INET6): (':1', 1443)
    })

    override_resolver.resolve('example.com', 0)
    override_resolver.resolve('example.com', 0, socket.AF_UNSPEC)
    override_resolver.resolve('login.example.com', 443)
    override_resolver.resolve('login.example.com', 443, socket.AF_INET6)

    # test assertions



# Generated at 2022-06-26 08:32:07.938593
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    for sock in sockets:
        assert sock.family == socket.AF_INET


# Generated at 2022-06-26 08:32:11.453138
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()


# Generated at 2022-06-26 08:32:39.335431
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # Test when the host is not found
    default_executor_resolver_1 = DefaultExecutorResolver()
    def tested_cb_1(future: Future) -> None:
        assert future.exception() is not None
        assert isinstance(future.exception(), IOError)
        assert future.result() is None

    future_1 = default_executor_resolver_1.resolve("thisisnotavalidhost", 80)
    future_1.add_done_callback(tested_cb_1)
    IOLoop.current().run_sync(future_1)

    # Test when the host is found
    default_executor_resolver_2 = DefaultExecutorResolver()
    def tested_cb_2(future: Future) -> None:
        assert future.exception() is None
        assert future.result()

# Generated at 2022-06-26 08:32:52.926848
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    print(__name__)
    print("test_OverrideResolver_resolve")
    resolver = OverrideResolver(DefaultExecutorResolver(), {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    })
    print("resolver", resolver)
    print("resolver.resolve(\"example.com\", 80)", resolver.resolve("example.com", 80))
    print("resolver.resolve(\"https://example.com\", 80)", resolver.resolve("https://example.com", 80))

if __name__ == "__main__":
    print("__name__", __name__)
    test

# Generated at 2022-06-26 08:33:00.135846
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(port=8888, address='localhost', family=socket.AF_INET, backlog=_DEFAULT_BACKLOG, flags=None, reuse_port=False)
    for sock in sockets:
        print ('bind_sockets: ', sock)
        sock.close()


# Generated at 2022-06-26 08:33:02.866396
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver = ExecutorResolver()
    executor_resolver.close()


# Generated at 2022-06-26 08:33:13.140837
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("0.0.0.0") == True
    assert is_valid_ip("0.0.0.256") == False
    assert is_valid_ip("0.0.0.256") == False
    assert is_valid_ip("") == False
    assert is_valid_ip("192.168.10.1") == True
    assert is_valid_ip("localhost") == False
    assert is_valid_ip("10.95.28.172") == True
    assert is_valid_ip("1") == False



# Generated at 2022-06-26 08:33:26.351843
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    host="python.org"
    port=0
    family=None
    #family=0x0
    #family=0x2
    #family=AF_INET6
    #family=AF_INET
                
    #instance_of_Resolver_0 = Resolver()
    instance_of_Resolver_0 = DefaultExecutorResolver()
    ret_val_0 = instance_of_Resolver_0.resolve(host, port, family)
    assert type(ret_val_0) is Future
    
    #instance_of_Resolver_0 = Resolver()
    instance_of_Resolver_0 = DefaultExecutorResolver()
    ret_val_0 = instance_of_Resolver_0.resolve(host, port)
    assert type(ret_val_0) is Future
    


# Generated at 2022-06-26 08:33:35.666295
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options_dict_0 = {'certfile': 'certfile'}
    # TODO: currently does not support pass in SSLContext instance
    # ssl_options_instance_0 = ssl.SSLContext()
    ssl_context_instance_0 = ssl_options_to_context(ssl_options_dict_0)

if __name__ == '__main__':
    test_case_0()
    test_ssl_options_to_context()

# Generated at 2022-06-26 08:33:39.392850
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.close()


# Generated at 2022-06-26 08:33:45.316806
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket()
    def callback(sock: socket.socket, address: Any) -> None:
        print(sock, type(sock))
        print(address, type(address))

    add_accept_handler(sock, callback)


# Generated at 2022-06-26 08:33:51.318312
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    from tornado.test.util import unittest
    
    context = ssl_options_to_context({"ssl_version": ssl.PROTOCOL_SSLv23})
    self.assertIsInstance(context, ssl.SSLContext)
    self.assertEqual(context.protocol, ssl.PROTOCOL_SSLv23)


# Test case for function ssl_options_to_context

# Generated at 2022-06-26 08:34:09.340731
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    override_resolver_0 = OverrideResolver(default_executor_resolver_0, {
        'example.com': '127.0.1.1',
        ('login.example.com', 443): ('localhost', 1443),
        ('login.example.com', 443, socket.AF_INET6): ("::1", 1443)
    })


# Generated at 2022-06-26 08:34:11.964039
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()



# Generated at 2022-06-26 08:34:13.513378
# Unit test for function bind_sockets
def test_bind_sockets():
    test_case_0()



# Generated at 2022-06-26 08:34:18.691034
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    try:
        loop.run_sync(default_executor_resolver.resolve)
    except Exception as err:
        print(f"Failed to resolve address: {err}")
        return False
    return True


# Generated at 2022-06-26 08:34:28.028765
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    default_executor_resolver_0.resolve("www.apache.org", 80)
    # Check if the instance attribute _reentrant is True
    assert (hasattr(default_executor_resolver_0, "_reentrant") and default_executor_resolver_0._reentrant)


# Generated at 2022-06-26 08:34:31.631402
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    default_executor_resolver_0 = DefaultExecutorResolver()
    assert default_executor_resolver_0.close() is None



# Generated at 2022-06-26 08:34:35.214027
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    socket_0 = socket.socket()
    ssl_wrap_socket_var_0 = ssl_wrap_socket(socket_0)

# Generated at 2022-06-26 08:34:42.601650
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    loop = IOLoop.current()
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor)
    host = 'localhost'
    port = 80
    family = socket.AF_UNSPEC
    result = loop.run_sync(lambda: resolver.resolve(host, port, family), timeout=2.0)
    assert result == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80, 0, 0)),
    ]



# Generated at 2022-06-26 08:34:51.113613
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    host_0 = ""
    port_0 = 0
    family_0 = 1000
    future_0 = default_executor_resolver_0.resolve(
    host_0, port_0, family_0)
    future_0 = default_executor_resolver_0.resolve(
    host_0, port_0)
    future_0 = default_executor_resolver_0.resolve(
    host_0)


# Generated at 2022-06-26 08:35:03.593013
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    o = OverrideResolver()
    o.resolver = 3
    o.mapping = {}
    host = "127.0.0.1"
    port = 43
    family = socket.AF_INET
    o.resolver.resolve(host, port, family)
    host = "127.0.0.1"
    port = 43
    family = socket.AF_INET
    o.mapping[(host, port, family)] = "127.0.0.1"
    o.resolver.resolve(host, port, family)
    host = "127.0.0.1"
    port = 43
    family = socket.AF_INET
    o.mapping[(host, port)] = "127.0.0.1"
    host = "127.0.0.1"

# Generated at 2022-06-26 08:35:31.427690
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    # Create an instance of class DefaultExecutorResolver
    default_executor_resolver_0 = DefaultExecutorResolver()
    # Call method resolve of default_executor_resolver_0
    result = default_executor_resolver_0.resolve()
    print(result)

# Generated at 2022-06-26 08:35:39.415748
# Unit test for function add_accept_handler
def test_add_accept_handler():
    default_executor_resolver_0 = DefaultExecutorResolver()

    def callback(connection: Any, address: Any) -> None:
        print("connection is [" + str(connection) + "]")
        print("address is [" + str(address) + "]")
        print("")

    sock_0 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock_0.setblocking(False)

    r_0 = add_accept_handler(sock_0, callback)

    print("r_0 is [" + str(r_0) + "]")

    r_0()



# Generated at 2022-06-26 08:35:49.719360
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = Resolver()
    mapping = {
        # Hostname to host or ip
        "example.com": "127.0.1.1",
        # Host+port to host+port
        ("login.example.com", 443): ("localhost", 1443),
        # Host+port+address family to host+port
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    override_resolver = OverrideResolver(resolver, mapping)
    res = override_resolver.resolve("example.com", 80)
    print("Unit test for method resolve of class OverrideResolver")
    print("resolve example.com:80")
    print("res=" + str(res))

# Generated at 2022-06-26 08:35:52.413163
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    default_executor_resolver_1 = ExecutorResolver()



# Generated at 2022-06-26 08:36:00.470057
# Unit test for function add_accept_handler
def test_add_accept_handler():
    port = 8888
    ioloop = IOLoop()
    sock = bind_sockets(port)
    addr = sock[0]
    print("listening on: %s" % addr)
    callback = lambda conn, addr: print(addr)
    add_accept_handler(addr, callback)
    ioloop.start()

if __name__=='__main__':
    test_add_accept_handler()

# Generated at 2022-06-26 08:36:07.205461
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    file = "/tmp/tornado_sockets.sock"
    if os.path.exists(file):
        os.remove(file)
    socket_0 = bind_unix_socket(file)
    assert isinstance(socket_0, socket.socket)
    os.remove(file)


# Generated at 2022-06-26 08:36:10.945475
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    try:
        bind_unix_socket('unix.sock')
    except ValueError as e:
        if str(e) != 'File unix.sock exists and is not a socket':
            raise e

# Test for function _TCPClient_initialize
# Use mock to replace socket.create_connection

# Generated at 2022-06-26 08:36:23.238125
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # Produce a dummy value to make sure we are calling the right `run_on_executor` wrapper
    dummy_executor = concurrent.futures.ThreadPoolExecutor(5)

    # This seems to be the most appropriate place to put this test case.
    # It is not relative to any classes.
    io_loop_future = IOLoop.current().run_in_executor(None, _resolve_addr, "localhost", 9999)
    print("io_loop_future:", io_loop_future)

    # Now test the decorated class method
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()
    print("executor_resolver_0:", executor_resolver_0)

# Generated at 2022-06-26 08:36:26.222910
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver = ExecutorResolver.configure()
    executor_resolver.close()



# Generated at 2022-06-26 08:36:30.346555
# Unit test for function add_accept_handler
def test_add_accept_handler():
    io_loop = IOLoop.instance()
    io_loop.add_callback(add_accept_handler,
    sock,
    callback)



# Generated at 2022-06-26 08:37:09.145727
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    print('Running test_OverrideResolver_resolve')
    # Test: explicit socket family
    resolver = OverrideResolver(
        resolver=DefaultExecutorResolver(),
        mapping={
            ("login.example.com", 443, socket.AF_INET): (
                ("::1", 1443),
            ),
            ("login.example.com", 443, socket.AF_INET6): (
                ("::1", 1443),
            ),
        },
    )

    # Test: no socket family
    resolver.resolve("login.example.com", 443)
    resolver.resolve("login.example.com", 443, socket.AF_INET)
    resolver.resolve("login.example.com", 443, socket.AF_INET6)

    # Test: hostname only
    res

# Generated at 2022-06-26 08:37:13.326149
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    default_executor_resolver_0 = DefaultExecutorResolver()
    default_executor_resolver_0.close()


# Generated at 2022-06-26 08:37:20.953540
# Unit test for function add_accept_handler
def test_add_accept_handler():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("", 0))
    s.listen(1)
    port = s.getsockname()[1]
    io_loop = IOLoop.current()
    result = [False]

    def handle_connection(connection: socket.socket, address: Any) -> None:
        connection.close()
        result[0] = True
        io_loop.stop()

    remove = add_accept_handler(s, handle_connection)
    (client,) = bind_sockets(0)
    client.connect(("127.0.0.1", port))
    io_loop.add_handler(s, lambda fd, events: None, io_loop.READ)
    io_loop.start()
    # TOD

# Generated at 2022-06-26 08:37:27.629008
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    host_0 = 'host_0'
    port_0 = -9312513329755021270
    family_0 = socket.AF_UNSPEC
    default_executor_resolver_0.resolve(host_0, port_0, family_0)



# Generated at 2022-06-26 08:37:40.697410
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    host_0: str = 'google.com'
    port_1: int = 80
    family_2: socket.AddressFamily = socket.AF_INET
    f: Awaitable[List[Tuple[int, Any]]]
    f = default_executor_resolver_0.resolve(host_0, port_1, family_2)
    if not (f is None):
        default_executor_resolver_0.resolve(host_0, port_1, family_2)
    class A:

        def __init__(self):
            pass
        def __await__(self):
            yield None
    a: A
    a = A()
    async def f(a):
        pass
    f(a)
