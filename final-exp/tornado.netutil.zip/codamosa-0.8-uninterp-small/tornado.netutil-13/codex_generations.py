

# Generated at 2022-06-26 08:28:50.356116
# Unit test for function bind_sockets
def test_bind_sockets():
    int_0 = -91391
    str_0 = 'KO_KR'
    int_1 = bind_sockets(int_0, str_0, socket.AF_UNSPEC, _DEFAULT_BACKLOG, None)


# Generated at 2022-06-26 08:28:54.856879
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        pass
    sock = socket.socket()
    sock.listen(10)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()
    sock.close()

test_add_accept_handler()

# Generated at 2022-06-26 08:28:57.377834
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_0 = True
    close_executor_0 = False
    executorResolver_0 = ExecutorResolver(executor_0, close_executor_0)
    executorResolver_0.close()


# Generated at 2022-06-26 08:28:58.655716
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = Executor()
    ExecutorResolver.initialize(executor)
    ExecutorResolver.close()

# Generated at 2022-06-26 08:29:01.084328
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = concurrent.futures.Executor()
    close_executor = False
    eresolver = ExecutorResolver()
    eresolver.initialize(executor, close_executor)


# Generated at 2022-06-26 08:29:05.370593
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    host = '127.0.0.1'
    port = 0
    family = 255
    resolver.resolve(host, port, family)


# Generated at 2022-06-26 08:29:14.796589
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado import concurrent, gen, ioloop
    @gen.coroutine
    def f() -> Generator[None, None, None]:
        r = Resolver()
        result = yield r.resolve('localhost', 80, 0)
        print(result)
    if __name__ == '__main__':
        ioloop.IOLoop.current().run_sync(f)


# Generated at 2022-06-26 08:29:23.739188
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    class_0 = OverrideResolver()
    class_1 = Resolver()
    dict_0 = {}
    class_0.initialize(class_1, dict_0)
    str_0 = '127.0.0.1'
    int_0 = 0
    int_1 = class_0.get_default_port(str_0)
    int_2 = socket.AF_UNSPEC
    future_0 = class_0.resolve(str_0, int_1, int_2)
    str_1 = 'ko_KR'
    bool_0 = is_valid_ip(str_1)

if __name__ == '__main__':
    test_case_0()
    test_OverrideResolver_resolve()

# Generated at 2022-06-26 08:29:31.955995
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    def callback(result):
        return result
    resolver = ExecutorResolver()
    str_0 = 'ko_KR'
    str_1 = 'www.google.com'
    str_2 = 'www.amazon.com'
    num_1 = 443
    # Commenting out the next line is equivalent to the test case
    # calling resolve(str_0, num_1), which results in an error
    # because the first argument is not a valid IP address.
    #bool_0 = is_valid_ip(str_0)
    future_0 = resolver.resolve(str_1, num_1)
    future_1 = resolver.resolve(str_2, num_1)
    IOLoop.current().run_sync(lambda: future_0)

# Generated at 2022-06-26 08:29:37.565918
# Unit test for method resolve of class Resolver

# Generated at 2022-06-26 08:30:00.232103
# Unit test for function bind_sockets
def test_bind_sockets():
    # Check if function will return a list of sockets
    sockets = bind_sockets(80, 'localhost', socket.AF_UNSPEC, 128, None, False)
    assert isinstance(sockets, list)
    assert isinstance(sockets[0], socket.socket)


# Generated at 2022-06-26 08:30:02.749635
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # TODO: add test cases
    return



# Generated at 2022-06-26 08:30:11.029444
# Unit test for function bind_sockets
def test_bind_sockets():
    print(bind_sockets(8080))

"""Raw python socket wrappers for `.IOLoop`.

For non-blocking sockets, the method implementations in this module
return a `.Future` whose result is available when the operation has
completed.
"""

try:
    ssl = ssl
except NameError:
    ssl = None  # type: ignore
    _ClientSSLSocket = _ServerSSLSocket = None



# Generated at 2022-06-26 08:30:15.924171
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_0 = module_0.Executor()
    obj_0 = ExecutorResolver(executor=executor_0)
    obj_0.close()

# Generated at 2022-06-26 08:30:23.893662
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # The mapping can be in three formats::
    #     {
    #         # Hostname to host or ip
    #         "example.com": "127.0.1.1",
    # 
    #         # Host+port to host+port
    #         ("login.example.com", 443): ("localhost", 1443),
    # 
    #         # Host+port+address family to host+port
    #         ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    #     }
    # 
    # .. versionchanged:: 5.0
    #    Added support for host-port-family triplets.
    pass


# Generated at 2022-06-26 08:30:29.160438
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_0 = module_0.Executor()
    resolver_0 = ExecutorResolver(executor_0)
    resolver_0.close()
    resolver_0.close()


# Generated at 2022-06-26 08:30:32.550218
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    executor_0 = module_0.Executor()
    # test code here...


import concurrent.futures._base as module_0


# Generated at 2022-06-26 08:30:41.689957
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    import socket
    executor_0 = ThreadedResolver()
    mapping_0 = {}
    mapping_0["example.com"] = "127.0.1.1"
    mapping_0[("login.example.com", 443)] = ("localhost", 1443)
    mapping_0[("login.example.com", 443, socket.AF_INET6)] = ("::1", 1443)
    resolver_0 = OverrideResolver(executor_0, mapping_0)
    host_0 = "login.example.com"
    port_0 = 443
    family_0 = socket.AF_INET6
    assert resolver_0.resolve(host_0, port_0, family_0) == ("::1", 1443)


# Generated at 2022-06-26 08:30:42.827127
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets_0 = bind_sockets(None)


# Generated at 2022-06-26 08:30:48.400278
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    override_resolver = OverrideResolver()
    resolve_0 = override_resolver.resolve(host="host_0", port=int(), family=1)


# Generated at 2022-06-26 08:31:15.304011
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    dict_0 = {
        "keyfile": "foo",
        "certfile": "bar",
        "ciphers": "baz"
    }

    ssl.SSLContext = ssl.SSLContext

    ssl_options_to_context(dict_0)

# Generated at 2022-06-26 08:31:18.171911
# Unit test for function add_accept_handler
def test_add_accept_handler():
    port = 8080
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.bind(("", 8080))
    sock.listen(1)
    func = add_accept_handler(sock, lambda x, y: print((x, y)))
    func()

if __name__ == "__main__":
    test_case_0()
    test_add_accept_handler()

# Generated at 2022-06-26 08:31:20.608411
# Unit test for function bind_sockets
def test_bind_sockets():
    test_case_0()



# Generated at 2022-06-26 08:31:28.946568
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    int_0 = 8080
    list_0 = bind_sockets(int_0)
    io_loop0 = IOLoop.current()
    executor0 = ThreadPoolExecutor(2)
    instance = ExecutorResolver(io_loop0, executor0)
    instance.close()
    int_0 = instance.resolve("127.0.0.1", 8080)
    assert int_0 == (2, ("127.0.0.1", 8080))
    instance.close()


# Generated at 2022-06-26 08:31:43.756111
# Unit test for function add_accept_handler
def test_add_accept_handler():
    class TestClass(object):
        def __init__(self):
            self.int_0 = 8080
            self.list_0 = bind_sockets(self.int_0)
            self.socket_0 = self.list_0[0]
            self.callback_0 = self.callback_0_impl
            self.callable_0 = add_accept_handler(self.socket_0, self.callback_0)
            self.callable_0()

        def callback_0_impl(self, socket_0 : socket.socket, any_0 : Any) -> None:
            print("callback_0_impl")
    tc = TestClass()

if __name__ == "__main__":
    test_case_0()
    test_add_accept_handler()

# Generated at 2022-06-26 08:31:45.913227
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    DefaultExecutorResolver().resolve('localhost', '80')


# Generated at 2022-06-26 08:31:46.690109
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    test = ExecutorResolver()
    test.close()


# Generated at 2022-06-26 08:31:54.189322
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    ExecutorResolver.initialize(dummy_executor, True)
    thread_pool_executor = concurrent.futures.ThreadPoolExecutor(max_workers=2)
    ExecutorResolver.initialize(executor=thread_pool_executor, close_executor=False)
    ExecutorResolver.initialize(executor=True, close_executor=True)
    ExecutorResolver.initialize()


# Generated at 2022-06-26 08:31:57.630441
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    to = ExecutorResolver()
    ip_str = "127.0.0.1"
    port = 8080
    ip_family = socket.AF_INET
    ip_list = to.resolve(ip_str, port, ip_family)    

# Generated at 2022-06-26 08:31:59.115830
# Unit test for function bind_sockets
def test_bind_sockets():
    test_case_0()



# Generated at 2022-06-26 08:32:16.362353
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    executor = DefaultExecutorResolver()
    res = executor.resolve("localhost", 8080)
    # res = await res
    print(res)


# Generated at 2022-06-26 08:32:28.779934
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import time

    server_listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    server_listen_sock.bind(("", 8080))
    server_listen_sock.setblocking(False)
    server_listen_sock.listen(128)

    def accept_handler(connection, address):
        data = connection.recv(1024)
        print("Server received: " + str(data.decode("utf-8")))

# Generated at 2022-06-26 08:32:41.286360
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Server
    def sock_callback(connection, address):
        print(f"connection: {connection}, address: {address}")
        # Write to socket
        message = input()
        connection.send(message.encode()) # Need to encode to type bytes
        # Close the connection
        connection.close()

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 8080))
    sock.listen(5)
    sock.setblocking(0)
    add_accept_handler(sock, sock_callback)

    # Client
    def client_connector():
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect(('localhost', 8080))
        # Read from socket
        response = sock

# Generated at 2022-06-26 08:32:43.328862
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    socket_1 = socket.socket()
    context_1 = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    sslsocket_1 = ssl_wrap_socket(socket_1, context_1, None)


# Generated at 2022-06-26 08:32:44.336121
# Unit test for function bind_sockets
def test_bind_sockets():
    # Test case 0
    test_case_0()
# Unit test entry
test_bind_sockets()

# Generated at 2022-06-26 08:32:55.069306
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import threading
    import logging

    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger("test.test_add_accept_handler")

    list_0 = bind_sockets(8080)
    func_0 = lambda x, y: None
    return_0 = add_accept_handler(list_0[0], func_0)
    return_1 = [False]
    
    def thread_target() -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect(("localhost", 8080))
        # Give the server some time to call the callback
        import time
        time.sleep(0.05)
        return_1[0] = True


# Generated at 2022-06-26 08:32:56.503489
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    instance_0 = ExecutorResolver()
    instance_1 = ExecutorResolver(executor = dummy_executor, close_executor = True)


# Generated at 2022-06-26 08:33:03.709138
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():

    class Resolver_0(Resolver):

        def resolve(
            self, host: str, port: int, family: socket.AddressFamily = socket.AF_UNSPEC
        ) -> Awaitable[List[Tuple[int, Any]]]:
            return 0
    Resolver_0_0 = Resolver_0()
    set_0 = Resolver.configured_class(Resolver.configurable_default(), {})
    int_0 = 8080
    str_0 = "test_str_0"


# Generated at 2022-06-26 08:33:05.535817
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    class_0 = ExecutorResolver()


# Generated at 2022-06-26 08:33:13.295699
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    for host in ["1.1.1.1", "localhost"]:
        for port in [80, 0, 8080]:
            for family in [socket.AF_UNSPEC, socket.AF_INET, socket.AF_INET6]:
                res = ExecutorResolver()
                res.initialize()
                cor = res.resolve(host, port, family)
                IOLoop.current().run_sync(cor)
                res.close()


# Generated at 2022-06-26 08:33:33.449484
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    print('Unit test for method resolve of class OverrideResolver')
    resolver = OverrideResolver()
    resolver.resolve('', 8907)


# Generated at 2022-06-26 08:33:35.108383
# Unit test for function bind_sockets
def test_bind_sockets():
    test_case_0()



# Generated at 2022-06-26 08:33:42.384320
# Unit test for function add_accept_handler
def test_add_accept_handler():
    int_0 = 8080
    list_0 = bind_sockets(int_0)
    for socket_0 in list_0:
        (_, sock) = add_accept_handler(socket_0, lambda _0, _1: None)
        print(sock)
        # Call the returned function
        sock()



# Generated at 2022-06-26 08:33:47.079395
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    executor_0 = dummy_executor
    list_0 = ExecutorResolver(executor_0)
    int_0, str_0 = 8080, "127.0.0.1"
    str_0 = list_0.resolve(int_0, str_0)


# Generated at 2022-06-26 08:33:55.816851
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import sys
    import socket

    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Bind the socket to the port
    """
    server_address = ('localhost', 30718)
    print('starting up on {} port {}'.format(*server_address))
    sock.bind(server_address)
    """
    list_0 = bind_sockets(30718)
    # Listen for incoming connections
    sock.listen(1)

    def callback(conn, addr):
        print(addr)
        print(type(addr))
        print('connection from', addr)
        while True:
            data = conn.recv(1024)
            if not data:
                break
            conn.sendall(data)
        conn.close()

    add_

# Generated at 2022-06-26 08:33:57.886146
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    pass



# Generated at 2022-06-26 08:34:06.151228
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    int_0 = 8080
    list_0 = bind_sockets(int_0)
    class_0 = Resolver()
    int_1 = 0
    list_1 = class_0.resolve("localhost", int_1)


# Generated at 2022-06-26 08:34:13.136502
# Unit test for function add_accept_handler
def test_add_accept_handler():
    int_0 = 8080
    sock_0 = socket.socket()
    sock_0.setblocking(0)
    sock_0.bind(int_0)
    sock_0.listen(128)
    func_0 = add_accept_handler(sock_0, f)


# Generated at 2022-06-26 08:34:21.201891
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # We use bind_sockets() to create IO server socket
    int_0 = 8443
    list_0 = bind_sockets(int_0)
    assert len(list_0) == 1
    socket_0 = list_0[0]
    try:
        # We use add_accept_handler() to create accept handler for IO server socket
        callable_0 = add_accept_handler(socket_0, callback)
        assert callable_0 != None
        # We use add_accept_handler() to remove accept handler for IO server socket
        callable_0()
    finally:
        # We use bind_sockets() to remove IO server socket
        socket_0.close()


# Generated at 2022-06-26 08:34:32.341597
# Unit test for method resolve of class Resolver

# Generated at 2022-06-26 08:34:50.205072
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver(DefaultExecutorResolver(), {"foo": "127.0.0.1"})
    result = resolver.resolve("foo", 8080)


# Generated at 2022-06-26 08:34:56.098431
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    socket_0 = socket.socket()
    ssl_options_0 = ssl.SSLContext()
    server_hostname = None
    ssl_wrap_socket(socket_0, ssl_options_0, server_hostname)


# Generated at 2022-06-26 08:34:58.207739
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    obj_0 = ExecutorResolver()
    var_0 = obj_0.resolve("tock", 123)
    print(var_0)


# Generated at 2022-06-26 08:34:59.662796
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Returns: void
    pass


# Generated at 2022-06-26 08:35:02.922920
# Unit test for function is_valid_ip
def test_is_valid_ip():
    str_0 = "1.1.1.1"
    assert is_valid_ip(str_0) == True
    str_1 = "www.google.com"
    assert is_valid_ip(str_1) == False


# Generated at 2022-06-26 08:35:11.199866
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    int_0 = 8080
    list_0 = bind_sockets(int_0)
    socks = bind_sockets(int_0)
    func_0 = ExecutorResolver().close
    func_0()
    func_0 = add_accept_handler(socks[0], lambda a, b: None)
    func_0()


# Generated at 2022-06-26 08:35:13.702451
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver =  OverrideResolver("",{})
    assert isinstance(resolver.resolve("",""), Awaitable)


# Generated at 2022-06-26 08:35:23.932786
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock.bind(('127.0.0.1',9005))
    sock.listen()
    def callback(connection, address):
        print('connection: ',connection)
        print(address)
    add_accept_handler(sock,callback)
    while True:
        pass

if __name__ == "__main__":
    # test_case_0()
    test_add_accept_handler()

# Generated at 2022-06-26 08:35:27.143068
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    bind_unix_socket('/tmp/unix.sock')


# Generated at 2022-06-26 08:35:38.875785
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time
    import threading
    import random
    import http.server

    count_0 = 1
    int_0 = 8080
    str_0 = "localhost"
    list_0 = bind_sockets(int_0, str_0)
    sock_0 = list_0[0]
    int_1 = 32768
    str_1 = "0.0.0.0"
    sock_1 = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock_1.bind((str_1,int_1))
    sock_1.listen(5)
    flag_0 = True
    def __handle__(connection, address):
        nonlocal count_0
        nonlocal flag_0
        count_0 += 1
        print("connection established!")

# Generated at 2022-06-26 08:35:57.585255
# Unit test for function bind_sockets
def test_bind_sockets():
    print("Test Case 0")
    test_case_0()

test_bind_sockets()

# Generated at 2022-06-26 08:36:03.415295
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    str_0 = "www.google.com"
    int_0 = 80
    res = DefaultExecutorResolver()
    future = res.resolve(str_0, int_0)
    list_0 = future.result()



# Generated at 2022-06-26 08:36:11.427502
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = Resolver()
    mapping = {"example.com": "127.0.1.1", ("login.example.com", 443): ("localhost", 1443), ("login.example.com", 443, socket.AF_INET6): ("::1", 1443)}
    host = "example.com"
    port = 443
    family = socket.AF_INET6
    print(resolver.resolve(host, port, family))

if __name__ == "__main__":
    test_case_0()
    test_OverrideResolver_resolve()

# Generated at 2022-06-26 08:36:20.011008
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    resolver = DefaultExecutorResolver()
    # future is a Future object
    future = resolver.resolve("localhost", 80)
    print(future)
    result = future.result()
    print(result)
    resolver.close()
    # [Errno 11001] getaddrinfo failed
    future = resolver.resolve("", 80)
    result = future.result()
    print(result)

# Generated at 2022-06-26 08:36:33.261459
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # Method: def resolve(self, host: str, port: int, family: socket.AddressFamily) -> List[Tuple[int, Any]]:
    #
    # Test Case
    # public String resolve(String host, int port, int family) throws IOException {
    #  		
    #  		String addressStr = this.resolveStr(host, port, family);
    #  		return addressStr;
    #  	}
    #  
    #  Test Case: 
    #  	public String resolveStr(String host, int port, int family) throws IOException {
    #  		SocketAddress address = new InetSocketAddress(host, port);
    #  		String addressStr = address.toString();
    #  		return addressStr;
    #  	}
    #
    string

# Generated at 2022-06-26 08:36:36.426733
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    exec_res = ExecutorResolver()
    exec_res.close()


# Generated at 2022-06-26 08:36:48.403818
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    list_0 = []
    tcp_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_server.bind(("127.0.0.1", 0))
    _, port = tcp_server.getsockname()
    tcp_server.listen(1)

    resolver = DefaultExecutorResolver()
    # add_callback runs resolver.resolve with a default callback
    list_0 = resolver.resolve("127.0.0.1", port)
    _ = [element.result() for element in list_0]

    resolver.close()
    tcp_server.close()


# Generated at 2022-06-26 08:36:53.302840
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_0 = dummy_executor
    close_executor_0 = False
    resolver_0 = ExecutorResolver()
    resolver_0.initialize(executor_0, close_executor_0)


# Generated at 2022-06-26 08:37:06.405390
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    # Initialization
    # ---------------
    # Run test_case_0
    test_case_0()
    # Run test case with the following parameters:
    #   socket: socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    #   ssl_options: ssl.create_default_context(purpose=ssl.Purpose.SERVER_AUTH, cafile=None, capath=None)
    #   server_hostname: None
    #   certfile: 'tests/test_filepath'
    #   keyfile: 'tests/test_filepath'
    test_case_1(socket, ssl_options, server_hostname, certfile, keyfile)



# Generated at 2022-06-26 08:37:19.092491
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    obj_0 = object()
    func_0 = (lambda a0, a1: a0)
    func_1 = (lambda a0, a1, a2: a0)
    obj_1 = (~(((obj_0 or func_0 or func_1 or obj_1) + ((obj_1 + obj_1) or (func_0 + func_0))) and obj_0) + -(-(-(-(-obj_1)))) + (((-obj_1 - (-(-obj_0))) - -(-(obj_0 + obj_0))) + (obj_1 or (obj_0 or (-obj_0 and (obj_1 - obj_1))))))
    value0 = func_0(obj_1, obj_0)
    value1 = func_1(obj_1, obj_1, obj_1)