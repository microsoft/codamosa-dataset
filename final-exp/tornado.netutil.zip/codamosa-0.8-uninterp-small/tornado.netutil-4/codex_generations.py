

# Generated at 2022-06-26 08:28:31.429968
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = ssl.SSLContext()
    context = ssl_options_to_context(ssl_options) # type: ssl.SSLContext
    assert isinstance(context, ssl.SSLContext)

test_case_0()
test_ssl_options_to_context()
print('test Passed!')

# Generated at 2022-06-26 08:28:42.329496
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    ip = '127.0.0.1'
    port = 8001
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile='cert.pem', keyfile='key.pem')
    #context.load_dh_params('dh2048.pem')
    #context.load_verify_locations('CA.pem')
    ssl_socket = ssl_wrap_socket(socket.socket(socket.AF_INET, socket.SOCK_STREAM), context)
    ssl_socket.bind((ip, port))
    ssl_socket.listen(5)
    #ssl_socket.settimeout(5)
    num_connections = 0

# Generated at 2022-06-26 08:28:46.353061
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    thread_resolver = ThreadedResolver()


# Generated at 2022-06-26 08:28:49.263825
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # This resolver must be used on a single thread
    executor = concurrent.futures.ThreadPoolExecutor()
    resolver = ExecutorResolver(executor)
    resolver.close()
# End unit test for method initialize of class ExecutorResolver



# Generated at 2022-06-26 08:28:53.980986
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    override_resolver_0 = OverrideResolver()
    try:
        dummy_future_0 = override_resolver_0.resolve("An address", 3751)
        assert False
    except NotImplementedError:
        dummy_future_0 = None
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 08:28:55.265465
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    bind_unix_socket("/tmp/test.sock")


# Generated at 2022-06-26 08:29:00.404914
# Unit test for function is_valid_ip
def test_is_valid_ip():
    print(is_valid_ip('localhost'))
    print(is_valid_ip(''))
    print(is_valid_ip('\x00'))
    print(is_valid_ip('127.0.0.1'))
    print(is_valid_ip('8.8.8.8'))
    print(is_valid_ip('::1'))
    print(is_valid_ip('2606:2800:220:1:248:1893:25c8:1946'))


# Generated at 2022-06-26 08:29:08.651293
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM,
                        proto=socket.IPPROTO_TCP)
    sock.bind(("0.0.0.0", 0))
    sock.listen(10)
    io_loop = IOLoop.current()
    def print_address(connection, address):
        print('connection: {}, address: {}'.format(connection, address))
        io_loop.stop()
    add_accept_handler(sock, print_address)
    io_loop.start()

if __name__ == '__main__':
    test_add_accept_handler()

# Generated at 2022-06-26 08:29:10.234628
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # TODO: Implement
    pass


# Generated at 2022-06-26 08:29:14.727092
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    override_resolver_0 = OverrideResolver()
    override_resolver_0.close()
    expected_result_0 = None
    assert expected_result_0 == None


# Generated at 2022-06-26 08:29:32.060246
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    defaultexecutorresolver_0 = DefaultExecutorResolver()
    # It returns a `.Future` whose result is a list of (family, address) pairs, where address is a tuple suitable to pass to `socket.connect <socket.socket.connect>` (i.e. a ``(host, port)`` pair for IPv4; additional fields may be present for IPv6). If a ``callback`` is passed, it will be run with the result as an argument when it is complete.
    defaultexecutorresolver_0.resolve("bug", 123)

    # Call method close of class DefaultExecutorResolver
    defaultexecutorresolver_0.close()


async def test_case_1():
    blocking_resolver_0 = BlockingResolver()


# Generated at 2022-06-26 08:29:33.826252
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    threaded_resolver_0 = ThreadedResolver()
    result = threaded_resolver_0.resolve('tcp://localhost:8080', 8080)
    print(result)


# Generated at 2022-06-26 08:29:38.913341
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    s = b'\x00\x00\x04\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x07\x65\x78\x61\x6d\x70\x6c\x65\x03\x63\x6f\x6d\x00\x00\x01\x00\x01'
    ip = "example.com"
    s_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s_sock.bind(("192.168.0.2", 0))  # This fixes the issues.
    s_sock.sendto(s, ("192.168.0.2", 53))
    data, addr= s_sock

# Generated at 2022-06-26 08:29:44.637334
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver_0 = DefaultExecutorResolver()
    # See method resolve of class Resolver
    # Tests here raise exceptions
    # test_utils.py has tests for these
    # Test args
    host: str = "www.google.com"
    port: int = 80
    family: Any = ""
    await resolver_0.resolve(host, port, family)


# Generated at 2022-06-26 08:29:52.024649
# Unit test for function add_accept_handler
def test_add_accept_handler():
    io_loop = IOLoop.current()
    
    def test_callback(fd, events):
        # print('in test_callback')
        pass 

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.listen(10)
    sock.setblocking(False)
    addr = ('localhost', 8090)
    sock.bind(addr)
    sock.listen()

    remove_handler = add_accept_handler(sock, test_callback)
    io_loop.start()
    
    
    



# Generated at 2022-06-26 08:30:03.487059
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    port = 9080
    host = 'localhost'
    executor = dummy_executor
    close_executor = False
    expected_type = ExecutorResolver
    expected_type = ExecutorResolver
    # ExecutorResolver.initialize( executor = dummy_executor, close_executor = False )
    resolver = ExecutorResolver(executor, close_executor)
    # resolver.resolve( host = 'localhost', port = 9080 ) must return type <class 'list'>
    future = resolver.resolve(host, port)
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    results = loop.run_until_complete(future)
    type_of_results = type(results)
    assert type_of_results == list
    #

# Generated at 2022-06-26 08:30:10.786364
# Unit test for function add_accept_handler
def test_add_accept_handler():
    port = 12345
    socket_set = bind_sockets(port)
    def test_callback(connection: socket.socket, address: str) -> None:
        print('connection',connection)
        print('address',address)
    remove_handler = add_accept_handler(socket_set[0],test_callback)
    print(remove_handler)


# Generated at 2022-06-26 08:30:19.579078
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    print("Testing", inspect.currentframe().f_code.co_name)
    resolver = DefaultExecutorResolver()
    loop = IOLoop.current()
    future = resolver.resolve("localhost", 8080)
    loop.run_until_complete(future)
    addresses = future.result()
    print("Found addresses", addresses)
    resolver.close()



# Generated at 2022-06-26 08:30:26.237122
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    # function call
    ssl_options_to_context_0 = ssl_options_to_context(
        {
            "keyfile": "keyfile",
            "ssl_version": ssl.PROTOCOL_SSLv2,
            "ca_certs": "ca_certs",
            "cert_reqs": ssl.CERT_OPTIONAL,
            "ciphers": "ciphers",
            "certfile": "certfile",
        }
    )


# Generated at 2022-06-26 08:30:38.297694
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    from tornado.concurrent import Future
    from tornado.netutil import Resolver as Resolver
    from typing import List, Tuple, Type, Union, Dict
    from typing import Callable
    from typing import IO
    future_0 = Future()  # type: Future
    host = None  # type: Union[str, bytes]
    port = None  # type: int
    family = socket.AF_UNSPEC  # type: socket.AddressFamily
    future_0 = Resolver.resolve(host, port, family)
    assert type(future_0) is Future 


# Generated at 2022-06-26 08:31:02.152677
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Bind the socket to the port
    server_address = ('localhost', 10000)
    print('starting up on {} port {}'.format(*server_address))
    sock.bind(server_address)
    # Listen for incoming connections
    sock.listen(1)
    # Wait for a connection
    print('waiting for a connection')
    connection, client_address = sock.accept()
    print('connection from', client_address)
    # Receive the data in small chunks and retransmit it
    while True:
        try:
            data = connection.recv(16)
        except ConnectionResetError as e:
            print('receive data error')

# Generated at 2022-06-26 08:31:06.030996
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import ssl
    # Create an SSL Context.
    ssl_ctx = ssl_wrap_socket(None, None)


# This context manager class is created for a ssl socket socket

# Generated at 2022-06-26 08:31:19.595716
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    context_0 = ssl_options_to_context(   {
        "ssl_version": "ssl.PROTOCOL_SSLv23",
        "certfile": "",
        "keyfile": None,
        "cert_reqs": "",
        "ca_certs": ""
        }
    )
    context_1 = ssl_options_to_context(   {
        "ssl_version": "ssl.PROTOCOL_SSLv23",
        "certfile": "",
        "keyfile": "",
        "cert_reqs": "",
        "ca_certs": ""
        }
    )

if __name__ == "__main__":
    test_case_0()
    test_ssl_options_to_context()

# Generated at 2022-06-26 08:31:23.447735
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Variables to test
    executor = dummy_executor
    close_executor = True # True or False
    ExecutorResolver.initialize(executor,close_executor)

# Generated at 2022-06-26 08:31:30.227894
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Initialize class
    threaded_resolver = ThreadedResolver()
    # Execute method
    threaded_resolver.initialize()
    # Check the result
    assert threaded_resolver.io_loop == IOLoop.current()
    assert isinstance(threaded_resolver.executor, concurrent.futures.Executor)
    assert threaded_resolver.close_executor == True

# Be careful, the `threaded_resolver.resolve` cannot be executed.

# Generated at 2022-06-26 08:31:38.351593
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver_0 = ExecutorResolver()
    resolver_0.close()
    # Check if the executor is closed after the close() method is called.
    assert resolver_0.executor == None


# Generated at 2022-06-26 08:31:44.679192
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Create a server socket
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM);
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_sock.setblocking(0)
    server_address = ('localhost', 12000)
    server_sock.bind(server_address)
    server_sock.listen(1)

    # Create a client socket
    client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_sock.connect(server_address)

    # Accept the connection on server side
    def callback(connection: socket.socket, address: Tuple[str, int]) -> None:
        print(address)
        print

# Generated at 2022-06-26 08:31:57.245460
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Test case 0
    # First test: Try to generate a conection and accept it
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(False)
    sock.bind(("localhost", 0))
    sock.listen(10)
    port = sock.getsockname()[1]
    # Connect to the port
    conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    conn.connect(("localhost", port))
    # Check if we can accept it

# Generated at 2022-06-26 08:32:01.254354
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    threaded_resolver = ExecutorResolver()
    loop = IOLoop.current()
    host = 'localhost'
    port = 80
    #family = socket.AF_UNSPEC
    family = 0
    result_future = threaded_resolver.resolve(host, port, family)
    result_list = loop.run_until_complete(result_future)
    print(result_list)


# Generated at 2022-06-26 08:32:05.917734
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # TODO: replace with real test
    threaded_resolver_0 = ThreadedResolver()

    host = ""
    port = 0
    family = socket.AF_UNSPEC
    future = threaded_resolver_0.resolve(host, port, family)
    result = future.result()
    assert result is not None



# Generated at 2022-06-26 08:32:39.446708
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor)
    assert resolver.executor == dummy_executor
    assert resolver.close_executor == True


# Generated at 2022-06-26 08:32:43.976630
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    executor_resolver_0 = DefaultExecutorResolver()

    # Test case 0
    test_case_0()



# Generated at 2022-06-26 08:32:49.825069
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    _host = 'google.com'
    _port = 80
    _family = socket.AF_INET
    threaded_resolver = ThreadedResolver()
    res = threaded_resolver.resolve(_host, _port, _family)
    print("test_ExecutorResolver_resolve: ", res)


# Generated at 2022-06-26 08:32:57.019358
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = ThreadedResolver()
    mapping = {
        # Hostname to host or ip
        "example.com": "127.0.1.1",
        # Host+port to host+port
        ("login.example.com", 443): ("localhost", 1443),
        # Host+port+address family to host+port
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    override_resolver = OverrideResolver(resolver=resolver, mapping=mapping)
    #host = "example.com"
    #port = 1234
    #loop = IOLoop.current()
    #result = loop.run_until_complete(override_resolver.resolve(host, port))
    #print(result)


# Generated at 2022-06-26 08:33:01.170055
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(1234, "localhost")
    sockets[0].close()
    pass

if __name__ == "__main__":
    test_case_0()
    test_bind_sockets()

# Generated at 2022-06-26 08:33:14.595305
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # Test normal socket.getaddrinfo
    address_pairs = [(socket.AF_INET, ("127.0.0.1", 80))]
    # Default implementation of Resolver is DefaultExecutorResolver
    resolver = Resolver()
    ret = IOLoop.current().run_sync(lambda: resolver.resolve("localhost", 80))
    assert ret == address_pairs

    # Test blocking resolver
    resolver = BlockingResolver()
    ret = IOLoop.current().run_sync(lambda: resolver.resolve("localhost", 80))
    assert ret == address_pairs

    # Test threaded resolver
    resolver = ThreadedResolver()
    ret = IOLoop.current().run_sync(lambda: resolver.resolve("localhost", 80))
    assert ret == address_pairs



# Generated at 2022-06-26 08:33:26.700790
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    threaded_resolver_1 = ThreadedResolver()
    #host = 'localhost'
    #host = 'www.google.com'
    host = '127.0.0.1'
    port = 8080
    family = socket.AF_UNSPEC
    future = threaded_resolver_1.resolve(host, port, family)
    # Convert the future object to list, otherwise the verifycation cannot
    # handle the future object.
    try:
        result = future.result()
    except:
        result = future.result()
    #print(result)
    #print(type(result))
    #print(len(result))
    assert_equal(len(result), 2)
    assert_equal(result[0][0], socket.AF_INET)

# Generated at 2022-06-26 08:33:32.546625
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(12345, '')
    print("binding port 12345 succeeded")
    for s in sockets:
        s.close()


# Generated at 2022-06-26 08:33:39.431511
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_dict = {'ssl_version': ssl.PROTOCOL_SSLv23,
                'certfile': '/Users/gaoyang/Desktop/Tornado/tests/testcert.pem',
                'keyfile': '/Users/gaoyang/Desktop/Tornado/tests/testcert.pem',
                'cert_reqs': 'CERT_NONE',
                'ca_certs': '/Users/gaoyang/Desktop/Tornado/tests/testcert.pem',
                'ciphers':  'CBC'}

    ssl_context_0 = ssl_options_to_context(ssl_dict)

    assert ssl_context_0.verify_mode == ssl.CERT_NONE
    assert ssl_context_0.protocol == ssl.PROTOCOL

# Generated at 2022-06-26 08:33:42.354926
# Unit test for function bind_sockets
def test_bind_sockets():
    print('test_bind_sockets:')
    sockets = bind_sockets(port=8888)
    local_ip_list = get_local_ip_list()
    print(sockets)
    print(local_ip_list)
    print('-' * 20)



# Generated at 2022-06-26 08:34:19.612055
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    socket_0 = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    ssl_options_0 = dict()
    ssl_options_0['ssl_version'] = ssl.PROTOCOL_SSLv23
    ssl_wrap_socket(socket_0,ssl_options_0)


# Generated at 2022-06-26 08:34:23.286341
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    threaded_resolver_1 = ExecutorResolver()
    threaded_resolver_1.close()


# Generated at 2022-06-26 08:34:27.080691
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_obj = ExecutorResolver()
    executor_resolver_obj.close()



# Generated at 2022-06-26 08:34:37.513131
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import time

    def on_accepted(conn, address):
        print("accept from %s:%s" % address)
        conn.send(b"hello\n")

    def on_client_connection(connection, address):
        print("Client connection")
        data = connection.recv(1024)
        print("Client data: %s" % data)

    loop = IOLoop.current()
    # server socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    server_socket.bind(("localhost", 1234))
    server_socket.listen(10)
    add_accept_handler(server_socket, on_accepted)
    # client socket

# Generated at 2022-06-26 08:34:39.892541
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    m = {('login.example.com', 443): ("localhost", 1443)}
    resolver = OverrideResolver(threaded_resolver_0, mapping = m)


# Generated at 2022-06-26 08:34:43.072540
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    exector = ExecutorResolver()
    exector.close()


# Generated at 2022-06-26 08:34:52.498763
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # 1. test for multiple threads
    resolver_1 = ExecutorResolver()
    resolver_1.initialize()
    executor_1: Future = resolver_1.executor
    resolver_2 = ExecutorResolver()
    resolver_2.initialize()
    executor_2: Future = resolver_2.executor
    assert executor_1 != executor_2
    # 2. test for the same executor
    resolver_3 = ExecutorResolver()
    resolver_3.initialize(executor_1, close_executor=False)
    executor_3: Future = resolver_3.executor
    assert executor_1 == executor_3
    resolver_1.close()
    resolver_3.close()


# Generated at 2022-06-26 08:34:57.347804
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # assert that resolve returns an awaitable object.
    fp = OverrideResolver(None, None)
    assert asyncio.iscoroutinefunction(fp.resolve)


# Generated at 2022-06-26 08:35:05.924733
# Unit test for function bind_sockets
def test_bind_sockets():
    # Call bind_sockets with port and address
    bindsock_port_address = bind_sockets(8000, address="127.0.0.1")
    # Check length of the returned list
    assert len(bindsock_port_address) == 1
    # Check the tuple representation of the returned socket
    sock_family, sock_type, sock_proto, sock_addr, sock_canonname = \
        bindsock_port_address[0].getsockname()
    assert sock_addr[0] == "127.0.0.1"
    assert sock_addr[1] == 8000
    # Verify the default backlog value
    assert bindsock_port_address[0].getsockopt(socket.SOL_SOCKET, socket.SO_BACKLOG) == 128

    # Call bind_sockets with port only
    bindsock

# Generated at 2022-06-26 08:35:17.189459
# Unit test for function bind_sockets
def test_bind_sockets():
    port = 8888
    res = bind_sockets(port)
    print("result: ", res)
    for sock in res:
        print("sock: ", sock)
        print("family: ", sock.family)
        print("type: ", sock.type)
        print("fileno: ", sock.fileno())
        #print("proto: ", sock.proto)

    port = 8887
    res = bind_sockets(port)
    print("result: ", res)
    for sock in res:
        print("sock: ", sock)
        print("family: ", sock.family)
        print("type: ", sock.type)
        print("fileno: ", sock.fileno())
        #print("proto: ", sock.proto)


# Generated at 2022-06-26 08:36:11.102812
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    print("test_ssl_options_to_context")
    pass

async def test():
    print("test")
    pass


# Generated at 2022-06-26 08:36:16.599273
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    ssl_options = dict()
    ssl_wrap_socket(s, ssl_options)

# Generated at 2022-06-26 08:36:21.603064
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Check that our implementation of close actually calls shutdown
    # on the executor, and that the shutdown call is actually made.
    executor = mock.MagicMock()
    resolver = ExecutorResolver(executor)
    resolver.close()
    executor.shutdown.assert_called_once_with()


# Generated at 2022-06-26 08:36:24.675658
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    threaded_resolver_0 = ThreadedResolver()
    override_resolver_0 = OverrideResolver(threaded_resolver_0, dict())
    override_resolver_0.resolve("", 0)
    # This line is throwing an error on cpython. We're not
    # sure why, so we are commenting it out for now.
    #override_resolver_0.resolve("", 0, 1)

# Generated at 2022-06-26 08:36:32.148255
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    threaded_resolver_1 = ThreadedResolver()
    loop_1 = IOLoop.current()

    @gen.coroutine
    def test_method_of_class_executor_resolver_1():
        result = yield threaded_resolver_1.resolve("localhost", 80)
        print(result)

    loop_1.run_sync(test_method_of_class_executor_resolver_1)



# Generated at 2022-06-26 08:36:44.681644
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # 1. bind_sockets
    #    Creates listening sockets bound to the given port and address.
    #    Returns a list of socket objects (multiple sockets are returned if
    #    the given address maps to multiple IP addresses, which is most common
    #    for mixed IPv4 and IPv6 use).
    sockets_list_0 = bind_sockets(8983, '127.0.0.1') # list length: 1

    # 2. add_accept_handler
    #    Adds an `.IOLoop` event handler to accept new connections on ``sock``.
    #    When a connection is accepted, ``callback(connection, address)`` will
    #    be run (``connection`` is a socket object, and ``address`` is the
    #    address of the other end of the connection).  Note that this signature
    #    is different

# Generated at 2022-06-26 08:36:56.246607
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = None # type: Any
    mapping = {
            ('example.com', 80): ('localhost', 1443),
            ('example.xn--com-pta.com', 80): ('localhost', 1443),
            ('example.com', 443): ('127.0.0.1', 1443),
            ('example.com', 443, socket.AF_INET6): ('127.0.0.1', 1443),
            ('localhost', 80): ('127.0.0.1', 1443),
            ('localhost', 80, socket.AF_INET6): ('127.0.0.1', 1443)
    }

    def check_result(result):
        assert result[0][0] == socket.AF_INET
        assert result[0][1][0] == 'localhost'

# Generated at 2022-06-26 08:37:08.314228
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    _host = "943gzlAKR1"
    _port = 60723
    _family = socket.AF_INET
    try:
        result = default_executor_resolver_0.resolve(_host, _port, _family)
    except Exception as e:
        if isinstance(e, IOError):
            assert True
        else:
            assert False
    else:
        assert False


if hasattr(socket, "AF_INET6"):

    def test_DefaultExecutorResolver_resolve_0():
        default_executor_resolver_0 = DefaultExecutorResolver()
        _host = "[::1]"
        _port = 60723
        _family = socket.AF_INET6

# Generated at 2022-06-26 08:37:13.458627
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def on_connection(connection: socket.socket, address: Any) -> None:
        print(connection, address)

    # Create a socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Bind the socket to port 9999
    server_address = ('localhost', 9999)
    print('starting up on %s port %s' % server_address)
    sock.bind(server_address)

    # Listen for incoming connections
    sock.listen(1)

    # add a event handler to accept new connections on sock
    remove_handler = add_accept_handler(sock, on_connection)

    # remove_handler()

    # remove_handler = add_accept_handler(sock, on_connection)


# Generated at 2022-06-26 08:37:15.039134
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    pass
