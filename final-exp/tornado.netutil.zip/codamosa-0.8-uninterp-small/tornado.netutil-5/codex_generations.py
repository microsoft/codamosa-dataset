

# Generated at 2022-06-26 08:28:14.349283
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    override_resolver_0 = OverrideResolver()
    try:
        override_resolver_0.close()
    except Exception as inst:
        print(inst)
        raise


# Generated at 2022-06-26 08:28:19.879081
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    threaded_resolver = ThreadedResolver()
    override_resolver = OverrideResolver(threaded_resolver, {"www.google.com": "127.0.0.1"})
    response = override_resolver.resolve("www.google.com", 80)


# Generated at 2022-06-26 08:28:27.661723
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()
    assert isinstance(executor_resolver_0.io_loop, IOLoop)
    assert isinstance(executor_resolver_0.executor, dummy_executor)
    assert executor_resolver_0.close_executor == True
    assert resolver.resolve == ExecutorResolver.resolve
    assert resolver.close == ExecutorResolver.close
    assert resolver.initialize == ExecutorResolver.initialize
    assert resolver.initialize == ExecutorResolver.initialize


# Generated at 2022-06-26 08:28:32.642439
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    try:
        test_class_0 = Resolver()
        str_0 = "afnetworking.github.io"
        int_0 = 80
        family = None
        future_0 = test_class_0.resolve(str_0, int_0, family)
        if (future_0 is not None):
            ip_address_list_0 = future_0.result()
            print(ip_address_list_0)
        else:
            print("future is none")
    except Exception as exception_0:
        print(exception_0)

if (__name__ == '__main__'):
    test_Resolver_resolve()

# Generated at 2022-06-26 08:28:34.675459
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    threaded_resolver_0 = ThreadedResolver()
    threaded_resolver_0.resolve('www.baidu.com', 80)



# Generated at 2022-06-26 08:28:40.343668
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor()
    close_executor = True
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize(executor, close_executor)
    executor_resolver_0.close()


# Generated at 2022-06-26 08:28:53.914639
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    print("\nUnit test for method close of class OverrideResolver:")
    print("Test case 0: ")

    resolver_0 = OverrideResolver(DefaultExecutorResolver, {socket.AF_INET})
    try:
        resolver_0.close()
    except:
        print("Exception: ", sys.exc_info())

    print("Test case 1: ")

    resolver_1 = OverrideResolver(ThreadedResolver, {socket.AF_INET6})
    resolver_1.close()

    print("Test case 2: ")

    resolver_2 = OverrideResolver(BlockingResolver, {socket.AF_INET6})
    try:
        resolver_2.close()
    except:
        print("Exception: ", sys.exc_info())


# Generated at 2022-06-26 08:29:06.422934
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import os
    import socket
    import pickle
    import sys
    import getpass
    #import pdb
    #pdb.set_trace()

# Generated at 2022-06-26 08:29:13.532920
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    threaded_resolver_0 = ThreadedResolver()
    threaded_resolver_0.initialize()
    #resolver = ThreadedResolver()
    #resolver.initialize(io_loop=self.io_loop)
    #self.io_loop.run_sync(lambda: resolver.resolve("example.com", 80))
    #self.io_loop.run_sync(lambda: threaded_resolver_0.resolve("localhost",  30120))
    threaded_resolver_0.resolve("localhost",  30120)
    threaded_resolver_0.close()


# Generated at 2022-06-26 08:29:17.137061
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    override_resolver_0 = OverrideResolver()
    try:
        override_resolver_0.close()
    except Exception as err:
        raise Exception(err)


# Generated at 2022-06-26 08:29:32.982923
# Unit test for function add_accept_handler
def test_add_accept_handler():
    host_0 = 'localhost'
    port_0 = 9999
    client_0 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_0.setblocking(False)
    server_0 = bind_sockets(port_0, host_0)[0]
    server_0.setblocking(False)
    loop_0 = IOLoop.current()
    def on_connected_0():
        pass

    def on_client_connected_0():
        client_0.close()
    
    def on_connect_0():
        server_0.close()
        loop_0.stop()
    
    # connect the client to server
    def test_case_0():
        client_0.connect_ex(('localhost', port_0))
        loop_0.add_handler

# Generated at 2022-06-26 08:29:40.268164
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    print(">> RUNNING UNIT TEST FOR DefaultExecutorResolver.resolve()")
    time.sleep(1)
    resolver_0 = DefaultExecutorResolver()
    loop_0 = IOLoop.current()
    future_0 = resolver_0.resolve("google.com", 443)
    loop_0.run_sync(future_0)
    print(">> COMPLETED UNIT TEST FOR DefaultExecutorResolver.resolve()")

# Unit tests for method __init__ of class DefaultExecutorResolver

# Generated at 2022-06-26 08:29:49.812818
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Initilisation
    resolver = OverrideResolver(mapping={"example.com": "127.0.1.1", ("login.example.com", 443): ("localhost", 1443), ("login.example.com", 443, socket.AF_INET6): ("::1", 1443)})

    # Run test function
    result = resolver.resolve(host="example.com", port=0)

    # Assertions
    assert isinstance(result, Awaitable)
    assert isinstance(result, object)
    assert callable(result)


# Generated at 2022-06-26 08:29:52.973070
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    # Asynchronous resolve
    # await resolver.resolve(host, port, family)

    # Check result
    print('Add unit tests here.')


if __name__ == '__main__':
    test_case_0()
    test_DefaultExecutorResolver_resolve()

# Generated at 2022-06-26 08:29:58.321130
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    # Instantiate a DefaultExecutorResolver
    default_executor_resolver = DefaultExecutorResolver()
    default_executor_resolver.resolve("www.google.com", 80)
    # Call resolve method
    #result = default_executor_resolver.resolve("www.google.com", 80)
    # Check the result
    #if not isinstance(result, Future):
    #    print("Test 1 fails!")



# Generated at 2022-06-26 08:30:03.244857
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 7777))
    sock.listen()

    loop = IOLoop.current()
    def callback(connection, address):
        print(connection, address)
    add_accept_handler(sock, callback)
    loop.start()


# Generated at 2022-06-26 08:30:13.949265
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver_0 = DefaultExecutorResolver()
    __host = "127.0.0.1"
    __port = 8080
    __family = socket.AF_INET
    loop_0 = IOLoop()
    # await
    result = loop_0.run_sync(lambda: resolver_0.resolve(__host, __port, __family))
    assert len(result) == 1
    assert result[0][0] == socket.AF_INET
    assert result[0][1][0] == "127.0.0.1"
    assert result[0][1][1] == 8080
    loop_0.close()
    print("[OK] - test_DefaultExecutorResolver_resolve")


# Generated at 2022-06-26 08:30:24.997573
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():

    from tornado.testing import AsyncTestCase, gen_test
    import asyncio

    resolver = Resolver()
    mapping = {
        ("127.0.0.1", 80): ("localhost", 1580),
        "example.com": "127.0.1.1",
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    resolver.initialize(Resolver(), mapping)

    def test_case_0():
        host = "example.com"
        port = 80
        resolver.resolve(host, port)

    def test_case_1():
        host = "login.example.com"
        port = 443
        family = socket.AF_INET6
        resolver.resolve(host, port, family)

    test_

# Generated at 2022-06-26 08:30:27.340131
# Unit test for function bind_sockets
def test_bind_sockets():
    # Case 0
    print("Running Case 0:")
    test_case_0()
    print("\n")

if __name__ == "__main__":
    test_bind_sockets()

# Generated at 2022-06-26 08:30:41.395297
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import threading
    import time
    import logging

    def callback(connection, address):
        logging.info("In Thread %d: Connection Received: %d from %s" %
                     (threading.get_ident(), connection, address))
        time.sleep(5)
        connection.close()

    def main():
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_sock.bind(('localhost', 8991))
        server_sock.listen(10)
        server_sock.setblocking(True)
        logging.info("server_sock = %d" % server_sock.fileno())

# Generated at 2022-06-26 08:31:04.639667
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def my_callback(connection: socket.socket, address: Any) -> None:
        print(connection)
        print(connection.getsockname())
        print(address)
        connection = None # The socket is closed

    # If all is well, the above print statement should be executed twice,
    # once for the two connections in the loop, and once for the connection
    # that was forced to close.

    sock = socket.socket()
    sock.setblocking(False)
    sock.bind(('localhost', 0))
    sock.listen(1)
    add_accept_handler(sock, my_callback)
    IOLoop.current().start()

    for i in range(2):
        sock_client = socket.socket()
        sock_client.connect(sock.getsockname())
        sock_client.close()



# Generated at 2022-06-26 08:31:13.442864
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_0 = dummy_executor
    close_executor_0 = True
    threaded_resolver_0 = ThreadedResolver()
    threaded_resolver_0.initialize(executor_0, close_executor_0)
    threaded_resolver_0.close()
    # The default Resolver now uses .IOLoop.run_in_executor; use that instead of this class.
    # assert isinstance(threaded_resolver_0.executor, dummy_executor)


# Generated at 2022-06-26 08:31:15.547671
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    obj = OverrideResolver()
    obj.close()


# Generated at 2022-06-26 08:31:17.079831
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver_0 = OverrideResolver()
    resolver_0.resolve("", 0)


# Generated at 2022-06-26 08:31:22.548538
# Unit test for function add_accept_handler
def test_add_accept_handler():
    from tornado.iostream import IOStream
    from tornado.tcpclient import TCPClient

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.setblocking(0)
    server_socket.bind(("127.0.0.1", 0))
    server_socket.listen(128)

    port = server_socket.getsockname()[1]

    client = TCPClient()
    stream = client.connect("127.0.0.1", port)
    def f():
        try:
            return (yield stream.read_bytes(1024, partial=True))
        except IOError:
            return b""

   

# Generated at 2022-06-26 08:31:27.806606
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # Note: If a singleton ExecutorResolver is reused across tests, then it
    # might be necessary to close the resolver before the next test.
    resolver = ExecutorResolver()
    future = resolver.resolve('www.python.org', 80)
    loop = IOLoop.current()
    loop.run_sync(future)
    resolver.close()


# Generated at 2022-06-26 08:31:32.013483
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    threaded_resolver_0 = ThreadedResolver()
    mapping = dict()
    override_resolver_0 = OverrideResolver(threaded_resolver_0,mapping)
    override_resolver_0.resolve("www.google.com", 80)
    override_resolver_0.close()
    threaded_resolver_0.close()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:31:41.038468
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    import unittest
    from . import DefaultExecutorResolver
    from . import OverrideResolver
    
    # TODO: Find way to construct OverrideResolver without AsyncResolver
    # instead of using a mock object
    resolver = Mock()
    mapping = {}
    overrideResolver = OverrideResolver(resolver, mapping)
    assert overrideResolver is not None
    overrideResolver.close()


# Generated at 2022-06-26 08:31:52.276176
# Unit test for function add_accept_handler
def test_add_accept_handler():

    def accept_handler(connection,address):
        print(connection)
        print(address)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.bind(('127.0.0.1', 10010))
    print("bind to 127.0.0.1:10010")
    sock.listen(5)
    print("listened")
    remove_handler = add_accept_handler(sock,accept_handler)
    print("done")



# Generated at 2022-06-26 08:31:56.301243
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    try:
        bind_unix_socket('/tmp/unix_socket')
    except:
        return True
    return False


# Generated at 2022-06-26 08:32:14.311815
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver_0 = ThreadedResolver()
    override_resolver_0 = OverrideResolver()
    override_resolver_0.close()


# Generated at 2022-06-26 08:32:25.885064
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver_0 = ThreadedResolver()
    mapping_0 = dict()
    override_resolver_0 = OverrideResolver(resolver_0, mapping_0)
    host_0 = "www.google.com"
    port_0 = 80
    family_0 = None
    awaitable_0 = override_resolver_0.resolve(host_0, port_0, family_0)
    # The following print statement is expected to be replaced by analysis code
    print(awaitable_0)


# Generated at 2022-06-26 08:32:29.167471
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8765)
    sockets[0].close()
    sockets[1].close()


# Generated at 2022-06-26 08:32:37.902830
# Unit test for function is_valid_ip
def test_is_valid_ip():
    test_ip_0 = "192.168.2.2"
    assert is_valid_ip(test_ip_0)

    test_ip_1 = "1993.168.2.2"
    assert not is_valid_ip(test_ip_1)

    test_ip_2 = "192.1689.2"
    assert not is_valid_ip(test_ip_2)


# Generated at 2022-06-26 08:32:43.572539
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    threaded_resolver_0 = ThreadedResolver()
    override_resolver_1 = OverrideResolver(threaded_resolver_0, {})
    override_resolver_1.close()



# Generated at 2022-06-26 08:32:48.609332
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    threaded_resolver = ThreadedResolver()
    #Function can return None, which is fine
    ret = threaded_resolver.resolve("127.0.0.1",0)



# Generated at 2022-06-26 08:32:53.412103
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    #.Test.rq:1
    executor_resolver = ExecutorResolver()
    #.Test.rq:2
    executor_resolver.close()



# Generated at 2022-06-26 08:33:01.129659
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    # Loop0
    # value1: host
    host = "www.google.com"
    # value2: port
    # value3: family
    # result: c
    c = default_executor_resolver_0.resolve(host, port, family)
    return c



# Generated at 2022-06-26 08:33:05.829451
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(8888)
    print("Size of sockets:", len(sockets))
    assert len(sockets) == 2


# Generated at 2022-06-26 08:33:16.135038
# Unit test for function bind_sockets
def test_bind_sockets():
    print("Test case : test_bind_sockets")
    # listen on IPv4/6 address
    sockets = bind_sockets(8888)
    assert len(sockets) ==1
    # test reuse_port option
    sockets_reuse_port = bind_sockets(8888, reuse_port=True)
    assert len(sockets_reuse_port) == 1

    # listen on IPv4 specific address
    sockets_ipv4 = bind_sockets(8888, 'localhost')
    assert len(sockets_ipv4) == 1

    # listen on IPv6 specific address
    sockets_ipv6 = bind_sockets(8888, '::1')
    assert len(sockets_ipv6) == 1

    # listen on all IPv4 interfaces
    sockets_ipv4_all = bind_sockets

# Generated at 2022-06-26 08:33:36.775454
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # Test for method resolve
    # Test for comment of method execute_command for Jython version lower then 2.7
    if sys.version_info[0] == 2 and sys.version_info[1] <= 6:
        # Jython version before 2.7 does not support concurrent.futures.Executor
        return

    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.resolve("wW.gOOGle.cOm.", 80, socket.AF_UNSPEC)


# Generated at 2022-06-26 08:33:39.612937
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options_to_context({ "keyfile": "./context_key_1" })


# Generated at 2022-06-26 08:33:40.879212
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("10.10.10")



# Generated at 2022-06-26 08:33:50.325287
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    class ValueResolver(Resolver):
        async def resolve(
            self, host: str, port: int, family: socket.AddressFamily = socket.AF_UNSPEC
        ) -> List[Tuple[int, Any]]:
            if (host, port, family) in self.mapping:
                host, port = self.mapping[(host, port, family)]
            elif (host, port) in self.mapping:
                host, port = self.mapping[(host, port)]
            elif host in self.mapping:
                host = self.mapping[host]
            return self.resolver.resolve(host, port, family)

        def initialize(self, resolver: Resolver, mapping: dict) -> None:
            self.resolver = resolver
            self.mapping = mapping
        
       

# Generated at 2022-06-26 08:33:54.650925
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    run_test(test_case_0, 'test_ExecutorResolver_close')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 08:33:57.691079
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_1: Optional[concurrent.futures.Executor] = None
    close_executor_1: bool = True
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize(executor_1, close_executor_1)


# Generated at 2022-06-26 08:34:07.973312
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Case 0
    threaded_resolver_0 = ThreadedResolver()
    # Case 1
    threaded_resolver_1 = ThreadedResolver()
    threaded_resolver_1.initialize()
    # Case 2
    threaded_resolver_2 = ThreadedResolver()
    threaded_resolver_2.initialize(executor = dummy_executor, close_executor = True)
    # Case 3
    threaded_resolver_3 = ThreadedResolver()
    threaded_resolver_3.initialize(executor = dummy_executor, close_executor = False)
    # Case 4
    threaded_resolver_4 = ThreadedResolver()
    threaded_resolver_4.initialize(executor = dummy_executor)
    # Case 5
    threaded_resolver_5 = ThreadedResolver()

# Generated at 2022-06-26 08:34:11.285848
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.close()


# Generated at 2022-06-26 08:34:16.761235
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = concurrent.futures.Executor()
    close_executor = True
    exec_resolver = ExecutorResolver()
    resolver = exec_resolver.initialize(executor, close_executor)
    assert resolver
    return resolver


# Generated at 2022-06-26 08:34:26.948158
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():

    # the first argument host is of type string, it is required.
    # the second argument port is of type int, it is required.
    # the third argument family is of type socket.AddressFamily, it is required.
    # the return value is of type Future
    # raise NotImplementedError if not implemented

    #r = Resolver()
    #return r.resolve(host, port, family)
    pass



# Generated at 2022-06-26 08:34:37.538887
# Unit test for function add_accept_handler
def test_add_accept_handler():
    test_case_0()


# Generated at 2022-06-26 08:34:38.953567
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResolver()
    resolver.close()


# Generated at 2022-06-26 08:34:50.960656
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    threaded_resolver_0 = ThreadedResolver()
    # Line OverrideResolver.initialize (line 445)
    # Line ThreadedResolver.initialize (line 465)
    var_tuple_0 = threaded_resolver_0.initialize()
    override_resolver_0 = OverrideResolver()
    # Line OverrideResolver.initialize (line 445)
    var_tuple_1 = override_resolver_0.initialize(threaded_resolver_0, {})
    # Line OverrideResolver.close (line 459)
    # Line ThreadedResolver.close (line 479)
    override_resolver_0.close()


# Generated at 2022-06-26 08:35:02.817765
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def log_connection(conn: socket.socket, address: Any) -> None:
        print("New connection:", conn, address)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.bind(("127.0.0.1", 0))
    sock.listen(128)
    port = sock.getsockname()[1]

    add_accept_handler(sock, log_connection)
    for i in range(3):
        conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        conn.connect(("127.0.0.1", port))

    IOLoop.current().start()



# Generated at 2022-06-26 08:35:15.196819
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    # Create a server socket
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('', 8088))
    server.listen(5)

    # Create a client socket
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(('', 8088))

    server_ssl_socket = ssl_wrap_socket(server, ssl_options={})
    client_ssl_socket = ssl_wrap_socket(client, ssl_options={})

if __name__ == "__main__":
    test_case_0()
    test_ssl_wrap_socket()

# Generated at 2022-06-26 08:35:25.162526
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    SSL_OPTION_DICT = {
        "ssl_version": ssl.PROTOCOL_TLSv1_2,
        "certfile": None,
        "keyfile": None,
        "cert_reqs": ssl.CERT_REQUIRED,
        "ca_certs": None,
        "ciphers": None
    }
    ssl_options_to_context(SSL_OPTION_DICT)

if __name__ == "__main__":
    # test_case_0()
    test_ssl_options_to_context()

# Generated at 2022-06-26 08:35:36.137459
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback1(connection, address):
        print("connection")
        print(connection)
        print("address")
        print(address)
    sock = bind_sockets(port=5432, address='localhost')
    print(sock)
    remove_handler = add_accept_handler(sock[0], callback1)
    remove_handler()
    sock = bind_sockets(port=5433, address='localhost')
    print(sock)
    remove_handler = add_accept_handler(sock[0], callback1)
    remove_handler()


# Generated at 2022-06-26 08:35:48.862289
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver_0 = DefaultExecutorResolver()
    exec_result_0 = resolver_0.resolve('www.google.com', 80)    
    print(exec_result_0)
    resolver_1 = DefaultExecutorResolver()
    exec_result_1 = resolver_1.resolve('www.google.com', 80, socket.AF_INET)    
    print(exec_result_1)
    resolver_2 = DefaultExecutorResolver()
    exec_result_2 = resolver_2.resolve('www.google.com', 80, socket.AF_UNSPEC)    
    print(exec_result_2)
    resolver_3 = DefaultExecutorResolver()

# Generated at 2022-06-26 08:36:01.258589
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    executor = concurrent.futures.ThreadPoolExecutor(
        max_workers=10
    )
    resolver = ExecutorResolver(executor, True)
    # Test normal case
    future = resolver.resolve('google.com', 80)
    result = future.result()
    # Test None case
    future = resolver.resolve('google.com', 80, None)
    result = future.result()
    # Test wrong data type case
    future = resolver.resolve(123.4, 80)
    result = future.result()
    # Test wrong data type case
    future = resolver.resolve('google.com', 3.14)
    result = future.result()


# Generated at 2022-06-26 08:36:12.193058
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import socket
    import sys
    import threading
    import logging
    logs = []
    def callback(connect, address):
        print('Connect by ', address)

        while True:
            data = connect.recv(1024)
            if not data:
                break
            connect.send(data)
        connect.close()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # s.bind(('127.0.0.1', 9999))
    s.bind(('0.0.0.0', 9999))

    s.listen(5)
    add_accept_handler(s, callback)

    # Create a new IOLoop
    io_loop = IOLoop()
    io_loop.start()


# Generated at 2022-06-26 08:37:13.001869
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    threaded_resolver_0 = ThreadedResolver()
    threaded_resolver_0.resolve("g.cn")


# Generated at 2022-06-26 08:37:18.138457
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    
    import concurrent.futures
    #executor = concurrent.futures.Executor()
    
    #s = ExecutorResolver()
    #s.initialize(executor, False)
    
    #s = ExecutorResolver()
    #s.initialize(executor)
    
    s = ExecutorResolver()
    s.initialize()


# Generated at 2022-06-26 08:37:27.702465
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    threaded_resolver_0 = ThreadedResolver()
    ioloop_current_0 = IOLoop.current()
    executor_0 = dummy_executor
    close_executor_0 = True
    threaded_resolver_0.initialize(executor_0, close_executor_0)
    executor_1 = None
    close_executor_1 = True
    threaded_resolver_0.initialize(executor_1, close_executor_1)


# Generated at 2022-06-26 08:37:38.491700
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    print("ExecutorResolver: test close")
    executor_0 = dummy_executor
    close_executor_0 = False
    executor_resolver_0 = ExecutorResolver(executor_0, close_executor_0)
    executor_resolver_0.initialize(executor_0, close_executor_0)
    executor_resolver_0.close()
    executor_0.shutdown()
    executor_0 = None # type: ignore
    return True
