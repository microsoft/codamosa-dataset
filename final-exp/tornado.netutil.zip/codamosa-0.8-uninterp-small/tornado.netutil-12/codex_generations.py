

# Generated at 2022-06-26 08:29:02.747233
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    # Test failure
    try:
        executor_resolver_0.initialize(executor = dummy_executor, close_executor = True)
    except:
        print("Unexpected exception")


# Generated at 2022-06-26 08:29:04.884185
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver = DefaultExecutorResolver()
    async def resolve_async():
        await default_executor_resolver.resolve(
            host, port, family=socket.AF_UNSPEC,
        )



# Generated at 2022-06-26 08:29:18.264774
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    override_resolver_0 = OverrideResolver(default_executor_resolver_0, {})
    host_arg_0 = ""
    port_arg_0 = 0
    family_arg_0 = socket.AF_INET
    # Using default value for argument f
    awaitable_0 = override_resolver_0.resolve(host_arg_0, port_arg_0, family_arg_0)
    result_0 = await awaitable_0
    assert isinstance(result_0, list)
    assert len(result_0) == 0
    assert isinstance(result_0[0], tuple)
    assert len(result_0[0]) == 0
    assert result_0[0][0] is ... # [empty]
   

# Generated at 2022-06-26 08:29:25.520948
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = None
    close_executor = True
    res1 = ExecutorResolver(executor, close_executor)
    res1.close()
    assert res1.executor == None
    assert res1.close_executor == True
    assert res1.io_loop
    
    

# Generated at 2022-06-26 08:29:29.724774
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    from tornado import ioloop
    file = "/data/tmp/test_bind_unix_socket.sock"
    sock = bind_unix_socket(file)
    assert sock.fileno() != -1
    ioloop.IOLoop.current().add_callback(ioloop.IOLoop.current().stop)


# Generated at 2022-06-26 08:29:33.529686
# Unit test for function bind_sockets
def test_bind_sockets():
    #    try:
    #        test_sock = socket.gethostbyname(socket.gethostname())
    #    except socket.gaierror:
    #        test_sock = '0.0.0.0'
    #    ts = bind_sockets(9898, address=test_sock)
    ts = bind_sockets(9898)
    print("test_bind_sockets: bind_sockets=%s" % str(ts))


# Generated at 2022-06-26 08:29:35.511617
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_1 = ExecutorResolver()
    executor_resolver_1.close()


# Generated at 2022-06-26 08:29:39.578236
# Unit test for function bind_sockets
def test_bind_sockets():
    bind_sockets(
        port = 0,
        address = None,
        family = socket.AF_UNSPEC,
        backlog = _DEFAULT_BACKLOG,
        flags = None,
        reuse_port = False,
        )


# Generated at 2022-06-26 08:29:51.648144
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Create a pair of connected sockets
    if os.name == 'nt':
        sock1, sock2 = socket.socket(), socket.socket()
        sock1.bind(('localhost', 0))
        sock1.listen(1)
        sock2.connect(sock1.getsockname())
    else:
        # On Unix, sockets can be autobound with an address of ''
        sock1 = socket.socket(family=socket.AF_UNIX)
        sock1.listen(1)
        sock2 = socket.socket(family=socket.AF_UNIX)
        sock2.connect(sock1.getsockname())
    connections = []  # type: List[socket.socket]
    addresses = []  # type: List[Any]


# Generated at 2022-06-26 08:29:57.605679
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    ssl_options0 = {}
    server_hostname0 = ""

    kwargs0 = {}
    socket0 = socket.socket()
    ssl_options_to_context0 = ssl_options_to_context(ssl_options0)
    socket1 = ssl_wrap_socket(
        socket0,
        ssl_options_to_context0,
        server_hostname0,
        **kwargs0
    )


# Generated at 2022-06-26 08:30:16.287035
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = None
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor)
    resolver.close()
    resolver.close_executor == False

    executor = concurrent.futures.Executor
    close_executor = True
    resolver = ExecutorResolver(executor, close_executor)
    resolver.close()
    resolver.close_executor == True
    # must shutdown executor

    executor = concurrent.futures.Executor
    close_executor = False
    resolver = ExecutorResolver(executor, close_executor)
    resolver.close()
    resolver.close_executor == False
    # must not shutdown executor


# Generated at 2022-06-26 08:30:24.789553
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    print("\n")
    # Module ExecutorResolver, Method initialize
    print("\nModule %s, Method %s" % ("ExecutorResolver", "initialize"))

    executor: Optional[concurrent.futures.Executor] = dummy_executor
    close_executor: bool = True
    test_ExecutorResolver_initialize_0 = ExecutorResolver()
    test_ExecutorResolver_initialize_0.initialize(executor, close_executor)

    close_executor: bool = True
    test_ExecutorResolver_initialize_1 = ExecutorResolver()
    test_ExecutorResolver_initialize_1.initialize(None, close_executor)

    close_executor: bool = False
    test_ExecutorResolver_initialize_2 = ExecutorResolver

# Generated at 2022-06-26 08:30:26.888502
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()
    executor_resolver_0.close()



# Generated at 2022-06-26 08:30:33.228395
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # Test case 1
    executor_resolver_1 = ExecutorResolver()
    executor_resolver_1.initialize(None, True)
    # Test case 2
    executor_resolver_2 = ExecutorResolver()
    executor_resolver_2.initialize(None, False)


# Generated at 2022-06-26 08:30:37.556931
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    override_resolver_0 = OverrideResolver()
    try:
        expected = ""
        awaitable = override_resolver_0.resolve("", 0, "")
        actual = await awaitable
        assert (expected == actual)
    except:
        raise


# Generated at 2022-06-26 08:30:48.894868
# Unit test for function bind_sockets
def test_bind_sockets():
    # If the number(*) of addresses bound is 0 or 1, the function is
    # successful. It should be either 0 or 1 whether the input address
    # is the empty string, None, or the localhost.
    (*_, bound_port) = bind_sockets(12345)[0].getsockname()
    assert bound_port == 12345
    (*_, bound_port) = bind_sockets(0)[0].getsockname()
    assert bound_port == 0
    (*_, bound_port) = bind_sockets(0, "")[0].getsockname()
    assert bound_port == 0
    (*_, bound_port) = bind_sockets(0, None)[0].getsockname()
    assert bound_port == 0

# Generated at 2022-06-26 08:30:53.026291
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()

    executor_resolver_1 = ExecutorResolver()
    executor_resolver_1.initialize(dummy_executor)

    executor_resolver_2 = ExecutorResolver()
    executor_resolver_2.initialize(dummy_executor, True)


# Generated at 2022-06-26 08:31:00.673558
# Unit test for function is_valid_ip
def test_is_valid_ip():
    if is_valid_ip("11:22:33::44"):
        print("string 11:22:33::44 is a well-formed ip address")
    else:
        print("string 11:22:33::44 is NOT a well-formed ip address")
    if is_valid_ip("127.0.0.1"):
        print("string 127.0.0.1 is a well-formed ip address")
    else:
        print("string 127.0.0.1 is NOT a well-formed ip address")


# Generated at 2022-06-26 08:31:09.309705
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock_0 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    removed_0 = [False]
    # Function to be wrapped by add_accept_handler
    def accept_handler_0(fd_0: socket.socket, events_0: int) -> None:
        for i_0 in range(_DEFAULT_BACKLOG):
            if removed_0[0]:
                # The socket was probably closed
                return
            try:
                connection, address = sock_0.accept()
            except BlockingIOError:
                # EWOULDBLOCK indicates we have accepted every
                # connection that is available.
                return

# Generated at 2022-06-26 08:31:18.064143
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Set Up
    resolver = socket.getaddrinfo("localhost", None)
    mapping = {("localhost", 80): ("127.0.0.1", 80), "localhost": "127.0.0.1"}
    override_resolver_0 = OverrideResolver(resolver, mapping)
    host = "localhost"
    port = 80
    family = socket.AF_INET

    # Invocation + Verification
    try:
        override_resolver_0.resolve(host, port, family)
    except:
        raise
    else:
        assert True


# Generated at 2022-06-26 08:31:52.569677
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():

    fam, address = _resolve_addr("google.com", 80)
    default_executor_resolver_0 = DefaultExecutorResolver()
    res = default_executor_resolver_0.resolve("google.com", 80)



# Generated at 2022-06-26 08:32:01.406983
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    try:
        executor_resolver_0.initialize(None, False)
    except ValueError:
        pass
    else:
        raise RuntimeError

    executor_resolver_1 = ExecutorResolver()
    executor_resolver_1.initialize(dummy_executor, True)


# Generated at 2022-06-26 08:32:04.800843
# Unit test for function bind_sockets
def test_bind_sockets():
    # Test case 1
    sockets_1 = bind_sockets(8888, address='')
    # Test case 2
    sockets_2 = bind_sockets(8888, address='localhost')


# Generated at 2022-06-26 08:32:11.528831
# Unit test for function add_accept_handler
def test_add_accept_handler():
    socks = bind_sockets(20000)
    def callback(connection, address):
        print('Accept connection', connection.getpeername())
        connection.close()
    handlers = [add_accept_handler(sock, callback) for sock in socks]
    IOLoop.current().start()


# Generated at 2022-06-26 08:32:21.195463
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_0 = dummy_executor
    close_executor_0 = True

    # Test of normal case.
    resolver_0 = ExecutorResolver()
    resolver_0.initialize(executor=executor_0, close_executor=close_executor_0)
    # Verification of attribute.
    assert resolver_0.executor == executor_0
    assert resolver_0.close_executor == close_executor_0

    # Test of normal case.
    resolver_0 = ExecutorResolver()
    resolver_0.initialize(executor=executor_0)
    # Verification of attribute.
    assert resolver_0.executor == executor_0
    assert resolver_0.close_executor == close_executor_0

    # Test of normal case

# Generated at 2022-06-26 08:32:31.144345
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # resolver_0 is of type Resolver
    resolver_0: Resolver = DefaultExecutorResolver()
    # Future[List[Tuple[int, Any]]]
    future_0 = resolver_0.resolve('www.google.com', 80)
    # List[Tuple[int, Any]]
    list_0: List[Tuple[int, Any]] = future_0.result()
    # address_0 is of type Tuple[int, Any]
    for address_0 in list_0:
        # int
        int_0 = address_0[0]
        # Any
        any_0 = address_0[1]


# Generated at 2022-06-26 08:32:41.073020
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    family = socket.AF_UNSPEC
    port = 0
    host = '0.0.0.0'
    default_executor_resolver = DefaultExecutorResolver()
    result_actual = default_executor_resolver.resolve(host, port, family)
    #TODO(nikhiljain): Fix this test case
    result_expected = ([], [(2, ['::', 0])])
    assert result_actual == result_expected
    # TODO: Setup an IOLoop to handle the exception when the function is called
    #with self.assertRaises(Exception):
    #    DefaultExecutorResolver().resolve(host, port)


# Generated at 2022-06-26 08:32:44.869409
# Unit test for function add_accept_handler
def test_add_accept_handler():
    try:
        socket.AF_INET6
    except AttributeError:
        socket.AF_INET6 = 6
    sockets = bind_sockets(9001)
    add_handles = []
    for sock in sockets:
        if sock.family == socket.AF_INET6:
            add_handles.append(add_accept_handler(sock, None))
    for add_handle in add_handles:
        add_handle()
    for sock in sockets:
        sock.close()


# Generated at 2022-06-26 08:32:48.999506
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()
    executor_resolver_0.close()


# Generated at 2022-06-26 08:32:50.103390
# Unit test for function add_accept_handler
def test_add_accept_handler():
    pass


# Generated at 2022-06-26 08:33:21.397809
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    port = 8888
    bind_sockets(port)
    bind_unix_socket('/tmp/test_bind_unix_socket.sock')


# Generated at 2022-06-26 08:33:34.028156
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("192.168.1.1") == True
    assert is_valid_ip("192.168.1.0") == True
    assert is_valid_ip("::") == True
    assert is_valid_ip("::1") == True
    assert is_valid_ip("1::") == True
    assert is_valid_ip("0:0:0:0:0:0:0:1") == True
    assert is_valid_ip("0:0:0:0:0:0:0:0") == True
    assert is_valid_ip("::0.0.0.0") == True
    assert is_valid_ip("::ffff:0.0.0.0") == True
    assert is_valid_ip("::ffff:192.168.1.1")

# Generated at 2022-06-26 08:33:39.612924
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    exe = dummy_executor
    resolver = ExecutorResolver(executor=exe, close_executor=False)
    resolver.close()
    assert(resolver.executor == exe)


# Generated at 2022-06-26 08:33:42.312099
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.close()

# Generated at 2022-06-26 08:33:45.958664
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # Create instance, resolve google.com
    class2 = ExecutorResolver()
    print(class2.resolve("google.com", 80))


# Generated at 2022-06-26 08:33:49.528795
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()


# Generated at 2022-06-26 08:33:55.959624
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(socket, address):
        pass

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 5202))
    sock.listen(1)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()



# Generated at 2022-06-26 08:34:01.082133
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_1 = ExecutorResolver()
    executor_resolver_1.initialize()

    executor_resolver_2 = ExecutorResolver(dummy_executor)
    executor_resolver_2.initialize(dummy_executor)

    executor_resolver_3 = ExecutorResolver(dummy_executor, True)
    executor_resolver_3.initialize(dummy_executor, True)


# Generated at 2022-06-26 08:34:05.172988
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_instance = ExecutorResolver()
    executor_resolver_instance.close()
    # UNREACHABLE CODE: assert False


# Generated at 2022-06-26 08:34:12.200580
# Unit test for function add_accept_handler
def test_add_accept_handler():

    fn = "delme.socket"
    sock = bind_unix_socket(fn, mode = 0o777, backlog = _DEFAULT_BACKLOG)

    client = socket.socket(socket.AF_UNIX)
    client.connect(fn)
    

# Generated at 2022-06-26 08:34:41.902306
# Unit test for function add_accept_handler
def test_add_accept_handler():
    io_loop = IOLoop.current()
    host = "127.0.0.1"
    port = 8888
    sockets = bind_sockets(port=port)
    socket_ = sockets[0]
    add_accept_handler(sock=socket_, callback=None)
    # TODO: currently, I cannot know how to test the functionality of this api


# Generated at 2022-06-26 08:34:52.600387
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    host_0 = "abcdefghilmnopqrstuvwxyz0123456789"
    port_0 = -1586343908
    family_0 = socket.AF_UNSPEC
    executor_0 = concurrent.futures.ThreadPoolExecutor()
    close_executor_0 = False
    # executor_0: concurrent.futures.ThreadPoolExecutor = concurrent.futures.ThreadPoolExecutor()
    # close_executor_0: bool = False
    # ExecutorResolver_0: ExecutorResolver = ExecutorResolver(executor_0, close_executor_0)
    # result_of_test: Awaitable[List[Tuple[int, Any]]] = ExecutorResolver_0.resolve(host_0, port_0, family_0)


# Generated at 2022-06-26 08:34:54.680246
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options_dict = {"ssl_version": None, "certfile": None, "keyfile": None,
                        "cert_reqs": None, "ca_certs": None, "ciphers": None}
    ssl_context = ssl_options_to_context(ssl_options_dict)


# Generated at 2022-06-26 08:35:00.440496
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    exe_resolver_0 = ExecutorResolver(executor, True)
    exe_resolver_0.close()


# Generated at 2022-06-26 08:35:07.402726
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    mapping = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    override_resolver_0 = OverrideResolver(resolver=None, mapping=mapping)
    host = "example.com"
    port = 80
    family = socket.AF_INET
    future_resolve_0_result = override_resolver_0.resolve(host, port, family)
    assert isinstance(future_resolve_0_result, Future)
    assert isinstance(future_resolve_0_result.result(), list)


# Generated at 2022-06-26 08:35:14.202651
# Unit test for function is_valid_ip
def test_is_valid_ip():
    # test 1
    assert is_valid_ip('8.8.8.8') == True
    # test 2
    assert is_valid_ip('255.255.255.255') == True
    # test 3
    assert is_valid_ip('1.1.1.1.2') == False
    # test 4
    assert is_valid_ip('') == False


# Generated at 2022-06-26 08:35:26.357425
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    print("hello world")
    ssl_options_0 = {}
    ssl_options_to_context(ssl_options_0)
    ssl_options_1 = {"ssl_version": ssl.PROTOCOL_TLS_CLIENT}
    ssl_options_to_context(ssl_options_1)
    certfile = "certfile"
    keyfile = "keyfile"
    ssl_options_2 = {"ssl_version": ssl.PROTOCOL_TLS_SERVER, "certfile": certfile, "keyfile": keyfile}
    ssl_options_to_context(ssl_options_2)
    ssl_options_3 = {"cert_reqs": ssl.CERT_OPTIONAL}
    ssl_options_to_context(ssl_options_3)
   

# Generated at 2022-06-26 08:35:38.483191
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # Mock the socket class
    class mock_socket:
        def __init__(self):
            self.family = 0
            self.type = 0
            self.proto = 0
            self.fileno = 0
            self.sock = 0
            self.sockaddr = ('', '', '')

        def accept(self):
            self.sock = self.sockaddr
            return self.sock

    # Mock the IOLoop class
    class mock_io_loop:
        def remove_handler(self, sock):
            return
        def add_handler(self, sock, accept_handler, flag):
            return
    
    # If the test runs well, the result should be 'True', otherwise 'False'
    result_1 = False
    result_2 = True

    # Mock a socket object

# Generated at 2022-06-26 08:35:45.213320
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()
    executor_resolver_0.initialize(dummy_executor, True)
    executor_resolver_0.initialize(dummy_executor, True)


# Generated at 2022-06-26 08:35:50.847113
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver()
    assert executor_resolver_0.close_executor == True and executor_resolver_0.executor == dummy_executor
    executor_resolver_0.initialize()
    executor_resolver_1 = ExecutorResolver(dummy_executor, False)
    assert executor_resolver_1.close_executor == False and executor_resolver_1.executor == dummy_executor
    executor_resolver_1.initialize()


# Generated at 2022-06-26 08:36:19.186608
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_resolver_0 = ExecutorResolver(None, True)
    executor_resolver_0.initialize(dummy_executor, True)
    assert executor_resolver_0.close_executor == True


# Generated at 2022-06-26 08:36:27.310342
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    mp_manager = multiprocessing.Manager()
    mp_queue = mp_manager.Queue()
    mp_resolver = ExecutorResolver(executor = ThreadPoolExecutor(max_workers = 1))
    mp_resolver.close()
    mp_queue.put(True)

# Unit test of method initialize of class ExecutorResolver

# Generated at 2022-06-26 08:36:30.199499
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    resolver = DefaultExecutorResolver()
    resolver.resolve("www.google.com", 80)


# Generated at 2022-06-26 08:36:35.042378
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options_to_context_0 = ssl_options_to_context(
        {"ssl_version": ssl.PROTOCOL_TLS},
    )
    ssl_options_to_context_1 = ssl_options_to_context(
        {"ssl_version": ssl.PROTOCOL_TLS},
    )
    # Test if ssl_options_to_context_1 is initialized
    assert ssl_options_to_context_1 is not None
    ssl_options_to_context_1.options |= ssl.OP_NO_COMPRESSION


# Generated at 2022-06-26 08:36:45.375453
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    try:
        import tornado.ioloop
    except ImportError:
        print("Module tornado.ioloop not found")
        return False
    try:
        import tornado.concurrent
    except ImportError:
        print("Module tornado.concurrent not found")
        return False
    try:
        import socket
    except ImportError:
        print("Module socket not found")
        return False
    import unittest
    import unittest.mock
    with unittest.mock.patch.object(tornado.ioloop.IOLoop, 'run_in_executor', autospec=True) as mock_run_in_executor:
        mock_run_in_executor.return_value = tornado.concurrent.Future()
        mock_run_in_executor.return_value.set_result(None)
       

# Generated at 2022-06-26 08:36:53.864305
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor: Optional[concurrent.futures.Executor] = None
    close_executor: bool = True
    dummy_executor.shutdown()

    executor_resolver_0 = ExecutorResolver(executor=executor, close_executor=close_executor)

    executor_resolver_0.initialize(executor=executor, close_executor=close_executor)


# Generated at 2022-06-26 08:37:00.042310
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver = ExecutorResolver()
    executor_resolver.close()
    executor_resolver_6 = ExecutorResolver()
    executor_resolver_6.close()


# Generated at 2022-06-26 08:37:05.062723
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    p = OverrideResolver()
    for i in range(100):
        host = 'www.google.com'
        port = 80
        family = socket.AF_UNSPEC
        res = p.resolve(host, port, family)
        print(res)


# Generated at 2022-06-26 08:37:07.373583
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    bind_unix_socket("unix")


# Generated at 2022-06-26 08:37:10.658406
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.close()
