

# Generated at 2022-06-26 08:29:06.585694
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    '''
    ssl_options_to_context(ssl_options)
    '''
    ssl_options_0 = dict()
    ssl_options_1 = dict()
    ssl_options_1['ssl_version'] = ssl.PROTOCOL_SSLv2
    ssl_options_1['certfile'] = 'certfile_0'
    ssl_options_1['keyfile'] = 'keyfile_0'
    ssl_options_1['cert_reqs'] = ssl.CERT_NONE
    ssl_options_1['ca_certs'] = 'ca_certs_0'
    ssl_options_1['ciphers'] = 'ciphers_0'
    ssl_options_2 = dict()

# Generated at 2022-06-26 08:29:16.657967
# Unit test for function add_accept_handler
def test_add_accept_handler():
    resolver_0 = Resolver()
    sock_0 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock_0.bind(("", 8888))
    sock_0.listen(128)
    sock_0.setblocking(0)
    remove_handler_0 = add_accept_handler(sock_0, print)
    def my_callback(connection, address):
        remove_handler_0()
    def my_callback_1(connection, address):
        return
    IOLoop.current().run_sync(
        lambda: resolver_0.resolve("www.example.com", 80, my_callback)
    )

# Generated at 2022-06-26 08:29:22.934143
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    socket_0 = socket.socket()
    dict_0 = {}
    ssl_wrap_socket(socket=socket_0,
                    ssl_options=dict_0,
                    server_hostname=None)


# Generated at 2022-06-26 08:29:29.757377
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import time
    import threading
    import tornado.web
    import tornado.ioloop
    io_loop = tornado.ioloop.IOLoop.instance()
    sockets = bind_sockets(8001)
    server = None
    def callback(connection: socket.socket, address: Any) -> None:
        print(connection, address)
        connection.close()
    for socket_0 in sockets:
        add_accept_handler(socket_0, callback)
    #io_loop.start()
    #io_loop.stop()
    time.sleep(2)


# Generated at 2022-06-26 08:29:31.752778
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # Object(s) of class Resolver
    resolver_0 = Resolver()

    # Test for the method resolve for class Resolver
    resolver_0.resolve("localhost", 80)


# Generated at 2022-06-26 08:29:33.431632
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    socket.socket()
    ssl_options = {"ssl_version": 3, "certfile": "key.txt"}
    ssl_wrap_socket(socket.socket(), ssl_options)


# Generated at 2022-06-26 08:29:35.329448
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    fn = "tmp.sock"
    file = bind_unix_socket(fn)
    print(file)


# Generated at 2022-06-26 08:29:38.258944
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver_0 = OverrideResolver()
    host = ''
    port = 0
    family = 0
    resolver_0.resolve(host, port, family)


# Generated at 2022-06-26 08:29:41.170108
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver_0 = Resolver()
    host_0 = "ipv6.google.com"
    port_0 = int()
    family_0 = socket.AF_INET
    future_0 = resolver_0.resolve(host_0, port_0, family_0)
    assert isinstance(future_0, Future)


# Generated at 2022-06-26 08:29:42.356298
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_0 = dummy_executor
    resolver_0 = ExecutorResolver(executor_0, True)
    resolver_0.close()


# Generated at 2022-06-26 08:30:06.141596
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver_0 = DefaultExecutorResolver()
    host_0 = "www.example.com"
    port_0 = 80
    family_0 = socket.AF_UNSPEC
    future_0 = resolver_0.resolve(host_0, port_0, family_0)
    future_0.done()


# Generated at 2022-06-26 08:30:11.487190
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Creating an object of OverrideResolver
    obj1 = OverrideResolver()
    resolver_0 = Resolver()
    obj1.initialize(resolver_0,{})
    obj1.resolve("xyz.com", 80)
    print("test_OverrideResolver_resolve completed")


# Generated at 2022-06-26 08:30:17.633566
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver_1 = ExecutorResolver()
    addr_info_list = resolver_1.resolve("www.google.com")
    print("addr_info_list:", addr_info_list)



# Generated at 2022-06-26 08:30:23.311902
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # TODO: This test is incomplete
    resolver_0 = Resolver()
    mapping = {}
    overrideresolver_0 = OverrideResolver(resolver_0, mapping)
    host = ''
    port = 123
    family = socket.AF_UNSPEC
    assert await overrideresolver_0.resolve(host, port, family) is None


# Generated at 2022-06-26 08:30:28.074298
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_0=concurrent.futures.Executor()
    resolver_0 = ExecutorResolver()
    resolver_0.initialize(executor_0)


# Generated at 2022-06-26 08:30:34.080944
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    ex_0 = ExecutorResolver()
    ex_0.initialize()


# Generated at 2022-06-26 08:30:40.857782
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    r = ssl_options_to_context({})
    assert r.verify_mode is ssl.CERT_REQUIRED
    assert r.options & ssl.OP_NO_COMPRESSION == ssl.OP_NO_COMPRESSION


# Generated at 2022-06-26 08:30:47.357996
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    import errno
    import socket
    import os

    def test_send_callback(fd, events):
        assert fd == unix_sock.fileno()
        assert events == IOLoop.WRITE
        test_message = "test_message"
        unix_sock.send(test_message.encode('utf-8'))
        print("send %s" % test_message)

    def test_recv_callback(fd, events):
        assert fd == unix_sock.fileno()
        assert events == IOLoop.READ
        recv_message = unix_sock.recv(1024).decode('utf-8')
        print("recv %s" % recv_message)


# Generated at 2022-06-26 08:30:58.085529
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    import tornado.testing
    import tornado.httpserver
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.tcpserver
    import tornado.web
    import tornado.websocket
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port

    class HelloWorldHandler(RequestHandler):
        def get(self):
            self.write("Hello world")

            sock_0 = socket.socket()
            ssl_wrap_socket(sock_0)
       	  
    class HelloWorldTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([('/', HelloWorldHandler)])

        def test_hello_world(self):
            response = self.fetch('/')
            self.assertEqual(response.code, 200)

# Generated at 2022-06-26 08:31:00.194267
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver = ExecutorResolver()
    resolver.close()


# Generated at 2022-06-26 08:31:28.282201
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options = {}
    ssl_options["ssl_version"] = ssl.PROTOCOL_SSLv23
    ssl_options["cert_reqs"] = ssl.CERT_REQUIRED
    ssl_options["ca_certs"] = "/etc/ssl/ca-bundle.pem"
    ssl_option_obj = ssl_options_to_context(ssl_options)
    print(ssl_option_obj)


# Generated at 2022-06-26 08:31:29.568160
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets= bind_sockets(8888)
    sockets[0].close()


# Generated at 2022-06-26 08:31:38.288722
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # create an object of the superclass
    resolver_0 = Resolver()
    # create an object of the tested class
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()



# Generated at 2022-06-26 08:31:41.126224
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket('/tmp/socket.sock')
    sock.close()
    os.remove('/tmp/socket.sock')


# Generated at 2022-06-26 08:31:47.203898
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    try:
        reply = resolver.resolve("www.google.com", 80)
    except AttributeError as e:
        pass
    else:
        assert False


# Generated at 2022-06-26 08:31:58.115322
# Unit test for function add_accept_handler
def test_add_accept_handler():
    io_loop = IOLoop.current()
    address = ''
    port = 8888
    sockets = bind_sockets(port, address)
    io_loop.add_callback(add_accept_handler(sockets[0],
        lambda x, y: (print("accept callback: x={}, y={}".format(x, y)))))

# Generated at 2022-06-26 08:32:08.626380
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    # Create a Unix domain listening socket.
    # Returns a socket object (not a list of socket objects as
    # bind_sockets() does)

    mode = 644
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(False)
    st = os.stat("/tmp/test.sock")
    if stat.S_ISSOCK(st.st_mode):
        os.remove(file)
    else:
        raise ValueError("File %s exists and is not a socket", file)
    sock.bind("/tmp/test.sock")
    os.chmod("/tmp/test.sock", mode)
    sock.listen

# Generated at 2022-06-26 08:32:16.962377
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver_0 = DefaultExecutorResolver()
    host_0 = 'www.baidu.com'
    port_0 = 80
    family_0 = 0
    # key point: the method is asynchronous
    print('test_DefaultExecutorResolver_resolve')
    resolver_0.resolve(host_0, port_0, family_0).add_done_callback(lambda x:print(x.result()))
    IOLoop.current().start()

# Generated at 2022-06-26 08:32:28.998416
# Unit test for function add_accept_handler
def test_add_accept_handler():
    io_loop_0 = IOLoop.current()
    print("io_loop_0=", io_loop_0)
    resolver_0 = Resolver()
    callback_0 = lambda x : x
    sock_0 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print("sock_0=", sock_0)
    sock_0.setblocking(0)
    sock_0.bind(("localhost", 0))
    sock_0.listen(10)
    print("sock_0=", sock_0)
    remove_handler_0 = add_accept_handler(sock_0, callback_0)
    print("remove_handler_0=", remove_handler_0)
    #io_loop_0.run_sync(remove_handler_0)
   

# Generated at 2022-06-26 08:32:31.735615
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()



# Generated at 2022-06-26 08:32:47.048820
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=10)
    resolver.initialize(executor=executor)
    resolver.close()


# Generated at 2022-06-26 08:32:54.981189
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile

    # Test 1: create a unix socket and listen on it
    fd, path = tempfile.mkstemp()
    os.close(fd)
    sock = bind_unix_socket(path, mode=0o700)
    os.remove(path)
    sock.close()

    # Test 2: create a file in place of unix socket
    fd, path = tempfile.mkstemp()
    os.close(fd)
    try:
        sock = bind_unix_socket(path, mode=0o700)
        os.remove(path)
        sock.close()
    except ValueError as e:
        print(e)



# Generated at 2022-06-26 08:33:02.050221
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    def test_impl():
        resolver_0 = Resolver()
        future_0 = resolver_0.resolve("localhost", 80)
        result_0 = future_0.result()
        assert_0 = [(10, ('127.0.0.1', 80)), (2, ('::1', 80))]
        return assert_0 == result_0
    assert test_impl()


# Generated at 2022-06-26 08:33:14.966488
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    host_0 = "example.com"
    port_0 = 8080
    family_0 = 0
    # resolver_0 of type OverrideResolver
    resolver_0 = Resolver()
    # mapping_0 of type dict
    mapping_0 = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443, socket.AF_INET): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    resolver_0.initialize(resolver_0, mapping_0)
    # result_0 of type Awaitable[List[Tuple[int, Any]]]

# Generated at 2022-06-26 08:33:26.839679
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver_r = ExecutorResolver()
    # Method parameters
    host_r: str
    port_r: int
    family_r: socket.AddressFamily = socket.AF_UNSPEC
    result_r: List[Tuple[int, Any]] = resolver_r.resolve(host_r, port_r, family_r)
    assert result_r != None
    assert type(result_r) == List
    assert len(result_r) > 0
    assert len(result_r) < 100
    for address in result_r:
        assert len(address) >= 2
        assert type(address[0]) == int
        assert address[0] >= 0
        assert address[0] < 256
        assert type(address[1]) == bytes
        assert len(address[1]) >= 2

# Generated at 2022-06-26 08:33:32.545287
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    res = resolver.resolve(host = 'www.example.com', port = 80)
    print(res)

# Generated at 2022-06-26 08:33:35.707062
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver_0 = DefaultExecutorResolver()
    try:
        resolver_0.resolve("www.google.com", 80)
        print("absence of exception")
    except Exception as e:
        print(e)



# Generated at 2022-06-26 08:33:40.639858
# Unit test for function add_accept_handler
def test_add_accept_handler():
    """Test for add_accept_handler"""
    # Create the event loop
    ioloop = IOLoop()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    server.bind(("127.0.0.1", 8888))
    server.listen(128)
    # Register the socket to IOLoop
    # And set the handler
    # handler signature: (fd, event) => ...
    add_handler = add_accept_handler(server, lambda conn, address : None)
    print("End function add_accept_handler")


# Generated at 2022-06-26 08:33:48.583949
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    print("\nUnitTest for Resolver.resolve()")
    # Define a resolver instance
    resolver_inst = Resolver()
    # Define host and port for the test
    host = 'www.baidu.com'
    port = 80
    family = socket.AF_UNSPEC
    # Call the asynchronous method 'resolve'
    result = resolver_inst.resolve(host, port, family)
    print("The result of Resolver.resolve(host, port, family) is: {}".format(result))


# Generated at 2022-06-26 08:33:55.790665
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    try:
        ssl_wrap_socket(None, None, None)
        assert False
    except TypeError:
        pass
    try:
        ssl_wrap_socket(None, None)
        assert False
    except TypeError:
        pass
    try:
        ssl_wrap_socket(None, None, None, None)
        assert False
    except TypeError:
        pass
    try:
        ssl_wrap_socket(None, None, None, None, None)
        assert False
    except TypeError:
        pass
    try:
        ssl_wrap_socket(None, None, None, None, None, None)
        assert False
    except TypeError:
        pass


# Generated at 2022-06-26 08:34:22.139206
# Unit test for function bind_sockets
def test_bind_sockets():
    # TODO: Find a way to get a list of currently active ports and
    # test whether they are shared
    #
    # Get a list of currently active ports from
    # `lsof -i :port`
    #
    # With `reuse_port` being true, there should be no port marked as
    # CLOSE_WAIT or similar
    resolver_0 = Resolver()
    sockets = bind_sockets(
        0, "localhost", reuse_port=False
    )
    
    sockets_2 = bind_sockets(
        0, "localhost", reuse_port=True
    )
    
    print(sockets)
    print(sockets_2)


# Use the poll() instead of select() in epoll mode
_POLL_EPOLLIN = (1 << 0)  # There is data

# Generated at 2022-06-26 08:34:28.115693
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    resolver = DefaultExecutorResolver()
    result = IOLoop.current().run_sync(lambda : resolver.resolve("www.google.com", 80, 0))
    print("test_DefaultExecutorResolver_resolve result:", result)


# Generated at 2022-06-26 08:34:32.196258
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock_0 = bind_unix_socket("/tmp/socket_path")
    sock_0.close()
    os.remove("/tmp/socket_path")



# Generated at 2022-06-26 08:34:42.949481
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket('./demo_sock.sock')
    print(sock)

# class ThreadedResolver(object):
#     """A thread pool that can be shared by multiple Resolvers.

#     This is a simple implementation that doesn't try to be
#     particularly efficient.
#     """

#     def __init__(self):
#         self._executor = concurrent.futures.ThreadPoolExecutor(
#             max_workers=20)
#         self._threads = []  # type: List[concurrent.futures.Future]

#     def close(self):
#         for t in self._threads:
#             t.cancel()
#         self._threads = []

#     def _add_thread(self, t: concurrent.fut

# Generated at 2022-06-26 08:34:49.800039
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = dummy_executor
    close_executor = True
    resolver = ExecutorResolver()
    resolver.initialize(executor, close_executor)
    assert resolver.executor == executor
    assert resolver.io_loop == IOLoop.current()
    assert resolver.close_executor == close_executor



# Generated at 2022-06-26 08:34:55.186933
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor_0 = dummy_executor
    close_executor_0 = True
    resolver_1 = ExecutorResolver()
    resolver_1.initialize(executor_0, True)


# Generated at 2022-06-26 08:35:04.008825
# Unit test for function add_accept_handler
def test_add_accept_handler():
    """A simple unit test for network utility add_accept_handler"""
    # Create a TCP server socket
    sever_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sever_sock.bind(('', 9999))
    sever_sock.listen(1)

    # Register callback using add_accept_handler
    add_accept_handler(sever_sock, test_accept_handler)

    # Create a TCP client socket
    client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_sock.connect(('', 9999))
    client_sock.close()


# Generated at 2022-06-26 08:35:14.774273
# Unit test for function add_accept_handler
def test_add_accept_handler():
    io_loop = IOLoop.current()
    sockets = bind_sockets(8888, address="")
    def callback_0(connection: socket.socket, address: Any) -> None:
        assert connection is connection
        assert address is address
        print(connection)
        print(address[0])
        print(address[1])
    for sock in sockets:
        add_accept_handler(sock, callback_0)
    io_loop.start()

if __name__ == "__main__":
    test_case_0()
    test_add_accept_handler()

# Generated at 2022-06-26 08:35:23.933020
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    """
    def initialize(self, executor: Optional[concurrent.futures.Executor] = None,
                   close_executor: bool = True) -> None
                   resolver.close_executor = False
                   resolver.executor.shutdown()
    """
    resolver = ExecutorResolver()
    resolver.initialize(close_executor=False)
    resolver.executor.shutdown()



# Generated at 2022-06-26 08:35:36.012675
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    if hasattr(socket, "AF_UNIX"):
        file = "./tmp"
        if os.path.exists(file):
            os.remove(file)
        sock = bind_unix_socket(file)
        assert sock.family == socket.AF_UNIX
        assert sock.type == socket.SOCK_STREAM
        assert sock.proto == 0
        assert sock.fileno() > 0
        assert sock.getsockname() == file
        sock.close()
        if os.path.exists(file):
            os.remove(file)


# Generated at 2022-06-26 08:36:06.644897
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor = concurrent.futures.ProcessPoolExecutor(max_workers=4)
    resolver = ExecutorResolver(executor, close_executor=False)
    print(resolver.__dict__)
    print(type(resolver))
    resolver.close()
    executor.shutdown()


# Generated at 2022-06-26 08:36:08.934486
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    resolver_0 = ExecutorResolver()
    resolver_0.close()


# Generated at 2022-06-26 08:36:21.485546
# Unit test for function is_valid_ip
def test_is_valid_ip():
    ip_valid_1 = "127.0.0.1"
    assert(is_valid_ip(ip_valid_1) == True)

    ip_valid_2 = "2001:0db8:85a3:0000:0000:8a2e:0370:7334"
    assert(is_valid_ip(ip_valid_2) == True)

    ip_invalid_1 = "127.0.0"
    assert(is_valid_ip(ip_invalid_1) == False)

    ip_invalid_2 = "an_invalid_ip"
    assert(is_valid_ip(ip_invalid_2) == False)


# Generated at 2022-06-26 08:36:33.554640
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # 1. Test for the first case, i.e. socket fd is ready for read.
    def test_callback_1(connection: socket.socket, address: Any) -> None:
        print("test_callback_1: connection = {}, address = {}".format(connection, address))

    def test_fd_handler_1(fd: socket.socket, events: Any) -> None:
        print("test_fd_handler_1: fd = {}, events = {}".format(fd, events))

    bind_port = 8880
    socket_list = bind_sockets(bind_port)
    sock = socket_list[0]
    io_loop = IOLoop.current()
    io_loop.add_handler(sock, test_fd_handler_1, IOLoop.READ)
    remove_handler = add_

# Generated at 2022-06-26 08:36:41.692621
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(
        port=9999,
        address='localhost',
        family=socket.AF_INET6,
        backlog=_DEFAULT_BACKLOG,
        flags=socket.AI_NUMERICHOST,
        reuse_port=False)
    for sock in sockets:
        print(sock)



# Generated at 2022-06-26 08:36:44.869522
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    result = await resolver.resolve(host, port, family)
    print(result)


# Generated at 2022-06-26 08:36:54.670122
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets_0 = bind_sockets(8989)
    sockets_1 = bind_sockets(8989)
    sockets_2 = bind_sockets(9000)

    sockets_0_len = len(sockets_0)
    sockets_1_len = len(sockets_1)
    sockets_2_len = len(sockets_2)

    print("sockets_0_len:{}, sockets_1_len:{}, sockets_2_len:{}".format(
        sockets_0_len, sockets_1_len, sockets_2_len
    ))



# Generated at 2022-06-26 08:37:06.569308
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    test_map = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    resolver = OverrideResolver(
        thread.resolver,
        test_map,
    )
    for key in test_map:
        resolver.resolve(*key)
    resolver.resolve("example.com",800)


if __name__ == "__main__":
    test_case_0()
    test_OverrideResolver_resolve()

# Generated at 2022-06-26 08:37:10.448944
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    try:
        bind_unix_socket("/home/m")
    except:
        pass
    else:
        raise AssertionError("Should raise an error")


# Generated at 2022-06-26 08:37:19.480747
# Unit test for function bind_sockets
def test_bind_sockets():
    servers = bind_sockets(8443, "localhost")
    print("server result:", servers)
    assert len(servers) > 0
    servers = bind_sockets(8443, "127.0.0.1")
    print("server result:", servers)
    assert len(servers) > 0
    servers = bind_sockets(8443, "0.0.0.0")
    print("server result:", servers)
    assert len(servers) > 0
    servers = bind_sockets(8443, "")
    print("server result:", servers)
    assert len(servers) > 0
