

# Generated at 2022-06-26 08:28:23.783989
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("127.0.0.1")
    assert is_valid_ip("[::1]")


# Generated at 2022-06-26 08:28:28.297105
# Unit test for function is_valid_ip
def test_is_valid_ip():
    print ("Testing is_valid_ip function.")
    valid_ip_addr = "127.0.0.1"
    assert is_valid_ip(valid_ip_addr) == True

if __name__ == "__main__":
    test_case_0()
    test_is_valid_ip()

# Generated at 2022-06-26 08:28:30.344284
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver_0 = OverrideResolver(resolver_0, dict())
    # Test: Execute method resolve of class OverrideResolver
    result = await resolver_0.resolve('host', 23895, socket.AF_UNSPEC)

# Generated at 2022-06-26 08:28:36.005372
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor : concurrent.futures.Executor = None
    close_executor : bool = True
    executor_resolver_0 = ExecutorResolver(executor, close_executor)


# Generated at 2022-06-26 08:28:41.404755
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():

    print("ExecutorResolver.close: BEGIN")

    # Create an object of class ExecutorResolver
    resolver = ExecutorResolver()

    # Close the resolver
    resolver.close()

    print("ExecutorResolver.close: END")


# Generated at 2022-06-26 08:28:46.046724
# Unit test for function add_accept_handler
def test_add_accept_handler():
    bind_sockets_0 = bind_sockets(30000)
    add_accept_handler_0 = add_accept_handler(bind_sockets_0[0], None)
    io_loop_1 = IOLoop()
    io_loop_1.add_handler(bind_sockets_0[0], None, None)
    io_loop_1.remove_handler(bind_sockets_0[0])
    add_accept_handler_0()


# Generated at 2022-06-26 08:28:55.274249
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    dictionary = {'a': 3}
    override_resolver_0 = OverrideResolver(default_executor_resolver_0, dictionary)
    host = 'ABC'
    port = 9
    family = socket.AF_UNSPEC

    # Call method under test
    result = override_resolver_0.resolve(host, port, family)

    # Check that result is as expected
    if result is None:
        raise TornadoError('Result is None')


# Generated at 2022-06-26 08:29:05.950529
# Unit test for function add_accept_handler
def test_add_accept_handler():
    # sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(False)
    print("Bind to: ", "/tmp/test_add_handler.sock")
    sock.bind("/tmp/test_add_handler.sock")
    sock.listen(128)
    os.chmod("/tmp/test_add_handler.sock", 0o600)

    def callback(connection, address):
        print("Accepted", "connection", "address", connection, address)

    # Remove the handler

# Generated at 2022-06-26 08:29:15.988959
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # DefaultExecutorResolver
    default_executor_resolver_0 = DefaultExecutorResolver()
    # keepalive_timeout is missing
    with pytest.raises(ValueError) as err:
        default_executor_resolver_0.close()
    # ThreadedResolver
    threaded_resolver_0 = ThreadedResolver()
    # keepalive_timeout is missing
    with pytest.raises(ValueError) as err:
        threaded_resolver_0.close()
    # close_resolver is missing
    threaded_resolver_1 = ThreadedResolver()
    with pytest.raises(ValueError) as err:
        threaded_resolver_1.close()
    # OverrideResolver
    override_resolver_0 = OverrideResolver()
    # keepalive_timeout

# Generated at 2022-06-26 08:29:27.146284
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    import tempfile

    temp_sockfile = tempfile.NamedTemporaryFile(prefix='unix_sock')
    temp_sockfile.close()
    temp_name = temp_sockfile.name
    try:
        print("creating socket")
        sock = bind_unix_socket(temp_name)
        print("created socket, port: " + str(sock.getsockname()))
    finally:
        print("deleting socket")
        os.remove(temp_name)


# Generated at 2022-06-26 08:29:45.347216
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    my_resolver = OverrideResolver()
    my_mapping = dict()
    my_mapping = {"foo": "bar"}

    my_resolver.initialize(my_resolver, my_mapping)
    my_resolver.resolve("www.google.com", 80)
    my_resolver.close()

# Generated at 2022-06-26 08:29:57.673817
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(False)

    sock.bind(("127.0.0.2", 9999))
    sock.listen(5)

    def callback(connection, address):
        print("accept!")
        print("address: {}".format(address))

    # Server
    add_accept_handler(sock, callback)

    # Client
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("127.0.0.2", 9999))
    IOLoop.current().start()


# Generated at 2022-06-26 08:30:06.463232
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    """Test for resolve of class OverrideResolver"""
    for arg0 in ['']:
        for arg1 in [80]:
            for arg2 in [socket.AF_UNSPEC]:
                if arg0 in ['0.0.0.0', '127.0.0.1', 'localhost']:
                    try:
                        override_resolver_0 = OverrideResolver()
                        awaitable_0 = override_resolver_0.resolve(arg0, arg1, arg2)
                    except:
                        print("Test case failed for args %s %s %s" % (arg0, arg1, arg2))

# Generated at 2022-06-26 08:30:07.146128
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    assert DefaultExecutorResolver.resolve(None, None, None) is None


# Generated at 2022-06-26 08:30:08.300293
# Unit test for function bind_sockets
def test_bind_sockets():
    print("Call test_bind_sockets")

    test_case_0()


# Generated at 2022-06-26 08:30:10.215673
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    host_0 = "ACO"
    port_0 = 42
    family_0: socket.AddressFamily = socket.AF_UNSPEC
    default_executor_resolver_0 = DefaultExecutorResolver()
    default_executor_resolver_0.resolve(host_0, port_0, family_0)



# Generated at 2022-06-26 08:30:13.807271
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    test_case_0()

# Tornado.netutil module

# Generated at 2022-06-26 08:30:24.919498
# Unit test for function bind_sockets
def test_bind_sockets():
    bind_sockets_0 = bind_sockets(8888, "")
    bind_sockets_1 = bind_sockets(8888, "localhost")
    bind_sockets_2 = bind_sockets(8888, "localhost", socket.AF_INET)
    bind_sockets_3 = bind_sockets(8888, "localhost", socket.AF_INET6)
    bind_sockets_4 = bind_sockets(8888, "localhost", socket.AF_UNSPEC)
    bind_sockets_5 = bind_sockets(8888, "localhost", socket.AF_UNSPEC, 128)
    flags = socket.AI_PASSIVE | socket.AI_NUMERICHOST
    bind_sockets_6 = bind_sockets(8888, "localhost", socket.AF_UNSPEC, 128, flags)

# Generated at 2022-06-26 08:30:30.902827
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor: Optional[concurrent.futures.Executor] = None
    close_executor: bool = True
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize(executor, close_executor)


# Generated at 2022-06-26 08:30:35.350808
# Unit test for function add_accept_handler
def test_add_accept_handler():
    class Test(object):

        def __call__(self):
            return 0

    test0 = Test()
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    remove_handler = add_accept_handler(sock, test0)
    print(type(remove_handler))
    print(remove_handler())

test_add_accept_handler()

# Generated at 2022-06-26 08:30:49.306511
# Unit test for function add_accept_handler
def test_add_accept_handler():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 0))
    port = sock.getsockname()[1]
    sock.listen(_DEFAULT_BACKLOG)
    remove_handler = add_accept_handler(sock, print)
    remove_handler()
    sock.close()


# Generated at 2022-06-26 08:30:54.871083
# Unit test for function add_accept_handler
def test_add_accept_handler():
    print("==============================")
    print("Unit test for add_accept_handler")
    print("==============================")
    def connection_callback(connection: socket.socket, address: Any):
        print("connection_callback")

    def remove_callback():
        print("remove_callback")

    sock = bind_sockets(port=12345)
    remove_handler = add_accept_handler(sock[0], connection_callback)
    remove_callback()
    remove_handler()
    print("Test pass")
    print()
    return True


# Generated at 2022-06-26 08:31:00.518504
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # TODO: Add more tests
    # Case 0 of 1
    default_executor_resolver_0 = DefaultExecutorResolver()
    mapping = {}
    override_resolver = OverrideResolver(default_executor_resolver_0, mapping)
    host = 'localhost'
    port = 80
    family = socket.AddressFamily.AF_UNSPEC
    override_resolver.resolve(host, port, family)
    return

# Generated at 2022-06-26 08:31:14.830957
# Unit test for method close of class ExecutorResolver

# Generated at 2022-06-26 08:31:17.262643
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = dummy_executor
    close_executor = True
    executor_resolver_0 = ExecutorResolver(executor, close_executor)
    executor_resolver_0.close()


# Generated at 2022-06-26 08:31:18.516719
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options_0 = {}
    ssl_options_to_context(ssl_options_0)


# Generated at 2022-06-26 08:31:26.937809
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    # initialize parameter 1: executor_0 = dummy_executor
    executor_0 = dummy_executor
    # initialize parameter 2: close_executor_0 = True
    close_executor_0 = True
    # Test class ExecutorResolver
    executor_resolver_0 = ExecutorResolver()
    # Test method initialize of class ExecutorResolver
    executor_resolver_0.initialize(executor_0, close_executor_0)


# Generated at 2022-06-26 08:31:31.200808
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    #assert await default_executor_resolver_0.resolve('localhost', 8080) == [], "Assertion error"

if __name__ == '__main__':
    test_case_0()
    test_DefaultExecutorResolver_resolve()

# Generated at 2022-06-26 08:31:42.579624
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolve_resolver_1 = OverrideResolver(resolver=DefaultExecutorResolver(), mapping={})
    resolve_host_1 = "192.168.0.1"
    resolve_port_1 = 9999
    resolve_family_1 = socket.AF_UNSPEC
    try:
        resolve_ret_1 = resolve_resolver_1.resolve(resolve_host_1,
                                                   resolve_port_1,
                                                   resolve_family_1)
        print("resolve_ret_1:", resolve_ret_1)
    except Exception as resolve_ret_1:
        print("resolve_ret_1:", resolve_ret_1)


# Generated at 2022-06-26 08:31:45.755787
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver = ExecutorResolver()
    executor_resolver.close()


# Generated at 2022-06-26 08:31:56.428250
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.close()


# Generated at 2022-06-26 08:31:59.063734
# Unit test for function ssl_wrap_socket
def test_ssl_wrap_socket():
    from tornado.test.httpclient_test import (
        AsyncHTTPTestCase,
        HTTPConnectionCloseTestCase
    )
    print('test_ssl_wrap_socket...')
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 08:32:02.048162
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.close()


# Generated at 2022-06-26 08:32:08.665193
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(port=8888, address='127.0.0.1')
    assert(sockets[0].getsockname()[0] == '127.0.0.1')
    assert(sockets[0].getsockname()[1] == 8888)

if __name__ == "__main__":
    # Use this main function to test the unit tests above
    def print_test_results(results):
        for result in results:
            print(result)

    test_results = [
        test_bind_sockets()
    ]
    print_test_results(test_results)

# Generated at 2022-06-26 08:32:12.120818
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executorResolver_0 = ExecutorResolver()
    executorResolver_0.initialize(dummy_executor, True)


# Generated at 2022-06-26 08:32:21.377329
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    print('Testing ExecutorResolver.initialize()')
    # Test case 0
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.initialize()
    test_case_0()
    # Test case 1
    executor_resolver_1 = ExecutorResolver()
    executor_resolver_1.initialize(dummy_executor, True)
    # Test case 2
    executor_resolver_2 = ExecutorResolver()
    executor_resolver_2.initialize(dummy_executor, False)
    # Test case 3
    executor_resolver_3 = ExecutorResolver()
    executor_resolver_3.initialize(None, False)
    # Test case 4
    executor_resolver_4 = ExecutorResolver()


# Generated at 2022-06-26 08:32:28.418046
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    my_override_resolver_1 = OverrideResolver()
    my_resolver_2 = BlockingResolver()
    my_dict_3 = dict()
    my_override_resolver_1.initialize(my_resolver_2, my_dict_3)
    # TOCHECK: test for variable 'host'
    # TOCHECK: test for variable 'port'
    # TOCHECK: test for variable 'family'
    my_override_resolver_1.resolve(host, port, family)


# Generated at 2022-06-26 08:32:30.421693
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    pass


# Generated at 2022-06-26 08:32:39.422910
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Test
    resolver = DefaultExecutorResolver()
    mapping = {"example.com": "127.0.1.1"}
    resolver_override = OverrideResolver(resolver, mapping)
    resolver_override.resolve("example.com", 80)
    resolver_override.resolve("example.com", 80, socket.AF_INET6)
    resolver_override.resolve("github.com", 80, socket.AF_UNSPEC)



# Generated at 2022-06-26 08:32:51.876158
# Unit test for function add_accept_handler
def test_add_accept_handler():
    io_loop = IOLoop.current()

    def print_connection(connection, address):
        print(connection, address)

    # create a socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 0))
    sock.listen(10)

    # add the callback function to IOLoop
    add_accept_handler(sock, print_connection)

    # create another socket
    another_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    another_sock.connect(sock.getsockname())

    # run IOloop
    io_loop.start()



# Generated at 2022-06-26 08:33:15.062345
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    future_0: Future[urllib3.util.wait.WAIT_TIMEOUT] = asyncio.Future()

    def _callback_0(future: Future) -> None:
        assert isinstance(future, (Future,))
        future_0.set_result(future.result())

    default_executor_resolver_0.resolve("127.0.0.1", 0).add_done_callback(_callback_0)


# Generated at 2022-06-26 08:33:22.580175
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():

    # Arrange
    self = ExecutorResolver()

    # Act
    self.close()

    # Assert
    try:
        assert_equal(self.executor, None)
    except AssertionError as e:
        print(e)
        import sys
        sys.exit()


# Generated at 2022-06-26 08:33:27.203587
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(1024, reuse_port=False)
    print("test_bind_sockets: sockets = %s" % sockets)
    for sock in sockets:
        print("test_bind_sockets: sock = ", sock)


# Generated at 2022-06-26 08:33:38.440772
# Unit test for function add_accept_handler
def test_add_accept_handler():
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_sock.setblocking(False)
    server_sock.bind(('', 1234))
    server_sock.listen(5)
    client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    client_sock.setblocking(False)
    try:
        client_sock.connect(('localhost', 1234))
    except BlockingIOError:
        pass

    # accept the connection from the client
    def accept_handler(connection, address):
        print('accepted connection from', address)
       

# Generated at 2022-06-26 08:33:40.006866
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    assert True


# Generated at 2022-06-26 08:33:46.826112
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver(None)
    executor_resolver_0.close()
    executor_resolver_1 = ExecutorResolver()
    executor_resolver_1.close()
    executor_resolver_2 = ExecutorResolver(dummy_executor, False)
    executor_resolver_2.close()


# Generated at 2022-06-26 08:33:52.494679
# Unit test for function add_accept_handler
def test_add_accept_handler():
    ports = [8888, 6666]

    def on_accept(conn, address):
        print('Client connection from %s:%d' % (address[0], address[1]))

    for port in ports:
        sockets = bind_sockets(port)
        for sock in sockets:
            remove_handler = add_accept_handler(sock, on_accept)
        IOLoop.current().start()


# Generated at 2022-06-26 08:33:55.138904
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor_resolver_0 = ExecutorResolver()
    executor_resolver_0.close()


# Generated at 2022-06-26 08:34:00.188510
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    # Setup
    executor_resolver = ExecutorResolver()

    # Exercise
    executor_resolver.close()
    # Verify



# Generated at 2022-06-26 08:34:05.544033
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # create a Resolver instance.
    default_executor_resolver = DefaultExecutorResolver()

    # call resolve method to resolve the specified address.
    result = default_executor_resolver.resolve("www.google.com", 80)
    print("Result: " + str(result))


# Generated at 2022-06-26 08:34:43.737093
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    # Test arguments.
    host = "host"
    port = 80
    family = socket.AddressFamily.AF_UNSPEC
    # Test conditions.
    # Test actions.
    default_executor_resolver = DefaultExecutorResolver()
    # Test assertions.
    future = default_executor_resolver.resolve(host, port, family)

    # Test conditions.
    # Test actions.
    tornado.ioloop.IOLoop.current().run_sync(lambda : future)
    # Test assertions.
    # Test exceptions.

    # Test conditions.
    # Test actions.
    # Test assertions.
    # Test exceptions.


# Generated at 2022-06-26 08:34:47.044474
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():

    resolver = Resolver()
    with pytest.raises(NotImplementedError):
        resolver.resolve("", 0)


# Generated at 2022-06-26 08:34:51.799935
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    mapping_0 = dict()
    resolver_0 = BlockingResolver()
    override_resolver_0 = OverrideResolver(resolver_0, mapping_0)
    host_0 = '127.0.0.1'
    port_0 = 25
    override_resolver_0.resolve(host_0, port_0)

# Generated at 2022-06-26 08:35:01.620072
# Unit test for function is_valid_ip
def test_is_valid_ip():
    is_valid_ip("")
    is_valid_ip("123.123.123.123")
    is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")

if hasattr(socket, "AF_UNIX"):
    # Unit test for function bind_unix_socket
    def test_bind_unix_socket():
        bind_unix_socket("/tmp/test.sock")


# Generated at 2022-06-26 08:35:07.016742
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    executor = None
    close_executor = True
    executorResolver = ExecutorResolver(executor, close_executor)
    executorResolver.close()
    assert True


# Generated at 2022-06-26 08:35:17.633307
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver0 = OverrideResolver(executor, mapping)
    host0 = "Y"
    port0 = 17178
    family0 = socket.AF_INET
    async def awaitable0():
        pass
    awaitable0()
    awaitable0().send(None)
    awaitable0().send(None)
    awaitable0().close()
    awaitable = awaitable0()
    awaitable0 = None # Prevent GC from clearing the awaitable
    awaitable.send(None)
    result = awaitable.send(None)
    host = host0
    port = port0
    family = family0
    print(awaitable)
    print(host)
    print(port)
    print(family)
    print(result)


# Generated at 2022-06-26 08:35:27.478312
# Unit test for function add_accept_handler
def test_add_accept_handler():
    print('*************add_accept_handler****************')
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock.bind(('127.0.0.1',9000))
    sock.listen(128)
    def callback(sock, address):
        print(sock)
        print(address)

    add_accept_handler(sock, callback)
    #print('add_accept_handler: %s'%(str(add_accept_handler(sock, callback))))
    #print('IOLoop: %s'%(str(IOLoop.current())))
    #add_accept_handler(sock, callback)
    IOLoop.current().start()

    #print('add_accept_handler: %s'%(str(add_accept_handler(s

# Generated at 2022-06-26 08:35:38.178970
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    default_executor_resolver_0 = DefaultExecutorResolver()
    loop_0 = IOLoop.current()
    def thread_run_in_executor_0(args: List[Any], kwargs: Dict[str, Any]) -> Any:
        return _resolve_addr(*args, **kwargs)
    future = loop_0.run_in_executor(None, thread_run_in_executor_0, ["8.8.8.8", 720, 0])
    addrinfo = future.result()
    assert(len(addrinfo) == 1)
    assert(addrinfo[0] == (2, ('8.8.8.8', 720)))


# Generated at 2022-06-26 08:35:48.476754
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    # set up the client
    executor: Optional[concurrent.futures.Executor] = None
    close_executor: bool = True
    resolver_0 = ExecutorResolver(executor, close_executor)

    host: str = "127.0.0.1"
    port: int = 8888
    family: socket.AddressFamily = socket.AF_UNSPEC
    # call the method
    async def call_resolve():
        result_0 = await resolver_0.resolve(host, port, family)
        print(result_0)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(call_resolve())

# Generated at 2022-06-26 08:35:59.705654
# Unit test for function bind_sockets
def test_bind_sockets():
    port = 8001
    address = "0.0.0.0"
    family = socket.AF_UNSPEC
    backlog = 128
    flags = socket.AI_PASSIVE | socket.AI_NUMERICHOST
    reuse_port = False
    sockets = bind_sockets(port, address, family, backlog, flags, reuse_port)
    assert len(sockets) == 1
    assert sockets[0].getsockname()[0] == address
    assert sockets[0].getsockname()[1] == port


# Generated at 2022-06-26 08:37:29.305452
# Unit test for function bind_sockets
def test_bind_sockets():
    port = None
    address = "localhost"
    family = socket.AF_UNSPEC
    backlog = 128
    flags = socket.AI_PASSIVE
    reuse_port = True
    result = bind_sockets(
        port, address, family, backlog, flags, reuse_port
    )
    print(result)

###############################################################################
# vim:et:sts=4:sw=4:tw=80:

# Generated at 2022-06-26 08:37:41.079706
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    ssl_options_0={
            "ssl_version": ssl.PROTOCOL_SSLv23,
            "certfile": "certfile.crt",
            "keyfile": "PrivateKey.key",
            "cert_reqs": ssl.CERT_REQUIRED,
            "ca_certs": "ca_certs.crt",
            "ciphers": "ciphers.crt"
    }