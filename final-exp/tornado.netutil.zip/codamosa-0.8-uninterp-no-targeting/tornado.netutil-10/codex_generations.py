

# Generated at 2022-06-22 04:07:21.005225
# Unit test for function bind_sockets
def test_bind_sockets():
    sockets = bind_sockets(0)
    assert sockets[0].getsockname()[1]
    assert len(socket.getaddrinfo(None, 0, socket.AF_UNSPEC, socket.SOCK_STREAM)) == len(
        sockets
    )
    assert len(socket.getaddrinfo("localhost", 0, socket.AF_UNSPEC, socket.SOCK_STREAM)) == len(
        sockets
    )
    assert len(
        socket.getaddrinfo("localhost", 0, socket.AF_INET, socket.SOCK_STREAM)
    ) + len(socket.getaddrinfo("localhost", 0, socket.AF_INET6, socket.SOCK_STREAM)) == len(
        sockets
    )



# Generated at 2022-06-22 04:07:26.722400
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    import multiprocessing

    # Create a thread and use it to create a ThreadedResolver instance
    def init_ThreadedResolver():
        resolver = ThreadedResolver()
        return resolver

    pool = multiprocessing.Pool(processes=1)
    result = pool.apply(init_ThreadedResolver)
    pool.close()
    pool.join()

# Generated at 2022-06-22 04:07:31.047728
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection, address)

    add_accept_handler(sock, callback)
    def remove_handler() -> None:
        io_loop.remove_handler(sock)
        removed[0] = True
    remove_handler()



# Generated at 2022-06-22 04:07:38.904691
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    # Test the close method in class OverrideResolver
    resolver = Resolver()
    mapping = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    resol = OverrideResolver(resolver,mapping)
    resol.close()


# Generated at 2022-06-22 04:07:41.867062
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    import concurrent.futures
    t = ThreadedResolver()
    assert t.executor is None
    t.initialize()
    assert isinstance(t.executor,concurrent.futures.ThreadPoolExecutor)



# Generated at 2022-06-22 04:07:46.444898
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    print("--- test_BlockingResolver ---")
    br = BlockingResolver()
    async def do_run():
        ret = await br.resolve("www.google.com",80)
        print(ret)
    asyncio.get_event_loop().run_until_complete(do_run())



# Generated at 2022-06-22 04:07:52.670910
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    executor: Optional[concurrent.futures.Executor] = fd_diff_executor
    close_executor: bool = True
    assert ExecutorResolver.initialize(executor, close_executor) is None
    assert ExecutorResolver.initialize() is None


# Generated at 2022-06-22 04:08:01.008407
# Unit test for function ssl_options_to_context
def test_ssl_options_to_context():
    import ssl
    ssl_options = {
        "ssl_version": ssl.PROTOCOL_SSLv23,
        "certfile": "certfile",
        "keyfile": "keyfile",
        "cert_reqs": ssl.CERT_NONE,
        "ca_certs": "ca_certs",
        "ciphers": "ciphers"
    }
    context = ssl_options_to_context(ssl_options)
    for ssl_opt in ["ssl_version", "certfile", "keyfile", "cert_reqs", "ca_certs", "ciphers"]:
        assert ssl_options[ssl_opt] == getattr(context, ssl_opt)

    assert isinstance(context, ssl.SSLContext)



# Generated at 2022-06-22 04:08:02.160459
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def handle(sock, address):
        pass
    t = bind_sockets(8010)
    add_accept_handler(t[0], handle)



# Generated at 2022-06-22 04:08:05.081978
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    assert hasattr(socket, "AF_UNIX")


# Generated at 2022-06-22 04:08:44.665984
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # setUp
    host = 'google.com'
    family = 0
    port = 80
    resolver = Resolver()
    # These two commented lines make test fail as expected
    #mapping =  {'facebook.com': '127.0.0.1'}
    #mapping =  {'facebook.com':'facebook.com'}
    #mapping =  {'facebook.com':'facebook.com', 'google.com':'google.com'}
    mapping = {'facebook.com': '127.0.0.1', 'google.com': 'google.com'}
    instance = OverrideResolver(resolver, mapping)
    # test
    resolved = instance.resolve(host, port, family)
    # tearDown
    del instance



# Generated at 2022-06-22 04:08:49.341652
# Unit test for method initialize of class ThreadedResolver
def test_ThreadedResolver_initialize():
    obj = ThreadedResolver()
    res = obj.initialize()
    return res


# Generated at 2022-06-22 04:08:50.403545
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    resolver = OverrideResolver(Resolver(), {})
    assert resolver


# Generated at 2022-06-22 04:08:55.198898
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    import aiohttp
    import tornado.web
    import asyncio
    import concurrent.futures
    import types
    import inspect

    class ProxyHandler(tornado.web.RequestHandler):

        async def get(self):
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=10)
            loop = asyncio.get_running_loop()
            resolver = ExecutorResolver(executor)
            res = await resolver.resolve(self.get_query_argument('host'),
                                         self.get_query_argument('port'))
            print(res)

    app = tornado.web.Application([
        ('/proxy', ProxyHandler),
    ])
    app.listen(8080)
    tornado.ioloop.IOLoop.current().start()


# Generated at 2022-06-22 04:08:57.642815
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    '''
    Test method initialize of class OverrideResolver
    '''
    pass # You cannot call tests from outside of the tests package


# Generated at 2022-06-22 04:09:00.821240
# Unit test for method close of class Resolver
def test_Resolver_close():
    configurable_cls = Configurable.configurable_default() # type: Type [Configurable]
    obj = configurable_cls.configurable_base()
    obj.close()



# Generated at 2022-06-22 04:09:03.377403
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    resolv = BlockingResolver()
    resolv.initialize()
    # test if initializer works:
    resolv.io_loop
    resolv.executor
    resolv.close_executor
    # test if the class is not abstract
    resolv.resolve('', '')
    
    
    

# Generated at 2022-06-22 04:09:04.659384
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    resolver = ExecutorResolver()
    resolver.initialize()
    assert_equal(type(resolver.io_loop), IOLoop)


# Generated at 2022-06-22 04:09:10.485599
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        print(connection)
        print(address)
    sock = socket.socket()
    sock.bind(("127.0.0.1", 8080))
    sock.listen(128)
    remove_handler = add_accept_handler(sock, callback)
    remove_handler()
# test_add_accept_handler()



# Generated at 2022-06-22 04:09:13.337290
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    resolver = OverrideResolver()
    assert resolver.resolve('example.com', 5, 4) == []


# Generated at 2022-06-22 04:09:41.373923
# Unit test for function bind_sockets
def test_bind_sockets():
    print('Start test bind_sockets...')
    # bind '0.0.0.0' or '::' should fail on windows without SO_EXCLUSIVEADDRUSE
    sockets = bind_sockets(8888, address='0.0.0.0', family=socket.AF_INET)
    assert len(sockets) == 1
    sockets = bind_sockets(8888, address='::', family=socket.AF_INET6)
    assert len(sockets) == 1
    print('OK test bind_sockets')



# Generated at 2022-06-22 04:09:54.301063
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    host="baidu.com"
    port=80
    family=socket.AF_UNSPEC
    # 解析IPV4地址
    for res in socket.getaddrinfo(host, port):
        af, socktype, proto, canonname, sockaddr = res
        if af == socket.AF_INET:
            print(res) # 输出ipv4地址信息
            print(sockaddr) # 输出ipv4地址列表
            print(sockaddr[0]) # 输出ipv4地址
            print(sockaddr[1]) # 输出端口号
            print(sockaddr[2:]) # 其他

# Generated at 2022-06-22 04:10:05.388268
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    import concurrent
    import sys
    import unittest

    class TestExecutorResolver(unittest.TestCase):
        def test_initialize(self):
            self.assertEqual(ExecutorResolver().initialize(), None)
            self.assertEqual(ExecutorResolver().initialize(executor=None,close_executor=True), None)

    suite = unittest.TestLoader().loadTestsFromModule(
        TestExecutorResolver())
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        sys.exit(1)


# Generated at 2022-06-22 04:10:09.836161
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    # pylint: disable=unused-variable
    ExecutorResolver(executor=None, close_executor=True)
    ExecutorResolver(executor=None, close_executor=False)
    ExecutorResolver(executor=dummy_executor, close_executor=False)
    ExecutorResolver(executor=dummy_executor, close_executor=True)



# Generated at 2022-06-22 04:10:14.736125
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    sock = bind_unix_socket('hello.sock', mode=0o600, backlog=128)
    assert sock.fileno()
    os.remove('hello.sock')


# Generated at 2022-06-22 04:10:16.243351
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    with pytest.raises(AssertionError, match=r"Not implements! Please add this"):
        test = OverrideResolver()
    # test = OverrideResolver()



# Generated at 2022-06-22 04:10:17.805796
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    resolver = DefaultExecutorResolver(
    )
    assert resolver.resolve



# Generated at 2022-06-22 04:10:21.901345
# Unit test for method resolve of class Resolver
def test_Resolver_resolve():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    asyncio.get_event_loop().run_until_complete(
        lambda: print(Resolver().resolve("127.0.0.1",0,socket.AF_INET))
    )

# Generated at 2022-06-22 04:10:29.655881
# Unit test for method initialize of class ExecutorResolver
def test_ExecutorResolver_initialize():
    test = ExecutorResolver()
    executor = dummy_executor
    close_executor = True
    test.initialize(executor, close_executor)
    assert test.executor == dummy_executor, "test.executor == dummy_executor"
    assert test.close_executor, "test.close_executor"
    assert test.__class__ == ExecutorResolver, "test.__class__ == ExecutorResolver"



# Generated at 2022-06-22 04:10:33.681376
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    resolver = BlockingResolver()
    print(isinstance(resolver, (BlockingResolver, ExecutorResolver, Resolver, Configurable)))
    resolver.initialize()


# Generated at 2022-06-22 04:10:49.059477
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    resolver = ExecutorResolver()
    assert resolver.resolve("localhost", 8080)


# Generated at 2022-06-22 04:10:53.472476
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    resolver = thread_resolver()
    mapping = {"example.com": "127.0.1.1"}
    override_resolver = OverrideResolver(resolver, mapping)
    #assert override_resolver.resolver == resolver
    #assert override_resolver.mapping == mapping


# Generated at 2022-06-22 04:10:59.694840
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    resolver = ThreadedResolver()
    assert isinstance(resolver, ExecutorResolver)  # type: ignore
    assert resolver.executor is not None
    assert isinstance(resolver.executor, concurrent.futures.ThreadPoolExecutor)
    assert resolver.executor.shutdown is None
    assert resolver.close_executor is True
    # test close
    resolver.close()
    assert isinstance(resolver.executor.shutdown, collections.abc.Callable)



# Generated at 2022-06-22 04:11:02.513179
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    def __init__(self, resolver: Resolver, mapping: dict):
        self.resolver = resolver
        self.mapping = mapping
    def close(self):
        self.resolver.close()  
    resolver = Resolver()
    mapping = {}
    ik = OverrideResolver(resolver, mapping)
    ik.close()
    assert ik is not None

# Generated at 2022-06-22 04:11:03.806841
# Unit test for function bind_unix_socket
def test_bind_unix_socket():
    assert bind_unix_socket('/tmp/foo') is not None


# Generated at 2022-06-22 04:11:05.827301
# Unit test for constructor of class Resolver
def test_Resolver():
    r = Resolver()
    try:
        r.resolve("localhost", "")
    except NotImplementedError as err:
        pass



# Generated at 2022-06-22 04:11:06.599395
# Unit test for constructor of class Resolver
def test_Resolver():
    pass



# Generated at 2022-06-22 04:11:09.235457
# Unit test for method close of class Resolver
def test_Resolver_close():
    assert Resolver.close(Resolver) == None

# Generated at 2022-06-22 04:11:22.902766
# Unit test for function add_accept_handler
def test_add_accept_handler():
    class Handler:
        def __init__(self, socket: socket.socket, callback: Callable[[socket.socket, Any], None]):
            self.socket = socket
            self.callback = callback
            self.removed = False

        def remove_handler(self) -> None:
            """Remove handler for add_accept_handler()."""
            self.removed = True

        def accept_handler(self, fd: socket.socket, events: int) -> None:
            """Callback handler for add_accept_handler().

            Args:
                fd: file descriptor for the socket.
                events: IOLoop events.
            """
            for i in range(_DEFAULT_BACKLOG):
                if self.removed:
                    # The socket was probably closed
                    return

# Generated at 2022-06-22 04:11:25.206961
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    try:
        OverrideResolver.initialize()
        close()
    except Exception as e:
        return False
    return True

# Generated at 2022-06-22 04:12:02.699924
# Unit test for function add_accept_handler
def test_add_accept_handler():
    from tornado.ioloop import IOLoop
    import socket
    import time
    import threading
    # open server port in loop, and bind it to a handler.
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('localhost', 0))
    port = sock.getsockname()[1]
    sock.listen(128)
    removed = False
    def accept_handler(client, address):
        nonlocal removed
        if removed:
            # The socket has been closed
            return
        # close the socket
        client.close()
    def remove_handler():
        nonlocal removed
        removed = True
        io_loop.remove_

# Generated at 2022-06-22 04:12:12.285917
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    resolver = ExecutorResolver(executor=None, close_executor=True)
    assert hasattr(resolver, 'resolve') and callable(resolver.resolve)
    assert hasattr(resolver, 'close') and callable(resolver.close)



# Generated at 2022-06-22 04:12:14.282280
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    BlockingResolver()

BlockingResolver()



# Generated at 2022-06-22 04:12:17.156835
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    resolver = dummy_resolver
    mapping = {}
    obj = OverrideResolver()
    obj.initialize(resolver, mapping)


# Generated at 2022-06-22 04:12:18.104882
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    r = ThreadedResolver()



# Generated at 2022-06-22 04:12:22.397353
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    import asyncio
    resolver = OverrideResolver()
    resolver.close()
    resolver.close()
    resolver.close()

    resolver = OverrideResolver()
    resolver.resolve(host='127.0.1.1',
                     port=443)



# Generated at 2022-06-22 04:12:35.056825
# Unit test for function bind_sockets
def test_bind_sockets():
    if os.name != 'nt':
        port = 1234
        expected_port = 1234
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', port))
        sock.listen(backlog=128)
        print(sock)
        res = bind_sockets(
            1234, address=None, family=socket.AF_INET,
            backlog=128, flags=None, reuse_port=False
        )
        assert res[0].fileno() == sock.fileno()
        assert res[0].getsockname()[1] == expected_port
        sock.close()

test_bind_sockets()

# Generated at 2022-06-22 04:12:37.194419
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    obj = DefaultExecutorResolver()
    result = obj.resolve("localhost",8888,1)
    print(result)

test_DefaultExecutorResolver_resolve()

# Generated at 2022-06-22 04:12:40.559636
# Unit test for function add_accept_handler
def test_add_accept_handler():
    def callback(connection, address):
        pass
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    remove_handler=add_accept_handler(sock, callback)
    remove_handler()
    sock.close()



# Generated at 2022-06-22 04:12:42.527116
# Unit test for method resolve of class DefaultExecutorResolver
def test_DefaultExecutorResolver_resolve():
    addr = DefaultExecutorResolver().resolve('localhost', 80)
    assert addr == [socket.AF_INET, ('127.0.0.1', 80)], 'Test DefaultExecutorResolver.resolve failed'
    print('test_DefaultExecutorResolver_resolve passed')

test_DefaultExecutorResolver_resolve()


# Generated at 2022-06-22 04:13:37.213974
# Unit test for method resolve of class OverrideResolver
def test_OverrideResolver_resolve():
    # Setup
    resolver = OverrideResolver()
    resolver.mapping = {
        "example.com": "127.0.1.1",
        ("login.example.com", 443): ("localhost", 1443),
        ("login.example.com", 443, socket.AF_INET6): ("::1", 1443),
    }
    # Test "Hostname to host or ip"
    host = "example.com"
    port = 80
    family = socket.AF_UNSPEC
    try:
        resolver.resolve(host, port, family)
    except:
        printerr("Expected exception occured in OverrideResolver.resolve")
    # Test "Host+port to host+port"
    host = "login.example.com"
    port = 443
    family = socket.AF_

# Generated at 2022-06-22 04:13:37.741010
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    resolver = DefaultExecutorResolver()


# Generated at 2022-06-22 04:13:48.903258
# Unit test for method resolve of class ExecutorResolver
def test_ExecutorResolver_resolve():
    '''
    Check if the resolve method of class ExecutorResolver is valid.
    '''

    host = 'www.google.com'
    port = 8080
    family = socket.AF_UNSPEC

    # Unit test for case function does not have any exception related to
    # socket.getaddrinfo.
    executor_resolver = ExecutorResolver()
    executor_resolver.resolve(host, port, family)

    # Unit test for case function have an exception related to
    # socket.getaddrinfo.
    host = '123456789'
    executor_resolver = ExecutorResolver()
    executor_resolver.resolve(host, port, family)



# Generated at 2022-06-22 04:13:52.306867
# Unit test for constructor of class ThreadedResolver
def test_ThreadedResolver():
    """Test for constructor of ThreadedResolver."""
    resolver = ThreadedResolver()
    assert isinstance(resolver, ThreadedResolver)
    resolver.initialize()
    assert resolver.executor == dummy_executor
    assert resolver.close_executor
    assert resolver.io_loop == IOLoop.current()
    resolver = ThreadedResolver()
    resolver.initialize(num_threads=5)
    assert isinstance(resolver.executor, concurrent.futures.ThreadPoolExecutor)
    assert not resolver.close_executor


# Generated at 2022-06-22 04:13:54.754194
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    r = BlockingResolver()
    r.initialize()



# Generated at 2022-06-22 04:14:03.390706
# Unit test for method close of class Resolver
def test_Resolver_close():
    """ Unit test for method close of class Resolver.
    """
    import system_test_utils
    import tornado.platform.asyncio

    async_mode = system_test_utils.get_async_mode()
    if async_mode is None:
        print('async_mode not found, skipping test')
        return

    tornado.platform.asyncio.AsyncIOMainLoop().install()
    resolver = tornado.netutil.Resolver()
    resolver.close()


# Generated at 2022-06-22 04:14:05.774524
# Unit test for constructor of class Resolver
def test_Resolver():
    x = Resolver()
    x.resolve('host', 80)
    x.close()

# test for the configurable base and default of Resolver

# Generated at 2022-06-22 04:14:19.107907
# Unit test for constructor of class OverrideResolver
def test_OverrideResolver():
    # 1, hostname to host or ip
    resolver = OverrideResolver(None, mapping={"example.com": "127.0.1.1"})
    assert resolver.mapping["example.com"] == "127.0.1.1"

    # 2, hostname, port to hostname, port
    resolver = OverrideResolver(
        None, mapping={"example.com": "127.0.1.1"}, mapping=(("login.example.com", 443), ("localhost", 1443)))
    assert resolver.mapping[("login.example.com", 443)] == ("localhost", 1443)

    # 3, hostname, port, family to hostname, port

# Generated at 2022-06-22 04:14:23.341314
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close(): 
    resolver = ExecutorResolver() 
    assert isinstance(resolver, ExecutorResolver)
    
    with pytest.raises(AttributeError): 
        ExecutorResolver.resolve(resolver, "http://localhost/", 80)
    
    assert isinstance(resolver.executor, dummy_executor)
    
    resolver.close()
    
    assert resolver.executor is None



# Generated at 2022-06-22 04:14:36.843566
# Unit test for function add_accept_handler
def test_add_accept_handler():
    import unittest as ut
    import threading
    import time
    import socket
    io_loop = IOLoop.current()
    # Start server.
    port = 8899
    class Server:
        def __init__(self, port):
            self.port = port
            self.sock = bind_sockets(port)[0]
            self.sock.setblocking(0)
            self.handler = add_accept_handler(
                self.sock, self.handle
            )
        def handle(self, connection, address):
            connection.close()
        def close(self):
            self.handler()
            self.sock.close()
    server = Server(port)
    # Start clients.

# Generated at 2022-06-22 04:15:09.177168
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    #raise NotImplementedError()
    assert True



# Generated at 2022-06-22 04:15:11.465499
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    Resolver = ExecutorResolver
    r = Resolver()
    assert not r.close_executor
    assert r.executor == dummy_executor


# Generated at 2022-06-22 04:15:13.886164
# Unit test for constructor of class BlockingResolver
def test_BlockingResolver():
    resolver = BlockingResolver()
    assert resolver is not None



# Generated at 2022-06-22 04:15:15.493050
# Unit test for constructor of class DefaultExecutorResolver
def test_DefaultExecutorResolver():
    r = DefaultExecutorResolver()
    assert r is not None



# Generated at 2022-06-22 04:15:23.348910
# Unit test for function is_valid_ip
def test_is_valid_ip():
    assert is_valid_ip("1.2.3.4")
    assert is_valid_ip("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert not is_valid_ip("1.2.3.4.5")
    assert not is_valid_ip("")
    assert not is_valid_ip("foo")
    assert not is_valid_ip("127.0.0.1/20")
test_is_valid_ip()



# Generated at 2022-06-22 04:15:25.304659
# Unit test for method initialize of class BlockingResolver
def test_BlockingResolver_initialize():
    res_loc:BlockingResolver = BlockingResolver()
    res_loc.initialize()
    pass


# Generated at 2022-06-22 04:15:30.770539
# Unit test for method initialize of class OverrideResolver
def test_OverrideResolver_initialize():
    assert "OverrideResolver" == OverrideResolver.__name__
    # assert callable(OverrideResolver.initialize)
    assert "Resolver" == Resolver.__name__
    assert "resolver" in OverrideResolver.__init__.__code__.co_varnames
    assert "mapping" in OverrideResolver.__init__.__code__.co_varnames
    resolver = Resolver()
    mapping = {}
    r = OverrideResolver(resolver, mapping)
    assert r.resolver == resolver
    assert r.mapping == mapping



# Generated at 2022-06-22 04:15:35.456264
# Unit test for constructor of class ExecutorResolver
def test_ExecutorResolver():
    executor = concurrent.futures.ThreadPoolExecutor(4)
    resolver = ExecutorResolver(executor, close_executor=False)
    asyncio.get_event_loop().run_until_complete(resolver.resolve("localhost", 8080))



# Generated at 2022-06-22 04:15:37.968541
# Unit test for method close of class ExecutorResolver
def test_ExecutorResolver_close():
    from concurrent.futures import Executor
    executor = Executor()
    resolver = ExecutorResolver(executor)
    resolver.close()
    # PASS



# Generated at 2022-06-22 04:15:40.341426
# Unit test for method close of class OverrideResolver
def test_OverrideResolver_close():
    resolver = OverrideResolver(resolver = Resolver(), mapping = dict())
    resolver.close()
