

# Generated at 2022-06-25 13:55:28.216831
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases = [
        ('',),
        ('2',),
        ('1.2.3',),
        ('1.2.3-alpha.2',),
        ('1.2.3-alpha.2+baz',),
        ('1.2.3-alpha.2.5',),
        ('1.2.3-alpha.2.5+baz',),
        ('1.2.3+baz',),
        ('1.2.3-alpha.2.5+baz',),
    ]
    for vstring in test_cases:
        loose_version = LooseVersion(vstring)
        semantic_version = SemanticVersion.from_loose_version(loose_version)
        assert semantic_version == vstring


# Generated at 2022-06-25 13:55:38.562732
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion

    loose_version = LooseVersion("1.2.7")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.2.7'
    assert semver.is_stable
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 7

    loose_version = LooseVersion("1.2.7-alpha")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.2.7-alpha'
    assert not semver.is_stable
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch

# Generated at 2022-06-25 13:55:46.635000
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4.5')) == SemanticVersion('1.2.3+4.5')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5')) == SemanticVersion('1.2.3-4.5')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5+4.5')) == SemanticVersion('1.2.3-4.5+4.5')

# Generated at 2022-06-25 13:55:55.834402
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_param_0 = {
        'loose_version': LooseVersion('9.3.1'),
        'method_output': SemanticVersion('9.3.1')
    }

    test_param_1 = {
        'loose_version': LooseVersion('0.1.0'),
        'method_output': SemanticVersion('0.1.0')
    }

    test_param_2 = {
        'loose_version': LooseVersion('0.1.0-alpha'),
        'method_output': SemanticVersion('0.1.0-alpha')
    }


# Generated at 2022-06-25 13:56:03.682857
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-25 13:56:06.510353
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version_0 = SemanticVersion()
    assert version_0.parse('1.0.0') is None
    assert version_0.major == 1
    assert version_0.minor == 0
    assert version_0.patch == 0
    assert version_0.prerelease == ()
    assert version_0.buildmetadata == ()


# Generated at 2022-06-25 13:56:13.819349
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert not SemanticVersion().parse

    with pytest.raises(ValueError) as ei:
        SemanticVersion.from_loose_version(LooseVersion('0.0.0+0'))
    assert 'version must be a tuple of integers' in str(ei.value)

    assert str(SemanticVersion.from_loose_version(LooseVersion('0.0.0'))) == '0.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == '1.2.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('4.5.6'))) == '4.5.6'

# Generated at 2022-06-25 13:56:16.226943
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()
    semantic_version.parse('1.2.3')
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3


# Generated at 2022-06-25 13:56:23.282017
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:56:26.422962
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion(vstring=None)
    assert (semantic_version.major == semantic_version.minor == semantic_version.patch ==
            semantic_version.prerelease == semantic_version.buildmetadata == None), "SemanticVersion object is not created properly"

# Generated at 2022-06-25 13:56:43.461217
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    if sys.version_info.major == 3:
        # PY3 but not PyPy3
        pytest.raises(ValueError, SemanticVersion.from_loose_version, None)
        pytest.raises(ValueError, SemanticVersion.from_loose_version, "version")
        pytest.raises(ValueError, SemanticVersion.from_loose_version, "1a")
        pytest.raises(ValueError, SemanticVersion.from_loose_version, "1")
        pytest.raises(ValueError, SemanticVersion.from_loose_version, "1.a")
        pytest.raises(ValueError, SemanticVersion.from_loose_version, "1.1.a")

# Generated at 2022-06-25 13:56:52.260860
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert repr(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == "SemanticVersion('1.2.3')"
    assert repr(SemanticVersion.from_loose_version(LooseVersion('1.2.3a1'))) == "SemanticVersion('1.2.3-a1')"
    assert repr(SemanticVersion.from_loose_version(LooseVersion('1.2.3a1.b2'))) == "SemanticVersion('1.2.3-a1.b2')"
    assert repr(SemanticVersion.from_loose_version(LooseVersion('1.2a.b'))) == "SemanticVersion('1.2-a.b')"

# Generated at 2022-06-25 13:56:59.433824
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion()
    semantic_version_2 = SemanticVersion()
    semantic_version_3 = SemanticVersion('1.2.3')
    semantic_version_4 = SemanticVersion('1.2.3-alpha')
    semantic_version_5 = SemanticVersion('1.2.3+build')
    semantic_version_6 = SemanticVersion('1.2.3-alpha+build')
    semantic_version_7 = SemanticVersion('1.2.3-alpha.1')
    semantic_version_8 = SemanticVersion('1.2.3-alpha.1+build')
    semantic_version_9 = SemanticVersion('1.2.3-1')

# Generated at 2022-06-25 13:57:02.375436
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Arrange
    # action
    # assert
    try:
        SemanticVersion.from_loose_version(object())
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid assertion raised') 


# Generated at 2022-06-25 13:57:10.823811
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.3.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.is_stable
    loose_version = LooseVersion('0.5.6')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert not semantic_version.is_stable
    loose_version = LooseVersion('0.5.6-beta.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert not semantic_version.is_stable
    assert semantic_version.is_prerelease
    semantic_version = SemanticVersion('1.3.3')
    assert semantic_version.is_stable

# Generated at 2022-06-25 13:57:20.140750
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Ensure that from_loose_version can take a LooseVersion
    # and create a SemanticVersion with the same core version
    # and no prerelease and no build metadata
    loose_version = LooseVersion('1.2.3-a1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert not semantic_version.prerelease
    assert not semantic_version.buildmetadata

    # Ensure that from_loose_version can take a LooseVersion
    # and create a SemanticVersion with the same core version
    # and prerelease and build metadata
    loose_version = LooseVersion('1.2.3-a1+9.8.7')


# Generated at 2022-06-25 13:57:22.852160
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_10 = LooseVersion("1.0.0")
    assert SemanticVersion("1.0.0") == SemanticVersion.from_loose_version(semantic_version_10)


# Generated at 2022-06-25 13:57:31.666592
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test the from_loose_version method of the SemanticVersion class
    """
    base_version = '0.3.3'
    loose_version = LooseVersion(base_version)
    semver_base = SemanticVersion(base_version)
    semver_from_loose = SemanticVersion.from_loose_version(loose_version)
    assert semver_base == semver_from_loose
    assert semver_base <= semver_from_loose
    assert semver_base >= semver_from_loose
    assert not semver_base < semver_from_loose
    assert not semver_base > semver_from_loose

    extra = '+foobar.baz'

# Generated at 2022-06-25 13:57:40.435671
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for the case where the parameter is a LooseVersion that
    # has integers for each value of the version
    loose_version=LooseVersion('1.2.3')
    SemanticVersion.from_loose_version(loose_version)
    # Test for the case where the parameter is a LooseVersion that
    # has integers and strings for each value of the version
    loose_version=LooseVersion('1.2.3a')
    SemanticVersion.from_loose_version(loose_version)
    # Test for the case where the parameter is a string
    loose_version='1.2.3a'
    try:
        SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        pass
    # Test for the case where the parameter is a LooseVersion that
   

# Generated at 2022-06-25 13:57:47.598874
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:57:56.997314
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    print(semantic_version)
    assert isinstance(semantic_version, SemanticVersion) and isinstance(semantic_version, Version) and isinstance(semantic_version, object)


# Generated at 2022-06-25 13:58:04.737076
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:58:10.568943
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    v = SemanticVersion.from_loose_version(loose_version)
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    loose_version = LooseVersion('1.0.0a1')
    v = SemanticVersion.from_loose_version(loose_version)
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Alpha('a1'),)
    assert v.buildmetadata == ()

    loose_version = LooseVersion('1.0.0.dev1')

# Generated at 2022-06-25 13:58:16.916584
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Invalid input
    try:
        SemanticVersion.from_loose_version('hello')
    except ValueError:
        pass
    else:
        assert False, "Invalid input not detected"

    # Set up test input
    input_loose_version = LooseVersion('1.2.3')

    # Execute unit test
    retval = SemanticVersion.from_loose_version(input_loose_version)

    # Verify unit test results
    expected_retval = SemanticVersion('1.2.3')
    assert retval == expected_retval, "Unit test failed"



# Generated at 2022-06-25 13:58:23.711741
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    assert isinstance(SemanticVersion.from_loose_version(loose_version), SemanticVersion)

    loose_version = LooseVersion('1.2.3-alpha.1')
    assert isinstance(SemanticVersion.from_loose_version(loose_version), SemanticVersion)

    loose_version = LooseVersion('1.2.3+sha.1')
    assert isinstance(SemanticVersion.from_loose_version(loose_version), SemanticVersion)

    # Test we have regression from lp:1728943 that allows py3 to work
    loose_version = LooseVersion('1.2.3.dev0')
    assert isinstance(SemanticVersion.from_loose_version(loose_version), SemanticVersion)



# Generated at 2022-06-25 13:58:30.070333
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('2.10.3')) == SemanticVersion('2.10.3')
    assert SemanticVersion.from_loose_version(LooseVersion('2.10.3-1.alpha1')) == SemanticVersion('2.10.3-1.alpha1')
    assert SemanticVersion.from_loose_version(LooseVersion('2.10.3+123.abc.def')) == SemanticVersion('2.10.3+123.abc.def')


# Generated at 2022-06-25 13:58:34.439040
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a default value
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion("1.2.3"))

    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 2
    assert semantic_version_0.patch == 3
    assert not semantic_version_0.is_stable


# Generated at 2022-06-25 13:58:43.369747
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_string_1 = "0.1.2-rc.1+build.1"
    semantic_version_from_string_1 = SemanticVersion(semantic_version_string_1)
    assert semantic_version_from_string_1
    assert not semantic_version_from_string_1.is_prerelease
    assert semantic_version_from_string_1.is_stable
    assert semantic_version_from_string_1.core == (0, 1, 2)
    assert semantic_version_from_string_1.prerelease == ()
    assert semantic_version_from_string_1.buildmetadata == ('build', '1')

    loose_version_from_string_1 = LooseVersion(semantic_version_string_1)
    assert loose_version_from_string_1
    assert loose_version

# Generated at 2022-06-25 13:58:48.320951
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('7.2.1')).vstring == '7.2.1'
    assert SemanticVersion.from_loose_version(LooseVersion('7.2')).vstring == '7.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('7')).vstring == '7.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('7-1')).vstring == '7.0.0-1'
    assert SemanticVersion.from_loose_version(LooseVersion('7-1.1')).vstring == '7.0.0-1.1'

# Generated at 2022-06-25 13:58:55.773274
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a case where the loose version is a correct integer set
    loose_version_0 = LooseVersion('0.1.1')
    assert(SemanticVersion.from_loose_version(loose_version_0) == SemanticVersion('0.1.1'))

    # Test a case where the loose version is an incorrect integer set
    loose_version_1 = LooseVersion('0.a.1')
    try:
        SemanticVersion.from_loose_version(loose_version_1)
        assert(False), "Semantic version should not allow this"
    except ValueError as e:
        assert('Non integer values in %r' % loose_version_1 in str(e))

    # Test a case where the loose version is a correct integer set with extra metadata

# Generated at 2022-06-25 13:59:10.533160
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert(v1 == '1.2.3')
    v2 = SemanticVersion.from_loose_version(LooseVersion('1.2'))
    assert(v2 == '1.2.0')
    v3 = SemanticVersion.from_loose_version(LooseVersion('1.4.5-rc1'))
    assert(v3 == '1.4.5-rc1')
    v4 = SemanticVersion.from_loose_version(LooseVersion('1.4.5+build1234'))
    assert(v4 == '1.4.5+build1234')



# Generated at 2022-06-25 13:59:18.072486
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion("0.8.2")
    assert SemanticVersion("0.8.2") == SemanticVersion.from_loose_version(loose_version_0)
    loose_version_1 = LooseVersion("1.8.2-123")
    assert SemanticVersion("1.8.2-123") == SemanticVersion.from_loose_version(loose_version_1)
    loose_version_2 = LooseVersion("1.8.2alpha")
    assert SemanticVersion("1.8.2-alpha") == SemanticVersion.from_loose_version(loose_version_2)
    loose_version_3 = LooseVersion("1.8.2-alpha.1")
    assert SemanticVersion("1.8.2-alpha.1") == SemanticVersion

# Generated at 2022-06-25 13:59:20.686508
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(
        LooseVersion('1.0.0-alpha')
    ) == SemanticVersion('1.0.0-alpha')



# Generated at 2022-06-25 13:59:23.435965
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("10.0.0.0")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.core == (10, 0, 0)


# Generated at 2022-06-25 13:59:32.354523
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    t0 = SemanticVersion.from_loose_version(LooseVersion("1.9.1-a1"))
    assert t0.vstring == "1.9.1-a1"
    assert t0.major == 1
    assert t0.minor == 9
    assert t0.patch == 1
    assert t0.prerelease == (_Alpha("a"), _Numeric("1"))
    assert t0.buildmetadata == ()
    t1 = SemanticVersion.from_loose_version(LooseVersion("1.9.1-a1+asdf.qwer+zxcv"))
    assert t1.vstring == "1.9.1-a1+asdf.qwer+zxcv"
    assert t1.major == 1
    assert t1.minor == 9
    assert t1.patch

# Generated at 2022-06-25 13:59:35.623724
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion()
    loose_version_1 = LooseVersion()
    try:
        semantic_version_1.from_loose_version(loose_version_1)
    except ValueError:
        pass
    else:
        assert False, "Expected assertion to be raised for test_SemanticVersion_from_loose_version"


# Generated at 2022-06-25 13:59:37.604118
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion.from_loose_version(LooseVersion(semver))
    v2 = SemanticVersion(semver)
    assert v1 == v2

# Generated at 2022-06-25 13:59:46.446266
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # No exception should be raised here
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    # Exception should be raised here
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.0.0.0'))
    except ValueError:
        pass
    except:
        assert False
    # Exception should be raised here
    try:
        SemanticVersion.from_loose_version('1.0.0')
    except ValueError:
        pass
    except:
        assert False
    # Exception should be raised here
    try:
        SemanticVersion.from_loose_version(1)
    except ValueError:
        pass
    except:
        assert False
    # Exception should be raised here

# Generated at 2022-06-25 13:59:54.583631
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion("01.02.03")
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3

    lv = LooseVersion("01.02.03rc1")
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == (_Numeric(1),)

    lv = LooseVersion("01.02.03~rc1")
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3

# Generated at 2022-06-25 14:00:02.560171
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check that a LooseVersion can be used to create a SemanticVersion
    loose_version = LooseVersion('1.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.is_stable
    assert not semantic_version.is_prerelease
    assert semantic_version == loose_version
    assert str(semantic_version) == str(loose_version)
    # Check that a SemanticVersion can be created from a LooseVersion with prerelease and build metadata
    loose_version = LooseVersion('1.9.9-rc.1+build.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert not semantic_version.is_stable
    assert semantic_version.is_prerelease
    assert semantic_

# Generated at 2022-06-25 14:00:14.872235
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test TypeError cases
    with pytest.raises(TypeError) as e:
        # non-string
        SemanticVersion.from_loose_version(1)

    # TypeError raised or not raised
    assert e.type == TypeError

    # Test ValueError cases
    with pytest.raises(ValueError) as e:
        # non-LooseVersion
        SemanticVersion.from_loose_version(SemanticVersion("1.0.0"))

    # ValueError raised or not raised
    assert e.type == ValueError

    # Test float cases

# Generated at 2022-06-25 14:00:22.978723
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:00:28.983715
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test 1: Test success with LooseVersion
    """
    # Setup
    loose_version = LooseVersion("2.1.1")
    # The expected value to be asserted
    expected_value = SemanticVersion("2.1.1")

    # Run the test
    test_value = SemanticVersion.from_loose_version(loose_version)

    # Verify
    assert test_value == expected_value


# Generated at 2022-06-25 14:00:33.407029
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # test whether it accepts LooseVersion instances
    lv = LooseVersion('0.1.1')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 0
    assert sv.minor == 1
    assert sv.patch == 1
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()



# Generated at 2022-06-25 14:00:40.924406
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:00:46.887748
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with no initial value
    semantic_version = SemanticVersion()
    assert isinstance(semantic_version, SemanticVersion)
    assert isinstance(semantic_version, Version)

    # Test with a valid version string
    semantic_version = SemanticVersion('1.2.3')
    assert isinstance(semantic_version, SemanticVersion)
    assert isinstance(semantic_version, Version)

    # Test with a valid version string with a prerelease
    semantic_version = SemanticVersion('1.2.3-rc.1')
    assert isinstance(semantic_version, SemanticVersion)
    assert isinstance(semantic_version, Version)

    # Test with a valid version string with a build metadata

# Generated at 2022-06-25 14:00:54.008236
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test 0
    arg0 = "1.2.3-a.b.c.d"

    instance0_class = SemanticVersion()
    instance0_class.parse(arg0)

    assert instance0_class.major == 1
    assert instance0_class.minor == 2
    assert instance0_class.patch == 3
    assert instance0_class.prerelease == (
        _Numeric(u'a'),
        _Numeric(u'b'),
        _Numeric(u'c'),
        _Numeric(u'd'),
    )
    assert instance0_class.buildmetadata == ()

    loose_version = LooseVersion(arg0)
    instance0 = SemanticVersion.from_loose_version(loose_version)

    assert instance0_class.major == instance0_class.major
   

# Generated at 2022-06-25 14:00:56.393398
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = LooseVersion('1.0')
    semver = SemanticVersion.from_loose_version(v)
    assert semver == '1.0.0'


# Generated at 2022-06-25 14:01:04.329256
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Version (from_loose_version) with mismatched type values
    # Make the assertion below work
    # assertLooseVersion("1.2.3") != "1.2.3"
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) != "1.2.3"

    # Version (from_loose_version) with mismatched type values
    # Make the assertion below work
    # assertLooseVersion("1.2.3") == (1, 2, 3)
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == (1, 2, 3)

    # Version (from_loose_version) with mismatched type values
    # Make the assertion below work
    # assertLooseVersion("1.2.3") < (1

# Generated at 2022-06-25 14:01:13.428711
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Unit test for method from_loose_version of class SemanticVersion
    """

    # From docs
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.dev')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.dev2')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.dev.2')) == SemanticVersion('1.0.0')

# Generated at 2022-06-25 14:01:33.700902
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('1.0.0'));


# Generated at 2022-06-25 14:01:40.118897
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.version import SemanticVersion
    from ansible.module_utils.compat.version import LooseVersion

    test_cases = (
        "foo",
        "1.2.3",
        "1.2.3.4",
        "1.2b3",
        "1.2.3a4",
    )

    for test_case in test_cases:
        loose_version = LooseVersion(test_case)
        assert SemanticVersion.from_loose_version(loose_version).vstring == test_case

    with pytest.raises(ValueError) as exc:
        SemanticVersion.from_loose_version("foo")

# Generated at 2022-06-25 14:01:46.431394
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test LooseVersion input
    loose_version = LooseVersion('1.2.3')
    assert isinstance(SemanticVersion.from_loose_version(loose_version), SemanticVersion)

    # Test error on non-LooseVersion input
    non_LooseVersion = '1.2.3'
    try:
        SemanticVersion.from_loose_version(non_LooseVersion)
    except ValueError:
        pass
    else:
        assert (False, 'Exception not thrown')

    # Test error on LooseVersion with non int values
    loose_version = LooseVersion('1.2.3-alpha')
    try:
        SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        pass

# Generated at 2022-06-25 14:01:51.312827
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create a LooseVersion and ensure it is a LooseVersion
    loose_version = LooseVersion('1.0.0')
    assert isinstance(loose_version, LooseVersion)
    # Convert it to a SemanticVersion and ensure it is a SemanticVersion
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semantic_version, SemanticVersion)
    # Ensure the resulting semantic version is the same
    # as if the string were used
    assert semantic_version == '1.0.0'


# Generated at 2022-06-25 14:01:58.353589
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("0.0.1-1-abc")

    # Verify acceptable cases
    assert SemanticVersion.from_loose_version(loose_version)
    assert SemanticVersion.from_loose_version("0.0.1-1-abc")

    # Verify unacceptable cases
    for val in ("0.0.1-1-", "0.0.1-1-1.1.1"):
        fails = True
        try:
            SemanticVersion.from_loose_version(val)
        except ValueError:
            fails = False
        assert fails, "invalid prerelease is acceptable"


# Generated at 2022-06-25 14:02:00.503620
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_1 = LooseVersion('0.2.0')
    assert SemanticVersion.from_loose_version(loose_version_1).vstring == '0.2.0'


# Generated at 2022-06-25 14:02:03.286924
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that invalid inputs raise
    for input_type in ((), [], object()):
        try:
            SemanticVersion.from_loose_version(input_type)
        except ValueError:
            pass
        else:
            assert False


# Generated at 2022-06-25 14:02:05.930984
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = test_case_0.loose_version
    semantic_version = test_case_0.semantic_version
    assert isinstance(semantic_version, SemanticVersion)
    assert(semantic_version == loose_version)

# Generated at 2022-06-25 14:02:13.913155
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import unittest

    class TestSemanticVersion_from_loose_version(unittest.TestCase):
        def test_case_0(self):
            v_0 = LooseVersion('2.10.1')
            v_1 = SemanticVersion.from_loose_version(v_0)
            self.assertEqual(str(v_1), '2.10.1')

        def test_case_1(self):
            v_0 = LooseVersion('2.10.1-beta.1')
            v_1 = SemanticVersion.from_loose_version(v_0)
            self.assertEqual(str(v_1), '2.10.1-beta.1')

    # Run unit tests

# Generated at 2022-06-25 14:02:21.089029
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:02:42.467177
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Case 0: Pass in a LooseVersion with a stable version
    loose_version_0 = LooseVersion('2.12.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.vstring == '2.12.1'
    assert semantic_version_0.is_stable
    assert not semantic_version_0.is_prerelease

    # Case 1: Pass in a LooseVersion with a prerelease
    loose_version_1 = LooseVersion('2.12.1-alpha')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert semantic_version_1.vstring == '2.12.1-alpha'
    assert not semantic_version_1.is_

# Generated at 2022-06-25 14:02:51.185579
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:02:54.700045
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion
    import distutils.version
    expected = SemanticVersion('1.0.0')
    actual = SemanticVersion.from_loose_version(distutils.version.LooseVersion('1.0.0'))
    assert actual == expected


# Generated at 2022-06-25 14:02:57.183192
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.7.5')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == SemanticVersion('2.7.5+0')


# Generated at 2022-06-25 14:03:03.592148
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    bad_test_cases = [
        (5, "not a loose version"),
        ("5.6", "not a loose version"),
        ("5.6.7", "not a loose version"),
        (SemanticVersion("1.2.3"), "not a loose version"),
        (LooseVersion("1"), "non integer values in LooseVersion ('1')")
    ]
    for (bad_loose_version, error) in bad_test_cases:
        try:
            SemanticVersion.from_loose_version(bad_loose_version)
            assert False, "Did not fail creating SemanticVersion from bad LooseVersion"
        except ValueError as e:
            assert str(e) == error
    loose_version_5 = LooseVersion("5")

# Generated at 2022-06-25 14:03:07.048025
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.23.45')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 23
    assert semantic_version.patch == 45
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()


# Generated at 2022-06-25 14:03:13.167395
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1'))
    assert semantic_version.core == (1, 0, 0)
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.2'))
    assert semantic_version.core == (1, 2, 0)
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert semantic_version.core == (1, 2, 3)
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.2a1'))
    assert semantic_version.core == (1, 2, 0)
    assert semantic_version.prerelease == ('a1',)
    semantic_version = SemanticVersion.from_loose_

# Generated at 2022-06-25 14:03:15.510113
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert (SemanticVersion('1.0.0') == SemanticVersion.from_loose_version(LooseVersion('1.0')))



# Generated at 2022-06-25 14:03:17.708458
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    sample_LooseVersion = LooseVersion('1.2.3')
    sample_SemanticVersion = SemanticVersion.from_loose_version(sample_LooseVersion)
    assert sample_SemanticVersion == '1.2.3'

# Generated at 2022-06-25 14:03:25.222577
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # This can be generated using ansible-test or ansible-test sanity
    # ansible-test sanity --test test_SemanticVersion_from_loose_version --python 3.5
    assert SemanticVersion.from_loose_version(LooseVersion('1.3.3')) == \
            SemanticVersion('1.3.3')

    assert SemanticVersion.from_loose_version(LooseVersion('1.3.0b1')) == \
            SemanticVersion('1.3.0-b1')

    assert SemanticVersion.from_loose_version(LooseVersion('1.3.0-b1')) == \
            SemanticVersion('1.3.0-b1')


# Generated at 2022-06-25 14:04:16.140394
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.0.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 2
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0


# Generated at 2022-06-25 14:04:21.744853
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_input_loose_version = "0.0.0"
    expected = SemanticVersion('0.0.0')

    loose_version = LooseVersion(test_input_loose_version)
    result = SemanticVersion.from_loose_version(loose_version)
    assert result == expected


# Generated at 2022-06-25 14:04:29.249645
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    from ansible.module_utils.common.version import LooseVersionMetadata
    from ansible.module_utils.common.version import SemanticVersion
    # Loose version is a LooseVersion
    assert isinstance(LooseVersion('v0.0.1'), LooseVersion) == True
    # Loose version is not a SemanticVersion
    assert isinstance(LooseVersion('v0.0.1'), SemanticVersion) == False
    # Loose version metadata is a LooseVersionMetadata
    assert isinstance(LooseVersion('v0.0.1+123'), LooseVersionMetadata) == True
    # Loose version metadata is not a SemanticVersion

# Generated at 2022-06-25 14:04:32.386984
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_version = LooseVersion('1.0.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version_version)

    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()


# Generated at 2022-06-25 14:04:38.850607
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible.module_utils.six as six
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import range
    import ansible.module_utils.compat.version as version


# Generated at 2022-06-25 14:04:43.746022
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import cStringIO as StringIO

    # This is our input string
    input_string = "1.2.3+abc"

    # This is the desired output of our unit test
    v = SemanticVersion(input_string)
    desiredOutput = SemanticVersion(input_string)

    # This is our method under test
    actualOutput = SemanticVersion.from_loose_version(v)

    assert actualOutput == desiredOutput

# Generated at 2022-06-25 14:04:47.091392
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = "1.0.0"
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version._cmp("1.0.0") == 0

if __name__ == '__main__':
    test_case_0()
    test_SemanticVersion_from_loose_version()

# Generated at 2022-06-25 14:04:49.755027
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible.module_utils.compat.version
    semver = "6.7.6"
    assert(ansible.module_utils.compat.version.SemanticVersion.from_loose_version(ansible.module_utils.compat.version.LooseVersion(semver)).vstring == semver)

# Generated at 2022-06-25 14:04:51.290733
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion.from_loose_version(semantic_version_0)



# Generated at 2022-06-25 14:04:57.119476
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.3.9-rc1')).vstring == '0.3.9-rc1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-rc1.3')).vstring == '1.2.3-rc1.3'
    assert SemanticVersion.from_loose_version(LooseVersion('10.15.24-rc1.1.2')).vstring == '10.15.24-rc1.1.2'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+0+abcdefabcdefabcdefabcdefabcdef')).vstring == '1.2.3+0+abcdefabcdefabcdefabcdefabcdef'
    assert Sem