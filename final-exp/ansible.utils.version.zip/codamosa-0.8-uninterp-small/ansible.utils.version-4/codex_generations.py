

# Generated at 2022-06-25 13:55:20.831588
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion('0.0.0-alpha.1+abc.12')
    assert version.major == 0
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == (_Alpha('alpha'), _Numeric(1))
    assert version.buildmetadata == (_Alpha('abc'), _Numeric(12))



# Generated at 2022-06-25 13:55:26.939886
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion(1.0)
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    int_0 = semantic_version_0.major
    int_1 = semantic_version_0.minor
    int_2 = semantic_version_0.patch
    tuple_0 = semantic_version_0.prerelease
    tuple_1 = semantic_version_0.buildmetadata
    str_0 = semantic_version_0.vstring


# Generated at 2022-06-25 13:55:36.989569
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semver = SemanticVersion()
    assert semver.parse('0.0.0') == None
    assert semver.parse('0.1.1') == None
    assert semver.parse('2.3.4') == None
    assert semver.parse('1.2.3-alpha.1') == None
    assert semver.parse('1.2.3+build.1') == None
    assert semver.parse('1.2.3-alpha.1+build.1') == None
    assert semver.parse('abcd.3') == None
    assert semver.parse('1.2.3-1.alpha') == None
    assert semver.parse('1.2.3+a1+b2.3c') == None

# Generated at 2022-06-25 13:55:45.651630
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v_0 = SemanticVersion('1.2.3')
    assert v_0
    assert v_0.core == (1, 2, 3)
    assert not v_0.prerelease
    assert not v_0.buildmetadata

    v_1 = SemanticVersion('1.2.3-alpha.1')
    assert v_1
    assert v_1.core == (1, 2, 3)
    assert v_1.prerelease == (_Alpha('alpha'), _Numeric(1))
    assert not v_1.buildmetadata

    v_2 = SemanticVersion('1.2.3-alpha.beta')
    assert v_2
    assert v_2.core == (1, 2, 3)
    assert v_2.prerelease == (_Alpha('alpha'), _Alpha('beta'))
    assert not v_

# Generated at 2022-06-25 13:55:48.426082
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    v.parse("1.0.0")

    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()



# Generated at 2022-06-25 13:55:57.709372
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semver = SemanticVersion()

    version = '1.2.3'
    semver.parse(version)
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == tuple()
    assert semver.buildmetadata == tuple()

    version = '1.2.3-alpha.1'
    semver.parse(version)
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == (_Alpha('alpha'), _Numeric(1))
    assert semver.buildmetadata == tuple()

    version = '1.2.3+20130313144700'
    semver.parse(version)
    assert semver.major == 1
   

# Generated at 2022-06-25 13:56:05.099581
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    lv = LooseVersion("0.2.4")
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 0
    assert sv.minor == 2
    assert sv.patch == 4

    lv = LooseVersion("2.4")
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 2
    assert sv.minor == 4
    assert sv.patch == 0

    lv = LooseVersion("2")
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 2
    assert sv.minor == 0
    assert sv.patch == 0
    assert sv.vstring == "2.0.0"

    lv = LooseVersion("2-dev")

# Generated at 2022-06-25 13:56:09.974673
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).is_stable
    assert not SemanticVersion.from_loose_version(LooseVersion('1.2.3-rc1')).is_stable
    assert not SemanticVersion.from_loose_version(LooseVersion('0.2.3')).is_stable
    assert SemanticVersion.from_loose_version(LooseVersion('0.2.3-rc1')).is_stable


# Generated at 2022-06-25 13:56:17.208141
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-25 13:56:24.086389
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Tests to ensure dict type of "kwargs" is handled correctly
    version = '1.0.0'
    semver = SemanticVersion()
    semver.parse(version)
    assert semver.major == 1
    assert semver.minor == 0
    assert semver.patch == 0
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()
    assert semver.vstring == version

    version = '1.0.0-alpha.1'
    semver = SemanticVersion()
    semver.parse(version)
    assert semver.major == 1
    assert semver.minor == 0
    assert semver.patch == 0
    assert semver.prerelease == (_Alpha('alpha'), _Numeric(1))
    assert semver.buildmetadata == ()

# Generated at 2022-06-25 13:56:38.136370
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    assert semantic_version_0.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert semantic_version_0.from_loose_version(LooseVersion('1.0.0-1')) == SemanticVersion('1.0.0-1')
    assert semantic_version_0.from_loose_version(LooseVersion('1.10.0')) == SemanticVersion('1.10.0')
    assert semantic_version_0.from_loose_version(LooseVersion('1.0.0.post1')) == SemanticVersion('1.0.0+post1')

# Generated at 2022-06-25 13:56:46.354375
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    semantic_version_0.parse('1.2.3')
    loose_version_0 = LooseVersion('1.2.3')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_0)

    assert semantic_version_0 == semantic_version_1
    assert not semantic_version_0 != semantic_version_1
    assert not semantic_version_0 > semantic_version_1
    assert semantic_version_0 >= semantic_version_1
    assert not semantic_version_0 < semantic_version_1
    assert semantic_version_0 <= semantic_version_1

    semantic_version_0.parse('1.2.3-alpha.1')

# Generated at 2022-06-25 13:56:52.525067
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion(vstring='0.1.2-3.4.5+6.7.8')._cmp(
        SemanticVersion.from_loose_version(LooseVersion('0.1.2.3-4.5-6.7.8'))
    ) == 0
    assert SemanticVersion(vstring='0.1.2-3.4.5+6.7.8')._cmp(
        SemanticVersion.from_loose_version(LooseVersion('0.1.2.3alpha4-5-6.7.8'))
    ) == 0

# Generated at 2022-06-25 13:56:53.892270
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.2.3")
    SemanticVersion.from_loose_version(loose_version)


# Generated at 2022-06-25 13:57:01.842951
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    input_0 = LooseVersion('1')
    output_0 = SemanticVersion.from_loose_version(input_0)
    assert output_0.major == 1
    assert output_0.minor == 0
    assert output_0.patch == 0

    input_1 = LooseVersion('1.2')
    output_1 = SemanticVersion.from_loose_version(input_1)
    assert output_1.major == 1
    assert output_1.minor == 2
    assert output_1.patch == 0

    input_2 = LooseVersion('1.2.3')
    output_2 = SemanticVersion.from_loose_version(input_2)
    assert output_2.major == 1
    assert output_2.minor == 2
    assert output_2.patch == 3

   

# Generated at 2022-06-25 13:57:10.398201
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    import sys

    if sys.version_info[0] == 2:
        # Py2
        assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
        assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-rc1")) == SemanticVersion("1.0.0-rc1")
        assert SemanticVersion.from_loose_version(LooseVersion("1.0.0+build")) == SemanticVersion("1.0.0+build")

# Generated at 2022-06-25 13:57:14.457758
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test that a SemanticVersion can be created from a LooseVersion
    when the LooseVersion is a normal version"""
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()


# Generated at 2022-06-25 13:57:24.239951
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class LooseVersion_Mock:
        version = (1,)
        vstring = None

    testcase_0 = SemanticVersion.from_loose_version(LooseVersion_Mock())
    assert str(testcase_0) == '1.0.0'

    class LooseVersion_Mock:
        version = (1, 2)
        vstring = None

    testcase_1 = SemanticVersion.from_loose_version(LooseVersion_Mock())
    assert str(testcase_1) == '1.2.0'

    class LooseVersion_Mock:
        version = (1, 2, 3)
        vstring = None

    testcase_2 = SemanticVersion.from_loose_version(LooseVersion_Mock())

# Generated at 2022-06-25 13:57:27.736402
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.20.0b2')
    expected = SemanticVersion('0.20.0-rc.2')
    actual = SemanticVersion.from_loose_version(loose_version)
    assert expected == actual



# Generated at 2022-06-25 13:57:29.895164
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.33.7')) == SemanticVersion('0.33.7')


# Generated at 2022-06-25 13:57:43.882410
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    SemanticVersion.from_loose_version( LooseVersion('2.10.0'))
    SemanticVersion.from_loose_version( LooseVersion('2.10.0-alpha'))
    SemanticVersion.from_loose_version( LooseVersion('2.10.0+buildmetadata'))


# Generated at 2022-06-25 13:57:50.077469
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion()
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.vstring == '0.0.0'
    loose_version_1 = LooseVersion('1.2.3')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert semantic_version_1.vstring == '1.2.3'
    loose_version_2 = LooseVersion('1.2.3-4')
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version_2)
    assert semantic_version_2.vstring == '1.2.3-4'

# Generated at 2022-06-25 13:57:57.892552
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Constructor call arguments
    loose_version = LooseVersion("1.2.3")
    # Call method of the class with arguments
    semver_0 = SemanticVersion.from_loose_version(loose_version)

    # Check whether the instance created is of correct type
    assert isinstance(semver_0, SemanticVersion)

    # Check default value of property
    assert semver_0.vstring == "1.2.3"

    # Check set property
    semver_0.vstring = "1.0.0"
    assert semver_0.vstring == "1.0.0"

    # Check the created instance is equal to it's own clone
    semver_1 = SemanticVersion.from_loose_version(semver_0)
    assert semver_0 == semver_1



# Generated at 2022-06-25 13:58:03.283822
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # assertEqual is used here instead of assertIsInstance as we want to be explicit with the
    # class being constructed
    assert semantic_version_0.__class__ == SemanticVersion
    assert semantic_version_0.vstring == None
    assert semantic_version_0.major == None
    assert semantic_version_0.minor == None
    assert semantic_version_0.patch == None
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()
    assert semantic_version_0.version == ()


# Generated at 2022-06-25 13:58:09.739357
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import distutils.version
    # Test simple versions
    # Loose version is a string
    version = SemanticVersion.from_loose_version(distutils.version.LooseVersion('1.0.0'))
    assert version.vstring == '1.0.0'

    # Loose version is a tuple
    version = SemanticVersion.from_loose_version(distutils.version.LooseVersion(('1', '0', '0')))
    assert version.vstring == '1.0.0'

    # Loose version is a list
    version = SemanticVersion.from_loose_version(distutils.version.LooseVersion(['1', '0', '0']))
    assert version.vstring == '1.0.0'

    # Loose version has the major, minor, and patch versions


# Generated at 2022-06-25 13:58:17.826013
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    # First, run with LooseVersion as the input, making sure that
    # it works
    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.3'
    # Second, run with a string and make sure that it works
    # This is the expected use case
    semantic_version = SemanticVersion.from_loose_version('1.2.3')
    assert semantic_version == '1.2.3'
    # Third, run with a string and make sure that it fails if
    # there are non-integer values
    # This is the expected use case

# Generated at 2022-06-25 13:58:21.919933
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test initializing of SemanticVersion with a LooseVersion
    loose_version = LooseVersion('v0.1.1-rc1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.core == (0, 1, 1)
    assert semantic_version.prerelease == (_Alpha('rc'), _Numeric(1))
    assert semantic_version.buildmetadata == ()


# Generated at 2022-06-25 13:58:24.302041
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Case 1
    loose_version = LooseVersion('1.2.3')
    expected = '1.2.3'
    actual = SemanticVersion.from_loose_version(loose_version)
    assert actual == expected


# Generated at 2022-06-25 13:58:30.426801
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion()
    # Testing with invalid input
    try:
        # Invalid: input is of type str
        semantic_version_1.from_loose_version('0.0.1')
    except ValueError as e:
        pass

    loose_version_0 = LooseVersion()
    assert(semantic_version_1.from_loose_version(loose_version_0) ==
           SemanticVersion('0.0.0'))


# Generated at 2022-06-25 13:58:39.242617
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test the case where there is '+' in the string
    # Given
    version_string = '1.2.3+build'
    loose_version = LooseVersion('1.2.3b5+build')

    # When
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # Then
    assert semantic_version.vstring == version_string

    # The following test cases have been commented out as they have been
    # covered in the pytest tests and verifying the same results in this
    # unit test would be a duplicate of those tests.
    # SORT_PRIORITY = {
    #     'loose': 0,
    #     'semantic': 1
    # }


    # # Test the case where there is '-' in the string
    # # Given
    # version

# Generated at 2022-06-25 13:58:57.262194
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion directly from LooseVersion string
    loose_version_0 = LooseVersion(u'1.0.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert isinstance(loose_version_0, LooseVersion)

    loose_version_1 = LooseVersion(u' 1.0.0')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert isinstance(loose_version_1, LooseVersion)

    loose_version_2 = LooseVersion(u'1.0.0-beta.1')
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version_2)

# Generated at 2022-06-25 13:59:02.492022
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create a LooseVersion instance
    loose_version = LooseVersion('2.0.0a1')

    # Convert the LooseVersion instance to a SemanticVersion instance
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # Assert that the converted SemanticVersion is equal to '2.0.0-a1'
    assert semantic_version.vstring == '2.0.0-a1'


# Generated at 2022-06-25 13:59:06.922361
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_01 = LooseVersion('0.1.1')
    SemanticVersion_01_01 = SemanticVersion('0.1.1')
    assert SemanticVersion.from_loose_version(loose_version_01) == SemanticVersion_01_01


# Generated at 2022-06-25 13:59:14.140921
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Version string: 2.3.4-1-x-x-x
    loose_version = LooseVersion('2.3.4-1-x-x-x')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 2
    assert semantic_version.minor == 3
    assert semantic_version.patch == 4
    assert semantic_version.prerelease == (_Numeric(1), _Alpha('x'), _Alpha('x'), _Alpha('x'))
    assert not semantic_version.buildmetadata

    # Version string: 2.3.4-1.2+a.b.c
    loose_version = LooseVersion('2.3.4-1.2+a.b.c')
    semantic_version = SemanticVersion.from_loose_

# Generated at 2022-06-25 13:59:16.503550
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version.core == (1, 0, 0)


# Generated at 2022-06-25 13:59:24.784970
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(SemanticVersion('0.10.5')) == SemanticVersion('0.10.5')
    assert SemanticVersion.from_loose_version(LooseVersion('0.10.5')) == SemanticVersion('0.10.5')
    assert SemanticVersion.from_loose_version(LooseVersion('0.10.5+38.g4cb4a4d')) == SemanticVersion('0.10.5+38.g4cb4a4d')
    assert SemanticVersion.from_loose_version(LooseVersion('0.10.5-1')) == SemanticVersion('0.10.5-1')

# Generated at 2022-06-25 13:59:27.820729
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.4')) == SemanticVersion('1.2.4')


# Generated at 2022-06-25 13:59:35.358366
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def _assert_from_loose_version(initial, expected):
        actual = SemanticVersion.from_loose_version(LooseVersion(initial))
        assert actual == expected

    _assert_from_loose_version('1.0', '1.0.0')
    _assert_from_loose_version('1.0.0', '1.0.0')
    _assert_from_loose_version('1.0.1', '1.0.1')
    _assert_from_loose_version('1.0.1c1', '1.0.1')
    _assert_from_loose_version('1.0.1.post1', '1.0.1')
    _assert_from_loose_version('1.0.1a1', '1.0.1')


# Generated at 2022-06-25 13:59:43.907821
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('')
    semantic_version_0 = SemanticVersion.from_loose_version(
        loose_version=loose_version_0
    )

    loose_version_1 = LooseVersion('0.0.0')
    semantic_version_1 = SemanticVersion.from_loose_version(
        loose_version=loose_version_1
    )

    loose_version_2 = LooseVersion('0')
    semantic_version_2 = SemanticVersion.from_loose_version(
        loose_version=loose_version_2
    )

    loose_version_3 = LooseVersion('0.1')
    semantic_version_3 = SemanticVersion.from_loose_version(
        loose_version=loose_version_3
    )

   

# Generated at 2022-06-25 13:59:46.808460
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.0")
    vstring = SemanticVersion.from_loose_version(loose_version)
    assert vstring.vstring == "1.0.0"



# Generated at 2022-06-25 14:00:30.281422
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.2.0'
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()
    assert semantic_version.is_prerelease, False
    assert semantic_version.is_stable, True

    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.2.3'
    assert semantic_version.major == 1
    assert semantic

# Generated at 2022-06-25 14:00:34.140949
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion("1.5.5")
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    semantic_version_1 = SemanticVersion("1.5.5")
    assert semantic_version_0 == semantic_version_1


# Generated at 2022-06-25 14:00:37.736520
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion()
    # ValueError raised at initialization of semantic_version_1
    with pytest.raises(ValueError):
        # Attempt to initialize a SemanticVersion with a non semver
        semantic_version_2 = SemanticVersion.from_loose_version(semantic_version_1)


# Generated at 2022-06-25 14:00:42.879079
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # When:
    #  Given that a LooseVersion with a string version
    loose_version = LooseVersion('1.1.1-beta.1.2.3-rc.1+build.1.2.3.4-pre')
    #  And we want to convert it to a SemanticVersion
    # Then:
    #  It should be converted correctly
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.1.1-beta.1.2.3-rc.1+build.1.2.3.4-pre')


# Generated at 2022-06-25 14:00:48.535812
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.dev1')).vstring == '1.0.0-dev1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.dev1+2017.1.15')).vstring == '1.0.0-dev1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.dev1+2017.1.15')).buildmetadata == ('2017', '1', '15')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0-alpha1')).vstring == '1.0.0-alpha1'

# Generated at 2022-06-25 14:00:55.203574
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Error testing
    try:
        version = SemanticVersion.from_loose_version(None)
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError not raised")

    try:
        version = SemanticVersion.from_loose_version(666)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError not raised")

    try:
        version = SemanticVersion.from_loose_version(SemanticVersion())
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError not raised")

    # Testing the actual value
    loose_version = LooseVersion('1.2.3')
    version = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-25 14:01:03.483938
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        SemanticVersion.from_loose_version("")
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"
    try:
        SemanticVersion.from_loose_version("A.B")
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"
    try:
        SemanticVersion.from_loose_version("A.B.C.D")
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"
    try:
        SemanticVersion.from_loose_version("A.B.C.D.E")
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"

# Generated at 2022-06-25 14:01:05.164491
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version("1.2").vstring == "1.2.0"


# Generated at 2022-06-25 14:01:14.363357
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:23.050024
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that method raises an error if argument is not a LooseVersion
    try:
        SemanticVersion.from_loose_version('2.0.0')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')
    try:
        SemanticVersion.from_loose_version(2.0)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.0.0'))
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    # Test that method raises an error if argument is not numeric

# Generated at 2022-06-25 14:03:03.923725
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('0.4.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    loose_version_1 = LooseVersion('0.4.1-beta')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)

    loose_version_2 = LooseVersion('0.4.1-beta.1')
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version_2)

    loose_version_3 = LooseVersion('0.4.1+build.3')
    semantic_version_3 = SemanticVersion.from_loose_version(loose_version_3)


# Generated at 2022-06-25 14:03:10.426252
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version_0 = LooseVersion('0.0.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert SemanticVersion.from_loose_version(loose_version_0) is not None
    assert isinstance(semantic_version_0, SemanticVersion)
    assert semantic_version_0.core == (0, 0, 1)
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()

    loose_version_1 = LooseVersion('0.0.1-alpha')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)

# Generated at 2022-06-25 14:03:12.327148
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion()
    try:
        affected_builds = SemanticVersion.from_loose_version(loose_version_0)
    except ValueError:
        pass


# Generated at 2022-06-25 14:03:19.583993
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:03:27.088399
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version1 = LooseVersion('1.2.3')
    semantic_version1 = SemanticVersion.from_loose_version(loose_version1)
    assert semantic_version1 == SemanticVersion('1.2.3')

    loose_version2 = LooseVersion('1.2')
    semantic_version2 = SemanticVersion.from_loose_version(loose_version2)
    assert semantic_version2 == SemanticVersion('1.2.0')

    loose_version3 = LooseVersion('1')
    semantic_version3 = SemanticVersion.from_loose_version(loose_version3)
    assert semantic_version3 == SemanticVersion('1.0.0')

    loose_version4 = LooseVersion('1.a')

# Generated at 2022-06-25 14:03:34.800384
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:03:37.903031
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Example of converting a LooseVersion to a SemanticVersion
    """
    >>> from distutils.version import LooseVersion
    >>> SemanticVersion.from_loose_version(LooseVersion('0.0.1'))
    SemanticVersion('0.0.1')
    """
    pass


# Generated at 2022-06-25 14:03:46.927614
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:03:54.420644
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = LooseVersion('1.2')
    assert SemanticVersion.from_loose_version(version) == SemanticVersion('1.2.0')

    version = LooseVersion('1.2rc1')
    assert SemanticVersion.from_loose_version(version) == SemanticVersion('1.2.0-rc1')

    version = LooseVersion('1.2rc1.4')
    assert SemanticVersion.from_loose_version(version) == SemanticVersion('1.2.0-rc1.4')

    version = LooseVersion('1.2rc1.4b')
    assert SemanticVersion.from_loose_version(version) == SemanticVersion('1.2.0-rc1.4b')

    version = LooseVersion('1.2.3')
    assert Semantic

# Generated at 2022-06-25 14:03:59.140755
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_1 = LooseVersion("1.2.3.dev1.foo")
    result_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert str(result_1) == "1.2.3-dev1.foo"

    loose_version_2 = LooseVersion("1.2.0")
    result_2 = SemanticVersion.from_loose_version(loose_version_2)
    assert str(result_2) == "1.2.0"

    loose_version_3 = LooseVersion("1.2.0a-1")
    result_3 = SemanticVersion.from_loose_version(loose_version_3)
    assert str(result_3) == "1.2.0-a.1"

    loose_version_