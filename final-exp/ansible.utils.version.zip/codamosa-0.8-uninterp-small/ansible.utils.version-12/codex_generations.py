

# Generated at 2022-06-25 13:55:32.479817
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion("0.4.4")
    semantic_version_0._SemanticVersion__parse("v0.4.4")
    semantic_version_1 = SemanticVersion("0.4.4")
    semantic_version_1._SemanticVersion__parse("0.4.4")
    semantic_version_2 = SemanticVersion("0.4.4")
    semantic_version_2._SemanticVersion__parse("v0.4.4.1")
    semantic_version_3 = SemanticVersion("0.4.4")
    semantic_version_3._SemanticVersion__parse("0.4.4.1")
    semantic_version_4 = SemanticVersion("0.4.4")
    semantic_version_4._SemanticVersion__parse("v0.4.4.0")


# Generated at 2022-06-25 13:55:39.543368
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test for method from_loose_version of class SemanticVersion"""
    # Create an instance of the SemanticVersion class
    semantic_version_0 = SemanticVersion()
    # Create an instance of the LooseVersion class
    loose_version_0 = LooseVersion('1.30.6')

    # Call the method from the class with the args
    semantic_version_0.from_loose_version(loose_version_0)

    # Check for the class
    assert isinstance(semantic_version_0, SemanticVersion)

# Generated at 2022-06-25 13:55:47.329468
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v_0 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert v_0.vstring == '1.2.3'
    v_1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-1.2.3'))
    assert v_1.vstring == '1.2.3-1.2.3'
    v_2 = SemanticVersion.from_loose_version(LooseVersion('1.2.3+1.2.3'))
    assert v_2.vstring == '1.2.3+1.2.3'
    v_3 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-1.2.3+1.2.3'))


# Generated at 2022-06-25 13:55:50.450530
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    bool_0 = False
    # Assertions
    try:
        SemanticVersion.from_loose_version(bool_0)
        assert False
    except ValueError as e:
        assert str(e) == "'False' is not a LooseVersion"


# Generated at 2022-06-25 13:55:55.138900
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    str_0 = '1.0.0'
    loose_version_0 = LooseVersion(str_0)
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    str_1 = str(semantic_version_0)
    assert str_1 == str_0


# Generated at 2022-06-25 13:55:57.751434
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = None
    try:
        v = SemanticVersion.from_loose_version
    except ValueError as e:
        print ("ValueError caught:", e)


# Generated at 2022-06-25 13:55:59.995057
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    sv = SemanticVersion.from_loose_version(LooseVersion('1.0'))
    # FIXME: need to write more tests, disabled
    # assert sv.major == 1
    # assert sv.minor == 0
    # assert sv.patch == 0
    pass

# Generated at 2022-06-25 13:56:05.743753
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    s = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert s.major == 1
    assert s.minor == 2
    assert s.patch == 3

    # LooseVersion has no concept of prerelease or buildmetadata
    # so we don't support it
    assert not s.prerelease
    assert not s.buildmetadata

    s = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert s.major == 1
    assert s.minor == 2
    assert s.patch == 3

    # LooseVersion has no concept of prerelease or buildmetadata
    # so we don't support it
    assert not s.prerelease
    assert not s.buildmetadata

    # In the event that we receive a non LooseVersion object


# Generated at 2022-06-25 13:56:07.748229
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    vstring_0 = '1.8.0'
    semantic_version_0 = SemanticVersion(vstring_0)
    semantic_version_0.parse(vstring_0)


# Generated at 2022-06-25 13:56:11.537821
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring_0 = '3.2.1'
    semantic_version_0 = SemanticVersion(vstring_0)
    loose_version_0 = LooseVersion(semantic_version_0)
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0 == semantic_version_1


# Generated at 2022-06-25 13:56:23.788005
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    vstring = "v1.2.3"
    v = SemanticVersion(vstring)
    assert isinstance(v.major, int)
    assert isinstance(v.minor, int)
    assert isinstance(v.patch, int)
    assert not isinstance(v.prerelease, tuple)
    assert not isinstance(v.buildmetadata, tuple)
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()


# Generated at 2022-06-25 13:56:32.912055
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    x = SemanticVersion('1.2.3')
    assert x.core == (1, 2, 3)
    assert x.prerelease == ()
    assert x.buildmetadata == ()

    x = SemanticVersion('0.2.3')
    assert x.core == (0, 2, 3)
    assert x.prerelease == ()
    assert x.buildmetadata == ()

    x = SemanticVersion('1.2.3-alpha')
    assert x.core == (1, 2, 3)
    assert x.prerelease == (_Alpha('alpha'),)
    assert x.buildmetadata == ()

    x = SemanticVersion('1.2.3-alpha.1')
    assert x.core == (1, 2, 3)
    assert x.prerelease == (_Alpha('alpha'), _Numeric('1'))

# Generated at 2022-06-25 13:56:41.593518
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-25 13:56:44.433172
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    ver = "0.9-alpha"
    loose_version = LooseVersion(ver)
    version = SemanticVersion.from_loose_version(loose_version)
    print(version)
    assert version == ver

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:56:53.175822
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.urls import open_url, ConnectionError, SSLValidationError

    args_0 = {
        'scheme': 'https',
        'netloc': 'api.github.com',
        'path': '/repos/ansible/ansible/releases/latest',
    }
    ansible_url = urlsplit(None, **args_0)
    try:
        result_0 = open_url(ansible_url)
    except SSLValidationError as ex:
        pass
    except ConnectionError as ex:
        pass
    else:
        if result_0.status != 200:
            test_case_0()
            return
        else:
            result_0 = result

# Generated at 2022-06-25 13:56:53.892451
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    test_case_0()


# Generated at 2022-06-25 13:57:01.843171
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert(SemanticVersion("1.0.0").core == (1, 0, 0))
    assert(SemanticVersion("2.1.3").core == (2, 1, 3))
    assert(SemanticVersion("0.0.0").core == (0, 0, 0))
    assert(SemanticVersion("0.0.0-alpha").core == (0, 0, 0))
    assert(SemanticVersion("0.0.0-alpha.2").core == (0, 0, 0))
    assert(SemanticVersion("4.4.4-rc.1").core == (4, 4, 4))
    assert(SemanticVersion("4.4.4-rc.1+build.4").core == (4, 4, 4))

# Generated at 2022-06-25 13:57:04.161822
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    x = u'1.0.0'
    # assert_is_instance(expected, type)
    assert_is_instance(x, text_type)


# Generated at 2022-06-25 13:57:09.800382
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    print('Executing test test_SemanticVersion_parse...')
    # Test the case where vstring is None
    # Call the method on an instance of the class
    # Actual value is None
    expected = None
    actual = SemanticVersion().parse(None)
    assert actual == expected, 'Test Failed: expected={}, actual={}'.format(expected, actual)
    print('Actual value {} equals expected value {}'.format(actual, expected))
    print('Test test_SemanticVersion_parse ran to completion')


# Generated at 2022-06-25 13:57:18.169247
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:57:32.356384
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion

    assert (SemanticVersion.from_loose_version(LooseVersion('1.0')).vstring == '1.0.0')
    assert (SemanticVersion.from_loose_version(LooseVersion('1.0+1')).vstring == '1.0.0+1')
    assert (SemanticVersion.from_loose_version(LooseVersion('1.0-1')).vstring == '1.0.0-1')
    assert (SemanticVersion.from_loose_version(LooseVersion('1.0-1+1')).vstring == '1.0.0-1+1')


# Generated at 2022-06-25 13:57:41.296763
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    # Semantic version to be compared against
    semver = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    if semver != '1.2.3':
        test_case_0()
    # Assert on type of attributes
    if (not isinstance(semver.major, int) or
            not isinstance(semver.minor, int) or
            not isinstance(semver.patch, int)):
        test_case_0()
    # Check for equality
    if semver != SemanticVersion('1.2.3'):
        test_case_0()
    if semver == SemanticVersion('1.2.4'):
        test_case_0()



# Generated at 2022-06-25 13:57:45.268269
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create a LooseVersion
    loose_version = LooseVersion('1.2.3')
    # Create a SemanticVersion
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    bool_0 = bool(semantic_version == '1.2.3')
    bool_1 = bool(semantic_version.is_stable)


# Generated at 2022-06-25 13:57:52.845090
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Validate that an exception is thrown on mismatched type
    try:
        SemanticVersion.from_loose_version('2.0.0')
    except ValueError:
        bool_0 = False
    else:
        bool_0 = True
    assert bool_0 == False
    # Validate that an exception is thrown on mismatched type
    try:
        SemanticVersion.from_loose_version(None)
    except ValueError:
        bool_0 = False
    else:
        bool_0 = True
    assert bool_0 == False
    # Validate that an exception is thrown when non-numeric values are found
    try:
        SemanticVersion.from_loose_version(LooseVersion('2.0.abcd'))
    except ValueError:
        bool_0 = False

# Generated at 2022-06-25 13:57:59.565612
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Assigning to Attribute[str | NoneType](u'1.1')
    vstring = str("1.1")
    # Executing method __init__ of class SemanticVersion with args (['1', '1']...)
    loose_version = LooseVersion(vstring)
    # Calling SemanticVersion.from_loose_version with args (loose_version)
    version = SemanticVersion.from_loose_version(loose_version)
    # Asserting that version.vstring equals vstring
    assert version.vstring == vstring
    # Asserting that version equals SemanticVersion('1.1.0')
    assert version == SemanticVersion("1.1.0")


# Generated at 2022-06-25 13:58:07.262393
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    ver = '1.0'
    loose_version = LooseVersion(ver)
    ver = SemanticVersion.from_loose_version(loose_version)
    assert ver.major == 1
    assert ver.minor == 0
    assert ver.patch == 0
    assert ver.prerelease == ()
    assert ver.buildmetadata == ()

    ver = '1.0.0+foo'
    loose_version = LooseVersion(ver)
    ver = SemanticVersion.from_loose_version(loose_version)
    assert ver.major == 1
    assert ver.minor == 0
    assert ver.patch == 0
    assert ver.prerelease == ()
    assert ver.buildmetadata == ('foo',)


# Generated at 2022-06-25 13:58:15.253738
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import datetime
    from ansible.module_utils.compat.version import LooseVersion

    class SemanticVersion_from_loose_version:
        def __init__(self, vstring):
            self.vstring = vstring
            self.version = tuple(vstring.split('.'))

        def __repr__(self):
            return self.vstring

    # Test case when exception is raised
    try:
        test_case = 'exception'
        loose_version = SemanticVersion_from_loose_version(vstring='test')
        SemanticVersion.from_loose_version(loose_version=loose_version)
    except ValueError as e:
        if test_case == 'exception':
            pass
        else:
            raise e
    # Test case with integer values in LooseVersion

# Generated at 2022-06-25 13:58:21.943732
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '1'
    assert SemanticVersion.from_loose_version(LooseVersion(vstring)) == SemanticVersion(vstring)
    vstring = '1.0'
    assert SemanticVersion.from_loose_version(LooseVersion(vstring)) == SemanticVersion(vstring)
    vstring = '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion(vstring)) == SemanticVersion(vstring)
    vstring = '1.0.0-alpha.1'
    assert SemanticVersion.from_loose_version(LooseVersion(vstring)) == SemanticVersion(vstring)
    vstring = '1.0.0-alpha.1.2'

# Generated at 2022-06-25 13:58:27.897409
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    LooseVersion0 = LooseVersion('2.2.8')
    LooseVersion1 = LooseVersion('1.1.2')
    LooseVersion2 = LooseVersion('0.1.1')
    LooseVersion3 = LooseVersion('1.2.2')
    LooseVersion4 = LooseVersion('1.1.1')
    LooseVersion5 = LooseVersion('1.3.3')
    LooseVersion6 = LooseVersion('1.1.1+2')
    LooseVersion7 = LooseVersion('0.1.1+1')
    LooseVersion8 = LooseVersion('1.2.2+2')
    LooseVersion9 = LooseVersion('1.1.1+2')
    LooseVersion10 = LooseVersion('1.3.3+2')
    test

# Generated at 2022-06-25 13:58:36.877742
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        loose_version = LooseVersion('0.1.1-beta')
    except:
        loose_version = None

    if not loose_version:
        raise AssertionError('Failed to create LooseVersion: 0.1.1-beta')

    test_version = SemanticVersion.from_loose_version(loose_version)
    idx = 0
    while 1:
        if (idx == len(test_version.core)):
            break
        if (test_version.core[idx] != 0):
            break
        idx = (idx + 1)

    if (idx != 3):
        raise AssertionError
    if (not isinstance(test_version.prerelease, tuple)):
        raise AssertionError

# Generated at 2022-06-25 13:58:50.472649
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = SemanticVersion.from_loose_version(LooseVersion('2.7.6-1'))
    assert v == SemanticVersion('2.7.6-1')



# Generated at 2022-06-25 13:58:58.140601
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Test with a string
    vstring = '4.0.0b1+build'.encode('utf-8')
    version = SemanticVersion.from_loose_version(LooseVersion(vstring))
    assert version == '4.0.0-beta.1+build'
    assert version.is_prerelease
    assert not version.is_stable

    vstring = '2.1'.encode('utf-8')
    version = SemanticVersion.from_loose_version(LooseVersion(vstring))
    assert version == '2.1.0'
    assert not version.is_prerelease
    assert version.is_stable

    vstring = '1.1.3.4'.encode('utf-8')
    version = SemanticVersion.from_loose_version(LooseVersion(vstring))

# Generated at 2022-06-25 13:59:05.429560
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3a'))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == (_Alpha('a'),)

    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease is None



# Generated at 2022-06-25 13:59:13.267111
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create a LooseVersion with value '0.90.0'
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('0.90.0'))
    # Assert that the version of semantic_version_0 is equal to '0.90.0'
    assert semantic_version_0.vstring == '0.90.0'
    # Create a SemanticVersion with value '0.90a0'
    semantic_version_1 = SemanticVersion('0.90a0')
    # Assert that semantic_version_1 is less than or equal to semantic_version_0
    assert semantic_version_1 <= semantic_version_0
    # Create a LooseVersion with value '0.90.0'

# Generated at 2022-06-25 13:59:21.268382
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()
    boolean_0 = semantic_version.is_stable
    assert boolean_0 == True
    assert str(semantic_version) == '1.0.0'

    loose_version = LooseVersion('1.0.0-alpha.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 0

# Generated at 2022-06-25 13:59:30.102528
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    obj_0 = SemanticVersion('1.2.3')
    obj_1 = SemanticVersion.from_loose_version('1.2.3')
    obj_0 == obj_1
    obj_2 = SemanticVersion('1.2.3.4+build')
    obj_3 = SemanticVersion.from_loose_version('1.2.3.4+build')
    obj_2 == obj_3
    obj_4 = SemanticVersion('1.2.3-alpha')
    obj_5 = SemanticVersion.from_loose_version('1.2.3-alpha')
    obj_4 == obj_5
    obj_6 = SemanticVersion('2.0.0')
    obj_7 = SemanticVersion.from_loose_version('2')
    obj_6 == obj_7

# Generated at 2022-06-25 13:59:36.955225
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:59:45.844507
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('0.0')
    test_case_0() # FIXME: Check return value
    semver_0 = SemanticVersion.from_loose_version(loose_version_0)
    loose_version_1 = LooseVersion('0.0.0')
    test_case_0() # FIXME: Check return value
    semver_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert semver_0.core == semver_1.core
    assert semver_0.is_stable == semver_1.is_stable
    assert semver_0.is_prerelease == semver_1.is_prerelease
    loose_version_2 = LooseVersion('0.1')
    test_case_0() # FIXME:

# Generated at 2022-06-25 13:59:47.342512
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '0.0.0'
    loose_version = LooseVersion(vstring)
    assert SemanticVersion(vstring) == SemanticVersion.from_loose_version(loose_version)



# Generated at 2022-06-25 13:59:48.208204
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    pass


# Generated at 2022-06-25 14:00:06.682206
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3.0')
    semantic_version = loose_version

    # Check the type
    assert isinstance(semantic_version, SemanticVersion)

    # Check the value
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()



# Generated at 2022-06-25 14:00:14.092682
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = '1.2.3'
    semver = SemanticVersion.from_loose_version(loose_version)
    assert '1.2.3' == semver.vstring

    loose_version = '1.2.3a'
    semver = SemanticVersion.from_loose_version(loose_version)
    assert '1.2.3a' == semver.vstring

    loose_version = '1.2.3-a'
    semver = SemanticVersion.from_loose_version(loose_version)
    assert '1.2.3-a' == semver.vstring

    loose_version = '1.2.3-a-234'
    semver = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-25 14:00:17.553928
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion(text_type('3.3.3'))
    expected_semver = SemanticVersion('3.3.3')
    actual_semver = SemanticVersion.from_loose_version(loose_version)
    assert actual_semver == expected_semver


# Generated at 2022-06-25 14:00:20.128955
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.0.0")
    semantic_version = SemanticVersion(".1.0.0")
    assert SemanticVersion.from_loose_version(loose_version) == semantic_version


# Generated at 2022-06-25 14:00:22.427104
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).vstring == '1.0.0'


# Generated at 2022-06-25 14:00:32.391210
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3

    loose_version = LooseVersion('1.2.3-alpha')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert 'alpha' in semantic_version.prerelease

    loose_version = LooseVersion('1.2.3alpha')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major

# Generated at 2022-06-25 14:00:34.547345
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("0.20.8")) == SemanticVersion("0.20.8")


# Generated at 2022-06-25 14:00:41.797482
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.1.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 1
    assert semantic_version.patch == 1
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()

    loose_version = LooseVersion('1.2.3-beta')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert semantic_version.prerelease == (_Alpha('beta'),)
    assert semantic_version.buildmetadata == ()


# Generated at 2022-06-25 14:00:43.733773
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-beta+private.test.data')) == SemanticVersion('1.2.3-beta+private.test.data')


# Generated at 2022-06-25 14:00:50.582735
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:10.485379
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create an instance of LooseVersion
    loose_version = LooseVersion('1.2.3')
    # Use the class method to create an instance of SemanticVersion
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semantic_version, SemanticVersion)


# Generated at 2022-06-25 14:01:18.783066
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:27.281358
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class LooseVersion(text_type):
        def __init__(self, vstring):
            self.vstring = vstring
    vstring = '0.0.1'
    loose_version = LooseVersion(vstring)
    version = SemanticVersion.from_loose_version(loose_version)
    assert vstring == version.vstring
    vstring = '1.0.0'
    loose_version = LooseVersion(vstring)
    version = SemanticVersion.from_loose_version(loose_version)
    assert vstring == version.vstring
    vstring = '6.0.0-pre'
    loose_version = LooseVersion(vstring)
    version = SemanticVersion.from_loose_version(loose_version)
    assert vstring == version.vstring


# Generated at 2022-06-25 14:01:35.025713
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-25 14:01:37.294778
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Setup
    loose_version_arg_0 = LooseVersion('0.37.0-rc2')

    # Invocation
    SemanticVersion.from_loose_version(loose_version_arg_0)


# Generated at 2022-06-25 14:01:43.179262
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Input parameters
    #     loose_version (LooseVersion) - Version object to convert to SemanticVersion
    # Return:
    #     SemanticVersion - Converted version object
    #
    # Test cases
    #     Runs with no issues
    #     Raises an exception when given a None
    #     Raises an exception when given a string
    #     Raises an exception when a non int is included
    #     Raises an exception when given a Version
    #     Raises an exception when given a SemanticVersion
    #     Raises an exception when the input version does not contain any numbers
    #     Raises an exception when the input version does not contain any integers
    loose_version = LooseVersion('1.2.3-beta1.1+build.2')

# Generated at 2022-06-25 14:01:49.972788
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    for version in [
            '9.9.9',
            '9.9.9-alpha.1',
            '9.9.9-alpha.1+build.1',
            [9, 9, 9],
    ]:
        semver = SemanticVersion.from_loose_version(LooseVersion(version))
        assert semver.major == 9
        assert semver.minor == 9
        assert semver.patch == 9
        assert semver.prerelease == ()

    for version in [
            '9.9.9-alpha',
            '9.9.9-alpha1',
            '9.9.9-alpha.1.2',
    ]:
        semver = SemanticVersion.from_loose_version(LooseVersion(version))
        assert semver.major == 9

# Generated at 2022-06-25 14:01:56.777644
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import re

    def assert_equal(l, r):
        if l == r:
            print(':)')
        else:
            print('AssertError: %s != %s' % (l, r))

    def assert_true(condition):
        if condition:
            print(':)')
        else:
            print('AssertError: %s is not True' % condition)

    def assert_false(condition):
        if not condition:
            print(':)')
        else:
            print('AssertError: %s is not False' % condition)

    def assert_raises(exception, function, *args, **kwargs):
        try:
            function(*args, **kwargs)
        except exception:
            return

        print('AssertError: %s not raised' % exception)


    #

# Generated at 2022-06-25 14:02:03.976848
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test normal cases
    loose_version_0 = LooseVersion('1.2.3')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.vstring == '1.2.3'

    loose_version_1 = LooseVersion('1.2.3-alpha.1')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert semantic_version_1.vstring == '1.2.3-alpha.1'

    loose_version_2 = LooseVersion('1.2.3-alpha.1+112233')
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version_2)

# Generated at 2022-06-25 14:02:06.986193
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '1.2.3.4'
    loose_version = LooseVersion(vstring)

    assert (str(SemanticVersion.from_loose_version(loose_version)) ==
            '1.2.3')


# Generated at 2022-06-25 14:02:48.470842
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test simple case
    semantic_version = SemanticVersion.from_loose_version(
        LooseVersion('0.0.1')
    )
    assert semantic_version.core == (0, 0, 1)
    assert not semantic_version.is_prerelease
    assert not semantic_version.is_stable

    semantic_version = SemanticVersion.from_loose_version(
        LooseVersion('0.0.1-alpha.1')
    )
    assert semantic_version.core == (0, 0, 1)
    assert semantic_version.is_prerelease
    assert not semantic_version.is_stable

    semantic_version = SemanticVersion.from_loose_version(
        LooseVersion('1.0.0')
    )
    assert semantic_version.core == (1, 0, 0)


# Generated at 2022-06-25 14:02:56.237708
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # test cases and expected results
    expected = {}
    expected[(LooseVersion('3.0'),)] = '3.0.0'
    expected[(LooseVersion('3.0.4'),)] = '3.0.4'
    expected[(LooseVersion('3.1'),)] = '3.1.0'
    expected[(LooseVersion('3.0.0.post1'),)] = '3.0.0-post1'
    expected[(LooseVersion('3.0.0.post1.dev0'),)] = '3.0.0-post1.dev0'
    expected[(LooseVersion('3.0.0.post1+build.3'),)] = '3.0.0-post1+build.3'

# Generated at 2022-06-25 14:03:02.606807
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.23.45')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.core == (1, 23, 45)
    loose_version = LooseVersion('1.23.45-whatever')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.core == (1, 23, 45)
    assert semantic_version.prerelease == ('whatever',)
    loose_version = LooseVersion('1.23.45+whatever')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.core == (1, 23, 45)
    assert semantic_version.buildmetadata == ('whatever',)

# Generated at 2022-06-25 14:03:05.281577
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    case_0_expected = SemanticVersion(vstring="0.999.0")
    case_0_input = LooseVersion("0.9.9")

    assert SemanticVersion.from_loose_version(case_0_input) == case_0_expected

# Generated at 2022-06-25 14:03:11.452651
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Make sure we can import LooseVersion
    from ansible.module_utils.compat.version import LooseVersion
    # Simple version
    loose_version = LooseVersion('1.2.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semantic_version, SemanticVersion)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 0

    loose_version = LooseVersion('1.2b0')
    try:
        semantic_version = SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        pass
    else:
        raise Exception("should have raised ValueError")



# Generated at 2022-06-25 14:03:18.432662
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    s = SemanticVersion.from_loose_version(LooseVersion('1.2.3-beta.4+build.5'))
    assert s.major == 1
    assert s.minor == 2
    assert s.patch == 3
    assert s.prerelease == (_Numeric('beta'), _Numeric('4'))
    assert s.buildmetadata == (_Numeric('build'), _Numeric('5'))
    assert s.core == (1, 2, 3)
    assert s.is_prerelease is True
    assert s.is_stable is False
    assert s == '1.2.3-beta.4+build.5'

    s = SemanticVersion.from_loose_version(LooseVersion('1.2.3-beta.4'))
    assert s.buildmetadata == ()

# Generated at 2022-06-25 14:03:20.610460
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(loose_version=LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

# Generated at 2022-06-25 14:03:27.056215
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test: GIVEN: '0.12.0'
    #       WHEN:  #from_loose_version() is called
    #       THEN:  - '0.12.0' is returned as a SemanticVersion

    # Arrange
    loose_version = LooseVersion('0.12.0')

    # Act
    result = SemanticVersion.from_loose_version(loose_version)

    # Assert
    assert(isinstance(result, SemanticVersion))
    assert(isinstance(result.core, tuple))
    assert(result.core[0] == 0)
    assert(result.core[1] == 12)
    assert(result.core[2] == 0)


# Generated at 2022-06-25 14:03:34.764329
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3

    tmp_lver = LooseVersion('1.2alpha1+')
    tmp_result = SemanticVersion.from_loose_version(tmp_lver)
    tmp_expected = SemanticVersion('1.2.0-alpha1+')

    if PY3:
        assert(isinstance(tmp_result.major, int))
        assert(isinstance(tmp_result.minor, int))
        assert(isinstance(tmp_result.patch, int))
        assert(isinstance(tmp_result.prerelease[0], text_type))
    else:
        assert(isinstance(tmp_result.major, int))
        assert(isinstance(tmp_result.minor, int))
        assert(isinstance(tmp_result.patch, int))
       

# Generated at 2022-06-25 14:03:43.470528
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.version import SemanticVersion
    from ansible.module_utils.six.moves import StringIO
    try:
        from contextlib import redirect_stdout
    except ImportError:
        from ansible.module_utils.pycompat24 import redirect_stdout

    # Create a new instance of SemanticVersion
    semantic_version_0 = SemanticVersion()

    # Create a new instance of SemanticVersion
    semantic_version_1 = SemanticVersion()

    # Create a new instance of SemanticVersion
    semantic_version_2 = SemanticVersion()

    # Create a new instance of SemanticVersion
    semantic_version_3 = SemanticVersion()

    # Create a new instance of SemanticVersion
    semantic_version_4 = SemanticVersion()

    # Create a new instance of SemanticVersion
    semantic