

# Generated at 2022-06-25 13:55:34.400776
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert isinstance(semantic_version_1, SemanticVersion)
    assert semantic_version_1 == '1.0.0'
    assert semantic_version_1.is_stable is True
    assert semantic_version_1.is_prerelease is False
    assert semantic_version_1.core == (1, 0, 0)
    assert semantic_version_1.prerelease == ()

    semantic_version_2 = SemanticVersion.from_loose_version(LooseVersion('1.0.0-1'))
    assert isinstance(semantic_version_2, SemanticVersion)
    assert semantic_version_2 == '1.0.0-1'

# Generated at 2022-06-25 13:55:38.775935
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = '0.1.2-alpha.3+build.8'
    loose_version = LooseVersion(v)
    assert SemanticVersion.from_loose_version(loose_version).vstring == '0.1.2-alpha.3+build.8'



# Generated at 2022-06-25 13:55:46.822944
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    net_dev_0 = {
        "mac": "00:54:33:44:55:66",
        "name": "eth0",
        "speed": 10000,
        "statistics": {
            "rx_errors": 0,
        },
    }
    net_dev_1 = {
        "mac": "00:54:33:44:55:66",
        "name": "eth0",
        "speed": 10000,
        "statistics": {
            "rx_errors": 0,
        },
    }
    net_dev_2 = {
        "mac": "00:54:33:44:55:66",
        "name": "eth0",
        "speed": 10000,
        "statistics": {
            "rx_errors": 0,
        },
    }



# Generated at 2022-06-25 13:55:51.528691
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3dev4')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert semantic_version.prerelease[0] == 'dev'
    assert semantic_version.prerelease[1] == 4


# Generated at 2022-06-25 13:55:59.910274
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Simple tests for a valid Semantic Version
    for version in (
        '0.0.4',
        '1.0.0',
        '1.0',
        '1',
        '2.0.0-alpha',
        '2.0.0-alpha.1',
        '2.0.0-0.3.7',
        '2.0.0-x.7.z.92',
        '2.0.0-alpha+001',
        '2.0.0+20130313144700',
        '1.0.0-beta+exp.sha.5114f85',
    ):
        SemanticVersion(version)



# Generated at 2022-06-25 13:56:06.648475
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-25 13:56:13.991399
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:56:18.566562
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version_string = "1.5.5.0"
    loose_version_0 = LooseVersion(version_string)

    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 5
    assert semantic_version_0.patch == 5
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()


# Generated at 2022-06-25 13:56:25.089199
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
        assert False, "SemanticVersion.from_loose_version with valid LooseVersion should not throw an exception"
    except ValueError:
        pass

    try:
        SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta.1'))
        assert False, "SemanticVersion.from_loose_version with valid LooseVersion should not throw an exception"
    except ValueError:
        pass


# Generated at 2022-06-25 13:56:27.154312
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion()


# Generated at 2022-06-25 13:56:48.527234
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-rc2')) == SemanticVersion('1.0.0-rc2')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')) == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0-rc2')) == SemanticVersion('0.0.0-rc2')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

# Generated at 2022-06-25 13:56:54.760713
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1+build.1'))
    assert semantic_version_0.vstring == '1.0.0-alpha.1+build.1'
    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 0
    assert semantic_version_0.patch == 0
    assert semantic_version_0.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert semantic_version_0.buildmetadata == (_Alpha('build'), _Numeric('1'))


# Generated at 2022-06-25 13:57:00.617741
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version = SemanticVersion()

    # Failed to instantiate SemanticVersion from LooseVersion
    with pytest.raises(ValueError):
        semantic_version.from_loose_version('')

    # Failed to instantiate SemanticVersion from LooseVersion that contains non-integer values
    with pytest.raises(ValueError):
        semantic_version.from_loose_version('1.2.3-alpha1')

    # Successfully instantiate SemanticVersion from LooseVersion
    assert semantic_version.from_loose_version(LooseVersion('1.2.3'))


# Generated at 2022-06-25 13:57:09.539308
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    from ansible.module_utils.common._text import to_text
    from ansible.module_utils.semver import SemanticVersion

    assert SemanticVersion.parse('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion.parse('1.2.3+foo') == SemanticVersion('1.2.3+foo')
    assert SemanticVersion.parse('1.2.3-foo.1+bar') == SemanticVersion('1.2.3-foo.1+bar')

    try:
        SemanticVersion.parse('1.2.3.4')
        failed = False
    except ValueError:
        failed = True
    assert failed


# Generated at 2022-06-25 13:57:17.177768
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-25 13:57:27.065753
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    loose_version_0 = LooseVersion()
    try:
        semantic_version_0.from_loose_version(loose_version_0)
    except ValueError:
        assert True

    loose_version_1 = LooseVersion('0.0.0')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    actual = semantic_version_1
    expected = '0.0.0'
    assert actual == expected

    loose_version_2 = LooseVersion('1')
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version_2)
    actual = semantic_version_2
    expected = '1.0.0'
    assert actual == expected

    loose_

# Generated at 2022-06-25 13:57:35.368408
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('0.0.0'))) == '0.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('0.0.1'))) == '0.0.1'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.0.0'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.1.0'))) == '1.1.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.1.1'))) == '1.1.1'

# Generated at 2022-06-25 13:57:44.131423
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert_raises(ValueError, SemanticVersion, 'abc')
    assert_raises(ValueError, SemanticVersion, '1.2.3+foo')


# Generated at 2022-06-25 13:57:46.815489
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion("1.2.3")
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == "1.2.3"
    assert sv.core == (1, 2, 3)
    assert sv.is_stable


# Generated at 2022-06-25 13:57:54.813890
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import cStringIO
    import sys

    # Capture stderr to prevent test from failing due to error output
    stderr = sys.stderr
    sys.stderr = cStringIO()
    try:
        # Test that SemanticVersion.from_loose_version raises ValueError
        # on attempt to convert non LooseVersion to SemanticVersion
        assert SemanticVersion.from_loose_version(object())
        assert False, "Expected ValueError"
    except ValueError:
        pass
    finally:
        sys.stderr = stderr
    # Test that SemanticVersion.from_loose_version raises ValueError
    # on attempt to convert LooseVersion with non-integer values
    # to SemanticVersion

# Generated at 2022-06-25 13:58:08.206411
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    string_version = '1.1.1'
    expected = SemanticVersion('1.1.1')
    actual = SemanticVersion.from_loose_version(LooseVersion(string_version))
    assert actual == expected


# Generated at 2022-06-25 13:58:11.243779
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion("1.0")
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0 != None



# Generated at 2022-06-25 13:58:13.288680
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = '1.1.1'
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.1.1'


# Generated at 2022-06-25 13:58:17.179879
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    loose_version_0 = LooseVersion('1.2.3')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    str_0 = str(semantic_version_0)
    assert str_0 == '1.2.3'


# Generated at 2022-06-25 13:58:21.163195
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create sample LooseVersion object
    loose_version = LooseVersion('1.0')
    # Call test method
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # TODO: Implement assertion
    assert(isinstance(semantic_version, SemanticVersion))
    # TODO: Implement assertion
    assert(semantic_version.core == (1,0,0))



# Generated at 2022-06-25 13:58:27.265381
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert(str(SemanticVersion.from_loose_version(LooseVersion('0.0.0'))) == '0.0.0')
    assert(str(SemanticVersion.from_loose_version(LooseVersion('0.0.0-pre.3'))) == '0.0.0-pre.3')
    assert(str(SemanticVersion.from_loose_version(LooseVersion('0.0.0-pre.3.4'))) == '0.0.0-pre.3.4')
    assert(str(SemanticVersion.from_loose_version(LooseVersion('0.0.0+build.1.2'))) == '0.0.0+build.1.2')

# Generated at 2022-06-25 13:58:36.328561
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.2.2a5')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '2.2.2a5'


# The following test cases are taken from:
# https://github.com/k-bx/semver/blob/master/tests/vercmp.t
#
# The following is the original copyright notice:
#
# Copyright (c) by the individual authors. For more information see the
# AUTHORS file.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
#   * Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.


# Generated at 2022-06-25 13:58:41.602264
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    loose_version = LooseVersion('2.9.9')
    expected = SemanticVersion('2.9.9')
    actual = SemanticVersion.from_loose_version(loose_version)
    assert actual == expected, \
        'The output of SemanticVersion.from_loose_version(loose_version) did not match the expected results'


# Generated at 2022-06-25 13:58:46.398793
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose = LooseVersion('0.9.0')
    s = SemanticVersion.from_loose_version(loose)
    assert(isinstance(s, SemanticVersion))
    assert(s.major == 0)
    assert(s.minor == 9)
    assert(s.patch == 0)
    assert(s.prerelease == ())
    assert(s.buildmetadata == ())
    assert(s.is_stable is False)



# Generated at 2022-06-25 13:58:53.062456
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()

    # Confirm the specifier is not set initially
    assert(semantic_version.vstring is None)

    # Confirm parsing a valid string sets the vstring
    specifier = '1.0.0'
    semantic_version.parse(specifier)
    assert(semantic_version.vstring == specifier)

    # Confirm parsing an invalid string raises a ValueError
    specifier = 'foo'
    try:
        semantic_version.parse(specifier)
        # If we reach this point, parsing the invalid string should have
        # raised an exception
        assert(False)
    except ValueError as e:
        # Confirm the ValueError has a message
        assert(e.args[0] == 'invalid semantic version \'%s\'' % specifier)


# Generated at 2022-06-25 13:59:09.771103
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '2.3.4-5.6.7+8'
    loose_version = LooseVersion(vstring)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert text_type(semantic_version) == vstring

# Generated at 2022-06-25 13:59:16.934990
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Negative test: Raises ValueError for non-LooseVersion
    instance = SemanticVersion()
    try:
        instance.from_loose_version(LooseVersion('0.0.0'))
    except ValueError as ex:
        assert str(ex) == "invalid semantic version '0.0.0'"
    else:
        assert False, "Failed to assert that SemanticVersion.from_loose_version raises ValueError"

    # Positive test - From valid string
    instance = SemanticVersion()
    version = instance.from_loose_version('0.5.5+20180321')
    assert version.major == 0
    assert version.minor == 5
    assert version.patch == 5
    assert version.prerelease == ()
    assert version.buildmetadata == ('20180321',)

    # Positive test

# Generated at 2022-06-25 13:59:25.244818
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.0')
    # Call SemanticVersion.from_loose_version with argument loose_version_0
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    loose_version_1 = LooseVersion('1.0.0')
    # Call SemanticVersion.from_loose_version with argument loose_version_1
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert semantic_version_0 == semantic_version_1

    loose_version_2 = LooseVersion('1.0.0.dev1')
    # Call SemanticVersion.from_loose_version with argument loose_version_2
    semantic_version_2 = SemanticVersion.from_loose

# Generated at 2022-06-25 13:59:29.225772
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0


# Generated at 2022-06-25 13:59:36.399153
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:59:45.258937
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    LooseVersion_vstring_a, SemanticVersion_vstring_a = ("1.6.0", "1.6.0")
    expected = SemanticVersion(SemanticVersion_vstring_a)
    actual = SemanticVersion.from_loose_version(LooseVersion(LooseVersion_vstring_a))
    assert actual == expected

    LooseVersion_vstring_b, SemanticVersion_vstring_b = ("1.6.0b", "1.6.0-b")
    expected = SemanticVersion(SemanticVersion_vstring_b)
    actual = SemanticVersion.from_loose_version(LooseVersion(LooseVersion_vstring_b))
    assert actual == expected


# Generated at 2022-06-25 13:59:49.736445
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion('1.2'))
    assert semantic_version_1.core == (1, 2, 0)
    assert semantic_version_1.prerelease == ()

    semantic_version_2 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha'))
    assert semantic_version_2.core == (1, 2, 3)
    assert semantic_version_2.prerelease == ('alpha', )

    semantic_version_3 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build.1'))
    assert semantic_version_3.core == (1, 2, 3)
    assert semantic_version_3.prerelease == ('alpha', )
    assert semantic_

# Generated at 2022-06-25 13:59:52.051573
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('10.1.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semantic_version, SemanticVersion)
    assert semantic_version == '10.1.0'


# Generated at 2022-06-25 13:59:54.458932
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.0.0'


# Generated at 2022-06-25 13:59:56.621881
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Given
    loose_version = LooseVersion('9.9.9-rc.6.2+debian')

    # When
    SemanticVersion.from_loose_version(loose_version)



# Generated at 2022-06-25 14:00:18.367037
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')) == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev1')) == SemanticVersion('1.2.3-dev1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev1.post2')) == SemanticVersion('1.2.3-dev1.post2')
   

# Generated at 2022-06-25 14:00:20.854030
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.0.0')



# Generated at 2022-06-25 14:00:23.547057
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semver = SemanticVersion.from_loose_version(LooseVersion('1.2.3-beta'))
    assert str(semver) == '1.2.3-beta'


# Generated at 2022-06-25 14:00:26.786934
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version)

# Unit tests for class SemanticVersion

# Generated at 2022-06-25 14:00:28.707276
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test normal usage
    loose_version = LooseVersion('1.2.4')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.4'


# Generated at 2022-06-25 14:00:33.816312
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create a LooseVersion object
    loose_version = LooseVersion('1.0.0')
    # Create a SemanticVersion object from the LooseVersion object
    # passed in
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    # Ensure that the vstring of the SemanticVersion object was
    # properly converted
    assert semantic_version.vstring == '1.0.0'


# Generated at 2022-06-25 14:00:41.271314
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test error if not LooseVersion
    failed = False
    try:
        SemanticVersion.from_loose_version('0.3.3')
    except ValueError:
        failed = True
    assert failed

    # LooseVersion with no extras
    v = SemanticVersion.from_loose_version(LooseVersion('0.3.3'))
    assert v.major == 0
    assert v.minor == 3
    assert v.patch == 3
    assert not v.prerelease
    assert not v.buildmetadata

    # LooseVersion with prerelease
    v = SemanticVersion.from_loose_version(LooseVersion('0.3.3-1.0.0'))
    assert v.major == 0
    assert v.minor == 3
    assert v.patch == 3

# Generated at 2022-06-25 14:00:44.913401
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion(
        '0.1.2-alpha.1+build.a.b.c.d'
    )
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.__class__.__name__ == 'SemanticVersion'
    assert semantic_version.vstring == '0.1.2-alpha.1+build.a.b.c.d'



# Generated at 2022-06-25 14:00:47.221542
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion()
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert "__len__" == semantic_version_0


# Generated at 2022-06-25 14:00:54.270584
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    #
    # Test for case 0 - Invalid types
    #
    try:
        SemanticVersion.from_loose_version([])
        assert False, "An exception should have been raised"
    except ValueError:
        pass
    except Exception as e:
        assert False, "The wrong exception was thrown: %r" % e

    try:
        SemanticVersion.from_loose_version(None)
        assert False, "An exception should have been raised"
    except ValueError:
        pass
    except Exception as e:
        assert False, "The wrong exception was thrown: %r" % e

    #
    # Test for case 1 - No extra
    #
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')

# Generated at 2022-06-25 14:01:11.318416
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('')
    SemanticVersion_0 = SemanticVersion.from_loose_version(loose_version_0) # expect exception to be raised here


# Generated at 2022-06-25 14:01:15.150069
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.1')).core == (1, 2, 1)
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.1-alpha.1+20130313144700')).core == (1, 2, 1)



# Generated at 2022-06-25 14:01:17.243448
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.0.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)


# Generated at 2022-06-25 14:01:25.896382
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv0 = LooseVersion("1.0.0")
    lv1 = LooseVersion("0.0.1")
    lv2 = LooseVersion("0.10.1")
    lv3 = LooseVersion("1.0.0-pre.3")
    lv4 = LooseVersion("1.0.0+build.1")
    lv5 = LooseVersion("0.0.0-pre.3")
    lv6 = LooseVersion("1.0.0-pre.3+build.8")

    sv0 = SemanticVersion.from_loose_version(lv0)
    sv1 = SemanticVersion.from_loose_version(lv1)
    sv2 = SemanticVersion.from_loose_version(lv2)
    sv3 = SemanticVersion.from_

# Generated at 2022-06-25 14:01:33.000916
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with LooseVersion
    loose_version = LooseVersion('1.2.3-4.5+6.7')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3-4.5+6.7')

    # Test with non LooseVersion
    assert SemanticVersion.from_loose_version(object()) == None

    # Test of LooseVersion with non integer values
    loose_version = LooseVersion('1.foo.3-4.5+6.7')
    assert SemanticVersion.from_loose_version(loose_version) == None


# Unit test to compare SemanticVersion with LooseVersion

# Generated at 2022-06-25 14:01:39.335961
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    See also https://github.com/python/cpython/pull/20356
    """
    loose_version = LooseVersion('0.0.0')
    assert SemanticVersion.from_loose_version(loose_version) == '0.0.0'
    loose_version = LooseVersion('0.0.1')
    assert SemanticVersion.from_loose_version(loose_version) == '0.0.1'
    loose_version = LooseVersion('1.0.0')
    assert SemanticVersion.from_loose_version(loose_version) == '1.0.0'
    loose_version = LooseVersion('1.0.1')
    assert SemanticVersion.from_loose_version(loose_version) == '1.0.1'
    loose

# Generated at 2022-06-25 14:01:44.468089
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion("2.5.1"))
    assert isinstance(semantic_version_1, SemanticVersion)
    semantic_version_2 = SemanticVersion.from_loose_version(LooseVersion("2.5.1dev1"))
    assert isinstance(semantic_version_2, SemanticVersion)
    semantic_version_3 = SemanticVersion.from_loose_version(LooseVersion("2.5.1.dev1"))
    assert isinstance(semantic_version_3, SemanticVersion)


# Generated at 2022-06-25 14:01:51.165383
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:58.164554
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        SemanticVersion.from_loose_version('0.7')
    except ValueError:
        pass
    else:
        raise AssertionError("SemanticVersion.from_loose_version did not raise ValueError on invalid input")

    semantic_version_0 = SemanticVersion.from_loose_version('0.7.0')
    if semantic_version_0.vstring != '0.7.0':
        raise AssertionError("SemanticVersion.from_loose_version() did not return correct vstring, got {semantic_version_0.vstring}")
    if semantic_version_0.core != (0, 7, 0):
        raise AssertionError("SemanticVersion.from_loose_version() did not return correct core, got {semantic_version_0.core}")


# Generated at 2022-06-25 14:02:05.525360
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version1 = LooseVersion('4.0.16b1')
    loose_version2 = LooseVersion('4.0.16b1.dev0')
    loose_version3 = LooseVersion('4.0.16b1.dev0+gf19b898')
    loose_version4 = LooseVersion('4.0.16b1.dev0+gf19b898.dirty')
    loose_version5 = LooseVersion('1.1.1')
    loose_version6 = LooseVersion('1.1.1.dev0')
    loose_version7 = LooseVersion('1.1.1.dev0+gf19b898')
    loose_version8 = LooseVersion('1.1.1.dev0+gf19b898.dirty')
    loose_version9

# Generated at 2022-06-25 14:03:00.566895
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.common.version import LooseVersion

    for value in [
        LooseVersion('1.0.0'),
        LooseVersion('2.3.4'),
        LooseVersion('4.5.6-alpha1'),
        LooseVersion('4.5.6-alpha2'),
        LooseVersion('4.5.6-beta1'),
        LooseVersion('4.5.6-rc1'),
    ]:
        if PY2:
            assert isinstance(SemanticVersion.from_loose_version(value), SemanticVersion)
        else:
            assert isinstance(SemanticVersion.from_loose_version(value), text_type)


# Generated at 2022-06-25 14:03:01.993911
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    pass


if __name__ == '__main__':
    test_case_0()
    test_SemanticVersion_from_loose_version()

# Generated at 2022-06-25 14:03:07.390212
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    with pytest.raises(ValueError) as exc_info:
        SemanticVersion.from_loose_version(
            LooseVersion('1.2.3-alpha.1+build.2920')
        )
    assert exc_info.value.args[0] == "Invalid character: 'a'"

    # Ensure we can pass in a unicode string
    with pytest.raises(ValueError) as exc_info:
        SemanticVersion.from_loose_version(
            LooseVersion('1.2.3-alpha.1+build.2920')
        )
    assert exc_info.value.args[0] == "Invalid character: 'a'"

    # Ensure we can pass in a bytes string
    with pytest.raises(ValueError) as exc_info:
        SemanticVersion.from_loose

# Generated at 2022-06-25 14:03:09.937022
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version='2.7.1.final.0')
    assert semantic_version_0.major == 2
    assert semantic_version_0.minor == 7
    assert semantic_version_0.patch == 1


# Generated at 2022-06-25 14:03:11.885556
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.0'



# Generated at 2022-06-25 14:03:18.966470
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test Case 1
    loose_version_1 = LooseVersion('1.0.0')
    result = SemanticVersion.from_loose_version(loose_version_1)
    assert result.vstring == '1.0.0'
    assert result.major == 1
    assert result.minor == 0
    assert result.patch == 0
    assert result.prerelease == ()

    # Test Case 2
    loose_version_2 = LooseVersion('1.0.0-beta+foo')
    result = SemanticVersion.from_loose_version(loose_version_2)
    assert result.vstring == '1.0.0-beta+foo'
    assert result.major == 1
    assert result.minor == 0
    assert result.patch == 0

# Generated at 2022-06-25 14:03:25.322687
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Input parameters, note that these vary depending on the method
    # and that there may be required and optional parameters:
    semantic_version_0 = SemanticVersion()
    loose_version_0 = LooseVersion()
    # The call to the method:
    try:
        returned_value = SemanticVersion.from_loose_version(loose_version_0)
    # The expected exception:
    except ValueError as e:
        assert True
    # The returned value (if any), note that this will vary:
    # The type of the returned value (if any), note that this will vary:
    assert isinstance(returned_value, SemanticVersion)


# Generated at 2022-06-25 14:03:27.934736
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = '0.0.1'
    loose_version = LooseVersion(version)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == version


# Generated at 2022-06-25 14:03:35.595766
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion and SemanticVersion compare as equal
    loose_version_0 = LooseVersion('2.0.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert loose_version_0 == semantic_version_0
    loose_version_1 = LooseVersion('3.0.0')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert loose_version_1 == semantic_version_1
    loose_version_2 = LooseVersion('1.1.0')
    assert loose_version_2 == SemanticVersion.from_loose_version(loose_version_2)
    # LooseVersion and SemanticVersion do not compare as equal
    loose_version_3 = LooseVersion

# Generated at 2022-06-25 14:03:44.487437
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    loose_version_0 = LooseVersion("1.0.0")
    semantic_version_0.from_loose_version(loose_version_0)
    loose_version_1 = LooseVersion("0.0.0")
    semantic_version_1 = SemanticVersion()
    semantic_version_1.from_loose_version(loose_version_1)
    loose_version_2 = LooseVersion("0.0.0+foo")
    semantic_version_1.from_loose_version(loose_version_2)
    loose_version_3 = LooseVersion("1.0.0+foo")
    semantic_version_2 = SemanticVersion()
    semantic_version_2.from_loose_version(loose_version_3)

# Generated at 2022-06-25 14:04:15.184276
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion('1.2b3')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.core == (1, 2, 0)
    assert sv.prerelease == (_Numeric(0), _Alpha('b'), _Numeric(3))
    assert sv.buildmetadata == ()

    lv = LooseVersion('1.2b-3.4')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.core == (1, 2, 0)
    assert sv.prerelease == (_Numeric(0), _Alpha('b'), _Alpha('-3'), _Numeric(4))
    assert sv.buildmetadata == ()

    lv = LooseVersion('1.2b-3.4a5')
    sv = SemanticVersion.from_lo

# Generated at 2022-06-25 14:04:21.639211
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()


# Generated at 2022-06-25 14:04:29.168462
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v_0 = SemanticVersion('1.2.3')
    lv_0 = LooseVersion(v_0.vstring)
    assert SemanticVersion.from_loose_version(lv_0) == v_0

    v_1 = SemanticVersion('1.2.3-alpha.1')
    lv_1 = LooseVersion(v_1.vstring)
    assert SemanticVersion.from_loose_version(lv_1) == v_1

    v_2 = SemanticVersion('1.2.3+build.1')
    lv_2 = LooseVersion(v_2.vstring)
    assert SemanticVersion.from_loose_version(lv_2) == v_2

    v_3 = SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-25 14:04:30.858088
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = '0.1.2'
    loose_version = LooseVersion(v)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == v


# Generated at 2022-06-25 14:04:37.695626
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = LooseVersion('1.2.3-4.5.6+7.8.9')
    semantic_version = SemanticVersion.from_loose_version(version)
    assert semantic_version.vstring == '1.2.3-4.5.6+7.8.9'
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert semantic_version.core == (1, 2, 3)
    assert semantic_version.prerelease == (_Numeric('4'), _Alpha('5'), _Numeric('6'))
    assert semantic_version.buildmetadata == (_Alpha('7'), _Alpha('8'), _Alpha('9'))
    assert not semantic_version.is_prerelease
    assert semantic_version.is_stable

# Generated at 2022-06-25 14:04:42.829918
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # A LooseVersion should be able to be converted
    v1 = '1.6.0'
    assert v1 == SemanticVersion.from_loose_version(LooseVersion(v1))

    # Only LooseVersion should be accepted
    try:
        SemanticVersion.from_loose_version('1.6.0')
    except ValueError as e:
        assert 'is not a LooseVersion' in str(e)

    # Only LooseVersion with integer identifiers should be accepted
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.6.0a'))
    except ValueError as e:
        assert 'Non integer values' in str(e)

    # A LooseVersion ending with a prerelease should be able
    # to be converted

# Generated at 2022-06-25 14:04:44.449168
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version = SemanticVersion()
    loose_version = LooseVersion()
    semantic_version.from_loose_version(loose_version)

# Generated at 2022-06-25 14:04:50.999723
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check that a valid LooseVersion can be converted to a SemanticVersion
    result = SemanticVersion.from_loose_version(LooseVersion('0.0.1'))
    assert result.vstring == '0.0.1'
    assert isinstance(result, SemanticVersion)

    # Check that a LooseVersion with a prerelease cannot be converted to a SemanticVersion
    try:
        SemanticVersion.from_loose_version(LooseVersion('0.0.1-pre'))
    except ValueError as e:
        assert str(e) == 'invalid semantic version \'0.0.1-pre\''
    else:
        raise AssertionError('should have raised ValueError')

    # Check that a LooseVersion with a build can't be converted to a SemanticVersion

# Generated at 2022-06-25 14:04:55.819095
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import StringIO
    original_stderr = StringIO()
    try:
        import sys
        stderr = sys.stderr
        sys.stderr = original_stderr
        loose_version = LooseVersion("1.5.7")
        assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion("1.5.7")
    finally:
        sys.stderr = stderr

if __name__ == '__main__':
    test_case_0()
    test_SemanticVersion_from_loose_version()

# Generated at 2022-06-25 14:05:02.213046
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version(LooseVersion('1.0.0-rc1'))
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert isinstance(version.prerelease[0], _Alpha)
    assert text_type(version.prerelease[0]) == 'rc1'
    assert version.buildmetadata == ()

    version = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version = SemanticVersion.from_loose_version(LooseVersion('1.0.0+foo.bar'))